# this was autocreated, please add functions in there
import kangarooTools.nodes as nodes
import kangarooTools.utilFunctions as utils
import kangarooTools.xforms as xforms
import kangarooTools.deformers as deformers
import kangarooTools.curves as curves
import kangarooTools.patch as patch

import kangarooTabTools.builder as builderTools
import kangarooTabTools.weights as weights
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.geometry as geometry
import kangarooTabTools.interpolator as interpolator
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.assets as assets

from collections import defaultdict

import maya.cmds as cmds
import maya.mel as mel
import numpy as np
import os

kBuilderColor = utils.uiColors.default



@builderTools.addToBuild(iOrder=100, dButtons={})
def setDefaultValues():
    # cmds.setAttr('eyesLookAtLFT_ctrl.lidFollow', 0.5)
    pass


@builderTools.addToBuild(iOrder=132, dButtons={})
def hideUnrealEyes():
    cmds.setAttr('unrealEyes.v', False)
    pass


