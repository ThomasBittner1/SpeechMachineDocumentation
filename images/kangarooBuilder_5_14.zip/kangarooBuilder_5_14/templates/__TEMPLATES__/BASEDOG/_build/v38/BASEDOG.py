# this was autocreated, please add functions in there
import os

import kangarooTools.nodes as nodes
import kangarooTools.utilFunctions as utils
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.patch as patch
import kangarooTools.constraints as constraints
import kangarooTools.deformers as deformers

import kangarooTabTools.builder as builderTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.weights as weights
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.blendShapesPro as blendShapesPro
import kangarooTabTools.geometry as geometry

import maya.cmds as cmds
import maya.mel as mel
import numpy as np


kBuilderColor = utils.uiColors.default






@builderTools.addToBuild(iOrder=55)
def setDefaultValues():
    pass
