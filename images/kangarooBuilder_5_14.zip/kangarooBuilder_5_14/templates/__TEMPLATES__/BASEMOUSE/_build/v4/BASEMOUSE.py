# this was autocreated, please add functions in there
import os

import kangarooTools.nodes as nodes
import kangarooTools.utilFunctions as utils
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.patch as patch
import kangarooTools.constraints as constraints
import kangarooTools.deformers as deformers

import kangarooTabTools.builder as builderTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.weights as weights
import kangarooTabTools.blendShapes as blendShapes

import maya.cmds as cmds
import numpy as np


kBuilderColor = utils.uiColors.default


# 2.142



@builderTools.addToBuild(iOrder=104)
def setDefaultValues(_report=None):
    pass





