# this was autocreated, please add functions in there
import kangarooTools.nodes as nodes
import kangarooTools.utilFunctions as utils

import kangarooTabTools.builder as builderTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.weights as weights
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTabTools.blendShapes as blendShapes

import maya.cmds as cmds

kBuilderColor = utils.uiColors.default



@builderTools.addToBuild(iOrder=104)
def setDefaultValues(_report=None):
    # ctrls.ctrlFromName('hips_ctrl').convertToSimpleTransforms()

    pass






