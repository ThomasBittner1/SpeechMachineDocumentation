# this was autocreated, please add functions in there
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator

import kangarooTabTools.builder as builderTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.puppet as puppet
import kangarooTabTools.geometry as geometry
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.blendShapesPro as blendShapesPro


import numpy as np
import maya.cmds as cmds
import maya.mel as mel

kBuilderColor = utils.uiColors.default



@builderTools.addToBuild(iOrder=104)
def setDefaultValues(_report=None):
    # ctrls.ctrlFromName('ctrl_m_neckBaseIk').convertToSimpleTransforms()
    pass


