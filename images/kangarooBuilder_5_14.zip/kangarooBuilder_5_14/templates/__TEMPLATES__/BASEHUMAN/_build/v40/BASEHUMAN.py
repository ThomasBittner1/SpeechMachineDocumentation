# this was autocreated, please add functions in there
import kangarooTools.nodes as nodes
import kangarooTools.utilFunctions as utils
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.blendShapesPro as blendShapesPro

import kangarooTabTools.builder as builderTools
import kangarooTabTools.interpolator as interpolator

import maya.cmds as cmds

kBuilderColor = utils.uiColors.default



@builderTools.addToBuild(iOrder=104)
def setDefaultValues(_report=None):
    # ctrls.ctrlFromName('hips_ctrl').convertToSimpleTransforms()
    pass

