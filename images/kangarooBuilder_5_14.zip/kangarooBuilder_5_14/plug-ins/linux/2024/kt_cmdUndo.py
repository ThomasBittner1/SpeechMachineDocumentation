###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.OpenMayaMPx as OpenMayaMPx
import maya.api.OpenMaya as OpenMaya2
import maya.OpenMaya as OpenMaya
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.OpenMayaAnim as OpenMayaAnim
import maya.cmds as cmds

import sys
import numpy as np
import ctypes



# name our command
kPluginCmdName="kt_cmdUndo"

kDataFlag = "-dt"
kDataFlagLong = "-data"


class cmdUndoCommand(OpenMayaMPx.MPxCommand):

    def __init__(self):
        OpenMayaMPx.MPxCommand.__init__(self)



    def doIt(self, args):
        # find out how many iterations
        #
        syntax = OpenMaya.MSyntax()

        syntax.addFlag( kDataFlag, kDataFlagLong, OpenMaya2.MSyntax.kString )


        argData = OpenMaya.MArgDatabase( syntax, args )
        if argData.isFlagSet( kDataFlag ):
            idAddress = argData.flagArgumentString( kDataFlag, 0 )

        dData = ctypes.cast(eval(idAddress), ctypes.py_object).value


        if 'funcRedo' in dData:
            self.funcRedo = dData['funcRedo']
            self.funcUndo = dData['funcUndo']
        else:
            self.funcRedo = None
            self.funcUndo = None

            if 'fJointWeights' in dData:
                self.sMesh = dData['sMesh']
                self.aIds = np.copy(dData['aIds'])
                self.mSkinCluster = getDependNode(dData['sSkinCluster'])
                self.mJointWeights = OpenMaya2.MDoubleArray(dData['fJointWeights'])
                self.mInfluences = OpenMaya2.MIntArray(list(range(dData['iInfCount'])))
                fOldWeights = dData['fOldJointWeights']
                self.mOldJointWeights = OpenMaya2.MDoubleArray(fOldWeights) if not isNone(fOldWeights) else None
            else:
                self.mJointWeights = None
                self.mOldJointWeights = None

            if 'fBlendWeights' in dData:
                self.sMesh = dData['sMesh']
                self.aIds = np.copy(dData['aIds'])
                self.mSkinCluster = getDependNode(dData['sSkinCluster'])
                self.mBlendWeights = OpenMaya2.MDoubleArray(dData['fBlendWeights'])
                self.mOldBlendWeights = OpenMaya2.MDoubleArray(dData['fOldBlendWeights'])
            else:
                self.mBlendWeights = None
                self.mOldBlendWeights = None


            if 'fDeformerWeights' in dData:
                self.sMesh = dData['sMesh']
                self.aIds = np.copy(dData['aIds'])
                self.mDeformerOldApi = getDependNodeOldApi(dData['sDeformer'])
                self.mDeformerWeights = OpenMaya.MFloatArray(len(self.aIds))
                self.mOldDeformerWeights = OpenMaya.MFloatArray(len(self.aIds))
                # print ('aIds: ', self.aIds)
                for i in range(len(self.aIds)):
                    self.mDeformerWeights.set(dData['fDeformerWeights'][i], i)
                    self.mOldDeformerWeights.set(dData['fOldDeformerWeights'][i], i)

            self.mPoints = dData.get('mPoints', None)
            if not isNone(self.mPoints):
                self.sMesh = dData['sMesh']
                self.mMesh = getDagPath(dData['sMesh'])
                self.mSpace = dData['mSpace']
                self.mOldPoints = dData.get('mOldPoints', None)
            else:
                self.mOldPoints = None

        self.redoIt()


    def redoIt(self):

        if self.funcRedo:
            self.funcRedo()

        else:
            pPatch = patchFromName(self.sMesh)

            if self.mJointWeights:
                fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(self.mSkinCluster)
                fnSkinCluster.setWeights(pPatch.mDagPath, pPatch.getIndexedComponents(aOverrideIds=self.aIds), self.mInfluences, self.mJointWeights)

            if self.mBlendWeights:
                fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(self.mSkinCluster)
                fnSkinCluster.setBlendWeights(pPatch.mDagPath, pPatch.getIndexedComponents(aOverrideIds=self.aIds), self.mBlendWeights)

            if self.mPoints:
                OpenMaya2.MFnMesh(self.mMesh).setPoints(self.mPoints, space=self.mSpace)

            if hasattr(self, 'mDeformerWeights'):
                mFnWeightFilter = OpenMayaAnim.MFnWeightGeometryFilter(self.mDeformerOldApi)
                mFnWeightFilter.setWeight(getDagPathOldApi(self.sMesh), pPatch.getIndexedComponentsOldApi(self.aIds), self.mDeformerWeights)


    def undoIt(self):

        if self.funcUndo:
            self.funcUndo()

        else:
            pPatch = patchFromName(self.sMesh)

            if self.mOldJointWeights != None:
                fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(self.mSkinCluster)
                fnSkinCluster.setWeights(pPatch.mDagPath, pPatch.getIndexedComponents(aOverrideIds=self.aIds), self.mInfluences, self.mOldJointWeights)

            if self.mBlendWeights != None and self.mOldBlendWeights != None:
                fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(self.mSkinCluster)
                fnSkinCluster.setBlendWeights(pPatch.mDagPath, pPatch.getIndexedComponents(aOverrideIds=self.aIds), self.mOldBlendWeights)

            if self.mOldPoints != None:
                OpenMaya2.MFnMesh(self.mMesh).setPoints(self.mOldPoints, space=self.mSpace)

            if hasattr(self, 'mDeformerWeights'):
                mFnWeightFilter = OpenMayaAnim.MFnWeightGeometryFilter(self.mDeformerOldApi)
                mFnWeightFilter.setWeight(getDagPathOldApi(self.sMesh), pPatch.getIndexedComponentsOldApi(self.aIds), self.mOldDeformerWeights)


    def isUndoable(self):
        return True


    def isRedoable(self):
        return True



def cmdCreator():
    return OpenMayaMPx.asMPxPtr( cmdUndoCommand() )


def initializePlugin(mobject):
    mplugin = OpenMayaMPx.MFnPlugin(mobject, "Thomas Bittner", "5.0", "Any")
    try:
        mplugin.registerCommand( kPluginCmdName, cmdCreator)
    except:
        sys.stderr.write( "Failed to register command: %s\n" % kPluginCmdName )
        raise


def uninitializePlugin(mobject):
    mplugin = OpenMayaMPx.MFnPlugin(mobject)
    try:
        mplugin.deregisterCommand( kPluginCmdName )
    except:
        sys.stderr.write( "Failed to unregister command: %s\n" % kPluginCmdName )
        raise





def patchFromName(sName, ):
    if not sName or not cmds.objExists(sName):
        return None
        raise Exception('cannot make a patch from %s' % sName)

    mDagPath = getDagPath(sName)
    mDagPath = mDagPath.extendToShape()
    if mDagPath.hasFn(OpenMaya2.MFn.kMesh):
        return MeshPatch(mDagPath, None, None)
    if mDagPath.hasFn(OpenMaya2.MFn.kNurbsSurface):
        return SurfacePatch(mDagPath, None, None)
    if mDagPath.hasFn(OpenMaya2.MFn.kNurbsCurve):
        return CurvePatch(mDagPath, None, None)




class Patch():
    def __init__(self, mDagPath, aIds=None, aSofts=None):
        self.mDagPath = mDagPath
        self.aSofts = aSofts
        if not isNone(aIds):# != None:
            self.aIds = aIds
        else:
            self.aIds = np.arange(self.getTotalCount())


class MeshPatch(Patch):
    def __init__(self, sName, aIds=None, aSofts=None):
        Patch.__init__(self, sName, aIds=aIds, aSofts=aSofts)
        def __repr__(self):
            return 'mesh: "%s" ids: %s softs: %s' % (self.mDagPath.partialPathName(), self.aIds, self.aSofts)

    def getIndexedComponents(self, aOverrideIds=None):
        fnVtxComp = OpenMaya2.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create(OpenMaya2.MFn.kMeshVertComponent)
        fnVtxComp.addElements(list(aOverrideIds if type(aOverrideIds) != type(None) else self.aIds))
        return self.mComponents


    def getIndexedComponentsOldApi(self, aOverrideIds=None):
        fnVtxComp = OpenMaya.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya.MFn.kMeshVertComponent )
        aIds = aOverrideIds if not isNone(aOverrideIds) else self.aIds
        mIds = OpenMaya.MIntArray(len(aIds))
        for i,id in enumerate(aIds):
            mIds.set(int(id),int(i)) # one of them needs to not get converted to int
        fnVtxComp.addElements(mIds)
        return self.mComponents


    def getTotalCount(self):
        return OpenMaya2.MFnMesh(self.mDagPath).numVertices




class CurvePatch(Patch):
    def __init__(self, sName, aIds=None, aSofts=None):
        Patch.__init__(self, sName, aIds=aIds, aSofts=aSofts)

    def getIndexedComponents(self, aOverrideIds=None):
        fnVtxComp = OpenMaya2.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya2.MFn.kCurveCVComponent )
        fnVtxComp.addElements(list(aOverrideIds if not isNone(aOverrideIds) else self.aIds))
        return self.mComponents


    def getIndexedComponentsOldApi(self, aOverrideIds=None):
        fnVtxComp = OpenMaya.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya.MFn.kMeshVertComponent )
        aIds = aOverrideIds if not isNone(aOverrideIds) else self.aIds
        mIds = OpenMaya.MIntArray(len(aIds))
        for i,id in enumerate(aIds):
            mIds.set(int(id),int(i)) # one of them needs to not get converted to int
        fnVtxComp.addElements(mIds)
        return self.mComponents


    def getTotalCount(self):
        return OpenMaya2.MFnNurbsCurve(self.mDagPath).numCVs



class SurfacePatch(Patch):

    def __init__(self, mDagPath, aIds=None, aCvs=None, aSofts=None):
        Patch.__init__(self, mDagPath, aIds=aIds, aSofts=aSofts)
        self.mDagPath = mDagPath
        if not isNone(aCvs):# != None:
            if not isNone(aIds):# != None:
                raise Exception('you tried to create a SurfacePatch with passing aIds AND aCvs. You can only use either one or the other')
            self.aIds = self._cvsToIds(aCvs)

    def getTotalCount(self):
        fnSurface = OpenMaya2.MFnNurbsSurface(self.mDagPath)
        return fnSurface.numCVsInU * fnSurface.numCVsInV

    def getIndexedComponents(self, aOverrideIds=None):
        aIds = self.aIds if isNone(aOverrideIds) else aOverrideIds
        iUCount, iVCount = self.getUVCounts()

        # aElements = np.zeros((iUCount,2), dtype=int)
        aUs = aIds // iVCount
        aVs = aIds % iVCount
        fnCvsComp = OpenMaya2.MFnDoubleIndexedComponent()
        self.mCvs = fnCvsComp.create( OpenMaya2.MFn.kSurfaceCVComponent )
        fnCvsComp.addElements(list(zip(aUs,aVs)))
        return self.mCvs


    def getUVCounts(self):
        sName = self.mDagPath.fullPathName()
        uCount = len(cmds.ls('%s.cv[*][0]' % sName, flatten=True))
        vCount = len(cmds.ls('%s.cv[0][*]' % sName, flatten=True))
        return uCount, vCount
        # fnSurface = OpenMaya2.MFnNurbsSurface(self.mDagPath)
        # return fnSurface.numCVsInU, fnSurface.numCVsInV




def getDagPath(sName):
    selList = OpenMaya2.MSelectionList()
    try:
        selList.add(sName)
    except:
        raise Exception('unable to create dagPath with "%s"' % sName)
    return selList.getDagPath(0)


def getDagPathOldApi(sName):
    selList = OpenMaya.MSelectionList()
    try:
        selList.add(sName)
    except:
        raise Exception('unable to create dagPath with "%s"' % sName)
    tmp = OpenMaya.MDagPath()
    selList.getDagPath(0, tmp)
    return tmp


def getDependNode(sName):
    selList = OpenMaya2.MSelectionList()
    selList.add(sName)
    return selList.getDependNode(0)


def getDependNodeOldApi(sName):
    selList = OpenMaya.MSelectionList()
    selList.add(sName)
    tmp = OpenMaya.MObject()
    selList.getDependNode(0, tmp)
    return tmp


def isNone(xInput):
    return isinstance(xInput, type(None))



