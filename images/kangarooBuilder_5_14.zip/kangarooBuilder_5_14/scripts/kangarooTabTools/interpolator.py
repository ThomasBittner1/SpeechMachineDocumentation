###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.cmds as cmds
import maya.mel as mel
import numpy as np

import kangarooTools.uiSettings as uiSettings
import kangarooTools.controls as controls

import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.patch as patch
import kangarooTools.xforms as xforms
import kangarooTools.nodes as nodes
import kangarooTabTools.blendShapes as blendShapes


from collections import defaultdict, OrderedDict
import kangarooTabTools.geometry as geometry
import kangarooTabTools.unreal as unreal

import kangarooShapeEditor.kangarooShapeEditorTools as kangarooShapeEditorTools


class MirrorMode():
    noMirror = 0
    mirrorIds = 1
    mirrorPositions = 2
    splitPositions = 3
    findShapes = 4


def extractInterpMeshName(sMesh):
    _, sModel, sInterp, sPose, sType = sMesh.split('__')
    return sModel, sInterp, sPose, sType


def makeInterpMeshName(sModel, sInterp, sPose, sType='inverted'):
    return 'TARGET2__%s__%s__%s__%s' % (sModel, sInterp, sPose, sType)

def makeMeshName(sModel, sKey, iWeight, sType='inverted'):
    return 'TARGET__%s__%s__%03d__%s' % (sModel, sKey, iWeight, sType)

def extractMeshName(sMesh):
    _, sModel, sKey, sWeight, sType = sMesh.split('__')
    iWeight = int(sWeight)
    return sModel, sKey, iWeight, sType



def getPoseDictFromX(xPoses):
    dPoses = OrderedDict()
    for xP in xPoses:
        dPoses[xP[0]] = xP[1:4]
    return dPoses


def getPosesDictFromInterp(sInterp):
    return getPoseDictFromX(eval(cmds.getAttr('%s.xPoses' % sInterp)))


# depricated!!
def createUpLegInterpolator(sName='uplegUp_l', bMirror=True):
    # upleg up pose

    for bFlip in [False, True]:
        if bFlip:
            if bMirror == False:
                continue
            sName = utils.getMirrorName(sName)
        sSide = utils.getSide(sName)

        sCtrl = 'legUpper_%s_ctrl' % sSide
        sInterp = cmds.createNode('transform', n=sName, p='master')
        sKnee = nodes.createPointByMatrixNode(nodes.getWorldPoint('jnt_%s_leg_lowerTwist_000' % sSide), 'jnt_m_hips.worldInverseMatrix')
        sDrivenKeyUp = nodes.setDrivenKeyController('%s.rx' % sCtrl, [0,90], '%sY' % sKnee, None, [0,1])
        cmds.setAttr('%s.rx' % sCtrl, 90)
        sDrivenKeyNoSide = nodes.setDrivenKeyController('%s.rz' % sCtrl, [15,45], '%sX' % sKnee, None, [1,0])
        cmds.setAttr('%s.rx' % sCtrl, 0)
        sDrivenKeyForward = nodes.setDrivenKeyController('%s.rx' % sCtrl, [0,15], '%sZ' % sKnee, None, [0,1])
        sPoseAttr = utils.addAttr(sInterp, ln='up', k=True)

        nodes.createMultiplyArrayNode([sDrivenKeyUp, sDrivenKeyNoSide, sDrivenKeyForward], sName='hipsCorrective_%s_corrective' % sSide, sTarget=sPoseAttr)

        utils.addStringAttr(sInterp, 'xPoses', [('up', 90, 0, 0)])
        utils.addStringAttr(sInterp, 'sCtrl', sCtrl)
        utils.addStringAttr(sInterp, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sInterp, 'uplegType', '')
        utils.addStringAttr(sInterp, 'drivenKeys', [sDrivenKeyUp.split('.')[0], sDrivenKeyNoSide.split('.')[0], sDrivenKeyForward.split('.')[0]])
        utils.addStringAttr(sInterp, 'sInterpType', 'upleg')


def createUpLegInterpolator2(sName='uplegUp_l', bMirror=True, sPoseNames=['up'], fKneeStarts=[0.0], fUpRotations=[90.0], bReverses=[False], fStartPos=None, fTurnOffOnIns=[1.0], bNoExport=False):
    # upleg up pose
    # fStartPos is just to keep backwardscompatibility, it doesn't do anything
    sReturnInterps = []
    for bFlip in [False, True]:
        if bFlip:
            if bMirror == False:
                continue
            sName = utils.getMirrorName(sName)
        sSide = utils.getSide(sName)


        sCtrl = 'legUpper_%s_ctrl' % sSide
        sInterp = cmds.createNode('transform', n=sName, p='master')
        sKnee = nodes.createPointByMatrixNode(nodes.getWorldPoint('jnt_%s_leg_lowerTwist_000' % sSide), 'jnt_m_hips.worldInverseMatrix', sName='uplegInterpolator_kneeInHips')

        for sPoseName, fKneeStart, fTurnOffOnIn, fUpRotation, bReverse in zip(sPoseNames, fKneeStarts, fTurnOffOnIns, fUpRotations, bReverses):
            cmds.setAttr('%s.rx' % sCtrl, 0)
            fKneeDown = cmds.getAttr('%sY' % sKnee)
            cmds.setAttr('%s.rx' % sCtrl, fUpRotation)
            fKneeUp = cmds.getAttr('%sY' % sKnee)
            cmds.setAttr('%s.rx' % sCtrl, 0)

            if not utils.isNone(fStartPos):
                fKneeStart = fStartPos

            sKneeStart = utils.addAttr(sInterp, ln='kneeStart_%s' % sPoseName, min=0, max=1, dv=fKneeStart, k=True)
            fTurnOffOnIn = utils.addAttr(sInterp, ln='turnOffOnIn_%s' % sPoseName, min=0, max=1, dv=fTurnOffOnIn, k=True)
            sReverse = utils.addAttr(sInterp, ln='reverse_%s' % sPoseName, min=0, max=1, at='bool', dv=bReverse, k=True)
            sKneeDown = nodes.createBlendNode(sKneeStart, fKneeUp, fKneeDown)
            sDrivenKeyUp = nodes.createRangeNode('%sY' % sKnee, sKneeDown, fKneeUp, 0, 1)

            cmds.setAttr('%s.rx' % sCtrl, fUpRotation)
            sDrivenKeyNoOutSide = nodes.setDrivenKeyController('%s.rz' % sCtrl, [15,45], '%sX' % sKnee, None, [1,0])
            sDrivenKeyNoInSide = nodes.setDrivenKeyController('%s.rz' % sCtrl, [0,-20], '%sX' % sKnee, None, [1,0])
            sDrivenKeyNoInSide = nodes.createBlendNode(fTurnOffOnIn,  sDrivenKeyNoInSide, 1.0)
            cmds.setAttr('%s.rx' % sCtrl, 0)
            sDrivenKeyForward = nodes.setDrivenKeyController('%s.rx' % sCtrl, [0,15], '%sZ' % sKnee, None, [0,1])
            sPoseAttr = utils.addAttr(sInterp, ln=sPoseName, k=True)
            sFullMultipl = nodes.createMultiplyArrayNode([sDrivenKeyUp, sDrivenKeyNoOutSide, sDrivenKeyNoInSide, sDrivenKeyForward], sName='hipsCorrective_%s_corrective' % sSide)
            nodes.createBlendNode(sReverse, nodes.createReverseNode(sFullMultipl), sFullMultipl, sTarget=sPoseAttr)


        utils.addStringAttr(sInterp, 'xPoses', [(sPoseName, fUpRotation, 0, 0) for sPoseName, fUpRotation in zip(sPoseNames, fUpRotations)])
        utils.addStringAttr(sInterp, 'sCtrl', sCtrl)
        utils.addStringAttr(sInterp, 'sPoseAttrs', str(['%s.rx' % sCtrl]))
        utils.addStringAttr(sInterp, 'uplegType', '')
        utils.addStringAttr(sInterp, 'drivenKeys', [sDrivenKeyUp.split('.')[0], sDrivenKeyNoOutSide.split('.')[0], sDrivenKeyNoInSide.split('.')[0], sDrivenKeyForward.split('.')[0]])
        utils.addStringAttr(sInterp, 'sInterpType', 'upleg')
        cmds.addAttr(sInterp, ln='noExport', at='bool', defaultValue=bNoExport, k=True)

        sReturnInterps.append(sInterp)

    return sReturnInterps


def createUpLegInterpolator2_depricatedTurnOffDiagonal(sName='uplegUp_l', bMirror=True, sPoseNames=['up'], fKneeStarts=[0.0], fStartPos=None, fTurnOffOnDiagonal=1.0, bNoExport=False):
    # upleg up pose
    # fStartPos is just to keep backwardscompatibility, it doesn't do anything
    print ('createUpLegInterpolator2: ', sName)
    sReturnInterps = []
    for bFlip in [False, True]:
        if bFlip:
            if bMirror == False:
                continue
            sName = utils.getMirrorName(sName)
        sSide = utils.getSide(sName)


        sCtrl = 'legUpper_%s_ctrl' % sSide
        sInterp = cmds.createNode('transform', n=sName, p='master')
        sKnee = nodes.createPointByMatrixNode(nodes.getWorldPoint('jnt_%s_leg_lowerTwist_000' % sSide), 'jnt_m_hips.worldInverseMatrix')
        fKneeDown = cmds.getAttr('%sY' % sKnee)
        cmds.setAttr('%s.rx' % sCtrl, 90)
        fKneeUp = cmds.getAttr('%sY' % sKnee)
        cmds.setAttr('%s.rx' % sCtrl, 0)

        for sPoseName, fKneeStart in zip(sPoseNames, fKneeStarts):
            if not utils.isNone(fStartPos):
                fKneeStart = fStartPos
            sKneeStart = utils.addAttr(sInterp, ln='kneeStart_%s' % sPoseName, min=0, max=1, dv=fKneeStart, k=True)
            sKneeDown = nodes.createBlendNode(sKneeStart, fKneeUp, fKneeDown)
            sDrivenKeyUp = nodes.createRangeNode('%sY' % sKnee, sKneeDown, fKneeUp, 0, 1)

            cmds.setAttr('%s.rx' % sCtrl, 90)
            sDrivenKeyNoOutSide = nodes.setDrivenKeyController('%s.rz' % sCtrl, [15,45], '%sX' % sKnee, None, [1,0])
            sDrivenKeyNoInSide = nodes.setDrivenKeyController('%s.rz' % sCtrl, [0,-20], '%sX' % sKnee, None, [1,0])
            sDrivenKeyNoInSide = nodes.createBlendNode(fTurnOffOnDiagonal,  sDrivenKeyNoInSide, 1.0)
            cmds.setAttr('%s.rx' % sCtrl, 0)
            sDrivenKeyForward = nodes.setDrivenKeyController('%s.rx' % sCtrl, [0,15], '%sZ' % sKnee, None, [0,1])
            sPoseAttr = utils.addAttr(sInterp, ln=sPoseName, k=True)
            nodes.createMultiplyArrayNode([sDrivenKeyUp, sDrivenKeyNoOutSide, sDrivenKeyNoInSide, sDrivenKeyForward], sName='hipsCorrective_%s_corrective' % sSide, sTarget=sPoseAttr)

        utils.addStringAttr(sInterp, 'xPoses', [(sPoseName, 90, 0, 0) for sPoseName in sPoseNames])
        utils.addStringAttr(sInterp, 'sCtrl', sCtrl)
        utils.addStringAttr(sInterp, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sInterp, 'uplegType', '')
        utils.addStringAttr(sInterp, 'drivenKeys', [sDrivenKeyUp.split('.')[0], sDrivenKeyNoOutSide.split('.')[0], sDrivenKeyNoInSide.split('.')[0], sDrivenKeyForward.split('.')[0]])
        utils.addStringAttr(sInterp, 'sInterpType', 'upleg')
        cmds.addAttr(sInterp, ln='noExport', at='bool', defaultValue=bNoExport, k=True)

        sReturnInterps.append(sInterp)

    return sReturnInterps



def createAngleInterpolator(sName, sJointA, sJointB, sJointC, sCtrlAttr, xPoses=[('bend80', [-15,-80], blendShapes.DrivenKeyCurveType.easeIn)], sMaster=None, bMirror=True):
    for s,sSide in enumerate(['l','r']):
        if sSide == 'r':
            if bMirror == False or utils.getSide(sCtrlAttr) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrlAttr = utils.getMirrorName(sCtrlAttr)
            sJointA = utils.getMirrorName(sJointA)
            sJointB = utils.getMirrorName(sJointB)
            sJointC = utils.getMirrorName(sJointC)

        if cmds.objExists(sName):
            raise Exception('interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sParent=sMaster if sMaster else utils.getMasterName())

        sPointA = nodes.getWorldPoint(sJointA)
        sPointB = nodes.getWorldPoint(sJointB)
        sPointC = nodes.getWorldPoint(sJointC)
        sRelA = nodes.createVectorAdditionNode([sPointA, sPointB], sOperation='minus')
        sRelC = nodes.createVectorAdditionNode([sPointC, sPointB], sOperation='minus')

        sCurrentAngle = utils.addAttr(sName, ln='currentAngle', k=False, cb=True)

        nodes.createAngleNode(sRelA, sRelC, sTarget=sCurrentAngle)
        iCurveTypes = []
        ffAngleRanges = []
        for sPose, fRange, iCurveType in xPoses:
            sPoseAttr = utils.addAttr(sName, ln=sPose, k=False, cb=True)
            fAngleValues = [None, None]
            fDefault = cmds.getAttr(sCtrlAttr)
            cmds.setAttr(sCtrlAttr, fRange[0])
            fAngleValues[0] = cmds.getAttr(sCurrentAngle)
            cmds.setAttr(sCtrlAttr, fRange[1])
            fAngleValues[1] = cmds.getAttr(sCurrentAngle)
            cmds.setAttr(sCtrlAttr, fDefault)

            # we are swapping it because driven key does it in reverse. Maybe we could solve that cleaner?
            iDrivenKeyCurveType = iCurveType
            if fAngleValues[1] < fAngleValues[0]:
                if iCurveType == blendShapes.DrivenKeyCurveType.easeIn:
                    iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeOut
                elif iCurveType == blendShapes.DrivenKeyCurveType.easeOut:
                    iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeIn
            sDrivenKeys = blendShapes._drivenKeys(sCurrentAngle, fAngleValues, iCurveType=iDrivenKeyCurveType)
            cmds.connectAttr(sDrivenKeys, sPoseAttr)
            ffAngleRanges.append(fAngleValues)
            iCurveTypes.append(iCurveType)

        xxPoses = []
        sCtrl, sA = sCtrlAttr.split('.')
        iAxis = ['rx','ry','rz'].index(sA)
        for sPose, fRange, _ in xPoses:
            xPose = [sPose, 0,0,0]
            xPose[iAxis+1] = fRange[1]
            xxPoses.append(tuple(xPose))
        sPosesString = str(xxPoses)

        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'ffAngleRanges', ffAngleRanges)
        utils.addStringAttr(sName, 'sCtrl', sCtrlAttr.split('.')[0])
        utils.addStringAttr(sName, 'sJoints', [sJointA, sJointB, sJointC])
        utils.addStringAttr(sName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sName, 'iCurveTypes', iCurveTypes)
        utils.addStringAttr(sName, 'angleType', '')
        utils.addStringAttr(sName, 'sInterpType', 'angleType')



def createSignedAngleInterpolator(sName, sTwist, sParent, sCtrlAttr, xPoses=[('twistBack90', [0,90], blendShapes.DrivenKeyCurveType.easeIn)], sMaster=None, bMirror=True, iAngleAxis=0, iUpAxis=None):
    if sTwist == sParent:
        raise Exception('Twist is the same as Parent ("%s") for %s' % (sTwist, sName))
    for s,sSide in enumerate(['l','r']):
        if sSide == 'r':
            if bMirror == False or utils.getSide(sCtrlAttr) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrlAttr = utils.getMirrorName(sCtrlAttr)
            sTwist = utils.getMirrorName(sTwist)
            sParent = utils.getMirrorName(sParent)

        if cmds.objExists(sName):
            raise Exception('interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sParent=sMaster if sMaster else utils.getMasterName())


        sCurrentTwist = utils.addAttr(sName, ln='currentAngle', k=False, cb=True)

        xforms.getSignedAngle(sTwist, sParent,
                              iAngleAxis=iAngleAxis,
                              iUpAxis=((iAngleAxis+1) % 3) if utils.isNone(iUpAxis) else iUpAxis,
                              sTarget=sCurrentTwist)

        iCurveTypes = []
        ffAngleRanges = []
        for sPose, fRange, iCurveType in xPoses:
            sPoseAttr = utils.addAttr(sName, ln=sPose, k=False, cb=True)
            fAngleValues = [None, None]
            fDefault = cmds.getAttr(sCtrlAttr)
            cmds.setAttr(sCtrlAttr, fRange[0])
            fAngleValues[0] = cmds.getAttr(sCurrentTwist)
            cmds.setAttr(sCtrlAttr, fRange[1])
            fAngleValues[1] = cmds.getAttr(sCurrentTwist)
            cmds.setAttr(sCtrlAttr, fDefault)

            sCurveTypeAttr = utils.addAttr(sName, ln='%s_curveType' % sPose, k=True, at='enum', en='linear:easeIn:easeOut:easeInEaseOut', dv=iCurveType)
            sAllDrivenKeys = []
            for i in range(4):
                iDrivenKeyCurveType = i
                # we are swapping it because driven key does it in reverse. Maybe we could solve that cleaner?
                if fAngleValues[1] < fAngleValues[0]:
                    if i == blendShapes.DrivenKeyCurveType.easeIn:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeOut
                    elif i == blendShapes.DrivenKeyCurveType.easeOut:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeIn
                sAllDrivenKeys.append(blendShapes._drivenKeys(sCurrentTwist, fAngleValues, iCurveType=iDrivenKeyCurveType))
            sDrivenKeys = nodes.createChoiceNode(sCurveTypeAttr, sAllDrivenKeys)

            cmds.connectAttr(sDrivenKeys, sPoseAttr)
            ffAngleRanges.append(fAngleValues)
            iCurveTypes.append(iCurveType)

        xxPoses = []
        sCtrl, sA = sCtrlAttr.split('.')
        iAxis = ['rx','ry','rz'].index(sA)
        for sPose, fRange, _ in xPoses:
            xPose = [sPose, 0,0,0]
            xPose[iAxis+1] = fRange[1]
            xxPoses.append(tuple(xPose))
        sPosesString = str(xxPoses)

        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'ffAngleRanges', ffAngleRanges)
        utils.addStringAttr(sName, 'sCtrl', sCtrlAttr.split('.')[0])
        utils.addStringAttr(sName, 'sJoints', [sTwist, sParent])
        utils.addStringAttr(sName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sName, 'iCurveTypes', iCurveTypes)
        utils.addStringAttr(sName, 'signedAngleType', '')
        utils.addStringAttr(sName, 'sInterpType', 'signedAngle')


# bComputeInParentSpace = False is actually better.. should it be the new default? UE Control Rig might need that fix
def createSignedAngleInterpolator2(sName, sTwist, sParent, sCtrlAttr, xPoses=[('twistBack90', [0,90], blendShapes.DrivenKeyCurveType.easeIn)], sMaster=None, bMirror=True, iForwardAxis=1, iUpAxis=2, bComputeInParentSpace=True):
    print ('sName: ', sName)
    print ('sTwist: ', sTwist)
    print ('sParent: ', sParent)
    print ('sCtrlAttr: ', sCtrlAttr)
    print ('xPoses: ', xPoses)
    print ('iForwardAxis: ', iForwardAxis)
    print ('iUpAxis: ', iUpAxis)
    print ('bComputeInParentSpace: ', bComputeInParentSpace)
    # return

    if sTwist == sParent:
        raise Exception('Twist is the same as Parent ("%s") for %s' % (sTwist, sName))

    iUpAxis = ((iForwardAxis + 1) % 3) if utils.isNone(iUpAxis) else iUpAxis
    sReturn = []
    for bFlip in [False, True]:
        sSide = utils.getSide(sName)
        if bFlip:
            if bMirror == False or utils.getSide(sCtrlAttr) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrlAttr = utils.getMirrorName(sCtrlAttr)
            sTwist = utils.getMirrorName(sTwist)
            sParent = utils.getMirrorName(sParent)

        if cmds.objExists(sName):
            raise Exception('interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sParent=sMaster if sMaster else utils.getMasterName())

        sCurrentTwist = utils.addAttr(sName, ln='currentAngle', k=False, cb=True)

        iAllAxes = set([0, 1, 2])
        iAllAxes.remove(iUpAxis)
        iAllAxes.remove(iForwardAxis)
        iAngleAxis = iAllAxes.pop()
        xforms.getSignedAngle4(sTwist, sParent,
                              iForwardAxis=iForwardAxis,
                              iUpAxis=iUpAxis, iAngleAxis=iAngleAxis,
                              sTarget=sCurrentTwist, bComputeInParentSpace=bComputeInParentSpace)


        iCurveTypes = []
        ffAngleValues = []
        ffRanges = []
        for sPose, fRange, iCurveType in xPoses:
            sPoseAttr = utils.addAttr(sName, ln=sPose, k=False, cb=True)
            fAngleValues = [None, None]
            fDefault = cmds.getAttr(sCtrlAttr)
            cmds.setAttr(sCtrlAttr, fRange[0])
            fAngleValues[0] = cmds.getAttr(sCurrentTwist)
            cmds.setAttr(sCtrlAttr, fRange[1])
            fAngleValues[1] = cmds.getAttr(sCurrentTwist)
            cmds.setAttr(sCtrlAttr, fDefault)

            sCurveTypeAttr = utils.addAttr(sName, ln='%s_curveType' % sPose, k=True, at='enum', en='linear:easeIn:easeOut:easeInEaseOut', dv=iCurveType)
            sAllDrivenKeys = []
            for i in range(4):
                iDrivenKeyCurveType = i
                # we are swapping it because driven key does it in reverse. Maybe we could solve that cleaner?
                if fAngleValues[1] < fAngleValues[0]:
                    if i == blendShapes.DrivenKeyCurveType.easeIn:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeOut
                    elif i == blendShapes.DrivenKeyCurveType.easeOut:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeIn
                sAllDrivenKeys.append(blendShapes._drivenKeys(sCurrentTwist, fAngleValues, iCurveType=iDrivenKeyCurveType))
            sDrivenKeys = nodes.createChoiceNode(sCurveTypeAttr, sAllDrivenKeys)

            cmds.connectAttr(sDrivenKeys, sPoseAttr)
            ffAngleValues.append(fAngleValues)
            iCurveTypes.append(iCurveType)
            ffRanges.append(fRange)
        xxPoses = []
        sCtrl, sA = sCtrlAttr.split('.')
        iAxis = ['rx','ry','rz'].index(sA)
        for sPose, fRange, _ in xPoses:
            xPose = [sPose, 0,0,0]
            xPose[iAxis+1] = fRange[1]
            xxPoses.append(tuple(xPose))
        sPosesString = str(xxPoses)

        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'ffAngleValues', ffAngleValues)
        utils.addStringAttr(sName, 'ffRanges', ffRanges)
        utils.addStringAttr(sName, 'sCtrl', sCtrlAttr.split('.')[0])
        utils.addStringAttr(sName, 'sCtrlAttr', sCtrlAttr)
        utils.addStringAttr(sName, 'sJoints', [sTwist, sParent])
        utils.addStringAttr(sName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sName, 'iCurveTypes', iCurveTypes)
        utils.addStringAttr(sName, 'signedAngleType', '') #only exists for backwardscompatibility
        utils.addStringAttr(sName, 'iForwardAxis', str(iForwardAxis))
        utils.addStringAttr(sName, 'iUpAxis', str(iUpAxis))
        utils.addStringAttr(sName, 'iAngleAxis', str(iAngleAxis))
        utils.addStringAttr(sName, 'sInterpType', 'signedAngle')

        sReturn.append(sName)
    return sReturn

def createSignedAngleInterpolator3(sName, sTwist, sParent, sCtrlAttr, xPoses=[('twistBack90', [0,90], blendShapes.DrivenKeyCurveType.easeIn)], sMaster=None, bMirror=True, iAngleAxis=1, iUpAxis=2, bComputeInParentSpace=False):
    print ('sName: ', sName)
    print ('sTwist: ', sTwist)
    print ('sParent: ', sParent)
    print ('sCtrlAttr: ', sCtrlAttr)
    print ('xPoses: ', xPoses)
    print ('iAngleAxis: ', iAngleAxis)
    print ('iUpAxis: ', iUpAxis)
    print ('bComputeInParentSpace: ', bComputeInParentSpace)
    # return

    if sTwist == sParent:
        raise Exception('Twist is the same as Parent ("%s") for %s' % (sTwist, sName))

    iAllAxes = set([0, 1, 2])
    iAllAxes.remove(iAngleAxis)
    iAllAxes.remove(iUpAxis)
    iForwardAxis = iAllAxes.pop()

    sReturn = []
    for bFlip in [False, True]:
        sSide = utils.getSide(sName)
        if bFlip:
            if bMirror == False or utils.getSide(sCtrlAttr) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrlAttr = utils.getMirrorName(sCtrlAttr)
            sTwist = utils.getMirrorName(sTwist)
            sParent = utils.getMirrorName(sParent)

        if cmds.objExists(sName):
            raise Exception('interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sParent=sMaster if sMaster else utils.getMasterName())

        sCurrentTwist = utils.addAttr(sName, ln='currentAngle', k=False, cb=True)

        xforms.getSignedAngle4(sTwist, sParent,
                              iForwardAxis=iForwardAxis,
                              iUpAxis=iUpAxis, iAngleAxis=iAngleAxis,
                              sTarget=sCurrentTwist, bComputeInParentSpace=bComputeInParentSpace)


        iCurveTypes = []
        ffAngleValues = []
        ffRanges = []
        for sPose, fRange, iCurveType in xPoses:
            sPoseAttr = utils.addAttr(sName, ln=sPose, k=False, cb=True)
            fAngleValues = [None, None]
            fDefault = cmds.getAttr(sCtrlAttr)
            cmds.setAttr(sCtrlAttr, fRange[0])
            fAngleValues[0] = cmds.getAttr(sCurrentTwist)
            cmds.setAttr(sCtrlAttr, fRange[1])
            fAngleValues[1] = cmds.getAttr(sCurrentTwist)
            cmds.setAttr(sCtrlAttr, fDefault)

            sCurveTypeAttr = utils.addAttr(sName, ln='%s_curveType' % sPose, k=True, at='enum', en='linear:easeIn:easeOut:easeInEaseOut', dv=iCurveType)
            sAllDrivenKeys = []
            for i in range(4):
                iDrivenKeyCurveType = i
                # we are swapping it because driven key does it in reverse. Maybe we could solve that cleaner?
                if fAngleValues[1] < fAngleValues[0]:
                    if i == blendShapes.DrivenKeyCurveType.easeIn:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeOut
                    elif i == blendShapes.DrivenKeyCurveType.easeOut:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeIn
                sAllDrivenKeys.append(blendShapes._drivenKeys(sCurrentTwist, fAngleValues, iCurveType=iDrivenKeyCurveType))
            sDrivenKeys = nodes.createChoiceNode(sCurveTypeAttr, sAllDrivenKeys)

            cmds.connectAttr(sDrivenKeys, sPoseAttr)
            ffAngleValues.append(fAngleValues)
            iCurveTypes.append(iCurveType)
            ffRanges.append(fRange)
        xxPoses = []
        sCtrl, sA = sCtrlAttr.split('.')
        iAxis = ['rx','ry','rz'].index(sA)
        for sPose, fRange, _ in xPoses:
            xPose = [sPose, 0,0,0]
            xPose[iAxis+1] = fRange[1]
            xxPoses.append(tuple(xPose))
        sPosesString = str(xxPoses)

        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'ffAngleValues', ffAngleValues)
        utils.addStringAttr(sName, 'ffRanges', ffRanges)
        utils.addStringAttr(sName, 'sCtrl', sCtrlAttr.split('.')[0])
        utils.addStringAttr(sName, 'sCtrlAttr', sCtrlAttr)
        utils.addStringAttr(sName, 'sJoints', [sTwist, sParent])
        utils.addStringAttr(sName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sName, 'iCurveTypes', iCurveTypes)
        utils.addStringAttr(sName, 'signedAngleType', '') #only exists for backwardscompatibility
        utils.addStringAttr(sName, 'iAngleAxis', str(iAngleAxis))
        utils.addStringAttr(sName, 'iUpAxis', str(iUpAxis))
        utils.addStringAttr(sName, 'iForwardAxis', str(iForwardAxis))
        utils.addStringAttr(sName, 'sInterpType', 'signedAngle')

        sReturn.append(sName)
    return sReturn


def createCustomInterpolator(sName, sCtrlAttrs, sDriverAttr, xPoses=[('on', [0,0,0], blendShapes.DrivenKeyCurveType.easeIn)], sMaster=None, bMirror=False):
    print ('sName: ', sName)
    print ('sCtrlAttrs: ', sCtrlAttrs)
    print ('xPoses: ', xPoses)
    def setCtrlValues(fValues):
        for _sCtrlAttr, fV in zip(sCtrlAttrs, fValues):
            if _sCtrlAttr:
                cmds.setAttr(_sCtrlAttr, fV)
                # utils.setAttrCheckLimit(_sCtrlAttr, fV)

    sCtrlAttrs = utils.setListLength(sCtrlAttrs, 3, '')


    if cmds.objExists(sName):
        raise Exception('interpolator with the name of "%s" already exists' % sName)

    xforms.createTransform(sName, sParent=sMaster if sMaster else utils.getMasterName())

    iCurveTypes = []
    # ffRangeValues = []
    # ffRanges = []

    fCtrlValuesBefore = [utils.getAttrIfExists(_sCtrlAttr, 0.0) for _sCtrlAttr in sCtrlAttrs]


    setCtrlValues([0, 0, 0])
    fDefaultDriverValue = cmds.getAttr(sDriverAttr)

    for sPose, fValues, iCurveType in xPoses:
        print ('fValues: ', fValues)
        setCtrlValues(fValues)
        fDriverRange = [fDefaultDriverValue, cmds.getAttr(sDriverAttr)]

        sCurveTypeAttr = utils.addAttr(sName, ln='%s_curveType' % sPose, k=True, at='enum', en='linear:easeIn:easeOut:easeInEaseOut', dv=iCurveType)
        sAllDrivenKeys = []

        for i in range(4):
            iDrivenKeyCurveType = i
            # we are swapping it because driven key does it in reverse. Maybe we could solve that cleaner?
            if fDriverRange[1] < fDriverRange[0]:
                if i == blendShapes.DrivenKeyCurveType.easeIn:
                    iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeOut
                elif i == blendShapes.DrivenKeyCurveType.easeOut:
                    iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeIn

            sAllDrivenKeys.append(blendShapes._drivenKeys(sDriverAttr, fDriverRange, iCurveType=iDrivenKeyCurveType))

        sDrivenKeysChoice = nodes.createChoiceNode(sCurveTypeAttr, sAllDrivenKeys)

        sPoseAttr = utils.addAttr(sName, ln=sPose, k=True)
        cmds.connectAttr(sDrivenKeysChoice, sPoseAttr)

        iCurveTypes.append(iCurveType)


    setCtrlValues(fCtrlValuesBefore)


    sPosesString = [(xP[0], xP[1][0], xP[1][1], xP[1][2]) for xP in xPoses]
    utils.addStringAttr(sName, 'xPoses', sPosesString)
    # utils.addStringAttr(sName, 'ffRangeValues', ffRangeValues)
    utils.addStringAttr(sName, 'sCtrl', sCtrlAttrs[0].split('.')[0])
    utils.addStringAttr(sName, 'sDriverAttr', sDriverAttr)
    utils.addStringAttr(sName, 'sCtrlAttrX', sCtrlAttrs[0])
    utils.addStringAttr(sName, 'sCtrlAttrY', sCtrlAttrs[1])
    utils.addStringAttr(sName, 'sCtrlAttrZ', sCtrlAttrs[2])
    utils.addStringAttr(sName, 'sPoseAttrs', sCtrlAttrs)
    utils.addStringAttr(sName, 'iCurveTypes', iCurveTypes)
    utils.addStringAttr(sName, 'sInterpType', 'custom')

    return [sName]

# DEPRICATED - bComputeInParentSpace = False is actually better.. should it be the new default? UE Control Rig might need that fix
def createAttributeInterpolator(sName, sCtrlAttr, sDriverAttr, xPoses=[('on', [0,10.0], blendShapes.DrivenKeyCurveType.easeIn)], sMaster=None, bMirror=True):
    print ('sName: ', sName)
    print ('sCtrlAttr: ', sCtrlAttr)
    print ('xPoses: ', xPoses)
    # return


    sReturn = []
    for bFlip in [False, True]:
        # sSide = utils.getSide(sName)
        if bFlip:
            if bMirror == False or utils.getSide(sCtrlAttr) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrlAttr = utils.getMirrorName(sCtrlAttr)
            sDriverAttr = utils.getMirrorName(sDriverAttr)

        if cmds.objExists(sName):
            raise Exception('interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sParent=sMaster if sMaster else utils.getMasterName())

        iCurveTypes = []
        ffRangeValues = []
        ffRanges = []
        for sPose, fRange, iCurveType in xPoses:

            sCurveTypeAttr = utils.addAttr(sName, ln='%s_curveType' % sPose, k=True, at='enum', en='linear:easeIn:easeOut:easeInEaseOut', dv=iCurveType)
            sAllDrivenKeys = []
            for i in range(4):
                iDrivenKeyCurveType = i
                # we are swapping it because driven key does it in reverse. Maybe we could solve that cleaner?
                if fRange[1] < fRange[0]:
                    if i == blendShapes.DrivenKeyCurveType.easeIn:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeOut
                    elif i == blendShapes.DrivenKeyCurveType.easeOut:
                        iDrivenKeyCurveType = blendShapes.DrivenKeyCurveType.easeIn

                fConvertedRange = []
                fPrevCtrlValue = cmds.getAttr(sCtrlAttr)
                for fValue in fRange:
                    _sCtrl, _sA = sCtrlAttr.split('.')
                    if _sA in cmds.listAttr(_sCtrl, userDefined=True):
                        fMax = cmds.addAttr(sCtrlAttr, q=True, max=True) or 99999999999
                    else:
                        fMax = 99999999999
                    cmds.setAttr(sCtrlAttr, min(fValue, fMax))
                    fConvertedRange.append(cmds.getAttr(sDriverAttr))
                cmds.setAttr(sCtrlAttr, fPrevCtrlValue)

                sAllDrivenKeys.append(blendShapes._drivenKeys(sDriverAttr, fConvertedRange, iCurveType=iDrivenKeyCurveType))
            sDrivenKeys = nodes.createChoiceNode(sCurveTypeAttr, sAllDrivenKeys)

            sPoseAttr = utils.addAttr(sName, ln=sPose, k=True)
            cmds.connectAttr(sDrivenKeys, sPoseAttr)

            ffRangeValues.append(fRange)
            iCurveTypes.append(iCurveType)
            ffRanges.append(fRange)
        xxPoses = []
        sCtrl, sA = sCtrlAttr.split('.')
        for sPose, fRange, _ in xPoses:
            xPose = [sPose, fRange[1],0,0]
            xxPoses.append(tuple(xPose))
        sPosesString = str(xxPoses)

        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'ffRangeValues', ffRangeValues)
        utils.addStringAttr(sName, 'ffRanges', ffRanges)
        utils.addStringAttr(sName, 'sCtrl', sCtrlAttr.split('.')[0])
        utils.addStringAttr(sName, 'sCtrlAttr', sCtrlAttr)
        utils.addStringAttr(sName, 'sDriverAttr', sDriverAttr)
        utils.addStringAttr(sName, 'sPoseAttrs', str([sA]))
        utils.addStringAttr(sName, 'iCurveTypes', iCurveTypes)
        utils.addStringAttr(sName, 'sInterpType', 'attribute')

        sReturn.append(sName)
    return sReturn


#depricated
def createConeInterpolator(sName, sJoint, sCtrl, xPoses=[('default',(0,0,0), (0,45), blendShapes.DrivenKeyCurveType.easeIn)], bMirror=True, sMaster=None, bAnim=False, bPointConstraint=True):
    print ('sName:', sName)
    print ('sJoint:', sJoint)
    print ('sCtrl:', sCtrl)
    print ('xPoses:', xPoses)
    # return


    for s,sSide in enumerate(['l','r']):
        if sSide == 'r':
            if bMirror == False or utils.getSide(sCtrl) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrl = utils.getMirrorName(sCtrl)
            sJoint = utils.getMirrorName(sJoint)
        fSideMultipl = -1.0 if sSide == 'r' else 1.0


        if cmds.objExists(sName):
            raise Exception ('cone interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sMatch=sJoint, sParent=sMaster if sMaster else utils.getMasterName())

        sParent = cmds.listRelatives(sJoint, p=True)[0]
        if bPointConstraint:
            xforms.matrixParentConstraint(sParent, sName, mo=True, skipTranslate=['x', 'y', 'z'])
            cmds.pointConstraint(sJoint, sName)
        else: # old way, this makes them wrongfully turn on if joint position moves relative to parent
            xforms.matrixParentConstraint(sParent, sName, mo=True)

        sPosesString = str([(sPose, fRot[0], fRot[1], fRot[2]) for sPose, fRot, _, _ in xPoses])
        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'sCtrl', sCtrl)
        utils.addStringAttr(sName, 'sJoint', sJoint)
        utils.addStringAttr(sName, 'sParent', sParent)
        utils.addStringAttr(sName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sName, 'coneType', '') # only exists for backwards compatibility
        utils.addStringAttr(sName, 'sInterpType', 'cone')
        utils.addStringAttr(sName, 'iCurveTypes', str([xP[3] for xP in xPoses]))

        fDefault = cmds.getAttr('%s.r' % sCtrl)[0]
        sJointPoint = nodes.createPointByMatrixNode([fSideMultipl,0,0], '%s.worldMatrix' % sJoint)
        sJointLocalPoint = nodes.createPointByMatrixNode(sJointPoint, '%s.worldInverseMatrix' % sName)

        sConeVis = utils.addOffOnAttr(sName, 'coneVis', bDefaultValue=False)
        sAllConesScale = utils.addAttr(sName, ln='coneScale', min=0.1, dv=1, k=True)

        iCounter = -1
        for sPose, fRot, fRange, iCurveType in xPoses:
            iCounter += 1
            fRange = [min(fRange[0], 179), min(fRange[1], 179)]
            if bAnim:
                cmds.setKeyframe('%s.rx' % sCtrl, t=iCounter * 10, v=fRot[0])
                cmds.setKeyframe('%s.ry' % sCtrl, t=iCounter * 10, v=fRot[1])
                cmds.setKeyframe('%s.rz' % sCtrl, t=iCounter * 10, v=fRot[2])
            sCone = cmds.polyCone(n='%s_%s_cone' % (sName, sPose))[0]
            cmds.rotate(0, 0, 90.0, '%s.vtx[*]' % sCone)
            cmds.move(1.0, 0, 0, '%s.vtx[*]' % sCone, r=True)
            cmds.scale(1*fSideMultipl,2*fSideMultipl,2*fSideMultipl, '%s.vtx[*]' % sCone)

            cmds.delete('%s.f[0]' % sCone)
            if fSideMultipl < 0:
                cmds.polyNormal(sCone, normalMode=0)
            cmds.delete(sCone, ch=True)

            cmds.connectAttr(sConeVis, '%s.v' % sCone)
            sConeSize = utils.addAttr(sCone, ln='coneSize', dv=cmds.getAttr('%s.radius' % sJoint) * 4, min=0, k=True)
            sConeSize = nodes.createMultiplyNode(sConeSize, sAllConesScale)
            sInnerAngle = utils.addAttr(sCone, ln='innerAngle', dv=fRange[0], min=0, max=179, k=True)
            sOuterAngle = utils.addAttr(sCone, ln='outerAngle', dv=fRange[1], min=0, max=179, k=True)

            sHalfInnerAngle = nodes.createMultiplyNode(sInnerAngle, 0.5)
            sHalfOuterAngle = nodes.createMultiplyNode(sOuterAngle, 0.5)

            sShowOuter = utils.addAttr(sCone, ln='displayMode', at='enum', en='inner:outer', dv=1, k=True)
            sCurrentAngle = utils.addAttr(sCone, ln='currentAngle', k=False, cb=True)
            sCurrentOut = utils.addAttr(sCone, ln='out', k=False, cb=True)

            sShowAngle = nodes.createConditionNode(sShowOuter, '==', 1, sHalfOuterAngle, sHalfInnerAngle)
            sSin, sCos = nodes.createSinCos(sShowAngle, bInputIsDegrees=True)
            sCosScaled = nodes.createMultiplyNode(sCos, sConeSize)
            sSinScaled = nodes.createMultiplyNode(sSin, sConeSize)
            cmds.connectAttr(sCosScaled, '%s.sx' % sCone)
            cmds.connectAttr(sSinScaled, '%s.sy' % sCone)
            cmds.connectAttr(sSinScaled, '%s.sz' % sCone)

            cmds.parent(sCone, sName)
            cmds.setAttr('%s.r' % sCtrl, *fRot)
            cmds.delete(cmds.parentConstraint(sJoint, sCone))
            sPosePoint = nodes.createPointByMatrixNode([fSideMultipl,0,0], '%s.matrix' % sCone)
            sAngle = nodes.createAngleNode(sJointLocalPoint, sPosePoint)
            sPoseAttr = utils.addAttr(sName, ln=sPose, k=True)
            cmds.connectAttr(sAngle, sCurrentAngle)
            sLinearRange = nodes.createRangeNode(sAngle, sHalfOuterAngle, sHalfInnerAngle, 0, 1)
            sDrivenKeys = _drivenKeys(sCone, 'curveType', sLinearRange, iDefaultCurveType=iCurveType)
            cmds.connectAttr(sDrivenKeys, sCurrentOut)
            # nodes.setDrivenKey(sLinearRange, [0,1], sCurrentOut, [0,1], sInTanType='flat', sOutTanType='flat')
            cmds.connectAttr(sCurrentOut, sPoseAttr)

        cmds.setAttr('%s.r' % sCtrl, *fDefault)


def createConeInterpolator2(sName, sJoint, sCtrl, sJointParent=None, xPoses=[('default',(0,0,0), (89.0, 0.0), blendShapes.DrivenKeyCurveType.easeIn, False)],
                            iCtrlTwistAxis=1, bMirror=True, sMaster=None, bAnim=False, bJointAngleFactor=False):
    print ('sName:', sName)
    print ('sJoint:', sJoint)
    print ('sCtrl:', sCtrl)
    print ('xPoses:', xPoses)
    print ('bJointAngleFactor: ', bJointAngleFactor)


    fCtrlTwistAxis = [0,0,0]
    fCtrlTwistAxis[int(iCtrlTwistAxis)] = 1.0

    sJointParentSave = sJointParent
    for bFlip in [False, True]:
        sSide = utils.getSide(sName)
        if bFlip:
            if bMirror == False or utils.getSide(sCtrl) == 'm':
                break
            sName = utils.getMirrorName(sName)
            sCtrl = utils.getMirrorName(sCtrl)
            sJoint = utils.getMirrorName(sJoint)
            sJointParent = utils.getMirrorName(sJointParent) if sJointParent else None

        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        cmds.setAttr('%s.r' % sCtrl, 0,0,0)

        if cmds.objExists(sName):
            raise Exception ('cone interpolator with the name of "%s" already exists' % sName)
        xforms.createTransform(sName, sMatch=sJoint, sParent=sMaster if sMaster else utils.getMasterName())

        if utils.isNone(sJointParent):
            sJointParent = cmds.listRelatives(sJoint, p=True)[0]


        if sJointParentSave == None:
            sJointParentSave = sJointParent
        # sInvParentRotation = nodes.getRotationMatrix2('%s.worldInverseMatrix' % sJointParent)

        xforms.matchXform(sCtrl, sName)
        xforms.matrixParentConstraint(sJointParent, sName, mo=True, skipTranslate=['x', 'y', 'z'])
        cmds.pointConstraint(sJoint, sName)

        sPosesString = str([(xP[0], xP[1][0], xP[1][1], xP[1][2]) for xP in xPoses])
        utils.addStringAttr(sName, 'xPoses', sPosesString)
        utils.addStringAttr(sName, 'sCtrl', sCtrl)
        utils.addStringAttr(sName, 'sJoint', sJoint)
        utils.addStringAttr(sName, 'sJointParent', sJointParentSave)
        utils.addStringAttr(sName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sName, 'coneType', '') # only exists for backwards compatibility
        utils.addStringAttr(sName, 'sInterpType', 'cone')
        utils.addStringAttr(sName, 'iCurveTypes', str([xP[3] for xP in xPoses]))
        utils.addAttr(sName, ln='iCtrlTwistAxis', dv=iCtrlTwistAxis)
        utils.addAttr(sName, ln='bJointAngleFactor', dv=bJointAngleFactor)

        fDefault = cmds.getAttr('%s.r' % sCtrl)[0]

        fCtrlPointWorld = nodes.createPointByMatrixNode(fCtrlTwistAxis, nodes.getRotationMatrix2('%s.worldMatrix' % sCtrl, bJustValues=True), bJustValues=True)
        fTwistAxisLocalInJoint = nodes.createPointByMatrixNode(fCtrlPointWorld, nodes.getRotationMatrix2('%s.worldInverseMatrix' % sJoint, bJustValues=True), bJustValues=True)
        sTwistAxisByJoint = nodes.createPointByMatrixNode(fTwistAxisLocalInJoint, nodes.getRotationMatrix2('%s.worldMatrix' % sJoint))
        # sJointLocalPoint = nodes.createPointByMatrixNode(sTwistAxisByJoint, '%s.worldInverseMatrix' % sName)

        sConeVis = utils.addOffOnAttr(sName, 'coneVis', bDefaultValue=False)
        sAllConesScale = utils.addAttr(sName, ln='coneScale', min=0.1, dv=1, k=True)

        iCounter = -1
        for xP in xPoses:
            sPose, fRot, fRange, iCurveType = xP[:4]
            bReverse = xP[4] if len(xP) > 4 else False

            iCounter += 1
            fRange = [min(fRange[0], 179), min(fRange[1], 179)]

            sCone = cmds.polyCone(n='%s_%s_cone' % (sName, sPose))[0]
            cmds.setAttr('%s.ro' % sCone, cmds.getAttr('%s.ro' % sCtrl))
            # cmds.rotate(0, 0, 90.0, '%s.vtx[*]' % sCone)
            cmds.move(0, 1, 0, '%s.vtx[*]' % sCone, r=True)
            cmds.scale(2,-1,2, '%s.vtx[*]' % sCone,  p=(0,1,0))
            cmds.delete('%s.f[0]' % sCone)
            if fSideMultipl < 0:
                cmds.polyNormal(sCone, normalMode=0)
            cmds.delete(sCone, ch=True)


            cmds.connectAttr(sConeVis, '%s.v' % sCone)

            cmds.parent(sCone, sName)
            cmds.setAttr('%s.r' % sCone, *fRot)
            cmds.setAttr('%s.t' % sCone, 0, 0, 0)

            sConeSize = utils.addAttr(sCone, ln='coneSize', dv=cmds.getAttr('%s.radius' % sJoint) * 4, min=0, k=True)
            sConeSize = nodes.createMultiplyNode(sConeSize, sAllConesScale)

            sStartAngle = utils.addAttr(sCone, ln='startAngle', dv=fRange[0], min=0, max=89.0, k=True)
            sEndAngle = utils.addAttr(sCone, ln='endAngle', dv=fRange[1], min=0, max=89.0, k=True)

            sFullRotationAngle = nodes.createAngleNode(nodes.createPointByMatrixNode(fCtrlTwistAxis, nodes.createComposeMatrixNode(xRotate='%s.r' % sCone)), fCtrlTwistAxis)
            utils.addAttr(sCone, ln='fullRotationAngle', k=False, cb=True, sConnect=sFullRotationAngle)

            sHalfOuterAngle = sStartAngle
            sHalfInnerAngle = sEndAngle

            utils.addAttr(sCone, ln='halfOuterAngle', k=False, cb=True, sConnect=sHalfOuterAngle)
            utils.addAttr(sCone, ln='halfInnerAngle', k=False, cb=True, sConnect=sHalfInnerAngle)
            sReverseAttr = utils.addAttr(sCone, ln='bReverse', dv=bReverse)
            cmds.setAttr(sReverseAttr, lock=True)

            sShowOuter = utils.addAttr(sCone, ln='displayMode', at='enum', en='inner:outer', dv=1, k=True)

            if bJointAngleFactor:
                sCurrentJointAngle = utils.addAttr(sCone, ln='currentJointAngle', k=False, cb=True)
                sCurrentAngle = utils.addAttr(sCone, ln='currentAngle', k=False, cb=True)
            sCurrentOut = utils.addAttr(sCone, ln='out', k=False, cb=True)

            sShowAngle = nodes.createConditionNode(sShowOuter, '==', 1, sHalfOuterAngle, sHalfInnerAngle)
            sSin, sCos = nodes.createSinCos(sShowAngle, bInputIsDegrees=True)
            sCosScaled = nodes.createMultiplyNode(sCos, sConeSize)
            sSinScaled = nodes.createMultiplyNode(sSin, sConeSize)
            cmds.connectAttr(sSinScaled, '%s.sx' % sCone)
            cmds.connectAttr(sCosScaled, '%s.sy' % sCone)
            cmds.connectAttr(sSinScaled, '%s.sz' % sCone)

            sConeRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sCone, bScale=False)
            sInvConeRotationMatrix = nodes.createInverseMatrix(sConeRotationMatrix)
            sTwistAxisByJointInCone = nodes.createPointByMatrixNode(sTwistAxisByJoint, sInvConeRotationMatrix)

            sPoseAttr = utils.addAttr(sName, ln=sPose, k=True)

            if bJointAngleFactor:

                fRotOnRangeEnd = xforms.rotateBackToZero(fRot, fRange[1], iRotateOrder=cmds.getAttr('%s.ro' % sCone))

                cmds.setAttr('%s.r' % sCtrl, *fRotOnRangeEnd)
                fFullRotationAngleOnRangeEnd = nodes.createAngleNode(nodes.createPointByMatrixNode(fCtrlTwistAxis, nodes.createComposeMatrixNode( xRotate=fRotOnRangeEnd)), fCtrlTwistAxis, bJustValues=True)

                fPosedJointInInterpolator = nodes.getRotationMatrix2(nodes.createMultMatrixNode(['%s.worldMatrix' % sJoint, '%s.worldInverseMatrix' % sName]), bJustValues=True)
                fJointRotationAngle = nodes.createAngleNode(nodes.createPointByMatrixNode(fTwistAxisLocalInJoint, fPosedJointInInterpolator), fCtrlTwistAxis, bJustValues=True)
                utils.addAttr(sCone, ln='jointRotationAngle', k=False, cb=True, sConnect=fJointRotationAngle)


                if abs(fJointRotationAngle) < 0.0001:
                    cmds.warning('Joint is not moving, could be that there\'s no rotation or only rotation among the twist axis')
                    fJointRotationAngle = 1.0
                fFactor = fFullRotationAngleOnRangeEnd / fJointRotationAngle
                utils.addAttr( sCone, ln='fJointFactor', k=True, dv=fFactor) #, bLock=True)

                sAngle = nodes.createAngleNode(fCtrlTwistAxis, sTwistAxisByJointInCone)
                cmds.connectAttr(sAngle, sCurrentJointAngle)

                sDiff = nodes.createAdditionNode([sAngle, sFullRotationAngle], sOperation='minus')
                sFactoredDiff = nodes.createMultiplyNode(sDiff, fFactor)
                sFinalAngle = nodes.createAdditionNode([sFactoredDiff, sFullRotationAngle])
                cmds.connectAttr(sFinalAngle, sCurrentAngle)

            else:
                sFinalAngle = nodes.createAngleNode(fCtrlTwistAxis, sTwistAxisByJointInCone)

            sLinearRange = nodes.createRangeNode(sFinalAngle, sHalfOuterAngle, sHalfInnerAngle, 0, 1)
            sDrivenKeys = _drivenKeys(sCone, 'curveType', sLinearRange, iDefaultCurveType=iCurveType)
            cmds.connectAttr(sDrivenKeys, sCurrentOut)

            if bReverse:
                nodes.createReverseNode(sCurrentOut, sTarget=sPoseAttr)
            else:
                cmds.connectAttr(sCurrentOut, sPoseAttr)


        cmds.setAttr('%s.r' % sCtrl, *fDefault)



def _drivenKeys(sSwitchAttrNode, sEnumAttrName, sInput, iDefaultCurveType=blendShapes.DrivenKeyCurveType.linear):
    sEnumAttr = utils.addAttr(sSwitchAttrNode, ln=sEnumAttrName, at='enum', en=':'.join(['linear', 'easeIn', 'easeOut', 'easeInEaseOut']), dv=iDefaultCurveType, k=True)
    sDrivenKeyNodes = []
    for iCurveType in range(4):
        if iCurveType == blendShapes.DrivenKeyCurveType.linear:
            sInTanType, sOutTanType = 'linear', 'linear'
        if iCurveType == blendShapes.DrivenKeyCurveType.easeIn:
            sInTanType, sOutTanType = 'linear', 'flat'
        if iCurveType == blendShapes.DrivenKeyCurveType.easeOut:
            sInTanType, sOutTanType = 'flat', 'linear'
        if iCurveType == blendShapes.DrivenKeyCurveType.easeInEaseOut:
            sInTanType, sOutTanType = 'flat', 'flat'

        sDrivenKeyNodes.append(nodes.setDrivenKey(sInput, [0,1], None, [0,1], sInTanType=sInTanType, sOutTanType=sOutTanType))
    return nodes.createChoiceNode(sEnumAttr, sDrivenKeyNodes)


# don\'t include the default (0,0,0) pose!
def createPoseInterpolator(sName, sJoint, sCtrl, sJointParent=None, xPoses=[('up',0,0,0, False)], sPoseAttrs=['rx','ry','rz'], bMirror=True, sMaster=None): #, sParentOfDriver=None, bInsertParentDriver=True):
    print ('sName: ', sName)
    print ('sJoint: ', sJoint)
    print ('sCtrl: ', sCtrl)
    print ('xPoses: ', xPoses)
    if xPoses[0][0] != 'default':
        xPoses = [('default',0,0,0, False)] + xPoses
    # return

    sGroup = 'grp_posesInterpolators%s' % (('_%s' % sMaster) if sMaster else '')

    if not cmds.objExists(sGroup):
        cmds.createNode('transform', n=sGroup, p=sMaster if sMaster else utils.getMasterName())
        cmds.setAttr('%s.v' % sGroup, False)

    sJointsGroup = 'grp_posesInterpolatorJoints%s' % (('_%s' % sMaster) if sMaster else '')
    if not cmds.objExists(sJointsGroup):
        cmds.createNode('transform', n=sJointsGroup, p=sGroup)

    if cmds.objExists(sName):
        raise Exception('Interpolator "%s" already exists' % sName)

    # sMaster = xforms.getWorldRoot(sJoint)
    sInterps = []
    for s, sSide in enumerate(['l','r']):
        if s == 0:
            sSideName = sName
            sSideJoint = sJoint
            sSideControl = sCtrl
            sSideJointParent = sJointParent
        if s == 1:
            if not bMirror:
                break
            sSideName = utils.getMirrorName(sName)
            if sSideName == sName:
                break
            sSideJoint = utils.getMirrorName(sJoint)
            sSideControl = utils.getMirrorName(sCtrl)
            sSideJointParent = utils.getMirrorName(sJointParent) if sJointParent else None
            # if sParentOfDriver:
            #     sParentOfDriver = utils.getMirrorName(sParentOfDriver)

        sChild = cmds.listRelatives(sSideJoint, p=False, c=True, typ='joint')[0]
        if not sJointParent:
            sSideJointParent = cmds.listRelatives(sSideJoint, p=True, c=False)[0]
            if s == 0:
                sJointParent = sSideJointParent

        fChildLocalPos = cmds.getAttr('%s.t' % sChild)[0]

        sJointCopy = cmds.createNode('joint', n=utils.getUniqueName('%s_POSE' % sSideJoint), p=sJointsGroup)
        xforms.createJoint('%s_%s_POSE' % (sName, sChild), xPos=fChildLocalPos, sParent=sJointCopy)

        xforms.matrixParentConstraint(sSideJoint, sJointCopy)
        sParentCopy = xforms.insertParent(sJointCopy, utils.getUniqueName('%s_PARENT' % sSideJoint))
        xforms.matrixParentConstraint(sSideJointParent, sParentCopy, mo=True)

        sInterp = cmds.poseInterpolator(sJointCopy, name=sSideName)[0]
        xPosesAttrValue = xPoses[1:]  #skipping the default pose
        cmds.setAttr('%s.allowNegativeWeights' % sInterp, False)
        utils.addStringAttr(sInterp, 'xPoses', str(xPosesAttrValue))
        utils.addStringAttr(sInterp, 'sCtrl', sSideControl)
        fRotBefore = [cmds.getAttr('%s.%s' % (sSideControl,sA)) for sA in sPoseAttrs]
        dPoses = getPoseDictFromX(xPoses)
        for sPoseName, fEuler in list(dPoses.items()):
            for a,sA in enumerate(sPoseAttrs):
                try: cmds.setAttr('%s.%s' % (sSideControl,sA), fEuler[a])
                except: pass
            cmds.poseInterpolator(sInterp, e=True, addPose=sPoseName)

        for a,sA in enumerate(sPoseAttrs):
            try: cmds.setAttr('%s.%s' % (sSideControl,sA), fRotBefore[a])
            except: pass

        bRevs = [xP[4] if len(xP) > 4 else False for xP in xPoses]
        cmds.parent(sInterp, sGroup)
        utils.addStringAttr(sInterp, 'sPoseAttrs', str(sPoseAttrs))
        sInterps.append(sInterp)

        for p,xP in enumerate(xPoses):
            sPose = xP[0]
            sVisAttr = utils.addAttr(sInterp, ln=sPose, k=True)
            if bRevs[p]:
                nodes.createReverseNode('%s.output[%d]' % (sInterp,p), sTarget=sVisAttr)
            else:
                cmds.connectAttr('%s.output[%d]' % (sInterp,p), sVisAttr)


        sPosesString = str([(xPose[0], xPose[1], xPose[2], xPose[3]) for xPose in xPoses])

        utils.addStringAttr(sSideName, 'xPoses', xPosesAttrValue)
        utils.addStringAttr(sSideName, 'bRevs', bRevs[1:])
        utils.addStringAttr(sSideName, 'sCtrl', sCtrl)
        utils.addStringAttr(sSideName, 'sJoint', sJoint)
        utils.addStringAttr(sSideName, 'sJointParent', sJointParent)
        utils.addStringAttr(sSideName, 'sPoseAttrs', str(['rx','ry','rz']))
        utils.addStringAttr(sSideName, 'mayaPoseType', '') # only exists for backwards compatibility
        utils.addStringAttr(sSideName, 'sInterpType', 'mayaPose')



    return sInterps



def goToPose(sInterp, sPose):
    sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
    dPoses = getPosesDictFromInterp(sInterp)
    sAttrs = eval(cmds.getAttr('%s.sPoseAttrs' % sInterp))
    for a, sA in enumerate(sAttrs):
        try: cmds.setAttr('%s.%s' % (sCtrl,sA), dPoses[sPose][a])
        except: pass



def getIndex(sInterp, sPose):
    dPoses = getPosesDictFromInterp(sInterp)
    sKeys = list(dPoses.keys())
    if sPose not in sKeys:
        raise Exception('pose "%s" not in list of poses (%s)' % (sPose, ', '.join(sKeys)))
    return sKeys.index(sPose)


def getAllInterpTargetsInScene(sModel='*', sInterp='*'):
    sSearchString = 'TARGET2__%s__%s__*' % (sModel, sInterp)
    sTargets = cmds.ls(sSearchString, et='transform')

    dTargets = defaultdict(list)
    for sMesh in sTargets:
        sParents = cmds.listRelatives(sMesh, p=True)
        if sParents and 'ignore' in sParents[0]:
            continue
        sModel, sInterp, sPose, sType = extractInterpMeshName(sMesh)
        dTargets[sInterp].append(sMesh)

    return dict(dTargets)


def getAllTargetsInScene(sModel='*', sKey='*'):
    sSearchString = 'TARGET__%s__%s__*' % (sModel, sKey)
    sTargets = cmds.ls(sSearchString, et='transform')

    dTargets = defaultdict(list)
    for sMesh in sTargets:
        sParents = cmds.listRelatives(sMesh, p=True)
        if sParents and 'ignore' in sParents[0]:
            continue
        sModel, sKey, iWeight, sType = extractMeshName(sMesh)
        dTargets[sKey].append(sMesh)

    return dict(dTargets)



def connectInterpTargets(sInterp, iMirror=MirrorMode.noMirror, fSplitRadius=0.5, sModels=None, sIgnoreModels=[], sFilterModels=None, bClampMin=False, bClampMax=False):
    if isinstance(sModels, type(None)):
        dMeshes = getAllInterpTargetsInScene(sInterp=sInterp)
        if sInterp not in dMeshes:
            cmds.warning('connectInterpTargets: skipping %s because there are no targets' % sInterp)
            return
        sMeshes = dMeshes[sInterp]
    else:
        sMeshes = []
        for sM in sModels:
            sMeshes += getAllInterpTargetsInScene(sInterp=sInterp, sModel=sM)[sInterp]

    if iMirror != MirrorMode.noMirror:
        sMirrorInterp = utils.getMirrorName(sInterp)
        iMirrorMode = geometry.MirrorMode.vertexIds if iMirror == MirrorMode.mirrorIds else geometry.MirrorMode.closestVertex



    for sMesh in sMeshes:
        sModel, sInterp, sPose, sType = extractInterpMeshName(sMesh)

        if not cmds.objExists(sModel):
            continue

        if iMirror == MirrorMode.splitPositions:
            if utils.getSide(sModel) == 'm':
                geometry.splitShape(sSculpt=sMesh, sBase=sModel, fRadius=fSplitRadius, sLeftName=sMesh, sRightName=makeInterpMeshName(sModel, utils.getMirrorName(sInterp), sPose,sType))


        if sFilterModels != None and sModel not in sFilterModels:
            continue
        if sModel in sIgnoreModels:
            continue

        if sType == 'inverted':
            sInverted = sMesh
        elif sType == 'posed':
            sInverted = utils.replaceStringEnd(sMesh, '__posed', '__inverted')
            goToPose(sInterp, sPose)
            sInverted = geometry.invertShapeDeformers(sSculpt=sMesh, sSkin=sModel, sInvertName=sInverted)
            goToPose(sInterp, 'default')

        iOutIndex = getIndex(sInterp, sPose)
        sTargetAttr = deformers.addBlendShapeTargets(sModel, [sInverted])[0]
        sOutput = '%s.output[%d]' % (sInterp, iOutIndex)
        if not bClampMin and not bClampMax:
            cmds.connectAttr(sOutput, sTargetAttr)
        else:
            nodes.createClampNode(sOutput, 0.0 if bClampMin else -100000, 1.0 if bClampMax else 100000,
                                  sTarget=sTargetAttr, sName='pose_%s_%s' % (sPose, sModel))

        if iMirror != MirrorMode.noMirror:
            if not cmds.objExists(sMirrorInterp):
                cmds.warning('skipping mirroring %s, because interpolator doesn\'t exist' % sInterp)
                continue

            sMirrorModel = utils.getMirrorName(sModel)
            sMirrorInverted = makeInterpMeshName(sMirrorModel, sMirrorInterp, sPose, 'inverted')

            if cmds.objExists(sMirrorInverted):
                pass
            else:
                if iMirror == MirrorMode.findShapes:
                    pass
                elif iMirror in [MirrorMode.mirrorIds, MirrorMode.mirrorPositions, MirrorMode.splitPositions]:
                    sMirrorPosed = makeInterpMeshName(sMirrorModel, sMirrorInterp, sPose, 'posed')
                    if cmds.objExists(sMirrorPosed): # invert it
                        goToPose(sMirrorInterp, sPose)
                        sMirrorInverted = geometry.invertShapeDeformers(sSculpt=sMirrorPosed, sSkin=sMirrorModel, sInvertName=sMirrorInverted)
                        goToPose(sMirrorInterp, 'default')
                    elif iMirror != MirrorMode.splitPositions: # mirror it
                        if patch.patchFromName(sInverted).getTotalCount() == patch.patchFromName(sMirrorModel).getTotalCount():
                            sMirrorInverted = cmds.duplicate(sInverted, n=sMirrorInverted)[0]
                            geometry.meshMirrorMiddle([patch.patchFromName(sMirrorInverted)], iDirection=geometry.MirrorDirection.flip, sBaseMesh=sModel, iMode=iMirrorMode)

            if cmds.objExists(sMirrorInverted):
                sTargetAttr = deformers.addBlendShapeTargets(sMirrorModel, [sMirrorInverted])[0]
                sOutput = '%s.output[%d]' % (sMirrorInterp, iOutIndex)
                if not bClampMin and not bClampMax:
                    cmds.connectAttr(sOutput, sTargetAttr)
                else:
                    nodes.createClampNode(sOutput, 0.0 if bClampMin else -100000, 1.0 if bClampMax else 100000,
                                          sTarget=sTargetAttr, sName='pose_%s_%s' % (sPose, sMirrorModel))





def getSplitShapesFromMain(sMain):
    sModel, sKey, iWeight, sType = extractMeshName(sMain)

    sCurrent = sMain#makeMeshName(sModel, sKey, iWeight, sType)
    sMirror = makeMeshName(sModel, utils.getMirrorName(sKey), iWeight, sType)
    if cmds.objExists(sMirror):
        return sCurrent, sMirror
    else:
        sMain = cmds.rename(sMain, '%s_deleteme' % sMain)
        sCurrent, sMirror = geometry.splitShape(sMain, sBase=sModel, fRadius=0.5, sLeftName=sCurrent, sRightName=sMirror)
        cmds.delete(sMain)
        return sCurrent, sMirror


# to do: we could simplify that function a lot. Has a lot of garbage from old stuff
def getMouthBottomWeights(sModel, iSkinClusterSmoothIterations=2):
    print('get mouthBottomWeights... sModel: ', sModel)
    sModel = utils.replaceStringEnd(sModel, '_noPreJoints', '')
    if cmds.objExists('MAP__%s__faceBottom' % sModel):
        return geometry.getMapValues('MAP__%s__faceBottom' % sModel)
    if cmds.objExists('MAP__faceBottom'):
        return geometry.getMapValues('MAP__faceBottom')
    if cmds.objExists('MAP__mouthBot'):
        return geometry.getMapValues('MAP__mouthBot')

    # pModel = patch.patchFromName(sModel)
    sSkinClusters = ['splitSkinCluster__%s' % sModel, 'skinCluster__%s__MOUTH' % sModel, 'skinCluster__%s' % sModel]

    if cmds.objExists(sSkinClusters[0]):
        sSkinCluster = sSkinClusters[0]
        ssLookForInfluences = [['jnt_m_jawMain'], ['jnt_m_headMain']]
    elif cmds.objExists(sSkinClusters[1]):
        sSkinCluster = sSkinClusters[1]
        ssLookForInfluences = [cmds.ls(['jnt_?_bot2Lip_???', 'jnt_?_botLip_???'], et='joint'),
                               cmds.ls(['jnt_?_top2Lip_???', 'jnt_?_topLip_???'], et='joint')]
    elif cmds.objExists(sSkinClusters[2]):
        sSkinCluster = sSkinClusters[2]
        ssLookForInfluences = [['jnt_m_jawMain'], ['jnt_m_headMain']]
    else:

        if cmds.confirmDialog(m='None of the 3 skinClusters exists: %s\nCreate an empty Map Mesh Cluster?' % ', '.join(sSkinClusters),
                           button=['yes', 'no']) == 'no':
            raise Exception('Can\'t find a way to split bottom/top for %s' % sModel)
        sSkinCluster = None


    if sSkinCluster:
        sMesh = deformers.getGeoFromDeformer(sSkinCluster)
        pModel = patch.patchFromName(sMesh)

        _, sInfluences, aWeights2d = pModel.getSkinCluster(sChooseSkinCluster=sSkinCluster)

        aWeightings2d = np.zeros((pModel.getTotalCount(), 3), dtype='float64')

        for p, sPart in enumerate(['bot', 'top']):
            sLipJoints = ssLookForInfluences[p]
            iLipInds = utils.findOneArrayInAnother(sInfluences, sLipJoints)
            aWeightings2d[:, p] = np.sum(aWeights2d[:, iLipInds], axis=1)

        aWeightings2d[:, 2] = 1.0 - np.sum([aWeightings2d[:, 0], aWeightings2d[:, 1]])
        aWeightings2d = pModel.smoothValues2d(aWeightings2d, iIterations=iSkinClusterSmoothIterations)

        aReturnWeights = aWeightings2d[:,0]
    else:
        aReturnWeights = np.zeros(cmds.polyEvaluate(sModel, vertex=True), dtype='float64')

    # generate cluster for saving next time
    sMapModel = '%s__MAPS' % sModel
    if not cmds.objExists(sMapModel):
        cmds.duplicate(sModel, n=sMapModel)
        utils.parentToWorld(sMapModel)
        cmds.setAttr('%s.v' % sMapModel, False)
    sCluster = cmds.deformer(sMapModel, type='cluster', n='MAP__%s__faceBottom' % sModel)[0]
    import kangarooTabTools.weights as weights

    deformers.makeNotExport(sCluster)
    cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, len(aReturnWeights)-1), *list(aReturnWeights))

    return aReturnWeights





kIgnoreAttachTargetsAttr = 'ignoreAttachTargets'
def addIgnoreAttachTargets(sCtrl, sTargets):
    sAttr = '%s.%s' % (sCtrl, kIgnoreAttachTargetsAttr)
    try: # this could be a reference, in which case it wouldn't matter anyway
        sPrevTargets = [] if not cmds.objExists(sAttr) else eval(cmds.getAttr(sAttr))
        sPrevTargets += sTargets
        utils.addStringAttr(sCtrl, kIgnoreAttachTargetsAttr, str(sPrevTargets))
    except:
        pass


class CombineMode(object):
    product = 0
    minimum = 1

def _combineValues(iMode, xValues, sTarget=None):
    if iMode == CombineMode.product:
        return nodes.createMultiplyArrayNode(xValues, sTarget=sTarget)
    elif iMode == CombineMode.minimum:
        return nodes.createMinimumNode(xValues, sTarget=sTarget)
    else:
        raise Exception('Don\'t know what combine mode %d is' % iMode)



bLegacyCombo = False


def connectTargets(sModel, sTarget, dDrivers={}, sDriversGetAttr=[], dMultDrivers={}, bMirror=True, dPoses={}, bInvert=False, sMaskMap=None, sMaskedName=None, bMaskFromPose=False,
                    fSplitRadius=0.2, bSplitBotTop=False, sBlendShape=None, bStopBeforeInvert=False, bStopBeforeMask=False, bStopBeforeMirror=False, bAppleBlendShapes=False, sSecondaryModels=[],
                   sAlias=None, bReturnIfNotExist=False, fOvershootRange=None, iCombineMode=CombineMode.minimum, xMirrorAxis=None, sMirrorBase=None):
    '''
    :param sModel:
    :param sTarget:
    :param dPoses: dictionary of attributes and values
            poses examples: dPoses={'clavLFT':'forward'},
    :param dDrivers: dictionary of attributes and values/lists. If it's a list it needs to have 2 items, start and end \
                    value of attribute. If it's missing, then the poses dictionary will be taken for it.
    :param sDriversGetAttr: list of attributes.
    :param bMirror:
    :param bInvert:
    :param fSplitRadius:
    :param bSplitBotTop:
    :param sBlendShape:
    :return:
    '''
    print ('this is depricated!!!! please use blendShapes.connectTargets() instead')
    if sTarget != None and not cmds.objExists(sTarget) and bReturnIfNotExist:
        print('skipping target "%s", because it doesn\'t exist.' % sTarget)
        return

    if bLegacyCombo:

        dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={})
        dConnectTargetsDriverGetAttrs = utils.data.get('dConnectTargetDriverGetAttrs', xDefault={})
        dConnectTargetPoses[sTarget] = dPoses
        if sDriversGetAttr:
            dConnectTargetsDriverGetAttrs[sTarget] = sDriversGetAttr
        else:
            dConnectTargetsDriverGetAttrs[sTarget] = list(dPoses.keys())

        utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
        utils.data.store('dConnectTargetDriverGetAttrs', dConnectTargetsDriverGetAttrs)

    else:

        dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={}) # should be defaultDict(list), but that can't be stored
        dConnectTargetsDriverGetAttrs = utils.data.get('dConnectTargetDriverGetAttrs', xDefault={}) # should be defaultDict(list), but that can't be stored

        utils.addListKey(dConnectTargetPoses, sTarget)
        dConnectTargetPoses[sTarget].append(dPoses)

        utils.addListKey(dConnectTargetsDriverGetAttrs, sTarget)
        if sDriversGetAttr:
            dConnectTargetsDriverGetAttrs[sTarget].append(sDriversGetAttr)
        else:
            dConnectTargetsDriverGetAttrs[sTarget].append(list(dPoses.keys()))

        utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
        utils.data.store('dConnectTargetDriverGetAttrs', dConnectTargetsDriverGetAttrs)



    sDriversGetAttr = list(sDriversGetAttr)
    dDrivers = dict(dDrivers)
    dPoses = dict(dPoses)
    dMultDrivers = dict(dMultDrivers)

    if bAppleBlendShapes:
        sUnrealCommands = ''

    if sTarget == None:
        sTarget = cmds.duplicate(sModel)[0]
        if cmds.listRelatives(sTarget, p=True):
           cmds.parent(sTarget, w=True)

    print('\n\n\n ============================= sTarget: %s (%s) - secondary models: %s' % (sTarget, sModel, sSecondaryModels))

    if not cmds.objExists(sTarget):
        raise Exception('Target %s doesn\'t exist.' % sTarget)

    if sBlendShape == None:
        sBlendShape = 'blendShape__%s' % sModel.split(':')[-1]
        if not cmds.objExists(sBlendShape):
            deformers.preDeformationBlendshapeHack([], sModel, n=sBlendShape)
            if not cmds.objExists(sBlendShape):
                raise Exception('wasn\'t able to create blendShape')

    if sSecondaryModels:
        sSecondaryModels = list(set(sSecondaryModels))
    sSecondaryBlendShapes = []
    for sSecondaryModel in sSecondaryModels:
        sSecondaryBlendShape = 'blendShape__%s' % sSecondaryModel
        if not cmds.objExists(sSecondaryBlendShape):
            sSecondaryBlendShapes.append(sSecondaryBlendShape)
            deformers.preDeformationBlendshapeHack([], sSecondaryModel, n=sSecondaryBlendShape)
            if not cmds.objExists(sSecondaryBlendShape):
                raise Exception('wasn\'t able to create blendShape')
        sSecondaryBlendShapes.append(sSecondaryBlendShape)



    if not dPoses and (bInvert or sDriversGetAttr):
        dPoses = dict(dDrivers)
        for sA,xV in list(dPoses.items()):
            if isinstance(xV,(list,tuple)):
                dPoses[sA] = xV[1]

    # clean dPoses
    for sKey, fValue in list(dPoses.items()):
        if utils.isStringOrUnicode(sKey) and utils.isStringOrUnicode(fValue): # poseInterpolator
            sInterp = sKey
            dInterp = getPosesDictFromInterp(sInterp)
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
            if ':' in sInterp:
                sCtrl = '%s:%s' % (':'.join(sInterp.split(':')[:-1]), sCtrl)
            dPoses['%s.r' % sCtrl] = np.array(dInterp[fValue], dtype='float64')
            del dPoses[sKey]
            if not dDrivers:
                sDriversGetAttr.append('%s.%s' % (sInterp,fValue))
        elif isinstance(fValue, (list,tuple)): # this is for compound attributes
            dPoses[sKey] = np.array(fValue)
        elif not isinstance(fValue, (int, float, type(None))):
            raise Exception('dPoses can only have floats, ints or None as values (%s, %s)' % (sTarget, dPoses))

    # clean dDrivers
    for sKey, fValue in list(dDrivers.items()):
        if utils.isStringOrUnicode(sKey) and utils.isStringOrUnicode(fValue): # poseInterpolator
            sInterp = sKey
            dDrivers['%s.%s' % (sInterp,fValue)] = 1.0
            del dDrivers[sKey]

    print('\n\n === target: ', sTarget)
    sInbetweens = []
    iInbetweens = []
    for sI in cmds.ls('%s__???' % sTarget, et='transform'):
        try: iNumber = int(sI.split('_')[-1])
        except: iNumber = None
        if iNumber:
            sInbetweens.append(sI)
            iInbetweens.append(iNumber)


    sTargets = [sTarget] + sInbetweens

    if sMaskMap != None and not bMaskFromPose:
        for t,sT in enumerate(sTargets):
            if sMaskedName == None:
                if sT.endswith('_SCAN'):
                    sMaskedName = sT[:-len('_SCAN')]
                else:
                    sMaskedName = '%s_masked' % sT

            sDeformers = deformers.listAllDeformers(sModel)
            dTurnedOffDeformers = {}
            for sD in sDeformers:
                sNodeStateAttr = '%s.nodeState' % sD
                dTurnedOffDeformers[sNodeStateAttr] = cmds.getAttr(sNodeStateAttr)
                cmds.setAttr(sNodeStateAttr, 1)

            sDuplT = cmds.duplicate(sModel, n=sMaskedName)[0]

            print('dTurnedOffDeformers: ', dTurnedOffDeformers)
            [cmds.setAttr(a,b) for a,b in list(dTurnedOffDeformers.items())]

            if cmds.listRelatives(sDuplT, p=True, c=False):
                cmds.parent(sDuplT, w=True)
            cmds.setAttr('%s.v' % sDuplT, False)
            sMaskBlendShape = cmds.blendShape(sT, sDuplT, w=[0,1])[0]

            iSize = cmds.polyEvaluate(sDuplT, vertex=True)
            # aMapValues = geometry.getMapValues(sMaskMap) #if isinstance(sMaskMap, (str, unicode)):
            aMapValues = geometry.getMapValues(sMaskMap)
            cmds.setAttr('%s.inputTarget[0].baseWeights[0:%d]' % (sMaskBlendShape, iSize-1), *list(aMapValues))
            sTargets[t] = sDuplT




    iInbetweens = [100] + iInbetweens

    aSorted = np.argsort(iInbetweens)

    sTargets = list(np.array(sTargets)[aSorted])
    iInbetweens = np.array(iInbetweens, dtype='float64')[aSorted]
    aPercs = iInbetweens * 0.01

    if bInvert:
        sNewTargetName = '%s_INV' % sTargets[0]
    else:
        sNewTargetName = str(sTargets[0])

    # dAllPoses = {}
    for sAttr in list(dPoses.keys()):
        if '.' not in sAttr:
            raise Exception('this is not an attribute: %s (dPoses)' % sAttr)
        if not cmds.objExists(sAttr):
            raise Exception('this attribute doesn\'t exist: %s' % sAttr)
        if bMirror:
            if utils.getSide(sAttr) == 'l':
                sRightAttr = utils.getMirrorName(sAttr)
                if sRightAttr not in dPoses:
                    dPoses[sRightAttr] = dPoses[sAttr]


    # make sure .r and .t endings are posed first
    sSortedPoseKeys = sorted(list(dPoses.keys()), key=lambda a:not a.endswith('.t') and not a.endswith('.r'))


    # dDefaultAttrs = {sA:cmds.getAttr(sA) for sA in dPoses.keys()}
    dDefaultAttrs = {}
    for sA in sSortedPoseKeys:
        fValue = cmds.getAttr(sA)
        if isinstance(fValue, (list,tuple)): # most likely rotation, in that case it'll look like [(0.0, 0.0, 90)]
            dDefaultAttrs[sA] = np.array(fValue[0], dtype='float64')
        else:
            dDefaultAttrs[sA] = fValue



    def _activatePose(fPerc):
        for sAttr in sSortedPoseKeys:
            fValue = dPoses[sAttr]
            if isinstance(fValue, np.ndarray):
                if sAttr.endswith('.t') or sAttr.endswith('.translate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['tx','ty','tz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPoses[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                else:
                    cmds.setAttr(sAttr, *list(dPoses[sAttr] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc)))
            else:
                cmds.setAttr(sAttr, dPoses[sAttr] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc))


    if not dDrivers:
        if sDriversGetAttr:
            dDrivers = {}
        else:
            dDrivers = dict(dPoses)
    else:
        for sAttr in list(dDrivers.keys()):
            if '.' not in sAttr:
                raise Exception('this is not an attribute: %s (dDrivers)' % sAttr)
            if bMirror:
                if utils.getSide(sAttr) == 'l':
                    sRightAttr = utils.getMirrorName(sAttr)
                    if sRightAttr not in dDrivers:
                        dDrivers[sRightAttr] = dDrivers[sAttr]
    if sDriversGetAttr:
        for d in range(len(sDriversGetAttr)):
            if '.' not in sDriversGetAttr[d]:
                raise Exception('this is not an attribute: %s (sDriversGetAttr)' % sDriversGetAttr[d])
            sDriver = sDriversGetAttr[d]
            if bMirror:
                if utils.getSide(sDriver) == 'l':
                    sRightDriver = utils.getMirrorName(sDriver)
                    if sRightDriver not in sDriversGetAttr:
                        sDriversGetAttr.append(sRightDriver)


        for sDriver in sDriversGetAttr:
            try:
                dDrivers[sDriver] = [cmds.getAttr(sDriver)]
            except: raise Exception('error getting attribute value for %s' % sDriver)
        _activatePose(1.0)
        for sDriver in sDriversGetAttr:
            dDrivers[sDriver].append(cmds.getAttr(sDriver))
        _activatePose(0.0)


    # split dDrivers into left and right middles
    sReturnTargetAttrs = []
    sLeftRights = [], []
    sMiddles = []
    if bMirror:
        for sAttr in list(dDrivers.keys()):
            if utils.getSide(sAttr) == 'l': #''_l_' in sAttr:
                sLeftRights[0].append(sAttr)
                sRightAttr = utils.getMirrorName(sAttr) #.replace('_l_', '_r_')
                sLeftRights[1].append(sRightAttr)
                dDrivers[sRightAttr] = dDrivers[sAttr]
            else:
                if utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                    sMiddles.append(sAttr)
    else:
        sMiddles = list(dDrivers.keys())




    sMultDriversLeftRights = [], []
    sMultDriversMiddles = []
    if bMirror:
        for sAttr in list(dMultDrivers.keys()):
            if utils.getSide(sAttr) == 'l':
                sMultDriversLeftRights[0].append(sAttr)
                sRightAttr = utils.getMirrorName(sAttr)
                sMultDriversLeftRights[1].append(sRightAttr)
                dMultDrivers[sRightAttr] = dMultDrivers[sAttr]
            else:
                if utils.getSide(sAttr) == 'm':
                    sMultDriversMiddles.append(sAttr)
    else:
        sMultDriversMiddles = list(dMultDrivers.keys())



    for sAttr, xDriver in list(dMultDrivers.items()):
        dMultDrivers[sAttr] = _rangeOrDrivenKeys(sAttr, xDriver, fOvershootRange)
    for sAttr, xDriver in list(dDrivers.items()):
        dDrivers[sAttr] = _rangeOrDrivenKeys(sAttr, xDriver, fOvershootRange)



    if bInvert:

        for t,sT in enumerate(sTargets):

            sCurrentNewName = str(sNewTargetName)
            if t < len(sTargets)-1:
                sCurrentNewName = '%s_%03d' % (sCurrentNewName, iInbetweens[t])

            _activatePose(aPercs[t])

            if bStopBeforeInvert:
                cmds.select(sT, sModel)
                raise Exception('exception on purpose: stop before invertShapeDeformers (meshes are selected)')

            sInverted = geometry.invertShapeDeformers(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)
            try:cmds.setAttr('%s.v' % sInverted, cmds.getAttr('%s.v' % sT))
            except: pass

            for b, sSecondaryModel in enumerate(sSecondaryModels):
                sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                if cmds.objExists(sSecondaryT):
                    sSecondaryInverted = geometry.invertShapeDeformers(sSecondaryT, sSecondaryModel, sComboBlendShape=sSecondaryBlendShapes[b], sInvertName='%s__%s' % (sSecondaryModel, sCurrentNewName))
                    try:cmds.setAttr('%s.v' % sSecondaryInverted, cmds.getAttr('%s.v' % sT))
                    except: pass

            try: cmds.parent(sInverted, '_invertedShapes_')
            except: pass

            sTargets[t] = sInverted

        _activatePose(0.0)

    if sMaskMap != None and bMaskFromPose:
        _activatePose(1.0)
        for t,sT in enumerate(sTargets):
            if sMaskedName == None:
                if sT.endswith('_SCAN'):
                    sMaskedName = sT[:-len('_SCAN')]
                else:
                    sMaskedName = '%s_masked' % sT

            if utils.isStringOrUnicode(bMaskFromPose):
                sDuplT = cmds.duplicate(bMaskFromPose, n='%s_INV' % sMaskedName)[0]
            else:
                sDuplT = cmds.duplicate(sModel, n='%s_masked' % sT)[0]
            if cmds.listRelatives(sDuplT, p=True, c=False):
                cmds.parent(sDuplT, w=True)
            cmds.setAttr('%s.v' % sDuplT, False)
            sMaskBlendShape = cmds.blendShape(sT, sDuplT, w=[0,1])[0]
            iSize = cmds.polyEvaluate(sDuplT, vertex=True)
            # aMapValues = geometry.getMapValues(sMaskMap) #if isinstance(sMaskMap, (str, unicode)):
            aMapValues = geometry.getMapValues(sMaskMap)
            cmds.setAttr('%s.inputTarget[0].baseWeights[0:%d]' % (sMaskBlendShape, iSize-1), *list(aMapValues))
            sTargets[t] = sDuplT
            if bStopBeforeMask:
                cmds.select(sT, sDuplT)
                raise Exception('exception on purpose: stop before masking meshes (meshes are selected)')

        _activatePose(0.0)


    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetMirrors, sTarget)
    dConnectTargetMirrors[sTarget].append(True if len(sLeftRights[0]) or len(sMultDriversLeftRights[0]) else False)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)

    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitBotTops, sTarget)
    dConnectTargetSplitBotTops[sTarget].append(bSplitBotTop)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)

    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitRadien, sTarget)
    dConnectTargetSplitRadien[sTarget].append(fSplitRadius)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)




    if not bSplitBotTop:
        if len(sLeftRights[0]) or len(sMultDriversLeftRights[0]): # split between left and right, no bot and top
            if dMultDrivers:
                sMultDriverSides = [_combineValues(iCombineMode,
                    [dMultDrivers[sAttr] for sAttr in sMultDriversLeftRights[0] + sMultDriversMiddles]),
                                    _combineValues(iCombineMode, [dMultDrivers[sAttr] for sAttr in
                                                             sMultDriversLeftRights[1] + sMultDriversMiddles])]
            else:
                sMultDriverSides = None

            sMainDrivers = [None, None]
            sFactors = [], []
            for s, sSide in enumerate(['l', 'r']):
                for sAttr in sLeftRights[s] + sMiddles:
                    sFactors[s].append(dDrivers[sAttr])

                sMainDrivers[s] = _combineValues(iCombineMode, sFactors[s])
                if bAppleBlendShapes:
                    for sAttr in sLeftRights[s] + sMiddles:
                        if sAttr.startswith('appleFaceBlendshapes'):
                            sUnrealTarget = sAttr.split('.')[-1]
                            unreal.addEmptyUnrealTargets(sUnrealTarget)


            for i, sT in enumerate(sTargets):
                cmds.setAttr('%s.envelope' % sBlendShape, 0.0) # careful with this - added later on
                if sMirrorBase == None:
                    sMirrorBase = sModel
                if bStopBeforeMirror:
                    cmds.select(sMirrorBase, sT)
                    raise Exception('exception on purpose: stop before geometry.splitShape() and addBlendShapeTargets() (meshes are selected)')
                ssSplitShapes = [geometry.splitShape(sT, sMirrorBase, fRadius=fSplitRadius, bUnParent=True, xMirrorAxis=xMirrorAxis)]
                sAliasAttrs = ssSplitShapes[-1] if sAlias == None else ['l_%s' % sAlias, 'r_%s' % sAlias]
                ssTargetAttrs = [deformers.addBlendShapeTargets(sModel, ssSplitShapes[-1], sAliasAttrs=sAliasAttrs)]

                for sSecondaryModel in sSecondaryModels:
                    sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                    if cmds.objExists(sSecondaryT):
                        ssSplitShapes.append(geometry.splitShape(sSecondaryT, sSecondaryModel, fRadius=fSplitRadius, bUnParent=True, xMirrorAxis=xMirrorAxis))
                        ssTargetAttrs.append(deformers.addBlendShapeTargets(sSecondaryModel, ssSplitShapes[-1], sAliasAttrs=sAliasAttrs))

                cmds.setAttr('%s.envelope' % sBlendShape, 1.0) # careful with this - added later on

                sReturnTargetAttrs += ssTargetAttrs
                for s, sSide in enumerate(['l', 'r']):
                    if bAppleBlendShapes:
                        sUnrealCommands += '\nCOMBINE %s ' % ssSplitShapes[0][s]
                        for sRangeOut in sFactors[s]:
                            sRange = sRangeOut.split('.')[0]
                            sAppleBlendShape = cmds.listConnections('%s.valueX' % sRange, p=True)[0]
                            sUnrealCommands += '0 %s %0.3f %0.3f %0.3f %0.3f ' % (sAppleBlendShape.split('.')[-1],
                                                                                cmds.getAttr('%s.oldMinX' % sRange), cmds.getAttr('%s.oldMaxX' % sRange),
                                                                                cmds.getAttr('%s.minX' % sRange), cmds.getAttr('%s.maxX' % sRange))

                    if len(sTargets) == 1:
                        if sMultDriverSides:
                            _combineValues(iCombineMode, [sMainDrivers[s], sMultDriverSides[s]], sTarget=[sTargetAttrs[s] for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]])
                        else:
                            [cmds.connectAttr(sMainDrivers[s], sTargetAttrs[s]) for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]]
                    else:
                        if i == len(sTargets) - 1:  # the full one
                            if sMultDriverSides:
                                sDriven = nodes.setDrivenKey(sMainDrivers[s], [aPercs[i - 1], 1], None, [0, 1], sInTanType='linear', sOutTanType='linear')
                                _combineValues(iCombineMode, [sDriven, sMultDriverSides[s]], sTarget=[sTargetAttrs[s] for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]])
                            else:
                                [nodes.setDrivenKey(sMainDrivers[s], [aPercs[i - 1], 1], sTargetAttrs[s], [0, 1], sInTanType='linear', sOutTanType='linear')
                                    for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]]
                        else:  # inbetween
                            if sMultDriverSides:
                                sDriven = nodes.setDrivenKey(sMainDrivers[s],
                                                             [aPercs[i - 1] if i > 0 else 0.0, aPercs[i],
                                                              aPercs[i + 1]], None, [0, 1, 0], sInTanType='linear', sOutTanType='linear')
                                _combineValues(iCombineMode, [sDriven, sMultDriverSides[s]], sTarget=[sTargetAttrs[s] for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]])
                            else:
                                for sTargetAttrs in ssTargetAttrs:
                                    if sTargetAttrs[s]:
                                        nodes.setDrivenKey(sMainDrivers[s],
                                                           [aPercs[i - 1] if i > 0 else 0.0, aPercs[i], aPercs[i + 1]],
                                                           sTargetAttrs[s], [0, 1, 0], sInTanType='linear', sOutTanType='linear')


        else: # simplest case: no splitting at all

            if dMultDrivers:
                sMultDriverMiddle = _combineValues(iCombineMode, [dMultDrivers[sAttr] for sAttr in sMultDriversMiddles])
            else:
                sMultDriverMiddle = None

            sFactors = []
            for sAttr in sMiddles:
                sFactors.append(dDrivers[sAttr])
            sMainDriver = _combineValues(iCombineMode, sFactors)

            if bAppleBlendShapes:
                for sAttr in sMiddles:
                    if sAttr.startswith('appleFaceBlendshapes'):
                        sUnrealTarget = sAttr.split('.')[-1]
                        unreal.addEmptyUnrealTargets(sUnrealTarget)

            for i, sT in enumerate(sTargets):
                sAliasAttr = sT if sAlias == None else sAlias
                sTargetAttrs = [deformers.addBlendShapeTargets(sModel, sT, sAliasAttrs=sAliasAttr)[0]]
                for sSecondaryModel in sSecondaryModels: # not fully tested yet
                    sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                    if cmds.objExists(sSecondaryT):
                        sTargetAttrs.append(deformers.addBlendShapeTargets(sSecondaryModel, sSecondaryT, sAliasAttrs=sAliasAttr)[0])

                sReturnTargetAttrs.append(sTargetAttrs)

                if len(sTargets) == 1:
                    for sTargetAttr in sTargetAttrs:
                        if sMultDriverMiddle:
                            _combineValues(iCombineMode, [sMainDriver, sMultDriverMiddle], sTarget=sTargetAttr)
                        else:
                            cmds.connectAttr(sMainDriver, sTargetAttr)
                else:
                    for sTargetAttr in sTargetAttrs:

                        if i == len(sTargets) - 1:  # the full one
                            sDrivenKey = nodes.setDrivenKey(sMainDriver, [aPercs[i - 1], 1], None, [0, 1], sInTanType='linear', sOutTanType='linear')
                        else:  # inbetween
                            sDrivenKey = nodes.setDrivenKey(sMainDriver, [aPercs[i - 1] if i > 0 else 0.0, aPercs[i],
                                                             aPercs[i + 1]], None, [0, 1, 0], sInTanType='linear', sOutTanType='linear')
                        if sMultDriverMiddle:
                            _combineValues(iCombineMode, [sDrivenKey, sMultDriverMiddle], sTarget=sTargetAttr)
                        else:
                            cmds.connectAttr(sDrivenKey, sTargetAttr)

            if bAppleBlendShapes:
                sUnrealCommands += '\nCOMBINE %s ' % sT
                for sRangeOut in sFactors:
                    sRange = sRangeOut.split('.')[0]
                    sAppleBlendShape = cmds.listConnections('%s.valueX' % sRange, p=True)[0]

                    sUnrealCommands += '0 %s %0.3f %0.3f %0.3f %0.3f ' % (sAppleBlendShape.split('.')[-1],
                                                                          cmds.getAttr('%s.oldMinX' % sRange),
                                                                          cmds.getAttr('%s.oldMaxX' % sRange),
                                                                          cmds.getAttr('%s.minX' % sRange),
                                                                          cmds.getAttr('%s.maxX' % sRange))

    else: # bSplitBotTop
        dBottomWeights = {}
        for sM in [sModel] + sSecondaryModels:
            dBottomWeights[sM] = getMouthBottomWeights(sM)

        if len(sLeftRights[0]): # biggest case - left and right, bot and top (4 different shapes).

            ssFactorsBot = [], []
            ssFactorsTop = [], []

            ssMainDrivers = [None, None], [None, None]
            for s, sSide in enumerate(['l', 'r']):
                for sAttr in sLeftRights[s] + sMiddles:
                    if 'Bot' in sAttr :
                        ssFactorsBot[s].append(dDrivers[sAttr])
                    elif 'Top' in sAttr:
                        ssFactorsTop[s].append(dDrivers[sAttr])
                    else:
                        ssFactorsBot[s].append(dDrivers[sAttr])
                        ssFactorsTop[s].append(dDrivers[sAttr])

                ssMainDrivers[s][0] = _combineValues(iCombineMode, ssFactorsBot[s])
                ssMainDrivers[s][1] = _combineValues(iCombineMode, ssFactorsTop[s])

            for i, sT in enumerate(sTargets):
                sBotShape, sTopShape = geometry.splitShape(sT, sModel, aLeftWeights=dBottomWeights[sModel], sLeftName='bot_%s' % sT, sRightName='top_%s' % sT, xMirrorAxis=xMirrorAxis)
                sAliasAttrs = ['bot_%s' % sAlias, 'top_%s' % sAlias] if sAlias else ['bot_%s' % sT, 'top_%s' % sT]
                ssTargetAttrsBot = [deformers.addBlendShapeTargets(sModel, geometry.splitShape(sBotShape, sModel, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis), sAliasAttrs=['l_%s' % sAliasAttrs[0], 'r_%s' % sAliasAttrs[0]])]
                ssTargetAttrsTop = [deformers.addBlendShapeTargets(sModel, geometry.splitShape(sTopShape, sModel, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis), sAliasAttrs=['l_%s' % sAliasAttrs[1], 'r_%s' % sAliasAttrs[1]])]
                sReturnTargetAttrs += ssTargetAttrsBot + ssTargetAttrsTop
                for sSecondaryModel in sSecondaryModels:
                    sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                    if cmds.objExists(sSecondaryT):

                        sBotShape, sTopShape = geometry.splitShape(sSecondaryT, sSecondaryModel, aLeftWeights=dBottomWeights[sSecondaryModel],
                                                                   sLeftName='%s__bot_%s' % (sSecondaryModel,sT), sRightName='%s__top_%s' % (sSecondaryModel,sT), xMirrorAxis=xMirrorAxis)
                        if sBotShape:
                            ssTargetAttrsBot.append(deformers.addBlendShapeTargets(sSecondaryModel, geometry.splitShape(sBotShape, sSecondaryModel, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis),
                                                                                    sAliasAttrs=['l_%s' % sAliasAttrs[0], 'r_%s' % sAliasAttrs[0]]))
                        if sTopShape:
                            ssTargetAttrsTop.append(deformers.addBlendShapeTargets(sSecondaryModel, geometry.splitShape(sTopShape, sSecondaryModel, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis),
                                                                                    sAliasAttrs=['l_%s' % sAliasAttrs[1], 'r_%s' % sAliasAttrs[1]]))



                for s, sSide in enumerate(['l', 'r']):
                    if len(sTargets) == 1: # no inbetweens
                        print('ssTargetAttrsBot: ', ssTargetAttrsBot)
                        [cmds.connectAttr(ssMainDrivers[s][0], sTargetAttrsBot[s]) for sTargetAttrsBot in ssTargetAttrsBot if sTargetAttrsBot[s]]
                        [cmds.connectAttr(ssMainDrivers[s][1], sTargetAttrsTop[s]) for sTargetAttrsTop in ssTargetAttrsTop if sTargetAttrsTop[s]]
                    else: # there are inbetweens
                        if i == len(sTargets) - 1:  # the full one
                            nodes.createRangeNode(ssMainDrivers[s][0], aPercs[i - 1], 1, 0, 1, sTarget=sTargetAttrsBot[s])
                            nodes.createRangeNode(ssMainDrivers[s][1], aPercs[i - 1], 1, 0, 1, sTarget=sTargetAttrsTop[s])
                        else:
                            nodes.setDrivenKey(ssMainDrivers[s][0],
                                             [aPercs[i - 1] if i > 0 else 0.0, aPercs[i], aPercs[i + 1]], sTargetAttrsBot[s], [0, 1, 0],
                                             sInTanType='linear', sOutTanType='linear')
                            nodes.setDrivenKey(ssMainDrivers[s][1],
                                             [aPercs[i - 1] if i > 0 else 0.0, aPercs[i], aPercs[i + 1]], sTargetAttrsTop[s], [0, 1, 0],
                                             sInTanType='linear', sOutTanType='linear')

        else:  # bot top, but not left and right
            sFactorsBot = []
            sFactorsTop = []
            sMainDrivers = [None, None]

            for sAttr in sMiddles:
                if 'Bot' in sAttr:
                    sFactorsBot.append(dDrivers[sAttr])
                elif 'Top' in sAttr:
                    sFactorsTop.append(dDrivers[sAttr])
                else:
                    sFactorsBot.append(dDrivers[sAttr])
                    sFactorsTop.append(dDrivers[sAttr])
            sMainDrivers[0] = _combineValues(iCombineMode, sFactorsBot)  # library.createMultiplyNodeArray(sFactorsBot, bForceNormalizedLinear=True)
            sMainDrivers[1] = _combineValues(iCombineMode, sFactorsTop)  # library.createMultiplyNodeArray(sFactorsTop, bForceNormalizedLinear=True)

            for i, sT in enumerate(sTargets):
                sBotShape, sTopShape = geometry.splitShape(sT, sModel, aLeftWeights=dBottomWeights[sModel], sLeftName='bot_%s' % sT, sRightName='top_%s' % sT, xMirrorAxis=xMirrorAxis)
                sAliasAttrs = ['bot_%s' % sAlias, 'top_%s' % sAlias] if sAlias else ['bot_%s' % sT, 'top_%s' % sT]
                ssTargetAttrBot = [deformers.addBlendShapeTargets(sModel, sBotShape, sAliasAttrs=sAliasAttrs[0])[0]]
                ssTargetAttrTop = [deformers.addBlendShapeTargets(sModel, sTopShape, sAliasAttrs=sAliasAttrs[1])[0]]
                sReturnTargetAttrs += [ssTargetAttrBot[0], ssTargetAttrTop[0]]

                for sSecondaryModel in sSecondaryModels:
                    sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                    if cmds.objExists(sSecondaryT):
                        sBotShape, sTopShape = geometry.splitShape(sSecondaryT, sSecondaryModel, aLeftWeights=dBottomWeights[sSecondaryModel],
                                                                   sLeftName='%s__bot_%s' % (sSecondaryModel,sT), sRightName='%s__top_%s' % (sSecondaryModel,sT), xMirrorAxis=xMirrorAxis)
                        ssTargetAttrBot.append(deformers.addBlendShapeTargets(sSecondaryModel, sBotShape, sAliasAttrs=sAliasAttrs[0])[0])
                        ssTargetAttrTop.append(deformers.addBlendShapeTargets(sSecondaryModel, sTopShape, sAliasAttrs=sAliasAttrs[1])[0])

                if len(sTargets) == 1:  # no inbetweens
                    print('ssTargetAttrBot: ', ssTargetAttrBot)
                    [cmds.connectAttr(sMainDrivers[0], sTargetAttrBot) for sTargetAttrBot in ssTargetAttrBot if sTargetAttrBot]
                    [cmds.connectAttr(sMainDrivers[1], sTargetAttrTop) for sTargetAttrTop in ssTargetAttrTop if sTargetAttrTop]
                else:  # there are inbetweens
                    if i == len(sTargets) - 1:  # the full one
                        [nodes.setDrivenKey(sMainDrivers[0], [aPercs[i - 1], 1], sTargetAttrBot, [0, 1], sInTanType='linear', sOutTanType='linear') for sTargetAttrBot in ssTargetAttrBot]
                        [nodes.setDrivenKey(sMainDrivers[1], [aPercs[i - 1], 1], sTargetAttrTop, [0, 1], sInTanType='linear', sOutTanType='linear') for sTargetAttrTop in ssTargetAttrTop]
                    else:
                        [nodes.setDrivenKey(sMainDrivers[0],
                                             [aPercs[i - 1] if i > 0 else 0.0, aPercs[i], aPercs[i + 1]],
                                             sTargetAttrBot, [0, 1, 0], sInTanType='linear', sOutTanType='linear') for sTargetAttrBot in ssTargetAttrBot if sTargetAttrBot]
                        [nodes.setDrivenKey(sMainDrivers[1],
                                             [aPercs[i - 1] if i > 0 else 0.0, aPercs[i], aPercs[i + 1]],
                                             sTargetAttrTop, [0, 1, 0], sInTanType='linear', sOutTanType='linear') for sTargetAttrTop in ssTargetAttrTop if sTargetAttrTop]



    for sCtrlAttr in list(dPoses.keys()):
        sCtrl = sCtrlAttr.split('.')[0]
        addIgnoreAttachTargets(sCtrl, utils.flattenedList(sReturnTargetAttrs))

    if bAppleBlendShapes:
        return sUnrealCommands
    else:
        return sReturnTargetAttrs



dBottomWeights = {}
dSplitAlongCurveWeights = {}
dZipperWeights = {}
sZipperOutAttrs = []
def clearWeightsCache():
    global dBottomWeights
    dBottomWeights.clear()

    global dSplitAlongCurveWeights
    dSplitAlongCurveWeights.clear()

    global dZipperWeights
    dZipperWeights.clear()

    global sZipperOutAttrs
    sZipperOutAttrs = []

def connectTargets2(sModel, sTarget, dDrivers={}, sDriversGetAttr=[], dMultDrivers={}, bMirror=True, dPoses={}, iInvert=False, sMaskMap=None, sMaskedName=None, bMaskFromPose=False,
                    fSplitRadius=0.2, bSplitBotTop=False, sBlendShape=None, bStopBeforeInvert=False, bStopBeforeMask=False, bStopBeforeMirror=False, bAppleBlendShapes=False, sSecondaryModels=[],
                   sAlias=None, bReturnIfNotExist=False, fOvershootRange=None, iCombineMode=CombineMode.minimum, xMirrorAxis=None, dSplitAlongCurve={}, dZipper={}):
    '''
    :param sModel:
    :param sTarget:
    :param dPoses: dictionary of attributes and values
            poses examples: dPoses={'clavLFT':'forward'},
    :param dDrivers: dictionary of attributes and values/lists. If it's a list it needs to have 2 items, start and end \
                    value of attribute. If it's missing, then the poses dictionary will be taken for it.
    :param sDriversGetAttr: list of attributes.
    :param bMirror:
    :param iInvert:
    :param fSplitRadius:
    :param bSplitBotTop:
    :param sBlendShape:
    :return:
    '''

    if sTarget != None and not cmds.objExists(sTarget) and bReturnIfNotExist:
        print('skipping target "%s", because it doesn\'t exist.' % sTarget)
        return

    # dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={}) # should be defaultDict(list), but that can't be stored
    # dConnectTargetsDriverGetAttrs = utils.data.get('dConnectTargetDriverGetAttrs', xDefault={}) # should be defaultDict(list), but that can't be stored
    #
    # utils.addListKey(dConnectTargetPoses, sTarget)
    # dConnectTargetPoses[sTarget].append(dPoses)
    #
    # utils.addListKey(dConnectTargetsDriverGetAttrs, sTarget)
    # if sDriversGetAttr:
    #     dConnectTargetsDriverGetAttrs[sTarget].append(sDriversGetAttr)
    # else:
    #     dConnectTargetsDriverGetAttrs[sTarget].append(dPoses.keys())
    #
    # utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
    # utils.data.store('dConnectTargetDriverGetAttrs', dConnectTargetsDriverGetAttrs)

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetPoses, sTarget)
    dConnectTargetPoses[sTarget].append(dPoses)
    utils.data.store('dConnectTargetPoses', dConnectTargetPoses)

    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetDrivers, sTarget)
    dConnectTargetDrivers[sTarget].append(dDrivers)
    utils.data.store('dConnectTargetDrivers', dConnectTargetDrivers)

    dConnectTargetDriverGetAttrs = utils.data.get('dConnectTargetDriverGetAttrs', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetDriverGetAttrs, sTarget)
    dConnectTargetDriverGetAttrs[sTarget].append(sDriversGetAttr)
    utils.data.store('dConnectTargetDriverGetAttrs', dConnectTargetDriverGetAttrs)


    sDriversGetAttr = list(sDriversGetAttr)
    dDrivers = dict(dDrivers)
    dPoses = dict(dPoses)
    dMultDrivers = dict(dMultDrivers)

    if bAppleBlendShapes:
        sUnrealCommands = ''

    if sTarget == None:
        sTarget = cmds.duplicate(sModel)[0]
        if cmds.listRelatives(sTarget, p=True):
           cmds.parent(sTarget, w=True)

    print('\n\n\n ============================= sTarget: %s (%s) - secondary models: %s' % (sTarget, sModel, sSecondaryModels))

    if not cmds.objExists(sTarget):
        raise Exception('Target %s doesn\'t exist.' % sTarget)

    if sBlendShape == None:
        sBlendShape = 'blendShape__%s' % sModel.split(':')[-1]
        if not cmds.objExists(sBlendShape):
            deformers.preDeformationBlendshapeHack([], sModel, n=sBlendShape)
            if not cmds.objExists(sBlendShape):
                raise Exception('wasn\'t able to create blendShape')

    if sSecondaryModels:
        sSecondaryModels = list(set(sSecondaryModels))
    sSecondaryBlendShapes = []
    for sSecondaryModel in sSecondaryModels:
        sSecondaryBlendShape = 'blendShape__%s' % sSecondaryModel
        if not cmds.objExists(sSecondaryBlendShape):
            sSecondaryBlendShapes.append(sSecondaryBlendShape)
            deformers.preDeformationBlendshapeHack([], sSecondaryModel, n=sSecondaryBlendShape)
            if not cmds.objExists(sSecondaryBlendShape):
                raise Exception('wasn\'t able to create blendShape')
        sSecondaryBlendShapes.append(sSecondaryBlendShape)



    if not dPoses and (iInvert or sDriversGetAttr):
        dPoses = dict(dDrivers)
        for sA,xV in list(dPoses.items()):
            if isinstance(xV,(list,tuple)):
                dPoses[sA] = xV[1]

    # clean dPoses
    for sKey, fValue in list(dPoses.items()):
        if utils.isStringOrUnicode(sKey) and utils.isStringOrUnicode(fValue): # poseInterpolator
            sInterp = sKey
            dInterp = getPosesDictFromInterp(sInterp)
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
            if ':' in sInterp:
                sCtrl = '%s:%s' % (':'.join(sInterp.split(':')[:-1]), sCtrl)
            dPoses['%s.r' % sCtrl] = np.array(dInterp[fValue], dtype='float64')
            del dPoses[sKey]
            if not dDrivers:
                sDriversGetAttr.append('%s.%s' % (sInterp,fValue))
        elif isinstance(fValue, (list,tuple)): # this is for compound attributes
            dPoses[sKey] = np.array(fValue)
        elif not isinstance(fValue, (int, float, type(None))):
            raise Exception('dPoses can only have floats, ints or None as values (%s, %s)' % (sTarget, dPoses))

    # clean dDrivers
    for sKey, fValue in list(dDrivers.items()):
        if utils.isStringOrUnicode(sKey) and utils.isStringOrUnicode(fValue): # poseInterpolator
            sInterp = sKey
            dDrivers['%s.%s' % (sInterp,fValue)] = 1.0
            del dDrivers[sKey]

    print('\n\n === target: ', sTarget)
    sInbetweens = []
    iInbetweens = []
    for sI in cmds.ls('%s__???' % sTarget, et='transform'):
        try: iNumber = int(sI.split('_')[-1])
        except: iNumber = None
        if iNumber:
            sInbetweens.append(sI)
            iInbetweens.append(iNumber)


    sTargets = [sTarget] + sInbetweens

    if sMaskMap != None and not bMaskFromPose:
        for t,sT in enumerate(sTargets):
            if sMaskedName == None:
                if sT.endswith('_SCAN'):
                    sMaskedName = sT[:-len('_SCAN')]
                else:
                    sMaskedName = '%s_masked' % sT

            sDeformers = deformers.listAllDeformers(sModel)
            dTurnedOffDeformers = {}
            for sD in sDeformers:
                sNodeStateAttr = '%s.nodeState' % sD
                dTurnedOffDeformers[sNodeStateAttr] = cmds.getAttr(sNodeStateAttr)
                cmds.setAttr(sNodeStateAttr, 1)

            sDuplT = cmds.duplicate(sModel, n=sMaskedName)[0]

            print('dTurnedOffDeformers: ', dTurnedOffDeformers)
            [cmds.setAttr(a,b) for a,b in list(dTurnedOffDeformers.items())]

            if cmds.listRelatives(sDuplT, p=True, c=False):
                cmds.parent(sDuplT, w=True)
            cmds.setAttr('%s.v' % sDuplT, False)
            sMaskBlendShape = cmds.blendShape(sT, sDuplT, w=[0,1])[0]

            iSize = cmds.polyEvaluate(sDuplT, vertex=True)
            # aMapValues = geometry.getMapValues(sMaskMap) #if isinstance(sMaskMap, (str, unicode)):
            aMapValues = geometry.getMapValues(sMaskMap)
            cmds.setAttr('%s.inputTarget[0].baseWeights[0:%d]' % (sMaskBlendShape, iSize-1), *list(aMapValues))
            sTargets[t] = sDuplT




    iInbetweens = [100] + iInbetweens

    aSorted = np.argsort(iInbetweens)

    sTargets = list(np.array(sTargets)[aSorted])
    iInbetweens = np.array(iInbetweens, dtype='float64')[aSorted]
    aPercs = iInbetweens * 0.01

    if iInvert == 2:
        sNewTargetName = '%s_INV' % sTargets[-1]
    elif iInvert == 1:
        sNewTargetName = '%s_CMB' % sTargets[-1]
    else:
        sNewTargetName = str(sTargets[-1])

    # dAllPoses = {}
    for sAttr in list(dPoses.keys()):
        if '.' not in sAttr:
            raise Exception('this is not an attribute: %s (dPoses)' % sAttr)
        if not cmds.objExists(sAttr):
            raise Exception('this attribute doesn\'t exist: %s' % sAttr)
        if bMirror:
            if utils.getSide(sAttr) == 'l':
                sRightAttr = utils.getMirrorName(sAttr)
                if sRightAttr not in dPoses:
                    dPoses[sRightAttr] = dPoses[sAttr]




    dPosesForInvert = dict(dPoses)
    if dSplitAlongCurve:
        for sA,fV in zip(dSplitAlongCurve['sAttrs'], dSplitAlongCurve['fValues']):
            dPosesForInvert[sA] = fV
    if dZipper:
        dPosesForInvert['lipsCornerLFT_ctrl.sealB'] = 1.0

    # make sure .r and .t endings are posed first
    sSortedPoseKeysForInvert = sorted(list(dPosesForInvert.keys()), key=lambda a:not a.endswith('.t') and not a.endswith('.r'))
    dDefaultAttrs = {}
    for sA in sSortedPoseKeysForInvert:
        fValue = cmds.getAttr(sA)
        if isinstance(fValue, (list,tuple)): # most likely rotation, in that case it'll look like [(0.0, 0.0, 90)]
            dDefaultAttrs[sA] = np.array(fValue[0], dtype='float64')
        else:
            dDefaultAttrs[sA] = fValue

    def _activatePose(fPerc):
        for sAttr in sSortedPoseKeysForInvert:
            fValue = dPosesForInvert[sAttr]
            if isinstance(fValue, np.ndarray):
                if sAttr.endswith('.t') or sAttr.endswith('.translate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['tx','ty','tz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                else:
                    cmds.setAttr(sAttr, *list(dPosesForInvert[sAttr] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc)))
            else:
                cmds.setAttr(sAttr, dPosesForInvert[sAttr] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc))

    print('dDrivers0: ', dDrivers)
    print('dPoses: ', dPoses)
    if not dDrivers:
        if sDriversGetAttr:
            dDrivers = {}
        else:
            dDrivers = dict(dPoses)
    else:
        for sAttr in list(dDrivers.keys()):
            if '.' not in sAttr:
                raise Exception('this is not an attribute: %s (dDrivers)' % sAttr)
            if bMirror:
                if utils.getSide(sAttr) == 'l':
                    sRightAttr = utils.getMirrorName(sAttr)
                    if sRightAttr not in dDrivers:
                        dDrivers[sRightAttr] = dDrivers[sAttr]

    print('dDrivers1: ', dDrivers)

    if sDriversGetAttr:
        for d in range(len(sDriversGetAttr)):
            if '.' not in sDriversGetAttr[d]:
                raise Exception('this is not an attribute: %s (sDriversGetAttr)' % sDriversGetAttr[d])
            sDriver = sDriversGetAttr[d]
            if bMirror:
                if utils.getSide(sDriver) == 'l':
                    sRightDriver = utils.getMirrorName(sDriver)
                    if sRightDriver not in sDriversGetAttr:
                        sDriversGetAttr.append(sRightDriver)


        for sDriver in sDriversGetAttr:
            try:
                dDrivers[sDriver] = [cmds.getAttr(sDriver)]
            except: raise Exception('error getting attribute value for %s' % sDriver)
        _activatePose(1.0)
        for sDriver in sDriversGetAttr:
            dDrivers[sDriver].append(cmds.getAttr(sDriver))
        _activatePose(0.0)


    # split dDrivers into left and right middles
    sReturnTargetAttrs = []
    sLeftRights = [], []
    sMiddles = []
    print('dDrivers2: ', dDrivers)
    print('bMirror: ', bMirror)
    if bMirror:
        for sAttr in list(dDrivers.keys()):
            if utils.getSide(sAttr) == 'l': #''_l_' in sAttr:
                sLeftRights[0].append(sAttr)
                sRightAttr = utils.getMirrorName(sAttr) #.replace('_l_', '_r_')
                sLeftRights[1].append(sRightAttr)
                dDrivers[sRightAttr] = dDrivers[sAttr]
            else:
                if utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                    sMiddles.append(sAttr)
    else:
        sMiddles = list(dDrivers.keys())

    print('dDrivers2.5: ', dDrivers)



    sMultDriversLeftRights = [], []
    sMultDriversMiddles = []
    if bMirror:
        for sAttr in list(dMultDrivers.keys()):
            if utils.getSide(sAttr) == 'l':
                sMultDriversLeftRights[0].append(sAttr)
                sRightAttr = utils.getMirrorName(sAttr)
                sMultDriversLeftRights[1].append(sRightAttr)
                dMultDrivers[sRightAttr] = dMultDrivers[sAttr]
            else:
                if utils.getSide(sAttr) == 'm':
                    sMultDriversMiddles.append(sAttr)
    else:
        sMultDriversMiddles = list(dMultDrivers.keys()) # gotta do something about that


    print('dDrivers2.6: ', dDrivers)

    for sAttr, xDriver in list(dMultDrivers.items()):
        dMultDrivers[sAttr] = _rangeOrDrivenKeys(sAttr, xDriver, fOvershootRange)
    for sAttr, xDriver in list(dDrivers.items()):
        dDrivers[sAttr] = _rangeOrDrivenKeys(sAttr, xDriver, fOvershootRange)

    print('dDrivers2.7: ', dDrivers)


    if iInvert:

        for t,sT in enumerate(sTargets):

            sCurrentNewName = str(sNewTargetName)
            if t < len(sTargets)-1:
                sCurrentNewName = '%s_%03d' % (sCurrentNewName, iInbetweens[t])

            _activatePose(aPercs[t])

            if bStopBeforeInvert:
                cmds.select(sT, sModel)
                raise Exception('exception on purpose: stop before invertShapeDeformers (meshes are selected)')

            if iInvert == 1:
                sInverted = geometry.calculateComboShape(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)
            else:
                sInverted = geometry.invertShapeDeformers(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)

            try:cmds.setAttr('%s.v' % sInverted, cmds.getAttr('%s.v' % sT))
            except: pass

            for b, sSecondaryModel in enumerate(sSecondaryModels):
                sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                if cmds.objExists(sSecondaryT):
                    sSecondaryInverted = geometry.invertShapeDeformers(sSecondaryT, sSecondaryModel, sComboBlendShape=sSecondaryBlendShapes[b], sInvertName='%s__%s' % (sSecondaryModel, sCurrentNewName))
                    try:cmds.setAttr('%s.v' % sSecondaryInverted, cmds.getAttr('%s.v' % sT))
                    except: pass

            try: cmds.parent(sInverted, '_invertedShapes_')
            except: pass

            sTargets[t] = sInverted

        _activatePose(0.0)

    if sMaskMap != None and bMaskFromPose:
        _activatePose(1.0)
        for t,sT in enumerate(sTargets):
            if sMaskedName == None:
                if sT.endswith('_SCAN'):
                    sMaskedName = sT[:-len('_SCAN')]
                else:
                    sMaskedName = '%s_masked' % sT

            if utils.isStringOrUnicode(bMaskFromPose):
                sDuplT = cmds.duplicate(bMaskFromPose, n='%s_INV' % sMaskedName)[0]
            else:
                sDuplT = cmds.duplicate(sModel, n='%s_masked' % sT)[0]
            if cmds.listRelatives(sDuplT, p=True, c=False):
                cmds.parent(sDuplT, w=True)
            cmds.setAttr('%s.v' % sDuplT, False)
            sMaskBlendShape = cmds.blendShape(sT, sDuplT, w=[0,1])[0]
            iSize = cmds.polyEvaluate(sDuplT, vertex=True)
            # aMapValues = geometry.getMapValues(sMaskMap) #if isinstance(sMaskMap, (str, unicode)):
            aMapValues = geometry.getMapValues(sMaskMap)
            cmds.setAttr('%s.inputTarget[0].baseWeights[0:%d]' % (sMaskBlendShape, iSize-1), *list(aMapValues))
            sTargets[t] = sDuplT
            if bStopBeforeMask:
                cmds.select(sT, sDuplT)
                raise Exception('exception on purpose: stop before masking meshes (meshes are selected)')

        _activatePose(0.0)


    if not sLeftRights[1] and not sMultDriversLeftRights[1]:
        bMirror = False

    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetMirrors, sTarget)
    dConnectTargetMirrors[sTarget].append(True if len(sLeftRights[0]) or len(sMultDriversLeftRights[0]) else False)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)

    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitBotTops, sTarget)
    dConnectTargetSplitBotTops[sTarget].append(bSplitBotTop)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)

    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetInverts, sTarget)
    dConnectTargetInverts[sTarget].append(iInvert)
    utils.data.store('dConnectTargetInverts', dConnectTargetInverts)

    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitRadien, sTarget)
    dConnectTargetSplitRadien[sTarget].append(fSplitRadius)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)

    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitAlongCurves, sTarget)
    dConnectTargetSplitAlongCurves[sTarget].append(dSplitAlongCurve)
    utils.data.store('dConnectTargetSplitAlongCurves', dConnectTargetSplitAlongCurves)

    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetZippers, sTarget)
    dConnectTargetZippers[sTarget].append(dZipper)
    utils.data.store('dConnectTargetZippers', dConnectTargetZippers)


    if bSplitBotTop:
        global dBottomWeights
        for sM in [sModel] + sSecondaryModels:
            if sM not in dBottomWeights:
                dBottomWeights[sM] = getMouthBottomWeights(sM)



    if dSplitAlongCurve:
        global dSplitAlongCurveWeights
        aaaSplitWeights = []
        for sM in [sModel] + sSecondaryModels:
            sKey = '%s_%s_%s' % (sM,
                                 dSplitAlongCurve['sCurve'],
                                 '_'.join('%0.3f' % fV for fV in dSplitAlongCurve['fParams']))
            if sKey not in dSplitAlongCurveWeights:
                aaWeights = geometry.generateMeshToCurveParamWeights(sM, dSplitAlongCurve['sCurve'], dSplitAlongCurve['fParams'])
                dSplitAlongCurveWeights[sKey] = aaWeights
            else:
                aaWeights = dSplitAlongCurveWeights[sKey]
            aaaSplitWeights.append(aaWeights)
        iParamsCount = len(dSplitAlongCurve['fParams'])
    else:
        iParamsCount = 1


    if dZipper:
        global dZipperWeights
        aaaZipperSplitWeights = []
        iZipperParamsCount = dZipper['iSampleCount']
        fParams = np.arange(iZipperParamsCount+2)[1:-1] / float(iZipperParamsCount-1)
        for sM in [sModel] + sSecondaryModels:
            sKey = '%s_%s_%d' % (sM, dZipper['sCurve'], iZipperParamsCount)
            if sKey not in dZipperWeights:
                aaWeights = geometry.generateMeshToCurveParamWeights(sM, dZipper['sCurve'], fParams)
                dZipperWeights[sKey] = aaWeights
            else:
                aaWeights = dZipperWeights[sKey]
            aaaZipperSplitWeights.append(aaWeights)
        sZipperOutputs = createOrGetZipperSetup(dZipper)
    else:
        iZipperParamsCount = 1
        sZipperOutputs = []

    sssMainDrivers = [[[[None, None], [None, None]] for _ in range(iParamsCount)] for _ in range(iZipperParamsCount)]

    for zz in range(iZipperParamsCount):
        for pp in range(iParamsCount):
            for s, sSide in enumerate(['l', 'r']):
                sFactorsBot = [sZipperOutputs[zz]] if sZipperOutputs else []
                sFactorsTop = [sZipperOutputs[zz]] if sZipperOutputs else []
                print('sFactorsBot-1: ', sFactorsBot)

                print('sLeftRights[s]: ', sLeftRights[s])
                print('sMiddles: ',  sMiddles)
                print('dDrivers4: ', dDrivers)
                for sAttr in sLeftRights[s] + sMiddles:
                    if bSplitBotTop and 'Bot' in sAttr :
                        sFactorsBot.append(dDrivers[sAttr])
                        print('add0: ', dDrivers[sAttr])
                    elif bSplitBotTop and 'Top' in sAttr:
                        sFactorsTop.append(dDrivers[sAttr])
                    else:
                        sFactorsBot.append(dDrivers[sAttr])
                        print('add1: ',dDrivers[sAttr])
                        if bSplitBotTop:
                            sFactorsTop.append(dDrivers[sAttr])
                print('sFactorsBot0: ', sFactorsBot)

                if dSplitAlongCurve:
                    sFactorsBot.append(_rangeOrDrivenKeys(dSplitAlongCurve['sAttrs'][pp], dSplitAlongCurve['fValues'][pp], fOvershootRange))

                print('sFactorsBot: ', sFactorsBot)
                sssMainDrivers[zz][pp][s][0] = _combineValues(iCombineMode, sFactorsBot)

                print('sssMainDrivers[zz][pp][s][0]: ', sssMainDrivers[zz][pp][s][0])
                if bSplitBotTop:
                    if dSplitAlongCurve:
                        sFactorsTop.append(_rangeOrDrivenKeys(dSplitAlongCurve['sAttrs'][pp], dSplitAlongCurve['fValues'][pp], fOvershootRange))
                    sssMainDrivers[zz][pp][s][1] = _combineValues(iCombineMode, sFactorsTop)


    for tt, sTT in enumerate(sTargets): # main target + inbetweens
        sModels = [sModel] + sSecondaryModels

        for m,sM in enumerate(sModels):
            sT = sTT if m == 0 else '%s__%s' % (sM, sTT)
            if not cmds.objExists(sT):
                continue

            if iZipperParamsCount == 1:
                sZipperTs = [sT]
            else:
                sZipperTs = geometry.splitShapeFromWeightsPerTarget(sT, sM, aaaZipperSplitWeights[m])

            ssParamSplitTs = [[] for _ in range(iZipperParamsCount)]
            for zz, sZipperT in enumerate(sZipperTs):
                if iParamsCount == 1:
                    ssParamSplitTs[zz] = [sZipperT]
                else:
                    sSplits = geometry.splitShapeFromWeightsPerTarget(sZipperT, sM, aaaSplitWeights[m])
                    for pp, sSplit in enumerate(sSplits):
                        ssParamSplitTs[zz].append(sSplits[pp])


            if m == 0:
                ssFirstParamSplitTs = list(ssParamSplitTs)

            for zz in range(iZipperParamsCount):
                sAliasZipper = sAlias if iZipperParamsCount else ('%s_%02d' % (sAlias, zz))

                for pp in range(iParamsCount):
                    if sAlias:
                        sAliasCurve = sAliasZipper if iParamsCount == 1 else ('%s_%02d' % (sAliasZipper, pp))

                    if bSplitBotTop:
                        sBotShape, sTopShape = geometry.splitShape(ssParamSplitTs[zz][pp], sM, aLeftWeights=dBottomWeights[sM], sLeftName='bot_%s' % ssParamSplitTs[zz][pp], sRightName='top_%s' % ssParamSplitTs[zz][pp], xMirrorAxis=xMirrorAxis)
                        sAliasAttrsBotTop = ['bot_%s' % sAliasCurve, 'top_%s' % sAliasCurve] if sAlias else ['bot_%s' % ssFirstParamSplitTs[zz][pp], 'top_%s' % ssFirstParamSplitTs[zz][pp]]
                    else:
                        sBotShape = ssParamSplitTs[zz][pp]
                        sAliasAttrsBotTop =  [sAliasCurve] if sAlias else [ssFirstParamSplitTs[zz][pp]]
                    if bMirror:
                        sShapesToAdd = geometry.splitShape(sBotShape, sM, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis)
                        sAliasAttrs = ['l_%s' % sAliasAttrsBotTop[0], 'r_%s' % sAliasAttrsBotTop[0]]
                    else:
                        sShapesToAdd = [sBotShape]
                        sAliasAttrs = [sAliasAttrsBotTop[0]]

                    ssTargetAttrsBot = [deformers.addBlendShapeTargets(sM, sShapesToAdd, sAliasAttrs=sAliasAttrs)]

                    if bSplitBotTop:
                        if bMirror:
                            sShapesToAdd = geometry.splitShape(sTopShape, sM, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis)
                            sAliasAttrs = ['l_%s' % sAliasAttrsBotTop[1], 'r_%s' % sAliasAttrsBotTop[1]]
                        else:
                            sShapesToAdd = [sTopShape]
                            sAliasAttrs = [sAliasAttrsBotTop[1]]
                        ssTargetAttrsTop = [deformers.addBlendShapeTargets(sM, sShapesToAdd, sAliasAttrs=sAliasAttrs)]
                    else:
                        ssTargetAttrsTop = []

                    if m == 0:
                        sReturnTargetAttrs += ssTargetAttrsBot + ssTargetAttrsTop

                    for s, sSide in enumerate(['l', 'r'] if bMirror else ['m`']):
                        if len(sTargets) == 1: # no inbetweens
                            [cmds.connectAttr(sssMainDrivers[zz][pp][s][0], sTargetAttrsBot[s]) for sTargetAttrsBot in ssTargetAttrsBot if sTargetAttrsBot[s]]
                            if bSplitBotTop:
                                [cmds.connectAttr(sssMainDrivers[zz][pp][s][1], sTargetAttrsTop[s]) for sTargetAttrsTop in ssTargetAttrsTop if sTargetAttrsTop[s]]
                        else: # there are inbetweens
                            if tt == len(sTargets) - 1:  # the full one
                                [nodes.createRangeNode(sssMainDrivers[zz][pp][s][0], aPercs[tt - 1], 1, 0, 1, sTarget=sTargetAttrsBot[s]) for sTargetAttrsBot in ssTargetAttrsBot if sTargetAttrsBot[s]]
                                if bSplitBotTop:
                                    [nodes.createRangeNode(sssMainDrivers[zz][pp][s][1], aPercs[tt - 1], 1, 0, 1, sTarget=sTargetAttrsTop[s]) for sTargetAttrsTop in ssTargetAttrsTop if sTargetAttrsTop[s]]
                            else:
                                [nodes.setDrivenKey(sssMainDrivers[zz][pp][s][0], [aPercs[tt - 1] if tt > 0 else 0.0, aPercs[tt], aPercs[tt + 1]], sTargetAttrsBot[s], [0, 1, 0],
                                                 sInTanType='linear', sOutTanType='linear') for sTargetAttrsBot in ssTargetAttrsBot if sTargetAttrsBot[s]]
                                if bSplitBotTop:
                                    [nodes.setDrivenKey(sssMainDrivers[zz][pp][s][1], [aPercs[tt - 1] if tt > 0 else 0.0, aPercs[tt], aPercs[tt + 1]], sTargetAttrsTop[s], [0, 1, 0],
                                                sInTanType='linear', sOutTanType='linear') for sTargetAttrsTop in ssTargetAttrsTop if sTargetAttrsTop[s]]


    for sCtrlAttr in list(dPoses.keys()) + dSplitAlongCurve.get('sAttrs', []):
        sCtrl = sCtrlAttr.split('.')[0]
        addIgnoreAttachTargets(sCtrl, utils.flattenedList(sReturnTargetAttrs))

    if bAppleBlendShapes:
        return sUnrealCommands
    else:
        return sReturnTargetAttrs


def autoConnectComboTarget(sComboT, sModel, sSecondaryModels, xMirrorAxis=None):
    print('\n\n\n\n\n\n\n\n\n\n 0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000', sComboT)

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={})  # should be defaultDict(list), but that can't be stored
    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={})  # should be defaultDict(list), but that can't be stored
    dConnectTargetsDriverGetAttrs = utils.data.get('dConnectTargetDriverGetAttrs', xDefault={})  # should be defaultDict(list), but that can't be stored
    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={})
    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={})
    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={})
    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={})
    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={})
    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={})

    dComboMainTargets = kangarooShapeEditorTools.getPercsFromComboName(sComboT)

    sMainTargets = list(dComboMainTargets.keys())
    iCombinationCount = 1
    for t, sMainT in enumerate(sMainTargets):
        if sMainT in ['eyelookLeft', 'eyelookRight']:
            return False, ('WARNING: skipping combo "%s", because %s is not supported for combos at this time' % (sComboT, sMainT))
        if sMainT not in dConnectTargetPoses:
            return False, ('WARNING: skipping combo "%s", because %s is not found' % (sComboT, sMainT))
        iCombinationCount *= len(dConnectTargetPoses[sMainT])


    for i in range(iCombinationCount):

        dPoses = {}
        dDrivers = {}
        sDriversGetAttr = []
        bMirror = False
        bSplitBotTop = False
        iInvert = 1
        fSplitRadiusSum = 0
        dSplitAlongCurve = {}
        dZipper = {}
        for t, sMainT in enumerate(sMainTargets):

            iIndex = i
            for k in range(t + 1, len(sMainTargets), 1):
                iIndex //= len(dConnectTargetPoses[sMainTargets[k]])
            iIndex %= len(dConnectTargetPoses[sMainTargets[t]])

            dMainPose = dict(dConnectTargetPoses[sMainT][iIndex])
            iPerc = dComboMainTargets[sMainT]
            if iPerc != 100:
                fPerc = iPerc * 0.01
                for sAttr, xValue in list(dMainPose.items()):
                    if isinstance(xValue, (int, float)):
                        dMainPose[sAttr] = xValue * fPerc
                    elif isinstance(xValue, (tuple, list)):
                        if len(xValue) == 2:
                            dMainPose[sAttr] = [xValue[0], xValue[1] * fPerc]
                        elif len(xValue) == 3:
                            dMainPose[sAttr] = [xValue[0] * fPerc, xValue[1] * fPerc, xValue[2] * fPerc]
                        else:
                            raise Exception('Don\'t know what to do with a pose with value of length %d (%s)' % (
                            len(xValue), xValue))
            dPoses.update(dMainPose)

            print('dConnectTargetPoses: ', list(dConnectTargetPoses.keys()))
            print('dConnectTargetsDriverGetAttrs: ', list(dConnectTargetsDriverGetAttrs.keys()))

            dDrivers.update(dConnectTargetDrivers[sMainT][iIndex])  # to do: consider percentages!!
            sDriversGetAttr += dConnectTargetsDriverGetAttrs[sMainT][iIndex]
            bMirror = True if dConnectTargetMirrors[sMainT][iIndex] else bMirror
            bSplitBotTop = True if dConnectTargetSplitBotTops[sMainT][iIndex] else bSplitBotTop
            iInvert = max(iInvert, dConnectTargetInverts[sMainT][iIndex])
            dZipper.update(dConnectTargetZippers[sMainT][iIndex])
            fSplitRadiusSum += dConnectTargetSplitRadien[sMainT][iIndex]
            dSplitAlongCurve.update(dConnectTargetSplitAlongCurves[sMainT][iIndex])

        bIncludesMouthClose = False
        for sT in list(dComboMainTargets.keys()):
            if sT.startswith('mouthClose'):
                bIncludesMouthClose = True
                break

        connectTargets2(sModel, sComboT,
                         dPoses=dPoses,
                         dDrivers=dDrivers,
                         sDriversGetAttr=sDriversGetAttr,
                         bMirror=bMirror,
                         fSplitRadius=np.average(fSplitRadiusSum),
                         bSplitBotTop=bSplitBotTop,
                         dSplitAlongCurve=dSplitAlongCurve,
                         dZipper=dZipper,
                         iInvert=iInvert,
                         sSecondaryModels=sSecondaryModels, xMirrorAxis=xMirrorAxis,
                         iCombineMode=CombineMode.product if bIncludesMouthClose else CombineMode.minimum)


    return True, ('%s assigned %d times' % (sComboT, iCombinationCount))


def createOrGetZipperSetup(dZipper):

    global sZipperOutAttrs
    if not sZipperOutAttrs:
        iSampleCount = dZipper['iSampleCount']
        sCornerCtrls = ['lipsCornerLFT_ctrl', 'lipsCornerRGT_ctrl']
        sSealLeft = utils.addAttr(sCornerCtrls[0], ln='sealB', at='double',  defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sSealRight = utils.addAttr(sCornerCtrls[1], ln='sealB', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sSealFadeLengthLeft = utils.addAttr(sCornerCtrls[0], ln='sealFadeB', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
        sSealFadeLengthRight = utils.addAttr(sCornerCtrls[1], ln='sealFadeB', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
        sSealLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealLeft, sSealFadeLengthLeft), sName='left_sealByFade')
        sSealRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealRight, sSealFadeLengthRight), sName='right_sealByFade')

        aSides, aInds = utils.convertMiddleSequenceToSides(iSampleCount)

        fLeftPercs = utils.bSpline4([0,0,1,1], aValues=np.arange(iSampleCount) / float(iSampleCount-1))
        fRightPercs = 1.0 - fLeftPercs

        for j in range(iSampleCount):
            sLeftRightSeals = cmds.createNode('plusMinusAverage', n='plus_%s_sumSeals_%03d' % (aSides[j], aInds[j]))

            sEndLeft = nodes.fromEquation('%f + %s' % (fLeftPercs[j], sSealFadeLengthLeft),
                                          sName='%s_left_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeLeft = nodes.createRangeNode(sSealLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0,
                                               sName='%s_left_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sEndRight = nodes.fromEquation('%f + %s' % (fRightPercs[j], sSealFadeLengthRight), sName='%s_right_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeRight = nodes.createRangeNode(sSealRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='%s_right_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sClamped = nodes.createClampNode('%s.output1D' % sLeftRightSeals, 0, 1)
            sZipperOutAttrs.append(sClamped)

    return sZipperOutAttrs


def _rangeOrDrivenKeys(sAttr, xRelation, fOvershootRange=None):
    if '.' not in sAttr:
        raise Exception('%s is not an attribute' % sAttr)
    if isinstance(xRelation, type(None)):
        return sAttr
    elif isinstance(xRelation, (list, tuple)):
        if len(xRelation) == 2:
            if isinstance(xRelation[0], (list, tuple)):  # [(-1,0,1),(0,1,0)]
                return nodes.setDrivenKey(sAttr, list(xRelation[0]), None, list(xRelation[1]), sInTanType='linear', sOutTanType='linear')
            else:  # [1,0]
                return nodes.createRangeNode(sAttr, xRelation[0], xRelation[1], 0, 1, sName=sAttr.replace('.', '_'), fOvershoot=fOvershootRange)
        elif len(xRelation) == 3:
            return nodes.setDrivenKey(sAttr, list(xRelation), None, [0.0, 1.0, 0.0], sInTanType='linear', sOutTanType='linear')
        else:
            raise Exception('not supported yet: %s ' % xRelation)
    elif isinstance(xRelation, (float, int)):
        return nodes.createRangeNode(sAttr, 0, xRelation, 0, 1, sName=sAttr.replace('.', '_'), fOvershoot=fOvershootRange)
    else:
        raise Exception('not sure what %s is - returning None from _rangeOrDrivenKeys' % sAttr)


# to do: change sFroms to sMeshes to be consistent with other functions
def warp(sModels, sTargetsModel, sTargets, bRigidIslands=False, fMinimumChange=0.0001):
    sSel = cmds.ls(sl=True, et='transform')


    sReturn = []

    for sM in sModels:

        for sT in sTargets:
            sNewMeshName = '%s__%s' % (sM,sT)

            if cmds.objExists(sNewMeshName):
                cmds.warning('%s already exists' % sNewMeshName)
                sReturn.append(sNewMeshName)
                continue

            sNewMesh = utils._duplicateGeoClean(sM, sName=sNewMeshName)
            try: cmds.parent(sNewMesh, w=True)
            except: pass

            if not bRigidIslands:
                sModelTemp = utils._duplicateGeoClean(sTargetsModel, bSetToOrigMesh=False)
                sWrap, sBase = deformers.createWrap(sNewMesh, sModelTemp)
                cmds.blendShape(sT, sModelTemp, w=[0,1], topologyCheck=False)
                cmds.delete(sNewMesh, ch=True)
                cmds.delete(sBase)
                cmds.delete(sModelTemp)
            else:
                geometry.warpRigidIslands(sNewMesh, sTargetsModel, sT)

            # if sT == 'browLower':
            #     cmds.select(sModelTemp)
            #     iii

            aPointsA = patch.patchFromName(sNewMesh).getPoints()
            aPointsB = patch.patchFromName(sM).getPoints()
            aDiffs = np.linalg.norm(aPointsB-aPointsA, axis=-1)
            fMaxDiff = np.max(aDiffs)
            if fMaxDiff < fMinimumChange:
                cmds.warning('not warping %s with %s, because it didn\'t have any changes' % (sT, sTargetsModel))
                cmds.delete(sNewMesh)
                continue

            sReturn.append(sNewMesh)

    return sReturn





def createSculptAnimationSelected(sInterpolators=None):
    if utils.isNone(sInterpolators):
        sInterpolators = [sO for sO in cmds.ls(sl=True, et='transform') if cmds.objExists('%s.xPoses' % sO)]

    iStartTime = cmds.currentTime()
    for sI in sInterpolators:
        dPoses = getPosesDictFromInterp(sI)
        sCtrl = cmds.getAttr('%s.sCtrl' % sI)
        for p, fEuler in enumerate([[0,0,0]] + list(dPoses.values()) + [[0,0,0]]):
            iTime = 1 if p == 0 else p*10
            for a, sA in enumerate(['rx','ry','rz']):
                try: cmds.setKeyframe('%s.%s' % (sCtrl, sA), v=fEuler[a], t=iTime)
                except: pass

    fMinTime = cmds.playbackOptions(q=True, minTime=True)
    fMaxTime = cmds.playbackOptions(q=True, maxTime=True)
    cmds.playbackOptions(e=True, minTime=min(fMinTime, 1), maxTime=max(fMaxTime, iTime))
dControls = {}


# @uiSettings.addToUI(sRunButton='Rename Target', sTab='Geometry', sModuleButton='Rename', bReloadBeforeRun=True,
#                   dControls=dControls, tRefreshControlsAfterRun=[])
def renameTargetMesh(sModel='model', sKey='key', bInverted=False, _report=None):
    sMeshName = makeMeshName(sModel, sKey, 100, sType='inverted' if bInverted else 'posed')
    if _report:_report.addLogText('rename to %s' % sMeshName)
    sSel = cmds.ls(sl=True, et='transform')
    cmds.rename(sSel[0], sMeshName)



def createRomAnimation(sInterpolators):

    iNextFrame = 0

    for sInterp in sInterpolators:

        sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
        sMirrorCtrl = utils.getMirrorName(sCtrl)

        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))

        for _sCtrl in [sCtrl, sMirrorCtrl]:
            cmds.setKeyframe('%s.rx' % _sCtrl, t=iNextFrame, v=0)
            cmds.setKeyframe('%s.ry' % _sCtrl, t=iNextFrame, v=0)
            cmds.setKeyframe('%s.rz' % _sCtrl, t=iNextFrame, v=0)
        iNextFrame += 10

        for sA, fX,fY,fZ in xPoses:
            if 'default' in sA or '_' in sA:
                continue
            for _sCtrl in [sCtrl, sMirrorCtrl]:
                cmds.setKeyframe('%s.rx' % _sCtrl, t=iNextFrame, v=fX)
                cmds.setKeyframe('%s.ry' % _sCtrl, t=iNextFrame, v=fY)
                cmds.setKeyframe('%s.rz' % _sCtrl, t=iNextFrame, v=fZ)
            iNextFrame += 10

        for _sCtrl in [sCtrl, sMirrorCtrl]:
            for _sCtrl in [sCtrl, sMirrorCtrl]:
                cmds.setKeyframe('%s.rx' % _sCtrl, t=iNextFrame, v=0)
                cmds.setKeyframe('%s.ry' % _sCtrl, t=iNextFrame, v=0)
                cmds.setKeyframe('%s.rz' % _sCtrl, t=iNextFrame, v=0)
        # iNextFrame += 10

    cmds.playbackOptions(e=True, minTime=0.0, maxTime=iNextFrame)




