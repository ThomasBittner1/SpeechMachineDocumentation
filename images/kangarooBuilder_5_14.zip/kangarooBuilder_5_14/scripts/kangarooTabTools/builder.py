###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np
import os
import importlib
import json
import inspect
import traceback
import sys
import time
import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
from collections import OrderedDict, defaultdict
import kangarooTools.utilsQt as utilsQt
import kangarooTools.jsonEditor as jsonEditor
import time
import shutil

import kangarooTools.uiSettings as uiSettings
import kangarooTools.controls as controls
import kangarooTools.assets as assets
import kangarooTools.report as report
import kangarooTools.clipboard as clipboard
import webbrowser

qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)
qBoldFont = QtGui.QFont()
qBoldFont.setBold(True)

_kRowHeight = utilsQt.getDpi() // 5

dJustOneKeysFunctions = defaultdict(list)
dJustOneKeysItems = defaultdict(list)

def addToBuild(iOrder=0, dButtons={}, xListButtons=[], bNoCheckbox=False, bDisableByDefault=False, sJustOneKey=None, sOverwriteColor=None, bCanGetDuplicated=False, sDocumentationLink=None):
    def addToUI_inside(func):
        def _builderFunction_(*args, **kwargs):
            return func(*args, **kwargs)

        def setOrderREC(dDict):
            if isinstance(dDict, OrderedDict):
                dDict['__order__'] = list(dDict.keys())
            if isinstance(dDict, dict):
                for sKey, xValue in dDict.items():
                    dDict[sKey] = setOrderREC(xValue)
            return dDict
        dButtonsOrdered = setOrderREC(dButtons)

        _builderFunction_.addToBuilder = None
        _builderFunction_.iOrder = iOrder
        _builderFunction_.dButtons = dButtonsOrdered
        _builderFunction_.xListButtons = xListButtons
        _builderFunction_.sDoc = func.__doc__
        _builderFunction_.bNoCheckbox = bNoCheckbox
        _builderFunction_.bDisableByDefault = bDisableByDefault
        _builderFunction_.sJustOneKey = sJustOneKey
        _builderFunction_.sOverwriteColor = sOverwriteColor
        _builderFunction_.bCanGetDuplicated = bCanGetDuplicated
        _builderFunction_.sDocumentationLink = sDocumentationLink
        args, _, _, defaults = inspect.getfullargspec(func)[0:4]
        if not args or not defaults:
            _builderFunction_.dDefaultArgs = OrderedDict()
            _builderFunction_.sArgsSorted = []
            _builderFunction_._args = []
        else:
            _builderFunction_.dDefaultArgs = {a:d for a,d in zip(args,defaults) if not a.startswith('_')}
            _builderFunction_.sArgsSorted = [a for a in args if not a.startswith('_')]
            _builderFunction_._args = [a for a in args if a.startswith('_')]

        return _builderFunction_
    
    return addToUI_inside


class QArgumentsTable(QtWidgets.QTableWidget):
    copy = QtCore.Signal()
    paste = QtCore.Signal()

    def keyPressEvent(self, event):
        super().keyPressEvent(event)
        if event.key() == QtCore.Qt.Key_C and (event.modifiers() & QtCore.Qt.ControlModifier):
            self.copy.emit()

        elif event.key() == QtCore.Qt.Key_V and (event.modifiers() & QtCore.Qt.ControlModifier):
            self.paste.emit()




class TArgList(controls.Control):
    def __init__(self):
        controls.Control.__init__(self)
        self.qtFuncTree = None
    
        self._fontIsDefault = QtGui.QFont()
        self._fontIsDefault.setItalic(True)
        self._fontIsChanged = QtGui.QFont()
        self._fontIsChanged.setBold(True)
        self.bDisableOnServer = True


    def serverSwitch(self, bServer):
        self.qtArgTable.setEnabled(not bServer)
        # self.qRefreshButton.setEnabled(not bServer)


    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        controls.Control.build(self, qParentLayout, sName, xValue)
        self.qtLayout = QtWidgets.QVBoxLayout()
        self.qtLayout.setSpacing(0)
        self.uniqueLayout.addLayout(self.qtLayout)
        self.qShowButton = QtWidgets.QPushButton('show args')
        self.qShowButton.setToolTip('Each function has arguments. This button can toggle them on/off')
        self.qShowButton.setCheckable(True)
        self.qShowButton.clicked.connect(self.showButtonPushed)
        self.qShowButton.setMaximumHeight(utilsQt.getDpi() // 4)
        self.qShowButton.setMinimumHeight(utilsQt.getDpi() // 4)
        self.qShowButton.setChecked(False)

        self.qFilterCheckedButton = QtWidgets.QPushButton('isolate checked')
        self.qFilterCheckedButton.setToolTip('Each function has arguments. This button can toggle them on/off')
        self.qFilterCheckedButton.setCheckable(True)
        self.qFilterCheckedButton.clicked.connect(self.filterCheckedClicked)
        self.qFilterCheckedButton.setMaximumHeight(utilsQt.getDpi() // 4)
        self.qFilterCheckedButton.setMinimumHeight(utilsQt.getDpi() // 4)
        self.qFilterCheckedButton.setChecked(False)

        self.qShowFilesButton = QtWidgets.QPushButton('hide file list')
        self.qShowFilesButton.setToolTip('Each function has arguments. This button can toggle them on/off')
        self.qShowFilesButton.setCheckable(True)
        self.qShowFilesButton.clicked.connect(self.toggleFileList)
        self.qShowFilesButton.setMaximumHeight(utilsQt.getDpi() // 4)
        self.qShowFilesButton.setMinimumHeight(utilsQt.getDpi() // 4)
        self.qShowFilesButton.setChecked(False)


        self.qtArgTable = QArgumentsTable() #QtWidgets.QTableWidget()
        self.qtArgTable.copy.connect(self.copy)
        self.qtArgTable.paste.connect(self.paste)
        self.qtArgTable.setRowCount(0)
        self.qtArgTable.setColumnCount(1)
        self.qtArgTable.setHorizontalHeaderLabels(('Arg', 'Value'))
        self.qtArgTable.horizontalHeader().setStretchLastSection(True)
        self.qtArgTable.horizontalHeader().hide()
        self.qtLayout.addWidget(self.qtArgTable)
        self.qtArgTable.itemChanged.connect(self.itemChanged)
        self.qtArgTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtArgTable.customContextMenuRequested.connect(self.markingMenu)
        # self.qtLayout.addWidget(self.qShowButton)


        self.qShowButtonLayout = QtWidgets.QHBoxLayout()
        self.qtLayout.addLayout(self.qShowButtonLayout)
        self.qShowButtonLayout.addWidget(self.qShowButton)
        self.qShowButtonLayout.addWidget(self.qFilterCheckedButton)
        self.qShowButtonLayout.addWidget(self.qShowFilesButton)

        self.showButtonPushed()

        self.qtArgTable.setMinimumHeight(2)
        self.qtArgTable.setMaximumHeight(2)

        iRowHeight = int(round((self.qtArgTable.verticalHeader().defaultSectionSize() * 0.62)))
        self.qtArgTable.verticalHeader().setMinimumSectionSize(iRowHeight)
        # self._report = qtWindow._report


    def filterCheckedClicked(self):
        self.qtFuncTree.setUncheckedFunctionsHidden(self.qFilterCheckedButton.isChecked())

    def toggleFileList(self):
        self.qtFuncTree.toggleFileList(self.qShowFilesButton.isChecked())

    def copy(self):
        sTexts = []
        for qIndex in sorted(self.qtArgTable.selectedIndexes()):
            iRow = qIndex.row()
            sTexts.append(self.qtArgTable.item(iRow, 0).text())
        clipboard.put('builderFields.%s' % str(sTexts))


    def paste(self):
        sPaste = clipboard.get()
        if sPaste.startswith('builderFields.'):
            sTextsString = sPaste[sPaste.find('.') + 1:]
            sTexts = eval(sTextsString)
            for i, qIndex in enumerate(sorted(self.qtArgTable.selectedIndexes())):
                iRow = qIndex.row()
                self.qtArgTable.item(iRow, 0).setText(sTexts[i % len(sTexts)])

    def showButtonPushed(self):
        self.qtArgTable.setHidden(not self.qShowButton.isChecked())



    def markingMenu(self, vPos):
        qMenu = QtWidgets.QMenu()
        qSelItems = self.qtArgTable.selectedItems()
        if qSelItems:
            qArg = qSelItems[0]

            iRow = qArg.row()
            sLabel = self.qtArgTable.verticalHeaderItem(iRow).text()

            _, xDefaultValue = qArg.data(QtCore.Qt.UserRole)
            if utils.evalValueFromString(qArg.text()) != xDefaultValue:
                qMenu.addAction('Reset', lambda:self.resetToDefault(qSelItems))
            qMenu.addAction('Set from Selection', lambda:self.setSelection(qArg))
            qMenu.addAction('Add Selection', lambda:self.addSelection(qArg))
            qMenu.addAction('Show in JSON Editor', lambda:self.showInUi(qArg, sLabel))
            qMenu.addAction('Select', lambda:self.select(qArg))
            qMenu.addAction('text replace LFT_ to l_', lambda: self.sideCtrlsReplace(qArg))
            qMenu.addAction('text replace _l_ to LFT_', lambda: self.sideCtrlsReplace(qArg, bToOld=True))

            qMenu.addSeparator()
            qMenu.addAction('copy \t\tCTRL+C', self.copy)
            qPaste = qMenu.addAction('paste \t\tCTRL+P', self.paste)

            sClipboard = clipboard.get()
            if not sClipboard or not sClipboard.startswith('builderFields.'):
                qPaste.setEnabled(False)

            qMenu.exec_(self.qtArgTable.viewport().mapToGlobal(vPos))
            return qMenu


    def select(self, qArg):
        sSelection = eval(qArg.text())
        sSelection = utils.stringOrListToObjects(sSelection)

        if not isinstance(sSelection, (list,tuple)):
            raise Exception('can\'t select %s' % sSelection)
        sExistings = []
        sMissings = []
        for sS in sSelection:
            if cmds.objExists(sS):
                sExistings.append(sS)
            else:
                sMissings.append(sS)

        cmds.select(sExistings)
        if sMissings:
            raise Exception('these are missing: %s (existing ones are selected)' % ','.join(sMissings))

    def setSelection(self, qArg):
        sSel = cmds.ls(sl=True)
        sStr = '[%s]' % ', '.join(["'%s'" % sS for sS in sSel])
        qArg.setText(sStr)

    def addSelection(self, qArg):
        sSel = cmds.ls(sl=True)
        sCurrent = eval(qArg.text())
        sNewList = sSel + sCurrent

        sStr = '[%s]' % ', '.join(["'%s'" % sS for sS in sNewList])
        qArg.setText(sStr)


    def sideCtrlsReplace(self, qArg, bToOld=False):
        sCurrent = qArg.text()
        if bToOld:
            sNewText = sCurrent.replace('_l_', 'LFT_').replace('_r_', 'RGT_')
        else:
            sNewText = sCurrent.replace('LFT_', '_l_').replace('RGT_', '_r_')
        qArg.setText(sNewText)


    def showInUi(self, qArg, sTitle):
        utils.reload2(jsonEditor)
        sText = qArg.text()

        def _updateText(dOutput, _qArg=qArg):
            _qArg.setText(str(dOutput))
        self._tempUi = jsonEditor.QJsonUi(sText, _updateText, sTitle=sTitle)
        self._tempUi.exec_() # used to be show()



    def resetToDefault(self, qArgs):
        for qArg in qArgs:
            sArg, xDefaultValue = qArg.data(QtCore.Qt.UserRole)
            qArg.setText(str(xDefaultValue))


    def getValue(self):
        return None


    def itemChanged(self, qItem):
        sArg, xDefaultValue = qItem.data(QtCore.Qt.UserRole)
        
        sValue = qItem.text()
        xValue = utils.evalValueFromString(sValue)

        if xDefaultValue == utils.evalValueFromString(sValue):
            self.qtFuncTree.removeFileArgument(self.qCurrentFunc, sArg)
        else:
            self.qtFuncTree.updateFileArgument(self.qCurrentFunc, sArg, xValue)
        
        self.updateFont(qItem)
    
    
    def clear(self):
        self.qtArgTable.blockSignals(True)
        self.qtArgTable.setRowCount(0)
        self.qtArgTable.setMinimumHeight(4)
        self.qtArgTable.setMaximumHeight(4)
        self.qtArgTable.blockSignals(False)
    
    
    def setArgs(self, qFunc, dDefaultArgs, sArgsSorted, dFileArgs):
        '''
        This is called from TBuildList, whenever something gets selected there
        It clears everything and sets new arguments
        '''
        
        qArgFont = QtGui.QFont()
        qArgFont.setBold(True)

        self.qCurrentFunc = qFunc

        self.qtArgTable.blockSignals(True)
        try:
            self.qtArgTable.clear()
            # sArgs = sArgsSorted #dDefaultArgs.keys()
            iRowCount = len(sArgsSorted)
            self.qtArgTable.setRowCount(iRowCount)

            iHeight = _kRowHeight * iRowCount + 4
            self.qtArgTable.setMinimumHeight(iHeight)
            self.qtArgTable.setMaximumHeight(iHeight)

            self.qtArgTable.setVerticalHeaderLabels(['  %s  ' % sA for sA in sArgsSorted])

            self.dPassArgTable = {}
            for a, sArg in enumerate(sArgsSorted):
                xDefaultValue = dDefaultArgs[sArg]
                xValue = dFileArgs.get(sArg, xDefaultValue)

                qArg = QtWidgets.QTableWidgetItem(str(xValue))
                qArg.setData(QtCore.Qt.UserRole, [sArg, xDefaultValue])
                self.qtArgTable.setRowHeight(a, _kRowHeight)

                self.updateFont(qArg)
                self.qtArgTable.setItem(a,0, qArg)

                self.dPassArgTable[sArg] = qArg

            self.qShowButton.setEnabled(iRowCount > 0)

        except:
            raise
        finally:
            self.qtArgTable.blockSignals(False)


    def updateFont(self, qItem):
        sArg, xDefaultValue = qItem.data(QtCore.Qt.UserRole)
        xValue = utils.evalValueFromString(qItem.text())
        if xValue == xDefaultValue:
            qItem.setFont(self._fontIsDefault)
        else:
            qItem.setFont(self._fontIsChanged)



class TButtonList(controls.Control):
    def __init__(self):
        controls.Control.__init__(self)
        self.qtFuncTree = None


    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        controls.Control.build(self, qParentLayout, sName, xValue)
        self.qtButtonLayouts = QtWidgets.QVBoxLayout()
        self.qtButtonLayouts.setSpacing(0)

        self.uniqueLayout.addLayout(self.qtButtonLayouts)

        self.qInfoBox = QtWidgets.QTextBrowser()
        self.qInfoBox.setOpenLinks(False)
        self.qInfoBox.setReadOnly(True)
        self.qInfoBox.anchorClicked.connect(self.handle_links)

        self.uniqueLayout.addWidget(self.qInfoBox)

        self.qDeleteLater = []


    def handle_links(self, qLink):
        sLink = qLink.toString()
        print ('sLink')
        webbrowser.open(sLink)



    def getValue(self):
        return None


    def clear(self):
        for qB in self.qDeleteLater:
            qB.deleteLater()


    def setDoc(self, sDoc, sDocumentationLink):
        self.qInfoBox.clear()
        self.qInfoBox.setCurrentCharFormat(QtGui.QTextCharFormat())
        if sDoc:
            self.qInfoBox.append(sDoc.replace('    ',''))

        if sDocumentationLink:
            # self.qInfoBox.moveCursor(self.qInfoBox.textCursor().End) # this was only working in pyside2
            self.qInfoBox.moveCursor(QtGui.QTextCursor.End) # this seems to be working in both

            self.qInfoBox.insertHtml('<br><br><i><a href="%s">Go to Documentation..</a></i>' % sDocumentationLink)


    def setButtons(self, dButtons, sButtonOrder, funcBuilder, iIndex, _report, _uiArgs, _buildList, qFunc, sListKeys=[]):
        '''
        This is called from TBuildList, whenever something gets selected there
        It clears everything and sets new arguments
        '''
        self.clear()
        self.qDeleteLater = []



        def _getCallbackFunction(fButtonFunc, _sListKey=None, sButton='buttonWithNoName'):
            def buttonCallBack(_fButtonFunc=fButtonFunc, _iUselessInt=22, sButton=sButton): # if I don't have iUselessInt, in python 3 value of _fButtonFunc becomes False

                _xValue = self.qtFuncTree.getValue()
                dAllArgs = dict(funcBuilder.dDefaultArgs)
                dBuilderDatas = _xValue['dFuncBuildFileDatas'].get(funcBuilder.sFuncName)
                dBuilderData = dBuilderDatas[iIndex]
                dBuilderArgs = dBuilderData.get('dFileArgs', {})

                dAllArgs.update(dBuilderArgs)
                dPassingArgs = {}

                sArgs, _, _, defaults = inspect.getfullargspec(_fButtonFunc)[0:4]
                if not defaults: defaults = []
                dDefaultArgs = {}
                iNonDefaultArgs = len(sArgs) - len(defaults)
                for d, default in enumerate(defaults):
                    dDefaultArgs[sArgs[iNonDefaultArgs+d]] = default

                sDefaultNoGoodArgs = [sA for sA in list(dDefaultArgs.keys()) if not sA.startswith('_')]
                if sDefaultNoGoodArgs:
                    raise Exception('There are arguments with default values in the button function! Remove those (%s)' % (', '.join(sDefaultNoGoodArgs)))
                sArgs = sArgs[:iNonDefaultArgs]
                if '_report' in dDefaultArgs:
                    dPassingArgs['_report'] = _report
                if '_uiArgs' in dDefaultArgs:
                    dPassingArgs['_uiArgs'] = _uiArgs
                if '_buildList' in dDefaultArgs:
                    dPassingArgs['_buildList'] = _buildList
                if '_sListKey' in sArgs and _sListKey != None:
                    dPassingArgs['_sListKey'] = _sListKey
                if '_funcSetAttr' in dDefaultArgs:
                    def funcSetAttr(sAttr, xValue, _uiArgs=_uiArgs):
                        sValue = str(xValue)
                        print ('funcSetAttr in builder..')
                        self.qtFuncTree.updateFileArgument(qFunc, sAttr, sValue)
                        _uiArgs[sAttr].setText(sValue)
                    dPassingArgs['_funcSetAttr'] = funcSetAttr

                for sA in sArgs:
                    if sA == '_sListKey':
                        continue
                    if sA in dAllArgs:
                        dPassingArgs[sA] = dAllArgs[sA]
                    else:
                        raise Exception('this attribute is in the button function but not in the main function: %s' % sA)

                sParamsText = ['%s=%s' % (sParam, sVal) for sParam, sVal in list(dPassingArgs.items())]
                _report.addLogText('Runing builder button...', bClearFirst=True)
                _report.addLogText('%s(%s)' % (sButton, ', '.join(sParamsText)), sWeight='bold',iSize=6)

                fTimeBefore = time.time()
                try:
                    cmds.undoInfo(openChunk=True)
                    bReturn = _fButtonFunc(**dPassingArgs)
                except Exception:
                    sError = traceback.format_exc()
                    sError = 'Builder Button Error: %s' % sError
                    _report.clearLogText()
                    _report.addLogText(sError, sColor=utils.uiColors.red, bQuotationsToLink=True)
                    _report.setProgressBarColor(utils.uiColors.red)
                    _report.setToFull()
                    raise Exception(traceback.format_exc())
                finally:
                    cmds.undoInfo(closeChunk=True)
                sTraceback = traceback.format_exc()

                fSeconds = time.time() - fTimeBefore
                _report.addLogText('Done! It took: %s (%s)' % (utils.secondsNice(fSeconds), time.ctime()), sColor=utils.uiColors.green)
                _report.addLogText(sTraceback)
                _report.setProgressBarColor(utils.uiColors.yellow if bReturn == False else utils.uiColors.green)
                _report.setToFull()

            return buttonCallBack

        xValue = self.qtFuncTree.getValue(bMessageBoxIfSyntaxError=False)
        for b,sButton in enumerate(sButtonOrder):
            if sButton == '__order__': # NEW
                continue
            _sListKey = sListKeys[b] if b < len(sListKeys) else None
            qButton = QtWidgets.QPushButton(sButton)
            self.qDeleteLater.append(qButton)
            qRowLayout = QtWidgets.QHBoxLayout()
            self.qtButtonLayouts.addLayout(qRowLayout)
            qRowLayout.addWidget(qButton)

            fFunction = dButtons[sButton]
            if callable(fFunction):
                buttonCallBack = _getCallbackFunction(dButtons[sButton], _sListKey=_sListKey, sButton=sButton)
                qButton.clicked.connect(buttonCallBack)
            else:
                qMenu = QtWidgets.QMenu()
                
                # print ('dFunctions: ', dButtons[sButton])



                def _addMenuREC(qMenu, dFunctions):
                    if isinstance(dFunctions, dict):
                        sKeys = dFunctions.get('__order__', list(dFunctions.keys()))
                        for sText in sKeys:
                            fFunc = dFunctions[sText]

                            if callable(fFunc):
                                def addAction(qMenu=qMenu, fFunc=fFunc):
                                    qMenu.addAction(sText, _getCallbackFunction(fFunc, _sListKey=_sListKey, sButton=sButton))
                                addAction()
                            else:
                                qSubMenu = qMenu.addMenu(sText)
                                _addMenuREC(qSubMenu, fFunc)
                _addMenuREC(qMenu, fFunction)
                
                # TO DO: make the marking menues use this, too
                def cleanFunctionsREC(xDictOrFunc):
                    if isinstance(xDictOrFunc, (OrderedDict, dict)):
                        dDict = OrderedDict()
                        for a,b in xDictOrFunc.items():
                            if not a.startswith('__'):
                                dDict[a] = cleanFunctionsREC(b)
                        xDictOrFunc = dDict
                    else:
                        xDictOrFunc = _getCallbackFunction(xDictOrFunc, _sListKey=_sListKey, sButton=sButton)
                    return xDictOrFunc
                dCleanedFunctions = cleanFunctionsREC(dButtons[sButton])

                
                def _createDetachedButtonMenu(_sTitle=sButton, dFunction=dCleanedFunctions):
                    createDetachedButtonMenu(_sTitle, dFunction)
                qMenu.addAction('<-->', _createDetachedButtonMenu)
                
                
                def _menuCallback(bDummyBool=False, qMenu=qMenu):
                    qCursor = QtGui.QCursor()
                    qMenu.exec_(qCursor.pos())

                qButton.clicked.connect(_menuCallback)

            if hasattr(dButtons[sButton], 'dSideButtons'):
                dSideButtons = dButtons[sButton].dSideButtons
                if dSideButtons:
                    sPythonKey = xValue['dFuncLocalPythonFiles'].get(funcBuilder, '')
                    sAbsoluteFile = os.path.join(utils.getScriptsDir(), sPythonKey)

                    for sName,fFunc in list(dSideButtons.items()):
                        qSideButton = QtWidgets.QPushButton(sName)
                        if callable(fFunc):
                            qSideButton.clicked.connect(_getCallbackFunction(fFunc, _sListKey=_sListKey, sButton=sButton))
                        else:
                            def helpCallback(_sButton=sButton, _xHelp=fFunc):
                                if isinstance(_xHelp, str) and _xHelp.startswith('https:'):
                                    webbrowser.open(_xHelp)
                                else:
                                    self.helpWindow = HelpUI(_sButton, _xHelp, os.path.dirname(sAbsoluteFile))
                                    self.helpWindow.show()
                            qSideButton.clicked.connect(helpCallback)

                        qSideButton.setMaximumWidth(100)
                        qRowLayout.addWidget(qSideButton)
                        self.qDeleteLater.append(qSideButton)
                        self.qDeleteLater.append(qRowLayout)



class QFuncTreeWidget(QtWidgets.QTreeWidget):

    def  __init__(self, parent=None):
        # super(QFuncTreeWidget, self).__init__(parent=parent)
        QtWidgets.QTreeWidget.__init__(self, parent=None)
        self.header().setMinimumSectionSize(10)

    leftMouseReleased = QtCore.Signal()

    def resizeEvent(self, event):
        fWidth = self.width() - 60
        fIconWidth = 20
        fPriorityWidth = 60
        self.setColumnWidth(0, fWidth - fIconWidth - fPriorityWidth)
        self.setColumnWidth(2, fPriorityWidth)
        self.setColumnWidth(1, fIconWidth)
        QtWidgets.QTreeWidget.resizeEvent(self, event)

    def mouseReleaseEvent(self,event):
        QtWidgets.QTreeWidget.mouseReleaseEvent(self, event)
        if event.button() == QtCore.Qt.LeftButton:
            self.leftMouseReleased.emit()




class QFileTableWidget(QtWidgets.QTableWidget):
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(QtCore.Qt.CopyAction)
            event.accept()
        else:
            event.ignore

    def dropEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(QtCore.Qt.CopyAction)
            event.accept()
            links = []
            for url in event.mimeData().urls():
                links.append(str(url.toLocalFile()))


            for sL in links:
                sL = sL.replace('/', os.sep)
                self.addPythonFileFunc(sL)
        else:
            event.ignore()


class HelpUI(QtWidgets.QDialog):

    def __init__(self, sTitle, xHelp, sPythonFolder):
        super(HelpUI, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.setWindowTitle(sTitle)
        for sRow in utils.toList(xHelp):
            qRowLayout = QtWidgets.QHBoxLayout()
            layout.addLayout(qRowLayout)
            sRow = utils.toList(sRow)
            for xH in sRow:
                sPath = os.path.join(sPythonFolder, '_help', xH)
                if os.path.exists(sPath):
                    qHelp = QtWidgets.QLabel()
                    qPixmap = QtGui.QPixmap(sPath)
                    qHelp.setPixmap(qPixmap)
                else:
                    qHelp = QtWidgets.QLabel(xH)
                    qHelp.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
                qRowLayout.addWidget(qHelp)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.close)
        layout.addWidget(qOkButton)



class QSearchLine(QtWidgets.QLineEdit):
    def keyPressEvent(self, event):
        if event.key() in [16777234, 16777235, 16777236, 16777237]: # arrow keys. space bar (32) used to be in there
            self.qFuncTree.keyPressEvent(event)
        else:
            super().keyPressEvent(event)

# this one doesnt' always work! it gives strange error that h e doesn't find certain things in TBuildList
qBuildList = None


class TBuildList(controls.FilePathControl):
    def __init__(self, tArgListControl=None, tButtonListControl=None):
        controls.FilePathControl.__init__(self, 'build files (*.bld)', bReadOnly=True, dBackupFolder={'sDirName':'_builderBackup', 'func':self.refreshFromBackup})
        self.bRefreshButton = True
        self.sDefaultFileName = 'build.bld'

        self.tArgListControl = tArgListControl
        tArgListControl.qtFuncTree = self
        self.tButtonListControl = tButtonListControl
        tButtonListControl.qtFuncTree = self
        self.dFuncLights = {}
        self.bDisableOnServer = True
        
        self.sPreviousFilter = ''
        global qBuildList
        qBuildList = self


    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        sFile, _ = xValue
        controls.FilePathControl.build(self, qParentLayout, sName, sFile, qtWindow=qtWindow)

        # self._report = qtWindow._report

        qtFileLayout = QtWidgets.QVBoxLayout()
        qtFileLayout.setSpacing(0)
        self.qtFileTable = QFileTableWidget()
        self.qtFileTable.verticalHeader().hide()
        self.qtFileTable.horizontalHeader().hide()
        self.qtFileTable.setColumnCount(1)
        self.qtFileTable.horizontalHeader().setStretchLastSection(True)
        qtFileLayout.addWidget(self.qtFileTable)
        self.qtFileTable.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.qtFileTable.setAcceptDrops(True)
        self.qtFileTable.addPythonFileFunc = self.addPythonFile
        self.qtVerticalLayout.addLayout(qtFileLayout)


        self.qSearchField = QSearchLine()
        self.qtVerticalLayout.addWidget(self.qSearchField)
        self.qSearchField.textChanged.connect(self.searchChanged)
        self.qSearchField.returnPressed.connect(self.searchReturn)
        self.iSearchEnterPressedCount = 0
        self.dFuncCounts = {}

        self.qtFuncTree = QFuncTreeWidget()
        self.qSearchField.qFuncTree = self.qtFuncTree
        self.qtFuncTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtFuncTree.customContextMenuRequested.connect(self.funcMarkingMenu)

        # self.qtFuncTree = QtWidgets.QTreeWidget()
        self.qtFuncTree.setHeaderHidden(True)
        self.setSelectionMode(True)
        # self.qtFuncTree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.qtFuncTree.leftMouseReleased.connect(self.funcSelectionChanged)
        self.qtFuncTree.setColumnCount(3)
        self.qtFileTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtFileTable.customContextMenuRequested.connect(self.fileMarkingMenu)
        self.qtVerticalLayout.addWidget(self.qtFuncTree)
        
        self.qSelectionTemplatesButton = QtWidgets.QPushButton('ST')
        self.qSelectionTemplatesButton.dTemplates = {}
        self.qSelectionTemplatesButton.setMaximumWidth(50)
        self.qSelectionTemplatesButton.setMinimumWidth(50)
        self.qSelectionTemplatesButton.setMaximumHeight(50)
        self.qSelectionTemplatesButton.setMinimumHeight(50)
        self.qSelectionTemplatesButton.setToolTip('Selection Templates for selected Functions. \nLeft mouse click for calling them. Right mouse click for adding/adjusting them')
        self.qReloadLayout.addWidget(self.qSelectionTemplatesButton)
        self.qSelectionTemplatesButton.clicked.connect(self.selectionTemplateClicked)
        self.qSelectionTemplatesButton.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qSelectionTemplatesButton.customContextMenuRequested.connect(self.selectionTemplateRightClicked)

        self.refresh()
        self.qtFuncTree.itemChanged.connect(self.funcItemChanged)
        self.qtFileTable.itemChanged.connect(self.fileItemChanged)
        self.bDisableEverything = False

        self.qRefreshButton.setToolTip('Reloads all the functions. \nMake sure to call this every time after you change some python code!')

    def selectionTemplateClicked(self):
        dData = self.getValue()
        dSelectionTemplates = dData.get('dSelectionTemplates')
        qMenu = QtWidgets.QMenu()
        
        dSelectionTemplates['* All Until Deformers *'] = 'UntilDeformers'
        dSelectionTemplates['* All Before Clean *'] = 'BeforeClean'
        # if not dSelectionTemplates:
        #     qMenu.addAction('-- Currently no Selection Templates. Right Click to add some --')
        for sName in sorted(dSelectionTemplates.keys()):
            sSelection = dSelectionTemplates[sName]
            def _select(sSelection=sSelection):
                qRoot = self.qtFuncTree.invisibleRootItem()
                
                qSelect = []
                qDeSelect = []

                bUncheckFromNow = False
                if sSelection == 'UntilDeformers':
                    for iChild in range(qRoot.childCount()):
                        qChild = qRoot.child(iChild)
                        if not bUncheckFromNow:
                            qSelect.append(qChild)
                            if qChild.text(0).strip().upper() == 'LOADDEFORMERS':
                                bUncheckFromNow = True
                        else:
                            qDeSelect.append(qChild)

                    if not bUncheckFromNow:
                        raise Exception('LoadDeformers function not found')
                elif sSelection == 'BeforeClean':
                    for iChild in range(qRoot.childCount()):
                        qChild = qRoot.child(iChild)
                        if qChild.text(0).strip().upper() in ['CLEAN', 'CLEANMUSCLES']:
                            bUncheckFromNow = True

                        if not bUncheckFromNow:
                            qSelect.append(qChild)
                        else:
                            qDeSelect.append(qChild)

                    if not bUncheckFromNow:
                        raise Exception('No Clean function found')

                else:
                    for iChild in range(qRoot.childCount()):
                        qChild = qRoot.child(iChild)
                        if qChild.text(0) in sSelection:
                            qSelect.append(qChild)
                        else:
                            qDeSelect.append(qChild)


                # now select them
                #
                self.qtFuncTree.blockSignals(True)
                try:
                    for qChild in qDeSelect:
                        qChild.setSelected(False)
                    for i,qChild in enumerate(qSelect):
                        if i == len(qSelect)-1:
                            self.qtFuncTree.blockSignals(False)
                        qChild.setSelected(True)
                        
                    self.saveToFile()
                except:
                    self.qtFuncTree.blockSignals(False)
                    raise

            qMenu.addAction(sName, _select)

        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())


    def selectionTemplateRightClicked(self, vPos):
        qMenu = QtWidgets.QMenu()
    
        def createFromSelection():
            sSelection = [qI.text(0) for qI in self.qtFuncTree.selectedItems()]
            def addNew(sName, sSelection=sSelection):
                self.qSelectionTemplatesButton.dTemplates[sName] = sSelection
                self.saveToFile()
            self.qDialog = utilsQt.QGetStringDialog(addNew, sMessage='Enter Name for Selection Template')
            self.qDialog.show()
        qMenu.addAction('--- create new from current selection ---', createFromSelection)

        dTemplates = self.qSelectionTemplatesButton.dTemplates
        for sName in sorted(dTemplates.keys()):
            qNameMenu = qMenu.addMenu(sName)

            def _update(sName=sName):
                sSelection = [qI.text(0) for qI in self.qtFuncTree.selectedItems()]
                dTemplates[sName] = sSelection
                self.saveToFile()
            qNameMenu.addAction('update to current selection', _update)
            
            def _delete(sName=sName):
                del dTemplates[sName]
                self.saveToFile()
            qNameMenu.addAction('delete', _delete)

            def _rename(sName=sName):
                def rename(sNewName, sName=sName):
                    if sNewName == sName:
                        raise Exception('no name is the same')
                    sSelection = dTemplates[sName]
                    dTemplates[sNewName] = sSelection
                    del self.qSelectionTemplatesButton.dTemplates[sName]
                    self.saveToFile()
    
                self.qDialog = utilsQt.QGetStringDialog(rename, sDefault=sName, sMessage='Enter New Name')
                self.qDialog.show()
    
                
                self.saveToFile()
            qNameMenu.addAction('rename', _rename)

        qMenu.exec_(self.qSelectionTemplatesButton.mapToGlobal(vPos))

        return qMenu

    
        
    def searchReturn(self):
        self.iSearchEnterPressedCount += 1
        if self.sFoundFunctions:
            self.qtFuncTree.clearSelection()
            sFunctionName = self.sFoundFunctions[self.iSearchEnterPressedCount % len(self.sFoundFunctions)]
            for x in self.dAllFuncs.values():
                if x[1].text(0) == sFunctionName:
                    qItem = x[1]
                    break
            self.qtFuncTree.setCurrentItem(qItem)
            self.qtFuncTree.scrollTo(self.qtFuncTree.indexFromItem(qItem))
            self.funcSelectionChanged()

    def searchChanged(self, bForce=False):
        def _updateSelectionFromFilter(sSearchText, bForce=False):
            if bForce or (sSearchText and sSearchText != self.sPreviousFilter):

                self.qtFuncTree.clearSelection()
                if len(sSearchText) > 1:
                    self.iSearchEnterPressedCount = 0
                    self.sFoundFunctions = [self.dAllFuncs[sK][1].text(0) for sK in list(self.dAllFuncs.keys()) if sSearchText in sK]
                    
                    if self.sFoundFunctions:
                        sFunctionName = self.sFoundFunctions[self.iSearchEnterPressedCount % len(self.sFoundFunctions)]
                        for x in self.dAllFuncs.values():
                            if x[1].text(0) == sFunctionName:
                                qItem = x[1]
                                break
                        self.qtFuncTree.setCurrentItem(qItem)
                        self.qtFuncTree.scrollTo(self.qtFuncTree.indexFromItem(qItem))

                self.sPreviousFilter = sSearchText
                self.funcSelectionChanged()

        sSearchText = self.qSearchField.text().replace(' ', '').lower()
        if bForce:
            _updateSelectionFromFilter(sSearchText, bForce=True)
        elif sSearchText < self.sPreviousFilter and len(sSearchText) < 2:
            _updateSelectionFromFilter(sSearchText, bForce=True)
        else:
            QtCore.QTimer.singleShot(500, _updateSelectionFromFilter(sSearchText))



    def serverSwitch(self, bServer):
        self.qtFileTable.setEnabled(not bServer)
        self.qtFuncTree.setEnabled(not bServer)
        self.qRefreshButton.setEnabled(not bServer)


    def setSelectionMode(self, bOffOn=True):
        if bOffOn:
            self.qtFuncTree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        else:
            self.qtFuncTree.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)


    def fileItemChanged(self, qFile, bSaveToFile=True):

        bFileIsChecked = True if qFile.checkState() == QtCore.Qt.Checked else False
        sTopLocalPythonFile = qFile.text()

        qRoot = self.qtFuncTree.invisibleRootItem()
        for iFunc in range(qRoot.childCount()):
            qFunc = qRoot.child(iFunc)
            ddData = qFunc.data(0, QtCore.Qt.UserRole)
            sPythonKey = ddData['sPythonKey']
            if sPythonKey == sTopLocalPythonFile:
                bHide = False
                if not bFileIsChecked:
                    bHide = True
                else:
                    if self.tArgListControl.qFilterCheckedButton.isChecked():
                        if qFunc.checkState(0) == QtCore.Qt.Unchecked:
                            bHide = True
                        else:
                            bHide = False
                    else:
                        bHide = False
                qFunc.setHidden(bHide)

                ddData['bFileIsChecked'] = bFileIsChecked
                qFunc.setData(0, QtCore.Qt.UserRole, ddData)
        if bSaveToFile:
            self.saveToFile()


    def fileMarkingMenu(self, vPos, iWidgetIndex=0):
        qGlobalMenu = QtWidgets.QMenu()
        qCurrentItem = self.qtFileTable.currentItem()
        sCurrentItemText = qCurrentItem.text()

        dBuildFolders = assets.getBuildFolders()

        if qCurrentItem:
            sCurrentItem = qCurrentItem.text()
            qGlobalMenu.addAction('Open "%s"' % sCurrentItem, lambda:self.openPythonFile(qCurrentItem))
            qGlobalMenu.addAction('Show in Explorer', lambda:self.openPythonFile(qCurrentItem, bJustExplorer=True))
            qGlobalMenu.addAction('Remove "%s"' % sCurrentItem, lambda:self.removeSelectedPythonFile(qCurrentItem))


        for sTask, iTask in [('Replace File',0), ('Add new File',1)]:
            qTaskMenu = qGlobalMenu.addMenu('%s..' % sTask)
            print ('dBuildFolders: ', dBuildFolders)
            for sTagName, sFolder in list(dBuildFolders.items()):
                qFolderMenu = qTaskMenu.addMenu('+%s' % sTagName)

                sAllFiles = [sF for sF in os.listdir(sFolder) if sF.endswith('.py') and not sF.startswith('_')]
                dMenus = defaultdict(list)
                for sF in sAllFiles:
                    sName = sF[0:sF.rfind('_')]
                    dMenus[sName].append(sF)


                for sMenu in sorted(dMenus.keys()):
                    sFiles = sorted(dMenus[sMenu], key=lambda a:utils.getVersionFromName(a))
                    if len(dMenus) > 1:
                        qMenu = qFolderMenu.addMenu(sMenu)
                    else:
                        qMenu = qFolderMenu

                    if iTask == 0 and sCurrentItemText.split('@')[-1] in sFiles:
                        qFolderMenu.menuAction().setFont(qBoldFont)
                        qMenu.menuAction().setFont(qBoldFont)
                        qDirectMenu = qTaskMenu.addMenu('CURRENT (%s)' % sMenu)
                        qDirectMenu.menuAction().setFont(qBoldFont)
                    else:
                        qDirectMenu = None

                    for sF in sFiles:
                        if iTask == 0:
                            def _fTask(_sTagName=sTagName, _sF=sF):
                                self.replacePythonFile('%s@%s' % (_sTagName, _sF), sCurrentItemText)
                        elif iTask == 1:
                            def _fTask(_sTagName=sTagName, _sF=sF):
                                self.addPythonFile('%s@%s' % (_sTagName, _sF))

                        qAction = qMenu.addAction(sF, _fTask)
                        if qDirectMenu:
                            qDirectAction = qDirectMenu.addAction(sF, _fTask)
                        if sCurrentItemText.endswith(sF):
                            qAction.setEnabled(False)
                            if qDirectMenu:
                                qDirectAction.setEnabled(False)


        qGlobalMenu.exec_(self.qtFileTable.mapToGlobal(vPos))
        return qGlobalMenu


    def funcMarkingMenu(self, vPos, iWidgetIndex=0):
        qMenu = QtWidgets.QMenu()
        qCurrentItem = self.qtFuncTree.currentItem()
        dData = qCurrentItem.data(0, QtCore.Qt.UserRole)
        bCanGetDuplicate = dData['func'].bCanGetDuplicated
        sDocumentationLink = dData['func'].sDocumentationLink

        sFuncName = qCurrentItem.text(0)


        def goToPythonCode():
            sPythonKey = dData['sPythonKey']
            sSplits = sPythonKey.split('@')
            if len(sSplits) == 2:
                sName, sFile = sSplits
                dBuildFolder = assets.getBuildFolders()
                sFilePath = os.path.join(dBuildFolder[sName], sFile)
            else:
                sBuildDir = self.getBuildFolder()
                sFilePath = os.path.abspath(os.path.join(sBuildDir, sPythonKey))
                sFilePath = os.path.normpath(sFilePath)

            iLineNumber = utils.getLineNumber(sFilePath, 'def %s(' % sFuncName)
            if iLineNumber == -1:
                iLineNumber = utils.getLineNumber(sFilePath, 'def %s (' % sFuncName)

            utils.openPycharm(sFilePath, iLineNumber)
        qMenu.addAction('Go to Code', goToPythonCode)


        def selectFunctionsBefore(qCurrentItem=qCurrentItem, bIncludeCurrent=False):
            qRoot = self.qtFuncTree.invisibleRootItem()
            self.blockSignals(True)
            try:
                self.qtFuncTree.clearSelection()
                for iFunc in range(qRoot.childCount()):
                    _qFunc = qRoot.child(iFunc)
                    if _qFunc != qCurrentItem:
                        _qFunc.setSelected(True)
                    else:
                        if bIncludeCurrent:
                            _qFunc.setSelected(True)
                        else:
                            _qFunc.setSelected(False)
                        break
            except:
                raise
            finally:
                self.blockSignals(False)
            self.funcSelectionChanged()


        def undoUntilBefore(qCurrentItem=qCurrentItem):
            dBuilderUndosBefore = utils.data.get('dBuilderUndosBefore')
            sFuncName = qCurrentItem.text(0)
            if sFuncName in dBuilderUndosBefore:
                iUndoPoint = dBuilderUndosBefore[sFuncName]
                print ('iUndoPoint: ', iUndoPoint)
                while cmds.undoInfo(q=True) > iUndoPoint:
                    cmds.undo()
            else:
                print ('function name not in dict ("%s")' % sFuncName)



        qMenu.addAction('Select Previous Functions', selectFunctionsBefore)
        qMenu.addAction('Select Previous Functions + this one', lambda:selectFunctionsBefore(bIncludeCurrent=True))
        qMenu.addAction('Undo until before this function', undoUntilBefore)


        def setCount():
            def settingTheCount(iCount):
                self.dFuncCounts[sFuncName] = int(iCount)
                self.saveToFile()
                self.refresh()
                pass
            self.qCountDialog = utilsQt.QGetStringDialog(settingTheCount, sMessage='enter count', sDefault=self.dFuncCounts.get(sFuncName, 1))
            self.qCountDialog.show()
        qSetCountAction = qMenu.addAction('set function instance count', setCount)
        if not bCanGetDuplicate:
            qSetCountAction.setEnabled(False)

        def help(sDocumentationLink=sDocumentationLink):
            webbrowser.open(sDocumentationLink)

        qHelpAction = qMenu.addAction('Go to Documentation..', help)
        utilsQt.makeActionItalic(qHelpAction)
        if not sDocumentationLink:
            qHelpAction.setEnabled(False)


        qMenu.exec_(self.qtFuncTree.mapToGlobal(vPos))
        return qMenu





    def _getAbsPath(self, sPythonKey):
        if '@' in sPythonKey:
            dBuildFolder = assets.getBuildFolders()
            sName, sFile = sPythonKey.split('@')
            sFolder = dBuildFolder[sName].replace('\\', '/')
            sPythonFile = os.path.abspath(os.path.join(sFolder, sFile))
            return sPythonFile
        else:
            return assets.assetManager.getCurrentVersionPath(sPythonKey)


    def openPythonFile(self, qFile, bJustExplorer=False):
        sFile = self._getAbsPath(qFile.text())
        if bJustExplorer:
            utils.openExplorer(sFile)
        else:
            # os.startfile(sFile)
            utils.openPycharm(sFile)


    def funcSelectionChanged(self, bSaveToFile=True):
        if bSaveToFile:
            self.saveToFile()
        qSelectedItems = self.qtFuncTree.selectedItems()
        if len(qSelectedItems) == 0 or len(qSelectedItems) > 1:
            self.tArgListControl.clear()
            self.tButtonListControl.clear()
            self.tButtonListControl.qDeleteLater = []
        else:
            qItem = qSelectedItems[0]
            ddData = qItem.data(0, QtCore.Qt.UserRole)
            self.tArgListControl.setArgs(qItem, ddData['dDefaultArgs'], ddData['sArgsSorted'], ddData['dFileArgs'])

            # here should setListButtons function come
            xListButtons = ddData['xListButtons']

            dButtons = ddData['dButtons']
            sButtons = ddData['sButtons']
            sListKeys = [None] * len(sButtons)

            if xListButtons:
                sNamesKey, dListButtons = xListButtons
                dFileArgs = ddData['dFileArgs']
                dDefaultArgs = ddData['dDefaultArgs']
                sAllNames = dFileArgs.get(sNamesKey, dDefaultArgs[sNamesKey])
                for sName in sAllNames:
                    for sButtonName, fFunction in dListButtons.items():
                        sReplaceButtonName = sButtonName % sName.split('.')[-1]
                        sButtons.append(sReplaceButtonName)
                        dButtons[sReplaceButtonName] = fFunction
                        sListKeys.append(sName)
            self.tButtonListControl.setButtons(dButtons, sButtons, ddData['func'], ddData['iIndex'], report.report, self.tArgListControl.dPassArgTable, self, qItem, sListKeys=sListKeys)
            self.tButtonListControl.setDoc(ddData['func'].sDoc, ddData['documentationLink'])


    def getFunctionArg(self, sFunction, sArg, iFunctionIndex=0, xDefault=None):
        sBuildFile = self.qtText.text()
        print('sBuildFile: ', sBuildFile)
        dBuildContent = utils.getJsonContent(sBuildFile)
        dAllFunctionDatas = dBuildContent.get('__FUNCTIONDATAS__', {})

        dFunctionDatas = dAllFunctionDatas.get(sFunction, [{}])
        dFunctionData = dFunctionDatas[iFunctionIndex]
        dFileArgs = dFunctionData.get('dFileArgs', {})

        return dFileArgs.get(sArg, xDefault)


    def setFunctionArg(self, sFunction, sArg, xData, iFunctionIndex=0):
        sBuildFile = self.qtText.text()
        dBuildContent = utils.getJsonContent(sBuildFile)
        dAllFunctionDatas = dBuildContent.get('__FUNCTIONDATAS__', {})

        dFunctionDatas = dAllFunctionDatas.get(sFunction, [{}])
        dFunctionData = dFunctionDatas[iFunctionIndex]
        dFileArgs = dFunctionData.get('dFileArgs', {})

        dFileArgs[sArg] = xData

        dFunctionDatas[iFunctionIndex] = dFunctionData
        dAllFunctionDatas[sFunction] = dFunctionDatas
        dBuildContent['__FUNCTIONDATAS__'] = dAllFunctionDatas

        utils.setJsonContent(sBuildFile, dBuildContent)

        self.refresh()


    def updateFileArgument(self, qFunc, sArg, xValue):
        '''
        gets called from TArgList
        '''
        ddData = qFunc.data(0, QtCore.Qt.UserRole)
        ddData['dFileArgs'][sArg] = xValue
        qFunc.setData(0, QtCore.Qt.UserRole, ddData)


    def setUncheckedFunctionsHidden(self, bSetHidden):
        for iChild in range(self.qtFuncTree.invisibleRootItem().childCount()):
            qChild = self.qtFuncTree.invisibleRootItem().child(iChild)
            dChild = qChild.data(0, QtCore.Qt.UserRole)
            if not dChild['bFileIsChecked']:
                qChild.setHidden(True)
            else:
                if not bSetHidden:
                    qChild.setHidden(False)
                else:
                    if dChild['bNoCheckBox'] or qChild.checkState(0) != QtCore.Qt.Unchecked:
                        qChild.setHidden(False)
                    else:
                        qChild.setHidden(True)




    def toggleFileList(self, bSetHidden):
        if bSetHidden:
            self.qtFileTable.hide()
        else:
            self.qtFileTable.show()


    def removeFileArgument(self, qFunc, sArg):
        '''
        gets called from TArgList
        '''
        ddData = qFunc.data(0, QtCore.Qt.UserRole) #Internal C++ object (PySide.QtWidgets.QTreeWidgetItem) already deleted.
        dFileArgs = ddData['dFileArgs']
        if sArg in list(dFileArgs.keys()):
            del dFileArgs[sArg]
            qFunc.setData(0, QtCore.Qt.UserRole, ddData)


    def blockSignals(self, bBlock):
        self.qtFuncTree.blockSignals(bBlock)
        self.qtFileTable.blockSignals(bBlock)


    def funcItemChanged(self, qItem):
        # sJustOneKey flag:
        self.qtFuncTree.blockSignals(True)
        fItem = qItem.data(0, QtCore.Qt.UserRole)['func']
        for sKey, qFuncs in list(dJustOneKeysItems.items()):
            if fItem in dJustOneKeysFunctions[sKey]:
                if qItem.checkState(0) == QtCore.Qt.Checked:
                    for qF in qFuncs:
                        fF = qF.data(0, QtCore.Qt.UserRole)['func']
                        if fF == fItem:
                            continue
                        qF.setCheckState(0, QtCore.Qt.Unchecked)
        self.qtFuncTree.blockSignals(False)

        self.saveToFile()


    def addPythonFileDialog(self):
        sBuildFile = self.getBuildFile()
        sBuildDir, _ = os.path.split(sBuildFile)
        sNewPythonFile, wtf = QtWidgets.QFileDialog.getOpenFileName(None, "open file", sBuildDir, '*.py')
        if sNewPythonFile:
            self.addPythonFile(sNewPythonFile)


    def addPythonFile(self, sNewPythonKey):
        '''
        opens build file, adds new file in there, saves build file and refreshes
        '''
        # open file
        sBuildFile = self.getBuildFile()
        dBuildData = utils.getJsonContent(sBuildFile)

        dBuildData['__FILES__'].append([sNewPythonKey, True])
        # now save it again
        utils.setJsonContent(sBuildFile, dBuildData)

        self.refresh()



    def replacePythonFile(self, sNewPythonKey, sOldPythonKey):
        '''
        opens build file, adds new file in there, saves build file and refreshes
        '''
        # open file
        dBuildFile = self.getBuildContent()

        xFiles = dBuildFile['__FILES__']
        for f,xF in enumerate(xFiles):
            sFileKey = xF[0]
            if sFileKey == sOldPythonKey:
                xF[0] = sNewPythonKey
                xFiles[f] = xF
                dBuildFile['__FILES__'] = xFiles

                sBuildFile = self.getBuildFile()
                with open(sBuildFile, 'w') as outfile:
                    json.dump(dBuildFile, outfile, indent=2)

                self.refresh()
                return

        raise Exception('could not find file to replace with')

    def removeSelectedPythonFile(self, qFile):
        '''
        opens build file, adds new file in there, saves build file and refreshes
        '''

        if cmds.confirmDialog(title='Remove File', message='Are you sure you want to remove the file?', button=['yes', 'no'],
                           defaultButton='no', cancelButton='no', dismissString='no') == 'no':
            return

        sRelPythonFile = qFile.text()

        sBuildFile = self.getBuildFile()
        sBuildDir, _ = os.path.split(sBuildFile)

        # open file
        sBuildFile = self.getBuildFile()
        dBuildFile = self.getBuildContent()

        # remove it from list
        for i, fileData in enumerate(dBuildFile['__FILES__']):
            if fileData[0] == sRelPythonFile:
                dBuildFile['__FILES__'].remove(fileData)

        # now save it again
        with open(sBuildFile, 'w') as outfile:
            json.dump(dBuildFile, outfile, indent=2)

        self.refresh()



    def saveToFile(self, xBuildList=None):
        '''
        gets info from qt elements and saves it as json
        into build file (*.bld)
        '''

        sBuildFile = self.getBuildFile()

        if self.bDisableEverything:
            print('not saving because something is wrong..')
            return

        dSaveData = {}
        sFiles = []
        bChecked = []
        for i in range(self.qtFileTable.rowCount()):
            qFile = self.qtFileTable.item(i,0)
            sFile = qFile.text()
            sFiles.append(sFile)
            bChecked.append(True if qFile.checkState() == QtCore.Qt.Checked else False)
        dSaveData['__FILES__'] = list(zip(sFiles, bChecked))
        
        qTopRoot = self.qtFuncTree.invisibleRootItem()
        dDatas = defaultdict(list)

        for iChild in range(qTopRoot.childCount()):
            qFunc = qTopRoot.child(iChild)
            sFuncName = qFunc.text(0)
            ddData = qFunc.data(0, QtCore.Qt.UserRole)
            
            
            dFuncData = {}
            if qFunc.checkState(0) == QtCore.Qt.Unchecked:
                dFuncData['bDisabled'] = True
            else:
                dFuncData['bDisabled'] = False

            
            if qFunc.isSelected():
                dFuncData['bSelected'] = True

            dFileArgs = ddData['dFileArgs']
            if dFileArgs:
                dFuncData['dFileArgs'] = dFileArgs
            
            if dFuncData:
                dDatas[sFuncName].append(dFuncData)

    
        dSaveData['__FUNCTIONDATAS__'] = dDatas

        dSaveData['dFuncCounts'] = self.dFuncCounts

        dSaveData['dSelectionTemplates'] = self.qSelectionTemplatesButton.dTemplates
        # now save it
        with open(sBuildFile, 'w') as outfile:
            json.dump(dSaveData, outfile, indent=2)

        utils.saveBackupFile(sBuildFile, '_builderBackup')



    def getBuildFile(self):
        return self.qtText.text()


    def getBuildContent(self, sBuildFile=None, bMessageBoxIfSyntaxError=True):

        if sBuildFile == None:
            sBuildFile = self.getBuildFile()
        try:
            with open(sBuildFile) as file:
                try:
                    dBuildFile = json.load(file)
                except:
                    if bMessageBoxIfSyntaxError:
                        cmds.confirmDialog(m='build file got corrupted - click the "backup" button to switch to an older one\n%s' % sBuildFile)
                    return {}

            xFiles = dBuildFile['__FILES__']
            for f,xF in enumerate(xFiles):
                sFile = xF[0]
                if '\\' in sFile:
                    sFilename = sFile.split('\\')[-1]
                    if sFile.startswith('kangarooBuilds'):
                        xF[0] = 'default@%s' % sFilename
                    xFiles[f] = xF

            dBuildFile['__FILES__'] = xFiles

        except Exception:
            raise
            # dBuildFile = {}


        return dBuildFile




    def getBuildFolder(self):
        sFile = self.getBuildFile()
        return os.path.dirname(sFile)


    def getValue(self, bReload=False, sBuildFile=None, bMessageBoxIfSyntaxError=True):
        '''
        takes build file, and looks at its python files.
        Then it returns all functions from the python files
        plus extra data function data saved in the build file
        '''

        if sBuildFile == None:
            sBuildFile = self.getBuildFile()

        if not os.path.exists(sBuildFile):
            return
        dBuildFile = self.getBuildContent(sBuildFile, bMessageBoxIfSyntaxError=bMessageBoxIfSyntaxError)


        sBuildDir = os.path.dirname(sBuildFile)
        if sBuildDir.endswith('Documents'):
            return



        if '__FILES__' not in list(dBuildFile.keys()):
            sNewPythonFile = os.path.join(sBuildDir, 'build.py')
            sRelPythonFile = os.path.relpath(sNewPythonFile, sBuildDir)
            
            if not os.path.isfile(sNewPythonFile):
                with open(sNewPythonFile, 'w+') as file:
                    file.write('# this was autocreated, please add functions in there\n\n\n\n')
                    file.write('import builder\n\n\n')
                    file.write('kBuilderColor = \'#d9d9d9\'\n\n\n')

                sInitFile = os.path.join(sBuildDir, '__init__.py')
                with open(sInitFile, 'w+') as file:
                    file.write('\n\n\n')

            dBuildFile['__FILES__'] = [(sRelPythonFile, True)]

        __FUNCTIONDATAS__ = dBuildFile.get('__FUNCTIONDATAS__', {})

        self.dFuncCounts = dBuildFile.get('dFuncCounts', {})
        dFuncs = defaultdict(dict) # iOrders as keys
        
        dPythonFileColors = {}
        dPythonFileModules = {}
        dFuncLocalPythonFiles = {} # funcs as keys
        dPythonFileChecked = {}

        sBuildDir = self.getBuildFolder()

        dBuildFolder = assets.getBuildFolders()
        for i, xFileInfo in enumerate(dBuildFile['__FILES__']):
            sPythonKey, bChecked = xFileInfo
            dPythonFileChecked[sPythonKey] = bChecked
            try:
                sPythonFile = None
                if '@' in sPythonKey:
                    sName, sFile = sPythonKey.split('@')
                    sFolder = dBuildFolder[sName].replace('\\', '/')

                    # this part is just to make sure that additional script locations will work also
                    if sFolder not in sys.path:
                        sys.path.append(sFolder)

                    sModule = '%s.%s' % (sFolder.split('/')[-1], sFile.split('.')[0])
                    sPythonFile = os.path.join(sFolder, sFile).replace('\\', '/')
                else:
                    sPythonFile = os.path.abspath(os.path.join(sBuildDir, sPythonKey))
                    sPythonFile = os.path.normpath(sPythonFile)

                    print ('PythonFile: ', sPythonFile) # keep this here in case we get that error below
                    print ('Asset root: ', assets.getCurrentAssetRoot()) # keep this here in case we get that error below
                    sRelToAssetPath = os.path.relpath(sPythonFile, assets.getCurrentAssetRoot())
                    sRelToAssetPath = os.path.normpath(sRelToAssetPath)

                    if not os.path.isfile(sPythonFile):
                        raise Exception('File %s doesn\'t exist' % sPythonFile)

                    sPathSplits = sRelToAssetPath.split(os.sep)
                    sModule =  '.'.join(sPathSplits[:-1] + [sPathSplits[-1].split('.')[0]])
                    sModule = '%s.%s' % (assets.getCurrentAssetRootName(), sModule)
                    sProject = assets.getCurrentProject()
                    if len(sProject):
                        sModule = '%s.%s' % (sProject, sModule)

                try:
                    modModule = importlib.import_module(sModule)
                except:
                    print ('importing without folder (%s)' % sModule)
                    modModule = importlib.import_module(sModule.split('.')[-1])

                if bReload:
                    report.report.addLogText('reloading module "%s"...' % sModule)
                    utils.reload2(modModule)

                sAttrsInModule = dir(modModule)
                try:
                    kBuilderColor = getattr(modModule, 'kBuilderColor')
                except:
                    kBuilderColor = '#d9d9d9'
                dPythonFileModules[sPythonKey] = modModule
                dPythonFileColors[sPythonKey] = kBuilderColor
            except Exception as e:
                cmds.warning('error loading build file %s: %s - see Script Editor' % (sPythonFile,e))
                sErrorLog = traceback.format_exc()
                print('Caught Error loading python file: ', sErrorLog)
                report.report.addLogText(sErrorLog, sColor=utils.uiColors.red, bQuotationsToLink=True)
                dPythonFileModules[sPythonKey] = None
                continue
            if dPythonFileModules[sPythonKey] != None:
                for sFuncName in sAttrsInModule:
                    func = getattr(modModule, sFuncName)
                    if hasattr(func, 'addToBuilder'):
                        if utils.isTextInFile(sPythonFile, 'def %s(' % sFuncName):
                            dFuncs[func.iOrder][sFuncName] = func
                            dFuncLocalPythonFiles[func] = sPythonKey
                            func.sFuncName = sFuncName


        # now that we got slightly messy dFunc, let's create dAllFunc that is more ordered
        # dAllFuncFileDatas has all functions as keys ordered, and values is its file datas
        # {} if there is no file data to it
        dAllFuncNamesOrdered = OrderedDict()
        dFuncBuildFileDatas = {}
        fDisabledFuncs = []

        iOrders = list(dFuncs.keys())
        iOrders.sort()
        for iO in iOrders:
            dSameOrderFuncs = dFuncs[iO]
            sFuncNames = list(dSameOrderFuncs.keys())
            sFuncNames.sort()
            for sFuncName in sFuncNames:
                func = dSameOrderFuncs[sFuncName]
                dAllFuncNamesOrdered[sFuncName] = func

                dDatas =  __FUNCTIONDATAS__.get(sFuncName, [])
                if not isinstance(dDatas, list):
                    dDatas = [dDatas]

                iCount = self.dFuncCounts.get(sFuncName, 1)
                if len(dDatas) < iCount:
                    dDatas += [{} for _ in range(iCount-len(dDatas))]
                dFuncBuildFileDatas[sFuncName] = dDatas

                if __FUNCTIONDATAS__.get('bDisabled', False) == True:
                    fDisabledFuncs.append(func)

        ddReturnData = {'dAllFuncNamesOrdered':dAllFuncNamesOrdered,
                        'dFuncBuildFileDatas':dFuncBuildFileDatas,
                        'dFuncLocalPythonFiles':dFuncLocalPythonFiles,
                        'dPythonFileModules':dPythonFileModules,
                        'dPythonFileColors':dPythonFileColors,
                        'dFuncLights':self.dFuncLights,
                        'dPythonFileChecked':dPythonFileChecked,
                        'dFuncCounts':self.dFuncCounts,
                        'dSelectionTemplates':dBuildFile.get('dSelectionTemplates', {})}
        return ddReturnData


    def refreshFromBackup(self, sFilePath):
        self.refresh(sBuildFile=sFilePath)


    def refresh(self, xValue=None, sBuildFile=None):
        '''
        takes build files and repopulates everything
        '''
        self.bDisableEverything = False

        dJustOneKeysItems.clear()
        dJustOneKeysFunctions.clear()

        try:
            qBar = self.qtFuncTree.verticalScrollBar()
            fScrollPosBefore = qBar.value()
        except:
            fScrollPosBefore = None

        ddValue = self.getValue(bReload=True, sBuildFile=sBuildFile)
        if ddValue == None:
            return
        self.dFuncLights = defaultdict(list)


        self.blockSignals(True)
        sPythonKeys = list(ddValue['dPythonFileModules'].keys())
        iRowCount = len(sPythonKeys)

        self.qtFileTable.setRowCount(iRowCount)
        iTableHeight = max(1,iRowCount) * _kRowHeight + 6
        self.qtFileTable.setMinimumHeight(iTableHeight)
        self.qtFileTable.setMaximumHeight(iTableHeight)
        self.qtFileTable.verticalHeader().setMinimumSectionSize(_kRowHeight)
        # filling qtFileTable
        self.qtFileTable.clear()
        for i, sPythonKey in enumerate(sPythonKeys):
            qFile = QtWidgets.QTableWidgetItem(sPythonKey)
            qFile.setFlags(QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsUserCheckable)
            bChecked = ddValue['dPythonFileChecked'][sPythonKey]
            qFile.setCheckState(QtCore.Qt.Checked if bChecked == True else QtCore.Qt.Unchecked)

            if ddValue['dPythonFileModules'][sPythonKey] != None:
                qFile.setForeground(QtGui.QBrush(QtGui.QColor(ddValue['dPythonFileColors'][sPythonKey])))
            else:
                qFile.setForeground(QtGui.QBrush(QtGui.QColor('#ea4963')))
                qFile.setFont(qItalicFont)
                self.bDisableEverything = True

            self.qtFileTable.setItem(i, 0, qFile)
            self.qtFileTable.setRowHeight(i, _kRowHeight)

        self.qtFuncTree.clear()
        self.dAllFuncs = {}
        iFunc = -1
        for sFuncName, func in list(ddValue['dAllFuncNamesOrdered'].items()):
            iCount = ddValue['dFuncCounts'].get(sFuncName, 1)

            # utils.toList is to support legacy ones
            dFileDatas = utils.toList(ddValue['dFuncBuildFileDatas'].get(sFuncName, []))
            if len(dFileDatas) < iCount:
                dFileDatas += [{} for _ in range(iCount-len(dFileDatas))]
            for p in range(iCount):
                iFunc += 1
                bDisabled = dFileDatas[p].get('bDisabled', func.bDisableByDefault)
                dFileArgs = dFileDatas[p].get('dFileArgs', {})
                bSelected = dFileDatas[p].get('bSelected', False)
                sPythonKey = ddValue['dFuncLocalPythonFiles'][func]

                bFileIsChecked = ddValue['dPythonFileChecked'][sPythonKey]
                qFunc = QtWidgets.QTreeWidgetItem(self.qtFuncTree.invisibleRootItem())

                self.dAllFuncs[sFuncName.lower()] = (iFunc, qFunc)

                if not func.bNoCheckbox:
                    qFunc.setCheckState(0, QtCore.Qt.Unchecked if bDisabled else QtCore.Qt.Checked)
                    if bDisabled and self.tArgListControl.qFilterCheckedButton.isChecked():
                        qFunc.setHidden(True)

                if not bFileIsChecked:
                    qFunc.setHidden(True)

                qFunc.setText(0, sFuncName)

                ddData = {'func':func,
                          'iIndex': p,
                          'dDefaultArgs':func.dDefaultArgs, 'dFileArgs':dFileArgs,
                          'dButtons':func.dButtons, 'sButtons':list(func.dButtons.keys()),
                          'xListButtons':func.xListButtons,
                          'sArgsSorted':func.sArgsSorted,
                          'sPythonKey':sPythonKey,
                          'bNoCheckBox':func.bNoCheckbox,
                          'bFileIsChecked':bFileIsChecked,
                          'documentationLink':func.sDocumentationLink}
                qFunc.setData(0, QtCore.Qt.UserRole, ddData)
                sColor = ddValue['dPythonFileColors'][sPythonKey] if func.sOverwriteColor == None else func.sOverwriteColor
                qFunc.setForeground(0, QtGui.QBrush(QtGui.QColor(sColor)))
                if func.bNoCheckbox:
                    qFunc.setFont(0, qItalicFont)

                if func.sJustOneKey:
                    dJustOneKeysItems[func.sJustOneKey].append(qFunc)
                    dJustOneKeysFunctions[func.sJustOneKey].append(func)

                if bSelected:
                    qFunc.setSelected(True)

                qFunc.setText(2, '  %s  ' % str(func.iOrder))


                if not func.bNoCheckbox:
                    qLight = QBuilderIcon(parent=self.qtFuncTree)
                    qLight.sLog = ''
                    qLight.qItem = qFunc
                    qLight.qTree = self.qtFuncTree
                    self.qtFuncTree.setItemWidget(qFunc, 1, qLight)
                    qFunc.qLight = qLight

                    self.dFuncLights[func].append(qLight)
                else:
                    self.dFuncLights[func].append(None)
                    qFunc.qLight = None

        self.qtFuncTree.itemSelectionChanged.connect(self.functionSelectionChanged)
        self.qtFuncTree.blockSignals(True)
        self.qtFuncTree._bTextIsFromMain = True


        self.qtFuncTree.setEnabled(not self.bDisableEverything)
        self.setSelectionMode(not self.bDisableEverything)

        self.qSelectionTemplatesButton.dTemplates = ddValue['dSelectionTemplates']
        self.blockSignals(False)
        self.funcSelectionChanged(bSaveToFile=False)
        report.report.setProgressBarColor(utils.uiColors.green)
        report.report.setToFull()
        if fScrollPosBefore:
            qBar.setValue(fScrollPosBefore)
        print ('end of refresh.. ', sBuildFile)

    def functionSelectionChanged(self):

        qFuncs = self.qtFuncTree.selectedItems()

        if self.qtFuncTree._bTextIsFromMain:
            self._sPrevLogText = report.report.getText()

        if len(qFuncs) == 1:
            qLight = qFuncs[0].qLight
            if not isinstance(qLight, type(None)):
                report.report.clearLogText()
                report.report.addLogText(qLight.sLog)
                self.qtFuncTree._bTextIsFromMain = False

        elif len(qFuncs) > 1:
            report.report.clearLogText()
            report.report.addLogText(' ------ ')
            self.qtFuncTree._bTextIsFromMain = False

        elif len(qFuncs) == 0:
            report.report.clearLogText()
            report.report.addLogText(self._sPrevLogText)

dRunControls = {}
dRunControls['xArgs'] = TArgList()
dRunControls['xButtons'] = TButtonList()
dRunControls['xBuildList'] = TBuildList(tArgListControl=dRunControls['xArgs'], tButtonListControl=dRunControls['xButtons'])
@uiSettings.addToUI(sRunButton='Run All', sTab='Builder', sModuleButton='Builder', bReloadBeforeRun=True, dControls=dRunControls,
                    sTabControls=['xButtons'], sToolTip='Execute all Functions. Run this before you publish',
                    sDocumentationLink='https://kangaroobuilder.com/builder/builderGeneral/')
def run(xBuildList=[os.path.expanduser('~/Documents/default.bld'), {}], xArgs=None, _bUndo=False, _report=None, _bOnlySelected=False, xButtons=None):

    # mel.eval('closeAllNodeEditors')

    ddValue = xBuildList

    dPythonFileChecked = ddValue['dPythonFileChecked']
    dFuncPythonFileChecked = {}
    for func, sPythonKey in list(ddValue['dFuncLocalPythonFiles'].items()):
        dFuncPythonFileChecked[func] = dPythonFileChecked[sPythonKey]



    # dFuncFileChecked = {}
    for sFuncName, func in list(ddValue['dAllFuncNamesOrdered'].items()):
        if not func.bNoCheckbox:
            if dFuncPythonFileChecked[func]:
                for qLight in ddValue['dFuncLights'][func]:
                    # sLightImage = os.path.join(utils.getToolsDir(), 'empty.png')
                    qLight.setIcon(iconSymbols.default)


    xxFilteredFunc = []
    for sFuncName, func in list(ddValue['dAllFuncNamesOrdered'].items()):
        if dFuncPythonFileChecked[func]:
            dFileDatas = ddValue['dFuncBuildFileDatas'].get(sFuncName, [])
            for p,dData in enumerate(dFileDatas):
                if _bOnlySelected and not dData.get('bSelected', False):
                    pass
                elif dData.get('bDisabled', func.bDisableByDefault) == True:
                    pass
                else:
                    xxFilteredFunc.append([func, sFuncName, dData, p])

    bRanFirst = False
    for func, sFuncName, dFileData, p in xxFilteredFunc:
        if _bUndo and not bRanFirst:
            dBuilderUndosBefore = utils.data.get('dBuilderUndosBefore')
            if sFuncName in dBuilderUndosBefore:
                iUndoPoint = dBuilderUndosBefore[sFuncName]
                print ('iUndoPoint: ', iUndoPoint)
                while cmds.undoInfo(q=True) > iUndoPoint:
                    cmds.undo()
        bRanFirst = True
        utils.data.updateDict('dBuilderUndosBefore', {sFuncName:cmds.undoInfo(q=True)})

        qLight = ddValue['dFuncLights'][func][p]
        if not utils.isNone(qLight):
            qLight.qTree.scrollTo(qLight.qTree.indexFromItem(qLight.qItem))
            qLight.setIcon(iconSymbols.loading)

        _report.clearLogText()
        cmds.refresh()

        dArgs = dFileData.get('dFileArgs', {})
        sParamsText = ['%s=%s' % (sParam, dArgs[sParam]) for sParam in list(dArgs.keys())]
        _report.addLogText('# %s(%s)\n' % (sFuncName, ', '.join(sParamsText)))

        fTimeBefore = time.time()
        dFilteredArgs = utils.filterArgs(dArgs, func.sArgsSorted)
        if '_argList' in func._args:
            dFilteredArgs['_argList'] = list(func.sArgsSorted)
        if '_report' in func._args:
            dFilteredArgs['_report'] = _report
        try:
            cmds.undoInfo(openChunk=True)
            bReturn = func(**dFilteredArgs)

            # if bReturn == None:
            #     sLightImage = os.path.join(utils.getToolsDir(), 'greenHook.png')
            # elif bReturn == False:
            #     sLightImage = os.path.join(utils.getToolsDir(), 'yellowHook.png')
            if not utils.isNone(qLight):
                qLight.setIcon(iconSymbols.green if bReturn == None else iconSymbols.yellow)

        except Exception:
            # sLightImage = os.path.join(utils.getToolsDir(), 'redCross.png')
            sTraceback = traceback.format_exc()
            sFromString = '_builderFunction_'
            sError = sTraceback[sTraceback.find(sFromString):]
            sError = sError[sError.find('\n'):]
            sError = 'ERROR: %s' % sError
            _report.addLogText(sError, bQuotationsToLink=True)
            if not utils.isNone(qLight):
                qLight.setIcon(iconSymbols.error)
                qLight.sLog = _report.getText()
                qLight.qTree.blockSignals(False)
                qLight.qTree._bTextIsFromMain = True
            utils.raiseExceptionNoChaining(sTraceback)
        finally:
            cmds.undoInfo(closeChunk=True)

        _report.addLogText('\n# finished - it took %s.' % utils.fullTimeUnits(time.time()-fTimeBefore), sColor=utils.uiColors.green)
        qLight.sLog = _report.getText()
        
        cmds.refresh()

    _report.clearLogText()
    if _bOnlySelected:
        _report.addLogText('## Done running selected Items ##\n\n')
    else:
        _report.addLogText('## Done building Rig ##\n\n')

    qLight.qTree.blockSignals(False)
    qLight.qTree._bTextIsFromMain = True


@uiSettings.addToUI(sRunButton='Run Selected', sTab='Builder', sModuleButton='Builder', bReloadBeforeRun=True, dControls={}, sToolTip='Run only the selected Functions')
def runSelected(xBuildList=[os.path.expanduser('~/Documents/default.bld'), {}], xArgs=None, _report=None, _bOnlySelected=False):
    run(xBuildList=xBuildList, xArgs=xArgs, _report=_report, _bOnlySelected=True)

sToolTip = 'Undos many times until you are at stage before the selected functions. Can be very efficient, but doesn\'t always work. So use with caution.'
@uiSettings.addToUI(sRunButton='Undo + Run Selected', sTab='Builder', sModuleButton='Builder', bReloadBeforeRun=True, dControls={}, sToolTip=sToolTip)
def undoRunSelected(xBuildList=[os.path.expanduser('~/Documents/default.bld'), {}], xArgs=None, _report=None, _bOnlySelected=False):
    run(xBuildList=xBuildList, xArgs=xArgs, _report=_report, _bOnlySelected=True, _bUndo=True)





# @uiSettings.addToUI(sRunButton='Pull + Run Selected', sTab='Builder', sModuleButton='Builder', bReloadBeforeRun=True, dControls={})
# def pullRefreshRunSelected(xBuildList=[os.path.expanduser('~/Documents/default.bld'), {}], xArgs=None, _report=None, _bOnlySelected=False):
#     assets.pull()
#     run(xBuildList=xBuildList, xArgs=xArgs, _report=_report, _bOnlySelected=True)




class QDictUi(QtWidgets.QDialog):

    def __init__(self, dInput, funcReturn):
        super(QDictUi, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)


        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qTable = QtWidgets.QTableWidget()

        self.layout.addWidget(self.qTable)
        self.qTable.setColumnCount(1)
        self.qTable.setRowCount(len(dInput))
        self.qTable.horizontalHeader().setStretchLastSection(True)
        self.qTable.setHorizontalHeaderLabels(['values'])

        self.qTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qTable.customContextMenuRequested.connect(self.markingMenu)

        sAttrs = list(dInput.keys())
        sAttrs.sort()
        self.qTable.setVerticalHeaderLabels(sAttrs)
        for a, sAttr in enumerate(sAttrs):
            xValue = dInput[sAttr]
            qItem = QtWidgets.QTableWidgetItem()
            qItem.setText(str(xValue))
            self.qTable.setItem(0,a, qItem)

        self.qTable.itemChanged.connect(lambda: self.saveButton.setEnabled(True))

        self.saveButton = QtWidgets.QPushButton('Save')
        self.saveButton.clicked.connect(self.save)


        self.layout.addWidget(self.saveButton)

        self.saveButton.setEnabled(False)

        self.funcReturn = funcReturn


    def save(self):
        dOutput = {}
        for iRow in range(self.qTable.rowCount()):
            sA = self.qTable.verticalHeaderItem(iRow).text()
            sValue = self.qTable.item(iRow,0).text()
            dOutput[sA] = sValue

        self.funcReturn(dOutput)
        self.close()


    def removeItems(self):
        qSelectionModel = self.qTable.selectionModel()
        iRows = qSelectionModel.selectedRows()
        for iRow in iRows[::-1]:
            self.qTable.removeRow(iRow.row())
        self.saveButton.setEnabled(True)


    def markingMenu(self, vPos):
        qMenu = QtWidgets.QMenu()
        qMenu.addAction('remove', self.removeItems)
        qMenu.exec_(self.qTable.mapToGlobal(vPos))
        return qMenu


class iconSymbols(object):
    default = 0
    loading = 1
    yellow = 2
    green = 3
    error = 4


dImages = {}
dImages[iconSymbols.default] = 'buttonDefault.png'
dImages[iconSymbols.loading] = 'buttonBlue00.png'
dImages[iconSymbols.yellow] = 'buttonYellow.png'
dImages[iconSymbols.green] = 'buttonGreen.png'
dImages[iconSymbols.error] = 'buttonRed.png'

qLoadingBuilderIcon = None

fLastRebuildTime = time.time()
def rotateLoadingIcon(bRefresh=False):
    global fLastRebuildTime
    fNewTime = time.time()
    if fNewTime - fLastRebuildTime > 0.25:

        global qLoadingBuilderIcon
        if not isinstance(qLoadingBuilderIcon, type(None)):
            qLoadingBuilderIcon.rotate()
            # if bRefresh:
            #     cmds.refresh()
        fLastRebuildTime = fNewTime

report.funcRotateBuilderIcon = rotateLoadingIcon


class QBuilderIcon(QtWidgets.QWidget):
    def __init__(self, parent):
        super(QBuilderIcon, self).__init__(parent=parent)
        self.qLayout = QtWidgets.QHBoxLayout()
        self.qLayout.setContentsMargins(0,0,0,0)
        self.qLayout.setSpacing(0)

        self.setLayout(self.qLayout)
        self.qIcon = QtWidgets.QLabel()
        self.qIcon.setAlignment(QtCore.Qt.AlignCenter)
        self.qLayout.addWidget(self.qIcon)
        self.iSize = _kRowHeight * 6 // 7
        self.setIcon(iconSymbols.default)
        self.setMaximumWidth(self.iSize)
        self.setMinimumWidth(self.iSize)
        self.setMaximumHeight(self.iSize)
        self.setMinimumHeight(self.iSize)
        self.resize(self.iSize,self.iSize)
        # self.qIcon.setStyleSheet('background-color: transparent; border: none')
        # self.fLastTime = time.time()

        self.iRotation = 0

    def setIcon(self, iIcon):
        global qLoadingBuilderIcon

        if iIcon == iconSymbols.loading:
            self.rotate()
            qLoadingBuilderIcon = self
        else:
            sImageFile = os.path.join(utils.getToolsDir(), dImages[iIcon])
            self.pixmap = QtGui.QPixmap(sImageFile).scaled(self.iSize,self.iSize)
            self.qIcon.setPixmap(self.pixmap)
            qLoadingBuilderIcon = None


    def rotate(self):

        self.iRotation += 1
        if self.iRotation >= 3:
            self.iRotation = 0

        sImageFile = os.path.join(utils.getToolsDir(), 'buttonBlue%02d.png' % self.iRotation)
        self.pixmap = QtGui.QPixmap(sImageFile).scaled(self.iSize,self.iSize)
        self.qIcon.setPixmap(self.pixmap)






qMenu = QtWidgets.QMenu()


qDetachedMenu = None
def createDetachedButtonMenu(sTitle, dFunctions):
    # print ('dFunctions: ', dFunctions)
    global qDetachedMenu
    qDetachedMenu = QDetachedMenu(sTitle, dFunctions)
    qDetachedMenu.show()



class QDetachedMenu(QtWidgets.QDialog):
    def __init__(self, sTitle, dFunctions):
        super(QDetachedMenu, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        
        _iIndent = 50
        self.setWindowTitle(sTitle)

        def _addButtonOrText(xPair, iIndent=-_iIndent, qLayout=layout):
            if isinstance(xPair[1], (dict, OrderedDict)):
                if xPair[0] != '__start__':
                    qL = QtWidgets.QHBoxLayout()
                    qLayout.addLayout(qL)
                    
                    qSpacer = QtWidgets.QSpacerItem(iIndent, 40)
                    qCheckerButton = QtWidgets.QPushButton('<> %s <>' % xPair[0])
                    qCheckerButton.setCheckable(True)
                    qL.addItem(qSpacer)
                    qL.addWidget(qCheckerButton)
                    qLayout.addLayout(qL)
                    
                    qNewLayout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
                    qFrame = QtWidgets.QFrame()
                    qFrame.setLayout(qNewLayout)
                    qLayout.addWidget(qFrame)
                    
                    def onClicked():
                        qFrame.setHidden(not qCheckerButton.isChecked())
                    qCheckerButton.clicked.connect(onClicked)
                    
                    qFrame.setHidden(True)
                else:
                    qNewLayout = qLayout
                for a,b in xPair[1].items():
                    _addButtonOrText((a,b), iIndent=iIndent+_iIndent, qLayout=qNewLayout)
                    
            elif callable(xPair[1]):
                qButton = QtWidgets.QPushButton(xPair[0])
                qButton.clicked.connect(xPair[1])
                qSpacer = QtWidgets.QSpacerItem(iIndent,40)
                
                qL = QtWidgets.QHBoxLayout()
                qLayout.addLayout(qL)
                qL.addItem(qSpacer)
                qL.addWidget(qButton)
            
        _addButtonOrText(('__start__', dFunctions))
        layout.addStretch()

