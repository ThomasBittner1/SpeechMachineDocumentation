###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.cmds as cmds
import numpy as np
import os
import csv
import subprocess
import json
import math
import kangarooTools.utilFunctions as utils
import kangarooTools.uiSettings as uiSettings
import kangarooTools.report as report
import kangarooTools.nodes as nodes
import kangarooTools.controls as controls
import kangarooTools.xforms as xforms
import kangarooTools.deformers as deformers

from collections import OrderedDict, defaultdict

class MirrorDirection(object):
    leftToRight = 0
    rightToLeft = 1
    flip = 2


class MirrorMode(object):
    vertexIds = 0
    closestVertex = 1



def readCsvFile(sFile):

    xxData = []
    sKeys = []

    with open(sFile) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for r,row in enumerate(csv_reader):
            # print 'row: ', row
            if line_count == 0:
                sKeys = list(row)
                xxData = [[] for i in range(len(sKeys))]
            else:
                for i, item in enumerate(row):
                    xxData[i].append(item)
            line_count += 1

    dData = OrderedDict()
    for k,sK in enumerate(sKeys):
        if k >= 2:
            dData[sK] = [float(fV) for fV in xxData[k]]

    return dData



def _stringTimeToFloat(sTime):
    fSplits = [float(sS) for sS in sTime.split(':')]
    return fSplits[-1] + fSplits[-2]*60.0 + fSplits[-3]*60*60 + fSplits[-4]*60*60*60




dControls = {}
# dControls['sFile'] = controls.FilePathControl('*.trg', sDefaultFileName=r'targets\targets.trg', bReadOnly=False, bShowContent=True, sPossibleFileExtensions=['.csv'], bUpdateFromAsset=False)
# @uiSettings.addToUI(sRunButton='Generate Setup', sTab='Unreal', sModuleButton='CSV Import', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def importAppleBlendshapeCsvSetup(sFilePath=r'MySlate_6_Kangaroos_iPhone.csv', bAlwaysRedoImages=True, bDefaultBlend=1.0):


    dData = readCsvFile(sFilePath)
    fFramesPerSecond, fFrameLength = utils.getFrameRate()
    sDir = os.path.dirname(sFilePath)
    sFilePath = sFilePath.replace('\\\\', '\\')
    sLoc = xforms.createLocator('appleFaceBlendshapes')
    sGrp = cmds.createNode('transform', n='__appleFaceBlendshapeAnims__', p=sLoc)

    # GET JSON INFO
    sJsonFilePath = os.path.join(sDir, 'take.json')
    with open(sJsonFilePath) as file:
        print('loading json file%s..' % sJsonFilePath)
        dJsonData = json.load(file)
        fLength = (_stringTimeToFloat(dJsonData['endTimecode']) - _stringTimeToFloat(dJsonData['startTimecode'])) / 60.0
        iInputFrameCount = len(dData[list(dData.keys())[0]])
        fInputFrameLength = fLength / iInputFrameCount
        fMayaDelta = fInputFrameLength * fFramesPerSecond
        cmds.playbackOptions(e=True, minTime=0.0, maxTime=iInputFrameCount*fMayaDelta)
        utils.data.store('take', dJsonData, sNode=sLoc)


    # ANIMATION
    sBlend = utils.addAttr(sLoc, ln='blend', minValue=0.0, maxValue=1.0, defaultValue=bDefaultBlend, k=True)
    for sAttr, fValues in list(dData.items()):
        sLocAttr = utils.addAttr(sLoc, ln=sAttr, minValue=0.0, maxValue=1.0, k=True)
        sGrpAttr = utils.addAttr(sGrp, ln=sAttr, minValue=0.0, maxValue=1.0, k=True)
        for f,fV in enumerate(fValues):
            cmds.setKeyframe('%s.%s' % (sGrp, sAttr), t=f*fMayaDelta, v=fV)
        nodes.createBlendNode(sBlend, sGrpAttr, 0.0, sTarget=sLocAttr)

    # MOVIE
    sFile = os.path.basename(sFilePath)
    sMovFile = os.path.join(sDir, '%s.mov' % sFile.split('.')[0])
    if not os.path.exists(sMovFile):
        raise Exception('movie file doesn\'t exist: %s' % sMovFile)

    sImageFilesDir = os.path.join(sDir, 'imageFiles')
    bDoImages = False
    if not os.path.exists(sImageFilesDir):
        os.makedirs(sImageFilesDir)
        bDoImages = True
    else:
        if bAlwaysRedoImages:
            bDoImages = True
            sContents = os.listdir(sImageFilesDir)
            for sC in sContents:
                sPathC = os.path.join(sImageFilesDir, sC)
                if os.path.isfile(sPathC):
                    os.remove(sPathC)

    if bDoImages:
        sOutFiles = os.path.join(sImageFilesDir, 'image%d.jpg')
        sCommand = ['ffmpeg', '-i', sMovFile, '-vf', 'fps=%0.3f' % fFramesPerSecond, sOutFiles]
        mpegProcess = subprocess.Popen(
            sCommand, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        sMpegProcessResult = mpegProcess.communicate()
        print(sMpegProcessResult[0])
        print(sMpegProcessResult[1])

    sImagePlane, sImagePlaneShape = cmds.imagePlane(w=float(1080)/1440, h=1)
    cmds.setAttr('%s.imageName' % sImagePlaneShape, os.path.join(sImageFilesDir, 'image1.jpg'), type='string')
    cmds.setAttr('%s.useFrameExtension' % sImagePlaneShape, True)


    # cmds.select(sImagePlane)
    #
    #     sUpdateCommand = 'ShowAttributeEditorOrChannelBox;'
    #     if(`isAttributeEditorRaised`){if(!`isChannelBoxVisible`){setChannelBoxVisible(1);} else {raiseChannelBox;}}else{openAEWindow;};
    #     attributeEditorVisibilityStateChange(`workspaceControl -q -visible AttributeEditor`, "");





kBlendShapeDummySphere = 'emptyBlendshapesSphere'
fLastScale = 1.01

def createEmptyUnrealTargetShape(sTargets):
    sTargets = utils.toList(sTargets)
    global fLastScale

    for sTarget in sTargets:
        fLastScale *= 1.01

        createBlendShapeDummySphereGeometry(sTarget)
        for sA in ['t', 'r', 's', 'tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
            cmds.setAttr('%s.%s' % (sTarget,sA), lock=False)
        cmds.scale(fLastScale, fLastScale, fLastScale, sTarget)
        cmds.makeIdentity(sTarget, s=True, apply=True)

        sTarget = cmds.rename(sTarget, sTarget)
        cmds.addAttr(sTarget, ln=kBlendShapeDummySphere, k=True)


def addEmptyUnrealTargets(sNames, bConnectToDummySphereAndDelete=True):

    # if not cmds.objExists(kBlendShapeDummySphere):
    createOrParentBlendShapeDummySphere()

    sNames = utils.toList(sNames)
    global fLastScale
    fLastScale *= 1.01
    sReturns = []
    for sName in sNames:
        if not cmds.objExists('blendShape__%s.%s' % (kBlendShapeDummySphere,sName)):
            sTarget = cmds.duplicate(kBlendShapeDummySphere)[0]
            for sA in ['t', 'r', 's', 'tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
                cmds.setAttr('%s.%s' % (sTarget,sA), lock=False)
            cmds.scale(fLastScale, fLastScale, fLastScale, sTarget)
            cmds.makeIdentity(sTarget, s=True, apply=True)

            sTarget = cmds.rename(sTarget, sName)
            if bConnectToDummySphereAndDelete:
                if not cmds.attributeQuery(sTarget, node=kBlendShapeDummySphere, exists=True):
                    sReturns += deformers.addBlendShapeTargets(kBlendShapeDummySphere, [sTarget])
                cmds.delete(sTarget)

    if bConnectToDummySphereAndDelete:
        return sReturns

def createBlendShapeDummySphereGeometry(sName):
    return cmds.polySphere(n=sName, ch=False)[0] # try increasing sx and sy if it crashes


def createOrParentBlendShapeDummySphere():

    if not cmds.objExists(kBlendShapeDummySphere):
        createBlendShapeDummySphereGeometry(kBlendShapeDummySphere)

    if not deformers.listAllDeformers(kBlendShapeDummySphere, sFilterTypes=['blendShape']):
        cmds.blendShape(kBlendShapeDummySphere, n='blendShape__%s' % kBlendShapeDummySphere)

    if cmds.objExists('GAMEMODEL'):
        utils.parentTo(kBlendShapeDummySphere, 'GAMEMODEL')
    elif cmds.objExists('GAMESKELETON'):
        utils.parentTo(kBlendShapeDummySphere, 'GAMESKELETON')
    skinBlendShapeDummySphere()


def skinBlendShapeDummySphere():
    if cmds.objExists(kBlendShapeDummySphere):
        if not deformers.listAllDeformers(kBlendShapeDummySphere, sFilterTypes=['skinCluster']):
            if cmds.objExists('GAMESKELETON'):
                sJoints = cmds.listRelatives('GAMESKELETON', ad=True, typ='joint', f=True)
                sJoint = min(sJoints, key=lambda a: len(a))
                try:
                    cmds.skinCluster(kBlendShapeDummySphere, sJoint, tsb=True)
                except Exception as e:
                    cmds.warning('error skinning %s - %s' % (kBlendShapeDummySphere, str(e)))


# kLiveLinkInfo = '__liveLinkInfo__'

def addLiveLinkTarget(sTarget, sParentJoint='jntU_m_headMain'):
    '''
    do not store the return of this function, as the returned joint name will likely change after
    '''
    if not cmds.objExists(sParentJoint):
        raise Exception('parent joint %s doesn\'t exist' % sParentJoint)
    # if not sParentJoint.split('_')[0].endswith('U'):
    #     raise Exception, 'parent joint needs to be an unreal joint (%s)' % sParentJoint

    sLiveLinkTargets = utils.data.get('liveLinkTargets', xDefault=[])
    sLiveLinkJoints = utils.data.get('liveLinkJoints', xDefault=[])

    if sTarget in sLiveLinkTargets:
        report.report.addLogText('there is already a livelink target joint for "%s"' % sTarget)
        return None, None

    iMod = len(sLiveLinkTargets) % 6
    if iMod == 0:
        sJointName = 'liveLink__%d' % len(sLiveLinkJoints)
        sJoint = cmds.createNode('joint', p=sParentJoint, n=sJointName)
        sLiveLinkJoints.append(sJoint)
        sCurrentJointTargets = []
    else:
        sJoint = sLiveLinkJoints[-1]
        sCurrentJointTargets = eval(cmds.getAttr('%s.sTargets' % sJoint))

    sLiveLinkTargets.append(sTarget)
    sCurrentJointTargets.append(sTarget)

    utils.addStringAttr(sJoint, 'sTargets', sCurrentJointTargets)

    utils.data.store('liveLinkTargets', str(sLiveLinkTargets))
    utils.data.store('liveLinkJoints', str(sLiveLinkJoints))

    sAttr = '%s.%s' % (sJoint, ['tx','ty','tz','sx','sy','sz'][iMod])
    sRange = [0,10] if iMod < 3 else [1,5]
    return sAttr, sRange


def connectLiveLinkTarget(sLiveLinkName, sTarget):
    sLivelinkJoints = cmds.ls('liveLink__*', et='joint')
    for sJ in sLivelinkJoints: #liveLink__l_clavicleForward_INV__r_clavicleForward_INV__l_elbowBend_INV__
        sSplits = [sN for sN in sJ.split('__')[1:] if len(sN)]
        if sLiveLinkName in sSplits:
            iIndex = sSplits.index(sLiveLinkName)
            cmds.connectAttr('%s.%s' % (sJ, ['tx','ty','tz'][iIndex]), sTarget)



def printThomasBittnerRiggingNodeLiveLinkCode():
    sUnrealCommands = ''
    sJoints = cmds.ls('liveLink__*', et='joint')
    for sJ in sJoints:
        sTargets = eval(cmds.getAttr('%s.sTargets' % sJ))
        for t,sT in enumerate(sTargets): # maximum 3 Targets
            sRange = '0/10/0/1' if t < 3 else '1/5/0/1'
            sUnrealCommands += '\nVALUEDRIVER %s %s.%s %s %s' % (sT, sJ, ['tx','ty','tz','sx','sy','sz'][t], cmds.listRelatives(sJ, p=True)[0], sRange)

    report.report.addLogText(sUnrealCommands, bPrint=True)




def printAllThomasBittnerRiggingNodeCode():

    sFirstTwistJoints = cmds.ls('jntU_*Twist_000', 'game:jnt_*Twist_000', et='joint')
    printTwistJoints(sFirstTwistJoints)

    sMuscleJoints = [sJ for sJ in cmds.ls('muscleJntU_?_*', 'game:muscleJnt_?_*', et='joint') if not sJ.endswith('End')]
    printThomasBittnerRiggingNodeMuscles(sMuscleJoints)

    sBlendJoints = [sJ for sJ in cmds.ls(et='joint') if cmds.objExists('%s.blendFrom' % sJ) and cmds.objExists('%s.blendTo' % sJ)]
    sBlendJoints = [sJ for sJ in sBlendJoints if sJ.startswith('game:') or sJ.startswith('jntU_')]
    printBlendJoints(sBlendJoints)





# depricated!! shouldn't be used anymore
def skinEmptyTargetSphere(sJoint='jntU_m_spineSpine_000'):
    try:
        cmds.skinCluster(kBlendShapeDummySphere, sJoint)
    except:
        cmds.warning('didn\'t bind %s' % kBlendShapeDummySphere)



def generateBlendShapeValueJointsFromMeshes(sMeshes=[], sParentJoint='jntU_m_headMain'):
    print('sMeshes: ', sMeshes)
    dTargets = defaultdict(list)
    sBlendShapes = []
    for sM in sMeshes:
        sBlendShapes += deformers.listAllDeformers(sM, sFilterTypes=['blendShape'])

    for sBs in sBlendShapes:
        sTargets = deformers.getBlendShapeTargets(sBs)
        for sT in sTargets:
            dTargets[sT].append(sBs)

    for sT,sBlendShapes in list(dTargets.items()):
        print('sT: ', sT)
        sAttr, fRange = addLiveLinkTarget(sT, sParentJoint)
        if sAttr:
            nodes.createRangeNode('%s.%s' % (sBlendShapes[0], sT), 0, 1, fRange[0], fRange[1], sTarget=sAttr)








def printValueJointCommands(sJoints):
    sUnrealCommands = ''
    for sJ in sJoints:
        sTargets = eval(cmds.getAttr('%s.sTargets' % sJ))

        for t,sT in enumerate(sTargets):
            sAxis = ['tx','ty','tz', 'sx', 'sy', 'sz'][t]
            fRange = [0,10] if t < 3 else [1,5]
            sRange = '%d/%d/0/1' % (fRange[0], fRange[1])
            sUnrealCommands += '\nVALUEDRIVER %s %s.%s %s %s' % (sT, sJ, sAxis, cmds.listRelatives(sJ, p=True)[0], sRange)

    report.report.addLogText(sUnrealCommands)




def makeUnrealJointName(sJoint):
    if cmds.namespace(exists='game'):
        return 'game:%s' % sJoint
    else: # legacy naming
        if sJoint.startswith('jnt_'):
            return utils.replaceStringStart(sJoint, 'jnt_', 'jntU_')
        elif sJoint.startswith('muscleJnt_'):
            return utils.replaceStringStart(sJoint, 'muscleJnt_', 'muscleJntU_')


def printThomasBittnerRiggingNodeMuscles(sJoints, bControlRig=False):

    sUnrealCommands = ''

    if bControlRig:
        sUnrealCommands += 'dMuscles = {}'
    for sJ in sJoints:
        # sParents = cmds.listRelatives(sJ, p=True, c=False)

        sEndJ = '%sEnd' % sJ
        if not cmds.objExists(sEndJ):
            raise Exception('%s doesn\'t exist' % sEndJ)
        sStartSpace = makeUnrealJointName(cmds.getAttr('%s.startSpace' % sJ))
        sEndSpace = makeUnrealJointName(cmds.getAttr('%s.endSpace' % sJ))

        fSquashValues = [cmds.getAttr('%s.%s' % (sJ, sA)) for sA in
                         ['squashYPos', 'squashYNeg', 'squashZPos', 'squashZNeg']]
        # sSquashValues = ', '.join('%0.3f' % fV for fV in fSquashValues)

        # start limit. placeholder for if we end up adding it later...
        # sStartParentParent = ''
        # sStartLimitValues = ''

        # end limit
        sEndParentParent = 'None' if bControlRig else 'NONE'
        sEndLimitValues = 'None' if bControlRig else 'NONE'
        sEndParentParentAttr = '%s.endSpaceParent' % sJ
        if cmds.objExists(sEndParentParentAttr):
            sEndParentParent = makeUnrealJointName(cmds.getAttr(sEndParentParentAttr))
            if cmds.objExists(sEndParentParent):
                fEndLimitValues = [cmds.getAttr('%s.%s' % (sJ, sA)) for sA in
                                   ['endLimitMinX', 'endLimitMinY', 'endLimitMinZ', 'endLimitMaxX', 'endLimitMaxY',
                                    'endLimitMaxZ']]
                # in maya it's the space of the joint orient, while in unreal it's the space of the parentparent (sEndParentParent)
                # which means we have to convert it now:
                # outstanding issue: sometimes negative becaomes positive. Gotta figure out what to do then
                aMapAxis = xforms.mapAxisSigned(sEndJ, sEndParentParent)
                aMappedLimitValues = np.array(fEndLimitValues)[aMapAxis]
                for i in range(3): # make sure minimums are smaller than maximums
                    if aMappedLimitValues[i] > aMappedLimitValues[i+3]:
                        aMappedLimitValues[i], aMappedLimitValues[i+3] = aMappedLimitValues[i+3], aMappedLimitValues[i]

                if bControlRig:
                    sEndLimitValues = '[ %s ]' %', '.join('%0.3f' % fV for fV in aMappedLimitValues)
                else:
                    sEndLimitValues = '/'.join('%0.3f' % fV for fV in aMappedLimitValues)

        if bControlRig:
            sUnrealCommands += "\ndMuscles['%s'] = ['%s', '%s', '%s', '%s', %0.3f, %0.3f, %0.3f, %0.3f, None, None, '%s', %s]" % \
                               (sJ.split(':')[-1], sEndJ.split(':')[-1], utils.getSide(sJ), sStartSpace.split(':')[-1], sEndSpace.split(':')[-1], \
                                fSquashValues[0], fSquashValues[1], fSquashValues[2], fSquashValues[3], \
                                sEndParentParent.split(':')[-1], sEndLimitValues)
        else:
            sUnrealCommands += '\nMUSCLE %s %s %s %s %0.3f/%0.3f/%0.3f/%0.3f NONE NONE %s %s' % \
                               (sJ.split(':')[-1], sEndJ.split(':')[-1], sStartSpace.split(':')[-1], sEndSpace.split(':')[-1], \
                                fSquashValues[0], fSquashValues[1], fSquashValues[2], fSquashValues[3], \
                                sEndParentParent.split(':')[-1], sEndLimitValues.split(':')[-1])

    print('sUnrealCommands: ', sUnrealCommands)

    report.report.addLogText(sUnrealCommands)
    return sUnrealCommands


def parentMuscles(sJoints):
    # sJoints = [sJ for sJ in cmds.ls('muscleJntU_?_*', et='joint') if not sJ.endswith('End')]

    print(sJoints)
    sUnrealCommands = ''
    for sJ in sJoints:
        sParents = cmds.listRelatives(sJ, p=True, c=False)

        sEndJ = '%sEnd' % sJ
        if not cmds.objExists(sEndJ):
            raise Exception('%s doesn\'t exist' % sEndJ)
        sStartSpace = makeUnrealJointName(cmds.getAttr('%s.startSpace' % sJ))

        if sParents and sParents[0] != sStartSpace:
            cmds.parent(sJ, sStartSpace)




def leavifyTwistJoints(sFirstTwistJoints):
    for sParentTwist in sFirstTwistJoints:

        sTwist = sParentTwist
        sName = sTwist.split('_')[-2]
        iCounter = 0

        sLeaves = []
        while True:
            print ('sTwist: ', sTwist)
            sChildren = cmds.listRelatives(sTwist, c=True, p=False) or []
            sTwist = None
            for sChild in sChildren:
                if sName in sChild and not sChild.endswith('Blend'):
                    sTwist = sChild

            if iCounter > 0:
                if sTwist != None:
                    cmds.parent(sTwist, sParentTwist)
                else:
                    cmds.parent(sChildren, sParentTwist)

            iCounter += 1
            if sTwist == None:
                sChild = sChildren[0]
                break

            sLeaves.append(sTwist)

        utils.addStringAttr(sParentTwist, 'sTwistChild', sChild)




def printTwistJoints(sFirstTwistJoints):
    sUnrealCommands = ''
    iCommandsCounter = 0
    for sParentTwist in sFirstTwistJoints:
        sSplits = sParentTwist.split('_')
        sSide, sLimb, sPartFull = sSplits[1], sSplits[2], sSplits[3]
        sPart = utils.replaceStringEnd(sPartFull, 'Twist', '')

        # sTwist = sParentTwist
        # sName = sTwist.split('_')[-2]
        # iCounter = 0

        sLeaves = cmds.ls('%s_???' % sParentTwist[:-4], et='joint')
        sLeaves = sorted(sLeaves)[1:]
        sLeaveNames = [sL.split(':')[-1] for sL in sLeaves]
        sChild = cmds.getAttr('%s.sTwistChild' % sParentTwist)
        sParent = cmds.listRelatives(sParentTwist, p=True, c=False)[0]
        sUnrealCommands += '\nTWIST %s %s %s %s %s %s' % \
                      (sParentTwist.split(':')[-1], sParent.split(':')[-1], sChild.split(':')[-1],
                       'true' if sPart == 'upper' else 'false',
                       'true' if sLimb == 'arm' else 'false',
                       ' '.join(sLeaveNames ))
        iCommandsCounter += 1

    print(sUnrealCommands)
    report.report.addLogText(sUnrealCommands)






def printBlendJoints(sBlends):
    print('blend joints... ', sBlends)
    sUnrealCommands = ''

    for sJ in sBlends:
        sTargets = [cmds.getAttr('%s.blendFrom' % sJ), cmds.getAttr('%s.blendTo' % sJ)]
        sWeight1 = cmds.getAttr('%s.blendWeight' % sJ)
        fWeight1 = float(sWeight1)

        sTarget0 = makeUnrealJointName(sTargets[0].split(':')[-1])
        sTarget1 = makeUnrealJointName(sTargets[1].split(':')[-1])
        sUnrealCommands += '\nBLEND %s %s %s %0.3f' % (sJ.split(':')[-1] , sTarget0.split(':')[-1], sTarget1.split(':')[-1], fWeight1)
        sCurrentParent = cmds.listRelatives(sJ, p=True, c=False)
        print('================== ', sJ, '... sCurrentParent: ', sCurrentParent)
        # if not sCurrentParent or sCurrentParent[0] != sTarget0:
        #     cmds.parent(sJ, sTarget0)

    print(sUnrealCommands)
    report.report.addLogText(sUnrealCommands)




def unrealifyJointHierarchy2(sRoot, bCollapseUnrealJoints=False):
    '''
    remove segmentsScaleCompensate, and get rid of extra group parents
    '''

    sNamespace = utils.getNamespace(sRoot)
    sNodes = cmds.listRelatives(sRoot, ad=True)
    for sN in sNodes:
        if 'shape' in cmds.nodeType(sN, i=True):
            cmds.delete(sN)
        else:
            cmds.setAttr('%s.s' % sN, 1,1,1)
    sNodes = cmds.listRelatives(sRoot, ad=True)
    sTypes = cmds.ls(sNodes, showType=True)
    dTypes = {sTypes[i]: sTypes[i + 1] for i in range(0, len(sTypes), 2)}

    # for collapsing (bCollapseUnrealJoints):
    # slave refers to joints getting deleted, master refers to joints getting kept
    sAllUnrealSlaveJoints = []
    sAllUnrealMasterJoints = []
    dSlaveJoints = {} # slaves are the values, masters are the keys
    dMasterJoints = {} # masters are the values, slaves are the keys


    for sN in sNodes:
        sUnrealRemoveJointsAttr = '%s.unrealCollapseJoints' % sN
        if cmds.objExists(sUnrealRemoveJointsAttr):
            sJoints = eval(cmds.getAttr(sUnrealRemoveJointsAttr))
            sConvertedCollapseJoints = ['%s%s' % (sNamespace,sJ) for sJ in sJoints]
            sAllUnrealSlaveJoints += sConvertedCollapseJoints
            sAllUnrealMasterJoints.append(sN)
            dSlaveJoints[sN] = sConvertedCollapseJoints

            for _sJ in sConvertedCollapseJoints:
                dMasterJoints[_sJ] = sN

        _sParent = sN
        if cmds.objectType(sN) == 'joint':
            cmds.setAttr('%s.segmentScaleCompensate' % sN, False)

        sOldParent = cmds.listRelatives(sN, p=True, c=False)[0]
        while True:
            _sParent = cmds.listRelatives(_sParent, p=True, c=False)[0]
            if _sParent == sRoot or dTypes[_sParent] == 'joint':
                sNewParent = _sParent
                break
        if sNewParent != None and sNewParent != sOldParent:
            cmds.parent(sN, sNewParent)

    sDelete = [sN for sN in sNodes if dTypes[sN] != 'joint']
    cmds.delete(sDelete)


    cmds.select(sAllUnrealSlaveJoints)



    for sSlave, sMaster in list(dMasterJoints.items()):
        utils.addStringAttr(sSlave, 'sUnrealCollapseTo', sMaster)
        utils.addStringAttr(utils.replaceStringStart(sSlave, sNamespace, ''), 'sUnrealCollapseTo', utils.replaceStringStart(sMaster, sNamespace, ''))


    if bCollapseUnrealJoints:
        for sJ in sAllUnrealMasterJoints:
            fMatrix = cmds.xform(sJ, q=True, m=True, ws=True)

            sDeleteJoints = dSlaveJoints[sJ]

            _sParent = cmds.listRelatives(sJ, p=True)[0]
            # find the next one not in the list
            while True:
                if _sParent not in sDeleteJoints:
                    break
                _sParent = cmds.listRelatives(_sParent, p=True)[0]


            # _sParent is now first joint not inside the joint's collapse list


            if _sParent in sAllUnrealSlaveJoints:
                # if _sParent is also getting deleted, we need to check all its children to find one where we can parent sJ to
                iCounter = 0
                sFoundJoint = None

                sChildrenLn = cmds.listRelatives(_sParent, ad=True, f=True)
                sChildrenLn.sort(key=lambda a:len(a))

                for sChildLn in sChildrenLn:
                    bIsChildOfItself = False
                    for _sJ in ([sJ] + dSlaveJoints[sJ]):
                        if _sJ in sChildLn:
                            bIsChildOfItself = True
                            continue
                    if bIsChildOfItself:
                        continue

                    sChild = sChildLn.split('|')[-1]
                    if sChild not in sAllUnrealSlaveJoints:
                        sFoundJoint = sChild
                        break
                    iCounter += 1

                if not sFoundJoint:
                    raise Exception('not found for %s' % sJ)
                else:
                    print('found Joint: %s' % sJ)
            else:
                sFoundJoint = _sParent

            cmds.parent(sJ, sFoundJoint)
            cmds.xform(sJ, m=fMatrix, ws=True)


        # now let's take care of the remaining children of the slave joints
        for sJ in sAllUnrealSlaveJoints:
            for sChild in cmds.listRelatives(sJ, c=True) or []:
                if sChild not in sAllUnrealSlaveJoints:
                    cmds.parent(sChild, dMasterJoints[sJ])


        # and finally delete the slave joints
        cmds.delete(sAllUnrealSlaveJoints)


    # cmds.setAttr('%s.v' % sRoot, True)





def unrealifyJointHierarchy(sRoot, bCollapseUnrealJoints=False, bNamespace=False):
    '''
    remove segmentsScaleCompensate, and get rid of extra group parents
    '''
    sNodes = cmds.listRelatives(sRoot, ad=True)
    for sN in sNodes:
        if 'shape' in cmds.nodeType(sN, i=True):
            cmds.delete(sN)
        else:
            cmds.setAttr('%s.s' % sN, 1,1,1)
    sNodes = cmds.listRelatives(sRoot, ad=True)
    sTypes = cmds.ls(sNodes, showType=True)
    dTypes = {sTypes[i]: sTypes[i + 1] for i in range(0, len(sTypes), 2)}

    # for collapsing (bCollapseUnrealJoints):
    # slave refers to joints getting deleted, master refers to joints getting kept
    sAllUnrealSlaveJoints = []
    sAllUnrealMasterJoints = []
    dSlaveJoints = {} # slaves are the values, masters are the keys
    dMasterJoints = {} # masters are the values, slaves are the keys


    for sN in sNodes:
        sUnrealRemoveJointsAttr = '%s.unrealCollapseJoints' % sN
        if cmds.objExists(sUnrealRemoveJointsAttr):
            sJoints = eval(cmds.getAttr(sUnrealRemoveJointsAttr))
            if bNamespace:
                sConvertedCollapseJoints = sJoints
            else:
                sConvertedCollapseJoints = [utils.replaceStringStart(sJ, 'jnt_', 'jntU_') for sJ in sJoints]
            sAllUnrealSlaveJoints += sConvertedCollapseJoints
            sAllUnrealMasterJoints.append(sN)
            dSlaveJoints[sN] = sConvertedCollapseJoints

            for _sJ in sConvertedCollapseJoints:
                dMasterJoints[_sJ] = sN

        _sParent = sN
        if cmds.objectType(sN) == 'joint':
            cmds.setAttr('%s.segmentScaleCompensate' % sN, False)

        sOldParent = cmds.listRelatives(sN, p=True, c=False)[0]
        while True:
            _sParent = cmds.listRelatives(_sParent, p=True, c=False)[0]
            if _sParent == sRoot or dTypes[_sParent] == 'joint':
                sNewParent = _sParent
                break
        if sNewParent != None and sNewParent != sOldParent:
            cmds.parent(sN, sNewParent)

    sDelete = [sN for sN in sNodes if dTypes[sN] != 'joint']
    cmds.delete(sDelete)


    cmds.select(sAllUnrealSlaveJoints)



    for sSlave, sMaster in list(dMasterJoints.items()):
        utils.addStringAttr(sSlave, 'sUnrealCollapseTo', sMaster)
        utils.addStringAttr(utils.replaceStringStart(sSlave, 'jntU_', 'jnt_'), 'sUnrealCollapseTo', utils.replaceStringStart(sMaster, 'jntU_', 'jnt_'))


    if bCollapseUnrealJoints:
        for sJ in sAllUnrealMasterJoints:
            fMatrix = cmds.xform(sJ, q=True, m=True, ws=True)

            sDeleteJoints = dSlaveJoints[sJ]

            _sParent = cmds.listRelatives(sJ, p=True)[0]
            # find the next one not in the list
            while True:
                if _sParent not in sDeleteJoints:
                    break
                _sParent = cmds.listRelatives(_sParent, p=True)[0]


            # _sParent is now first joint not inside the joint's collapse list


            if _sParent in sAllUnrealSlaveJoints:
                # if _sParent is also getting deleted, we need to check all its children to find one where we can parent sJ to
                iCounter = 0
                sFoundJoint = None

                sChildrenLn = cmds.listRelatives(_sParent, ad=True, f=True)
                sChildrenLn.sort(key=lambda a:len(a))

                for sChildLn in sChildrenLn:
                    bIsChildOfItself = False
                    for _sJ in ([sJ] + dSlaveJoints[sJ]):
                        if _sJ in sChildLn:
                            bIsChildOfItself = True
                            continue
                    if bIsChildOfItself:
                        continue

                    sChild = sChildLn.split('|')[-1]
                    if sChild not in sAllUnrealSlaveJoints:
                        sFoundJoint = sChild
                        break
                    iCounter += 1

                if not sFoundJoint:
                    raise Exception('not found for %s' % sJ)
                else:
                    print('found Joint: %s' % sJ)
            else:
                sFoundJoint = _sParent

            cmds.parent(sJ, sFoundJoint)
            cmds.xform(sJ, m=fMatrix, ws=True)


        # now let's take care of the remaining children of the slave joints
        for sJ in sAllUnrealSlaveJoints:
            for sChild in cmds.listRelatives(sJ, c=True) or []:
                if sChild not in sAllUnrealSlaveJoints:
                    cmds.parent(sChild, dMasterJoints[sJ])


        # and finally delete the slave joints
        cmds.delete(sAllUnrealSlaveJoints)


    # cmds.setAttr('%s.v' % sRoot, True)

