###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.cmds as cmds
import numpy as np
import os
import pickle
import kangarooTools.report as report
import kangarooTools.utilFunctions as utils
import kangarooTools.uiSettings as uiSettings
import kangarooTools.deformers as deformers
import kangarooTools.nodes as nodes
import kangarooTools.patch as patch
import kangarooTools.controls as controls
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTools.assets as assets
import kangarooTools.barycentric as barycentric
from collections import defaultdict
from functools import reduce

class MirrorDirection(object):
    leftToRight = 0
    rightToLeft = 1
    flip = 2


class MirrorMode(object):
    vertexIds = 0
    closestVertex = 1
    closestPoint = 2


dControls = {}
dControls['iDirection'] = controls.RadioButtonsControl(MirrorDirection)
dControls['iMode'] = controls.RadioButtonsControl(MirrorMode)
dControls['sMiddleEdge'] = controls.MiddleEdgeControl()
dControls['sBaseMesh'] = controls.SelectionControl(bList=False)
dControls['sPositionMesh'] = controls.SelectionControl(bList=False)

@uiSettings.addToUI(sRunButton='Mirror', sTab='Geometry', sModuleButton='MirrorMiddle', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#mirror')
def meshMirrorMiddle(_pSelection=None, iDirection=MirrorDirection.leftToRight, iMode=MirrorMode.vertexIds, sMiddleEdge=None, sBaseMesh=None, sPositionMesh=None, bInPlace=True, bWorld=False, bBaseAsOrig=True, bMatrixOnBase=False):
    sSelBefore = cmds.ls(sl=True)
    
    
    cmds.undoInfo(openChunk=True)
    try:
        if sMiddleEdge:
            iMiddleEdge = utils.intFromComponent(sMiddleEdge)
        else:
            iMiddleEdge = None

        if sBaseMesh:
            xBaseSpaces = [None] * cmds.polyEvaluate(sBaseMesh, vertex=True)

        report.report.resetProgress(len(_pSelection or patch.getSelectedPatches()))
        pReturns = []
        for pSelected in _pSelection or patch.getSelectedPatches():
            pBase = patch.patchFromName(sBaseMesh) if sBaseMesh else None
            pPosition = patch.patchFromName(sPositionMesh) if sPositionMesh else None
        
            if pPosition: pTablePatch = pPosition
            elif pBase: pTablePatch = pBase
            else: pTablePatch = pSelected


            aTarget = pSelected.getAllPoints(bWorld=bWorld)
            aBase = pBase.getAllPoints(bWorld=bWorld, bOrig=bBaseAsOrig) if pBase else None

            if not isinstance(aBase, type(None)):
                iSmallerCount = min(len(aTarget), len(aBase))
                aTarget = aTarget[:iSmallerCount]
                aBase = aBase[:iSmallerCount]



            aMirrored = np.copy(aTarget)

            if iMode == MirrorMode.closestPoint:
                aFaceVerticesAll, aCoordsAll, aSide = pTablePatch.getMirrorTablePointsOnFaces()

                if iDirection == MirrorDirection.flip:
                    aChangeIds = pSelected.aIds
                else:
                    aChangeIds = np.array(np.where(aSide == (2 if iDirection == MirrorDirection.leftToRight else 1))[0], dtype=int)
                    aChangeIds = np.intersect1d(aChangeIds, pSelected.aIds)

                if not utils.isNone(aBase):
                    aDiffsPlusZero = np.concatenate([aTarget-aBase, [[0,0,0]]])
                else:
                    aDiffsPlusZero = np.concatenate([aTarget, [[0,0,0]]])

                aMultiplied = aDiffsPlusZero[aFaceVerticesAll[aChangeIds]] * aCoordsAll[aChangeIds][..., np.newaxis]
                aSum = np.sum(aMultiplied, axis=1)
                aSum[:,0] *= -1.0

                if not utils.isNone(aBase):
                    aMirrored[aChangeIds] = aBase[aChangeIds] + aSum
                else:
                    aMirrored[aChangeIds] = aSum

            else:
                aTable, aSide = pTablePatch.getMirrorTable(bIds = True if iMode==MirrorMode.vertexIds else False, iMiddleEdge=iMiddleEdge)

                if iDirection == MirrorDirection.flip:
                    aChangeIds = pSelected.aIds
                else:
                    aChangeIds = np.array(np.where(aSide == (2 if iDirection == MirrorDirection.leftToRight else 1))[0], dtype=int)
                    aChangeIds = np.intersect1d(aChangeIds, pSelected.aIds)

                aDiff = (aTarget - aBase) if not utils.isNone(aBase) and not bMatrixOnBase else np.copy(aTarget)
                aDiff[:, 0] *= -1
                aDiffSelected = aDiff[aTable]

                if not utils.isNone(aBase):
                    if bMatrixOnBase: # first we mirror without diffs, and then we apply the diffs in matrix space
                        if iMode == MirrorMode.closestPoint:
                            raise Exception('Matrix On Base is not supported for closestPoint. Use ClosestVertex or VertexId instead')
                        aMirrored[aChangeIds] = aDiffSelected[aChangeIds]

                        aBaseMirrored = aBase[aTable]
                        aBaseMirrored[:,0] *= -1.0
                        mBaseVertexIter = OpenMaya2.MItMeshVertex(pBase.mDagPath)
                        aBasePoints4 = utils.makePoint4Array(aBase[aChangeIds])

                        for iInd, iId in enumerate(aChangeIds):
                            if utils.isNone(xBaseSpaces[iId]):
                                mBaseVertexIter.setIndex(int(iId))
                                # aNormal = np.array(mBaseVertexIter.getNormal(), dtype='float64')
                                iNeighborIds = np.array(mBaseVertexIter.getConnectedVertices(), dtype=int)
                                aTriangleNormals = np.zeros((len(iNeighborIds),3), dtype='float64')
                                aLocalNeighborPoints = aBaseMirrored[iNeighborIds] - aBaseMirrored[iId]
                                aNeighborDistances = np.linalg.norm(aLocalNeighborPoints, axis=-1)
                                fAverageNeighborDistance = np.average(aNeighborDistances)
                                for i in range(len(iNeighborIds)):
                                    aTriangleNormals[i] = np.cross(aLocalNeighborPoints[i], aLocalNeighborPoints[(i+1) % len(iNeighborIds)])
                                aNormal = np.sum(aTriangleNormals, axis=0)
                                aNormal *= -fAverageNeighborDistance / np.linalg.norm(aNormal)
                                aLocalPoints = aBaseMirrored[iNeighborIds] - aBaseMirrored[iId]
                                iBiggestNeighbordInd = np.argmax(np.linalg.norm(aLocalPoints, axis=1))
                                iBiggestId = iNeighborIds[iBiggestNeighbordInd]

                                aBaseMirroredMatrix = utils.getOrthoMatrixFromVectors(aBaseMirrored[iId], aNormal, aBaseMirrored[iBiggestId])
                                aLocalBaseInMirrored4 = np.dot(aBasePoints4[iInd], np.linalg.inv(aBaseMirroredMatrix))
                                xBaseSpaces[iId] = [aBaseMirroredMatrix, aLocalBaseInMirrored4, iId, iBiggestId, iNeighborIds]


                        aTargetPoints = np.copy(aMirrored)
                        for iInd, iId in enumerate(aChangeIds):
                            aBaseMirroredMatrix, aLocalBaseInMirrored4, iId, iBiggestId, iNeighborIds = xBaseSpaces[iId]
                            aTriangleNormals = np.zeros((len(iNeighborIds), 3), dtype='float64')

                            aLocalNeighborPoints = aTargetPoints[iNeighborIds] - aTargetPoints[iId]
                            aNeighborDistances = np.linalg.norm(aLocalNeighborPoints, axis=-1)
                            fAverageNeighborDistance = np.average(aNeighborDistances)
                            for i in range(len(iNeighborIds)):
                                aTriangleNormals[i] = np.cross(aLocalNeighborPoints[i], aLocalNeighborPoints[(i+1) % len(iNeighborIds)])
                            aTargetNormal = np.sum(aTriangleNormals, axis=0)
                            aTargetNormal *= -fAverageNeighborDistance / np.linalg.norm(aTargetNormal)

                            aTargetMatrix = utils.getOrthoMatrixFromVectors(aTargetPoints[iId], aTargetNormal, aTargetPoints[iBiggestId])

                            aNewPoint = np.dot(aLocalBaseInMirrored4, aTargetMatrix)[0:3]
                            aMirrored[iId] = aNewPoint
                    else:
                        aMirrored[aChangeIds] = aBase[aChangeIds] + aDiffSelected[aChangeIds]
                else:
                    aMirrored[aChangeIds] = aDiffSelected[aChangeIds]

            if iDirection != MirrorDirection.flip:
                aMiddleChangeIds = np.array(np.where(aSide == 0)[0], dtype=int)
                aMiddleChangeIds = np.intersect1d(aMiddleChangeIds, pSelected.aIds)
                aMirrored[aMiddleChangeIds,0] = 0.0

            if not utils.isNone(pSelected.aSofts):# != None:
                aSoftAll = np.ones(pSelected.getTotalCount())
                aSoftAll[pSelected.aIds] = np.array(pSelected.aSofts, dtype='float64')
                aSoft2d = aSoftAll[:,np.newaxis]
                aMirrored = np.multiply(aMirrored, aSoft2d) + np.multiply(aTarget,1-aSoft2d)

            if not bInPlace:
                sTarget = cmds.duplicate(pSelected.getName())[0]
                pSelected = patch.patchFromName(sTarget)

            aVects = (aMirrored-aTarget)
            aSums = np.sum(np.square(aVects), axis=1)
            aDifferentIds = np.array(np.where(aSums > 0.0000000001)[0], dtype=int)

            pSelected.setPoints(aMirrored[aDifferentIds], aIds=aDifferentIds, bWorld=bWorld)
            
            report.report.incrementProgress(bRefresh=True)

            pReturns.append(pSelected)

        # cmds.select(sSelBefore)
        return pReturns
    except:
        raise
    finally:
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)



dControls = {}
dControls['sFromMesh'] = controls.SelectionControl(bList=False)
dControls['sBaseFromMesh'] = controls.SelectionControl(bList=False)
dControls['sBaseMesh'] = controls.SelectionControl(bList=False)

# to do: make work with vertex selection including soft values
# @uiSettings.addToUI(sRunButton='Mirror', sTab='Geometry', sModuleButton='MirrorSide', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def meshMirrorSide(sBaseMesh=None, sFromMesh=None, sBaseFromMesh=None, bWorld=False):

    for pSelected in patch.getSelectedPatches():
        pBase = patch.patchFromName(sBaseMesh)
        pFrom = patch.patchFromName(sFromMesh)
        pBaseFrom = patch.patchFromName(sBaseFromMesh)
        
        aSelected = pSelected.getAllPoints(bWorld=bWorld)
        aBase = pBase.getAllPoints(bWorld=bWorld)
        aFrom = pFrom.getAllPoints(bWorld=bWorld)
        aBaseFrom = pBaseFrom.getAllPoints(bWorld=bWorld)
        
        aDiff = aFrom-aBaseFrom
        aDiff[:,0] *= -1

        aMirrored = aBase + aDiff
        
        '''
        if fSoftValues != None:
            aSoftAll = np.ones(iVertexCount)
            aSoftAll[aIds] = np.array(fSoftValues, dtype='float64')
            aSoft2d = aSoftAll[:,np.newaxis]
            aMirrored = np.multiply(aMirrored, aSoft2d) + np.multiply(aMesh,1-aSoft2d)
        '''
        
        aVects = (aMirrored-aSelected)
        aSums = np.sum(np.square(aVects), axis=1)
        aDifferentIds = np.array(np.where(aSums > 0.0000000001)[0], dtype=int)
        pSelected.setPoints(aMirrored[aDifferentIds], aDifferentIds, bWorld=bWorld)




dControls = {}
dControls['iDirectionIfMiddleMesh'] = controls.RadioButtonsControl(MirrorDirection)
dControls['iMode'] = controls.RadioButtonsControl(MirrorMode)
dControls['sMiddleEdge'] = controls.MiddleEdgeControl()

@uiSettings.addToUI(sRunButton='Mirror', sTab='Geometry', sModuleButton='MirrorNoBase', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#mirror')
def meshMirrorNoBase(_pSelection=None, iDirectionIfMiddleMesh=MirrorDirection.leftToRight, sMiddleEdge=None, bReverseNurbs=False, bWorld=False, _report=None):
    '''
    For side objects (l_* or r_*) he looks for the other mesh, and
    manipulates that to look like the selected meshes. If the other
    mesh doesn't exist, he'll create it.

    '''
    # to do: mirroring hierarchy doesn't work properly (stuff still being parented to old ones)
    sReturn = []
    try:
        cmds.undoInfo(openChunk=True)
        sSelBefore = cmds.ls(sl=True)

        pPatches = _pSelection or patch.getSelectedPatches()

        if _report:
            _report.resetProgress(len(pPatches))

        for pSelected in pPatches:
            if _report:
                _report.incrementProgress()

            sMesh = pSelected.getTransformName()
            sOpp = utils.getMirrorName(sMesh)

            if sMesh == sOpp: #middle
                meshMirrorMiddle(_pSelection=[pSelected], iDirection=iDirectionIfMiddleMesh, iMode=MirrorMode.vertexIds, sMiddleEdge=sMiddleEdge, bInPlace=True, bWorld=True)
            else: # side
                bNewMesh = False
                if not cmds.objExists(sOpp):
                    sOpp = cmds.duplicate(sMesh, name=sOpp)[0]
                    sChildren = cmds.listRelatives(sOpp, c=True, f=True)
                    if sChildren: cmds.delete([sC for sC in sChildren if cmds.objectType(sC) not in ['mesh', 'nurbsCurve', 'nurbsSurface']])
                    bNewMesh = True

                pOpp = patch.patchFromName(sOpp)
                aPoints = pSelected.getAllPoints(bWorld=bWorld)
                aPoints[:,0] *= -1.0
                if bReverseNurbs and isinstance(pSelected, patch.SurfacePatch):
                    aPoints = aPoints[pSelected.getReverseIndices()]

                if not bNewMesh and isinstance(pOpp, (patch.CurvePatch, patch.SurfacePatch)):
                    pOpp.matchTopology(pSelected)
                pOpp.setPoints(aPoints, bWorld=bWorld)
                sReturn.append(sOpp)
            cmds.select(sSelBefore)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)

    return sReturn

@uiSettings.addToUI(sRunButton='Make Symmetric', sTab='Geometry', sModuleButton='Symmetry', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#create-symmetry-mesh')
def meshCreateSymmetry(_pSelection=None, sMiddleEdge=None, _report=None):
    utils.reload2(patch)
    try:
        cmds.undoInfo(openChunk=True)
        sSelBefore = cmds.ls(sl=True)

        pPatches = _pSelection or patch.getSelectedPatches()

        if _report:
            _report.resetProgress(len(pPatches))

        for pSelected in pPatches:
            if _report:
                _report.incrementProgress()

            sMesh = pSelected.getTransformName()
            pMesh = patch.patchFromName(sMesh)
            aPoints = pMesh.getPoints()
            if sMiddleEdge:
                iMiddleEdge = utils.intFromComponent(sMiddleEdge)
            else:
                iMiddleEdge = None

            aTable, aSide = pMesh.getMirrorTable(bIds=True,iMiddleEdge=iMiddleEdge)
            aMiddlePoints = np.where(aSide == 0)[0]
            aPoints[aMiddlePoints,0] = 0.0

            aLeftPoints = np.where((aSide == 1) & (aTable != -1))[0]
            aRightPoints = aTable[aLeftPoints]
            aPoints[aLeftPoints, 0] = (aPoints[aLeftPoints, 0] - aPoints[aRightPoints, 0]) * 0.5
            aPoints[aLeftPoints, 1] = (aPoints[aLeftPoints, 1] + aPoints[aRightPoints, 1]) * 0.5
            aPoints[aLeftPoints, 2] = (aPoints[aLeftPoints, 2] + aPoints[aRightPoints, 2]) * 0.5

            aPoints[aRightPoints, 0] = aPoints[aLeftPoints, 0] * -1
            aPoints[aRightPoints, 1] = aPoints[aLeftPoints, 1]
            aPoints[aRightPoints, 2] = aPoints[aLeftPoints, 2]

            pMesh.setPoints(aPoints)

    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)




def _turnOffDeformerAndSave(sDeformer, dSaveDict={}):
    if sDeformer in dSaveDict:
        return

    sEnvelope = '%s.envelope' % sDeformer
    sConns = cmds.listConnections(sEnvelope, s=True, d=False, p=True)
    if sConns:
        dSaveDict[sDeformer] = sConns[0]
        cmds.disconnectAttr(sConns[0], sEnvelope)
    else:
        dSaveDict[sDeformer] = cmds.getAttr(sEnvelope)

    cmds.setAttr(sEnvelope, 0)



def calculateComboShape(sSculpt=None, sSkin=None, sComboBlendShape=None, sInvertName=''):

    if not cmds.objExists(sSculpt):
        raise Exception('sculpt shape %s doesn\'t exist' % sSculpt)

    if not sInvertName:
        if sSculpt.endswith('_posed'):
            utils.replaceStringEnd(sSculpt, '_posed', '_inverted')

    if sComboBlendShape == None:
        sBlendShapes = deformers.listAllDeformers(sSkin, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sComboBlendShape = sBlendShapes[0]
        else:
            sComboBlendShape = None

    pSculpt = patch.patchFromName(sSculpt)
    pSkin = patch.patchFromName(sSkin)

    if pSculpt.getTotalCount() != pSkin.getTotalCount():
        cmds.warning('%s and %s don\'t have the same vertex count (%d -> %d)' % (sSculpt, sSkin, pSculpt.getTotalCount(), pSkin.getTotalCount()))

    iSculptCount = pSculpt.getTotalCount()
    iSkinCount = pSkin.getTotalCount()
    iSmallerCount = min(iSculptCount, iSkinCount)

    aSculptTotal = pSculpt.getPoints()[:iSmallerCount]
    cmds.setAttr('%s.envelope' % sComboBlendShape, 1.0)
    aSkinTotal = np.array(pSkin.getPoints()[:iSmallerCount])

    cmds.setAttr('%s.envelope' % sComboBlendShape, 0.0)
    aSkinTotalNoBlendShape = np.array(pSkin.getPoints()[:iSmallerCount])
    cmds.setAttr('%s.envelope' % sComboBlendShape, 1.0)

    aComboPoints = aSkinTotalNoBlendShape + (aSculptTotal-aSkinTotal)

    sDupl = cmds.duplicate(sSkin, name=sInvertName)[0]
    utils.parentToWorld(sDupl)

    patch.patchFromName(sDupl).setPoints(aComboPoints)

    utils.freezeGeo(sDupl)
    return sDupl



def invertShapeDeformers(sSculpt=None, sSkin=None, sComboBlendShape=None, sInvertName=''):

    if not cmds.objExists(sSculpt):
        raise Exception('sculpt shape %s doesn\'t exist' % sSculpt)

    if not sInvertName:
        if sSculpt.endswith('_posed'):
            utils.replaceStringEnd(sSculpt, '_posed', '_inverted')

    if sComboBlendShape == True:
        sBlendShapes = deformers.listAllDeformers(sSkin, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sComboBlendShape = sBlendShapes[0]
        else:
            sComboBlendShape = None


    sAllDeformers = deformers.listAllDeformers(sSkin)

    pSculpt = patch.patchFromName(sSculpt)
    pSkin = patch.patchFromName(sSkin)

    if pSculpt.getTotalCount() != pSkin.getTotalCount():
        cmds.warning('%s and %s don\'t have the same vertex count (%d -> %d)' % (sSculpt, sSkin, pSculpt.getTotalCount(), pSkin.getTotalCount()))


    dDeformerEnvelopes = {}

    for d, sDeformer in enumerate(sAllDeformers):
        if cmds.objectType(sDeformer) == 'blendShape' and cmds.getAttr('%s.envelope' % sDeformer) > 0.0 and sComboBlendShape != sDeformer:
            _turnOffDeformerAndSave(sDeformer, dDeformerEnvelopes)


    # create calculateMeshDELETEME and assign as temporary blendShape
    sDeformers = deformers.listAllDeformers(pSkin.getTransformName())
    dPreviousNodeStates = {}
    for sD in sDeformers:
        dPreviousNodeStates[sD] = cmds.getAttr('%s.nodeState' % sD)
        cmds.setAttr('%s.nodeState' % sD, 1)

    sMeshCalculate = utils._duplicateGeoClean(sSkin, sName='calculateMeshDELETEME')
    pMeshCalculate = patch.patchFromName(sMeshCalculate)
    for sD in sDeformers:
        cmds.setAttr('%s.nodeState' % sD, dPreviousNodeStates[sD])

    sCalculateBlendShape = deformers.preDeformationBlendshapeHack(sMeshCalculate, sSkin, w=[0,1],
                                                               n='calculateBlendShapeDELETEME')[0]

    iSculptCount = pSculpt.getTotalCount()
    iSkinCount = pSkin.getTotalCount()
    iSmallerCount = min(iSculptCount, iSkinCount)

    if pSkin.__class__ == patch.CurvePatch:
        fnMeshCalculate = OpenMaya2.MFnNurbsCurve(pMeshCalculate.mDagPath)
        mCalculatePointsClean = fnMeshCalculate.cvPositions()
    else:
        fnMeshCalculate = OpenMaya2.MFnMesh(utils.getDagPath(pMeshCalculate.mDagPath))
        mCalculatePointsClean = fnMeshCalculate.getPoints()

    # mCalculatePoints = OpenMaya2.MPointArray(mCalculatePointsClean)
    # mDefaultCalculatePoints = OpenMaya2.MPointArray(mCalculatePointsClean) #OpenMaya2.MPointArray(mCalculatePoints)

    if sComboBlendShape:
        aCalculateCleanTotal = pMeshCalculate.getPoints()[:iSculptCount]

        fOldComboBlendShapeEnvelope = cmds.getAttr('%s.envelope' % sComboBlendShape)
        cmds.setAttr('%s.envelope' % sComboBlendShape, False)

    aSculptTotal = pSculpt.getPoints()[:iSmallerCount]
    aSkinTotal = pSkin.getPoints()[:iSmallerCount]

    aDiffSqr = np.sum(np.square(aSculptTotal - aSkinTotal), axis=1)
    aIdsCalculate = np.where(aDiffSqr > 0.0000001)[0]
    aSculpt = aSculptTotal[aIdsCalculate]
    aSkin = aSkinTotal[aIdsCalculate]

    try:
        cmds.undoInfo(openChunk=True)
        # first move all verts into the 3 directions and store their positions
        aMoves = np.zeros((3,aIdsCalculate.size,3), dtype='float64')
        for a in [0,1,2]:
            if False: # old way - faster, doesn't work with 2022. to use it, uncomment mCalculatePoints = OpenMaya2.MPointArray...
                if a == 0:
                    for aId in aIdsCalculate:
                        mCalculatePoints[aId].x += 1
                else:
                    mCalculatePoints = OpenMaya2.MPointArray(mCalculatePointsClean)
                    if a == 1:
                        for aId in aIdsCalculate:
                            mCalculatePoints[aId].y += 1
                    if a == 2:
                        for aId in aIdsCalculate:
                            mCalculatePoints[aId].z += 1

            else: # new way - slower, works with 2022
                mCalculatePoints = OpenMaya2.MPointArray(mCalculatePointsClean)

                if a == 0:
                    for aId in aIdsCalculate:
                        mCalculatePoints[aId] = OpenMaya2.MPoint(mCalculatePointsClean[aId].x + 1, mCalculatePointsClean[aId].y, mCalculatePointsClean[aId].z)
                elif a == 1:
                    for aId in aIdsCalculate:
                        mCalculatePoints[aId] = OpenMaya2.MPoint(mCalculatePointsClean[aId].x, mCalculatePointsClean[aId].y + 1, mCalculatePointsClean[aId].z)
                elif a == 2:
                    for aId in aIdsCalculate:
                        mCalculatePoints[aId] = OpenMaya2.MPoint(mCalculatePointsClean[aId].x, mCalculatePointsClean[aId].y, mCalculatePointsClean[aId].z + 1)


            if pSkin.__class__ == patch.CurvePatch:
                fnMeshCalculate.setCVPositions(mCalculatePoints)
                fnMeshCalculate.updateCurve()
            else:
                fnMeshCalculate.setPoints(mCalculatePoints)


            aMoves[a] = pSkin.getPoints()[aIdsCalculate]
        if not np.all(np.linalg.norm(aMoves, axis=-1)):
            raise Exception('Some of the vertices didn\'t move. There might be a deformer blocking them')

        # calculate how far we have to move the verts to have the correct behavior
        aLocals = np.zeros((len(aIdsCalculate), 3), dtype='float64')
        for a in [0,1,2]:
            unit = aMoves[a]
            axis1 = aMoves[(a+1)%3]
            axis2 = aMoves[(a+2)%3]
            diff = unit - aSkin
            pointB = aSculpt + diff

            planeNormal = np.cross(aSkin - axis1, axis2 - axis1)
            denom = np.sum(diff * planeNormal, axis=1)
            u = (np.sum(aSkin * planeNormal, axis=1) - np.sum(aSculpt*planeNormal, axis=1)) / denom

            intersect = aSculpt + (u[:,np.newaxis]*diff)
            convert = np.linalg.norm(unit - aSkin, axis=1)
            dwPoint = aSculpt - intersect

            distance = np.linalg.norm(dwPoint, axis=1)
            pointC = intersect + diff

            difAC = np.linalg.norm(aSculpt - pointC, axis=1)
            difBI = np.linalg.norm(pointB - intersect, axis=1)
            aLocals[:,a] = distance / convert
            aBigger = np.where(difAC > difBI)[0]
            aLocals[aBigger,a] *= -1


    except Exception as e:
        cmds.delete(sMeshCalculate, sCalculateBlendShape)
        raise Exception('error happened: %s ("%s")' % (e,sSkin))
    finally:
        cmds.undoInfo(closeChunk=True)

    for sDeformer in sAllDeformers:
        _turnOffDeformerAndSave(sDeformer, dDeformerEnvelopes)

    if not sComboBlendShape:
        for i, aId in enumerate(aIdsCalculate):
            mCalculatePoints[aId] = OpenMaya2.MPoint(mCalculatePointsClean[aId].x + aLocals[i,0],
                                                      mCalculatePointsClean[aId].y + aLocals[i,1],
                                                      mCalculatePointsClean[aId].z + aLocals[i,2])
        if pSkin.__class__ == patch.CurvePatch:
            fnMeshCalculate.setCVPositions(mCalculatePoints)
            fnMeshCalculate.updateCurve()
        else:
            fnMeshCalculate.setPoints(mCalculatePoints)

    else: # sComboBlendShape
        if pSkin.__class__ == patch.CurvePatch:
            fnMeshCalculate.setCVPositions(mCalculatePointsClean)
            fnMeshCalculate.updateCurve()
        else:
            fnMeshCalculate.setPoints(mCalculatePointsClean)

        aDeformerInverted = np.copy(aCalculateCleanTotal)
        aDeformerInverted[aIdsCalculate] += aLocals

        cmds.setAttr('%s.envelope' % sComboBlendShape, True)
        cmds.setAttr('%s.envelope' % sCalculateBlendShape, False)
        aPreviousState = pSkin.getPoints()[:iSculptCount]

        aAdd = aDeformerInverted - aPreviousState
        aLengths = np.linalg.norm(aAdd, axis=-1)
        aNonZeroIds = np.where(aLengths  > 0.000001)[0]
        mDifferencePoints = OpenMaya2.MPointArray(mCalculatePointsClean)
        for iIndex in aNonZeroIds:
            mDifferencePoints[iIndex] = OpenMaya2.MPoint(mDifferencePoints[iIndex].x + aAdd[iIndex,0],
                                                         mDifferencePoints[iIndex].y + aAdd[iIndex,1],
                                                         mDifferencePoints[iIndex].z + aAdd[iIndex,2])

        if pSkin.__class__ == patch.CurvePatch:
            fnMeshCalculate.setCVPositions(mDifferencePoints)
            fnMeshCalculate.updateCurve()
        else:
            fnMeshCalculate.setPoints(mDifferencePoints)

        cmds.setAttr('%s.envelope' % sComboBlendShape, False)
        cmds.setAttr('%s.envelope' % sCalculateBlendShape, True)

    sDupl = cmds.duplicate(sSkin, name=sInvertName)[0]
    utils.parentToWorld(sDupl)

    # reset everything to its previous state
    #
    if sComboBlendShape:
        cmds.setAttr('%s.envelope' % sComboBlendShape, fOldComboBlendShapeEnvelope)

    for sDeformer in list(dDeformerEnvelopes.keys()):
        if sDeformer != sComboBlendShape:
            nodes._connectOrSet(dDeformerEnvelopes[sDeformer], '%s.envelope' % sDeformer)
    cmds.delete(sMeshCalculate, sCalculateBlendShape)
    utils.freezeGeo(sDupl)
    return sDupl





def getSplitWeights(sMesh, fRadius=2.0):

    pBase = patch.patchFromName(sMesh)
    aBase = pBase.getPoints()

    aLeftWeights = np.zeros(len(aBase), dtype='float64')
    aXs = aBase[:, 0]
    aLeftWeights[aXs > fRadius] = 1.0

    aMiddles = np.arange(pBase.getTotalCount())[(aXs < fRadius) & (aXs > -fRadius)]
    aXsNormalized = (aXs[aMiddles] + fRadius) / (2 * fRadius)
    aLeftWeights[aMiddles] = utils.bSpline4([0, 0, 1, 1], aValues=aXsNormalized)

    return aLeftWeights, 1.0-aLeftWeights


def splitShapeFromWeightsPerTarget(sSculpt, sBase, aWeights2d=None, bSkipNonChangingOnes=False):
    # bSkipNonChangingOnes = False
    pSculpt = patch.patchFromName(sSculpt)
    aSculpt = pSculpt.getPoints()
    pBase = patch.patchFromName(sBase)
    aBase = pBase.getPoints()

    iSmallestIndex = min(len(aSculpt), len(aBase), aWeights2d.shape[1])

    sReturnTargets = []

    aSculpt = aSculpt[:iSmallestIndex]
    aBase = aBase[:iSmallestIndex]

    for i in range(len(aWeights2d)):
        aWeights = aWeights2d[i,:iSmallestIndex]
        aNewPoints = aSculpt * aWeights.reshape(-1,1) + aBase * (1.0-aWeights.reshape(-1,1))

        if bSkipNonChangingOnes and utils.pointPositionsMatch(aNewPoints, aBase):
            sReturnTargets.append(None)
        else:
            sNewMesh = cmds.duplicate(sSculpt, n='%s_%03d' % (sSculpt, i))[0]
            patch.patchFromName(sNewMesh).setPoints(aNewPoints)
            sReturnTargets.append(sNewMesh)

    return sReturnTargets


def generateMeshToCurveParamWeights(sMesh, sCurve, fPercs, iMaxCount=None, sMinimumMeshes=[], iSmoothIterations=3, bCreateSkinClusterMesh=True):
    ''' TODO: replace part of the code with: returnWeightsIfExist()'''
    sWeightMesh = '_%s_%s_weightMesh_curveParamWeights_%d' % (sMesh, sCurve, len(fPercs))

    if cmds.objExists(sWeightMesh):
        pWeightMesh = patch.patchFromName(sWeightMesh)
        _, _, aWeights2d = pWeightMesh.getSkinCluster()
        if not utils.isNone(aWeights2d):
            return aWeights2d.T

    import kangarooTools.assets as assets
    sDeformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    sWeightFile = os.path.join(sDeformerFolder, 'skinCluster__%s.npz' % sWeightMesh)
    if os.path.exists(sWeightFile):
        if not cmds.objExists(sWeightMesh):
            cmds.duplicate(sMesh, n=sWeightMesh)[0]
            utils.deleteNoneShapeChildren(sWeightMesh)
            utils.parentToWorld(sWeightMesh)
            cmds.setAttr('%s.v' % sWeightMesh, False)
        from kangarooTabTools import weights
        weights._loadFromFile((sWeightFile, None), iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection, iLoadWorldspace=weights.LoadWorldspace.closestPointsIfTopologyDiffers)
        pWeightMesh = patch.patchFromName(sWeightMesh)
        _, _, aWeights2d = pWeightMesh.getSkinCluster()
        return aWeights2d.T
    else:
        aBasePoints = patch.patchFromName(sMesh).getAllPoints()

        iTotalCounts = [cmds.polyEvaluate(sM, vertex=True) for sM in sMinimumMeshes]
        iTotalCounts.append(len(aBasePoints))
        if iMaxCount != None:
            iTotalCounts.append(iMaxCount)
        iSmallestCount = min(iTotalCounts)
        aBasePoints = aBasePoints[:iSmallestCount]

        # fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
        # aParams = np.zeros(len(aBasePoints), dtype='float64')
        # for v,aPoint in enumerate(aBasePoints):
        #     _, fParam = fnCurve.closestPoint(OpenMaya2.MPoint(aPoint))
        #     aParams[v] = fParam
        # fEndParam = fnCurve.knots()[-1]
        # aPointPercs = aParams / fEndParam
        aPointPercs = curves.getPercsFromPoints(sCurve, aBasePoints)

        aClosests = xforms.findClosestFloats(aPointPercs, np.array(fPercs))
        aWeights2d = np.zeros((len(aBasePoints), len(fPercs)), dtype='float64')
        for i in range(len(fPercs)):
            aOneInds = np.where(aClosests == i)[0]
            aWeights2d[aOneInds[:,np.newaxis],i] = 1.0

        pMesh = patch.patchFromName(sMesh)
        pMesh.aIds = np.arange(iSmallestCount)
        aWeights2d = pMesh.smoothValues2d(aWeights2d, iIterations=iSmoothIterations, bBarycentricWeighted=False)

        if bCreateSkinClusterMesh:
            if not cmds.objExists(sWeightMesh):
                cmds.duplicate(sMesh, n=sWeightMesh)[0]
                utils.deleteNoneShapeChildren(sWeightMesh)
                utils.parentToWorld(sWeightMesh)
                cmds.setAttr('%s.v' % sWeightMesh, False)
            pWeightMesh = patch.patchFromName(sWeightMesh)

            xInds = utils.convertMiddleSequenceToSides(len(fPercs), bZipped=True)
            sInfluences = ['__jnt_%s_curveParam_%03d__' % (xInd[0], xInd[1]) for xInd in xInds]
            for sI in sInfluences:
                if not cmds.objExists(sI):
                    cmds.createNode('joint', n=sI)
            pWeightMesh.setSkinClusterWeights(aWeights2d, sInfluences, bRemoveZeroInfluencesOnCreate=False, _bSkipDeformerAdjustLogging=True)
            cmds.setAttr('%s.v' % sWeightMesh, False)

        return aWeights2d.T



def generateBrowSplineWeights(sMesh, bCreateSkinClusterMesh=True, iExpandCount=20, bPerCtrls=False):
    sWeightMesh = '__%s__weightMesh__browSplinesMain__' % (sMesh)
    if cmds.objExists(sWeightMesh):
        pWeightMesh = patch.patchFromName(sWeightMesh)
        _, _, aWeights2d = pWeightMesh.getSkinCluster()
        return aWeights2d[:,:-1].T

    aaaBrowSplinesMainWeights = []
    sBrowInfluences = utils.data.get('browSplinesMeasureJoints')
    iVertexCount = cmds.polyEvaluate(sMesh, v=True)
    aaBrowWeights = np.zeros((iVertexCount, len(sBrowInfluences)+1), dtype='float64')

    pMesh = patch.patchFromName(sMesh)
    _, sInfluences, aaSkinWeights = pMesh.getSkinCluster(sChooseSkinCluster='skinCluster__%s' % sMesh)
    aaSkinWeights = np.concatenate([aaSkinWeights.T, np.zeros((1, len(aaSkinWeights)), dtype='float64')]).T

    for i,sInf in enumerate(sBrowInfluences):
        sJoints = [sInf] + eval(utils.getStringAttr(sInf, 'sAdditionalSkinJoints', []))
        aJointsInAll = utils.findOneArrayInAnother(sInfluences, sJoints)
        aaBrowWeights[:,i] = np.sum(aaSkinWeights[:,aJointsInAll], axis=1)


    aSums = np.sum(aaBrowWeights, axis=-1)
    aSmallSumIds = np.where(aSums < 0.0001)[0]
    aSums[aSmallSumIds] = 1.0
    aBigSumIds = np.setdiff1d(np.arange(len(aSums)), aSmallSumIds)

    aaBrowWeights /= aSums[:,np.newaxis]
    aaaBrowSplinesMainWeights.append(aaBrowWeights.T)

    # expand the weights to non weighted areas
    iiNeighbors = pMesh.getNeighbors()

    iTotalVertexCount = len(aaSkinWeights)
    aFilledFromIteration = np.empty(iTotalVertexCount, dtype=int)
    aFilledFromIteration.fill(-1)

    aTheFirstIds = np.zeros(iTotalVertexCount, dtype=bool)
    aTheFirstIds[aBigSumIds] = True

    aWeightValues = np.zeros(iTotalVertexCount, dtype='float64')
    aWeightValues[aBigSumIds] = 1.0

    iLastReached = list(aBigSumIds)
    for w in range(iExpandCount):
        iReached = set()
        for k, iNonzero in enumerate(iLastReached):
            for n, iNb in enumerate(iiNeighbors[iNonzero]):
                if aTheFirstIds[iNb] == True:
                    continue
                if aFilledFromIteration[iNb] == -1 or aFilledFromIteration[iNb] == w:
                    aaBrowWeights[iNb] += aaBrowWeights[iNonzero]
                    aFilledFromIteration[iNb] = w
                    iReached.add(iNb)

        aSums = np.sum(aaBrowWeights, axis=1)
        aSums[aSums == 0] = 1.0
        aaBrowWeights /= aSums[:, np.newaxis]
        iLastReached = list(iReached)

    if bPerCtrls:
        iOneSideCount = (len(sBrowInfluences)-1) // 2
        aaCtrlWeights = np.zeros((7, len(sBrowInfluences)), dtype='float64')
        aaCtrlWeights[0][:iOneSideCount] = utils.bSpline3([1,0,0], iOneSideCount)
        aaCtrlWeights[1][:iOneSideCount] = utils.bSpline3([0,1,0], iOneSideCount)
        aaCtrlWeights[2][:iOneSideCount] = utils.bSpline3([0,0,1], iOneSideCount)
        aaCtrlWeights[3][iOneSideCount:-1] = utils.bSpline3([1,0,0], iOneSideCount)
        aaCtrlWeights[4][iOneSideCount:-1] = utils.bSpline3([0,1,0], iOneSideCount)
        aaCtrlWeights[5][iOneSideCount:-1] = utils.bSpline3([0,0,1], iOneSideCount)
        aaCtrlWeights[6][-1] = 1.0

        aaaMultipls = np.zeros((7, iVertexCount, len(sBrowInfluences)), dtype='float64')
        for i in range(7):
            aaaMultipls[i] = aaBrowWeights[:,:-1] * aaCtrlWeights[i,np.newaxis]
        aaBrowWeights = np.sum(aaaMultipls, axis=2).T

    if bCreateSkinClusterMesh:
        aaBrowSkinWeights = np.concatenate([aaBrowWeights.T, np.zeros((1, len(aaBrowWeights)), dtype='float64')]).T
        aaBrowSkinWeights[:,-1] = 1.0 - np.sum(aaBrowSkinWeights, axis=-1)
        cmds.duplicate(sMesh, n=sWeightMesh)[0]
        utils.parentToWorld(sWeightMesh)
        pWeightMesh = patch.patchFromName(sWeightMesh)
        if bPerCtrls:
            sInfluences = [cmds.createNode('joint') for _ in range(7)] + ['jnt_m_zero']
        else:
            sInfluences = sBrowInfluences + ['jnt_m_zero']
        if not cmds.objExists('jnt_m_zero'):
            cmds.createNode('joint', n='jnt_m_zero', p='modules')
        pWeightMesh.setSkinClusterWeights(aaBrowSkinWeights, sInfluences, bRemoveZeroInfluencesOnCreate=False, _bSkipDeformerAdjustLogging=True)
        cmds.setAttr('%s.v' % sWeightMesh, False)

    return aaBrowWeights.T



def returnWeightsIfExist(sMesh, sWeightMesh):
    ''' TODO: apply this function to others'''
    if cmds.objExists(sWeightMesh):
        pWeightMesh = patch.patchFromName(sWeightMesh)
        _, _, aWeights2d = pWeightMesh.getSkinCluster()
        if not utils.isNone(aWeights2d):
            return aWeights2d

    import kangarooTools.assets as assets
    sDeformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    sWeightFile = os.path.join(sDeformerFolder, 'skinCluster__%s.npz' % sWeightMesh)
    if os.path.exists(sWeightFile):
        if not cmds.objExists(sWeightMesh):
            cmds.duplicate(sMesh, n=sWeightMesh)[0]
            utils.deleteNoneShapeChildren(sWeightMesh)
            utils.parentToWorld(sWeightMesh)
            cmds.setAttr('%s.v' % sWeightMesh, False)
        from kangarooTabTools import weights
        weights._loadFromFile((sWeightFile, None), iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection, iLoadWorldspace=weights.LoadWorldspace.closestPointsIfTopologyDiffers)
        pWeightMesh = patch.patchFromName(sWeightMesh)
        _, _, aWeights2d = pWeightMesh.getSkinCluster()
        return aWeights2d

    return None


def createSkinClusterMesh(sMesh, sWeightMesh, sJoints, aaWeightings):
    ''' TODO: apply this function to others'''
    cmds.duplicate(sMesh, n=sWeightMesh)
    try:
        cmds.setAttr('%s.v' % sWeightMesh, False)
    except:
        pass

    utils.parentToWorld(sWeightMesh)

    pWeightMesh = patch.patchFromName(sWeightMesh)
    pWeightMesh.setSkinClusterWeights(aaWeightings, sJoints, _bSkipDeformerAdjustLogging=True)


def getJointWeights(sMesh, sJoints, sLabel='splitJoints'):

    sWeightMesh = '_%s_weightMesh_%s' % (sMesh, sLabel)
    aaWeightings = returnWeightsIfExist(sMesh, sWeightMesh)
    if not utils.isNone(aaWeightings):
        return aaWeightings
    else:
        pModel = patch.patchFromName(sMesh)
        sSkinCluster = 'skinCluster__%s' % sMesh
        _, sInfluences, aaWeights = pModel.getSkinCluster(sChooseSkinCluster=sSkinCluster)
        aInfluences = np.array(sInfluences)
        aJoints = utils.findOneArrayInAnother(aInfluences, sJoints)
        aBadOnes = np.where(aJoints == -1)[0]
        if len(aBadOnes):
            raise Exception('These joints are not found in %s: %s' % (sSkinCluster, np.array(sJoints)[aBadOnes]))

        aaWeightings = np.zeros((len(aaWeights), 4), dtype='float64')
        aaWeightsT = aaWeights.T
        for j in range(4):
            aaWeightings[:,j] = aaWeightsT[aJoints[j]]
        aSums = np.sum(aaWeightings, axis=1)
        aDenom = np.where(aSums < 0.001, 1.0, aSums)
        aaWeightings /= aDenom[:,np.newaxis]
        aAddAverage = np.where(aSums < 0.001, 1.0, 0.0)
        aaAverages = np.repeat(np.array([0.25, 0.25, 0.25, 0.25], dtype='float64'), len(aaWeights)).reshape(-1,4)
        aaWeightings += aaAverages * aAddAverage[:,np.newaxis]

        createSkinClusterMesh(sMesh, sWeightMesh, sJoints, aaWeightings)

        return aaWeightings




def getClosestToCurvesWeights(sModel, sCurves, iSmoothIterations=2):
    sWeightMesh = '%s__eyelidCorrectiveWeights' % sModel

    if cmds.objExists(sWeightMesh):
        return patch.patchFromName(sWeightMesh).getSkinCluster()[2]
    else:
        pModel = patch.patchFromName(sModel)
        aOrigs = np.zeros(pModel.getTotalCount(), dtype=int)
        aOrigs.fill(-1)
        iNextCheckIds = []
        for c,sCurve in enumerate(sCurves):
            iClosests = cmds.kt_findClosestPoints(fromMesh=sCurve, toMesh=sModel, vertex=True)
            aClosests = np.array(iClosests, dtype=int)
            aOrigs[aClosests] = c
            iNextCheckIds += list(aClosests)

        xNeighbors = pModel.getNeighbors()
        for _ in range(pModel.getTotalCount()): # just be be safe
            iNewNextCheckIds = []
            for iId in iNextCheckIds:
                iOrig = aOrigs[iId]
                for iNeighborId in xNeighbors[iId]:
                    if aOrigs[iNeighborId] == -1:
                        aOrigs[iNeighborId] = iOrig
                        iNewNextCheckIds.append(iNeighborId)
            if not iNewNextCheckIds:
                break
            else:
                iNextCheckIds = list(iNewNextCheckIds)

        aaWeights = np.zeros((pModel.getTotalCount(), len(sCurves)), dtype='float64')
        aaWeights[np.arange(pModel.getTotalCount())[:,np.newaxis],aOrigs[:,np.newaxis]] = 1.0

        sJoints = []
        for c,sCurve in enumerate(sCurves):
            sJ = 'jnt_%s' % sCurve
            if cmds.objExists(sJ):
                cmds.delete(sJ)
            cmds.createNode('joint', n=sJ)
            sJoints.append(sJ)

        cmds.duplicate(sModel, n=sWeightMesh)
        try:
            cmds.setAttr('%s.v' % sWeightMesh, False)
        except:
            pass
        utils.parentToWorld(sWeightMesh)
        cmds.parent(sJoints, sWeightMesh)

        aaWeights = pModel.smoothValues2d(aaWeights, iIterations=iSmoothIterations)
        pWeightMesh = patch.patchFromName(sWeightMesh)
        pWeightMesh.setSkinClusterWeights(aaWeights, sJoints, _bSkipDeformerAdjustLogging=True)

        return aaWeights


def getSideWeights(sGeo, fRadius=5.0, iCheckAxis=0):
    pGeo = patch.patchFromName(sGeo)
    aBase = pGeo.getAllPoints()
    aLeftWeights = np.zeros(len(aBase), dtype='float64')
    aXs = aBase[:, iCheckAxis]
    aLeftWeights[aXs >= fRadius] = 1.0

    aMiddles = np.arange(len(aBase))[(aXs < fRadius) & (aXs > -fRadius)]
    aXsNormalized = (aXs[aMiddles] + fRadius) / (2 * fRadius)
    aLeftWeights[aMiddles] = utils.bSpline4([0, 0, 1, 1], aValues=aXsNormalized)

    return aLeftWeights


def cutFromGeoByWeights(sSculpt, sBase, aWeights, sNewName):
    sNewTarget = cmds.duplicate(sBase, n=sNewName)[0]
    aSculptPoints = patch.patchFromName(sSculpt).getPoints()
    aBasePoints = patch.patchFromName(sBase).getPoints()
    aWeights = aWeights[:,np.newaxis]
    aNewPoints = aSculptPoints * aWeights + aBasePoints * (1.0-aWeights)

    patch.patchFromName(sNewTarget).setPoints(aNewPoints)
    utils.parentToWorld(sNewTarget)




# @uiSettings.addToUI(sRunButton='Split', sTab='Geometry', sModuleButton='Split', bReloadBeforeRun=True, dControls={}, tRefreshControlsAfterRun=[])
def splitShape(sSculpt=None, sBase=None, fRadius=5.0, aLeftWeights=None, sLeftName='', sRightName='', bUnParent=False, xMirrorAxis=None, bBaseAsOrig=False):

    if sSculpt == None:
        sSculpt = cmds.ls(sl=True)[0]
    if sBase == None:
        sBase = sSculpt.split('__')[1]

    if not sLeftName:
        sLeftName = sSculpt.replace('_m_', '_l_') if '_m_' in sSculpt else 'l_%s' % sSculpt
    if not sRightName:
        sRightName = sSculpt.replace('_m_', '_r_') if '_m_' in sSculpt else 'r_%s' % sSculpt

    if cmds.objExists(sLeftName) and cmds.objExists(sRightName):
        return sLeftName, sRightName

    pSculpt = patch.patchFromName(sSculpt)
    aSculpt = pSculpt.getPoints()

    pBase = patch.patchFromName(sBase)
    aBase = pBase.getPoints(bOrig=bBaseAsOrig)

    iSmallerCount = min(len(aSculpt), len(aBase))
    aBase = aBase[:iSmallerCount]
    aSculpt = aSculpt[:iSmallerCount]


    if xMirrorAxis == None:
        aCheckBase = aBase
        iCheckAxis = 0
    else:
        sJoint, iAxis = xMirrorAxis
        aJointMatrix = np.array(cmds.xform(sJoint, q=True, ws=True, m=True), dtype='float64').reshape(4,4)
        aBase4 = utils.makePoint4Array(aBase)
        aBaseLocal4 = np.dot(aBase4, np.linalg.inv(aJointMatrix))
        aCheckBase = aBaseLocal4[:,0:3]
        iCheckAxis = iAxis % 3
        if iAxis >= 3:
            aCheckBase *= -1.0

    if not isinstance(aLeftWeights, np.ndarray):
        aLeftWeights = np.zeros(len(aBase), dtype='float64')
        aXs = aCheckBase[:,iCheckAxis]
        aLeftWeights[aXs >= fRadius] = 1.0

        aMiddles = np.arange(pSculpt.getTotalCount())[(aXs < fRadius) & (aXs > -fRadius)]
        aXsNormalized = (aXs[aMiddles] + fRadius) / (2*fRadius)
        aLeftWeights[aMiddles] = utils.bSpline4([0,0,1,1], aValues=aXsNormalized)

    aRightWeights = 1.0 - aLeftWeights

    if np.any(aLeftWeights):
        aLeftWeights = aLeftWeights[:len(aBase)]
        aLeft = aBase * (1.0-aLeftWeights[:,np.newaxis]) + aSculpt * aLeftWeights[:,np.newaxis]
        if not cmds.objExists(sLeftName):
            sLeftName = cmds.duplicate(sSculpt, n=sLeftName)[0]
        patch.patchFromName(sLeftName).setPoints(aLeft)
    else:
        sLeftName = None

    if np.any(aRightWeights):
        aRightWeights = aRightWeights[:len(aBase)]
        aRight = aBase * (1.0-aRightWeights[:,np.newaxis]) + aSculpt * aRightWeights[:,np.newaxis]
        if not cmds.objExists(sRightName):
            sRightName = cmds.duplicate(sSculpt, n=sRightName)[0]
        patch.patchFromName(sRightName).setPoints(aRight)
    else:
        sRightName = None

    if bUnParent:
        if sLeftName:
            try:cmds.parent(sLeftName, w=True)
            except: pass
        if sRightName:
            try:cmds.parent(sRightName, w=True)
            except: pass


    return sLeftName, sRightName



class WarpToModelChangeOptions():
    matrix = 0
    blendshape = 1
    wrapDeformer = 2
    scaledDeltas = 3


dControls = {}
dControls['iWarpMode'] = controls.RadioButtonsControl(WarpToModelChangeOptions)
@uiSettings.addToUI(sRunButton='Warp', sTab='Geometry', sModuleButton='WarpPoses', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#warp-poses')
def warpToModelChange(sFrom='', sTo='', iWarpMode=WarpToModelChangeOptions.wrapDeformer, _report=None):
    '''
    Model change
    If the topology is the same on the new mesh, use Matrix mode or BlendShape mode
    If the topology changed, use Wrap Deformer mode
    '''
    cmds.undoInfo(openChunk=True)
    try:
        sGeos = cmds.ls(sl=True)

        if not cmds.objExists(sFrom):
            raise Exception('%s doesn\'t exist' % sFrom)
        if not cmds.objExists(sTo):
            raise Exception('%s doesn\'t exist' % sTo)

        sOldGeos = []
        sNewGeos = []

        xFromSpaces = [None] * cmds.polyEvaluate(sFrom, vertex=True)

        for sGeo in sGeos:
            sOldGeos.append(cmds.rename(sGeo, '__%s' % sGeo))
            sNewGeos.append( utils._duplicateGeoClean(sFrom if iWarpMode==WarpToModelChangeOptions.blendshape else sTo, sName=sGeo, bParentToOrigin=True))

        report.report.resetProgress(len(sGeos))

        if iWarpMode == WarpToModelChangeOptions.matrix:
            pFrom = patch.patchFromName(sFrom)
            pTo = patch.patchFromName(sTo)
            aFromPoints = pFrom.getPoints()
            aToPoints = pTo.getPoints()
            aDiffs = np.linalg.norm(aFromPoints - aToPoints, axis=-1)
            aChangeIds = np.array(np.where(aDiffs > 0.0001)[0], dtype=int)
            mFromVertexIter = OpenMaya2.MItMeshVertex(pFrom.mDagPath)
            for iInd, iId in enumerate(aChangeIds):
                if utils.isNone(xFromSpaces[iId]):
                    mFromVertexIter.setIndex(int(iId))
                    aNormal = np.array(mFromVertexIter.getNormal(), dtype='float64')
                    iNeighborIds = np.array(mFromVertexIter.getConnectedVertices(), dtype=int)
                    aLocalPoints = aFromPoints[iNeighborIds] - aFromPoints[iId]
                    iBiggestNeighbordInd = np.argmax(np.linalg.norm(aLocalPoints, axis=1))
                    iBiggestId = iNeighborIds[iBiggestNeighbordInd]

                    aFromMatrix = utils.getOrthoMatrixFromVectors(aFromPoints[iId], aNormal, aFromPoints[iBiggestId])
                    aPoints4 = utils.makePoint4Array(aToPoints[aChangeIds])
                    aLocalChangePoint4 = np.dot(aPoints4[iInd], np.linalg.inv(aFromMatrix))
                    xFromSpaces[iId] = [aFromMatrix, aLocalChangePoint4, iId, iBiggestId]
                
            for g, sGeo in enumerate(sOldGeos):
                report.report.incrementProgress()
                pTarget = patch.patchFromName(sGeo)
                aTargetPoints = pTarget.getPoints()
                aNewTargetPoints = np.copy(aTargetPoints)
                mTargetVertexIter = OpenMaya2.MItMeshVertex(pTarget.mDagPath)

                for iInd, iId in enumerate(aChangeIds):
                    aFromMatrix, aLocalChangePoint4, iId, iBiggestId = xFromSpaces[iId]
                    mTargetVertexIter.setIndex(int(iId))
                    aTargetNormal = np.array(mTargetVertexIter.getNormal(), dtype='float64')
                    aTargetMatrix = utils.getOrthoMatrixFromVectors(aTargetPoints[iId], aTargetNormal, aTargetPoints[iBiggestId])
                    aNewPoint = np.dot(aLocalChangePoint4, aTargetMatrix)[0:3]
                    aNewTargetPoints[iId] = aNewPoint
                patch.patchFromName(sNewGeos[g]).setPoints(aNewTargetPoints)

        elif iWarpMode == WarpToModelChangeOptions.blendshape:
            for g,sGeo in enumerate(sGeos):
                cmds.blendShape(sTo, sOldGeos[g], sNewGeos[g], w=[[0,1], [1,1]], topologyCheck=False)
                # cmds.delete(sNewGeos[g], ch=True)

        elif iWarpMode == WarpToModelChangeOptions.wrapDeformer:
            sUnorderedWraps, sBase = deformers.createWrap(sNewGeos, sFrom)
            for g,sGeo in enumerate(sGeos):
                cmds.blendShape(sOldGeos[g], sFrom, w=[0,1], topologyCheck=False)
                cmds.delete(sNewGeos[g], ch=True)
            cmds.delete(sBase)
            cmds.select(sNewGeos)

        elif iWarpMode == WarpToModelChangeOptions.scaledDeltas:
            aFrom = patch.patchFromName(sFrom).getPoints()
            aTo = patch.patchFromName(sTo).getPoints()
            fScaleFactor = utils.getModelBoundingBoxDiagonal(sTo) / utils.getModelBoundingBoxDiagonal(sFrom)
            for g,sGeo in enumerate(sGeos):
                aGeo = patch.patchFromName(sOldGeos[g]).getPoints()
                aDelta = aGeo - aFrom
                aNewGeo = aTo + aDelta * fScaleFactor
                patch.patchFromName(sNewGeos[g]).setPoints(aNewGeo)

        cmds.select(sGeos)
    except Exception:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



dControls = {}
@uiSettings.addToUI(sRunButton='Warp', sTab='Geometry', sModuleButton='WarpSecPoses', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#warp-secondary-poses')
def warpPoses(sMainModel='', sSecondaryModel='', bRigidIslands=False, _report=None):
    '''
    Warp Secondary Model to poses
    Fill Main Mesh, Secondary Mesh, and select the poses of the main Mesh.
    '''

    try:
        cmds.undoInfo(openChunk=True)
        sTargets = cmds.ls(sl=True)

        sNewMeshes = []

        if bRigidIslands:
            for sTarget in sTargets:
                sNewTarget = cmds.duplicate(sSecondaryModel, n='%s__%s' % (sSecondaryModel, sTarget))[0]
                utils.parentToWorld(sNewTarget)
                warpRigidIslands(sNewTarget, sMainModel, sTarget)
                sNewMeshes.append(sNewTarget)
        else:
            sMainModelDupl = cmds.duplicate(sMainModel, n='%s_dupl' % sMainModel)[0] # needs to add the blendshape on a duplicated one, since other deformers might ruin the process
            sUnorderedWraps, sBase = deformers.createWrap(sSecondaryModel, sMainModelDupl)

            sTargetAttrs = deformers.addBlendShapeTargets(sMainModelDupl, sTargets)
            for t,sTarget in enumerate(sTargets):
                cmds.setAttr(sTargetAttrs[t], 1.0)
                sNewTarget = cmds.duplicate(sSecondaryModel, n='%s__%s' % (sSecondaryModel, sTarget))[0]
                xforms.unlockTrs(sNewTarget)
                cmds.setAttr(sTargetAttrs[t], 0.0)
                utils.parentToWorld(sNewTarget)
                sNewMeshes.append(sNewTarget)
                cmds.setAttr('%s.v' % sNewTarget, cmds.getAttr('%s.v' % sTarget))

            cmds.delete(sTargetAttrs[0].split('.')[0])
            cmds.delete(sMainModelDupl, sUnorderedWraps)

        cmds.select(sNewMeshes)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



class warpOrderOptions():
    selectionOrder = 0
    hierarchy = 1
    blueprintCtrls = 2
    blueprintCtrlsAllInScene = 3

dControls = {}
dControls['iOrder'] = controls.RadioButtonsControl(warpOrderOptions)
@uiSettings.addToUI(sRunButton='Warp', sTab='Geometry', sModuleButton='WarpXForms', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#warp-xforms')
def warpXforms(sFrom='', sTo='', iOrder=0, bOrient=False, _report=None):
    ''' warps selected transforms'''

    sJoints = cmds.ls(sl=True, et='joint') + cmds.ls(sl=True, et='transform')
    if iOrder == warpOrderOptions.selectionOrder:
        pass
    elif iOrder == warpOrderOptions.hierarchy:
        sJoints = cmds.ls(sJoints, l=True)
        sJoints.sort(key=lambda s: len(s))
    elif iOrder in [warpOrderOptions.blueprintCtrls, warpOrderOptions.blueprintCtrlsAllInScene]:
        if iOrder == warpOrderOptions.blueprintCtrlsAllInScene:
            sJoints = cmds.ls('*_ctrl')
        if 'bpGlobal_ctrl' in sJoints:
            del sJoints[sJoints.index('bpGlobal_ctrl')]
        def _sortFunction(sCtrl):
            if cmds.attributeQuery('iWarpPriority', node=sCtrl, exists=True):
                return cmds.getAttr('%s.iWarpPriority' % sCtrl)
            else:
                return 100000000
        sJoints.sort(key=_sortFunction)
    utils.reload2(xforms)
    xforms.warpTransforms(sFrom, sTo, sJoints, bOrient=bOrient)




# @uiSettings.addToUI(sRunButton='Transfer Selection', sTab='Geometry', sModuleButton='TransferSel', bReloadBeforeRun=True, dControls={}, tRefreshControlsAfterRun=[])
def transferSelection(sTo=''):
    sComponents = [sO.split('.')[-1] for sO in cmds.ls(sl=True, flatten=True) if '.' in sO]
    sNewComponents = ['%s.%s' % (sTo, sComp) for sComp in sComponents]
    cmds.select([sO for sO in sNewComponents if cmds.objExists(sO)])



# dControls = {}
@uiSettings.addToUI(sRunButton='Match Selection', sTab='Geometry', sModuleButton='Match', bReloadBeforeRun=True,
                    dControls={}, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#match-vertex-positions')
def setModelVerts(sFrom='', fWeight=1.0, bWorld=False, _report=None):
    sSelBefore = cmds.ls(sl=True)

    pSelection = patch.getSelectedPatches()

    if not sFrom:
        raise Exception('set sForm mesh')

    cmds.undoInfo(openChunk=True)
    try:
        pParent = patch.patchFromName(sFrom)
        aParentPoints = pParent.getAllPoints(bWorld=bWorld)
        
        for pP in pSelection:
            aPoints = pP.getPoints(bWorld=bWorld)
            if utils.isNone(pP.aSofts):# == None:
                pP.aSofts = np.ones(pP.aIds.size, dtype='float64')
            aSoftsReshaped = pP.aSofts[:,np.newaxis]
            aNewPoints = aParentPoints[pP.aIds]*aSoftsReshaped + aPoints*(1-aSoftsReshaped)
            aNewPoints = aNewPoints*fWeight + aPoints*(1.0-fWeight)
            pP.setPoints(aNewPoints, aIds=pP.aIds, bWorld=bWorld)
    
        cmds.select(sSelBefore)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


# dControls = {}
dControls = {}
dControls['iDirectionIfMiddleMesh'] = controls.RadioButtonsControl(MirrorDirection)
dControls['iMode'] = controls.RadioButtonsControl(MirrorMode)
dControls['sMiddleEdge'] = controls.MiddleEdgeControl()
@uiSettings.addToUI(sRunButton='Mirror Selection', sTab='Geometry', sModuleButton='SelMirror', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[])
def SelectionMirror(iMode=MirrorMode.vertexIds, sMiddleEdge=None, bAdd=True, _report=None):
    '''
    Mirrors Vertex Selection, or selects all left, all right or all middle vertices.

    Currently only Vertex Selection supported.
    '''
    if sMiddleEdge:
        iMiddleEdge = utils.intFromComponent(sMiddleEdge)
    else:
        iMiddleEdge = None

    sSel = cmds.ls(sl=True)

    dVertSel = defaultdict(list)
    for sS in sSel:
        if '.vtx' in sS:
            sMesh = sS.split('.')[0]
            sNumber = sS.split('[')[-1].split(']')[0]
            try:
                dVertSel[sMesh].append(int(sNumber))
            except:
                sSplits = sNumber.split(':')
                dVertSel[sMesh] += range(int(sSplits[0]), int(sSplits[1])+1, 1)

    sNewSelection = []

    for sMesh, iVerts in list(dVertSel.items()):
        aInds = np.array(iVerts, dtype=int)
        pMesh = patch.patchFromName(sMesh)
        aTable, aSides = pMesh.getMirrorTable(bIds = True if iMode==MirrorMode.vertexIds else False, iMiddleEdge=iMiddleEdge)
        aOpposit = aTable[aInds]
        sOpposit = ['%s.vtx[%s]' % (sMesh, sVerts) for sVerts in utils.createMayaStringFromList(aOpposit)]
        sNewSelection += sOpposit

    cmds.select(sOpposit, add=bAdd)



@uiSettings.addToUI(sRunButton='Select Left Side', sTab='Geometry', sModuleButton='SelMirror', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def SelectLeftVertices(iMode=MirrorMode.vertexIds, sMiddleEdge=None, bAdd=True):
    SelectSideVertices(iMode=iMode, sMiddleEdge=sMiddleEdge, bAdd=bAdd, _iSide=1)

@uiSettings.addToUI(sRunButton='Select Right Side', sTab='Geometry', sModuleButton='SelMirror', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def SelectRightVertices(iMode=MirrorMode.vertexIds, sMiddleEdge=None, bAdd=True):
    SelectSideVertices(iMode=iMode, sMiddleEdge=sMiddleEdge, bAdd=bAdd, _iSide=2)


@uiSettings.addToUI(sRunButton='Select Middle', sTab='Geometry', sModuleButton='SelMirror', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def SelectMiddleVertices(iMode=MirrorMode.vertexIds, sMiddleEdge=None, bAdd=True):
    SelectSideVertices(iMode=iMode, sMiddleEdge=sMiddleEdge, bAdd=bAdd, _iSide=0)


def SelectSideVertices(iMode=MirrorMode.vertexIds, sMiddleEdge=None, bAdd=True, _iSide=1):
    if sMiddleEdge:
        iMiddleEdge = utils.intFromComponent(sMiddleEdge)
    else:
        iMiddleEdge = None

    sSel = cmds.ls(sl=True)
    sMeshes = list(set([sObj.split('.')[0] for sObj in sSel]))

    sNewSelection = []
    for sMesh in sMeshes:
        pMesh = patch.patchFromName(sMesh)
        aTable, aSides = pMesh.getMirrorTable(bIds = True if iMode==MirrorMode.vertexIds else False, iMiddleEdge=iMiddleEdge)
        aSelectIds = np.where(aSides==_iSide)[0]
        sOpposit = ['%s.vtx[%s]' % (sMesh, sVerts) for sVerts in utils.createMayaStringFromList(aSelectIds)]
        sNewSelection += sOpposit

    cmds.select(sOpposit, add=bAdd)





#
#
# dControls = {}
# dControls['sFile'] = controls.FilePathControl('*.ma', sDefaultFileName='mayaImport\stuff.ma', bShowContent=True)
# @uiSettings.addToUI(sTab='Export', sModuleButton='MayaImport', sRunButton='Export Selection', dControls=dControls)
# def exportToMayaImport(sFile='file'):
#
#     cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
#     #
#
#
#
# dControls = {}
# @uiSettings.addToUI(sTab='Export', sModuleButton='MayaImport', sRunButton='Save', dControls=dControls)
# def saveToMayaImport(sFile='file'):
#
#     cmds.file(rename=sFile)
#     cmds.file(force=True, type='mayaAscii', save=True)
#     #
#
#
#
#
# dControls = {}
# @uiSettings.addToUI(sTab='Export', sModuleButton='MayaImport', sRunButton='Open', dControls=dControls)
# def openFromMayaImport(sFile='file'):
#     cmds.file(sFile, open=True, force=True)






def warpRigidIslands(sMesh, sFrom, sTo):
    pMesh = patch.patchFromName(sMesh)
    pFrom = patch.patchFromName(sFrom)
    pTo = patch.patchFromName(sTo)

    iiIslands = pMesh.getIslands()
    aAllPoints = pMesh.getPoints()
    aMeans = np.empty((len(iiIslands),3), dtype='float64')

    for i,iIsland in enumerate(iiIslands):
        aIsland = np.array(iIsland, dtype=int)
        aPoints = aAllPoints[aIsland]
        aMeans[i] = np.mean(aPoints, axis=0)

    aClosests = xforms.getClosestInfoFromPoints(sFrom, aMeans, bReturnFaces=True, bReturnNormals=True)

    aFaceVertexCounts = np.empty(len(iiIslands), dtype=int)
    aSourcePositions = np.zeros((len(iiIslands),4,3), dtype='float64')
    mFromMeshIter = OpenMaya2.MItMeshPolygon(utils.getDagPath(sFrom))
    aFromPoints = pFrom.getAllPoints()

    iiFaceVerts = []
    aNormals = np.zeros((len(iiIslands),3), dtype='float64')
    for i, iIsland in enumerate(iiIslands):
        iFace = int(aClosests[i, 6])
        mFromMeshIter.setIndex(iFace)
        aNormals[i] = mFromMeshIter.getNormal()
        iVerts = mFromMeshIter.getVertices()
        aFaceVertexCounts[i] = len(iVerts)
        aSourcePositions[i] = aFromPoints[np.array(iVerts)]
        iiFaceVerts.append(np.array(iVerts, dtype=int))

    aBarys = barycentric.getBarycentricCoords(aClosests[:,0:3], aSourcePositions, aFaceVertexCounts)
    aToPoints = pTo.getAllPoints()
    mToMeshIter = OpenMaya2.MItMeshPolygon(utils.getDagPath(sTo))
    for i, iIsland in enumerate(iiIslands):
        aVerts = iiFaceVerts[i]
        aFacePointDistances = np.linalg.norm(aMeans[i] - aFromPoints[aVerts], axis=1)
        iFurthest = aVerts[np.argmax(aFacePointDistances)]

        if aFaceVertexCounts[i] == 4:
            aPointBary = np.sum(aFromPoints[aVerts] * aBarys[i][:,np.newaxis], axis=0)
        elif aFaceVertexCounts[i] == 3:
            aPointBary = np.sum(aFromPoints[aVerts] * aBarys[i,0:3].reshape(-1, 1), axis=0)
        else:
            raise Exception('unsupported face vertex count: %i' % aFaceVertexCounts[i])

        # aPoint = aClosests[i,0:3]
        aNormal = aNormals[i]
        aUp = aFromPoints[iFurthest] - aPointBary
        aCross = np.cross(aUp, aNormal)
        aUp = np.cross(aNormal, aCross)
        aNormal /= np.linalg.norm(aNormal)
        aUp /= np.linalg.norm(aUp)
        aCross /= np.linalg.norm(aCross)
        aFromMatrix = np.array([[aUp[0], aUp[1], aUp[2], 0.0],
                                [aNormal[0], aNormal[1], aNormal[2], 0.0],
                                [aCross[0], aCross[1], aCross[2], 0.0],
                                [aPointBary[0], aPointBary[1], aPointBary[2], 1.0]], dtype='float64')

        if aFaceVertexCounts[i] == 4:
            aToPoint = np.sum(aToPoints[aVerts] * aBarys[i][:,np.newaxis], axis=0)
        elif aFaceVertexCounts[i] == 3:
            aToPoint = np.sum(aToPoints[aVerts] * aBarys[i,0:3].reshape(-1, 1), axis=0)
        else:
            raise Exception('unsupported face vertex count: %i' % aFaceVertexCounts[i])

        mToMeshIter.setIndex(int(aClosests[i,6]))
        aToNormal = np.array((mToMeshIter.getNormal()), dtype='float64')
        aToUp = aToPoints[iFurthest] - aToPoint
        aToCross = np.cross(aToUp, aToNormal)
        aToUp = np.cross(aToNormal, aToCross)
        aToNormal /= np.linalg.norm(aToNormal)
        aToUp /= np.linalg.norm(aToUp)
        aToCross /= np.linalg.norm(aToCross)
        aToMatrix = np.array([[aToUp[0], aToUp[1], aToUp[2], 0.0],
                            [aToNormal[0], aToNormal[1], aToNormal[2], 0.0],
                            [aToCross[0], aToCross[1], aToCross[2], 0.0],
                            [aToPoint[0], aToPoint[1], aToPoint[2], 1.0]], dtype='float64')

        aIsland = np.array(iIsland, dtype=int)
        aPoints = aAllPoints[aIsland]
        aPoints4 = np.ones((len(aPoints), 4), dtype='float64')
        aPoints4[:,:3] = aPoints
        aLocals4 = np.dot(aPoints4, np.linalg.inv(aFromMatrix))
        aWarped4 = np.dot(aLocals4, aToMatrix)
        aAllPoints[aIsland] = aWarped4[:,0:3]

    pMesh.setPoints(aAllPoints)





'''

import kangarooTabTools.geometry as geometry
utils.reload2(geometry)
geometry.warpRigidIslands('Mesh', 'Pants', 'TARGET__Pants__l_knee__100__posed')

'''


def scaleSelectedCurves(fFactor=1.1):
    sShapes = cmds.listRelatives(cmds.ls(sl=True), c=True, s=True, typ='nurbsCurve')
    for sS in sShapes:
        cmds.scale(fFactor, fFactor, fFactor, '%s.cv[*]' % sS)


# def downSizeSelectedCurves(fFactor=0.9):
#     sShapes = cmds.listRelatives(cmds.ls(sl=True), c=True, s=True, typ='nurbsCurve')
#     for sS in sShapes:
#         cmds.scale(fFactor, fFactor, fFactor, '%s.cv[*]' % sS)
#



def scaleSelectedPlanes(fFactor=1.1):
    sShapes = cmds.listRelatives(cmds.ls(sl=True), c=True, s=True, typ='nurbsSurface')
    for sS in sShapes:
        cmds.scale(fFactor, fFactor, fFactor, '%s.cv[*][*]' % sS)


# def downSizeSelectedPlanes(fFactor=0.9):
#     sShapes = cmds.listRelatives(cmds.ls(sl=True), c=True, s=True, typ='nurbsSurface')
#     for sS in sShapes:
#         cmds.scale(fFactor, fFactor, fFactor, '%s.cv[*][*]' % sS)


def getGeosInGroup(sGrp):
    sGeos = []
    for sType in ['mesh', 'nurbsCurve', 'nurbsSurface']:
        sGeos += cmds.listRelatives(sGrp, ad=True, typ=sType) or []
    sTransforms = [cmds.listRelatives(sG, p=True, c=False, typ='transform')[0] for sG in sGeos]
    sTransforms = list(set(sTransforms))

    return sTransforms



class adjustCornerMapsOptions():
    firstChangesOthers = 0
    highest = 1
    lowest = 2
    average = 3


def alignMeshes(sMeshes, sMask, iCornerPoint, iAxis=1, bMirror=True, fSplitRadius=2.0, iMode=adjustCornerMapsOptions.firstChangesOthers):

    '''
    # # example use:

    # neutral lines
    geometry.adjustCornersBetweenMeshes(['body_ply', 'lipsWide', 'lipsNarrow'], 'MAP__mouthAround', 3784, 1, fSplitRadius=2.0)
    geometry.adjustCornersBetweenMeshes(['body_ply', 'lipsCornerUp', 'lipsCornerDown'], 'MAP__mouthAround', 3784, 0, fSplitRadius=2.0)

    # out line
    geometry.adjustCornersBetweenMeshes(['lipsWide', 'lipsSmile', 'lipsFrown'], 'MAP__mouthAround', 3784, 0, fSplitRadius=2.0)

    # upper/lower lines
    geometry.adjustCornersBetweenMeshes(['lipsCornerUp', 'lipsSmile'], 'MAP__mouthAround', 3784, 1, fSplitRadius=2.0)
    geometry.adjustCornersBetweenMeshes(['lipsCornerDown', 'lipsFrown'], 'MAP__mouthAround', 3784, 1, fSplitRadius=2.0)
    '''

    aMask = getMapValues(sMask)
    iVertCount = cmds.polyEvaluate(sMeshes[0], vertex=True)

    pMeshes = [patch.patchFromName(sM) for sM in sMeshes]
    aaPoints = [pM.getAllPoints() for pM in pMeshes]

    aMirror = pMeshes[0].getMirrorTable()[0]

    aaSplitWeights = getSplitWeights(sMeshes[0], fRadius=fSplitRadius) if bMirror else [np.ones(iVertCount, dtype='float64')]

    for s,sSide in enumerate(['l','r'] if bMirror else ['m']):
        if s == 1:
            iCornerPoint = aMirror[iCornerPoint]

        aCornerPoints = np.array([aaPoints[i][iCornerPoint] for i in range(len(sMeshes))], dtype='float64')

        if iMode == adjustCornerMapsOptions.firstChangesOthers:
            aFromCornerPoint = aCornerPoints[0]
            iIgnore = 0
        elif iMode == adjustCornerMapsOptions.highest:
            if iAxis == 0 and sSide == 'r':
                iIgnore = np.argmin(aCornerPoints[:,iAxis])
                aFromCornerPoint = aCornerPoints[iIgnore]
            else:
                iIgnore = np.argmax(aCornerPoints[:,iAxis])
                aFromCornerPoint = aCornerPoints[iIgnore]
        elif iMode == adjustCornerMapsOptions.lowest:
            if iAxis == 0 and sSide == 'r':
                iIgnore = np.argmax(aCornerPoints[:,iAxis])
                aFromCornerPoint = aCornerPoints[iIgnore]
            else:
                iIgnore = np.argmin(aCornerPoints[:,iAxis])
                aFromCornerPoint = aCornerPoints[iIgnore]
        elif iMode == adjustCornerMapsOptions.average:
            iIgnore = -1
            aFromCornerPoint = np.average(aCornerPoints, axis=0)

        iTos = [i for i in range(len(sMeshes)) if i != iIgnore]


        for iTo in iTos:
            sAxis = ['X','Y','Z'][iAxis]
            sCluster, sHandle = cmds.cluster(sMeshes[iTo], n='cluster_%s_%sFix%s' % (sSide, sMeshes[iTo], sAxis))
            cmds.setAttr('%s.v' % sHandle, False)
            sShapeHandle = cmds.listRelatives(sHandle, c=True, s=True)[0]
            cmds.setAttr('%s.origin' % sShapeHandle, *list(aCornerPoints[1]))

            cmds.move(aCornerPoints[iTo][0], aCornerPoints[iTo][1], aCornerPoints[iTo][2],
                      ['%s.scalePivot' % sHandle, '%s.rotatePivot' % sHandle], a=True)

            aMask = aMask[:iVertCount]
            aSplitWeights = aaSplitWeights[s][:iVertCount]
            cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, iVertCount - 1), *list(aMask*aSplitWeights))

            aOffset = aFromCornerPoint - aCornerPoints[iTo]

            fChangeOffset = [0,0,0]
            fChangeOffset[iAxis] = aOffset[iAxis]
            cmds.move(fChangeOffset[0], fChangeOffset[1], fChangeOffset[2], sHandle, r=True, ws=True)



def _getMapAttr(sDeformer):
    sGeometry = cmds.deformer(sDeformer, q=True, g=True)[0]
    iSize = cmds.polyEvaluate(sGeometry, vertex=True)

    if cmds.objectType(sDeformer) == 'cluster':
        sAttr = '%s.weightList[0].weights[0:%d]' % (sDeformer, iSize - 1)
    elif cmds.objectType(sDeformer) == 'blendShape':
        sAttr = '%s.inputTarget[0].baseWeights[0:%d]' % (sDeformer, iSize - 1)
    return sAttr



def getMapValues(sDeformer):
    if isinstance(sDeformer, np.ndarray):
        return sDeformer

    if sDeformer.startswith('MAP__'):
        sAttr = _getMapAttr(sDeformer)
        fValues = cmds.getAttr(sAttr)
        return np.array(fValues, dtype='float64')
    elif sDeformer.startswith('MAPREV__'):
        sAttr = _getMapAttr(utils.replaceStringStart(sDeformer, 'MAPREV', 'MAP'))
        fValues = cmds.getAttr(sAttr)
        return 1.0 - np.array(fValues, dtype='float64')
    else:
        raise Exception('%s is not a map deformer. It needs to start with "MAP__" (2 underscores!)' % sDeformer)


# dControls = {}
# dControls['sFolder'] = controls.FolderPathControl(sSubFolder='maps', bReadOnly=True)
# @uiSettings.addToUI(sTab='Export', sModuleButton='Maps', sRunButton='Export All Maps in Scene', dControls=dControls, bDisableOnServer=True)
# def exportAllMaps(sFolder='maps'):
#     sAllNodes = [sC for sC in (cmds.ls(et='blendShape') + cmds.ls(et='cluster')) if sC.startswith('MAP__')]
#     exportMaps(sAllNodes, sFolder)
#
#
# dControls = {}
# dControls['sFolder'] = controls.FolderPathControl(sSubFolder='maps', bReadOnly=True)
# @uiSettings.addToUI(sTab='Export', sModuleButton='Maps', sRunButton='Export Selected Maps', dControls=dControls, bDisableOnServer=True)
# def exportSelectedMap(sFolder='maps'):
#     sClusters = [sC for sC in (cmds.ls(et='blendShape', sl=True) + cmds.ls(et='cluster', sl=True)) if sC.startswith('MAP__')]
#     exportMaps(sClusters, sFolder)
#
#
# dControls = {}
# dControls['sFolder'] = controls.FolderPathControl(sSubFolder='maps', bReadOnly=True)
# @uiSettings.addToUI(sTab='Export', sModuleButton='Maps', sRunButton='Export Maps from Selected Meshes', dControls=dControls, bDisableOnServer=True)
# def exportMapSelectedMeshes(sFolder='maps'):
#     sMeshes = cmds.ls(sl=True)
#     sClusters = []
#     for sM in sMeshes:
#         sClusters += [sC for sC in deformers.listAllDeformers(sM, sFilterTypes=['cluster']) if sC.startswith('MAP__')]
#     exportMaps(sClusters, sFolder)
#
#
# def exportMaps(sClusters, sFolder):
#     for sCluster in sClusters:
#         report.report.addLogText('saving for %s..' % sCluster)
#
#         aMap = cmds.getAttr(_getMapAttr(sCluster))
#
#         if not os.path.exists(sFolder): os.makedirs(sFolder)
#
#         sFile = os.path.join(sFolder, '%s.map' % '__'.join(sCluster.split('__')[1:]))
#         with open(sFile, 'wb') as handle:
#             pickle.dump(aMap, handle, protocol=2)
#             # pickle.dump(aMap, handle, protocol=pickle.HIGHEST_PROTOCOL)
#
#
#
#
#
# def getMapFromFile(sFile):
#     with open(sFile, 'rb') as handle:
#         aValues = pickle.load(handle)
#     return aValues
#
#
# def mapSum(sMaps):
#     aaValues = [getMapValues(sM) for sM in sMaps]
#     aSum = reduce(lambda a,b:a+b, aaValues)
#     aSum = np.clip(aSum, 0, 1)
#     return aSum
#
#
# def mapDiff(sMaps):
#     aaValues = [getMapValues(sM) for sM in sMaps]
#     aSum = reduce(lambda a,b:a-b, aaValues)
#     aSum = np.clip(aSum, 0, 1)
#     return aSum
#
#
# def mapProduct(sMaps):
#     aaValues = [getMapValues(sM) for sM in sMaps]
#     aSum = reduce(lambda a,b:a*b, aaValues)
#     return aSum
#
#
# def meshByMap(sOutput, sInput, sModel, sMap):
#     if cmds.objExists(sOutput):
#         return sOutput
#     else:
#         cmds.duplicate(sModel, n=sOutput)
#         if cmds.listRelatives(sOutput, p=True): cmds.parent(sOutput, w=True)
#
#     iSize = cmds.polyEvaluate(sModel, vertex=True)
#
#     if isinstance(sMap, np.ndarray):
#         aValues = sMap
#     else:
#         aValues = getMapValues(sMap)
#
#
#     if len(aValues) != iSize:
#         raise Exception('vertex count doesn\'t match map length')
#
#     sBlendShape = cmds.blendShape(sInput, sOutput, w=[0,1])[0]
#     # cmds.select(sBlendShape)
#     cmds.setAttr('%s.inputTarget[0].baseWeights[0:%d]' % (sBlendShape, iSize-1), *list(aValues))
#
#
#     return sOutput




@uiSettings.addToUI(sRunButton='Head Reset selected Faces', sTab='Geometry', sModuleButton='Head Reset',
                    bReloadBeforeRun=True, dControls={}, tRefreshControlsAfterRun=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsGeometry/#head-reset')
def resetTopologySelectedFaces():
    '''
    This is to have head vertices start from zero
    It creates a cut version of the head, and a new full mesh that blends with the head
    '''
    sFaces = [sO for sO in cmds.ls(sl=True, flatten=True) if '.f[' in sO]
    sMainMesh = sFaces[0].split('.')[0]

    sCopy = cmds.duplicate(sMainMesh, n='mainMesh')[0]
    sSelectedFaces = []
    for sFace in sFaces:
        if sFace.startswith(sMainMesh):
            _,sF = sFace.split('.')
            sSelectedFaces.append('%s.%s' % (sCopy,sF))

    sSelectedVerts = cmds.polyListComponentConversion(sSelectedFaces, fromFace=True, toVertex=True)
    fSelectedVerts = cmds.xform(sSelectedVerts, q=True, ws=True, t=True)

    cmds.select(sSelectedFaces)
    cmds.DetachComponent()

    sSeparates = cmds.polySeparate(sCopy, ch=False)
    sParent = cmds.listRelatives(sSeparates, p=True, c=False)[0]
    cmds.parent(sSeparates, w=True)
    cmds.delete(sParent)

    def _isBorder(sEdge):
        iFaceCount = len(cmds.ls(cmds.polyListComponentConversion(sEdge,
                                                fromEdge=True, toFace=True), flatten=True))
        return True if iFaceCount == 1 else False

    fMinLengths = [-1] * len(sSeparates)
    for m,sMesh in enumerate(sSeparates):
        print('\n\n\n')
        sCheckVertex = None
        for v in range(cmds.polyEvaluate(vertex=True)):
            bIsBorder = False
            sVert = '%s.vtx[%d]' % (sMesh, v)
            sEdges = cmds.ls(cmds.polyListComponentConversion(sVert, fromVertex=True, toEdge=True), flatten=True)
            for sE in sEdges:
                if _isBorder(sE):
                    bIsBorder = True
                    break
            if not bIsBorder:
                sCheckVertex = sVert
                break

        if sCheckVertex == None:
            cmds.select(sMesh)
            raise Exception('couldn\'t find a non border vertex')

        fCheckVertex = cmds.xform(sCheckVertex, q=True, ws=True, t=True)

        for i in range(len(fSelectedVerts) // 3):
            fDiff = [fSelectedVerts[i * 3 + 0] - fCheckVertex[0],
                     fSelectedVerts[i * 3 + 1] - fCheckVertex[1],
                     fSelectedVerts[i * 3 + 2] - fCheckVertex[2]]
            fLength = fDiff[0]*fDiff[0] + fDiff[1]*fDiff[1] + fDiff[2]*fDiff[2]
            if fMinLengths[m] == -1 or fLength < fMinLengths[m]:
                fMinLengths[m] = fLength

    iMinMesh = -1
    fMinDistance = -1
    for m,sMesh in enumerate(sSeparates):
        if iMinMesh == -1 or fMinLengths[m] < fMinDistance:
            iMinMesh = m
            fMinDistance = fMinLengths[m]

    sHead = sSeparates[iMinMesh]
    sHeadReturn = cmds.duplicate(sHead, n='%s_HEAD' % sMainMesh)

    sOthers = [sM for m,sM in enumerate(sSeparates) if m != iMinMesh]
    cmds.select(sHead, sOthers)
    sUnited = cmds.polyUnite(ch=False, n='%s_NEWTOPOLOGY' % sMainMesh)[0]
    cmds.polyMergeVertex(sUnited, ch=False, d=0.0001)

    cmds.select(sHeadReturn, sUnited)

    cmds.transferAttributes(sMainMesh, sUnited, transferUVs=2)
    cmds.delete(sUnited, ch=True)
    cmds.addAttr(sUnited, ln='headFaceCount', defaultValue=cmds.polyEvaluate(sHeadReturn, face=True))
    cmds.setAttr('%s.headFaceCount' % sUnited, lock=True)

    cmds.rename(sMainMesh, '%s_OLD' % sMainMesh)
    cmds.rename(sUnited, sMainMesh)

    return sHeadReturn, sUnited


def yetiFeathersToMeshes(sCurveTransforms, sName='feathers_00', fRadiusQuill=0.02, fRadiusStrands=0.0075, sParent=None):

    sPolys = []
    for f, sF in enumerate(sCurveTransforms):
        cmds.refresh()
        sShapes = cmds.listRelatives(sF, s=True, f=True)
        sCircleQuill = cmds.circle(s=3, d=1, r=fRadiusQuill)[0]
        sCircleStrands = cmds.circle(s=3, d=1, r=fRadiusStrands)[0]

        for s, sShape in enumerate(sShapes):
            sSurface = cmds.extrude(sCircleQuill if s == 0 else sCircleStrands, sShape, ch=False, et=2, ucp=True,
                                    fpt=True, upn=True)
            sPolys.append(cmds.nurbsToPoly(sSurface[0], ch=False, mnd=True, f=3, pt=1, ut=1)[0])
            cmds.delete(sSurface)

    cmds.select(sPolys)
    sUnited = cmds.polyUnite(ch=False, n=sName)[0]
    if sParent:
        cmds.parent(sUnited, sParent)
    return sUnited



def yetiFeathersToProxy(sCurveTransforms, iHeightDivisions=8, sName='feathers_00', fRadiusQuill=0.02, fRadiusStrands=0.0075, sParent=None):
    import kangarooTools.curves as curves

    sProxies = []

    for f,sF in enumerate(sCurveTransforms):
        print('%s..' % sF)
        sPlane = cmds.polyPlane(sx=2, sy=iHeightDivisions, n='%s__PROXY' % sF.split('|')[-1])[0]
        sProxies.append(sPlane)
        aPoints = np.array(cmds.xform('%s.vtx[*]' % sPlane, q=True, ws=True, t=True), dtype='float64').reshape(-1, 3)

        aMidRow = np.where(np.abs(aPoints[:, 0]) < 0.01)[0]
        aLeftRow = np.where(aPoints[:, 0] < -0.25)[0]
        aRightRow = np.where(aPoints[:, 0] > 0.25)[0]


        sShapes = cmds.listRelatives(sF, s=True, f=True)
        aStartPoints = np.array([cmds.xform('%s.cv[0]' % sS, q=True, ws=True, t=True) for sS in sShapes], dtype='float64')
        aEndPoints = np.array([cmds.xform('%s.cv[%d]' % (sS, len('%s.cv[*]' % sS)-1), q=True, ws=True, t=True) for sS in sShapes], dtype='float64')
        sQuill = sShapes[0]
        aPercs = np.interp(np.arange(iHeightDivisions+1), [0,iHeightDivisions], [0.0, 1.0])
        aQuillPoints = curves.getPointsFromPercs(sQuill, aPercs)

        iLongest = len(sShapes) // 2
        aClosestPointMiddle = curves.getPointsFromPoints(sShapes[0], [aEndPoints[iLongest]])[0]

        aLengthVector = aEndPoints[0] - aStartPoints[0]
        aSideVector = aEndPoints[iLongest] - aClosestPointMiddle
        aLengthVector /= np.linalg.norm(aLengthVector)
        aSideVector /= np.linalg.norm(aSideVector)

        aNormVector = np.cross(aLengthVector, aSideVector)
        aMatrix = np.diag(np.ones(4, dtype='float64'))
        aMatrix[0,0:3] = aSideVector
        aMatrix[1,0:3] = aLengthVector
        aMatrix[2,0:3] = aNormVector
        aClosestStarts = xforms.findClosestPoints(aQuillPoints, aStartPoints[1:]) + 1

        aEndPoints4 = utils.makePoint4Array(aEndPoints)
        for iHeight in range(iHeightDivisions+1):
            aPoints[aMidRow[iHeight]] = aQuillPoints[iHeight]

            iLeft = None
            iRight = None
            iClosest = aClosestStarts[iHeight]
            for i in range(len(sShapes)): # will break anyway
                for iInd in [iClosest+i, iClosest-i]:
                    if iInd >= 0 and iInd < len(aEndPoints4):
                        aMatrix[3, 0:3] = aStartPoints[iInd]
                        aLocal4 = np.dot(aEndPoints4[iInd], np.linalg.inv(aMatrix))
                        if aLocal4[0] > 0.0 and iLeft == None:
                            iLeft = iInd
                        elif aLocal4[0] < 0.0 and iRight == None:
                            iRight = iInd

                if iLeft != None and iRight != None:
                    break

            aPoints[aLeftRow[iHeight]] = aEndPoints[iLeft]
            aPoints[aRightRow[iHeight]] = aEndPoints[iRight]

        patch.patchFromName(sPlane).setPoints(aPoints)

    if sParent and sProxies:
        cmds.parent(sProxies, sParent)



def getUvsFromMesh(sMesh, sUvSet=None):
    fnMesh = OpenMaya2.MFnMesh(utils.getDagPath(sMesh))
    mUvs = fnMesh.getUVs() if utils.isNone(sUvSet) else fnMesh.getUVs(uvSet=sUvSet)
    aUVs = np.array(list(zip(list(mUvs[0]), list(mUvs[1]))))
    return aUVs






def getRandomPointsOnMesh(sMeshSelection, iCount, sAvoidTransforms=[]):
    pMesh = patch.patchFromName(sMeshSelection[0].split('.')[0])

    sFaces = cmds.ls(cmds.polyListComponentConversion(sMeshSelection, toFace=True), flatten=True)
    iFaces = [int(sF.split('[')[-1].split(']')[0]) for sF in sFaces]
    iFacesSet = set(iFaces)

    faceIter = OpenMaya2.MItMeshPolygon(pMesh.mDagPath)
    aAllFaces = np.zeros((len(iFaces),3), dtype='float64')

    iEdges = []
    for f,iF in enumerate(iFaces):
        faceIter.setIndex(iF)
        mCenter = faceIter.center(space=OpenMaya2.MSpace.kWorld)
        aAllFaces[f,0:3] = mCenter.x, mCenter.y, mCenter.z
        iEdges += faceIter.getEdges()
    iEdges = sorted(list(set(iEdges)))

    edgeIter = OpenMaya2.MItMeshEdge(pMesh.mDagPath)
    mBorderPoints = []
    for e,iE in enumerate(iEdges):
        edgeIter.setIndex(iE)
        iConnectedFaces = edgeIter.getConnectedFaces()
        if len(iConnectedFaces) == 1:
            mBorderPoints.append(edgeIter.center())
        elif len(iConnectedFaces) == 2:
            if iConnectedFaces[0] not in iFacesSet or iConnectedFaces[1] not in iFacesSet:
                mBorderPoints.append(edgeIter.center())
        else:
            raise 'this is a weird edge.. don\'t know what to do with that: %s.e[%d]' % (pMesh.getTransformName(),iE)

    fAvoidJoints = [cmds.xform(sX, q=True, ws=True, t=True) for sX in sAvoidTransforms]

    aAvoids = np.array(fAvoidJoints, dtype='float64').reshape(-1, 3)
    if mBorderPoints:
        aAvoids = np.concatenate([aAvoids, np.array(mBorderPoints, dtype='float64')[:,0:3]])

    iDots = []
    iAllFacesCount = len(aAllFaces)
    fReturnPoints = []
    for i in range(iCount):
        if len(iDots) >= len(aAllFaces):
            cmds.warning('reached possible number of joints (%d)' % len(aAllFaces))
            break

        if len(aAvoids):
            aToPoints = np.concatenate([aAllFaces[iDots], aAvoids])
        else:
            aToPoints = aAllFaces[iDots]
        if not len(aToPoints):
            iDots.append(0)
            continue
        iToPointsCount = len(aToPoints)
        aToPointsRep = np.repeat(aToPoints[np.newaxis,:], iAllFacesCount, axis=0).reshape(iAllFacesCount,iToPointsCount,3)
        aFromPointsRep = np.repeat(aAllFaces, iToPointsCount, axis=0).reshape(iAllFacesCount,iToPointsCount,3)
        aDiff = aToPointsRep - aFromPointsRep
        aDistances = np.linalg.norm(aDiff, axis=-1)
        aSmallestDistances = np.min(aDistances, axis=1)
        iBiggestSmallest = np.argmax(aSmallestDistances)
        iDots.append(iBiggestSmallest)
        fReturnPoints.append(aAllFaces[iBiggestSmallest])


    return np.array(fReturnPoints, dtype='float64')


def deleteColorSets(sMeshes):
    for sMesh in sMeshes:
        sSets = cmds.polyColorSet(sMesh, q=True, allColorSets=True) or []
        for sSet in sSets:
            print('deleteing "%s" in mesh "%s"..' % (sSet, sMesh))
            cmds.polyColorSet(sMesh, colorSet=sSet, delete=True)





dControls = {}
dControls['fUpVector'] = controls.VectorControl()
@uiSettings.addToUI(sRunButton='Slide', sTab='Geometry', sModuleButton='Curve', bReloadBeforeRun=True,
                    dControls=dControls, tRefreshControlsAfterRun=[])
def slideAlongCurve(_pSelection=None, sCurve='', fStrength=0.1, fUpVector=(0,1,0)):
    '''
Here you can slide or move perpendicular some vertices along a curve. It can be useful for sculpting some expressions\
on a very curved mouth
    '''
    pMesh = patch.getSelectedPatches()[0]
    aPoints = pMesh.getPoints()
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    fCurveLength = fnCurve.length()

    for i,aP in enumerate(aPoints):
        mPoint = OpenMaya2.MPoint(aP)
        aP4 = utils.makePoint4(aP)
        mCurvePoint, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)

        aCurvePoint = np.array([mCurvePoint[0], mCurvePoint[1], mCurvePoint[2]], dtype='float64')

        aTangent = np.array(fnCurve.tangent(fParam, space=OpenMaya2.MSpace.kWorld), dtype='float64')
        aUp = np.array(fUpVector, dtype='float64')
        aPerp = np.cross(aTangent, aUp)
        aUp = np.cross(aTangent, aPerp)
        aPerp = np.cross(aTangent, aUp)
        aMatrix = utils.numpyMatrixFromVectors(aCurvePoint, aTangent, aUp, aPerp)
        aInvStartMatrix = np.linalg.inv(aMatrix)

        fStartPerc = fnCurve.findLengthFromParam(fParam) / fCurveLength
        fNewPerc = fStartPerc + fStrength
        fNewParam = fnCurve.findParamFromLength(fNewPerc * fCurveLength)

        aTangent = np.array(fnCurve.tangent(fNewParam, space=OpenMaya2.MSpace.kWorld), dtype='float64')
        mNewPoint = fnCurve.getPointAtParam(fNewParam)
        aNewPoint = np.array([mNewPoint[0], mNewPoint[1], mNewPoint[2]], dtype='float64')
        aUp = np.array(fUpVector, dtype='float64')
        aPerp = np.cross(aTangent, aUp)
        aUp = np.cross(aTangent, aPerp)
        aPerp = np.cross(aTangent, aUp)
        aNewMatrix = utils.numpyMatrixFromVectors(aNewPoint, aTangent, aUp, aPerp)

        aLocalP4 = np.dot(aP4, aInvStartMatrix)
        aMovedP4 = np.dot(aLocalP4, aNewMatrix)

        aMovedP = aMovedP4[0:3]
        if not utils.isNone(pMesh.aSofts):
            aMovedP = aMovedP * pMesh.aSofts[i] + aP * (1.0-pMesh.aSofts[i])
        aPoints[i] = aMovedP

    pMesh.setPoints(aPoints, aIds=pMesh.aIds)



@uiSettings.addToUI(sRunButton='Perpendicular', sTab='Geometry', sModuleButton='Curve', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def slidePerpendicularToCurve(_pSelection=None, sCurve='', fStrength=0.1, fUpVector=(0,1,0)):

    pMesh = patch.getSelectedPatches()[0]
    aPoints = pMesh.getPoints()
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    for i,aP in enumerate(aPoints):
        mPoint = OpenMaya2.MPoint(aP)
        mCurvePoint, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)

        aCurvePoint = np.array([mCurvePoint[0], mCurvePoint[1], mCurvePoint[2]], dtype='float64')

        aTangent = np.array(fnCurve.tangent(fParam, space=OpenMaya2.MSpace.kWorld), dtype='float64')
        aUp = np.array(fUpVector, dtype='float64')
        aPerp = np.cross(aTangent, aUp)
        aUp = np.cross(aTangent, aPerp)
        aPerp = np.cross(aTangent, aUp)
        aMatrix = utils.numpyMatrixFromVectors(aP, aTangent, aUp, aPerp)

        aMovedP4 = np.dot(np.array([0,0,fStrength*10,1]), aMatrix)
        aMovedP = aMovedP4[0:3]

        if not utils.isNone(pMesh.aSofts):
            aMovedP = aMovedP * pMesh.aSofts[i] + aP * (1.0-pMesh.aSofts[i])
        aPoints[i] = aMovedP

    pMesh.setPoints(aPoints, aIds=pMesh.aIds)





dControls = {}
@uiSettings.addToUI(sRunButton='Smooth', sTab='Geometry', sModuleButton='Smooth Vertices', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[])
def smoothVertices(_pSelection=None, iIterations=8, bIncludeNeighborsNotInIds=True, bBarycentricWeighted=False, bKeepEndPointsOfLine=False):
    '''
    This relaxes the vertices. It's similar to the smooth sculpting tool, but works just on vertex (soft) selection.
    It's very useful for when sculpting Correctives and you want to relax some faces that are collapsed from a pose.
    '''
    sSelBefore = cmds.ls(sl=True)

    if utils.isNone(_pSelection):
        _pSelection = patch.getSelectedPatches()
    else:
        _pSelection = utils.toList(_pSelection)
    cmds.undoInfo(openChunk=True)
    try:
        if bKeepEndPointsOfLine:
            import kangarooTools.curves as curves
            try:
                aLine = curves.getSelectedOrderedPoints()
            except Exception as e:
                cmds.confirmDialog(m='Error getting line. If you turn on Keep Endpoints of Line, you\'ll have to select a clean vertex line')
                raise

        for pSelected in _pSelection:
            aNbsArray, aIdsWithNeighbors, aMap_indsWithNeighbors_to_inds, aNeighborSizesDenoms2d = \
                pSelected.getNeighborDataForSmoothing(bBarycentricWeighted=bBarycentricWeighted, bIncludeNeighborsNotInIds=bIncludeNeighborsNotInIds)

            aFullPoints = pSelected.getAllPoints()
            aPoints = np.concatenate([aFullPoints[aIdsWithNeighbors], np.array([[0,0,0]], dtype='float64')])
            aOldPointsFiltered = aPoints[aMap_indsWithNeighbors_to_inds]

            if not utils.isNone(pSelected.aSofts):
                aStrength = np.copy(pSelected.aSofts)
            else:
                aStrength = np.ones(len(pSelected.aIds))

            if bKeepEndPointsOfLine:
                iStartInd = np.where(pSelected.aIds==aLine[0])[0][0]
                iEndInd = np.where(pSelected.aIds==aLine[-1])[0][0]
                aStrength[iStartInd] = 0.0
                aStrength[iEndInd] = 0.0

            for _ in range(iIterations):
                aMultipls = aPoints[aNbsArray] * aNeighborSizesDenoms2d[..., np.newaxis]
                aPoints[aMap_indsWithNeighbors_to_inds] = np.sum(aMultipls, axis=-2)
                aPoints[aMap_indsWithNeighbors_to_inds] = aPoints[aMap_indsWithNeighbors_to_inds] * aStrength[:,np.newaxis] + \
                                                           aOldPointsFiltered * (1.0-aStrength[:,np.newaxis])

            pSelected.setPoints(aPoints[aMap_indsWithNeighbors_to_inds], aIds=pSelected.aIds)

        cmds.select(sSelBefore)
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)

