###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from collections import defaultdict, OrderedDict
import os
import numpy as np


import maya.cmds as cmds
import kangarooTools.controlsPuppet as controlsPuppet
import kangarooTools.utilFunctions as utils
import kangarooTools.uiSettings as uiSettings
import kangarooTools.controls as controls
import kangarooTools.curves as curves
import kangarooTools.nodes as nodes
import kangarooTools.assets as assets
import kangarooTools.blueprints as blueprints
import kangarooTools.xforms as xforms
import kangarooTools.report as report
import kangarooTools.constraints as constraints
import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls2 as ctrls2
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.ctrls5 as ctrls5
import kangarooTabTools.ctrls6 as ctrls6
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.ctrls8 as ctrls8
import kangarooTabTools.ctrls9 as ctrls9
import kangarooTools.utilsQt as utilsQt
import kangarooTools.match as match

try:
    import kangarooTools.utilsUnreal as utilsUnreal
except:
    utilsUnreal = None


_kRowHeight = utilsQt.getDpi() / 5

# bUnrealControlRig = True
if utilsUnreal:
    utils.reload2(utilsUnreal)
    pass

@uiSettings.addToUI(sRunButton='Save', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls = {}, bDisableOnServer=True, sToolTip='Saves the .rig file. It does NOT save Blueprints!')
def saveToFile(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr'), {}], _qApplyButton=None):

    sFile, dLimbs = xLimbs


    for l,dL in enumerate(dLimbs):

        dNewL = {}

        for k,v in list(dL.items()):

            if k.endswith('FILE'):
                if k.endswith('sOutputsFILE'):
                    if v:
                        dNewL[k] = v
                elif k.endswith('dArgsFILE'):
                    kDefault = '%sdArgDefaults' % k[0:-len('dArgsFILE')]
                    dArgDefaults = dL[kDefault]
                    dNewArgs = {k0:v0 for k0,v0 in list(v.items()) if k0 in list(dArgDefaults.keys()) and dArgDefaults[k0] != v0}
                    dNewL[k] = dNewArgs
                else:
                    dNewL[k] = v
            elif k == '__parent__':
                dNewL[k] = v

        dLimbs[l] = dNewL


    if isinstance(sFile, list):
        sFile = sFile[0]

    puppetDataUtils.fileDump(sFile, dLimbs)

    _qApplyButton.setText('Save')

    utils.saveBackupFile(sFile, sFolderName='_puppetBackup')



dControls = {}
dControls['all'] = controlsPuppet.TLibraryListControl()
dControls['xLimbs'] = controlsPuppet.TLimbsControl(dControls['all'])
dControls['xAttrs'] = controlsPuppet.TLimbAttrs(dControls['xLimbs'])
dCreatedLimbs = OrderedDict()


@uiSettings.addToUI(sRunButton='Clean', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls=dControls, tRefreshControlsAfterRun=[], sTabControls=['xAttrs'], sToolTip='Makes new scene and reloads all (most) modules')
def clean():
    ctrls5.checkBeforeNewScene(assets.assetManager.getCurrentVersionPath())
    import kangarooTabTools.weights as weights
    weights.checkBeforeNewScene(assets.assetManager.getCurrentVersionPath(sSubPath='deformers'))

    
    cmds.file(new=True, f=True)
    report.report.addLogText('reloading all limbs..')
    puppetDataUtils.limbsFromFiles(bReload=True)

    for module in [nodes, xforms, curves, ctrls, ctrls2, ctrls3, ctrls4, ctrls5, ctrls6, ctrls7, ctrls8, ctrls9, blueprints, constraints, match]:
        print('reloading %s' % module.__name__)
        report.report.addLogText('reloading %s' % module.__name__)
        utils.reload2(module)



def buildRigClean(all=None, xAttrs=None, xLimbs=[os.path.expanduser('~/Documents/puppet.tbr'), {}], _bClearBeforeBuild=True):
    buildRig(all=all, xAttrs=xAttrs, xLimbs=xLimbs, _bClearBeforeBuild=True)


sMannequinReplacedLimbs = ['m_global', 'm_placement', 'm_cog', 'm_spine', 'l_leg', 'r_leg', 'm_hips', 'm_spine', 'l_clavicle', 'r_clavicle', 'l_arm',
                           'r_arm', 'm_neck', 'm_head', 'l_index', 'l_middle', 'l_ring', 'l_pinky', 'l_thumb',  'r_index', 'r_middle', 'r_ring', 'r_pinky', 'r_thumb',  'l_eye', 'r_eye']


@uiSettings.addToUI(sRunButton='Test Build', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls=dControls,
                    tRefreshControlsAfterRun=[], sTabControls=['xAttrs'], sToolTip='Test builds it',
                    sDocumentationLink='https://kangaroobuilder.com/puppet/puppetGeneral/')
def buildRig(all=None, xAttrs=None, xLimbs=[os.path.expanduser('~/Documents/puppet.tbr'), {}], sMaster='master', sPostFix='', _bClearBeforeBuild=False,
             _bReloadLimbs=True, _bFromUI=True, _bMetahumanJoints=False, _dDisplayCtrlAttributeOrder={}, _dDynamicStrengthAttributesOrder={}, _bBuildUnrealPuppet=None):
    dDisplayCtrlAttributeOrder = dict(_dDisplayCtrlAttributeOrder)
    dDynamicStrengthAttributesOrder = dict(_dDynamicStrengthAttributesOrder)
    def _updateCtrlAttributeOrders():
        sProccessedDisplayCtrls = []
        for sDisplayCtrl, sAttributes in dDisplayCtrlAttributeOrder.items():
            if cmds.objExists(sDisplayCtrl):
                for sA in sAttributes:
                    utils.addOffOnAttr(sDisplayCtrl, sA, bDefaultValue=True, bReturnIfExists=True)
                sProccessedDisplayCtrls.append(sDisplayCtrl)
        for sDisplayCtrl in sProccessedDisplayCtrls:
            del dDisplayCtrlAttributeOrder[sDisplayCtrl]

        sProccessedDynamicCtrls = []
        for sDisplayCtrl, sAttributes in dDynamicStrengthAttributesOrder.items():
            if cmds.objExists(sDisplayCtrl):
                for sA in sAttributes:
                    utils.addAttr(sDisplayCtrl, ln=sA, min=0.0, max=1.0, dv=0.0, k=True, bReturnIfExists=True)
                sProccessedDynamicCtrls.append(sDisplayCtrl)
        for sDisplayCtrl in sProccessedDynamicCtrls:
            del dDynamicStrengthAttributesOrder[sDisplayCtrl]

    try:


        if _bClearBeforeBuild:
            cmds.file(new=True, f=True)

        puppetDataUtils.limbsFromFiles(bReload=_bClearBeforeBuild)

        cmds.undoInfo(st=False)

        _, dLimbs = xLimbs

        dLimbs = [dL for dL in dLimbs if dL.get('bDisabledFILE', False) == False]

        report.report.resetProgress(len(dLimbs)*3+3)

        sMaster, sModules, sSkeleton, sCtrls, sModel = assets.createTopGroups(sMaster=sMaster, sPostFix=sPostFix)

        global dCreatedLimbs
        dCreatedLimbs.clear()
        dLimbLibrary = puppetDataUtils.limbsFromFiles()
        dCreatedLimbVersions = defaultdict(list)

        dMergedDatas = {}
        for xFileData in dLimbs:
            report.report.incrementProgress()
            sLimbClass = xFileData['sClassTypeFILE']
            iVersion = xFileData['iVersionFILE']
            LLimbClass = dLimbLibrary[sLimbClass][iVersion]

            lLimb, dMergedData = puppetDataUtils.mergeClassWithData(LLimbClass, xFileData)
            # lLimb.updateReport()

            lLimb.dMergedData = dMergedData
            sLimbName = '%s_%s' % (lLimb.sSide, lLimb.sName)
            report.report.addLogText('Building Limb "%s"' % sLimbName)

            dMergedDatas[sLimbName] = dMergedData
            sParentLimb = lLimb.dMergedData['__parent__']

            if sParentLimb:
                lLimb.lParent = dCreatedLimbs[sParentLimb]
                sParentOutput = lLimb.dMergedData['parentOutputFILE']
                lLimb.sApproximateParentBlueprint = lLimb.lParent.guessBlueprintFromOutput(sParentOutput)
            else:
                lLimb.lParent = None
                lLimb.sApproximateParentBlueprint = None

            lLimb.sBpSkelGrp = _getBlueprintsGroupNameFromPuppetFile(xLimbs[0])
            lLimb.createOrSetBlueprints(lParent=lLimb.lParent)
            lLimb.setGlobalGroups(sMaster, sModules, sSkeleton, sCtrls, sModel)
            lLimb.buildTopGroups()
            lLimb.createFeatureShape()

            _updateCtrlAttributeOrders()

            sVersionAttr = utils.addAttr(lLimb.sTopGrp, ln='iVersion', defaultValue=iVersion, k=True)
            cmds.setAttr(sVersionAttr, lock=True)


            # for sFeat, dFeat in dFileFeatureData.items():
            for sFeature in dMergedData['sFeatures']:
                if dMergedData['%s.bCheckedFILE' % sFeature] == True:
                    dFeatureArgs = lLimb.dMergedData['%s.dArgsFILE' % sFeature]
                    lLimb.buildFeature(sFeature, dFeatureArgs)
                    _updateCtrlAttributeOrders()



            # lLimb.createFeatureShape()
            lLimb.createOutputs(dMergedData.get('sStartFeatureFILE', None))
            lLimb.attachFeatureCtrl()
            lLimb.fillAllCtrlLists()

            # for sFeat, dFeat in dFileFeatureData.items():
            # sUsedDetails = []
            for sDetail in dMergedData['sDetails']:
                if dMergedData['%s.bCheckedFILE' % sDetail] == True:
                    # sUsedDetails.append(sDetail)
                    dDetailArgs = lLimb.dMergedData['%s.dArgsFILE' % sDetail]
                    lLimb.buildDetail(sDetail, dDetailArgs)
                    break

            lLimb.createOutoutputsAttr()

            for sName,sJoint in list(lLimb.dOutputs.items()):
                utils.addStringAttr(sJoint, 'sLimbJoint', lLimb.sLimbName)
                utils.addStringAttr(sJoint, 'sOutputName', sName)

            dCreatedLimbs[sLimbName] = lLimb
            dCreatedLimbVersions['%s.%d' % (sLimbClass, iVersion)] = lLimb
            cmds.setAttr('%s.v' % lLimb.sBpSkelGrp, False)

            lLimb.removeEndSkinJoint()



        # static post setups
        for sClassVersion in list(dCreatedLimbVersions.keys()):
            sLimbClass, sVersion = sClassVersion.split('.')
            iVersion = int(sVersion)
            LLimbClass = dLimbLibrary[sLimbClass][iVersion]
            LLimbClass.staticPostSetup()


        # connect attachers
        print('\n\n\n\n================= connect attachers.. =================')
        report.report.addLogText('\n\n Connect Attachers...')

        for sLimbName, lLimb in list(dCreatedLimbs.items()):
            report.report.incrementProgress()
            print('=== doing limb: ', sLimbName)
            lLimb.parentSkeleton(dCreatedLimbs)
            lLimb.connectAttachers(dCreatedLimbs)



        # add scale groups for joints
        dScaleTransforms = {}
        for sLimbName, lLimb in list(dCreatedLimbs.items()):
            if 'scale.sOutputsFILE' in lLimb.dMergedData:
                sScaleOutputs = [sO for sO in lLimb.dMergedData['scale.sOutputsFILE'] if not sO.startswith(utils.kNoneString)]
                if sScaleOutputs:
                    sScaleOutputLimb, sScaleOutputName, sScaleOutputAttrName, iScaleWeight = utils.extractOutputInfo(sScaleOutputs[0])

                    if sScaleOutputLimb == utils.kCustomString:

                        # sScaleOutputTransform = xforms.createTransform('grp_customScaleTransform_%s' % sScaleOutputName,
                        #                                           sParent=xforms.createIfNotExists('grp_customTransforms', sParent=sModules))
                        # utils.addStringAttr(sScaleOutputTransform, 'sParent', sScaleOutputName)

                        # once everything is using new costum function in constraints.py, we could remove this one:
                        if sScaleOutputName:
                            if not cmds.objExists(sScaleOutputName):
                                raise Exception('"%s": for scale attachment the transforms have to be there already ("%s")' % (sLimbName, sScaleOutputName))
                            else:
                                sScaleOutputTransform = sScaleOutputName
                    else:
                        tScaleOutputLimb = dCreatedLimbs[sScaleOutputLimb]
                        sScaleOutputTransform = tScaleOutputLimb.dOutputs[sScaleOutputName]
                    dScaleTransforms[sLimbName] = sScaleOutputTransform


        def __scaleChildrenREC__(sJoint, bIsRoot=False, sCurrentLimb=None, sLastConstrainer=None):
            if not bIsRoot:
                sAttr = '%s.sLimbName' % sJoint
                if not cmds.objExists(sAttr):
                    cmds.warning('%s doesn\'t have sLimbName attribute' % sJoint)
                    sNewLimb = sCurrentLimb
                else:
                    sNewLimb = cmds.getAttr(sAttr)
                if sNewLimb != sCurrentLimb:
                    if sNewLimb in dScaleTransforms:
                        sNewConstrainer = dScaleTransforms[sNewLimb]
                        if sNewConstrainer != sLastConstrainer:
                            sParent = cmds.listRelatives(sJoint, p=True)[0]
                            sScaleParent = 'grp_%s_SCALE_%s' % (sNewConstrainer, sParent)
                            if not cmds.objExists(sScaleParent):
                                cmds.createNode('transform', n=sScaleParent, p=sParent)
                                cmds.setAttr('%s.t' % sScaleParent, 0,0,0)
                                cmds.setAttr('%s.r' % sScaleParent, 0, 0, 0)
                                cmds.scaleConstraint(sNewConstrainer, sScaleParent)
                            cmds.parent(sJoint, sScaleParent)
                            sLastConstrainer = sNewConstrainer

                    sCurrentLimb = sNewLimb

            for sJ in cmds.listRelatives(sJoint, c=True, typ='joint') or []:
                __scaleChildrenREC__(sJ, sCurrentLimb=sCurrentLimb, sLastConstrainer=sLastConstrainer)

        __scaleChildrenREC__(sSkeleton, bIsRoot=True)
        report.report.incrementProgress(3)



        dChildren = _getChildrenDictFromCreatedLimbs(dCreatedLimbs)


        print('================= childrenConnect functions.. =================')
        for sParent, lChildren in list(dChildren.items()):
            if sParent == None:
                continue
            lParentLimb = dCreatedLimbs[sParent]
            sChildrenTypes = [utils.getClassNameFromClass(type(tC)) for tC in lChildren]
            for sFunc in lParentLimb.dMergedData['sChildrenConnects']:
                sFuncType = sFunc.split('_')[-1]
                lMatchingChildren = []
                for c, tChild in enumerate(lChildren):
                    if sChildrenTypes[c] == sFuncType: lMatchingChildren.append(tChild)
                if lMatchingChildren:
                    func = getattr(lParentLimb, sFunc)
                    func(_lChildren=lMatchingChildren)


        for sLimbName, lLimb in list(dCreatedLimbs.items()):
            lLimb.finalCleanup(dCreatedLimbs=dCreatedLimbs, lChildren=dChildren[sLimbName])

        for sLimbName, lLimb in list(dCreatedLimbs.items()):
            lLimb.pickwalkChildrenSetups(dChildren[sLimbName])


        # clean constraints under skeleton
        sChildren = cmds.listRelatives(sSkeleton, ad=True, c=True) or []
        sConstraints = [sC for sC in sChildren if cmds.objectType(sC).endswith('Constraint')]
        sConstraintGroup = cmds.createNode('transform', n='skeletonConstraints%s' % sPostFix, p=sMaster)
        if sConstraints:
            cmds.parent(sConstraints, sConstraintGroup)

        cmds.delete([sC for sC in cmds.ls('__features__*', et='transform') if cmds.objExists('%s.tempFeatureCurveDelete' % sC)])
        if _bFromUI:
            cmds.setAttr('%s.skeletonVis' % sMaster, True)


        if _bMetahumanJoints:
            sFile = os.path.join(os.path.dirname(__file__), os.pardir, 'mayaImport', 'SKM_Manny.ma')
            utils.importMayaFiles(sFile, sNamespace='game')[0]
            sGameSkeleton = cmds.rename('game:SKM_Manny', 'GAMESKELETON')
            cmds.parent(sGameSkeleton, sMaster)
            cmds.createNode('transform', n='GAMEMODEL', p='GAMESKELETON')
            sUnrealHelpers = ['ankle_bck_l', 'ankle_bck_r', 'ankle_fwd_l', 'ankle_fwd_r', 'calf_correctiveRoot_l',
                              'calf_correctiveRoot_r', 'clavicle_out_l', 'clavicle_out_r',
                              'clavicle_pec_l', 'clavicle_pec_r', 'clavicle_scap_l', 'clavicle_scap_r',
                              'lowerarm_correctiveRoot_l', 'lowerarm_correctiveRoot_r', 'spine_04_latissimus_l',
                              'spine_04_latissimus_r', 'thigh_bck_l', 'thigh_bck_lwr_l', 'thigh_bck_lwr_r',
                              'thigh_bck_r', 'thigh_fwd_l', 'thigh_fwd_lwr_l', 'thigh_fwd_lwr_r',
                              'thigh_fwd_r', 'thigh_in_l', 'thigh_in_r', 'thigh_out_l', 'thigh_out_r', 'upperarm_bck_l',
                              'upperarm_bck_r', 'upperarm_bicep_l', 'upperarm_bicep_r',
                              'upperarm_fwd_l', 'upperarm_fwd_r', 'upperarm_in_l', 'upperarm_in_r', 'upperarm_out_l',
                              'upperarm_out_r', 'upperarm_tricep_l', 'upperarm_tricep_r',
                              'wrist_inner_l', 'wrist_inner_r', 'wrist_outer_l', 'wrist_outer_r',
                              'upperarm_twistCor_01_l', 'upperarm_twistCor_02_l',
                              'upperarm_twistCor_01_r', 'upperarm_twistCor_02_r',
                              'thigh_twistCor_01_l', 'thigh_twistCor_02_l',
                              'thigh_twistCor_01_r', 'thigh_twistCor_02_r',
                              'upperarm_correctiveRoot_l', 'upperarm_correctiveRoot_r', 'thigh_correctiveRoot_l',
                              'thigh_correctiveRoot_r']
            for sJ in sUnrealHelpers:
                sNamespacedJ = 'game:%s' % sJ
                if cmds.objExists(sNamespacedJ):
                    cmds.delete(sNamespacedJ)

            # cmds.parent(sGameSkeleton, utils.getMasterName())
            xxMapData = getMetahumanMapData()

            for s, sSide in enumerate(['l', 'r']):
                # upper arm
                sKangarooTwists = cmds.ls('jnt_%s_arm_upperTwist_???' % sSide)[1:]
                sUnrealTwists = cmds.ls('game:upperarm_twist_??_%s' % sSide)
                for i in range(len(sUnrealTwists), len(sKangarooTwists), 1):
                    sNewUnrealTwist = 'game:upperarm_twist_%02d_%s' % ((i + 1), sSide)
                    cmds.duplicate(sUnrealTwists[-1], n=sNewUnrealTwist, po=True)[0]
                    xxMapData.append([sKangarooTwists[i], sNewUnrealTwist.split(':')[-1], True, None])
                    # utils.matchJointRadius(sNewUnrealTwist, sKangarooTwists[i])
                # lower arm
                sKangarooTwists = cmds.ls('jnt_%s_arm_lowerTwist_???' % sSide)[1:]
                sUnrealTwists = cmds.ls('game:lowerarm_twist_??_%s' % sSide)
                for i in range(len(sUnrealTwists), len(sKangarooTwists), 1):
                    sNewUnrealTwist = 'game:lowerarm_twist_%02d_%s' % ((i + 1), sSide)
                    cmds.duplicate(sUnrealTwists[-1], n=sNewUnrealTwist, po=True)[0]
                    xxMapData.append([sKangarooTwists[i], sNewUnrealTwist.split(':')[-1], True, None])
                    # utils.matchJointRadius(sNewUnrealTwist, sKangarooTwists[i])
                # upper leg
                sKangarooTwists = cmds.ls('jnt_%s_leg_upperTwist_???' % sSide)[1:]
                sUnrealTwists = cmds.ls('game:thigh_twist_??_%s' % sSide)
                for i in range(len(sUnrealTwists), len(sKangarooTwists), 1):
                    sNewUnrealTwist = 'game:thigh_twist_%02d_%s' % ((i + 1), sSide)
                    cmds.duplicate(sUnrealTwists[-1], n=sNewUnrealTwist, po=True)[0]
                    xxMapData.append([sKangarooTwists[i], sNewUnrealTwist.split(':')[-1], True, None])
                    # utils.matchJointRadius(sNewUnrealTwist, sKangarooTwists[i])
                # lower leg
                sKangarooTwists = cmds.ls('jnt_%s_leg_lowerTwist_???' % sSide)[1:]
                sUnrealTwists = cmds.ls('game:calf_twist_??_%s' % sSide)
                for i in range(len(sUnrealTwists), len(sKangarooTwists), 1):
                    sNewUnrealTwist = 'game:calf_twist_%02d_%s' % ((i + 1), sSide)
                    cmds.duplicate(sUnrealTwists[-1], n=sNewUnrealTwist, po=True)[0]
                    xxMapData.append([sKangarooTwists[i], sNewUnrealTwist.split(':')[-1], True, None])
                    # utils.matchJointRadius(sNewUnrealTwist, sKangarooTwists[i])



            for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
                sNamespacedUnreal = 'game:%s' % sUnreal
                if not cmds.objExists(sKangaroo):
                    if cmds.objExists(sNamespacedUnreal):
                        pass
                else:
                    if bPosition:
                        cmds.delete(cmds.pointConstraint(sKangaroo, sNamespacedUnreal))
                    if xRotation:
                        fAim, fUp = xRotation
                        sTempAim = xforms.createLocator('tempAim', sParent=sKangaroo, xPos=[1, 0, 0])
                        sTempUp = xforms.createLocator('tempUp', sParent=sKangaroo, xPos=[0, 1, 0])
                        cmds.delete(
                            cmds.aimConstraint(sTempAim, sNamespacedUnreal, wut='object', wuo=sTempUp, aim=fAim, u=fUp))
                        cmds.delete(sTempAim, sTempUp)
                        cmds.makeIdentity(sNamespacedUnreal, r=True, apply=True)
                    if cmds.objectType(sNamespacedUnreal) == 'joint' and cmds.objectType(sKangaroo) == 'joint':
                        xforms.matchRadius(sNamespacedUnreal, sKangaroo)

            cmds.rotate(180, 0, 0, 'game:heel_r', r=True, os=True)

            dUnrealJoints = getInitialUnrealJoints(xxMapData=xxMapData)
            utils.data.store('dUnrealJoints', dUnrealJoints)

            cmds.setAttr('%s.v' % sGameSkeleton, False)


        # unreal control rig
        bBuildUnrealPuppet = utils.data.get('bBuildUnrealPuppet', xDefault=False)

        if bBuildUnrealPuppet and utilsUnreal:
            utilsUnreal.processLimbsForControlRig(dCreatedLimbs, dMergedDatas, dChildren)


    except:
        raise
    finally:
        cmds.undoInfo(st=True)



def getInitialUnrealJoints(xxMapData=None):
    if utils.isNone(xxMapData):
        xxMapData = getMetahumanMapData()
    xxExtraSkinData = []
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        sAttr = '%s.segmentsData' % sKangaroo
        if cmds.objExists(sAttr):
            dSegmentsData = eval(cmds.getAttr(sAttr)) # {'sSearchReplace': 'Spine;SpineSquash'}";
            sSearchReplace = dSegmentsData.get('sSearchReplace', None)
            if not utils.isNone(sSearchReplace):
                sSearch, sReplace = sSearchReplace.split(';')
                if sSearch in sKangaroo:
                    sReplacedJoint = sKangaroo.replace(sSearch, sReplace)
                    if cmds.objExists(sReplacedJoint):
                        xxExtraSkinData.append([sReplacedJoint, sUnreal, bPosition, xRotation])
    # xxExtraSkinData.append(['jnt_l_thumbMeta', 'hand_l', None, None])
    # xxExtraSkinData.append(['jnt_r_thumbMeta', 'hand_r', None, None])
    xxMapData += xxExtraSkinData

    return {sKangaroo: sUnreal for sKangaroo, sUnreal, bPosition, xRotation in xxMapData}


def getMetahumanMapData():
    xxMapData = []
    xxMapData.append(['jnt_r_armWrist', 'ik_hand_gun', True, None])
    xxMapData.append(['jnt_l_armWrist', 'ik_hand_l', True, None])
    xxMapData.append(['jnt_l_legWrist', 'ik_foot_l', True, None])
    xxMapData.append(['jnt_m_hips', 'pelvis', True,  [(0,0,-1),(1,0,0)]])
    xxMapData.append(['jnt_l_leg_upperTwist_000', 'thigh_l', True, [(-1,0,0),(0,1,0)]])
    xxMapData.append(['jnt_l_leg_upperTwist_001', 'thigh_twist_01_l', True, None])
    xxMapData.append(['jnt_l_leg_upperTwist_002', 'thigh_twist_02_l', True, None])
    xxMapData.append(['jnt_l_leg_lowerTwist_000', 'calf_l', True, [[-1,0,0], [0,1,0]]])
    xxMapData.append(['jnt_l_leg_lowerTwist_001', 'calf_twist_01_l', True, None])
    xxMapData.append(['jnt_l_leg_lowerTwist_002', 'calf_twist_02_l', True, None])
    xxMapData.append(['jnt_l_legWrist', 'foot_l', True, None])
    xxMapData.append(['jnt_l_legFingers', 'ball_l', True, None])
    xxMapData.append(['jnt_m_spineSpine_000', 'spine_01', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_001', 'spine_02', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_002', 'spine_03', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_003', 'spine_04', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_end', 'spine_05', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_clavicleMain', 'clavicle_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_upperTwist_000', 'upperarm_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_upperTwist_001', 'upperarm_twist_01_l', True, None])
    xxMapData.append(['jnt_l_arm_upperTwist_002', 'upperarm_twist_02_l', True, None])
    xxMapData.append(['jnt_l_arm_lowerTwist_000', 'lowerarm_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_lowerTwist_001', 'lowerarm_twist_01_l', True, None])
    xxMapData.append(['jnt_l_arm_lowerTwist_002', 'lowerarm_twist_02_l', True, None])
    xxMapData.append(['jnt_l_armWrist', 'hand_l', True, [(1,0,0), (0,0,-1)]])
    xxMapData.append(['jnt_m_neckSpine_000', 'neck_01', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_neckSpine_001', 'neck_02', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_headMain', 'head', True, [(1,0,0),(0,1,0)]])
    xxMapData.append(['ctrl_l_legHeelOut', 'heel_l', True, [(0,0,1),(0,1,0)]])
    xxMapData.append(['ctrl_l_legToesRevOut', 'tip_l', True, [(0,0,1),(0,1,0)]])

    sKangarooFingerBones = ['jnt_l_%sMeta', 'jnt_l_%sBase', 'jnt_l_%sMid', 'jnt_l_%sTip']
    sUnrealFingerBones = ['%s_metacarpal_l', '%s_01_l', '%s_02_l', '%s_03_l']
    for sFinger in ['thumb', 'index', 'middle', 'ring', 'pinky']:
        for sKangaroPattern, sUnrealPattern in zip(sKangarooFingerBones, sUnrealFingerBones[1:] if sFinger == 'thumb' else sUnrealFingerBones):
            sKangarooJoint = sKangaroPattern % sFinger
            sUnrealJoint = sUnrealPattern % sFinger
            if cmds.objExists('game:%s' % sUnrealJoint):
                xxMapData.append([sKangarooJoint, sUnrealJoint, True, [(1, 0, 0), (0, -1, 0)]])

    xxRightData = []
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        if utils.getSide(sKangaroo) == 'l':
            xxRightData.append([utils.getMirrorName(sKangaroo), utils.replaceStringEnd(sUnreal, '_l', '_r'), bPosition, xRotation])
    xxMapData += xxRightData

    return xxMapData




def _getChildrenDictFromCreatedLimbs(dCreatedLimbs):
    dChildren = defaultdict(list)
    for sLimbName, tLimb in list(dCreatedLimbs.items()):
        sParentLimb = None if not tLimb.lParentLimb else tLimb.lParentLimb.sLimbName
        dChildren[sParentLimb].append(tLimb)
    return dChildren



@uiSettings.addToUI(sRunButton='Create missing BP Joints', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Creates missing BP joints and selects them')
def createBPJoints(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr'), {}]):
    sAllNodesBefore = cmds.ls(dag=True)
    sBpSkelGrp = _getBlueprintsGroupNameFromPuppetFile(xLimbs[0])
    try:
        cmds.undoInfo(openChunk=True)
        _, dLimbs = xLimbs

        for dLimb in dLimbs:
            print ('dLimbx: ', dLimb)

        dLimbs = [dL for dL in dLimbs if dL.get('bDisabledFILE', False) == False]
        for dLimb in dLimbs:
            print ('dLimb: ', dLimb)

        report.report.resetProgress(len(dLimbs))

        for xFileData in dLimbs:
            report.report.incrementProgress()
            lLimb, dMergedData = puppetDataUtils.mergeClassWithData(dFileData=xFileData)
            # lLimb.updateReport()
            lLimb.dMergedData = dMergedData
            sLimbName = '%s_%s' % (lLimb.sSide, lLimb.sName)

            sParentLimb = lLimb.dMergedData['__parent__']

            if sParentLimb:
                lLimb.lParent = dCreatedLimbs[sParentLimb]
                sParentOutput = lLimb.dMergedData['parentOutputFILE']
                lLimb.sApproximateParentBlueprint = lLimb.lParent.guessBlueprintFromOutput(sParentOutput)
            else:
                lLimb.lParent = None
                lLimb.sApproximateParentBlueprint = None
            lLimb.sBpSkelGrp = sBpSkelGrp
            lLimb.createOrSetBlueprints(lParent=lLimb.lParent)

            dCreatedLimbs[sLimbName] = lLimb

        sNewNodes = list(set(cmds.ls(dag=True)) - set(sAllNodesBefore))
        if sNewNodes:
            cmds.select(xforms.getRoots(sNewNodes))

    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)






@uiSettings.addToUI(sRunButton='Build BP Rig', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Builds BP Rig. Run this after importing blueprints to adjust them')
def buildBPRig(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr'), {}]):
    utils.reload2(blueprints)
    sBpSkelGrp = _getBlueprintsGroupNameFromPuppetFile(xLimbs[0])

    _, dLimbs = xLimbs
    dLimbs = [dL for dL in dLimbs if dL.get('bDisabledFILE', False) == False]

    # utils.reload2(puppetDataUtils)
    report.report.resetProgress(len(dLimbs) * 2)

    dLimbLibrary = puppetDataUtils.limbsFromFiles(bReload=True)

    dBuiltLimbs = {}
    dMirrorLimbs = {}
    tMiddleLimbs = []
    dChildren = defaultdict(list)
    dStatuses = puppetDataUtils.getLimbStatusesInHierarchy(dLimbs, dLimbLibrary=dLimbLibrary, bReverse=True)

    blueprints.resetWarpCounter()

    for xFileData in dLimbs:
        report.report.incrementProgress()

        sLimbClass = xFileData['sClassTypeFILE']
        iVersion = xFileData['iVersionFILE']
        LLimbClass = dLimbLibrary[sLimbClass][iVersion]
        lLimb, dMergedData = puppetDataUtils.mergeClassWithData(LLimbClass, xFileData)
        # lLimb.updateReport()
        lLimb.sBpSkelGrp = sBpSkelGrp
        lLimb.dMergedData = dMergedData
        sLimbName = '%s_%s' % (lLimb.sSide, lLimb.sName)
        report.report.addLogText('%s...' % sLimbName)

        sParentLimb = lLimb.dMergedData['__parent__']
        dChildren[sParentLimb].append(lLimb)
        if sParentLimb:
            lLimb.lParent = dCreatedLimbs[sParentLimb]
            sParentOutput = lLimb.dMergedData['parentOutputFILE']
            lLimb.sApproximateParentBlueprint = lLimb.lParent.guessBlueprintFromOutput(sParentOutput)
        else:
            lLimb.lParent = None
            lLimb.sApproximateParentBlueprint = None
        lLimb.buildBlueprintRig(lParent=lLimb.lParent)

        dCreatedLimbs[sLimbName] = lLimb

        if lLimb.sSide in ['l','r']:
            tSideLimbs = dMirrorLimbs.get(lLimb.sName, [None,None])
            if lLimb.sSide == 'l':
                tSideLimbs[0] = lLimb
            elif lLimb.sSide == 'r':
                tSideLimbs[1] = lLimb
            dMirrorLimbs[lLimb.sName] = tSideLimbs
        elif lLimb.sSide == 'm':
            tMiddleLimbs.append(lLimb)

        lLimb.dData = xFileData
        dBuiltLimbs[sLimbName] = lLimb

    blueprints.createOrGetGlobalCtrl()

    # post builds
    for sLimbName, lLimb in list(dBuiltLimbs.items()):
        lLimb.postSetupBlueprintRig(lLimb.dData, dBuiltLimbs, lChildren=dChildren[sLimbName])

    # mirror limbs:
    for sN, tSideLimbs in list(dMirrorLimbs.items()):
        report.report.incrementProgress()
        if tSideLimbs[0] and tSideLimbs[1]:
            if type(tSideLimbs[0]) == type(tSideLimbs[1]):
                blueprints.createMirrorBpSetup(tSideLimbs[0], tSideLimbs[1])

    for tMiddleLimb in tMiddleLimbs:
        blueprints.createMiddleMirrorBpSetup(tMiddleLimb)

    report.report.incrementProgress()


    sBlueprintsLayerName = 'blueprintsLayer'
    if cmds.objExists(sBlueprintsLayerName):
        cmds.delete(sBlueprintsLayerName)
    cmds.createDisplayLayer(sBpSkelGrp, n=sBlueprintsLayerName, nr=True)

    sConnectedBlueprintLayerName = 'connectedBlueprintsLayer'
    if cmds.objExists(sConnectedBlueprintLayerName):
        cmds.delete(sConnectedBlueprintLayerName)
    cmds.createDisplayLayer('connected:%s' % sBpSkelGrp, n=sConnectedBlueprintLayerName, nr=True)
    cmds.setAttr('blueprintsLayer.visibility', False)
    cmds.setAttr('connectedBlueprintsLayer.displayType', 2)



def _getBlueprintPathsFromPuppetFile(sFile):
    sPuppetFilename = os.path.basename(sFile)
    sDir = os.path.dirname(sFile)
    if sPuppetFilename == 'puppet.rig':
        sFileSkel = os.path.join(sDir, 'blueprints.ma')
        sFileRig = os.path.join(sDir, 'blueprintRig.ma')
    else:
        sFileSkel = os.path.join(sDir, '%sBlueprints.ma' % sPuppetFilename.split('.')[0])
        sFileRig = os.path.join(sDir, '%sBlueprintRig.ma' % sPuppetFilename.split('.')[0])

    return sFileSkel, sFileRig



def _getBlueprintsGroupNameFromPuppetFile(sFile):
    print('_getBlueprintsGroupNameFromPuppetFile: ', sFile)
    sPuppetFilename = os.path.basename(sFile).split('.')[0]
    if sPuppetFilename == 'puppet':
        sBpSkelGrp = '_blueprints'
    else:
        sBpSkelGrp = '_%sBlueprints' % sPuppetFilename

    return sBpSkelGrp


@uiSettings.addToUI(sRunButton='Extract+Export Skel', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, bDisableOnServer=True, bCheckAsset=True, sToolTip='This exports to blueprints.ma and blueprintRig.ma (if BP Rig is in scene) from scene. It does NOT save anything in the rig file')
def extractAndExportSkeleton(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr')]):

    sFileSkel, sFileRig = _getBlueprintPathsFromPuppetFile(xLimbs[0])
    sBpSkelGrp = _getBlueprintsGroupNameFromPuppetFile(xLimbs[0])
    print('sBpSkelGrp: ', sBpSkelGrp)
    sChangedJoints = printOrientationChanges()
    if sChangedJoints:
        print('sChangedJoints: ', sChangedJoints)
        sButton = cmds.confirmDialog(message='Joints that changed: \n%s' % utils.listToString(sChangedJoints, iMaxCount=15), button=['ok, export', 'abort'])
        if sButton == 'abort':
            return False


    cmds.delete(cmds.ls(et='unknown'))

    if not cmds.objExists(sBpSkelGrp):
        raise Exception('don\'t know what to export with the things that are in scene')

    sConnected = 'connected:%s' % sBpSkelGrp

    if not cmds.objExists(sConnected): # BP rig is not in scene -> it's easy
        print('exporting %s to %s' % (sBpSkelGrp, sFileSkel))
        cmds.select(sBpSkelGrp)
        cmds.file(sFileSkel, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)

        report.report.addLogText('exported: %s' % sFileSkel)
    else:
        if cmds.objExists(sBpSkelGrp):
            cmds.delete(sBpSkelGrp)
        cmds.duplicate(sConnected, name=sBpSkelGrp, rr=True)

        # fix symmetry values that go lost on duplicating
        sNodes = (cmds.listRelatives(sBpSkelGrp, ad=True, typ='joint') or []) + \
                 (cmds.listRelatives(sBpSkelGrp, ad=True, typ='transform') or [])
        for sN in sNodes:
            for sA in cmds.listAttr(sN, k=True):
                if sA.endswith('Symmetry'):
                    iValue = cmds.getAttr('connected:%s.%s' % (sN,sA))
                    cmds.setAttr('%s.%s' % (sN,sA), iValue)


        print('exporting %s to %s' % (sBpSkelGrp, sFileSkel))
        [cmds.setAttr('%s.v' % sT, True) for sT in cmds.listRelatives(sBpSkelGrp, ad=True, typ='transform')]
        cmds.select(sBpSkelGrp)
        cmds.file(sFileSkel, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)

        print('saving scene file to %s' % sFileRig)
        cmds.file(rename=sFileRig)
        cmds.file(save=True, typ='mayaAscii')

        report.report.addLogText('exported: %s' % sFileSkel)
        report.report.addLogText('exported: %s' % sFileRig)

    if utils.getPythonVersion() == 3: # this is just so we don't change behavior in maya 2020 and below
        sMessage = utils.removeRequiresLines(sFileSkel)
        report.report.addLogText(sMessage)



@uiSettings.addToUI(sRunButton='Import BP Skel', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Imports blueprints.ma')
def importBpSkeleton(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr')]):
    sFileSkel, sFileRig = _getBlueprintPathsFromPuppetFile(xLimbs[0])
    utils.importMayaFiles([sFileSkel])



# @uiSettings.addToUI(sRunButton='Import BP Rig', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Import blueprintRig.ma. It\'s actually not recommended. Instead import Blueprint Skel and build BP Rig from that')
def importBpRig(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr')]):
    sFileSkel, sFileRig = _getBlueprintPathsFromPuppetFile(xLimbs[0])
    utils.importMayaFiles([sFileRig])


@uiSettings.addToUI(sRunButton='Clean Limbs Attachers', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Import blueprintRig.ma. It\'s actually not recommended. Instead import Blueprint Skel and build BP Rig from that')
def cleanLimbs(xLimbs=[os.path.expanduser('~/Documents/puppet.tbr')]):
    bChangedSomething = controlsPuppet.globalLimbControl.removeInvalidOutputsOfAllLimbs()
    print ('bChangedSomething: ', bChangedSomething)
    if not bChangedSomething:
        return False




@uiSettings.addToUI(sRunButton='Maximize All Limb', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Sets all limbs\' versions to latest.')
def versionUpAllLimbs():
    bChangedSomething = controlsPuppet.globalLimbControl.allVersionsUp()
    if not bChangedSomething:
        return False



dControls['sFromMesh'] = controls.SelectionControl(bList=False)
dControls['sToMesh'] = controls.SelectionControl(bList=False)
# @uiSettings.addToUI(sRunButton='Warp Puppet', sTab='Geometry', sModuleButton='WarpPuppet', bReloadBeforeRun=True, dControls=dControls)
def warpPuppet(sFromMesh=None, sToMesh=None):
    cmds.undoInfo(openChunk=True)
    try:
        sCtrls = blueprints.getAllWarpCtrls()
        sLocs = [cmds.spaceLocator(n='warpLoc__%s' % sC)[0] for sC in sCtrls]
        for c in range(len(sCtrls)):
            cmds.delete(cmds.parentConstraint(sCtrls[c], sLocs[c]))

        xforms.warpTransforms(sFromMesh, sToMesh, sLocs, bOrient=False, bScale=False, bOrderBasedOnHier=False)

        for c in range(len(sCtrls)):
            fPos = cmds.xform(sLocs[c], q=True, ws=True, t=True)
            cmds.move(fPos[0], fPos[1], fPos[2], sCtrls[c], a=True, ws=True)

        cmds.delete(sLocs)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)




@uiSettings.addToUI(sRunButton='Print Blueprint Changes', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={})
def printOrientationChanges():
    if not cmds.objExists('connected:_blueprints'):
        return None
    sConnectedJoints = cmds.listRelatives('connected:_blueprints', ad=True, typ='joint')
    sChanged = []
    for sJoint in sConnectedJoints:
        sOld = sJoint.split(':')[-1]
        aMatrixCon = np.array(cmds.xform(sJoint, q=True, ws=True, m=True)).reshape(4,4)[:,:3]
        aMatrixOld = np.array(cmds.xform(sOld, q=True, ws=True, m=True)).reshape(4,4)[:,:3]
        aDiff = aMatrixCon-aMatrixOld
        aLengths = np.linalg.norm(aDiff, axis=1)
        for i in range(4):
            if aLengths[i] > 0.0001:
                sChanged.append(sOld)

    sConnectedCurves = utils.listCurves('connected:_blueprints')
    for sCurve in sConnectedCurves:
        sOld = sCurve.split(':')[-1]
        aConnectedPoints = np.array(cmds.xform('%s.cv[*]' % sCurve, q=True, ws=True, t=True)).reshape(-1,3)
        aOldPoints = np.array(cmds.xform('%s.cv[*]' % sOld, q=True, ws=True, t=True)).reshape(-1,3)
        aDiffs = np.linalg.norm(aConnectedPoints-aOldPoints, axis=-1)
        if len(np.where(aDiffs > 0.00001)[0]):
            sChanged.append(sOld)


    sChanged = sorted(list(set(sChanged)))
    print('sChanged: ', sChanged)

    if not sChanged:
        report.report.addLogText('\nAll is the same')
    else:
        report.report.addLogText('\nJoints that changed:')
        for sJ in sChanged:
            report.report.addLogText(sJ)

    return sChanged




@uiSettings.addToUI(sRunButton='MetaHuman layout', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='If you have a metahuman in scene, it can move the BP Rig to that')
def metaHumanLayout():
    sNamespace = 'metaHuman:'

    cmds.undoInfo(openChunk=True)
    try:
        # spine
        sHips = '%spelvis_drv' % sNamespace
        sSpineJoints = ['%sspine_%s_drv' % (sNamespace, sIndex) for sIndex in ['01', '02', '03', '04', '05']]
        cmds.delete(cmds.pointConstraint(sSpineJoints[0], 'spineGrpRoot_ctrl'))
        cmds.delete(cmds.pointConstraint(sSpineJoints[-1], 'spineGrpspine_end_ctrl'))
        cmds.delete(cmds.pointConstraint(sSpineJoints[-1], 'spineEnd_ctrl'))
        cmds.delete(cmds.pointConstraint(sHips, 'hipsMain_ctrl'))
        cmds.delete(cmds.pointConstraint(sSpineJoints[1], 'spineSpine0_ctrl'))
        cmds.delete(cmds.pointConstraint(sSpineJoints[2], 'spineSpine1_ctrl'))
        cmds.delete(cmds.pointConstraint(sSpineJoints[3], 'spineSpine2_ctrl'))

        sNecks = ['%sneck_01_drv' % sNamespace, '%sneck_02_drv' % sNamespace, '%shead_drv' % sNamespace]
        cmds.delete(cmds.pointConstraint(sNecks[0], 'neckGrpRoot_ctrl'))
        cmds.delete(cmds.pointConstraint(sNecks[0], 'neckRoot_ctrl'))
        cmds.delete(cmds.pointConstraint(sNecks[2], 'neckEnd_ctrl'))
        cmds.delete(cmds.pointConstraint(sNecks[2], 'headMain_ctrl'))
        sMetaHumanEndPoint = cmds.createNode('transform', p=sNecks[-1])
        cmds.setAttr('%s.t' % sMetaHumanEndPoint, 10.0, 0, 0)
        cmds.delete(cmds.pointConstraint(sMetaHumanEndPoint, 'headMainEnd_ctrl'))

        cmds.delete(cmds.pointConstraint(sSpineJoints[2], 'cogMain_ctrl'))

        for s,sSide in enumerate(['l','r']):
            sUpperLeg = '%sthigh_%s_drv' % (sNamespace, sSide)
            sKnee = '%scalf_%s_drv' % (sNamespace, sSide)
            sFoot = '%sfoot_%s_drv' % (sNamespace, sSide)
            sBall = '%sball_%s_drv' % (sNamespace, sSide)

            cmds.delete(cmds.pointConstraint(sUpperLeg, 'legUpper%s_ctrl' % utils.sSides3[s]))
            cmds.delete(cmds.pointConstraint(sFoot, 'legGrpHand%s_ctrl' % utils.sSides3[s]))

            fPoleVectorPos = xforms.fPoleVectorPos(sUpperLeg, sKnee, sFoot)
            cmds.xform('legPole%s_ctrl' % utils.sSides3[s], t=fPoleVectorPos, ws=True)
            cmds.xform('legUpperElbow000000%s_ctrl' % utils.sSides3[s], t=cmds.xform(sKnee, q=True, ws=True, t=True), ws=True)
            cmds.delete(cmds.pointConstraint(sBall, 'legFingers%s_ctrl' % utils.sSides3[s]))
            sMetaHumanEndPoint = cmds.createNode('transform', p=sBall)
            cmds.setAttr('%s.t' % sMetaHumanEndPoint, 4.0, 0, 0)
            cmds.delete(cmds.pointConstraint(sMetaHumanEndPoint, 'legFingersEnd%s_ctrl' % utils.sSides3[s]))

            sPrintBp = 'legPrint%s_ctrl' % utils.sSides3[s]
            fPrintPos = cmds.xform(sPrintBp, q=True, ws=True, t=True)
            cmds.xform(sPrintBp, t=[fPrintPos[0], 0, fPrintPos[2]], ws=True)



            sUpperArm = '%supperarm_%s_drv' % (sNamespace, sSide)
            sElbow = '%slowerarm_%s_drv' % (sNamespace, sSide)
            sClavicle = '%sclavicle_%s_drv' % (sNamespace, sSide)
            sHand = '%shand_%s_drv' % (sNamespace, sSide)


            cmds.delete(cmds.pointConstraint(sUpperArm, 'clavicleclavicleEnd%s_ctrl' % utils.sSides3[s]))
            cmds.delete(cmds.pointConstraint(sClavicle, 'clavicleClavicle%s_ctrl' % utils.sSides3[s]))
            cmds.delete(cmds.parentConstraint(sHand, 'armGrpHand%s_ctrl' % utils.sSides3[s]))

            fPoleVectorPos = xforms.fPoleVectorPos(sUpperArm, sElbow, sHand)
            cmds.xform('armPole%s_ctrl' % utils.sSides3[s], t=fPoleVectorPos, ws=True)
            cmds.xform('armUpperElbow000000%s_ctrl' % utils.sSides3[s], t=cmds.xform(sElbow, q=True, ws=True, t=True), ws=True)

            ssMetaFingerJoints = []
            ssBpFingers = []
            for sFinger in ['index', 'middle', 'ring', 'pinky']:
                ssMetaFingerJoints.append(['%s%s_%s_%s_drv' % (sNamespace, sFinger, sPart, sSide) for sPart in ['metacarpal', '01', '02', '03']])
                ssBpFingers.append(['%s%s%s_ctrl' % (sFinger, sPart, utils.sSides3[s]) for sPart in ['Meta', 'Base', 'Mid', 'Tip', 'End']])


            for f,sFinger in enumerate(['index', 'middle', 'ring', 'pinky']):
                sMetaHumanEndPoint = cmds.createNode('transform', p=ssMetaFingerJoints[f][-1])
                cmds.setAttr('%s.t' % sMetaHumanEndPoint, cmds.getAttr('%s.tx' % ssMetaFingerJoints[f][-1]), 0, 0)

                # meta
                cmds.delete(cmds.pointConstraint(ssMetaFingerJoints[f][0], ssBpFingers[f][0]))

                # base
                cmds.delete(cmds.pointConstraint(ssMetaFingerJoints[f][1], ssBpFingers[f][1]))

                # tip
                cmds.delete(cmds.pointConstraint(sMetaHumanEndPoint, ssBpFingers[f][-1]))

                sMetaHumanUpPoint = cmds.createNode('transform', p=ssMetaFingerJoints[f][2])
                cmds.setAttr('%s.t' % sMetaHumanUpPoint, 0, -5.0, 0)
                sBpPole = '%sPole%s_ctrl' % (sFinger, utils.sSides3[s])
                cmds.delete(cmds.pointConstraint(sMetaHumanUpPoint, sBpPole))

                # middle, tip
                cmds.xform(ssBpFingers[f][2], t=cmds.xform(ssMetaFingerJoints[f][2], q=True, ws=True, t=True), ws=True)
                cmds.xform(ssBpFingers[f][3], t=cmds.xform(ssMetaFingerJoints[f][3], q=True, ws=True, t=True), ws=True)
                cmds.delete(sMetaHumanEndPoint, sMetaHumanUpPoint)

            # thumb
            sMetaThumbJoints = ['%s%s_%s_%s_drv' % (sNamespace, 'thumb', sPart, sSide) for sPart in ['01', '02', '03']]

            cmds.delete(cmds.pointConstraint(sMetaThumbJoints[0], 'thumbMeta%s_ctrl' % (utils.sSides3[s])))
            cmds.delete(cmds.pointConstraint(sMetaThumbJoints[1], 'thumbBase%s_ctrl' % (utils.sSides3[s])))
            sMetaHumanEndPoint = cmds.createNode('transform', p=sMetaThumbJoints[-1])
            cmds.setAttr('%s.t' % sMetaHumanEndPoint, cmds.getAttr('%s.tx' % ssMetaFingerJoints[f][-1]), 0, 0)
            cmds.pointConstraint(sMetaHumanEndPoint, 'thumbEnd%s_ctrl' % utils.sSides3[s])
            cmds.xform('thumbMid%s_ctrl' % utils.sSides3[s], t=cmds.xform(sMetaThumbJoints[2], q=True, ws=True, t=True), ws=True)

            sMetaHumanUpPoint = cmds.createNode('transform', p=sMetaThumbJoints[1])
            cmds.setAttr('%s.t' % sMetaHumanUpPoint, 0, -5.0, 0)
            cmds.delete(cmds.pointConstraint(sMetaHumanUpPoint, 'thumbPole%s_ctrl' % utils.sSides3[s]))
            cmds.delete(sMetaHumanEndPoint, sMetaHumanUpPoint)

            # hand fk joints
            sMetaHumanEndPoint = cmds.createNode('transform', p=sHand)
            fJointDistance = cmds.getAttr('%s.tx' % ssMetaFingerJoints[1][1])
            cmds.setAttr('%s.t' % sMetaHumanEndPoint, fJointDistance * 1.25, 0, 0)
            cmds.delete(cmds.pointConstraint(sMetaHumanEndPoint, 'armFingers%s_ctrl' % utils.sSides3[s]))
            cmds.setAttr('%s.t' % sMetaHumanEndPoint, fJointDistance * 2.5, 0, 0)
            cmds.delete(cmds.pointConstraint(sMetaHumanEndPoint, 'armFingersEnd%s_ctrl' % utils.sSides3[s]))

            sMetaHumanUpPoint = cmds.createNode('transform', p=sHand)
            cmds.setAttr('%s.t' % sMetaHumanUpPoint, 0, 0, fJointDistance*5)
            cmds.delete(cmds.pointConstraint(sMetaHumanUpPoint, 'armPoleWrist%s_ctrl' % utils.sSides3[s]))
            cmds.delete(cmds.pointConstraint(sMetaHumanUpPoint, 'armPoleFingers%s_ctrl' % utils.sSides3[s]))

            sHandPrintBp = 'armPrint%s_ctrl' % utils.sSides3[s]
            cmds.delete(cmds.pointConstraint(sHand, sHandPrintBp))
            xforms.orientThreePoints(sHandPrintBp, sMetaHumanEndPoint, sMetaHumanUpPoint, fAimVector=[0,0,1], fUpVector=[-1,0,0])




    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)
        
        
@uiSettings.addToUI(sRunButton='Import Model', sTab='Puppet', sModuleButton='Create', bReloadBeforeRun=True, dControls={}, sToolTip='Runs all functions in the builder starting with "importModel"'  )
def importModel():
    import kangarooTabTools.builder as builder
    import sys
    import importlib

    sBuildFile = assets.assetManager.getCurrentVersionPath(sSubPath='build.bld')
    dBuildFolders = assets.getBuildFolders()
    dBuildContent = builder.dRunControls['xBuildList'].getBuildContent(sBuildFile=sBuildFile)
    sBuildDir = os.path.dirname(sBuildFile)

    dImportModelFunctions = OrderedDict()

    for sPythonKey, bChecked in dBuildContent['__FILES__']:
        if not bChecked:
            continue

        if '@' in sPythonKey:
            sName, sFile = sPythonKey.split('@')
            sFolder = dBuildFolders[sName].replace('\\', '/')
            
            # this part is just to make sure that additional script locations will work also
            if sFolder not in sys.path:
                sys.path.append(sFolder)
            
            sModule = '%s.%s' % (sFolder.split('/')[-1], sFile.split('.')[0])
            # sPythonFile = os.path.join(sFolder, sFile).replace('\\', '/')
        else:
            sPythonFile = os.path.abspath(os.path.join(sBuildDir, sPythonKey))
            sPythonFile = os.path.normpath(sPythonFile)
            
            sRelToAssetPath = os.path.relpath(sPythonFile, assets.getCurrentAssetRoot())
            sRelToAssetPath = os.path.normpath(sRelToAssetPath)
            
            if not os.path.isfile(sPythonFile):
                raise Exception('File %s doesn\'t exist' % sPythonFile)
            
            sPathSplits = sRelToAssetPath.split(os.sep)
            sModule = '.'.join(sPathSplits[:-1] + [sPathSplits[-1].split('.')[0]])
            sModule = '%s.%s' % (assets.getCurrentAssetRootName(), sModule)
            sProject = assets.getCurrentProject()
            if len(sProject):
                sModule = '%s.%s' % (sProject, sModule)
            
        try:
            modModule = importlib.import_module(sModule)
        except:
            modModule = importlib.import_module(sModule.split('.')[-1])

        sAttrsInModule = dir(modModule)
        for sFunc in sAttrsInModule:
            if sFunc.startswith('importModel'):
                bDisabled = dBuildContent['__FUNCTIONDATAS__'].get(sFunc, [{}])[0].get('bDisabled', False)
                if not bDisabled:
                    report.report.addLogText('Running function "%s()" function from %s' % (sFunc, sModule))
                    funcImportModel = getattr(modModule, sFunc)
                    dFileArgs = dBuildContent['__FUNCTIONDATAS__'].get(sFunc, [{}])[0].get('dFileArgs', {})
                    dArgsSelected = {sKey:dFileArgs[sKey] for sKey in funcImportModel.sArgsSorted if sKey in dFileArgs}
                    # report.report.addLogText('Selected dFileArgs: %s' % str(dArgsSelected))
                    # funcImportModel(**dArgsSelected)
                    dImportModelFunctions[sFunc] = (funcImportModel, dArgsSelected)


    for sFunc, xFunc in dImportModelFunctions.items():
        funcImportModel, dArgs = xFunc
        funcImportModel(**dArgs)

