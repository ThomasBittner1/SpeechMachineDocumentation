###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.cmds as cmds
import numpy as np
import os
from collections import deque, defaultdict

import kangarooTools.uiSettings as uiSettings
import kangarooTools.controls as controls
import kangarooTools.utilFunctions as utils
import kangarooTools.patch as patch
import kangarooTools.nodes as nodes
import kangarooTabTools.geometry as geometry
import kangarooTabTools.weights as weights
import kangarooTools.topology as topology
import kangarooTools.xforms as xforms
import kangarooTools.report as report


kPlanesGroup = '_planes'

def _createOrGetCutGroup():
    sGrp = '_cuts'
    if not cmds.objExists(sGrp):
        cmds.createNode('transform', name=sGrp)
    return sGrp


def _createOrGetProxyGroup():
    sGrp = '_proxys'
    if not cmds.objExists(sGrp):
        cmds.createNode('transform', name=sGrp)
    return sGrp


def updateTagAttr(sJoints, dInDict):
    sJoints = utils.toList(sJoints)
    for sJ in sJoints:

        sAttr = '%s.segmentsData' % sJ
        if not cmds.objExists(sAttr):
            utils.addAttr(sJ, ln='segmentsData', dt='string')
        sValue = cmds.getAttr(sAttr)
        if sValue:
            dDict = eval(sValue)
        else:
            dDict = {}

        dDict.update(dInDict)
        cmds.setAttr(sAttr, str(dDict), type='string')


def getTagAttrData(sJoint):
    sAttr = '%s.segmentsData' % sJoint
    try:
        sValue = cmds.getAttr(sAttr)
        if sValue:
            dValue = eval(sValue)
    except:
        dValue = {}

    return dValue


def _orderByPiority(sJoints, dDatas):
    iPriorities = [dDatas[sJ].get('iPriority',0) for sJ in sJoints]
    iSorted = np.argsort(iPriorities)
    aJoints = np.array(sJoints)
    return aJoints[iSorted[::-1]]




def _createPlaneREC(sJoint, dDatas, sParent, iUCount=3, iVCount=3, bRoot=False, dChildren={}, fSize=1.0):
    sChildren = dChildren[sJoint]
    if sChildren:
        if dDatas[sJoint].get('bDisable',False) == False:
            if not sJoint.startswith('jnt_'):
                return
            sPlane = utils.replaceStringStart(sJoint, 'jnt_', 'plane_')
            print('sPlane: ', sPlane)
            if cmds.objExists(sPlane):
                return
            if not bRoot and dDatas[sJoint].get('bIsRoot',False) == True:
                return
            iPriority = dDatas[sJoint].get('iPriority', 0)
            sPlane = cmds.nurbsPlane(name=sPlane, w=fSize, u=iUCount-3, v=iVCount-3)[0]
            utils.addAttr(sPlane, ln='priority', defaultValue=iPriority, k=True)

            sSearchReplace = dDatas[sJoint].get('sSearchReplace', None)
            if sSearchReplace:
                utils.addStringAttr(sPlane, 'searchReplace', sSearchReplace)

            if '_r_' in sPlane:
                cmds.reverseSurface(sPlane, ch=True)
            cmds.parent(sPlane, sParent)
            xforms.matrixParentConstraint(sJoint, sPlane)
            for sA in ['t','r','s']:
                cmds.setAttr('%s.%s' % (sPlane,sA), lock=True)

            sCrossHierarchy = dDatas[sJoint].get('sCrossHierarchy', None)
            if sCrossHierarchy:
                _placePlaneBetweenHierarchies(sCrossHierarchy, sJoint, sPlane, dDatas)

        else:
            sPlane = sParent


        sOrderedChildren = _orderByPiority(sChildren, dDatas)
        for c, sChild in enumerate(sOrderedChildren):
            _createPlaneREC(sChild, dDatas, sPlane, iUCount=iUCount, iVCount=iVCount, dChildren=dChildren, fSize=fSize)


dControls = {}
dControls['sFile'] = controls.FilePathControl('*.ma', sDefaultFileName='planes.ma')
@uiSettings.addToUI(sRunButton='Export Planes', sTab='Segments', sModuleButton='Export', bReloadBeforeRun=True,
                    dControls=dControls, sTabControls=[], bDisableOnServer=True, bCheckAsset=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def exportPlanes(sFile='file'):
    sPlanes = cmds.listRelatives('_planes', ad=True, typ='transform')
    for sPlane in sPlanes:
        for sA in ['t','r','s']:
            cmds.setAttr('%s.%s' % (sPlane,sA), lock=False)
    cmds.select('_planes')
    print('exporting _planes to %s' % (sFile))
    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #




dControls = {}
dControls['sFile'] = controls.FilePathControl('*.ma', sDefaultFileName='planes.ma')
@uiSettings.addToUI(sRunButton='Import', sTab='Segments', sModuleButton='Import', bReloadBeforeRun=True,
                    dControls=dControls, sTabControls=[], sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def importPlanes(sFile='file', bDeletePlanesThatHaveNoJoint=True):
    '''
    You need to create the planes first. This will only import the shapes.
    You can select some planes and he will import only those planes. Or if you have nothing
    selected, he'll do all.
    '''

    # if not cmds.objExists('_planes'):
    #     raise Exception, 'you need to create planes first'

    sSel = cmds.ls(sl=True, et='transform')
    sSelectedPlanes = [sO for sO in sSel if sO.startswith('plane_')]
    if not sSelectedPlanes and cmds.objExists('_planes'):
        sSelectedPlanes = [sN for sN in cmds.listRelatives('_planes', ad=True, typ='transform') if cmds.objectType(sN) == 'transform']


    sNs = 'importedPlanes'
    if not os.path.exists(sFile):
        raise Exception('File "%s" doesn\'t exist.' % sFile)
    sNewNodes = utils.importMayaFiles(sFile, sNamespace=sNs if sSelectedPlanes else None)
    sNs = sNewNodes[0].split(':')[0]
    cmds.refresh()


    if sSelectedPlanes:
        for sPlane in sSelectedPlanes:
            print('sPlane: ', sPlane)
            pPlane = patch.patchFromName(sPlane)
            sImportedPlane = '%s:%s' % (sNs, sPlane)
            if cmds.objExists(sImportedPlane):
                pImported = patch.patchFromName(sImportedPlane)
                pPlane.matchTopology(pImported)
                pPlane.setPoints(pImported.getPoints(bWorld=False), bWorld=False)
            else:
                report.report.addLogText('\nthere is no imported plane for "%s"' % sPlane)
        cmds.delete(sNewNodes)
        cmds.select(sSelectedPlanes)
    else:
        sConstraints = cmds.listRelatives('_planes', ad=True, typ='parentConstraint', f=True)
        cmds.delete(sConstraints)
        sPlanes = cmds.listRelatives('_planes', ad=True, typ='transform')
        sPrefix = 'plane'
        for sP in sPlanes:
            sJoint = 'jnt%s' % sP[len(sPrefix):]
            if cmds.objExists(sJoint):
                for sA in ['t', 'r', 's']:
                    cmds.setAttr('%s.%s' % (sP, sA), lock=False)
                xforms.matrixParentConstraint(sJoint, sP)
                for sA in ['t', 'r', 's']:
                    cmds.setAttr('%s.%s' % (sP,sA), lock=True)

            else:
                report.report.addLogText('\nskipping plane "%s" because joint "%s" doesn\'t exist' % (sP, sJoint))
                if bDeletePlanesThatHaveNoJoint:
                    cmds.delete(sP)




@uiSettings.addToUI(sTab='Segments', sModuleButton='Create', sRunButton='Create for All Joints',
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def createPlanes(iUCount=6, iVCount=6):
    sTopGrp = cmds.createNode('transform', name=kPlanesGroup)
    xforms.addUniformScaleAttr(sTopGrp)

    sAllJoints = cmds.listRelatives('skeleton', ad=True, typ='joint')
    dChildren = _getChildDict(sAllJoints)

    dDatas = {sJ:getTagAttrData(sJ) for sJ in sAllJoints}
    sRoots = [sJ for sJ,dData in list(dDatas.items()) if dData.get('bIsRoot', False) == True]
    sRoots += dChildren['skeleton']#cmds.listRelatives('skeleton', typ='joint', c=True)
    sRoots = list(set(sRoots))
    sRoots = _orderByPiority(sRoots, dDatas)
    fSize = utils.getJointsBoundingBoxDiagonal(sAllJoints) * 0.015

    report.report.resetProgress(len(sRoots))

    for sRoot in sRoots:
        _createPlaneREC(sRoot, dDatas, sTopGrp, iUCount=iUCount, iVCount=iVCount, bRoot=True, dChildren=dChildren, fSize=fSize)
        report.report.incrementProgress()

    cmds.select(cl=True)



@uiSettings.addToUI(sTab='Segments', sModuleButton='Create', sRunButton='Create for Selected Joints')
def createPlanesSelected(iUCount=6, iVCount=6):
    sNewPlanes = []
    for sJoint in cmds.ls(sl=True, et='joint'):
        sPlane = utils.replaceStringStart(sJoint, 'jnt_', 'plane_')
        if cmds.objExists(sPlane):
            cmds.delete(sPlane)
        sPlane = cmds.nurbsPlane(name=sPlane, w=cmds.getAttr('%s.radius' % sJoint) * 10, u=iUCount - 3, v=iVCount - 3)[0]
        utils.addAttr(sPlane, ln='priority', defaultValue=0, k=True)
        xforms.matrixParentConstraint(sJoint, sPlane)
        for sA in ['s']:
            cmds.setAttr('%s.%s' % (sPlane, sA), lock=True)

        sNewPlanes.append(sPlane)
        
    cmds.select(sNewPlanes)



@uiSettings.addToUI(sTab='Segments', sModuleButton='Select', sRunButton='Select Joints')
def selectJointsForSkinCluster():
    '''
This just selects all the joints that the "Create" Tool would create planes for. It's useful if you want to just \
create a skinCluster on your own and you are not sure which joints you should choose.
    '''
    sAllJoints = cmds.listRelatives('skeleton', ad=True, typ='joint')
    sSelectJoints = []
    for sJ in sAllJoints:
        print('sJ: ', sJ)
        sAttr = '%s.segmentsData' % sJ

        if cmds.objExists(sAttr):
            dData = eval(cmds.getAttr(sAttr))
            if dData.get('bDisable', False):
                continue
            sSearchReplace = dData.get('sSearchReplace', None)
            if sSearchReplace:
                sSearch, sReplace = sSearchReplace.split(';')
                sReplaced = sJ.replace(sSearch, sReplace)
                if cmds.objExists(sReplaced):
                    sSelectJoints.append(sReplaced)
                    continue

        if not cmds.listRelatives(sJ, c=True, typ='joint'):
            continue
        sSelectJoints.append(sJ)

    cmds.select(sSelectJoints)



def rebuildWithCount(sPlane, iUCount=6, iVCount=6):
    cmds.rebuildSurface(sPlane, ch=True, rpo=1, rt=0, end=1, kr=0, kcp=0, kc=0, su=iUCount-2, du=2, sv=iVCount-2, dv=2, tol=0.01, fr=0, dir=2)



dControls = {}
@uiSettings.addToUI(sTab='Segments', sModuleButton='Reset', sRunButton='Reset Selected', dControls=dControls,
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def resetPlanes():
    '''
This resets the selected planes to what they would be if you would recreate them. We use this option a lot on the fingers, when they \
get a bit messy from small joint blueprint changes
    '''
    try:
        cmds.undoInfo(openChunk=True)
        sPlanes = cmds.ls('plane_*', sl=True)
        sAllJoints = cmds.listRelatives('skeleton', ad=True, typ='joint')
        fSize = utils.getJointsBoundingBoxDiagonal(sAllJoints) * 0.015
        dDatas = {sJ:getTagAttrData(sJ) for sJ in sAllJoints}
        print ('dDatas: ', dDatas)
        for sPlane in sPlanes:
            sJoint = utils.replaceStringStart(sPlane, 'plane_', 'jnt_')
            print ('dDatas: ', dDatas)
            dData = dDatas[sJoint]
            sCrossHierarchy = dData.get('sCrossHierarchy', None)
            if sCrossHierarchy:
                _placePlaneBetweenHierarchies(sCrossHierarchy, sJoint, sPlane, dDatas)
            else:
                iUCount, iVCount = 6, 6
                rebuildWithCount(sPlane, iUCount, iVCount)
                sTempPlane = cmds.nurbsPlane(name='deletemeplane', w=fSize, u=iUCount - 2, v=iVCount-2, d=2, ch=False)[0]
                cmds.blendShape(sTempPlane, sPlane, w=[0,1])
                cmds.delete(sTempPlane)
        cmds.select(sPlanes)

    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



dControls = {}
dControls['iUCount'] = controls.SliderControl([2,20])
dControls['iVCount'] = controls.SliderControl([2,20])
@uiSettings.addToUI(sTab='Segments', sModuleButton='Rebuild', sRunButton='Rebuild Selected', dControls=dControls,
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def rebuildPlane(iUCount=6, iVCount=6, bResetShape=False):
    try:
        cmds.undoInfo(openChunk=True)

        print('iUCount: ', iUCount)
        print('iVCount: ', iVCount)
        sPlanes = cmds.ls(sl=True, et='transform')
        for sPlane in sPlanes:
            rebuildWithCount(sPlane, iUCount, iVCount)

            if bResetShape:
                fSize = 1.0
                sTempPlane = cmds.nurbsPlane(name='deletemeplane', w=fSize, u=iUCount - 2, v=iVCount-2, d=2, ch=False)[0]
                cmds.blendShape(sTempPlane, sPlane, w=[0,1])
        cmds.select(sPlanes)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



class MirrorDirection(object):
    leftToRight = 0
    rightToLeft = 1


dControls = {}
dControls['iDirection'] = controls.RadioButtonsControl(MirrorDirection)


@uiSettings.addToUI(sTab='Segments', sModuleButton='Mirror', sRunButton='Mirror Selected Planes', dControls=dControls,
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def mirrorSelectedPlanes(iDirection=MirrorDirection.leftToRight):
    '''
    "Mirror Selected Planes" looks at Direction input for middle meshes, but
    for side objects (l_* or r_*) he looks for the opposite meshes, and
    manipulates those to look like the selected meshes. If the other
    meshes don't exist, he'll create them.
    '''
    geometry.meshMirrorNoBase(iDirectionIfMiddleMesh=iDirection, bReverseNurbs=True, bWorld=True)
    


@uiSettings.addToUI(sTab='Segments', sModuleButton='Mirror', sRunButton='Mirror All Planes')
def mirrorAllPlanes(iDirection=MirrorDirection.leftToRight):
    '''
    "Mirror All Planes" mirrors the shapes of all planes in scene, looking
    at the Direction input
    '''
    cmds.undoInfo(openChunk=True)
    try:
        sPlanes = [sS for sS in cmds.ls(et='transform') if sS.startswith('plane_')]
        sSides = [utils.getSide(sP) for sP in sPlanes]
        sMiddlePlanes = [sP for p, sP in enumerate(sPlanes) if sSides[p] == 'm']
        sLeftPlanes = [sP for p, sP in enumerate(sPlanes) if sSides[p] == 'l']
        sRightPlanes = [sP for p, sP in enumerate(sPlanes) if sSides[p] == 'r']

        sSelBefore = cmds.ls(sl=True)

        if iDirection == MirrorDirection.leftToRight:
            cmds.select(sMiddlePlanes + sLeftPlanes)
        elif iDirection == MirrorDirection.rightToLeft:
            cmds.select(sMiddlePlanes + sRightPlanes)

        geometry.meshMirrorNoBase(iDirectionIfMiddleMesh=iDirection, bReverseNurbs=True, bWorld=True)

        sChangeMeshes = sRightPlanes if iDirection == MirrorDirection.leftToRight else sLeftPlanes
        for sMesh in sChangeMeshes:
            sOther = utils.getMirrorName(sMesh)
            if cmds.objExists(sOther):
                sOtherAttr = '%s.priority' % sOther
                if cmds.objExists(sOtherAttr):
                    sAttr = utils.addAttr(sMesh, ln='priority', k=True, bReturnIfExists=True)
                    cmds.setAttr(sAttr, cmds.getAttr(sOtherAttr))

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


dControls = {}
dControls['iJointLocks'] = controls.RadioButtonsControl(patch.JointLocks)
@uiSettings.addToUI(sTab='Segments', sModuleButton='SkinCluster', sRunButton='Selected Polys all Planes',
                    dControls=dControls, sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def createSkinCluster(bShowProcess=True, iSmoothIterations=2, iJointLocks=patch.JointLocks.ignore):
    '''
    If you are using jointLocks, make sure to only use that option when mesh is already skinned, and you just want to  \
    adjust those weights.
    And you may have to create a new set of planes that only include those of the joints that are locked. Otherwise \
    you'll end up with zero weighted vertices
    '''
    
    sSelBefore = cmds.ls(sl=True)
    sAllPlanes = cmds.listRelatives(kPlanesGroup, ad=True)
    sAllPlanes = [sP for sP in sAllPlanes if sP.startswith('plane_') and cmds.objectType(sP) == 'transform']
    iAllPlanes = len(sAllPlanes)

    sJoints = []
    for sP in sAllPlanes:
        sJ = utils.replaceStringStart(sP, 'plane_', 'jnt_')
        sSearchReplaceAttr = '%s.searchReplace' % sP
        if cmds.objExists(sSearchReplaceAttr):
            for sSR in cmds.getAttr(sSearchReplaceAttr).split(' '):
                sSearch, sReplace = sSR.split(';')
                sReplaced = sJ.replace(sSearch, sReplace)
                if cmds.objExists(sReplaced):
                    sJ = sReplaced
        sJoints.append(sJ)

    pPatches = patch.getSelectedPatches()

    xFrontIds = [np.arange(pP.getTotalCount()) for pP in pPatches]

    global xSplitWeights
    xSplitWeights = [np.zeros((pP.getTotalCount(), len(sJoints)), dtype='float64') for pP in pPatches]

    global xAllPoints
    xAllPoints = [pP.getAllPoints() for pP in pPatches]

    dInfluenceIds = dict(list(zip(sAllPlanes, np.arange(len(sAllPlanes)))))

    report.report.resetProgress(iAllPlanes)

    def _skinClusterHierarchyREC(xFrontIds, sPlane):  # xGeo = [xWeights, xFrontIds, xAllPoints]
        report.report.addLogText('splitting for joint %s..' % sPlane)
        report.report.incrementProgress()

        if bShowProcess:
            sSelect = []
            for i, aFrontIds in enumerate(xFrontIds):
                sSelect += ['%s.vtx[%s]' % (pPatches[i].getName(), sStr) for sStr in
                            utils.createMayaStringFromList(aFrontIds, bIdListIsAlreadySorted=True)]
                cmds.select(sSelect)
        cmds.refresh()
        # time.sleep(1)

        # do the boolean intersection
        #
        xNewFrontIds = []
        xBackIds = []
        if sPlane == kPlanesGroup:
            xNewFrontIds = xFrontIds
        else:
            for iWeightIndex, aFrontIds in enumerate(xFrontIds):
                aBackIds, aFrontIds = splitSkinClusterWeights(aFrontIds, sPlane, dInfluenceIds, iWeightIndex)
                xNewFrontIds.append(aFrontIds)
                xBackIds.append(aBackIds)

        sChildPlanes = cmds.listRelatives(sPlane, c=True, typ='transform')  or []
        # if not sChildPlanes:
        #     raise Exception('something is wrong with %s, it doesn\'t have children' % sPlane)
        sNextPlanes = [sN for sN in sChildPlanes if cmds.objectType(sN) == 'transform']
        if sNextPlanes:
            # should be fPriorities, fPriorities becasue it's actually float values
            iPrioritiesAll = [int(cmds.getAttr('%s.priority' % sP)) for sP in sNextPlanes]
            iPriorities = list(set(iPrioritiesAll))
            iPriorities.sort(reverse=True)
            xNextPlanes = {i: [] for i in iPriorities}
            for sP, iPr in zip(sNextPlanes, iPrioritiesAll):
                xNextPlanes[iPr].append(sP)
            sOrderedNextPlanes = []
            for iPriority in iPriorities:
                sOrderedNextPlanes += xNextPlanes[iPriority]

            for sPlane in sOrderedNextPlanes:
                xCutBackIds, _ = _skinClusterHierarchyREC([np.copy(x) for x in xNewFrontIds], sPlane)

                for i in range(len(xNewFrontIds)):
                    xNewFrontIds[i] = xCutBackIds[i]

        return xBackIds, xNewFrontIds

    cmds.undoInfo(stateWithoutFlush=False)
    try:
        _, xLeftOverIds = _skinClusterHierarchyREC(xFrontIds, kPlanesGroup)

        # assign left over ids to the last plane of the first iteration
        sRootPlanes = [sP for sP in cmds.listRelatives(kPlanesGroup, c=True) if cmds.objExists('%s.priority' % sP)]
        iPriorities = [int(cmds.getAttr('%s.priority' % sP)) for sP in sRootPlanes]
        sLeftOverPlane = sRootPlanes[np.argmin(iPriorities)]

        for i, aLeftOverIds in enumerate(xLeftOverIds):
            if len(aLeftOverIds):
                _assignFullJointWeight(xSplitWeights[i], aLeftOverIds, sLeftOverPlane, dInfluenceIds)
    except:
        raise
    finally:
        cmds.undoInfo(stateWithoutFlush=True)

    for i, pPatch in enumerate(pPatches):
        aWeights2d = xSplitWeights[i]
        aWeightsReduced2d, sJointsReduced = patch._removeZeroInfluencesNumpy(aWeights2d, sJoints)
        sBodySkinCluster = 'skinCluster__%s' % pPatch.getTransformName()
        sChooseSkinCluster = sBodySkinCluster if cmds.objExists(sBodySkinCluster) else None
        pPatch.setSkinClusterWeights(aWeightsReduced2d[pPatch.aIds], sInfluences=sJointsReduced, sChooseSkinCluster=sChooseSkinCluster, iJointLocks=iJointLocks,
                                     iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene)

    if iSmoothIterations:
        weights.smoothSkinWeights(pPatches, iIterations=iSmoothIterations)

    cmds.select(sSelBefore)


@uiSettings.addToUI(sTab='Segments', sModuleButton='GeoReduce', sRunButton='Reduce Selected')
def reduceGeo(Strength=5):
    '''
    This is for when you make proxy geo, but first you want to reduce the meshes.
    It just calls the maya tool "Poly Reduce" with attributes that work in many cases.
    '''
    for sMesh in cmds.ls(sl=True):
        print('reducing %s..' % sMesh)
        cmds.delete(sMesh, ch=True)
        cmds.polyReduce(sMesh, ver=1, trm=0, shp=0, keepBorder=1, keepMapBorder=1, keepColorBorder=1, keepFaceGroupBorder=1, keepHardEdge=1, keepCreaseEdge=1, keepBorderWeight=0.5, keepMapBorderWeight=0.5,
        keepColorBorderWeight=0.5, keepFaceGroupBorderWeight=0.5, keepHardEdgeWeight=0.5, keepCreaseEdgeWeight=0.5, useVirtualSymmetry=0, symmetryTolerance=0.01, sx=0, sy=1, sz=0,
        sw=0, preserveTopology=1, keepQuadsWeight=1, vertexMapName="", cachingReduce=1, ch=0, p=Strength, vct=0, tct=0, replaceOriginal=1)
        cmds.refresh()



def _getChildDict(sJoints):
    dChildren = defaultdict(list)
    for sJ in sJoints:
        sParent = sJ
        for i in range(10):
            sParent = cmds.listRelatives(sParent, p=True)[0]
            if sParent == 'skeleton' or cmds.objectType(sParent) == 'joint':
                dChildren[sParent].append(sJ)
                break
    return dChildren






def _getChain(sRoot, dDatas, iMaxCount=5):
    sJoints = [sRoot]
    for i in range(iMaxCount-1):
        sChildren = cmds.listRelatives(sJoints[-1], c=True, typ='joint') or []
        for sChild in sChildren:
            if dDatas[sChild].get('bDisable',False) == False:
                sJoints.append(sChild)
                break
    return sJoints





def _placePlaneBetweenHierarchies(sRootA, sRootB, sPlane, dDatas, iMaxJoints=5):

    sJointsA = _getChain(sRootA, dDatas, iMaxCount=iMaxJoints)
    sJointsB = _getChain(sRootB, dDatas, iMaxCount=iMaxJoints)

    iMaxJoints = min(iMaxJoints, len(sJointsA), len(sJointsB))
    sJointsA = _getChain(sRootA, dDatas, iMaxCount=iMaxJoints)
    sJointsB = _getChain(sRootB, dDatas, iMaxCount=iMaxJoints)

    iVCount = 3
    iUCount = iMaxJoints
    rebuildWithCount(sPlane, iUCount=iUCount, iVCount=iVCount)
    aPointsA = np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sJointsA], dtype='float64').reshape(-1,3)
    aPointsB = np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sJointsB], dtype='float64').reshape(-1,3)
    aMiddles = (aPointsA + aPointsB) * 0.5

    aVectorA = aPointsA - aMiddles
    aVectorB = np.zeros_like(aVectorA)

    print('sJointsA: ', sJointsA)
    print('sJointsB: ', sJointsB)

    aVectorB[:-1] = aMiddles[1:] - aMiddles[:-1]
    aVectorB[-1] = aVectorB[-2]

    aCross = np.cross(aVectorA, aVectorB)

    scaleFactors = 0.25 * np.linalg.norm(aPointsB-aPointsA) / np.linalg.norm(aCross, axis=1)
    aCross *= scaleFactors[:,np.newaxis]

    aCrossWorld = aMiddles + aCross
    aCrossNegWorld = aMiddles - aCross

    for i in range(iUCount):
        cmds.move(aCrossWorld[i,0], aCrossWorld[i,1], aCrossWorld[i,2], '%s.cv[%d][0]' % (sPlane, i), a=True, ws=True)
        cmds.move(aMiddles[i,0], aMiddles[i,1], aMiddles[i,2], '%s.cv[%d][1]' % (sPlane, i), a=True, ws=True)
        cmds.move(aCrossNegWorld[i,0], aCrossNegWorld[i,1], aCrossNegWorld[i,2], '%s.cv[%d][2]' % (sPlane, i), a=True, ws=True)


xSplitWeights = []
dAllPoints = []


@uiSettings.addToUI(sTab='Segments', sModuleButton='GeoCut', sRunButton='Selected Polys all Planes',
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def cutGeo(bFillHoles=False, bShowProcess=True):
    def _splitHierarchyREC(sGeo, sPlane):
        
        report.report.incrementProgress()


        # do the boolean intersection and rename them
        #
        sGeoA = []
        sGeoB = []
        print('splitting for joint %s..' % sPlane)
        if bShowProcess:
            cmds.select([sMesh for sMesh in sGeo if cmds.objExists(sMesh)])
            cmds.refresh()

        if sPlane != kPlanesGroup:
            for sMesh in sGeo:
                if not cmds.objExists(sMesh):
                    continue
                sMeshA, sMeshB = splitMesh(sMesh, sPlane, sMeshNameA=sMesh, sMeshNameB=_cutNameFromPlane(sPlane), bFillHoles=bFillHoles)
                if sMeshA: sGeoA.append(sMeshA)
                if sMeshB: sGeoB.append(sMeshB)
        else:
            sGeoB = sGeo

        sNextPlanes = [sN for sN in (cmds.listRelatives(sPlane, c=True, typ='transform') or []) if cmds.objectType(sN) == 'transform']
        if sNextPlanes:
            # should be fPrioritiesAll because it's actually float
            iPrioritiesAll = []
            for sP in sNextPlanes:
                sPriorityAttr = '%s.priority' % sP
                if cmds.objExists(sPriorityAttr):
                    iPrioritiesAll.append(int(cmds.getAttr(sPriorityAttr)))
                else:
                    iPrioritiesAll.append(0)
            # iPrioritiesAll = [int(cmds.getAttr('%s.priority' % sP)) for sP in sNextPlanes]
            iPriorities = list(set(iPrioritiesAll))
            iPriorities.sort(reverse=True)
            xNextPlanes = {i:[] for i in iPriorities}
            for sP, iPr in zip(sNextPlanes, iPrioritiesAll):
                xNextPlanes[iPr].append(sP)
            sOrderedNextPlanes = []
            for iPriority in iPriorities:
                sOrderedNextPlanes += xNextPlanes[iPriority]
            for sPlane in sOrderedNextPlanes:
                _splitHierarchyREC(sGeoB, sPlane)

        return sGeoA, sGeoB


    sGeo = cmds.ls(sl=True)
    
    cmds.undoInfo(openChunk=True)
    try:
        sGroup = _createOrGetCutGroup()

        for g in range(len(sGeo)):
            sParents = cmds.listRelatives(sGeo[g], p=True)
            if not sParents or sParents[0] != sGroup:
                sGeo[g] = cmds.parent(sGeo[g], sGroup)[0]

        cmds.setAttr('%s.v' % sGroup, True)

        sAllPlanes = cmds.listRelatives(kPlanesGroup, ad=True)
        sAllPlanes = [sP for sP in sAllPlanes if sP.startswith('plane_') and cmds.objectType(sP) == 'transform']
        iAllPlanes = len(sAllPlanes)
        report.report.resetProgress(iAllPlanes)

        xSplitResult = _splitHierarchyREC(sGeo, kPlanesGroup)

        # handle left overs
        #
        sLeftOvers = utils.toList(xSplitResult[1])
        sRootPlanes = [sP for sP in cmds.listRelatives(kPlanesGroup, c=True) if cmds.objExists('%s.priority' % sP)]
        iPriorities = [int(cmds.getAttr('%s.priority' % sP)) for sP in sRootPlanes]
        iMinIndex = np.argmin(iPriorities)
        sLeftOverPlane = sRootPlanes[iMinIndex]
        
        for sLeftOver in sLeftOvers:
            if sLeftOver and cmds.objExists(sLeftOver):
                print('cutting: "%s"' % sLeftOver)
                cmds.rename(sLeftOver, _cutNameFromPlane(sLeftOverPlane))
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def _cutNameFromPlane(sPlane):
    return '%s_0' % sPlane.replace('plane_','cut_')


#
# @uiSettings.addToUI(sTab='Segments', sModuleButton='Cut', sRunButton='Assign Poly to Planes')
# def assign():
#     sSel = cmds.ls(sl=True)
#     sPlane, sPoly = None, None
#     for sObj in sSel:
#         if sObj.startswith('plane_'): sPlane = sObj
#         elif cmds.listRelatives(sObj, s=True, typ='mesh'): sMesh = sObj
#
#     sMesh = cmds.rename(sMesh, _cutNameFromPlane(sPlane))
#     cmds.parent(sMesh, _createOrGetCutGroup())
#


def _createCleanPlane(sPlane):
    print('sPlane: ', sPlane)
    sPlane = cmds.duplicate(sPlane, rr=True)[0]
    sChildren = cmds.listRelatives(sPlane, c=True, f=True, typ='transform')
    if sChildren: cmds.delete(sChildren)
    for sAttr in ['t','r','s', 'tx','ty','tz','rx','ry','rz','sx','sy','sz']:
        cmds.setAttr('%s.%s' % (sPlane,sAttr), lock=False)

    try: sPlane = cmds.parent(sPlane, w=True)[0]
    except: pass

    cmds.makeIdentity(sPlane, apply=True, t=True, r=True, s=True)
    return sPlane


@uiSettings.addToUI(sTab='Segments', sModuleButton='Proxy', sRunButton='Make Proxy Meshes',
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsPlaneCutter/')
def makeProxyMeshes():
    '''
    Takes the cut meshes and creates proxy meshes from them
    '''
    cmds.undoInfo(openChunk=True)
    try:
        dCuts = defaultdict(list)
        sCuts = cmds.listRelatives('_cuts')
        for sCut in sCuts:
            sSplits = sCut.split('_')
            sSplits[0] = 'proxy'
            sProxy = '_'.join(sSplits[:-1])
            dCuts[sProxy].append(sCut)

        for sProxy, sCuts in list(dCuts.items()):
            if len(sCuts) > 1:
                cmds.polyUnite(sCuts, ch=False, name=sProxy)
                try:
                    cmds.delete(sCuts)
                except:
                    pass
            elif len(sCuts) == 1:
                utils._duplicateGeoClean(sCuts[0], sName=sProxy)
                cmds.delete(sCuts[0])
                try:
                    cmds.parent(sProxy, w=True)
                except:
                    pass

            cmds.setAttr('%s.rotatePivot' % sProxy, 0, 0, 0)
            cmds.setAttr('%s.scalePivot' % sProxy, 0, 0, 0)
            utils.parentTo(sProxy, _createOrGetProxyGroup())
            # try:
            #     cmds.parent(sProxy, _createOrGetProxyGroup())
            # except:
            #     pass
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



@uiSettings.addToUI(sTab='Segments', sModuleButton='Proxy', sRunButton='Test ParentConstraint Proxy Meshes')
def parentProxyMeshes():
    
    sProxies = cmds.listRelatives('_proxys', typ='transform')
    
    cmds.undoInfo(openChunk=True)
    try:
        for sProxy in sProxies:
            sJoint = utils.replaceStringStart(sProxy, 'proxy_', 'jnt_')
            
            for sAttr in ['t', 'tx', 'ty', 'tz', 'r', 'rx', 'ry', 'rz', 's', 'sx', 'sy', 'sz']:
                cmds.setAttr('%s.%s' % (sProxy, sAttr), lock=False, channelBox=True)
                cmds.setAttr('%s.%s' % (sProxy, sAttr), keyable=True)
            
            if cmds.objExists(sJoint):
                xforms.matrixParentConstraint(sJoint, sProxy, mo=True)
    
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def splitSkinClusterWeights(aFrontIds, sPlane, dInfluenceIds, iWeightIndex):
    sPlaneName = sPlane
    global xSplitWeights
    aWeights = xSplitWeights[iWeightIndex]

    global xAllPoints
    aAllPoints = xAllPoints[iWeightIndex]

    sPlane = _createCleanPlane(sPlane)
    fnPlaneNurbs = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sPlane))
    aPlanePoints = np.array(fnPlaneNurbs.cvPositions(), dtype='float64')[:,0:3]
    bPerfectPlane = topology.arePointsOnPlane(aPlanePoints)
    

    aClosPoints = np.empty((aFrontIds.size,3), dtype='float64')
    aNormals = np.empty((aFrontIds.size, 3), dtype='float64')
    if bPerfectPlane:
        aClosPoints[:] = aPlanePoints[0]
        aNormals[:] = fnPlaneNurbs.normal(0,1)
    else:
        for i, iVert in enumerate(aFrontIds):
            mClosestPoint, u, v = fnPlaneNurbs.closestPoint(OpenMaya2.MPoint(aAllPoints[iVert]))
            mNormal = fnPlaneNurbs.normal(u,v)
            aClosPoints[i] = [mClosestPoint[0], mClosestPoint[1], mClosestPoint[2]]
            aNormals[i] = [mNormal[0], mNormal[1], mNormal[2]]

    cmds.delete(sPlane)


    # find out what vertices are below and above
    #
    aLocals = aAllPoints[aFrontIds]-aClosPoints
    aDots = np.sum(aLocals*aNormals, axis=1)
    aAbove = aFrontIds[np.array(np.where(aDots >= 0)[0], dtype=int)]
    aBelow = np.setdiff1d(aFrontIds, aAbove)

    if aAbove.size:
        _assignFullJointWeight(aWeights, aAbove, sPlaneName, dInfluenceIds)

    return aBelow, aAbove



def getAbove(pMesh, aFilterIds, sPlane):

    aAllPoints = pMesh.getPoints()

    sPlane = _createCleanPlane(sPlane)
    fnPlaneNurbs = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sPlane))
    aPlanePoints = np.array(fnPlaneNurbs.cvPositions(), dtype='float64')[:, 0:3]
    bPerfectPlane = topology.arePointsOnPlane(aPlanePoints)

    aClosPoints = np.empty((aFilterIds.size, 3), dtype='float64')
    aNormals = np.empty((aFilterIds.size, 3), dtype='float64')
    if bPerfectPlane:
        aClosPoints[:] = aPlanePoints[0]
        aNormals[:] = fnPlaneNurbs.normal(0, 1)
    else:
        for i, iVert in enumerate(aFilterIds):
            mClosestPoint, u, v = fnPlaneNurbs.closestPoint(OpenMaya2.MPoint(aAllPoints[iVert]))
            mNormal = fnPlaneNurbs.normal(u, v)
            aClosPoints[i] = [mClosestPoint[0], mClosestPoint[1], mClosestPoint[2]]
            aNormals[i] = [mNormal[0], mNormal[1], mNormal[2]]

    cmds.delete(sPlane)

    aLocals = aAllPoints[aFilterIds] - aClosPoints
    aDots = np.sum(aLocals * aNormals, axis=1)
    aAbove = aFilterIds[np.array(np.where(aDots >= 0)[0], dtype=int)]
    return aAbove






def _assignFullJointWeight(aWeights, aIds, sPlane, dInfluenceIds):
    iInf = dInfluenceIds[sPlane]
    iOtherInfs = np.arange(len(list(dInfluenceIds.keys()))-1)
    iOtherInfs[iInf:] += 1
    aWeights[aIds[:,np.newaxis], iOtherInfs] = 0
    aWeights[aIds, iInf] = 1.0



def splitMesh(sMesh, sPlane, bFillHoles=True, sMeshNameA=None, sMeshNameB=None):


    sPlane = _createCleanPlane(sPlane)
    fnPlaneNurbs = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sPlane))
    aPlanePoints = np.array(fnPlaneNurbs.cvPositions(), dtype='float64')[:,0:3]


    cmds.delete(sMesh, sPlane, ch=True)
    sDupl = cmds.duplicate(sMesh)[0]
    cmds.delete(sMesh)
    sMesh = sDupl
    if sMeshNameA:
        sMesh = cmds.rename(sMesh, sMeshNameA)

    mDagPath = utils.getDagPath(sMesh)
    fnMesh = OpenMaya2.MFnMesh(mDagPath)
    iVertexCount = fnMesh.numVertices
    if not cmds.listRelatives(sPlane, s=True, typ='nurbsSurface'):
        raise Exception('%s is not a nurbsSurface' % sPlane)

    if not cmds.listRelatives(sMesh, s=True, typ='mesh'):
        raise Exception('%s is not a polygon mesh' % sMesh)


    bPerfectPlane = topology.arePointsOnPlane(aPlanePoints)

    # get closestPoints and normals for each vertex
    #
    mPoints = fnMesh.getPoints(OpenMaya2.MSpace.kWorld)
    aPoints = np.array(mPoints, dtype='float64')[:,0:3]
    if bPerfectPlane:
        aClosPoints = np.empty((fnMesh.numVertices,3), dtype='float64')
        aNormals = np.empty((fnMesh.numVertices,3), dtype='float64')
        aClosPoints[:] = aPlanePoints[0]
        aNormals[:] = fnPlaneNurbs.normal(0,1)
    else:
        fClosests = cmds.kt_findClosestPoints(fromMesh=sMesh, toMesh=sPlane, returnNormals=True)
        aClosests = np.array(fClosests, dtype='float64').reshape(-1,6)
        aClosPoints = aClosests[:,0:3]
        aNormals = aClosests[:,3:]

    # find out what vertices are below and above
    #
    aPlaneDs = np.sum(aClosPoints * aNormals, axis=1)
    aLocals = aPoints-aClosPoints
    aDots = np.sum(aLocals*aNormals, axis=1)
    aAbove = np.where(aDots >= 0)[0]
    aBelow = np.setdiff1d(np.arange(iVertexCount, dtype=int), aAbove)
    if not aAbove.size:
        if sMeshNameA:
            sMesh = cmds.rename(sMesh, sMeshNameA)
        cmds.delete(sPlane)
        return sMesh, None
    if not aBelow.size:
        if sMeshNameB:
            sMesh = cmds.rename(sMesh, sMeshNameB)
        cmds.delete(sPlane)
        return None, sMesh


    aEdges = utils.numpify2dList(topology.getAllVertexEdges(mDagPath))

    aEdgesAbove = aEdges[aAbove]
    aEdgesBelow = aEdges[aBelow]

    aCutEdges = np.intersect1d(aEdgesAbove.ravel(), aEdgesBelow.ravel())
    aCutEdges = np.delete(aCutEdges, np.where(aCutEdges == -1)[0])
    aCutEdges.sort()
    aCutVerts = np.zeros(aCutEdges.size*2, dtype=int).reshape(-1,2)

    for i, edge in enumerate(aCutEdges):
        aCutVerts[i] = fnMesh.getEdgeVertices(edge)

    # get neighbor edges
    #
    iFaceEdges = topology.getAllFaceEdges(mDagPath)

    it = OpenMaya2.MItMeshEdge(mDagPath)
    iNeighborEdges = [None] * fnMesh.numEdges
    iCounter = 0
    while not it.isDone():
        ind = it.index()
        if iCounter == aCutEdges.size:
            break
        if aCutEdges[iCounter] == ind:
            faces = it.getConnectedFaces()
            iEdgeList = []
            for face in faces:
                iEdgeList += iFaceEdges[face]
            iEdgeList = list(set(iEdgeList))
            try: iEdgeList.remove(it.index())
            except: pass

            iNeighborEdges[ind] = iEdgeList
            iCounter += 1
        it.next()

    aP0s = aPoints[aCutVerts[:,0].ravel()]
    aP1s = aPoints[aCutVerts[:,1].ravel()]

    aRayDs = aP1s-aP0s
    aRayLengths = np.sqrt(np.sum(np.square(aRayDs), axis=1))
    aRayDs /= aRayLengths[:,np.newaxis]
    
    
    # now calculate the intersections of rays and planes
    #
    aCutNormals = aNormals[aCutVerts[:,0]]
    aCounterDots = np.sum((aP0s * aCutNormals), axis=1)
    aCounter = aPlaneDs[aCutVerts[:,0]] - aCounterDots
    aDenom = np.sum(aRayDs * aCutNormals, axis=1)
    aTs = aCounter / aDenom

    aPositions = aP0s + aRayDs * aTs[:,np.newaxis]
    aPercs = aTs / aRayLengths
    aPercs = np.clip(aPercs, 0.001, 0.999)
    aPercsTotal = np.zeros(fnMesh.numEdges, dtype='float64')
    aPercsTotal[aCutEdges] = aPercs

    xCutQueues = []
    xFirstVertPositions = []
    iCutEdges = list(aCutEdges)


    for iSafety in range(300):
        if iSafety == 299:
            print('something is going wrong..')
        iQueueStart = -2
        for i in range(len(iCutEdges)):
            if iCutEdges[i] != -1:
                iQueueStart = i
                break
        if iQueueStart == -2:
            break
        iCurrentEdge = iCutEdges[iQueueStart]
        aFirstVertPosition = None
        xCutQueue = deque([iCurrentEdge])
        iCutEdges[iQueueStart] = -1

        for bRight in [True, False]:
            iFirstEdgeForThisSide = iCurrentEdge
            for iStart in range(1, len(iCutEdges), 1):
                for i in range(0, len(iCutEdges), 1):
                    if iCutEdges[i] != -1 and iCutEdges[i] in iNeighborEdges[iCurrentEdge]:
                        iCurrentEdge = iCutEdges[i]
                        if bRight: xCutQueue.append(iCurrentEdge)
                        else: xCutQueue.appendleft(iCurrentEdge)
                        iCutEdges[i] = -1
                        if utils.isNone(aFirstVertPosition):# == None: # NOT TESTED YET - but should be ok (python 3 fix)
                            aFirstVertPosition = aPositions[i]
                        break

            iCurrentEdge = iFirstEdgeForThisSide
        xCutQueues.append(xCutQueue)
        xFirstVertPositions.append(aFirstVertPosition)


    # polySplit using xCutQueues
    for xCutQueue in xCutQueues:
        xCutList = []
        for iEdge in xCutQueue:
            xCutList.append((int(iEdge),float(aPercsTotal[iEdge])))
        if xCutQueue[0] in iNeighborEdges[xCutQueue[-1]]:
            xCutList.append((int(xCutQueue[0]),float(aPercsTotal[xCutQueue[0]])))

        print ('xCutList: ', xCutList)
        cmds.polySplit(sMesh, ip=xCutList)
        mDagPath = utils.getDagPath(sMesh)
        fnMesh = OpenMaya2.MFnMesh(mDagPath)

    # make 2 pieces
    sMeshB = cmds.duplicate(sMesh)[0]
    if sMeshNameB:
        sMeshB = cmds.rename(sMeshB, sMeshNameB)


    iFaces = []
    aAbove.sort()
    iAboveInd = 0

    it = OpenMaya2.MItMeshVertex(mDagPath)
    while not it.isDone():
        if iAboveInd >= (aAbove.size):
            break
        if it.index() == aAbove[iAboveInd]:
            mFaces = it.getConnectedFaces()
            iFaces += list(mFaces)
            iAboveInd += 1
        it.next()

    aFaces = np.unique(np.array(iFaces, dtype=int))
    aFacesAll = np.arange(int(fnMesh.numPolygons), dtype=int)
    aFacesOpp = np.setdiff1d(aFacesAll, np.array(iFaces, dtype=int))

    for sM, aArr in [(sMesh, aFaces), (sMeshB,aFacesOpp)]:
        sComponentStrings = ['%s.f[%s]' % (sM, sInds) for sInds in utils.createMayaStringFromList(aArr,True)]
        cmds.delete(sComponentStrings)

    if bFillHoles:
        for sM in [sMesh, sMeshB]:
            for aFirstVertPosition in xFirstVertPositions:
                if utils.isNone(aFirstVertPosition):# == None:
                    continue

                mDagPath = utils.getDagPath(sM)
                fnMesh = OpenMaya2.MFnMesh(mDagPath)
                mPoints = fnMesh.getPoints(OpenMaya2.MSpace.kWorld)
                aPoints = np.array(mPoints, dtype='float64')[:,0:3]
                aLocals = aPoints - aFirstVertPosition
                aSums = np.sum(np.square(aLocals), axis=1)
                aSmallest = np.argmin(aSums)
                cmds.polyCloseBorder('%s.vtx[%d]' % (sM, aSmallest))
                fnMesh = OpenMaya2.MFnMesh(mDagPath)

    cmds.delete(sPlane)
    return sMesh, sMeshB


