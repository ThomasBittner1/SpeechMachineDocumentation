###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.cmds as cmds
import numpy as np
import os
import pickle
import re
import math
from collections import defaultdict
import shutil

import kangarooTools.utilFunctions as utils
import kangarooTools.report as report
import kangarooTools.patch as patch
import kangarooTools.nodes as nodes
import kangarooTools.uiSettings as uiSettings
import kangarooTools.controls as controls
import kangarooTools.xforms as xforms
import kangarooTools.deformers as deformers
import kangarooTools.barycentric as barycentric
from functools import reduce
import kangarooTools.utilsQt as utilsQt
from kangarooTools.controlsPuppet import dDocumentationLinks


# =================
# Save
# =================

class SaveDeformerFilter():
    everything = 0
    onlySkinCluster = 1
    everythingExceptSkinCluster = 2



class LoadMayaSelection():
    ignoreSelection = 0
    loadOntoSelection = 1
    # loadOnlyTheSelected = 2


class LoadWorldspace():
    ignore = 0
    closestVertices = 1
    closestPoints = 2
    closestVerticesIfTopologyDiffers = 3
    closestPointsIfTopologyDiffers = 4



# def _validateChooseSkinCluster(sSkinCluster):
#     if sSkinCluster:
#         if not cmds.objExists(sSkinCluster):
#             raise Exception('SkinCluster "%s" doesn\'t exist' % sSkinCluster)
#
#         if cmds.objectType(sSkinCluster) != 'skinCluster':
#             raise Exception('"%s" is not of type skinCluster' % sSkinCluster)


dControls = {}
dControls['sFolder'] = controls.FolderPathControl(sSubFolder='deformers', bReadOnly=True)
dControls['iSaveDeformerFilter'] = controls.RadioButtonsControl(SaveDeformerFilter)


@uiSettings.addToUI(sTab='Export', sModuleButton='Deformers', sRunButton='Export Deformers', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=True, bCheckAsset=True, sDocumentationLink='https://kangaroobuilder.com/builder/builderGeneral/#loaddeformers')
def exportDeformers(_pSelection=None, sFolder=os.path.expanduser('~/Documents'), bSkipBlendShapes=True):
    '''
    Export Deformers: Select Meshes and click Export
    '''

    # sPath = xFile.keys()[0]
    if utils.isNone(sFolder):
        sFolder = assets.assetManager.getCurrentVersionPath()
    bSubFolders = utils.data.get('bDeformerSubFolders', utils.kExportNode, xDefault=False)

    pPatches = _pSelection or patch.getSelectedPatches()

    dMasters = defaultdict(list)  # masters:deformers
    dPatches = {}  # deformers:patches

    # if bSubFolders:
    for pPatch in pPatches:
        if bSubFolders:
            sTransform = pPatch.getTransformName()
            sMaster = xforms.getWorldRoot(sTransform)
            sMasterAttr = '%s.sMaster' % sMaster
            if cmds.objExists(sMasterAttr):
                sMaster = cmds.getAttr(sMasterAttr)
            if sMaster == sTransform:
                sMaster = '.'
        sDs = deformers.listAllDeformers(pPatch.getTransformName(), sIgnoreTypes=['tweak', 'sculpt'])
        for sD in sDs:
            if not cmds.objExists('%s.noExport' % sD) or cmds.getAttr('%s.noExport' % sD) == False:
                if bSkipBlendShapes and cmds.objectType(sD) == 'blendShape':
                    continue
                dPatches[sD] = pPatch
                if bSubFolders:
                    dMasters[sMaster].append(sD)

    dRenamedDeformers = {}
    if bSubFolders:
        sMastersText = '\n'.join(['--root--' if d == '.' else d for d in list(dMasters.keys())])
        sCreateFolder = cmds.confirmDialog(message='Saving weights for these masters?\n%s' % sMastersText,
                                           button=['Extra Folders', 'All in Root', 'Abort'])
        if sCreateFolder == 'Abort':
            return
        elif sCreateFolder == 'All in Root':
            bSubFolders = False
    else:
        dMasters['root'] = list(dPatches.keys())

    # first rename them
    for sD, pP in list(dPatches.items()):
        if '__' not in sD:
            sNamespace, sObjectName = utils.splitNamespace(pP.getTransformName())
            sNewName = '%s%s__%s' % (sNamespace, cmds.objectType(sD), sObjectName)
            dRenamedDeformers[sD] = cmds.rename(sD, sNewName)
        else:
            dRenamedDeformers[sD] = sD

    report.report.resetProgress(len(dRenamedDeformers))
    print('dMasters.items: ', dMasters)
    dReuseData = {}
    for sMaster, sDeformers in list(dMasters.items()):
        if bSubFolders:
            sMasterPath = os.path.join(sFolder, sMaster)
        else:
            sMasterPath = sFolder

        if not os.path.exists(sMasterPath):
            os.makedirs(sMasterPath)

        for sOldDeformer in sDeformers:
            sD = dRenamedDeformers[sOldDeformer]
            sPath = os.path.join(sMasterPath, '%s.npz' % sD.replace(':','.'))
            report.report.addLogText('\n"%s" \n-> "%s"' % (sD, sPath), bIncrementProgress=True)
            _saveDeformerToFile(sPath, [sD], dReuseRecreateData=dReuseData)
            # cmds.refresh()


@uiSettings.addToUI(sTab='Export', sModuleButton='Deformers', sRunButton='Select Changed Meshes', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=True, bCheckAsset=True,
                    sToolTip='This selects all the Meshes where you changed the skinning through kangaroo tools. \nHowever it does NOT know which meshes you changed using other skinning tools')
def selectedChangedDeformerMeshes():
    '''
    If you click Select Changed Meshes it selects all the meshes where you adjusted weights using kangaroo tools. It will\
    not select meshes that got adjusted using maya skin tools
    '''
    sChangedDeformedMeshes = utils.data.get('sChangedDeformedMeshes', xDefault=[])
    sMeshes = []
    sNonExisting = []
    for sDeformerMesh in sChangedDeformedMeshes:
        sMesh = sDeformerMesh.split('.')[0]
        if cmds.objExists(sMesh):
            sMeshes.append(sMesh)
        else:
            sNonExisting.append(sMesh)

    if sMeshes:
        cmds.select(sMeshes)
    else:
        cmds.select(d=True)

    if sNonExisting:
        cmds.confirmDialog(m='Some meshes don\'t exist anymore: %s' % utils.listToString(sNonExisting, iMaxCount=10))



def _saveDeformerToFile(sFile, sDeformers, dReuseRecreateData={}):
    saveDict = {}

    for sDeformer in sDeformers:
        sType = cmds.objectType(sDeformer)
        sGeo = deformers.getGeoFromDeformer(sDeformer, bTransform=True)
        pGeo = patch.patchFromName(sGeo)

        saveDict['%s_type' % sDeformer] = sType
        if sType == 'skinCluster':
            sSkinCluster, sInfluences, aWeights2d = pGeo.getSkinCluster(sChooseSkinCluster=sDeformer)
            aWeights = aWeights2d.ravel()
            aNonZeros = np.array(np.nonzero(aWeights)[0], dtype=int)
            saveDict['%s_skinWeights' % sDeformer] = aWeights[aNonZeros]
            saveDict['%s_nonZeroWeights' % sDeformer] = aNonZeros
            saveDict['%s_weightsCount' % sDeformer] = len(aWeights)
            saveDict['%s_influences' % sDeformer] = np.array(sInfluences)
            saveDict['%s_blendWeights' % sDeformer] = pGeo.getSkinClusterBlendWeights(sChooseSkinCluster=sDeformer)
        sMaps = []
        for sMap, sMapName in deformers.getWeightMaps(sDeformer):
            sMapMaya = deformers.decodeMapName(sMap)
            aWeights = pGeo.getMapValues(sMapMaya)
            saveDict[sMap] = aWeights
            sMaps.append(sMap)

        dAttrs = deformers.getSaveAttributesDict(sDeformer)

        saveDict['%s_attrNames' % sDeformer] = np.array(list(dAttrs.keys()))
        saveDict['%s_attrValues' % sDeformer] = np.array(list(dAttrs.values()), dtype=object)
        saveDict['%s_maps' % sDeformer] = np.array(sMaps)
        sPostDeformers = deformers.getPostDeformers(sDeformer)
        saveDict['%s_postDeformers' % sDeformer] = np.array(sPostDeformers)
        saveDict['%s_geo' % sDeformer] = sGeo
        saveDict['%s_totalPointCount' % sDeformer] = pGeo.getTotalCount()

        if sGeo in dReuseRecreateData:
            xData = dReuseRecreateData[sGeo]
        else:
            pGeo = patch.patchFromName(sGeo)
            xData = pGeo.recreateData()
            dReuseRecreateData[sGeo] = xData

        for sKey, xData in list(xData.items()):
            saveDict['%s_recreateData_%s' % (sDeformer, sKey)] = xData
            
        patch.unlogSkinnedMeshes('%s.%s' % (sGeo, sDeformer))

    saveDict['deformers'] = np.array(sDeformers)

    sDir = os.path.dirname(sFile)
    if not os.path.exists(sDir):
        os.makedirs(sDir)

    if True:
        np.savez(sFile, **saveDict)
        if sFile.endswith('.npz'):
            sOldWtsFile = utils.replaceStringEnd(sFile, '.npz', '.wts')
            if os.path.exists(sOldWtsFile):
                sBackupDir = os.path.join(os.path.dirname(sFile), '_oldWtsFiles')
                if not os.path.exists(sBackupDir):
                    os.makedirs(sBackupDir)
                shutil.move(sOldWtsFile, sBackupDir)
    else:
        with open(sFile, 'wb') as handle:
            pickle.dump(saveDict, handle, protocol=2)
            # pickle.dump(saveDict, handle, protocol=pickle.HIGHEST_PROTOCOL)



# =================
# Load
# =================
# =================

dControls = {}
dControls['iLoadWorldSpace'] = controls.RadioButtonsControl(LoadWorldspace)
dControls['sFolder'] = controls.FolderPathControl(sSubFolder='deformers', bReadOnly=True)

@uiSettings.addToUI(sTab='Export', sModuleButton='DeformerImport', sRunButton='Load', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=False, bCheckAsset=True,
                  sToolTip='Just loads the weight files of whatever you have selected. Vertex selection is supported', sDocumentationLink='https://kangaroobuilder.com/face/mouth/')
def simpleLoad(sFolder=os.path.expanduser('~/Documents'), iLoadWorldSpace=LoadWorldspace.ignore):
    '''
    While normally you load weights in the Load Deformer function of the builder, here you can manually load some of those \
    files in more specific ways.
    Don\'t forget to set the Load WorldSpace option if you are loading files onto geo with changed topology!
    '''
    sSelBefore = cmds.ls(sl=True)

    dSel = defaultdict(list)
    for sSelString in sSelBefore:
        if '.' in sSelString:
            sObj, sComponent = sSelString.split('.')
            dSel[sObj].append(sSelString)
        else:
            dSel[sSelString].append(None)


    sSel = [sO.split('.')[0] for sO in sSelBefore]
    sSel = list(set(sSel))

    report.report.addLogText('importing from folder %s..' % sFolder)
    if not os.path.exists(sFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % sFolder)
        return False


    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sSel))

    sLoadFiles = []
    for sObj, sComponents in dSel.items():

        sFiles = utils.listFilesInFolder(sFolder, bAbsolute=True, sEndswith=['.wts', '.npz'])
        for sFile in sFiles:
            if '__%s.' % sObj in sFile or '__%s__' % sObj in sFile:
                if None in sComponents:
                    cmds.select(sObj)
                else:
                    cmds.select(sComponents)

                sLoaded, dSkipped = _loadFromFile((sFile, None),
                                                  iLoadMayaSelection=LoadMayaSelection.loadOntoSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldSpace, _bNeverSkipDeformerAdjustLogging=True)
                dAllSkipped.update(dSkipped)

        report.report.incrementProgress()

    for sFile in sLoadFiles:
        report.report.addLogText('loading: %s...' % sFile)
        cmds.select(sSelBefore)
        print ('sSelBefore: ', sSelBefore)


    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))
        
        bReturn = False
    
    cmds.select(sSelBefore)
    
    return bReturn
    
    



qDialog = None


@uiSettings.addToUI(sTab='Export', sModuleButton='DeformerImport', sRunButton='Load from Named', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=False, bCheckAsset=True,
                    sToolTip='This opens a prompt where you specify a name of a mesh that you saved from. \nIt will load those weight files onto whatever you have selected  '
                             '\nVertex Selection NOT supported!')
def loadDeformersFromNamed(sFolder=os.path.expanduser('~/Documents'), iLoadWorldSpace=LoadWorldspace.ignore):

    sSelBefore = cmds.ls(sl=True)
    sSel = sSelBefore

    global qClusterDialog
    def _load(sName):
        sName = sName.strip()

        report.report.addLogText('importing from folder %s..' % sFolder)
        if not os.path.exists(sFolder):
            report.report.addLogText('Deformer Folder "%s" not found' % sFolder)
            return False
        sFiles = utils.listFilesInFolder(sFolder, bAbsolute=True, sEndswith=['.wts', '.npz'])

        bReturn = None
        dAllSkipped = {}
        report.report.resetProgress(len(sFiles))
        sMeshFiles = []
        for f, sFile in enumerate(sFiles):
            print('\n\n\nsFile: ', sFile)
            loadedDict = utils.getDictFromPickleOrNumpyFile(sFile)
            # with open(sFile, 'rb') as handle:
            #     loadedDict = pickle.load(handle)

            sKeys = list(loadedDict.keys())
            for sK in sKeys:
                if sK.endswith('_geo'):  # and
                    print(sK, ' -> ', loadedDict[sK])

                    if loadedDict[sK] == sName:
                        report.report.addLogText(sFile)
                        sMeshFiles.append(sFile)

        for sMesh in sSel:
            for sFile in sMeshFiles:
                cmds.select(sMesh)
                sLoaded, dSkipped = _loadFromFile((sFile, None), iLoadMayaSelection=LoadMayaSelection.loadOntoSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldSpace)
                dAllSkipped.update(dSkipped)
                for sDef in sLoaded:
                    sSplits = sDef.split('__')
                    if len(sSplits) >= 1:
                        sSplits[1] = sMesh
                    cmds.rename(sDef, '__'.join(sSplits))


        if dAllSkipped:
            report.report.addLogText('\n\nskipped: ')
            for sDeformer, sReason in list(dAllSkipped.items()):
                report.report.addLogText('%s: %s' % (sDeformer, sReason))

            bReturn = False

        cmds.select(sSelBefore)
        return bReturn

    global qDialog
    qDialog = utilsQt.QGetStringDialog(_load, sMessage='enter name of mesh to load from ')
    qDialog.show()





# @uiSettings.addToUI(sTab='Export', sModuleButton='DeformerImport', sRunButton='Fix Deformer Names', dControls=dControls,
#                     tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=False, bCheckAsset=True)
# def fixDeformerNames():
#     '''
#     Fix Deformer Mesh Names: use that to fix the deformer names after loading
#     '''
#     cmds.undoInfo(openChunk=True)
#     try:
#         sSelBefore = cmds.ls(sl=True)
#         sSel = sSelBefore
#
#         for sMesh in sSel:
#             sDeformers = deformers.listAllDeformers(sMesh)
#             for sD in sDeformers:
#                 sSplits = sD.split('__')
#                 if len(sSplits) >= 2:
#                     sSplits[1] = sMesh
#                     cmds.rename(sD, '__'.join(sSplits))
#     except:
#         raise
#     finally:
#         cmds.undoInfo(closeChunk=True)


@uiSettings.addToUI(sTab='Export', sModuleButton='DeformerImport', sRunButton='Load Select Files', dControls=dControls,
                    tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=False, bCheckAsset=True,
                    sToolTip='This opens a File Select Prompt. \nIt will then load those files on whatever you have selected. \
                    \nVertex Selection NOT supported!')
def loadSelectFiles(sFolder=os.path.expanduser('~/Documents'),
                           iLoadWorldSpace=LoadWorldspace.ignore):

    from PySide2 import QtWidgets
    sFiles, _ = QtWidgets.QFileDialog.getOpenFileNames(None, 'open files', sFolder, '*.npz')


    sSelBefore = cmds.ls(sl=True)


    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    # sMeshFiles = []
    for f, sFile in enumerate(sFiles):
        sLoaded, dSkipped = _loadFromFile((sFile, None),
                                          iLoadMayaSelection=LoadMayaSelection.loadOntoSelection,
                                          iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                          iLoadWorldspace=iLoadWorldSpace)
        for sDef in sLoaded:
            cmds.rename(sDef, sDef.replace('_', ''))

        dAllSkipped.update(dSkipped)

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False

    cmds.select(sSelBefore)
    return bReturn


@uiSettings.addToUI(sTab='Export', sModuleButton='DeformerImport', sRunButton='Load Best Fitting SkinClusters',
                    dControls=dControls,
                    tRefreshControlsAfterRun=[], bAddDefaultButton=True, bDisableOnServer=False, bCheckAsset=True,
                    sToolTip='For every mesh that you have selected he\'ll find the best saved skinCluster based on vertex positions.'
                             '\nVertex Selection NOT supported!')
def loadDeformersBestFitting(sFolder=os.path.expanduser('~/Documents'), iLoadWorldSpace=LoadWorldspace.ignore):

    sSelBefore = cmds.ls(sl=True)

    sSel = sSelBefore

    report.report.addLogText('importing from folder %s..' % sFolder)
    if not os.path.exists(sFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % sFolder)
        return False
    sFiles = utils.listFilesInFolder(sFolder, bAbsolute=False, sEndswith=['.wts', '.npz'])

    sFiles = sorted([os.path.join(sFolder, sF) for sF in sFiles if sF.startswith('skinCluster__')])

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    aFileMeanValues = np.zeros((len(sFiles), 3), dtype='float64')
    dMeshFiles = {}
    for f, sFile in enumerate(sFiles):
        print('\n\n\nsFile: ', sFile)
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)
        loadedDict = utils.getDictFromPickleOrNumpyFile(sFile)
        # with open(sFile, 'rb') as handle:
        #     loadedDict = pickle.load(handle)

        sKeys = list(loadedDict.keys())
        for sK in sKeys:
            if sK.endswith('_geo'):
                dMeshFiles[str(loadedDict[sK])] = sFile
            if 'recreateData' in sK and sK.endswith('_points'):
                aFileMeanValues[f] = np.mean(loadedDict[sK], axis=0)

    for sMesh in sSel:
        if len(deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])):
            continue

        aMeanValue = np.mean(patch.patchFromName(sMesh).getAllPoints(), axis=0)
        aFileDiffs = aFileMeanValues - aMeanValue[np.newaxis, :]
        aLengths = np.linalg.norm(aFileDiffs, axis=-1)
        iMin = np.argmin(aLengths)

        sFile = sFiles[iMin]
        cmds.select(sMesh)
        sSkinClusters, dSkipped = _loadFromFile((sFile, None), iLoadMayaSelection=LoadMayaSelection.loadOntoSelection,
                                                iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                iLoadWorldspace=iLoadWorldSpace, bAlwaysCreateNew=True)
        dAllSkipped.update(dSkipped)

        if sSkinClusters:
            cmds.rename(sSkinClusters[0], sSkinClusters[0].replace('_', ''))

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False

    cmds.select(sSelBefore)
    return bReturn


# reove those lines????
sTabControls = ['iJointLocks', 'iCheckMissingInfluences', 'xDistanceMeshes', 'iBorderEdges',
                'iSmoothBorderMask', 'xClosestToCurve', 'sSphereMasks']
sTopControls = ['sChooseSkinCluster']



def _extractFileSelections(loadedDict, sFilter=None):
    dDeformers = {}

    def __getLoadEverythingDict(sDef):
        dX = defaultdict(set)
        dX['bJointWeights'] = True
        dX['bBlendWeights'] = True
        dX['sMaps'] = [sM for sM in loadedDict['%s_maps' % sDef]]
        dX['sAttrs'] = [sM for sM in loadedDict['%s_attrNames' % sDef]]
        dX['bOrder'] = True
        return dX

    if not sFilter:  # either nothing is selected, or the file is selected
        for sD in loadedDict['deformers']:
            dDeformers[sD] = __getLoadEverythingDict(sD)

    else:
        for sF in sFilter:
            if '.' not in sF:  # deformer
                dDeformers[sF] = __getLoadEverythingDict(sF)
            else:
                sSplits = sF.split('.')
                sD = sSplits[1]

                if sD not in list(dDeformers.keys()):
                    dDeformers[sD] = defaultdict(set)

                if sSplits[0] == 'jointWeights':
                    dDeformers[sD]['bJointWeights'] = True
                    if len(sSplits) > 2:  # joint is selected
                        dDeformers[sD]['sJointFilter'].add(sSplits[2])
                elif sSplits[0] == 'blendWeights':
                    dDeformers[sD]['bBlendWeights'] = True
                if sSplits[0] == 'maps':
                    dDeformers[sD]['sMaps'].add('.'.join(sSplits[1:]))
                elif sSplits[0] == 'attributes':
                    if len(sSplits) == 2:  # all attributes
                        dDeformers[sD]['sAttrs'] = list(loadedDict['%s_attrNames' % sD])
                    elif len(sSplits) > 2:  # one attribute
                        dDeformers[sD]['sAttrs'].add('.'.join(sSplits[2:]))
                elif sSplits[0] == 'order':
                    bOrder = True

    dDeformers = {sK: dict(sV) for sK, sV in list(dDeformers.items())}

    return dDeformers


def _areWeLoadingWorldSpace(iLoadWorldspace, iSavedTotalPoints, iLoadTotalPoints):
    # check if we are loading in worldspace ?!
    #

    bMatchingTopology = iSavedTotalPoints == iLoadTotalPoints
    bWorldspace = False
    if iLoadWorldspace == LoadWorldspace.ignore:
        if not bMatchingTopology:
            cmds.warning('saved geo\'s vertex count doesn\'t match the load geo (%d -> %d)' % (
            iSavedTotalPoints, iLoadTotalPoints))
            return None, 0
            # sSkipped.append(sD)
            # continue
        else:
            iLoadWorldspacePass = patch.Worldspace.ignore
    elif iLoadWorldspace in [LoadWorldspace.closestVertices, LoadWorldspace.closestPoints]:
        bWorldspace = True
        if iLoadWorldspace == LoadWorldspace.closestVertices:
            iLoadWorldspacePass = patch.Worldspace.closestVertices
        elif iLoadWorldspace == LoadWorldspace.closestPoints:
            iLoadWorldspacePass = patch.Worldspace.closestPoints
    elif iLoadWorldspace in [LoadWorldspace.closestVerticesIfTopologyDiffers,
                             LoadWorldspace.closestPointsIfTopologyDiffers]:
        if not bMatchingTopology:
            bWorldspace = True
            if iLoadWorldspace == LoadWorldspace.closestVerticesIfTopologyDiffers:
                iLoadWorldspacePass = patch.Worldspace.closestVertices
            elif iLoadWorldspace == LoadWorldspace.closestPointsIfTopologyDiffers:
                iLoadWorldspacePass = patch.Worldspace.closestPoints
        else:  # topology matches -> no need
            iLoadWorldspacePass = patch.Worldspace.ignore

    return bWorldspace, iLoadWorldspacePass




def _loadFromFile(xFile=(os.path.expanduser('~/Documents/defaultMapWeights.wts'), None),
                  iLoadMayaSelection=LoadMayaSelection.loadOntoSelection, fBlend=1.0, xDistanceMeshes=None,
                  iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                  iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                  iJointLocks=patch.JointLocks.ignore,
                  iLoadWorldspace=LoadWorldspace.ignore, bKeepWorldspaceGeometry=False, pIsolatePatches=None, sChooseSkinCluster=None, bAlwaysCreateNew=False, _bNeverSkipDeformerAdjustLogging=False):
    # sSkipped = []

    iFileCounter = -1
    sPath, sFilter = xFile
    iFileCounter += 1


    loadedDict = utils.getDictFromPickleOrNumpyFile(sPath)
    
    dDeformers = _extractFileSelections(loadedDict, sFilter=sFilter)
    dSkippedDeformers = {}
    sLoadedDeformers = []

    if not dDeformers:
        dSkippedDeformers[sPath] = 'Couldn\'t find deformer key'
        return [], dSkippedDeformers

    pSelection = patch.getSelectedPatches()
    dSelection = {pS.getTransformName(): pS for pS in pSelection}


    # if sIsolateDeformers != None:
    #     sIsolateDeformers = set(sIsolateDeformers)

    sKeyD = list(dDeformers.keys())[0] # sKeyD will go away later, but for now it's still used for the keys
    xDeformerContent = dDeformers[sKeyD]
    sDotSplits = os.path.basename(sPath).rsplit('.', maxsplit=1)
    sD = sDotSplits[0].replace('.', ':')
    sDeformerSplits = sD.split('__')
    if len(sDeformerSplits) < 2:
        raise Exception('problem with file name "%s", it needs at least one __ in there' % os.path.basename(sPath))

    if True: # used to be iteration through deformers in file. But now we only have one
        sNamespace, __sType__ = utils.splitNamespace(sDeformerSplits[0])
        sGeo = '%s%s' % (sNamespace, sDeformerSplits[1])
        if pIsolatePatches:
            if not cmds.objExists(sGeo):
                return [], dSkippedDeformers

            for pI in pIsolatePatches:
                if utils.geoEqual(pI.getTransformName(), sGeo):
                    report.report.addLogText('== Loading weights for %s (%s)' % (sGeo, sD))
                else:
                    return [], dSkippedDeformers



        iSavedTotalPoints = loadedDict['%s_totalPointCount' % sKeyD]

        sType =  str(loadedDict['%s_type' % sKeyD])

        if sType == 'skinCluster':
            sInfluences, aWeights2d = _extractSkinClusterFromLoadedDict(loadedDict, sKeyD)
            aWeights2d, sInfluences = patch._removeZeroInfluencesNumpy(aWeights2d, sInfluences)
            if not len(sInfluences):
                print('skipping %s, couldn\'t find influences in the file' % sInfluences)
                dSkippedDeformers[sD] = 'no influences found in file: %s' % sGeo
                return [], dSkippedDeformers
        else:
            sInfluences = None

        if cmds.objExists(sGeo):
            try:
                pSaved = patch.patchFromName(sGeo)
            except Exception as e:
                dSkippedDeformers[sD] = 'Problem with "%s" - %s' % (sGeo, str(e))
                return [], dSkippedDeformers

        else:
            if iLoadMayaSelection == LoadMayaSelection.ignoreSelection:
                dSkippedDeformers[sD] = 'object doen\'t exist: %s' % sGeo
                return [], dSkippedDeformers
            elif iLoadMayaSelection == LoadMayaSelection.loadOntoSelection:
                pass

        pLoadOnto = None

        # create if needed
        #
        bCreatedNewDeformer = False
        sSceneDeformer = None


        if iLoadMayaSelection == LoadMayaSelection.loadOntoSelection:
            pLoadOnto = pSelection[0]
            bWorldspace, iLoadWorldspacePass = _areWeLoadingWorldSpace(iLoadWorldspace, iSavedTotalPoints,
                                                                       pLoadOnto.getTotalCount())
            if bWorldspace == None:  # geo count don't match but we don't want to load worldspace
                dSkippedDeformers[sD] = 'Geo doesn\'t match (B)'
                return [], dSkippedDeformers

            # if a deformer with saved name already exists on that pLoadOnto, use that. If not, create it
            sDeformersOfGeo = deformers.listAllDeformers(pLoadOnto.getName(), sFilterTypes=[sType])
            if sD in sDeformersOfGeo and not bAlwaysCreateNew:
                sSceneDeformer = sD
            else:

                sSceneDeformer = deformers.createDeformer(sD, sType, pLoadOnto.getName(), sInfluences=sInfluences,
                                                          bAlwaysAddDefaultWeightsOnSkinCluster=bWorldspace)

                bCreatedNewDeformer = True

        elif iLoadMayaSelection == LoadMayaSelection.ignoreSelection:

            if not cmds.objExists(sD):
                if not pSaved:
                    cmds.warning('skipping deformer "%s", because geometry is missing' % sD)
                    dSkippedDeformers[sD] = 'Geo is missing'
                    return [], dSkippedDeformers
                else:
                    bWorldspace, iLoadWorldspacePass = _areWeLoadingWorldSpace(iLoadWorldspace, iSavedTotalPoints,
                                                                               pSaved.getTotalCount())
                    if bWorldspace == None:  # geo count don't match but we don't want to load worldspace
                        dSkippedDeformers[sD] = 'Geo doesn\'t match (C)'
                        return [], dSkippedDeformers

                    bFoundOtherExistingDeformer = False
                    if sType == 'skinCluster':  # isn't this the same for other deformers???
                        sSkinClusters = deformers.listAllDeformers(pSaved.getName(), sFilterTypes=['skinCluster'])
                        if sSkinClusters:  # remove this?
                            if sD in sSkinClusters:
                                sSceneDeformer = sD
                                pLoadOnto = pSaved
                                bFoundOtherExistingDeformer = True

                    if not bFoundOtherExistingDeformer:
                        sSceneDeformer = deformers.createDeformer(sD, sType, pSaved.getName(), sInfluences=sInfluences,
                                                                  bAlwaysAddDefaultWeightsOnSkinCluster=bWorldspace)
                        bCreatedNewDeformer = True
                        pLoadOnto = pSaved
                    else:
                        print('already found a deformer.. ', sD, sSceneDeformer)

            else:  # deformer already exists
                pLoadOnto = patch.patchFromName(cmds.deformer(sD, q=True, g=True)[0])
                bWorldspace, iLoadWorldspacePass = _areWeLoadingWorldSpace(iLoadWorldspace, iSavedTotalPoints,
                                                                           pLoadOnto.getTotalCount())
                if bWorldspace == None:  # geo count don't match but we don't want to load worldspace
                    dSkippedDeformers[sD] = 'Geo count doesn\'t match'
                    return [], dSkippedDeformers
                sSceneDeformer = sD

        if bWorldspace == False:
            pWorldspaceGeo = None
        elif bWorldspace == True:
            sWorldspaceGeo = _recreateGeoFromFile(loadedDict, sKeyD)
            pWorldspaceGeo = patch.patchFromName(sWorldspaceGeo)
            bClosestVertex = True if iLoadWorldspacePass == patch.Worldspace.closestVertices else False
            aAllMapVerts, aAllMapCoords, _ = barycentric.getVertexCoordinates(pWorldspaceGeo, pLoadOnto,
                                                                              bClosestVertex=bClosestVertex)

        def worldspacifyOrReduceWeights(aWeightsXd):
            if bClosestVertex:
                aWeightsXd = aWeightsXd[aAllMapVerts]
            else:  # closest point
                if len(aWeightsXd.shape) == 1:
                    aWeightsXd = np.sum(aWeightsXd[aAllMapVerts] * aAllMapCoords, axis=1)
                elif len(aWeightsXd.shape) == 2:
                    aWeightsXd = np.sum(aWeightsXd[aAllMapVerts] * aAllMapCoords[..., np.newaxis], axis=1)
            return aWeightsXd

        if sType == 'skinCluster':
            if xDeformerContent.get('bJointWeights', False) == True:
                # aInfluences, aWeights2d = _extractSkinClusterFromLoadedDict(loadedDict, sD)
                if bWorldspace:
                    aWeights2d = worldspacifyOrReduceWeights(aWeights2d)
                else:
                    aWeights2d = aWeights2d[pLoadOnto.aIds]
                sJointFilter = xDeformerContent.get('sJointFilter', None)
                pLoadOnto.setSkinClusterWeights(aWeights2d, sInfluences, sJointFilter=sJointFilter,
                                                fBlend=fBlend, xDistanceMeshes=xDistanceMeshes,
                                                iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                                sChooseSkinCluster=sSceneDeformer,
                                                iCheckMissingInfluences=iCheckMissingInfluences,
                                                iJointLocks=iJointLocks, bSkipEffects=bCreatedNewDeformer,
                                                _bSkipDeformerAdjustLogging=True if (iLoadWorldspacePass == LoadWorldspace.ignore and _bNeverSkipDeformerAdjustLogging==False) else False)
            if xDeformerContent.get('bBlendWeights', False) == True:
                aBlendWeights = loadedDict['%s_blendWeights' % sKeyD]
                if bWorldspace:
                    aBlendWeights = worldspacifyOrReduceWeights(aBlendWeights)
                else:
                    aBlendWeights = aBlendWeights[pLoadOnto.aIds]
                pLoadOnto.setSkinClusterBlendWeights(aBlendWeights, fBlend=fBlend, xDistanceMeshes=xDistanceMeshes,
                                                     iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                                     sChooseSkinCluster=sSceneDeformer, _bSkipDeformerAdjustLogging=False if _bNeverSkipDeformerAdjustLogging else True)  # was True

        for sMap in xDeformerContent.get('sMaps', []):
            sSceneMap = deformers.decodeMapName(sMap, sReplaceDeformer=sSceneDeformer)
            if not sSceneMap:
                cmds.warning('skipping %s, because we can\'t find it' % sMap)
                dSkippedDeformers[sMap] = 'Can\'t find it in scene'
                return [], dSkippedDeformers
            aValuesFile = loadedDict[sMap]
            if bWorldspace: aValuesFile = worldspacifyOrReduceWeights(aValuesFile)
            pLoadOnto.setMapValues(sSceneMap, aValuesFile[pLoadOnto.aIds], _bSkipDeformerAdjustLogging=False if _bNeverSkipDeformerAdjustLogging else True) # was True
        sAttrs = xDeformerContent.get('sAttrs', [])
        if sAttrs:
            dAttrValues = dict(list(zip(loadedDict['%s_attrNames' % sKeyD], loadedDict['%s_attrValues' % sKeyD])))
            for sAttr in sAttrs:
                try:
                    cmds.setAttr('%s.%s' % (sD, sAttr), dAttrValues[sAttr])
                except:
                    cmds.warning('not able to set attribute %s.%s to %s' % (sD, sAttr, dAttrValues[sAttr]))
        if bWorldspace and not bKeepWorldspaceGeometry:
            pWorldspaceGeo.delete()

        sLoadedDeformers.append(sSceneDeformer)

        # now take care of the order
        sPostDeformers = loadedDict['%s_postDeformers' % sKeyD]
        deformers.reorderDeformer(sD, sPostDeformers[0], pLoadOnto.getName())

    return sLoadedDeformers, dSkippedDeformers


def _recreateGeoFromFile(loadedDict, sKey):
    iType = loadedDict['%s_recreateData_type' % sKey]
    aPoints = loadedDict['%s_recreateData_points' % sKey]
    mPoints = utils.listToMPointArray(aPoints)

    if iType == patch.PatchTypes.mesh:
        aPolygonCounts = loadedDict['%s_recreateData_polygonCounts' % sKey]
        aPolygonConnects = loadedDict['%s_recreateData_polygonConnects' % sKey]
        fnMesh = OpenMaya2.MFnMesh()
        fnMesh.create(mPoints, aPolygonCounts, aPolygonConnects)
        return fnMesh.partialPathName()

    elif iType == patch.PatchTypes.curve:
        aKnots = loadedDict['%s_recreateData_knots' % sKey]
        iDegree = loadedDict['%s_recreateData_degree' % sKey]
        iForm = loadedDict['%s_recreateData_form' % sKey]
        mKnots = OpenMaya2.MDoubleArray(list(aKnots))
        fnCurve = OpenMaya2.MFnNurbsCurve()
        fnCurve.create(mPoints, mKnots, iDegree, iForm, False, True)
        return fnCurve.partialPathName()

    elif iType == patch.PatchTypes.surface:
        aUKnots = loadedDict['%s_recreateData_uKnots' % sKey]
        aVKnots = loadedDict['%s_recreateData_vKnots' % sKey]
        iUDegree = loadedDict['%s_recreateData_uDegree' % sKey]
        iVDegree = loadedDict['%s_recreateData_vDegree' % sKey]
        iUForm = loadedDict['%s_recreateData_uForm' % sKey]
        iVForm = loadedDict['%s_recreateData_vForm' % sKey]

        mUKnots = OpenMaya2.MDoubleArray(list(aUKnots))
        mVKnots = OpenMaya2.MDoubleArray(list(aVKnots))

        fnSurface = OpenMaya2.MFnNurbsSurface()
        fnSurface.create(mPoints, mUKnots, mVKnots, iUDegree, iVDegree, iUForm, iVForm, True)
        return fnSurface.partialPathName()
    else:
        raise Exception('don\'t know what type: %d is.' % iType)


# dControls = {}
# dControls['xFile'] = controls.WeightFilePathControl(bUpdateFromAsset=False)


# @uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Save/Load', sRunButton='Save', dControls=dControls,
#                   tRefreshControlsAfterRun=[dControls['xFile']], bAddDefaultButton=True, bDisableOnServer=True)
def saveSkinCluster(_pSelection=None, xFile=(os.path.expanduser('~/Documents/defaultMapWeights.wts'), None),
                    bOnlySkinCluster=True):
    '''
    Select geometry and hit "Save"

    This tool hasn't been supported much and therefore may not work very stable
    '''
    sPath, _ = xFile

    sDeformers = []
    for pSelected in _pSelection or patch.getSelectedPatches():
        sDs = deformers.listAllDeformers(pSelected.getName(), sFilterTypes=['skinCluster'] if bOnlySkinCluster else [])
        sDeformers += sDs

    _saveDeformerToFile(sPath, sDeformers)



dLoadWeightmapsControls = {}
dLoadWeightmapsControls['xFile'] = controls.WeightFilePathControl(bSingleSelection=True, bOnlyMaps=True)
dLoadWeightmapsControls['iLoadMayaSelection'] = controls.RadioButtonsControl(LoadMayaSelection)
dLoadWeightmapsControls['iLoadWorldspace'] = controls.RadioButtonsControl(LoadWorldspace)
dLoadWeightmapsControls['bKeepWorldspaceGeometry'] = controls.BoolControl()
dLoadWeightmapsControls['bKeepWorldspaceGeometry'].addToControlLayout(dLoadWeightmapsControls['iLoadWorldspace'])
dLoadWeightmapsControls['iLoadWorldspace'].setControlEnabled(dLoadWeightmapsControls['bKeepWorldspaceGeometry'], [0],
                                                             False)

# this is first weightmap tool -> we'll add second tab controls
# dLoadWeightmapsControls['sMaps'] = controls.WeightmapSelector()
# dLoadWeightmapsControls['fBlend'] = controls.SliderControl([0, 1])
# dLoadWeightmapsControls['xDistanceMeshes'] = controls.DistanceMeshesControl()
# dLoadWeightmapsControls['iBorderEdges'] = controls.RadioButtonsControl(patch.BorderEdges)
# dLoadWeightmapsControls['iSmoothBorderMask'] = controls.SliderControl([1, 10])
# dLoadWeightmapsControls['iSmoothBorderMask'].addToControlLayout(dLoadWeightmapsControls['iBorderEdges'])
# dLoadWeightmapsControls['iBorderEdges'].setControlEnabled(dLoadWeightmapsControls['iSmoothBorderMask'], [0], False)
#
# sTabControls = ['fBlend', 'xDistanceMeshes', 'iBorderEdges', 'iBorderEdges', 'iSmoothBorderMask']
# sTopControls = ['sMaps']
#
# dSaveWeightmapsControls = {}
# dSaveWeightmapsControls['xFile'] = controls.WeightFilePathControl(bSingleSelection=True, bOnlyMaps=True)


# @uiSettings.addToUI(sTab='WeightMaps', sModuleButton=`Save`, sRunButton='Save', dControls=dSaveWeightmapsControls,
#                   bDisableOnServer=True,
#                   tRefreshControlsAfterRun=[dSaveWeightmapsControls['xFile'], dLoadWeightmapsControls['xFile']],
#                   bAddDefaultButton=True)
# DEPRICATED !!!!
def saveWeightmaps(_pSelection=None, xFile=(os.path.expanduser('~/Documents/defaultMapWeights.wts'), None),
                   bNoSkinCluster=True):
    '''
    Select Geometry and Save
    '''
    sPath, _ = xFile

    sDeformers = []
    for pSelected in _pSelection or patch.getSelectedPatches():
        sDs = deformers.listAllDeformers(pSelected.getName(),
                                         sIgnoreTypes=['tweak', 'skinCluster'] if bNoSkinCluster else ['tweak'])
        sDeformers += sDs

    _saveDeformerToFile(sPath, sDeformers)


# @uiSettings.addToUI(sTab='WeightMaps', sModuleButton='Load', sRunButton='Load', dControls=dLoadWeightmapsControls,
#                   tRefreshControlsAfterRun=[], sTabControls=sTabControls, sTopControls=sTopControls,
#                   bAddDefaultButton=True)
def loadWeightMapFromFile(sMaps=[], xFile=(os.path.expanduser('~/Documents/defaultMapWeights.wts'), None), fBlend=1.0,
                          xDistanceMeshes=['', 0, 0], iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                          iLoadWorldspace=LoadWorldspace.ignore, bKeepWorldspaceGeometry=False):
    '''
    Load: if you have anything selected in the Maps on right side of the UI, he'll just load Maps selected in the left side of the UI onto those (he skips attributes and order!).
    If there's nothing selected in the right side of the UI, he'll load what you have selected on the left side of the UI to whatever it was saved on.
    In both cases, if you have vertices of that mesh selected, he'll try to load onto those.
    '''

    if not sMaps:
        raise Exception('maps need to be selected. If you just want to load it to same names, go to the skinCluster loader')

    sSelectedMaps = sMaps
    sFile, sSavedMaps = xFile
    sSavedMap = sSavedMaps[0]

    # loadedDict = np.load(sFile)
    loadedDict = utils.getDictFromPickleOrNumpyFile(sFile)
    # with open(sFile, 'rb') as handle:
    #     loadedDict = pickle.load(handle)

    sMapsSplits = sSavedMap.split('.')
    sMapType = sMapsSplits[0]  # maps or jointWeights or blendWeights
    sFileDeformer = sMapsSplits[1]

    # first get values
    #
    if sMapType == 'maps':
        aValues = loadedDict['.'.join(sMapsSplits[1:])]
    elif sMapType == 'jointWeights':
        aInfluences, aWeights2d = _extractSkinClusterFromLoadedDict(loadedDict, sFileDeformer)
        sSelectedInfluence = sMapsSplits[-1]
        iSelectedInfluence = list(aInfluences).index(sSelectedInfluence)
        aValues = aWeights2d[iSelectedInfluence]
    elif sMapType == 'blendWeights':
        aValues = loadedDict['%s_blendWeights' % sFileDeformer]

    # now that we have values -> assign them to each selected map
    for sMap in sSelectedMaps:
        sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
        pLoadOnto = patch.patchFromName(sGeometry, bConsiderSelection=True)
        sDeformer = sSceneMap.split('.')[0]

        # worldspace
        #
        iSavedTotalPoints = loadedDict['%s_totalPointCount' % sFileDeformer]
        bWorldspace, iLoadWorldspacePass = _areWeLoadingWorldSpace(iLoadWorldspace, iSavedTotalPoints,
                                                                   pLoadOnto.getTotalCount())
        if bWorldspace == None:  # geo count don't match but we don't want to load worldspace
            raise Exception('vertex count between saved and geo in scene doesn\'t match (%d -> %d)' % (
            iSavedTotalPoints, pLoadOnto.getTotalCount()))
        elif bWorldspace == False:
            pWorldspaceGeo = None
        elif bWorldspace == True:
            sWorldspaceGeo = _recreateGeoFromFile(loadedDict, sFileDeformer)
            pWorldspaceGeo = patch.patchFromName(sWorldspaceGeo)

        if bWorldspace:

            bClosestVertex = True if iLoadWorldspacePass == patch.Worldspace.closestVertices else False
            aAllMapVerts, aAllMapCoords, _ = barycentric.getVertexCoordinates(pWorldspaceGeo, pLoadOnto,
                                                                              bClosestVertex=bClosestVertex)
            if bClosestVertex:
                aValues = aValues[aAllMapVerts]
            else:  # closest point
                aValues = np.sum(aValues[aAllMapVerts] * aAllMapCoords, axis=1)
            if not bKeepWorldspaceGeometry:
                pWorldspaceGeo.delete()
        else:
            aValues = aValues[pLoadOnto.aIds]
        #
        # end of worldspace

        pLoadOnto.setMapValues(sSceneMap, aValues)


def _extractSkinClusterFromLoadedDict(loadedDict, sSkinCluster):
    aWeightValues = loadedDict['%s_skinWeights' % sSkinCluster]
    aNonZero = loadedDict['%s_nonZeroWeights' % sSkinCluster]
    iWeightsCount = loadedDict['%s_weightsCount' % sSkinCluster]
    aInfluences = loadedDict['%s_influences' % sSkinCluster]
    aWeights = np.zeros(iWeightsCount, dtype='float64')
    aWeights[aNonZero] = aWeightValues
    aWeights2d = aWeights.reshape(-1, len(aInfluences))
    return aInfluences, aWeights2d


# =================
# Flood
# =================

class FloodSkinClusterOperation():
    replaceClosest = 0
    addClosest = 1
    replaceAll = 2
    addAll = 3
    subractAll = 4
    scaleAll = 6
    distributeWeights = 12
    # bindToClosestVertexAndExpand = 15


class FloodWeightMapsOperation():
    replace = 0
    add = 1
    subtract = 4
    scale = 6
    invert = 10
    replaceAbsolute = 11


class JointLines():
    No = 0
    Yes = 1
    YesAndIncludeChildrenNotInInputForClosestJoints = 2


dControls = {}
dControls['sFolder'] = controls.FolderPathControl(sSubFolder='deformers', bReadOnly=True)
dControls['iLoadWorldspace'] = controls.RadioButtonsControl(LoadWorldspace)
dControls['iJointLines'] = controls.RadioButtonsControl(JointLines)
dControls['bKeepWorldspaceGeometry'] = controls.BoolControl()
dControls['bKeepWorldspaceGeometry'].addToControlLayout(dControls['iLoadWorldspace'])
dControls['iLoadWorldspace'].setControlEnabled(dControls['bKeepWorldspaceGeometry'], [0], False)

# it is first SkinCluster tool we are declaring -> add the tab things
skinClusterChooseControl = controls.SelectionControl(bList=False)
dControls['sChooseSkinCluster'] = skinClusterChooseControl
# dControls['fBlend'] = controls.SliderControl([0, 1])
dControls['iCheckMissingInfluences'] = controls.RadioButtonsControl(patch.MissingInfluencesOptions)
dControls['iJointLocks'] = controls.RadioButtonsControl(patch.JointLocks)
dControls['xDistanceMeshes'] = controls.DistanceMeshesControl()
dControls['iBorderEdges'] = controls.RadioButtonsControl(patch.BorderEdges)
dControls['iSmoothBorderMask'] = controls.SliderControl([1, 10])
dControls['iSmoothBorderMask'].addToControlLayout(dControls['iBorderEdges'])
dControls['iBorderEdges'].setControlEnabled(dControls['iSmoothBorderMask'], [0], False)
dControls['sSphereMasks'] = controls.SphereMasksControl()
dControls['xClosestToCurve'] = controls.ClosestToCurveControl()
dControls['sJoints'] = controls.JointsSelector(chooseControl=skinClusterChooseControl)
dControls['iOperation'] = controls.RadioButtonsControl(FloodSkinClusterOperation, bGroupBox=False, iColumns=2)
dControls['iSmoothSteps'] = controls.SliderControl([0, 10])
dControls['iOperation'].setControlEnabled(dControls['iSmoothSteps'],
                                          [FloodSkinClusterOperation.replaceClosest,
                                           FloodSkinClusterOperation.addClosest,
                                           FloodSkinClusterOperation.distributeWeights], True)
# dControls['iExpandedFullWeightLoops'] = controls.SliderControl([0, 20])
# dControls['iExpandedFadeOutLoops'] = controls.SliderControl([0, 20])
# dControls['iOperation'].setControlEnabled(dControls['iExpandedFullWeightLoops'],
#                                           [FloodSkinClusterOperation.bindToClosestVertexAndExpand], True)
# dControls['iOperation'].setControlEnabled(dControls['iExpandedFadeOutLoops'],
#                                           [FloodSkinClusterOperation.bindToClosestVertexAndExpand], True)

sTabControls = ['iJointLocks', 'iCheckMissingInfluences', 'xDistanceMeshes', 'iBorderEdges',
                'iSmoothBorderMask', 'xClosestToCurve', 'sSphereMasks']
sTopControls = ['sChooseSkinCluster']



def getSkinClusterCompleterStrings(bIncludeSuffixes=False):
    sStrings = []
    sDoneMeshes = set()
    for sObj in cmds.ls(sl=True):
        sMesh = sObj.split('.')[0]
        if sMesh in sDoneMeshes:
            continue
        else:
            sSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
            sStrings.extend(sSkinClusters)
            if bIncludeSuffixes:
                for sSkinCluster in sSkinClusters:
                    if sSkinCluster.count('__') == 2:
                        sStrings.append('__%s' % sSkinCluster.split('__')[-1])
        sDoneMeshes.add(sMesh)
    return sStrings


dControls = {}
dControls['sFolder'] = controls.FolderPathControl(sSubFolder='deformers', bReadOnly=True)
dControls['iLoadWorldspace'] = controls.RadioButtonsControl(LoadWorldspace)
dControls['iJointLines'] = controls.RadioButtonsControl(JointLines)
dControls['bKeepWorldspaceGeometry'] = controls.BoolControl()
dControls['bKeepWorldspaceGeometry'].addToControlLayout(dControls['iLoadWorldspace'])
dControls['iLoadWorldspace'].setControlEnabled(dControls['bKeepWorldspaceGeometry'], [0], False)

# it is first SkinCluster tool we are declaring -> add the tab things
skinClusterChooseControl = controls.SelectionControl(bList=False, funcGetCompleterStrings=lambda:getSkinClusterCompleterStrings(bIncludeSuffixes=True))
dControls['sChooseSkinCluster'] = skinClusterChooseControl
# dControls['fBlend'] = controls.SliderControl([0, 1])
dControls['iCheckMissingInfluences'] = controls.RadioButtonsControl(patch.MissingInfluencesOptions)
dControls['iJointLocks'] = controls.RadioButtonsControl(patch.JointLocks)
dControls['xDistanceMeshes'] = controls.DistanceMeshesControl()
dControls['iBorderEdges'] = controls.RadioButtonsControl(patch.BorderEdges)
dControls['iSmoothBorderMask'] = controls.SliderControl([1, 10])
dControls['iSmoothBorderMask'].addToControlLayout(dControls['iBorderEdges'])
dControls['iBorderEdges'].setControlEnabled(dControls['iSmoothBorderMask'], [0], False)
dControls['sSphereMasks'] = controls.SphereMasksControl()
dControls['xClosestToCurve'] = controls.ClosestToCurveControl()
dControls['sJoints'] = controls.JointsSelector(chooseControl=skinClusterChooseControl)
dControls['iOperation'] = controls.RadioButtonsControl(FloodSkinClusterOperation, bGroupBox=False, iColumns=2)
dControls['iSmoothSteps'] = controls.SliderControl([0, 10])
# dControls['iOperation'].setControlEnabled(dControls['iSmoothSteps'],
#                                           [FloodSkinClusterOperation.replaceClosest,
#                                            FloodSkinClusterOperation.addClosest,
#                                            FloodSkinClusterOperation.distributeWeights], True)
# dControls['iExpandedFullWeightLoops'] = controls.SliderControl([0, 20])
# dControls['iExpandedFadeOutLoops'] = controls.SliderControl([0, 20])
# dControls['iOperation'].setControlEnabled(dControls['iExpandedFullWeightLoops'],
#                                           [FloodSkinClusterOperation.bindToClosestVertexAndExpand], True)
# dControls['iOperation'].setControlEnabled(dControls['iExpandedFadeOutLoops'],
#                                           [FloodSkinClusterOperation.bindToClosestVertexAndExpand], True)

@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Flood', sRunButton='Flood', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sTabControls=sTabControls, sTopControls=sTopControls, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#flood')
def floodSkinCluster(_pSelection=None, fValue=1.0, sJoints=[], iOperation=FloodSkinClusterOperation.replaceClosest,
                     iSmoothSteps=4, fBlend=1.0, xClosestToCurve=None,
                     iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                     iJointLocks=patch.JointLocks.ignore,
                     xDistanceMeshes=None, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=1,
                     # iExpandedFullWeightLoops=1, iExpandedFadeOutLoops=3,
                     sSphereMasks=[], sChooseSkinCluster=None, iJointLines=JointLines.YesAndIncludeChildrenNotInInputForClosestJoints, bProjectSquashToMainJoints=True, bDisableIslandCheck=False):
    '''
    This works similar like maya flood button, except that it also takes soft selection into account and you can flood more than one influence at the same time.
    "Closest" means that for every vertex or CV he'll look for the closest joint and uses that, while "All" means that he'll set the value to all joints selected.
    If you only have one joint selected, there is no difference between the two
    '''

    patch.iMissingInfluencesForNext = None
    cmds.undoInfo(openChunk=True)
    try:

        sJoints = utils.toList(sJoints)

        if iOperation == FloodSkinClusterOperation.distributeWeights:
            xJoints = {sJ: '; '.join(sJoints) for sJ in sJoints}
            moveSkinClusterWeights(_pSelection=_pSelection, xJoints=xJoints, iSmoothSteps=iSmoothSteps,
                                   xDistanceMeshes=xDistanceMeshes, iJointLocks=iJointLocks,
                                   iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask, fBlend=fBlend, iJointLines=iJointLines,
                                   _bResetSettings=False, sChooseSkinCluster=sChooseSkinCluster)
            return

        # if iOperation == FloodSkinClusterOperation.bindToClosestVertexAndExpand:
        #     bindToClosestVertexAndExpand(_pSelection=_pSelection, sJoints=sJoints,
        #                                  iExpandedFullWeightLoops=iExpandedFullWeightLoops,
        #                                  iExpandedFadeOutLoops=iExpandedFadeOutLoops,
        #                                  xDistanceMeshes=xDistanceMeshes, iBorderEdges=iBorderEdges,
        #                                  iSmoothBorderMask=iSmoothBorderMask,
        #                                  fBlend=fBlend, iJointLocks=iJointLocks,
        #                                  iCheckMissingInfluences=iCheckMissingInfluences,
        #                                  sChooseSkinCluster=sChooseSkinCluster)
        #     return

        for pSelected in _translateInput(_pSelection):
            if not bDisableIslandCheck:
                if len(pSelected.aIds) != pSelected.getTotalCount():
                    if len(pSelected.getIslands(bFullObject=False)) > 1:
                        if cmds.confirmDialog(m='There are more than one islands selected on %s. Continue?' % pSelected.getTransformName(),
                                              button=['yes', 'no']) == 'no':
                            continue

            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())
            sSkinCluster, sInfluences, aWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
            aWeights2dOld = np.copy(aWeights2d)
            if not sSkinCluster:
                raise Exception('there is no skinCluster on %s.' % pSelected.getTransformName())
            iCheckInfluencesResult = pSelected.checkInfluences(sJoints, iCheckMissingInfluences=iCheckMissingInfluences,
                                                               sChooseSkinCluster=sConvertedChooseSkinCluster)
            if iCheckInfluencesResult == patch.CheckInfluencesResult.influencesStillMissing:
                continue
            elif iCheckInfluencesResult == patch.CheckInfluencesResult.addedInfluences:
                sSkinCluster, sInfluences, aWeights2d = pSelected.getSkinCluster(
                    sChooseSkinCluster=sConvertedChooseSkinCluster)
                aWeights2dOld = np.copy(aWeights2d)

            dInfDict = dict(list(zip(sInfluences, range(len(sInfluences)))))
            aJoints = np.array([dInfDict[sJ] for sJ in sJoints], dtype=int)
            aOtherJoints = np.delete(np.arange(len(sInfluences)), aJoints)

            if isinstance(fValue, np.ndarray):
                aValues = fValue
            else:
                aValues = np.empty(aJoints.size, dtype='float64')
                aValues.fill(fValue)

            # aSetWeights is the value for each vertex and each joint (will have lots of repeated values in bsaic cases)
            aSetWeights = np.zeros((len(pSelected.aIds), aJoints.size), dtype='float64')
            if aJoints.size == 1:
                aSetWeights[:, :] = aValues
            elif aJoints.size > 1:
                # assign to closest
                if iOperation in [FloodSkinClusterOperation.replaceClosest, FloodSkinClusterOperation.addClosest]:
                    iClosestJoints = xforms.findClosestJointsToPatchComponents(pSelected,
                                                                               [sInfluences[j] for j in aJoints], bJointLines=iJointLines > 0,
                                                                               sProjectAttrs=['skinParent'] if bProjectSquashToMainJoints else [],
                                                                               bIncludeChildrenNotInInputJoints=iJointLines==JointLines.YesAndIncludeChildrenNotInInputForClosestJoints)
                    for i in range(aJoints.size):
                        aClosestVertsForJoint = np.array(np.where(iClosestJoints == i)[0], dtype=int)
                        aSetWeights[aClosestVertsForJoint, i] = aValues[i]
                else:  # all (evenly)
                    for i in range(aJoints.size):
                        aSetWeights[:, i] = aValues[i] / float(len(sJoints))

                # smooth and normalize back
                if iSmoothSteps > 0:
                    aSumBefore = np.sum(aSetWeights, axis=1)
                    aSetWeights = pSelected.smoothValues2d(aSetWeights, iIterations=iSmoothSteps)
                    aSumAfter = np.sum(aSetWeights, axis=1)
                    aZeros = np.where(aSumAfter == 0)[0]
                    aSumAfter[aZeros] = 1
                    aSetWeights *= aSumBefore[:, np.newaxis] / aSumAfter[:, np.newaxis]
            # print 'aWeights2d 2: ', aWeights2d

            # setting the weights: ['replace', 'add','subtract', 'scale', 'invert']
            #
            if iOperation in [FloodSkinClusterOperation.replaceClosest, FloodSkinClusterOperation.replaceAll]:
                aWeights2d[:, aJoints] = aSetWeights
            elif iOperation in [FloodSkinClusterOperation.addClosest, FloodSkinClusterOperation.addAll]:
                aSetWeightsSum = np.sum(aSetWeights, axis=-1)
                aSetWeightsDenom = 1 / np.where(aSetWeightsSum > 1.0, aSetWeightsSum, 1.0)
                aSetWeights *= aSetWeightsDenom[:, np.newaxis]
                aFreeSum = 1 - np.sum(aWeights2d[:, aJoints], axis=-1)
                aWeights2d[:, aJoints] += aSetWeights * aFreeSum[:, np.newaxis]
            # elif iOperation == FloodSkinClusterOperation.subtractAll:
            #     aWeights2d[:,aJoints] = np.maximum(0, aWeights2d[:,aJoints] - aSetWeights)
            elif iOperation == FloodSkinClusterOperation.scaleAll:
                aWeights2d[:, aJoints] = aWeights2d[:, aJoints] * aSetWeights
                aNewSum = np.sum(aWeights2d[:, aJoints], axis=-1)
                aWeightsDenom = np.where(aNewSum > 1.0, aNewSum, 1.0)
                aWeightsDenom[aWeightsDenom < 0.000001] = 1
                aWeights2d[:, aJoints] /= aWeightsDenom[:, np.newaxis]

            # shrinking the weights of other influences
            #
            if isinstance(fValue, (float,int)) and fValue == 1.0:
                aWeights2d[:, aOtherJoints] = 0
            else:
                aSumsJoints = np.sum(aWeights2d[:, aJoints], axis=1)[:, np.newaxis]
                aFullSetIds = np.where(aSumsJoints > 0.999999)[0]
                aSumsJoints[aFullSetIds] = 0
                aSumsOthers = np.sum(aWeights2d[:, aOtherJoints], axis=1)[:, np.newaxis]
                aSumsOthers[aSumsOthers < 0.00001] = 1
                aWeights2d[:, aOtherJoints] *= (1 - aSumsJoints) / aSumsOthers
                aWeights2d[aFullSetIds[:, np.newaxis], aOtherJoints] = 0

            # back to skinCluster
            #
            pSelected.setSkinClusterWeights(aWeights2d, sInfluences=sInfluences, aOldWeights2d=aWeights2dOld,
                                            xDistanceMeshes=xDistanceMeshes, iBorderEdges=iBorderEdges,
                                            sChooseSkinCluster=sConvertedChooseSkinCluster,
                                            iSmoothBorderMask=iSmoothBorderMask, iJointLocks=iJointLocks,
                                            xClosestToCurve=xClosestToCurve, sSphereMasks=sSphereMasks)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)
        patch.iMissingInfluencesForNext = None





dControls = {}
dControls['sJoints'] = controls.JointsSelector(chooseControl=skinClusterChooseControl)
dControls['iExpandedFullWeightLoops'] = controls.SliderControl([0, 20])
dControls['iExpandedFadeOutLoops'] = controls.SliderControl([0, 20])
@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='ClosestExpand', sRunButton='Bind', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sTabControls=sTabControls, sTopControls=sTopControls, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#closestexpand')
def bindToClosestVertexAndExpand(_pSelection=None, sJoints=[], _fJointWeightings=[], xDistanceMeshes=None,
                                 iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=1, fBlend=1.0,
                                 iJointLocks=patch.JointLocks.ignore,
                                 iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                                 iExpandedFullWeightLoops=1, iExpandedFadeOutLoops=3,
                                 sChooseSkinCluster=None, iMaxConnectionPathCount=2, bDistribute=False, _sDistributeJoints=None):
    try:

        for pSelected in _pSelection or patch.getSelectedPatches():
            cmds.undoInfo(openChunk=True)
            sSelBefore = cmds.ls(sl=True)
            iTotalCount = pSelected.getTotalCount()
            pFullMesh = patch.patchFromName(pSelected.getTransformName())
            iiNeighbors = pFullMesh.getNeighbors()

            sPositionJoints = []
            for sJ in sJoints:
                sSkinParentAttr = '%s.skinParent' % sJ
                if cmds.objExists(sSkinParentAttr):
                    sPositionJoints.append(cmds.getAttr(sSkinParentAttr))
                else:
                    sPositionJoints.append(sJ)
            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())

            sTempCurve = cmds.curve(p=xforms.getPositionArray(sPositionJoints))

            if not len(_fJointWeightings):
                _fJointWeightings = [1.0] * len(sJoints)

            fMaxJointWeighting = np.max(_fJointWeightings)
            iMaxJointWeighting = 1 if fMaxJointWeighting < 1.0 else int(math.ceil(fMaxJointWeighting))

            aClosest = np.array(cmds.kt_findClosestPoints(fromMesh=sTempCurve, toMesh=pSelected.getTransformName(), vertex=True), dtype=int)
            cmds.delete(sTempCurve)

            sStartJoints = list(sJoints)
            dRowJointInds = {sJ:[j] for j,sJ in enumerate(sJoints)}
            for sJ in sStartJoints:
                sRowJointsAttr = '%s.sRowJoints' % sJ
                if cmds.objExists(sRowJointsAttr):
                    sRowJoints = eval(cmds.getAttr(sRowJointsAttr))
                    for sRowJ in sRowJoints:
                        iNewInd = len(sJoints)
                        sJoints.append(sRowJ)
                        dRowJointInds[sJ].append(iNewInd)
            dRowJointInds = {sJ:np.array(iInds, dtype=int) for sJ,iInds in dRowJointInds.items()}

            aWeights2d = np.zeros((iTotalCount, len(sJoints)), dtype='float64')
            aWeights2d[aClosest,:len(aClosest)] = np.diag(np.ones(len(aClosest), dtype='float64'))

            dRowWeights = {}
            for sJ in sStartJoints:
                aaRowWeights = []
                aRowJoints = dRowJointInds[sJ]
                for iRowJ in aRowJoints:
                    aRowWeights = np.zeros(len(sJoints), dtype='float64')
                    aRowWeights[iRowJ] = 1.0
                    aaRowWeights.append(aRowWeights)
                dRowWeights[sJ] = aaRowWeights

            if bDistribute:
                iExpandedFullWeightLoops += iExpandedFadeOutLoops + 5
                iExpandedFadeOutLoops = 1

            aWeightingDefault = np.concatenate([np.ones(iExpandedFullWeightLoops, dtype='float64'), utils.bSpline4([1, 1, 0, 0], iCount=iExpandedFadeOutLoops + 2)[1:-1]])

            iIdsMapper = utils.getIdsToIndicesMapper(aClosest)


            iiFound2Ids = [[] for _ in range(len(aClosest))]

            xIdsOnPath = []
            for i,iId in enumerate(aClosest):
                if len(iiFound2Ids[i]) >= 2:
                    continue
                iTos = list(aClosest)
                iTos.remove(iId)
                for iF in iiFound2Ids[i]:
                    iTos.remove(iF)

                for m in range(2-len(iiFound2Ids[i])):
                    iPath = barycentric.findShortestPath(iiNeighbors, iId, iTos, iStopperIds=iiFound2Ids[i], iInbetweenMaxCount=iMaxConnectionPathCount)
                    if iPath:
                        iPathEndId = iPath[-1]
                        iPathEndIndex = iIdsMapper[iPathEndId]
                        iiFound2Ids[i].append(iPathEndId)
                        iiFound2Ids[iPathEndIndex].append(iId)
                        iTos.remove(iPathEndId)
                        for p, iPathId in enumerate(iPath[1:-1]):
                            fT = (p+1) / (len(iPath)-1)
                            xIdsOnPath.append([iPathId, iPath[0], iPath[-1], fT])

            for i, xId in enumerate(xIdsOnPath):
                iId, iStartId, iEndId, fT = xId
                aWeights2d[iId] = aWeights2d[iStartId] * (1.0-fT) + aWeights2d[iEndId] * fT

            aStartIds = np.concatenate([aClosest, np.array([xId[0] for xId in xIdsOnPath], dtype=int)])
            aaWeightings = np.zeros((len(aStartIds), len(aWeightingDefault) * iMaxJointWeighting), dtype='float64')
            if not len(_fJointWeightings):
                aaWeightings[:] = aWeightingDefault
            else:
                if len(_fJointWeightings) != len(sStartJoints):
                    raise Exception('_fJointWeightings needs to have same length as sJoints')
                iOldLength = len(aWeightingDefault)
                for j, fW in enumerate(_fJointWeightings):
                    fNewLength = iOldLength * fW
                    iNewLength = int(math.ceil(fNewLength))
                    fCompressedRange = np.interp(np.arange(iOldLength), [0, iOldLength - 1], [0, fNewLength])
                    aMappedWeightings = np.interp(range(iNewLength), fCompressedRange, aWeightingDefault)
                    aaWeightings[j, np.arange(len(aMappedWeightings), dtype=int)] = aMappedWeightings

                for i, xId in enumerate(xIdsOnPath):
                    iId, iStartId, iEndId, fT = xId
                    aaWeightings[len(_fJointWeightings) + i] = aaWeightings[iIdsMapper[iStartId]] * (1.0-fT) + aaWeightings[iIdsMapper[iEndId]] * fT

            iMaxWeightingsCount = len(aWeightingDefault) * iMaxJointWeighting

            aFilledFromIteration = np.empty(iTotalCount, dtype=int)
            aFilledFromIteration.fill(-1)

            aTheFirstIds = np.zeros(iTotalCount, dtype=bool)
            aTheFirstIds[aStartIds] = True

            aCameFrom = np.empty(iTotalCount, dtype=int)
            aCameFrom.fill(-1)
            aCameFrom[aStartIds] = np.arange(len(aStartIds))

            aWeightValues = np.zeros(iTotalCount, dtype='float64')
            aWeightValues[aStartIds] = 1.0

            iLastReached = list(aStartIds)
            for w in range(iMaxWeightingsCount):
                iReached = set()

                # aPrevWeightsForExpanding2d is so it interpolates it between the additional row joint sets
                aPrevWeightsForExpanding2d = np.copy(aWeights2d)
                for sJ, aInds in dRowJointInds.items():
                    aColumnSums = np.sum(aPrevWeightsForExpanding2d[:, aInds], axis=-1)
                    aPrevWeightsForExpanding2d[:, aInds] = 0.0
                    aInterpolatedWeights = utils.multiDimensionInterp(w / (iMaxWeightingsCount-1),  np.arange(len(aInds)) / (len(aInds)-1), dRowWeights[sJ])
                    aPrevWeightsForExpanding2d += aInterpolatedWeights * aColumnSums[:, np.newaxis]

                for k, iNonzero in enumerate(iLastReached):
                    for n, iNb in enumerate(iiNeighbors[iNonzero]):
                        if aTheFirstIds[iNb] == True:
                            continue
                        if aFilledFromIteration[iNb] == -1 or aFilledFromIteration[iNb] == w:
                            aCameFrom[iNb] = aCameFrom[iNonzero]
                            aWeights2d[iNb] += aPrevWeightsForExpanding2d[iNonzero]
                            aWeightValues[iNb] = max(aWeightValues[iNb], aaWeightings[aCameFrom[iNonzero], w])
                            aFilledFromIteration[iNb] = w
                            iReached.add(iNb)

                aSums = np.sum(aWeights2d, axis=1)
                aSums[aSums == 0] = 1.0
                aWeights2d /= aSums[:, np.newaxis]
                iLastReached = list(iReached)

            if bDistribute:
                _, sCurrentInfluences, aCurrentWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
                aSetWeights2d = np.copy(aCurrentWeights2d)
                aStrenghtesPerVert = np.zeros(len(pSelected.aIds), dtype='float64')
                iExistingJoints = []
                iJoints = []

                if utils.isNone(_sDistributeJoints):
                    _sDistributeJoints = sJoints

                for j,sJ in enumerate(_sDistributeJoints):
                    if sJ in sCurrentInfluences:
                        iJoint = sCurrentInfluences.index(sJ)
                        aStrenghtesPerVert += aCurrentWeights2d[:,iJoint]
                        iExistingJoints.append(iJoint)
                        iJoints.append(sJoints.index(sJ) if sJ in sJoints else -1)

                aReducedWeights2d = aWeights2d[pSelected.aIds]
                aReducedWeights2d *= aStrenghtesPerVert[:,np.newaxis]

                aReducedWeightsPlusOne2d = np.zeros((len(aReducedWeights2d), len(sJoints)+1), dtype='float64')
                aReducedWeightsPlusOne2d[:,:-1] = aReducedWeights2d

                aSetWeights2d[:,np.array(iExistingJoints, int)] = aReducedWeightsPlusOne2d[:,np.array(iJoints, int)]
                sSetJoints = sCurrentInfluences
            else:
                aWeights2d *= aWeightValues[:, np.newaxis]
                aSetWeights2d = aWeights2d[pSelected.aIds]
                sSetJoints = sJoints


            aNonZero = np.where(np.sum(aSetWeights2d, axis=1) > 0.001)[0]
            aSetWeights2d = aSetWeights2d[aNonZero]
            pSelected.aIds = pSelected.aIds[aNonZero]
            if not utils.isNone(pSelected.aSofts):
                pSelected.aSofts = pSelected.aSofts[aNonZero]

            pSelected.setSkinClusterWeights(aSetWeights2d, sInfluences=sSetJoints, xDistanceMeshes=xDistanceMeshes,
                                            iJointLocks=iJointLocks, bAddToCurrent=True,
                                            sChooseSkinCluster=sConvertedChooseSkinCluster,
                                            iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask, fBlend=fBlend,
                                            iCheckMissingInfluences=iCheckMissingInfluences)
    except:
        raise
    finally:
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)

# =================
# Smooth
# =================

def _translateInput(xInput):
    if isinstance(xInput, type(None)):
        return patch.getSelectedPatches()
    else:
        xInputList = utils.toList(xInput)
        for i in range(len(xInputList)):
            if utils.isStringOrUnicode(xInputList[i]):
                xInputList[i] = patch.patchFromName(xInputList[i])
        return xInputList

dControls = {}
dControls['sLoopCurve'] = controls.SelectionControl(bList=False)

@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Smooth', sRunButton='Smooth', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#smooth')
def smoothSkinWeights(_pSelection=None, iIterations=4, fBlend=1.0, iJointLocks=patch.JointLocks.ignore,
                      bKeepValueOne=False, xDistanceMeshes=None, sChooseSkinCluster=None,
                      iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2, bBarycentricWeighted=False,
                      fRigid=0.0, sLoopCurve=None, _bSkipDeformerAdjustLogging=False, bLogReport=True):
    # _validateChooseSkinCluster(sChooseSkinCluster)

    if fRigid > 0.0:
        fPower = 1.0 + fRigid * 0.25

    if sLoopCurve:
        if isinstance(sLoopCurve, str) and not cmds.objExists(sLoopCurve):
            raise Exception('Loop Curve "%s" doesn\'t exist' % sLoopCurve)

    for pSelected in _translateInput(_pSelection):

        if bLogReport: report.report.resetProgress(iIterations + 2)

        aNbsArray, aIdsWithNeighbors, aMap_indsWithNeighbors_to_inds, aNeighborSizesDenoms2d = \
            pSelected.getNeighborDataForSmoothing(bBarycentricWeighted=bBarycentricWeighted, sLoopCurve=sLoopCurve)

        sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())
        _, sInfluences, aWeights2d = pSelected.getSkinCluster(aOverrideIds=aIdsWithNeighbors,
                                                              sChooseSkinCluster=sConvertedChooseSkinCluster)

        iInfCount = len(sInfluences)

        aWeights2d = np.concatenate([aWeights2d, np.zeros((1, iInfCount), dtype='float64')])
        aOldWeights2d = np.copy(aWeights2d)
        if bKeepValueOne:
            aOneInds = np.where(aWeights2d > 0.9999)[0]

        if iJointLocks != patch.JointLocks.ignore:
            iLocks = [cmds.getAttr('%s.liw' % sI) for sI in sInfluences]
            aLockedBool = np.array(iLocks, dtype=bool)
            aLockedJoints = np.arange(len(sInfluences))[aLockedBool]
            aFreeJoints = np.arange(len(sInfluences))[~aLockedBool]

        if bLogReport: report.report.incrementProgress(bRefresh=True)


        # if iMaxInfluences > 0 and iMaxInfluences >= iInfCount:
        #     iMaxInfluences = -1

        for iteration in range(iIterations):
            if bLogReport: report.report.incrementProgress(bRefresh=False)

            aMultipls = aWeights2d[aNbsArray] * aNeighborSizesDenoms2d[..., np.newaxis]
            if fRigid > 0.0:
                aMultipls = np.power(aMultipls, fPower)
            aWeights2d[aMap_indsWithNeighbors_to_inds] = np.sum(aMultipls, axis=-2)

            if fRigid > 0.0:
                aSums = np.sum(aWeights2d, axis=-1)
                aSums[aSums < 0.00001] = 1
                aSumsDenom = 1.0 / aSums
                aWeights2d *= aSumsDenom[..., np.newaxis]

            if bKeepValueOne:
                aWeights2d[aOneInds] = aOldWeights2d[aOneInds]

            if iJointLocks != patch.JointLocks.ignore:
                aWeights2d = patch._applyJointLocks(aLockedJoints, aFreeJoints, aWeights2d, aOldWeights2d,
                                                    iMode=iJointLocks)

            # if iMaxInfluences > 0:
            #     aRemoveInfluences2d = np.argsort(aWeights2d, axis=1)[:,np.arange(iInfCount-iMaxInfluences)]
            #     aWeights2d[np.arange(len(aWeights2d))[:,np.newaxis], aRemoveInfluences2d] = 0.0
            #     aNewSums = np.sum(aWeights2d, axis=1)
            #     aWeights2d /= aNewSums[:,np.newaxis]


        if bLogReport: report.report.incrementProgress(bRefresh=True)

        aWeights2d_isolated = aWeights2d[aMap_indsWithNeighbors_to_inds]
        aOldWeights2d_isolated = aOldWeights2d[aMap_indsWithNeighbors_to_inds]
        pSelected.setSkinClusterWeights(aWeights2d_isolated, aOldWeights2d=aOldWeights2d_isolated,
                                        xDistanceMeshes=xDistanceMeshes,
                                        iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask, fBlend=fBlend,
                                        sChooseSkinCluster=sConvertedChooseSkinCluster, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)


dControls = {}
dControls['iOperation'] = controls.RadioButtonsControl(FloodWeightMapsOperation, bGroupBox=False, iColumns=2)
dControls['iJointLines'] = controls.RadioButtonsControl(JointLines)
dControls['fValue'] = controls.SliderControl([0, 1])
dControls['iOperation'].setControlEnabled(dControls['fValue'], [FloodWeightMapsOperation.invert], False)
dControls['sMaps'] = controls.WeightmapSelector()

# this is first weightmap tool -> we'll add second tab controls
dControls['sMaps'] = controls.WeightmapSelector()
dControls['fBlend'] = controls.SliderControl([0, 1])
dControls['xDistanceMeshes'] = controls.DistanceMeshesControl()
dControls['iBorderEdges'] = controls.RadioButtonsControl(patch.BorderEdges)
dControls['iSmoothBorderMask'] = controls.SliderControl([1, 10])
dControls['iSmoothBorderMask'].addToControlLayout(dControls['iBorderEdges'])
dControls['iBorderEdges'].setControlEnabled(dControls['iSmoothBorderMask'], [0], False)

sTabControls = ['fBlend', 'xDistanceMeshes', 'iBorderEdges', 'iBorderEdges', 'iSmoothBorderMask']
sTopControls = ['sMaps']

dSaveWeightmapsControls = {}
dSaveWeightmapsControls['xFile'] = controls.WeightFilePathControl(bSingleSelection=True, bOnlyMaps=True)


@uiSettings.addToUI(sTab='WeightMaps', sModuleButton='Flood', sRunButton='Flood', tRefreshControlsAfterRun=[], sTabControls=sTabControls,
                  dControls=dControls, bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsWeightmaps/')
def floodWeightMaps(sMaps=[], fValue=1.0, iOperation=FloodWeightMapsOperation.replace, fBlend=1.0, xDistanceMeshes=None,
                    iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2):
    '''
    simply sets all the selected vertices' map values to the
    value you specify. "Replace Absolute" means that he sets
    everything to zero (black) first.
    '''
    utils.reload2(patch)
    sMaps = utils.toList(sMaps)
    for sMap in sMaps:
        sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
        tbPatch = patch.patchFromName(sGeometry, bConsiderSelection=True)

        if iOperation == FloodWeightMapsOperation.replaceAbsolute:
            tbPatch.resetAllMapValues(sSceneMap, 0.0)
            aValues = np.zeros(tbPatch.aIds.size, dtype='float64')
            aValues.fill(fValue)
        else:
            aValues = tbPatch.getMapValues(sSceneMap)

            if iOperation == FloodWeightMapsOperation.invert:
                aValues = 1 - aValues
            if iOperation == FloodWeightMapsOperation.replace:
                aValues[:] = fValue
            elif iOperation == FloodWeightMapsOperation.add:
                aValues[:] = np.minimum(1, aValues + fValue)
            elif iOperation == FloodWeightMapsOperation.subtract:
                aValues[:] = np.maximum(0, aValues - fValue)
            elif iOperation == FloodWeightMapsOperation.scale:
                aValues[:] = np.minimum(1, aValues * fValue)


        tbPatch.setMapValues(sSceneMap, aValues, fBlend=fBlend, iBorderEdges=iBorderEdges,
                             iSmoothBorderMask=iSmoothBorderMask, xDistanceMeshes=xDistanceMeshes)


dControls = {}
dControls['sMaps'] = controls.WeightmapSelector()


@uiSettings.addToUI(sTab='WeightMaps', sModuleButton='Smooth', sRunButton='Smooth', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsWeightmaps/')
def smoothWeightMaps(sMaps=[], iIterations=4, bKeepValueOne=False, bKeepValueZero=False, xDistanceMeshes=None,
                     iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2, bBarycentricWeighted=False):
    for sMap in sMaps:
        sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
        tbPatch = patch.patchFromName(sGeometry, bConsiderSelection=True)

        aNbsArray, aIdsWithNeighbors, aMap_indsWithNeighbors_to_inds, aNeighborSizesDenoms2d = \
            tbPatch.getNeighborDataForSmoothing(bBarycentricWeighted=bBarycentricWeighted)

        aValues = tbPatch.getMapValues(sSceneMap, aOverrideIds=aIdsWithNeighbors)
        aValues = np.append(aValues, 0)
        aValuesOld = np.copy(aValues)

        if bKeepValueOne:
            aOneInds = np.where(aValues > 0.9999)[0]
        if bKeepValueZero:
            aZeroInds = np.where(aValues > 0.0001)[0]

        for iteration in range(iIterations):
            aMultipls = aValues[aNbsArray] * aNeighborSizesDenoms2d
            aSum = np.sum(aMultipls, axis=1)
            aValues[aMap_indsWithNeighbors_to_inds] = aSum

            if bKeepValueOne:
                aValues[aOneInds] = aValuesOld[aOneInds]
            if bKeepValueZero:
                aValues[aZeroInds] = aValuesOld[aZeroInds]

        aValues_isolated = aValues[aMap_indsWithNeighbors_to_inds]
        # aValuesOld_isolated = aValuesOld[aMap_indsWithNeighbors_to_inds]
        tbPatch.setMapValues(sSceneMap, aValues_isolated, xDistanceMeshes=xDistanceMeshes, iBorderEdges=iBorderEdges,
                             iSmoothBorderMask=iSmoothBorderMask)


# =================
# Average
# =================

class CalculateAverageMode():
    onlyFullSelectedVertices = 0
    fullAndSoftSelectedVertices = 1
    fullAndSoftSelectedVerticesWeighted = 2


class SeparateIslands():
    IgnoreIslands = 0
    AverageEachIslandSeparately = 1
    AverageEachIslandSeparatelyButIgnoreBiggestIsland = 2


dControls = {}
dControls['iSeparateIslands'] = controls.RadioButtonsControl(SeparateIslands)
dControls['iCalculateAverageMode'] = controls.RadioButtonsControl(CalculateAverageMode)


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Average', sRunButton='Average', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#average')
def averageSkinCluster(_pSelection=None, iSeparateIslands=SeparateIslands.IgnoreIslands,
                       iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                       iCalculateAverageMode=CalculateAverageMode.fullAndSoftSelectedVerticesWeighted, fBlend=1.0,
                       iJointLocks=patch.JointLocks.ignore, xDistanceMeshes=None,
                       sChooseSkinCluster=None, bDisableIslandCheck=False):
    '''
    This averages the skinWeights. Islands are separated pieces in the mesh that have no edge connections to other pieces.
    For example buttons combined into one mesh
    '''
    # _validateChooseSkinCluster(sChooseSkinCluster)

    for pSelected in _translateInput(_pSelection):

        if not bDisableIslandCheck:
            if len(pSelected.aIds) != pSelected.getTotalCount():
                if len(pSelected.getIslands(bFullObject=False)) > 1:
                    if cmds.confirmDialog(
                            m='There are more than one islands selected on %s. Continue?' % pSelected.getTransformName(),
                            button=['yes', 'no']) == 'no':
                        continue

        sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())

        sSkinCluster, sInfluences, aWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
        aOldWeights2d = np.copy(aWeights2d)
        _averageWeights2d(pSelected, aWeights2d, iSeparateIslands, iCalculateAverageMode)
        pSelected.setSkinClusterWeights(aWeights2d, aOldWeights2d=aOldWeights2d, fBlend=fBlend, iJointLocks=iJointLocks,
                                        iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                        xDistanceMeshes=xDistanceMeshes, sChooseSkinCluster=sConvertedChooseSkinCluster)


dControls = {}
dControls['iSeparateIslands'] = controls.RadioButtonsControl(SeparateIslands)
dControls['iCalculateAverageMode'] = controls.RadioButtonsControl(CalculateAverageMode)
dControls['sMaps'] = controls.WeightmapSelector()


@uiSettings.addToUI(sTab='WeightMaps', sModuleButton='Average', sRunButton='Average', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsWeightmaps/')
def averageWeightMaps(sMaps=[], iSeparateIslands=SeparateIslands.IgnoreIslands,
                      iCalculateAverageMode=CalculateAverageMode.fullAndSoftSelectedVerticesWeighted,
                      fBlend=1.0, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2):
    for sMap in sMaps:
        sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
        pPatch = patch.patchFromName(sGeometry, bConsiderSelection=True)
        aWeights2d = pPatch.getMapValues(sSceneMap)
        aOldWeights2d = np.copy(aWeights2d)
        _averageWeights2d(pPatch, aWeights2d, iSeparateIslands, iCalculateAverageMode)
        pPatch.setMapValues(sSceneMap, aWeights2d.reshape(1, -1))


def _averageWeights2d(pPatch, aWeights2d, iSeparateIslands, iCalculateAverageMode, dControls={}):
    aMapper = utils.getIdsToIndicesMapper(pPatch.aIds)
    if iSeparateIslands == SeparateIslands.IgnoreIslands:
        aIslands = [pPatch.aIds]
    else:
        iIslands = pPatch.getIslands()
        aIslands = [np.array(iIsland, dtype=int) for iIsland in iIslands]
        if iSeparateIslands == SeparateIslands.AverageEachIslandSeparatelyButIgnoreBiggestIsland:
            aPoints = pPatch.getAllPoints()
            # aVolumes = np.empty(len(aIslands), dtype=int)
            aVolumes = np.zeros(len(aIslands), dtype='float64')
            for i, aIsland in enumerate(aIslands):
                aIslandPoints = aPoints[aIsland]
                aLeftBot = np.amin(aIslandPoints, axis=0)
                aRightTop = np.max(aIslandPoints, axis=0)
                aVolumes[i] = np.prod(np.abs(aRightTop - aLeftBot))
            aVolumeOrder = np.argsort(aVolumes)[::-1]
            aIslands = [aIslands[aVolumeOrder[a]] for a in range(1, len(aIslands), 1)]
    for i, aIsland in enumerate(aIslands):
        if utils.isNone(pPatch.aSofts) or iCalculateAverageMode == CalculateAverageMode.fullAndSoftSelectedVertices:
            aAverage = np.average(aWeights2d[aMapper[aIsland]], axis=0)
        else:
            aAllSoft = np.zeros(np.max(pPatch.aIds) + 1, dtype='float64')
            aAllSoft[pPatch.aIds] = pPatch.aSofts
            aDenomInverted = 1.0 / np.sum(aAllSoft[aIsland])
            if iCalculateAverageMode == CalculateAverageMode.onlyFullSelectedVertices:
                aAllSoft[aAllSoft < 1.0] = 0.0
                aAverage = np.sum(aWeights2d[aMapper[aIsland]] * aAllSoft[aIsland, np.newaxis], axis=0) * aDenomInverted
            elif iCalculateAverageMode == CalculateAverageMode.fullAndSoftSelectedVerticesWeighted:
                aAverage = np.sum(aWeights2d[aMapper[aIsland]] * aAllSoft[aIsland, np.newaxis], axis=0) * aDenomInverted
        aWeights2d[aMapper[aIsland]] = aAverage


# =================
# Transfer
# =================


class TransferMode(object):
    vertexIndex = 0
    closestVertex = 1
    closestPoint = 2
    closestUV = 3
    closestUVPoint = 4
    spikes = 5




dControls = {}
dControls['iMode'] = controls.RadioButtonsControl(TransferMode)
dControls['sFrom'] = controls.SelectionControl(bList=True, funcGetCompleterStrings=getSkinClusterCompleterStrings)


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Transfer', sRunButton='Transfer', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#average')
def transferSkinCluster(_pSelection=None, sFrom=[], fBlend=1.0, iJointLocks=patch.JointLocks.ignore,
                        iMode=TransferMode.closestPoint, sPositionMesh=None,
                        xDistanceMeshes=None, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                        sChooseSkinCluster=None, bAutoCreateNewSkinCluster=False,
                        iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                        sJointsOverride=None, bMirror=False, bLookForJointsWithoutNamespaces=False, _bResetSettings=True, funcMapJoint=None, bLogReport=True, bPostNormalize=False, _bSkipDeformerAdjustLogging=False):
    if bAutoCreateNewSkinCluster:
        sChooseSkinCluster = None

    # _validateChooseSkinCluster(sChooseSkinCluster)


    sFroms = utils.toList(sFrom)
    dFroms = defaultdict(list)
    for sF in sFroms:
        if '.' in sF:
            sObj, _ = sF.split('.')
            dFroms[sObj].append(sF)
        else:
            dFroms[sF] = None

    sReturns = []
    if _bResetSettings:
        patch.iMissingInfluencesForNext = None
        cmds.undoInfo(openChunk=True)
    try:
        sSelBefore = cmds.ls(sl=True)

        # pFromPatches = [patch.patchFromName(sM) for sM in sFroms]
        pPatches = _translateInput(_pSelection)
        if bLogReport: report.report.resetProgress(len(pPatches))
        dChooseSkinCluster = {}
        for pSelected in pPatches:
            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())
            if bLogReport:
                report.report.incrementProgress()
                report.report.addLogText('transferring to %s...' % pSelected.getTransformName())

            sNonExistingMeshes = []
            sFromsTransfer = list(dFroms.keys())
            xSkipDict = {}
            for i, sFromMesh in enumerate(sFromsTransfer):
                if not utils.isNone(dFroms[sFromMesh]):# != None:
                    sComponents = dFroms[sFromMesh]

                    if iMode in [TransferMode.closestVertex, TransferMode.closestUV]:
                        sComps = cmds.ls(cmds.polyListComponentConversion(sComponents, tv=True), flatten=True)
                    elif iMode in [TransferMode.closestPoint, TransferMode.closestUVPoint]:
                        sComps = cmds.ls(cmds.polyListComponentConversion(sComponents, tf=True), flatten=True)

                    aComps = np.array([int(sC.split('[')[1].split(']')[0]) for sC in sComps], dtype=int)

                    if iMode in [TransferMode.closestVertex, TransferMode.closestUV]:
                        aSkip = np.setdiff1d(np.arange(cmds.polyEvaluate(sFromMesh, vertex=True)), aComps)
                    elif iMode in [TransferMode.closestPoint, TransferMode.closestUVPoint]:
                        aSkip = np.setdiff1d(np.arange(cmds.polyEvaluate(sFromMesh, face=True)), aComps)
                    xSkipDict[sFromMesh] = aSkip


                if cmds.objectType(sFromMesh) == 'skinCluster':
                    sFromsTransfer[i] = deformers.getGeoFromDeformer(sFromMesh)
                    dChooseSkinCluster[sFromsTransfer[i]] = sFromMesh
                if ',' in sFromMesh:
                    sFromMesh = sFromMesh.replace(' ', '')
                    sSearch, sReplace = sFromMesh.split(',')
                    sMesh = pSelected.getTransformName()
                    if sSearch in sMesh:
                        sFromsTransfer[i] = re.sub(sSearch, sReplace, sMesh)
                        if not cmds.objExists(sFromsTransfer[i]):
                            sNonExistingMeshes.append(sFromsTransfer[i])
                    else:
                        sFromsTransfer[i] = None

            if sNonExistingMeshes:
                print('WARNING: skipping %s, because mesh %s don\'t exist!' % (sMesh, ', '.join(sNonExistingMeshes)))
                continue
            sFromsTransfer = [sM for sM in sFromsTransfer if sM != None]
            if not sFromsTransfer:
                cmds.warning('no meshes to transfer found for %s' % pSelected.getName())
                continue

            pFromPatches = [patch.patchFromName(sM) for sM in sFromsTransfer]
            iVertCounts = [tbP.getTotalCount() for tbP in pFromPatches]

            # bUseComponents = False

            def _addProgressBarStep():
                pass

            if iMode in [TransferMode.closestVertex, TransferMode.closestPoint, TransferMode.closestUV,
                         TransferMode.closestUVPoint]:
                iSkipIds = [xSkipDict.get(sFromMeshTransfer, None) for sFromMeshTransfer in sFromsTransfer]
                bVertex = iMode in [TransferMode.closestVertex, TransferMode.closestUV]
                bUvs = iMode in [TransferMode.closestUV, TransferMode.closestUVPoint]
                pPositionMesh = pSelected if not sPositionMesh else patch.patchFromName(sPositionMesh)
                aAllMapVerts, aMapCoords, aMeshes = barycentric.getVertexCoordinates(pFromPatches, pPositionMesh,
                                                                                     bUvs=bUvs,
                                                                                     bClosestVertex=bVertex,
                                                                                     fProgressBarFunc=_addProgressBarStep,
                                                                                     iiSkipVertOrFaceIds=iSkipIds,
                                                                                     bMirror=bMirror)
            elif iMode == TransferMode.vertexIndex:
                if len(sFromsTransfer) > 1:
                    cmds.warning(
                        'when vertexIndex is set, multiple meshes is not supported, taking the first one ("%s")' %
                        pFromPatches[0].getName())
                aMeshes = np.zeros(len(pSelected.aIds), dtype=int)
                aAllMapVerts = pSelected.aIds
                # bVertex = True
            elif iMode == TransferMode.spikes:
                iNbs = pSelected.getIslands()
                aVerts = pSelected.getAllPoints(bWorld=True)

                mPoints, iIntersectionEdges = pFromPatches[0].getEdgeIntersections(pSelected)
                if mPoints:
                    aPoints = np.array(mPoints, dtype='float64')[:, 0:3]
                    aIntersectionEdges = np.array(iIntersectionEdges, dtype=int)
                    aMapEdges = np.zeros(np.max(aIntersectionEdges) + 1, dtype=int)
                    aMapEdges[aIntersectionEdges] = np.arange(len(aIntersectionEdges))

                    fMeans = []
                    # for each Island get eiher the mean intersection point, or the mean point between all its
                    # vertices if it doesn't intersect

                    if len(iNbs) > 1:  # polys (curves and surfaces wouldn't fall into that since they only have one island)
                        aVertexEdges = utils.numpify2dList(pSelected.getAllVertexEdges())

                    if bLogReport:
                        if len(iNbs) > 1:
                            report.report.addLogText('spikes count: %d' % len(iNbs))
                            report.report.addToMaximum(len(iNbs) / 10)

                    for i, iIsland in enumerate(iNbs):
                        aIsland = np.array(iIsland, dtype=int)
                        if len(iNbs) > 1:  # polys (curves and surfaces wouldn't fall into that since they only have one island)
                            aIslandEdges = np.unique(aVertexEdges[aIsland].flatten())
                            aIslandIntersectionEdges = np.intersect1d(aIntersectionEdges, aIslandEdges,
                                                                      assume_unique=True)
                        else:  # curves or surfaces
                            aIslandIntersectionEdges = aIntersectionEdges
                        if len(aIslandIntersectionEdges):
                            if isinstance(pSelected, patch.CurvePatch): # if it's a hair strand, we just want the closest intersection at the root
                                aIslandIntersectionEdges = aIslandIntersectionEdges[:1]
                            aIslandIntersectionEdges = np.array(aIslandIntersectionEdges, dtype=int)
                            aIndices = aMapEdges[aIslandIntersectionEdges]
                            aIslandPoints = aPoints[aIndices]
                            aMean = np.average(aIslandPoints, axis=0)
                        else:
                            aMean = np.mean(aVerts[aIsland], axis=0)
                        fMeans.append(aMean)

                        if bLogReport and not i % 10:
                            report.report.incrementProgress()

                else:
                    fMeans = []
                    for i, iIsland in enumerate(iNbs):
                        aIsland = np.array(iIsland, dtype=int)
                        fMeans.append(np.mean(aVerts[aIsland], axis=0))

                fnCurve = OpenMaya2.MFnNurbsCurve()

                mMeans = OpenMaya2.MPointArray([OpenMaya2.MPoint(fM) for fM in fMeans])

                mMeansCurve = mMeans if len(mMeans) > 1 else [mMeans[0], OpenMaya2.MPoint(0, 0, 0)]
                mKnots = OpenMaya2.MDoubleArray([0] * len(mMeansCurve))
                oCurve = fnCurve.create(mMeansCurve, mKnots, 1, OpenMaya2.MFnNurbsCurve.kOpen, False, False)
                sCurve = OpenMaya2.MFnDagNode(oCurve).fullPathName()
                pCurve = patch.patchFromName(sCurve)
                aCurveVerts, aCurveCoords, aCurveMeshes = barycentric.getVertexCoordinates([pFromPatches[0]], pCurve,
                                                                                           bClosestVertex=False,
                                                                                           bMirror=False)

                if len(mMeansCurve) != len(mMeans):
                    aCurveVerts = aCurveVerts[:-1]
                    aCurveCoords = aCurveCoords[:-1]

                cmds.delete(sCurve)
                aAllMapVerts = np.zeros((pSelected.getTotalCount(), aCurveVerts.shape[1]), dtype=int)
                aMapCoords = np.zeros((pSelected.getTotalCount(), aCurveVerts.shape[1]), dtype='float64')
                aMeshes = np.zeros(pSelected.getTotalCount(), dtype=int)

                for i, iIsland in enumerate(iNbs):
                    aIsland = np.array(iIsland, dtype=int)
                    aAllMapVerts[aIsland] = aCurveVerts[i]
                    aMapCoords[aIsland] = aCurveCoords[i]
                # end of analyzing for spikes

            sAllFromSkinClusters = []
            xWeights, xInfluences, xGetIds, xInds, xIdMaps = [], [], [], [], []
            for iMesh, tbFromPatch in enumerate(pFromPatches):
                iSourceVertexCount = iVertCounts[iMesh]

                aInds = np.array(np.where(aMeshes == iMesh)[0], dtype=int)
                xInds.append(aInds)
                aGetIds = np.unique(aAllMapVerts[aInds].ravel())
                aGetIds.sort()
                aGetIds = np.delete(aGetIds, np.where(aGetIds == -1)[0])
                xGetIds.append(aGetIds)
                aIdMapper = np.zeros(iSourceVertexCount, dtype=int)
                aIdMapper[aGetIds] = np.arange(aGetIds.size)
                xIdMaps.append(aIdMapper[aAllMapVerts[aInds]])

                # sChooseFromSkinCluster = dChooseSkinCluster.get(sFromsTransfer[iMesh], None)
                if sFromsTransfer[iMesh] in dChooseSkinCluster:
                    sChooseFromSkinCluster = dChooseSkinCluster[sFromsTransfer[iMesh]]
                else:
                    sChooseFromSkinCluster = deformers.chooseMainSkinClusterFromList(deformers.listAllDeformers(sFromsTransfer[iMesh], sFilterTypes='skinCluster'))
                sSkinCluster, sInfluences, aWeights2d = tbFromPatch.getSkinCluster(aOverrideIds=aGetIds, sChooseSkinCluster=sChooseFromSkinCluster)

                if not sSkinCluster:
                    raise Exception('trying to transfer weights from %s, but it doesn\'t have a skinCluster!' % tbFromPatch.getName())


                sInfluences = np.array(sInfluences)
                if funcMapJoint != None:
                    sInfluences = [funcMapJoint(sJ) for sJ in sInfluences]

                if bLookForJointsWithoutNamespaces:
                    for i,sI in enumerate(sInfluences):
                        if ':' in sI:
                            sNoNamespaceI = sI.split(':')[-1]
                            if cmds.objExists(sNoNamespaceI):
                                sInfluences[i] = sNoNamespaceI

                sDuplicates = utils.getDuplicates(sInfluences)
                if sDuplicates:
                    for sDupl in sDuplicates:
                        iDuplInds = []
                        for i,sInf in enumerate(sInfluences):
                            if sInf == sDupl:
                                iDuplInds.append(i)
                        for iInd in iDuplInds[1:]:
                            aWeights2d[:,iDuplInds[0]] += aWeights2d[:,iInd]
                        sInfluences = np.delete(sInfluences, iDuplInds[1:])
                        aWeights2d = np.delete(aWeights2d, iDuplInds[1:], axis=1)



                sAllFromSkinClusters.append(sSkinCluster)

                if not utils.isNone(sJointsOverride):# != None:
                    sInfluences = sJointsOverride[iMesh]
                xWeights.append(aWeights2d)
                xInfluences.append(list(sInfluences))

            sReducedInfluences = reduce((lambda x, y: x + y), xInfluences)

            aAllInfluences = np.unique(np.array(sReducedInfluences))

            dAllInfluences = dict(list(zip(aAllInfluences, range(aAllInfluences.size))))
            iInfCount = aAllInfluences.size
            aWeights = np.zeros((pSelected.aIds.size, iInfCount), dtype='float64')
            for iMesh, tbFromPatch in enumerate(pFromPatches):

                if xInds[iMesh].size == 0:
                    continue
                aMappedInfluences = np.array([dAllInfluences[sInf] for sInf in xInfluences[iMesh]], dtype=int)
                if iMode in [0, 1, 3]:
                    aWeights[xInds[iMesh][:, np.newaxis], aMappedInfluences] = xWeights[iMesh][xIdMaps[iMesh]]
                elif iMode in [2, 4, 5]:
                    aMultiplied = xWeights[iMesh][xIdMaps[iMesh]] * aMapCoords[xInds[iMesh]][..., np.newaxis]
                    aWeights[xInds[iMesh][:, np.newaxis], aMappedInfluences] = np.sum(aMultiplied, axis=1)

            if bAutoCreateNewSkinCluster:
                if isinstance(bAutoCreateNewSkinCluster, str):
                    sCreateNew = bAutoCreateNewSkinCluster
                else:
                    sCreateNew = '%sskinCluster__%s' % utils.splitNamespace(pSelected.getTransformName())
                    sSplits = sFroms[0].split('__')
                    if len(sSplits) == 3:
                        sCreateNew = '%s__%s' % (sCreateNew, sSplits[-1])

                if not cmds.objExists(sCreateNew):
                    print ('not existing..')
                    if iCheckMissingInfluences == patch.MissingInfluencesOptions.askToAddOrCreateInfluences:
                        iCheckMissingInfluences = patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster
                else:
                    print ('existing...', sCreateNew)
                    cmds.select(sCreateNew)
                    sConvertedChooseSkinCluster = sCreateNew
                    sCreateNew = None

            else:
                sCreateNew = None
            print ('sCreateNew: ', sCreateNew)
            aExtractedWeights2d, sExtractedInfluences = patch._removeZeroInfluencesNumpy(aWeights, aAllInfluences)
            sReturnSkinCluster, _, _ = pSelected.setSkinClusterWeights(aExtractedWeights2d, sExtractedInfluences,
                                                                    iCheckMissingInfluences=iCheckMissingInfluences, iJointLocks=iJointLocks,
                                                                    iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                                                    xDistanceMeshes=xDistanceMeshes, fBlend=fBlend,
                                                                    sChooseSkinCluster=sConvertedChooseSkinCluster,
                                                                    sCreateNew=sCreateNew,
                                                                    bPostNormalize=bPostNormalize, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)
            sReturns.append(sReturnSkinCluster)

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        if _bResetSettings:
            patch.iMissingInfluencesForNext = None
            cmds.undoInfo(closeChunk=True)

    return sReturns


class IntTransferMode(object):
    closestVertex = 0
    closestPoint = 2



dControls = {}
dControls['iMode'] = controls.RadioButtonsControl(IntTransferMode)


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='IntTransfer', sRunButton='Transfer', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#inttransfer')
def intTransferSkinCluster(_pSelection=None, sFromComponents=[], iMode=IntTransferMode.closestPoint, _bFromComponentIsIndices=False, fBlend=1.0,
                           iJointLocks=patch.JointLocks.ignore,
                           xDistanceMeshes=None, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                           sChooseSkinCluster=None):
    '''
    IMPORTANT: you need to select vertices for that

    Transfers weights between components inside the same mesh
    If you leave From Components empty, he will transfer from all components except selected
    '''

    sSelBefore = cmds.ls(sl=True)
    pPatches = _translateInput(_pSelection)
    report.report.resetProgress(len(pPatches))

    bVertex = iMode == IntTransferMode.closestVertex

    for pSelected in pPatches:
        pFull = patch.patchFromName(pSelected.getName())

        sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())

        if len(sFromComponents) or sFromComponents == None:  # we provided comps, iSkipIds needs to be all ids except fromComps
            if bVertex:
                if _bFromComponentIsIndices:
                    iSkipIds = sFromComponents
                else:
                    sFromVerts = cmds.polyListComponentConversion(sFromComponents, tv=True)
                    iFromVerts = utils.mayaCompStringsToList(sFromVerts)
                    iSkipIds = np.setdiff1d(np.arange(pSelected.getTotalCount()), iFromVerts)
            else:
                if _bFromComponentIsIndices:
                    iSkipIds = sFromComponents
                else:
                    sFromFaces = cmds.polyListComponentConversion(sFromComponents, tf=True)
                    iFromFaces = utils.mayaCompStringsToList(sFromFaces)
                    iFacesCount = len(cmds.ls('%s.f[*]' % pSelected.getTransformName(), flatten=True))
                    iSkipIds = np.setdiff1d(np.arange(iFacesCount), iFromFaces)
        else:  # no comps provided, we'll easily set iSkipIds to selected ids
            if bVertex:
                iSkipIds = pSelected.aIds
            else:  # convert pSelected.aIds to face ids
                sVertStrings = ['%s.vtx[%s]' % (pSelected.getTransformName(), sC) for sC in
                                utils.createMayaStringFromList(pSelected.aIds)]
                sFaceStrings = cmds.polyListComponentConversion(sVertStrings, tf=True)
                iSkipIds = utils.mayaCompStringsToList(sFaceStrings)

        sSkinCluster, sInfluences, aWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster,
                                                                         aOverrideIds=np.arange(
                                                                             pSelected.getTotalCount()))

        aMapVerts, aMapCoords, aMeshes = barycentric.getVertexCoordinates([pFull], pSelected, bClosestVertex=bVertex,
                                                                          iiSkipVertOrFaceIds=[iSkipIds])
        if bVertex:
            aWeights2d[pSelected.aIds] = aWeights2d[aMapVerts]
        else:
            aIndMapper = utils.getIdsToIndicesMapper(pSelected.aIds)
            aMultiplied = aWeights2d[aMapVerts] * aMapCoords[aIndMapper[pSelected.aIds]][..., np.newaxis]
            aWeights2d[pSelected.aIds, :] = np.sum(aMultiplied, axis=1)

        pSelected.setSkinClusterWeights(aWeights2d[pSelected.aIds], sChooseSkinCluster=sConvertedChooseSkinCluster,
                                        iJointLocks=iJointLocks,
                                        iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                        xDistanceMeshes=xDistanceMeshes, fBlend=fBlend)

    cmds.select(sSelBefore)


dControls = {}
dControls['iMode'] = controls.RadioButtonsControl(TransferMode)
dControls['sFrom'] = controls.WeightmapSelector(bSingleSelection=True)
dControls['sTo'] = controls.WeightmapSelector()


@uiSettings.addToUI(sTab='WeightMaps', sModuleButton='Transfer', sRunButton='Transfer', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsWeightmaps/')
def transferWeightMaps(sFrom=None, sMaps=[], fBlend=1.0, iMode=TransferMode.closestPoint, bMirror=False,
                       xDistanceMeshes=None, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=patch.BorderEdges.doEverything, _bSkipDeformerAdjustLogging=False):
    sFrom = utils.toList(sFrom)
    sFromSceneMap, sFromGeometry = deformers.decodeMapName(sFrom[0], bReturnGeo=True)
    tbFromPatch = patch.patchFromName(sFromGeometry)
    print('sFromSceneMap: ', sFromSceneMap, ' -- ', sFromGeometry, ' -- ')
    aFromValues = tbFromPatch.getMapValues(sFromSceneMap)
    for sMap in sMaps:
        sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
        tbPatch = patch.patchFromName(sGeometry, bConsiderSelection=True)
        if iMode > 0:
            bVertex = iMode in [TransferMode.closestVertex, TransferMode.closestUV]
            bUvs = iMode in [TransferMode.closestUV, TransferMode.closestUVPoint]
            aMapVerts, aCoords, _ = barycentric.getVertexCoordinates([tbFromPatch], tbPatch, bUvs=bUvs,
                                                                     bClosestVertex=bVertex, bMirror=bMirror)
        elif iMode == TransferMode.vertexIndex:
            bVertex = True
            aMapVerts = tbPatch.aIds
            if bMirror:
                aMirror, aSide = tbPatch.getMirrorTable()
                aFromValues = aFromValues[aMirror]

        if bVertex:
            aValues = aFromValues[aMapVerts]
        else:
            aValues = np.sum(aFromValues[aMapVerts] * aCoords, axis=-1)
        tbPatch.setMapValues(sSceneMap, aValues, xDistanceMeshes=xDistanceMeshes, iBorderEdges=iBorderEdges,
                             iSmoothBorderMask=iSmoothBorderMask, fBlend=fBlend, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)


# =================
# Copy Paste
# =================

class CopyPasteContainer(object):
    pass


CopyPasteContainer = CopyPasteContainer()


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Copy/Paste', sRunButton='Copy', dControls={},
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True)
def pasteOne(sChooseSkinCluster=None):
    # _validateChooseSkinCluster(sChooseSkinCluster)

    tbPatch = patch.getSelectedPatches()[0]
    sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, tbPatch.getName())

    sSkinCluster, sInfluences, aWeights2d = tbPatch.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
    aAverage = np.average(aWeights2d, axis=0)

    global CopyPasteContainer
    CopyPasteContainer.aCopiedAverage2d = aAverage
    CopyPasteContainer.sCopiedInfluences = sInfluences


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Copy/Paste', sRunButton='Paste', bReloadBeforeRun=False,
                  dControls={}, tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#copypaste')
def paste(fBlend=1.0, iJointLocks=patch.JointLocks.ignore, xDistanceMeshes=None,
          iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
          iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences, sChooseSkinCluster=None):
    '''
    first select a vertex and copy, and then select another region (can be on a different
    mesh), and hit Paste
    '''
    global CopyPasteContainer
    aCopiedAverage2d = CopyPasteContainer.aCopiedAverage2d
    sCopiedInfluences = CopyPasteContainer.sCopiedInfluences

    cmds.undoInfo(openChunk=True)
    patch.iMissingInfluencesForNext = None
    try:
        for tbPatch in patch.getSelectedPatches():
            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, tbPatch.getName())

            aWeights2d = np.zeros((tbPatch.aIds.size, len(sCopiedInfluences)), dtype='float64')
            aWeights2d[:, :] = aCopiedAverage2d
            tbPatch.setSkinClusterWeights(aWeights2d, sInfluences=sCopiedInfluences, xDistanceMeshes=xDistanceMeshes,
                                          iJointLocks=iJointLocks, fBlend=fBlend,
                                          iCheckMissingInfluences=iCheckMissingInfluences, iBorderEdges=iBorderEdges,
                                          iSmoothBorderMask=iSmoothBorderMask,
                                          sChooseSkinCluster=sConvertedChooseSkinCluster)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)
        patch.iMissingInfluencesForNext = None


# =================
# Mirror
# =================

class MirrorDirectionSkinCluster(object):
    leftToRight = 0
    rightToLeft = 1

class MirrorMode(object):
    closestVertex = 0
    closestPoint = 1

dControls = {}
dControls['iMirrorMode'] = controls.RadioButtonsControl(MirrorMode)
dControls['iDirection'] = controls.RadioButtonsControl(MirrorDirectionSkinCluster)
dControls['sPositionMesh'] = controls.SelectionControl(bList=False)

@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Mirror', sRunButton='Mirror', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#mirror')
def mirrorSkinCluster(_pSelection=None, fBlend=1.0, iJointLocks=patch.JointLocks.ignore,
                        iMirrorMode=MirrorMode.closestPoint, iDirection=MirrorDirectionSkinCluster.leftToRight,
                        xDistanceMeshes=None, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                        sChooseSkinCluster=None, bJointLabels=False, sPositionMesh=None,
                        iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                        _bResetSettings=True, bPostNormalize=False):


    if _bResetSettings:
        patch.iMissingInfluencesForNext = None
        cmds.undoInfo(openChunk=True)
    try:
        sSelBefore = cmds.ls(sl=True)

        pPatches = _translateInput(_pSelection)

        if iMirrorMode == MirrorMode.closestPoint:
            pNotSupportedPatches = [pPatch for pPatch in pPatches if not pPatch.supportsClosestPoint()]
            if pNotSupportedPatches:
                raise Exception('closestPoint is not supported for %s.\nSwitch to ClosestVertex instead' % utils.listToString([pP.getTransformName() for pP in pNotSupportedPatches]))


        if sChooseSkinCluster:
            if len(pPatches) > 1:
                utils.reload2(utils)
                if not sChooseSkinCluster.startswith('__') and not utils.isInteger(sChooseSkinCluster):
                    raise Exception('If you mirror across more than one meshes, you need to either leave the ChooseSkinCluster empty, or specify a generic one - such as the suffix (like __TWEAKER) or or number (like 1)')

        pFromPatches = []
        sConvertedSkinClusters = []
        for pPatch in pPatches:
            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pPatch.getName())
            if sConvertedChooseSkinCluster:
                sConvertedSkinClusters.append(sConvertedChooseSkinCluster)
                pFromPatches.append(pPatch)


        iVertCounts = [tbP.getTotalCount() for tbP in pFromPatches]

        for p, pSelected in enumerate(pFromPatches):

            aAllPoints = pSelected.getAllPoints()
            if iDirection == MirrorDirectionSkinCluster.leftToRight:
                aSideIds = np.where(aAllPoints[:,0] < 0.0)[0]
            else:
                aSideIds = np.where(aAllPoints[:,0] > 0.0)[0]
            aDoIds = np.intersect1d(pSelected.aIds, aSideIds)
            if not len(aDoIds):
                continue

            if not utils.isNone(pSelected.aSofts):
                aTotalSoftValues = np.zeros(pSelected.getTotalCount(), dtype='float64')
                aTotalSoftValues[pSelected.aIds] = pSelected.aSofts
                pSelected.aSofts = aTotalSoftValues[aDoIds]

            pSelected.aIds = aDoIds


            aAllMapVerts, aMapCoords, aMeshes = barycentric.getVertexCoordinates(pFromPatches, pSelected,
                                                                                 bClosestVertex=iMirrorMode==MirrorMode.closestVertex,
                                                                                 bMirror=True)

            xWeights, xInfluences, xInds, xIdMaps = [], [], [], []

            for iFromMesh, tbFromPatch in enumerate(pFromPatches):
                iSourceVertexCount = iVertCounts[iFromMesh]
                aInds = np.array(np.where(aMeshes == iFromMesh)[0], dtype=int)
                aGetIds = np.unique(aAllMapVerts[aInds].ravel())
                aGetIds.sort()
                aGetIds = np.delete(aGetIds, np.where(aGetIds == -1)[0])
                aIdMapper = np.zeros(iSourceVertexCount, dtype=int)
                aIdMapper[aGetIds] = np.arange(aGetIds.size)
                xIdMaps.append(aIdMapper[aAllMapVerts[aInds]])
                xInds.append(aInds)

                if not len(aInds):
                    xWeights.append(None)
                    xInfluences.append([])
                else:
                    sSkinCluster, sInfluences, aWeights2d = tbFromPatch.getSkinCluster(aOverrideIds=aGetIds, sChooseSkinCluster=sConvertedSkinClusters[iFromMesh])

                    if not sSkinCluster:
                        raise Exception('trying to transfer weights from %s, but it doesn\'t find skinCluster!' % tbFromPatch.getName())

                    sMirrorInfluences = _createMirrorInfluencesList(sInfluences, bJointLabels=bJointLabels)
                    xWeights.append(aWeights2d)
                    xInfluences.append(sMirrorInfluences)

            sReducedInfluences = utils.flattenedList(xInfluences) #reduce((lambda x, y: x + y), xInfluences)
            aAllInfluences = np.unique(np.array(sReducedInfluences))

            dAllInfluences = dict(list(zip(aAllInfluences, range(aAllInfluences.size))))
            iInfCount = aAllInfluences.size
            aWeights = np.zeros((pSelected.aIds.size, iInfCount), dtype='float64')
            for iFromMesh, tbFromPatch in enumerate(pFromPatches):
                if xInds[iFromMesh].size == 0:
                    continue
                aMappedInfluences = np.array([dAllInfluences[sInf] for sInf in xInfluences[iFromMesh]], dtype=int)
                if iMirrorMode == MirrorMode.closestVertex:
                    aWeights[xInds[iFromMesh][:, np.newaxis], aMappedInfluences] = xWeights[iFromMesh][xIdMaps[iFromMesh]]
                elif iMirrorMode == MirrorMode.closestPoint:
                    aMultiplied = xWeights[iFromMesh][xIdMaps[iFromMesh]] * aMapCoords[xInds[iFromMesh]][..., np.newaxis]
                    aWeights[xInds[iFromMesh][:, np.newaxis], aMappedInfluences] = np.sum(aMultiplied, axis=1)


            aExtractedWeights2d, sExtractedInfluences = patch._removeZeroInfluencesNumpy(aWeights, aAllInfluences)
            pSelected.setSkinClusterWeights(aExtractedWeights2d, sExtractedInfluences,
                                            iCheckMissingInfluences=iCheckMissingInfluences, iJointLocks=iJointLocks,
                                            iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                            xDistanceMeshes=xDistanceMeshes, fBlend=fBlend,
                                            sChooseSkinCluster=sConvertedSkinClusters[p],
                                            bPostNormalize=bPostNormalize)

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        if _bResetSettings:
            patch.iMissingInfluencesForNext = None
            cmds.undoInfo(closeChunk=True)





# =================
# Mirror Topo
# =================





def _createMirrorInfluencesList(sInfluences, bJointLabels=None):
    sMirrorInfluences = []
    sAllJoints = cmds.ls(et='joint')
    if bJointLabels:
        sAllLables = [cmds.getAttr('%s.otherType' % sJoint) for sJoint in sAllJoints]
        for sInf in sInfluences:
            sLabel = cmds.getAttr('%s.otherType' % sInf)
            sMirrorLabel = utils.getMirrorName(sLabel)
            bFoundLabel = False
            for l, sLabel in enumerate(sAllLables):
                if sMirrorLabel == sLabel:
                    sMirrorInfluences.append(sAllJoints[l])
                    bFoundLabel = True
                    break
            if not bFoundLabel:
                sMirrorInfluences.append(utils.getMirrorName(sInf))
    else:
        for sInf in sInfluences:
            sMirrorName = utils.getMirrorName(sInf)
            sMirrorInfluences.append(sMirrorName if sMirrorName != None else sInf)
    return sMirrorInfluences


dControls = {}
dControls['iMirrorMode'] = controls.RadioButtonsControl(MirrorMode)
dControls['iDirection'] = controls.RadioButtonsControl(MirrorDirectionSkinCluster)
dControls['sMiddleEdge'] = controls.MiddleEdgeControl()

@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='MirrorTopo', sRunButton='Mirror', dControls=dControls,
                    tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#mirrortopo')
def mirrorSkinClusterTopo(_pSelection=None, iDirection=MirrorDirectionSkinCluster.leftToRight,
                      fBlend=1.0, iJointLocks=patch.JointLocks.ignore,
                      sMiddleEdge=None, iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                      iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                      xDistanceMeshes=None, bJointLabels=False,
                      sChooseSkinCluster=None):
    '''
    On Middle Meshes he sets the weights of what you have selected to the mirror vertices on the other side.
    On vertex that are on the middle line he does average (but not in "ClosestPoint" mode!. Middle Vertices
    are handeled better with Closest Ids or Closest Vertex instead of Closest Point.
    On side meshes he sets the weights of what you have selected to the weights of the vertices on the other side.
    '''

    # _validateChooseSkinCluster(sChooseSkinCluster)

    cmds.undoInfo(openChunk=True)
    patch.iMissingInfluencesForNext = None
    try:
        sSelBefore = cmds.ls(sl=True)
        for pSelected in _translateInput(_pSelection):

            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())

            _, sInfluences = pSelected.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sConvertedChooseSkinCluster)

            if sMiddleEdge:
                pAnalyze, iMiddleEdge = utils.intFromComponent(sMiddleEdge, bReturnPatch=True)
                aTable, aSides = pAnalyze.getMirrorTable(bIds=True, iMiddleEdge=iMiddleEdge)
            else:
                aTable, aSides = pSelected.getMirrorTable(bIds=True)

            aSelIds = np.copy(pSelected.aIds)

            aBothIds = np.unique(np.append(pSelected.aIds, aTable[aSelIds]))

            aBothIds = aBothIds[aBothIds >= 0]
            # aBothIds = aBothIds[aTable >= 0]
            aBadIds = np.where(aTable < 0)[0]
            if len(aBadIds):
                aBothIds = np.setdiff1d(aBothIds, aBadIds)

            _, sInfluences, aWeights2d = pSelected.getSkinCluster(aOverrideIds=aBothIds,
                                                                  sChooseSkinCluster=sConvertedChooseSkinCluster)
            sInfluences = np.array(sInfluences)
            aIdMapper = utils.getIdsToIndicesMapper(aBothIds)
            aOldWeights = np.copy(aWeights2d)

            # do the weights
            #
            aMiddleIds = np.intersect1d(np.where(aSides == 0)[0], aBothIds)

            if iDirection == MirrorDirectionSkinCluster.leftToRight:
                aToIds = np.intersect1d(np.where(aSides == 2)[0], aBothIds)
            elif iDirection == MirrorDirectionSkinCluster.rightToLeft:
                aToIds = np.intersect1d(np.where(aSides == 1)[0], aBothIds)
            else:
                raise Exception('unknown direction', iDirection)

            aToIds = np.concatenate([aMiddleIds, aToIds])


            aToIds = np.intersect1d(aToIds, aSelIds)
            if not len(aToIds):
                report.report.addLogText('skipping %s, all vertices are on one side' % pSelected.getTransformName())
                continue

            aToIds.sort()
            aFromIds = aTable[aToIds]

            # check which influences we have on aToIds
            #
            aInfluenceIndices = np.empty((aFromIds.size, len(sInfluences)), dtype=int)
            aInfluenceIndices[:] = np.arange(len(sInfluences))
            aInfluencesOnFromIds = aInfluenceIndices[aWeights2d[aIdMapper[aFromIds]].nonzero()]
            aInfluencesOnFromIds = np.unique(aInfluencesOnFromIds)

            sInfluencesOnFromIds = sInfluences[aInfluencesOnFromIds]
            sMirrorInfluences = _createMirrorInfluencesList(sInfluencesOnFromIds, bJointLabels=bJointLabels)

            iCheckInfluencesResult = pSelected.checkInfluences(sMirrorInfluences,
                                                               iCheckMissingInfluences=iCheckMissingInfluences,
                                                               sChooseSkinCluster=sConvertedChooseSkinCluster)
            if iCheckInfluencesResult == patch.CheckInfluencesResult.influencesStillMissing:
                raise Exception('influences missing')

            elif iCheckInfluencesResult == patch.CheckInfluencesResult.addedInfluences:
                _, sInfluences, aWeights2d = pSelected.getSkinCluster(aOverrideIds=aBothIds,
                                                                      sChooseSkinCluster=sConvertedChooseSkinCluster)
                sInfluences = np.array(sInfluences)

                aOldWeights = np.copy(aWeights2d)

            sAllMirrorInfluences = _createMirrorInfluencesList(sInfluences, bJointLabels=bJointLabels)
            aAllMirrorInfs = utils.findOneArrayInAnother(sInfluences, sAllMirrorInfluences)
            aSetInfs = utils.findOneArrayInAnother(sInfluences, sInfluencesOnFromIds)
            aMirrorInfs = utils.findOneArrayInAnother(sInfluences, sMirrorInfluences)

            aWeights2d[aIdMapper[aToIds][:, np.newaxis], aMirrorInfs] = aWeights2d[
                aIdMapper[aTable[aToIds]][:, np.newaxis], aSetInfs]
            aZeroInfluences = np.setdiff1d(np.arange(len(sInfluences)), aMirrorInfs)
            aWeights2d[:, aZeroInfluences] = 0.0

            aMiddleInfs = np.unique(np.concatenate([aSetInfs, aMirrorInfs]))
            aMiddleWeights = aWeights2d[aIdMapper[aMiddleIds]]
            aMiddleWeights[:, aMiddleInfs] += aMiddleWeights[:, aAllMirrorInfs[aMiddleInfs]]
            aMiddleWeights[:, aMiddleInfs] *= 0.5
            aWeights2d[aIdMapper[aMiddleIds]] = aMiddleWeights

            aSetWeights2d = aWeights2d[aIdMapper[aToIds]]

            if not utils.isNone(pSelected.aSofts):
                aTotalSoftValues = np.zeros(pSelected.getTotalCount(), dtype='float64')
                aTotalSoftValues[aTable[aSelIds]] = pSelected.aSofts
                aTotalSoftValues[aSelIds] = np.maximum(pSelected.aSofts, aTotalSoftValues[aSelIds])
                aSoftValues = aTotalSoftValues[aToIds]
            else:
                aSoftValues = None

            aOldWeightsSet = aOldWeights[aIdMapper[aToIds]]
            pSelected.setSkinClusterWeights(aSetWeights2d, sInfluences, aOverrideIds=aToIds,
                                            aOverrideSofts=aSoftValues,
                                            aOldWeights2d=aOldWeightsSet, iJointLocks=iJointLocks,
                                            fBlend=fBlend,
                                            sChooseSkinCluster=sConvertedChooseSkinCluster, xDistanceMeshes=xDistanceMeshes,
                                            iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask)

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        patch.iMissingInfluencesForNext = None
        cmds.undoInfo(closeChunk=True)


dControls = {}

@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Mirror', sRunButton='Mirror Middle', dControls=dControls, tRefreshControlsAfterRun=[], bAddDefaultButton=True)
def mirrorSkinClusterMiddleVerts(_pSelection=None,
                      fBlend=1.0, iJointLocks=patch.JointLocks.ignore,
                      iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2,
                      iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                      xDistanceMeshes=None, bJointLabels=False,
                      sChooseSkinCluster=None):

    cmds.undoInfo(openChunk=True)
    patch.iMissingInfluencesForNext = None
    try:
        sSelBefore = cmds.ls(sl=True)
        for pSelected in _translateInput(_pSelection):

            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())

            _, sInfluences, aWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
            sInfluences = np.array(sInfluences)


            sNonZeroInfluences = patch._removeZeroInfluencesNumpy(aWeights2d, sInfluences)[1]
            sMirrorInfluences = _createMirrorInfluencesList(sNonZeroInfluences, bJointLabels=bJointLabels)

            iCheckInfluencesResult = pSelected.checkInfluences(sMirrorInfluences,
                                                               iCheckMissingInfluences=iCheckMissingInfluences,
                                                               sChooseSkinCluster=sConvertedChooseSkinCluster)
            if iCheckInfluencesResult == patch.CheckInfluencesResult.influencesStillMissing:
                raise Exception('influences missing')

            elif iCheckInfluencesResult == patch.CheckInfluencesResult.addedInfluences:
                _, sInfluences, aWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
                sInfluences = np.array(sInfluences)

            aNonZeroInfs = utils.findOneArrayInAnother(sInfluences, sNonZeroInfluences)
            aMirrorInfs = utils.findOneArrayInAnother(sInfluences, sMirrorInfluences)

            aWeights2d[:,aNonZeroInfs] += aWeights2d[:, aMirrorInfs]
            aWeights2d[:] *= 0.5

            pSelected.setSkinClusterWeights(aWeights2d, sInfluences,
                                            iJointLocks=iJointLocks,
                                            fBlend=fBlend,
                                            sChooseSkinCluster=sConvertedChooseSkinCluster, xDistanceMeshes=xDistanceMeshes,
                                            iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask)

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        patch.iMissingInfluencesForNext = None
        cmds.undoInfo(closeChunk=True)


def _getMirrorMapName(sMap, bToRight=True):
    if bToRight:
        if sMap.startswith('r_'):
            sMap = '%s%s' % ('l_', sMap[2:])
        sMap = sMap.replace('[r_', '[l_')
        sMap = sMap.replace('_r_', '_l_')
    else:  # toLeft
        if sMap.startswith('l_'):
            sMap = '%s%s' % ('r_', sMap[2:])
        sMap = sMap.replace('[l_', '[r_')
        sMap = sMap.replace('_l_', '_r_')
    return sMap


class MirrorDirectionWeightMaps(object):
    leftToRight = 0
    rightToLeft = 1
    flip = 2
    removeRight = 3
    removeLeft = 4


class WeightmapsMirrorMode(object):
    vertexIds = 0
    closestVertex = 1
    closestPoint = 2


dControls = {}
dControls['iMirrorMode'] = controls.RadioButtonsControl(WeightmapsMirrorMode)
dControls['iDirection'] = controls.RadioButtonsControl(MirrorDirectionWeightMaps)
dControls['sMiddleEdge'] = controls.MiddleEdgeControl()
dControls['iMirrorMode'].setControlEnabled(dControls['sMiddleEdge'], [0], True)
dControls['sPositionMesh'] = controls.SelectionControl(bList=False)
dControls['iMirrorMode'].setControlEnabled(dControls['sPositionMesh'], [0], False)
dControls['sMaps'] = controls.WeightmapSelector()


@uiSettings.addToUI(sTab='WeightMaps', sModuleButton='Mirror', sRunButton='Mirror', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsWeightmaps/')
def mirrorWeightMaps(sMaps=[], iDirection=MirrorDirectionWeightMaps.leftToRight, iMirrorMode=WeightmapsMirrorMode.vertexIds,
                     bLookForSeparateOppositeMap=False,
                     fBlend=1.0, sMiddleEdge=None, sPositionMesh=None):
    '''
    Select the maps you want to mirror to. If it's a right or left weightmap,
    he'll find the opposite. If it's a middle one, he'll mirror in place
    '''
    sSelBefore = cmds.ls(sl=True)
    print('iDirection....: ', iDirection)
    try:
        cmds.undoInfo(openChunk=True)
        iMiddleEdge = utils.intFromComponent(sMiddleEdge) if sMiddleEdge else None

        for sMap in sMaps:
            sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
            pSelected = patch.patchFromName(sGeometry, bConsiderSelection=True)

            if bLookForSeparateOppositeMap:
                sSceneMap, sGeometry = deformers.decodeMapName(sMap, bReturnGeo=True)
                sFromSceneMap = '.'.join([utils.getMirrorName(sSplit) for sSplit in sSceneMap.split('.')])
                sFromGeometry = utils.getMirrorName(sGeometry)
                if not cmds.objExists(sFromSceneMap):
                    report.report.addLogText('skipping %s, because map %s doesn\'t exist' % (sMap, sFromSceneMap))
                    continue

                if not cmds.objExists(sFromGeometry):
                    report.report.addLogText('skipping %s, because geometry %s doesn\'t exist' % (sMap, sFromGeometry))
                    continue
                print ('transferring.. ', sFromSceneMap)
                report.report.addLogText('mirror transferring %s to %s' % (sFromSceneMap, sMap))
                transferWeightMaps(sFrom=sFromSceneMap, sMaps=[sMap], fBlend=fBlend,
                                   iMode=TransferMode.vertexIndex if sFromGeometry == sGeometry else iMirrorMode,
                                   bMirror=True, xDistanceMeshes=None) # had iBorderEdges=[0, 5] before
            else:
                # middle => in place
                if iMirrorMode == WeightmapsMirrorMode.vertexIds:
                    if sMiddleEdge:
                        pAnalyze, iMiddleEdge = utils.intFromComponent(sMiddleEdge,
                                                                       bReturnPatch=True) if sMiddleEdge else None
                        if pAnalyze == None:
                            sWarning = '%s doesn\'t exist, using that index on %s' % (sMiddleEdge, pSelected.getName())
                            report.report.addLogText(sWarning)
                            cmds.warning(sWarning)
                            pAnalyze = patch.patchFromName(pSelected.getName())
                        aTable, aSides = pAnalyze.getMirrorTable(bIds=True, iMiddleEdge=iMiddleEdge)
                    else:
                        aTable, aSides = pSelected.getMirrorTable(bIds=True)

                else:
                    pAnalyze = patch.patchFromName(sPositionMesh) if sPositionMesh else pSelected
                    if iMirrorMode == WeightmapsMirrorMode.closestVertex:
                        aTable, aSides = pAnalyze.getMirrorTable(bIds=False)
                    elif iMirrorMode == WeightmapsMirrorMode.closestPoint:
                        aTable, aCoords, _ = barycentric.getVertexCoordinates(pAnalyze, pAnalyze,
                                                                              aOverrideIds=np.arange(
                                                                                  pAnalyze.getTotalCount()),
                                                                              bClosestVertex=False, bMirror=True)
                        aPoints = pAnalyze.getAllPoints(bWorld=False)
                        aSides = np.where(aPoints[:, 0] > 0.0, 1, 2)

                aSelIds = np.copy(pSelected.aIds)

                if iMirrorMode in [WeightmapsMirrorMode.vertexIds, WeightmapsMirrorMode.closestVertex]:
                    aBothIds = np.unique(np.append(pSelected.aIds, aTable[aSelIds]))
                    aBothIds = aBothIds[aBothIds >= 0]
                    aBadIds = np.where(aTable < 0)[0]
                    if len(aBadIds):
                        aBothIds = np.setdiff1d(aBothIds, aBadIds)

                elif iMirrorMode == WeightmapsMirrorMode.closestPoint:
                    aTableFlattened = np.unique(aTable[aSelIds].flatten())
                    if aTableFlattened[0] == -1:
                        aTableFlattened = aTableFlattened[1:]
                    aBothIds = np.unique(np.append(pSelected.aIds, aTableFlattened))

                aWeights = pSelected.getMapValues(sSceneMap, aOverrideIds=aBothIds)
                aIdMapper = utils.getIdsToIndicesMapper(aBothIds)
                if iDirection == MirrorDirectionWeightMaps.leftToRight:
                    aToIds = np.intersect1d(np.where(aSides == 2)[0], aBothIds)
                elif iDirection == MirrorDirectionWeightMaps.rightToLeft:
                    aToIds = np.intersect1d(np.where(aSides == 1)[0], aBothIds)
                elif iDirection == MirrorDirectionWeightMaps.flip:
                    aToIds = aBothIds
                else:
                    raise Exception('unknown direction', iDirection)

                aToIds = np.intersect1d(aToIds, aSelIds)
                aToIds.sort()
                aFromIds = aTable[aToIds]
                if iMirrorMode == WeightmapsMirrorMode.closestPoint:  # if closestPoint, table is 2dimensional
                    aFromIds = np.unique(aFromIds.flatten())
                    if aFromIds[0] == -1: aFromIds = aFromIds[1:]
                if iMirrorMode in [WeightmapsMirrorMode.vertexIds, WeightmapsMirrorMode.closestVertex]:
                    aWeights[aIdMapper[aToIds]] = aWeights[aIdMapper[aTable[aToIds]]]
                elif iMirrorMode == WeightmapsMirrorMode.closestPoint:
                    aMultWeights = aWeights[aIdMapper[aTable[aToIds]]] * aCoords[aToIds].reshape(len(aToIds), -1)
                    aSum = np.sum(aMultWeights, axis=1)
                    aWeights[aIdMapper[aToIds]] = aSum

                aSetWeights = aWeights[aIdMapper[aToIds]]

                if not utils.isNone(pSelected.aSofts):# != None:
                    aTotalSoftValues = np.zeros(pSelected.getTotalCount(), dtype='float64')
                    aTotalSoftValues[aTable[aSelIds]] = pSelected.aSofts
                    aTotalSoftValues[aSelIds] = np.maximum(pSelected.aSofts, aTotalSoftValues[aSelIds])
                    aSoftValues = aTotalSoftValues[aToIds]
                else:
                    aSoftValues = None

                pSelected.setMapValues(sSceneMap, aSetWeights, aOverrideIds=aToIds, aOverrideSofts=aSoftValues)

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


# =================
# Move
# =================

def getPossibleJoints(skinClusterChooseControl=skinClusterChooseControl):
    sChooseSkinCluster = skinClusterChooseControl.getValue()
    sSelection = cmds.ls(sl=True)
    sAllJoints = cmds.ls(et='joint')

    try:
        sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, sSelection[0])
        sSkinClusterJoints = cmds.listConnections('%s.matrix' % sConvertedChooseSkinCluster, s=True, d=False, t='joint')
        sRemainingJoints = sorted(list(set(sAllJoints) - set(sSkinClusterJoints)))
        return ['%s (%s)' % (sJ, sConvertedChooseSkinCluster) for sJ in sSkinClusterJoints] + sRemainingJoints
    except:
        return sAllJoints


dControls['iJointLines'] = controls.RadioButtonsControl(JointLines)
dControls['xJoints'] = controls.DictionaryControl(funcGetCompleterSrings=getPossibleJoints)

@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Move', sRunButton='Move', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#move')
def moveSkinClusterWeights(_pSelection=None, xJoints={}, fStrength=1.0, iSmoothSteps=5, bJustLogForDebug=False,
                           iJointLocks=patch.JointLocks.ignore, fBlend=1.0,
                           iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences,
                           xDistanceMeshes=None,
                           iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=2, bDisableIslandCheck=False, iJointLines=JointLines.Yes,
                           sChooseSkinCluster=None, _bResetSettings=True, bProjectSquashToMainJoints=True, _bSkipDeformerAdjustLogging=False):
    '''
    Moves weights between joints
    The left sides in the tab can have * and ? in the name.
    For the right ones - if you add a comma (","), he does text replacing (left part of the comma with right part)
    example: "^, namespace0:" will find the To joints in the namespace "namespace0:"
    '''

    bAllDidStuff = True


    # explode the lists in the keys
    xJoints = dict(xJoints)
    for sKey,sValue in list(xJoints.items()):
        sValueEvaled = utils.evalValueFromString(sValue)
        if isinstance(sValueEvaled, (list, tuple, np.ndarray)):
            xJoints[sKey] = '; '.join(sValueEvaled)

    # explode the lists in the values
    for sKey,sValue in list(xJoints.items()):
        sKeyEvaled = utils.evalValueFromString(sKey)
        if isinstance(sKeyEvaled, (list, tuple, np.ndarray)):
            for sK in sKeyEvaled:
                xJoints[sK] = sValue
            del xJoints[sKey]


    if _bResetSettings:
        patch.iMissingInfluencesForNext = None
        cmds.undoInfo(openChunk=True)
    try:
        for pSelected in _translateInput(_pSelection):
            report.report.resetProgress(5)

            if not bDisableIslandCheck:
                if len(pSelected.aIds) != pSelected.getTotalCount():
                    if len(pSelected.getIslands(bFullObject=False)) > 1:
                        if cmds.confirmDialog(m='There are more than one islands selected on %s. Continue?' % pSelected.getTransformName(),
                                              button=['yes', 'no']) == 'no':
                            continue

            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())

            sSkinCluster, sInfluences, aWeightsAtFirst = pSelected.getSkinCluster(
                sChooseSkinCluster=sConvertedChooseSkinCluster)
            if not sSkinCluster:
                sWarning = '%s doesn\'t have a skinCluster' % pSelected.getName()
                report.report.addLogText(sWarning)
                cmds.warning(sWarning)
                continue

            aNonZeroInfluences = patch._removeZeroInfluencesNumpy(aWeightsAtFirst, np.array(sInfluences))[1]
            setNonZeroInfluences = set(aNonZeroInfluences)
            xJointsSorted = {}
            report.report.incrementProgress()
            for sFromJoint in list(xJoints.keys()):
                sToInput = xJoints[sFromJoint].replace(' ', '')
                sFromJointLsAll = set(cmds.ls(sFromJoint, et='joint') + cmds.ls('*:%s' % sFromJoint, et='joint'))
                sFromJointsLsBound = list(sFromJointLsAll.intersection(setNonZeroInfluences))
                sFromJointsLsBound = [sJoint for sJoint in sFromJointsLsBound if '|' not in sJoint]
                if not sFromJointsLsBound:
                    if bJustLogForDebug:
                        cmds.warning(
                            '========= No joints found for "%s" (%s). Could also be clashing names (%s) ========='
                            % (sFromJoint, pSelected.getName(), ', '.join(sFromJointsLsBound)))
                    continue
                for sTo in sToInput.split(';'):
                    for sFromJointLs in sFromJointsLsBound:
                        if ',' in sTo:
                            sFind, sReplace = sTo.split(',')
                            if re.search(sFind, sFromJointLs):
                                sLsTextReplaced = re.sub(sFind, sReplace, sFromJointLs)
                                if iCheckMissingInfluences != patch.MissingInfluencesOptions.skipIfMissingInfluences or cmds.objExists(
                                        sLsTextReplaced):
                                    sTempList = xJointsSorted.get(sFromJointLs, [])
                                    sTempList += cmds.ls(sLsTextReplaced)
                                    xJointsSorted[sFromJointLs] = sTempList
                        else:
                            sToLs = cmds.ls(sTo, et='joint')
                            sTempList = xJointsSorted.get(sFromJointLs, [])
                            sTempList += sToLs
                            xJointsSorted[sFromJointLs] = sTempList
            for sKey, sValue in list(xJointsSorted.items()):
                sValue = list(set(sValue))
                if sValue:
                    xJointsSorted[sKey] = sValue
                else:
                    del xJointsSorted[sKey]

            if not xJointsSorted:
                cmds.warning('========= No joints found for mapping (%s) =========' % pSelected.getName())
                report.report.addLogText('\n\n========= NO JOINTS FOUND FOR MAPPING (%s) =========\n\n' % pSelected.getName())
                bAllDidStuff = False
                continue

            sFlattenedJoints = reduce((lambda x, y: x + y), list(xJointsSorted.values()))
            sFlattenedJoints = list(set(sFlattenedJoints))

            if bJustLogForDebug:
                return

            if pSelected.checkInfluences(sFlattenedJoints, iCheckMissingInfluences=iCheckMissingInfluences,
                                         sChooseSkinCluster=sConvertedChooseSkinCluster) == \
                    patch.CheckInfluencesResult.influencesStillMissing:
                raise Exception('influences missing')

            report.report.incrementProgress()

            sSkinCluster, sInfluences, aWeights = pSelected.getSkinCluster(
                sChooseSkinCluster=sConvertedChooseSkinCluster)
            report.report.incrementProgress()

            aWeightsOld = np.copy(aWeights)
            aWeightsSwapped = aWeights.swapaxes(0, 1)
            aWeightsSwappedBefore = np.copy(aWeightsSwapped)
            dInfDict = dict(list(zip(sInfluences, range(len(sInfluences)))))
            for sKeyJoint in list(xJointsSorted.keys()):
                sToJoints = xJointsSorted[sKeyJoint]
                iFromJoint = dInfDict[sKeyJoint]

                iToJointsCount = len(sToJoints)
                aSetWeights = np.zeros((iToJointsCount, len(pSelected.aIds)), dtype='float64')

                if len(sToJoints) == 1:
                    iClosestJoints = np.zeros(len(pSelected.aIds), dtype='float64')
                else:
                    iClosestJoints = xforms.findClosestJointsToPatchComponents(pSelected, sToJoints, bJointLines=iJointLines>0,
                                                                               bIncludeChildrenNotInInputJoints=iJointLines==JointLines.YesAndIncludeChildrenNotInInputForClosestJoints,
                                                                               sProjectAttrs=['skinParent'] if bProjectSquashToMainJoints else [])

                for i, sToJoint in enumerate(sToJoints):
                    aVertsForToJoint = np.array(np.where(iClosestJoints == i)[0], dtype=int)
                    aSetWeights[i, aVertsForToJoint] += aWeightsSwappedBefore[iFromJoint, aVertsForToJoint]
                    aWeightsSwapped[iFromJoint, aVertsForToJoint] -= aWeightsSwappedBefore[iFromJoint, aVertsForToJoint]

                # smooth
                if len(sToJoints) > 1 and iSmoothSteps > 0:
                    aSetWeights = aSetWeights.T
                    aSumsBefore = np.sum(aSetWeights, axis=1)
                    aSetWeights = pSelected.smoothValues2d(aSetWeights, iIterations=iSmoothSteps)
                    aSumAfter = np.sum(aSetWeights, axis=1)
                    aZeros = np.where(aSumAfter == 0)[0]
                    aSumAfter[aZeros] = 1
                    aSumsDenom = 1.0 / aSumAfter
                    aSetWeights *= aSumsBefore[:, np.newaxis] * aSumsDenom[:, np.newaxis]
                    aSetWeights = aSetWeights.T

                for i, sToJoint in enumerate(sToJoints):
                    iToJoint = dInfDict[sToJoint]
                    aWeightsSwapped[iToJoint] += aSetWeights[i]

            report.report.incrementProgress()

            pSelected.setSkinClusterWeights(aWeights, sInfluences, aOldWeights2d=aWeightsOld,
                                            xDistanceMeshes=xDistanceMeshes,
                                            iBorderEdges=iBorderEdges, iSmoothBorderMask=iSmoothBorderMask,
                                            fBlend=fBlend*fStrength, iJointLocks=iJointLocks,
                                            sChooseSkinCluster=sConvertedChooseSkinCluster, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)
    except:
        raise
    finally:
        if _bResetSettings:
            patch.iMissingInfluencesForNext = None
            cmds.undoInfo(closeChunk=True)

    if not bAllDidStuff:
        return False


# =================
# Prune
# =================

class PruneIslands():
    pruneEverything = 0
    prunePerIsland = 1
    prunePerIslandKeepBiggest = 2


dControls = {}
dControls['iIslands'] = controls.RadioButtonsControl(PruneIslands)


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Prune', sRunButton='Prune', dControls=dControls,
                  tRefreshControlsAfterRun=[], bAddDefaultButton=True, sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#prune')
def pruneSkinCluster(_pSelection=None, fValue=0.001, iIslands=PruneIslands.prunePerIsland,
                     iJointLocks=patch.JointLocks.ignore, sChooseSkinCluster=None,
                     iBorderEdges=patch.BorderEdges.doEverything, iSmoothBorderMask=5, fBlend=1.0,
                     xDistanceMeshes=['', 0, 0]):
    '''
    By default simply removes values below what's specified in Value.
    Pruning by island separates the weights for each joint into
    islands of weights. And only prunes if all weights of that island
    are below the Value. This let's you smooth with a higher value and
    still remain the smoothness of the weights.
    '''

    # _validateChooseSkinCluster(sChooseSkinCluster)

    for pSelected in _translateInput(_pSelection):

        sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pSelected.getName())
        _, sInfluences, aWeights2d = pSelected.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)

        aInfluencesFiltered = np.array(sInfluences)
        aJointIdsFiltered = np.arange(len(sInfluences))
        if iJointLocks:

            iLocks = [cmds.getAttr('%s.liw' % sI) for sI in sInfluences]
            bLocks = np.array(iLocks, dtype=bool)

            aInfluencesFiltered = aInfluencesFiltered[-bLocks]
            aJointIdsFiltered = aJointIdsFiltered[-bLocks]
            aWeightsFiltered = aWeights2d[:, aJointIdsFiltered]  # changed from aWeights to aWeights2d - to be tested!
        else:
            aWeightsFiltered = np.copy(aWeights2d)

        if iIslands == PruneIslands.pruneEverything:
            aWeightsFiltered[aWeightsFiltered <= fValue] = 0
        else:
            bKeepAtLeastOne = True if iIslands == PruneIslands.prunePerIslandKeepBiggest else False
            aIslands = _getIslandsWeights(pSelected, aWeightsFiltered)

            aPrunedVertexCounts = np.zeros(len(aInfluencesFiltered), dtype=int)
            aPrunedIslandsCounts = np.zeros(len(aInfluencesFiltered), dtype=int)
            aTotalVertexCount = np.zeros(len(aInfluencesFiltered), dtype=int)
            aTotalIslandsCounts = np.zeros(len(aInfluencesFiltered), dtype=int)
            aHighestPrunedValue = np.zeros(len(aInfluencesFiltered), dtype='float64')
            for iJoint in range(len(aInfluencesFiltered)):
                aIslandsJoint = aIslands[iJoint]
                iIslandCount = np.max(aIslandsJoint)
                fMaxes = []
                xInds = []

                for i in range(iIslandCount):

                    aInds = np.where(aIslandsJoint == (i + 1))[0]
                    if aInds.size == 0:
                        continue

                    aTotalVertexCount[iJoint] += len(aInds)
                    aTotalIslandsCounts[iJoint] += 1

                    fMax = np.max(aWeightsFiltered[aInds, iJoint])
                    fMaxes.append(fMax)
                    xInds.append(aInds)

                aMaxIslandSort = np.argsort(list(fMaxes))
                for i in range(iIslandCount):
                    if fMaxes[aMaxIslandSort[i]] >= fValue:
                        break
                    if bKeepAtLeastOne and i == iIslandCount - 1:
                        break
                    aInds = xInds[aMaxIslandSort[i]]
                    aPrunedIslandsCounts[iJoint] += 1
                    aPrunedVertexCounts[iJoint] += len(aInds)
                    aHighestPrunedValue[iJoint] = max(aHighestPrunedValue[iJoint], fMaxes[aMaxIslandSort[i]])
                    aWeightsFiltered[aInds, iJoint] = 0

            aMaxVertexSort = np.argsort(aPrunedVertexCounts)[::-1]
            for i in range(len(aInfluencesFiltered)):
                iJoint = aMaxVertexSort[i]
                if aPrunedVertexCounts[iJoint] == 0:
                    break
                sHighestPrunedValueText = '- highest pruned value: %s' % str(aHighestPrunedValue[iJoint]) if \
                aPrunedVertexCounts[iJoint] else ''
                report.report.addLogText('## pruned %d from %d vertices (%d from %d islands) for joint "%s" %s' %
                                   (aPrunedVertexCounts[iJoint], aTotalVertexCount[iJoint],
                                    aPrunedIslandsCounts[iJoint], aTotalIslandsCounts[iJoint],
                                    aInfluencesFiltered[iJoint], sHighestPrunedValueText))

        # normalize
        #
        aWeights2d[:, aJointIdsFiltered] = aWeightsFiltered

        aSumsDenom = 1 / np.sum(aWeights2d, axis=1)
        aWeights2d *= aSumsDenom[:, np.newaxis]

        pSelected.setSkinClusterWeights(aWeights2d, iJointLocks=iJointLocks, iBorderEdges=iBorderEdges,
                                        iSmoothBorderMask=iSmoothBorderMask, fBlend=fBlend,
                                        xDistanceMeshes=xDistanceMeshes, sChooseSkinCluster=sConvertedChooseSkinCluster)


def _getIslandsWeights(pPatch, aWeights2d):
    aReturnIslands = np.zeros((aWeights2d.shape[1], aWeights2d.shape[0]), dtype=int)

    iNeighbors = pPatch.getNeighbors()
    iTotalVertexCount = pPatch.getTotalCount()
    aAllIdsMapper = np.empty(iTotalVertexCount, dtype=int)
    aAllIdsMapper.fill(-1)
    aAllIdsMapper[pPatch.aIds] = np.arange(len(pPatch.aIds))

    # use iNeighbors to move indices to where they are connected to
    #
    for iJoint in range(len(aReturnIslands)):
        aIdsJoint = np.nonzero(aWeights2d[:, iJoint])[0]

        iIslands = [list(iNeighbors[i]) for i in aIdsJoint]
        aIdsMapper = np.empty(iTotalVertexCount, dtype=int)
        aIdsMapper.fill(-1)
        aIdsMapper[pPatch.aIds[aIdsJoint]] = np.arange(len(aIdsJoint))

        for i, aId in enumerate(aIdsJoint):
            if not iIslands[i]:
                continue
            c = 0
            while c < len(iIslands[i]):
                index = iIslands[i][c]
                indexMapped = aIdsMapper[index]
                if indexMapped != -1 and iIslands[indexMapped] and index != pPatch.aIds[aId]:
                    iIslands[i] += iIslands[indexMapped]
                    iIslands[indexMapped] = []
                c += 1

        iSetValue = 1
        for iIslandExpanded in iIslands:
            if not iIslandExpanded:
                continue
            aIslandExpanded = np.unique(np.array(iIslandExpanded, dtype=int))
            aIsland = np.intersect1d(aIslandExpanded, pPatch.aIds[aIdsJoint])
            aReturnIslands[iJoint][aAllIdsMapper[aIsland]] = iSetValue
            iSetValue += 1

    return aReturnIslands



@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='MaxInf', sRunButton='Check', tRefreshControlsAfterRun=[])
def checkMaxInfluences(_pSelection=None, iMaxInfluences=4, sChooseSkinCluster=None):
    for pMesh in _translateInput(_pSelection):
        _, _, aWeights2d = pMesh.getSkinCluster(sChooseSkinCluster=sChooseSkinCluster)
        iVertCount = 0
        for iVert in range(len(aWeights2d)):
            iCurrentCount = len(np.where(aWeights2d[iVert] > 0.0000001)[0])
            if iCurrentCount > iMaxInfluences:
                report.report.addLogText('%s.vtx[%d] has more than %d influences (%d)' % (pMesh.getTransformName(), iVert, iMaxInfluences, iCurrentCount), bPrint=True)
                iVertCount += 1

        if iVertCount == 0:
            report.report.addLogText('=== %s is all good ===' % pMesh.getTransformName(), bPrint=True)
        else:
            report.report.addLogText('=== %s has %d vertices with more than maximum influences ===' % (pMesh.getTransformName(), iVertCount), bPrint=True)


@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='MaxInf', sRunButton='Reduce', tRefreshControlsAfterRun=[],
                    sDocumentationLink='https://kangaroobuilder.com/tools/toolsSkinCluster/#maxinf')
def reduceInfluences(_pSelection=None, iMaxInfluences=4, sChooseSkinCluster=None, _bSkipDeformerAdjustLogging=False):
    '''
    This makes sure that each vertex has only a specific amount of influences.
    == only works on full meshes (no vertex selection) ==
    '''
    for pMesh in _translateInput(_pSelection):
        report.report.addLogText('checking "%s"...' % pMesh.getTransformName())
        _, sInfluences, aWeights2d = pMesh.getSkinCluster(sChooseSkinCluster=sChooseSkinCluster)
        iInfCount = len(sInfluences)
        if iInfCount > iMaxInfluences:
            aRemoveInfluences2d = np.argsort(aWeights2d, axis=1)[:, np.arange(iInfCount - iMaxInfluences)]
            aWeights2d[np.arange(len(aWeights2d))[:, np.newaxis], aRemoveInfluences2d] = 0.0
            aNewSums = np.sum(aWeights2d, axis=1)
            aWeights2d /= aNewSums[:, np.newaxis]
            pMesh.setSkinClusterWeights(aWeights2d, sChooseSkinCluster=sChooseSkinCluster, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)



@uiSettings.addToUI(sTab='SkinCluster', sModuleButton='Normalize', sRunButton='Normalize', tRefreshControlsAfterRun=[])
def normalizeWeights(_pSelection=None, sChooseSkinCluster=None, _bSkipDeformerAdjustLogging=False):
    '''
    Nothing fancy, just does what the maya normalize does, except that you can choose a specific skinCluster
    == only works on full meshes (no vertex selection) ==
    '''
    for pMesh in _translateInput(_pSelection):
        sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, pMesh.getTransformName())

        _, sInfluences, aWeights2d = pMesh.getSkinCluster(sChooseSkinCluster=sConvertedChooseSkinCluster)
        aWeights2d = np.maximum(0, aWeights2d)
        aDenoms = 1.0 / np.sum(aWeights2d, axis=-1)
        aWeights2d *= aDenoms[:,np.newaxis]
        pMesh.setSkinClusterWeights(aWeights2d, sChooseSkinCluster=sConvertedChooseSkinCluster, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)



def skinCurveBSpline4(pCurve, sJoints, bStrongEnds=False, sChooseSkinCluster=None, iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences):
    '''
    the joints need to be in the correct order!!
    '''
    aJointCvIds = xforms.findClosestPoints(xforms.getPositionArray(sJoints), pCurve.getPoints())
    aWeights2d = np.zeros((pCurve.getTotalCount(), len(sJoints)), dtype='float64')

    for i in range(len(sJoints) - 1):
        iStart = aJointCvIds[i]
        if i == 0:
            aWeights2d[0:iStart, 0] = 0

        iEnd = aJointCvIds[i + 1]
        aSplineValues = utils.bSpline4([0, 0, 1, 1], aValues=np.linspace(0, 1.0, num=iEnd - iStart, endpoint=False))
        aWeights2d[np.arange(iStart, iEnd, 1), i] = 1.0 - aSplineValues
        aWeights2d[np.arange(iStart, iEnd, 1), i + 1] = aSplineValues


    aWeights2d[iEnd:, -1] = 1.0

    if bStrongEnds:
        aWeights2d[1, :] = 0.0
        aWeights2d[1, 0] = 1.0
        aWeights2d[-2, :] = 0.0
        aWeights2d[-2, -1] = 1.0
    pCurve.setSkinClusterWeights(aWeights2d, sJoints, sChooseSkinCluster=sChooseSkinCluster, iCheckMissingInfluences=iCheckMissingInfluences, _bSkipDeformerAdjustLogging=True)
    return aWeights2d


def skinCurveLinear(pCurve, sJoints):
    aJointCvIds = xforms.findClosestPoints(xforms.getPositionArray(sJoints), pCurve.getPoints())
    aWeights2d = np.zeros((pCurve.getTotalCount(), len(sJoints)), dtype='float64')

    for i in range(len(sJoints) - 1):
        iStart = aJointCvIds[i]
        iEnd = aJointCvIds[i + 1]
        # aSplineValues = utils.bSpline4([0, 0, 1, 1], aValues=)
        aSplineValues = np.linspace(0, 1.0, num=iEnd - iStart, endpoint=False)
        aWeights2d[np.arange(iStart, iEnd, 1), i] = 1.0 - aSplineValues
        aWeights2d[np.arange(iStart, iEnd, 1), i + 1] = aSplineValues
    aWeights2d[-1, -1] = 1.0
    pCurve.setSkinClusterWeights(aWeights2d, sJoints)



def createWhiskerJointsMesh(sBody, sWhiskers, sSide='m', sParent=None, bSkin=False):
    pWhiskers = patch.patchFromName(sWhiskers)
    pBody = patch.patchFromName(sBody)

    iiIslands = pWhiskers.getIslands()
    aVerts = pWhiskers.getAllPoints(bWorld=True)

    mPoints, iIntersectionEdges = pBody.getEdgeIntersections(pWhiskers)
    if mPoints:
        aPoints = np.array(mPoints, dtype='float64')[:, 0:3]
        aIntersectionEdges = np.array(iIntersectionEdges, dtype=int)
        aMapEdges = np.zeros(np.max(aIntersectionEdges) + 1, dtype=int)
        aMapEdges[aIntersectionEdges] = np.arange(len(aIntersectionEdges))

        fMeans = []

        if len(iiIslands) > 1:  # polys (curves and surfaces wouldn't fall into that since they only have one island)
            aVertexEdges = utils.numpify2dList(pWhiskers.getAllVertexEdges())

        for i, iIsland in enumerate(iiIslands):
            aIsland = np.array(iIsland, dtype=int)
            if len(
                    iiIslands) > 1:  # polys (curves and surfaces wouldn't fall into that since they only have one island)
                aIslandEdges = np.unique(aVertexEdges[aIsland].flatten())
                aIslandIntersectionEdges = np.intersect1d(aIntersectionEdges, aIslandEdges,
                                                          assume_unique=True)
            else:  # curves or surfaces
                aIslandIntersectionEdges = aIntersectionEdges
            if len(aIslandIntersectionEdges):
                aIslandIntersectionEdges = np.array(aIslandIntersectionEdges, dtype=int)
                aIndices = aMapEdges[aIslandIntersectionEdges]
                aIslandPoints = aPoints[aIndices]
                aMean = np.average(aIslandPoints, axis=0)
            else:
                aMean = np.mean(aVerts[aIsland], axis=0)
            fMeans.append(aMean)

    else:
        fMeans = []
        for i, iIsland in enumerate(iiIslands):
            aIsland = np.array(iIsland, dtype=int)
            fMeans.append(np.mean(aVerts[aIsland], axis=0))

    sJoints = []
    for j,fM in enumerate(fMeans):
        sJ = 'jnt_%s_%s_%03d' % (sSide,sWhiskers,j)
        if cmds.objExists(sJ):
            utils.parentTo(sJ, sParent)
            xforms.resetJoint(sJ)
        else:
            cmds.createNode('joint', n=sJ, p=sParent)
        cmds.move(fM[0], fM[1], fM[2], sJ, a=True, ws=True)
        sJoints.append(sJ)
    deformers.resetJointReferences(sJoints)

    if bSkin:
        sSkinCluster = 'skinCluster__%s' % sWhiskers
        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sWhiskers, sJoints, sName=sSkinCluster)
        aaWeights = np.zeros((pWhiskers.getTotalCount(), len(iiIslands)), dtype='float64')
        for i, iIsland in enumerate(iiIslands):
            aIsland = np.array(iIsland, dtype=int)
            aaWeights[aIsland, i] = 1.0

        pWhiskers.setSkinClusterWeights(aaWeights, sInfluences=sJoints, sChooseSkinCluster=sSkinCluster,
                                        iCheckMissingInfluences=patch.MissingInfluencesOptions.askToAddOrCreateInfluences)

    return sJoints



def createWhiskerJointsCurves(sBody, sWhiskerCurves, sSide='m', sName='whiskers', sParent=None, bSkin=False):
    sWhiskerCurves = utils.toList(sWhiskerCurves)

    pBody = patch.patchFromName(sBody)

    sJoints = []

    for j, sCurve in enumerate(sWhiskerCurves):
        print('=================== sCurve: ', sCurve)
        pCurve = patch.patchFromName(sCurve)


        mPoints, iIntersectionEdges = pBody.getEdgeIntersections(pCurve)
        print('mPoints: ', mPoints)
        if len(mPoints):
            aIntersectionPoint = [mPoints[0].x, mPoints[0].y, mPoints[0].z]
        else:
            aIntersectionPoint = cmds.xform('%s.cv[0]' % sCurve, q=True, ws=True, t=True)

        sJ = 'jnt_%s_%s%s_%03d' % (sSide,sName, utils.getFirstLetterUpperCase(sCurve), j)
        if cmds.objExists(sJ):
            cmds.parent(sJ, sParent)
            xforms.resetJoint(sJ)
        else:
            cmds.createNode('joint', n=sJ, p=sParent)

        cmds.move(aIntersectionPoint[0], aIntersectionPoint[1], aIntersectionPoint[2], sJ, a=True, ws=True)
        sJoints.append(sJ)
        deformers.resetJointReferences(sJoints)

        if bSkin:
            deformers.skinMesh(sCurve, [sJ], bAlwaysAddDefaultWeights=True)

    return sJoints



def simpleTransferValues(sFrom, sTo, aValues):
    aMapVerts, aCoords, _ = barycentric.getVertexCoordinates(patch.patchFromName(sFrom),
                                                             patch.patchFromName(sTo), bClosestVertex=False)
    aNewValues = np.sum(aValues[aMapVerts] * aCoords, axis=-1)
    return aNewValues



def checkBeforeNewScene(sExportFolder):
    # check if deformers changed
    sChangedDeformedMeshes = utils.data.get('sChangedDeformedMeshes', xDefault=[])
    if sChangedDeformedMeshes:
        sButtons = ['yes, no need to export', 'no, cancel', 'export deformers and continue']

        sMeshesString = []
        sChangedMeshes = []
        for sMeshDeformer in sChangedDeformedMeshes:
            sM,sDef = sMeshDeformer.split('.')
            if cmds.objExists(sDef) and not sDef.startswith('autoTransferredSkinCluster'):
                sMeshesString.append('%s (%s)' % (sM,sDef))
                sChangedMeshes.append(sM)

        if sMeshesString:
            sForSelect = [sMeshDeformer.split('.')[0] for sMeshDeformer in sChangedDeformedMeshes]
            cmds.select([sObj for sObj in sForSelect if cmds.objExists(sObj)])
            cmds.refresh()
            iMeshesCount = len(set(sChangedMeshes))
            sReturnButton = cmds.confirmDialog(m='Those meshes (%d) have unexported deformers. Sure you want to rebuild?\n%s' % (iMeshesCount, utils.listToString(sMeshesString, iMaxCount=10)), button=sButtons)
            if sReturnButton == sButtons[1]:
                raise Exception('creating new scene stopped by user')
            elif sReturnButton == sButtons[2]:
                sMeshes = [sMeshDeformer.split('.')[0] for sMeshDeformer in sChangedDeformedMeshes]
                exportDeformers([patch.patchFromName(sM) for sM in sMeshes], sFolder=sExportFolder)
