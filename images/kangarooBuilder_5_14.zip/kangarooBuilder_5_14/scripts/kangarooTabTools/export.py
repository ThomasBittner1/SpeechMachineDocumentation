###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import math

import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim2
import shutil
import os
import wave
import time
import pickle
import numpy as np
import json
import subprocess
import kangarooTools.report as report
import kangarooTools.utilFunctions as utils
import kangarooTools.uiSettings as uiSettings
import kangarooTools.controls as controls
import kangarooTools.nodes as nodes
import kangarooTools.patch as patch
import kangarooTools.assets as assets
import kangarooTabTools.ctrls as ctrls
import kangarooTools.utilsQt as utilsQt







dControls = {}
dControls['sProject'] = controls.ProjectsControl(assetsModule=assets)
@uiSettings.addToUI(sTab='Export', sModuleButton='NEW', sRunButton='Create', dControls=dControls, bDisableOnServer=False,
                    sDocumentationLink='https://kangaroobuilder.com/gettingStarted/#templates')
def createNewCharacter(sProject='', sName='', bCopyModel=True, bEnforceUpperCase=True):
    if not sName:
        raise Exception('asset name not specified')
    if bEnforceUpperCase:
        sName = sName.upper()


    sAssetRoot = assets.getLocalAssetRoot()
    sCurrentProject = assets.getCurrentProject()

    if assets.getCurrentProject() != sProject:
        if cmds.confirmDialog(m='You are copying between different projects - from "%s" to "%s". Are you sure?' %
                                (assets.projectNameNice(sCurrentProject), assets.projectNameNice(sProject)),
                                button=['yes', 'no']) == 'no':
            return


    if not sAssetRoot:
        raise Exception('no asset root specified')

    sNewFolder = os.path.join(sAssetRoot, sProject, sName)
    if os.path.exists(sNewFolder):
        raise Exception ('folder %s already exists' % sNewFolder.replace('\\', '/'))

    sCurrentAsset = assets.assetManager.getCurrentAsset()

    report.report.resetProgress(2)
    report.report.addLogText('\ncopying %s to new folder (%s)' % (sCurrentAsset,sNewFolder))
    os.makedirs(sNewFolder)
    sNewVersionFolder = os.path.join(sNewFolder, '_build', 'v0')

    sCurrentVersionPath = assets.assetManager.getCurrentVersionPath()
    print('sCurrentVersionPath: ', sCurrentVersionPath)

    utilsQt.copyWithProgressBar(sCurrentVersionPath, sNewVersionFolder, 'copy to new version')
    # shutil.copytree(sCurrentVersionPath, sNewVersionFolder)
    report.report.incrementProgress()

    report.report.addLogText('\nrcreate __init__.py files')
    open(os.path.join(sNewFolder, '__init__.py'), 'a').close()
    open(os.path.join(sNewFolder, '_build', '__init__.py'), 'a').close()

    report.report.addLogText('\ntext replacing python file in build.bld')
    utils.searchReplaceFile(os.path.join(sNewVersionFolder, 'build.bld'),
                            '%s.py' % sCurrentAsset, '%s.py' % sName)

    report.report.addLogText('\ncreate missing _model and _publish folder and rename %s.py' % (sCurrentAsset))
    sModelFirstVersionDir = os.path.join(sNewFolder, '_model', 'v0')

    os.makedirs(sModelFirstVersionDir)
    if bCopyModel:
        sBuildFile = os.path.join(sCurrentVersionPath, 'build.bld')
        with open(sBuildFile) as file:
            dBuildData = json.load(file)
        dDatas = dBuildData['__FUNCTIONDATAS__']

        try:
            sModelVersionString = dDatas['importModel']['dFileArgs']['sVersion']
        except:
            sModelVersionString = '__latest__'
        sCurrentModelVersionFolder = assets.assetManager.getModelPath(sCurrentAsset, sModelVersionString)
        for sF in os.listdir(sCurrentModelVersionFolder):
            if sF == '.mayaSwatches':
                continue
            sContent = os.path.join(sCurrentModelVersionFolder,sF)
            if os.path.isfile(sContent):
                shutil.copy(sContent, sModelFirstVersionDir)
            else:
                shutil.copytree(sContent, os.path.join(sModelFirstVersionDir,sF))

    os.makedirs(os.path.join(sNewFolder, '_published'))

    sPycFiles = utils.listFilesInFolder(sNewVersionFolder, sEndswith=['.pyc'], bAbsolute=True)
    [os.remove(sF) for sF in sPycFiles]
    sAssetPythonFile = os.path.join(sNewVersionFolder, '%s.py' % sCurrentAsset)

    if os.path.exists(sAssetPythonFile):
        os.rename(sAssetPythonFile, os.path.join(sNewVersionFolder, '%s.py' % sName))

    assets.assetManager.fillProjects(sSwitchAssetTo=sName, sSwitchProjectTo=sProject)

    assets.checkServerBox(False)
    assets.refresh()

    report.report.incrementProgress()



def _makeNewModelPath(bReturnVersion=False):
    sRootFolder = os.path.join(assets.assetManager.getCurrentAssetPath(), '_model')
    sCurrents = os.listdir(sRootFolder)
    iNumbers = [utils.getNumberAtEnd(sF.split('_')[0])[1] for sF in sCurrents]
    if iNumbers:
        iNewVersion = max(iNumbers) + 1
    else:
        iNewVersion = 0
    sNewVersion = 'v%d' % iNewVersion
    sNewPath = os.path.join(sRootFolder, sNewVersion)
    os.makedirs(sNewPath)
    if bReturnVersion:
        return sNewPath, sNewVersion
    else:
        return sNewPath


dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MODEL', sRunButton='Save New Version', dControls=dControls, bDisableOnServer=True,
                    sDocumentationLink='https://kangaroobuilder.com/builder/builderGeneral/#importmodel')
def publishSaveModel(bRemoveRequiresLines=False):
    sNewPath, sVersion = _makeNewModelPath(bReturnVersion=True)
    sFile = os.path.join(sNewPath, '%s_model_%s.ma' % (assets.assetManager.getCurrentAsset(), sVersion))
    report.report.addLogText('saving to: %s' % sFile)
    cmds.file(rename=sFile)
    cmds.file(force=True, type='mayaAscii', save=True)
    if bRemoveRequiresLines:
        sRemoveResult = utils.removeRequiresLines(sFile)
        report.report.addLogText(sRemoveResult)


dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MODEL', sRunButton='Export Selected to New Version', dControls=dControls, bDisableOnServer=True)
def publishExportModel(bRemoveRequiresLines=False):
    sNewPath, sVersion = _makeNewModelPath(bReturnVersion=True)
    sFile = os.path.join(sNewPath, '%s_model_%s.ma' % (assets.assetManager.getCurrentAsset(), sVersion))
    report.report.addLogText('exporting to: %s' % sFile)
    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    if bRemoveRequiresLines:
        sRemoveResult = utils.removeRequiresLines(sFile)
        report.report.addLogText(sRemoveResult)


dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MODEL', sRunButton='Open Latest', dControls=dControls)
def openLatestModel():
    sModelPath = assets.assetManager.getModelPath(sAsset='__self__', sVersion='__latest__', bErrorIfNotExist=True)
    sFilesNames = utils.listFilesInFolder(sModelPath, bAbsolute=True, sEndswith=['.ma','.mb', '.obj', '.fbx'])
    cmds.file(sFilesNames[0], o=True, f=True, prompt=False, ignoreVersion=True)


dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MODEL', sRunButton='Explorer Latest', dControls=dControls)
def explorerLatestModel():
    sModelPath = assets.assetManager.getModelPath(sAsset='__self__', sVersion='__latest__', bErrorIfNotExist=True)
    print ('Explorer -> "%s"' % sModelPath)
    utils.openExplorer(sModelPath)



dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MODEL', sRunButton='Explorer New Version', dControls=dControls)
def explorerNewVersion():
    sNewPath = _makeNewModelPath()
    print ('Explorer -> "%s"' % sNewPath)
    utils.openExplorer(sNewPath)




dControls = {}
dControls['sFile'] = controls.FilePathControl('*.ma', sDefaultFileName='mayaImport\stuff.ma', bShowContent=True, sPossibleFileExtensions=utils.sMayaImportExtensions)
@uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Export Selected', dControls=dControls,
                    bDisableOnServer=True, bCheckAsset=True, sDocumentationLink='https://kangaroobuilder.com/builder/builderGeneral/#importmayafiles')
def exportToMayaImport(sFile='file', bConstructionHistory=False):
    sFolder = os.path.dirname(sFile)
    if not os.path.exists(sFolder):
        os.makedirs(sFolder)
    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=bConstructionHistory)


dControls = {}
dControls['sFile'] = controls.FilePathControl('*.ma', sDefaultFileName='mayaImport\stuff.ma', bShowContent=True, sPossibleFileExtensions=utils.sMayaImportExtensions)
@uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Remove Required Lines', dControls=dControls, bDisableOnServer=True, sToolTip='Removes all the "requires.." lines from the specified file. This is to make it open faster')
def removeRequiresLines(sFile='file', bConstructionHistory=False):
    sMessage = utils.removeRequiresLines(sFile)
    report.report.addLogText(sMessage)


dControls = {}
dControls['sFile'] = controls.FilePathControl('*.ma', sDefaultFileName='mayaImport\stuff.ma', bShowContent=True, sPossibleFileExtensions=utils.sMayaImportExtensions)
@uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Remove Required Lines Folder', dControls=dControls, bDisableOnServer=True, sToolTip='Removes all the "requires.." lines from the specified folder. This is to make it open faster')
def removeRequiresLinesFolder(sFile='file', bConstructionHistory=False):
    sFiles = utils.listFilesInFolder(os.path.dirname(sFile), bAbsolute=True, sEndswith=['.ma'])
    for sFile in sFiles:
        sFile = sFile.replace('\\', '/')
        report.report.addLogText('\n%s...' % sFile)
        sMessage = utils.removeRequiresLines(sFile)
        report.report.addLogText(sMessage)


# dControls = {}
# @uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Save', dControls=dControls, bDisableOnServer=True)
# def saveToMayaImport(sFile='file'):
#     cmds.file(rename=sFile)
#     cmds.file(force=True, type='mayaAscii', save=True)
#

dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Open', dControls=dControls)
def openFromMayaImport(sFile='file'):
    cmds.file(sFile, open=True, force=True, prompt=False)


dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Import', dControls=dControls)
def importFromMayaImport(sFile='file'):
    utils.importMayaFiles(sFile, sNamespace=None, bReference=False)


dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='MayaImp', sRunButton='Reference', dControls=dControls)
def referenceFromMayaImport(sFile='file'):
    utils.importMayaFiles(sFile, sNamespace='_%s_' % os.path.basename(sFile).split('.')[0], bReference=True)


dControls = {}
dControls['sFile'] = controls.FilePathControl('*.trg', sDefaultFileName=r'targets\\targets.trg', bReadOnly=False, bShowContent=True, sPossibleFileExtensions=['.trg'])
@uiSettings.addToUI(sTab='Export', sModuleButton='Targets', sRunButton='Export', dControls=dControls, bDisableOnServer=True,
                    bCheckAsset=True, sDocumentationLink='https://kangaroobuilder.com/builder/builderGeneral/#importtargets')
def exportTargets(sFile='file', bOneFilePerMesh=True):
    '''
    if you turn on one file per mesh (default), the file name in the field gets ignored. It'll only take the path \
    and creates the names from the meshes.
    '''
    sSel = cmds.ls(sl=True)
    pCurrentSelected = [patch.patchFromName(sS) for sS in sSel]

    if bOneFilePerMesh:
        sDir = os.path.dirname(sFile)
        xIter = [([pS],os.path.join(sDir, '%s.trg' % pS.getTransformName())) for pS in pCurrentSelected]
    else:
        xIter = [(pCurrentSelected, sFile)]

    for pSel, sCurrentFile in xIter:
        sStatus = '(new)' if not os.path.exists(sCurrentFile) else '(replace)'
        report.report.addLogText('exporting to file %s ... %s' % (sCurrentFile, sStatus), bRefresh=True)

        for pS in pSel:
            pS.aPoints = pS.getPoints(bWorld=False)

        sDir = os.path.dirname(sCurrentFile)
        if not os.path.exists(sDir):
            os.makedirs(sDir)

        dTargets = {} # keys are the mains

        for s, pS in enumerate(pSel):
            pMain = None
            for m, pM in enumerate(dTargets.keys()):
                if len(pM.aPoints) == len(pS.aPoints):
                    pMain = pM
                    break

            if pMain == None:
                dTargets[pS] = []
                continue

            dTargets[pMain].append(pS)

        xxSaveData = []

        for pM, pTargets in list(dTargets.items()):

            sTargetNames = []
            aTargetDiffIds = []
            aTargetDiffs = []
            for pT in pTargets:
                sTargetNames.append(pT.getTransformName())
                aDiffs = pT.aPoints - pM.aPoints
                aLengths = np.linalg.norm(aDiffs, axis=-1)
                aDiffIds = np.where(aLengths > 0.00001)[0]
                aTargetDiffIds.append(aDiffIds)
                aTargetDiffs.append(aDiffs[aDiffIds])

            dMain = {#'sName':pM.getTransformName(),
                     'recreateData': pM.recreateData(bOrigIfSameVertCount=False, bWorld=False),
                     'sTargetNames': sTargetNames,
                     'aTargetDiffIds': aTargetDiffIds,
                     'aTargetDiffs': aTargetDiffs}
            if not bOneFilePerMesh:
                dMain['sName'] = pM.getTransformName()


            xxSaveData.append(dMain)

        with open(sCurrentFile, 'wb') as handle:
            pickle.dump(xxSaveData, handle, protocol=2)
            # pickle.dump(xxSaveData, handle, protocol=pickle.HIGHEST_PROTOCOL)

        print('done saving to %s' % sCurrentFile)




dControls = {}
dControls['sFile'] = controls.FilePathControl('*.trg', sDefaultFileName=r'targets\targets.trg', bReadOnly=False, bShowContent=True, sPossibleFileExtensions=['.trg'])
@uiSettings.addToUI(sTab='Export', sModuleButton='Targets', sRunButton='Import', dControls=dControls)
def importTargets(sFile='file'):
    with open(sFile, 'rb') as handle:
        if utils.getPythonVersion() == 2:
            xxLoadData = pickle.load(handle)
        else:
            xxLoadData = pickle.load(handle, encoding='latin1')

        fnMesh = OpenMaya2.MFnMesh()
        sNewMeshes = []
        for xData in xxLoadData:
            recreateData = xData['recreateData']
            aPoints = recreateData['points']
            mPoints = utils.listToMPointArray(aPoints)
            aPolygonCounts = recreateData['polygonCounts']
            aPolygonConnects = recreateData['polygonConnects']
            fnMesh.create(mPoints, aPolygonCounts, aPolygonConnects)
            sNewMainMesh = cmds.listRelatives(fnMesh.partialPathName(), p=True)[0]
            sNewMainMesh = cmds.rename(sNewMainMesh, xData.get('sName', os.path.basename(sFile).split('.')[0]))
            sNewMeshes.append(sNewMainMesh)

            for sTarget, aDiffIds, aDiffs in zip(xData['sTargetNames'], xData['aTargetDiffIds'], xData['aTargetDiffs']):
                aTargetPoints = np.copy(aPoints)
                aTargetPoints[aDiffIds] += aDiffs
                fnMesh.create(utils.listToMPointArray(aTargetPoints), aPolygonCounts, aPolygonConnects)
                sNewMesh = cmds.listRelatives(fnMesh.partialPathName(), p=True)[0]
                sNewMesh = cmds.rename(sNewMesh, sTarget)
                sNewMeshes.append(sNewMesh)

        for sM in sNewMeshes:
            cmds.setAttr('%s.v' % sM, False)
            utils.addStringAttr(sM, 'sFromFile', sFile)
            utils.addStringAttr(sM, 'sAllMeshesInFile', ', '.join(sNewMeshes))

        cmds.select(sNewMeshes)
        cmds.hyperShade(assign='lambert1')


@uiSettings.addToUI(sTab='Export', sModuleButton='Delete', sRunButton='Delete Old Versions')
def deleteOldVersions(iKeepLast=3):
    '''
    if you have problems with your disk getting too full, you can use this to delete older versions. But use with caution!!
    '''
    sAssetRoot = assets.getCurrentAssetRoot()
    print ('sAssetRoot: ', sAssetRoot)
    sBuildFolder = os.path.join(sAssetRoot, '_build')
    sFolders = utils.listFoldersInFolder(sBuildFolder)

    sVersionFolders = []
    iNumbers = []
    for sFolder in sFolders:
        if sFolder.startswith('v'):
            sNumber = sFolder[1:]
            try:
                iNumber = int(sNumber)
            except:
                iNumber = None
            if iNumber != None:
                sVersionFolders.append(sFolder)
                iNumbers.append(iNumber)

    iSortedNumbers = np.argsort(iNumbers)[::-1]
    sSortedFolders = np.array(sVersionFolders)[iSortedNumbers]

    print ('sSortedFolders: ', sSortedFolders)


    if len(sFolders) < iKeepLast:
        cmds.confirmDialog(m='There are only %d version folders, but your limit is %d' % (len(sFolders), iKeepLast))
    else:
        sDeleteFolders = sSortedFolders[2:]
        sKeepFolders = sSortedFolders[:2]
        if cmds.confirmDialog(m='Keeping %s, but deleting:\n%s' % (utils.listToString(sKeepFolders), utils.listToString(sDeleteFolders)), button=['yes', 'no, abort']) == 'yes':
            for sFolder in sDeleteFolders:
                if sFolder:
                    sVersionFolder = os.path.join(sBuildFolder, sFolder)
                    report.report.addLogText('Deleting "%s"...' % sVersionFolder, bQuotationsToLink=False, bRefresh=True)
                    shutil.rmtree(sVersionFolder)


@uiSettings.addToUI(sTab='Export', sModuleButton='Delete', sRunButton='Delete _build versions')
def deleteOldVersionsBuild(iKeepLast=3):
    '''
    if you have problems with your disk getting too full, you can use this to delete older versions. But use with caution!!
    '''
    deleteOldVersions(sRootName='_build', iKeepLast=iKeepLast)


@uiSettings.addToUI(sTab='Export', sModuleButton='Delete', sRunButton='Delete _published versions')
def deleteOldVersionsPublished(iKeepLast=3):
    '''
    if you have problems with your disk getting too full, you can use this to delete older versions. But use with caution!!
    '''
    deleteOldVersions(sRootName='_published', iKeepLast=iKeepLast)


def deleteOldVersions(sRootName='_build', iKeepLast=3):
    sAssetRoot = assets.getCurrentAssetRoot()
    sParentFolder = os.path.join(sAssetRoot, sRootName)
    sFolders = utils.listFoldersInFolder(sParentFolder)

    sVersionFolders = []
    iNumbers = []
    for sFolder in sFolders:
        if sFolder.startswith('v'):
            sNumber = sFolder[1:]
            try:
                iNumber = int(sNumber)
            except:
                iNumber = None
            if iNumber != None:
                sVersionFolders.append(sFolder)
                iNumbers.append(iNumber)

    iSortedNumbers = np.argsort(iNumbers)[::-1]
    sSortedFolders = np.array(sVersionFolders)[iSortedNumbers]

    print ('sSortedFolders: ', sSortedFolders)


    if len(sSortedFolders) <= iKeepLast:
        cmds.confirmDialog(m='There are only %d version folders, and your limit is %d' % (len(sSortedFolders), iKeepLast))
    else:
        sDeleteFolders = sSortedFolders[iKeepLast:]
        sKeepFolders = sSortedFolders[:iKeepLast]
        if cmds.confirmDialog(m='%s:\nKeeping %s, but deleting:\n%s' % (sParentFolder, utils.listToString(sKeepFolders), utils.listToString(sDeleteFolders)), button=['yes', 'no, abort']) == 'yes':
            for sFolder in sDeleteFolders:
                if sFolder:
                    sVersionFolder = os.path.join(sParentFolder, sFolder)
                    report.report.addLogText('Deleting "%s"...' % sVersionFolder, bQuotationsToLink=False, bRefresh=True)
                    shutil.rmtree(sVersionFolder)





dControls = {}
@uiSettings.addToUI(sTab='Export', sModuleButton='Anim', sRunButton='Import Keys', dControls=dControls,
                    sDocumentationLink='https://kangaroobuilder.com/animationTools/#saveload-animation')
def importAnimation(sFile='file', sNamespace='', bAdditiveOnLoad=False, bShowProgress=False):
    '''
    Exports/Imports animations. Don\'t forget to set the namespace on either exporting and importing!\n
    To see which files are there right now, right click on the file name. Which btw is a great way
    to see if your last export was successful, by looking at the file size.
    '''

    cmds.undoInfo(openChunk=True)
    try:
        print('loading json file %s...' % sFile)
        
        iAttributestoNextUpdate = 200
        with open(sFile) as file:

            dAnim = json.load(file)
            bApi2 = 'API2' in dAnim
            fMinTime = dAnim.get('minTime', None)
            fMaxTime = dAnim.get('maxTime', None)
            
            if not utils.isNone(fMinTime):
                cmds.playbackOptions(e=True, minTime=fMinTime, maxTime=fMaxTime)

            if bShowProgress:
                report.report.resetProgress(len(dAnim) / iAttributestoNextUpdate)
                iCounter = -1

            sMissingAttrsNode = '%s__missingAnimatedAttrsNode__' % sNamespace
            if cmds.objExists(sMissingAttrsNode):
                cmds.delete(sMissingAttrsNode)
            cmds.createNode('transform', n=sMissingAttrsNode)
            utils.lockAndHide(sMissingAttrsNode, ['t','r','s','v'])

            fnAnimCurve = OpenMayaAnim2.MFnAnimCurve()

            for sAttr, xAnim in list(dAnim.items()):
                if bShowProgress:
                    iCounter += 1
                    if not iCounter % iAttributestoNextUpdate:
                        report.report.incrementProgress(sAttr)
                
                sMayaAttr = '%s%s' % (sNamespace, sAttr)
                if cmds.objExists(sMayaAttr):
                    bAttrExists = True
                else:
                    sMayaAttr = utils.addAttr(sMissingAttrsNode, ln=sAttr.replace('.','___'), k=True)
                    bAttrExists = False
                
                sNode = sMayaAttr.split('.')[0]
                sSkipAttrsAttr = '%s.%s' % (sNode, utils.kSkipKeyImportAttrs)
                sSkipAttrs = cmds.getAttr(sSkipAttrsAttr) if cmds.objExists(sSkipAttrsAttr) else []
                if sAttr.split('.')[-1] in sSkipAttrs:
                    continue
                
                
                if bAttrExists:
                    if not cmds.attributeQuery('bIsCtrl', node=sNode, exists=True) \
                        and not cmds.attributeQuery('ctrlType', node=sNode, exists=True) \
                        and not cmds.attributeQuery('bIsFeatureShape', node=sNode, exists=True):
                        continue
                    if not bAdditiveOnLoad:
                        sConnectedNodes = cmds.listConnections(sMayaAttr, s=True, d=False) or []
                        sAnimNodes = [sN for sN in sConnectedNodes if cmds.objectType(sN).startswith('animCurve')]
                        if sAnimNodes:
                            cmds.delete(sAnimNodes)

                if isinstance(xAnim, (float, bool, int)):
                    sConnections = cmds.listConnections(sMayaAttr, s=True, d=False)
                    if sConnections and not cmds.objectType(sConnections[0]).startswith('animCurve'):
                        print('attribute %s has a connection' % sMayaAttr)
                        report.report.addLogText('attribute %s has an incoming connection' % sMayaAttr)
                    elif cmds.getAttr(sMayaAttr, lock=True):
                        print('attribute %s is locked' % sMayaAttr)
                        # report.report.addLogText('attribute %s is locked' % sMayaAttr)
                    else:
                        try:
                            cmds.setAttr(sMayaAttr, xAnim)
                        except Exception as e: cmds.warning('not able to set %s. %s' % (sMayaAttr, e))
                elif isinstance(xAnim,  (list,tuple)): # old way
                    for fT, fV in zip(xAnim[0], xAnim[1]):
                        cmds.setKeyframe(sMayaAttr, t=fT, v=fV)
                elif isinstance(xAnim, dict): # new way
                    if bApi2:
                        # mPlug = utils.getPlug(sMayaAttr)
                        mAnimCurve = fnAnimCurve.create(xAnim['animCurveType'])
                        sAnimCurve = OpenMaya2.MFnDependencyNode(mAnimCurve).name()

                        fnAnimCurve.setIsWeighted(xAnim['isWeighted'])
                        fnAnimCurve.setPostInfinityType(xAnim['postInfinityType'])
                        fnAnimCurve.setPreInfinityType(xAnim['preInfinityType'])

                        fnAnimCurve.addKeysWithTangents(xAnim['fTimes'], xAnim['fValues'],
                                                        # tangentInType=xAnim['preInfinityType'],
                                                        # tangentOutType=xAnim['postInfinityType'],
                                                        tangentInTypeArray=xAnim['tangentInTypeArray'],
                                                        tangentOutTypeArray=xAnim['tangentOutTypeArray'],
                                                        tangentInXArray=xAnim['tangentInXArray'],
                                                        tangentInYArray=xAnim['tangentInYArray'],
                                                        tangentOutXArray=xAnim['tangentOutXArray'],
                                                        tangentOutYArray=xAnim['tangentOutYArray'],
                                                        tangentsLockedArray=xAnim['tangentsLockedArray'],
                                                        weightsLockedArray=xAnim['weightsLockedArray'],
                                                        convertUnits=False,
                                                        )

                        for i,fWeight in enumerate(xAnim['fInTangentAngleWeights']):
                            if fWeight != None:
                                fnAnimCurve.setWeight(i, fWeight, True)
                        for i,fWeight in enumerate(xAnim['fOutTangentAngleWeights']):
                            if fWeight != None:
                                fnAnimCurve.setWeight(i, fWeight, False)

                        sAnimCurve = cmds.rename(sAnimCurve, sMayaAttr.replace('.', '_'))
                        if cmds.getAttr(sMayaAttr, settable=True):
                            cmds.connectAttr('%s.output' % sAnimCurve, sMayaAttr, force=True)

                    else: # old and slow format
                        ffKeys = xAnim['ffKeys']
                        for fT, fV in zip(ffKeys[0], ffKeys[1]):
                            cmds.setKeyframe(sMayaAttr, t=fT, v=fV)
                        cmds.setInfinity(sMayaAttr, pri=xAnim['preInfinity'])
                        cmds.setInfinity(sMayaAttr, poi=xAnim['postInfinity'])

                        dTangents = xAnim.get('dTangents', None)
                        if dTangents:
                            dFlags = {}
                            for i in range(len(ffKeys[0])):
                                for sFlag in ['inAngle', 'outAngle', 'inWeight', 'outWeight', 'inTangentType', 'outTangentType']:
                                    dFlags[str(sFlag)] = dTangents[sFlag][i]
                                cmds.keyTangent(sMayaAttr, index=(i, i), **dFlags)
                else:
                    pass
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)





def moveAnimBackupFile(sFilePath):
    print ('move file: sFilePath: ', sFilePath)

    sBackupFileName = os.path.basename(sFilePath)
    sSplits = sBackupFileName.split('.')
    iUnderscore = sSplits[0].rfind('_')
    sMainFileName = '%s.%s' % (sSplits[0][:iUnderscore], sSplits[1])
    sMainFilePath = os.path.join(os.path.dirname(sFilePath), os.pardir, sMainFileName)
    sMainFilePath = os.path.normpath(sMainFilePath)


    print ('sMainFilePath: ', sMainFilePath)
    if not os.path.exists(sMainFilePath):
        raise Exception('couldn\'t find main file: %s' % sMainFilePath)

    utils.saveBackupFile(sMainFilePath, sFolderName='_animBackup')
    shutil.copy(sFilePath, sMainFilePath)
    report.report.addLogText('backup-ed "%s" and replaced it with chosen backup file' % sMainFilePath)


dControls = {}
dControls['sFile'] = controls.FilePathControl('*.anim', sDefaultFileName=r'anim\anim.anim', bReadOnly=False, bShowContent=True, sPossibleFileExtensions=['.anim'], dBackupFolder={'sDirName':'_animBackup', 'func':moveAnimBackupFile})
dControls['sNamespace'] = controls.NamespaceControl()
@uiSettings.addToUI(sTab='Export', sModuleButton='Anim', sRunButton='Export Keys', dControls=dControls, bDisableOnServer=True, bCheckAsset=True)
def exportAnimation(sFile='file', sNamespace='', bIgnoreNamespaceOnSave=True):
    # sNamespace and bIgnoreNamespaceOnSave is not tested yet!
    if os.path.exists(sFile):
        if cmds.confirmDialog(m='File "%s" already exists.\nOverwrite?' % sFile, button=['yes', 'no, abort']) != 'yes':
            return
        
    dSave = {}
    dSave['API2'] = True
    dSave['minTime'] = cmds.playbackOptions(q=True, minTime=True)
    dSave['maxTime'] = cmds.playbackOptions(q=True, maxTime=True)
    sShapes = set()
    
    
    dAllAttrs = {}
    for sCtrl in ctrls.getAllCtrlsInScene(sNamespace=sNamespace, bReturnNames=True):

        sNodes = [sCtrl]
        sFeatureAttr = '%s.featureShape' % sCtrl
        if cmds.objExists(sFeatureAttr):
            sPlug = cmds.listConnections(sFeatureAttr, p=True, d=False, s=True)[0]
            sShape = sPlug.split('|')[-1].split('.')[0]
            if sShape not in sShapes:
                sNodes.append(sShape)

        for sNode in sNodes:
            sAttrs = ['%s.%s' % (sNode, sA) for sA in utils._getAnimAttrsFromNode(sNode)]
            dAllAttrs.update({sA:sA for sA in sAttrs})


    sMissingAttrsNode = '%s__missingAnimatedAttrsNode__' % sNamespace
    if cmds.objExists(sMissingAttrsNode):
        dAllAttrs.update({sA.replace('___', '.'):'%s.%s' % (sMissingAttrsNode,sA) for sA in utils._getAnimAttrsFromNode(sMissingAttrsNode) if '___' in sA})



    for sKey, sA in dAllAttrs.items():
        if bIgnoreNamespaceOnSave:
            sKey = sKey.split(':')[-1]
        fTimes = cmds.keyframe(sA, q=True)
        if not fTimes:
            dSave[sKey] = cmds.getAttr(sA)
        else:
            sAnimNode = cmds.keyframe(sA, q=True, name=True)[0]

            fnAnimCurve = OpenMayaAnim2.MFnAnimCurve(utils.getDependNode(sAnimNode))

            fTimes = [fnAnimCurve.input(i).value for i in range(fnAnimCurve.numKeys)]
            fValues = [fnAnimCurve.value(i) for i in range(fnAnimCurve.numKeys)]

            tangentInTypeArray = [fnAnimCurve.inTangentType(i) for i in range(fnAnimCurve.numKeys)]
            tangentOutTypeArray = [fnAnimCurve.outTangentType(i) for i in range(fnAnimCurve.numKeys)]

            tangentInXYArray = [fnAnimCurve.getTangentXY(i, True) for i in range(fnAnimCurve.numKeys)]
            tangentOutXYArray = [fnAnimCurve.getTangentXY(i, False) for i in range(fnAnimCurve.numKeys)]

            tangentsLockedArray = [fnAnimCurve.tangentsLocked(i) for i in range(fnAnimCurve.numKeys)]
            weightsLockedArray = [fnAnimCurve.weightsLocked(i) for i in range(fnAnimCurve.numKeys)]


            fInTangentAngleWeights = []
            fOutTangentAngleWeights = []
            for i in range(fnAnimCurve.numKeys):
                xInAngleWeight = fnAnimCurve.getTangentAngleWeight(i, True)
                xOutAngleWeight = fnAnimCurve.getTangentAngleWeight(i, False)
                fInTangentAngleWeights.append(None if utils.isNone(xInAngleWeight) else xInAngleWeight[1])
                fOutTangentAngleWeights.append(None if utils.isNone(xOutAngleWeight) else xOutAngleWeight[1])


            dAttr = {'fTimes':fTimes,
                     'fValues':fValues,
                     'animCurveType':fnAnimCurve.animCurveType,
                     'preInfinityType':fnAnimCurve.preInfinityType,
                     'postInfinityType':fnAnimCurve.postInfinityType,
                     'tangentInTypeArray':tangentInTypeArray,
                     'tangentOutTypeArray':tangentOutTypeArray,
                     'tangentInXArray':[x for x,y in tangentInXYArray],
                     'tangentInYArray':[y for x,y in tangentInXYArray],
                     'tangentOutXArray':[x for x,y in tangentOutXYArray],
                     'tangentOutYArray':[y for x,y in tangentOutXYArray],
                     'tangentsLockedArray':tangentsLockedArray,
                     'weightsLockedArray':weightsLockedArray,
                     'fInTangentAngleWeights':fInTangentAngleWeights,
                     'fOutTangentAngleWeights':fOutTangentAngleWeights,
                     'isWeighted':fnAnimCurve.isWeighted,
                     }

            dSave[sKey] = dAttr


    sDir = os.path.dirname(sFile)
    if not os.path.exists(sDir):
        os.makedirs(sDir)

    if os.path.exists(sFile):
        utils.saveBackupFile(sFile, sFolderName='_animBackup')

    with open(sFile, 'w') as fp:
        json.dump(dSave, fp, indent=2)


dControls = {}
dControls['sFile'] = controls.FilePathControl('*.mp4', sDefaultFileName=r'playblast.mp4', bReadOnly=False, bShowContent=True, sPossibleFileExtensions=['.mp4'])
@uiSettings.addToUI(sTab='Export', sModuleButton='Playblast', sRunButton='Playblast', dControls=dControls, sDocumentationLink='https://kangaroobuilder.com/animationTools/#mp4-playblast')
def playblastMov(sFile='', bOpenWhenDone=True, bSameFolderAsSceneFile=True, iWidthHeight=None, bNoAudio=False,  bJustAudio=False):
    '''
    This makes a playblast of your current scene, does a nice codex using ffMpeg, and saves it in same folder where you current maya file is located
    '''
    sTempFile = os.path.join(cmds.internalVar(utd=True), 'playblastTemp.avi')
    sTempFile = sTempFile.replace('\\', '/')



    if sFile == None:
        sSceneFile = cmds.file(q=True, sn=True)
        if not sSceneFile:
            raise Exception('You need to have the scene saved')
        sSceneName = os.path.basename(sSceneFile).split('.')[0]
        sExtension = 'avi' if bJustAudio else 'mp4'
        sAudioExt = '_audio' if bJustAudio else ''
        if bSameFolderAsSceneFile:
            sFile = os.path.join(os.path.dirname(sSceneFile), '%s%s.%s' % (sSceneName, sAudioExt, sExtension)).replace('\\','/')
        else:
            sFile = os.path.join(cmds.internalVar(utd=True), '%s%s.%s' % (sSceneName, sAudioExt, sExtension)).replace('\\','/')

    if bNoAudio:
        sAudioNode = None
    else:
        sAudioNode = mel.eval("global string $gPlayBackSlider; $audioNode = `timeControl -q -s $gPlayBackSlider`")

    print('sFile: ', sFile)
    sFile = sFile.replace('\\', '/')
    if bJustAudio:
        if os.path.exists(sFile):
            os.remove(sFile)
        cmds.playblast(format='avi', sound=sAudioNode, filename=sFile, compression=None, percent=10, quality=1, viewer=False)

    else:
        sPlayblastToFile = sTempFile.replace('\\', '/')

        print('playblast to %s' % sPlayblastToFile)


        if os.path.exists(sPlayblastToFile):
            os.remove(sPlayblastToFile)

        if isinstance(iWidthHeight, (list,tuple)):
            cmds.playblast(format='avi', sequenceTime=0, clearCache=1, showOrnaments=1, fp=4, viewer=False, sound=sAudioNode, combineSound=True,
                               percent=100, compression="none", quality=0, filename=sPlayblastToFile, widthHeight=iWidthHeight)
        else:
            cmds.playblast(format='avi', sequenceTime=0, clearCache=1, showOrnaments=1, fp=4, viewer=False, sound=sAudioNode, combineSound=True,
                               percent=100, compression="none", quality=0, filename=sPlayblastToFile)

        print('create "%s"...' % sFile)

        fTimeBefore = time.time()
        utils.ffMpegCodex(sTempFile, sFile)
        print(sFile)
        if not os.path.exists(sFile) or os.path.getmtime(sFile) < fTimeBefore:
            raise Exception('Did not create file')


        print('from maya: ', sPlayblastToFile)
        print('ffmpeg-ed: ', sFile)


    if report.report != None:
        report.report.addLogText('done: %s' % sFile, bPrint=True)

    if bOpenWhenDone:
        os.system('start %s' % sFile)



qDialog = None

def importObjsUI():
    global qDialog

    def _importObjs(sFolder):
        sFiles = [sF for sF in os.listdir(sFolder) if sF.endswith('.obj') or sF.endswith('.OBJ')]

        f = 1
        for sF in sFiles:
            sAbsF = os.path.join(sFolder, sF)
            sNodes = utils.importMayaFiles(sAbsF, sNamespace=None, bReference=False)

            for sNode in sNodes:
                if cmds.objectType(sNode) == 'transform':
                    cmds.setAttr('%s.tx' % sNode, f * 20)

            for sNode in sNodes:
                if cmds.objExists(sNode) and cmds.objectType(sNode) == 'transform':
                    sNewName = sF.split('.')[0]
                    if sNewName[0] in '0123456789':
                        sNewName = '_%s' % sNewName
                    cmds.rename(sNode, sNewName)
            f += 1

    qDialog = utilsQt.QGetStringDialog(_importObjs, sMessage='enter folder')
    qDialog.show()



def cleanReferenceEditsOfCurrentlyOpenedMaFile():
   sFile = cmds.file(q=True, sn=True)
   sFileName = os.path.basename(sFile)
   sFileSplits = sFileName.split('.')
   if sFileSplits[-1].upper() != 'MA':
       raise Exception('This is not an MA file')
   sFileSplits[-2] = '%s_CLEANED' % sFileSplits[-2]
   sOutFile = os.path.join(os.path.dirname(sFile), '.'.join(sFileSplits))

   sReferences = cmds.ls(sl=True, et='reference')
   if not sReferences:
       raise Exception('Please select References, it\'s those nodes ending with RN')

   sLines = utils.readFile(sFile)
   sOutLines = []
   def _includesCtrlLine(sLine):
       if ('_ctrl"' in sLine or '_ctrl.' in sLine) and "_ctrl.world" not in sLine:
           return True
       else:
           return False

   i = -1
   while True:
       i += 1
       if i >= len(sLines):
           break
       sOutLines.append(sLines[i])
       bEndOfReferenceEdits = False
       iKeeping = 0
       iRemoving = 0
       if 'setAttr ".ed" -type "dataReferenceEdits" ' in sLines[i]:
           bDoIt = False
           for sRef in sReferences:
               if '"%s"' % sRef in sLines[i+1]:
                   bDoIt = True
                   break
           if not bDoIt:
               print ('\nSkipping %s...' % sLines[i+1].strip())
           else:
               print ('\nCleaning %s...' % sLines[i+1].strip())
               while True:
                   i += 1
                   sStripped = sLines[i].strip()
                   if sStripped and sStripped[0] in ['0', '1', '2', '3', '4', '5', '6'] and _includesCtrlLine(sStripped): # record
                       iKeeping += 1
                       sOutLines.append(sLines[i])
                       while True:
                           i += 1
                           sStripped = sLines[i].strip()
                           if sStripped and sStripped[0] in ['0', '1', '2', '3', '4', '5', '6']:
                               i -= 1
                               break
                           else:
                               sOutLines.append(sLines[i])
                           if ';' in sLines[i]:
                               bEndOfReferenceEdits = True
                               break
                   if sStripped and sStripped[0] in ['0', '1', '2', '3', '4', '5', '6'] and not _includesCtrlLine(sStripped): # don't record
                       iRemoving += 1
                       while True:
                           i += 1
                           sStripped = sLines[i].strip()
                           if sStripped and sStripped[0] in ['0', '1', '2', '3', '4', '5', '6']:
                               i -= 1
                               break
                           if ';' in sLines[i]:
                               bEndOfReferenceEdits = True
                               break

                   if bEndOfReferenceEdits:
                       print ('keeping %d and removing %d edits' % (iKeeping, iRemoving))
                       break

                   if not sStripped or sStripped[0] not in ['0', '1', '2', '3', '4', '5', '6']:
                       sOutLines.append(sLines[i])

                   if ';' in sLines[i]:
                       print ('keeping %d and removing %d edits' % (iKeeping, iRemoving))
                       break


   print ('creating text file "%s"...' % sOutFile)
   utils.createTextFile(sOutFile, sOutLines)
   print ('Done!')




dControls = {}
dControls['sProject'] = controls.ProjectsControl(assetsModule=assets)
@uiSettings.addToUI(sTab='Export', sModuleButton='Batch', sRunButton='Builder', dControls=dControls, bDisableOnServer=True)
def batchToolsBuilder():
    '''
    Here you can find some tools for Batch Matching other Assets,
    Originally written by Markus Hadinger
    '''
    sAssetRoot = assets.getCurrentAssetRoot().replace('\\', '/')
    sDirs = sAssetRoot.split('/')
    sAssetName = sDirs[-1]

    sProjectPath = os.path.normpath(os.path.join(sAssetRoot, os.pardir))

    from kangarooBatchTools.batchArgSync import gui as argument_gui
    utils.reload2(argument_gui)
    argument_gui.show(sProjectPath, sAssetName)



dControls = {}
dControls['sProject'] = controls.ProjectsControl(assetsModule=assets)
@uiSettings.addToUI(sTab='Export', sModuleButton='Batch', sRunButton='Puppet', dControls=dControls, bDisableOnServer=True)
def batchToolsPuppet():
    print ('assets.getCurrentAssetRoot(): ', assets.getCurrentAssetRoot())

    sAssetRoot = assets.getCurrentAssetRoot().replace('\\', '/')
    sDirs = sAssetRoot.split('/')
    sAssetName = sDirs[-1]

    sProjectPath = os.path.normpath(os.path.join(sAssetRoot, os.pardir))

    from kangarooBatchTools.batchPuppetSync import gui as puppet_gui
    utils.reload2(puppet_gui)
    puppet_gui.show(sProjectPath, sAssetName)



dControls = {}
dControls['sProject'] = controls.ProjectsControl(assetsModule=assets)
@uiSettings.addToUI(sTab='Export', sModuleButton='Batch', sRunButton='Publish', dControls=dControls, bDisableOnServer=True)
def batchToolsPublish():
    print ('assets.getCurrentAssetRoot(): ', assets.getCurrentAssetRoot())

    sAssetRoot = assets.getCurrentAssetRoot().replace('\\', '/')
    sProjectPath = os.path.normpath(os.path.join(sAssetRoot, os.pardir))

    from kangarooBatchTools.batchPublisher import gui as publish_gui
    from kangarooBatchTools.batchPublisher import core

    utils.reload2(publish_gui)
    utils.reload2(core)
    publish_gui.show(sProjectPath)


