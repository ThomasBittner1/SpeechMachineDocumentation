###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np


import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.patch as patch
import kangarooTools.xforms as xforms
import kangarooTools.nodes as nodes

from collections import OrderedDict
import kangarooTabTools.geometry as geometry
import kangarooTabTools.weights as weights

import kangarooShapeEditor.kangarooShapeEditorTools as kangarooShapeEditorTools


class MirrorMode():
    noMirror = 0
    mirrorIds = 1
    mirrorPositions = 2
    splitPositions = 3
    findShapes = 4



def getPoseDictFromX(xPoses):
    dPoses = OrderedDict()
    for xP in xPoses:
        dPoses[xP[0]] = xP[1:4]
    return dPoses


def getPosesDictFromInterp(sInterp):
    return getPoseDictFromX(eval(cmds.getAttr('%s.xPoses' % sInterp)))


def createPoseInterpolator(sName, sJoint, sCtrl, xPoses=[('default',0,0,0)], sPoseAttrs=['rx','ry','rz'], bMirror=True, sMaster=None): #, sParentOfDriver=None, bInsertParentDriver=True):
    sGroup = 'grp_posesInterpolators%s' % (('_%s' % sMaster) if sMaster else '')

    if not cmds.objExists(sGroup):
        cmds.createNode('transform', n=sGroup, p=sMaster if sMaster else utils.getMasterName())
        cmds.setAttr('%s.v' % sGroup, False)

    sJointsGroup = 'grp_posesInterpolatorJoints%s' % (('_%s' % sMaster) if sMaster else '')
    if not cmds.objExists(sJointsGroup):
        cmds.createNode('transform', n=sJointsGroup, p=sGroup)

    if cmds.objExists(sName):
        raise Exception('Interpolator "%s" already exists' % sName)

    # sMaster = xforms.getWorldRoot(sJoint)
    sInterps = []
    for s, sSide in enumerate(['l','r']):
        if s == 0:
            sSideName = sName
            sSideJoint = sJoint
            sSideControl = sCtrl
        if s == 1:
            if not bMirror:
                break
            sSideName = utils.getMirrorName(sName)
            if sSideName == sName:
                break
            sSideJoint = utils.getMirrorName(sJoint)
            sSideControl = utils.getMirrorName(sCtrl)
            # if sParentOfDriver:
            #     sParentOfDriver = utils.getMirrorName(sParentOfDriver)

        sChild = cmds.listRelatives(sSideJoint, p=False, c=True, typ='joint')[0]
        sParent = cmds.listRelatives(sSideJoint, p=True, c=False)[0]
        fChildLocalPos = cmds.getAttr('%s.t' % sChild)[0]

        sJointCopy = cmds.createNode('joint', n='%s_POSE' % sSideJoint, p=sJointsGroup)
        xforms.createJoint('%s_POSE' % sChild, xPos=fChildLocalPos, sParent=sJointCopy)

        xforms.matrixParentConstraint(sSideJoint, sJointCopy)
        sParentCopy = xforms.insertParent(sJointCopy, '%s_PARENT' % sSideJoint)
        xforms.matrixParentConstraint(sParent, sParentCopy, mo=True)
        # if bInsertParentDriver:
        #     xforms.insertParent(sJointCopy, utils.getUniqueName(utils.replaceStringEnd(sJoint, 'jnt_', 'grp_')))

        # if sParentOfDriver:
        #     print 'createPoseInterpolator(): sParentOfDriver flag is depricated, please use bInsertParentDriver instead'
        #     sNewSideTransform = cmds.createNode('transform', p=sParentOfDriver, n='%s_interp' % sJointCopy)
        #     xforms.matrixParentConstraint(sJointCopy, sNewSideTransform, skipScale=['x','y','z'])
        #     sJointCopy = sNewSideTransform

        sInterp = cmds.poseInterpolator(sJointCopy, name=sSideName)[0]

        cmds.setAttr('%s.allowNegativeWeights' % sInterp, False)
        utils.addStringAttr(sInterp, 'xPoses', str(xPoses))
        utils.addStringAttr(sInterp, 'sCtrl', sSideControl)
        fRotBefore = [cmds.getAttr('%s.%s' % (sSideControl,sA)) for sA in sPoseAttrs]
        dPoses = getPoseDictFromX(xPoses)
        for sPoseName, fEuler in list(dPoses.items()):
            for a,sA in enumerate(sPoseAttrs):
                try: cmds.setAttr('%s.%s' % (sSideControl,sA), fEuler[a])
                except: pass
            cmds.poseInterpolator(sInterp, e=True, addPose=sPoseName)

        for a,sA in enumerate(sPoseAttrs):
            try: cmds.setAttr('%s.%s' % (sSideControl,sA), fRotBefore[a])
            except: pass
        cmds.parent(sInterp, sGroup)
        utils.addStringAttr(sInterp, 'sPoseAttrs', str(sPoseAttrs))
        sInterps.append(sInterp)

        for p,xP in enumerate(xPoses):
            sPose = xP[0]
            sVisAttr = utils.addAttr(sInterp, ln=sPose, k=True)
            cmds.connectAttr('%s.output[%d]' % (sInterp,p), sVisAttr)


    return sInterps



def goToPose(sInterp, sPose):
    sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
    dPoses = getPosesDictFromInterp(sInterp)
    sAttrs = eval(cmds.getAttr('%s.sPoseAttrs' % sInterp))
    for a, sA in enumerate(sAttrs):
        try: cmds.setAttr('%s.%s' % (sCtrl,sA), dPoses[sPose][a])
        except: pass


# to do: we could simplify that function a lot. Has a lot of garbage from old stuff
def getMouthBottomWeights(sModel, iSkinClusterSmoothIterations=2):
    print('get mouthBottomWeights... sModel: ', sModel)
    sModel = utils.replaceStringEnd(sModel, '_noPreJoints', '')
    if cmds.objExists('MAP__%s__faceBottom' % sModel):
        return geometry.getMapValues('MAP__%s__faceBottom' % sModel)
    if cmds.objExists('MAP__faceBottom'):
        return geometry.getMapValues('MAP__faceBottom')
    if cmds.objExists('MAP__mouthBot'):
        return geometry.getMapValues('MAP__mouthBot')

    # pModel = patch.patchFromName(sModel)
    sSkinClusters = ['splitSkinCluster__%s' % sModel, 'skinCluster__%s__MOUTH' % sModel, 'skinCluster__%s' % sModel]

    if cmds.objExists(sSkinClusters[0]):
        sSkinCluster = sSkinClusters[0]
        ssLookForInfluences = [['jnt_m_jawMain'], ['jnt_m_headMain']]
    elif cmds.objExists(sSkinClusters[1]):
        sSkinCluster = sSkinClusters[1]
        ssLookForInfluences = [cmds.ls(['jnt_?_bot2Lip_???', 'jnt_?_botLip_???'], et='joint'),
                               cmds.ls(['jnt_?_top2Lip_???', 'jnt_?_topLip_???'], et='joint')]
    elif cmds.objExists(sSkinClusters[2]):
        sSkinCluster = sSkinClusters[2]
        ssLookForInfluences = [['jnt_m_jawMain'], ['jnt_m_headMain']]
    else:

        if cmds.confirmDialog(m='None of the 3 skinClusters exists: %s\nCreate an empty Map Mesh Cluster?' % ', '.join(sSkinClusters),
                           button=['yes', 'no']) == 'no':
            raise Exception('Can\'t find a way to split bottom/top for %s' % sModel)
        sSkinCluster = None


    if sSkinCluster:
        sMesh = deformers.getGeoFromDeformer(sSkinCluster)
        pModel = patch.patchFromName(sMesh)

        _, sInfluences, aWeights2d = pModel.getSkinCluster(sChooseSkinCluster=sSkinCluster)

        aWeightings2d = np.zeros((pModel.getTotalCount(), 3), dtype='float64')

        for p, sPart in enumerate(['bot', 'top']):
            sLipJoints = ssLookForInfluences[p]
            iLipInds = utils.findOneArrayInAnother(sInfluences, sLipJoints)
            aWeightings2d[:, p] = np.sum(aWeights2d[:, iLipInds], axis=1)

        aWeightings2d[:, 2] = 1.0 - np.sum([aWeightings2d[:, 0], aWeightings2d[:, 1]])
        aWeightings2d = pModel.smoothValues2d(aWeightings2d, iIterations=iSkinClusterSmoothIterations)

        aReturnWeights = aWeightings2d[:,0]
    else:
        aReturnWeights = np.zeros(cmds.polyEvaluate(sModel, vertex=True), dtype='float64')

    # generate cluster for saving next time
    sMapModel = '%s__MAPS' % sModel
    if not cmds.objExists(sMapModel):
        cmds.duplicate(sModel, n=sMapModel)
        utils.parentToWorld(sMapModel)
        cmds.setAttr('%s.v' % sMapModel, False)
    # sCluster = cmds.deformer(sMapModel, type='cluster', n='MAP__%s__faceBottom' % sModel)[0]
    sCluster, sTempHandle = cmds.cluster(sMapModel, n='MAP__%s__faceBottom' % sModel)
    nodes.deleteConnectionsAndItself2(cmds.ls(sTempHandle, dag=True))

    deformers.makeNotExport(sCluster)
    cmds.refresh()
    cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, len(aReturnWeights)-1), *list(aReturnWeights))

    return aReturnWeights




def getLidsBottomWeights(sModel):
    sMainModel = None
    if '__' in sModel:
        sMainModel = sModel.split('__')[0]
        if not cmds.objExists(sMainModel):
            sMainModel = None

    if sMainModel:
        pass
    else:
        aaWeights = geometry.getClosestToCurvesWeights(sModel,
                                                        ['bpCurve_l_botLidSpline', 'bpCurve_l_topLidSpline', 'bpCurve_r_botLidSpline', 'bpCurve_r_topLidSpline'],
                                                        iSmoothIterations=2)
    return aaWeights[:,0] + aaWeights[:,2]



kIgnoreAttachTargetsAttr = 'ignoreAttachTargets'
def addIgnoreAttachTargets(sCtrl, sTargets):
    sAttr = '%s.%s' % (sCtrl, kIgnoreAttachTargetsAttr)
    try: # this could be a reference, in which case it wouldn't matter anyway
        sPrevTargets = [] if not cmds.objExists(sAttr) else eval(cmds.getAttr(sAttr))
        sPrevTargets += sTargets
        utils.addStringAttr(sCtrl, kIgnoreAttachTargetsAttr, str(sPrevTargets))
    except:
        pass


class CombineMode(object):
    product = 0
    minimum = 1

def _combineValues(iMode, xValues, sTarget=None):
    if iMode == CombineMode.product:
        return nodes.createMultiplyArrayNode(xValues, sTarget=sTarget)
    elif iMode == CombineMode.minimum:
        return nodes.createMinimumNode(xValues, sTarget=sTarget)
    else:
        raise Exception('Don\'t know what combine mode %d is' % iMode)


dBottomWeightsMouth = {}
dBottomWeightsLids = {}
dSplitAlongCurveWeights = {}
dZipperWeights = {}
def clearWeightsCache():
    global dBottomWeightsMouth
    dBottomWeightsMouth.clear()

    global dBottomWeightsLids
    dBottomWeightsLids.clear()

    global dSplitAlongCurveWeights
    dSplitAlongCurveWeights.clear()

    global dZipperWeights
    dZipperWeights.clear()


def connectTargets(sModel, sTarget, dPoses={}, dDrivers={}, sPostMultDrivers=[], bMirror=True, iInvert=False, sMaskMap=None, sMaskedName=None, bMaskFromPose=False,
                    fSplitRadius=0.2, bSplitBotTop=False, ffLidRanges=[], sBlendShape=None, bStopBeforeInvert=False, bStopBeforeMask=False, bStopBeforeMirror=False, bAppleBlendShapes=False, sSecondaryModels=[],
                   sAlias=None, bReturnIfNotExist=False, fOvershootRange=None, iCombineMode=CombineMode.minimum, xMirrorAxis=None, dSplitAlongCurve={}, dZipper={}, sAliasSuffix=''):
    '''
    :param sModel:
    :param sTarget:
    :param dPoses: dictionary of attributes and values
            poses examples: dPoses={'clavLFT':'forward'},
    :param dDrivers: dictionary of attributes and values/lists. If it's a list it needs to have 2 items, start and end \
                    value of attribute. If it's missing, then the poses dictionary will be taken for it.
    :param bMirror:
    :param iInvert:
    :param fSplitRadius:
    :param bSplitBotTop:
    :param sBlendShape:
    :return:
    '''

    if sTarget != None and not cmds.objExists(sTarget) and bReturnIfNotExist:
        print('skipping target "%s", because it doesn\'t exist.' % sTarget)
        return


    dDrivers = dict(dDrivers)
    dPoses = dict(dPoses)
    sPostMultDrivers = list(sPostMultDrivers)

    if bMirror:
        _mirrorAttrsDict(dDrivers)
        _mirrorAttrsDict(dPoses)
        _mirrorAttrsList(sPostMultDrivers)


    # if not dDrivers and not dPoses:
    #     raise Exception, 'you need either dDrivers or dPoses, or both'
    if not dDrivers:
        dDrivers = dict(dPoses)
    elif not dPoses:
        dPoses = dict(dDrivers)

    if bAppleBlendShapes:
        import kangarooTabTools.unreal as unreal
        sUnrealCommands = ''

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={})
    utils.addListKey(dConnectTargetPoses, sTarget)
    dConnectTargetPoses[sTarget].append(dPoses)
    utils.data.store('dConnectTargetPoses', dConnectTargetPoses)

    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={})
    utils.addListKey(dConnectTargetDrivers, sTarget)
    dConnectTargetDrivers[sTarget].append(dDrivers)
    utils.data.store('dConnectTargetDrivers', dConnectTargetDrivers)


    bSplitLidTargets = True if ffLidRanges and ffLidRanges[0] and ffLidRanges[1] else False
    iLidTargetsCount = 2 if bSplitLidTargets else 1
    ffLidFactors = []
    ssLidPoseAttrs = [['lidBotLFT_ctrl.ty', 'lidTopLFT_ctrl.ty'],
                    ['lidBotRGT_ctrl.ty', 'lidTopRGT_ctrl.ty']]
    ssLidDrivers = [['grp_l_blinkPasser.blendCurveBot', 'grp_l_blinkPasser.blendCurveTop'],
                   ['grp_r_blinkPasser.blendCurveBot', 'grp_r_blinkPasser.blendCurveTop']]

    if ffLidRanges:
        for p,sPart in enumerate(['bot','top']):
            if ffLidRanges[p]:
                fDriverValues = list(ffLidRanges[p])
                fDrivenValues = [0,1,0]

                if fDriverValues[0] == None:
                    fDriverValues = fDriverValues[1:]
                    fDrivenValues = fDrivenValues[1:]
                elif fDriverValues[-1] == None:
                    fDriverValues = fDriverValues[:-1]
                    fDrivenValues = fDrivenValues[:-1]

                if p == 1:
                    for i in range(len(fDriverValues)):
                        fDriverValues[i] *= -1

                sLeftRightDriven = [nodes.setDrivenKey(ssLidDrivers[s][p], fDriverValues, None, fDrivenValues) for s in [0,1]]
                ffLidFactors.append(sLeftRightDriven)


    dPosesForInvert = dict(dPoses)
    if dSplitAlongCurve:
        for sAttrs, fValues in zip(dSplitAlongCurve['ssAttrs'], dSplitAlongCurve['ffValues']):
            for sA,fV in zip(sAttrs, fValues):
                dPosesForInvert[sA] = fV
    if dZipper:
        dPosesForInvert['lipsCornerLFT_ctrl.sealB'] = 1.0

    if ffLidRanges:
        for p,sPart in enumerate(['bot','top']):
            if ffLidRanges[p]:
                dPosesForInvert[ssLidPoseAttrs[0][p]] = ffLidRanges[p][1]
                dPosesForInvert[ssLidPoseAttrs[1][p]] = ffLidRanges[p][1]


    # make sure .r and .t endings are posed first
    sSortedPoseKeysForInvert = sorted(list(dPosesForInvert.keys()), key=lambda a:not a.endswith('.t') and not a.endswith('.r'))
    dDefaultAttrs = {}
    for sA in sSortedPoseKeysForInvert:
        fValue = cmds.getAttr(sA)
        if isinstance(fValue, (list,tuple)): # most likely rotation, in that case it'll look like [(0.0, 0.0, 90)]
            dDefaultAttrs[sA] = np.array(fValue[0], dtype='float64')
        else:
            dDefaultAttrs[sA] = fValue


    if sTarget == None:
        sTarget = cmds.duplicate(sModel)[0]
        if cmds.listRelatives(sTarget, p=True):
           cmds.parent(sTarget, w=True)

    print('\n\n\n ============================= sTarget: %s (%s) - secondary models: %s' % (sTarget, sModel, sSecondaryModels))

    if not cmds.objExists(sTarget):
        raise Exception('Target %s doesn\'t exist.' % sTarget)

    if sBlendShape == None:
        sBlendShape = 'blendShape__%s' % sModel.split(':')[-1]
        if not cmds.objExists(sBlendShape):
            deformers.preDeformationBlendshapeHack([], sModel, n=sBlendShape)
            if not cmds.objExists(sBlendShape):
                raise Exception('wasn\'t able to create blendShape')

    if sSecondaryModels:
        sSecondaryModels = list(set(sSecondaryModels))
    sSecondaryBlendShapes = []
    for sSecondaryModel in sSecondaryModels:
        sSecondaryBlendShape = 'blendShape__%s' % sSecondaryModel
        if not cmds.objExists(sSecondaryBlendShape):
            sSecondaryBlendShapes.append(sSecondaryBlendShape)
            deformers.preDeformationBlendshapeHack([], sSecondaryModel, n=sSecondaryBlendShape)
            if not cmds.objExists(sSecondaryBlendShape):
                raise Exception('wasn\'t able to create blendShape')
        sSecondaryBlendShapes.append(sSecondaryBlendShape)



    print('\n\n === target: ', sTarget)
    sInbetweens = []
    iInbetweens = []
    for sI in cmds.ls('%s__???' % sTarget, et='transform'):
        try: iNumber = int(sI.split('_')[-1])
        except: iNumber = None
        if iNumber:
            sInbetweens.append(sI)
            iInbetweens.append(iNumber)


    sTargets = [sTarget] + sInbetweens


    iInbetweens = [100] + iInbetweens

    aSorted = np.argsort(iInbetweens)

    sTargets = list(np.array(sTargets)[aSorted])
    iInbetweens = np.array(iInbetweens, dtype='float64')[aSorted]
    aPercs = iInbetweens * 0.01

    if iInvert == 2:
        sNewTargetName = '%s_INV' % sTargets[-1]
    elif iInvert == 1:
        sNewTargetName = '%s_CMB' % sTargets[-1]
    else:
        sNewTargetName = str(sTargets[-1])




    def _activatePose(fPerc):
        for sAttr in sSortedPoseKeysForInvert:
            fValue = dPosesForInvert[sAttr]
            if isinstance(fValue, tuple):
                if sAttr.endswith('.t') or sAttr.endswith('.translate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['tx','ty','tz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                elif sAttr.endswith('.r') or sAttr.endswith('.rotate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['rx','ry','rz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                elif '.input3D' in sAttr:
                    for a,sA in enumerate(['x','y','z']):
                        sAttr2 = '%s.input3D%s' % (sAttr, sA)
                        cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))

            elif isinstance(fValue, (list,np.ndarray)):
                cmds.setAttr(sAttr, dPosesForInvert[sAttr][-1] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc))
            else:
                cmds.setAttr(sAttr, dPosesForInvert[sAttr] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc))


    sNoneDrivers = []
    for sAttr,xV in list(dDrivers.items()):
        if utils.isNone(xV):
            sNoneDrivers.append(sAttr)
            dDrivers[sAttr] = [None, None]

    if sNoneDrivers:
        for sAttr in sNoneDrivers:
            if '.' not in sAttr:
                raise Exception('this is not an attribute: %s (sDriversGetAttr)' % sA)
            try:
                dDrivers[sAttr][0] = cmds.getAttr(sAttr)
            except: raise Exception('error getting attribute value for %s' % sAttr)

        _activatePose(1.0)
        for sAttr in sNoneDrivers:
            dDrivers[sAttr][1] = cmds.getAttr(sAttr)
        _activatePose(0.0)


    sLeftRights = [None, None]
    sLeftRights[0], sLeftRights[1] = _separateAttrKeysIntoSides(dDrivers, bMirror)

    sAllPostMultDriversLeftRights = [None, None]
    sAllPostMultDriversLeftRights[0], sAllPostMultDriversLeftRights[1] = _separateAttrListIntoSides(sPostMultDrivers, bMirror)

    # split dDrivers into left and right middles
    sReturnTargetAttrs = []


    for sAttr, xRelation in list(dDrivers.items()):
        dDrivers[sAttr] = _rangeOrDrivenKeys(sAttr, xRelation, fOvershootRange)

    if iInvert:

        for t,sT in enumerate(sTargets):

            sCurrentNewName = str(sNewTargetName)
            if t < len(sTargets)-1:
                sCurrentNewName = '%s_%03d' % (sCurrentNewName, iInbetweens[t])

            _activatePose(aPercs[t])

            if bStopBeforeInvert:
                cmds.select(sT, sModel)
                raise Exception('exception on purpose: stop before invertShapeDeformers (meshes are selected)')

            print ('inverting.. ', sT, sModel)

            if iInvert == 1:
                sInverted = geometry.calculateComboShape(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)
            else:
                sInverted = geometry.invertShapeDeformers(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)

            try:cmds.setAttr('%s.v' % sInverted, cmds.getAttr('%s.v' % sT))
            except: pass

            for b, sSecondaryModel in enumerate(sSecondaryModels):
                sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                if cmds.objExists(sSecondaryT):
                    sSecondaryInverted = geometry.invertShapeDeformers(sSecondaryT, sSecondaryModel, sComboBlendShape=sSecondaryBlendShapes[b], sInvertName='%s__%s' % (sSecondaryModel, sCurrentNewName))
                    try:cmds.setAttr('%s.v' % sSecondaryInverted, cmds.getAttr('%s.v' % sT))
                    except: pass

            try: cmds.parent(sInverted, '_invertedShapes_')
            except: pass

            sTargets[t] = sInverted

        _activatePose(0.0)

    if sMaskMap != None and bMaskFromPose:
        _activatePose(1.0)
        for t,sT in enumerate(sTargets):
            if sMaskedName == None:
                if sT.endswith('_SCAN'):
                    sMaskedName = sT[:-len('_SCAN')]
                else:
                    sMaskedName = '%s_masked' % sT

            if isinstance(bMaskFromPose, (str,unicode)):
                sDuplT = cmds.duplicate(bMaskFromPose, n='%s_INV' % sMaskedName)[0]
            else:
                sDuplT = cmds.duplicate(sModel, n='%s_masked' % sT)[0]
            if cmds.listRelatives(sDuplT, p=True, c=False):
                cmds.parent(sDuplT, w=True)
            cmds.setAttr('%s.v' % sDuplT, False)
            sMaskBlendShape = cmds.blendShape(sT, sDuplT, w=[0,1])[0]
            iSize = cmds.polyEvaluate(sDuplT, vertex=True)
            # aMapValues = geometry.getMapValues(sMaskMap) #if isinstance(sMaskMap, (str, unicode)):
            aMapValues = geometry.getMapValues(sMaskMap)
            cmds.setAttr('%s.inputTarget[0].baseWeights[0:%d]' % (sMaskBlendShape, iSize-1), *list(aMapValues))
            sTargets[t] = sDuplT
            if bStopBeforeMask:
                cmds.select(sT, sDuplT)
                raise Exception('exception on purpose: stop before masking meshes (meshes are selected)')

        _activatePose(0.0)


    if not sLeftRights[1] and not sAllPostMultDriversLeftRights[1] and not ffLidRanges:
        bMirror = False

    sSides = ['l','r'] if bMirror else ['m']
    sParts = ['bot','top'] if bSplitBotTop else ['bot']


    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetMirrors, sTarget)
    dConnectTargetMirrors[sTarget].append(True if len(sLeftRights[0]) or len(sAllPostMultDriversLeftRights[0]) else False)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)

    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitBotTops, sTarget)
    dConnectTargetSplitBotTops[sTarget].append(bSplitBotTop)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)

    dConnectTargetLidRanges = utils.data.get('dConnectTargetLidRanges', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetLidRanges, sTarget)
    dConnectTargetLidRanges[sTarget].append(ffLidRanges)
    utils.data.store('dConnectTargetLidRanges', dConnectTargetLidRanges)

    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetInverts, sTarget)
    dConnectTargetInverts[sTarget].append(iInvert)
    utils.data.store('dConnectTargetInverts', dConnectTargetInverts)

    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitRadien, sTarget)
    dConnectTargetSplitRadien[sTarget].append(fSplitRadius)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)

    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetSplitAlongCurves, sTarget)
    dConnectTargetSplitAlongCurves[sTarget].append(dSplitAlongCurve)
    utils.data.store('dConnectTargetSplitAlongCurves', dConnectTargetSplitAlongCurves)

    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={}) # should be defaultDict(list), but that can't be stored
    utils.addListKey(dConnectTargetZippers, sTarget)
    dConnectTargetZippers[sTarget].append(dZipper)
    utils.data.store('dConnectTargetZippers', dConnectTargetZippers)


    if bSplitBotTop:
        global dBottomWeightsMouth
        for sM in [sModel] + sSecondaryModels:
            if sM not in dBottomWeightsMouth:
                dBottomWeightsMouth[sM] = getMouthBottomWeights(sM)

    if bSplitLidTargets:
        global dBottomWeightsLids
        aModelWeights = getLidsBottomWeights(sModel)
        if sModel not in dBottomWeightsLids:
            dBottomWeightsLids[sModel] = aModelWeights

        for sSecondaryM in sSecondaryModels:
            if sSecondaryM not in dBottomWeightsLids:
                aTransferredWeights = weights.simpleTransferValues(sModel, sSecondaryM, aModelWeights)
                dBottomWeightsLids[sSecondaryM] = aTransferredWeights

    if dSplitAlongCurve:
        global dSplitAlongCurveWeights
        aaaSplitWeights = []
        for sM in [sModel] + sSecondaryModels:
            sKey = '%s_%s_%s' % (sM,
                                 dSplitAlongCurve['sCurve'],
                                 '_'.join('%0.3f' % fV for fV in dSplitAlongCurve['fParams']))
            if sKey not in dSplitAlongCurveWeights:
                aaWeights = geometry.generateMeshToCurveParamWeights(sM, dSplitAlongCurve['sCurve'], dSplitAlongCurve['fParams'])
                dSplitAlongCurveWeights[sKey] = aaWeights
            else:
                aaWeights = dSplitAlongCurveWeights[sKey]
            aaaSplitWeights.append(aaWeights)
        iParamsCount = len(dSplitAlongCurve['fParams'])
    else:
        iParamsCount = 1


    if dZipper:
        global dZipperWeights
        aaaZipperSplitWeights = []
        iZipperParamsCount = dZipper['iSampleCount']
        fParams = np.arange(iZipperParamsCount+2)[1:-1] / float(iZipperParamsCount+1)
        for sM in [sModel] + sSecondaryModels:
            sKey = '%s_%s_%d' % (sM, dZipper['sCurve'], iZipperParamsCount)
            if sKey not in dZipperWeights:
                aaWeights = geometry.generateMeshToCurveParamWeights(sM, dZipper['sCurve'], fParams)
                dZipperWeights[sKey] = aaWeights
            else:
                aaWeights = dZipperWeights[sKey]
            aaaZipperSplitWeights.append(aaWeights)
        sZipperOutputs = createOrGetZipperSetup(dZipper)
    else:
        iZipperParamsCount = 1
        sZipperOutputs = []

    sssMainDrivers = np.zeros((iZipperParamsCount, iParamsCount, len(sSides), len(sParts), iLidTargetsCount), dtype=object)
    for zz in range(iZipperParamsCount):
        for pp in range(iParamsCount):
            for s, sSide in enumerate(sSides):
                for p,sPart in enumerate(sParts):
                    for l in range(iLidTargetsCount):
                        sFactors = [sZipperOutputs[zz]] if sZipperOutputs else []
                        for sAttr in sLeftRights[s]:
                            if 'Bot' in sAttr or 'Top' in sAttr:
                                if bSplitBotTop:
                                    if p == 0 and 'Bot' in sAttr:
                                        sFactors.append(dDrivers[sAttr])
                                    elif p == 1 and 'Top' in sAttr:
                                        sFactors.append(dDrivers[sAttr])
                                else:
                                    sFactors.append(dDrivers[sAttr])
                            else:
                                sFactors.append(dDrivers[sAttr])

                        if dSplitAlongCurve:
                            for ss in range(len(dSplitAlongCurve['ssAttrs'])):
                                sFactors.append(_rangeOrDrivenKeys(dSplitAlongCurve['ssAttrs'][ss][pp], dSplitAlongCurve['ffValues'][ss][pp], fOvershootRange))

                        if ffLidRanges and ffLidFactors[l]:
                            sFactors.append(ffLidFactors[l][s])

                        sssMainDrivers[zz][pp][s][p][l] = _combineValues(iCombineMode, sFactors)


    for tt, sTT in enumerate(sTargets): # main target + inbetweens
        sModels = [sModel] + sSecondaryModels

        for m,sM in enumerate(sModels):
            sT = sTT if m == 0 else '%s__%s' % (sM, sTT)
            if not cmds.objExists(sT):
                continue

            if iZipperParamsCount == 1:
                sZipperTs = [sT]
            else:
                sZipperTs = geometry.splitShapeFromWeightsPerTarget(sT, sM, aaaZipperSplitWeights[m], bSkipNonChangingOnes=True)

            ssParamSplitTs = [[] for _ in range(iZipperParamsCount)]
            for zz, sZipperT in enumerate(sZipperTs):
                if iParamsCount == 1:
                    ssParamSplitTs[zz] = [sZipperT]
                else:
                    if not utils.isNone(sZipperTs):
                        sSplits = geometry.splitShapeFromWeightsPerTarget(sZipperT, sM, aaaSplitWeights[m])
                        for pp, sSplit in enumerate(sSplits):
                            ssParamSplitTs[zz].append(sSplits[pp])
                    else:
                        ssParamSplitTs[zz] = [None for pp in range(len(sSplits))]

            if m == 0:
                ssFirstParamSplitTs = list(ssParamSplitTs)
            for zz in range(iZipperParamsCount):
                sAliasZipper = sAlias if iZipperParamsCount else ('%s_%02d' % (sAlias, zz))

                for pp in range(iParamsCount):
                    if sAlias:
                        sAliasCurve = sAliasZipper if iParamsCount == 1 else ('%s_%02d' % (sAliasZipper, pp))

                    if bSplitBotTop:
                        if not utils.isNone(ssParamSplitTs[zz][pp]):
                            sBotTopShapes = geometry.splitShape(ssParamSplitTs[zz][pp], sM, aLeftWeights=dBottomWeightsMouth[sM],
                                                                sLeftName='bot_%s' % ssParamSplitTs[zz][pp], sRightName='top_%s' % ssParamSplitTs[zz][pp])
                            sAliasAttrsBotTop = ['bot_%s' % sAliasCurve, 'top_%s' % sAliasCurve] if sAlias else ['bot_%s' % ssFirstParamSplitTs[zz][pp], 'top_%s' % ssFirstParamSplitTs[zz][pp]]
                        else:
                            sBotTopShapes = [None, None]
                    else:
                        sBotTopShapes = [ssParamSplitTs[zz][pp]]
                        sAliasAttrsBotTop = [sAliasCurve] if sAlias else [ssFirstParamSplitTs[zz][pp]]


                    ssLidShapes = []
                    ssAliasAttrsLids = [None] * iLidTargetsCount
                    if bSplitLidTargets:
                        for p,sShape in enumerate(sBotTopShapes):
                            if not utils.isNone(sShape):
                                ssLidShapes.append(geometry.splitShape(sShape, sM, aLeftWeights=dBottomWeightsLids[sM], sLeftName='lidA_%s' % sShape, sRightName='top_%s' % sShape))
                                ssAliasAttrsLids[p] = ['lidA_%s' % sAliasAttrsBotTop[p], 'top_%s' % sAliasAttrsBotTop[p]] if sAlias else ['bot_%s' % ssFirstParamSplitTs[zz][pp], 'top_%s' % ssFirstParamSplitTs[zz][pp]]
                            else:
                                ssLidShapes.append([None, None])
                    else:
                        ssLidShapes = [[x] for x in sBotTopShapes]
                        ssAliasAttrsLids = [[x] for x in sAliasAttrsBotTop]

                    ssTargetAttrsBotTop = []
                    for p,sPart in enumerate(sParts):

                        sLidTargetAttrs = []
                        for l in range(iLidTargetsCount):
                            if bMirror:
                                if not utils.isNone(ssLidShapes[p][l]):
                                    sShapesToAdd = geometry.splitShape(ssLidShapes[p][l], sM, fRadius=fSplitRadius, xMirrorAxis=xMirrorAxis)
                                    sAliasAttrs = ['l_%s' % sAliasAttrsBotTop[p], 'r_%s' % sAliasAttrsBotTop[p]]
                                else:
                                    sShapesToAdd = [None, None]
                                    sAliasAttrs = [None, None]
                            else:
                                sShapesToAdd = [ssLidShapes[p][l]]
                                sAliasAttrs = [ssAliasAttrsLids[p][l]]

                            sLidTargetAttrs.append([addTargets(sM, sShapesToAdd, sAliasAttrs=['%s%s' % (_sA,sAliasSuffix) if _sA else _sA for _sA in sAliasAttrs])])
                        ssTargetAttrsBotTop.append(sLidTargetAttrs)

                    if m == 0:
                        sReturnTargetAttrs += ssTargetAttrsBotTop[0]
                        if bSplitBotTop:
                            sReturnTargetAttrs += ssTargetAttrsBotTop[1]

                    if bAppleBlendShapes:
                        for sAppleBlendShapeName in dPoses.keys():
                            if sAppleBlendShapeName.startswith('appleFaceBlendshapes'):
                                sUnrealTarget = sAttr.split('.')[-1]
                                unreal.addEmptyUnrealTargets(sUnrealTarget)
                            else:
                                raise Exception('bAppleBlendShapes is True, but "%s" is not an apple blendShape' % sAppleBlendShapeName)

                    for s, sSide in enumerate(['l', 'r'] if bMirror else ['m`']):
                        if len(sTargets) == 1: # no inbetweens
                            for p,sPart in enumerate(sParts):
                                for l in range(iLidTargetsCount):
                                    _sFrom = sssMainDrivers[zz][pp][s][p][l]
                                    if sAllPostMultDriversLeftRights[s]:
                                        _sFrom = nodes.createMultiplyNode(_sFrom, sAllPostMultDriversLeftRights[s])
                                    [cmds.connectAttr(_sFrom, sTargetAttrsBot[s]) for sTargetAttrsBot in ssTargetAttrsBotTop[p][l] if sTargetAttrsBot[s]]
                                    if bAppleBlendShapes:
                                        sRange = _sFrom.split('.')[0]
                                        sAppleBlendShapePlug = cmds.listConnections(sRange, p=True, s=True, d=False)[0]
                                        sUnrealCommands += '\nCOMBINE %s ' % ssTargetAttrsBotTop[p][l][0][s].split('.')[1]
                                        sUnrealCommands += '0 %s %0.3f %0.3f %0.3f %0.3f ' % (
                                        sAppleBlendShapePlug.split('.')[-1],
                                        0, 1,
                                        0, 1)


                        else: # there are inbetweens
                            if bAppleBlendShapes:
                                raise Exception('inbetweens are not supported yet with bAppleBlendShapes')
                            if tt == len(sTargets) - 1:  # the full one
                                for p,sPart in enumerate(sParts):
                                    for l in range(iLidTargetsCount):
                                        _sFrom = nodes.createRangeNode(sssMainDrivers[zz][pp][s][p][l], aPercs[tt - 1], 1, 0, 1)
                                        if sAllPostMultDriversLeftRights[s]:
                                            _sFrom = nodes.createMultiplyNode(_sFrom, sAllPostMultDriversLeftRights[s])
                                        [cmds.connectAttr(_sFrom, sTargetAttrsBot[s]) for sTargetAttrsBot in ssTargetAttrsBotTop[p][l] if sTargetAttrsBot[s]]
                            else:
                                for p,sPart in enumerate(sParts):
                                    for l in range(iLidTargetsCount):
                                        _sFrom = nodes.setDrivenKey(sssMainDrivers[zz][pp][s][p][l], [aPercs[tt - 1] if tt > 0 else 0.0, aPercs[tt], aPercs[tt + 1]],
                                                                    None, [0, 1, 0], sInTanType='linear', sOutTanType='linear')
                                        if sAllPostMultDriversLeftRights[s]:
                                            _sFrom = nodes.createMultiplyNode(_sFrom, sAllPostMultDriversLeftRights[s])
                                        [cmds.connectAttr(_sFrom, sTargetAttrsBot[s]) for sTargetAttrsBot in ssTargetAttrsBotTop[p][l] if sTargetAttrsBot[s]]


    sSplitAlongAttrs = []
    if dSplitAlongCurve:
        for ss in range(len(dSplitAlongCurve['ssAttrs'])):
            sSplitAlongAttrs += dSplitAlongCurve['ssAttrs'][ss]
    for sCtrlAttr in list(dPoses.keys()) + sSplitAlongAttrs:
        sCtrl = sCtrlAttr.split('.')[0]
        addIgnoreAttachTargets(sCtrl, utils.flattenedList(sReturnTargetAttrs))

    if bAppleBlendShapes:
        return sUnrealCommands
    else:
        return sReturnTargetAttrs



def autoConnectComboTarget(sComboT, sModel, sSecondaryModels, xMirrorAxis=None, bLegacyIgnoreEyeLookHoriz=True):
    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={})
    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={})
    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={})
    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={})
    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={})
    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={})
    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={})
    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={})
    dConnectTargetLidRanges = utils.data.get('dConnectTargetLidRanges', xDefault={})

    dComboMainTargets = kangarooShapeEditorTools.getPercsFromComboName(sComboT)

    sMainTargets = list(dComboMainTargets.keys())
    iCombinationCount = 1
    for t, sMainT in enumerate(sMainTargets):
        if bLegacyIgnoreEyeLookHoriz and sMainT in ['eyelookLeft', 'eyelookRight']:
            return False, ('WARNING: skipping combo "%s", because %s is not supported for combos on legacy versions' % (sComboT, sMainT))
        if sMainT not in dConnectTargetPoses:
            return False, ('WARNING: skipping combo "%s", because %s is not found' % (sComboT, sMainT))
        iCombinationCount *= len(dConnectTargetPoses[sMainT])


    for i in range(iCombinationCount):

        dPoses = {}
        dDrivers = {}
        bMirror = False
        bSplitBotTop = False
        iInvert = 1
        fSplitRadien = []
        dSplitAlongCurve = {}
        dZipper = {}
        ffLidRanges = []
        for t, sMainT in enumerate(sMainTargets):

            iIndex = i
            for k in range(t + 1, len(sMainTargets), 1):
                iIndex //= len(dConnectTargetPoses[sMainTargets[k]])
            iIndex %= len(dConnectTargetPoses[sMainTargets[t]])

            dMainPose = dict(dConnectTargetPoses[sMainT][iIndex])
            dMainDriver = dict(dConnectTargetDrivers[sMainT][iIndex])
            iPerc = dComboMainTargets[sMainT]
            if iPerc != 100:
                fPerc = iPerc * 0.01
                for sAttr, xValue in list(dMainPose.items()):
                    if isinstance(xValue, (int, float)):
                        dMainPose[sAttr] = xValue * fPerc
                    elif isinstance(xValue, list):
                        if len(xValue) != 2:
                            raise Exception('it is list but not of length 2')
                        dMainPose[sAttr] = [xValue[0], xValue[1] * fPerc]
                    elif isinstance(xValue, tuple):
                        dMainPose[sAttr] = tuple([xValue[0] * fPerc, xValue[1] * fPerc, xValue[2] * fPerc])
                    else:
                        raise Exception('Don\'t know what to do with (%s)' % xValue)

                for sAttr, xValue in list(dMainDriver.items()):
                    if isinstance(xValue, (int, float)):
                        dMainDriver[sAttr] = xValue * fPerc

            dPoses.update(dMainPose)
            dDrivers.update(dMainDriver)

            bMirror = True if dConnectTargetMirrors[sMainT][iIndex] else bMirror
            bSplitBotTop = True if dConnectTargetSplitBotTops[sMainT][iIndex] else bSplitBotTop
            iInvert = max(iInvert, dConnectTargetInverts[sMainT][iIndex])
            dZipper.update(dConnectTargetZippers[sMainT][iIndex])
            if bMirror:
                fSplitRadien.append(dConnectTargetSplitRadien[sMainT][iIndex])

            if dConnectTargetSplitAlongCurves[sMainT][iIndex]:
                if not dSplitAlongCurve:
                    dSplitAlongCurve = dict(dConnectTargetSplitAlongCurves[sMainT][iIndex])
                else:
                    dSplitAlongCurve['ssAttrs'] += dConnectTargetSplitAlongCurves[sMainT][iIndex]['ssAttrs']
                    dSplitAlongCurve['ffValues'] += dConnectTargetSplitAlongCurves[sMainT][iIndex]['ffValues']


            if dConnectTargetLidRanges[sMainT][iIndex]:
                if ffLidRanges:
                    raise Exception('there\'s a combo shape for more than one lidRange, that\'s not supported')
                ffLidRanges = dConnectTargetLidRanges[sMainT][iIndex]

        bIncludesMouthClose = False
        for sT in list(dComboMainTargets.keys()):
            if sT.startswith('mouthClose'):
                bIncludesMouthClose = True
                break

        connectTargets(sModel, sComboT,
                         dPoses=dPoses,
                         dDrivers=dDrivers,
                         bMirror=bMirror,
                         fSplitRadius=np.average(fSplitRadien) if fSplitRadien else 1.0,
                         bSplitBotTop=bSplitBotTop,
                         dSplitAlongCurve=dSplitAlongCurve,
                         dZipper=dZipper,
                         iInvert=iInvert,
                         sSecondaryModels=sSecondaryModels, xMirrorAxis=xMirrorAxis,
                         ffLidRanges=ffLidRanges,
                         iCombineMode=CombineMode.product if bIncludesMouthClose else CombineMode.minimum,
                         sAliasSuffix=utils.getLetter(i))


    return True, ('%s assigned %d times' % (sComboT, iCombinationCount))




def createOrGetZipperSetup(dZipper):
    iSampleCount = dZipper['iSampleCount']

    sZipperOutAttrs = ['zipperOut_%03d.outputR' % j for j in range(iSampleCount)]

    if not cmds.objExists(sZipperOutAttrs[0]):
        sCornerCtrls = ['lipsCornerLFT_ctrl', 'lipsCornerRGT_ctrl']
        sSealLeft = utils.addAttr(sCornerCtrls[0], ln='sealB', at='double',  defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sSealRight = utils.addAttr(sCornerCtrls[1], ln='sealB', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sSealFadeLengthLeft = utils.addAttr(sCornerCtrls[0], ln='sealFadeB', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
        sSealFadeLengthRight = utils.addAttr(sCornerCtrls[1], ln='sealFadeB', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
        sSealLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealLeft, sSealFadeLengthLeft), sName='left_sealByFade')
        sSealRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealRight, sSealFadeLengthRight), sName='right_sealByFade')

        aSides, aInds = utils.convertMiddleSequenceToSides(iSampleCount)

        fLeftPercs = utils.bSpline4([0,0,1,1], aValues=np.arange(iSampleCount) / float(iSampleCount-1))
        fRightPercs = 1.0 - fLeftPercs

        for j in range(iSampleCount):
            sLeftRightSeals = cmds.createNode('plusMinusAverage', n='plus_%s_sumSeals_%03d' % (aSides[j], aInds[j]))

            sEndLeft = nodes.fromEquation('%f + %s' % (fLeftPercs[j], sSealFadeLengthLeft),
                                          sName='%s_left_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeLeft = nodes.createRangeNode(sSealLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0,
                                               sName='%s_left_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sEndRight = nodes.fromEquation('%f + %s' % (fRightPercs[j], sSealFadeLengthRight), sName='%s_right_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeRight = nodes.createRangeNode(sSealRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='%s_right_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sClamped = nodes.createClampNode('%s.output1D' % sLeftRightSeals, 0, 1, sFullName=sZipperOutAttrs[j].split('.')[0])
            sZipperOutAttrs.append(sClamped)

    return sZipperOutAttrs


def _rangeOrDrivenKeys(sAttr, xRelation, fOvershootRange=None):
    if '.' not in sAttr:
        raise Exception('%s is not an attribute' % sAttr)
    if isinstance(xRelation, type(None)):
        return sAttr
    elif isinstance(xRelation, list):
        if len(xRelation) == 2:
            if isinstance(xRelation[0], list):  # [(-1,0,1),(0,1,0)]
                return nodes.setDrivenKey(sAttr, list(xRelation[0]), None, list(xRelation[1]), sInTanType='linear', sOutTanType='linear')
            else:  # [1,0]
                return nodes.createRangeNode(sAttr, xRelation[0], xRelation[1], 0, 1, sName=sAttr.replace('.', '_'), fOvershoot=fOvershootRange)
        elif len(xRelation) == 3:
            return nodes.setDrivenKey(sAttr, list(xRelation), None, [0.0, 1.0, 0.0], sInTanType='linear', sOutTanType='linear')
        else:
            raise Exception('not supported yet: %s ' % xRelation)
    elif isinstance(xRelation, (float, int)):
        return nodes.createRangeNode(sAttr, 0, xRelation, 0, 1, sName=sAttr.replace('.', '_'), fOvershoot=fOvershootRange)
    else:
        raise Exception('not sure what %s is - returning None from _rangeOrDrivenKeys' % sAttr)



class DrivenKeyCurveType():
    linear = 0
    easeIn = 1
    easeOut = 2
    easeInEaseOut = 3


def _drivenKeys(sAttr, xRelation, iCurveType=DrivenKeyCurveType.linear):

    if iCurveType == DrivenKeyCurveType.linear:
        sInTanType, sOutTanType = 'linear', 'linear'
    if iCurveType == DrivenKeyCurveType.easeIn:
        sInTanType, sOutTanType = 'linear', 'flat'
    if iCurveType == DrivenKeyCurveType.easeOut:
        sInTanType, sOutTanType = 'flat', 'linear'
    if iCurveType == DrivenKeyCurveType.easeInEaseOut:
        sInTanType, sOutTanType = 'flat', 'flat'


    if '.' not in sAttr:
        raise Exception('%s is not an attribute' % sAttr)
    if isinstance(xRelation, type(None)):
        return sAttr
    elif isinstance(xRelation, list):
        if len(xRelation) == 2:
            if isinstance(xRelation[0], list):  # [(-1,0,1),(0,1,0)]
                return nodes.setDrivenKey(sAttr, list(xRelation[0]), None, list(xRelation[1]), sInTanType=sInTanType, sOutTanType=sOutTanType)
            else:  # [1,0]
                return nodes.setDrivenKey(sAttr, list(xRelation), None, [0.0, 1.0], sInTanType=sInTanType, sOutTanType=sOutTanType)
        elif len(xRelation) == 3:
            return nodes.setDrivenKey(sAttr, list(xRelation), None, [0.0, 1.0, 0.0], sInTanType=sInTanType, sOutTanType=sOutTanType)
        else:
            raise Exception('not supported yet: %s ' % xRelation)
    elif isinstance(xRelation, (float, int)):
        return nodes.createRangeNode(sAttr, 0, xRelation, 0, 1, sName=sAttr.replace('.', '_'))
    else:
        raise Exception('not sure what %s is - returning None from _rangeOrDrivenKeys' % sAttr)


# to do: change sFroms to sMeshes to be consistent with other functions
def warp(sModels, sTargetsModel, sTargets, bRigidIslands=False, fMinimumChange=0.0001):
    sSel = cmds.ls(sl=True, et='transform')


    sReturn = []

    for sM in sModels:

        for sT in sTargets:
            sNewMeshName = '%s__%s' % (sM,sT)

            if cmds.objExists(sNewMeshName):
                cmds.warning('%s already exists' % sNewMeshName)
                sReturn.append(sNewMeshName)
                continue

            sNewMesh = utils._duplicateGeoClean(sM, sName=sNewMeshName)
            try: cmds.parent(sNewMesh, w=True)
            except: pass

            if not bRigidIslands:
                sModelTemp = utils._duplicateGeoClean(sTargetsModel, bSetToOrigMesh=False)
                sWrap, sBase = deformers.createWrap(sNewMesh, sModelTemp)
                cmds.blendShape(sT, sModelTemp, w=[0,1], topologyCheck=False)
                cmds.delete(sNewMesh, ch=True)
                cmds.delete(sBase)
                cmds.delete(sModelTemp)
            else:
                geometry.warpRigidIslands(sNewMesh, sTargetsModel, sT)

            # if sT == 'browLower':
            #     cmds.select(sModelTemp)
            #     iii

            aPointsA = patch.patchFromName(sNewMesh).getPoints()
            aPointsB = patch.patchFromName(sM).getPoints()
            aDiffs = np.linalg.norm(aPointsB-aPointsA, axis=-1)
            fMaxDiff = np.max(aDiffs)
            if fMaxDiff < fMinimumChange:
                cmds.warning('not warping %s with %s, because it didn\'t have any changes' % (sT, sTargetsModel))
                cmds.delete(sNewMesh)
                continue

            sReturn.append(sNewMesh)

    return sReturn


def disconnectTargetGeos(sBlendShape):
    sConns = cmds.listConnections('%s.inputTarget' % sBlendShape, p=True, c=True, s=True, d=False)
    for i in range(0,len(sConns),2):
        cmds.disconnectAttr(sConns[i+1], sConns[i])

def getUniqueBlendShapeTargetName(sBlendShape, sTarget):

    if not cmds.objExists('%s.%s' % (sBlendShape, sTarget)):
        return sTarget

    sTarget, iNumber = utils.getNumberAtEnd(sTarget)
    while True:
        iNumber += 1
        sNewTarget = '%s%d' % (sTarget, iNumber)
        if not cmds.objExists('%s.%s' % (sBlendShape, sNewTarget)):
            return sNewTarget


def getOrderedTargets(sBlendShape, bSkipDoubleUnderscored=False):
    dTargets = getTargetsDictFromBlendShape(sBlendShape)
    sTargets = []
    for iIndex in dTargets.keys():
        sTarget = dTargets[iIndex]
        if bSkipDoubleUnderscored and sTarget.startswith('__'):
            continue
        else:
            sTargets.append(sTarget)
    return sTargets


def getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=False):
    sAliases = cmds.aliasAttr(sBlendShape, q=True)
    if not sAliases:
        return {}
    sTargets = sAliases[::2]
    iIds = [utils.intFromComponent(sComponent) for sComponent in sAliases[1::2]]
    if bPerTargetNames:
        return dict(list(zip(sTargets, iIds)))
    else:
        return dict(list(zip(iIds, sTargets)))



def getFirstAvailableTargetIndexFromBlendShape(sBlendShape):
    dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    iIndices = list(dTargets.values())
    iIndices.sort()
    iFirstIndex = len(iIndices)
    for i,iIndex in enumerate(iIndices):
        if i != iIndex:
            iFirstIndex = i
            return iFirstIndex, False
    return iFirstIndex, True


def addTargets(sGeometry, sTargets, bFoc=True, sAliasAttrs=None, bTopologyCheck=False, bDisconnectGeo=False, bWorld=False):
    sOrigin = 'world' if bWorld else 'local'
    sTargets = utils.toList(sTargets)

    if sAliasAttrs != None:
        sAliasAttrs = utils.toList(sAliasAttrs)
        if len(sAliasAttrs) != len(sTargets):
            raise Exception('if there are alias attributes specified, they need to have same length as targets')
        sAliasDuplicates = utils.getDuplicates([sA for sA in sAliasAttrs if sA != None])
        if len(sAliasDuplicates):
            raise Exception('there are non unique aliases: %s' % utils.listToString(sAliasDuplicates))

    sBlendShapes = deformers.listAllDeformers(sGeometry, sFilterTypes=['blendShape'])
    bCleanIndices = False
    sReturnTargets = []
    if sBlendShapes:
        sBs = sBlendShapes[0]
        sGeo = cmds.deformer(sBs, q=True, g=True)[0]

        for t, sT in enumerate(sTargets):
            if sT == None:
                sReturnTargets.append(None)
                continue

            if bCleanIndices:
                iNewIndex += 1
            else:
                iNewIndex, bCleanIndices = getFirstAvailableTargetIndexFromBlendShape(sBs)

            if sAliasAttrs:
                sUniqueAliasAttr = getUniqueBlendShapeTargetName(sBs, sAliasAttrs[t]) # we rely on this being the exact name of target that cmds.blendShape will create
                cmds.blendShape(sBs, e=True, t=[sGeo, iNewIndex, sT, 1.0], topologyCheck=bTopologyCheck, o=sOrigin)

                if sT != sAliasAttrs[t]:
                    try:
                        cmds.aliasAttr(sUniqueAliasAttr, '%s.w[%d]' % (sBs, iNewIndex))
                    except Exception as e:
                        raise Exception('BLENDSHAPE: %s - %s' % (sBs, e))
                sReturnTargets.append('%s.%s' % (sBs,sUniqueAliasAttr))
            else:
                sReturnAttr = '%s.%s' % (sBs,sT)
                if not cmds.objExists(sReturnAttr):
                    cmds.blendShape(sBs, e=True, t=[sGeo, iNewIndex, sT, 1.0], topologyCheck=bTopologyCheck, o=sOrigin)
                    sReturnTargets.append(sReturnAttr)
                else:
                    sConnections = cmds.listConnections(sReturnAttr, s=True, d=False, p=True)
                    if not sConnections: # there's a blendshape with no connections. Let's just return that
                        sReturnTargets.append(sReturnAttr)
                    else:
                        sCurrentSource = sConnections[0]
                        sAddition = nodes.createAdditionNode([sCurrentSource])
                        cmds.connectAttr(sAddition, sReturnAttr, force=True)
                        sReturnTargets.append('%s.input1D[1]' % sAddition.split('.')[0])

            if bDisconnectGeo:
                sGeoPlug = '%s.inputTarget[0].inputTargetGroup[%d].inputTargetItem[6000].inputGeomTarget' % (
                sBs, iNewIndex)
                sConns = cmds.listConnections(sGeoPlug, p=True, s=True, d=False)
                cmds.disconnectAttr(sConns[0], sGeoPlug)


    else:
        sNamespace, sG = utils.splitNamespace(sGeometry)
        sName = '%sblendShape__%s' % (sNamespace, sG)
        sBs = cmds.blendShape(sTargets, sGeometry, n=sName, foc=bFoc, topologyCheck=bTopologyCheck, o=sOrigin)[0]
        sReturnTargets = ['%s.%s' % (sBs, sT.split('|')[-1]) for sT in sTargets]
        if sAliasAttrs:
            for t,sTargetAttr in enumerate(sReturnTargets):
                if sTargetAttr.split('.')[-1] != sAliasAttrs[t]:
                    try:
                        cmds.aliasAttr(sAliasAttrs[t], '%s.w[%d]' % (sBs, t))
                    except Exception as e:
                        raise Exception('Blendshape: %s, Mesh: %s -> %s' % (sBs, sGeometry, e))

                    sReturnTargets[t] = '%s.%s' % (sBs, sAliasAttrs[t])
        if bDisconnectGeo:
            disconnectTargetGeos(sBs)

    return sReturnTargets



def createSculptAnimationSelected():
    sInterpolators = [sO for sO in cmds.ls(sl=True, et='transform') if cmds.objExists('%s.xPoses' % sO)]

    for sI in sInterpolators:
        dPoses = getPosesDictFromInterp(sI)
        sCtrl = cmds.getAttr('%s.sCtrl' % sI)
        for p, fEuler in enumerate(dPoses.values()):
            iTime = 1 if p == 0 else p*10
            for a, sA in enumerate(['rx','ry','rz']):
                try: cmds.setKeyframe('%s.%s' % (sCtrl, sA), v=fEuler[a], t=iTime)
                except: pass


dControls = {}




def _mirrorAttrsDict(dDict):
    for sAttr in list(dDict.keys()):
        if utils.getSide(sAttr) == 'l':
            sRightAttr = utils.getMirrorName(sAttr)
            if sRightAttr not in dDict:
                dDict[sRightAttr] = dDict[sAttr]
    return dDict


def _mirrorAttrsList(sList):
    sAdd = []
    for sAttr in sList:
        if utils.getSide(sAttr) == 'l':
            sRightAttr = utils.getMirrorName(sAttr)
            if sRightAttr not in sList:
                sAdd.append(sRightAttr)
    sList += sAdd
    return sList


def _separateAttrKeysIntoSides(dDict, bMirror=True):
    if bMirror:
        sLefts, sRights = [], []
        for sAttr in list(dDict.keys()):
            sSide = utils.getSide(sAttr)
            if sSide == 'l':
                sLefts.append(sAttr)
            elif sSide == 'r':
                sRights.append(sAttr)
            elif utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                sLefts.append(sAttr)
                sRights.append(sAttr)
    else:
        sLefts = list(dDict.keys())
        sRights = []

    return sLefts, sRights


def _separateAttrListIntoSides(sList, bMirror=True):
    if bMirror:
        sLefts, sRights = [], []
        for sAttr in sList:
            sSide = utils.getSide(sAttr)
            if sSide == 'l':
                sLefts.append(sAttr)
            elif sSide == 'r':
                sRights.append(sAttr)
            elif utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                sLefts.append(sAttr)
                sRights.append(sAttr)
    else:
        sLefts = list(sList)
        sRights = []
    return sLefts, sRights




def bake(sMesh=None, sBlendShape=None, sPrefix='', bSkipUnchanged=False, bSkipDoubleUnderscored=False):
    sResult = []
    dPrevious = {}

    dCombinationShapes = {}
    sSkipped = []
    if bSkipUnchanged:
        aDefaultPoints = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True)).reshape(-1, 3)

    sOrderedTargets = getOrderedTargets(sBlendShape, bSkipDoubleUnderscored=bSkipDoubleUnderscored)
    for sTarget in sOrderedTargets:
        sAttr = '%s.%s' % (sBlendShape, sTarget)

        if cmds.getAttr(sAttr, lock=True):
            continue

        sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)

        if sConns:
            sNode = sConns[0].split('.')[0]
            if cmds.objectType(sNode) == 'combinationShape':
                dCombinationShapes[sAttr] = cmds.listConnections(sNode, s=True, d=False, p=True)
            else:
                cmds.disconnectAttr(sConns[0], sAttr)
                dPrevious[sAttr] = sConns[0]
                cmds.setAttr(sAttr, 0)
        else:
            dPrevious[sAttr] = cmds.getAttr(sAttr)
            cmds.setAttr(sAttr, 0)

    sReturnTargets = []
    for sTarget in sOrderedTargets:
        sAttr = '%s.%s' % (sBlendShape, sTarget)

        if cmds.getAttr(sAttr, lock=True):
            continue

        if sAttr in dCombinationShapes:
            for sA in dCombinationShapes[sAttr]:
                cmds.setAttr(sA, 1.0)
        else:
            cmds.setAttr(sAttr, 1.0)

        if bSkipUnchanged:
            aTargetPoints = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True)).reshape(-1,3)
            aDiff = aTargetPoints - aDefaultPoints
            aLengths = np.linalg.norm(aDiff, axis=-1)
            if not len(np.where(aLengths > 0.001)[0]):
                sSkipped.append(sTarget)
                continue

        sTargetName = '%s%s' % (sPrefix, sTarget)
        sDupl = cmds.duplicate(sMesh, n=sTargetName)[0]
        if sDupl.split('|')[-1] != sTargetName:
            sDupl = cmds.rename(sDupl, sTargetName)

        sResult.append(sDupl)
        sReturnTargets.append(sTarget)

        if sAttr in dCombinationShapes:
            for sA in dCombinationShapes[sAttr]:
                cmds.setAttr(sA, 0.0)
        else:
            cmds.setAttr(sAttr, 0.0)



    for sAttr, xValue in list(dPrevious.items()):
        if utils.isStringOrUnicode(xValue):
            cmds.connectAttr(xValue, sAttr)
        else:
            cmds.setAttr(sAttr, xValue)

    return sResult, sReturnTargets, sSkipped






def connectTargetsBody(sModel, sTarget, sDriversGetAttr=[], bMirror=True, dPoses={}, bInvert=False,
                    fSplitRadius=0.2, sBlendShape=None, bStopBeforeInvert=False, bStopBeforeMirror=False, bAppleBlendShapes=False, sSecondaryModels=[],
                    sAlias=None, bReturnIfNotExist=False, iCombineMode=CombineMode.minimum, xMirrorAxis=None, sMirrorBase=None, iDrivenKeyCurveType=DrivenKeyCurveType.linear):


    # dMultDrivers will need to get into the flag list and tested properly
    dMultDrivers = {}



    if sTarget != None and not cmds.objExists(sTarget) and bReturnIfNotExist:
        print('skipping target "%s", because it doesn\'t exist.' % sTarget)
        return


    sDriversGetAttr = list(sDriversGetAttr)
    dPoses = dict(dPoses)
    dMultDrivers = dict(dMultDrivers)

    if bAppleBlendShapes:
        sUnrealCommands = ''
        import kangarooTabTools.unreal as unreal


    if sTarget == None:
        sTarget = cmds.duplicate(sModel)[0]
        if cmds.listRelatives(sTarget, p=True):
           cmds.parent(sTarget, w=True)

    print('\n\n\n ============================= sTarget: %s (%s) - secondary models: %s' % (sTarget, sModel, sSecondaryModels))

    if not cmds.objExists(sTarget):
        raise Exception('Target %s doesn\'t exist.' % sTarget)

    if sBlendShape == None:
        sBlendShape = 'blendShape__%s' % sModel.split(':')[-1]
        if not cmds.objExists(sBlendShape):
            deformers.preDeformationBlendshapeHack([], sModel, n=sBlendShape)
            if not cmds.objExists(sBlendShape):
                raise Exception('wasn\'t able to create blendShape')

    if sSecondaryModels:
        sSecondaryModels = [sSecM.strip() for sSecM in list(set(sSecondaryModels))] # in case there are white spaces

    sSecondaryBlendShapes = []
    for sSecondaryModel in sSecondaryModels:
        sSecondaryBlendShape = 'blendShape__%s' % sSecondaryModel
        if not cmds.objExists(sSecondaryBlendShape):
            sSecondaryBlendShapes.append(sSecondaryBlendShape)
            deformers.preDeformationBlendshapeHack([], sSecondaryModel, n=sSecondaryBlendShape)
            if not cmds.objExists(sSecondaryBlendShape):
                raise Exception('wasn\'t able to create blendShape (mesh: "%s", blendShape: "%s")' % (sSecondaryModel, sSecondaryBlendShape))
        sSecondaryBlendShapes.append(sSecondaryBlendShape)



    # clean dPoses
    for sKey, fValue in list(dPoses.items()):
        if utils.isStringOrUnicode(sKey) and utils.isStringOrUnicode(fValue): # poseInterpolator
            sInterp = sKey
            dInterp = getPosesDictFromInterp(sInterp)
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
            if ':' in sInterp:
                sCtrl = '%s:%s' % (':'.join(sInterp.split(':')[:-1]), sCtrl)
            print ('sCtrl: ', sCtrl)
            print ('fValue: ', fValue)
            print ('dInterp: ', dInterp)
            print ('dInterp[fValue]: ', dInterp[fValue])
            dPoses['%s.r' % sCtrl] = np.array(dInterp[fValue], dtype='float64')
            del dPoses[sKey]
            sDriversGetAttr.append('%s.%s' % (sInterp, fValue))
        elif isinstance(fValue, tuple): # this is for compound attributes
            dPoses[sKey] = np.array(fValue)
        elif isinstance(fValue, list):
            dPoses[sKey] = fValue # no change
        elif not isinstance(fValue, (int, float, type(None))):
            raise Exception('dPoses can only have floats, ints or None as values (%s, %s)' % (sTarget, dPoses))


    print('\n\n === target: ', sTarget)
    sInbetweens = []
    iInbetweens = []
    for sI in cmds.ls('%s__???' % sTarget, et='transform'):
        try: iNumber = int(sI.split('_')[-1])
        except: iNumber = None
        if iNumber:
            sInbetweens.append(sI)
            iInbetweens.append(iNumber)


    sTargets = [sTarget] + sInbetweens




    iInbetweens = [100] + iInbetweens

    aSorted = np.argsort(iInbetweens)

    sTargets = list(np.array(sTargets)[aSorted])
    iInbetweens = np.array(iInbetweens, dtype='float64')[aSorted]
    aPercs = iInbetweens * 0.01

    if bInvert:
        sNewTargetName = '%s_INV' % sTargets[0]
    else:
        sNewTargetName = str(sTargets[0])

    # dAllPoses = {}
    for sAttr in list(dPoses.keys()):
        if '.' not in sAttr:
            raise Exception('this is not an attribute: %s (dPoses)' % sAttr)
        if not cmds.objExists(sAttr):
            raise Exception('this attribute doesn\'t exist: %s' % sAttr)
        if bMirror:
            if utils.getSide(sAttr) == 'l':
                sRightAttr = utils.getMirrorName(sAttr)
                if sRightAttr not in dPoses:
                    dPoses[sRightAttr] = dPoses[sAttr]


    # make sure .r and .t endings are posed first
    sSortedPoseKeys = sorted(list(dPoses.keys()), key=lambda a:not a.endswith('.t') and not a.endswith('.r'))


    # dDefaultAttrs = {sA:cmds.getAttr(sA) for sA in dPoses.keys()}
    dDefaultAttrs = {}
    for sA in sSortedPoseKeys:
        fValue = cmds.getAttr(sA)
        if isinstance(fValue, (list,tuple)): # most likely rotation, in that case it'll look like [(0.0, 0.0, 90)]
            dDefaultAttrs[sA] = np.array(fValue[0], dtype='float64')
        else:
            dDefaultAttrs[sA] = fValue


    def _activatePose(fPerc):
        for sAttr in sSortedPoseKeys:
            fValue = dPoses[sAttr]

            _fPerc = 0.0 if fPerc == None else fPerc
            if isinstance(fValue, np.ndarray):
                if sAttr.endswith('.t') or sAttr.endswith('.translate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['tx','ty','tz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPoses[sAttr][a] * _fPerc + dDefaultAttrs[sAttr][a] * (1.0 - _fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                else:
                    cmds.setAttr(sAttr, *list(dPoses[sAttr] * _fPerc + dDefaultAttrs[sAttr] * (1.0-_fPerc)))

            elif isinstance(fValue, list):
                if fPerc == None:
                    cmds.setAttr(sAttr, dDefaultAttrs[sAttr])
                else:
                    cmds.setAttr(sAttr, dPoses[sAttr][1] * _fPerc + dPoses[sAttr][0] * (1.0-_fPerc))
            else:
                cmds.setAttr(sAttr, dPoses[sAttr] * _fPerc + dDefaultAttrs[sAttr] * (1.0-_fPerc))

    dDrivers = {}
    print ('bMirror: ', bMirror)
    print ('sDriversGetAttr: ', sDriversGetAttr)
    if sDriversGetAttr:
        for d in range(len(sDriversGetAttr)):
            if '.' not in sDriversGetAttr[d]:
                raise Exception('this is not an attribute: %s (sDriversGetAttr)' % sDriversGetAttr[d])
            sDriver = sDriversGetAttr[d]
            if bMirror:
                if utils.getSide(sDriver) == 'l':
                    sRightDriver = utils.getMirrorName(sDriver)
                    if sRightDriver not in sDriversGetAttr:
                        sDriversGetAttr.append(sRightDriver)

        print ('sDriversGetAttr xx: ', sDriversGetAttr)

        _activatePose(0.0)
        for sDriver in sDriversGetAttr:
            try:
                cmds.getAttr(sDriver)
            except:
                raise Exception('error getting attribute value for %s' % sDriver)
            dDrivers[sDriver] = [cmds.getAttr(sDriver)]

        _activatePose(1.0)
        for sDriver in sDriversGetAttr:
            dDrivers[sDriver].append(cmds.getAttr(sDriver))
            print ('dDrivers -1: ', dDrivers)

        _activatePose(None)


    # split dDrivers into left and right middles
    sReturnTargetAttrs = []
    sLeftRights = [], []
    sMiddles = []
    if bMirror:
        for sAttr in list(dDrivers.keys()):
            if utils.getSide(sAttr) == 'l': #''_l_' in sAttr:
                sLeftRights[0].append(sAttr)
                sRightAttr = utils.getMirrorName(sAttr) #.replace('_l_', '_r_')
                sLeftRights[1].append(sRightAttr)
                dDrivers[sRightAttr] = dDrivers[sAttr]
            else:
                if utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                    sMiddles.append(sAttr)
    else:
        sMiddles = list(dDrivers.keys())




    sMultDriversLeftRights = [], []
    sMultDriversMiddles = []
    if bMirror:
        for sAttr in list(dMultDrivers.keys()):
            if utils.getSide(sAttr) == 'l':
                sMultDriversLeftRights[0].append(sAttr)
                sRightAttr = utils.getMirrorName(sAttr)
                sMultDriversLeftRights[1].append(sRightAttr)
                dMultDrivers[sRightAttr] = dMultDrivers[sAttr]
            else:
                if utils.getSide(sAttr) == 'm':
                    sMultDriversMiddles.append(sAttr)
    else:
        sMultDriversMiddles = list(dMultDrivers.keys())


    for sAttr, xDriver in list(dMultDrivers.items()):
        dMultDrivers[sAttr] = _drivenKeys(sAttr, xDriver, iCurveType=iDrivenKeyCurveType)
    for sAttr, xDriver in list(dDrivers.items()):
        dDrivers[sAttr] = _drivenKeys(sAttr, xDriver, iCurveType=iDrivenKeyCurveType)



    if bInvert:

        for t,sT in enumerate(sTargets):

            sCurrentNewName = str(sNewTargetName)
            if t < len(sTargets)-1:
                sCurrentNewName = '%s_%03d' % (sCurrentNewName, iInbetweens[t])

            _activatePose(aPercs[t])

            if bStopBeforeInvert:
                cmds.select(sT, sModel)
                raise Exception('exception on purpose: stop before invertShapeDeformers (meshes are selected)')

            sInverted = geometry.invertShapeDeformers(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)
            try:cmds.setAttr('%s.v' % sInverted, cmds.getAttr('%s.v' % sT))
            except: pass

            for b, sSecondaryModel in enumerate(sSecondaryModels):
                sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                if cmds.objExists(sSecondaryT):
                    sSecondaryInverted = geometry.invertShapeDeformers(sSecondaryT, sSecondaryModel, sComboBlendShape=sSecondaryBlendShapes[b], sInvertName='%s__%s' % (sSecondaryModel, sCurrentNewName))
                    try:cmds.setAttr('%s.v' % sSecondaryInverted, cmds.getAttr('%s.v' % sT))
                    except: pass

            try: cmds.parent(sInverted, '_invertedShapes_')
            except: pass

            sTargets[t] = sInverted

        _activatePose(None)

    if len(sLeftRights[0]) or len(sMultDriversLeftRights[0]): # split between left and right, no bot and top
        if dMultDrivers:
            sMultDriverSides = [_combineValues(iCombineMode,
                [dMultDrivers[sAttr] for sAttr in sMultDriversLeftRights[0] + sMultDriversMiddles]),
                                _combineValues(iCombineMode, [dMultDrivers[sAttr] for sAttr in
                                                         sMultDriversLeftRights[1] + sMultDriversMiddles])]
        else:
            sMultDriverSides = None

        sMainDrivers = [None, None]
        sFactors = [], []
        for s, sSide in enumerate(['l', 'r']):
            for sAttr in sLeftRights[s] + sMiddles:
                sFactors[s].append(dDrivers[sAttr])

            sMainDrivers[s] = _combineValues(iCombineMode, sFactors[s])
            if bAppleBlendShapes:
                for sAttr in sLeftRights[s] + sMiddles:
                    if sAttr.startswith('appleFaceBlendshapes'):
                        sUnrealTarget = sAttr.split('.')[-1]
                        unreal.addEmptyUnrealTargets(sUnrealTarget)


        for i, sT in enumerate(sTargets):
            cmds.setAttr('%s.envelope' % sBlendShape, 0.0) # careful with this - added later on
            if sMirrorBase == None:
                sMirrorBase = sModel
            if bStopBeforeMirror:
                cmds.select(sMirrorBase, sT)
                raise Exception('exception on purpose: stop before geometry.splitShape() and addBlendShapeTargets() (meshes are selected)')
            ssSplitShapes = [geometry.splitShape(sT, sMirrorBase, fRadius=fSplitRadius, bUnParent=True, xMirrorAxis=xMirrorAxis)]
            sAliasAttrs = ssSplitShapes[-1] if sAlias == None else ['l_%s' % sAlias, 'r_%s' % sAlias]
            ssTargetAttrs = [deformers.addBlendShapeTargets(sModel, ssSplitShapes[-1], sAliasAttrs=sAliasAttrs)]

            for sSecondaryModel in sSecondaryModels:
                sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                if cmds.objExists(sSecondaryT):
                    ssSplitShapes.append(geometry.splitShape(sSecondaryT, sSecondaryModel, fRadius=fSplitRadius, bUnParent=True, xMirrorAxis=xMirrorAxis))
                    ssTargetAttrs.append(deformers.addBlendShapeTargets(sSecondaryModel, ssSplitShapes[-1], sAliasAttrs=sAliasAttrs))

            cmds.setAttr('%s.envelope' % sBlendShape, 1.0) # careful with this - added later on

            sReturnTargetAttrs += ssTargetAttrs
            for s, sSide in enumerate(['l', 'r']):
                if bAppleBlendShapes:
                    sUnrealCommands += '\nCOMBINE %s ' % ssSplitShapes[0][s]
                    for sRangeOut in sFactors[s]:
                        sRange = sRangeOut.split('.')[0]
                        sAppleBlendShape = cmds.listConnections('%s.valueX' % sRange, p=True)[0]
                        sUnrealCommands += '0 %s %0.3f %0.3f %0.3f %0.3f ' % (sAppleBlendShape.split('.')[-1],
                                                                            cmds.getAttr('%s.oldMinX' % sRange), cmds.getAttr('%s.oldMaxX' % sRange),
                                                                            cmds.getAttr('%s.minX' % sRange), cmds.getAttr('%s.maxX' % sRange))

                if len(sTargets) == 1:
                    if sMultDriverSides:
                        _combineValues(iCombineMode, [sMainDrivers[s], sMultDriverSides[s]], sTarget=[sTargetAttrs[s] for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]])
                    else:
                        [cmds.connectAttr(sMainDrivers[s], sTargetAttrs[s]) for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]]
                else:
                    if i == len(sTargets) - 1:  # the full one
                        if sMultDriverSides:
                            sDriven = nodes.setDrivenKey(sMainDrivers[s], [aPercs[i - 1], 1], None, [0, 1], sInTanType='linear', sOutTanType='linear')
                            _combineValues(iCombineMode, [sDriven, sMultDriverSides[s]], sTarget=[sTargetAttrs[s] for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]])
                        else:
                            [nodes.setDrivenKey(sMainDrivers[s], [aPercs[i - 1], 1], sTargetAttrs[s], [0, 1], sInTanType='linear', sOutTanType='linear')
                                for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]]
                    else:  # inbetween
                        if sMultDriverSides:
                            sDriven = nodes.setDrivenKey(sMainDrivers[s],
                                                         [aPercs[i - 1] if i > 0 else 0.0, aPercs[i],
                                                          aPercs[i + 1]], None, [0, 1, 0], sInTanType='linear', sOutTanType='linear')
                            _combineValues(iCombineMode, [sDriven, sMultDriverSides[s]], sTarget=[sTargetAttrs[s] for sTargetAttrs in ssTargetAttrs if sTargetAttrs[s]])
                        else:
                            for sTargetAttrs in ssTargetAttrs:
                                if sTargetAttrs[s]:
                                    nodes.setDrivenKey(sMainDrivers[s],
                                                       [aPercs[i - 1] if i > 0 else 0.0, aPercs[i], aPercs[i + 1]],
                                                       sTargetAttrs[s], [0, 1, 0], sInTanType='linear', sOutTanType='linear')


    else: # no splitting

        if dMultDrivers:
            sMultDriverMiddle = _combineValues(iCombineMode, [dMultDrivers[sAttr] for sAttr in sMultDriversMiddles])
        else:
            sMultDriverMiddle = None

        sFactors = []
        for sAttr in sMiddles:
            sFactors.append(dDrivers[sAttr])

        print ('dDrivers: ', dDrivers)
        print ('dPoses: ', dPoses)
        sMainDriver = _combineValues(iCombineMode, sFactors)

        if bAppleBlendShapes:
            for sAttr in sMiddles:
                if sAttr.startswith('appleFaceBlendshapes'):
                    sUnrealTarget = sAttr.split('.')[-1]
                    unreal.addEmptyUnrealTargets(sUnrealTarget)

        for i, sT in enumerate(sTargets):
            sAliasAttr = sT if sAlias == None else sAlias
            sTargetAttrs = [deformers.addBlendShapeTargets(sModel, sT, sAliasAttrs=sAliasAttr)[0]]
            for sSecondaryModel in sSecondaryModels: # not fully tested yet
                sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                if cmds.objExists(sSecondaryT):
                    sTargetAttrs.append(deformers.addBlendShapeTargets(sSecondaryModel, sSecondaryT, sAliasAttrs=sAliasAttr)[0])

            sReturnTargetAttrs.append(sTargetAttrs)

            if len(sTargets) == 1:
                for sTargetAttr in sTargetAttrs:
                    if sMultDriverMiddle:
                        _combineValues(iCombineMode, [sMainDriver, sMultDriverMiddle], sTarget=sTargetAttr)
                    else:
                        cmds.connectAttr(sMainDriver, sTargetAttr)
            else:
                for sTargetAttr in sTargetAttrs:

                    if i == len(sTargets) - 1:  # the full one
                        sDrivenKey = nodes.setDrivenKey(sMainDriver, [aPercs[i - 1], 1], None, [0, 1], sInTanType='linear', sOutTanType='linear')
                    else:  # inbetween
                        sDrivenKey = nodes.setDrivenKey(sMainDriver, [aPercs[i - 1] if i > 0 else 0.0, aPercs[i],
                                                         aPercs[i + 1]], None, [0, 1, 0], sInTanType='linear', sOutTanType='linear')
                    if sMultDriverMiddle:
                        _combineValues(iCombineMode, [sDrivenKey, sMultDriverMiddle], sTarget=sTargetAttr)
                    else:
                        cmds.connectAttr(sDrivenKey, sTargetAttr)

        if bAppleBlendShapes:
            sUnrealCommands += '\nCOMBINE %s ' % sT
            for sRangeOut in sFactors:
                sRange = sRangeOut.split('.')[0]
                sAppleBlendShape = cmds.listConnections('%s.valueX' % sRange, p=True)[0]

                sUnrealCommands += '0 %s %0.3f %0.3f %0.3f %0.3f ' % (sAppleBlendShape.split('.')[-1],
                                                                      cmds.getAttr('%s.oldMinX' % sRange),
                                                                      cmds.getAttr('%s.oldMaxX' % sRange),
                                                                      cmds.getAttr('%s.minX' % sRange),
                                                                      cmds.getAttr('%s.maxX' % sRange))




    for sCtrlAttr in list(dPoses.keys()):
        sCtrl = sCtrlAttr.split('.')[0]
        addIgnoreAttachTargets(sCtrl, utils.flattenedList(sReturnTargetAttrs))

    if bAppleBlendShapes:
        return sUnrealCommands
    else:
        return sReturnTargetAttrs




def getInbetweenTargetIndices(sBlendShape, iTargetIndex):
    '''
    This returns indices between 5000 and 6000, 6000 being the full shape
    passing sMesh seems to be irrelevant, since it seems for each mesh/shape it seems to return all target indices. Not sure if that's a bug...
    '''
    import maya.OpenMaya as OpenMaya
    import maya.OpenMayaAnim as OpenMayaAnim

    fnBlendShape = OpenMayaAnim.MFnBlendShapeDeformer(utils.getDependNodeOldApi(sBlendShape))

    mAllObjectsArray = OpenMaya.MObjectArray()
    fnBlendShape.getBaseObjects(mAllObjectsArray)
    mAllObjectsArray = [mAllObjectsArray[i] for i in range(mAllObjectsArray.length())]

    iAllIndices = []
    iArray = OpenMaya.MIntArray()
    for mObj in mAllObjectsArray:
        try:
            fnBlendShape.targetItemIndexList(iTargetIndex, mObj, iArray) # on some shapes it just errors with "No element at given index"
        except:
            iAllIndices.append(6000)
            break
        iAllIndices.extend(list(iArray))
    iAllIndices = sorted(list(set(iAllIndices)))
    if 5000 in iAllIndices:
        iAllIndices.remove(5000)
    return iAllIndices


def getInbetweenFloats(sBlendShape, iTargetIndex):
    iIndices = getInbetweenTargetIndices(sBlendShape, iTargetIndex)
    return [utils.projectToRange(float(iIndex), 5000, 6000, 0, 1.0) for iIndex in iIndices if iIndex > 5000 and iIndex < 6000]


def addEmptyTarget(sBlendShape, sTarget, bReturnIfAlreadyExists=False):
    ''' only supports blendShapes with one mesh'''

    sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
    if cmds.objExists(sTargetAttr):
        if bReturnIfAlreadyExists:
            return sTargetAttr
        else:
           raise Exception('Target "%s" already exists on blendShape "%s"' % (sTarget, sBlendShape))

    sMesh = deformers.getGeoFromDeformer(sBlendShape, bTransform=True)
    sTempTarget = cmds.duplicate(sMesh)[0]
    addTargets(sMesh, [sTempTarget], sAliasAttrs=sTarget)
    cmds.delete(sTempTarget)
    resetTargetDeltasFull(sBlendShape, sTarget)
    return sTargetAttr


def renameTarget(sBlendShape, sTarget, sNewTarget):
    dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    iTarget = dTargets[sTarget]
    cmds.aliasAttr(sNewTarget, '%s.w[%d]' % (sBlendShape, iTarget))


def deleteBlendShapeTarget(sBlendShape, sTargets, bErrorIfNotExists=True):
    for sTarget in utils.toList(sTargets):
        sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
        if not cmds.objExists(sTargetAttr):
            if bErrorIfNotExists:
                raise Exception('Target "%s" doesn\'t exist on "%s"' % (sTarget, sBlendShape))
            else:
                continue
        sConnections = cmds.listConnections(sTargetAttr, s=True, d=False, p=True)
        if sConnections:
            cmds.disconnectAttr(sConnections[0], sTargetAttr)
        cmds.setAttr(sTargetAttr, 0.0)
        cmds.aliasAttr(sTargetAttr, rm=True)



def resetTargetDeltasFull(sBlendShape, iTarget):
    if isinstance(iTarget, str):
        iTarget = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)[iTarget]

    cmds.undoInfo(openChunk=True)
    try:
        iMesh = 0

        fZeroPoints = [(0.0, 0.0, 0.0, 1.0)]
        cmds.setAttr('%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' %
                     (sBlendShape, iMesh, iTarget),
                     len(fZeroPoints), *fZeroPoints, type='pointArray')
        sZeroPoints = ['vtx[0]']
        cmds.setAttr('%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' %
                     (sBlendShape, iMesh, iTarget),
                     len(sZeroPoints), *sZeroPoints, type='componentList')
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


