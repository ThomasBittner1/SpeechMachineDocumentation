###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.utilFunctions as utils
import re
import numpy as np
import maya.api.OpenMaya as OpenMaya2
import os
from collections import OrderedDict


def addAttr(*args, **kwargs):

    try:
        bReturnIfExists = kwargs['bReturnIfExists']
        del kwargs['bReturnIfExists']
    except:
        bReturnIfExists = False

    try:
        bCb = kwargs['cb']
        del kwargs['cb']
    except:
        bCb = False

    try:
        sTarget = kwargs['sTarget']
        del kwargs['sTarget']
    except:
        sTarget = None

    try:
        sAddSidePostFix = kwargs['sAddSidePostFix']
        del kwargs['sAddSidePostFix']
    except:
        sAddSidePostFix = None
    if sAddSidePostFix != None:
        sLn = kwargs['ln']
        if sAddSidePostFix.startswith('l'):
            sLn = '%sLeft' % sLn
        elif sAddSidePostFix.startswith('r'):
            sLn = '%sRight' % sLn
        elif sAddSidePostFix.startswith('m'):
            sLn = '%sMiddle' % sLn
        else:
            raise Exception('don\'t recognize what side "%s" is' % sAddSidePostFix)
        kwargs['ln'] = sLn

    sAttr = '%s.%s' % (args[0], kwargs['ln'])
    if cmds.objExists(sAttr):
        if bReturnIfExists:
            return sAttr
        else:
            raise Exception('attribute %s already exists!' % sAttr)

    try:
        fMultipl = kwargs['fMultipl']
        del kwargs['fMultipl']
    except:
        fMultipl = None


    cmds.addAttr(*args, **kwargs)

    if kwargs.get('at', 'double').endswith('3'):
        kChildrenArgs = dict(kwargs)
        sAttrName = kwargs['ln']
        kChildrenArgs['at'] = kwargs['at'][:-1]
        kChildrenArgs['p'] = sAttrName
        for i in range(3):
            kChildrenArgs['ln'] = '%s%s' % (sAttrName, ['X','Y','Z'][i])
            cmds.addAttr(*args, **kChildrenArgs)

    if bCb:
        cmds.setAttr(sAttr, cb=True)

    if sTarget:
        _connectTarget(sAttr, sTarget)

    if fMultipl:
        sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True)
        cmds.connectAttr(sAttr, '%s.input1X' % sMultipl)
        cmds.setAttr('%s.input2X' % sMultipl, fMultipl)
        return '%s.%s' % (sMultipl, 'outputX')
    else:
        return sAttr


def deleteConnection(sAttr):
    sConnections = cmds.listConnections(sAttr, p=True, s=True, d=False)
    if sConnections:
        cmds.disconnectAttr(sConnections[0], sAttr)



def deleteConnectionsAndItself(sNodes):
    '''
    this is depricated!! use deleteConnectionsAndItself3() instead
    '''
    if utils.getPythonVersion() == 3:
        deleteConnectionsAndItself2(sNodes)
    else: # following code is bad. It looks for all nodes for each node, and in the end doesn't delete it. Also it doesn't handle outgoing connections
        sDelete = []
        for sNode in sNodes:
            if cmds.objExists(sNode):
                sConnections = cmds.listConnections(sNodes, p=True, s=True, d=False, c=True)
                if sConnections:
                    for i in range(0,len(sConnections),2):
                        cmds.disconnectAttr(sConnections[i], sConnections[i+1])
                    sDelete.append(sNode)
            sDelete.append(sNode)



def deleteConnectionsAndItself2(sNodes):
    '''
    # depricated, use deleteConnectionsAndItself3 instead
    '''
    sNodes = utils.toList(sNodes)
    sDelete = []
    for sNode in sNodes:
        if cmds.objExists(sNode):

            sConnections = cmds.listConnections(sNode, p=True, s=True, d=False, c=True) or [] # incoming connections:
            for i in range(0,len(sConnections),2):
                cmds.disconnectAttr(sConnections[i+1], sConnections[i])

            sConnections = cmds.listConnections(sNode, p=True, s=False, d=True, c=True) or [] # outgoing connections
            for i in range(0,len(sConnections),2):
                cmds.disconnectAttr(sConnections[i], sConnections[i+1])

        sDelete.append(sNode)

    if sDelete:
        cmds.delete(sDelete)



def deleteConnectionsAndItself3(sNodes):
    sNodes = utils.toList(sNodes)
    sDelete = []
    for sNode in sNodes:
        if cmds.objExists(sNode):

            sConnections = cmds.listConnections(sNode, p=True, s=False, d=True, c=True) or [] # outgoing connections
            for i in range(0,len(sConnections),2):
                try:
                    xValue = cmds.getAttr(sConnections[i+1])
                except:
                    continue
                cmds.disconnectAttr(sConnections[i], sConnections[i+1])
                try:
                    cmds.setAttr(sConnections[i+1], xValue) # normal value?
                except:
                    try:
                        cmds.setAttr(sConnections[i+1], *xValue[0]) # vector?
                    except:
                        try:
                            cmds.setAttr(sConnections[i+1], *xValue, type='matrix') # matrix?
                        except:
                            print('sConnections[i+1]: ', sConnections[i + 1])
                            print('xValue: ', xValue)
                            raise

            sConnections = cmds.listConnections(sNode, p=True, s=True, d=False, c=True) or [] # incoming connections:
            for i in range(0,len(sConnections),2):
                cmds.disconnectAttr(sConnections[i+1], sConnections[i])


        sDelete.append(sNode)

    if sDelete:
        cmds.delete(sDelete)



def lockAndHide(sObj, sAttrs=[]):
    for sAttr in sAttrs:
        cmds.setAttr('%s.%s' % (sObj, sAttr), lock=True, keyable=False, channelBox=False)


def addOffOnAttr(sNode, sAttr, bDefaultValue=True, bLock=False, bReturnNonIfExists=False, bReturnIfExists=False, sTarget=[], bNoAnim=False, bForce=False):
    if bReturnNonIfExists and cmds.objExists('%s.%s' % (sNode,sAttr)):
        return None
    elif bReturnIfExists and cmds.objExists('%s.%s' % (sNode,sAttr)):
        sAttr = '%s.%s' % (sNode,sAttr)
    else:
        sAttr = addAttr(sNode, ln=sAttr, at='enum', en='Off:On', defaultValue=bDefaultValue, k=False if bNoAnim else True, cb=True)
        if bLock:
            cmds.setAttr(sAttr, lock=True)

    for sT in utils.toList(sTarget):
        try:
            cmds.connectAttr(sAttr, sT, force=bForce)
        except:
            raise Exception('Cannot connect %s -> %s' % (sAttr, sT))
    return sAttr


def addStringAttr(sGrp, sAttr, sText, bLock=False, bSkipIfAlreadyThere=False):
    if bSkipIfAlreadyThere and cmds.attributeQuery(sAttr, node=sGrp, exists=True):
        return '%s.%s' % (sGrp, sAttr)
    sAttr = addAttr(sGrp, ln=sAttr, dt='string', k=False, bReturnIfExists=True)
    bLockedBefore = cmds.getAttr(sAttr, lock=True)
    cmds.setAttr(sAttr, q=True, lock=False)
    cmds.setAttr(sAttr, sText, type='string')
    if bLockedBefore or bLock: cmds.setAttr(sAttr, lock=True)
    return sAttr


def transferStringAttr(sFromAttr, sToObj, bErrorIfNotExists=True):
    if not cmds.objExists(sFromAttr):
        if bErrorIfNotExists:
            raise Exception('attribute doesn\'t exist: %s' % sFromAttr)
        else:
            return None

    addStringAttr(sToObj, sFromAttr.split('.')[-1], cmds.getAttr(sFromAttr))



def getStringAttr(sGrp, sAttr, sDefault, bCreateIfNotExists=False):
    sFullAttr = '%s.%s' % (sGrp, sAttr)
    if cmds.objExists(sFullAttr):
        return cmds.getAttr(sFullAttr)
    else:
        if bCreateIfNotExists:
            addStringAttr(sGrp, sAttr, sDefault, bLock=True)
        return sDefault


def addToListStringAttr(sGrp, sAttr, sAdd=[], bLock=False):
    sCurrent = eval(getStringAttr(sGrp, sAttr, '[]'))
    addStringAttr(sGrp, sAttr, sCurrent+sAdd, bLock=bLock)


def addMatrixAttr(sGrp, sAttr, fMatrix, bLock=False):
    sAttr = addAttr(sGrp, ln=sAttr, dt='matrix', k=False, bReturnIfExists=True)
    bLockedBefore = cmds.getAttr(sAttr, lock=True)
    cmds.setAttr(sAttr, q=True, lock=False)
    cmds.setAttr(sAttr, fMatrix, type='matrix')
    if bLockedBefore or bLock: cmds.setAttr(sAttr, lock=True)
    return sAttr



def addSeparatorAttr(sObj, sName):
    sLongName = '__%s__' % sName.upper()
    cmds.addAttr(sObj, sn=sName, ln=sLongName, at='enum', en='______', k=True)
    cmds.setAttr('%s.%s' % (sObj, sLongName), lock=True)



def createComposeMatrixNode(xTranslate=None, xRotate=None, xQuat=None, xScale=None, xShear=None, sTarget=None, bForce=False, sName='noname', bJustValues=False):
    sNode = cmds.createNode('composeMatrix', name='composeMatrix_%s' % sName)
    if not isinstance(xTranslate, type(None)):
        _connectOrSetVector(xTranslate, '%s.inputTranslate' % sNode, ['inputTranslateX', 'inputTranslateY', 'inputTranslateZ'])
    if not isinstance(xRotate, type(None)):
        _connectOrSetVector(xRotate, '%s.inputRotate' % sNode, ['inputRotateX', 'inputRotateY', 'inputRotateZ'])
    if not isinstance(xQuat, type(None)):
        _connectOrSetVector(xQuat, '%s.inputQuat' % sNode)
    if not isinstance(xScale, type(None)):
        _connectOrSetVector(xScale, '%s.inputScale' % sNode, ['inputScaleX', 'inputScaleY', 'inputScaleZ'])
    if not isinstance(xShear, type(None)):
        _connectOrSetVector(xShear, '%s.inputShear' % sNode, ['inputShearX', 'inputShearY', 'inputShearZ'])

    sOutput = '%s.outputMatrix' % sNode

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)
        deleteConnectionsAndItself(sNode)
        return fOutput

    if sTarget:
        _connectOrSetMatrix(sOutput, sTarget, bForce=bForce)
    return sOutput




def createInverseMatrix(xInputMatrix, sTarget=None, sName='noname', sFullName=None, bJustValues=False):

    if utils.isStringOrUnicode(xInputMatrix) and xInputMatrix.endswith('.worldMatrix'):
        return '%s.worldInverseMatrix' % xInputMatrix.split('.')[0]

    if not sFullName:
        sFullName = 'inverseMatrix_%s' % sName
    sNode = cmds.createNode('inverseMatrix', name=sFullName)
    _connectOrSetMatrix(xInputMatrix, '%s.inputMatrix' % sNode)
    sOutput = '%s.outputMatrix' % sNode

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)
        disconnectIncomingAttrs(sNode)
        cmds.delete(sNode)
        return fOutput

    if sTarget:
        cmds.connectAttr(sOutput, sTarget)

    return sOutput


#depricated, use getRotationMatrix2() instead, to get shearing if bScale is on
def getRotationMatrix(sMatrix, bScale=True, sName='noname'):
    sDecomp = createDecomposeMatrix(sMatrix, sName=sName).split('.')[0]
    sRotMatrix = createComposeMatrixNode(xRotate='%s.outputRotate' % sDecomp,
                                       xScale='%s.outputScale' % sDecomp if bScale else None, sName=sName)
    return sRotMatrix


def getRotationMatrix2(sMatrix, bScale=True, sName='noname'):
    sDecomp = createDecomposeMatrix(sMatrix, sName=sName).split('.')[0]
    sRotMatrix = createComposeMatrixNode(xRotate='%s.outputRotate' % sDecomp,
                                         xScale='%s.outputScale' % sDecomp if bScale else None,
                                         xShear='%s.outputShear' % sDecomp if bScale else None,
                                         sName=sName)
    return sRotMatrix


# bConnectRotateOrder should be True, but it's False to not change old rig behavior
def createDecomposeMatrix(xInputMatrix, sTargetPos=None, sTargetRot=None, sTargetScale=None, bConnectRotateOrder=False, sName='noname', sFullName=None, bReturnRotate=False, bJustValues=False, bForce=False):
    if not sFullName:
        sFullName = 'decomposeMatrix_%s' % sName

    sNode = cmds.createNode('decomposeMatrix', name=sFullName)
    _connectOrSetMatrix(xInputMatrix, '%s.inputMatrix' % sNode)
    sOutputPos = '%s.outputTranslate' % sNode
    sOutputRot = '%s.outputRotate' % sNode
    sOutputScale = '%s.outputScale' % sNode
    if sTargetPos:
        cmds.connectAttr(sOutputPos, sTargetPos, force=bForce)
    if sTargetRot:
        cmds.connectAttr(sOutputRot, sTargetRot, force=bForce)
        if bConnectRotateOrder:
            cmds.setAttr('%s.inputRotateOrder' % sNode, cmds.getAttr('%s.rotateOrder' % sTargetRot.split('.')[0]))

    if sTargetScale:
        cmds.connectAttr(sOutputScale, sTargetScale, force=bForce)

    sOutput = sOutputRot if bReturnRotate else sOutputPos

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)[0]
        disconnectIncomingAttrs(sNode)
        cmds.delete(sNode)
        return fOutput
    else:
        return sOutput


def scaleFromXform(sTransform):
    sDecompose = createDecomposeMatrix('%s.worldMatrix' % sTransform)
    return '%s.outputScaleX' % sDecompose.split('.')[0]



def getWorldPoint(sTransform, bDecomposeMatrix=False):
    if bDecomposeMatrix:
        sMatrixNode = 'decomposeMatrixWorldPoint_%s' % sTransform
        if not cmds.objExists(sMatrixNode):
            return createDecomposeMatrix('%s.worldMatrix' % sTransform, sFullName=sMatrixNode)
        else:
            return '%s.outputTranslate' % sMatrixNode
    else:
        if cmds.objectType(sTransform) == 'locator':
            sWorldPoint = '%s.worldPosition' % sTransform
        elif cmds.objectType(sTransform) in ('joint', 'transform'):
            sChildren = cmds.listRelatives(sTransform, s=True, typ='locator', f=True)
            if sChildren:
                sWorldPoint = '%s.worldPosition' % cmds.ls(sChildren[0], sn=True)[0]
            else:
                sFromTransformLong = cmds.ls(sTransform, l=True)[0]
                sLocator = cmds.createNode('locator', name='%sShape' % sTransform)
                sOldParent = cmds.listRelatives(sLocator, p=True, f=True)
                sLocator = cmds.parent(sLocator, sFromTransformLong, s=True, add=True)[0]
                cmds.delete(sOldParent)
                cmds.setAttr('%s.v' % sLocator, False)
                sWorldPoint = '%s.worldPosition' % sLocator
        else:
            raise Exception('don\'t know what %s is (%s)' % (sTransform, type(sTransform)))
        return sWorldPoint




def transformInLocalSpace(sFromTransform, sFromParent, sTarget, bSkipPos=False, bSkipRot=False, bSkipScale=False, bJustPosition=False):
    try:
        if cmds.objectType(sTarget) == 'joint':
            cmds.setAttr('%s.jo' % sTarget, 0,0,0)
            cmds.setAttr('%s.jo' % sTarget, lock=True)
    except: pass

    sName = sFromTransform
    if bJustPosition:
        if utils.isStringOrUnicode(sFromTransform):
            sFromPoint = getWorldPoint(sFromTransform)
        else:
            sFromPoint = sFromTransform
        sFromParentMatrix = ('%s.worldInverseMatrix' % sFromParent) if utils.isStringOrUnicode(sFromParent) else sFromParent
        return createPointByMatrixNode(sFromPoint, sFromParentMatrix, sTarget='%s.t' % sTarget)
    else:
        sFromMatrix = ('%s.worldMatrix' % sFromTransform) if utils.isStringOrUnicode(sFromTransform) else sFromTransform
        sFromParentMatrix = ('%s.worldInverseMatrix' % sFromParent) if utils.isStringOrUnicode(sFromParent) else sFromParent
        sLocalMatrix = createMultMatrixNode([sFromMatrix, sFromParentMatrix], sName=sName)
        sDecomposeMatrix = createDecomposeMatrix(sLocalMatrix,
                                                 sTargetPos = None if bSkipPos else ('%s.t' % sTarget),
                                                 sTargetRot = None if bSkipRot else ('%s.r' % sTarget),
                                                 sTargetScale = None if bSkipScale else ('%s.s' % sTarget),
                                                 sName = sName)
        # ideally we should change this output to look similar to the others:
        return sLocalMatrix.split('.')[0], sDecomposeMatrix.split('.')[0]


def createMultMatrixNode(xInputMatrices, sTarget=None, sName='noname', sFullName=None, bJustValues=False):

    if not isinstance(xInputMatrices, (list,tuple)):
        raise Exception('He needs a LIST of matrices')

    if sFullName == None:
        sFullName = 'multiplyMatrix_%s' % sName

    sNode = cmds.createNode('multMatrix', name=sFullName)
    
    for i, xMatrix in enumerate(xInputMatrices):
        _connectOrSetMatrix(xMatrix, '%s.matrixIn[%d]' % (sNode, i))

    sOutput = '%s.matrixSum' % sNode

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)

        disconnectIncomingAttrs(sNode)
        cmds.delete(sNode)

        return fOutput

    if sTarget:
        _connectOrSetMatrix(sOutput, sTarget)
    return sOutput


def createBlendMatrixNode(xInputMatrices, fBlendAttrs, sTarget=None, sName='noname', bForce=False, bBugfixWeightInConnections=False):
    sNode = cmds.createNode('wtAddMatrix', name='wtAddMatrix_%s' % sName)

    if len(xInputMatrices) != len(fBlendAttrs):
        raise Exception('length of xInputMatrices and fBlendAttrs needs to be the same (%d -> %d)' % (len(xInputMatrices), len(fBlendAttrs)))

    for i, xMatrix, fWeight in zip(range(len(xInputMatrices)), xInputMatrices, fBlendAttrs):
        _connectOrSetMatrix(xMatrix, '%s.wtMatrix[%d].matrixIn' % (sNode, i))

        if bBugfixWeightInConnections:
            if isinstance(fWeight, (float,int)):
                createAdditionNode([fWeight], sTarget='%s.wtMatrix[%d].weightIn' % (sNode, i), sName='bugFix')
        else:
            _connectOrSet(fWeight, '%s.wtMatrix[%d].weightIn' % (sNode, i))

    sOutput = '%s.matrixSum' % sNode
    if sTarget:
        _connectOrSetMatrix(sOutput, sTarget, bForce=bForce)
    return sOutput


def createFourByFourMatrixNode(xValueList0=None, xValueList1=None, xValueList2=None, xValueList3=None, sTarget=None, sName='noname'):
    sNode = cmds.createNode('fourByFourMatrix', name='fourByFourMatrix_%s' % sName)

    for vl, xValueList in enumerate([xValueList0, xValueList1, xValueList2, xValueList3]):
        if xValueList != None:
            for v, xValue in enumerate(xValueList):
                _connectOrSet(xValue, '%s.in%d%d' % (sNode,vl,v))

    sOutput = '%s.output' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sOutput



def createSimpleAimConstraint(sAimer, sAimed, xUpMatrix=None, sName='noname', sParent=None):
    sConstraint = cmds.createNode('aimConstraint', name='AIMCNSTR_%s' % sName)
    if sParent:
        cmds.parent(sConstraint, sParent)

    cmds.connectAttr('%s.t' % sAimer, '%s.target[0].targetTranslate' % sConstraint)
    cmds.connectAttr('%s.t' % sAimed, '%s.constraintRotateTranslate' % sConstraint)
    cmds.connectAttr('%s.constraintRotate' % sConstraint, '%s.r' % sAimed)
    if xUpMatrix != None:
        cmds.setAttr('%s.worldUpType' % sConstraint, 1)
        _connectOrSetMatrix(xUpMatrix, '%s.worldUpMatrix' % sConstraint)

    return sConstraint[0]


def createSimpleAimConstraint2(xAimToPos, sAimingTransform, xUpMatrix=None, xAimedPos=None, sName='noname', sParent=None, xAimVector=None, xUpVector=None,
                               bSceneUp=False, bRotateUp=False, xWorldUpVector=None, sComputeOffsetToTransform=None, fWorldUpVector=[0,1,0]):
    sFullName = utils.getUniqueName('aimConstraint_%s' % sName)
    # if cmds.objExists(sFullName):
    #     raise Exception, 'the name %s is not unique' % sFullName

    sConstraint = cmds.createNode('aimConstraint', name=sFullName)

    if sParent:
        cmds.parent(sConstraint, sParent)

    _connectOrSetVector(xAimToPos, '%s.target[0].targetTranslate' % sConstraint)
    if xAimedPos:
        _connectOrSetVector(xAimedPos, '%s.constraintRotateTranslate' % sConstraint)
    else:
        cmds.connectAttr('%s.t' % sAimingTransform, '%s.constraintRotateTranslate' % sConstraint)
    cmds.connectAttr('%s.constraintRotate' % sConstraint, '%s.r' % sAimingTransform)
    if xUpMatrix != None:
        if bRotateUp:
            cmds.setAttr('%s.worldUpType' % sConstraint, 2)
        else:
            cmds.setAttr('%s.worldUpType' % sConstraint, 1)
        _connectOrSetMatrix(xUpMatrix, '%s.worldUpMatrix' % sConstraint)
    elif bSceneUp == True:
        cmds.setAttr('%s.worldUpType' % sConstraint, 0)

    if xWorldUpVector != None:
        _connectOrSetVector(xWorldUpVector, '%s.worldUpVector' % sConstraint)


    if xAimVector != None:
        _connectOrSetVector(xAimVector, '%s.aimVector' % sConstraint)
    if xUpVector != None:
        _connectOrSetVector(xUpVector, '%s.upVector' % sConstraint)

    if sComputeOffsetToTransform:
        fOffset = createMultMatrixNode([cmds.getAttr('%s.worldMatrix' % sComputeOffsetToTransform),
                                        cmds.getAttr('%s.worldInverseMatrix' % sAimingTransform)], bJustValues=True)
        createDecomposeMatrix(fOffset, sTargetRot='%s.offset' % sConstraint, bJustValues=True)

    cmds.setAttr('%s.worldUpVector' % sConstraint, *fWorldUpVector) # added in the end - watch out for it

    return sConstraint



def createPointByMatrixNode(xVector, xMatrix, sTarget=None, sName='noname', sFullName=None, bJustValues=False):
    if sFullName == None:
        sFullName = 'vectorMatrixProduct_%s' % sName
    sNode = cmds.createNode('vectorProduct', name=sFullName)
    _connectOrSetVector(xVector, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])
    _connectOrSetMatrix(xMatrix, '%s.matrix' % sNode)
    cmds.setAttr('%s.operation' % sNode, 4)

    sOutput = '%s.output' % sNode

    if bJustValues:
        fOut = cmds.getAttr(sOutput)[0]
        deleteConnectionsAndItself(sNode)
        return fOut

    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput



def createDotProductNode(xVectorA, xVectorB, sTarget=None, sName='noname'):
    sNode = cmds.createNode('vectorProduct', name='dotProduct_%s' % sName)
    _connectOrSetVector(xVectorA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])
    _connectOrSetVector(xVectorB, '%s.input2' % sNode, ['input2X', 'input2Y', 'input2Z'])
    cmds.setAttr('%s.operation' % sNode, 1)

    sOutput = '%s.outputX' % sNode
    if sTarget:
        _connectOrSet(sOutput, sTarget)
    return sOutput



def createCrossProductNode(xVectorA, xVectorB, sTarget=None, sName='noname'):
    sNode = cmds.createNode('vectorProduct', name='crossProduct_%s' % sName)
    _connectOrSetVector(xVectorA, '%s.input1' % sNode)
    _connectOrSetVector(xVectorB, '%s.input2' % sNode)
    cmds.setAttr('%s.operation' % sNode, 2)

    sOutput = '%s.output' % sNode
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput


def createAxisAngleToQuatNode(xAxis, xAngle, sTarget=None, sName='noname'):
    sNode = cmds.createNode('axisAngleToQuat', name=sName)
    _connectOrSetVector(xAxis, '%s.inputAxis' % sNode)
    _connectOrSet(xAngle, '%s.inputAngle' % sNode)

    sOutput = '%s.outputQuat' % sNode
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput


def createQuatToEulerNode(xQuat, sTarget=None, sName='noname', bForce=False):
    sNode = cmds.createNode('quatToEuler', name=sName)
    cmds.connectAttr(xQuat, '%s.inputQuat' % sNode)

    sOutput = '%s.outputRotate' % sNode
    if sTarget:
        _connectOrSetVector(sOutput, sTarget, bForce=bForce)
    return sOutput




def createInfiniteDotProduct(xProducts, sName='noname', bDoUnitConversionNodes=True, sTarget=None, bForce=False):
    if len(xProducts) == 1:
        sOutput = createMultiplyNode(xProducts[0][0], xProducts[0][1], sName='%sComplexDotProduct' % sName)
    elif len(xProducts) == 0:
        sOutput = 0
    else:
        iDotCount = (len(xProducts) - 1) // 3 + 1
        sDotProducts = [cmds.createNode('vectorProduct', n='complexDotProduct_%s' % sName) for x in range(iDotCount)]
        sLetters = ['X', 'Y', 'Z']
        for x, xPr in enumerate(xProducts):
            _connectOrSet(xPr[0], '%s.input1%s' % (sDotProducts[x // 3], sLetters[x % 3]))
            _connectOrSet(xPr[1], '%s.input2%s' % (sDotProducts[x // 3], sLetters[x % 3]))

        if len(sDotProducts) == 1:
            sOutput = '%s.outputX' % sDotProducts[0]
        else:
            sOutput = createAdditionNode(['%s.outputX' % sD for sD in sDotProducts])

    if sTarget:
        _connectOrSetVector(sOutput, sTarget, bForce=bForce)

    return sOutput


def createVectorMultiplyNode(xInputA, xInputB, bVectorByScalar=False, sTarget=None, sOperation='multiply', sName='noname', sFullName=None, bShadingNode=False):

    if sFullName == None:
        sFullName = 'MULT_%s' % sName

    if bShadingNode:
       sNode = cmds.shadingNode('multiplyDivide', name=sFullName, asTexture=True)
    else:
       sNode = cmds.createNode('multiplyDivide', name=sFullName)


    _connectOrSetVector(xInputA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])

    if bVectorByScalar:
        _connectOrSet(xInputB, '%s.input2X' % sNode)
        _connectOrSet(xInputB, '%s.input2Y' % sNode)
        _connectOrSet(xInputB, '%s.input2Z' % sNode)
    else:
        _connectOrSetVector(xInputB, '%s.input2' % sNode, ['input2X', 'input2Y', 'input2Z'])

    if sOperation != 'multiply':
        iOperation = ['noOperation', 'multiply', 'divide', 'power'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)
    sOutput = '%s.output' % sNode
    #
    # if bOutputIsSum:
    #     sOutput = createAdditionNode(['%sX' % sOutput, '%sY' % sOutput, '%sZ' % sOutput], sName=sName)
    #
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput



def createNormalizedVector(xInputA, bSafe=False, bReturnDistance=False, sTarget=None, sName='noname'):
    sNode = cmds.createNode('multiplyDivide', name='normalize_%s' % sName)

    _connectOrSetVector(xInputA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])
    sActualDistance = createDistanceNode(xInputA,[0,0,0], sName='normalize_%s' % sName)
    if bSafe:
        sDistance = createConditionNode(sActualDistance, '<', 0.001, 1.0, sActualDistance, sName='normalize_%s' % sName)
    else:
        sDistance = sActualDistance

    cmds.connectAttr(sDistance, '%s.input2X' % sNode)
    cmds.connectAttr(sDistance, '%s.input2Y' % sNode)
    cmds.connectAttr(sDistance, '%s.input2Z' % sNode)
    cmds.setAttr('%s.operation' % sNode, 2) # divide

    sOutput = '%s.output' % sNode

    if sTarget:
        _connectOrSetVector(sOutput, sTarget)

    if bReturnDistance:
        return sOutput, sActualDistance
    else:
        return sOutput


def createAbsoluteNode(xValue):
    return createConditionNode(xValue, '<', 0, createMultiplyNode(xValue, -1), xValue)


def createMultiplyNode(xInputA, xInputB, sTarget=None, sOperation='multiply', sName='noname', sFullName=None, bForce=False, bShadingNode=False):
    if sFullName == None:
        sFullName = 'MULT_%s' % sName

    if bShadingNode:
        sNode = cmds.shadingNode('multiplyDivide', name=sFullName, asTexture=True)
    else:
        sNode = cmds.createNode('multiplyDivide', name=sFullName)

    _connectOrSet(xInputA, '%s.input1X' % sNode)
    _connectOrSet(xInputB, '%s.input2X' % sNode)

    if sOperation != 'multiply':
        iOperation = ['noOperation', 'multiply', 'divide', 'power'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)
    sOutput = '%s.outputX' % sNode

    if sTarget:
        # changed on 01/20/2023:
        _connectTarget(sOutput, sTarget, bForce=bForce)
        # _connectOrSetVector(sOutput, sTarget, bForce=bForce)
    return sOutput


def createMultiplyArrayNode(xInputs, sTarget=None, bVector=False, sOperation='multiply', sName='noname', bAddFactorsInfoAttr=False):

    sPrev = xInputs[0]
    sNode = None
    for i, xInput in enumerate(xInputs[1:]):
        sNode = cmds.createNode('multiplyDivide', name='MULT_%s' % sName)
        if bVector:
            _connectOrSet(sPrev, '%s.input1' % sNode)
            _connectOrSet(xInput, '%s.input2' % sNode)
        else:
            _connectOrSet(sPrev, '%s.input1X' % sNode)
            _connectOrSet(xInput, '%s.input2X' % sNode)

        if sOperation != 'multiply':
            iOperation = ['noOperation', 'multiply', 'divide', 'square'].index(sOperation)
            cmds.setAttr('%s.operation' % sNode, iOperation)
        if bVector:
            sPrev = '%s.output' % sNode
        else:
            sPrev = '%s.outputX' % sNode

    sOutput = sPrev
    if sTarget:
        if bVector:
            _connectOrSetVector(sOutput, sTarget)
        else:
            _connectOrSet(sOutput, sTarget)
    if bAddFactorsInfoAttr:
        addStringAttr(sOutput.split('.')[0], 'sFactors', str(xInputs))
    return sOutput


def createExtremeNode(xInputs, bMinimum=True, sName='noname', sTarget=None, bAddFactorsInfoAttr=False):
    if len(xInputs) == 1:
        sOutput = xInputs[0]
    else:
        xPrev = xInputs[0]
        for i in range(1, len(xInputs), 1):
            xPrev = createConditionNode(xPrev, '<' if bMinimum else '>', xInputs[i], xPrev, xInputs[i], sName='%sMinimum' % sName)
        sOutput = xPrev

    if bAddFactorsInfoAttr:
        addStringAttr(sOutput.split('.')[0], 'sFactors', str(xInputs))
    _connectTargetIfNotNone(sTarget, sOutput)

    return sOutput


def createMinimumNode(xInputs, sName='noname', sTarget=None, bAddFactorsInfoAttr=False):
    return createExtremeNode(xInputs, bMinimum=True, sName=sName, sTarget=sTarget, bAddFactorsInfoAttr=bAddFactorsInfoAttr)


def createMaximumNode(xInputs, sName='noname', sTarget=None, bAddFactorsInfoAttr=False):
    return createExtremeNode(xInputs, bMinimum=False, sName=sName, sTarget=sTarget, bAddFactorsInfoAttr=bAddFactorsInfoAttr)


def createAdditionNode(xInputs, sTarget=None, sName='noname', sFullName=None, sOperation='plus', bForce=False):
    if sFullName == None:
        sFullName = 'plusMinusAverage_%s' % sName

    if not isinstance(xInputs, (list,tuple)):
        raise Exception('input needs to be a list')

    sNode = cmds.createNode('plusMinusAverage', name=sFullName)
    for i, xInput in enumerate(xInputs):
        _connectOrSet(xInput, '%s.input1D[%d]' % (sNode,i))

    if sOperation != 'plus':
        iOperation = ['noOperation','plus', 'minus', 'average'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)

    sOutput = '%s.output1D' % sNode
    if sTarget:
        if isinstance(sTarget, (list, tuple)):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT, force=bForce)
        else:
            cmds.connectAttr(sOutput, sTarget, force=bForce)

        # _connectOrSet(sOutput, sTarget)
    return sOutput


def createMultiplyScaleNodes(xScaleInput, xMultipl, sName=None, sTarget=None):
    sOffset = createVectorAdditionNode([xScaleInput, [1,1,1]], sOperation='minus', sName=sName)
    sMultiplied = createVectorMultiplyNode(sOffset, xMultipl, bVectorByScalar=True, sName=sName)
    sAddedBack = createVectorAdditionNode([[1,1,1], sMultiplied], sName=sName, sTarget=sTarget)
    return sAddedBack


def createVectorAdditionNode(xInputs, sTarget=None, sName='noname', sFullName=None, sOperation='plus', bForce=False, bJustValues=False, bShadingNode=True):
    if sFullName == None:
        sFullName = 'plusMinusAverageVector_%s' % sName

    if not isinstance(xInputs, (list,tuple)):
        raise Exception('input needs to be a list')

    if bShadingNode:
       sNode = cmds.shadingNode('plusMinusAverage', name=sFullName, asTexture=True)
    else:
       sNode = cmds.createNode('plusMinusAverage', name=sFullName)

    for i, xInput in enumerate(xInputs):
        if isinstance(xInput, (list,tuple,np.ndarray)):
            _connectOrSet(xInput[0], '%s.input3D[%d].input3Dx' % (sNode, i))
            _connectOrSet(xInput[1], '%s.input3D[%d].input3Dy' % (sNode, i))
            _connectOrSet(xInput[2], '%s.input3D[%d].input3Dz' % (sNode, i))
        else:
            _connectOrSetVector(xInput, '%s.input3D[%d]' % (sNode,i), sSeparateItems=['input3Dx[%d]' % i, 'input3Dy[%d]' % i, 'input3Dz[%d]' % i])

    if sOperation != 'plus':
        iOperation = ['noOperation','plus', 'minus', 'average'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)

    sOutput = '%s.output3D' % sNode
    if sTarget:
        _connectOrSetVector(sOutput, sTarget, bForce=bForce)

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)[0]
        deleteConnectionsAndItself(sNode)
        return fOutput

    return sOutput


def createReverseNode(xInput, sTarget=None, sName='noname', sFullName=None, bVector=False, bShadingNode=False):
    if sFullName == None:
        sFullName = 'reverse_%s' % sName
    if bShadingNode:
        sNode = cmds.shadingNode('reverse', name=sFullName, asTexture=True)
    else:
        sNode = cmds.createNode('reverse', name=sFullName)

    if bVector:
        _connectOrSet(xInput, '%s.input' % sNode)
    else:
        _connectOrSet(xInput, '%s.inputX' % sNode)

    if bVector:
        sOutput = '%s.output' % sNode
    else:
        sOutput = '%s.outputX' % sNode
    if sTarget:
        for sT in utils.toList(sTarget):
            _connectTarget(sOutput, sT)
    return sOutput


def _connectTarget(sOutput, sTarget, bForce=False):
    if sTarget == None:
        return
    sTargets = utils.toList(sTarget)
    for Ts in sTargets:
        cmds.connectAttr(sOutput, Ts, force=bForce)



def createSinCos(sInput, bInputIsDegrees=False, sName='noname'):
    # cmds.loadPlugin("quatNodes", qt=False)
    if bInputIsDegrees:
        sDegrees = createMultiplyNode(sInput, 2, sName='sinCosMultiply_%s' % sName)
    else:
        sDegrees = createMultiplyNode(sInput, 2 * 57.2958, sName='sinCosMultiply_%s' % sName)
    sNode = cmds.createNode('eulerToQuat', n='sinCosEulerToQuat_%s' % sName)
    _connectOrSet(sDegrees, '%s.inputRotateX' % sNode)
    return '%s.outputQuatX' % sNode, '%s.outputQuatW' % sNode




def createDistanceNode(xInputA, xInputB, sTarget=None, sName='noname', fNormalized=None, sDivide=None, bByPassDivisionByZeroError=False):
    sNode = cmds.createNode('distanceBetween', name='distanceBetween_%s' % sName)

    if not isinstance(xInputA, (list,tuple)) and '.' not in xInputA:
        xInputA = createDecomposeMatrix('%s.worldMatrix' % xInputA, sName=sName)
    if not isinstance(xInputB, (list,tuple)) and '.' not in xInputB:
        xInputB = createDecomposeMatrix('%s.worldMatrix' % xInputB, sName=sName)

    _connectOrSetVector(xInputA, '%s.point1' % sNode, sSeparateItems=['point1X ', 'point1Y ', 'point1Z'])
    _connectOrSetVector(xInputB, '%s.point2' % sNode, sSeparateItems=['point2X ', 'point2Y ', 'point2Z'])
    sOutput = '%s.distance' % sNode

    if sDivide != None:
        sOutput = fromEquation('%s / %s' % (sOutput, sDivide), sName='%sDivide' % sName)

    if fNormalized != None:
        fDivider = cmds.getAttr(sOutput)
        if bByPassDivisionByZeroError:
            fDivider = max(0.00000001, fDivider)
        sOutput = fromEquation('%s * %f' % (sOutput, fNormalized/fDivider), sName='%sNormalize' % sName)
    
    if sTarget:
        [cmds.connectAttr(sOutput, sT) for sT in utils.toList(sTarget)]

    return sOutput


def createAngleNode(xInputA, xInputB, sTarget=None, sName='noname', sFullName=None):
    if sFullName == None:
        sFullName = 'angleBetween_%s' % sName
    sNode = cmds.createNode('angleBetween', name=sFullName)
    _connectOrSetVector(xInputA, '%s.vector1' % sNode, sSeparateItems=['vector1X', 'vector1Y', 'vector1Z'])
    _connectOrSetVector(xInputB, '%s.vector2' % sNode, sSeparateItems=['vector2X', 'vector2Y', 'vector2Z'])
    sOutput = '%s.angle' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sOutput



def createSignedAngleNodeFromJoints(sJoints=[], sSide='m'):
    # it's currently locking y to be zero. Needs to have options for what to lock or skip locking
    sAngleAttr = '%s.signedAngle' % sJoints[1]
    if not cmds.objExists(sAngleAttr):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        addAttr(sJoints[1], ln='signedAngle', k=True)

        fRelTopPoint = createPointByMatrixNode(getWorldPoint(sJoints[0]), '%s.worldInverseMatrix' % sJoints[1], bJustValues=True)

        fNeededTopPointWorld = createPointByMatrixNode([fRelTopPoint[0], 0, 0],
                                                             '%s.worldMatrix' % sJoints[1], bJustValues=True)

        fNeededTopPointLocal = createPointByMatrixNode(fNeededTopPointWorld, '%s.worldInverseMatrix' % sJoints[0], bJustValues=True)
        sCurrentTopPointWorld = createPointByMatrixNode(fNeededTopPointLocal, '%s.worldMatrix' % sJoints[0])
        sRelTopPoint = createPointByMatrixNode(sCurrentTopPointWorld, '%s.worldInverseMatrix' % sJoints[1])
        sAngle = createAngleNode(['%sX' % sRelTopPoint, '%sY' % sRelTopPoint, 0], [-fSideMultipl,0,0])
        createConditionNode('%sY' % sRelTopPoint, '>' if sSide == 'r' else '<=', 0, sAngle, createMultiplyNode(sAngle, -1),sTarget=sAngleAttr)

    return sAngleAttr



def createClampNode(xInputA, xMin, xMax, bVector=False, sTarget=None, sName='noname', sFullName=None):
    if not sFullName:
        sFullName = 'clamp_%s' % sName

    sNode = cmds.createNode('clamp', name=sFullName)

    if not bVector:
        _connectOrSet(xInputA, '%s.inputR' % sNode)
        _connectOrSet(xMin, '%s.minR' % sNode)
        _connectOrSet(xMax, '%s.maxR' % sNode)
        sOutput = '%s.outputR' % sNode
    else:
        _connectOrSetVector(xInputA, '%s.input' % sNode, sSeparateItems=['inputR', 'inputG', 'inputB'])
        _connectOrSetVector(xMin, '%s.min' % sNode, sSeparateItems=['minR', 'minG', 'minB'])
        _connectOrSetVector(xMax, '%s.max' % sNode, sSeparateItems=['maxR', 'maxG', 'maxB'])
        sOutput = '%s.output' % sNode

    _connectTargetIfNotNone(sTarget, sOutput)
    return sOutput


def _connectTargetIfNotNone(sTarget, sOutput, bForce=False):
    if sTarget:
        if isinstance(sTarget, list):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT)
        else:
            cmds.connectAttr(sOutput, sTarget, force=bForce)


def createRangeNode(xValue, xInMin, xInMax, xOutMin, xOutMax, sName='noname', sTarget=None, bForce=False, bOutRangeIsVector=False, bInfinity=False, fOvershoot=None):

    try: fInMin = cmds.getAttr(xInMin)
    except: fInMin = float(xInMin)
    try: fInMax = cmds.getAttr(xInMax)
    except: fInMax = float(xInMax)
    if fInMin > fInMax:
        xInMin, xInMax = xInMax, xInMin
        xOutMin, xOutMax = xOutMax, xOutMin
        if not isinstance(fOvershoot, type(None)):
            fOvershoot = [fOvershoot[1], fOvershoot[0]]

    fBeforeOverShoot = None
    if not utils.isNone(fOvershoot): #not isinstance(fOvershoot, type(None)):
        if bOutRangeIsVector:
            raise Exception('bOutRangeIsVector with fOvershoot is not supported yet')

        fBeforeOverShoot = [xInMin, xInMax, xOutMin, xOutMax]
        sPre = [xInMin, xOutMin, 0]
        sPost = [xInMax, xOutMax, 0]
        sDistance = createVectorAdditionNode([[xInMax, xOutMax, 0], [xInMin, xOutMin, 0]], sOperation='minus')

        if fOvershoot[0]:
            sMult = createVectorMultiplyNode(sDistance, fOvershoot[0], bVectorByScalar=True)
            sPre = createVectorAdditionNode([sPre, sMult], sOperation='minus')
            if isinstance(xInMin, (float, int)) and isinstance(xOutMin, (float, int)):
                xInMin = cmds.getAttr('%sx' % sPre)
                xOutMin = cmds.getAttr('%sy' % sPre)
                deleteConnectionsAndItself([sMult, sPre])
            else:
                xInMin = '%sx' % sPre
                xOutMin = '%sy' % sPre
        if fOvershoot[1]:
            sMult = createVectorMultiplyNode(sDistance, fOvershoot[1], bVectorByScalar=True)
            sPost = createVectorAdditionNode([sPost, sMult])
            if isinstance(xInMax, (float, int)) and isinstance(xOutMax, (float, int)):
                xInMax = cmds.getAttr('%sx' % sPost)
                xOutMax = cmds.getAttr('%sy' % sPost)
                deleteConnectionsAndItself([sMult, sPost])
            else:
                xInMax = '%sx' % sPost
                xOutMax = '%sy' % sPost


    if not bInfinity:
        sNode = cmds.createNode('setRange', name='range_%s' % sName)
        if not utils.isNone(fBeforeOverShoot):
            addStringAttr(sNode, 'fBeforeOverShoot', str(fBeforeOverShoot))
        if bOutRangeIsVector:
            for sA in ['X','Y','Z']:
                _connectOrSet(xValue, '%s.value%s' % (sNode,sA))
                _connectOrSet(xInMin, '%s.oldMin%s' % (sNode,sA))
                _connectOrSet(xInMax, '%s.oldMax%s' % (sNode,sA))
            _connectOrSetVector(xOutMin, '%s.min' % sNode)
            _connectOrSetVector(xOutMax, '%s.max' % sNode)
            sOutput = '%s.outValue' % sNode
        else:
            _connectOrSet(xValue, '%s.valueX' % sNode)
            _connectOrSet(xInMin, '%s.oldMinX' % sNode)
            _connectOrSet(xInMax, '%s.oldMaxX' % sNode)
            _connectOrSet(xOutMin, '%s.minX' % sNode)
            _connectOrSet(xOutMax, '%s.maxX' % sNode)
            sOutput = '%s.outValueX' % sNode
    else:
        if bOutRangeIsVector:
            raise Exception('bOutRangeIsVector with bInfinity is not supported yet')
        sName = '%sRange' % sName
        sT = fromEquation('(%s-%s) / (%s-%s)' % (xValue, xInMin, xInMax, xInMin), sName=sName)
        sOutput = fromEquation('%s*%s + %s*(1.0-%s)' % (xOutMax, sT, xOutMin, sT), sName=sName)

    _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)
    return sOutput



def getRangeFromRangeNode(sRangeNode):
    sBeforeOverShootAttr = '%s.fBeforeOverShoot' % sRangeNode
    if cmds.objExists(sBeforeOverShootAttr):
        return eval(cmds.getAttr(sBeforeOverShootAttr))
    else:
        return cmds.getAttr('%s.oldMinX' % sRangeNode), cmds.getAttr('%s.oldMaxX' % sRangeNode),  cmds.getAttr('%s.minX' % sRangeNode), cmds.getAttr('%s.maxX' % sRangeNode)




def createBlendNode(xBlend, xFirst, xSecond, bVector=False, sName='noname', sFullName=None, sTarget=None, bForce=False, bInfinity=False):
    if sFullName == None:
        sFullName = 'BLEND_%s' % sName

    if bInfinity:
        sBlendRev = createAdditionNode([1, xBlend], sOperation='minus')
        if bVector:
            xFirstProduct = createVectorMultiplyNode(xFirst, xBlend, bVectorByScalar=True)
            xSecondProduct = createVectorMultiplyNode(xSecond, sBlendRev, bVectorByScalar=True)
            sOutput = createVectorAdditionNode([xFirstProduct, xSecondProduct], sTarget=sTarget, bForce=bForce)
        else:
            xFirstProduct = createMultiplyNode(xFirst, xBlend)
            xSecondProduct = createMultiplyNode(xSecond, sBlendRev)
            sOutput = createAdditionNode([xFirstProduct, xSecondProduct], sTarget=sTarget, bForce=bForce)
        return sOutput
    else:
        sNode = cmds.createNode('blendColors', name=sFullName)
        _connectOrSet(xBlend, '%s.blender' % sNode)

        if bVector:
            _connectOrSetVector(xFirst, '%s.color1' % sNode, ['color1R', 'color1G', 'color1B'])
            _connectOrSetVector(xSecond, '%s.color2' % sNode, ['color2R', 'color2G', 'color2B'])

            sOutput = '%s.output' % sNode
            if sTarget:
                cmds.connectAttr(sOutput, sTarget, force=bForce)
        else: # this is not tested yet!
            _connectOrSet(xFirst, '%s.color1R' % sNode)
            _connectOrSet(xSecond, '%s.color2R' % sNode)
            sOutput = '%s.outputR' % sNode
            _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)
    return sOutput


def createChoiceNode(xSelector, xInputs, sTarget=None, sName='noname', sFullName=None, bForce=False):
    if sFullName == None:
        sFullName = 'CHOICE_%s' % sName

    sNode = cmds.createNode('choice', name=sFullName)
    _connectOrSet(xSelector, '%s.selector' % sNode)
    for i, xInput in enumerate(xInputs):
        _connectOrSet(xInput, '%s.input[%d]' % (sNode,i))
    sOutput = '%s.output' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget, f=bForce)
    return sOutput


def _connectOrSet(xValue, sAttr, bForce=False):
    if isinstance(xValue, (list, tuple, np.ndarray)) and len(xValue) == 16:
        sHoldMatrix = cmds.createNode('holdMatrix')
        cmds.setAttr('%s.inMatrix' % sHoldMatrix, xValue, type='matrix')
        cmds.connectAttr('%s.outMatrix' % sHoldMatrix, sAttr)
    else:
        try:
            fValue = float(xValue)
        except:
            fValue = None

        if fValue != None:
            cmds.setAttr(sAttr, fValue)
        else:
            cmds.connectAttr(xValue, sAttr, f=bForce)


def _connectOrSetVector(xValue, sAttr, sSeparateItems=[], bForce=False):
    if sSeparateItems and isinstance(xValue, (list, tuple, np.ndarray)):
        sNode = sAttr.split('.')[0]
        _connectOrSet(xValue[0], '%s.%s' % (sNode, sSeparateItems[0]), bForce=bForce)
        _connectOrSet(xValue[1], '%s.%s' % (sNode, sSeparateItems[1]), bForce=bForce)
        _connectOrSet(xValue[2], '%s.%s' % (sNode, sSeparateItems[2]), bForce=bForce)
    elif sSeparateItems and isinstance(xValue, OpenMaya2.MVector):
        sNode = sAttr.split('.')[0]
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[0]), xValue[0])
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[1]), xValue[1])
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[2]), xValue[2])
    else:
        try:
            cmds.setAttr(sAttr, *xValue) # it's a list of values
        except:
            cmds.connectAttr(xValue, sAttr, force=bForce) # it's a compound attribute to connect


def _connectOrSetMatrix(xValue, sAttr, bForce=False):
    
    # print('sAttr (api).. ', sAttr)
    # print('xValue (api).. ', xValue)
    # print('getAttr of current (api).. ', cmds.getAttr(sAttr))
    # print('type (api).. ', type(xValue))
    #
    if isinstance(xValue, (list, tuple, np.ndarray)):
        xValue = list(xValue)
        if len(xValue) != 16:
            raise Exception('matrix list has wrong length %d, needs to be 16' % len(xValue))
        
        if sAttr.count('.') > 1:
            cmds.setAttr(sAttr, *list(xValue), type='matrix')
        else:
            sNode, sIndexedA = sAttr.split('.')
            if '[' in sIndexedA:
                sA, iIndex = utils.indexFromName(sIndexedA, bAlsoReturnPrefix=True)
            else:
                sA, iIndex = sIndexedA, None
            mNode = utils.getDependNode(sNode)
            matPlug = utils.getPlugOnNode(mNode, sA)
            
            if iIndex != None:
                matPlugIndexed = matPlug.elementByLogicalIndex(iIndex)
            else:
                matPlugIndexed = matPlug
    
            matrixData = OpenMaya2.MFnMatrixData()
            mMatrix = OpenMaya2.MMatrix(xValue)
            
            matobj = matrixData.create(mMatrix)
            matPlugIndexed.setMObject(matobj)
    
            '''
            sNode = cmds.createNode( "multMatrix" )
            node = getDependNode( sNode )
            matPlug = nameToNodePlug( "matrixIn", node)
            matPlug0 = matPlug.elementByLogicalIndex(0)
            
            matrixData = OpenMaya2.MFnMatrixData(matPlug0.asMObject())
            matobj = matrixData.create(OpenMaya2.MMatrix([1.0,0.0,0.0,0.0, 0.0,1.0,0.0,0.0, 0.0,0.0,1.0,0.0, 4445.0,5.0,5.0,1.0]))
            matPlug0.setMObject(matobj)
            '''
    else:
        cmds.connectAttr(xValue, sAttr, force=bForce)


def createConditionNode(xFirstTerm, sOperator, xSecondTerm, xOutputTrue, xOutputFalse, sName='noname', sFullName=None, bVector=False, sTarget=None, bForce=False):
    if sFullName == None:
        sFullName = 'condition_%s' % sName

    try:
        iOperation = ['==', '!=', '>', '>=', '<', '<='].index(sOperator)
    except:
        raise Exception('don\'t know what operator %s is' % sOperator)

    sNode = cmds.createNode('condition', name=sFullName)
    _connectOrSet(xFirstTerm, '%s.firstTerm' % sNode )
    _connectOrSet(xSecondTerm, '%s.secondTerm' % sNode )
    cmds.setAttr('%s.operation' % sNode, iOperation)
    
    if bVector:
        _connectOrSetVector(xOutputTrue, '%s.colorIfTrue' % sNode, sSeparateItems=['colorIfTrueR', 'colorIfTrueG', 'colorIfTrueB'])
        _connectOrSetVector(xOutputFalse, '%s.colorIfFalse' % sNode, sSeparateItems=['colorIfFalseR', 'colorIfFalseG', 'colorIfFalseB'])
        sOutput = '%s.outColor' % sNode
        if sTarget:
            _connectOrSetVector(sOutput, sTarget, bForce=bForce)
        return sOutput
    else:
        _connectOrSet(xOutputTrue, '%s.colorIfTrueR' % sNode)
        _connectOrSet(xOutputFalse, '%s.colorIfFalseR' % sNode)
        sOutput = '%s.outColorR' % sNode
        if sTarget:
            _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)
        return sOutput



def fromEquation(sEquation, sTarget=None, sName='noName', sFullName=None, bDoUnitConversionNodes=False, bReturnNodes=False):
    if sFullName == None:
        sMultiplName = 'multiplyDivide_%s_000' % sName
        sPlusName = 'plusMinusAverage_%s_000' % sName
        sConvName = 'conversion_%s_000' % sName
    else:
        sMultiplName = sFullName
        sPlusName = sFullName
        sConvName = sFullName

    sAllNodes = []
    # print 'sEquation: ', sEquation
    def createNodes(sEqu):
        sSplits = re.split('\/-|\*-|\*|\/|\+|\-|\^', sEqu)
        #print sEqu, '->', sSplits
        
        # first clean up minus signs, if the first one is '', then it should be a minus
        #
        if sSplits[0] == '':
            if sEqu[0] == '-':
                try:
                    float(sSplits[1])
                    sSplits[1] = '-%s' % sSplits[1]
                    del sSplits[0]
                except:
                    sSplits[0] = '-1'
                    sEqu = '-1*%s' % sEqu[1:]
    
        # still on minus signs, if  iPos is -, then it's a combination with * or /
        #
        iPos = 0
        i = 0
        while i < len(sSplits):
            if iPos != 0 and sEqu[iPos] == '-':
                try:
                    float(sSplits[i])
                    sSplits[i] = '-%s' % sSplits[i]
                except:
                    sSplits.insert(i, '-1')
                    sEqu = '%s%s%s' % (sEqu[:iPos+1], '1*', sEqu[iPos+1:])
        
            iPos += len(sSplits[i])
            iPos += 1
            i += 1
        
        # now go through all the splits, and either multiply or add them
        #
        i = 0
        iPos = -1
        sOperator = '.'
        sPrevAttr = None
        sAdditions = []
        sAdditionOperators = []
        while i < len(sSplits):
            sAttr = sSplits[i]
            
            if sOperator == '.':
                sPrevAttr = sAttr
            else:
                fConversionFactor = None
                if sOperator in '+-':
                    sAdditions.append(sPrevAttr if sPrevAttr != None else sSplits[i-1])
                    sAdditionOperators.append(sOperator)
                    sOperator = '.'
                    sPrevAttr = None
                    continue
                elif sOperator == '*':
                    if bDoUnitConversionNodes:
                        try:
                            fConversionFactor = float(sAttr)
                        except:
                            pass
                        if fConversionFactor != None:
                            sConv = cmds.createNode('unitConversion', name=sConvName)
                            sAllNodes.append(sConv)
                            _connectOrSet(sPrevAttr, '%s.input' % sConv)
                            cmds.setAttr('%s.conversionFactor' % sConv, fConversionFactor) # can only be set and not connected
                            sPrevAttr = '%s.output' % sConv

                if fConversionFactor == None and sOperator in '*/^':
                    sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True, name=sMultiplName)
                    sAllNodes.append(sMultipl)
                    _connectOrSet(sPrevAttr, '%s.input1X' % sMultipl)
                    _connectOrSet(sAttr, '%s.input2X' % sMultipl)
                    if sOperator == '/':
                        cmds.setAttr('%s.operation' % sMultipl, 2)
                    elif sOperator == '^':
                        cmds.setAttr('%s.operation' % sMultipl, 3)
                    sPrevAttr = '%s.outputX' % sMultipl
        
            iPos += len(sSplits[i])+1
            if iPos < len(sEqu):
                sOperator = sEqu[iPos]
                i += 1
            else:
                sAdditions.append(sAttr if sPrevAttr == None else sPrevAttr)
                break

        # we collected additions and additionsOperators before, now let's add them together
        #
        if len(sAdditions) == 1:
            return sAdditions[0]
        else:
            sPlusMinus = cmds.createNode ('plusMinusAverage', name=sPlusName)
            sAllNodes.append(sPlusMinus)
            # first check if we need to make minus or plus
            bMinus, bPlus = False, False
            for sOp in sAdditionOperators:
                if sOp == '+': bPlus = True
                elif sOp == '-': bMinus = True
            if bMinus:
                if not bPlus:
                    cmds.setAttr('%s.operation' % sPlusMinus, 2)
                elif bPlus: # if we have mixed minus and plus, we'll have to multiply the minus ones by -1
                    for i in range(len(sAdditionOperators)):
                        if sAdditionOperators[i] == '-':
                            try: sAdditions[i+1] = -float(sAdditions[i+1])
                            except: sAdditions[i+1] = createNodes('-1*%s' % sAdditions[i+1])
            # finally connect the parts to the plus node
            for i, sAddition in enumerate(sAdditions):
                _connectOrSet(sAddition, '%s.input1D[%d]' % (sPlusMinus, i))
            sOutput = '%s.output1D' % sPlusMinus
            return sOutput
            
    def traverseParenthesis(sEqu, sSplits):
        sEquNew = ''
        i = 0
        iPos = 0
        while True:
            if sSplits[i]:
                sEquNew += sSplits[i]
            iPos += len(sSplits[i])
            if iPos >= len(sEqu):
                break
            iP = sEqu[iPos]
            iPos += 1
            i += 1
            if iP == '(':
                sNewOutput, i2, iPos2 = traverseParenthesis(sEqu[iPos:], sSplits[i:])
                i += i2
                iPos += iPos2
                sEquNew += sNewOutput
            elif iP == ')':
                sOutput = createNodes(sEquNew)
                return sOutput, i, iPos

        sLastPart = createNodes(sEquNew)
        return sLastPart

    sEquationStripped = sEquation.replace(' ','')
    sEquationStripped = sEquationStripped.replace('+-', '-').replace('--','+').replace('*+', '*')


    # print 'sEquationStripped: ', sEquationStripped

    sSplits = re.split('\(|\)', sEquationStripped)
    sRet = traverseParenthesis(sEquationStripped, sSplits)

    if sTarget:
        if isinstance(sTarget, (list, tuple)):
            for sT in sTarget:
                cmds.connectAttr(sRet, sT)
        else:
            cmds.connectAttr(sRet, sTarget)

    if bReturnNodes:
        return sRet, sAllNodes
    else:
        return sRet



def setDrivenKey(sDriverAttrPath, fDriverVals, sDrivenAttrPath, fDrivenVals, sInTanType='clamped', sOutTanType='clamped',
                 bPreEndless=False, bPostEndless=False, sFullName=None, dTangentFlags={}):

    if sDrivenAttrPath == None:
        bCreatedTemp = True
        sTemp = cmds.createNode('transform')
        sDrivenAttrPath = '%s.tx' % sTemp
    else:
        bCreatedTemp = False

    if sDriverAttrPath == None:
        bCreatedTempDriver = True
        sTempDriver = cmds.createNode('transform')
        sDriverAttrPath = '%s.tx' % sTempDriver
    else:
        bCreatedTempDriver = False


    for i in range(len(fDriverVals)):
        cmds.setDrivenKeyframe(sDrivenAttrPath, cd=sDriverAttrPath, dv=fDriverVals[i],  v=fDrivenVals[i],
                               itt=sInTanType, ott=sOutTanType)

    sAnimCurveAttr = (cmds.listConnections(sDrivenAttrPath, d=False, p=True) or [None])[0]

    if sFullName:
        sSplits = sAnimCurveAttr.split('.')
        sSplits[0] = cmds.rename(sSplits[0], sFullName)
        sAnimCurveAttr = '%s.%s' % (sSplits[0], sSplits[1])

    sPreInfinite = 'linear' if bPreEndless else 'constant'
    sPostInfinite = 'linear' if bPostEndless else 'constant'
    cmds.setInfinity(sDrivenAttrPath, pri=sPreInfinite, poi=sPostInfinite)

    if dTangentFlags:
        dFlags = {}
        for i in range(len(fDriverVals)):
            for sFlag in dTangentFlags.keys():
                dFlags[str(sFlag)] = dTangentFlags[sFlag][i]
            cmds.keyTangent(sAnimCurveAttr.split('.')[0], index=(i,i), **dFlags)

    if bCreatedTemp:
        cmds.disconnectAttr(sAnimCurveAttr, sDrivenAttrPath)
        cmds.delete(sTemp)

    if bCreatedTempDriver:
        cmds.disconnectAttr(sDriverAttrPath, '%s.input' % sAnimCurveAttr.split('.')[0])
        cmds.delete(sTempDriver)

    return sAnimCurveAttr


def disconnectAttr(sAttr):
    sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
    if sConns:
        cmds.disconnectAttr(sConns[0], sAttr)


def disconnectIncomingAttrs(sNode):
    sConnections = cmds.listConnections(sNode, s=True, d=False, c=True, p=True) or []
    for i in range(0, len(sConnections), 2):
        cmds.disconnectAttr(sConnections[i + 1], sConnections[i])



def setDrivenKeyController(sCtrlAttr, fCtrlValues, sDriverAttr, sDrivenAttr, fDrivenVals, sInTanType='linear', sOutTanType='linear', sFullName=None):
    fPrevControlValue = cmds.getAttr(sCtrlAttr)
    if isinstance(fPrevControlValue, list):
        fPrevControlValueList = list(fPrevControlValue[0])
    else:
        fPrevControlValueList = utils.toList(fPrevControlValue)

    if sCtrlAttr ==sDriverAttr:
        fDriverVals = fCtrlValues
    else:
        fDriverVals = []
        for fControlVal in fCtrlValues:
            print('sCtrlAttr: ', sCtrlAttr)
            print('fControlVal: ', fControlVal)
            print('utils.toList(fControlVal): ', utils.toList(fControlVal))
            cmds.setAttr(sCtrlAttr, *utils.toList(fControlVal))
            fDriverVals.append(cmds.getAttr(sDriverAttr))

        # restore the state
        cmds.setAttr(sCtrlAttr, *fPrevControlValueList)

    return setDrivenKey(sDriverAttr, fDriverVals, sDrivenAttr, fDrivenVals, sInTanType=sInTanType, sOutTanType=sOutTanType, sFullName=sFullName)


def createMatrixDebugLocator(sMatrixNode):
    sLocs = []
    for sMatrixNode in utils.toList(sMatrixNode):
        sLoc = cmds.spaceLocator()[0]

        if '.' in sMatrixNode:
            sOutput = sMatrixNode
            createDecomposeMatrix(sOutput, sTargetPos='%s.t' % sLoc, sTargetRot='%s.r' % sLoc, sTargetScale='%s.s' % sLoc)
        elif cmds.objectType(sMatrixNode) in ['joint', 'transform']:
            cmds.parent(sLoc, sMatrixNode)
            for sA in ['tx','ty','tz', 'rx','ry','rz']:
                cmds.setAttr('%s.%s' % (sLoc, sA), 0)
            for sA in ['sx','sy','sz']:
                cmds.setAttr('%s.%s' % (sLoc, sA), 1)
        else:
            dAttrs = {'multMatrix':'matrixSum', 'wtAddMatrix':'matrixSum', 'composeMatrix':'outputMatrix'}
            sOutput = '%s.%s' % (sMatrixNode, dAttrs[cmds.objectType(sMatrixNode)])
            createDecomposeMatrix(sOutput, sTargetPos='%s.t' % sLoc, sTargetRot='%s.r' % sLoc, sTargetScale='%s.s' % sLoc)
        sLocs.append(sLoc)
    cmds.select(sLocs)


def createMatrixDebugLocatorSelected():
    sSel = cmds.ls(sl=True)
    createMatrixDebugLocator(sSel[0])


def moveCustomAttributes(sFrom, sTo, sAttrs=None, bDeleteOldAttr=True, bSkipIfNotExists=False, bReconnectDest=True, bConnectOldToNew=False):
    if sAttrs == None:
        sAttrs = cmds.listAttr(sFrom, userDefined=True)

    for sA in sAttrs:
        sFullA = '%s.%s' % (sFrom,sA)
        if not cmds.objExists(sFullA):
            if bSkipIfNotExists:
                cmds.warning('%s doesn\'t exist' % sFullA)
                continue
            else:
                raise Exception('%s doesn\'t exist' % sFullA)


        sType = cmds.addAttr(sFullA, q=True, attributeType=True)
        if sType == 'double':
            fDefaultValue = cmds.addAttr(sFullA, q=True, defaultValue=True)
            fMinValue = cmds.addAttr(sFullA, q=True, minValue=True)
            fMaxValue = cmds.addAttr(sFullA, q=True, maxValue=True)
            bKeyAble = cmds.addAttr(sFullA, q=True, k=True)

            dMinMax = {}
            if fMinValue != None:
                dMinMax['minValue'] = fMinValue
            if fMaxValue != None:
                dMinMax['maxValue'] = fMaxValue
            sNewAttr = addAttr(sTo, ln=sA, attributeType=sType, k=bKeyAble,
                               defaultValue=fDefaultValue, **dMinMax)

            if bReconnectDest:
                for sPlug in cmds.listConnections(sFullA, s=False, d=True, p=True) or []:
                    cmds.disconnectAttr(sFullA, sPlug)
                    cmds.connectAttr(sNewAttr, sPlug)

        if bDeleteOldAttr:
            if bConnectOldToNew:
                raise Exception('bDeleteOldAttr and bConnectOldToNew don\'t work the same time')
            cmds.deleteAttr(sFullA)

        if bConnectOldToNew:
            cmds.connectAttr(sFullA, sNewAttr)

        # else:
        #     cmds.warning('attribute type not supported for moving: %s (%s)' % (sType, sFullA))


def getScaleFromXform(sXform):
    sScaleNode = 'decomposedScale__%s' % sXform
    if not cmds.objExists(sScaleNode):
        createDecomposeMatrix('%s.worldMatrix' % sXform, sFullName=sScaleNode)
    return '%s.outputScale' % sScaleNode



def orderAttrs(sCtrl, sAttrs):
    sTempPost = '_tempDelete'
    for sAttr in sAttrs:
        sFullAttr = '%s.%s' % (sCtrl, sAttr)
        sType = cmds.addAttr(sFullAttr, q=True, at=True)
        fMin = cmds.addAttr(sFullAttr, q=True, minValue=True)
        fMax = cmds.addAttr(sFullAttr, q=True, maxValue=True)
        fDefault = cmds.addAttr(sFullAttr, q=True, defaultValue=True)
        fValue = cmds.getAttr(sFullAttr)
        sOldAttrName = '%s%s' % (sAttr, sTempPost)
        sOldAttrName = cmds.renameAttr(sFullAttr, sOldAttrName)
        sFullOldAttr = '%s.%s' % (sCtrl, sOldAttrName)

        cmds.addAttr(sCtrl, ln=sAttr, at=sType, minValue=fMin, maxValue=fMax, defaultValue=fDefault, k=True)
        for sPlug in cmds.listConnections(sFullOldAttr, s=False, d=True, p=True):
            cmds.disconnectAttr(sFullOldAttr, sPlug)
            cmds.connectAttr(sFullAttr, sPlug)

        cmds.setAttr(sFullAttr, fValue)

        cmds.deleteAttr(sFullOldAttr)





def createTextureNode(sTexturePath, sName='file', bUdim=False, bPlaceNode=False):
    
    if bUdim and bPlaceNode:
        raise Exception('bUdim and bPlacenode don\'t work the same time')

    if not os.path.exists(sTexturePath):
        raise Exception('path "%s" doesn\'t exist' % sTexturePath)
    sFileNode = cmds.shadingNode('file', asTexture=True, n=sName)
    cmds.addAttr(sFileNode, ln='createdFromKangaroo', k=True, dv=True, at='bool')

    cmds.setAttr('%s.fileTextureName' % sFileNode, sTexturePath, type='string')
    if bUdim:
        cmds.setAttr('%s.uvTilingMode' % sFileNode, 3)

    if bPlaceNode:
        if isinstance(bPlaceNode, bool):
            sPlaceNode = cmds.shadingNode('place2dTexture', asUtility=True)
        elif isinstance(bPlaceNode, str):
            if cmds.objExists(bPlaceNode):
                sPlaceNode = bPlaceNode
            else:
                sPlaceNode = cmds.shadingNode('place2dTexture', asUtility=True, n=bPlaceNode)
        else:
            raise Exception('not sure what to do with type %s (%s)' % (type(bPlaceNode), bPlaceNode))

        cmds.setAttr('%s.filterType' % sFileNode, 0)
        cmds.connectAttr('%s.outUV' % sPlaceNode, '%s.uvCoord' % sFileNode)
        cmds.connectAttr('%s.outUvFilterSize' % sPlaceNode, '%s.uvFilterSize' % sFileNode)
        cmds.connectAttr('%s.vertexCameraOne' % sPlaceNode, '%s.vertexCameraOne' % sFileNode, f=True)
        cmds.connectAttr('%s.vertexUvOne' % sPlaceNode, '%s.vertexUvOne' % sFileNode, f=True)
        cmds.connectAttr('%s.vertexUvThree' % sPlaceNode, '%s.vertexUvThree' % sFileNode, f=True)
        cmds.connectAttr('%s.vertexUvTwo' % sPlaceNode, '%s.vertexUvTwo' % sFileNode, f=True)
        cmds.connectAttr('%s.coverage' % sPlaceNode, '%s.coverage' % sFileNode, f=True)
        cmds.connectAttr('%s.mirrorU' % sPlaceNode, '%s.mirrorU' % sFileNode, f=True)
        cmds.connectAttr('%s.mirrorV' % sPlaceNode, '%s.mirrorV' % sFileNode, f=True)
        cmds.connectAttr('%s.noiseUV' % sPlaceNode, '%s.noiseUV' % sFileNode, f=True)
        cmds.connectAttr('%s.offset' % sPlaceNode, '%s.offset' % sFileNode, f=True)
        cmds.connectAttr('%s.repeatUV' % sPlaceNode, '%s.repeatUV' % sFileNode, f=True)
        cmds.connectAttr('%s.rotateFrame' % sPlaceNode, '%s.rotateFrame' % sFileNode, f=True)
        cmds.connectAttr('%s.rotateUV' % sPlaceNode, '%s.rotateUV' % sFileNode, f=True)
        cmds.connectAttr('%s.stagger' % sPlaceNode, '%s.stagger' % sFileNode, f=True)
        cmds.connectAttr('%s.translateFrame' % sPlaceNode, '%s.translateFrame' % sFileNode, f=True)
        cmds.connectAttr('%s.wrapU' % sPlaceNode, '%s.wrapU' % sFileNode, f=True)
        cmds.connectAttr('%s.wrapV' % sPlaceNode, '%s.wrapV' % sFileNode, f=True)
        
        return sFileNode, sPlaceNode

    else:
        return sFileNode



kGeneralDataNode = '__generalData__'
kExportNode = '__export__'
kBodyDataNode = '__bodyData__'
kFaceDataNode = '__faceData__'
kCostumeDataNode = '__costumeData__'
kPosesDataNode = '__posesData__'
kSkipKeyImportAttrs = 'sSkipKeyImportAttrs'

class data:

    @staticmethod
    def store(sAttr, xValue, sNode=kGeneralDataNode):
        if not cmds.objExists(sNode):
            cmds.createNode('transform', n=sNode)

        sAttrName = '%s.%s' % (sNode,sAttr)
        if not cmds.objExists(sAttrName):
            addAttr(sNode, ln=sAttr, dt='string', k=False)

        sValue = str(xValue).replace('array', 'np.array')
        cmds.setAttr(sAttrName, sValue, type='string')


    @staticmethod
    def exists(sAttr, sNode='__generalData__'):
        if cmds.objExists('%s.%s' % (sNode, sAttr)):
            return True
        else:
            return False


    @staticmethod
    def get(sAttr, sNode='__generalData__', xDefault=None, bForceString=False):
        sAttr = '%s.%s' % (sNode, sAttr)
        if cmds.objExists(sAttr):
            sValue = cmds.getAttr(sAttr)
            if bForceString:
                return sValue
            else:
                return utils.evalValueFromString(sValue)
        else:
            return xDefault

    @staticmethod
    def addToList(sAttr, sList, sNode = '__generalData__'):
        sAttrName = '%s.%s' % (sNode, sAttr)
        if cmds.objExists(sAttrName):
            sValue = cmds.getAttr(sAttrName)
            sCurrentList = utils.evalValueFromString(sValue)
            if not isinstance(sCurrentList, list):
                raise Exception('the value of %s is not a list (%s)' % (sAttrName, sValue))
        else:
            sCurrentList = []

        sCurrentList += sList
        data.store(sAttr, sCurrentList, sNode=sNode)


def getDefaultAttrsMenu(sKey='sDefaultSettingAttrs', sArgName='dDefaultSettingValues'):
    dDefaultAttrsMenu = OrderedDict()

    def _getDefaultAttrs(sKey):
        sAttrs = data.get(sKey)
        return sAttrs

    def infoSettingAttrs(_sKey=sKey):
        sAttrs = _getDefaultAttrs(_sKey)
        cmds.confirmDialog(t='attributes to save', m='\n'.join(sAttrs))

    dDefaultAttrsMenu['Info'] = infoSettingAttrs

    def selectSettingAttrs(_sKey=sKey):
        sAttrs = _getDefaultAttrs(_sKey)

        sObjs = list(set([sA.split('.')[0] for sA in sAttrs]))
        cmds.select(sObjs)

    dDefaultAttrsMenu['Select'] = selectSettingAttrs

    def _mirror(_sKey=sKey):
        sAttrs = _getDefaultAttrs(_sKey)

        dValues = {sA: cmds.getAttr(sA) for sA in sAttrs}
        for sAttr in dValues.keys():
            if utils.getSide(sAttr) == 'r':
                sMirrorAttr = utils.getMirrorName(sAttr)
                if cmds.objExists(sMirrorAttr):
                    print('mirroring %s to %s' % (sMirrorAttr, sAttr))
                    cmds.setAttr(sAttr, cmds.getAttr(sMirrorAttr))

    dDefaultAttrsMenu['Mirror'] = _mirror

    def clearDefaultAttrsFlag(_uiArgs=None):
        _uiArgs['dDefaultSettingValues'].setText('{}')

    dDefaultAttrsMenu['Clear'] = clearDefaultAttrsFlag

    def _fill(_sKey=sKey, _uiArgs=None):
        sAttrs = _getDefaultAttrs(_sKey)
        dValues = {sA: cmds.getAttr(sA) for sA in sAttrs}
        _uiArgs[sArgName].setText(str(dValues))

    dDefaultAttrsMenu['Fill all values'] = _fill

    return dDefaultAttrsMenu
