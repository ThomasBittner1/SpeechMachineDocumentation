###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel

import math
import time
import shutil

import numpy as np
import kangarooTools.utilFunctions as utils
import kangarooTools.utilsQt as utilsQt

QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt

import kangarooTools.deformers as deformers
import kangarooTools.patch as patch

from collections import defaultdict
import os
import kangarooTools.topology as topology
from functools import reduce


kControlsPrefix = 'control__'
kTabSettingsPrefix = 'tabSettings__'



class Control(object):
    def __init__(self, bDisableOnServer=False):
        self.bRefreshButton = False
        self.bGroupBox = False
        self.tbParentControl = None
        self.bIsChild = False
        self.tbChildren = []
        self.bTurnedOffFromOtherControl = False

        self.controlOtherControls = []
        self.controlOtherControlsValues = []
        self.controlOtherControlsEnable = []
        self.bGotBuilt = False
        self.bDisableOnServer = bDisableOnServer

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        self.bGotBuilt = True

        self.sName = sName
        self.qtWindow = qtWindow
        self.xDefaultValue = xValue if not self.tbChildren else xValue[0]
        self.uniqueLayout = QtWidgets.QVBoxLayout()
        self.qMainLayout = QtWidgets.QHBoxLayout()
        if self.tbParentControl != None:
            self.tbParentControl.uniqueLayout.addLayout(self.qMainLayout)
        else:
            qParentLayout.addLayout(self.qMainLayout)
        
        if self.bGroupBox:
            self.qGroupBox = QtWidgets.QGroupBox(utils.beautifyVariableName(sName))
            self.qGroupBox.setLayout(self.uniqueLayout)
            self.qMainLayout.addWidget(self.qGroupBox)
        else:
            self.qMainLayout.addLayout(self.uniqueLayout)

        if self.bRefreshButton:
            self.qRefreshButton = QtWidgets.QPushButton('')
            sIconFile = os.path.join(utils.getToolsDir(), 'refresh.png')
            self.qRefreshButton.setIcon(QtGui.QIcon(sIconFile))
            _kIconSize = 50
            self.qRefreshButton.setMaximumWidth(_kIconSize)
            self.qRefreshButton.setMinimumWidth(_kIconSize)
            self.qRefreshButton.setMaximumHeight(_kIconSize)
            self.qRefreshButton.setMinimumHeight(_kIconSize)
            self.qReloadLayout = QtWidgets.QVBoxLayout()
            self.qMainLayout.addLayout(self.qReloadLayout)
            self.qReloadLayout.addWidget(self.qRefreshButton)
            self.qRefreshButton.clicked.connect(self.refresh)

        self.bGotBuilt = True

        
    def setEnabled(self, bOn, bFromOtherControl=False):
        self.bTurnedOffFromOtherControl = bFromOtherControl
        for sAttr, attr in list(self.__dict__.items()):
            if issubclass(type(attr), QtWidgets.QWidget):
                attr.setEnabled(bOn)

    def refresh(self):
        pass

    def setToDefault(self, xValue=None):
        for tbChild in self.tbChildren:
            tbChild.setToDefault()

    def setControlEnabled(self, otherControl, xValues, bEnableIfEqual=True):
        self.controlOtherControls.append(otherControl)
        self.controlOtherControlsValues.append(xValues)
        self.controlOtherControlsEnable.append(bEnableIfEqual)

    def runControlOtherControl(self):
        if self.controlOtherControls:
            for c, controlOtherControl in enumerate(self.controlOtherControls):
                xValue = self.getValue()
                xCompareValue = xValue if not self.tbChildren else xValue[0]
                if xCompareValue in self.controlOtherControlsValues[c]:
                    self.controlOtherControls[c].setEnabled(True if self.controlOtherControlsEnable[c] else False, bFromOtherControl=True)
                else:
                    self.controlOtherControls[c].setEnabled(False if self.controlOtherControlsEnable[c] else True, bFromOtherControl=True)

    def addToControlLayout(self, tbControl):
        self.tbParentControl = tbControl
        #tbControl.tbChildren.append(self)
        #self.bIsChild = True

    def addChildrenValues(self, xValue):
        if self.tbChildren:
            return [xValue] + [tbC.getValue() for tbC in self.tbChildren]
        else:
            return xValue

    def getValue(self):
        return None


    def serverSwitch(self, bServer):
        pass


class BoolControl(Control):
    def __init__(self):
        Control.__init__(self)
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)
        self.widget = QtWidgets.QWidget()
        self.layout = QtWidgets.QVBoxLayout()
        self.widget.setLayout(self.layout)
        self.checkbox = QtWidgets.QCheckBox(utils.beautifyVariableName(sName))
        self.layout.addWidget(self.checkbox)
        self.uniqueLayout.addWidget(self.widget)
        self.setToDefault()
    
    def getValue(self):
        return self.checkbox.isChecked()

    def setToDefault(self, xValue=None):
        return self.checkbox.setChecked(xValue if xValue else self.xDefaultValue)



class SelectionControl(Control):
    def __init__(self, bList=True, bDisableOnServer=False, funcGetCompleterStrings=None):
        Control.__init__(self, bDisableOnServer=bDisableOnServer)
        self.bList = bList
        self.funcGetCompleterStrings = funcGetCompleterStrings


    def serverSwitch(self, bServer):
        self.button.setEnabled(not bServer)
        self.text.setEnabled(not bServer)


    def build(self, qParentLayout, sName, xValue, qtWindow=None, bClearButton=False):
        Control.build(self, qParentLayout, sName, xValue)

        self.layout = QtWidgets.QHBoxLayout()
        
        self.verticalLayout = QtWidgets.QVBoxLayout()
        
        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))

        if not utils.isNone(self.funcGetCompleterStrings):
            self.text = utilsQt.QLineEditWithCompleter()
            self.text.gotFocus.connect(self.gotFocus)
        else:
            self.text = QtWidgets.QLineEdit()


        if xValue:
            if self.bList:
                self.text.setText(';'.join(xValue))
            else:
                self.text.setText(xValue)
        self.button = QtWidgets.QPushButton('Selected')
        self.button.clicked.connect(self.selectedClicked)
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.text)
        self.layout.addWidget(self.button)

        if bClearButton:
            self.clearButton = QtWidgets.QPushButton('Clear')
            self.clearButton.clicked.connect(self.clearClicked)
            self.layout.addWidget(self.clearButton)

        self.verticalLayout.addLayout(self.layout)
        self.uniqueLayout.addLayout(self.verticalLayout)
        self.bGotBuilt = True


    def gotFocus(self):
        if not utils.isNone(self.funcGetCompleterStrings):
            sStrings = self.funcGetCompleterStrings()
            self.text.qCompleterModel.setStringList(sStrings)


    def clearClicked(self):
        self.text.setText('')


    def selectedClicked(self):
        sSel = cmds.ls(sl=True)
        if self.bList:
            self.text.setText('; '.join(sSel))
        else:
            self.text.setText(sSel[0])

    def getValue(self):
        if self.bList:
            sObjs = self.text.text().split(';')
            sReturns = []
            for sObj in sObjs:
                sObj = sObj.strip()
                if sObj: sReturns.append(sObj)
            return sReturns
        else:
            return self.text.text()

#
# class NamespaceControl(SelectionControl):
#     def __init__(self, bDisableOnServer=False):
#         SelectionControl.__init__(self, bList=False, bDisableOnServer=bDisableOnServer)
#
#     def selectedClicked(self):
#         sSel = cmds.ls(sl=True)
#         sObj = sSel[0]
#         sSplits = sObj.split(':')
#         sNamespace = '%s:' % ':'.join(sSplits[:-1])
#         self.text.setText(sNamespace)



class NamespaceControl(SelectionControl):
    def __init__(self):
        SelectionControl.__init__(self)
        self.bList = False

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        SelectionControl.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow, bClearButton=True)
        self.text.setEnabled(False)

    def selectedClicked(self):
        sSel = cmds.ls(sl=True)[0]
        sNamespace = '%s:' % ':'.join(sSel.split(':')[:-1])
        self.text.setText(sNamespace)






class SphereMasksControl(SelectionControl):
    def __init__(self):
        SelectionControl.__init__(self)

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        SelectionControl.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow)
        self.createButton = QtWidgets.QPushButton('Create')
        self.createButton.clicked.connect(self.createSphere)
        self.layout.addWidget(self.createButton)

    def createSphere(self):
        patch.createSkinningSphere('noname')



class MiddleEdgeControl(Control):
    def __init__(self):
        Control.__init__(self)

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)

        self.layout = QtWidgets.QHBoxLayout()
        
        self.verticalLayout = QtWidgets.QVBoxLayout()
        
        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.text = QtWidgets.QLineEdit()
        if xValue:
            self.text.setText(xValue)
        self.button = QtWidgets.QPushButton('Selected')

        self.button.clicked.connect(self.selectedClicked)
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.text)
        self.layout.addWidget(self.button)
        self.verticalLayout.addLayout(self.layout)
        self.uniqueLayout.addLayout(self.verticalLayout)


    def selectedClicked(self):
        sSel = cmds.ls(sl=True)
        sObj = sSel[0]
        if '.e[' in sObj:
            self.text.setText(sObj)
        else:
            pPatch = patch.patchFromName(sObj)
            sEdge = topology.detectMiddleEdge(pPatch, bReturnString=True)
            self.text.setText(sEdge)


    def getValue(self):
        return self.text.text()


class VectorControl(Control):
    def __init__(self, iLength=3):
        self.iLength = iLength
        Control.__init__(self)

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)

        self.layout = QtWidgets.QHBoxLayout()

        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.texts = [QtWidgets.QLineEdit() for _ in range(self.iLength)]
        if xValue:
            for i,fV in enumerate(xValue):
                self.texts[i].setText(str(fV))

        self.layout.addWidget(self.label)
        for i in range(self.iLength):
            self.layout.addWidget(self.texts[i])

        self.uniqueLayout.addLayout(self.layout)


    def getValue(self):
        return [float(text.text()) for text in self.texts]



class ProjectsControl(Control):
    def __init__(self, assetsModule=None):
        Control.__init__(self)
        self.bRefreshButton = True
        self.assetsModule = assetsModule

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)
        self.layout = QtWidgets.QHBoxLayout()

        self.verticalLayout = QtWidgets.QVBoxLayout()

        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.qProjects = QtWidgets.QComboBox()

        self.layout.addWidget(self.label)
        self.layout.addWidget(self.qProjects)
        self.verticalLayout.addLayout(self.layout)
        self.uniqueLayout.addLayout(self.verticalLayout)
        self.refresh()

    def getValue(self):
        sProjectText = self.qProjects.currentText()
        return '__%s__' % sProjectText

    def refresh(self):
        sCurrentAssetRoot = self.assetsModule.getLocalAssetRoot()
        sProjects = self.assetsModule.getProjectsFromRoots(sCurrentAssetRoot)
        sCurrentProject = self.assetsModule.getCurrentProject()
        self.qProjects.clear()
        iSetIndex = 0
        for p,sP in enumerate(sProjects):
            self.qProjects.addItem(sP[2:-2])
            if sP == sCurrentProject:
                iSetIndex = p
        self.qProjects.setCurrentIndex(iSetIndex)


class DistanceMeshesControl(Control):
    def __init__(self, bList=True):
        Control.__init__(self)
        self.bGroupBox = True
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)
        
        self.layout = QtWidgets.QHBoxLayout()

        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.text = QtWidgets.QLineEdit()
        self.text.setText(';'.join(xValue[0] if xValue else []))
        self.button = QtWidgets.QPushButton('Selected')
        
        self.button.clicked.connect(self.selectedClicked)
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.text)
        self.layout.addWidget(self.button)
        
        self.uniqueLayout.addLayout(self.layout)
        
        layout = QtWidgets.QHBoxLayout()
        for sName,fDefault in [('Start',0.1), ('End',0.5)]:
            label = QtWidgets.QLabel('%s: ' % sName)
            textField = QtWidgets.QLineEdit(str(fDefault))
            textField.setValidator(utilsQt.QFloatValidator())
            setattr(self, 'q%sLabel' % sName, label)
            setattr(self, 'q%sText' % sName, textField)
            layout.addWidget(label)
            layout.addWidget(textField)
        self.outsideRangeCheckbox = QtWidgets.QCheckBox('Outside Range')
        self.splineInterp = QtWidgets.QCheckBox('Spline Interp')
        layout.addWidget(self.outsideRangeCheckbox)
        layout.addWidget(self.splineInterp)
        self.uniqueLayout.addLayout(layout)

    def selectedClicked(self):
        sSel = cmds.ls(sl=True)
        self.text.setText('; '.join(sSel))


    def getValue(self):
        sMeshes = self.text.text()
        if sMeshes:
            return {'sMeshes':[sObj.strip() for sObj in sMeshes.split(';')],
                    'fStart': float(self.qStartText.text()),
                    'fEnd': float(self.qEndText.text()),
                    'bOutside': self.outsideRangeCheckbox.isChecked(),
                    'bSplineInterp':self.outsideRangeCheckbox.isChecked()}
        else:
            return None


class ClosestToCurveControl(Control):
    def __init__(self, bList=True):
        Control.__init__(self)
        self.bGroupBox = True

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)

        self.layout = QtWidgets.QHBoxLayout()

        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.text = QtWidgets.QLineEdit()
        # self.text.setText(';'.join(xValue[0]))
        self.button = QtWidgets.QPushButton('Selected')

        self.button.clicked.connect(self.selectedClicked)
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.text)
        self.layout.addWidget(self.button)

        self.uniqueLayout.addLayout(self.layout)

        layout = QtWidgets.QHBoxLayout()
        qExpandTextFields = []
        for sName, fDefault in [('forwExpand', 2), ('forwFade', 2), ('backExpand', 2), ('backFade', 2)]:
            label = QtWidgets.QLabel('%s: ' % sName)
            textField = QtWidgets.QLineEdit(str(fDefault))
            textField.setValidator(QtGui.QIntValidator())
            layout.addWidget(label)
            layout.addWidget(textField)
            qExpandTextFields.append(textField)
        self.qForwExpand, self.qForwFade, self.qBackExpand, self.qBackFade = qExpandTextFields
        self.uniqueLayout.addLayout(layout)

        layout = QtWidgets.QHBoxLayout()
        self.qVector = []
        label = QtWidgets.QLabel('Halfspace Vector:')
        layout.addWidget(label)

        for i,fV in enumerate([0.0,1.0,0.0]):
            textField = QtWidgets.QLineEdit('%.2f' % fV)
            textField.setValidator(utilsQt.QFloatValidator())
            layout.addWidget(textField)
            self.qVector.append(textField)
        self.uniqueLayout.addLayout(layout)


    def selectedClicked(self):
        sSel = cmds.ls(sl=True)
        self.text.setText('; '.join(sSel))


    def getValue(self):
        sCurve = self.text.text()
        if sCurve:
            dReturn = {'sCurve':sCurve,
                        'iForwExpand':int(self.qForwExpand.text()),
                        'iForwFade':int(self.qForwFade.text()),
                        'iBackExpand':int(self.qBackExpand.text()),
                        'iBackFade':int(self.qBackFade.text()),
                        'fHalfspaceVector':(float(self.qVector[0].text()),float(self.qVector[1].text()),float(self.qVector[2].text()))}
            return dReturn
        else:
            return None


class RadioButtonsControl(Control):
    def __init__(self, enumClassOrList, bGroupBox=True, iColumns=1):
        Control.__init__(self)
        try:
            sOptions = list(enumClassOrList)
            xValues = list(enumClassOrList)
        except:
            sOptions = [sO for sO in enumClassOrList.__dict__ if not sO.startswith('__')]
            xValues = [enumClassOrList.__dict__[sO] for sO in sOptions]
        iSorts = np.argsort(xValues)
        self.sOptions = [sOptions[i] for i in iSorts]
        self.xValues = [xValues[i] for i in iSorts]
        self.bGroupBox = bGroupBox
        self.iColumns = iColumns
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)
        self.buttons = []
        allColumns = QtWidgets.QHBoxLayout()
        self.uniqueLayout.addLayout(allColumns)
        
        buttonLayouts = []
        for iC in range(self.iColumns):
            columnLayout = QtWidgets.QVBoxLayout()
            columnLayout.setAlignment( QtCore.Qt.AlignTop)
            buttonLayouts.append(columnLayout)
            allColumns.addLayout(columnLayout)
        
        iMaxCountPerColumn = int(math.ceil(float(len(self.sOptions)) / self.iColumns))
        for i, sOption in enumerate(self.sOptions):
            iC = i // iMaxCountPerColumn
            qtRadioButton = QtWidgets.QRadioButton(utils.beautifyVariableName(sOption))
            if self.xDefaultValue == self.xValues[i]:
                qtRadioButton.setChecked(True)
            buttonLayouts[iC].addWidget(qtRadioButton)
            self.buttons.append(qtRadioButton)
            qtRadioButton.toggled.connect(self.runControlOtherControl)

    def getValue(self):
        xValue = None
        for i, qtRadioButton in enumerate(self.buttons):
            if qtRadioButton.isChecked():
                xValue = self.xValues[i]
        return xValue

    def setToDefault(self, xValue=None):
        Control.setToDefault(self)
        if xValue == None:
            xValue = self.xDefaultValue
        for i, qtRadioButton in enumerate(self.buttons):
            if qtRadioButton.setChecked(True if self.xDefaultValue == i else False):
                return self.xValues[i]



class SliderControl(Control):
    def __init__(self, iRange=[0,10]):
        Control.__init__(self)
        self.iRange = iRange
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        #print traceback.format_exc()
        Control.build(self, qParentLayout, sName, xValue)
        self.layout = QtWidgets.QHBoxLayout()
        self.bIsFloat = True if type(xValue) == float else False

        self.label = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.text = QtWidgets.QLineEdit()
        if self.bIsFloat:
            self.text.setValidator(utilsQt.QFloatValidator())
        else:
            self.text.setValidator(QtGui.QIntValidator())
        self.text.setText(str(xValue))
        self.text.textChanged.connect(self.textChanged)
        iWidth = 50
        self.text.setMaximumWidth(iWidth)
        self.text.setMinimumWidth(iWidth)
        self.text.setAlignment(QtCore.Qt.AlignCenter)
        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        if self.bIsFloat:
            self.slider.setRange(0,1000)
            self.iRange[0] = float(self.iRange[0])
            self.iRange[1] = float(self.iRange[1])
        else:
            self.slider.setRange(self.iRange[0], self.iRange[1])

        self.slider.valueChanged.connect(self.sliderMove)
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.text)
        self.layout.addWidget(self.slider)
        self.qMainLayout.addLayout(self.layout)
        
        self.textChanged(self.text.text())
    
    def textChanged(self, sText):
        if self.bIsFloat:
            try:
                fValue = float(sText)
            except:
                fValue = 0.0
            fPerc = (fValue-self.iRange[0]) / (self.iRange[1]-self.iRange[0])
            self.slider.blockSignals(True)
            try:
                self.slider.setValue(fPerc*1000)
            except:
                raise
            finally:
                self.slider.blockSignals(False)
        else:
            try:
                iText = int(sText)
            except:
                iText = 0
            
            self.slider.blockSignals(True)
            try:
                self.slider.setValue(iText)
            except:
                raise
            finally:
                self.slider.blockSignals(False)

    def sliderMove(self):
        if self.bIsFloat:
            fPerc = self.slider.value() * 0.001
            fValue = self.iRange[0] + (self.iRange[1]-self.iRange[0])*fPerc
            self.text.setText(str(fValue))
        else:
            self.text.setText(str(self.slider.value()))
    
    def getValue(self):
        return float(self.text.text()) if self.bIsFloat else int(self.text.text())

    def setToDefault(self, xValue=None):
        self.text.setText(str(xValue if xValue else self.xDefaultValue))





class CompleterDelegate(QtWidgets.QStyledItemDelegate):
    def __init__(self, words_list, parent=None, funcGetStrings=None, bMatchContain=False):
        super(CompleterDelegate, self).__init__(parent)
        self.words_list = words_list
        self.funcGetStrings = funcGetStrings
        self.bMatchContain = bMatchContain

    def updateFunction(self):
        if not utils.isNone(self.funcGetStrings):
            sStrings = self.funcGetStrings()
            self.qLineEdit.qCompleterModel.setStringList(sStrings)


    def createEditor(self, parent, option, index):
        self.qLineEdit = utilsQt.QLineEditWithCompleter(parent=parent, bMatchContain=self.bMatchContain)

        if self.updateFunction:
            self.qLineEdit.gotFocus.connect(self.updateFunction)

        return self.qLineEdit

    def setEditorData(self, editor, index):
        text = index.model().data(index)
        editor.setText(text)

    def setModelData(self, editor, model, index):
        model.setData(index, editor.text())




class DictionaryControl(Control):
    def __init__(self, funcGetCompleterSrings=None):
        self.funcGetCompleterSrings = funcGetCompleterSrings
        Control.__init__(self)
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)
        self.qtLayout = QtWidgets.QVBoxLayout()
        self.qtLayout.setSpacing(0)
        self.uniqueLayout.addLayout(self.qtLayout)
        self.qtTable = QtWidgets.QTableWidget()
        self.qtTable.setRowCount(1)
        self.qtTable.setColumnCount(2)
        self.qtTable.setHorizontalHeaderLabels(('From', 'To'))
        self.qtTable.horizontalHeader().setStretchLastSection(True)
        self.qtTable.verticalHeader().hide()
        self.qtTable.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)

        

        self.qtButtonAddRow = QtWidgets.QPushButton('Add Row')
        self.qtButtonAddRow.clicked.connect(self.addRow)
        self.qtButtonDeleteRow = QtWidgets.QPushButton('Delete Row')
        self.qtButtonDeleteRow.clicked.connect(self.deleteRow)
        self.qtButtonFlipRow = QtWidgets.QPushButton('Flip Row')
        self.qtButtonFlipRow.clicked.connect(self.flipRow)
        self.qtLayout.addWidget(self.qtButtonAddRow)
        self.qtLayout.addWidget(self.qtButtonDeleteRow)
        self.qtLayout.addWidget(self.qtButtonFlipRow)
        self.qtLayout.addWidget(self.qtTable)


        self.qtTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtTable.customContextMenuRequested.connect(self.markingMenu)

        delegate = CompleterDelegate([], funcGetStrings=self.funcGetCompleterSrings, bMatchContain=True)
        self.qtTable.setItemDelegateForColumn(0, delegate)
        self.qtTable.setItemDelegateForColumn(1, delegate)

    def addSelection(self):
        utils.debugPrint('selection: ', self.qtTable.selectedItems())

        iRow = self.qtTable.currentRow()
        iColumn = self.qtTable.currentColumn()
        qItem = self.qtTable.item(iRow,iColumn)

        sSel = cmds.ls(sl=True, et='joint')
        sSelString = str(sSel)


        if not qItem:
            qItem = QtWidgets.QTableWidgetItem(sSelString)
            self.qtTable.setItem(iRow, iColumn, qItem)
        else:
            qItem.setText(sSelString)

    def select(self):
        iRow = self.qtTable.currentRow()
        iColumn = self.qtTable.currentColumn()
        qItem = self.qtTable.item(iRow,iColumn)
        try:
            sList = eval(qItem.text())
            sObjects = utils.stringOrListToObjects(sList)
            cmds.select(sObjects)
        except:
            cmds.select(qItem.text())



    def markingMenu(self, vPos):
        qMenu = QtWidgets.QMenu()
        qMenu.addAction('Set from Selection', self.addSelection)
        qMenu.addAction('Select', self.select)
        qMenu.exec_(self.qtTable.mapToGlobal(vPos))


        return qMenu




    def addRow(self):
        self.qtTable.insertRow(self.qtTable.rowCount())
    
    def deleteRow(self):
        iRows = [ind.row() for ind in self.qtTable.selectionModel().selectedRows()]
        iRows.sort(reverse=True)
        for iR in iRows:
            self.qtTable.removeRow(iR)

    def flipRow(self):
        iRows = [ind.row() for ind in self.qtTable.selectionModel().selectedRows()]
        for iR in iRows:
            sFrom = self.qtTable.item(iR,0).text()
            sTo = self.qtTable.item(iR,1).text()

            self.qtTable.item(iR,0).setText(sTo)
            self.qtTable.item(iR,1).setText(sFrom)


    def getValue(self):
        dReturn = {}
        for i in range(self.qtTable.rowCount()):
            sFrom = self.qtTable.item(i,0).text()
            sTo = self.qtTable.item(i,1).text()
            dReturn[sFrom] = sTo
        return dReturn



class WeightmapSelector(Control):
    def __init__(self, bSingleSelection=False):
        Control.__init__(self)
        self.bRefreshButton = True
        self.bSingleSelection=bSingleSelection
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue)
        
        self.qtLayout = QtWidgets.QHBoxLayout()
        self.qtTree = QtWidgets.QTreeWidget()
        self.qtTree.setHeaderHidden(True)
        
        if self.bSingleSelection:
            self.qtTree.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        else:
            self.qtTree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

        self.qLabel = QtWidgets.QLabel(utils.beautifyVariableName(sName))
        self.qtLayout.addWidget(self.qLabel)

        self.qtLayout.addWidget(self.qtTree)
        self.uniqueLayout.addLayout(self.qtLayout)
        
        self.qtTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtTree.customContextMenuRequested.connect(self.markingMenu)

        self.refresh()



    def printWeights(self, sMap):
        print('sMap: ', sMap)

        sMap = deformers.decodeMapName(sMap)

        fValues = cmds.getAttr(sMap)[0]
        sValues = ['%0.3f' % fV for fV in fValues]
        for v in range(len(sValues)):
            if sValues[v] == '0.000':
                sValues[v] = '0'
            elif sValues[v] == '1.000':
                sValues[v] = '1'

        utils.debugPrint('(%s)' % ', '.join(sValues))



    def paint(self, sMap):
        utils.debugPrint(sMap)
        sSplitMap = sMap.split('.')
        sDeformer = sSplitMap[0]
        sType = cmds.objectType(sDeformer)
        sAttr = sSplitMap[-1]
        sGeo = deformers.getGeoFromDeformer(sDeformer)
        cmds.select(sGeo)
        mel.eval('toolPropertyWindow -inMainWindow true')
        mel.eval('source "artAttrBlendShapeCallback.mel"')
        if sType == 'blendShape': # this is not selecting the correct target or base weights. Need to revisit in 2017
            if sAttr == 'baseWeights':
                mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.baseWeights" )' % sDeformer)
                mel.eval('artAttrInitPaintableAttr')
                cmds.refresh()
            else: # targetWeights
                #blendShape1.inputTarget[0].inputTargetGroup[pSphere2].targetWeights
                sTarget = 'pSphere2'
                mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.paintTargetWeights" )' % sDeformer)
                mel.eval('artBlendShapeTargetIndex')
                mel.eval('artBlendShapeSelectTarget artAttrCtx "%s"' % sTarget) #errors on first time
                mel.eval('artBlendShapeTargetIndex')
                mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.paintTargetWeights" )' % sDeformer)
                cmds.refresh(force=True)
                
                iIndex = mel.eval('artBlendShapeTargetIndex')
                if iIndex[0] != 0:
                    cmds.confirmDialog( title='Confirm', message= 'please select "paint" again to ensure you are painting '
                                                                  'the correct target.\n(this should only happen the first time after you opened Maya)', button=['ok'])
    
        elif sType == 'nCloth':
            sMapName = sMap.split('.')[-1][:-len('perVertex')]
            mel.eval('setNClothMapType("%s","outputCloth1",1)' % sMapName)
            mel.eval('artAttrNClothToolScript 4 %s' % sMapName)
        else:
            mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "%s.%s.%s" )' % (sType, sDeformer, sAttr))
            mel.eval('artAttrInitPaintableAttr')
            cmds.refresh()
        

        '''
        iIndex = mel.eval('artBlendShapeTargetIndex')
        if iIndex[0] != 0:
            cmds.confirmDialog( title='Confirm', message= 'please select "paint" again to ensure you are painting '
                                                          'the correct target.\n(this should only happen the first time after you opened Maya)', button=['ok'])
        '''
    
    def markingMenu(self, vPos):
        qMenu = QtWidgets.QMenu()
        qSelItems = self.qtTree.selectedItems()
        sSelMap = qSelItems[0].data(0, QtCore.Qt.UserRole)

        qMenu.addAction('paint %s' % qSelItems[0].text(0), lambda:self.paint(sSelMap))
        qMenu.addAction('print %s' % qSelItems[0].text(0), lambda:self.printWeights(sSelMap))

        qMenu.exec_(self.qtTree.mapToGlobal(vPos))
        return qMenu




    def refresh(self, xValue=None):
        self.qtTree.clear()

        def addDeformer(sDeformer, qParent, sGeoShape=None):
            utils.debugPrint('addDeformer: ', sDeformer)
            qDeformer = QtWidgets.QTreeWidgetItem(qParent)
            qDeformer.setText(0, sDeformer)
            qDeformer.setExpanded(True)
            qDeformer.setFlags(qDeformer.flags() & ~QtCore.Qt.ItemIsSelectable)
            qDeformer.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.green)))
            sMaps = deformers.getWeightMaps(sDeformer, sGeoShape=sGeoShape)

            utils.debugPrint('sMaps: ', sMaps)
            for sAttr, sAttrName in sMaps:
                utils.debugPrint('making map item... ', sAttrName)
                qMapItem = QtWidgets.QTreeWidgetItem(qDeformer)
                qMapItem.setText(0, sAttrName)
                qMapItem.setData(0, QtCore.Qt.UserRole, sAttr)
                qMapItem.setSelected(True)
            if cmds.objectType(sDeformer) == 'skinCluster':
                qJointWeights = QtWidgets.QTreeWidgetItem(qDeformer)
                qJointWeights.setText(0, '__jointWeights__')
                qJointWeights.setFlags(qJointWeights.flags() & ~QtCore.Qt.ItemIsSelectable)
                _, sInfluences = patch.patchFromName(sGeo).getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sDeformer)
                for sI in sInfluences:
                    qInfluence = QtWidgets.QTreeWidgetItem(qJointWeights)
                    qInfluence.setText(0, sI)
                    qInfluence.setData(0, QtCore.Qt.UserRole, '%s.%s.__jointWeights__' % (sDeformer, sI))

                qBlendWeights = QtWidgets.QTreeWidgetItem(qDeformer, '__blendWeights__')
                qBlendWeights.setText(0, '__blendWeights__')
                qBlendWeights.setData(0, QtCore.Qt.UserRole, '%s.__blendWeights__' % sDeformer)


        sAddedDeformers = []
        for tbPatch in patch.getSelectedPatches(bAlwaysReturnFullGeometry=True):
            sGeo = utils.extendToShape(tbPatch.getObjectName())

            qGeo = QtWidgets.QTreeWidgetItem(self.qtTree.invisibleRootItem())
            qGeo.setExpanded(True)
            qGeo.setText(0, sGeo)
            qGeo.setFlags(qGeo.flags() & ~QtCore.Qt.ItemIsSelectable)
            qGeo.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.green)))
            sDeformers = deformers.listAllDeformers(tbPatch.getTransformName(), bDoCloth=True)
            utils.debugPrint('sDeformers: ', sDeformers)
            for sDeformer in sorted(sDeformers):
                addDeformer(sDeformer, qGeo, sGeoShape=sGeo)

            sAddedDeformers.append(addDeformer)

        sSelectedDeformers = [sN for sN in cmds.ls(sl=True) if 'geometryFilter' in cmds.nodeType(sN, i=True)]
        for sDeformer in sSelectedDeformers:
            if sDeformer not in sAddedDeformers:
                addDeformer(sDeformer, self.qtTree)

    def getValue(self):
        qSelectedItems = self.qtTree.selectedItems()
        sReturn = []
        for qItem in qSelectedItems:
            sReturn.append(qItem.data(0, QtCore.Qt.UserRole))
        return sReturn



class JointsSelector(Control):
    def __init__(self, chooseControl=None):
        Control.__init__(self)
        self.bRefreshButton = True
        self.chooseControl = chooseControl
        
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        Control.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow)
        self.qtLayout = QtWidgets.QVBoxLayout()
        self.qtMeshes = QtWidgets.QLineEdit()
        self.qtMeshes.setReadOnly(True)
        self.qtMeshes.setEnabled(False)

        self.qtFilter = QtWidgets.QLineEdit()


        self.qJointTable = QtWidgets.QTableWidget()
        # self.qJointTable.setHeaderHidden(True)
        self.qJointTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.qJointTable.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.qJointTable.setColumnCount(2)
        self.qJointTable.setColumnWidth(0,1)
        self.qJointTable.verticalHeader().hide()
        self.qJointTable.horizontalHeader().hide()
        self.qJointTable.horizontalHeader().setStretchLastSection(True)

        self.qtLayout.addWidget(self.qtMeshes)
        self.qtLayout.addWidget(self.qtFilter)
        self.qtLayout.addWidget(self.qJointTable)
        self.uniqueLayout.addLayout(self.qtLayout)

        self.selectedLayout = QtWidgets.QHBoxLayout()
        self.uniqueLayout.addLayout(self.selectedLayout)
        self.qSelJoints = QtWidgets.QPushButton('selected joints')
        self.qSelJoints.clicked.connect(self.selJoints)
        self.selectedLayout.addWidget(self.qSelJoints)

        self.qSelJointSequence = QtWidgets.QPushButton('selected joint sequence')
        self.qSelJointSequence.clicked.connect(lambda:self.selJoints(bSequence=True))
        self.selectedLayout.addWidget(self.qSelJointSequence)

        self._iRowHeight = utilsQt.getDpi() // 5
        self.refresh()

        self.qtFilter.textChanged.connect(self.filterChanged)

        self.qJointTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qJointTable.customContextMenuRequested.connect(self.markingMenu)


    def paintJoint(self, sJoint):
        # print 'paint %s. Not working yet.... ' % sJoint
        mel.eval('ArtPaintSkinWeightsTool()')
        mel.eval('artSkinInflListChanging "%s" 1' % sJoint)
        mel.eval('artSkinInflListChanged artAttrSkinPaintCtx')


    def markingMenu(self, vPos):
        utils.debugPrint('marking menu')
        qMenu = QtWidgets.QMenu()

        qSelectedItems = self.qJointTable.selectedItems()
        for qItem in qSelectedItems:
            utils.debugPrint('qItem.sJoint: ', qItem.sJoint)

            def _paintJoint(sJoint=qItem.sJoint):
                self.paintJoint(sJoint)

            def _copyToClipBoardJoint(sJoint=qItem.sJoint):
                utils.copyToClipBoard(sJoint)

            qMenu.addAction('paint "%s"' % qItem.sJoint, _paintJoint)
            qMenu.addAction('copy to clipboard "%s"' % qItem.sJoint, _copyToClipBoardJoint)

        sAllJoints = [qI.sJoint for qI in qSelectedItems]
        def _selectJoints():
            cmds.select(sAllJoints)
        qMenu.addAction('select %s' % utils.listToString(sAllJoints, iMaxCount=3), _selectJoints)

        qMenu.exec_(self.qJointTable.mapToGlobal(vPos))
        return qMenu



    def filterChanged(self):
        sFilter = self.qtFilter.text()
        if not sFilter:
            for qJ in list(self.dQJointItems.values()):
                qJ.bOutFiltered=False
                self._updateJointRowVis(qJ)
        else:
            sFilterJoints = []
            sAllJointsInScene = np.array(cmds.ls(et='joint'))
            sLowerAllJointsInScene = [sJ.lower() for sJ in sAllJointsInScene]
            sSplits = sFilter.replace(' ', ',').split(',')
            iAllFilterJoints = []
            for sSp in sSplits:
                if sSp:
                    sLowerSp = sSp.lower()
                    iAllFilterJoints += [j for j,sJ in enumerate(sLowerAllJointsInScene) if sLowerSp in sJ]
            if iAllFilterJoints:
                sAllFilterJoints = sAllJointsInScene[np.array(list(set(iAllFilterJoints)), dtype=int)]
                sFilterJoints = np.intersect1d(sAllFilterJoints, list(self.dQJointItems.keys()))

            sHideJoints = list(set(self.dQJointItems.keys()) - set(sFilterJoints))
            for sHide in sHideJoints:
                qJ = self.dQJointItems[sHide]
                qJ.bOutFiltered = True
                self._updateJointRowVis(qJ)
                qJ.setSelected(False)
            for sShow in sFilterJoints:
                qJ = self.dQJointItems[sShow]
                qJ.bOutFiltered = False
                self._updateJointRowVis(qJ)


    def selJoints(self, bSequence=False):
        sChoose=None
        if self.chooseControl.bGotBuilt:
            sChoose = self.chooseControl.getValue()

        sJoints = cmds.ls(sl=True, et='joint')
        if bSequence:
            sNewJoints = []
            for sJ in sJoints:
                sSplits = sJ.split('_')
                try:
                    int(sSplits[-1])
                except:
                    sNewJoints.append(sJ)
                    continue
                sSplits[-1] = '*'
                sNewJoints += cmds.ls('_'.join(sSplits), et='joint')
            sJoints = sNewJoints
            sJoints = list(set(sJoints))
            sJoints.sort()
            cmds.select(sJoints)

        sMissingJoints = set(sJoints) - set(self.dQJointItems.keys())

        if len(sMissingJoints):
            sMissingJoints = list(sMissingJoints)
            if cmds.confirmDialog( title='Add these joints?', message=', '.join(sMissingJoints), button=['Yes','No'],
                                                defaultButton='Yes', cancelButton='No', dismissString='No') == 'Yes':
                sMeshes = self.qtMeshes.text().split(', ')
                for sMesh in sMeshes:
                    sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChoose, sMesh)
                    pMesh = patch.patchFromName(sMesh)
                    sSkinCluster, _ = pMesh.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sConvertedChooseSkinCluster)
                    utils.debugPrint('adding to sSkinCluster: ', sSkinCluster)
                    deformers.addInfluences(sSkinCluster, sMissingJoints)
                self.refresh(bKeepMeshes=True)

        self.qtFilter.setText('')

        sExistingKeys = list(set(self.dQJointItems.keys()) & set(sJoints))
        self.qJointTable.clearSelection()

        self.qJointTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)

        for sJ in sExistingKeys:
            qJ = self.dQJointItems[sJ]
            self.qJointTable.selectRow(qJ.iRow)
            ind = self.qJointTable.indexFromItem(qJ)
            self.qJointTable.scrollTo(ind)

        self.qJointTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)


    def refresh(self, xValue=None, bKeepMeshes=False):
        self.qtFilter.setText('')
        sChooseSkinCluster=None
        if self.chooseControl.bGotBuilt:
            sChooseSkinCluster = self.chooseControl.getValue()

        if not bKeepMeshes:
            pPatches = patch.getSelectedPatches(bAlwaysReturnFullGeometry=True)
            if not pPatches and sChooseSkinCluster:
                if isinstance(sChooseSkinCluster, (str,unicode)):
                    sGeo = deformers.getGeoFromDeformer(sChooseSkinCluster)
                    pPatches.append(patch.patchFromName(sGeo))
        else:
            pPatches = [patch.patchFromName(sM) for sM in self.qtMeshes.text().split(', ')]



        sMeshes = []
        sAllInfluences = []
        for tbPatch in pPatches:
            sConvertedChooseSkinCluster = deformers.convertChooseSkinCluster(sChooseSkinCluster, tbPatch.getName())#, _report=self.qtWindow._report)
            utils.debugPrint('sConvertedChooseSkinCluster: ', sConvertedChooseSkinCluster)
            sSkinCluster, sInfluences = tbPatch.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sConvertedChooseSkinCluster)
            if not sSkinCluster:
                continue
            sMeshes.append(tbPatch.getName())
            sAllInfluences += sInfluences
        sAllInfluences = list(set(sAllInfluences))
        self.qtMeshes.setText(', '.join(sMeshes))
        dChildren = defaultdict(list)
        sRoots = []
        for sInf in sAllInfluences:
            sCheckInf = sInf
            for i in range(1000):
                sParents = cmds.listRelatives(sCheckInf, p=True)
                if not sParents:
                    sRoots.append(sInf)
                    break
                elif sParents[0] in sAllInfluences:
                    dChildren[sParents[0]].append(sInf)
                    break
                else:
                    sCheckInf = sParents[0]

        self.qJointTable.clear()
        self.qJointTable.iCurrentRow = 0

        self.dQJoinlChildren = defaultdict(list) # per joint Name, their children's tablewidgetitems
        self.dQJointItems = {} # per joint name, its tablewidgetitem

        def _addQJoints(sJoints, iIndent=0, sParentJoint=None):
            sJoints.sort()
            for sJoint in sJoints:

                qTableItem, qJointItem = self._createJointItem(sJoint, iIndent,
                                                               self.qJointTable.iCurrentRow,
                                                               bHasChildren = True if dChildren[sJoint] else False)
                self.qJointTable.setItem(self.qJointTable.iCurrentRow, 0, qTableItem)
                self.qJointTable.setCellWidget(self.qJointTable.iCurrentRow, 1, qJointItem)

                # self.qJointTable.setRowHeight(self.qJointTable.iCurrentRow, self._iRowHeight)
                self.qJointTable.iCurrentRow += 1

                self.dQJoinlChildren[sParentJoint].append(qTableItem)
                self.dQJointItems[sJoint] = qTableItem
                _addQJoints(dChildren[sJoint], iIndent=iIndent+1, sParentJoint=sJoint)

        self.qJointTable.setRowCount(len(sAllInfluences))
        sRoots.sort()
        _addQJoints(sRoots)
        self.qJointTable.resizeRowsToContents()




    def _createJointItem(self, sJoint, iIndent, iRow, bHasChildren):

        qTableItem = QtWidgets.QTableWidgetItem('')
        qJointItem = QtWidgets.QWidget(self.qJointTable)

        itemLayout = QtWidgets.QHBoxLayout(self.qJointTable)
        itemLayout.setContentsMargins(0, 0, 0, 0)

        qTableItem.sJoint = sJoint
        qTableItem.iRow = iRow
        qTableItem.qLock = QtWidgets.QPushButton('lck')
        qTableItem.qLock.setCheckable(True)
        qTableItem.qLock.setChecked(cmds.getAttr('%s.liw' % sJoint))
        qTableItem.qLock.setMaximumWidth(35)
        qTableItem.qLock.setMinimumWidth(35)
        qTableItem.qLock.setMaximumHeight(self._iRowHeight)
        qTableItem.qLock.setMinimumHeight(self._iRowHeight)

        def _lockClicked(bDummy=False, qTableItem=qTableItem):
            bIsLocked = qTableItem.qLock.isChecked()
            cmds.setAttr('%s.liw' % qTableItem.sJoint, bIsLocked)
            qSelectedItems = self.qJointTable.selectedItems()
            if len(qSelectedItems) > 1 and qTableItem.isSelected():
                for qTableI in qSelectedItems:
                    qTableI.qLock.blockSignals(True)
                    qTableI.qLock.setChecked(bIsLocked)
                    qTableI.qLock.blockSignals(False)
                    cmds.setAttr('%s.liw' % qTableI.sJoint, bIsLocked)



        qTableItem.qLock.clicked.connect(_lockClicked)

        if bHasChildren:
            qSpacer = QtWidgets.QSpacerItem(10 * iIndent, 1)

            def _collapseBelowREC(qTableItem=qTableItem, bCollapse=None, bFirst=True):
                qChildItems = self.dQJoinlChildren[qTableItem.sJoint]
                if bCollapse == None or bCollapse == False:  # either the first one, or the first was expanded and now we have to check each
                    if qTableItem.qCollapse != None:
                        bCollapse = qTableItem.qCollapse.isChecked()
                    else:
                        bCollapse = False

                for qI in qChildItems:
                    qI.bCollapsed = bCollapse
                    self._updateJointRowVis(qI)
                    _collapseBelowREC(qTableItem=qI, bCollapse=bCollapse, bFirst=False)

            qTableItem.qCollapse = QtWidgets.QPushButton('>')
            qTableItem.qCollapse.clicked.connect(_collapseBelowREC)
            iCollapseButtonSize = self._iRowHeight * 0.5
            qTableItem.qCollapse.setMaximumWidth(iCollapseButtonSize)
            qTableItem.qCollapse.setMinimumWidth(iCollapseButtonSize)
            qTableItem.qCollapse.setMaximumHeight(iCollapseButtonSize)
            qTableItem.qCollapse.setMinimumHeight(iCollapseButtonSize)
            qTableItem.qCollapse.setCheckable(True)
        else:
            qSpacer = QtWidgets.QSpacerItem(10 * (iIndent+2), 1)
            qTableItem.qCollapse = None
        qTableItem.bCollapsed = False
        qTableItem.bOutFiltered = False
        qLabel = QtWidgets.QLabel(sJoint)
        itemLayout.addWidget(qTableItem.qLock)
        itemLayout.addItem(qSpacer)
        if bHasChildren:
            itemLayout.addWidget(qTableItem.qCollapse)
        itemLayout.addWidget(qLabel)
        qJointItem.setLayout(itemLayout)

        return qTableItem, qJointItem

    def _updateJointRowVis(self, qTableItem):
        if qTableItem.bCollapsed or qTableItem.bOutFiltered:
            self.qJointTable.setRowHidden(qTableItem.iRow, True)
        else:
            self.qJointTable.setRowHidden(qTableItem.iRow, False)



    def getValue(self):
        return [qI.sJoint for qI in self.qJointTable.selectedItems()]




class FilePathControl(Control):
    def __init__(self, sFormat, bLoad=True, sDefaultFileName='default.file', bUpdateFromAsset=True, bReadOnly=False, bShowContent=False,
                 sPossibleFileExtensions=[], bIsPublish=False, bDisableOnServer=False, dBackupFolder=None):
        Control.__init__(self, bDisableOnServer=bDisableOnServer)
        self.sFormat = sFormat
        self.bLoad = bLoad
        self.sDefaultFileName = sDefaultFileName
        self.bUpdateFromAsset = bUpdateFromAsset
        self.bReadOnly = bReadOnly
        self.bShowContent = bShowContent
        self.sPossibleFileExtensions = sPossibleFileExtensions
        self.bIsPublish = bIsPublish
        self.dBackupFolder = dBackupFolder


    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        if qtWindow != None and self.bUpdateFromAsset:
            qtWindow.assetManager.connectedFileControls.append(self)

        Control.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow)
        self.qtVerticalLayout = QtWidgets.QVBoxLayout()
        self.uniqueLayout.addLayout(self.qtVerticalLayout)

        qtFileLayout = QtWidgets.QHBoxLayout()
        self.qtVerticalLayout.addLayout(qtFileLayout)

        self.qtText = QtWidgets.QLineEdit(xValue)
        if self.bReadOnly:
            self.qtText.setEnabled(False)
        qtFileLayout.addWidget(self.qtText)

        if not self.bReadOnly:
            self.qtButtonFile = QtWidgets.QPushButton('set')
            self.qtButtonFile.clicked.connect(self.openDialog)
            qtFileLayout.addWidget(self.qtButtonFile)

        self.qtButtonExplorer = QtWidgets.QPushButton('explorer')
        self.qtButtonExplorer.clicked.connect(lambda: utils.openExplorer(self.qtText.text()))
        self.qtButtonExplorer.setToolTip('Opens the file in Explorer')
        qtFileLayout.addWidget(self.qtButtonExplorer)

        if self.bShowContent:
            self.qtText.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.qtText.customContextMenuRequested.connect(self.markingMenu)

        self.qtText.textChanged.connect(self.pathGotChanged)

        if self.dBackupFolder:
            self.qtButtonBackup = QtWidgets.QPushButton('backup')
            self.qtButtonBackup.clicked.connect(self.backupMarkingMenu)
            self.qtButtonBackup.setToolTip('Every change you do creates a backup file in "%s". This button can retrieve them' % self.dBackupFolder['sDirName'])
            qtFileLayout.addWidget(self.qtButtonBackup)


    def backupMarkingMenu(self):
        sFile = self.qtText.text()
        sDir = os.path.dirname(sFile)
        sBackupDir = os.path.join(sDir, self.dBackupFolder['sDirName'])
        sContents = os.listdir(sBackupDir)

        self.qMenu = QtWidgets.QMenu()
        iCurrentTime = int(time.time())

        dTimes = {}
        for sContent in sContents:
            if os.path.isfile(os.path.join(sBackupDir, sContent)) and '_' in sContent:
                sName = sContent.split('.')[0]
                if sName.count('_') == 1:
                    sLabel, sTime = sName.split('_')
                    iTime = int(sTime)
                    dTimes[sContent] = iTime

        print ('times: ', list(dTimes.keys()))
        for i, sContent in enumerate(sorted(list(dTimes.keys()), key=lambda a:dTimes[a], reverse=True)):
            print ('sContent: ', sContent)
            if i == 0:
                continue
            iTime = dTimes[sContent]
            def _run(sContent=sContent):
                self.dBackupFolder['func'](sFilePath=os.path.join(sBackupDir, sContent))
            self.qMenu.addAction('%s ago' % utils.fullTimeUnits(iCurrentTime-iTime), _run)

        qCursor = QtGui.QCursor()
        self.qMenu.exec_(qCursor.pos())
        return self.qMenu


    def pathGotChanged(self, sPath):
        # print 'text: ', sPath
        pass

    def markingMenu(self, vPos):
        qMenu = QtWidgets.QMenu()

        sPath = self.qtText.text()
        sDir = os.path.dirname(sPath)
        sFiles = os.listdir(sDir)
        iTimeInds = np.argsort([os.path.getmtime(os.path.join(sDir, sF)) for sF in sFiles])[::-1]

        for iInd in iTimeInds:
            sF = sFiles[iInd]
            bSkip = True
            for sExt in self.sPossibleFileExtensions:
                if sF.endswith(sExt):
                    bSkip = False
                    break
            if bSkip:
                continue
            def setToFile(sF=sF):
                self.qtText.setText(os.path.join(sDir, sF))

            sFilePath = os.path.join(sDir, sF)
            sTimeAgo = utils.fullTimeUnits(time.time() - os.path.getmtime(sFilePath))

            sText = '%s (%s, %s ago)' % (sF, utils.fileSizeNice(os.path.getsize(sFilePath)), sTimeAgo)

            qMenu.addAction(sText, setToFile)
        qMenu.exec_(self.qtText.mapToGlobal(vPos))

        return qMenu


    # def openFolderInExplorer(self):
    #     sFolder = os.path.dirname(self.qtText.text())
    #     print ('open explorer (0)')
    #     utils.openExplorer(sFolder)


    def openDialog(self):
        sPath = os.path.dirname(self.qtText.text())
        if self.bLoad:
            sFiles, _ = QtWidgets.QFileDialog.getOpenFileNames(None, "open file", sPath, self.sFormat)
            if sFiles:
                self.qtText.setText(', '.join(sFiles))
        else:
            sFile, _ = QtWidgets.QFileDialog.getSaveFileName(None, "open file", sPath, self.sFormat)
            if sFile:
                self.qtText.setText(sFile)
        self.refresh()


    def getValue(self):
        return self.qtText.text()


    def changeTopFolder(self, sFolder):
        if self.bIsPublish:
            sPathSplits = sFolder.split(os.sep)
            sDrive = '%s\\' % sPathSplits[0]
            sComponents = [sDrive] + sPathSplits[1:-2] + ['_published', 'RIG_%s_%s.ma' % (sPathSplits[-3], sPathSplits[-1])]
            sPath = os.path.join(*sComponents)
            utils.debugPrint(sPathSplits)
        else:
            sPath = os.path.join(sFolder, self.sDefaultFileName) if self.sDefaultFileName else sFolder

        self.qtText.setText(sPath)
        self.refresh()






class FolderPathControl(Control):
    def __init__(self, sSubFolder=None, bUpdateFromAsset=True, bReadOnly=False):
        Control.__init__(self)
        self.bUpdateFromAsset = bUpdateFromAsset
        self.sSubFolder = sSubFolder
        self.bReadOnly=bReadOnly

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        if qtWindow != None and self.bUpdateFromAsset:
            qtWindow.assetManager.connectedFileControls.append(self)

        Control.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow)
        self.qtVerticalLayout = QtWidgets.QVBoxLayout()
        qtFileLayout = QtWidgets.QHBoxLayout()
        self.uniqueLayout.addLayout(self.qtVerticalLayout)
        self.qtVerticalLayout.addLayout(qtFileLayout)

        self.qtText = QtWidgets.QLineEdit(xValue)
        qtFileLayout.addWidget(self.qtText)
        if self.bReadOnly:
            self.qtText.setEnabled(False)

        if not self.bReadOnly:
            self.qtButtonFile = QtWidgets.QPushButton('set')
            self.qtButtonFile.clicked.connect(self.openDialog)
            qtFileLayout.addWidget(self.qtButtonFile)

        self.qtButtonExplorer = QtWidgets.QPushButton('explorer')
        self.qtButtonExplorer.clicked.connect(self.openFolderInExplorer)
        qtFileLayout.addWidget(self.qtButtonExplorer)




    def openDialog(self):
        sPath = os.path.dirname(self.qtText.text())
        sFolder = QtWidgets.QFileDialog.getExistingDirectory (None, "open file", sPath)
        if sFolder:
            self.qtText.setText(sFolder)
        utils.debugPrint('sFolder: ', sFolder)
        self.refresh()


    def getValue(self):
        return self.qtText.text()


    def changeTopFolder(self, sFolder):
        sPath = os.path.join(sFolder, self.sSubFolder) if self.sSubFolder else sFolder
        self.qtText.setText(sPath)
        self.refresh()


    def openFolderInExplorer(self):
        print ('open explorer (1)')
        sText = self.qtText.text()
        if os.path.isdir(sText):
            utils.openExplorer(sText)
        else:
            utils.openExplorer(os.path.dirname(sText))



class WeightFilePathControl(FilePathControl):
    def __init__(self, bSingleSelection=False, bOnlyMaps=False, bUpdateFromAsset=True):
        FilePathControl.__init__(self, 'weight files (*.wts)', bUpdateFromAsset=bUpdateFromAsset)
        self.bSingleSelection = bSingleSelection
        self.bOnlyMaps = bOnlyMaps
        self.bRefreshButton = True
        self.sDefaultFileName = 'deformers/defaultWeights.wts'

        self.qDeformerFont = QtGui.QFont()
        # self.qDeformerFont.setColor(utils.uiColors.green)

        self.qTopFont = QtGui.QFont()
        self.qTopFont.setBold(True)
        self.qTopFont.setPointSize(7)
    
    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        if isinstance(xValue, list):
            xValue = {xValue[0]:xValue[1]}
        sPath, _ = xValue
        FilePathControl.build(self, qParentLayout, sName, sPath, qtWindow=qtWindow)
        self.qtTree = QtWidgets.QTreeWidget()
        self.qtTree.setHeaderHidden(True)
        if self.bSingleSelection:
            self.qtTree.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        else:
            self.qtTree.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.qtVerticalLayout.addWidget(self.qtTree)
        self.refresh()


    def refresh(self, xValue=None):
        self.qtTree.clear()
        sFile = self.qtText.text()

        try:
            loadedDict = np.load(sFile)
            sDeformers = loadedDict['deformers']


            for sD in sDeformers:
                if not self.bOnlyMaps:
                    sPostDeformers = loadedDict['%s_postDeformers' % sD]
                    sAttrNames = loadedDict['%s_attrNames' % sD]
                    sAttrValues = loadedDict['%s_attrValues' % sD]
                    dAttributes = dict(list(zip(sAttrNames, sAttrValues)))

                #sAllMaps = [sM for sM in loadedDict['maps'] if sM.startswith('%s.' % sD)]
                sAllMaps = loadedDict['%s_maps' % sD]
                qItemKey = QtWidgets.QTreeWidgetItem(self.qtTree)
                qItemKey.setExpanded(True)
                qItemKey.setText(0, '%s ("%s")' % (sD, loadedDict['%s_geo' % sD]))
                # qItemKey.setFont(0, self.qDeformerFont)
                qItemKey.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.green)))

                if self.bOnlyMaps:
                    qItemKey.setFlags(qItemKey.flags() & ~QtCore.Qt.ItemIsSelectable)
                else:
                    qItemKey.setData(0, QtCore.Qt.UserRole, sD)

                for sMap in sAllMaps:
                    qMap = QtWidgets.QTreeWidgetItem(qItemKey)
                    qMap.setText(0, '.'.join(sMap.split('.')[1:]))
                    qMap.setData(0, QtCore.Qt.UserRole, 'maps.%s' % sMap)
                    # qMap.setFont(0, self.qTopFont)

                # _deformers_
                if not self.bOnlyMaps:
                    dOrder = QtWidgets.QTreeWidgetItem(qItemKey)
                    sPostDeformersFlattened = list(set(reduce(lambda x,y :x+y ,sPostDeformers)))
                    if len(sPostDeformersFlattened):
                        sPostDeformersText = 'move before: %s' % ', '.join(sPostDeformersFlattened)
                    else:
                        sPostDeformersText = 'move to the top'
                    dOrder.setText(0, '__order__ (%s)' % sPostDeformersText)
                    dOrder.setData(0, QtCore.Qt.UserRole, 'order.%s' % sD)
                    dOrder.setFont(0, self.qTopFont)
                    # dOrder.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.blue)))

                    # _attributes_
                    qAttrs = QtWidgets.QTreeWidgetItem(qItemKey)
                    qAttrs.setText(0, '__attributes__')
                    qAttrs.setData(0, QtCore.Qt.UserRole, 'attributes.%s' % sD)
                    qAttrs.setFont(0, self.qTopFont)
                    # qAttrs.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.blue)))
                    for sAttr, fValue in list(dAttributes.items()):
                        qAttr = QtWidgets.QTreeWidgetItem(qAttrs)
                        qAttr.setText(0, '%s: %s' % (sAttr, fValue))
                        qAttr.setData(0, QtCore.Qt.UserRole, 'attributes.%s.%s' % (sD, sAttr))

                # _skinCluster_
                if loadedDict['%s_type' % sD] == 'skinCluster':
                    qWeights = QtWidgets.QTreeWidgetItem(qItemKey)
                    qWeights.setText(0, '__jointWeights__')
                    qWeights.setFont(0, self.qTopFont)
                    # qWeights.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.blue)))

                    if self.bOnlyMaps:
                        qWeights.setFlags(qWeights.flags() & ~QtCore.Qt.ItemIsSelectable)
                        qWeights.setExpanded(True)
                    else:
                        qWeights.setData(0, QtCore.Qt.UserRole, 'jointWeights.%s' % sD)

                    qBlendWeights = QtWidgets.QTreeWidgetItem(qItemKey)
                    qBlendWeights.setText(0, '__quaternionBlendWeights__')
                    qBlendWeights.setData(0, QtCore.Qt.UserRole, 'blendWeights.%s' % sD)
                    qBlendWeights.setFont(0, self.qTopFont)
                    # qBlendWeights.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.blue)))

                    sInfluences = loadedDict['%s_influences' % sD]
                    for i, sI in enumerate(sInfluences):
                        qI = QtWidgets.QTreeWidgetItem(qWeights)
                        qI.setText(0, sInfluences[i])
                        qI.setData(0, QtCore.Qt.UserRole, 'jointWeights.%s.%s' % (sD,sI))

        except Exception as e:
            utils.debugPrint('Weight Files: problem with file %s: %s' % (sFile, e))
            # sError = traceback.format_exc()
            # sError = 'RELOAD ERROR: %s' % sError
            # self.qtWindow._report.addLogText('Weight Files: problem with file %s: %s' % (sFile, e))
            # self.qtWindow._report.addLogText(sError)
            # self.qtWindow._report.setProgressBarColor(utils.uiColors.orange)
            # self.qtWindow._report.setToFull()

    
    def getValue(self):

        sSelection = []
        def _recCheck(qRoot):
            if qRoot.isSelected():
                sSelection.append(qRoot.data(0, QtCore.Qt.UserRole))
            else:
                for i in range(qRoot.childCount()):
                    _recCheck(qRoot.child(i))

        qTopRoot = self.qtTree.invisibleRootItem()
        for iDeformerIndex in range(qTopRoot.childCount()):
            qDeformer = qTopRoot.child(iDeformerIndex)
            _recCheck(qDeformer)
        return self.qtText.text(), sSelection





