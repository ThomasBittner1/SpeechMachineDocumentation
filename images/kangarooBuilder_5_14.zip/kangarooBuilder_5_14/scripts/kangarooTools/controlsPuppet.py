###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np
import json
import traceback
import copy
import os
import inspect
import time
import webbrowser

import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
from collections import OrderedDict, defaultdict
import kangarooTools.controls as controls
import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.puppetAttrItems as puppetAttrItems
import kangarooTools.report as report
import kangarooTools.clipboard as clipboard
import kangarooTools.dependencyEditor as dependencyEditor
import kangarooTools.utilsQt as utilsQt

globalLimbControl = None

_depricatedLimbs = ['LToe']

dToolTips = {}
dDocumentationLinks = {}
dToolTips['iSegmentsPriority'] = 'This is for the Plane Cutter. \nIf you this value is -1, it won\'t create planes for those joints. \nIf it\'s zero or higher, it\'ll create planes and set the priority to that value'
dToolTips['bSegmentPlanes'] = 'This is for the Plane Cutter. \nThe next time you run Create Joints will either create a joint or not create a joint depending on what you set here.'
dToolTips['bIsBpBarent'] = 'For BP Rig Generation. Depricated, so best leave it at False'
dToolTips['iFeatureCtrlType'] = 'Feature Ctrl is the control that has the switch values, and some global attributes'
dToolTips['sCustomFeatureCtrlName'] = 'If Feature Ctrl Type is set to custom ctrl, specify the name of it in here. \nIt\'s important that it exists! Because it doesn\'t create it for this'
dToolTips['sBlueprintMirrorPlane'] = 'Here you can specify at blueprint joint and a mirror plane. \nFor example "bp_l_head_main.Z" would mean the Z of bp_l_head_main is the mirror plane. ' \
                                      '\nThis is useful for example when you have a character with more than one heads, where some heads are not in the worldspace middle axis '
dToolTips['fBlueprintsCreationTranslationOffset'] = 'These are offset values for when you create the blueprints the first time (might go away in future versions)'
dToolTips['fBlueprintsCreationRotationOffset'] = 'These are offset values for when you create the blueprints the first time (might go away in future versions)'
dToolTips['bRemoveEndSkinJoint'] = 'When for example the head joint sits exactly on the last neck joint, you wouldn\'t need that neck joint. \nThis attribute can remove it'
dToolTips['fCtrlSize'] = 'This attribute will probably go away in future versions. Because in most cases the default ctrl sizes are created by the blueprint joint radien'
dToolTips['bBlueprintsCurve'] = 'For lots of situations using Spines it\'s better to deal with curves as blueprints instead of joints'
dToolTips['iColorIndex'] = '0 means main ctrl, 1 means secondary control, 2 means even more secondary'
dToolTips['iFaceExtraMove'] = 'This can make the ctrls follow the face squash stretch.\nright click -> "Go to Documentation.." for more info'
dToolTips['iBlueprintCount'] = 'The number of joints. \nIf you change that number, it\'s best to delete the blueprint joints and let the "Create missing BP Joints" button recreate them' \
                                '\nIMPORTANT: this does NOT change the actual joint count in the setup. For that you need to change the SpineJointCount'
dToolTips['iSpineJointCount'] = 'This number can be different to the Blueprint Count. Joints will be interpolated along the blueprint joints'
dToolTips['fChestPerc'] = 'If you leave this at 1, there won\'t be a chest, and the top control is called topIk. \nBut if you set it to a value smaller than 1, there\'ll be a chest ctrl'\
                            '\nIMPORTANT: The values of CtrlPercs below will be compressed by this value.'
dToolTips['fCtrlPercs'] = 'With Right Click you can resize this array, to have more ctrls'
dToolTips['fSecondaryCtrlPercs'] = 'With Right Click you can add some. They\'ll follow the main ctrls that are specified with the CtrlPercs attribute'
dToolTips['iCvsPerCtrl'] = 'The more CVs, the more it\'ll react to ctrl orientations'
dToolTips['bOffsetJoints'] = 'If you have more than one feature, then it\'s recommended to switch this on for all features. \nThis way on default pose there won\'t be any transition on blending between the features.'
dToolTips['iOrient'] = 'The ctrl orientation. If it\'s Line, they are aimed between first and last ctrl'
dToolTips['iCtrlTwist'] = 'This will interpolate the twist along the ctrls. This can be very important if your stretchmode is Spline Ik'
dToolTips['bCtrlScale'] = 'The joints will get scaled by the ctrls'
dToolTips['iStretchMode'] = 'Spline Ik: This is using the Maya Ik Spline Handle. Good for actual torsos, since it also gives you min/max stretch. '\
                            '\nThe twist for Spline Ik gets interpolated from start to end, which could get unstable if the spine is very curved'\
                            '\nFor the other options, you can switch between curveInfo nodes and motionPath nodes. MotionPath is slower but interpolates along the whole spline '\
                            '\nThe difference between soft and rigid twist is that for soft he\'s creating a curve, and for rigid he\'s just interpolating between poles of each ctrl.'\
                            '\nIt\'s best to try rigid twist first, and only switch to soft if you find it\'s unstable'
dToolTips['bAttachMiddlesToLine'] = 'This means that all ctrls except the first and the last one will move along the first and last ctrls\n'\
                                    'When you change this attribute, the attacher setup will change. This is why you might see a jump inside this attributes UI'
dToolTips['fUpAxis'] = 'If you find the twist gets unstable on bending some ctrls, try setting a different up axis, like (0,0,1). \nIt acts on the blueprint\'s orientation'
dToolTips['bPostRefJoints'] = 'This is for Puppet Tweakers. Right click and "Go to Documentation.." for more info'
dToolTips['bPostRefJoint'] = dToolTips['bPostRefJoints']
dToolTips['iPostRefJoints'] = dToolTips['bPostRefJoints']
dToolTips['bAutoTangents'] = 'This will make the tangent ctrls aim to the neighbor ctrls'
dToolTips['iPostCtrls'] = 'Creates a Hip and Arch Ctrl. Can be useful for cartoony characters. \nDon\'t foget to set the following PostHipsPerc and PostArchPerc attributes'
dToolTips['bSpring'] = 'Uses MEL expression to create a simple spring with damping and stiffness values'
dToolTips['iSpring'] = 'Uses MEL expression to create a simple spring with damping and stiffness values'
dToolTips['sSpringAttrsCtrl'] = 'The ctrl with the damping/stiffness attributes'

dToolTips['iCurveJoints'] = 'If you leave it an None, it\'ll just create a joint for each ctrl'
dToolTips['bOrientToNearestStraightMatrix'] = 'Animators often like to have controls aligned in worldspace. '
dToolTips['iOrientToNearestStraightMatrix'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['iOrientToNearestStraightMatrixBase'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['iOrientToNearestStraightMatrixMiddle'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['iOrientToNearestStraightMatrixTop'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['bWorldspaceOrient'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['bOrientWristToWorldMatrix'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['bWorldOrientIkCtrl'] = dToolTips['bOrientToNearestStraightMatrix']
dToolTips['fCtrlOrient'] = 'It\'s just the shape orientation. If you are not creating Unreal Control Rigs, this could get ignored and entirely handled with just shaping ctrls'
dToolTips['iRemoveEndCtrls'] = 'Useful for example on cable setups, where the cable is attached so something. The attachers will still be there, but the controls will be removed'
dToolTips['bDistributeRotationStartToEnd'] = 'This can be useful for very fat characters, where the vertices are so far away from the joints so that orientations get sensitive.'\
                                            '\nYou can also fine tune this by setting each "botToTopStrength" attribute on the squash joints.'
dToolTips['iDynamics'] = 'Creates hairSystem dynamics'
dToolTips['sDynamicsMasterCtrl'] = 'This is the ctrl where the dynamics attributes will be placed. \nYou can also use this to group some spine dynamics together, \nfor example the hair dynamics could be on the head_ctrl'
dToolTips['bLengthScale'] = 'Depricated, will be removed in future versions'
dToolTips['fDefaultSquash'] = 'When spine gets shorter/longer, it can get thinner/thicker. Attributes are on the feature ctrl specified above. Here you can just set the default value'
dToolTips['bIsLeg'] = 'This mainly just changes control names, for example from wrist to ankle.'
dToolTips['bIsBackLeg'] = 'This mainly just changes control names, for example from wrist to ankle.'
dToolTips['iShoesCount'] = 'If you have more than one shoe setup, he\'ll create more pivots on the Blueprints Setup.'\
                            '\nThose can then be switched on the PivotsType attribute on the Leg Ik'
dToolTips['bLockBreak'] = 'If you want to have elbow rotate only in one axis, you can turn this to On'
dToolTips['fAimAtElbowPlaneDefault'] = 'If you break-rotate the elbow into a wrong direction, he\'ll try to compensate by twisting'
# dToolTips['bLocalWrist'] = 'This adds another attribute that lets the wrist joints move locally to the elbow joints'
dToolTips['bAnkleCtrl'] = 'If this is on, it\'ll create ankle or wristRev ctrls. If it\'s off, it creates attributes ballRoll or midFinger attributes instead.'\
                            '\nThe behavior is the same, however animators are divided which one they prefer'
dToolTips['bAutoScapulaFollowIk'] = 'On Bipeds it should always follow the Elbow (keeping this attribute at off)' \
                                    '\nBut on Quadrupeds where you would also use the DogScapula instead of Clavicle, this might be better set to On'
dToolTips['bAutoClavicleFollowIk'] = 'If it\'s off, it follows the elbow'
dToolTips['bAutoClavicle'] = 'If you switch this attribute, make sure to set the root attacher again!'
dToolTips['fUpperParams'] = 'Twist joints. Right click on the values for changing the count, or interpolating the values.'
dToolTips['fLowerParams'] = dToolTips['fUpperParams']
dToolTips['iUpperPlane'] = 'The plane axis for the upper limb. If the twist orientation behaves unstable, try switching this value'\
                            '\nGenerally for biped arms this would be Y, and for legs pointing to the ground, this would be Z'
dToolTips['iLowerUpAxis'] = 'The plane axis for the lower limb. If the twist orientation behaves unstable, try switching this value'\
                            '\nGenerally for biped arms this would be Z, and for legs pointing to the ground, this would be Y'
dToolTips['bFingerCtrl'] = 'This is depricated. Because FK and IK limbs already have finger joints.'
dToolTips['bArmTwistFromPoseT'] = 'This is for the Twist Algorithm of the upper limb. Turn this on if you have a character in the A-Pose.'\
                                    '\nBut if the arms are in a very different and unusual pose like either pointing forward or back - turning on this attribute could do more damage than good'
dToolTips['iBendy'] = 'Adds bendy ctrls. The roundElbow option is depricated'
dToolTips['iIsThumb'] = 'If it\'s a thumb, he won\'t do the meta ik ctrls, and it won\'t follow the Leg IK Rev setup'
dToolTips['iDogMidFingerIk'] = 'This creates an IK setup for the MidFingerRoll attribute on the Dog Leg IK. \nOn non-dog characters this attribute can be ignored. '\
                                '\nFor dogs, turn this Off on toes that are not touching the ground' \
                                '\nIMPORTANT: Before trying to tweak those values, make sure that the armFingersElbow000000LFT_ctrl blueprint ctrls are at the right location'
dToolTips['fDogMidFingerIkStretch'] = 'If you set this to 0, the toes might get lifted from the ground if they are too short'
dToolTips['iDogMidFingerIkIndex'] = 'This is the joint where the IK is placed. This value is actually rarely changed'
dToolTips['bSpaceJointsEvenly'] = 'If the UpperParams and LowerParams are interpolated evenly, this attribute wouldn\'t have much effect'\
                                    '\nBut sometimes you might want UpperParams and LowerParams more uneven. In that case you can turn this on, to keep the joint distance even still'
dToolTips['iSquashStretchJoints'] = 'Adds extra joints to the twist joints that take care of the squash/stretch'
dToolTips['iBoneCount'] = 'Careful when changing this value! You may have to delete your blueprint joints and recreate them'
dToolTips['bMetaScale'] = 'This creates extra joints that will stretch/shrink when the meta gets longer/shorter. It can be helpful on the feet'
dToolTips['sCreateReplacerAttachers'] = 'DEPRICATED'
dToolTips['sDisplayAttr'] = 'The display attribute that will show/hide those ctrls'
dToolTips['bNoJoint'] = 'If you set that to True, this limb will not create a joint'
dToolTips['bMirrorOrient'] = 'Legacy Depricated stuff. Just leave it at True to not get into troubles'
dToolTips['bForceParentSkeletonToRoot'] = 'Depricated - This will parent the joints to the root instead of under the parent. '
dToolTips['bNoCtrl'] = 'Creates only joint and no ctrl. Useful if you want to use this limb just for attacher stuff'
dToolTips['sCtrlShape'] = 'The default shapes. You can also change it after building'
dToolTips['iSlider'] = 'Depricated - it should always stay at default'
dToolTips['iPivotCtrls'] = 'Specifies which ctrls you get at actual ctrls or which are attributes on the main iks'
dToolTips['bToeFkCtrl'] = 'Specifies if the FK should be a ctrl or an attribute'
dToolTips['fPoleVectorFurtherAwayFactor'] = 'First keep it at 1.0, but if animators tell you to move the pole vector ctrl further away from the leg, set it to a higher value.'
dToolTips['bLocalAttacher'] = 'This is experimental, it creates a local attacher under Attacher "Main (tr)"'
dToolTips['fScaleCtrlShape'] = 'The default scale of the ctrl. You can also resize it by shaping the ctrl after building'
dToolTips['sDoScale'] = 'Careful! If this limb has children, only choose between off and uniform.'
dToolTipsBeautifulNames = {utils.beautifyVariableName(sA):sStr for sA,sStr in dToolTips.items()}

dDocumentationLinks['sDisplayAttr'] = 'https://kangaroobuilder.com/puppet/puppetGeneral/#display-attributes'
dDocumentationLinks['bSpring'] = 'https://kangaroobuilder.com/puppet/dynamics/#springs'
dDocumentationLinks['iSpring'] = 'https://kangaroobuilder.com/puppet/dynamics/#springs'
dDocumentationLinks['sSpringAttrsCtrl'] = 'https://kangaroobuilder.com/puppet/dynamics/#springs'
dDocumentationLinks['iPivotCtrls'] = 'https://kangaroobuilder.com/puppet/limbsReference/#pivot-ctrls'
dDocumentationLinks['bToeFkCtrl'] = 'https://kangaroobuilder.com/puppet/limbsReference/#toe-fk-ctrl'
dDocumentationLinks['bWorldOrientIkCtrl'] = 'https://kangaroobuilder.com/puppet/limbsReference/#worldorientctrlarmlegik'
dDocumentationLinks['fDoubleKneeDefault'] = 'https://kangaroobuilder.com/puppet/limbsReference/#double-knee'
dDocumentationLinks['fUpperParams'] = 'https://kangaroobuilder.com/puppet/limbsReference/#twist'
dDocumentationLinks['fLowerParams'] = dDocumentationLinks['fUpperParams']
dDocumentationLinks['iUpperPlane'] = dDocumentationLinks['fUpperParams']
dDocumentationLinks['iLowerUpAxis'] = dDocumentationLinks['fUpperParams']
dDocumentationLinks['bArmTwistFromPoseT'] = dDocumentationLinks['fUpperParams']
dDocumentationLinks['iSquashStretchJoints'] = 'https://kangaroobuilder.com/puppet/limbsReference/#squash-stretch-joints'
dDocumentationLinks['bIsBell'] = 'https://kangaroobuilder.com/puppet/bellCollider/'
dDocumentationLinks['fBellUpVector'] = dDocumentationLinks['bIsBell']
dDocumentationLinks['sBellSettings'] = dDocumentationLinks['bIsBell']
dDocumentationLinks['bPostRefJoint'] = 'https://kangaroobuilder.com/puppet/tweakerCtrls/'
dDocumentationLinks['bPostRefJoints'] = dDocumentationLinks['bPostRefJoint']
dDocumentationLinks['iPostRefJoints'] = dDocumentationLinks['bPostRefJoint']
dDocumentationLinks['iFaceExtraMove'] = 'https://kangaroobuilder.com/face/squashStretch'
dDocumentationLinksBeautifulNames = {utils.beautifyVariableName(sA):sStr for sA,sStr in dDocumentationLinks.items()}


dLimbDocuments = {}
dLimbDocuments['LSingleTransform'] = 'https://kangaroobuilder.com/puppet/limbsReference/#singletransformsinglebone'
dLimbDocuments['LSingleBone'] = 'https://kangaroobuilder.com/puppet/limbsReference/#singletransformsinglebone'
dLimbDocuments['LSpine'] = 'https://kangaroobuilder.com/puppet/limbsReference/#spine'
dLimbDocuments['LClavicle'] = 'https://kangaroobuilder.com/puppet/limbsReference/#clavicle-dogscapula'
dLimbDocuments['LDogScapula'] = 'https://kangaroobuilder.com/puppet/limbsReference/#clavicle-dogscapula'
dLimbDocuments['LArmLeg'] = 'https://kangaroobuilder.com/puppet/limbsReference/#armleg'
dLimbDocuments['LDogArmLeg'] = 'https://kangaroobuilder.com/puppet/limbsReference/#dogarmleg'
dLimbDocuments['LHorseArmLeg'] = 'https://kangaroobuilder.com/puppet/limbsReference/#horsearmleg'
dLimbDocuments['LBirdLeg'] = 'https://kangaroobuilder.com/puppet/limbsReference/#birdleg'
dLimbDocuments['LBelt'] = 'https://kangaroobuilder.com/puppet/limbsReference/#belt'
dLimbDocuments['LEye'] = 'https://kangaroobuilder.com/face/eyes/#eye-puppet-limbs'
dLimbDocuments['LEyesLookAt'] = 'https://kangaroobuilder.com/face/eyes/#eye-puppet-limbs'
dLimbDocuments['LEyeLookAtIndiv'] = 'https://kangaroobuilder.com/face/eyes/#eye-puppet-limbs'
dLimbDocuments['LWheel'] = 'https://kangaroobuilder.com/puppet/limbsReference/#wheel'
dLimbDocuments['LFinger'] = 'https://kangaroobuilder.com/puppet/limbsReference/#finger'
dLimbDocuments['LBirdToe'] = 'https://kangaroobuilder.com/puppet/limbsReference/#finger'






class QLibraryTreeWidget(QtWidgets.QTreeWidget):
    def __init__(self, parent=None):
        QtWidgets.QTreeWidget.__init__(self, parent=parent)
        self.header().hide()
        self.setIndentation(0)
        self.itemPressed.connect(self.itemClickedFunc)

    def resizeEvent(self, event):
        iWidth = self.width() - 10
        self.setColumnWidth(0, iWidth/3)
        self.setColumnWidth(1, iWidth/3)
        self.setColumnWidth(2, iWidth/3)

    def itemClickedFunc(self, qItem, iColumn):
        xData = qItem.data(iColumn, QtCore.Qt.UserRole)
        if xData == None:
            self.setDragEnabled(False)
            # self.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        else:
            self.setDragEnabled(True)
            # self.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)


class TLibraryListControl(controls.Control):
    def __init__(self):
        controls.Control.__init__(self, bDisableOnServer=True)
        self.bRefreshButton = True
        # self.bDisableOnServer = True

    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        controls.Control.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow)
        self.qtLayout = QtWidgets.QVBoxLayout()
        self.qtLayout.setSpacing(0)
        self.uniqueLayout.addLayout(self.qtLayout)
        self.qtTree = QLibraryTreeWidget()
        self.qtTree.setColumnCount(3)

        self.qtTree.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectItems)

        self.qtLayout.addWidget(self.qtTree)
        self.qtTree.setDragEnabled(True)
        self.qtTree.itemSelectionChanged.connect(self.selectionChanged)
        self.qtTree.itemPressed.connect(self.selectionChanged)

        self.qtTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtTree.customContextMenuRequested.connect(self.markingMenuLibrary)

        self.refresh()

    def markingMenuLibrary(self, vPos):
        qMenu = QtWidgets.QMenu()
        qItem = self.qtTree.currentItem()
        iColumn = self.qtTree.currentColumn()
        if qItem:
            def documentation():
                dData = qItem.data(iColumn, QtCore.Qt.UserRole)
                sType = dData['sClassType']
                print ('sType: ', sType)
                if sType in dLimbDocuments:
                    sLink = dLimbDocuments[sType]
                    webbrowser.open(sLink)
                else:
                    cmds.confirmDialog(m='No Documentation found for "%s"' % sType)

            qDocumentationAction = qMenu.addAction('Go to Documentation..', documentation)
            utilsQt.makeActionItalic(qDocumentationAction)
            qMenu.addSeparator()

        qMenu.exec_(self.qtTree.mapToGlobal(vPos))
        return qMenu



    def serverSwitch(self, bServer):
        self.qtTree.setEnabled(not bServer)


    def selectionChanged(self):
        bSignalsBlockedBefore = self.tLimbsControl.qtTree.signalsBlocked()
        self.tLimbsControl.qtTree.blockSignals(True)
        try:
            self.tLimbsControl.qtTree.clearSelection()
            # self.tLimbsControl.activateRootDrop(True)
            self.tLimbsControl.activateItemsStartingWithDrop('attacher: ', False)
            self.tLimbsControl.activateItemsStartingWithDrop('limb(s): ', False)
        except:
            raise
        finally:
            self.tLimbsControl.qtTree.blockSignals(bSignalsBlockedBefore)


    def refresh(self):
        try:

            dAllLimbClasses = puppetDataUtils.limbsFromFiles(True)
            dLimbClasses = {sN:mL for sN,mL in list(dAllLimbClasses.items()) if not sN.startswith('_') and sN not in _depricatedLimbs}

            self.qtTree.clear()
            self.qtTree.setUniformRowHeights(True)
            self.qtTree.setColumnCount(3)
            self.qtTree.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectItems)
            self.qRoot = self.qtTree.invisibleRootItem()

            iRowCount = len(dLimbClasses) // 3
            if len(dLimbClasses) % 3 != 0:
                iRowCount += 1
            qItems = []
            for _ in range(iRowCount):
                qItems.append(QtWidgets.QTreeWidgetItem(self.qRoot))

            sKeys = sorted(dLimbClasses.keys())
            iNextRow = 0
            iNextColumn = 0
            for i, sClassType in enumerate(sKeys):
                iRow = iNextRow
                iColumn = iNextColumn

                qItem = qItems[iRow]
                qItem.setText(iColumn, utils.replaceStringStart(sClassType, 'L', ''))
                qItem.setData(iColumn, QtCore.Qt.UserRole, {'sType':'class', 'sClassType':sClassType})

                iNextRow  += 1
                if iNextRow >= iRowCount:
                    iNextRow = 0
                    iNextColumn += 1

            firstIndex = self.qtTree.indexFromItem(qItems[0])
            iHeight = self.qtTree.rowHeight(firstIndex)
            self.qtTree.setMinimumHeight(iHeight*(iRowCount) + 15)
            self.qtTree.setMaximumHeight(iHeight*(iRowCount) + 15)

            report.report.setProgressBarColor(utils.uiColors.green)
            report.report.setToFull()
            # report.report.addLogText('\n\n successfully reloaded limbs')

        except Exception as e:
            sError = traceback.format_exc()
            sError = 'RELOAD ERROR (0): %s' % sError
            report.report.addLogText(sError, sColor=utils.uiColors.orange, bQuotationsToLink=True)
            report.report.setProgressBarColor(utils.uiColors.orange)
            report.report.setToFull()


    def setEnabled(self, bOn, bFromOtherControl=False):
        pass

    def getValue(self):
        return None




qInstanceFont = QtGui.QFont()
qInstanceFont.setBold(True)
qInstanceFont.setPointSize(10)
qTypeFont = QtGui.QFont()
qTypeFont.setPointSize(8)
qItalic = QtGui.QFont()
qItalic.setItalic(True)
qBold = QtGui.QFont()
qBold.setBold(True)
qFuncFont = QtGui.QFont()
qFuncFont.setPointSize(10)


# class DuplicateUI(QtWidgets.QDialog):
#     def __init__(self, tControl, qInLimb, qtParentWindow):
#         super(DuplicateUI, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
#         layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
#
#         countLayout = QtWidgets.QHBoxLayout()
#         countLayout.addWidget(QtWidgets.QLabel('count'))
#         self.qCount = QtWidgets.QLineEdit('1')
#         countLayout.addWidget(self.qCount)
#         layout.addLayout(countLayout)
#
#         offsetLayout = QtWidgets.QHBoxLayout()
#         offsetLayout.addWidget(QtWidgets.QLabel('offset'))
#         self.qOffsets = [QtWidgets.QLineEdit('0'), QtWidgets.QLineEdit('0'), QtWidgets.QLineEdit('0')]
#         for qO in self.qOffsets:
#             offsetLayout.addWidget(qO)
#         layout.addLayout(offsetLayout)
#         self.setWindowTitle('Duplicate Limb "%s"' % qInLimb.text(0))
#         self.setWindowModality(QtCore.Qt.ApplicationModal)
#         qButton = QtWidgets.QPushButton('Duplicate')
#         qButton.clicked.connect(self.duplicateClicked)
#         layout.addWidget(qButton)
#
#         self.qInLimb = qInLimb
#         self.tControl = tControl
#
#     def duplicateClicked(self):
#
#         fOffset = [float(qL.text()) for qL in self.qOffsets]
#         iCount = int(self.qCount.text())
#         self.close()
#
#         self.tControl.cloneLimb(self.qInLimb, fOffset=fOffset, iCount=iCount)



class QAttrTreeWidget(QtWidgets.QTreeWidget):
    def __init__(self, parent, tControl, dropEventFunc):
        QtWidgets.QTreeWidget.__init__(self, parent=parent)
        self.dropEventFunc = dropEventFunc
        self.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.setIndentation(15)
        self.setColumnCount(2)
        self.setColumnWidth(0, 200)
        self.setHeaderLabels(['',''])
        self.tControl = tControl


    def dropEvent(self, event):
        self.dropEventFunc(event)


    def keyPressEvent(self, event):
        super().keyPressEvent(event)
        if event.key() == QtCore.Qt.Key_C and (event.modifiers() & QtCore.Qt.ControlModifier):
            qCurrent = self.currentItem()
            ddItem = qCurrent.data(0, QtCore.Qt.UserRole)
            if ddItem['sType'] == 'attacher':
                qAttacher = qCurrent
                # sLocals = [tO.getOutputName() for tO in qAttacher.qLocalOutputs] # if we ever want to incluce local attachers
                sNames = [qO.getOutputName() for qO in qAttacher.qOutputs]
                clipboard.put('attacher.%s' % str(sNames))

    
        elif event.key() == QtCore.Qt.Key_V and (event.modifiers() & QtCore.Qt.ControlModifier):
            qCurrent = self.currentItem()
            ddItem = qCurrent.data(0, QtCore.Qt.UserRole)
            sPaste = clipboard.get()
            if sPaste.startswith('attacher.'):
                if ddItem['sType'] == 'attacher':
                    print ('sPaste: ', sPaste)
                    sOutputs = eval(sPaste[sPaste.find('.')+1:])
                    sToAttacher = ddItem['sName']
                    self.tControl.copyFromAttacher(sToAttacher, sOutputs)
                
    


class TLimbAttrs(controls.Control):
    def __init__(self, tCharLimbsControl=None):
        controls.Control.__init__(self, bDisableOnServer=True)
        # self.bRefreshButton = True
        self.tCharLimbs = tCharLimbsControl
        tCharLimbsControl.tAttrControl = self
        self.xSnapShots = []

        self.dShow = OrderedDict()
        self.dShow['Parent'] = True
        self.dShow['Attributes'] = True
        self.dShow['Attachers'] = True
        self.dShow['Features'] = True
        self.dShow['Parent'] = True


    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        controls.Control.build(self, qParentLayout, sName, xValue, qtWindow=qtWindow)
        self.qtLayout = QtWidgets.QVBoxLayout()
        self.qtLayout.setSpacing(0)
        self.uniqueLayout.addLayout(self.qtLayout)
        self.qShowButton = QtWidgets.QPushButton('show/hide')
        self.qShowButton.clicked.connect(self.showHideMarkingMenu)
        self.qRefreshButton = QtWidgets.QPushButton('reload')
        self.qRefreshButton.clicked.connect(self.refresh)

        self.qtTree = QAttrTreeWidget(qtWindow, self, self.attrDropEvent)

        qTopButtons = QtWidgets.QHBoxLayout()
        self.qtLayout.addLayout(qTopButtons)
        qTopButtons.addWidget(self.qRefreshButton)
        qTopButtons.addWidget(self.qShowButton)
        self.qtLayout.addWidget(self.qtTree)

        self.qtTree.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.qtTree.itemDoubleClicked.connect(self.doubleClick)
        self.qtTree.itemChanged.connect(self.attrItemChanged)
        self.qtTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtTree.customContextMenuRequested.connect(self.attrMarkingMenu)

        self.qRoot = self.qtTree.invisibleRootItem()
        self.qRoot.setFlags(self.qRoot.flags() & ~QtCore.Qt.ItemIsDropEnabled)


        self.qtWindow=qtWindow
        self.sCurrentLimbs = []
        self.refresh()

        self.qtTree.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)


    def showHideMarkingMenu(self):
        qMenu = QtWidgets.QMenu()

        def _show():
            for sKey, _ in list(self.dShow.items()):
                self.dShow[sKey] = True
            self.showLimbs()
        def _hide():
            for sKey, _ in list(self.dShow.items()):
                self.dShow[sKey] = False
            self.showLimbs()

        qShowAll = qMenu.addAction('Show all', _show)
        qHideAll = qMenu.addAction('Hide all', _hide)
        bAllOn = True
        bAllOff = True
        for sKey, bValue in list(self.dShow.items()):
            if not bValue:
                bAllOn = False
            else:
                bAllOff = False
        if bAllOn: qShowAll.setEnabled(False)
        if bAllOff: qHideAll.setEnabled(False)


        for sKey, bValue in list(self.dShow.items()):

            def _update(bState, _sKey=sKey, _qShowAll=qShowAll):
                self.dShow[_sKey] = bState
                bAllOn = True
                for sKey, bValue in list(self.dShow.items()):
                    if not bValue:
                        bAllOn = False
                        break
                _qShowAll.setEnabled(not bAllOn)
                self.showLimbs()

            qShow = QtWidgets.QWidgetAction(qMenu)
            qCheckBox = QtWidgets.QCheckBox(sKey)
            qCheckBox.setChecked(bValue)

            qCheckBox.stateChanged.connect(_update)
            qShow.setDefaultWidget(qCheckBox)
            qMenu.addAction(qShow)


        qMenu.exec_(QtGui.QCursor().pos())



    def getCurrentLimbObjects(self, sLimbs=None):
        return self.getLimbObjects(self.sCurrentLimbs if sLimbs == None else sLimbs)


    def getLimbObjects(self, sLimbs):
        return [self.tCharLimbs.getLimbItemWithName(sL) for sL in sLimbs]


    def serverSwitch(self, bServer):
        # self.qtLayout.setEnabled(not bServer)
        self.qtTree.setEnabled(not bServer)


    def attrDropEvent(self, event):
        qOutput = self.qtTree.itemAt(event.pos())
        qDragged = self.tCharLimbs.qtTree.selectedItems()[0]
        qOutput.setIndexFromLimbName(qDragged.text(0))



    def setOutputCount(self, qAttacher, iNewCount, bIsCommonCount, qLimbsWithValidOutputs, bUserChanged=True):
        '''
        only to be called if qAttacher.bMulti == True ????
        '''

        if iNewCount < 0:
            iNewCount = 0

        if qAttacher.bMulti == False and iNewCount > 1:
            iNewCount = 1
            report.report.addLogText('ATTACHER CHANGE: "%s": setting to 1, because it\'s not a multi attacher.' % (qAttacher.text(0)))

        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)
        try:
            if qAttacher.bMulti:
                if bIsCommonCount:
                    qAttacher.tBlendInfo.setCount(iNewCount)

            bTurnLocalAttachersOff = False
            bTurnLocalAttachersOn = False
            if bUserChanged:
                if len(qAttacher.qOutputs) == 0 and iNewCount > 0:
                    bTurnLocalAttachersOff = True
                elif len(qAttacher.qOutputs) > 0 and iNewCount == 0:
                    bTurnLocalAttachersOn = True


            iAdd = iNewCount - len(qAttacher.qOutputs)
            if iAdd == 0:
                return

            elif iAdd > 0:
                for i in range(iAdd):
                    iIndex = len(qAttacher.qOutputs) + i # len(qAttacher.sLocalOutputs)
                    qOutput = puppetAttrItems.QAttacherOutputItem(self.qtTree, qAttacher, self, self.tCharLimbs, qLimbsWithValidOutputs, iIndex=iIndex, bParentIsMulti=qAttacher.bMulti)
                    qAttacher.qOutputs.append(qOutput)

            elif iAdd < 0:
                iOutputCount = len(qAttacher.qOutputs)
                for i in range(iOutputCount-1, iNewCount-1, -1):
                    qAttacher.removeChild(qAttacher.child(len(qAttacher.qLocalOutputs) + i))
                qAttacher.qOutputs = qAttacher.qOutputs[:iNewCount]

            if not bUserChanged:
                qAttacher.setExpanded(True if iNewCount > 0 else False)

            self._setAttrEnabled(qAttacher)

            if bTurnLocalAttachersOff:
                for qO in qAttacher.qLocalOutputs:
                    qO.qDefaultWeight.setText('0')
                qAttacher.qOutputs[0].qDefaultWeight.setText('1')
            elif bTurnLocalAttachersOn:
                if len(qAttacher.qLocalOutputs):
                    qAttacher.qLocalOutputs[0].qDefaultWeight.setText('1')
                    for qO in qAttacher.qLocalOutputs[1:]:
                        qO.qDefaultWeight.setText('0')


        except:
            raise
        finally:
            self.qtTree.blockSignals(bSignalsBlockedBefore)


    def saveAttacherOutputs(self, qAttacher, bMaintainCount=False):
        print ('saveattacheroutputs')
        sLocalOutputNames, sOutputNames = self.getOutputNames(qAttacher)
        try:
            for sCurrentLimb in self.sCurrentLimbs:
                qCurrentLimb = self.tCharLimbs.getLimbItemWithName(sCurrentLimb)
                ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
                ddAttacherData = qAttacher.data(0, QtCore.Qt.UserRole)
                sAttacher = ddAttacherData['sName']

                dLocalSavedOutputs = ddLimbData.get('%s.dLocalOutputsFILE' % sAttacher, {})

                for o, sOutputName in enumerate(sLocalOutputNames):
                    _, sOutput, sAttrName, fWeight = utils.extractOutputInfo(sOutputName)

                    sLocalSavedOutput = dLocalSavedOutputs.get(sOutput, sOutputName)

                    _, sO, sA, fW = utils.extractOutputInfo(sLocalSavedOutput)

                    if sAttrName: sA = sAttrName
                    if fWeight != -1: fW = fWeight
                    sJoinedName = '%s@%0.3f' % (sA, fW)
                    dLocalSavedOutputs[sOutput] = sJoinedName


                ddLimbData['%s.dLocalOutputsFILE' % sAttacher] = dLocalSavedOutputs


                sCurrentSavedOutputs = ddLimbData['%s.sOutputsFILE' % sAttacher]
                for o, sNewOutputName in enumerate(sOutputNames):
                    sLimb, sOutput, sAttrName, fWeight = utils.extractOutputInfo(sNewOutputName)

                    if o < len(sCurrentSavedOutputs):
                        sL, sO, sA, fW = utils.extractOutputInfo(sCurrentSavedOutputs[o])
                    else:
                        sL, sO, sA, fW = '', '', '', -1
                    if sLimb: sL = sLimb
                    if sOutput: sO = sOutput
                    if sAttrName: sA = sAttrName
                    if fWeight != -1: fW = fWeight

                    sJoinedName = utils.combineOutputInfo(sL,sO,sA,fW)
                    if o < len(sCurrentSavedOutputs):
                        sCurrentSavedOutputs[o] = sJoinedName
                    else:
                        sCurrentSavedOutputs.append(sJoinedName)

                if bMaintainCount:
                    sCurrentSavedOutputs = sCurrentSavedOutputs[:len(sOutputNames)]


                ddLimbData['%s.sOutputsFILE' % ddAttacherData['sName']] = sCurrentSavedOutputs

                bSignalsBlocked = self.tCharLimbs.qtTree.blockSignals(True)
                try:
                    qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
                except:
                    raise
                finally:
                    self.tCharLimbs.qtTree.blockSignals(bSignalsBlocked)
            self.dApplyButtons['Save'].setText('Save *')

        except Exception as e:
            # cmds.confirmDialog(m='(0) %s' % str(e)) # this crashes unfortunately
            raise

    def qAttacherCountChanged(self, qAttacher, iCount):
        qLimbs = self.getCurrentLimbObjects()
        qqLimbsWithValidOutputs = [self.tCharLimbs.getAllLimbsWithValidOutputs(qL) for qL in qLimbs]
        qLimbsWithValidOutputs = utils.intersectionLists(qqLimbsWithValidOutputs)
        qLimbsWithValidOutputs.sort(key=lambda x: x.text(0))

        self.setOutputCount(qAttacher, iCount, True, qLimbsWithValidOutputs)
        self.saveAttacherOutputs(qAttacher, bMaintainCount=True)

        self.dApplyButtons['Save'].setText('Save *')

    def saveAttacherDoBlend(self, qAttacher, bDoBlend):
        for sCurrentLimb in self.sCurrentLimbs:
            qCurrentLimb = self.tCharLimbs.getLimbItemWithName(sCurrentLimb)
            ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
            ddAttacherData = qAttacher.data(0, QtCore.Qt.UserRole)
            ddLimbData['%s.bDoBlendFILE' % ddAttacherData['sName']] = bDoBlend

            self.dApplyButtons['Save'].setText('Save *')

            bSignalsBlocked = self.tCharLimbs.qtTree.blockSignals(True)
            try:
                qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
            except:
                raise
            finally:
                self.tCharLimbs.qtTree.blockSignals(bSignalsBlocked)



    def attrItemChanged(self, qItem, iColumn):
        ddData = qItem.data(0, QtCore.Qt.UserRole)
        sType = ddData['sType']

        for qCurrentLimb in self.getCurrentLimbObjects():
            ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
            bSignalsBlockedBefore = self.qtTree.signalsBlocked()
            bLimbsSignalsBlockedBefore = self.tCharLimbs.qtTree.signalsBlocked()
            self.qtTree.blockSignals(True)
            self.tCharLimbs.qtTree.blockSignals(True)
            try:
                if ddLimbData:
                    if iColumn == 1:
                        if sType == 'attacher':
                            iCount = int(qItem.text(1))
                            qLimbsWithValidOutputs = self.tCharLimbs.getAllLimbsWithValidOutputs(qCurrentLimb)
                            bMulti = ddData['bMulti']
                            self.setOutputCount(qItem, iCount, qLimbsWithValidOutputs)
                            ddLimbData['%s.sOutputsFILE' % ddData['sName']] = self.getOutputNames(qItem)
                            self._setAttrEnabled(qItem)
                            qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)


                    elif iColumn == 0:
                        if sType in ['feature', 'detail']:
                            sFunctionName = ddData['sFunctionName']
                            bChecked = True if qItem.checkState(0) == QtCore.Qt.Checked else False
                            ddLimbData['%s.bCheckedFILE' % sFunctionName] = bChecked
                            self.funcItemEnabled(qItem, bChecked)
                            qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
                            if bChecked == False and sType == 'detail': # some outputs got less
                                tCurrentLimb = puppetDataUtils.instantiateLimb(ddLimbData)
                                sNewOutputs = puppetDataUtils.getAllOutputs(ddLimbData)
                                sDefaultOutput = tCurrentLimb.getDefaultParentOutput()

                                qAllLimbs = self.tCharLimbs.getAllLimbs()
                                for qL in qAllLimbs:
                                    ddChange = qL.data(0, QtCore.Qt.UserRole)
                                    sAllAttachers = puppetDataUtils.getAllAttachers(ddChange, bAddSplittedAttachers=True)
                                    for sA in sAllAttachers:
                                        sOutputs = ddChange['%s.sOutputsFILE' % sA]
                                        if not sOutputs: continue
                                        for o, sOutput in enumerate(sOutputs):
                                            sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                                            if sL in self.sCurrentLimbs and sO not in sNewOutputs:
                                                sOutputs[o] = '%s@%s' % (sL, sDefaultOutput)
                                    qL.setData(0, QtCore.Qt.UserRole, ddChange)

                            qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
                            if sType == 'feature':
                                self.updateFeatureSwitchFromCurrentLimbs()
                                self.qFeatureSwitch.gotChanged()

            except:
                raise
            finally:
                self.qtTree.blockSignals(bSignalsBlockedBefore)
                self.tCharLimbs.qtTree.blockSignals(bLimbsSignalsBlockedBefore)


    def getOutputNames(self, qAttacher):
        sLocals = [tO.getOutputName() for tO in qAttacher.qLocalOutputs]
        sNames = []
        for qOutput in qAttacher.qOutputs:
            sNames.append(qOutput.getOutputName())
        return sLocals, sNames



    def removeOutputFromAttacher(self, qLimb, qOutput):
        qAttacher = qOutput.parent()
        iOutput = qAttacher.indexOfChild(qOutput)

        ddAttacher = qAttacher.data(0, QtCore.Qt.UserRole)
        sOutputsKey = '%s.sOutputsFILE' % ddAttacher['sName']

        ddData = qLimb.data(0, QtCore.Qt.UserRole)
        sOutputs = ddData[sOutputsKey]
        del sOutputs[iOutput]
        qLimb.setData(0, QtCore.Qt.UserRole, ddData)
        self.refresh()


    def copyFromAttacher(self, sToAttacher, sOutputs):
        sToLimbs = self.sCurrentLimbs
        try:
            self.tCharLimbs.qtTree.blockSignals(True)
            qToLimbs = self.getLimbObjects(sToLimbs)
            for qToLimb in qToLimbs:
                ddToData = qToLimb.data(0, QtCore.Qt.UserRole)

                sValidLimbs = list(self.tCharLimbs.getAllLimbsWithValidOutputs(qToLimb, bReturnDict=True).keys()) + [utils.kNoneString, utils.kCustomString]
                sValidOutputs = [sL for sL in sOutputs if utils.tempOutputSplit(sL)[0] in sValidLimbs]

                # strip if multi
                dPredefinedData = ddToData['%s.dPredefinedData' % sToAttacher.split('(')[0]]
                if dPredefinedData.get('bMulti', False) == False:
                    sValidOutputs = sValidOutputs[:1]

                ddToData['%s.sOutputsFILE' % sToAttacher] = sValidOutputs
                qToLimb.setData(0, QtCore.Qt.UserRole, ddToData)
            self.refresh()
        except:
            raise
        finally:
            self.tCharLimbs.qtTree.blockSignals(False)



    def attrMarkingMenu(self, vPos):
        qMenu = QtWidgets.QMenu()

        qCurrent = self.qtTree.currentItem()

        # self.addCopyAttacherMarkingMenu(qMenu, qCurrent)

        ddItem = qCurrent.data(0, QtCore.Qt.UserRole)
        if ddItem['sType'] == 'attacher':
            if qCurrent.bParent:
                if qCurrent.qChild.isHidden():
                    qMenu.addAction('Split to Translate (t) and Rotate (r)', lambda: self.splitOrCombineTrAttacher(qCurrent, False))
                else:
                    qMenu.addAction('Combine Translate and Rotate (tr))', lambda: self.splitOrCombineTrAttacher(qCurrent, True))
            elif qCurrent.bChild:
                qMenu.addAction('Combine Translate and Rotate (tr)', lambda: self.splitOrCombineTrAttacher(qCurrent.qParent, True))

            def openAttacherDocumentationLink():
                webbrowser.open('https://kangaroobuilder.com/puppet/puppetGeneral/#attachers')
            qAttacherDocumentationAction = qMenu.addAction('Go to Attacher Documentation..', openAttacherDocumentationLink)
            utilsQt.makeActionItalic(qAttacherDocumentationAction)

        else:
            sBeautifulName = qCurrent.text(0)
            sInfo = dToolTipsBeautifulNames.get(sBeautifulName, None)
            if sInfo:
                def showInfo(sInfo=sInfo):
                    cmds.confirmDialog(m=sInfo, t='%s (from ToolTip)' % sBeautifulName)
                qMenu.addAction('Info..', showInfo)
            else:
                qInfoAction = qMenu.addAction('Info..', None)
                qInfoAction.setEnabled(False)

            sDocumentationLink = dDocumentationLinksBeautifulNames.get(sBeautifulName, None)
            if sDocumentationLink:
                def openDocumentationLink(sDocumentationLink=sDocumentationLink):
                    webbrowser.open(sDocumentationLink)
                qDocumentationAction = qMenu.addAction('Go to Documentation..', openDocumentationLink)
                utilsQt.makeActionItalic(qDocumentationAction)
                qDocumentationAction.setEnabled(True)


        qMenu.exec_(self.qtTree.mapToGlobal(vPos))
        return qMenu

        # print 'marking menu...'


    def splitOrCombineTrAttacher(self, qParentAttacher, bCombine=False, bSave=True):
        sText = qParentAttacher.text(0).split(' ')
        if not bCombine:
            sText[-1] = '(t)'
            qParentAttacher.qChild.setHidden(False)
        else:
            sText[-1] = '(tr)'
            qParentAttacher.qChild.setHidden(True)
        qParentAttacher.setText(0, ' '.join(sText))
        if bSave:
            for sCurrentLimb in self.sCurrentLimbs:
                qCurrentLimb = self.tCharLimbs.getLimbItemWithName(sCurrentLimb)
                ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
                ddAttacherData = qParentAttacher.data(0, QtCore.Qt.UserRole)
                sAttacher = ddAttacherData['sName']
                ddLimbData['%s.bSplitFILE' % sAttacher] = not bCombine

                bSignalsBlocked = self.tCharLimbs.qtTree.blockSignals(True)
                try:
                    qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
                except:
                    raise
                finally:
                    self.tCharLimbs.qtTree.blockSignals(bSignalsBlocked)

            self.tCharLimbs.dirtySaveButton()

    def doubleClick(self, item, column):
        ddData = item.data(0, QtCore.Qt.UserRole)
        if not ddData:
            return
        sType = ddData['sType']
        if column == 1:
            if sType == 'attr' or sType == 'attacher':
                self.qtTree.editItem(item, column)

    def clear(self):
        try:
            self.qtTree.clear()
        except:
            pass


    def refresh(self):
        if self.sCurrentLimbs:
            qCurrentLimbs = self.getCurrentLimbObjects()
            iScrollPos = self.qtTree.verticalScrollBar().value()
            self.showLimbs(qCurrentLimbs)
            self.qtTree.verticalScrollBar().setSliderPosition(iScrollPos)
        else:
            self.clear()


    def updateFeatureSwitchFromCurrentLimbs(self):
        qCurrentLimbs = self.getCurrentLimbObjects()
        ddLimbDatas = [qL.data(0, QtCore.Qt.UserRole) for qL in qCurrentLimbs]

        sPreviousFeature = self.qFeatureSwitch.getCurrentFeature()
        sIntersectedFeatures = []
        for sFeature in ddLimbDatas[0]['sFeatures']:
            bCheckeds = [ddL['%s.bCheckedFILE' % sFeature] for ddL in ddLimbDatas]
            if len(set(bCheckeds)) == 1 and bCheckeds[0] == True:
                sIntersectedFeatures.append(sFeature)

        self.qFeatureSwitch.updateFeatures(sIntersectedFeatures)

        if sPreviousFeature:
            if sPreviousFeature in sIntersectedFeatures:
                self.qFeatureSwitch.setToFeature(sPreviousFeature)
            else:
                self.qFeatureSwitch.gotChanged()



    def showLimbs(self, qLimbs=None):

        if utils.isNone(qLimbs):
            qLimbs = self.getCurrentLimbObjects()
            self.qtTree.clear()
        else:
            # changed recently: qtTree.clear is called before updating self.sCurrentLimbs, because some signals
            # are still being called from the QAttacherBlendItem item (maybe more?)
            # and unfortunately blocking the signals from self.qtTree didn't solve that
            self.qtTree.clear()
            self.sCurrentLimbs = [qL.text(0) for qL in qLimbs]

        self.qtTree.setHeaderLabels(['',''])
        if not qLimbs:
            return

        iSplitterSizes = self.settings.qSplitter.sizes()
        if iSplitterSizes[1] == 0:
            return


        qqLimbsWithValidOutputs = [self.tCharLimbs.getAllLimbsWithValidOutputs(qL) for qL in qLimbs]
        qLimbsWithValidOutputs = utils.intersectionLists(qqLimbsWithValidOutputs)
        qLimbsWithValidOutputs.sort(key=lambda x: x.text(0))


        def _addOneAttacher(sAttacher, qRoot):
            qAttachers = self._addAttacher(qRoot, sAttacher,
                                          ddLimbDatas[0]['%s.dPredefinedData' % sAttacher])

            sLimbNames = []
            for qL in qLimbs:
                dD = qL.data(0, QtCore.Qt.UserRole)
                sLimbNames.append('%s_%s' % (dD['dArgsFILE']['sSide'], dD['dArgsFILE']['sName']))

            # self.qtTree.sSelectedLimbNames = sLimbNames
            dDefaultOutputs = {sLocal:'%s@%0.3f' % (sLocal, 1.0 if o == 0 else 0.0) for o,sLocal in enumerate(qAttachers[0].sLocalOutputs)}
            ddSavedLocals = [ddL.get('%s.dLocalOutputsFILE' % sAttacher, dDefaultOutputs) for ddL in ddLimbDatas]
            for t,qAttacher in enumerate(qAttachers): # 2 when there's tr, otherwise 1
                sAttacherName = sAttacher if t == 0 else '%s(%d)' % (sAttacher,t)
                ssOutputs = [ddL['%s.sOutputsFILE' % sAttacherName] for ddL in ddLimbDatas]
                iOutputCounts = [len(sOutputs) for sOutputs in ssOutputs]

                if qAttacher.bMulti:
                    for o, sLocal in enumerate(qAttacher.sLocalOutputs):

                        qOutput = puppetAttrItems.QAttacherOutputItem(self.qtTree, qAttacher, self, self.tCharLimbs, iIndex=o, sFixedLocal=sLocal, bParentIsMulti=True)
                        qAttacher.qLocalOutputs.append(qOutput)

                        sDefaultLocal = '%s@%0.3f' % (sLocal, 1.0 if o == 0 else 0.0)
                        sRowOutputs = [utils.tempOutputSplit(ddSavedLocals[m].get(sLocal, sDefaultLocal)) for m in range(len(ddSavedLocals))]
                        sRowOutputsTranspose = list(map(list, list(zip(*sRowOutputs))))
                        bRowOutputDupls = [False if len(set(sR)) == 1 else True for sR in sRowOutputsTranspose]
                        sO = '@'.join(['' if bRowOutputDupls[x] else sRowOutputsTranspose[x][0] for x in range(len(sRowOutputsTranspose))])
                        qO = qAttacher.qLocalOutputs[o]
                        qO.setOutputByName(sO, iIndex=o)

                    bAllSameCount = True if len(set(iOutputCounts)) == 1 else False
                    # where does that come from
                    self.setOutputCount(qAttacher, min(iOutputCounts), bAllSameCount, qLimbsWithValidOutputs, bUserChanged=False)
                    bDoBlends = [ddL.get('%s.bDoBlendFILE' % sAttacherName, False) for ddL in ddLimbDatas]
                    if len(set(bDoBlends)) == 1:
                        qAttacher.tBlendInfo.setBlend(bDoBlends[0])
                else:
                    self.setOutputCount(qAttacher, 1, True, qLimbsWithValidOutputs, bUserChanged=False)

                for o in range(min(iOutputCounts)):
                    sRowOutputs = [utils.tempOutputSplit(ssOutputs[m][o]) for m in range(len(ssOutputs))]
                    sRowOutputsTranspose = list(map(list, list(zip(*sRowOutputs))))
                    bRowOutputDupls = [False if len(set(sR)) == 1 else True for sR in sRowOutputsTranspose]

                    sO = '@'.join(['' if bRowOutputDupls[x] else sRowOutputsTranspose[x][0] for x in
                                   range(len(sRowOutputsTranspose))])
                    qO = qAttacher.qOutputs[o]
                    qO.setOutputByName(sO, iIndex=o)

            sKey = '%s.bSplitFILE' % sAttacher
            if ddL.get('%s.bSplitFILE' % sAttacher, False):
                self.splitOrCombineTrAttacher(qAttachers[0], bCombine=False, bSave=False) # by default it is collapsed

        if not isinstance(qLimbs, list):
            raise Exception('qLimbs needs to be list')
        # qLimb = qLimbs[0]
        utils.debugPrint('\n\n\n\n\n ============================= showlimb...')

        self.qtTree.blockSignals(True)
        try:

            qChildren = self.qtTree.findChildren(QtWidgets.QLineEdit)
            for qChild in qChildren:
                qChild.blockSignals(True)

            ddLimbDatas = [qL.data(0, QtCore.Qt.UserRole) for qL in qLimbs]

            sClassTypeNames = ['<%s>' % ddL['sClassTypeFILE'] for ddL in ddLimbDatas]
            self.qtTree.setHeaderLabels([', '.join(self.sCurrentLimbs), ', '.join(sClassTypeNames)])
            bAllSameTypes = True if len(set(sClassTypeNames)) == 1 else False

            if self.dShow['Parent']:

                qParents = [qL.parent() for qL in qLimbs]
                iParentsCount = len(set(qParents))
                qParent = qParents[0]

                if iParentsCount == 1:
                    if not qParent:
                        sParents = []
                    else:
                        sParents = puppetDataUtils.getAllOutputs(qParent.data(0, QtCore.Qt.UserRole))

                    sParentOutputs = [ddL.get('parentOutputFILE', None) for ddL in ddLimbDatas]

                    iDifferentParentOutputsCount = len(set(sParentOutputs))
                    lParentOutputItem = puppetAttrItems.QParentItem(self.qtTree, self, self.tCharLimbs)
                    if iDifferentParentOutputsCount > 1:
                        lParentOutputItem.setOutputs([''] + sParents, sParent=qParent.text(0) if qParent else None)
                    else:
                        lParentOutputItem.setOutputs(sParents, sParent=qParent.text(0) if qParent else None)

                    if iDifferentParentOutputsCount == 1:
                        if sParentOutputs[0] in lParentOutputItem.sOutputs:
                            lParentOutputItem.switchToOutput(sParentOutputs[0])
                        else:
                            if not utils.isNone(sParentOutputs[0]):
                                report.report.addLogText('output %s not in list' % sParentOutputs[0])
                    else:
                        lParentOutputItem.switchToOutput('')

            if self.dShow['Attributes']:
                if bAllSameTypes:
                    self.qFeatureSwitch = puppetAttrItems.QStartFeatureSwitchItem(self.qtTree, self, self.tCharLimbs)
                    self.updateFeatureSwitchFromCurrentLimbs()

                    sCurrentFeatures = []
                    for ddL in ddLimbDatas:
                        sCurrentFeature = ddL.get('sStartFeatureFILE', None)
                        if sCurrentFeature == None:
                            for sFeature in ddL['sFeatures']:
                                bChecked = ddL['%s.bCheckedFILE' % sFeature]
                                if bChecked:
                                    sCurrentFeature = sFeature
                                    break
                        sCurrentFeatures.append(sCurrentFeature)
                    if len(set(sCurrentFeatures)) == 1:
                        self.qFeatureSwitch.setToFeature(sCurrentFeatures[0])

                    bSameCurrentFeatures = True if len(set(sCurrentFeatures)) == 1 else False
                    if bSameCurrentFeatures:
                        self.qFeatureSwitch.setToFeature(sCurrentFeatures[0])
                    else:
                        self.qFeatureSwitch.setToFeature('')

                sBaseInitArgs = puppetDataUtils.getBaseInitArgs()

                ddInitArgs = [ddL['dArgsFILE'] for ddL in ddLimbDatas]
                ddInitArgDefaults = [ddL['dArgDefaults'] for ddL in ddLimbDatas]
                ssInitArgsKeys = [ddL['sArgsShow'] for ddL in ddLimbDatas]

                sInitArgsKeys = list(utils.intersectionSets([set(x) for x in ssInitArgsKeys]))

                aBaseInitIndices = utils.findOneArrayInAnother(sInitArgsKeys, sBaseInitArgs, bSkipMissing=True)
                iBaseArgCount = aBaseInitIndices.size
                aLimbInitIndices = np.setdiff1d(np.arange(len(sInitArgsKeys)), aBaseInitIndices)

                sSortedInitArgsKeys = [sInitArgsKeys[i] for i in np.concatenate([aBaseInitIndices, aLimbInitIndices])]


                for a, sArg in enumerate(sSortedInitArgsKeys):
                    values = [ddI[sArg] for ddI in ddInitArgs]
                    dTupleDefaults = tuple(ddInitArgDefaults[0][sArg]) if sArg in ddLimbDatas[0]['sTuples'] else ddInitArgDefaults[0][sArg]

                    self._addFuncAttr(None, sArg, values, dTupleDefaults,
                                      sComboboxItems=ddLimbDatas[0]['dComboboxItems'].get(sArg, []),
                                      iInterpolateBehavior=ddLimbDatas[0]['dInterpolateBehavior'].get(sArg,0),
                                      bIsBase=a < iBaseArgCount)


            if bAllSameTypes:

                if self.dShow['Attachers']:

                    ssAttachers = [ddL['sAttachers'] for ddL in ddLimbDatas]
                    sAttachers = sorted(utils.intersectionLists(ssAttachers))

                    for a, sAttacher in enumerate(sAttachers):
                        _addOneAttacher(sAttacher, self.qtTree.invisibleRootItem())

                if self.dShow['Features']:
                    for sFeature in ddLimbDatas[0]['sFeatures']:
                        bCheckeds = [ddL['%s.bCheckedFILE' % sFeature] for ddL in ddLimbDatas]

                        bCheckedDifferent = True if len(set(bCheckeds)) > 1 else False
                        bChecked = None if bCheckedDifferent else bCheckeds[0]
                        qFeat = self._addOnOffFunction(sFeature, 'feature',
                                               [ddL['%s.dArgsFILE' % sFeature] for ddL in ddLimbDatas],
                                               ddLimbDatas[0]['%s.dArgDefaults' % sFeature],
                                               ddLimbDatas[0]['%s.sArgsShow' % sFeature],
                                               dComboboxItems = ddLimbDatas[0]['%s.dComboboxItems' % sFeature],
                                               dInterpolateBehavior=ddLimbDatas[0]['%s.dInterpolateBehavior' % sFeature],
                                               bChecked=bChecked, sTextOverride='%s (feature)' % sFeature.split('_')[-1])

                        if self.dShow['Attachers']:

                            ssAttachers = [ddL['%s.sAttachers' % sFeature] for ddL in ddLimbDatas]
                            sAttachers = sorted(utils.intersectionLists(ssAttachers))
                            for a, sAttacher in enumerate(sAttachers):
                                _addOneAttacher(sAttacher, qFeat)

                        self.funcItemEnabled(qFeat, bChecked)


                if self.dShow['Attributes']:

                    for sDetail in ddLimbDatas[0]['sDetails']:
                        bCheckeds = [ddL['%s.bCheckedFILE' % sDetail] for ddL in ddLimbDatas]
                        bCheckedDifferent = True if len(set(bCheckeds)) > 1 else False
                        bChecked = None if bCheckedDifferent else bCheckeds[0]

                        qFeat = self._addOnOffFunction(sDetail, 'detail',
                                               [ddL['%s.dArgsFILE' % sDetail] for ddL in ddLimbDatas],
                                               ddLimbDatas[0]['%s.dArgDefaults' % sDetail],
                                               ddLimbDatas[0]['%s.sArgsShow' % sDetail],
                                               dComboboxItems = ddLimbDatas[0]['%s.dComboboxItems' % sDetail],
                                               dInterpolateBehavior=ddLimbDatas[0]['%s.dInterpolateBehavior' % sDetail],
                                               bChecked=bChecked, sTextOverride='Advanced')
                        self.funcItemEnabled(qFeat, bChecked)


        except Exception as e:
            print(traceback.format_exc())
            cmds.confirmDialog(m='(1) %s' % str(e))
            raise
        finally:
            self.qtTree.blockSignals(False)

        utils.debugPrint('\n === end of showLimbs...')



    def _addOnOffFunction(self, sFunctionName, sFunctionType, ddArgs, dArgDefaults, sArgOrder, bChecked=True, dComboboxItems={}, dInterpolateBehavior={},
                          sTextOverride=None):

        qFunc = QtWidgets.QTreeWidgetItem(self.qRoot)
        qFunc.setText(0, sTextOverride if sTextOverride else sFunctionName)
        qFunc.setFont(0, qFuncFont)
        qFunc.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.orange)))

        qFunc.setCheckState(0, QtCore.Qt.Checked if bChecked else QtCore.Qt.Unchecked)
        qFunc.setFlags(qFunc.flags() ^ QtCore.Qt.ItemIsDragEnabled ^ QtCore.Qt.ItemIsDropEnabled)
        qFunc.setExpanded(True)
        qFunc.setData(0, QtCore.Qt.UserRole,  {'sType':sFunctionType, 'sFunctionName':sFunctionName})

        for sArg in sArgOrder:
            values = [dArgs[sArg] for dArgs in ddArgs]
            self._addFuncAttr(qFunc, sArg, values, dArgDefaults[sArg],
                              sComboboxItems=dComboboxItems.get(sArg, []),
                              iInterpolateBehavior=dInterpolateBehavior.get(sArg, 0))

        qFunc.setExpanded(True if bChecked else False)

        return qFunc


    def _addAttacher(self, qParent, sAttacher, dPredifinedData):
        sTrs = dPredifinedData.get('sTrs', 'tr')

        if sTrs == 'tr':
            sAllTrs = ['tr','r'] # tr will be swapped to to if r is turned on
        else:
            sAllTrs = [sTrs]

        bMulti = dPredifinedData.get('bMulti', True)

        qAttachers = []
        for t,_sTrs in enumerate(sAllTrs):
            qAttacher = QtWidgets.QTreeWidgetItem(qParent)
            qAttacher.bMulti = bMulti
            qAttacher.setText(0, 'attacher: %s (%s)' % (sAttacher, _sTrs))

            sAttacherName = sAttacher if t == 0 else '%s(1)' % sAttacher
            qAttacher.setData(0, QtCore.Qt.UserRole, {'sType': 'attacher', 'sName': sAttacherName, 'bMulti':bMulti, 'iAttacherIndex':t})
            qAttacher.setFlags(qAttacher.flags() ^ QtCore.Qt.ItemIsDragEnabled ^ QtCore.Qt.ItemIsDropEnabled)
            qAttacher.setExpanded(True)
            qAttacher.sLocalOutputs = dPredifinedData.get('sLocals', [])

            if bMulti:
                qAttacher.tBlendInfo =  puppetAttrItems.QAttacherBlendItem(self.qtTree, qAttacher, self)

            qAttacher.qLocalOutputs = []
            qAttacher.qOutputs = []
            qAttacher.setExpanded(False)
            self._setAttrEnabled(qAttacher)
            qAttachers.append(qAttacher)


        if len(sAllTrs) == 1:
            qAttachers[0].bParent = False
            qAttachers[0].bChild = False
        elif len(sAllTrs) == 2:
            qAttachers[0].bParent = True
            qAttachers[0].bChild = False
            qAttachers[1].bParent = False
            qAttachers[1].bChild = True
            qAttachers[0].qChild = qAttachers[1]
            qAttachers[1].qParent = qAttachers[0]
            qAttachers[1].setHidden(True)

        return qAttachers


    def attrItemChangedFunc(self, sArgDictKey, sName, xValues):
        utils.debugPrint('attrItemChangedFunc start.. ')
        bSignalsBlockedBefore = self.tCharLimbs.qtTree.signalsBlocked()
        self.tCharLimbs.qtTree.blockSignals(True)
        try:
            qCurrentLimbs = self.getCurrentLimbObjects()
            for l, qCurrentLimb in enumerate(qCurrentLimbs):
                ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
                sAttachersBefore = puppetDataUtils.getAllAttachers(ddLimbData, bAddExtraInfos=True, bAddSplittedAttachers=True)
                sOutputsBefore = puppetDataUtils.getAllOutputs(ddLimbData)

                dArgs = ddLimbData[sArgDictKey]
                dArgs[sName] = xValues[l]
                qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
                sOutputsAfter = puppetDataUtils.getAllOutputs(ddLimbData)
                sDiff = set(sOutputsBefore) - set(sOutputsAfter)

                if sDiff:
                    self.tCharLimbs.fixOutputsOfAllLimbs(qCurrentLimb, sOutputsAfter)

                if sName == 'sSide' or sName == 'sName':
                    sNewName = self.tCharLimbs.updateLimbName(qCurrentLimb, bUpdateConnections=True)
                    self.sCurrentLimbs[l] = sNewName

                # in case it changed the attachers:
                _, ddNewData = puppetDataUtils.mergeClassWithData(dFileData=ddLimbData)
                qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddNewData)
                sAttachersAfter = puppetDataUtils.getAllAttachers(ddNewData, bAddExtraInfos=True, bAddSplittedAttachers=True)
                if set(sAttachersBefore) != set(sAttachersAfter):
                    self.refresh()

                self.tCharLimbs.dirtySaveButton()

        except Exception as e:
            cmds.confirmDialog(m='(2) %s' % str(e))
            raise
        finally:
            self.tCharLimbs.qtTree.blockSignals(bSignalsBlockedBefore)
        utils.debugPrint('attrItemChangedFunc end.. ')




    # get rid of that and call the QAttrItem directly?
    def _addFuncAttr(self, qParentItem, sArg, values, default, bIsBase=False, sComboboxItems=[], iInterpolateBehavior=0):  # , dFileFuncData=None):
        qAttrItem = puppetAttrItems.createAttrItem(qtTree=self.qtTree, qParentItem=qParentItem, sName=sArg, xValues=values, bIsBase=bIsBase,
                                     xDefault=default, changedFunc=self.attrItemChangedFunc, qtWindow=self.qtWindow, sComboboxItems=sComboboxItems, iInterpolateBehavior=iInterpolateBehavior)
        sToolTip = dToolTips.get(sArg, None)
        if sToolTip:
            qAttrItem.setToolTip(0, '%s (%s)' % (sToolTip, sArg))
        else:
            qAttrItem.setToolTip(0, sArg)
        return qAttrItem



    def _setAttrEnabled(self, qItem, bEnabled=True):
        ddData = qItem.data(0, QtCore.Qt.UserRole)
        if not ddData or 'sType' not in ddData:
            return
        sType = ddData['sType']

        if sType == 'attr':
            qItem.setEnabled(True if bEnabled else False)
        if sType == 'attacher':
            if bEnabled:
                # if int(qItem.text(1)) > 0: # filled, qItem.text(0)
                if not qItem.bMulti or qItem.tBlendInfo.getCount() > 0:
                    qItem.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.lightGreen)))
                    qItem.setForeground(1, QtGui.QBrush(QtGui.QColor(utils.uiColors.lightGreen)))
                    qItem.setFlags(qItem.flags() | QtCore.Qt.ItemIsEditable | QtCore.Qt.ItemIsSelectable)
                    qItem.setFont(0, qBold)
                    qItem.setFont(1, qBold)
                else: # not filll
                    qItem.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.lightGreen)))
                    qItem.setForeground(1, QtGui.QBrush(QtGui.QColor(utils.uiColors.lightGreen)))
                    qItem.setFlags(qItem.flags() | QtCore.Qt.ItemIsEditable | QtCore.Qt.ItemIsSelectable)
                    qItem.setFont(0, qItalic)
                    qItem.setFont(1, qItalic)
            else:
                qItem.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.disabled)))
                qItem.setForeground(1, QtGui.QBrush(QtGui.QColor(utils.uiColors.disabled)))
                qItem.setFlags(qItem.flags() ^ QtCore.Qt.ItemIsEditable ^ QtCore.Qt.ItemIsSelectable)
                qItem.setFont(1, qItalic)
            for qOutput in qItem.qOutputs:
                qOutput.setEnabled(bEnabled)
            if qItem.bMulti:
                qItem.tBlendInfo.setEnabled(bEnabled)

        elif sType == 'feature':
            for iChild in range(qItem.childCount()):
                qChild = qItem.child(iChild)
                if qChild.data(0, QtCore.Qt.UserRole)['sType'] == 'attacher':
                    self._setAttrEnabled(qChild, bEnabled=bEnabled)


    def funcItemEnabled(self, qFunc, bEnabled):
        for iChild in range(qFunc.childCount()):
            qChild = qFunc.child(iChild)
            self._setAttrEnabled(qChild, bEnabled=bEnabled)




class QLimbsTreeWidget(QtWidgets.QTreeWidget):
    def __init__(self, parent, setAttrAcceptDropsFunc, dropEventFunc, funcCopy, funcPaste):
        QtWidgets.QTreeWidget.__init__(self, parent=parent)
        self.dropEventFunc = dropEventFunc
        self.setAttrAcceptDropsFunc = setAttrAcceptDropsFunc
        self.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.header().hide()
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.bMouseDownSinceSelect = False

        self.setColumnCount(2)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        # self.setColumnWidth(0, 2)
        self.setHeaderLabels(['',''])
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.funcCopy = funcCopy
        self.funcPaste = funcPaste

    def superDropEvent(self, event):
        QtWidgets.QTreeWidget.dropEvent(self, event)


    def dropEvent(self, event):
        self.dropEventFunc(event)
        # QtWidgets.QTreeWidget.dropEvent(self, event)


    def resizeEvent(self, event):
        iWidthLeft = self.width() * 0.8
        self.setColumnWidth(0, iWidthLeft)
        self.setColumnWidth(1, self.width() - iWidthLeft - 100)


    def focusOutEvent(self, event):
        self.tAttrControl.qtTree.setAcceptDrops(False)
        return QtWidgets.QTreeWidget.focusOutEvent(self, event)


    def keyPressEvent(self, event):
        super().keyPressEvent(event)
        if (event.modifiers() & QtCore.Qt.ControlModifier):
            if event.key() == QtCore.Qt.Key_C:
                self.funcCopy()
            elif event.key() == QtCore.Qt.Key_V:
                self.funcPaste()


class TLimbsControl(controls.FilePathControl):
    def __init__(self, tAllLimbsControl=None):
        controls.FilePathControl.__init__(self, '*.rig', bLoad=True, bReadOnly=False, bDisableOnServer=True, bShowContent=True, sPossibleFileExtensions=['.rig'],
                                          dBackupFolder={'sDirName': '_puppetBackup', 'func': self.refreshFromBackup})
        self.bRefreshButton = True
        self.sDefaultFileName = 'puppet.rig'
        self.tAllLimbsControl = tAllLimbsControl
        tAllLimbsControl.tLimbsControl = self
        self.xSnapShots = []


    def serverSwitch(self, bServer):
        self.qtTree.setEnabled(not bServer)


    def build(self, qParentLayout, sName, xValue, qtWindow=None):
        sFile = xValue[0]
        controls.FilePathControl.build(self, qParentLayout, sName, sFile, qtWindow=qtWindow)
        self.qtLayout = QtWidgets.QVBoxLayout()
        self.qtLayout.setSpacing(0)
        self.uniqueLayout.addLayout(self.qtLayout)
        self.qFilter = utilsQt.QFilter()
        self.qFilter.changed.connect(self.updateLimbFilterVisibility)

        self.qtTree = QLimbsTreeWidget(qtWindow, self.setAttrAcceptDropsFunc, self.dropToLimbsEvent, self.copy, self.paste)
        self.qtTree.tAttrControl = self.tAttrControl
        self.qRoot = self.qtTree.invisibleRootItem()

        self.qtTree.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.qtTree.itemSelectionChanged.connect(self.limbSelectionChanged)
        self.qtTree.itemDoubleClicked.connect(self.doubleClick)

        self.qtTree.itemChanged.connect(self.limbItemChanged)
        self.qtTree.itemExpanded.connect(self.limbExpanded)
        self.qtTree.itemCollapsed.connect(self.limbExpanded)


        self.qtLayout.addWidget(self.qFilter)
        self.qtLayout.addWidget(self.qtTree)


        self.qtTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qtTree.customContextMenuRequested.connect(self.markingMenuTable)

        self.qtTree.mouseUpSelectFunction = self.updateAttrTreeWithSelection


        self.qtWindow=qtWindow
        self.refresh(bCleanSaveButton=False)
        global globalLimbControl
        globalLimbControl = self

    def updateLimbFilterVisibility(self, sFilter):

        def _matchItem(item):
            for sF in sFilter:
                if sF.lower() in item.text(0).lower():
                    return True
            return False

        def _processItemREC(qItem):
            bMatches = False
            for i in range(qItem.childCount()):
                qChild = qItem.child(i)
                if _processItemREC(qChild):
                    bMatches = True

            current_matches = _matchItem(qItem)
            qItem.setHidden(not (current_matches or bMatches))
            return current_matches or bMatches

        for i in range(self.qRoot.childCount()):
            qTopItem = self.qRoot.child(i)
            _processItemREC(qTopItem)


    def copy(self):
        sSelectedLimbs = [qL.text(0) for qL in self.getAllLimbs(bOnlySelected=True)]
        dAllLimbs = self.getAllLimbs(bReturnDict=True)
        print ('sSelectedLimbs: ', sSelectedLimbs)
        xItems = []
        for sLimb in sSelectedLimbs:
            dItem = dAllLimbs[sLimb].data(0, QtCore.Qt.UserRole)
            if dItem['__parent__'] == None:
                qParent = dAllLimbs[sLimb].parent()
                if qParent:
                    dItem['__parent__'] = qParent.text(0) if qParent else None
            xItems.append(dItem)
        clipboard.put('kangarooLimb.%s' % str(xItems))



    # this is a duplicate.... of the one in tCharLimbs. Is it great? Nope
    def getAllLimbsWithValidOutputs(self, qLimb, bReturnDict=False):

        qLimbs = []
        sExcludeLimbs = list(self.getAllLimbs(qLimb, bReturnDict=True).keys())

        def getLimbsREC(qItem, bItIsRoot):
            if not bItIsRoot and qItem.text(0) not in sExcludeLimbs:
                tItem = puppetDataUtils.instantiateLimb(qItem.data(0, QtCore.Qt.UserRole))
                if list(tItem.dOutputs.keys()):
                    qLimbs.append(qItem)
            if qItem.text(0) not in sExcludeLimbs:
                for iChild in range(qItem.childCount()):
                    getLimbsREC(qItem.child(iChild), False)
        getLimbsREC(self.qRoot, True)

        qLimbs.sort(key=lambda x:x.text(0))

        if bReturnDict:
            return {qL.text(0):qL for qL in qLimbs}
        else:
            return qLimbs



    def paste(self):
        utils.reload2(dependencyEditor)

        sClipboard = clipboard.get()
        if sClipboard.startswith('kangarooLimb.'):
            sClipboard = utils.replaceStringStart(sClipboard, 'kangarooLimb.', '')
        else:
            return
        xPastedLimbs = eval(sClipboard)
        sPastedLimbNames = ['%s_%s' % (dLimb['dArgsFILE']['sSide'], dLimb['dArgsFILE']['sName']) for dLimb in xPastedLimbs]
        dAllCurrentLimbs = self.getAllLimbs(bReturnDict=True)
        print ('sPastedLimbNames: ', sPastedLimbNames)


        # check clashing names
        #
        dRenamedLimbs = {}
        sAllCurrentLimbs = list(dAllCurrentLimbs.keys())
        print ('sPastedLimbNames: ', sPastedLimbNames)
        for l in range(len(sPastedLimbNames)):
            sOldLimbName = sPastedLimbNames[l]
            sCheckLimbs = sAllCurrentLimbs + sPastedLimbNames
            sCheckLimbs.remove(sOldLimbName)
            print ('sOldLimbName: ', sOldLimbName)
            sPastedLimbNames[l] = utils.getUniqueNameFromList(sOldLimbName, sCheckLimbs, bCheckCapitalEnding=True)
            dRenamedLimbs[sOldLimbName] = sPastedLimbNames[l]
            print ('new name: ', sPastedLimbNames[l])

        for l in range(len(sPastedLimbNames)):
            sSide, sName = sPastedLimbNames[l].split('_')
            xPastedLimbs[l]['dArgsFILE']['sSide'] = sSide
            xPastedLimbs[l]['dArgsFILE']['sName'] = sName



        # resolve missing parents
        #
        sMissingParents = set()
        dParentToLimbIndexMapper = defaultdict(list)
        print ('dRenamedLimbs: ', dRenamedLimbs)
        for iLimb, sLimb, dLimb in zip(range(len(sPastedLimbNames)), sPastedLimbNames, xPastedLimbs):
            sParentLimb = dLimb['__parent__']
            if utils.isNone(sParentLimb):
                continue
            sParentOutput = dLimb['parentOutputFILE']
            sOutputKey = '%s@%s' % (sParentLimb, sParentOutput)
            if sParentLimb in dRenamedLimbs:
                print ('sParentLimb in dRenamedLimbs: ', sParentLimb, dRenamedLimbs)
                xPastedLimbs[iLimb]['__parent__'] = dRenamedLimbs[sParentLimb]
            if sParentLimb not in dAllCurrentLimbs and sParentLimb not in sPastedLimbNames:
                sMissingParents.add(sOutputKey)
                dParentToLimbIndexMapper[sOutputKey].append(iLimb)
            elif sParentLimb not in sPastedLimbNames: # if sParentLimb is in existing limbs, we'll make sure the outputs are also there. Just in case we parent to another limb with different outputs
                dParentLimb = dAllCurrentLimbs[sParentLimb].data(0, QtCore.Qt.UserRole)
                sOutputs = puppetDataUtils.getAllOutputs(dParentLimb)
                if sParentOutput not in sOutputs:
                    sMissingParents.add(sOutputKey)
                    dParentToLimbIndexMapper[sOutputKey].append(iLimb)

        dLimbOutputs = {sL:puppetDataUtils.getAllOutputs(qL.data(0,QtCore.Qt.UserRole)) for sL,qL in dAllCurrentLimbs.items()}

        if sMissingParents:
            sMissingParents = sorted(list(sMissingParents))
            ssNewParents = dependencyEditor.showUi([(sMissingParent, dLimbOutputs, 2) for sMissingParent in sMissingParents], 'Resolve missing Parents')
            for p in range(len(sMissingParents)):
                sMissingParentOutput = sMissingParents[p]
                sParent, sOutput = ssNewParents[p].split('@')
                for iLimb in dParentToLimbIndexMapper[sMissingParentOutput]:
                    xPastedLimbs[iLimb]['__parent__'] = sParent
                    xPastedLimbs[iLimb]['parentOutputFILE'] = sOutput


        # resolve missing attacher plugs
        #
        dAllLimbs = self.getAllLimbs(bReturnDict=True)
        sMissingAttacherOutputs = set()
        dOutputToLimbIndexMapper = defaultdict(list)
        for iLimb, sLimb, dLimb in zip(range(len(sPastedLimbNames)), sPastedLimbNames, xPastedLimbs):
            for sKey in dLimb.keys():
                if sKey.endswith('.sOutputsFILE'):
                    sOutputs = dLimb[sKey]
                    for o,sO in enumerate(sOutputs):
                        print ('sO:', sO)
                        sOutputSplits = utils.tempOutputSplit(sO)
                        sOutputLimb = sOutputSplits[0]
                        if sOutputLimb == utils.kCustomString:
                            continue
                        sOutput = sOutputSplits[1]
                        sOutputKey = '%s@%s' % (sOutputLimb, sOutput)
                        if sOutputLimb in dRenamedLimbs:
                            sOutputSplits[0] = dRenamedLimbs[sOutputLimb]
                            sOutputs[o] = '@'.join(sOutputSplits)
                        elif sOutputLimb not in dAllLimbs:
                            sMissingAttacherOutputs.add(sOutputKey)
                            dOutputToLimbIndexMapper[sOutputKey].append((iLimb, sKey, o))
                        else:
                            sPossibleOutputs = puppetDataUtils.getAllOutputs(dAllLimbs[sOutputLimb].data(0, QtCore.Qt.UserRole))
                            if sOutput not in sPossibleOutputs:
                                sMissingAttacherOutputs.add(sOutputKey)
                                dOutputToLimbIndexMapper[sOutputKey].append((iLimb, sKey, o))

        if sMissingAttacherOutputs:
            sNewOutputs = dependencyEditor.showUi([(sMissingOutput, dLimbOutputs, 2) for sMissingOutput in sMissingAttacherOutputs], 'Resolve missing Attacher Plugs')
            for sOutputKey in sMissingAttacherOutputs:
                for iLimb, sKey, o in dOutputToLimbIndexMapper[sOutputKey]:
                    sSplits = utils.tempOutputSplit(xPastedLimbs[iLimb][sKey][o])
                    sSplits[0], sSplits[1] = sNewOutputs[o].split('@')[0:2]
                    xPastedLimbs[iLimb][sKey][o] = '@'.join(sSplits)


        # finally adding them
        #
        self.qtTree.clearSelection()
        for dLimb in xPastedLimbs:
            sParentLimb = dLimb['__parent__']

            dAllLimbs = self.getAllLimbs(bReturnDict=True)

            dLimbClasses = puppetDataUtils.limbsFromFiles()[dLimb['sClassTypeFILE']]
            qNewLimb = self.addLimbToUI(dLimbClasses, dFileData=dLimb, qParentUnderLimb=dAllLimbs[sParentLimb] if sParentLimb else None)
            qNewLimb.setSelected(True)

            self.dirtySaveButton()
        self.qtTree.scrollTo(self.qtTree.indexFromItem(qNewLimb))


    def dirtySaveButton(self):
        self.dApplyButtons['Save'].setText('Save *')


    def cleanSaveButton(self):
        self.dApplyButtons['Save'].setText('Save')


    def pathGotChanged(self, sPath):
        if os.path.exists(sPath):
            self.refresh()


    def setAttrAcceptDropsFunc(self, qDraggedLimb):
        sValidLimbs = list(self.getAllLimbsWithValidOutputs(self.tAttrControl.qCurrentLimb, bReturnDict=True).keys())
        if qDraggedLimb.text(0) in sValidLimbs:
            self.tAttrControl.qtTree.setAcceptDrops(True)
        else:
            self.tAttrControl.qtTree.setAcceptDrops(False)


    def limbExpanded(self, item):
        ddData = item.data(0, QtCore.Qt.UserRole)
        ddData['bExpandedFILE'] = item.isExpanded()
        item.setData(0, QtCore.Qt.UserRole, ddData)


    def doubleClick(self, item, column):
        self.qtTree.editItem(item, 0)


    def limbItemChanged(self, qLimb):
        # print 'name got changed'

        ddData = qLimb.data(0, QtCore.Qt.UserRole)
        dArgs = ddData['dArgsFILE']
        sNameStart = '%s_%s' % (dArgs['sSide'], dArgs['sName'])

        if sNameStart == qLimb.text(0): # it was probably the version change
            bBlockedBefore = self.qtTree.signalsBlocked()
            if qLimb.text(0) in self.tAttrControl.sCurrentLimbs:
                try:
                    qCurrentLimbs = self.tAttrControl.getCurrentLimbObjects(sLimbs=self.tAttrControl.sCurrentLimbs)
                    self.tAttrControl.showLimbs(qCurrentLimbs)
                    self.dirtySaveButton()

                except:
                    raise
                finally:
                    self.qtTree.blockSignals(bBlockedBefore)

        if sNameStart != qLimb.text(0):
            bBlockedBefore = self.qtTree.signalsBlocked()
            self.qtTree.blockSignals(True)
            try:
                self.makeUniqueName(qLimb)

                ddData = qLimb.data(0, QtCore.Qt.UserRole)
                dArgs = ddData['dArgsFILE']
                sOldName = '%s_%s' % (dArgs['sSide'], dArgs['sName'])
                sNewName = qLimb.text(0)

                if sOldName != sNewName:
                    sSplits = qLimb.text(0).split('_')
                    if len(sSplits) == 1:
                        dArgs['sName'] = sSplits[0]
                        sNewName = '%s_%s' % (dArgs['sSide'], sSplits[0])
                        qLimb.setData(0, QtCore.Qt.UserRole, ddData)
                        self.updateLimbName(qLimb, bUpdateConnections=False)
                        utils.debugPrint ('switch limbs 0')
                        self.switchLimbsInAllAttacherOutputs(sOldName, sNewName)
                    elif len(sSplits) == 2:
                        if sSplits[0] in ['l','m','r']:
                            dArgs['sSide'] = sSplits[0]
                            dArgs['sName'] = sSplits[1]
                            qLimb.setData(0, QtCore.Qt.UserRole, ddData)
                            utils.debugPrint ('switch limbs 1')
                            self.switchLimbsInAllAttacherOutputs(sOldName, sNewName)
                        else:
                            qLimb.setText(0, sOldName)
                    else: #len(sSplits) > 2:
                        qLimb.setText(0, sOldName)

                    self.dirtySaveButton()

                qCurrentLimbs = self.tAttrControl.getCurrentLimbObjects(sLimbs=[sNewName])
                self.tAttrControl.showLimbs(qCurrentLimbs)

            except:
                raise
            finally:
                self.qtTree.blockSignals(bBlockedBefore)



    def fixOutputsOfAllLimbs(self, qLimb, sNewOutputs):
        tLimb = puppetDataUtils.instantiateLimb(qLimb.data(0, QtCore.Qt.UserRole))
        sDefaultOutput = tLimb.getDefaultParentOutput()
        qAllLimbs = self.getAllLimbs()
        sLimb = qLimb.text(0)

        # attachers:
        for qL in qAllLimbs:
            ddD = qL.data(0, QtCore.Qt.UserRole)
            sAttachers = puppetDataUtils.getAllAttachers(ddD, bAddSplittedAttachers=True)
            for sA in sAttachers:
                sOutputs = ddD.get('%s.sOutputsFILE' % sA, [])
                for o, sOutput in enumerate(sOutputs):
                    sOldOutput = str(sOutput)
                    sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                    if sL == sLimb and sO not in sNewOutputs:
                        sOutputs[o] = '%s@%s@%s' % (sL,sDefaultOutput, sDefaultOutput)
                        report.report.addLogText('ATTACHER CHANGE: "%s": changing in attacher "%s" from %s to %s' % (qL.text(0), sA, sOldOutput, sOutputs[o]))
            qL.setData(0, QtCore.Qt.UserRole, ddD)

        # children:
        for iChild in range(qLimb.childCount()):
            qChild = qLimb.child(iChild)
            ddC = qChild.data(0, QtCore.Qt.UserRole)
            if ddC['parentOutputFILE'] not in sNewOutputs:
                sOldOutput = ddC['parentOutputFILE']
                ddC['parentOutputFILE'] = sDefaultOutput
                report.report.addLogText('PARENT CHANGE: "%s": changing parent from "%s" to "%s"' % (qChild.text(0), sOldOutput, sDefaultOutput))
                qChild.setData(0, QtCore.Qt.UserRole, ddC)





    def getValue(self):

        qLimbs = self.getAllLimbs()
        xLimbs = []
        for qL in qLimbs:
            ddSave = qL.data(0, QtCore.Qt.UserRole)

            qParent = qL.parent()
            ddSave['__parent__'] = qParent.text(0) if qParent else None

            xLimbs.append(ddSave)

        sFile = controls.FilePathControl.getValue(self)


        print ('getValue: ', xLimbs)
        return sFile, xLimbs


    def getAllLimbs(self, qRoot=None, bReturnDict=False, bOnlySelected=False):

        if not qRoot:
            bFirstIsRoot = True
            qRoot = self.qRoot
        else:
            bFirstIsRoot = False

        qLimbs = []

        def getLimbsREC(qItem, bItIsRoot):
            if not bItIsRoot:
                bSkip = bOnlySelected and not qItem.isSelected()
                if not bSkip:
                    qLimbs.append(qItem)
            for iChild in range(qItem.childCount()):
                getLimbsREC(qItem.child(iChild), False)
        getLimbsREC(qRoot, bFirstIsRoot)

        if bReturnDict:
            return {qL.text(0):qL for qL in qLimbs}
        else:
            return qLimbs


    def getAllLimbsWithValidOutputs(self, qLimb, bReturnDict=False):

        qLimbs = []
        sExcludeLimbs = list(self.getAllLimbs(qLimb, bReturnDict=True).keys())

        def getLimbsREC(qItem, bItIsRoot):
            if not bItIsRoot and qItem.text(0) not in sExcludeLimbs:
                tItem = puppetDataUtils.instantiateLimb(qItem.data(0, QtCore.Qt.UserRole))
                if list(tItem.dOutputs.keys()):
                    qLimbs.append(qItem)
            if qItem.text(0) not in sExcludeLimbs:
                for iChild in range(qItem.childCount()):
                    getLimbsREC(qItem.child(iChild), False)
        getLimbsREC(self.qRoot, True)

        qLimbs.sort(key=lambda x:x.text(0))

        if bReturnDict:
            return {qL.text(0):qL for qL in qLimbs}
        else:
            return qLimbs



    def getLimbItemWithName(self, sName):
        qItems = self.qtTree.findItems(sName, QtCore.Qt.MatchExactly | QtCore.Qt.MatchRecursive)
        if not qItems:
            raise Exception('there are no limb with the name "%s"' % sName)
        return qItems[0]



    def refreshFromBackup(self, sFilePath):
        self.refresh(bReload=True, bRestoreExpanded=True, sPuppetFile=sFilePath)



    def refresh(self, bReload=True, bRestoreExpanded=True, sPuppetFile=None, bCleanSaveButton=True):
        try:
            self.tAttrControl.clear()
            if sPuppetFile == None:
                sPuppetFile = controls.FilePathControl.getValue(self)

            if os.path.exists(sPuppetFile):

                dLimbLibrary = puppetDataUtils.limbsFromFiles(bReload=bReload)

                try:
                    xFileData = puppetDataUtils.getDictListFromFile(sPuppetFile)
                except:
                    cmds.confirmDialog(m='puppet.rig file got corrupted. \nTry to switch to an old one with the backup button\n%s' % sPuppetFile)
                    raise

                self.qtTree.blockSignals(True)
                self.qtTree.clear()
                for dLimb in xFileData:
                    sClassType = dLimb['sClassTypeFILE']
                    if sClassType.startswith('T'):
                        sClassType = 'L%s' % sClassType[1:]
                        dLimb['sClassType'] = sClassType

                    if sClassType in dLimbLibrary:
                        TLimbs = dLimbLibrary[sClassType]
                        if dLimb['__parent__']:
                            qParent = self.getLimbItemWithName(dLimb['__parent__'])
                        else:
                            qParent = None

                        self.addLimbToUI(TLimbs, qParentUnderLimb=qParent, dFileData=dLimb)
                    else:
                        report.report.addLogText('Limb "%s" not found' % sClassType)

                report.report.setProgressBarColor(utils.uiColors.green)
                report.report.setToFull()
                # report.report.addLogText('\n\n successfully filled puppet limbs')

                self.qtTree.resizeEvent(None)

            if bCleanSaveButton:
                self.cleanSaveButton()

        except Exception as e:
            # raise
            sError = traceback.format_exc()
            sError = 'RELOAD ERROR (1): %s' % sError
            report.report.addLogText(sError, sColor=utils.uiColors.orange, bQuotationsToLink=True)
            print(sError)
            report.report.setProgressBarColor(utils.uiColors.orange)
            report.report.setToFull()
        finally:
            self.qtTree.blockSignals(False)



    def limbSelectionChanged(self):
        utils.debugPrint('selection changed START...')
        qSelection = self.qtTree.selectedItems()
        if qSelection:
            self.qtTree.tAttrControl.showLimbs(qSelection)
        else:
            self.qtTree.tAttrControl.clear()
        utils.debugPrint('selection changed END...')




    def updateAttrTreeWithSelection(self):
        self.qSelection = self.qtTree.selectedItems()
        if self.qSelection:
            self.tAttrControl.showLimbs(self.qSelection)
        else:
            self.tAttrControl.clear()



    def activateItemsStartingWithDrop(self, sStartWith, bOn=True):
        qAttachers = self.qtTree.findItems(sStartWith, QtCore.Qt.MatchContains|QtCore.Qt.MatchRecursive)

        for qItem in qAttachers:
            if bOn:
                qItem.setFlags(qItem.flags() | QtCore.Qt.ItemIsDropEnabled)
            else:
                qItem.setFlags(qItem.flags() & ~QtCore.Qt.ItemIsDropEnabled)



    def deleteSelected(self):
        qItems = self.qtTree.selectedItems()
        qChildrenItems = []
        for qI in qItems:
            qChildrenItems.extend(self.getAllLimbs(qI))
        qItems.extend(qChildrenItems)

        qLimbsApproved = self.removeInvalidOutputsFromAllLimbsToLimbs(qLimbsToDelete=qItems)

        if len(qLimbsApproved):
            for qI in qLimbsApproved:
                qParent = qI.parent()
                if not qParent: qParent = self.qRoot
                qParent.removeChild(qI)

            self.dirtySaveButton()


    def disableSelected(self):
        qItems = self.qtTree.selectedItems()
        qChildrenItems = []
        for qI in qItems:
            qChildrenItems.extend(self.getAllLimbs(qI))
        qItems.extend(qChildrenItems)

        qLimbsApproved = self.removeInvalidOutputsFromAllLimbsToLimbs(qLimbsToDelete=qItems)

        if len(qLimbsApproved):
            for qLimbItem in qLimbsApproved:
                ddData = qLimbItem.data(0, QtCore.Qt.UserRole)
                ddData['bDisabledFILE'] = True
                self._setStatusFont(qLimbItem, bDisabled=True)

                qLimbItem.setData(0, QtCore.Qt.UserRole, ddData)

            self.dirtySaveButton()


    def enableSelected(self):
        qItems = self.qtTree.selectedItems()
        qChildrenItems = []
        for qI in qItems:
            qChildrenItems.extend(self.getAllLimbs(qI))
        qItems.extend(qChildrenItems)


        for qLimbItem in qItems:
            ddData = qLimbItem.data(0, QtCore.Qt.UserRole)
            ddData['bDisabledFILE'] = False
            self._setStatusFont(qLimbItem, bDisabled=False)

            qLimbItem.setData(0, QtCore.Qt.UserRole, ddData)

            self.dirtySaveButton()



    def mirrorLimbs(self, qLimbs):

        def _flipStringAttrs(dArgs):
            for sAttr, xValue in dArgs.items():
                if sAttr in ['sSide', 'sName']:
                    continue
                if utils.isStringOrUnicode(xValue):
                    dArgs[sAttr] = utils.getMirrorName(xValue)

        dAllLimbs = self.getAllLimbs(bReturnDict=True)
        try:
            self.qtTree.blockSignals(True)
            qMirroredLimbs = []
            for qL in qLimbs:
                ddData = qL.data(0, QtCore.Qt.UserRole)
                dArgs = ddData['dArgsFILE']
                sSide = dArgs['sSide']
                if sSide == 'l':
                    sRightLimb = 'r_%s' % dArgs['sName']
                    if sRightLimb not in list(dAllLimbs.keys()):
                        qRight = qL.clone()

                        qLeftParent = qL.parent()
                        if not qLeftParent:
                            self.qRoot.addChild(qRight)
                        else:
                            sRightParent = 'r_%s' % qLeftParent.text(0)[2:]
                            qRightParent = dAllLimbs.get(sRightParent, qLeftParent)
                            qRightParent.addChild(qRight)

                        self.addVersionBox(qRight)
                        qMirroredLimbs.append(qRight)

                        qRemoveChildren = [qRight.child(i) for i in range(qRight.childCount())]
                        [qRight.removeChild(qC) for qC in qRemoveChildren]

                        ddDataRight = qRight.data(0, QtCore.Qt.UserRole)
                        dArgsRight = ddDataRight['dArgsFILE']
                        dArgsRight['sSide'] = 'r'
                        _flipStringAttrs(dArgsRight)
                        for sDetail in ddDataRight['sDetails']:
                            _flipStringAttrs(ddDataRight['%s.dArgsFILE' % sDetail])
                        for sFeature in ddDataRight['sFeatures']:
                            _flipStringAttrs(ddDataRight['%s.dArgsFILE' % sFeature])

                        qRight.setData(0, QtCore.Qt.UserRole, ddDataRight)
                        self.updateLimbName(qRight)
                        dAllLimbs[sRightLimb] = qRight
                    else: #it's already there
                        # mirror the data
                        ddDataRight = copy.deepcopy(ddData)
                        dArgs = ddDataRight['dArgsFILE']
                        dArgs['sSide'] = 'r'
                        _flipStringAttrs(dArgs)
                        for sDetail in ddDataRight['sDetails']:
                            _flipStringAttrs(ddDataRight['%s.dArgsFILE' % sDetail])
                        for sFeature in ddDataRight['sFeatures']:
                            _flipStringAttrs(ddDataRight['%s.dArgsFILE' % sFeature])

                        qRight = dAllLimbs[sRightLimb]
                        qRight.setData(0, QtCore.Qt.UserRole, ddDataRight)
                        qMirroredLimbs.append(qRight)

                        # update the version combo of the right limb
                        # qVersion = qRight.qVersion
                        iVersions = ddDataRight['iVersions']
                        iCurrentVersion = ddDataRight.get('iVersionFILE', iVersions[-1])
                        iVersionIndex = iVersions.index(iCurrentVersion)
                        qRight.qVersion.setCurrentIndex(iVersionIndex)


                elif sSide == 'r':
                    sLeftLimb = 'l_%s' % dArgs['sName']
                    if sLeftLimb not in list(dAllLimbs.keys()):
                        qLeft = qL.clone()

                        qLeftParent = qL.parent()
                        if not qLeftParent:
                            self.qRoot.addChild(qLeft)
                        else:
                            sLeftParent = 'l_%s' % qLeftParent.text(0)[2:]
                            qLeftParent = dAllLimbs.get(sLeftParent, qLeftParent)
                            qLeftParent.addChild(qLeft)

                        self.addVersionBox(qLeft)
                        qMirroredLimbs.append(qLeft)

                        qRemoveChildren = [qLeft.child(i) for i in range(qLeft.childCount())]
                        [qLeft.removeChild(qC) for qC in qRemoveChildren]

                        ddDataLeft = qLeft.data(0, QtCore.Qt.UserRole)
                        dArgsLeft = ddDataLeft['dArgsFILE']
                        dArgsLeft['sSide'] = 'l'
                        _flipStringAttrs(dArgsLeft)
                        for sDetail in ddDataLeft['sDetails']:
                            _flipStringAttrs(ddDataLeft['%s.dArgsFILE' % sDetail])
                        for sFeature in ddDataLeft['sFeatures']:
                            _flipStringAttrs(ddDataLeft['%s.dArgsFILE' % sFeature])

                        qLeft.setData(0, QtCore.Qt.UserRole, ddDataLeft)
                        self.updateLimbName(qLeft)
                        dAllLimbs[sLeftLimb] = qLeft
                    else: #it's already there
                        # mirror the data
                        ddDataLeft = copy.deepcopy(ddData)
                        dArgs = ddDataLeft['dArgsFILE']
                        dArgs['sSide'] = 'l'
                        _flipStringAttrs(dArgs)
                        for sDetail in ddDataLeft['sDetails']:
                            _flipStringAttrs(ddDataLeft['%s.dArgsFILE' % sDetail])
                        for sFeature in ddDataLeft['sFeatures']:
                            _flipStringAttrs(ddDataLeft['%s.dArgsFILE' % sFeature])

                        qLeft = dAllLimbs[sLeftLimb]
                        qLeft.setData(0, QtCore.Qt.UserRole, ddDataLeft)
                        qMirroredLimbs.append(qLeft)

                        # update the version combo of the left limb
                        # qVersion = qLeft.qVersion
                        iVersions = ddDataLeft['iVersions']
                        iCurrentVersion = ddDataLeft.get('iVersionFILE', iVersions[-1])
                        iVersionIndex = iVersions.index(iCurrentVersion)
                        qLeft.qVersion.setCurrentIndex(iVersionIndex)


            # mirror output lists
            for qL in qMirroredLimbs:
                ddData = qL.data(0, QtCore.Qt.UserRole)
                # attacher outputs
                sAttachers = puppetDataUtils.getAllAttachers(ddData, bAddSplittedAttachers=True)
                for sA in sAttachers:
                    sOutputs = ddData['%s.sOutputsFILE' % sA]
                    for o,sO in enumerate(sOutputs):
                        sLimb, sOutput, sAttrName, fWeight = utils.extractOutputInfo(sO)
                        if sLimb == utils.kCustomString:
                            sOtherOutput = utils.getMirrorName(sOutput)
                            sO = '%s@%s@%s@%0.3f' % (utils.kCustomString, sOtherOutput, sAttrName, fWeight)
                            sOutputs[o] = sO
                        elif sLimb.startswith('l_'):
                            sOtherLimb = 'r_%s' % sLimb[2:]
                            if sOtherLimb in list(dAllLimbs.keys()):
                                sO = '%s@%s@%s@%0.3f' % (sOtherLimb, sOutput, sAttrName, fWeight)
                                sOutputs[o] = sO
                        elif sLimb.startswith('r_'):
                            sOtherLimb = 'l_%s' % sLimb[2:]
                            if sOtherLimb in list(dAllLimbs.keys()):
                                sO = '%s@%s@%s@%0.3f' % (sOtherLimb, sOutput, sAttrName, fWeight)
                                sOutputs[o] = sO
                        elif sLimb.startswith('m_'):
                            if 'LFT' in sOutput:
                                sOutput = sOutput.replace('LFT', 'RGT')
                                sO = '%s@%s@%s@%0.3f' % (sLimb, sOutput, sAttrName, fWeight)
                                sOutputs[o] = sO
                            elif 'RGT' in sOutput:
                                sOutput = sOutput.replace('RGT', 'LFT')
                                sO = '%s@%s@%s@%0.3f' % (sLimb, sOutput, sAttrName, fWeight)
                                sOutputs[o] = sO


                qL.setData(0, QtCore.Qt.UserRole, ddData)
                self.dirtySaveButton()
        except:
            raise
        finally:
            self.qtTree.blockSignals(False)


    def markingMenuTable(self, vPos):
        qMenu = QtWidgets.QMenu()
        qSelItems = self.qtTree.selectedItems()

        def _selectFromScene():
            sSel = cmds.ls(sl=True)
            sLimbs = set()
            for sO in sSel:
                for sA in ['sBlueprintJoint', 'sBlueprintCtrl', 'sLimbName', 'sLimbJoint', 'sLimbCtrl']:
                    sAttr = '%s.%s' % (sO, sA)
                    if cmds.objExists(sAttr):
                        sLimbs.add(cmds.getAttr(sAttr))
                        break
            qL = None
            if sLimbs:
                dAllLimbs = self.getAllLimbs(bReturnDict=True)
                sIntersectedLimbs = sLimbs.intersection(set(dAllLimbs.keys()))

                bBlockSignalStateBefore = self.qtTree.signalsBlocked()
                if not bBlockSignalStateBefore:
                    self.qtTree.blockSignals(True)
                try:
                    self.qtTree.clearSelection()
                    for sL in sIntersectedLimbs:
                        qL = dAllLimbs[sL]
                        qL.setSelected(True)
                except:
                    raise
                finally:
                    if not bBlockSignalStateBefore:
                        self.qtTree.blockSignals(False)
                self.limbSelectionChanged()
                if qL:
                    index = self.qtTree.indexFromItem(qL)
                    self.qtTree.scrollTo(index)
            else:
                cmds.confirmDialog(m='no limbs found')

        if not qSelItems:
            qMenu.addAction('select from scene', _selectFromScene)
        else: # selected items
            _qItem = qSelItems[0]
            for i in range(10):
                ddData = _qItem.data(0, QtCore.Qt.UserRole)
                if ddData and 'sType' in list(ddData.keys()) and ddData['sType'] == 'instance':
                    break
                _qItem = _qItem.parent()
            qLimb = _qItem


            #delete limb
            qMenu.addSeparator()
            qMenu.addAction('delete', self.deleteSelected)
            qMenu.addAction('disable', self.disableSelected)
            qMenu.addAction('enable', self.enableSelected)

            qMenu.addSeparator()

            # mirror selected
            def _mirrorSelectedLimbs(bRec=False, bToSelected=False):
                qItems = self.qtTree.selectedItems()
                qMirror = []
                for qI in qItems:
                    ddData = qI.data(0, QtCore.Qt.UserRole)
                    if ddData and ddData['sType'] == 'instance':
                        if bRec:
                            qMirror += self.getAllLimbs(qI)
                        else:
                            qMirror.append(qI)
                if not bToSelected:
                    self.mirrorLimbs(qMirror)
                else:
                    dAllLimbs = self.getAllLimbs(bReturnDict=True)
                    qOtherLimbs = []
                    for qI in qMirror:
                        sI = qI.text(0)
                        sOtherI = utils.getMirrorName(sI)
                        qOtherI = dAllLimbs.get(sOtherI, None)
                        if qOtherI:
                            qOtherLimbs.append(qOtherI)

                    self.mirrorLimbs(qOtherLimbs)


            def _selectXformsWithTag(sTag, sParent=None):
                qItems = self.qtTree.selectedItems()
                sLimbNames = []
                for qI in qItems:
                    ddData = qI.data(0, QtCore.Qt.UserRole)
                    if ddData and ddData['sType'] == 'instance':
                        dArgs = ddData['dArgsFILE']
                        sLimbNames.append(str('%s_%s' % (dArgs['sSide'], dArgs['sName'])))

                sSelect = []
                for sT in cmds.ls(et='transform') + cmds.ls(et='joint'):
                    sAttr = '%s.%s' % (sT, sTag)
                    if cmds.objExists(sAttr):
                        sLimbNameGet = cmds.getAttr(sAttr)
                        if sLimbNameGet in sLimbNames:
                            sSelect.append(sT)

                if sParent:
                    sNodesUnderParent = cmds.listRelatives(sParent, ad=True) or []
                    sSelect = list(set(sNodesUnderParent).intersection(set(sSelect)))

                if sSelect:
                    cmds.select(sSelect)
                else:
                    cmds.warning('no xforms found for %s' % ', '.join(sLimbNames))

            qMirrorMenu = qMenu.addMenu('mirror')
            qMirrorMenu.addAction('mirror from selected', lambda:_mirrorSelectedLimbs(False))
            qMirrorMenu.addAction('mirror from selected (recursive)', lambda:_mirrorSelectedLimbs(True))
            qMirrorMenu.addAction('mirror from opposite', lambda:_mirrorSelectedLimbs(False, True))
            qMirrorMenu.addAction('mirror from opposite (recursive)', lambda:_mirrorSelectedLimbs(True, True))

            qSelectMenu = qMenu.addMenu('select in scene')
            qSelectMenu.addAction('select blueprint controls', lambda: _selectXformsWithTag('sBlueprintCtrl'))
            qSelectMenu.addAction('select blueprint joints', lambda: _selectXformsWithTag('sBlueprintJoint'))
            qSelectMenu.addAction('select joints', lambda: _selectXformsWithTag('sLimbJoint', sParent='skeleton'))
            qSelectMenu.addAction('select ctrls', lambda: _selectXformsWithTag('sLimbCtrl'))


            #duplicate
            # def duplicateLimb(qInLimb, qtTree):
            #     self.nd = DuplicateUI(self, qInLimb, self.qtWindow)
            #     self.nd.show()
            # qMenu.addAction('duplicate', lambda:duplicateLimb(qLimb,self.qtTree))

            # custom static functions
            dCustomFunctions = defaultdict(list)
            for _qI in qSelItems:
                ddData = _qI.data(0, QtCore.Qt.UserRole)
                LLimb = puppetDataUtils.limbsFromFiles()[ddData['sClassTypeFILE']][ddData.get('iVersionFILE', -1)]
                members = inspect.getmembers(LLimb)

                for member in members:
                    if member[0].startswith('rightClickCommand_'):
                        def _action(func=member[1], _ddData=ddData, __qI=_qI):
                            dArgs = {'ddData':_ddData}
                            if 'qLimb' in inspect.getfullargspec(func)[0]:
                                dArgs['qLimb'] = __qI

                            try:
                                bChangedPuppetSettings = func(**dArgs)
                                if bChangedPuppetSettings:
                                    self.dirtySaveButton()
                            except Exception as e:
                                sError = traceback.format_exc()
                                sError = 'Static Function Error: %s' % sError
                                report.report.clearLogText()
                                report.report.addLogText(sError, sColor=utils.uiColors.red, bQuotationsToLink=True)
                                report.report.setProgressBarColor(utils.uiColors.red)
                                report.report.setToFull()
                                raise Exception(traceback.format_exc())

                            self.tAttrControl.refresh()

                        sActionName = utils.beautifyVariableName(member[0][len('rightClickCommand_'):])
                        dCustomFunctions[sActionName].append(_action)
            for sFunc, funcActions in dCustomFunctions.items():
                def _allActions(funcActions=funcActions):
                    [func() for func in funcActions]
                    import kangarooTools.patch as patch
                    patch.iMissingInfluencesForNext = None
                qMenu.addAction('CUSTOM: %s' % sFunc, _allActions)

            qMenu.addSeparator()

            def printInfo(qSelItem):
                print('data: ', qSelItem.data(0, QtCore.Qt.UserRole))
            qMenu.addAction('___print info___', lambda:printInfo(qSelItems[0]))

            def goToFile(qSelItem):
                dData = qSelItem.data(0, QtCore.Qt.UserRole)
                iVersionFILE = dData['iVersionFILE']
                sClassTypeFILE = dData['sClassTypeFILE']
                sFilePath = os.path.join(puppetDataUtils.kLimbsPath, '%s%s_v%d.py' % (sClassTypeFILE[1].lower(), sClassTypeFILE[2:], iVersionFILE))
                print ('sFile: ', sFilePath)
                utils.openPycharm(sFilePath)



            qMenu.addAction('___to go python file___', lambda:goToFile(qSelItems[0]))
            qMenu.addSeparator()
            qMenu.addAction('select from scene', _selectFromScene)


        qMenu.addSeparator()
        qCopy = qMenu.addAction('copy \t\tCTRL+C', self.copy)
        if not qSelItems:
            qCopy.setEnabled(False)
        qPaste = qMenu.addAction('paste \t\tCTRL+P', self.paste)
        sClipboard = clipboard.get()
        if not sClipboard or not sClipboard.startswith('kangarooLimb.'):
            qPaste.setEnabled(False)
        qMenu.addSeparator()

        if qSelItems:
            def documentation():
                dData = qSelItems[0].data(0, QtCore.Qt.UserRole)
                sType = dData['sClassTypeFILE']
                print ('sType: ', sType)
                if sType in dLimbDocuments:
                    sLink = dLimbDocuments[sType]
                    webbrowser.open(sLink)
                else:
                    cmds.confirmDialog(m='No Documentation found for "%s"' % sType)

            qDocumentationAction = qMenu.addAction('Go to Documentation..', documentation)
            utilsQt.makeActionItalic(qDocumentationAction)
            qMenu.addSeparator()


        qMenu.exec_(self.qtTree.mapToGlobal(vPos))
        return qMenu



    def switchLimbsInAllAttacherOutputs(self, sOldName, sNewName):
        for qL in self.getAllLimbs():
            ddD = qL.data(0, QtCore.Qt.UserRole)
            sAttachers = puppetDataUtils.getAllAttachers(ddD, bAddSplittedAttachers=True)
            for sA in sAttachers:
                sOutputs = ddD['%s.sOutputsFILE' % sA]
                for o, sOutput in enumerate(sOutputs):
                    sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                    if sL == sOldName:
                        sOutputs[o] = '%s@%s@%s' % (sNewName, sO, sN)
            qL.setData(0, QtCore.Qt.UserRole, ddD)



    def updateLimbName(self, qLimb, bUpdateConnections=False):
        try:
            bBlockSignalStateBefore = self.qtTree.signalsBlocked()
            if not bBlockSignalStateBefore:
                self.qtTree.blockSignals(True)

            sOldName = qLimb.text(0)
            ddData = qLimb.data(0, QtCore.Qt.UserRole)
            dArgs = ddData['dArgsFILE']
            # print 'dArgs in the update limb name: ', dArgs
            sNewName = '%s_%s' % (dArgs['sSide'], dArgs['sName'])
            # print 'and the new name is: %s' % sNewName
            qLimb.setText(0, sNewName)

            sUniqueName = self.makeUniqueName(qLimb)
            if sNewName != sUniqueName:
                sNewName = sUniqueName

            if bUpdateConnections:
                self.switchLimbsInAllAttacherOutputs(sOldName, sNewName)
        except:
            raise
        finally:
            if not bBlockSignalStateBefore:
                self.qtTree.blockSignals(False)

        return sNewName


    def _setStatusFont(self, qLimbItem, bDisabled=False):
        if bDisabled:
            qLimbItem.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.darkBlue)))
            qLimbItem.setFont(0, qItalic)
        else:
            qLimbItem.setForeground(0,QtGui.QBrush(QtGui.QColor(utils.uiColors.blue)))
            qLimbItem.setFont(0, qInstanceFont)



    def addLimbToUI(self, dLimbClasses, dFileData={}, qReplaceItem=None, qParentUnderLimb=None):
        iVersion = dFileData.get('iVersionFILE', list(dLimbClasses.keys())[-1])

        # if dFileData: # give a better error if trying to limbs with old versions that got deleted in kangaroo
        dArgsForVersionCheck = dFileData.get('dArgsFILE', None)
        if dArgsForVersionCheck:
            sName = '%s_%s' % (dArgsForVersionCheck['sSide'], dArgsForVersionCheck['sName'])
            if iVersion not in dLimbClasses:
                raise Exception('Limb "%s" missing version %d ("%s")' % (dFileData['sClassTypeFILE'], iVersion, sName))

        TLimbClass = dLimbClasses[iVersion]
        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)
        self.qRoot = self.qtTree.invisibleRootItem()
        if qReplaceItem:
            qLimbItem = qReplaceItem
        else:
            qLimbItem = QtWidgets.QTreeWidgetItem(qParentUnderLimb if qParentUnderLimb else self.qRoot)

        dNewLimbData = {'sType':'instance', 'sClassTypeFILE':utils.getClassNameFromClass(TLimbClass), 'iVersionFILE':iVersion, 'iVersions':list(dLimbClasses.keys())}
        tLimb, dMergedData = puppetDataUtils.mergeClassWithData(TLimbClass, dFileData=dFileData)
        dNewLimbData.update(dMergedData)

        qLimbItem.changeList = []

        self._setStatusFont(qLimbItem, bDisabled=dFileData.get('bDisabledFILE', False))

        qLimbItem.setFont(1, qTypeFont)

        qLimbItem.setFlags(qLimbItem.flags() | QtCore.Qt.ItemIsEditable)

        qLimbItem.setExpanded(dFileData.get('bExpandedFILE', True ))

        qLimbItem.setData(0, QtCore.Qt.UserRole, dNewLimbData)

        self.addVersionBox(qLimbItem)

        self.updateLimbName(qLimbItem)

        if not bSignalsBlockedBefore:
            self.qtTree.blockSignals(False)

        return qLimbItem


    def addVersionBox(self, qLimbItem):
        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)
        try:
            ddData = qLimbItem.data(0, QtCore.Qt.UserRole)
            iVersions = list(ddData['iVersions'])
            qLimbItem.qVersion = puppetAttrItems.QNoWheelComboBox(self.qtTree)

            self.qtTree.setItemWidget(qLimbItem, 1, qLimbItem.qVersion)
            qLimbItem.qVersion.setStyleSheet('background:transparent; ')

            for iV in iVersions:
                qLimbItem.qVersion.addItem('v%d' % iV)
            iCurrentVersion = ddData.get('iVersionFILE', iVersions[-1])
            iVersionIndex = iVersions.index(iCurrentVersion)
            qLimbItem.qVersion.setCurrentIndex(iVersionIndex)

            def userVersionChange(iIndex, qItem = qLimbItem):
                ddData = qLimbItem.data(0, QtCore.Qt.UserRole)
                # iIndex = qLimbItem.qVersion.currentIndex()
                utils.debugPrint('ddData: ', ddData)
                iVersion = ddData['iVersions'][iIndex]
                ddData['iVersionFILE'] = iVersion
                tLimb = puppetDataUtils.limbsFromFiles()[ddData['sClassTypeFILE']][iVersion]
                _, dMergedData = puppetDataUtils.mergeClassWithData(tLimb, dFileData=ddData)
                ddData.update(dMergedData)
                qItem.setData(0, QtCore.Qt.UserRole, ddData)

            qLimbItem.qVersion.currentIndexChanged.connect(userVersionChange)
        except:
            raise
        finally:
            if not bSignalsBlockedBefore:
                self.qtTree.blockSignals(False)

    def allVersionsUp(self):
        qLimbs = self.getAllLimbs()
        bChangedSomething = False
        report.report.addLogText('')
        for qL in qLimbs:

            iOldVersion = qL.qVersion.currentIndex()
            iCount = qL.qVersion.count()
            iNewVersion = iCount - 1

            if iNewVersion != iOldVersion:
                sVersions = [qL.qVersion.itemText(i) for i in range(qL.qVersion.count())]
                qL.qVersion.setCurrentIndex(iCount-1)

                sType = qL.data(0, QtCore.Qt.UserRole)['sClassTypeFILE']
                report.report.addLogText(f'{qL.text(0)} ({sType}):\t\t\t {sVersions[iOldVersion]} -> {sVersions[iNewVersion]}')
                bChangedSomething = True


        report.report.addLogText('')


        if bChangedSomething:
            self.dirtySaveButton()
        else:
            report.report.addLogText('\n --- nothing changed ---\n')

        return bChangedSomething


    def getUniqueName(self, qLimb):
        sAllLimbs = [qL.text(0) for qL in self.getAllLimbs()]
        sFullName = qLimb.text(0)
        sAllLimbs.remove(sFullName)
        if sFullName not in sAllLimbs:
            return sFullName

        return utils.getUniqueNameFromList(sFullName, sAllLimbs, bCheckCapitalEnding=True)


    def makeUniqueName(self, qLimb):
        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)


        try:
            sNewName = self.getUniqueName(qLimb)
            sOldName = qLimb.text(0)
            if sNewName != sOldName:
                sSide, sName = sNewName.split('_')
                ddLimbData = qLimb.data(0, QtCore.Qt.UserRole)
                dArgs = ddLimbData['dArgsFILE']
                dArgs['sName'] = sName
                qLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
                qLimb.setText(0, sNewName)
            bSuccess=True
        except:
            bSuccess=False
            raise
        finally:
            self.qtTree.blockSignals(bSignalsBlockedBefore)
            if bSuccess:
                return sNewName


    def removeInvalidOutputsFromAllLimbsToLimbs(self, qLimbsToDelete=[]):
        sLimbsToDelete = [qL.text(0) for qL in qLimbsToDelete]
        sLimbsApproved = set(sLimbsToDelete)

        dAllLimbs = self.getAllLimbs(bReturnDict=True)
        bUserSaysAlwaysContinue = False


        # first run - check
        #
        for sLimb, qLimb in list(dAllLimbs.items()):
            if sLimb in sLimbsToDelete:
                continue
            ddData = qLimb.data(0, QtCore.Qt.UserRole)
            sAttachers = puppetDataUtils.getAllAttachers(ddData, bAddSplittedAttachers=True)
            for sA in sAttachers:
                sOutputs = ddData['%s.sOutputsFILE' % sA]
                if sOutputs:
                    for o, sOutput in enumerate(sOutputs):
                        sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                        if sL in sLimbsApproved:
                            if bUserSaysAlwaysContinue:
                                sButtonReturn = 'Continue'
                            else:
                                sButtonReturn = cmds.confirmDialog(m='Need to remove Connection: "%s" -> %s.\nContinue?' % (sLimb, sOutputs[o]),
                                                                    button=['Continue', 'Always Continue', 'Skip Deleting %s' % sL, 'Skip All'])

                            if sButtonReturn == 'Skip All':
                                return []
                            elif sButtonReturn.startswith('Skip'):
                                sLimbsApproved.remove(sL)
                                break
                            else:
                                if sButtonReturn == 'Always Continue':
                                    bUserSaysAlwaysContinue = True
                                sOutputs[o] = None

        # second run - check if non approved one have connections to approved ones
        #

        sLeftOverLimbs = set(sLimbsToDelete) - sLimbsApproved
        for sLimb in sLeftOverLimbs:
            qLimb = dAllLimbs[sLimb]

            ddData = qLimb.data(0, QtCore.Qt.UserRole)
            sAttachers = puppetDataUtils.getAllAttachers(ddData, bAddSplittedAttachers=True)
            for sA in sAttachers:
                sOutputs = ddData['%s.sOutputsFILE' % sA]
                if sOutputs:
                    for o, sOutput in enumerate(sOutputs):
                        sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                        if sL in sLimbsApproved:
                            cmds.confirmDialog(m=f'Aborting! We are trying to delete "{sL}", but not "{sLimb}". And those have connections ({sOutput})')
                            return []

        # third run - cut the connections
        #
        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)
        try:
            for sLimb, qLimb in list(dAllLimbs.items()):
                if sLimb in sLimbsToDelete:
                    continue

                ddData = qLimb.data(0, QtCore.Qt.UserRole)
                sAttachers = puppetDataUtils.getAllAttachers(ddData, bAddSplittedAttachers=True)
                for sA in sAttachers:
                    sOutputs = ddData['%s.sOutputsFILE' % sA]
                    if sOutputs:
                        for o, sOutput in enumerate(sOutputs):
                            sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                            if sL in sLimbsApproved:
                                sOutputs[o] = None

                        ddData['%s.sOutputsFILE' % sA] = [sO for sO in sOutputs if sO != None]

                qLimb.setData(0, QtCore.Qt.UserRole, ddData)

        except:
            raise
        finally:
            self.qtTree.blockSignals(bSignalsBlockedBefore)

        return [qL for qL in qLimbsToDelete if qL.text(0) in sLimbsApproved]




    def removeInvalidOutputsOfAllLimbs(self):
        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)
        report.report.addLogText('')
        try:
            dAllLimbs = self.getAllLimbs(bReturnDict=True)
            bChangedSomething = False
            for sLimb, qLimb in list(dAllLimbs.items()):
                sLimbsWithValidOutputs = list(self.getAllLimbsWithValidOutputs(qLimb, bReturnDict=True).keys()) + [utils.kNoneString, utils.kCustomString]
                ddData = qLimb.data(0, QtCore.Qt.UserRole)
                sAttachers = puppetDataUtils.getAllAttachers(ddData, bAddSplittedAttachers=True)
                for sA in sAttachers:
                    sOutputs = ddData['%s.sOutputsFILE' % sA]
                    if sOutputs:
                        if not sLimbsWithValidOutputs: # TODO: remove this if it hasn't caused issues after a few months
                            cmds.confirmDialog(m='not supported')
                            raise Exception('not supported')
                            ddData['%s.sOutputsFILE' % sA] = []
                            bChangedSomething = True
                            sInvalidOutputsString = ', '.join(['"%s"' % o for o in sOutputs])
                            report.report.addLogText('REMOVED CONNECTIONS of "%s", because outputs %s became invalid for that limb' % (sLimb, sInvalidOutputsString))
                        else:
                            for o, sOutput in enumerate(sOutputs):
                                sL, sO, sN, fW = utils.extractOutputInfo(sOutput)
                                if sL not in sLimbsWithValidOutputs:
                                    report.report.addLogText('REMOVED CONNECTION from "%s": %s, it became invalid for that limb' % (sLimb, sOutputs[o]))
                                    sOutputs[o] = None
                                    bChangedSomething = True
                            ddData['%s.sOutputsFILE' % sA] = [sO for sO in sOutputs if sO != None]
                qLimb.setData(0, QtCore.Qt.UserRole, ddData)
        except:
            raise
        finally:
            self.qtTree.blockSignals(bSignalsBlockedBefore)

        if bChangedSomething:
            self.dirtySaveButton()

        report.report.addLogText('')
        return bChangedSomething


    def dropToLimbsEvent(self, event):
        bSignalsBlockedBefore = self.qtTree.signalsBlocked()
        self.qtTree.blockSignals(True)

        qSourceItems = event.source().selectedItems()

        ddData0 = qSourceItems[0].data(0, QtCore.Qt.UserRole) # because we can only move one type at a time
        sType = ddData0['sType']
        if sType == 'class': # moving from LimbList
            iColumn = event.source().currentColumn()
            ddLimbListData0 = qSourceItems[0].data(iColumn, QtCore.Qt.UserRole)
            self.qtTree.superDropEvent(event)

            qDestItem = self.qtTree.findItems(qSourceItems[0].text(iColumn), QtCore.Qt.MatchExactly | QtCore.Qt.MatchRecursive)[0]

            dLimb = puppetDataUtils.limbsFromFiles()[ddLimbListData0['sClassType']]

            qLimb = self.addLimbToUI(dLimb, qReplaceItem = qDestItem)
            self.makeUniqueName(qLimb)
            self.setAutoParentOutput(qLimb)
            if qLimb.parent():
                qLimb.parent().setExpanded(True)
            self.dirtySaveButton()

        elif sType == 'instance': # moving around limbs inside charList
            # print '\n\n\n\ngot moved'
            event.setDropAction(QtCore.Qt.MoveAction)
            self.qtTree.superDropEvent(event)
            for qSourceI in qSourceItems:
                self.setAutoParentOutput(qSourceI)
            self.removeInvalidOutputsOfAllLimbs()
            self.qtTree.clearSelection()

            for qSourceI in qSourceItems:
                qSourceI.setSelected(True)
                self.addVersionBox(qSourceI)
            self.tAttrControl.refresh()
            self.dirtySaveButton()

        self.qtTree.blockSignals(bSignalsBlockedBefore)




    def setAutoParentOutput(self, qLimb):

        qNewParent = qLimb.parent()

        ddData = qLimb.data(0, QtCore.Qt.UserRole)

        sScaleParents = ['m_head', 'm_cog', 'm_global', 'm_placement']

        if qNewParent:
            lParentLimb = puppetDataUtils.instantiateLimb(qNewParent.data(0, QtCore.Qt.UserRole))
            sParentLimb = qNewParent.text(0)
            sParentOutput = lParentLimb.getDefaultParentOutput()
            ddData['parentOutputFILE'] = sParentOutput


            sScaleParentLimb = None
            qScaleNewParent = qNewParent
            for i in range(10):
                if isinstance(qNewParent, type(None)):
                    qScaleNewParent = None
                    break
                sName = qNewParent.text(0)
                if sName in sScaleParents:
                    sScaleParentLimb = sName
                    break

                qNewParent = qScaleNewParent.parent()
                if not qNewParent:
                    sScaleParentLimb = qScaleNewParent.text(0)
                else:
                    qScaleNewParent = qNewParent

            sAttacherNames = ['root']

            if not isinstance(qScaleNewParent, type(None)):
                lScaleParentLimb = puppetDataUtils.instantiateLimb(qScaleNewParent.data(0, QtCore.Qt.UserRole))
                sScaleParentOutput = lScaleParentLimb.getDefaultParentOutput()
                sAttacherNames.append('scale')

            sAttachers = puppetDataUtils.getAllAttachers(ddData, bAddSplittedAttachers=True)
            # print 'sAttachers: ', sAttachers
            sAutoSetAttachers = set(sAttachers).intersection(set(sAttacherNames))

            for sA in sAutoSetAttachers:
                sOutputs = ddData['%s.sOutputsFILE' % sA]
                bAlreadyConnected = False
                for sO in sOutputs:
                    if sO.startswith(sParentLimb):
                        bAlreadyConnected = True
                if not bAlreadyConnected:
                    if sA == 'root':
                        sOutputs.insert(0, '%s@%s' % (sParentLimb, sParentOutput))
                    elif sA == 'scale':
                        if sScaleParentLimb:
                            sOutputs.insert(0, '%s@%s' % (sScaleParentLimb, sScaleParentOutput))
                    else:
                        raise Exception('don\'t know what %s is' % sA)

                    if len(sOutputs) > 1:
                        sOutputs = sOutputs[:1]
                ddData['%s.sOutputsFILE' % sA] = sOutputs

        else:
            ddData['parentOutputFILE'] = None


        qLimb.setData(0, QtCore.Qt.UserRole, ddData)






