###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import numpy as np
import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import kangarooTools.utilsQt as utilsQt

QtWidgets, QtGui, QtCore = utils.importQtModules()


import kangarooTools.report as report
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.weights as weights
qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)

_kRowHeight = utilsQt.getDpi() / 4



qMouthPaintUI = None
def openMouthPaintUI():
    global qMouthPaintUI
    qMouthPaintUI = QMouthPaintUI()
    qMouthPaintUI.show()


QtWidgets, QtGui, QtCore = utils.importQtModules()


class QMouthPaintUI(QtWidgets.QDialog):

    def __init__(self):
        super(QMouthPaintUI, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)

        self.setWindowTitle('Face Skinning')


        import kangarooTools.utilsQt as utilsQt
        utils.reload2(utilsQt)

        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        qJointLoopsLayout = utilsQt.createGroupBoxLayout(layout, 'Joint Loops')
        self.qRowBlend = utilsQt.createFloatSlider(qJointLoopsLayout, 'Blend', 0.0, 1.0, 1.0)
        self.qRigidLoops = self._addField(qJointLoopsLayout, 'rigid loops', '2')
        self.qFadeLoops = self._addField(qJointLoopsLayout, 'fade loops', '2')
        self.qTopPerc = self._addField(qJointLoopsLayout, 'top perc', '1.0')
        self.qCornerPerc = self._addField(qJointLoopsLayout, 'corner perc', '1.0')
        self.qBotPerc = self._addField(qJointLoopsLayout, 'bot perc', '1.0')
        self.qLockCheeks = QtWidgets.QCheckBox('lock cheeks')
        qJointLoopsLayout.addWidget(self.qLockCheeks)

        # Add to Big/Small
        qAddToRowsLayout = QtWidgets.QHBoxLayout()
        qJointLoopsLayout.addLayout(qAddToRowsLayout)
        qAddToBigJoints = QtWidgets.QPushButton('Add to BigJoints')
        qAddToBigJoints.clicked.connect(lambda: self.addToRowJoints(bBig=True))
        qJointLoopsLayout.addWidget(qAddToBigJoints)
        qAddToRowsLayout.addWidget(qAddToBigJoints)
        qAddToSmallJoints = QtWidgets.QPushButton('Add to SmallJoints')
        qAddToSmallJoints.clicked.connect(lambda: self.addToRowJoints(bBig=False))
        qAddToRowsLayout.addWidget(qAddToSmallJoints)

        # Distribute Big/Small
        qAddToRowsLayout = QtWidgets.QHBoxLayout()
        qJointLoopsLayout.addLayout(qAddToRowsLayout)
        qAddToBigJoints = QtWidgets.QPushButton('Distribute BigJoints')
        qAddToBigJoints.clicked.connect(lambda: self.addToRowJoints(bBig=True, bDistribute=True))
        qJointLoopsLayout.addWidget(qAddToBigJoints)
        qAddToRowsLayout.addWidget(qAddToBigJoints)
        qAddToSmallJoints = QtWidgets.QPushButton('Distribute SmallJoints')
        qAddToSmallJoints.clicked.connect(lambda: self.addToRowJoints(bBig=False, bDistribute=True))
        qAddToRowsLayout.addWidget(qAddToSmallJoints)

        qMoveLayout = utilsQt.createGroupBoxLayout(layout, 'Move Weights')

        # self.qMoveStrength = self._addField(qMoveLayout, 'Move Strength', '1.0')
        self.qMoveStrength = utilsQt.createFloatSlider(qMoveLayout, 'Move Strength', 0.0, 1.0, 1.0)
        for sButton, func in [('move big/small back to head/jaw', self.backToHeadJaw),
                              ('move lipsEnd back to jaw/head', lambda: self.moveWeights({'jnt_l_lipsEnd': 'jnt_m_headMain;jnt_m_jawMain', 'jnt_r_lipsEnd': 'jnt_m_headMain;jnt_m_jawMain'})),
                              ('move small to big joints', lambda: self.moveWeights({'*MouthSplineSmall*': 'Small,Big'})),
                              ('move big to small joints', lambda: self.moveWeights({'*MouthSplineBig*': 'Big,Small'})),
                              ('move head/jaw to lipEnds', self.headJawToLipsEnd),
                              ('move lipEnds to head',  lambda: self.moveWeights({"['jnt_l_lipsEnd', 'jnt_r_lipsEnd']": 'jnt_m_headMain'})),
                              ('move head/jaw/lipsEnd to cheeks', lambda: self.moveWeights({"['jnt_m_headMain', 'jnt_m_jawMain', 'jnt_l_lipsEnd']": 'jnt_l_cheek_???'})),
                              ('move big to small joints', lambda: self.moveWeights({'*MouthSplineBig*': 'Big,Small'})),
                              ('move head to jaw', lambda: self.moveWeights({'jnt_m_headMain': 'jnt_m_jawMain'})),
                              ('move jaw to head', lambda: self.moveWeights({'jnt_m_jawMain': 'jnt_m_headMain'})),
                              ('smooth', lambda: weights.smoothSkinWeights(iIterations=1)),
                              ('smooth loop', smoothLoop),
                              ('lip cubes', createLipCubes),
                              ('move head/jaw to frontPivots', lambda: self.moveWeights({'jnt_m_jawMain': 'jnt_m_mouthPivotFrontJaw', 'jnt_m_headMain':'jnt_m_mouthPivotFrontHead'})),
                              ('move frontPivots to head/jaw', lambda: self.moveWeights({'jnt_m_mouthPivotFrontJaw': 'jnt_m_jawMain', 'jnt_m_mouthPivotFrontHead':'jnt_m_headMain'})),
                              ]:
            qButton = QtWidgets.QPushButton(sButton)
            qButton.clicked.connect(func)
            qMoveLayout.addWidget(qButton)

        layout.addStretch()

    def getRowBlend(self):
        return max(0, min(1, eval(self.qRowBlend.text())))

    def getMoveStrength(self):
        return max(0, min(1, eval(self.qMoveStrength.text())))

    def backToHeadJaw(self):
        print ('back to head/jaw')
        sTopJoints = cmds.ls('jnt_?_topMouthSpline*_???', et='joint')
        sBotJoints = cmds.ls('jnt_?_botMouthSpline*_???', et='joint')
        dJoints = {sJ: 'jnt_m_headMain' for sJ in sTopJoints}
        dJoints.update({sJ: 'jnt_m_jawMain' for sJ in sBotJoints})
        weights.moveSkinClusterWeights(xJoints=dJoints, fStrength=eval(self.qMoveStrength.text()))

    def moveWeights(self, dDict):
        print('moving weights..')
        weights.moveSkinClusterWeights(None, dDict, fStrength=self.getMoveStrength())

    def addToRowJoints(self, bBig=False, bDistribute=False):
        try:
            proceduralBind_mouthSplineJoints(eval(self.qRigidLoops.text()), eval(self.qFadeLoops.text()),
                                             eval(self.qBotPerc.text()), eval(self.qCornerPerc.text()),
                                             eval(self.qTopPerc.text()), bDistribute=bDistribute,
                                             fBlend=self.getRowBlend(), bLockCheeks=self.qLockCheeks.isChecked(),
                                             sSuffix='MouthSplineBig' if bBig else 'MouthSplineSmall')
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise

    def _addField(self, layout, sName, sDefaultValue):
        qNewLayout = QtWidgets.QHBoxLayout()
        qLabel = QtWidgets.QLabel(sName)
        qNewLayout.addWidget(qLabel)

        qLineEdit = QtWidgets.QLineEdit(sDefaultValue)
        qNewLayout.addWidget(qLineEdit)
        layout.addLayout(qNewLayout)
        return qLineEdit

    def headJawToLipsEnd(self):
        print ('head/jaw to lipsEnd')
        dJoints = {'jnt_m_headMain': 'jnt_l_lipsEnd',
                   'jnt_m_jawMain': 'jnt_l_lipsEnd'}
        weights.moveSkinClusterWeights(xJoints=dJoints, fStrength=eval(self.qMoveStrength.text()),
                                       iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)


def proceduralBind_mouthSplineJoints(iFullWeightLoops, iFadeOutLoops, fBotMultipl, fCornerMultipl, fTopMultipl, fBlend=1.0, bLockCheeks=False, sSuffix='MouthSpline', bDistribute=False):

    utils.reload2(weights)
    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        cmds.undoInfo(openChunk=True)
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        sSkinCluster = 'skinCluster__%s' % (sMesh)

        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)


        sAllJoints = []
        fAllValues = []


        bIgnoreMostOut = False # probably useless...
        if bIgnoreMostOut:
            iStart = 1
            iEnd = -1
        else:
            iStart = 0
            iEnd = None

        # left top
        sDistributeJoints = []
        sJoints = ['jnt_m_top%s_000' % sSuffix] + sorted(cmds.ls('jnt_l_top%s_???' % sSuffix, et='joint'))
        sDistributeJoints.extend(sJoints)
        sJoints = [sJ for sJ in sJoints if cmds.attributeQuery('createdFromFaceRigFunction', node=sJ, exists=True)]
        fValues = utils.bSpline4([fTopMultipl, fTopMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # left bot
        sJoints = sorted(cmds.ls('jnt_l_bot%s_???' % sSuffix, et='joint'), reverse=True) + ['jnt_m_bot%s_000' % sSuffix]
        sDistributeJoints.extend(sJoints)
        sJoints = [sJ for sJ in sJoints if cmds.attributeQuery('createdFromFaceRigFunction', node=sJ, exists=True)]
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fBotMultipl, fBotMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        # right bot
        sJoints = sorted(cmds.ls('jnt_r_bot%s_???' % sSuffix, et='joint'))
        sDistributeJoints.extend(sJoints)
        sJoints = [sJ for sJ in sJoints if cmds.attributeQuery('createdFromFaceRigFunction', node=sJ, exists=True)]
        fValues = utils.bSpline4([fBotMultipl, fBotMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # right top
        sJoints = sorted(cmds.ls('jnt_r_top%s_???' % sSuffix, et='joint'), reverse=True)
        sDistributeJoints.extend(sJoints)
        sJoints = [sJ for sJ in sJoints if cmds.attributeQuery('createdFromFaceRigFunction', node=sJ, exists=True)]
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fTopMultipl, fTopMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        print('sAlLJoins: ', sAllJoints)
        print('fAllValues: ', fAllValues)

        fJointWeightings = np.array(fAllValues, dtype='float64')


        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)


        _, sOldInfluences = pMesh.getSkinCluster(sChooseSkinCluster=sSkinCluster, bSkipWeights=True)


        if bLockCheeks:
            dValuesBefore = {}
            sCheekJoints = cmds.ls('jnt_?_cheek_???', et='joint')
            for sJ in sCheekJoints:
                sAttr = '%s.liw' % sJ
                dValuesBefore[sAttr] = cmds.getAttr(sAttr)
                cmds.setAttr(sAttr, True)

        weights.bindToClosestVertexAndExpand(None, sJoints=sAllJoints, _fJointWeightings=fJointWeightings, fBlend=fBlend,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iFullWeightLoops, iExpandedFadeOutLoops=iFadeOutLoops,
                                             sChooseSkinCluster=sSkinCluster, bDistribute=bDistribute, _sDistributeJoints=sDistributeJoints,
                                             iJointLocks=patch.JointLocks.dontChangeLockedJoints if bLockCheeks else patch.JointLocks.ignore)

        if bLockCheeks:
            for sAttr,fValue in dValuesBefore.items():
                cmds.setAttr(sAttr, fValue)


        deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]
        cmds.undoInfo(closeChunk=True)

    cmds.select(sSelBefore)




def createLipCubes():

    sRedShader = 'faceLipJointsRedCubes'
    sBlueShader = 'faceLipJointsBlueCubes'

    for sShader, fColor in [(sRedShader, [1,0,0]), (sBlueShader, [0,0,1])]:
        sShader = cmds.shadingNode('lambert', asShader=True, n=sShader)
        cmds.setAttr('%s.color' % sShader, *fColor)
        cmds.setAttr('%s.transparency' % sShader, 0.5, 0.5, 0.5)

    sBigJoints = cmds.ls('jnt_?_???MouthSplineBig_???', et='joint')
    sSmallJoints = cmds.ls('jnt_?_???MouthSplineSmall_???', et='joint')

    for sJoints,sShader in [(sBigJoints, sBlueShader), (sSmallJoints, sRedShader)]:
        sCubes = []
        for sJ in sJoints:

            sCube = cmds.polyCube()[0]
            cmds.parent(sCube, sJ)
            fSize = cmds.getAttr('%s.radius' % sJ)
            cmds.setAttr('%s.t' % sCube, 0, 0, 0)
            cmds.setAttr('%s.r' % sCube, 0, 0, 0)
            cmds.setAttr('%s.s' % sCube, fSize, fSize, fSize)
            sCubes.append(sCube)

        cmds.select(sCubes)
        cmds.hyperShade(assign=sShader)



def smoothLoop():
    utils.reload2(patch)
    utils.reload2(weights)
    iLoopIds = eval(cmds.getAttr('grp_m_mouthPasser.iIdsAlongCurve'))
    weights.smoothSkinWeights(iIterations=1, sLoopCurve=iLoopIds)
