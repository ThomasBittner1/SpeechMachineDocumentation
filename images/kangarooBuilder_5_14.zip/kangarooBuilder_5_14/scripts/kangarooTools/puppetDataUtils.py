###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import importlib
import inspect
import json
import re
import sys

from collections import OrderedDict, defaultdict
import kangarooTools.utilFunctions as utils



def instantiateLimb(ddData):
    if ddData['sType'] != 'instance':
        raise Exception('instantiateLimb needs to be called on a limb item')
    TLimb = limbsFromFiles()[ddData['sClassTypeFILE']][ddData.get('iVersionFILE', -1)]
    dArgs = utils.filterArgs(ddData['dArgsFILE'], TLimb.__init__)
    return TLimb(**dArgs)


def getAllAttachers(ddData, bAddExtraInfos=False, bAddSplittedAttachers=False):
    sAllAttachers = list(ddData['sAttachers'])
    for sFunc in ddData['sFeatures']:
        sAllAttachers += ddData['%s.sAttachers' % sFunc]

    if bAddExtraInfos:
        for a,sA in enumerate(sAllAttachers):
            dPredefinedData = ddData['%s.dPredefinedData' % sA]
            sLocals = dPredefinedData.get('sLocals', [])
            sAllAttachers[a] = '%s.%s' % (sA, '.'.join(sLocals))


    if bAddSplittedAttachers:
        sSplittedAttachers = []
        for sA in sAllAttachers:
            sSplitA = sA.split('.')
            if ddData['%s.dPredefinedData' % sSplitA[0]]['sTrs'] == 'tr':
                sSplitA[0] = '%s(1)' % sSplitA[0]
                sSplittedAttachers.append('.'.join(sSplitA))
        sAllAttachers += sSplittedAttachers


    return sAllAttachers


def getAllOutputs(ddData):
    TLimbClass = limbsFromFiles()[ddData['sClassTypeFILE']][ddData.get('iVersionFILE',0)]
    tLimb, dMergedData = mergeClassWithData(TLimbClass, dFileData=ddData)
    sAllOutputs = list(tLimb.dOutputs.keys())
    sAllRemoveOutputs = []
    for sF in dMergedData['sDetails']:
        if dMergedData['%s.bCheckedFILE' % sF]:
            _, sName = sF.split('_')
            dArgs = dMergedData['%s.dArgsFILE' % sF]
            funcGenerateOutputs = getattr(tLimb, 'generateOutputs_%s' % sName)
            _sNewOutputs, _sRemoveOutputs = funcGenerateOutputs(**dArgs)
            sAllOutputs += _sNewOutputs
            sAllRemoveOutputs += _sRemoveOutputs

    for sOutput in sAllRemoveOutputs:
        if sOutput in sAllOutputs:
            iIndex = sAllOutputs.index(sOutput)
            del sAllOutputs[iIndex]

    return [sO for sO in sAllOutputs if not sO.startswith('_')]



sBaseInitArgs = None
def getBaseInitArgs():
    global sBaseInitArgs
    if sBaseInitArgs != None:
        return sBaseInitArgs
    else:
        baseLimb = limbsFromFiles()['_LBaseLimb']
        sBaseInitArgs = inspect.getfullargspec(baseLimb.__init__)[0]
        return sBaseInitArgs[1:] # because first one is self



def mergeClassWithData(TLimbClass=None, dFileData={}, dExtraData={}):
    dMergedData = {}
    dMergedData.update(dExtraData)
    dMergedData['parentOutputFILE'] = dFileData.get('parentOutputFILE', None)

    dMergedData['__parent__'] = dFileData.get('__parent__', None)
    dMergedData['bExpandedFILE'] = dFileData.get('bExpandedFILE', True) # do we need this???

    if 'iVersionFILE' in dFileData:
        dMergedData['iVersionFILE'] = dFileData['iVersionFILE']
    if 'iVersions' in dFileData:
        dMergedData['iVersions'] = dFileData['iVersions']

    allLimbs = limbsFromFiles()
    if TLimbClass == None:
        sClassType = dFileData['sClassTypeFILE']
        iVersion = dFileData.get('iVersionFILE', -1)
        TLimbClass = allLimbs[sClassType][iVersion]

    dMergedData['sClassTypeFILE'] = utils.getClassNameFromClass(TLimbClass)
    dMergedData['sType'] = 'instance'

    # __init__() attrs
    args, _, _, defaults = inspect.getfullargspec(TLimbClass.__init__)[0:4]
    dInitArgs = OrderedDict()
    dInitArgDefaults = {}
    dFileLimb = {}
    sTuples = set()

    dComboboxItems = {}
    dInterpolateBehavior = {}
    if len(args) > 1:
        for arg, default in zip(args[1:], defaults):
            if arg.startswith('_'):
                if arg == '_dComboboxItems':
                    dComboboxItems = default
                elif arg == '_dInterpolateBehavior':
                    dInterpolateBehavior = default
                continue
            value = dFileLimb.get(arg, default)
            dInitArgs[arg] = value
            dInitArgDefaults[arg] = default
            if isinstance(default, tuple):
                sTuples.add(arg)


    dInitArgs.update(dFileData.get('dArgsFILE', {}))
    dFilteredInitArgs = utils.filterArgs(dInitArgs, TLimbClass.__init__)
    dMergedData['dArgsFILE'] = dFilteredInitArgs
    dMergedData['bDisabledFILE'] = dFileData.get('bDisabledFILE', False)
    dMergedData['dArgDefaults'] = dInitArgDefaults
    dMergedData['sArgsShow'] = [a for a in args[1:] if not a.startswith('_')]
    dMergedData['dComboboxItems'] = dComboboxItems
    dMergedData['dInterpolateBehavior'] = dInterpolateBehavior

    tLimb = TLimbClass(**dFilteredInitArgs)

    # attachers:
    try:
        funcGenerateAttachers = getattr(tLimb, 'generateAttachers_init')
    except:
        funcGenerateAttachers = None
    dFiltereFeaturedInitArgs = utils.filterArgs(dFilteredInitArgs, funcGenerateAttachers)
    dAttachers = funcGenerateAttachers(**dFiltereFeaturedInitArgs)
    sAttachersSorted = list(dAttachers.keys())
    sAttachersSorted.sort()

    dMergedData['sAttachers'] = sAttachersSorted
    for sA, dD in list(dAttachers.items()):
        dMergedData['%s.dPredefinedData' % sA] = dD
        dMergedData['%s.sOutputsFILE' % sA] = dFileData.get('%s.sOutputsFILE' % sA, [])
        dMergedData['%s(1).sOutputsFILE' % sA] = dFileData.get('%s(1).sOutputsFILE' % sA, [])
        dMergedData['%s.dLocalOutputsFILE' % sA] = dFileData.get('%s.dLocalOutputsFILE' % sA, {})
        dMergedData['%s.bDoBlendFILE' % sA] = dFileData.get('%s.bDoBlendFILE' % sA, False)
        dMergedData['%s(1).bDoBlendFILE' % sA] = dFileData.get('%s(1).bDoBlendFILE' % sA, False)
        dMergedData['%s.bSplitFILE' % sA] = dFileData.get('%s.bSplitFILE' % sA, False)

    dMergedData['sStartFeatureFILE'] = dFileData.get('sStartFeatureFILE', None)

    sDefaultFeatures = tLimb.sDefaultFeatures
    for sFunc in ['feature', 'detail']:
        sStringKey = 's%s%ss' % (sFunc[0].upper(), sFunc[1:]) # 'sFeatures', sDetails'
        sFunctions = [sF for sF in dir(TLimbClass) if sF.startswith('%s_' % sFunc)]
        dMergedData[sStringKey] = sFunctions
        for sF in sFunctions:
            bDefaultChecked = True if sF in sDefaultFeatures else False
            dMergedData['%s.bCheckedFILE' % sF] = dFileData.get('%s.bCheckedFILE' % sF, bDefaultChecked)
            _, sFeatureName = sF.split('_')
            dArgs = OrderedDict()
            dArgDefaults = {}

            fFunc = getattr(tLimb, sF)
            args, _, _, defaults = inspect.getfullargspec(fFunc)[0:4]

            dComboboxItems = {}
            dInterpolateBehavior = {}
            if len(args) > 1:
                for arg, default in zip(args[1:], defaults):
                    if arg.startswith('_'):
                        if arg == '_dComboboxItems':
                            dComboboxItems = default
                        elif arg == '_dInterpolateBehavior':
                            dInterpolateBehavior = default
                        continue
                    value = default
                    dArgs[arg] = value
                    dArgDefaults[arg] = default
                    if isinstance(default, tuple):
                        sTuples.add(arg)


            dArgs.update(dFileData.get('%s.dArgsFILE' % sF, {}))
            dMergedData['%s.dComboboxItems' % sF] = dComboboxItems
            dMergedData['%s.dInterpolateBehavior' % sF] = dInterpolateBehavior
            dMergedData['%s.dArgsFILE' % sF] = dArgs
            dMergedData['%s.dArgDefaults' % sF] = dArgDefaults
            dMergedData['%s.sArgsShow' % sF] = [a for a in args[1:] if not a.startswith('_')]

            if sFunc == 'feature':
                try:
                    funcGenerateAttachers = getattr(tLimb, 'generateAttachers_%s' % sFeatureName)
                except:
                    funcGenerateAttachers = None
                if funcGenerateAttachers:
                    dFilteredArgs = dArgs# because we already use the ** utils.filterArgs(dArgs, funcGenerateAttachers)
                    dAttachers = funcGenerateAttachers(**dFilteredArgs)
                else:
                    dAttachers = {}
                sAttachersSorted = list(dAttachers.keys())
                sAttachersSorted.sort()

                dMergedData['%s.sAttachers' % sF] = sAttachersSorted
                for sA, dD in list(dAttachers.items()):
                    dMergedData['%s.dPredefinedData' % sA] = dD
                    dMergedData['%s.sOutputsFILE' % sA] = dFileData.get('%s.sOutputsFILE' % sA, [])
                    dMergedData['%s(1).sOutputsFILE' % sA] = dFileData.get('%s(1).sOutputsFILE' % sA, [])
                    dMergedData['%s.dLocalOutputsFILE' % sA] = dFileData.get('%s.dLocalOutputsFILE' % sA, {})
                    dMergedData['%s.bDoBlendFILE' % sA] = dFileData.get('%s.bDoBlendFILE' % sA, False)
                    dMergedData['%s(1).bDoBlendFILE' % sA] = dFileData.get('%s(1).bDoBlendFILE' % sA, False)
                    dMergedData['%s.bSplitFILE' % sA] = dFileData.get('%s.bSplitFILE' % sA, False)
                    # print 'get: ', dD,  dFileData.get('%s.sOutputsFILE' % sA, [])

    dMergedData['sTuples'] = sTuples
    sChildrenConnectFunctions = [sF for sF in dir(TLimbClass) if sF.startswith('childrenConnect_')]
    dMergedData['sChildrenConnects'] = sChildrenConnectFunctions

    return tLimb, dMergedData



dLimbLibrary = None
kLimbsPath = os.path.join(utils.getScriptsDir(), 'kangarooLimbs')
kCustomLimbsPath = os.environ.get('KANGAROO_EXTRALIMBS_PATH', '') if 'KANGAROO_EXTRALIMBS_PATH' in os.environ else None
def limbsFromFiles(bReload=False):
    global dLimbLibrary

    if dLimbLibrary and not bReload:
        return dLimbLibrary

    else:
        dLimbLibrary = defaultdict(list)

        baseLimb = importlib.import_module('kangarooLimbs.baseLimb')
        utils.reload2(baseLimb)

        if kCustomLimbsPath and kCustomLimbsPath not in sys.path:
            print ('appending "%s" to sys.path' % kCustomLimbsPath)
            sys.path.append(kCustomLimbsPath)

        xModules = [(sFile.split('.')[0], False) for sFile in os.listdir(kLimbsPath) if sFile.endswith('.py') and '_v' in sFile]
        if kCustomLimbsPath:
            xCustomLimbs = [(sFile.split('.')[0], True) for sFile in os.listdir(kCustomLimbsPath) if sFile.endswith('.py') and '_v' in sFile]
            xModules += xCustomLimbs

        for sModule, bCustom in xModules:
            sVersion = sModule.split('_')[-1]
            iVersion = utils.getNumberAtEnd(sVersion)[1]
            if bCustom:
                modModule = importlib.import_module(sModule)
            else:
                modModule = importlib.import_module('kangarooLimbs.%s' % sModule)

            if sModule != 'baseLimb':
                utils.reload2(modModule)
            for name, attr in inspect.getmembers(modModule):
                if inspect.isclass(attr):
                    if baseLimb._LBaseLimb in attr.__bases__ or attr == baseLimb._LBaseLimb:
                        dLimbLibrary[name].append([iVersion, attr])

        for sName in list(dLimbLibrary.keys()):
            sSorted = sorted(dLimbLibrary[sName], key=lambda a:a[0])
            dLimbLibrary[sName] = OrderedDict()
            for v,l in sSorted:
                dLimbLibrary[sName][v] = l

        dLimbLibrary['_LBaseLimb'] = baseLimb._LBaseLimb

        # to make the mergeData function regather the sBaseInitArgs:
        global sBaseInitArgs
        sBaseInitArgs = None

        return dLimbLibrary



def getLimbStatusesInHierarchy(dLimbs, dLimbLibrary={}, bReverse=False):
    dChildren = defaultdict(list)

    for xFileData in dLimbs:
        sLimbClass = xFileData['sClassTypeFILE']
        iVersion = xFileData['iVersionFILE']
        LLimbClass = dLimbLibrary[sLimbClass][iVersion]
        lLimb, dMergedData = mergeClassWithData(LLimbClass, xFileData)

        lLimb.dMergedData = dMergedData
        sLimbName = '%s_%s' % (lLimb.sSide, lLimb.sName)
        sParentLimb = lLimb.dMergedData['__parent__']
        dChildren[sParentLimb].append(sLimbName)

    dPriorities = {}

    def collectRec(sLimbs=[None], iCounter=0):
        for sL in sLimbs:
            dPriorities[sL] = iCounter
            collectRec(dChildren[sL], iCounter=iCounter + 1)

    collectRec()

    if bReverse:
        iMax = max(dPriorities.values())
        for sL,iP in list(dPriorities.items()):
            dPriorities[sL] = iMax-iP

    return dPriorities



def fileDump(sFile, dLimbs):
    sWriteLines = []
    allLimbs = limbsFromFiles()

    for dL in dLimbs:

        sSide = dL['dArgsFILE'].pop('sSide', None)
        sName = dL['dArgsFILE'].pop('sName', None)

        if sSide == None or sName == None:
            sClassType = dL['sClassTypeFILE']
            iVersion = dL.get('iVersionFILE', 0)
            TLimbClass = allLimbs[sClassType][iVersion]

            sInitArgs, _, _, xInitDefaults = inspect.getfullargspec(TLimbClass.__init__)[0:4]
            sFlags = sInitArgs[len(sInitArgs)-len(xInitDefaults):]
            if sSide == None:
                sSide = xInitDefaults[sFlags.index('sSide')]
            if sName == None:
                sName = xInitDefaults[sFlags.index('sName')]

        sLine = '%s_%s = %s\n' % (sSide, sName, str(dL))
        sWriteLines.append(sLine)

    file = open('%s' % sFile, 'w')
    for sLine in sWriteLines:
        file.write(sLine)

    file.close()



def getDictListFromFile(sFile):
    with open(sFile) as myFile:
        sAllLines = list(myFile)

    if not sAllLines:
        return []

    if sAllLines[0].startswith('['):  # old json
        try:
            with open(sFile) as file:
                xFileData = json.load(file)
        except Exception as e:
            raise Exception('couldn\'t read file %s' % e)
    else:  # new format
        xFileData = []
        for sLine in sAllLines:
            sEquals = sLine.split('=')
            sLimbName = sEquals[0].strip()
            if not sLimbName: # empty line
                continue
            sSide, sName = sLimbName.split('_')

            if utils.getPythonVersion() == 3:
                sCleanText = re.sub(r'(\W)(\d+)L', r'\1\2', sEquals[1]) # to remove the L after numbers (files from python 2.7)
            else:
                sCleanText = sEquals[1]

            try:
                dLimb = eval(sCleanText)
            except:
                raise Exception('syntax error with this line: %s' % sCleanText)

            dLimb['dArgsFILE']['sSide'] = sSide
            dLimb['dArgsFILE']['sName'] = sName
            xFileData.append(dLimb)

    return xFileData

