###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np
import copy

import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt

import kangarooTools.deformerAttachEditor as deformerAttachEditor

import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls9 as ctrls9
import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.xforms as xforms


dPredefinedEnums = {}
dPredefinedEnums['sSide'] = ['l', 'm', 'r'], ['left', 'middle', 'right']
dPredefinedEnums['sCtrlShape'] = list(ctrls9.dCtrlShapes.keys()), [utils.beautifyVariableName(sK) for sK in list(ctrls9.dCtrlShapes.keys())]
dPredefinedEnums['sDoTranslation'] = ['xyz', '', 'x', 'y', 'z', 'xy', 'xz', 'yz'], ['on (xyz)', 'off', 'x', 'y', 'z', 'xy', 'xz', 'yz']
dPredefinedEnums['sDoRotation'] = ['xyz', '', 'x', 'y', 'z', 'xy', 'xz', 'yz'], ['on (xyz)', 'off', 'x', 'y', 'z', 'xy', 'xz', 'yz']
dPredefinedEnums['iRotateOrder'] = [range(len(xforms.sRotateOrders)), xforms.sRotateOrders]
dPredefinedEnums['sDoScale'] = ['xyz', '', 'uniform', 'x', 'y', 'z', 'xy', 'xz', 'yz'], ['on (xyz)', 'off', 'uniform', 'x', 'y', 'z', 'xy', 'xz', 'yz']


qBaseAttrFont = QtGui.QFont()
qBaseAttrFont.setItalic(True)



class QAttacherBlendItem(QtWidgets.QTreeWidgetItem):
    def __init__(self, parent=None, qAttacher=None, tAttrControl=None):
        QtWidgets.QTreeWidgetItem.__init__(self) #, parent=parent)

        self.tAttrControl = tAttrControl
        self.qAttacher = qAttacher
        qInfoWidget = QtWidgets.QWidget(self.tAttrControl.qtTree)
        qInfoLayout = QtWidgets.QHBoxLayout(self.tAttrControl.qtTree)
        qInfoLayout.setContentsMargins(0, 0, 0, 0)
        qInfoLayout.setSpacing(0)

        qInfoWidget.setLayout(qInfoLayout)
        self.qLabel = QtWidgets.QLabel('count')
        qInfoLayout.addWidget(self.qLabel)
        self.qCountLine = QtWidgets.QLineEdit()
        self.qCountLine.setText('-')
        self.qCountLine.setValidator(QtGui.QIntValidator())
        self.qCountLine.setMaximumWidth(50)

        self.qCountLine.editingFinished.connect(self.qAttacherCountChanged)

        self.qLabel.setMaximumWidth(80)
        qInfoLayout.addWidget(self.qCountLine)

        self.qBlendBox = QtWidgets.QCheckBox('blend')
        qInfoLayout.addWidget(self.qBlendBox)
        self.qBlendBox.stateChanged.connect(self.qAttacherBlendGotChanged)

        self.tAttrControl.qtTree.setItemWidget(self.qAttacher, 1, qInfoWidget)


    def qAttacherCountChanged(self):
        self.tAttrControl.qAttacherCountChanged(self.qAttacher, self.getCount())


    def qAttacherBlendGotChanged(self, iChecked):
        self.tAttrControl.saveAttacherDoBlend(self.qAttacher, True if iChecked else False)

    def getCount(self):
        sText = self.qCountLine.text()
        if sText == '-':
            return 0
        return int(sText)


    def setCount(self, iCount):
        bSignalsBefore = self.qCountLine.signalsBlocked()
        self.qCountLine.blockSignals(True)

        self.qCountLine.setText('%d' % iCount)

        self.qCountLine.blockSignals(bSignalsBefore)



    def doBlend(self):
        return self.qBlendBox.isChecked()


    def setBlend(self, bDoBlend):
        bSignalsBlocked = self.qBlendBox.signalsBlocked()
        self.qBlendBox.blockSignals(True)
        try:
            self.qBlendBox.setChecked(bDoBlend)
        except:
            raise
        finally:
            self.qBlendBox.blockSignals(bSignalsBlocked)


    def setEnabled(self, bEnabled):
        if utils.isNone(bEnabled): # watch this... started adding it for maya 2023 because if it's None, it'll error
            bEnabled = False
        self.qCountLine.setEnabled(bEnabled)
        self.qLabel.setEnabled(bEnabled)
        self.qBlendBox.setEnabled(bEnabled)






class QAttacherOutputItem(QtWidgets.QTreeWidgetItem):
    def __init__(self, parent=None, qAttacher=None, tAttrControl=None, tCharLimbs=None, qValidLimbs=None, iIndex=0, sFixedLocal=None, bParentIsMulti=False):
        QtWidgets.QTreeWidgetItem.__init__(self) #, parent=parent)
        self.parent = parent
        self.bParentIsMulti = bParentIsMulti
        self.qAttacher = qAttacher
        self.qAttacher.addChild(self)

        self.sAttacher = qAttacher.data(0, QtCore.Qt.UserRole)['sName']

        self.iIndex = iIndex

        self.tCharLimbs = tCharLimbs
        self.tAttrControl = tAttrControl

        self.qValidLimbs = qValidLimbs
        self.qtTree = self.tAttrControl.qtTree

        self.setData(0, QtCore.Qt.UserRole, {'sType': 'output'})

        # if not sLimbNames:
        #     raise Exception, 'there are no limb names set'
        # self.sLimbNames = sLimbNames

        self.qLimbsCombo = QNoWheelComboBox(self.qtTree)
        self.qOutputsCombo = QNoWheelComboBox(self.qtTree)
        self.qOutputsCustom = QtWidgets.QLineEdit(self.qtTree)
        iMaxHeight = 25
        self.qLimbsCombo.setMaximumHeight(iMaxHeight)
        self.qOutputsCombo.setMaximumHeight(iMaxHeight)
        self.qOutputsCustom.setMaximumHeight(iMaxHeight)

        qOutputsWidget = QtWidgets.QWidget(self.qtTree)
        qOutputsLayout = QtWidgets.QHBoxLayout(self.qtTree)
        qOutputsLayout.setContentsMargins(0, 0, 0, 0)
        qOutputsLayout.setSpacing(0)
        qOutputsLayout.addWidget(self.qOutputsCombo)
        qOutputsLayout.addWidget(self.qOutputsCustom)
        self.qOutputsCustom.setHidden(True)

        qOutputsWidget.setLayout(qOutputsLayout)


        self.qOutputAttrName = QtWidgets.QLineEdit(self.qtTree)
        self.qOutputAttrName.setText('')
        self.qOutputAttrName.setMaximumHeight(iMaxHeight)
        qOutputsLayout.addWidget(self.qOutputAttrName)

        self.qDefaultWeight = QtWidgets.QLineEdit(self.qtTree)
        self.qDefaultWeight.setText('1' if iIndex == 0 else '0')
        self.qDefaultWeight.setMaximumHeight(iMaxHeight)
        self.validator = utilsQt.QFloatValidator(self.qtTree)
        self.qDefaultWeight.setValidator(self.validator)

        qOutputsLayout.addWidget(self.qDefaultWeight)

        if not qAttacher.bMulti:
            self.qOutputAttrName.setHidden(True)
            self.qDefaultWeight.setHidden(True)

        self.qtTree.setItemWidget(self, 1, qOutputsWidget)
        self.tAttrControl.qtTree.setItemWidget(self, 0, self.qLimbsCombo)

        self.sFixedLocal = sFixedLocal
        if self.sFixedLocal:
            self.qLimbsCombo.addItems(['SELF'])
            self.qOutputsCombo.addItems([sFixedLocal])
            self.qLimbsCombo.setEnabled(False)
            self.qOutputsCombo.setEnabled(False)
            self.qOutputAttrName.setText(sFixedLocal)

        else:
            self.sValidLimbs = [qL.text(0) for qL in self.qValidLimbs]
            sItems = [utils.kNoneString] + self.sValidLimbs + [utils.kCustomString, '']
            self.qLimbsCombo.addItems(sItems)
            self.iCustomIndex = sItems.index(utils.kCustomString)

            self.qLimbsCombo.currentIndexChanged.connect(self.updateOutputSelectorSignal)
            self.qOutputsCombo.currentIndexChanged.connect(self.outputGotChangedSignal)
            self.qOutputsCustom.editingFinished.connect(self.outputGotChangedSignal)

            self.qLimbsCombo.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.qLimbsCombo.customContextMenuRequested.connect(self.markingMenuLimbs)
            self.qLimbsCombo.setMinimumWidth(5) # this is because in maya 2020 it gets set automatically based on items
            self.qOutputsCombo.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.qOutputsCombo.customContextMenuRequested.connect(self.markingMenuOutputs)

            def _markingMenuCustom(vPos, qCustomLine=self.qOutputsCustom):
                qMenu = QtWidgets.QMenu()

                def _setTo(sPreset):
                    sSel = cmds.ls(sl=True)[0]
                    qCustomLine.setText(sPreset % sSel)

                def _openDeformerAttachUI():
                    utils.reload2(deformerAttachEditor)

                    def _updateText(sText):
                        qCustomLine.setText(sText)
                        self.outputGotChanged() # should be set automatically, but doesn't always do it

                    sCurrentText = qCustomLine.text().strip()

                    if sCurrentText and not sCurrentText.startswith('deformers:') and not sCurrentText.startswith('deformers;'):
                        if cmds.confirmDialog(m='Current Entry is not a deformer selection. \nClear it?',
                                              button=['yes', 'no, abort']) == 'yes':
                            sCurrentText = 'deformers:'
                        else:
                            return

                    self._tempUi = deformerAttachEditor.QDeformerAttachUi(sCurrentText, _updateText)
                    self._tempUi.show()

                qPresetsMenu = qMenu.addAction('Attach Deformers UI', _openDeformerAttachUI)
                qPresetsMenu = qMenu.addMenu('Other Presets')
                qPresetsMenu.addAction('all deformers of selected mesh', lambda:_setTo('%s.allDeformersExceptLast0'))
                qPresetsMenu.addAction('selected mesh (slow)', lambda:_setTo('%s.geo'))
                qPresetsMenu.addAction('selected xform', lambda:_setTo('%s'))
                qMenu.exec_(self.qOutputsCombo.mapToGlobal(vPos))
                return qMenu

            self.qOutputsCustom.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.qOutputsCustom.customContextMenuRequested.connect(_markingMenuCustom)



        if qAttacher.bMulti:
            self.qOutputAttrName.editingFinished.connect(self.outputAttrNameGotChangedSignal)
            self.qDefaultWeight.editingFinished.connect(self.weightGotChangedSignal)

            if not self.sFixedLocal:
                self.updateOutputSelector(-1, bRunOutputGotChanged=False)


        self.qOutputsCombo.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.qOutputAttrName.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)


    # def showAttrName(self, bShow):
    #     self.qOutputAttrName.setHidden(not bShow)


    def outputGotChangedSignal(self):
        self.outputGotChanged()


    def outputAttrNameGotChangedSignal(self):
        self.outputGotChanged()


    def weightGotChangedSignal(self):
        self.outputGotChanged()


    def updateOutputSelectorSignal(self, iIndex, bRunOutputGotChanged=True):
        self.updateOutputSelector(iIndex, bRunOutputGotChanged)


    def markingMenuLimbs(self, vPos):
        qMenu = QtWidgets.QMenu()
        self.tAttrControl.addCopyAttacherMarkingMenu(qMenu, self)
        qMenu.exec_(self.qLimbsCombo.mapToGlobal(vPos))
        return qMenu


    def setToClosest(self):
        sA = self.qAttacher.data(0, QtCore.Qt.UserRole)['sName']

        # self.sLimbNames is not being updated properly!!!!!
        sLimbNames = self.tAttrControl.sCurrentLimbs
        iOutputsCount = self.qOutputsCombo.count()
        sComboOutputNames = [self.qOutputsCombo.itemText(i) for i in range(iOutputsCount)]

        iIndices = []
        for l,sL in enumerate(sLimbNames):
            sTransform = None
            for sT in cmds.ls(et='transform'):
                sAttr = '%s.sAttacherTransformLimbName' % sT
                if cmds.objExists(sAttr):

                    if cmds.getAttr(sAttr) == sL:
                        sTransformNames = cmds.getAttr('%s.sAttacherTransformNames' % sT)
                        if sA in sTransformNames:
                            sTransform = sT
                            break

            if sTransform == None:
                cmds.confirmDialog(t='build rig', m='Cannot find attacher transforms for %s. Make sure you build the rig before running this' % utils.listToString(sLimbNames))
                return


            qL = self.tCharLimbs.getLimbItemWithName(sL)
            ddLimbData = qL.data(0, QtCore.Qt.UserRole)
            sOutputs = ddLimbData['%s.sOutputsFILE' % self.sAttacher]
            sLimb, sOutput, sAttrName, fWeight = utils.extractOutputInfo(sOutputs[self.iIndex])

            sPossibleOutputs = puppetDataUtils.getAllOutputs(self.tCharLimbs.getLimbItemWithName(sLimb).data(0, QtCore.Qt.UserRole))

            aPos = np.array(cmds.xform(sTransform, q=True, ws=True, t=True), dtype='float64')

            sOutputJoints = [None for i in range(len(sPossibleOutputs))]
            sExistingLimbTransforms = []
            for sJ in cmds.ls(et='joint'):
                sAttr = '%s.sLimbJoint' % sJ

                if cmds.objExists(sAttr) and cmds.getAttr(sAttr) == sLimb:
                    sOutputNameAttr = '%s.sOutputName' % sJ
                    if cmds.objExists(sOutputNameAttr):
                        sExistingLimbTransforms.append(sJ)
                        sOutputName = cmds.getAttr(sOutputNameAttr)
                        if sOutputName in sPossibleOutputs:
                            o = sComboOutputNames.index(sOutputName)
                            sOutputJoints[o] = sJ

            aValidJoints = np.array([j for j,sJ in enumerate(sOutputJoints) if sJ])
            aClosests = xforms.findClosestJoints([aPos], np.array(sOutputJoints)[aValidJoints], bIncludeChildrenNotInInputJoints=False)
            iIndex = aValidJoints[aClosests[0]]
            sNewOutput = sPossibleOutputs[iIndex]

            sNewOutputName = utils.combineOutputInfo(sLimb, sNewOutput, sAttrName, fWeight)
            sOutputs[self.iIndex] = sNewOutputName
            iIndices.append(iIndex)
            # change data of qLimb
            bSignalsBlocked = qL.treeWidget().signalsBlocked()
            qL.treeWidget().blockSignals(True)
            try:
                qL.setData(0, QtCore.Qt.UserRole, ddLimbData)
            except:
                raise
            finally:
                qL.treeWidget().blockSignals(bSignalsBlocked)

        
        self.tAttrControl.dApplyButtons['Save'].setText('Save *')
        
        bSignalsBlocked = self.qOutputsCombo.signalsBlocked()
        self.qOutputsCombo.blockSignals(True)
        try:
            if len(set(iIndices)) == 1:
                self.qOutputsCombo.setCurrentIndex(iIndices[0])
            else:
                self.qOutputsCombo.setCurrentIndex(self.qOutputsCombo.count()-1)
        except:
            raise
        finally:
            self.qOutputsCombo.blockSignals(bSignalsBlocked)





    def markingMenuOutputs(self, vPos):
        qMenu = QtWidgets.QMenu()

        qClosest = qMenu.addAction('set to closest', self.setToClosest)
        if self.qLimbsCombo.currentText() in [utils.kNoneString, utils.kCustomString]:
            qClosest.setEnabled(False)
        qMenu.exec_(self.qOutputsCombo.mapToGlobal(vPos))
        return qMenu


    def setIndexFromLimbName(self, sLimb):
        iIndex = self.sValidLimbs.index(sLimb)
        self.qLimbsCombo.setCurrentIndex(iIndex+1)


    def setEnabled(self, bEnabled):

        if not self.sFixedLocal:
            self.qLimbsCombo.setEnabled(bEnabled)
            self.qOutputsCombo.setEnabled(bEnabled)
        self.qOutputAttrName.setEnabled(bEnabled)
        self.qDefaultWeight.setEnabled(bEnabled)


    def blockSignals(self, bBlockSignals):
        self.qOutputsCombo.blockSignals(bBlockSignals)
        self.qOutputsCustom.blockSignals(bBlockSignals)
        self.qLimbsCombo.blockSignals(bBlockSignals)
        self.qOutputAttrName.blockSignals(bBlockSignals)
        self.qDefaultWeight.blockSignals(bBlockSignals)


    def updateOutputSelector(self, iIndex, bRunOutputGotChanged=True):

        iIndex = self.qLimbsCombo.currentIndex()

        bSignalsBlockedBefore = self.qOutputsCombo.signalsBlocked()

        self.blockSignals(True)
        try:
            self.qOutputsCombo.clear() # clearing the self one, too - bad!

            if iIndex == 0:  # <None>
                self.sOutputs = []
                self.qOutputsCombo.setHidden(True)
                self.qOutputsCustom.setHidden(True)
                self.qOutputAttrName.setHidden(True)
                self.qDefaultWeight.setHidden(True)
            elif iIndex == self.iCustomIndex:
                self.qOutputsCombo.setHidden(True)
                self.qOutputsCustom.setHidden(False)
                self.qOutputAttrName.setHidden(False if self.bParentIsMulti else True)
                self.qDefaultWeight.setHidden(False if self.bParentIsMulti else True)
            else: # regular combo box
                self.qOutputsCombo.setHidden(False)
                self.qOutputsCustom.setHidden(True)
                self.qOutputAttrName.setHidden(False if self.bParentIsMulti else True)
                self.qDefaultWeight.setHidden(False if self.bParentIsMulti else True)
                qLimb = self.qValidLimbs[iIndex - 1]
                self.sOutputs = puppetDataUtils.getAllOutputs(qLimb.data(0, QtCore.Qt.UserRole))

                self.qOutputsCombo.addItems(self.sOutputs + [''])
                tLimb = puppetDataUtils.instantiateLimb(qLimb.data(0, QtCore.Qt.UserRole))
                sDefaultOutput = tLimb.getDefaultParentOutput()
                iOutputIndex = self.sOutputs.index(sDefaultOutput)
                self.qOutputsCombo.setCurrentIndex(iOutputIndex)
                self.qOutputAttrName.setText(tLimb.sName.split('_')[-1])

        except:
            raise
        finally:
            self.blockSignals(bSignalsBlockedBefore)
        if bRunOutputGotChanged:
            self.outputGotChanged()


    def getOutputName(self):
        sDefaultWeights = self.qDefaultWeight.text()
        if sDefaultWeights:
            fDefaultWeights = float(sDefaultWeights)
        else:
            fDefaultWeights = -1

        sLimb = self.qLimbsCombo.currentText()
        if sLimb == utils.kCustomString:
            sOutput = self.qOutputsCustom.text()
        else:
            sOutput = self.qOutputsCombo.currentText()
        return utils.combineOutputInfo(sLimb, sOutput, self.qOutputAttrName.text(), fDefaultWeights)


    def outputGotChanged(self):
        self.tAttrControl.saveAttacherOutputs(self.qAttacher)




    def setOutputByName(self, sOutputName, iIndex=0):
        try:
            bOutputsSignalsBlocked = self.qOutputsCombo.signalsBlocked()
            bLimbsSignalsBlocked = self.qLimbsCombo.signalsBlocked()
            bAttrNameSignalsBlocked = self.qOutputAttrName.signalsBlocked()
            bDefaultWeightBlocked = self.qDefaultWeight.signalsBlocked()
            bOutputsCustomSignalsBlocked = self.qOutputsCustom.signalsBlocked()
            self.blockSignals(True)

            if self.sFixedLocal:
                if '@' in sOutputName:
                    sAttrName, sWeight = sOutputName.split('@')
                elif '__' in sOutputName:
                    sAttrName, sWeight = sOutputName.split('__') # legacy
                else:
                    sAttrName, sWeight = sOutputName.split('.')[:2] # legacy legacy

                # sAttrName, sWeight = sOutputName.split('__') if '__' in sOutputName else sOutputName.split('.')[:2]
                iWeight = float(sWeight) if len(sWeight) else -1

                self.qOutputAttrName.setText(sAttrName)
                if iWeight >= 0:
                    self.qDefaultWeight.setText(str(iWeight))
                else:
                    self.qDefaultWeight.setText('')
            else:
                sLimb, sOutput, sAttrName, iWeight = utils.extractOutputInfo(sOutputName, iIndex=iIndex)

                if sLimb:
                    if sLimb == utils.kNoneString:
                        # iLimb = -1
                        # self.qLimbsCombo.setCurrentIndex(self.qLimbsCombo.count()-1) # we may not need this?
                        self.qOutputsCombo.setHidden(True)
                        self.qOutputsCustom.setHidden(True)
                        self.qOutputAttrName.setHidden(True)
                        self.qDefaultWeight.setHidden(True)
                        self.qLimbsCombo.setCurrentIndex(0)
                    elif sLimb == utils.kCustomString:
                        self.qOutputsCustom.setText(sOutput)
                        self.qOutputsCombo.setHidden(True)
                        self.qOutputsCustom.setHidden(False)
                        self.qOutputAttrName.setHidden(False if self.bParentIsMulti else True)
                        self.qDefaultWeight.setHidden(False if self.bParentIsMulti else True)
                        self.qLimbsCombo.setCurrentIndex(self.iCustomIndex)
                        if sAttrName:
                            self.qOutputAttrName.setText(sAttrName)
                        else:
                            self.qOutputAttrName.setText('')

                    else: # normal combobox
                        iLimb = self.sValidLimbs.index(sLimb)
                        self.qOutputsCombo.setHidden(False)
                        self.qOutputsCustom.setHidden(True)
                        self.qOutputAttrName.setHidden(False if self.bParentIsMulti else True)
                        self.qDefaultWeight.setHidden(False if self.bParentIsMulti else True)

                        self.qLimbsCombo.setCurrentIndex(iLimb+1)
                        self.updateOutputSelector(iLimb, bRunOutputGotChanged=False)

                        if sOutput:
                            iOutput = self.sOutputs.index(sOutput)
                            self.qOutputsCombo.setCurrentIndex(iOutput)
                            if sAttrName:
                                self.qOutputAttrName.setText(sAttrName)
                            else:
                                self.qOutputAttrName.setText('')
                        else:
                            self.qOutputsCombo.setCurrentIndex(self.qOutputsCombo.count()-1)

                    if sLimb != utils.kNoneString:
                        if iWeight >= 0:
                            self.qDefaultWeight.setText(str(iWeight))
                        else:
                            self.qDefaultWeight.setText('')

        except Exception as e:
            cmds.confirmDialog(m='(4) %s' % str(e))
            raise
        finally:
            # self.blockSignals(bOutputsSignalsBlocked)
            self.qOutputsCombo.blockSignals(bOutputsSignalsBlocked)
            self.qLimbsCombo.blockSignals(bLimbsSignalsBlocked)
            self.qOutputAttrName.blockSignals(bAttrNameSignalsBlocked)
            self.qDefaultWeight.blockSignals(bDefaultWeightBlocked)
            self.qOutputsCustom.blockSignals(bOutputsCustomSignalsBlocked)




class QParentItem(QtWidgets.QTreeWidgetItem):
    def __init__(self, parent=None, tAttrControl=None, tCharLimbs=None):
        QtWidgets.QTreeWidgetItem.__init__(self) #, parent=parent)

        parent.invisibleRootItem().addChild(self)

        self.tCharLimbs = tCharLimbs
        self.tAttrControl = tAttrControl

        self.qtTree = self.tAttrControl.qtTree
        self.setText(0, 'PARENT')
        self.setData(0, QtCore.Qt.UserRole, {'sType': 'parent'})

        self.qCombo = QNoWheelComboBox(self.qtTree)
        self.tAttrControl.qtTree.setItemWidget(self, 1, self.qCombo)

        self.qCombo.currentIndexChanged.connect(self.gotChanged)
        self.qCombo.setMaximumHeight(20)
        self.sOutputs = []

        self.setToolTip(0, 'Joint Parent. \nSpecify which of the joints of the parent limb this should should be parented to')

        self.qCombo.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qCombo.customContextMenuRequested.connect(self.markingMenuParents)


    def markingMenuParents(self, vPos):
        qMenu = QtWidgets.QMenu()

        qMenu.addAction('set to root attacher', self.setToRoot)
        qMenu.exec_(self.qCombo.mapToGlobal(vPos))
        return qMenu



    def setToRoot(self):
        sLimbNames = self.tAttrControl.sCurrentLimbs
        print ('sLimbNames: ', sLimbNames)

        iIndices = []
        bDidSomething = False
        for l, sL in enumerate(sLimbNames):

            qL = self.tCharLimbs.getLimbItemWithName(sL)
            ddLimbData = qL.data(0, QtCore.Qt.UserRole)
            sRootOutput = ddLimbData['root.sOutputsFILE'][0]
            sLimb, sOutput, sAttrName, fWeight = utils.extractOutputInfo(sRootOutput)

            if sLimb != ddLimbData['__parent__']:
                print ('skipping "%s" because parent is not the same as root limb' % sL)
                iIndices.append(self.qCombo.currentIndex())
            else:
                ddLimbData['parentOutputFILE'] = sOutput

                # change data of qLimb
                bSignalsBlocked = qL.treeWidget().signalsBlocked()
                qL.treeWidget().blockSignals(True)
                try:
                    qL.setData(0, QtCore.Qt.UserRole, ddLimbData)
                except:
                    raise
                finally:
                    qL.treeWidget().blockSignals(bSignalsBlocked)

                iIndices.append(self.sOutputs.index(sOutput))
                bDidSomething = True

        if bDidSomething:
            self.tAttrControl.dApplyButtons['Save'].setText('Save *')

            bSignalsBlocked = self.qCombo.signalsBlocked()
            self.qCombo.blockSignals(True)
            try:
                if len(set(iIndices)) == 1:
                    self.qCombo.setCurrentIndex(iIndices[0])
                else:
                    pass
                    # TODO: when creating the combo, we'll need to add an empty item, so the following commented line
                    # works. We didn't do that yet because it's risky.
                    #self.qCombo.setCurrentIndex(self.qCombo.count() - 1)
            except:
                raise
            finally:
                self.qCombo.blockSignals(bSignalsBlocked)


    def setOutputs(self, sOutputs, sParent=None):
        self.sOutputs = sOutputs
        if sParent:
            self.setText(0, 'PARENT - "%s"' % sParent)
        else:
            self.setText(0, '---')

        bSignalsBlocked = self.qCombo.signalsBlocked()
        self.qCombo.blockSignals(True)
        try:
            self.qCombo.clear()
            self.qCombo.addItems(sOutputs)
        except:
            raise
        finally:
            self.qCombo.blockSignals(bSignalsBlocked)
        # self.gotChanged()


    def switchToOutput(self, sOutput):
        iIndex = self.sOutputs.index(sOutput)
        bSignalsBlocked = self.qCombo.signalsBlocked()
        self.qCombo.blockSignals(True)
        try:
            self.qCombo.setCurrentIndex(iIndex)
        except:
            raise
        finally:
            self.qCombo.blockSignals(bSignalsBlocked)


    def gotChanged(self):
        sOutput = self.qCombo.currentText()
        for sCurrentLimb in self.tAttrControl.sCurrentLimbs:
            qCurrentLimb = self.tCharLimbs.getLimbItemWithName(sCurrentLimb)
            ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
            ddLimbData['parentOutputFILE'] = sOutput
            qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)

        self.tAttrControl.dApplyButtons['Save'].setText('Save *')


class QStartFeatureSwitchItem(QtWidgets.QTreeWidgetItem):
    def __init__(self, parent=None, tAttrControl=None, tCharLimbs=None):
        QtWidgets.QTreeWidgetItem.__init__(self) #, parent=parent)

        parent.invisibleRootItem().addChild(self)

        self.tCharLimbs = tCharLimbs
        self.tAttrControl = tAttrControl

        self.qtTree = self.tAttrControl.qtTree
        self.setText(0, 'DefaultFeature')
        self.setData(0, QtCore.Qt.UserRole, {'sType': 'defaultFeature'})

        self.qFeatures = QNoWheelComboBox(self.qtTree)
        self.tAttrControl.qtTree.setItemWidget(self, 1, self.qFeatures)

        self.qFeatures.currentIndexChanged.connect(self.gotChanged)
        self.qFeatures.setMaximumHeight(20)
        self.sOutputs = []

        self.setToolTip(0, 'The switch attribute will by default be set to whatever you specify here')

    def getCurrentFeature(self):
        return self.qFeatures.currentText()


    def updateFeatures(self, sFeatures):
        self.sFeatures = sFeatures

        bSignalsBlocked = self.qFeatures.signalsBlocked()
        self.qFeatures.blockSignals(True)
        try:
            self.qFeatures.clear()
            self.qFeatures.addItems(self.sFeatures + [''])
        except:
            raise
        finally:
            self.qFeatures.blockSignals(bSignalsBlocked)


    def setToFeature(self, sFeature):
        bSignalsBlocked = self.qFeatures.signalsBlocked()
        self.qFeatures.blockSignals(True)
        try:
            sFeatures = [self.qFeatures.itemText(i) for i in range(self.qFeatures.count())]
            if sFeature in sFeatures:
                iIndex = sFeatures.index(sFeature)
            else:
                iIndex = 0
            self.qFeatures.setCurrentIndex(iIndex)
        except:
            raise
        finally:
            self.qFeatures.blockSignals(bSignalsBlocked)


    def gotChanged(self):
        sFeature = self.qFeatures.currentText()
        for qCurrentLimb in self.tAttrControl.getCurrentLimbObjects():
            ddLimbData = qCurrentLimb.data(0, QtCore.Qt.UserRole)
            ddLimbData['sStartFeatureFILE'] = sFeature
            qCurrentLimb.setData(0, QtCore.Qt.UserRole, ddLimbData)
        self.tAttrControl.dApplyButtons['Save'].setText('Save *')



def createAttrItem(**kwargs):
    xValues = kwargs['xValues']
    sName = kwargs['sName']
    sComboboxItems = kwargs['sComboboxItems']
    del kwargs['sComboboxItems']
    iInterpolateBehavior = kwargs['iInterpolateBehavior']
    del kwargs['iInterpolateBehavior']

    if sComboboxItems:
        return QEnumItem(xEnumValues=range(len(sComboboxItems)), sEnumDisplays=sComboboxItems, **kwargs)
    elif sName in dPredefinedEnums:
        xEnumValues, sEnumDisplays = dPredefinedEnums[sName]
        return QEnumItem(xEnumValues=xEnumValues, sEnumDisplays=sEnumDisplays, **kwargs)
    elif isinstance(xValues[0], bool):
        return QEnumItem(xEnumValues=[False,True], sEnumDisplays=['off','on'], **kwargs)
    elif isinstance(xValues[0], (list, tuple)):#, np.ndarray)):
        return QLineListItem(iInterpolateBehavior=iInterpolateBehavior, **kwargs)
    elif utils.isStringOrUnicode(xValues[0]) or utils.isNumber(xValues[0]):
        return QLineItem(**kwargs)
    else:
        raise Exception('unrecognized data type %s (%s) - %s' % (xValues[0], sName, str(type(xValues[0]))))



class QBaseAttrItem(QtWidgets.QTreeWidgetItem):
    def __init__(self, qtTree=None, qParentItem=None, sName='noname', xValues=None, xDefault=None, bEnabled=True, changedFunc=None, qtWindow=None, bIsBase=False):
        QtWidgets.QTreeWidgetItem.__init__(self) #, parent=qtTree)
        self.qtTree = qtTree
        self.qtWindow = qtWindow
        if qParentItem:
            qParentItem.addChild(self)
        else:
            self.qtTree.invisibleRootItem().addChild(self)
        self.sPrettyName = utils.beautifyVariableName(sName)
        self.setText(0, self.sPrettyName)

        if bIsBase:
            self.setFont(0, qBaseAttrFont)

        self.sName = sName
        self.setFlags(self.flags() & ~QtCore.Qt.ItemIsDropEnabled & ~QtCore.Qt.ItemIsDragEnabled | QtCore.Qt.ItemIsEditable)
        self.setData(0, QtCore.Qt.UserRole, {'sType': 'attr'})

        self.bEnabled = bEnabled
        self.xValues = copy.deepcopy(xValues)
        self.xDefault = xDefault
        self.changedFunc = changedFunc

        if qParentItem:
            ddParentData = qParentItem.data(0, QtCore.Qt.UserRole)
            self.sArgDictKey = '%s.dArgsFILE' % ddParentData['sFunctionName']
        else:
            self.sArgDictKey = 'dArgsFILE'


    def setEnabled(self, bEnabled):
        self.bEnabled = bEnabled
        self.setStyle()


    def setStyle(self):
        if self.bEnabled:
            self.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.default)))
            self.setFlags(self.flags() | QtCore.Qt.ItemIsEditable | QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsDropEnabled)
        else:
            self.setForeground(0, QtGui.QBrush(QtGui.QColor(utils.uiColors.disabled)))
            self.setFlags(self.flags() ^ QtCore.Qt.ItemIsEditable ^ QtCore.Qt.ItemIsSelectable ^ QtCore.Qt.ItemIsDropEnabled)

        for qL in self.qWidgets:
            qL.setEnabled(self.bEnabled)


    def userChangedValue(self, xNewValue):
        for i in range(len(self.xValues)):
            self.xValues[i] = xNewValue

        self.setStyle()
        self.changedFunc(self.sArgDictKey, self.sName, self.xValues)


    def reset(self):
        self.xValues = [self.xDefault] * len(self.xValues)
        self.updateValueInWidgets()
        self.setStyle()
        self.userChangedValue(self.xDefault)


    def printInfo(self):
        print('%s: %s ' % (self.sName, self.data(0, QtCore.Qt.UserRole)))


    def markingMenu(self, vPos, iWidgetIndex=0):
        utils.debugPrint ('== create marking menu')
        qMenu = QtWidgets.QMenu()
        self.addActionsToMarkingMenu(qMenu)

        qMenu.addAction('__print info__', self.printInfo)
        bSignalsBlocked = self.qWidgets[0].signalsBlocked()
        self.blockSignals(True)
        try:
            qMenu.exec_(self.qWidgets[iWidgetIndex].mapToGlobal(vPos))
        except:
            raise
        finally:
            self.blockSignals(bSignalsBlocked)
        utils.debugPrint ('== end of create marking menu')
        return qMenu


    def addActionsToMarkingMenu(self, qMenu):
        qResetAction = qMenu.addAction('reset attribute', self.reset)
        if self.xValues == self.xDefault:
            qResetAction.setEnabled(False)
        if self.sName == 'sBellSettings':
            qMenu.addAction('store bell collider settings', self.reset)




    def valueIsDefault(self):
        if self.xValue == self.xDefault:
            return True
        else:
            return False


    def blockSignals(self, bBlock):
        for qW in self.qWidgets:
            qW.blockSignals(bBlock)


    def signalsBlocked(self):
        return self.qWidgets[0].signalsBlocked()



class QEnumItem(QBaseAttrItem):
    def __init__(self, qtTree=None, qParentItem=None, sName='noname', xValues=None, xDefault=None, bEnabled=True,
                 changedFunc=None, sEnumDisplays=[], xEnumValues=[], qtWindow=None, bIsBase=False):
        QBaseAttrItem.__init__(self, qtTree=qtTree, qParentItem=qParentItem, sName=sName, xValues=xValues, xDefault=xDefault,
                               bEnabled=bEnabled, changedFunc=changedFunc, qtWindow=qtWindow, bIsBase=bIsBase)
        self.sEnumDisplays = sEnumDisplays
        self.xEnumValues = xEnumValues

        self.qWidgets = [QNoWheelComboBox(self.qtTree)]
        self.qtTree.setItemWidget(self, 1, self.qWidgets[0])
        self.qWidgets[0].addItems(self.sEnumDisplays + [''])
        self.qWidgets[0].setMaximumHeight(22)
        self.sStyle = 'background:transparent; '
        self.updateValueInWidgets()
        self.qWidgets[0].currentIndexChanged.connect(self.comboIndexChanged)
        self.qWidgets[0].setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qWidgets[0].customContextMenuRequested.connect(self.markingMenu)


    def updateValueInWidgets(self):
        bSignalsBlocked = self.qWidgets[0].signalsBlocked()
        self.qWidgets[0].blockSignals(True)
        try:
            bSameValues = True if len(set(self.xValues)) == 1 else False

            if bSameValues and self.xValues[0] in self.xEnumValues:
                iCurrentIndex = self.xEnumValues.index(self.xValues[0])
            else:
                iCurrentIndex = len(self.xEnumValues)

            self.qWidgets[0].setCurrentIndex(iCurrentIndex)

        except:
            raise
        finally:
            self.qWidgets[0].blockSignals(bSignalsBlocked)
        self.setStyle()


    def comboIndexChanged(self, iIndex):
        if iIndex < len(self.xEnumValues):
            bNewValue = self.xEnumValues[iIndex]
            self.userChangedValue(bNewValue)


    def setStyle(self):
        QBaseAttrItem.setStyle(self)

        if self.xValues[0] == self.xDefault: # fix that
            self.qWidgets[0].setStyleSheet('%s font:italic' % self.sStyle)
        else:
            self.qWidgets[0].setStyleSheet('%s font:bold' % self.sStyle)


class QLineItem(QBaseAttrItem):
    def __init__(self, qtTree=None, qParentItem=None, sName='noname', xValues=None, xDefault=None, bEnabled=True, changedFunc=None, qtWindow=None, bIsBase=False):
        QBaseAttrItem.__init__(self, qtTree=qtTree, qParentItem=qParentItem, sName=sName, xValues=xValues,qtWindow=qtWindow,
                               xDefault=xDefault, bEnabled=bEnabled, changedFunc=changedFunc, bIsBase=bIsBase)
        self.qWidgets = [QtWidgets.QLineEdit(self.qtTree)]
        self.qtTree.setItemWidget(self, 1, self.qWidgets[0])
        self.sStyle = 'border:none; background:transparent; '
        self.updateValueInWidgets()
        self.qWidgets[0].setMaximumHeight(22)
        self.qWidgets[0].editingFinished.connect(self.editingFinishedAction)
        self.Type = type(xValues[0])

        if self.Type == float:
            self.validator = utilsQt.QFloatValidator(self.qtTree)
            self.qWidgets[0].setValidator(self.validator)
        elif self.Type == int:
            self.validator = QtGui.QIntValidator(self.qtTree)
            self.qWidgets[0].setValidator(self.validator)
        elif self.Type == str:
            pass

        self.qWidgets[0].setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qWidgets[0].customContextMenuRequested.connect(self.markingMenu)



    def updateValueInWidgets(self):
        bSignalsBlocked = self.qWidgets[0].signalsBlocked()
        self.qWidgets[0].blockSignals(True)
        try:
            bSameValues = True if len(set(self.xValues)) == 1 else False
            if bSameValues:
                self.qWidgets[0].setText(str(self.xValues[0]))
        except:
            raise
        finally:
            self.qWidgets[0].blockSignals(bSignalsBlocked)
        self.setStyle()


    def editingFinishedAction(self):
        sText = self.qWidgets[0].text()
        xNewValue = self.Type(sText)

        self.userChangedValue(xNewValue)


    def setStyle(self):
        QBaseAttrItem.setStyle(self)

        if self.xValues[0] == self.xDefault:
            self.qWidgets[0].setStyleSheet('%s font:italic' % self.sStyle)
        else:
            self.qWidgets[0].setStyleSheet('%s font:bold' % self.sStyle)




class QLineListItem(QBaseAttrItem):
    def __init__(self, qtTree=None, qParentItem=None, sName='noname', xValues=None, xDefault=None, bEnabled=True, changedFunc=None, qtWindow=None, bIsBase=False, iInterpolateBehavior=0):
        QBaseAttrItem.__init__(self, qtTree=qtTree, qParentItem=qParentItem, sName=sName, xValues=xValues, qtWindow=qtWindow,
                               xDefault=xDefault, bEnabled=bEnabled, changedFunc=changedFunc, bIsBase=bIsBase)

        self.iMinimumSize = 1

        self.qWidgets = []

        self.sStyle = 'background:transparent; '

        self.qRowLayout = QtWidgets.QHBoxLayout(self.qtTree)
        self.qRowLayout.setContentsMargins(0, 0, 0, 0)
        self.qRowLayout.setSpacing(0)

        self.Type = type(xValues[0])


        self.bResizeAble = True if isinstance(self.xDefault, list) else False # if it's tuple then not resizeable
        if self.bResizeAble:
            self.qEmptyLabel = QtWidgets.QLabel('<empty>')
            self.qRowLayout.addWidget(self.qEmptyLabel)
            self.qEmptyLabel.setHidden(True if len(self.xDefault) else False)

            self.qEmptyLabel.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
            self.qEmptyLabel.customContextMenuRequested.connect(self._markingMenuEmptyLabel)


        iValuesMinLength = min([len(xV) for xV in xValues])

        for i in range(iValuesMinLength):
            self._addOneLine()
        self.updateValueInWidgets()

        self.qWidget = QtWidgets.QFrame(self.qtTree)
        self.qWidget.setLayout(self.qRowLayout)
        self.qtTree.setItemWidget(self, 1, self.qWidget)

        self.iInterpolateBehavior = iInterpolateBehavior


    def _markingMenuEmptyLabel(self, vPos):
        qMenu = QtWidgets.QMenu()
        self.addActionsToMarkingMenu(qMenu)
        qMenu.exec_(self.qEmptyLabel.mapToGlobal(vPos))
        return qMenu


    def _addOneLine(self):
        qLine = QtWidgets.QLineEdit(self.qtTree)
        qLine.setMaximumHeight(27)

        qLine.editingFinished.connect(self.editingFinishedAction)
        if self.Type == float:
            self.validator = utilsQt.QFloatValidator()
            qLine.setValidator(self.validator)
        elif self.Type == int:
            self.validator = QtGui.QIntValidator()
            qLine.setValidator(self.validator)
        self.qRowLayout.addWidget(qLine)
        self.qWidgets.append(qLine)
        qLine.setText('0')

        qLine.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        def _markingMenu(vPos, iWidgetIndex=len(self.qWidgets)-1):
            self.markingMenu(vPos, iWidgetIndex=iWidgetIndex)
        qLine.customContextMenuRequested.connect(_markingMenu)



    def updateValueInWidgets(self):

        iValuesMinLength = min([len(xV) for xV in self.xValues])
        xValuesTranspose = list(map(list, list(zip(*[a[:iValuesMinLength] for a in self.xValues]))))
        bSameValues = [True if len(set(xT)) == 1 else False for xT in xValuesTranspose]

        for qW,xV,bS in zip(self.qWidgets, xValuesTranspose, bSameValues):
            bSignalsBlocked = qW.signalsBlocked()
            qW.blockSignals(True)
            try:
                if bS:
                    qW.setText(str(xV[0]))
                else:
                    qW.setText('')
            except:
                pass
            finally:
                qW.blockSignals(bSignalsBlocked)
        self.setStyle()



    def editingFinishedAction(self):
        xNewValueStrings = [qW.text() for i,qW in enumerate(self.qWidgets)]
        xNewValue = [float(xS) if xS != '' else None for xS in xNewValueStrings]
        utils.debugPrint ('editing finishedAction.. %s' % self.sName)
        self.userChangedValue(xNewValue)




    # overridden for QLineListItem
    def userChangedValue(self, xNewValue):
        utils.debugPrint('user changed value (%s)' % self.sName)

        for i in range(len(self.xValues)):
            if isinstance(self.xValues[i], tuple): # in Maya 2020 it becomes (rightfully ?) a tuple
                self.xValues[i] = list(self.xValues[i])

            for v,xN in enumerate(xNewValue):
                if xN != None:
                    if v < len(self.xValues[i]):
                        self.xValues[i][v] = xN
                    else:
                        self.xValues[i].append(xN)
            self.xValues[i] = self.xValues[i][:len(xNewValue)]

        self.setStyle()
        self.changedFunc(self.sArgDictKey, self.sName, self.xValues)



    def setStyle(self):
        QBaseAttrItem.setStyle(self)

        if self.valueIsDefault():
            for qL in self.qWidgets:
                qL.setStyleSheet('%s font:italic' % self.sStyle)
        else:
            for qL in self.qWidgets:
                qL.setStyleSheet('%s font:bold' % self.sStyle)


    def reset(self):
        self.resizeArray(len(self.xDefault))
        self.xValues[0] = list(self.xDefault)
        QBaseAttrItem.reset(self)


    def callResizeUI(self):
        self.resizeUi = QResizeUI(self, iDefaultSize=len(self.qWidgets))
        self.resizeUi.show()


    def interpolateArray(self, iPower=1, bRevPower=False):
        for v,xV in enumerate(self.xValues):

            if self.iInterpolateBehavior == 0:
                xV = np.interp(np.arange(len(xV)), [0, len(xV)-1], [0,1])
            elif self.iInterpolateBehavior == 1:
                xV = np.interp(np.arange(len(xV)), [-1, len(xV)], [0,1])
            else:
                raise Exception('Don\'t know what iInterpolateBehavior %d is' % self.iInterpolateBehavior)

            if bRevPower:
                xV = 1.0 - xV
            xV = np.power(xV, iPower)
            if bRevPower:
                xV = 1.0 - xV

            xV = np.round(xV, 2)

            self.xValues[v] = list(xV)

        bSignalsBlocked = self.signalsBlocked()
        self.blockSignals(True)
        try:
            for w,qW in enumerate(self.qWidgets):
                qW.setText(str(self.xValues[0][w]))
        except:
            raise
        finally:
            self.blockSignals(bSignalsBlocked)


    def resizeArray(self, iNewSize):
        if iNewSize < self.iMinimumSize:
            iNewSize = self.iMinimumSize

        iDiff = iNewSize - len(self.qWidgets)

        for v, xV in enumerate(self.xValues):
            if iDiff < 0:
                if v == 0:
                    for i in range(len(xV)-1, iNewSize-1, -1):
                        self.qWidgets[i].deleteLater()
                    self.qWidgets = self.qWidgets[:iNewSize]
                xV = xV[:iNewSize]
            elif iDiff > 0:
                if v == 0:
                    for i in range(iDiff):
                        self._addOneLine()
                xV.append(0)

            self.qEmptyLabel.setHidden(True if iNewSize > 0 else False)
        self.editingFinishedAction()


    def addActionsToMarkingMenu(self, qMenu):
        QBaseAttrItem.addActionsToMarkingMenu(self, qMenu)
        if self.bResizeAble:
            qMenu.addAction('resize array', self.callResizeUI)
        qMenu.addAction('interpolate', self.interpolateArray)
        qMenu.addAction('interpolate (more on end, square)', lambda:self.interpolateArray(iPower=2, bRevPower=True))
        qMenu.addAction('interpolate (more on start, square)', lambda:self.interpolateArray(iPower=2, bRevPower=False))


    def valueIsDefault(self):
        if len(self.xValues[0]) != len(self.xDefault):
            return False
        else:
            for v,d in zip(self.xValues[0], self.xDefault):
                if v != d:
                    return False
            return True





class QResizeUI(QtWidgets.QDialog):
    def __init__(self, qArrayItem, iDefaultSize=1):
        super(QResizeUI, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qArrayItem = qArrayItem

        countLayout = QtWidgets.QHBoxLayout()
        countLayout.addWidget(QtWidgets.QLabel('count'))
        self.qCount = QtWidgets.QLineEdit(str(iDefaultSize))

        self.validator = QtGui.QIntValidator(self)
        self.qCount.setValidator(self.validator)

        countLayout.addWidget(self.qCount)
        layout.addLayout(countLayout)

        self.setWindowTitle('Resize Array for "%s"' % self.qArrayItem.text(0))
        self.setWindowModality(QtCore.Qt.ApplicationModal)
        qButton = QtWidgets.QPushButton('Resize')
        qButton.clicked.connect(self.ResizeClicked)
        layout.addWidget(qButton)


    def ResizeClicked(self):
        iCount = int(self.qCount.text())
        self.qArrayItem.resizeArray(iCount)
        self.close()






class QNoWheelComboBox(QtWidgets.QComboBox):
    def __init__(self, parent=None):
        QtWidgets.QComboBox.__init__(self, parent=parent)
        self.parent = parent

    def wheelEvent(self, *args, **kwargs):
        return self.parent.wheelEvent(*args, **kwargs)


