###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.OpenMaya as OpenMaya
import maya.OpenMayaAnim as OpenMayaAnim
import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.cmds as cmds
import numpy as np

import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.topology as topology
import kangarooTools.barycentric as barycentric
import itertools


class MissingInfluencesOptions():
    skipIfMissingInfluences = 0
    onlyAddMissingInfluencesInSkinCluster = 1
    createAndAddMissingInfluencesInScene = 2
    askToAddOrCreateInfluences = 3

iMissingInfluencesForNext = None


class BorderEdges():
    doEverything = 0
    ignoreBorderEdges = 1
    onlyDoBorderEdges = 2

class CheckInfluencesResult():
    everythingWasThere = 0
    influencesStillMissing = 1
    addedInfluences = 2

class Worldspace():
    ignore = 0
    closestVertices = 1
    closestPoints = 2

class JointLocks():
    ignore = 0
    dontChangeLockedJoints = 1
    onlyAddWeightsToLockedJoints = 2
    onlyRemoveWeightsFromLockedJoints = 3

class PatchTypes():
    mesh = 0,
    curve = 1,
    surface = 2


class Patch():
    def __init__(self, mDagPath, aIds=None, aSofts=None):
        self.mDagPath = mDagPath
        self.aSofts = aSofts
        if isinstance(aIds, (np.ndarray, list, tuple)):
            self.aIds = aIds
        else:
            self.aIds = np.arange(self.getTotalCount())


    def supportsClosestPoint(self):
        return False


    def isSelected(self):
        sSel = set([sS.split('.')[0] for sS in cmds.ls(sl=True)])
        sSel = None

    def getName(self, bFullPath=False):
        if bFullPath:
            return self.mDagPath.fullPathName()
        else:
            return self.mDagPath.partialPathName()


    def __repr__(self):
        return '<Patch: %s>' % self.getName()
    
    
    def __str__(self):
        return '<Patch: %s>' % self.getName()


    def delete(self):
        cmds.delete(self.getTransformName())


    def getTransformName(self):
        sName = self.getName()
        if cmds.objectType(sName) == 'transform':
            return sName
        else:
            return cmds.listRelatives(self.getName(), p=True)[0]


    def getSkinCluster(self, bSkipWeights=False, aOverrideIds=None, sChooseSkinCluster=None):
        sSkinClusters = deformers.listAllDeformers(self.getTransformName(), sFilterTypes=['skinCluster']) # changed this recently from self.getName() to self.getTransformName() to support references
        if not sSkinClusters:
            if bSkipWeights:
                return None, None
            else:
                return None, None, None

        if sChooseSkinCluster:
            if sChooseSkinCluster not in sSkinClusters:
                if bSkipWeights:
                    return None, None
                else:
                    return None, None, None
            sSkinCluster = sChooseSkinCluster
        else:
            sSkinCluster = sSkinClusters[0]
        mSkinCluster = utils.getDependNode(sSkinCluster)
        fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(mSkinCluster)
        self.sInfluences = [dp.fullPathName().split('|')[-1] for dp in fnSkinCluster.influenceObjects()]
        
        if bSkipWeights:
            return sSkinCluster, self.sInfluences
        else:
            mComponents = self.getIndexedComponents(aOverrideIds=aOverrideIds)
            fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(mSkinCluster)
            mWeights, iInfCount = fnSkinCluster.getWeights(utils.getDagPath(self.getTransformName()), mComponents) # gives less indices than what MFnNurbsSurface functions give
            aWeights2d = np.array(list(mWeights), dtype='float64').reshape(-1, iInfCount)
            return sSkinCluster, self.sInfluences, aWeights2d


    def getSkinClusterBlendWeights(self, aOverrideIds=None, sChooseSkinCluster=None): # sChooseSkinCluster is not tested
        sSkinClusters = deformers.listAllDeformers(self.getTransformName(), sFilterTypes=['skinCluster']) # changed this recently from self.getName() to self.getTransformName() to support references

        if sChooseSkinCluster:
            if sChooseSkinCluster not in sSkinClusters:
                return None
            sSkinCluster = sChooseSkinCluster
        else:
            sSkinCluster = sSkinClusters[0]

        mSkinCluster = utils.getDependNode(sSkinCluster)
        fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(mSkinCluster)
        mComponents = self.getIndexedComponents(aOverrideIds=aOverrideIds)
        mWeights = fnSkinCluster.getBlendWeights(self.mDagPath, mComponents)
        return np.array(list(mWeights), dtype='float64')


    def removedUnusedInfluences(self, fMinValue=0.0001):
        _, sInfluences, aWeights2d = self.getSkinCluster()
        aSums = np.sum(aWeights2d, axis=0)
        aInds = np.where(aSums < fMinValue)[0]
        aZeroInfluences = np.array(sInfluences)[aInds]
        cmds.skinCluster(self.getTransformName(), e=True, removeInfluence=list(aZeroInfluences))
        print('removed %d influences from %s' % (len(aZeroInfluences), self.getTransformName()))


    def hasSkinCluster(self):
        sSkinClusters = deformers.listAllDeformers(self.mDagPath.fullPathName(), sFilterTypes=['skinCluster'])
        return True if sSkinClusters else False
    
    '''
    def getWeights(self, aOverrideIds=None, bForceUpdate=True):
        if bForceUpdate == False:
            if aOverrideIds == None:
                if self.aWeights != None: return self.aWeights
            else:
                cmds.warning('is aOverrideIds are set, weights will always be udpated')

        mComponents = self.getIndexedComponents(aOverrideIds=aOverrideIds)
        fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(self.mSkinCluster)
        mWeights, iInfCount = fnSkinCluster.getWeights(self.mDagPath, mComponents)
        aWeights = np.array(list(mWeights), dtype='float64').reshape(-1, iInfCount)
        self.aWeights = aWeights if aOverrideIds == None else None
        return aWeights
    '''

    def getMapValues(self, sMap, aOverrideIds=None):
        if sMap.endswith('.__blendWeights__'):
            return self.getSkinClusterBlendWeights(aOverrideIds=aOverrideIds)
        
        elif sMap.endswith('.__jointWeights__'):
            sSkinCluster, sInf, _ = sMap.split('.')
            _, sInfluences, aWeights2d = self.getSkinCluster(sChooseSkinCluster=sSkinCluster) # sMap:  skinCluster__Realistic_White_Male_Low_PolyShape.jnt_r_thumbBase.__jointWeights__
            iInf = list(sInfluences).index(sInf)
            return aWeights2d[:,iInf]
        elif 'weightList[0].weights' in sMap and not isinstance(self, SurfacePatch) and cmds.about(version=True) >= '2023':
            aIds = self.aIds if utils.isNone(aOverrideIds) else aOverrideIds
            sDeformer = sMap.split('.')[0]
            mObject = utils.getDependNodeOldApi(sDeformer)
            mFnWeightFilter = OpenMayaAnim.MFnWeightGeometryFilter(mObject)
            mComponents = self.getIndexedComponentsOldApi(aOverrideIds=aIds)
            sGeometry = cmds.deformer(sDeformer, q=True, g=True)[0]
            mWeights = OpenMaya.MFloatArray()
            mFnWeightFilter.getWeights(utils.getDagPathOldApi(sGeometry), mComponents, mWeights)
            return np.array(mWeights, dtype='float64')
        else:
            sDeformer = sMap.split('.')[0]
            if deformers.isGeometryFilter(sDeformer):
                fValues = cmds.getAttr('%s[0:%d]' % (sMap, self.getTotalCount()-1))
                aValues = np.array(fValues, dtype='float64')
            elif cmds.objectType(sDeformer) == 'nCloth':
                aValues = np.zeros(self.getTotalCount(), dtype='float64')
                fValuesFromDeformer = cmds.getAttr(sMap)
                if fValuesFromDeformer:
                    aValuesFromDeformer = np.array(fValuesFromDeformer, dtype='float64')
                    aValues[:len(aValuesFromDeformer)] = aValuesFromDeformer

        if not utils.isNone(aOverrideIds):# != None:
            return aValues[aOverrideIds]
        else:
            return aValues[self.aIds]


    def setMapValues(self, sMap, aValues, aOverrideIds=None, aOverrideSofts=None, fBlend=1.0, iBorderEdges=BorderEdges.doEverything, iSmoothBorderMask=2, xDistanceMeshes=None, _bSkipDeformerAdjustLogging=False):
        if not utils.isNone(aOverrideIds):# != None:
            aIds = aOverrideIds
            if utils.isNone(aOverrideSofts):# == None:
                aSofts = np.ones(len(aOverrideIds), dtype='float64') if not utils.isNone(self.aSofts) else None
            else:
                aSofts = aOverrideSofts
        else:
            aIds = self.aIds
            aSofts = self.aSofts
        
        if sMap.endswith('.__blendWeights__'):
            # sChooseSkinCluster wasn't tested yet
            self.setSkinClusterBlendWeights(aValues, aOverrideIds=aOverrideIds, fBlend=fBlend, iBorderEdges=iBorderEdges, sChooseSkinCluster=sMap.split('.')[0],
                                                    iSmoothBorderMask=iSmoothBorderMask, xDistanceMeshes=xDistanceMeshes)
        elif sMap.endswith('.__jointWeights__'):
            sSkinCluster, sInf, _ = sMap.split('.')
            _, sInfluences, aWeights2d = self.getSkinCluster(sChooseSkinCluster=sSkinCluster) # sMap:  skinCluster__Realistic_White_Male_Low_PolyShape.jnt_r_thumbBase.__jointWeights__
            iInf = list(sInfluences).index(sInf)
            aWeights2d[:,iInf] = aValues
            aOtherInfs = np.arange(len(sInfluences)-1)
            aOtherInfs[iInf:] += 1
            aOtherSums = np.sum(aWeights2d[:,aOtherInfs], axis=-1)
            aOtherSums = np.where(aOtherSums == 0, 1, aOtherSums)
            aWeights2d[:,aOtherInfs] *= ((1.0 - aValues) / aOtherSums)[:,np.newaxis]
            # for verts that used to have only influence on the one that we are setting, and we are setting less than 1.0
            aAllSums = np.sum(aWeights2d, axis=-1)
            aWeights2d[:,iInf] = np.where(aAllSums < 1.0, 1.0, aWeights2d[:,iInf])
            self.setSkinClusterWeights(aWeights2d, sInfluences=sInfluences, aOverrideIds=aOverrideIds, fBlend=fBlend, iBorderEdges=iBorderEdges, bAddToCurrent=True,
                                                    iSmoothBorderMask=iSmoothBorderMask, xDistanceMeshes=xDistanceMeshes, sChooseSkinCluster=sSkinCluster, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)

        else:
            if 'weightList[0].weights' in sMap and isinstance(self, MeshPatch) and cmds.about(version=True) >= '2023':
                aIds = self.aIds if utils.isNone(aOverrideIds) else aOverrideIds
                aOldValues = self.getMapValues(sMap, aOverrideIds=aIds)

                if not utils.isNone(aSofts):  # != None:
                    aValues = aValues * aSofts + aOldValues * (1 - aSofts)
                if fBlend != 1.0:
                    aValues = aValues * fBlend + aOldValues * (1.0 - fBlend)
                if iBorderEdges != BorderEdges.doEverything:
                    aBorderMask = self.getBorderMask(iSmoothSteps=iSmoothBorderMask,
                                                     bInverse=True if iBorderEdges == BorderEdges.onlyDoBorderEdges else False)[aIds]
                    aValues = aValues * aBorderMask + aOldValues * (1.0 - aBorderMask)
                if not utils.isNone(xDistanceMeshes) and xDistanceMeshes['sMeshes']:
                    aDistanceMask = self.getDistanceMask(**xDistanceMeshes)[aIds]
                    aValues = aValues * aDistanceMask + aOldValues * (1.0 - aDistanceMask)

                sDeformer = sMap.split('.')[0]
                sGeometry = cmds.deformer(sDeformer, q=True, g=True)[0]
                dSetWeightsData = {'sMesh': sGeometry,
                                   'sDeformer': sDeformer,
                                   'aIds': aIds,
                                   'fDeformerWeights': aValues,
                                   'fOldDeformerWeights': aOldValues}
                cmds.kt_cmdUndo(dt=str(id(dSetWeightsData)))

            else:
                aAllOldValues = self.getMapValues(sMap, aOverrideIds=np.arange(self.getTotalCount()))
                aOldValues = aAllOldValues[aIds]

                if not utils.isNone(aSofts):  # != None:
                    aValues = aValues * aSofts + aOldValues * (1 - aSofts)
                if fBlend != 1.0:
                    aValues = aValues * fBlend + aOldValues * (1.0 - fBlend)
                if iBorderEdges != BorderEdges.doEverything:
                    aBorderMask = self.getBorderMask(iSmoothSteps=iSmoothBorderMask,
                                                     bInverse=True if iBorderEdges == BorderEdges.onlyDoBorderEdges else False)
                    aValues = aValues * aBorderMask + aOldValues * (1.0 - aBorderMask)
                if not utils.isNone(xDistanceMeshes) and xDistanceMeshes['sMeshes']:
                    aDistanceMask = self.getDistanceMask(**xDistanceMeshes)
                    aValues = aValues * aDistanceMask + aOldValues * (1.0 - aDistanceMask)

                aAllOldValues[aIds] = aValues
                sDeformer = sMap.split('.')[0]
                if deformers.isGeometryFilter(sDeformer):
                    cmds.setAttr('%s[0:%d]' % (sMap, self.getTotalCount()-1), *list(aAllOldValues))
                elif cmds.objectType(sDeformer) == 'nCloth':
                    cmds.setAttr(sMap, list(aAllOldValues), type='doubleArray')

        if not _bSkipDeformerAdjustLogging:
            logSkinnedMeshes('%s.%s' % (self.getName(), sDeformer))

    def resetAllMapValues(self, sMap, fValue=0.0):
        # fTotalCount = self.getTotalCount()
        aValues = np.zeros(self.getTotalCount(), dtype='float64')
        if fValue != 0.0:
            aValues.fill(fValue)
        self.setMapValues(sMap, aValues, aOverrideIds=np.arange(self.getTotalCount()))



    def setSkinClusterWeights(self, aWeights2d, sInfluences=None, aOldWeights2d = None, aOverrideIds=None, aOverrideSofts=None, bAddToCurrent=False, bRemoveZeroInfluencesOnCreate=True, bPostNormalize=False,
                            iCheckMissingInfluences = MissingInfluencesOptions.askToAddOrCreateInfluences, sJointFilter=None, bSkipEffects=False, sSphereMasks=[], bFocIfNew=False, sCreateNew=None,
                            fBlend=1.0, iBorderEdges=BorderEdges.doEverything, iSmoothBorderMask=2, xDistanceMeshes=None, iJointLocks=False, xClosestToCurve=None, sChooseSkinCluster=None, _bSkipDeformerAdjustLogging=False):
        '''
        if sInfluences == None, we assume that the aWeights2d is already mapped
        bNoEffects is just to optimize, he won't get aOldWeights2d, which should speed up something.
        '''
        aIds = aOverrideIds if not utils.isNone(aOverrideIds) else self.aIds
        aSofts = aOverrideSofts if not utils.isNone(aOverrideSofts) else self.aSofts

        bNewSkinCluster = False
        # sCurrentInfluences = None
        sSkinCluster, sCurrentInfluences = self.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sChooseSkinCluster)
        if sChooseSkinCluster and not sSkinCluster:
            raise Exception('the chosen skinCluster %s was not found on this mesh (%s)' % (sChooseSkinCluster, self.getTransformName()))

        cmds.undoInfo(openChunk=True)
        try:
            if sCreateNew or not sSkinCluster: # if there is no skinCluster, we make one
                if utils.isNone(sInfluences):
                    raise Exception('if there is no skinCluster, influences must be given to setSkinClusterWeights() (%s)' % self.getName())
                if bRemoveZeroInfluencesOnCreate:
                    aWeights2d, sInfluences = _removeZeroInfluencesNumpy(aWeights2d, sInfluences)

                if not sCreateNew:
                    sCreateNew = sChooseSkinCluster if sChooseSkinCluster else '%sskinCluster__%s' % utils.splitNamespace(self.getTransformName())
                sSkinCluster = deformers.skinMesh(self.getTransformName(), sInfluences, sName=sCreateNew, bFoc=bFocIfNew)
                sChooseSkinCluster = sSkinCluster
                bNewSkinCluster = True

            if utils.isNone(sInfluences):
                if aWeights2d.shape[1] != len(sCurrentInfluences):
                    raise Exception('there are no influences passed, and the influence count in aWeights2d doesn\'t match with the current influences count')
            else: # influences were passed, we'll need to map the array
                iResult = self.checkInfluences(sInfluences, iCheckMissingInfluences=iCheckMissingInfluences, sChooseSkinCluster=sChooseSkinCluster)
                if iResult == CheckInfluencesResult.influencesStillMissing:
                    raise Exception('not skinning "%s", because there are some influences missing' % self.getTransformName())

                _, sCurrentInfluences = self.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sChooseSkinCluster)

                if len(sCurrentInfluences) > len(sInfluences): # it can't be smaller at this point.
                    aInfInds = utils.findOneArrayInAnother(sCurrentInfluences, sInfluences)
                    aTmp = np.zeros((len(aIds),len(sCurrentInfluences)), dtype='float64')
                    aTmp[:,aInfInds] = aWeights2d
                    aWeights2d = aTmp
                    if not utils.isNone(aOldWeights2d):# != None:
                        aTmp.fill(0.0)
                        aTmp[:,aInfInds] = aOldWeights2d
                        aOldWeights2d = aTmp
                else:
                    aInfInds = utils.findOneArrayInAnother(sInfluences, sCurrentInfluences)
                    aWeights2d = aWeights2d[:,aInfInds]
                    if isinstance(aOldWeights2d, np.ndarray): # != None:
                        aOldWeights2d = aOldWeights2d[:,aInfInds]

            if bAddToCurrent: # assuming that aWeights2d is NOT normalized, but aCurrentWeights2d is
                _, _, aCurrentWeights2d = self.getSkinCluster(sChooseSkinCluster=sChooseSkinCluster)  # we already mapped influences or aWeights2d to old ones before
                aAddSums = np.sum(aWeights2d, axis=-1)
                aCurrentWeights2d *= 1.0 - aAddSums[:, np.newaxis]
                aWeights2d += aCurrentWeights2d


            if bPostNormalize:
                aWeights2d /= np.sum(aWeights2d, axis=1)[:,np.newaxis]

            if not bNewSkinCluster and not bSkipEffects:


                if not isinstance(aOldWeights2d, np.ndarray): # or aOldWeights2d == None:
                    _, _, aOldWeights2d = self.getSkinCluster(sChooseSkinCluster=sChooseSkinCluster) # we already mapped influences or aWeights2d to old ones before
                
                if fBlend != 1.0:
                    aWeights2d = aWeights2d * fBlend + aOldWeights2d * (1.0-fBlend)

                if isinstance(aSofts, (np.ndarray, list, tuple)):
                    aSoft2d = np.array(aSofts, dtype='float64')[:,np.newaxis]
                    aWeights2d = aWeights2d * aSoft2d + aOldWeights2d * (1.0-aSoft2d)

                if not utils.isNone(xDistanceMeshes):# != None:
                    aDistanceMask = self.getDistanceMask(**xDistanceMeshes)[:,np.newaxis]
                    aWeights2d = aWeights2d * aDistanceMask + aOldWeights2d * (1.0-aDistanceMask)

                if not utils.isNone(sJointFilter):# != None:
                    aFilteredJoints = utils.findOneArrayInAnother(sInfluences, list(sJointFilter))
                    aIgnoreJoints = np.setdiff1d(np.arange(len(sInfluences)), aFilteredJoints)
                    aNewWeights2d = np.copy(aOldWeights2d)
                    aNewWeights2d[:,aFilteredJoints] = aWeights2d[:,aFilteredJoints]
                    aWeights2d = aNewWeights2d
                    
                    aFilteredSums = np.sum(aWeights2d[:,aFilteredJoints], axis=1)
                    aIgnoreSums = np.sum(aWeights2d[:,aIgnoreJoints], axis=1)
                    aIgnoreSums[aIgnoreSums < 0.000000001] = 1.0
                    aWeights2d[:,aIgnoreJoints] *= ((1.0-aFilteredSums) / aIgnoreSums)[...,np.newaxis]

                    aSumsAfter = np.sum(aWeights2d, axis=1)
                    aVertsWithSumsTooSmall = aSumsAfter < 1.0
                    aWeights2d[aVertsWithSumsTooSmall,:] *= (1.0 / aSumsAfter[aVertsWithSumsTooSmall])[...,np.newaxis]

                if iJointLocks != JointLocks.ignore:

                    iLocks = [cmds.getAttr('%s.liw' % sI) for sI in sCurrentInfluences]

                    aLocked = np.array(iLocks, dtype=bool)
                    aLockedJoints = np.arange(len(sCurrentInfluences))[aLocked]
                    aFreeJoints = np.arange(len(sCurrentInfluences))[~aLocked]

                    aWeights2d = _applyJointLocks(aLockedJoints, aFreeJoints, aWeights2d, aOldWeights2d, iMode=iJointLocks)

                if iBorderEdges != BorderEdges.doEverything:
                    aBorderMask = self.getBorderMask(iSmoothSteps=iSmoothBorderMask,
                                                     bInverse=True if iBorderEdges == BorderEdges.onlyDoBorderEdges else False)[:,np.newaxis]
                    aWeights2d = aWeights2d * aBorderMask + aOldWeights2d * (1.0-aBorderMask)

                if not utils.isNone(xClosestToCurve): # != None:
                    aClosestToCurveMask2d = self.getClosestToCurveMask(**xClosestToCurve)[:,np.newaxis]
                    aWeights2d = aWeights2d * aClosestToCurveMask2d + aOldWeights2d * (1.0-aClosestToCurveMask2d)

                if sSphereMasks:
                    aMask = np.zeros(aIds.size, dtype='float64')
                    for sSphere in sSphereMasks:
                        aMask += self.getMaskFromSphere(sSphere)
                    if len(sSphereMasks) > 1:
                        aMask = np.clip(aMask, 0, 1)
                    aMask2d = aMask[:,np.newaxis]
                    aWeights2d = aWeights2d * aMask2d + aOldWeights2d * (1.0-aMask2d)


            # send skin weights data to the undo plugin
            #
            if isinstance(aOldWeights2d, (np.ndarray)):
                fOldWeights2d = list(aOldWeights2d.flatten())
            else:
                fOldWeights2d = aOldWeights2d

            # just a last normalize to avoid that "The weight total would have exceeded 1.0" warning
            aWeights2d = aWeights2d / np.sum(aWeights2d, axis=-1)[:,np.newaxis]

            dSetWeightsData = { 'sMesh':self.getName(),
                                'sSkinCluster':sSkinCluster,
                                'aIds':aIds,
                                'iInfCount':len(sCurrentInfluences),
                                'fJointWeights':list(aWeights2d.flatten()),
                                'fOldJointWeights': fOldWeights2d}
            if not _bSkipDeformerAdjustLogging:
                logSkinnedMeshes('%s.%s' % (self.getName(), sSkinCluster))
            if bNewSkinCluster:
                pass
                # this crashes maya 2018 when it's dual quaternion:
                # cmds.setAttr('%s.skinningMethod' % sSkinCluster, iSkinningMethodIfNew)
            cmds.kt_cmdUndo(dt=str(id(dSetWeightsData)))
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

        return sSkinCluster, sCurrentInfluences, aWeights2d



    def setSkinClusterBlendWeights(self, aBlendWeights,  aOldBlendWeights = None, aOverrideIds=None, aOverrideSofts=None,
                            fBlend=1.0, iBorderEdges=BorderEdges.doEverything, iSmoothBorderMask=2, xDistanceMeshes=None, sChooseSkinCluster=None, _bSkipDeformerAdjustLogging=False):
        
        aIds = aOverrideIds if not utils.isNone(aOverrideIds) else self.aIds
        aSofts = aOverrideSofts if not utils.isNone(aOverrideSofts) else self.aSofts
        
        sSkinCluster, _ = self.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sChooseSkinCluster)
        if not sSkinCluster:
            raise Exception('there is no skinCluster on %s' % self.getName())
        
        if utils.isNone(aOldBlendWeights):# == None:
            aOldBlendWeights = self.getSkinClusterBlendWeights(aOverrideIds=aIds)

        if not utils.isNone(aSofts):# != None:
            aBlendWeights = aBlendWeights * aSofts + aOldBlendWeights * (1.0-aSofts)
        if not utils.isNone(xDistanceMeshes):# != None:
            aDistanceMask = self.getDistanceMask(**xDistanceMeshes)
            aBlendWeights = aBlendWeights * aDistanceMask + aOldBlendWeights * (1.0-aDistanceMask)
        if iBorderEdges != BorderEdges.doEverything:
            aBorderMask = self.getBorderMask(iSmoothSteps=iSmoothBorderMask,
                                             bInverse=True if iBorderEdges == BorderEdges.onlyDoBorderEdges else False)
            aBlendWeights = aBlendWeights * aBorderMask + aOldBlendWeights * (1.0-aBorderMask)
        if fBlend != 1.0:
            aBlendWeights = aBlendWeights * fBlend + aOldBlendWeights * (1.0-fBlend)


        dSetWeightsData = { 'sMesh':self.getName(),
                            'sSkinCluster':sSkinCluster,
                            'aIds':aIds,
                            'fBlendWeights':list(aBlendWeights),
                            'fOldBlendWeights':list(aOldBlendWeights)}
        cmds.kt_cmdUndo(dt=str(id(dSetWeightsData)))
        
        if not _bSkipDeformerAdjustLogging:
            logSkinnedMeshes('%s.%s' % (self.getName(), sSkinCluster))

    def getObjectName(self):
        return self.mDagPath.partialPathName()


    def getOrigShape(self):
    
        sTransform = cmds.listRelatives(self.getName(), p=True, f=True)[0]
        sAllShapes = cmds.listRelatives(sTransform, s=True, f=True)
        sNoIntermShapes = cmds.listRelatives(sTransform, s=True, ni=True, f=True)
        sShapes = set(sAllShapes) - set(sNoIntermShapes)
        if len(sShapes) > 0:
            iTotalCount = cmds.polyEvaluate(sTransform, vertex=True)
            for sS in sShapes:
                if cmds.polyEvaluate(sS, vertex=True) == iTotalCount:
                    return sS
        return sAllShapes[0]


    def checkInfluences(self, sInfluences, sChooseSkinCluster=None, iCheckMissingInfluences=MissingInfluencesOptions.askToAddOrCreateInfluences):
        global iMissingInfluencesForNext
        if not utils.isNone(iMissingInfluencesForNext):# != None:
            iCheckMissingInfluences = iMissingInfluencesForNext

        sYes = 'Yes'
        sYesAll = 'Yes, to All'
        sNo = 'No'

        sSkinCluster, sCurrentInfluences = self.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sChooseSkinCluster)
        sMissingInSkinCluster = list(set(sInfluences).difference(set(sCurrentInfluences)))

        if not sMissingInSkinCluster:
            return CheckInfluencesResult.everythingWasThere
        elif iCheckMissingInfluences == MissingInfluencesOptions.skipIfMissingInfluences:
            return CheckInfluencesResult.influencesStillMissing
        else:
            sAllInScene = cmds.ls(et='joint')
            sMissingInScene = list(set(sMissingInSkinCluster).difference(sAllInScene))
            if sMissingInScene:
                if iCheckMissingInfluences == MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster:
                    print('influences not in scene: ', sMissingInScene)
                    return CheckInfluencesResult.influencesStillMissing
                elif iCheckMissingInfluences == MissingInfluencesOptions.askToAddOrCreateInfluences:
                    sMessage = 'create: %s' % utils.listToString(sMissingInScene, iMaxCount=15)
                    sMissingInfluencesAlreadyInScene = list(set(sMissingInSkinCluster).difference(sMissingInScene))
                    if sMissingInfluencesAlreadyInScene:
                        sMessage += '%s:\n\n add: %s' % (sSkinCluster, utils.listToString(sMissingInfluencesAlreadyInScene, iMaxCount=15))
                    sMessage +=  '\n(if you are not in Bind Pose, click "No" and go to Bind Pose)'
                    sButtonClicked = cmds.confirmDialog(title='create/add missing influences?',
                                                        message=sMessage, button=[sYes, sYesAll, sNo],
                                                        defaultButton=sYes, cancelButton=sNo, dismissString=sNo)

                    if sButtonClicked == sNo:
                        return CheckInfluencesResult.influencesStillMissing
                    elif sButtonClicked == sYes:
                        [cmds.createNode('joint', n=sI) for sI in sMissingInScene]
                        iCheckMissingInfluences = MissingInfluencesOptions.createAndAddMissingInfluencesInScene
                    elif sButtonClicked == sYesAll:
                        [cmds.createNode('joint', n=sI) for sI in sMissingInScene]
                        iCheckMissingInfluences = MissingInfluencesOptions.createAndAddMissingInfluencesInScene
                        iMissingInfluencesForNext = MissingInfluencesOptions.createAndAddMissingInfluencesInScene

                elif iCheckMissingInfluences == MissingInfluencesOptions.createAndAddMissingInfluencesInScene:
                    [cmds.createNode('joint', n=sI) for sI in sMissingInScene]

            if iCheckMissingInfluences == MissingInfluencesOptions.askToAddOrCreateInfluences:
                sButtonClicked = cmds.confirmDialog(title='add missing influences?',
                                                    message='%s (%s):\n\n%s' % (sSkinCluster, self.getTransformName(), utils.listToString(sMissingInSkinCluster, iMaxCount=15)), button=[sYes, sYesAll, sNo],
                                                    defaultButton=sYes, cancelButton=sNo, dismissString=sNo)
                if sButtonClicked == sNo:
                    return CheckInfluencesResult.influencesStillMissing

                if sButtonClicked == sYesAll:
                    iMissingInfluencesForNext = MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster

            deformers.addInfluences(sSkinCluster, sMissingInSkinCluster)
            return CheckInfluencesResult.addedInfluences


    def isSameGeo(self, tbPatch):
        if self.mDagPath.fullPathName() == tbPatch.mDagPath.fullPathName():
            return True
        else:
            return False


    def getBorderMask(self, iSmoothSteps=3, bInverse=False):
        aBorders = self.getBorderBoolArray()
        aMask2d = np.array(aBorders, dtype='float64')[:,np.newaxis]
        aMask2d = self.smoothValues2d(aValues2d=aMask2d, iIterations=iSmoothSteps, bWholeMesh=True, bLockArray=aBorders)
        if not bInverse:
            aMask2d = 1 - aMask2d
        return aMask2d[self.aIds,0]


    def smoothValues2d(self, aValues2d, iIterations=8, bWholeMesh=False, bLockArray=None, bBarycentricWeighted=False):
        if bWholeMesh:
            aIdsBefore = np.copy(self.aIds)
            self.aIds = np.arange(self.getTotalCount())
        aNbsArray, aIdsWithNeighbors, aMap_indsWithNeighbors_to_aInds, aNeighborSizesDenoms2d = self.getNeighborDataForSmoothing(bIncludeNeighborsNotInIds=False, bBarycentricWeighted=bBarycentricWeighted)
        aValues2d = np.concatenate([aValues2d, np.zeros((1,aValues2d.shape[1]), dtype='float64')])
        if not utils.isNone(bLockArray):# != None:
            aValuesCopy2d = np.copy(aValues2d)
        for iteration in range(iIterations):

            if bBarycentricWeighted:
                aMultipls = aValues2d[aNbsArray] * aNeighborSizesDenoms2d[..., np.newaxis]
                aValues2d[aMap_indsWithNeighbors_to_aInds] = np.sum(aMultipls, axis=-2)
            else:
                aValues2d[aMap_indsWithNeighbors_to_aInds] = np.sum(aValues2d[aNbsArray], axis=1) * aNeighborSizesDenoms2d

            if not utils.isNone(bLockArray):# != None:
                aValues2d[bLockArray] = aValuesCopy2d[bLockArray]
        
        if bWholeMesh:
            self.aIds = aIdsBefore
        return aValues2d[:-1,:]



    def getNeighborDataForSmoothing(self, bIncludeNeighborsNotInIds=True, iMaxNeighborCount=None, bIncludeSelfPoints=True, bBarycentricWeighted=False, sLoopCurve=None):

        iNbsArray = self.getNeighbors(bExcludeNeighborsNotInIds=not bIncludeNeighborsNotInIds, sLoopCurve=sLoopCurve)

        if bIncludeSelfPoints:
            iNbsArray = [[self.aIds[i]] + list(xI) for i,xI in enumerate(iNbsArray)]
        iHighestNumber = self.getTotalCount()

        if bBarycentricWeighted:
            iMaxNeighborCount = 5

        aNbsArray, aNeighborSizes = utils.numpify2dList(iNbsArray, dtype=int, iEmptyValue=iHighestNumber, bReturnSizes=True, iMaxCount=iMaxNeighborCount)
        #iVertexCount, iMaxNeighborCount = aNbsArray.shape
        
        if bBarycentricWeighted:
            aFaceVertexCounts = np.where(aNbsArray[:,4] == iHighestNumber, 3, 4) # triangles and quads
            aFaceVertexCounts = np.where(aNbsArray[:,3] == iHighestNumber, 2, aFaceVertexCounts) # lines
            aFaceVertexCounts = np.where(aNbsArray[:,2] == iHighestNumber, 1, aFaceVertexCounts) # points
            aPositions = self.getAllPoints(bOrig=True)
            
            aNbsArrayCopy = np.copy(aNbsArray)
            aNbsArrayCopy[aNbsArrayCopy == self.getTotalCount()] = 0

            aBarCoords = barycentric.getBarycentricCoords(aPositions[self.aIds], aPositions[aNbsArrayCopy[:,1:5]], aFaceVertexCounts, iSizeLimit=5-1)
            aCoords = np.zeros((self.aIds.size,5), dtype='float64')
            aCoords[:,0] = 0.5 # to do: experiment with that value when we have proper geometry for that
            aCoords[:,1:] = aBarCoords * 0.5
        else:
            aCoords = 1.0

        if not bBarycentricWeighted:
            aNeighborSizesDenoms2d = (1.0 / aNeighborSizes[:,np.newaxis])
        else:
            aNeighborSizesDenoms2d = aCoords

        aIdsWithNeighbors = np.concatenate([aNbsArray.ravel(), self.aIds])
        aIdsWithNeighbors = np.unique(aIdsWithNeighbors)

        aMap_idsWithNeighbors_to_allVertices = np.zeros(self.getTotalCount()+1, dtype=int)
        aMap_idsWithNeighbors_to_allVertices[aIdsWithNeighbors] = np.arange(aIdsWithNeighbors.size)
        aMap_indsWithNeighbors_to_aInds = aMap_idsWithNeighbors_to_allVertices[self.aIds]
        aNbsArray = aMap_idsWithNeighbors_to_allVertices[aNbsArray]
        if aIdsWithNeighbors[-1] == iHighestNumber:
            aIdsWithNeighbors = aIdsWithNeighbors[:-1]

        return aNbsArray, aIdsWithNeighbors, aMap_indsWithNeighbors_to_aInds, aNeighborSizesDenoms2d


    def getMaskFromSphere(self, sSphere):
        fRadius = 1.0
        fFadeOutFactor = cmds.getAttr('%s.fallOff' % sSphere)
        aPoints = self.getPoints()
        aPoints4 = np.ones((aPoints.shape[0], 4), dtype='float64')
        aPoints4[:,:3] = aPoints

        aJointMatrix = np.array(cmds.xform(sSphere, q=True, ws=True, m=True)).reshape(4,4)
        aPointsLocal = np.dot(aPoints4, np.linalg.inv(aJointMatrix))
        aDistances = np.linalg.norm(aPointsLocal[:,:3], axis=1)
        fEndRadius = fRadius * fFadeOutFactor
        aWeights = utils.bSpline4([1,1,0,0], aValues=(aDistances-fRadius)/(fEndRadius-fRadius))
        aWeights[aDistances <= fRadius] = 1.0
        aWeights[aDistances >= fEndRadius] = 0.0
        return aWeights


    def getMaskFromSphereParameters(self, aPos, fRadius, fFadeOutFactor=1.5):
        aPoints = self.getPoints()
        aPointsLocal = aPoints - aPos
        aDistances = np.linalg.norm(aPointsLocal[:,:], axis=1)
        fEndRadius = fRadius * fFadeOutFactor
        aWeights = utils.bSpline4([1,1,0,0], aValues=(aDistances-fRadius)/(fEndRadius-fRadius))
        aWeights[aDistances <= fRadius] = 1.0
        aWeights[aDistances >= fEndRadius] = 0.0
        return aWeights


    def getClosestToCurveMask(self, sCurve, iForwExpand=2, iForwFade=2, iBackExpand=2, iBackFade=2,
                              fHalfspaceVector=[0,1,0], fForwMultipl=[0.5, 0.5, 0.75, 1.0], fBackMultipl=[1.0, 1.0]):

        if not cmds.objExists(sCurve):
            raise Exception('curve %s doesn\'t exist! ( getClosestCurveToCurveMask() )' % sCurve)

        aHalfspaceVector = np.array(fHalfspaceVector)


        iVertexQueue, fParamQueue = topology.getIdsAlongCurve(self, sCurve)

        aPoints = self.getPoints()

        # now expand and fade
        aStartIds = np.array(iVertexQueue, dtype=int)

        aStartParams = np.array(fParamQueue, dtype='float64')
        iTotal = self.getTotalCount()
        aCameFrom = np.empty(iTotal, dtype=int)
        aCameFrom.fill(-1)
        aCameFrom[aStartIds] = np.arange(aStartIds.size)

        aIsTop = np.empty(iTotal, dtype=int)
        aIsTop.fill(-1)
        aIsTop[aStartIds] = 3

        aWeights = np.zeros(iTotal, dtype='float64')
        aWeights[aStartIds] = 1.0
        iiNeighbors = self.getNeighbors()
        iLastExpandedIds = aStartIds

        iForwExpandSum = iForwExpand + iForwFade
        iBackExpandSum = iBackExpand + iBackFade

        aForwMultipl = np.array(fForwMultipl, dtype='float64')
        aBackMultipl = np.array(fBackMultipl, dtype='float64')

        fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
        fLastParam = fnCurve.knots()[-1]

        aForwMultiplMapped = np.interp(aStartParams, np.linspace(0, fLastParam, aForwMultipl.size), aForwMultipl)
        aBackMultiplMapped = np.interp(aStartParams, np.linspace(0, fLastParam, aBackMultipl.size), aBackMultipl)

        iForwMax = int(np.round(np.max(aForwMultipl) * iForwExpandSum))
        iBackMax = int(np.round(np.max(aBackMultipl) * iBackExpandSum))
        aForwSplines = np.zeros((aStartIds.size, iForwMax), dtype='float64')
        aBackSplines = np.zeros((aStartIds.size, iBackMax), dtype='float64')
        for i,aId in enumerate(aStartIds):
            aForwAdd = np.concatenate([np.ones(iForwExpand*aForwMultiplMapped[i], dtype='float64'),
                                              utils.bSpline4([1,1,0,0], np.round(iForwFade*aForwMultiplMapped[i])+2)[1:-1]])
            aForwSplines[i,:len(aForwAdd)] = aForwAdd
            aBackAdd = np.concatenate([np.ones(iBackExpand*aBackMultiplMapped[i], dtype='float64'),
                                              utils.bSpline4([1,1,0,0], np.round(iBackFade*aBackMultiplMapped[i])+2)[1:-1]])
            aBackSplines[i,:len(aBackAdd)] = aBackAdd


        for iIter in range(max(iForwMax, iBackMax)):
            iNewExpandedIds = []
            for iAlreadyExpandedId in iLastExpandedIds:
                for iNb in iiNeighbors[iAlreadyExpandedId]:
                    if aCameFrom[iNb] == -1:
                        iCameFrom = aCameFrom[iAlreadyExpandedId]
                        aLocal = aPoints[iNb] - aPoints[aStartIds[iCameFrom]]
                        fDot = np.sum(aLocal * aHalfspaceVector)

                        if fDot >= 0.0 and iIter < iForwMax:
                            aIsTop[iNb] = 1
                            aWeights[iNb] = aForwSplines[iCameFrom,iIter]
                        elif fDot < 0.0 and iIter < iBackMax:
                            aIsTop[iNb] = 2
                            aWeights[iNb] = aBackSplines[iCameFrom,iIter]
                        else:
                            continue

                        aCameFrom[iNb] = iCameFrom
                        iNewExpandedIds.append(iNb)

            iLastExpandedIds = list(iNewExpandedIds)

        return aWeights



    def getDistanceMask(self, sMeshes, fStart, fEnd, bOutside=False, bSplineInterp=False):
        # sMeshes, fStart, fEnd, bOutside, bSplineInterp = xDistanceMeshes
        sMeshes = utils.toList(sMeshes)
        aMeshDistances = np.empty((len(sMeshes),self.aIds.size))
        for m, sMesh in enumerate(sMeshes):
            try:
                sShape = utils.extendToShape(sMesh)
            except:
                sShape = None

            if not utils.isNone(sShape) and cmds.objectType(sShape) in ['mesh', 'nurbsSurface', 'nurbsCurve']:
                fClosestArray = cmds.kt_findClosestPoints(fromMesh=self.getName(), toMesh=sMesh, returnDistances=True)
                aAllDistances = np.array(fClosestArray, dtype='float64')[3::4]
                aMeshDistances[m] = aAllDistances[self.aIds]
            else:
                aMeshPoint = np.array(cmds.xform(sMesh, q=True, ws=True, t=True), dtype='float64')
                aMeshDistances[m] = np.linalg.norm(aMeshPoint-self.getPoints(), axis=-1)
    
        aDistances = np.min(aMeshDistances, axis=0)
        aMask = (aDistances-fStart) / (fEnd-fStart)
        aMask = aMask.clip(0,1)
        
        # bSplineInterp = True
        if bSplineInterp:
            aMask = 3*aMask*aMask*(1-aMask) + aMask*aMask*aMask
        
        if not bOutside:
            aMask = 1.0 - aMask
        return aMask


    def getPoints(self, bWorld=True, bOrig=False):
        return self.getAllPoints(bWorld=bWorld, bOrig=bOrig)[self.aIds]


class MeshPatch(Patch):
    def __init__(self, sName, aIds=None, aSofts=None):
        Patch.__init__(self, sName, aIds=aIds, aSofts=aSofts)
        def __repr__(self):
            return 'mesh: "%s" ids: %s softs: %s' % (self.mDagPath.partialPathName(), self.aIds, self.aSofts)

    def supportsClosestPoint(self):
        return True

    def getTotalCount(self):
        return OpenMaya2.MFnMesh(self.mDagPath).numVertices


    def getTotalFaceCount(self):
        return OpenMaya2.MFnMesh(self.mDagPath).numPolygons


    def select(self):
        sTransform = self.getTransformName()
        cmds.select(['%s.vtx[%d]' % (sTransform, iId) for iId in self.aIds])


    def getIndexedComponents(self, aOverrideIds=None):
        fnVtxComp = OpenMaya2.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya2.MFn.kMeshVertComponent )
        fnVtxComp.addElements(list(aOverrideIds if not utils.isNone(aOverrideIds) else self.aIds))
        return self.mComponents


    def getIndexedComponentsOldApi(self, aOverrideIds=None):
        fnVtxComp = OpenMaya.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya.MFn.kMeshVertComponent )
        aIds = aOverrideIds if not utils.isNone(aOverrideIds) else self.aIds
        mIds = OpenMaya.MIntArray(len(aIds))
        for i,id in enumerate(aIds):
            mIds.set(int(id),int(i)) # one of them needs to not get converted to int
        fnVtxComp.addElements(mIds)
        return self.mComponents

    
    def getAllPoints(self, bWorld=True, bOrig=False):
        if bOrig:
            sShape = self.getOrigShape()
        else:
            sShape = self.getName()
        return np.array(cmds.xform('%s.vtx[*]' % sShape, q=True, ws=bWorld, t=True), dtype='float64').reshape(-1,3)
    

    def setPoints(self, aPoints, aIds=None, bWorld=True):
        mSpace = OpenMaya2.MSpace.kWorld if bWorld else OpenMaya2.MSpace.kObject
        pArray = OpenMaya2.MFnMesh(self.mDagPath).getPoints(space=mSpace)
        pOldArray = OpenMaya2.MPointArray(pArray)

        if utils.isNone(aIds):# == None:
            aIds = np.arange(self.getTotalCount())
        for i, iVert in enumerate(aIds[:len(aPoints)]):
            pArray[iVert] = OpenMaya2.MPoint(aPoints[i,0], aPoints[i,1], aPoints[i,2], 1)
        
        dMovePointsData = { 'sMesh':self.getName(),
                            'aIds':aIds,
                            'mPoints':pArray,
                            'mOldPoints':pOldArray,
                            'mSpace':mSpace}

        cmds.kt_cmdUndo(dt=str(id(dMovePointsData)))
        #OpenMaya2.MFnMesh(self.mDagPath).setPoints(pArray, space=mSpace)



    def getNeighbors(self, bExcludeNeighborsNotInIds=True, bIncludeOpposites=False, sLoopCurve=None, bJustBorders=False):
        mVertexIter = OpenMaya2.MItMeshVertex(self.mDagPath)
        xNeighbors = []
        iMaxNeighborCount = -1
        iTotalVertexCount = self.getTotalCount()
        if len(self.aIds) == iTotalVertexCount:
            bExcludeNeighborsNotInIds = False
        
        if bExcludeNeighborsNotInIds:
            aUsedIds = np.zeros(iTotalVertexCount, dtype=bool)
            aUsedIds[self.aIds] = True

        if bIncludeOpposites:
            iVertexFaces = topology.getAllVertexFaces(self.mDagPath)
            aFaceVertices = utils.numpify2dList(topology.getAllFaceVertices(self.mDagPath))

        xNeighbors = [None] * len(self.aIds)

        if sLoopCurve:
            aAllOrigs = np.zeros(self.getTotalCount(), dtype=int)
            aAllOrigs.fill(-1)
            if isinstance(sLoopCurve, str):
                iClosestIds = cmds.kt_findClosestPoints(fromMesh=sLoopCurve, toMesh=self.getOrigShape(), vertex=True)
                iClosestIds = list([int(iId) for iId in iClosestIds])
            elif isinstance(sLoopCurve, list):
                iClosestIds = sLoopCurve
            else:
                raise Exception('not sure what to do with type "%s" of sLoopCurve (%s)' % (type(sLoopCurve), sLoopCurve))

            aClosestIds = np.array(iClosestIds, dtype=int)
            aAllOrigs[aClosestIds] = aClosestIds
            iNextIds = list(iClosestIds)

            aMapArray = utils.getIdsToIndicesMapper(self.aIds, iTotalCount=self.getTotalCount(), iFillNonUsed=-1)
            for i in range(self.getTotalCount()): # just to be safe
                iNewNextIds = []
                if not len(iNextIds):
                    break

                for iId in iNextIds:
                    iOrigId = aAllOrigs[iId]
                    mVertexIter.setIndex(int(iId))
                    iConnectedIds = mVertexIter.getConnectedVertices()
                    iValidConnectedIds = [iConnId for iConnId in iConnectedIds if aAllOrigs[iConnId] in [iOrigId, -1]]
                    iValidNonUsedConnectedIds = [iConnId for iConnId in iConnectedIds if aAllOrigs[iConnId] == -1]

                    if not len(iValidConnectedIds):
                        continue
                    if i == 0 or len(iValidNonUsedConnectedIds) == 1: # after first go, if we have a fork, we'll cancel
                        for iValidId in iValidConnectedIds:
                            if aAllOrigs[iValidId] == -1:
                                iNewNextIds.append(iValidId)
                                aAllOrigs[iValidId] = iOrigId
                        iInd = aMapArray[iId]
                        if iInd != -1:
                            xNeighbors[iInd] = iValidConnectedIds
                iNextIds = list(iNewNextIds)

        if bJustBorders:
            aBorders = self.getBorderBoolArray()


        for i,iId in enumerate(self.aIds):
            if not utils.isNone(xNeighbors[i]):
                continue

            if bIncludeOpposites:
                aConnectedFaces = np.array(iVertexFaces[iId], dtype=int)
                aConnectedVertices = np.unique(aFaceVertices[aConnectedFaces])
                aConnectedVertices = aConnectedVertices[aConnectedVertices != iId]
            else:
                mVertexIter.setIndex(int(iId))
                aConnectedVertices = np.array(mVertexIter.getConnectedVertices(), dtype=int)

            if bJustBorders:
                aConnectedVertices = [iVert for iVert in aConnectedVertices if aBorders[iVert]]

            if bExcludeNeighborsNotInIds:
                aUsed = aUsedIds[aConnectedVertices]
                iUsedNeighbors = list(aConnectedVertices[aUsed])
            else:
                iUsedNeighbors = list(aConnectedVertices)
            xNeighbors[i] = iUsedNeighbors
            if len(iUsedNeighbors) > iMaxNeighborCount:
                iMaxNeighborCount = len(iUsedNeighbors)
                
        return xNeighbors


    def getBorderBoolArray(self):
        aBorders = np.zeros(self.getTotalCount(), dtype=bool)
        itVertex = OpenMaya2.MItMeshVertex(self.mDagPath)
        while not itVertex.isDone():
            if itVertex.onBoundary():
                aBorders[itVertex.index()] = True
            itVertex.next()
        return aBorders


    def getVertexQueueBetween(self, iStartId, iEndIds, iiNeighbors=None):
        iEndIds = utils.toList(iEndIds)
        if utils.isNone(iiNeighbors):
            iiNeighbors = self.getNeighbors()

        iVisited = set()

        iQueue = []
        iQueue.append(iStartId)

        dPrev = {i: None for i in range(len(iiNeighbors))}

        while iQueue:
            iCurrent = iQueue.pop(0)

            if iCurrent in iEndIds:
                iEndId = iCurrent
                break

            iVisited.add(iCurrent)

            for iNeighbor in iiNeighbors[iCurrent]:
                if iNeighbor in iVisited:
                    continue
                iQueue.append(iNeighbor)
                dPrev[iNeighbor] = iCurrent


        # Create a list of the optimal path
        iPath = []
        iCurrent = iEndId
        while dPrev[iCurrent] is not None:
            iPath.append(iCurrent)
            iCurrent = dPrev[iCurrent]
        iPath.append(iStartId)
        iPath.reverse()
        return iPath



    def getMirrorTable(self, bIds=True, iMiddleEdge=None):
    
        if bIds:
            if not iMiddleEdge:
                iMiddleEdge = topology.detectMiddleEdge(self)

            sEdge = '%s.e[%d]' % (self.getOrigShape(), iMiddleEdge)
            sSelBefore = cmds.ls(sl=True)
            cmds.select(self.getName())
            iTable = cmds.kt_edgeFlowMirror(me=sEdge)
            cmds.select(sSelBefore)
            aTable = np.array(iTable, dtype=int)
            iPointCount = aTable.size // 2
            return aTable[:iPointCount], aTable[iPointCount:]
        else:
            fClosestArray = cmds.kt_findClosestPoints(fromMesh=self.getOrigShape(), toMesh=self.getOrigShape(), vertex=True, mirror=True)
            aTable = np.array(fClosestArray, dtype='int')
            aPoints = self.getAllPoints()
            aSide = np.where(aPoints[:,0] > 0.0, 1, 2)
            aSide[aTable==np.arange(len(aTable))] = 0

            return aTable, aSide



    def getMirrorTablePointsOnFaces(self, pOtherMesh=None):
        aFaceVerticesAll, aCoordsAll, aClosestMeshes = barycentric.getVertexCoordinates(self if utils.isNone(pOtherMesh) else pOtherMesh, self, bMirror=True, bClosestVertex=False, aOverrideIds=np.arange(self.getTotalCount()))
        aPoints = self.getAllPoints()
        aSide = np.where(aPoints[:,0] > 0.0, 1, 2)
        return aFaceVerticesAll, aCoordsAll, aSide


    def getEdgeIntersections(self, pIntersector):
        fnMesh = OpenMaya2.MFnMesh(self.mDagPath)
        accelParams = fnMesh.autoUniformGridParams()
        mIntersectionPoints = []
        iIntersectionEdges = []
        
        if isinstance(pIntersector, MeshPatch):
            fnMeshIntersector = OpenMaya2.MFnMesh(utils.getDagPath(pIntersector.mDagPath))
            aPointsIntersector = pIntersector.getAllPoints(bWorld=True)
            aEdges = np.zeros((fnMeshIntersector.numEdges,2), dtype=int)
            for edge in range(fnMeshIntersector.numEdges):
                aEdges[edge] = fnMeshIntersector.getEdgeVertices(edge)
            
        elif isinstance(pIntersector, CurvePatch):
            aPointsIntersector = pIntersector.getAllPoints(bWorld=True)
            iVertexCount = len(aPointsIntersector)
            aEdges = np.zeros((iVertexCount-1,2), dtype=int)
            aEdges[:,0] = np.arange(iVertexCount-1)
            aEdges[:,1] = np.arange(iVertexCount-1)+1
        else:
            raise Exception('getEdgeIntersections is currently not supported with %s' % str(type(pIntersector)))
        
        
        aEdgeDirections = aPointsIntersector[aEdges[:,1]] - aPointsIntersector[aEdges[:,0]]
        aEdgeLengths = np.linalg.norm(aEdgeDirections, axis=-1)
        aEdgeDirections /= aEdgeLengths[:,np.newaxis]
        for edge in range(aEdges.size // 2):
            dir = OpenMaya2.MFloatVector(aEdgeDirections[edge])
            pos = OpenMaya2.MFloatPoint(aPointsIntersector[aEdges[edge,0]])

            xxIntersReturn = fnMesh.closestIntersection(pos, dir, OpenMaya2.MSpace.kWorld, aEdgeLengths[edge], False, accelParams=accelParams)
            if not utils.isNone(xxIntersReturn): # in maya 2022 it returns None if there no intersections, and in 2019 it returns a tuple with iFace equals -1
                mPoint, _, iFace, _, _, _ = xxIntersReturn
                if iFace != -1:
                    mIntersectionPoints.append(mPoint)
                    iIntersectionEdges.append(edge)

        return mIntersectionPoints, iIntersectionEdges


    def getAllVertexEdges(self):
        fnVertexIter = OpenMaya2.MItMeshVertex(self.mDagPath)
        iVertexEdges = []
        while not fnVertexIter.isDone():
            iVertexEdges.append(fnVertexIter.getConnectedEdges())
            fnVertexIter.next()
        return iVertexEdges


    def getIslands(self, bFullObject=True, bReturnNumpyList=False):
        iNeighbors = self.getNeighbors(bExcludeNeighborsNotInIds=not bFullObject)
        aIdsMapper = utils.getIdsToIndicesMapper(self.aIds)
        
        iIslands = [list(iNeighbors[i]) for i in range(len(self.aIds))]
        for i, aId in enumerate(self.aIds):
            if not iIslands[i]:
                continue
            k = 0
            while k < len(iIslands[i]):
                currentId = iIslands[i][k]
                currentIdMapped = aIdsMapper[currentId]
                if currentIdMapped != -1 and iIslands[currentIdMapped] and currentId != self.aIds[aIdsMapper[aId]]:
                    iIslands[i] += iIslands[currentIdMapped]
                    iIslands[currentIdMapped] = None
                k += 1
    
        iIslands = [list(set(iI)) for iI in iIslands if iI]
        [iI.sort() for iI in iIslands]
        iIslands += [[self.aIds[i]] for i, iI in enumerate(iNeighbors) if not iI] # single verts
        if bReturnNumpyList:
            return [np.array(iI, dtype=int) for iI in iIslands]
        else:
            return iIslands

    #
    # def getFeatherIslands(self):
    #     pass
    #


    def getAllFaceVertices(self):
        it = OpenMaya2.MItMeshPolygon(self.mDagPath)
        iFaceVertices = []
        if cmds.about(version=True).startswith('201'):
            while not it.isDone():
                edges = it.getVertices()
                iFaceVertices.append(edges)
                it.next(None)
        else:
            while not it.isDone():
                edges = it.getVertices()
                iFaceVertices.append(edges)
                it.next()
        return iFaceVertices
    
    
    def recreateData(self, bOrigIfSameVertCount=True, bAsTriangles=False, bWorld=True):
        fnMesh = OpenMaya2.MFnMesh(self.mDagPath)
        bOrig = False
        if bOrigIfSameVertCount:
            fnMeshOrig = OpenMaya2.MFnMesh(utils.getDagPath(self.getOrigShape()))
            if fnMesh.numVertices == OpenMaya2.MFnMesh(self.mDagPath).numVertices:
                fnMesh = fnMeshOrig
                bOrig = True


        if bAsTriangles:
            _, mTriangleVertexIds = fnMesh.getTriangles()
            aPolygonCounts = np.empty(len(mTriangleVertexIds) // 3, dtype=int)
            aPolygonCounts.fill(3)
            aFaceVertexIds = np.array(list(mTriangleVertexIds), dtype=int)
        else:
            iiFaceVertices = topology.getAllFaceVertices(self.mDagPath)
            aPolygonCounts = np.array([len(iV) for iV in iiFaceVertices], dtype=int)
            # iFaceVertexIds = reduce(lambda a,b:a+b, iiFaceVertices) # old way - very slow on larger objects!
            iFaceVertexIds = list(itertools.chain(*iiFaceVertices))
            aFaceVertexIds = np.array(iFaceVertexIds, dtype=int)

        return {'type':PatchTypes.mesh,
                'points':self.getAllPoints(bOrig=bOrig, bWorld=bWorld),
                'polygonCounts':aPolygonCounts,
                'polygonConnects':aFaceVertexIds}
    
    '''
 
    def getAllVertexFaces(self, bNumpy=True):
        iter = OpenMaya2.MItMeshVertex(self.mDagPath)
        if aIds == None:
            aIds = np.arange(iter.count)
        iReturns = []
        for i, id in enumerate(aIds):
            iter.setIndex(id)
            iReturns.append(list(iter.getConnectedFaces()))
        return iReturns
    '''


class LatticePatch(Patch):
    def __init__(self, mDagPath, aIds=None, aSofts=None):
        print ('............. init lattice patch', mDagPath, type(mDagPath))
        Patch.__init__(self, mDagPath, aIds=aIds, aSofts=aSofts)

    def __repr__(self):
        return 'lattice: "%s" ids: %s softs: %s' % (self.mDagPath.partialPathName(), self.aIds, self.aSofts)


    def getTotalCount(self):
        return len(cmds.ls('%s.pt[*][*][*]' % self.getName(), flatten=True))


    def getDimensions(self, bNumpy=False):
        sName = self.getName()
        iLenX = len(cmds.ls('%s.pt[*][0][0]' % sName, flatten=True))
        iLenY = len(cmds.ls('%s.pt[0][*][0]' % sName, flatten=True))
        iLenZ = len(cmds.ls('%s.pt[0][0][*]' % sName, flatten=True))
        if bNumpy:
            return np.array([iLenX, iLenY, iLenZ], dtype=int)
        else:
            return iLenX, iLenY, iLenZ


    def getIndices(self):
        iDims = self.getDimensions()
        iiiIds = []
        for z in range(iDims[2]):
            for y in range(iDims[1]):
                for x in range(iDims[0]):
                    iiiIds.append((x, y, z))
        return iiiIds
    
    
    def getIdsMapper(self):
        iDims = self.getDimensions()
        aaaMapper = np.zeros((iDims), dtype=int)
        iCounter = 0
        for z in range(iDims[2]):
            for y in range(iDims[1]):
                for x in range(iDims[0]):
                    aaaMapper[x,y,z] = iCounter
                    iCounter += 1
        return aaaMapper

    
    # def getMapperToIdsOld(self):
    #     iDim = self.getDimensions()
    #     aaaIds = np.zeros((iDim), dtype=int)
    #     aaaIds[:] = np.arange(self.getTotalCount())
    #     return aaaIds
        
 
    
    
    def getIndexedComponents(self, aOverrideIds=None):
        fnVtxComp = OpenMaya2.MFnTripleIndexedComponent()
        self.mComponents = fnVtxComp.create(OpenMaya2.MFn.kLatticeComponent)
        fnVtxComp.addElements(self.getIndices())
        return self.mComponents


    def getAllPoints(self, bWorld=True, bOrig=False):
        if bOrig:
            sShape = self.getOrigShape()
        else:
            sShape = self.getName()
        return np.array(cmds.xform('%s.pt[*][*][*]' % sShape, q=True, ws=bWorld, t=True), dtype='float64').reshape(-1,3)
    
    
    def getPoints(self, bWorld=True, bOrig=False):
        aAllPoints = self.getAllPoints()
        return aAllPoints[self.aIds]


    def _idsToPts(self, aIds):
        return self.getIndices()[aIds]


    # THIS IS NOT WORKING YET!!
    def getNeighbors(self, bExcludeNeighborsNotInIds=True):
        return []
    
        if len(self.aIds) == self.getTotalCount():
            bExcludeNeighborsNotInIds = False
    
        if bExcludeNeighborsNotInIds:
            aUsedIds = np.zeros(self.getTotalCount() + 1, dtype=bool)
            aUsedIds[self.aIds] = True
    
        aPts = self._idsToPts(self.aIds)
        xNeighbors = []
    
        iDimX,iDimY,iDimZ = self.getDimensions()
    
        for iPt in aPts:
            aAssignIds = []
            for iOffset in [(-1, 0, 0), (1, 0, 0), (0, -1, 0), (0, 1, 0), (0, 0, -1), (0, 0, 1)]:
                iNewPt = [iPt[0] + iOffset[0],
                          iPt[1] + iOffset[1],
                          iPt[2] + iOffset[2]]
                if  iNewPt[0] >= 0 and iNewPt[0] < iDimX and \
                    iNewPt[1] >= 0 and iNewPt[1] < iDimY and \
                    iNewPt[2] >= 0 and iNewPt[2] < iDimY:
                    aId = 0 # this needs to be finished!
                    if not bExcludeNeighborsNotInIds or aUsedIds[aId]:
                        aAssignIds.append(iId)
        
            xNeighbors.append(aAssignIds)
        return xNeighbors



class SurfacePatch(Patch):

    def __init__(self, mDagPath, aIds=None, aCvs=None, aSofts=None):
        Patch.__init__(self, mDagPath, aIds=aIds, aSofts=aSofts)


        if not utils.isNone(aCvs):# != None:
            if not utils.isNone(aIds):# != None:
                raise Exception('you tried to create a SurfacePatch with passing aIds AND aCvs. You can only use either one or the other')
            self.aIds = self._cvsToIds(aCvs)

    def getUVCounts(self):
        # fnSurface = OpenMaya2.MFnNurbsSurface(self.mDagPath)
        # return fnSurface.numCVsInU, fnSurface.numCVsInV
        uCount = len(cmds.ls('%s.cv[*][0]' % self.getName(), flatten=True))
        vCount = len(cmds.ls('%s.cv[0][*]' % self.getName(), flatten=True))
        return uCount, vCount


    def getNeighbors(self, bExcludeNeighborsNotInIds=True, sLoopCurve=None):

        if sLoopCurve:
            raise Exception('sLoopCurve flag not supported for surfaces')

        if len(self.aIds) == self.getTotalCount():
            bExcludeNeighborsNotInIds = False
        
        if bExcludeNeighborsNotInIds:
            aUsedIds = np.zeros(self.getTotalCount()+1, dtype=bool)
            aUsedIds[self.aIds] = True
            
        # fnSurface = OpenMaya2.MFnNurbsSurface(self.mDagPath)
        aCvs = self._idsToCvs(self.aIds)
        xNeighbors = []
        
        iUCount, iVCount = self.getUVCounts()
        
        for iCv in aCvs:
            aAssignIds = []
            for iOffset in [(-1,0),(1,0),(0,-1),(0,1)]:
                iNewCv = [iCv[0] + iOffset[0], iCv[1] + iOffset[1]]
                if iNewCv[0] >= 0 and iNewCv[0] < iUCount and iNewCv[1] >= 0 and iNewCv[1] < iVCount:
                    iId = iNewCv[0] * iVCount + iNewCv[1]
                    if not bExcludeNeighborsNotInIds or aUsedIds[aId]:
                        aAssignIds.append(iId)
            
            xNeighbors.append(aAssignIds)
        return xNeighbors


    def getBorderBoolArray(self):
        iUCount, iVCount = self.getUVCounts()
        
        aBorders = np.ones((iUCount, iVCount), dtype=bool)
        aBorders[1:-1, 1:-1] = False
        return aBorders.flatten()
    

    def getTotalCount(self):
        uCount, vCount = self.getUVCounts()
        return uCount * vCount
        # fnSurface = OpenMaya2.MFnNurbsSurface(self.mDagPath)
        # return fnSurface.numCVsInU * fnSurface.numCVsInV


    def getIndexedComponents(self, aOverrideIds=None):
        aIds = self.aIds if utils.isNone(aOverrideIds) else aOverrideIds
        iUCount, iVCount = self.getUVCounts()

        # aElements = np.zeros((iUCount,2), dtype=int)
        aUs = aIds // iVCount
        aVs = aIds % iVCount
        fnCvsComp = OpenMaya2.MFnDoubleIndexedComponent()
        self.mCvs = fnCvsComp.create( OpenMaya2.MFn.kSurfaceCVComponent )
        fnCvsComp.addElements(list(zip(aUs,aVs)))
        return self.mCvs


    def getAllPoints(self, bWorld=True, bOrig=False):
        return np.array(cmds.xform('%s.cv[*][*]' % (self.getOrigShape() if bOrig else self.getName()), q=True, ws=bWorld, t=True),
                        dtype='float64').reshape(-1,3)
    

    def setPoints(self, aPoints, aIds=None, bWorld=True):
        ## this doesnt work in 2016: fnNurbsSurface.setCVPositions(pArray)
        if utils.isNone(aIds): #== None:
            aIds = np.arange(self.getTotalCount())

        aCvs = self._idsToCvs(aIds)
        sShape = self.getName()
        
        cmds.undoInfo(openChunk=True)
        try:
            for i in range(len(aIds)):
                iU, iV = aCvs[i]
                cmds.move(aPoints[i,0], aPoints[i,1], aPoints[i,2], '%s.cv[%d][%d]' % (sShape, iU, iV),
                            a=True, os=not bWorld)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)
            
        


    def _cvsToIds(self, aCvs):
        #from documentation - MFnNurbsSurface.getCVs returns it in this index:
        #index = numCVsInV() * uIndex + vIndex".
        _, iVCount = self.getUVCounts()
        aIds = aCvs[...,0] * iVCount + aCvs[...,1]
        aIds[aIds < 0] = self.getTotalCount()
        return aIds


    def _idsToCvs(self, aIds):
        iUCount, iVCount = self.getUVCounts()
        aCvs = np.zeros((len(aIds),2), dtype=int)
        aCvs[:,0] = aIds / iVCount
        aCvs[:,1] = aIds % iVCount
        return aCvs


    def getMirrorTable(self, bIds=True, iMiddleEdge=None):
        if iMiddleEdge:
            cmds.warning('middle edge is being ignored for nurbs')
        return topology.getNurbsMirrorTable(self)


    def getReverseIndices(self): # for mirroring to keep the normals mirrored
        iUCount, iVCount = self.getUVCounts()

        aSwapped = np.arange(self.getTotalCount())
        for u in range(iUCount):
            for v in range(iVCount):
                aSwapped[u*iVCount + v] = u*iVCount + iVCount-1-v
        return aSwapped


    def matchTopology(self, pOpp):
        # iUCountOpp, iVCountOpp = pOpp.getUVCounts()
        iSpans = cmds.getAttr('%s.spansUV' % pOpp.getTransformName())[0]
        iDegree = cmds.getAttr('%s.degreeUV' % pOpp.getTransformName())[0]
        cmds.rebuildSurface(self.getName(), ch=True, rpo=1, rt=0, end=1, kr=0, kcp=0, kc=0, su=iSpans[0], sv=iSpans[1], du=iDegree[0], dv=iDegree[1], tol=0.01, fr=0, dir=2)


    def getIslands(self, bFullObject=True):
        if bFullObject == False:
            cmds.warning('setting bFullObject on getIslands() to True, because False is not supported yet on Surfaces')
        return [self.aIds] # used do be [[self.aIds]]


    def recreateData(self, bOrig=True, bWorld=True):
        fnSurface = OpenMaya2.MFnNurbsSurface(self.mDagPath)
        mUKnots = fnSurface.knotsInU()
        mVKnots = fnSurface.knotsInV()

        return {'type':PatchTypes.surface,
                'points':self.getAllPoints(bOrig=bOrig, bWorld=bWorld),
                'uKnots':np.array(list(mUKnots), dtype='float64'),
                'vKnots':np.array(list(mVKnots), dtype='float64'),
                'uDegree':fnSurface.degreeInU,
                'vDegree':fnSurface.degreeInV,
                'uForm':fnSurface.formInU,
                'vForm':fnSurface.formInV,
                 }

    def getTotalFaceCount(self):
        iUCount, iVCount = self.getUVCounts()
        return (iUCount-1) * (iVCount-1)


    def getAllFaceVertices(self):
        iTotalFaceCount = self.getTotalFaceCount()
        iFaceVertices = []
        iUCount, iVCount = self.getUVCounts()
        for u in range(iUCount-1):
            for v in range(iVCount-1):
                iVerts = np.array([(u,v), (u+1,v), (u+1,v+1), (u,v+1)])
                iFaceVertices.append(self._cvsToIds(iVerts))
        return iFaceVertices



    #create(cvs, uKnots, vKnots, uDegree, vDegree, uForm, vForm,
    #    rational, parent=kNullObj) -> MObject




class CurvePatch(Patch):
    def __init__(self, sName, aIds=None, aSofts=None):
        Patch.__init__(self, sName, aIds=aIds, aSofts=aSofts)
        #iTotalCount = MFnCurve(self.mDagPath).numCvs;

    def getTotalCount(self):
        return len(cmds.ls('%s.cv[*]' % self.getName(), flatten=True)) # changed recently to make it work for circles (closed curves)
        # return OpenMaya2.MFnNurbsCurve(self.mDagPath).numCVs


    # not tested yet:
    def select(self):
        sTransform = self.getTransformName()
        cmds.select(['%s.cv[%d]' % (sTransform, iId) for iId in self.aIds])


    def getIndexedComponents(self, aOverrideIds=None):
        fnVtxComp = OpenMaya2.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya2.MFn.kCurveCVComponent )
        fnVtxComp.addElements(list(aOverrideIds if not utils.isNone(aOverrideIds) else self.aIds))
        return self.mComponents


    def getIndexedComponentsOldApi(self, aOverrideIds=None):
        fnVtxComp = OpenMaya.MFnSingleIndexedComponent()
        self.mComponents = fnVtxComp.create( OpenMaya.MFn.kMeshVertComponent )
        aIds = aOverrideIds if not utils.isNone(aOverrideIds) else self.aIds
        mIds = OpenMaya.MIntArray(len(aIds))
        for i,id in enumerate(aIds):
            mIds.set(int(id),int(i)) # one of them needs to not get converted to int
        fnVtxComp.addElements(mIds)
        return self.mComponents


    def getMirrorTable(self, bIds=True, iMiddleEdge=None):
        aPoints = self.getAllPoints()
        iTotalCount = len(aPoints)

        if cmds.attributeQuery('brokenCircle', node=self.getTransformName(), exists=True):
            iClosestToMiddle = np.argsort(np.abs(aPoints[:,0]))
            aMiddleIds = np.sort([iClosestToMiddle[0], iClosestToMiddle[1]])

            iLoopA = list(range(0, aMiddleIds[0], 1))
            if len(iLoopA):
                iLoopB = list(range(min(aMiddleIds[0] + len(iLoopA), aMiddleIds[1]), aMiddleIds[0], -1))
            else:
                iLoopB = []

            iLoopC = list(range(iTotalCount - 1, aMiddleIds[1], -1))
            if len(iLoopC):
                iLoopD = list(range(aMiddleIds[1] - len(iLoopC), aMiddleIds[1], 1))
            else:
                iLoopD = []

            aLefts = np.array(iLoopA + iLoopC, dtype=int)
            aRights = np.array(iLoopB + iLoopD, dtype=int)
            aTable = np.empty(iTotalCount, dtype=int)
            aTable[aLefts] = aRights
            aTable[aRights] = aLefts
            aTable[aMiddleIds] = aMiddleIds
            fLeftAverageX = np.average(aPoints[aLefts], axis=0)[0]
            fRightAverageX = np.average(aPoints[aRights], axis=0)[0]

            aSides = np.zeros(iTotalCount, dtype=int)
            if fLeftAverageX > fRightAverageX:
                aSides[aLefts] = 1
                aSides[aRights] = 2
            else:
                aSides[aLefts] = 2
                aSides[aRights] = 1
            return aTable, aSides

        else: # normal curves that go through the middle
            if not iTotalCount % 2:
                raise Exception('Curve needs to have uneven cv count for getting mirror table (%s)' % self.getTransformName())
            aTable = np.arange(iTotalCount)
            iMiddleCv = iTotalCount // 2
            aTable[np.arange(0,iMiddleCv)] = np.arange(iTotalCount-1, iMiddleCv, -1)
            aTable[np.arange(iTotalCount-1, iMiddleCv, -1)] = np.arange(0,iMiddleCv)

            aSides = np.zeros(iTotalCount, dtype=int)
            if aPoints[0,0] > aPoints[-1,0]:
                aSides[np.arange(0, iMiddleCv)] = 1
                aSides[np.arange(iTotalCount - 1, iMiddleCv, -1)] = 2
            else:
                aSides[np.arange(0, iMiddleCv)] = 2
                aSides[np.arange(iTotalCount - 1, iMiddleCv, -1)] = 1

            return aTable, aSides


    def getNeighbors(self, bExcludeNeighborsNotInIds=True, sLoopCurve=None):
        if sLoopCurve:
            raise Exception('sLoopCurve flag not supported for curves')

        xNeighbors = []

        if bExcludeNeighborsNotInIds:
            aUsedIds = np.zeros(self.getTotalCount(), dtype=bool)
            aUsedIds[self.aIds] = True
        
        for iId in self.aIds:
            iCvs = []
            for i in (iId-1, iId+1):
                if i >= 0 and i < self.getTotalCount():
                    if not bExcludeNeighborsNotInIds or aUsedIds[i]:
                        iCvs.append(i)
            
            xNeighbors.append(iCvs)
        return xNeighbors


    def getAllPoints(self, bWorld=True, bOrig=False):
        return np.array(cmds.xform('%s.cv[*]' % (self.getOrigShape() if bOrig else self.getName()), q=True, ws=bWorld, t=True),
                        dtype='float64').reshape(-1,3)

    def getIslands(self, bFullObject=True):
        if bFullObject == False:
            cmds.warning('setting bFullObject on getIslands() to True, because False is not supported yet on Curves')
        return [self.aIds] # used do be [[self.aIds]]


    def getBorderBoolArray(self):
        aBorders = np.zeros(self.getTotalCount(), dtype=bool)
        aBorders[0] = True
        aBorders[-1] = True
        return aBorders


    def getTotalFaceCount(self):
        return self.getTotalCount()-1


    def getAllFaceVertices(self):
        iTotalFaceCount = self.getTotalFaceCount()
        iFaceVertices = []
        for i in range(iTotalFaceCount):
            iFaceVertices.append((i,i+1))
        return iFaceVertices


    def recreateData(self, bOrig=True, bWorld=True):
        fnCurve = OpenMaya2.MFnNurbsCurve(self.mDagPath)
        mKnots = fnCurve.knots()
        
        return {'type':PatchTypes.curve,
                'points':self.getAllPoints(bOrig=bOrig, bWorld=bWorld),
                'knots':np.array(list(mKnots), dtype='float64'),
                'degree':fnCurve.degree,
                'form':fnCurve.form,
                 }


    def setPoints(self, aPoints, aIds=None, bWorld=True):
        ## this doesnt work in 2016: fnNurbsSurface.setCVPositions(pArray)
        if utils.isNone(aIds): # == None:
            aIds = np.arange(self.getTotalCount())

        sShape = self.getName()

        cmds.undoInfo(openChunk=True)
        try:
            for i,iId in enumerate(aIds):
                cmds.move(aPoints[i, 0], aPoints[i, 1], aPoints[i, 2], '%s.cv[%d]' % (sShape, iId), a=True, os=not bWorld)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


def patchFromName(sName, bConsiderSelection=False):
    if not sName:
        raise Exception('cannot make a patch from "%s"' % sName)
    if not sName or not cmds.objExists(sName):
        raise Exception('cannot make a patch from "%s", it doesn\'t exist' % sName)

    if bConsiderSelection:
        tbSel = getSelectedPatches()
        for tbS in tbSel:
            if sName in [tbS.getName(), tbS.getTransformName()]:
                return tbS

    try:
        mDagPath = utils.getDagPath(sName)
        mDagPath = mDagPath.extendToShape()
    except Exception as e:
        raise Exception('Error with "%s", it may not be a geometry ("%s")' % (sName, str(e)))
    if mDagPath.hasFn(OpenMaya2.MFn.kMesh):
        return MeshPatch(mDagPath, None, None)
    if mDagPath.hasFn(OpenMaya2.MFn.kNurbsSurface):
        return SurfacePatch(mDagPath, None, None)
    if mDagPath.hasFn(OpenMaya2.MFn.kNurbsCurve):
        return CurvePatch(mDagPath, None, None)
    if mDagPath.hasFn(OpenMaya2.MFn.kLattice):
        return LatticePatch(mDagPath, None, None)




def patchesFromDeformer(sDeformer):
    sGeos = cmds.deformer(sDeformer, q=True, g=True)
    return [patchFromName(sG) for sG in sGeos]


def getSelectedPatches(bAlwaysReturnFullGeometry=False):
    try:
        mRichSelection = OpenMaya2.MGlobal.getRichSelection()
    except:
        return []
    mSelection = mRichSelection.getSelection()
    selection = []
    mComponentPatches = []

    # mesh verts:
    #
    
    for kType, PatchClass in [  (OpenMaya2.MFn.kMeshVertComponent, MeshPatch),
                                (OpenMaya2.MFn.kCurveCVComponent, CurvePatch)]:
                                
        iter = OpenMaya2.MItSelectionList(mSelection, kType)
        while not iter.isDone():
            mDagPath, component = iter.getComponent()
            fnComp = OpenMaya2.MFnSingleIndexedComponent(component)
            mDagPath.pop()
            
            if bAlwaysReturnFullGeometry:
                aIds = None
            else:
                aIds = np.array([fnComp.element(i) for i in range(fnComp.elementCount)], dtype=int)

            if fnComp.hasWeights:
                aSofts = np.array([fnComp.weight(i).influence for i in range(fnComp.elementCount)], dtype='float64')
            else:
                aSofts = None

            mShape = mDagPath.extendToShape()
            selection.append(PatchClass(mShape, aIds, aSofts))
            mComponentPatches.append(mShape)
            iter.next()


    # nurbs surface cvs:
    #
    iter = OpenMaya2.MItSelectionList( mSelection, OpenMaya2.MFn.kSurfaceCVComponent)
    while not iter.isDone():
        mDagPath, component = iter.getComponent()
        fnComp = OpenMaya2.MFnDoubleIndexedComponent(component)
        mDagPath.pop()
        
        aCvs = np.array(fnComp.getElements(), dtype=int)
        if fnComp.hasWeights:
            aSofts = np.array([fnComp.weight(i).influence for i in range(fnComp.elementCount)], dtype='float64')
        else:
            aSofts = None

        selection.append(SurfacePatch(mDagPath.extendToShape(), aCvs=aCvs, aSofts=aSofts))

        iter.next()



    # Whole Geometries
    #
    xTypes = [('mesh',MeshPatch), ('nurbsCurve',CurvePatch), ('nurbsSurface',SurfacePatch)]
    for sType,PatchClass in xTypes:
        for sShape in cmds.ls(sl=True, et=sType):
            selection.append(PatchClass(utils.getDagPath(sShape), None, None))
    for sTransform in cmds.ls(sl=True, et='transform'):
        for sType,PatchClass in xTypes:
            sShapes = cmds.listRelatives(sTransform, typ=sType)
            if sShapes:
                selection.append(PatchClass(utils.getDagPath(sShapes[0]), None, None))

    #
    # for kType, PatchClass in [  (OpenMaya2.MFn.kMesh, MeshPatch),
    #                             (OpenMaya2.MFn.kNurbsCurve, CurvePatch),
    #                             (OpenMaya2.MFn.kNurbsSurface, SurfacePatch)]:
    #     iter = OpenMaya2.MItSelectionList( mSelection, kType)
    #     print 'kType: ', kType, 'iter: ', iter
    #     while not iter.isDone():
    #         print 'aaa'
    #         mDagPath, component = iter.getComponent()
    #         mDagPath.pop()
    #         print 'mDagPath: ', mDagPath
    #         print 'componetn: ', component
    #         mShape = mDagPath.extendToShape()
    #         if mShape not in mComponentPatches:
    #             selection.append(PatchClass(mShape, None, None))
    #         iter.next()

    return selection


def _applyJointLocks(aLockedJoints, aFreeJoints, aWeights2d, aOldWeights2d, iMode=JointLocks.dontChangeLockedJoints):
    if iMode == JointLocks.dontChangeLockedJoints:
        aWeights2d[:,aLockedJoints] = aOldWeights2d[:,aLockedJoints]
    elif iMode == JointLocks.onlyAddWeightsToLockedJoints:
        aWeights2d[:,aLockedJoints] = np.maximum(aWeights2d[:,aLockedJoints], aOldWeights2d[:,aLockedJoints])
    elif iMode == JointLocks.onlyRemoveWeightsFromLockedJoints:
        aWeights2d[:,aLockedJoints] = np.minimum(aWeights2d[:,aLockedJoints], aOldWeights2d[:,aLockedJoints])
    aFreeSums = np.sum(aWeights2d[:,aFreeJoints], axis=1)
    aFreeSums[aFreeSums < 0.000000001] = 1.0
    aRequiredFreeSums = 1.0 - np.sum(aWeights2d[:,aLockedJoints], axis=1)
    aWeights2d[:,aFreeJoints] *= (aRequiredFreeSums / aFreeSums)[...,np.newaxis]

    # # this may cause weights to disrispect joint locks, but necessary to keep it normalized
    # aFullSums = np.sum(aWeights2d, axis=1)
    # aWeights2d *= (1.0 / aFullSums)[..., np.newaxis]

    return aWeights2d




def _removeZeroInfluencesNumpy(aWeights, aInfluences, fPrune=0.00000001):
    if fPrune != None:
        aWeights[aWeights < fPrune] = 0
    
    aZeroJoints = np.where(np.any(aWeights, axis=0) == False)[0]
    aNewInfluences = np.delete(aInfluences, aZeroJoints, axis = 0)
    aNewWeights = np.delete(aWeights, aZeroJoints, axis = 1)
    return aNewWeights, aNewInfluences



def createSkinningSphere(sName='noname', sMatch=None, fScale=(1,1,1), sParent=None, fFalloff=1.5,
                         bIsCircle=False, bKeepConstraint=False):

    makeSphere = cmds.circle if bIsCircle else cmds.sphere
    sSphereA = makeSphere(n=sName)[0]
    sSphereB = makeSphere(n='%sOuter' % sName)[0]
    sSphereB = cmds.parent(sSphereB, sSphereA)[0]
    if bIsCircle:
        cmds.rotate(0,90,0, sSphereA, r=True)
        cmds.makeIdentity(sSphereA, apply=True, r=True)

    if sMatch:
        if bKeepConstraint:
            cmds.parentConstraint(sMatch, sSphereA)
        else:
            cmds.delete(cmds.parentConstraint(sMatch, sSphereA))
        # cmds.delete(cmds.scaleConstraint(sMatch, sSphereA))

    cmds.setAttr('%s.s' % sSphereA, fScale[0], fScale[1], fScale[2])

    cmds.addAttr(sSphereA, ln='fallOff', defaultValue=fFalloff, at='double', k=True)
    sFallOff = '%s.fallOff' % sSphereA
    for sA in ['sx','sy','sz']:
        cmds.connectAttr(sFallOff, '%s.%s' % (sSphereB,sA))

    for sL in ['tx','ty','tz','rx','ry','rz','v']:
        cmds.setAttr('%s.%s' % (sSphereB, sL), lock=True, keyable=False, channelBox=False)
    cmds.setAttr('%s.template' % sSphereB, True)

    if sParent:
        cmds.parent(sSphereA, sParent)

    return sSphereA




def logSkinnedMeshes(sMeshes):
    import kangarooTools.nodes as nodes
    sAllMeshes = utils.data.get('sChangedDeformedMeshes', xDefault=set())
    sMeshTransforms = set()
    for sMesh in utils.toList(sMeshes):
        sM, sDef = sMesh.split('.')
        if cmds.objectType(sM) == 'transform':
            sMeshTransforms.add(sMesh)
        else:
            sTransform = cmds.listRelatives(sM, p=True)[0]
            sMeshTransforms.add('%s.%s' % (sTransform, sDef))

    sAllMeshes.update(sMeshTransforms)
    utils.data.store('sChangedDeformedMeshes', sAllMeshes)



def unlogSkinnedMeshes(sMeshes):
    import kangarooTools.nodes as nodes
    sAllMeshes = utils.data.get('sChangedDeformedMeshes', xDefault=set())
    sMeshTransforms = set()
    for sMesh in utils.toList(sMeshes):
        sM, sDef = sMesh.split('.')

        if cmds.objectType(sM) == 'transform':
            sMeshTransforms.add(sMesh)
        else:
            sTransform = cmds.listRelatives(sM, p=True)[0]
            sMeshTransforms.add('%s.%s' % (sTransform, sDef))

    sAllMeshes = sAllMeshes.difference(sMeshTransforms)
    utils.data.store('sChangedDeformedMeshes', sAllMeshes)


