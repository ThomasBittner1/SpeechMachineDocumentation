###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import numpy as np
import maya.cmds as cmds
import kangarooTools.nodes as nodes
import kangarooTools.utilFunctions as utils
import kangarooTools.xforms as xforms


class Type():
    pointConstraint = 0
    orientConstraint = 1
    parentConstraint = 2



kMatchAttr = '__match__'

def addAttr(sGrp, sScript):
    utils.addStringAttr(sGrp, kMatchAttr, sScript)


def generateApplyAngleCommand(iOutputIndex, iParentOutputIndex, sOutputs, iAimAxis, iUpAxis, sAttrToSet, bNegate, sNegativeAttrToSet=None):

    aMatrix = utils.getNumpyMatrixFromTransform(sOutputs[iOutputIndex])
    aParentMatrix = utils.getNumpyMatrixFromTransform(sOutputs[iParentOutputIndex])
    aLocalMatrix = np.dot(aMatrix, np.linalg.inv(aParentMatrix))
    sLocalMatrix = '[%s]' % ', '.join(['%0.3f' % a for a in aLocalMatrix.flatten()])

    sNegativeAttrToSetPass = ''
    if sNegativeAttrToSet != None:
        sNegativeAttrToSetPass = ", sNegSetAttr='%s'" % sNegativeAttrToSet
    sMatchScript = "\nsetByAngle(NAMESPACE, '{%d}', '{%d}', %s, %d, %d, '%s', %d%s)" % \
                    (iOutputIndex, iParentOutputIndex, sLocalMatrix, iAimAxis, iUpAxis, sAttrToSet, bNegate, sNegativeAttrToSetPass)
    return sMatchScript


def generateMatchingConstrainCommand2(iOutputIndex, sOutputs, sConstrainedCtrl, iConstraintType, sTransferToAttrs=None, xCondition=None, bLiveOffset=None):

    if bLiveOffset:
        sOutputJoint = sOutputs[iOutputIndex]
        sOffsetTransform = cmds.createNode('transform', p='modules', n='liveMatchingOffset_%s' % sOutputJoint)
        xforms.matrixParentConstraint(sOutputJoint, sOffsetTransform)
        sOffsetMatrix = 'None'
        sLiveOffsetTransformPass = ", sLiveOffsetTo='%s'" % sOffsetTransform
    else:
        aCtrlMatrix = utils.getNumpyMatrixFromTransform(sConstrainedCtrl)
        aOutputMatrix = utils.getNumpyMatrixFromTransform(sOutputs[iOutputIndex])
        aLocalMatrix = np.dot(aCtrlMatrix, np.linalg.inv(aOutputMatrix))
        sOffsetMatrix = '[%s]' % ', '.join(['%0.3f' % a for a in aLocalMatrix.flatten()])
        sLiveOffsetTransformPass = ''

    if utils.isNone(sTransferToAttrs):
        sTransferPass = ''
    else:
        sTransferPass = ', sTransferToAttrs=%s' % str(sTransferToAttrs)

    if utils.isNone(xCondition):
        sCondtionPass = ''
    else:
        sCondtionPass = ', xCondition=%s' % str(xCondition)

    sMatchScript = "\nconstraint2(NAMESPACE, '{%d}', '%s', %d, %s%s%s%s)" % \
                    (iOutputIndex, sConstrainedCtrl, iConstraintType, sOffsetMatrix, sTransferPass, sCondtionPass, sLiveOffsetTransformPass)
    return sMatchScript



# depricated, use generateMatchingConstrainCommand2 instead
def generateMatchingConstrainCommand(iOutputIndex, sOutputs, sConstrainedCtrl, iConstraintType=Type.parentConstraint, bOffsetR=False, bOffsetT=False):
    sCommaOffsetR, sCommaOffsetT = '', ''

    if bOffsetR or bOffsetT:

        sTempParent = cmds.createNode('transform')
        sTempTransform = cmds.createNode('transform', p=sTempParent)
        # cmds.parentConstraint(sOutputs[iOutputIndex], sTempTransform)

        cmds.delete(cmds.parentConstraint(cmds.listRelatives(sConstrainedCtrl, p=True)[0], sTempParent))
        cmds.delete(cmds.parentConstraint(sConstrainedCtrl, sTempTransform))

        if iConstraintType == Type.orientConstraint:

            sTempConstr = cmds.orientConstraint(sOutputs[iOutputIndex], sTempTransform, mo=True)[0]
            if bOffsetR:
                fOffsetR = cmds.getAttr('%s.offset' % sTempConstr)[0]
                sCommaOffsetR = ', fOffsetR=(%f, %f, %f)' % (fOffsetR[0], fOffsetR[1], fOffsetR[2])

        else:
            sTempConstr = cmds.parentConstraint(sOutputs[iOutputIndex], sTempTransform, mo=True)[0]
            if bOffsetR:
                fOffsetR = cmds.getAttr('%s.target[0].tor' % sTempConstr)[0]
                sCommaOffsetR = ', fOffsetR=(%f, %f, %f)' % (fOffsetR[0], fOffsetR[1], fOffsetR[2])
            if bOffsetT:
                fOffsetT = cmds.getAttr('%s.target[0].tot' % sTempConstr)[0]
                sCommaOffsetT = ', fOffsetT=(%f, %f, %f)' % (fOffsetT[0], fOffsetT[1], fOffsetT[2])

        cmds.delete(sTempParent)

    sMatchScript = "\nconstraint(NAMESPACE, '{%d}', '%s', %d%s%s)" % \
                    (iOutputIndex, sConstrainedCtrl, iConstraintType , sCommaOffsetR, sCommaOffsetT)

    return sMatchScript


