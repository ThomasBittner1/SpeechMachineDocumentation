###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.utilFunctions as utils
import re
import numpy as np
import maya.api.OpenMaya as OpenMaya2
import os
from collections import OrderedDict



def __valueOrList(fValue):
    if isinstance(fValue, (list, tuple)):
        return utils.flattenedList(fValue)
    else:
        return fValue


def getDefaultAttrs(sKey):
    sAttrs = utils.data.get(sKey)
    return sAttrs


def getValuesForFill(sKey):
    sAttrs = getDefaultAttrs(sKey)
    if not sAttrs:
        raise Exception('No Attributes found. Maybe this is a cleaned scene?')

    dValues = {}
    for sAttr in sAttrs:
        xValue = __valueOrList(cmds.getAttr(sAttr))
        sA = sAttr.split('.')[-1]
        if sA in 'tr' and not np.any(xValue):
            continue
        elif sA == 's' and not any([fV - 1.0 for fV in xValue]):
            continue
        dValues[sAttr] = xValue
    return dValues


def mirror(sKey):
    sAttrs = getDefaultAttrs(sKey)
    print('sAttrs: ', sAttrs)
    if not sAttrs:
        raise Exception('No Attributes found. Maybe this is a cleaned scene?')

    dValues = {sA: __valueOrList(cmds.getAttr(sA)) for sA in sAttrs}
    for sAttr in dValues.keys():
        if utils.getSide(sAttr) == 'r':
            sMirrorAttr = utils.getMirrorName(sAttr)
            if cmds.objExists(sMirrorAttr):
                # print('mirroring %s to %s' % (sMirrorAttr, sAttr))
                fMirrorValue = __valueOrList(cmds.getAttr(sMirrorAttr))
                if isinstance(fMirrorValue, (list, tuple)):
                    cmds.setAttr(sAttr, *fMirrorValue)
                else:
                    cmds.setAttr(sAttr, fMirrorValue)


def getDefaultAttrsMenu(sKey='sDefaultSettingAttrs', sArgName='dDefaultSettingValues'):
    dDefaultAttrsMenu = OrderedDict()

    def _getDefaultAttrs(sKey):
        return getDefaultAttrs(sKey)

    def infoSettingAttrs(_sKey=sKey):
        sAttrs = _getDefaultAttrs(_sKey)
        cmds.confirmDialog(t='attributes to save', m='\n'.join(sAttrs))

    dDefaultAttrsMenu['Info'] = infoSettingAttrs

    def selectSettingAttrs(_sKey=sKey):
        sAttrs = _getDefaultAttrs(_sKey)

        sObjs = list(set([sA.split('.')[0] for sA in sAttrs]))
        cmds.select(sObjs)

    dDefaultAttrsMenu['Select'] = selectSettingAttrs

    def _mirror(_sKey=sKey):
        mirror(sKey)
    dDefaultAttrsMenu['Mirror'] = _mirror

    def clearDefaultAttrsFlag(_uiArgs=None):
        _uiArgs[sArgName].setText('{}')

    dDefaultAttrsMenu['Clear'] = clearDefaultAttrsFlag

    def _fill(_sKey=sKey, _uiArgs=None):
        import kangarooTools.assets as assets
        if not assets.checkIfAssetWasBuiltInCurrentAssetConfirmBox():
            return
        dValues = getValuesForFill(_sKey)
        _uiArgs[sArgName].setText(str(dValues))

    dDefaultAttrsMenu['Fill all values'] = _fill

    return dDefaultAttrsMenu

