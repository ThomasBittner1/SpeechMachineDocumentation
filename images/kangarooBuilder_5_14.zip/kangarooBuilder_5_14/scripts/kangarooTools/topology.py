###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import numpy as np
import maya.api.OpenMaya as OpenMaya2
import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import math

def getNurbsMirrorTable(pPatch):
    sObj = pPatch.getName()
    
    iMaxU = len(cmds.ls('%s.cv[*][0]' % sObj, flatten=True))
    iMaxV = len(cmds.ls('%s.cv[0][*]' % sObj, flatten=True))
    iMiddleU = iMaxU // 2
    iMiddleV = iMaxV // 2

    # initialize to be all middle points
    #
    mapArray = np.arange(iMaxU*iMaxV, dtype=int)
    sideArray = np.zeros(iMaxU*iMaxV, dtype=int)
    fEndPos = cmds.xform('%s.cv[%d][0]' % (sObj,iMaxU-1), q=True, t=True, ws=True )
    fStartPos = cmds.xform('%s.cv[%d][0]' % (sObj,0), q=True, t=True, ws=True)
    fXDist = math.fabs(fEndPos[0]-fStartPos[0])
    fYZDist = math.sqrt(math.pow(fEndPos[1]-fStartPos[1],2) + math.pow(fEndPos[2]-fStartPos[2],2))

    if fXDist > fYZDist:
        #
        bSmallToBig = True if fEndPos[0] > fStartPos[0] else False

        # other rows:
        #
        for i in range(iMiddleU):
            iU = iMaxU - 1 - i if bSmallToBig else i
            iOppU = iMaxU - iU - 1

            for iV in range(iMaxV):
                ind = iV + iU * iMaxV
                indOpp = iV + iOppU * iMaxV

                mapArray[ind] = indOpp
                mapArray[indOpp] = ind
                sideArray[ind] = 1
                sideArray[indOpp] = 2

        return mapArray, sideArray


    # mirror in v
    #
    else:
        # find the middle axis (iStartV, iEndV)
        #
        fEndPos = cmds.xform('%s.cv[0][%d]' % (sObj,iMaxV-1), q=True, t=True, ws=True )
        fStartPos = cmds.xform('%s.cv[0][%d]' % (sObj,0), q=True, t=True, ws=True)
        fnSurface = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sObj))
        if fnSurface.formInV != OpenMaya2.MFnNurbsSurface.kOpen:


            # find out from which direction we mirror
            #
            bSmallToBig = True if fEndPos[0] > fStartPos[0] else False

            # other rows:
            #
            for i in range(iMiddleV):
                iV = iMaxV - 1 - i if bSmallToBig else i
                iOppV = iMaxV - iV - 1

                for iU in range(iMaxU):
                    ind = iU + iV * iMaxU
                    indOpp = iU + iOppV * iMaxU

                    mapArray[ind] = indOpp
                    mapArray[indOpp] = ind
                    sideArray[ind] = 1
                    sideArray[indOpp] = 2

            return mapArray, sideArray


        else:
            bSmallToBig = True
            if cmds.xform('%s.cv[0][%d]' % (sObj,iMaxV-1), q=True, t=True, ws=True )[0] < cmds.xform('%s.cv[0][0]' % sObj, q=True, t=True, ws=True )[0]:
                bSmallToBig = False

            iMiddles = np.array(cmds.xform('%s.cv[%d][*]' % (sObj,iMiddleU), q=True, t=True, ws=True ))[::3]
            iStartV = np.argmin(np.abs(iMiddles))
            iEndV = (iStartV + iMiddleV) % iMaxV
            for i in range(iMiddleV):
                iV = (iStartV + 1 + i) % iMaxV
                iOppV = (iStartV - 1 - i) % iMaxV
                if not bSmallToBig:
                    iTempV = iOppV
                    iOppV = iV
                    iV = iTempV

                for iU in range(iMaxU):
                    ind = iV + iU * iMaxV
                    indOpp = iOppV + iU * iMaxV
                    mapArray[ind] = indOpp
                    mapArray[indOpp] = ind
                    sideArray[ind] = 1
                    sideArray[indOpp] = 2
            return mapArray, sideArray




                        
def detectMiddleEdge(pPatch, bReturnString=False):

    sShape = pPatch.getOrigShape()

    aPos = np.array(cmds.xform('%s.vtx[*]' % sShape, q=True, ws=False, t=True))

    dagPath = utils.getDagPath(sShape)
    fnMesh = OpenMaya2.MFnMesh(dagPath)
    iEdgeVerts = []
    for i in range(fnMesh.numEdges):
        iVerts = fnMesh.getEdgeVertices(i)
        iEdgeVerts.append(iVerts[0])
        iEdgeVerts.append(iVerts[1])
    aVertIds = np.array(iEdgeVerts, dtype=int)

    aX = np.abs(aPos[0::3])
    aEdgesX = aX[aVertIds].reshape(fnMesh.numEdges, 2)
    aSums = aEdgesX.sum(axis=1)
    iIndex = np.argmin(aSums)

    return '%s.e[%d]' % (pPatch.getTransformName(), iIndex) if bReturnString else iIndex


def getAllVertexFaces(mMesh, aIds=None):
    iter = OpenMaya2.MItMeshVertex(mMesh)
    if aIds == None:
        aIds = np.arange(iter.count())
    iReturns = []
    for i, id in enumerate(aIds):
        iter.setIndex(int(id))
        iReturns.append(list(iter.getConnectedFaces()))
    return iReturns


def getAllEdgeVertices(mMesh, aEdgeIds=None):
    fnMesh = OpenMaya2.MFnMesh(mMesh)
    if aEdgeIds == None:
        aEdgeIds = np.arange(fnMesh.numEdges)
    aReturns = np.zeros((aEdgeIds.size, 2), dtype=int)

    for i, id in enumerate(aEdgeIds):
        iEdgeVertices = fnMesh.getEdgeVertices(id)
        aReturns[i] = iEdgeVertices[0], iEdgeVertices[1]

    return aReturns


def getAllFaceEdges(mMesh):
    it = OpenMaya2.MItMeshPolygon(mMesh)
    iFaceEdges = []
    while not it.isDone():
        edges = it.getEdges()
        iFaceEdges.append(edges)
        it.next(None) if cmds.about(version=True) == '2019' else it.next()
    return iFaceEdges


def getAllFaceVertices(mMesh):
    it = OpenMaya2.MItMeshPolygon(mMesh)
    iFaceEdges = []
    while not it.isDone():
        edges = it.getVertices()
        iFaceEdges.append(edges)
        it.next(None) if cmds.about(version=True) == '2019' else it.next()
    return iFaceEdges


def getAllVertexEdges(mMesh):
    it = OpenMaya2.MItMeshVertex(mMesh)
    iEdges = []
    while not it.isDone():
        edges = it.getConnectedEdges()
        iEdges.append(edges)
        it.next()
    return iEdges


def getAllVertexVertices(mMesh):
    it = OpenMaya2.MItMeshVertex(mMesh)
    iVerts = []
    while not it.isDone():
        verts = it.getConnectedVertices()
        iVerts.append(verts)
        it.next()
    return iVerts


def arePointsOnPlane(aPoints):
    for p in aPoints:
        mFirstVector = (OpenMaya2.MVector(aPoints[1]) - OpenMaya2.MVector(aPoints[0])).normalize()
        mFirstVectorNeg = mFirstVector * -1
        mSecondVector = None
        for i in range(2, len(aPoints), 1):
            mSecondVector = (OpenMaya2.MVector(aPoints[i]) - OpenMaya2.MVector(aPoints[0])).normalize()
            if (mSecondVector-mFirstVector).length() > 0.001 and (mSecondVector-mFirstVectorNeg).length() > 0.001:
                break
    mNormal = (mFirstVector ^ mSecondVector).normalize()
    fFirstD = mNormal * OpenMaya2.MVector(aPoints[0])
    bPerfectPlane = True
    for i in range(1, len(aPoints), 1):
        fD = mNormal * OpenMaya2.MVector(aPoints[i])
        if abs(fD-fFirstD) > 0.001:
            bPerfectPlane = False
            break
    return bPerfectPlane


def getHalfspacePointsFromCurve(pMesh, sCurve, fHalfspaceVector=[0,1,0], iMaxStepsTop=5, iMaxStepsBot=1):
    iVertexQueue, _ = getIdsAlongCurve(pMesh, sCurve)
    aStartIds = np.array(iVertexQueue, dtype=int)
    iTotal = pMesh.getTotalCount()
    aCameFrom = np.empty(iTotal, dtype=int)
    aCameFrom.fill(-1)
    aCameFrom[aStartIds] = np.arange(aStartIds.size)

    aPoints = pMesh.getPoints()
    aIsTop = np.empty(iTotal, dtype=int)
    aIsTop.fill(-1)
    aIsTop[aStartIds] = 3
    # 1 will be top, 2 bottom

    aHalfspaceVector = np.array(fHalfspaceVector, dtype='float64')
    iiNeighbors = pMesh.getNeighbors()

    iLastExpandedIds = aStartIds
    for iIter in range(max(iMaxStepsTop, iMaxStepsBot)):
        iNewExpandedIds = []
        for iAlreadyExpandedId in iLastExpandedIds:
            for iNb in iiNeighbors[iAlreadyExpandedId]:
                if aCameFrom[iNb] == -1:
                    iCameFrom = aCameFrom[iAlreadyExpandedId]
                    aLocal = aPoints[iNb] - aPoints[aStartIds[iCameFrom]]
                    fDot = np.sum(aLocal * aHalfspaceVector)
                    if fDot > 0.0 and iIter > iMaxStepsTop:
                        continue
                    elif fDot < 0.0 and iIter >iMaxStepsBot:
                        continue
                    else:
                        aIsTop[iNb] = 1 if fDot >= 0.0 else 2
                        aCameFrom[iNb] = iCameFrom
                        iNewExpandedIds.append(iNb)
        iLastExpandedIds = list(iNewExpandedIds)

    aTops = np.where(aIsTop == 1)[0]
    aBots = np.where(aIsTop == 2)[0]
    aAll = np.concatenate([aTops, aStartIds, aBots])
    return np.unique(aAll)




def getIdsAlongCurve(pMesh, sCurve, iStartCv=0, iEndCv=-1):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    fnMesh = OpenMaya2.MFnMesh(pMesh.mDagPath)
    mPoints = fnMesh.getPoints(space=OpenMaya2.MSpace.kWorld)

    iiNeighbors = pMesh.getNeighbors(bIncludeOpposites=True)
    iClosestPoints = cmds.kt_findClosestPoints(fromMesh=sCurve, toMesh=pMesh.getName(), vertex=True)
    if iEndCv == -1:
        iEndCv = len(mPoints)-1

    iClosestPoints = iClosestPoints[iStartCv:iEndCv+1]

    iFirstVert, iLastVert = int(iClosestPoints[0]), int(iClosestPoints[-1])

    _, fEndParam = fnCurve.closestPoint(OpenMaya2.MPoint(mPoints[iLastVert]))
    _, fLastParam = fnCurve.closestPoint(OpenMaya2.MPoint(mPoints[iFirstVert]))

    iVertexQueue = [iFirstVert]
    fParamQueue = [fLastParam]
    aPoints = pMesh.getPoints()

    for i in range(50):
        aNbs = np.array(iiNeighbors[iVertexQueue[-1]], dtype=int)
        aParams = np.empty(aNbs.size, dtype='float64')
        aCurvePoints = np.empty((aNbs.size, 3), dtype='float64')
        for n, iNb in enumerate(aNbs):
            mPoint, aParams[n] = fnCurve.closestPoint(mPoints[iNb], space=OpenMaya2.MSpace.kWorld)
            aCurvePoints[n, 0:3] = mPoint.x, mPoint.y, mPoint.z
        aDistances = np.linalg.norm(aCurvePoints - aPoints[aNbs], axis=1)
        aArgSort = np.argsort(aDistances)
        aSortedIds = aNbs[aArgSort]
        aSortedParams = aParams[aArgSort]

        for p, fParam in enumerate(aSortedParams):
            if fParam > fLastParam:
                iVertexQueue.append(aSortedIds[p])
                fParamQueue.append(fParam)
                fLastParam = fParam
                break

        if iVertexQueue[-1] == iLastVert:
            break
        elif fLastParam >= fEndParam * 0.995:
            iVertexQueue.append(iLastVert)
            fParamQueue.append(fnCurve.knots()[-1])
            break

    return iVertexQueue, fParamQueue

