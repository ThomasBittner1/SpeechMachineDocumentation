###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import kangarooTools.patch as patch

import kangarooTools.assets as assets
import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2
import kangarooTools.utilFunctions as utils
import kangarooTools.xforms as xforms
import kangarooTools.report as report
import kangarooTools.nodes as nodes
import kangarooTools.deformers as deformers
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.interpolator as interpolator
import os
import numpy as np
from collections import defaultdict
# import kangarooTabTools.poser as poser

iColorIndexCtrls = 0
bPolyCtrls = False
kBuilderColor = utils.uiColors.orange  # '#39a9f4'


def _tagForAttachment(cCtrl, sAttach):
    utils.addStringAttr(cCtrl.sCtrl, 'attachThisToFace', sAttach)
    # cmds.addAttr(cCtrl.sCtrl, ln='attachThisToFace')


def _getFaceCtrlGrp():
    sName = 'faceCtrls'
    if not cmds.objExists(sName):
        sSelBefore = cmds.ls(sl=True)
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.ctrlVis' % sMaster, '%s.v' % sName)
        cmds.select(sSelBefore)

    return sName



kBpParents = '__sliderBlueprints'
kFileName = 'sliderBlueprints.ma'


def exportBps():
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', kFileName))
    utils.createFolderIfNotExists(sFile)

    sAllBps = cmds.listRelatives(kBpParents, typ='joint', p=False, c=True)
    sNoExportBps = [sBp for sBp in sAllBps if cmds.getAttr('%s.doExport' % sBp) == False]
    if sNoExportBps:
        cmds.parent(sNoExportBps, w=True)

    cmds.select(kBpParents)
    report.report.addLogText('exporting "%s" to "%s" ' % (kBpParents, sFile))
    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)






def getFaceGrp():
    sName = 'faceRig'
    if not cmds.objExists(sName):
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sName)
    return sName



def makeBlendShapeBox(cCtrl, bAlongX=False, fRangeX=[0,0], fRangeY=[0,0], fRangeZ=[0,0], bBorder=True, sLockRot=['rx','ry','rz']):

    # if min equals max, this means no range and therefore off
    if (fRangeX[0] == fRangeX[1]) and (fRangeY[0] == fRangeY[1] and fRangeZ[0] == fRangeZ[1]):
        raise Exception('there is no possible range with %s' % cCtrl.sCtrl)
    elif (fRangeX[0] != fRangeX[1]) and (fRangeY[0] != fRangeY[1]):
        bTwoDim = True
    elif (fRangeY[0] == fRangeY[1]):
        bAlongX = True
        bTwoDim = False
    elif (fRangeX[0] == fRangeX[1]):
        bAlongX = False
        bTwoDim = False
    else:
        raise Exception('don\'t know what to do with %s' % cCtrl.sCtrl)

    sLockHide = sLockRot + ['sx','sy','sz', 'v', 'ro']
    if fRangeZ[0] == fRangeZ[1]:
        sLockHide.append('tz')
    else:
        cmds.transformLimits(cCtrl.sCtrl, tz=fRangeZ, etz=(True, True))


    if bTwoDim:
        if bBorder:
            aBorderPoints = ctrls.dCtrlShapes['squareZ'] * 2.0
            aBorderPoints[np.array([1,2], dtype=int),0] = fRangeX[0]
            aBorderPoints[np.array([0,3,4], dtype=int),0] = fRangeX[1]
            aBorderPoints[np.array([2,3], dtype=int),1] = fRangeY[0]
            aBorderPoints[np.array([0,1,4], dtype=int),1] = fRangeY[1]
        cmds.transformLimits(cCtrl.sCtrl, tx=fRangeX, etx=(True, True))
        cmds.transformLimits(cCtrl.sCtrl, ty=fRangeY, ety=(True, True))
        # cCtrl.lockAndHide(['r', 'tz', 's'])
    else:
        if bAlongX:
            if bBorder:
                aBorderPoints = ctrls.dCtrlShapes['lineX'] * 2.0
                aBorderPoints[0:3, 0] = fRangeX[0]
                aBorderPoints[7:11, 0] = fRangeX[1]
            cmds.transformLimits(cCtrl.sCtrl, tx=fRangeX, etx=(True, True))
            sLockHide.append('ty')
        else: # along Y
            if bBorder:
                aBorderPoints = ctrls.dCtrlShapes['lineY'] * 2.0
                aBorderPoints[0:3, 1] = fRangeY[0]
                aBorderPoints[7:11, 1] = fRangeY[1]

            cmds.transformLimits(cCtrl.sCtrl, ty=fRangeY, ety=(True, True))
            sLockHide.append('tx')

    cCtrl.lockAndHide(sLockHide)


    if bBorder:
        sTempCurve = cmds.curve(p=aBorderPoints, d=1)
        sTempCurveShape = cmds.listRelatives(sTempCurve, c=True, s=True)[0]
        sBorderTransform = cCtrl.getOffsetByName('slider')
        sOldCurveShapes = cmds.listRelatives(sBorderTransform, typ='nurbsCurve')
        if sOldCurveShapes:
            cmds.delete(sOldCurveShapes)

        cCtrl.sBorderShape = cmds.parent(sTempCurveShape, sBorderTransform, add=True, shape=True)[0]
        cmds.setAttr('%s.overrideEnabled' % cCtrl.sBorderShape, True)
        cmds.setAttr('%s.overrideDisplayType' % cCtrl.sBorderShape, 2)
        cmds.delete(sTempCurve)
    else:
        cCtrl.sBorderShape = None

    return cCtrl.sBorderShape




# DEPRICATED!!!!
def createSliderCtrl(sName, sSide='l', fScale=1.0, fScaleShape=[0.5,0.5,0.5], bMirror=True, bAlongX=False, sAttach=None, bPoly=False, iColorIndex=0,
                     sShape='sphere', fRangeX=[0,0], fRangeY=[0,0], fRangeZ=[0,0], sMatch=None, fBpPos=None, bBorder=True, dAuto={}, sAlignOnModel=[]):
    # DEPRICATED!!!!

    if bPoly:
        fScale *= 0.5
    fRangeX.sort()
    fRangeY.sort()
    fRangeZ.sort()
    if not cmds.objExists(kBpParents):
        cmds.createNode('transform', n=kBpParents)
    sSides = ['l','r'] if (bMirror == True and sSide != 'm') else [sSide]
    cCtrls = []
    iFurthestMovingVertex = -1
    for s,sSide in enumerate(sSides):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        sBp = 'sliderBp_%s_%s' % (sSide, sName)

        if not cmds.objExists(sBp):
            sMirrorBp = utils.getMirrorName(sBp)
            if cmds.objExists(sMirrorBp):
                sMirror = xforms.mirrorJoints([sMirrorBp])[0]
                sDoExport = '%s.doExport' % sMirror
                cmds.setAttr(sDoExport, lock=False)
                cmds.setAttr(sDoExport, False)
            else:
                xforms.createJoint(sBp, xPos=fBpPos, sMatch=sMatch, sParent=kBpParents)
                cmds.setAttr('%s.radius' % sBp, 0.8 * fScale)
                if len(sAlignOnModel):
                    aaAlignModels = []

                    iLengths = []
                    for m, sM in enumerate(sAlignOnModel):
                        if sM and cmds.objExists(sM):
                            aPoints = np.array(cmds.xform('%s.vtx[*]' % sM, q=True, ws=True, t=True)).reshape(-1, 3)
                            aaAlignModels.append(aPoints)
                            iLengths.append(len(aPoints))

                    if len(aaAlignModels) > 1:
                        iSmallestLength = min(iLengths)

                        for m, aPoints in enumerate(aaAlignModels):
                            aaAlignModels[m] = aPoints[:iSmallestLength]

                        aLeftPointIds = np.where(aaAlignModels[0][:, 0] > 0.0)[0]

                        aaSideAlignModels = np.zeros((len(aaAlignModels), len(aLeftPointIds), 3), dtype='float64')
                        for m, aPoints in enumerate(aaAlignModels):
                            aaSideAlignModels[m] = aaAlignModels[m][aLeftPointIds]

                        aaDiffs = aaSideAlignModels[1:] - aaSideAlignModels[0:1]
                        aaLengths = np.linalg.norm(aaDiffs, axis=-1)
                        iFurthestMovingVertexFlattened = np.argmax(aaLengths)
                        iFurthestMovingMesh = iFurthestMovingVertexFlattened / len(aLeftPointIds)
                        iFurthestMovingIndex = iFurthestMovingVertexFlattened % len(aLeftPointIds)
                        # fFurthestMovingLength = aaLengths[iFurthestMovingMesh, iFurthestMovingIndex]
                        iFurthestMovingVertex = aLeftPointIds[iFurthestMovingIndex]
                        fScale = np.max(aaLengths[:,iFurthestMovingIndex]) * 1.0

                        mNormal = OpenMaya2.MFnMesh(utils.getDagPath(sAlignOnModel[0])).getNormals()[iFurthestMovingVertex]
                        mNormal.normalize()
                        aNormal = np.array(mNormal, dtype='float64')
                        aPos = aaAlignModels[0][iFurthestMovingVertex] + aNormal*fScale*0.5
                        cmds.setAttr('%s.t' % sBp, *list(aPos))

                # if sName == 'innerEyebrow':
                #     print 'aaLengths[:,iFurthestMovingIndex]: ', aaLengths[:,iFurthestMovingIndex]
                #     print 'fScale: ', fScale
                #     print 'iFurthesstMovingVertex: ', iFurthestMovingVertex
                #     ooooo5
                cmds.setAttr('%s.s' % sBp, fScale, fScale, fScale)

        utils.addOffOnAttr(sBp, 'doExport',
                            bDefaultValue=False if sSide=='r' else True,
                            bLock=False if sSide=='r' else True,
                            bReturnNonIfExists=True)

        cCtrl = ctrls.create(sName, sSide, sMatch=sBp, sParent=_getFaceCtrlGrp(), sShape=sShape, fScaleShape=fScaleShape, bPoly=bPoly, iColorIndex=iColorIndex)
        utils.addAttr(cCtrl.sCtrl, ln='debugVertex', defaultValue=float(iFurthestMovingVertex))
        xforms.matrixParentConstraint(sBp, cCtrl.sPasser, sParentAttr='faceTempAttach')
        cCtrl.sSlider = cCtrl.appendOffsetGroup('slider')
        makeBlendShapeBox(cCtrl, bAlongX=bAlongX, fRangeX=fRangeX, fRangeY=fRangeY, fRangeZ=fRangeZ, bBorder=bBorder)
        print('sAttach: ', sAttach)
        if sAttach:
            _tagForAttachment(cCtrl, sAttach)

        cmds.setAttr('%s.s' % cCtrl.sSlider, fScale*fSideMultipl, fScale*fSideMultipl, fScale*fSideMultipl)
        cmds.setAttr('%s.s' % cCtrl.sOut, 1.0/(fScale*fSideMultipl), 1.0/(fScale*fSideMultipl), 1.0/(fScale*fSideMultipl))

        # dAuto = {'#auto:lipsCornerLFT_ctrl.ty:ty:0.5':[0.0, 1.0, 0.0, 1.0]}
        if dAuto:
            dOutputs = defaultdict(list)
            for sKey, fValues in list(dAuto.items()):
                sAttr, sDriver, sDrivenA, sDefault = sKey.split(':') #auto:lipsCornerLFT_ctrl.ty:ty:0.5
                fDefault = float(sDefault)
                if bMirror and utils.getSide(sDriver) != sSide:
                    sDriver = utils.getMirrorName(sDriver)
                sAutoAttr = utils.addAttr(cCtrl.sCtrl, ln=sAttr, minValue=0.0, maxValue=1.0, defaultValue=fDefault, k=True)
                sRange = nodes.createRangeNode(sDriver, fValues[0], fValues[1], fValues[2], fValues[3])
                sOutput = nodes.createMultiplyNode(sAutoAttr, sRange)#, sTarget='%s.%s' % (sOffset, sDrivenA))
                dOutputs[sAttr] = sOutput
            for sAttr, sOutput in list(dOutputs.items()):
                sOutAttr = utils.addAttr(cCtrl.sCtrl, ln='%sOut' % sAttr, k=False, cb=True)
                cmds.connectAttr(dOutputs[sAttr], sOutAttr)

            sAutoOutputs = nodes.createMaximumNode(list(dOutputs.values()))
            sOffset = cCtrl.appendOffsetGroup(sAttr, bAboveCtrl=True)
            cmds.connectAttr(sAutoOutputs, '%s.%s' % (sOffset, sDrivenA))
            sOutSumAttr = utils.addAttr(cCtrl.sCtrl, ln='%sOut' % sDrivenA, k=False, cb=True)
            nodes.createAdditionNode([sAutoOutputs] + ['%s.%s' % (cCtrl.sCtrl,sDrivenA)], sTarget=sOutSumAttr)

        dSliderData = {'bAlongX':bAlongX, 'fRangeX':fRangeX, 'fRangeY':fRangeY, 'fRangeZ':fRangeZ, 'bBorder':bBorder}
        utils.addStringAttr(cCtrl.sCtrl, 'dSliderData', dSliderData, bLock=True)

        cCtrls.append(cCtrl)

    return cCtrls

# DEPRICATED!!!!
def createSliderCtrl2(sName, sSide='l', fScale=1.0, fScaleShape=[0.5,0.5,0.5], bMirror=True, bAlongX=False, sAttach=None, bPoly=False, iColorIndex=0,
                     sShape='sphere', fRangeX=[0,0], fRangeY=[0,0], fRangeZ=[0,0], sMatch=None, fBpPos=None, bBorder=True, dAuto={}, sAlignOnModel=[]):
    # DEPRICATED!!!!

    if bPoly:
        fScale *= 0.5
    fRangeX.sort()
    fRangeY.sort()
    fRangeZ.sort()
    if not cmds.objExists(kBpParents):
        cmds.createNode('transform', n=kBpParents)
    sSides = ['l','r'] if (bMirror == True and sSide != 'm') else [sSide]
    cCtrls = []
    iFurthestMovingVertex = -1
    for s,sSide in enumerate(sSides):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        sBp = 'sliderBp_%s_%s' % (sSide, sName)

        if not cmds.objExists(sBp):
            sMirrorBp = utils.getMirrorName(sBp)
            if cmds.objExists(sMirrorBp):
                sMirror = xforms.mirrorJoints([sMirrorBp])[0]
                sDoExport = '%s.doExport' % sMirror
                cmds.setAttr(sDoExport, lock=False)
                cmds.setAttr(sDoExport, False)
            else:
                xforms.createJoint(sBp, xPos=fBpPos, sMatch=sMatch, sParent=kBpParents)
                cmds.setAttr('%s.radius' % sBp, 0.8 * fScale)
                if len(sAlignOnModel):
                    aaAlignModels = []
                    iAlignModelIndices = [None, None, None, None]
                    iLengths = []
                    for m, sM in enumerate(sAlignOnModel):
                        if sM and cmds.objExists(sM):
                            aPoints = np.array(cmds.xform('%s.vtx[*]' % sM, q=True, ws=True, t=True)).reshape(-1, 3)
                            aaAlignModels.append(aPoints)
                            iLengths.append(len(aPoints))
                            if m > 0:
                                iAlignModelIndices[m-1] = len(aaAlignModels)-1

                    if len(aaAlignModels) > 1:
                        iSmallestLength = min(iLengths)

                        for m, aPoints in enumerate(aaAlignModels):
                            aaAlignModels[m] = aPoints[:iSmallestLength]

                        aLeftPointIds = np.where(aaAlignModels[0][:, 0] > 0.0)[0]

                        aaSideAlignModels = np.zeros((len(aaAlignModels), len(aLeftPointIds), 3), dtype='float64')
                        for m, aPoints in enumerate(aaAlignModels):
                            aaSideAlignModels[m] = aaAlignModels[m][aLeftPointIds]

                        aaDiffs = aaSideAlignModels[1:] - aaSideAlignModels[0:1]
                        aaLengths = np.linalg.norm(aaDiffs, axis=-1)
                        iFurthestMovingIndexFlattened = np.argmax(aaLengths)
                        iFurthestMovingMesh = iFurthestMovingIndexFlattened / len(aLeftPointIds)
                        iFurthestMovingIndex = iFurthestMovingIndexFlattened % len(aLeftPointIds)
                        iFurthestMovingVertex = aLeftPointIds[iFurthestMovingIndex]
                        fScale = np.max(aaLengths[:,iFurthestMovingIndex]) * 1.0

                        mNormal = OpenMaya2.MFnMesh(utils.getDagPath(sAlignOnModel[0])).getVertexNormal(iFurthestMovingVertex, True)
                        mNormal.normalize()
                        aNormal = np.array(mNormal, dtype='float64')
                        aPos = aaAlignModels[0][iFurthestMovingVertex] + aNormal*fScale*0.5

                        if isinstance(fBpPos, type(None)):
                            cmds.setAttr('%s.t' % sBp, *list(aPos))

                        aAim = np.array([0, 1, 0], dtype='float64')
                        if iAlignModelIndices[0] != None:
                            aAim[:] += aaAlignModels[iAlignModelIndices[0]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        if iAlignModelIndices[1] != None:
                            aAim[:] -= aaAlignModels[iAlignModelIndices[1]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        aAim /= np.linalg.norm(aAim)

                        aUp = np.array([1, 0, 0], dtype='float64')
                        if iAlignModelIndices[2] != None:
                            aUp[:] += aaAlignModels[iAlignModelIndices[2]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        if iAlignModelIndices[3] != None:
                            aUp[:] -= aaAlignModels[iAlignModelIndices[3]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        aUp /= np.linalg.norm(aUp)

                        xforms.orientThreePoints(sBp, aAim, aUp, fAimVector=[0,1,0], fUpVector=[1,0,0])


                cmds.setAttr('%s.s' % sBp, fScale, fScale, fScale)

        utils.addOffOnAttr(sBp, 'doExport',
                            bDefaultValue=False if sSide=='r' else True,
                            bLock=False if sSide=='r' else True,
                            bReturnNonIfExists=True)

        cCtrl = ctrls.create(sName, sSide, sMatch=sBp, sParent=_getFaceCtrlGrp(), sShape=sShape, fScaleShape=fScaleShape, bPoly=bPoly, iColorIndex=iColorIndex)
        utils.addAttr(cCtrl.sCtrl, ln='debugVertex', defaultValue=float(iFurthestMovingVertex))
        xforms.matrixParentConstraint(sBp, cCtrl.sPasser, sParentAttr='faceTempAttach')
        cCtrl.sSlider = cCtrl.appendOffsetGroup('slider')
        makeBlendShapeBox(cCtrl, bAlongX=bAlongX, fRangeX=fRangeX, fRangeY=fRangeY, fRangeZ=fRangeZ, bBorder=bBorder)
        print('sAttach: ', sAttach)
        if sAttach:
            _tagForAttachment(cCtrl, sAttach)

        cmds.setAttr('%s.s' % cCtrl.sSlider, fSideMultipl, fSideMultipl, fSideMultipl)
        cmds.setAttr('%s.s' % cCtrl.sOut, 1.0/(fSideMultipl), 1.0/(fSideMultipl), 1.0/(fSideMultipl))

        # dAuto = {'#auto:lipsCornerLFT_ctrl.ty:ty:0.5':[0.0, 1.0, 0.0, 1.0]}
        if dAuto:
            dOutputs = defaultdict(list)
            for sKey, fValues in list(dAuto.items()):
                sAttr, sDriver, sDrivenA, sDefault = sKey.split(':') #auto:lipsCornerLFT_ctrl.ty:ty:0.5
                fDefault = float(sDefault)
                if bMirror and utils.getSide(sDriver) != sSide:
                    sDriver = utils.getMirrorName(sDriver)
                sAutoAttr = utils.addAttr(cCtrl.sCtrl, ln=sAttr, minValue=0.0, maxValue=1.0, defaultValue=fDefault, k=True)
                sRange = nodes.createRangeNode(sDriver, fValues[0], fValues[1], fValues[2], fValues[3])
                sOutput = nodes.createMultiplyNode(sAutoAttr, sRange)#, sTarget='%s.%s' % (sOffset, sDrivenA))
                dOutputs[sAttr] = sOutput
            for sAttr, sOutput in list(dOutputs.items()):
                sOutAttr = utils.addAttr(cCtrl.sCtrl, ln='%sOut' % sAttr, k=False, cb=True)
                cmds.connectAttr(dOutputs[sAttr], sOutAttr)

            sAutoOutputs = nodes.createMaximumNode(list(dOutputs.values()))
            sOffset = cCtrl.appendOffsetGroup(sAttr, bAboveCtrl=True)
            cmds.connectAttr(sAutoOutputs, '%s.%s' % (sOffset, sDrivenA))
            sOutSumAttr = utils.addAttr(cCtrl.sCtrl, ln='%sOut' % sDrivenA, k=False, cb=True)
            nodes.createAdditionNode([sAutoOutputs] + ['%s.%s' % (cCtrl.sCtrl,sDrivenA)], sTarget=sOutSumAttr)

        dSliderData = {'bAlongX':bAlongX, 'fRangeX':fRangeX, 'fRangeY':fRangeY, 'fRangeZ':fRangeZ, 'bBorder':bBorder}
        utils.addStringAttr(cCtrl.sCtrl, 'dSliderData', dSliderData, bLock=True)

        cCtrls.append(cCtrl)

    return cCtrls



def addParentCtrl(sCtrl, bTurnOffParentAttr=False):
    sCtrls = [sCtrl]
    if 'LFT' in sCtrl:
        sCtrls.append(sCtrl.replace('LFT', 'RGT'))

    for sCtrl in sCtrls:
        if 'LFT' in sCtrl:
            sParentCtrl = sCtrl.replace('LFT_ctrl', 'ParentLFT_ctrl')
        elif 'RGT' in sCtrl:
            sParentCtrl = sCtrl.replace('RGT_ctrl', 'ParentRGT_ctrl')
        else:
            sParentCtrl = sCtrl.replace('_ctrl', 'Parent_ctrl')

        cmds.duplicate(sCtrl, n=sParentCtrl)
        sDeleteAttr = '%s.attachThisToFace' % sParentCtrl
        if cmds.objExists(sDeleteAttr):
            cmds.deleteAttr(sDeleteAttr)

        cmds.setAttr('%s.v' % sParentCtrl, lock=False)

        sVisAttr = utils.addOffOnAttr(sCtrl, 'parentVis', bDefaultValue=False)
        sShapes = cmds.listRelatives(sParentCtrl, c=True, typ='nurbsCurve') or []
        sShapes += cmds.listRelatives(sParentCtrl, c=True, typ='mesh') or []
        for sS in sShapes:
            cmds.connectAttr(sVisAttr, '%s.v' % sS)

        cmds.parent(sCtrl, sParentCtrl)
        cmds.setAttr('%s.overrideColorRGB' % sParentCtrl, 0.0, 0.9826998710632324, 1.0)
        cmds.scale(1.5, 1.5, 1.5, '%s.cv[*]' % sParentCtrl)

        sAttrs = ['tx','ty','tz', 't']
        ssConns = [cmds.listConnections('%s.%s' % (sCtrl,sA), s=False, d=True, p=True) or [] for sA in sAttrs]


        if bTurnOffParentAttr:
            sDisableAttr = utils.addAttr(sParentCtrl, ln='disable', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
            sDisableRev = nodes.createReverseNode(sDisableAttr)
            sMult = nodes.createVectorMultiplyNode('%s.t' % sParentCtrl, sDisableRev, bVectorByScalar=True)
            sSum = nodes.createVectorAdditionNode(['%s.t' % sCtrl, sMult])
        else:
            sSum = nodes.createVectorAdditionNode(['%s.t' % sCtrl, '%s.t' % sParentCtrl])

        for a,sA in enumerate(sAttrs):
            for sConn in ssConns[a]:
                cmds.connectAttr('%s%s' % (sSum, ['x','y','z',''][a]), sConn, force=True)




def createSliderCtrl3(sName, sSide='l', fScale=1.0, fScaleShape=[0.5,0.5,0.5], bMirror=True, bAlongX=False, sAttach=None, bPoly=False, iColorIndex=0, bExportMirrorBps=False, bRotateByNeighborVerts=False,
                     sShape='sphere', fRangeX=[0,0], fRangeY=[0,0], fRangeZ=[0,0], sMatch=None, fBpPos=None, bBorder=True, dAuto={}, sAlignOnModel=[], xMirrorAxis=None):

    if bPoly:
        fScale *= 0.5
    fRangeX.sort()
    fRangeY.sort()
    fRangeZ.sort()
    if not cmds.objExists(kBpParents):
        cmds.createNode('transform', n=kBpParents)
    sSides = ['l','r'] if (bMirror == True and sSide != 'm') else [sSide]
    cCtrls = []
    iFurthestMovingVertex = -1
    for s,sSide in enumerate(sSides):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        sBp = 'sliderBp_%s_%s' % (sSide, sName)

        if not cmds.objExists(sBp):
            sMirrorBp = utils.getMirrorName(sBp)
            if cmds.objExists(sMirrorBp):
                sMirror = xforms.mirrorJoint(sMirrorBp, xMirrorAxis=xMirrorAxis)
                if not bMirror and not isinstance(fBpPos, type(None)):
                    cmds.setAttr('%s.t' % sBp, *fBpPos)

                sDoExport = '%s.doExport' % sMirror
                cmds.setAttr(sDoExport, lock=False)
                cmds.setAttr(sDoExport, bExportMirrorBps)
            else:
                xforms.createJoint(sBp, xPos=fBpPos, sMatch=sMatch, sParent=kBpParents)
                utils.addOffOnAttr(sBp, 'bRotateByNeighborVerts', bRotateByNeighborVerts)
                # cmds.setAttr('%s.radius' % sBp, 0.8 * fScale)
                if len(sAlignOnModel):
                    aaAlignModels = []
                    iAlignModelIndices = [None, None, None, None]
                    iLengths = []
                    for m, sM in enumerate(sAlignOnModel):
                        if sM and cmds.objExists(sM):
                            aPoints = np.array(cmds.xform('%s.vtx[*]' % sM, q=True, ws=True, t=True)).reshape(-1, 3)
                            aaAlignModels.append(aPoints)
                            iLengths.append(len(aPoints))
                            if m > 0:
                                iAlignModelIndices[m-1] = len(aaAlignModels)-1

                    if isinstance(xMirrorAxis, (list,tuple)):
                        sJoint, iAxis = xMirrorAxis
                        aJointMatrix = np.array(cmds.xform(sJoint, q=True, ws=True, m=True), dtype='float64').reshape(4, 4)
                        aaLocalAlignModels = [None] * len(aaAlignModels)

                        for m, aPoints in enumerate(aaAlignModels):
                            if not isinstance(aPoints, type(None)):
                                aPoints4 = utils.makePoint4Array(aPoints)
                                aPointsLocal4 = np.dot(aPoints4, np.linalg.inv(aJointMatrix))
                                aaLocalAlignModels[m] = aPointsLocal4[:, 0:3]
                                iCheckAxis = iAxis % 3
                                bCheckNegative = True if iAxis >= 3 else False
                    else:
                        aaLocalAlignModels = aaAlignModels
                        iCheckAxis = 0
                        bCheckNegative = False


                    if len(aaAlignModels) > 1:
                        iSmallestLength = min(iLengths)

                        for m, aPoints in enumerate(aaAlignModels):
                            aaAlignModels[m] = aPoints[:iSmallestLength]
                            aaLocalAlignModels[m] = aaLocalAlignModels[m][:iSmallestLength]

                        if bCheckNegative:
                            aLeftPointIds = np.where(aaLocalAlignModels[0][:, iCheckAxis] < 0.0)[0]
                        else:
                            aLeftPointIds = np.where(aaLocalAlignModels[0][:, iCheckAxis] > 0.0)[0]

                        aaSideAlignModels = np.zeros((len(aaLocalAlignModels), len(aLeftPointIds), 3), dtype='float64')
                        for m, aPoints in enumerate(aaLocalAlignModels):
                            aaSideAlignModels[m] = aaLocalAlignModels[m][aLeftPointIds]

                        aaDiffs = aaSideAlignModels[1:] - aaSideAlignModels[0:1]
                        aaLengths = np.linalg.norm(aaDiffs, axis=-1)
                        iFurthestMovingIndexFlattened = np.argmax(aaLengths)
                        iFurthestMovingMesh = iFurthestMovingIndexFlattened / len(aLeftPointIds)
                        iFurthestMovingIndex = iFurthestMovingIndexFlattened % len(aLeftPointIds)
                        iFurthestMovingVertex = aLeftPointIds[iFurthestMovingIndex]
                        fScale = np.max(aaLengths[:,iFurthestMovingIndex]) * 1.0

                        mNormal = OpenMaya2.MFnMesh(utils.getDagPath(sAlignOnModel[0])).getVertexNormal(iFurthestMovingVertex, True)
                        mNormal.normalize()
                        aNormal = np.array(mNormal, dtype='float64')
                        aPos = aaAlignModels[0][iFurthestMovingVertex] + aNormal*fScale*0.5
                        if isinstance(fBpPos, type(None)):
                            cmds.setAttr('%s.t' % sBp, *list(aPos))

                        aAim = np.array([0, 1, 0], dtype='float64')
                        if iAlignModelIndices[0] != None:
                            aAim[:] += aaAlignModels[iAlignModelIndices[0]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        if iAlignModelIndices[1] != None:
                            aAim[:] -= aaAlignModels[iAlignModelIndices[1]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        aAim /= np.linalg.norm(aAim)

                        aUp = np.array([1, 0, 0], dtype='float64')
                        if iAlignModelIndices[2] != None:
                            aUp[:] += aaAlignModels[iAlignModelIndices[2]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        if iAlignModelIndices[3] != None:
                            aUp[:] -= aaAlignModels[iAlignModelIndices[3]][iFurthestMovingVertex] - aaAlignModels[0][iFurthestMovingVertex]
                        aUp /= np.linalg.norm(aUp)

                        xforms.orientThreePoints(sBp, aAim, aUp, fAimVector=[0,1,0], fUpVector=[1,0,0])

                cmds.setAttr('%s.s' % sBp, fScale, fScale, fScale)

        utils.addOffOnAttr(sBp, 'doExport',
                            bDefaultValue=False if sSide=='r' else True,
                            bLock=False if sSide=='r' else True,
                            bReturnNonIfExists=True)

        cCtrl = ctrls.create(sName, sSide, sMatch=sBp, sParent=_getFaceCtrlGrp(), sShape=sShape, fScaleShape=fScaleShape, bPoly=bPoly, iColorIndex=iColorIndex)
        utils.addAttr(cCtrl.sCtrl, ln='debugVertex', defaultValue=float(iFurthestMovingVertex))
        xforms.matrixParentConstraint(sBp, cCtrl.sPasser, sParentAttr='faceTempAttach')
        cCtrl.sSlider = cCtrl.appendOffsetGroup('slider')
        makeBlendShapeBox(cCtrl, bAlongX=bAlongX, fRangeX=fRangeX, fRangeY=fRangeY, fRangeZ=fRangeZ, bBorder=bBorder)
        print('sAttach: ', sAttach)
        if sAttach:
            _tagForAttachment(cCtrl, sAttach)

        cmds.setAttr('%s.s' % cCtrl.sSlider, fSideMultipl, fSideMultipl, fSideMultipl)
        cmds.setAttr('%s.s' % cCtrl.sOut, 1.0/(fSideMultipl), 1.0/(fSideMultipl), 1.0/(fSideMultipl))

        # dAuto = {'#auto:lipsCornerLFT_ctrl.ty:ty:0.5':[0.0, 1.0, 0.0, 1.0]}
        if dAuto:
            dOutputs = defaultdict(list)
            for sKey, fValues in list(dAuto.items()):
                sAttr, sDriver, sDrivenA, sDefault = sKey.split(':')
                fDefault = float(sDefault)
                if bMirror and utils.getSide(sDriver) != sSide:
                    sDriver = utils.getMirrorName(sDriver)
                sAutoAttr = utils.addAttr(cCtrl.sCtrl, ln=sAttr, minValue=0.0, maxValue=1.0, defaultValue=fDefault, k=True)
                sRange = nodes.createRangeNode(sDriver, fValues[0], fValues[1], fValues[2], fValues[3])
                sOutput = nodes.createMultiplyNode(sAutoAttr, sRange)
                dOutputs[sAttr] = sOutput
            for sAttr, sOutput in list(dOutputs.items()):
                sOutAttr = utils.addAttr(cCtrl.sCtrl, ln='%sOut' % sAttr, k=False, cb=True)
                cmds.connectAttr(dOutputs[sAttr], sOutAttr)

            sAutoOutputs = nodes.createMaximumNode(list(dOutputs.values()))
            sOffset = cCtrl.appendOffsetGroup(sAttr, bAboveCtrl=True)
            cmds.connectAttr(sAutoOutputs, '%s.%s' % (sOffset, sDrivenA))
            sOutSumAttr = utils.addAttr(cCtrl.sCtrl, ln='%sOut' % sDrivenA, k=False, cb=True)
            nodes.createAdditionNode([sAutoOutputs] + ['%s.%s' % (cCtrl.sCtrl,sDrivenA)], sTarget=sOutSumAttr)

        dSliderData = {'bAlongX':bAlongX, 'fRangeX':fRangeX, 'fRangeY':fRangeY, 'fRangeZ':fRangeZ, 'bBorder':bBorder}
        utils.addStringAttr(cCtrl.sCtrl, 'dSliderData', dSliderData, bLock=True)

        cCtrls.append(cCtrl)

    return cCtrls





def _addSliderGroups(cCtrl, bAddPlaceOffset):
    cCtrl.sSliderExtra = cCtrl.appendOffsetGroup('place') if bAddPlaceOffset else None
    cCtrl.sSlider = cCtrl.appendOffsetGroup('slider')


# don't use anymore
def setNewRange(cCtrl, fMin, fMax):
    if isinstance(cCtrl, str):
        cCtrl = ctrls.ctrlFromName(cCtrl)

    cmds.transformLimits(cCtrl.sCtrl, ty=(fMin, fMax), etz=(True, True))
    print('cCtrl.sPasser: ', cCtrl.sBorderShape)
    pBorder = patch.patchFromName(cCtrl.sBorderShape)
    aPoints = pBorder.getPoints(bWorld=False)
    aPoints[0:3, 1] = fMin
    aPoints[7:11, 1] = fMax
    pBorder.setPoints(aPoints, bWorld=False)
    # cmds.move(0, -0.5, 0, '%s.cv[7:10]' % cmds.listRelatives(cCtrl.sCtrl, p=True)[0], r=True, os=True)



def setRange(cCtrl, fRangeX=None, fRangeY=None, fRangeZ=None, bAdjustBorders=False):
    if isinstance(cCtrl, str):
        cCtrl = ctrls.ctrlFromName(cCtrl)

    dSliderData = eval(cmds.getAttr('%s.dSliderData' % cCtrl.sCtrl))
    if fRangeX:
        fRangeX.sort()
        dSliderData['fRangeX'] = fRangeX
        # cmds.transformLimits(cCtrl.sCtrl, tx=(fRangeX[0], fRangeX[1]), etx=(True, True))
    if fRangeY:
        fRangeY.sort()
        dSliderData['fRangeY'] = fRangeY
        # cmds.transformLimits(cCtrl.sCtrl, ty=(fRangeY[0], fRangeY[1]), ety=(True, True))
    if fRangeZ:
        fRangeZ.sort()
        dSliderData['fRangeZ'] = fRangeZ
        # cmds.transformLimits(cCtrl.sCtrl, tz=(fRangeZ[0], fRangeZ[1]), etz=(True, True))


    utils.addStringAttr(cCtrl.sCtrl, 'dSliderData', dSliderData, bLock=True)

    if bAdjustBorders:
        makeBlendShapeBox(cCtrl,
                          bAlongX=dSliderData['bAlongX'],
                          fRangeX=dSliderData['fRangeX'],
                          fRangeY=dSliderData['fRangeY'],
                          fRangeZ=dSliderData['fRangeZ'],
                          bBorder=dSliderData['bBorder'])


# DEPRICATED !!!! please use attachAllCtrls2
def attachAllCtrls(sModel, sScaleJoint, sAdditionalSkinClusters=[], bReorderSkinClusters=False):
    sGrp = cmds.createNode('transform', n='faceAttachmentLocators', p='modules')

    sCtrls = [sC for sC in cmds.ls('*_ctrl', et='transform') if cmds.objExists('%s.attachThisToFace' % sC)]

    sTempConnections = [sN for sN in cmds.ls() if cmds.objExists('%s.faceTempAttach' % sN)]
    cmds.delete(sTempConnections)

    dMeshAttach = defaultdict(list)
    for sC in sCtrls:
        sAttach = cmds.getAttr('%s.attachThisToFace' % sC)
        cC = ctrls.ctrlFromName(sC)
        if cmds.objectType(sAttach) == 'joint':
            xforms.matrixParentConstraint(sAttach, cC.sPasser, mo=True)
        elif cmds.objectType(sAttach) == 'transform' and not cmds.listRelatives(sAttach, s=True, typ='mesh'):
            xforms.matrixParentConstraint(sAttach, cC.sPasser, mo=True)
        else:
            dMeshAttach[sAttach].append(sC)


    for sMesh, sCtrls in list(dMeshAttach.items()):
        aPoints = xforms.getPositionArray(sCtrls)
        aClosestIds = xforms.getClosestIdsFromPoints(sMesh, aPoints)

        ssIgnoreTargets = []
        for c,sCtrl in enumerate(sCtrls):
            sIgnoreAttr = '%s.%s' % (sCtrl, interpolator.kIgnoreAttachTargetsAttr)
            if cmds.objExists(sIgnoreAttr):
                sTargets = eval(cmds.getAttr(sIgnoreAttr))
                sTargets = utils.extendMirrorList([sT for sT in sTargets if sT])
                ssIgnoreTargets.append(sTargets)
            else:
                ssIgnoreTargets.append([])

        sSkinClusters = ['skinCluster__%s' % sModel] + sAdditionalSkinClusters
        if bReorderSkinClusters:
            sAllSkinClusters = deformers.listAllDeformers(sModel, sFilterTypes=['skinCluster'])
            sReorderedSkinClusters = [sS for sS in sAllSkinClusters if sS in sSkinClusters][::-1]
        else:
            sReorderedSkinClusters = sSkinClusters
        sLocs = deformers.blendShapeSkinClusterToPositions(sModel, aClosestIds, bDoSkinCluster=True, sSkinClusters=sReorderedSkinClusters,
                                                           sParent=sGrp, sScaleJoint=sScaleJoint, ssIgnoreTargets=ssIgnoreTargets)

        for c, sCtrl in enumerate(sCtrls):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            xforms.matrixParentConstraint(sLocs[c], cCtrl.sPasser, mo=True)





def attachAllCtrls2(sScaleJoint, sAdditionalSkinClusters=[], bReorderSkinClusters=False):
    sGrp = cmds.createNode('transform', n='faceAttachmentLocators', p='modules')

    sCtrls = [sC for sC in cmds.ls('*_ctrl', et='transform') if cmds.objExists('%s.attachThisToFace' % sC)]

    sTempConnections = [sN for sN in cmds.ls() if cmds.objExists('%s.faceTempAttach' % sN)]
    cmds.delete(sTempConnections)

    dMeshAttach = defaultdict(list)
    for sC in sCtrls:
        sAttach = cmds.getAttr('%s.attachThisToFace' % sC)
        cC = ctrls.ctrlFromName(sC)
        if cmds.objectType(sAttach) == 'joint':
            xforms.matrixParentConstraint(sAttach, cC.sPasser, mo=True)
        elif cmds.objectType(sAttach) == 'transform' and not cmds.listRelatives(sAttach, s=True, typ='mesh'):
            xforms.matrixParentConstraint(sAttach, cC.sPasser, mo=True)
        else:
            dMeshAttach[sAttach].append(sC)


    for sMesh, sCtrls in list(dMeshAttach.items()):
        aPoints = xforms.getPositionArray(sCtrls)
        aClosestIds = xforms.getClosestIdsFromPoints(sMesh, aPoints)

        ssIgnoreTargets = []
        for c,sCtrl in enumerate(sCtrls):
            sIgnoreAttr = '%s.%s' % (sCtrl, interpolator.kIgnoreAttachTargetsAttr)
            if cmds.objExists(sIgnoreAttr):
                sTargets = eval(cmds.getAttr(sIgnoreAttr))
                sTargets = utils.extendMirrorList([sT for sT in sTargets if sT])
                ssIgnoreTargets.append(sTargets)
            else:
                ssIgnoreTargets.append([])

        sSkinClusters = ['skinCluster__%s' % sMesh] + ['skinCluster__%s__BEND' % sMesh] + ['lattice__%s__l_EYE' % sMesh, 'lattice__%s__l_EYE' % sMesh] + sAdditionalSkinClusters
        if bReorderSkinClusters:
            sAllSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
            sReorderedSkinClusters = [sS for sS in sAllSkinClusters if sS in sSkinClusters][::-1]
        else:
            sReorderedSkinClusters = sSkinClusters
        sLocs = deformers.blendShapeSkinClusterToPositions(sMesh, aClosestIds, bDoSkinCluster=True, sSkinClusters=sReorderedSkinClusters,
                                                           sParent=sGrp, sScaleJoint=sScaleJoint, ssIgnoreTargets=ssIgnoreTargets)

        for c, sCtrl in enumerate(sCtrls):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            xforms.matrixParentConstraint(sLocs[c], cCtrl.sPasser, mo=True)


