###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import os
import subprocess
import kangarooTools.utilFunctions as utils
import kangarooTools.utilsQt as utilsQt

QtWidgets, QtGui, QtCore = utils.importQtModules()




report = None

def createReport(parent):
    global report
    report = Report(parent)


funcRotateBuilderIcon = None

class Report(object):
    def __init__(self, qParentUI):
        self.qParentUI = qParentUI
        self.qBrowserLayout = QtWidgets.QVBoxLayout()
        self.qProgress = QtWidgets.QProgressBar()
        self.setProgressBarColor(utils.uiColors.blue)
        self.resetProgress()
        self.qLog = utilsQt.makeWidgetFromLayout(self.qBrowserLayout)
        self.resetLog()


    def resetLog(self):
        self.qBrowser = QtWidgets.QTextBrowser()
        self.qBrowserLayout.addWidget(self.qBrowser)
        self.qBrowser.setOpenLinks(False)
        self.qBrowser.setReadOnly(True)
        self.qBrowser.anchorClicked.connect(self.handle_links)
        self.sLogFormatted = ''


    def handle_links(self, qLink):
        sLink = qLink.toString()
        print ('sLink: ', sLink)
        sLinkSplits = sLink.split('@')
        if '.py' in sLink:
            utils.openPycharm(sLinkSplits[0], iLine=None if len(sLinkSplits) < 2 else int(sLinkSplits[1]))
        else:
            utils.openExplorer(os.path.dirname(sLink))

    def clearLogText(self):
        if False:
            self.qBrowser.setHidden(True)
            self.qBrowserLayout.removeWidget(self.qBrowser)
            self.qBrowser.deleteLater()
            self.qBrowser = None
            self.resetLog()
        else:
            self.qBrowser.clear()
            self.qBrowser.setCurrentCharFormat(QtGui.QTextCharFormat())

            # self.qBrowser.clearHistory()
        self.sLogFormatted = ''


    def addLogText(self, sText, bClearFirst=False, iSize=8, sWeight='normal', sColor=utils.uiColors.white, bQuotationsToLink=False, bRefresh=False, bIncrementProgress=False, bPrint=False):
        if bPrint:
            print(sText)
        if bClearFirst:
            self.clearLogText()

        # sHtmlText = sText.replace('\n', '<br/>').replace('  ', '&nbsp;&nbsp;&nbsp;')
        # sHtmlText = '<span style="color:%s; font-size:%dpt; font-weight:%s">%s</span>' % (sColor, iSize, sWeight, sHtmlText)
        # for sHtmlText in sText.split('\n'):

        sLines = sText.split('\n')
        sCommaLine = ', line'
        if bQuotationsToLink:
            for l,sLine in enumerate(sLines):
                iFirstQuotation = sLine.find('"', 0)
                if iFirstQuotation != -1:
                    iSecondQuotation = sLine.find('"', iFirstQuotation+1)
                    if iSecondQuotation != -1:
                        sFilePath = sLine[iFirstQuotation+1:iSecondQuotation]
                        if '/' in sFilePath or '\\' in sFilePath:
                            sLink = sFilePath
                            iCommaLine = sLine.find(sCommaLine, iSecondQuotation)

                            if iCommaLine != -1:
                                iNumberStart = iCommaLine + len(sCommaLine)
                                iNumberEnd = sLine.find(',', iNumberStart)
                                if iNumberEnd == -1:
                                    iNumberEnd = len(sLine)
                                sNumber = sLine[iNumberStart:iNumberEnd].strip()
                                sLink = '%s@%s' % (sLink, sNumber)

                            sLines[l] = '%s<a href="%s"> "%s" </a>%s' % (sLine[:iFirstQuotation], sLink.replace('\\','/'), sFilePath, sLine[iSecondQuotation+1:])
                # print ('formatted: ', sLines[l])

        for sLine in sLines:
            self.qBrowser.append(sLine)

        self.sLogFormatted += '\n%s' % '\n'.join(sLines)

        if bIncrementProgress:
            self.incrementProgress()

        self.refreshIcon()
        if bRefresh:
            QtWidgets.QApplication.processEvents()
            # cmds.refresh()

    def incrementProgress(self, bRefresh=False, iSteps=1):
        self.qProgress.setValue(self.qProgress.value() + iSteps)
        self.refreshIcon()
        if bRefresh:
            QtWidgets.QApplication.processEvents()
            # cmds.refresh()



    def resetProgress(self, iMaximum=100):
        if iMaximum == 0:
            iMaximum = 1
        self.qProgress.setRange(0,iMaximum)
        self.qProgress.setValue(0)
        self.iMaximum = iMaximum
        self.refreshIcon()
        QtWidgets.QApplication.processEvents()
        # cmds.refresh()


    def addToMaximum(self, iAdd):
        self.qProgress.setRange(0, self.qProgress.maximum()+iAdd)


    def setToFull(self):
        self.qProgress.setValue(self.iMaximum)


    def setProgressBarColor(self, sColor):
        palette = QtGui.QPalette(self.qProgress.palette())
        palette.setColor(QtGui.QPalette.Highlight,
                         QtGui.QColor(sColor))
        self.qProgress.setPalette(palette)

        # print ('setting color.... ', sColor)
        #
        # palette = QtGui.QPalette(self.qProgress.palette())
        # palette.setColor(QtGui.QPalette.Highlight,
        #                  QtGui.QColor(QtCore.Qt.red))
        # self.qProgress.setPalette(palette)
        #
        #
        #
        # self.qParentUI.setStyleSheet('''
        # QProgressBar {
        #     border: 2px solid grey;
        #     border-radius: 5px;
        # }
        #
        # QProgressBar::chunk {
        #     background-color: %s;
        #     width: 20px;
        # }
        # ''' % sColor)

    def getText(self):
        return self.sLogFormatted
        # return self.qBrowser.toPlainText()


    def refreshIcon(self, bRefresh=False):
        if not isinstance(funcRotateBuilderIcon, type(None)):
            funcRotateBuilderIcon(bRefresh)
