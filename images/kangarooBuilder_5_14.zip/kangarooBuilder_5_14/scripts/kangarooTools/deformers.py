###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OpenMaya
import maya.OpenMayaAnim as OpenMayaAnim
import maya.api.OpenMayaAnim as OpenMayaAnim2
import kangarooTools.utilFunctions as utils
import kangarooTools.barycentric as barycentric
import kangarooTools.utilsQt as utilsQt
import numpy as np
import kangarooTools.report as report

kPostRefJointAttr = 'sPostRefJoint'


def listAllDeformers(sGeometry, sFilterTypes=[], sIgnoreTypes=['tweak'], bSkipGeoTest=False, bDoCloth=False):
    sHistory = cmds.listHistory(sGeometry)
    
    sDeformers = [sN for sN in sHistory if 'geometryFilter' in cmds.nodeType(sN, i=True)]
    if sFilterTypes:
        sDeformers = [sD for sD in sDeformers if cmds.objectType(sD) in sFilterTypes]
    if sIgnoreTypes:
        sDeformers = [sD for sD in sDeformers if cmds.objectType(sD) not in sIgnoreTypes]

    if bSkipGeoTest:
        sGeometryDeformers = sDeformers
    else:
        sGeometryDeformers = []
        for sDeformer in sDeformers:
            sGeos = cmds.deformer(sDeformer, q=True, g=True) or []
            for sGeo in sGeos:
                if utils.geoEqual(sGeo.split('|')[-1], sGeometry):
                    sGeometryDeformers.append(sDeformer)

    if bDoCloth:
        if 'nCloth' not in sIgnoreTypes or (sFilterTypes and 'nCloth' not in sFilterTypes):
            sCloths = [sN for sN in sHistory if cmds.objectType(sN) == 'nCloth']
            if sCloths:
                sClothShape = utils.extendToShape(sCloths[0])
                sGeometryDeformers.append(sClothShape)

    return sGeometryDeformers


def getPostDeformers(sDeformer, sIgnoreTypes=[]):
    sShape = getGeoFromDeformer(sDeformer)
    xReturn = []
    
    sDeformers = listAllDeformers(sShape)

    if sDeformer in sDeformers:
        iIndex = sDeformers.index(sDeformer)
        sPosts = sDeformers[:iIndex]
        sPosts.reverse()
        xReturn.append(sPosts)
    return xReturn


def reorderDeformer(sDeformer, sPostDeformers, sGeo):
    # sDeformer comes before the first one in sPostDeformers

    sCurrentDeformers = listAllDeformers(sGeo)
    if not len(sPostDeformers):
        return

    iPostInCurrent = utils.findOneArrayInAnother(sCurrentDeformers, sPostDeformers)
    iImportantCurrent = np.max(iPostInCurrent)
    if iImportantCurrent < 0: # no post deformer is there
        return

    try:
        cmds.reorderDeformers(sCurrentDeformers[iImportantCurrent], sDeformer, sGeo)
    except:
        pass

def getBlendShapeTargets(sBlendShape):
    sAliasAttrs = cmds.aliasAttr(sBlendShape, q=True)
    if sAliasAttrs:
        return sAliasAttrs[::2]
    else:
        return []



def getSaveAttributesDict(sDeformer):
    sAttrs = cmds.listAttr(sDeformer, keyable=False, channelBox=True, scalar=True, visible=True, leaf=True) or []
    sAttrs += cmds.listAttr(sDeformer, keyable=True, scalar=True, visible=True, leaf=True) or []
    if cmds.objectType(sDeformer) == 'blendShape':
        sAliasAttrs = cmds.aliasAttr(sDeformer, q=True)
        if sAliasAttrs:
            sAttrs += sAliasAttrs[::2]
            try:
                sAttrs.remove('weight')
            except:
                pass

    dAttrs = {}
    for sAttr in sAttrs:
        try:
            fValue = cmds.getAttr('%s.%s' % (sDeformer, sAttr))
            dAttrs[sAttr] = fValue
        except:
            pass

    return dAttrs


def chooseMainSkinClusterFromList(sSkinClusters):
    iCounts = [len(sS.split('__')) for sS in sSkinClusters]
    iInd = np.argmin(iCounts)
    return sSkinClusters[iInd]


def convertChooseSkinCluster(xChooseSkinCluster, sGeo, _report=None):

    if not xChooseSkinCluster:
        sSkinClusters = listAllDeformers(sGeo, sFilterTypes=['skinCluster'])
        if sSkinClusters:
            return chooseMainSkinClusterFromList(sSkinClusters)
        else:
            return None
    else:
        try:
            xChooseSkinCluster = int(xChooseSkinCluster)
        except: pass

        if isinstance(xChooseSkinCluster, str):
            if xChooseSkinCluster.startswith('__'):
                if not cmds.objExists(sGeo):
                    return None
                sSkinClusters = listAllDeformers(sGeo, sFilterTypes=['skinCluster'])
                for sSkinC in sSkinClusters:
                    if sSkinC.endswith(xChooseSkinCluster):
                        return sSkinC
                return None
            else:
                return xChooseSkinCluster
        elif isinstance(xChooseSkinCluster, int):
            if not cmds.objExists(sGeo):
                return None
            sSkinClusters = listAllDeformers(sGeo, sFilterTypes=['skinCluster'])
            if xChooseSkinCluster >= len(sSkinClusters):
                iIndex = len(sSkinClusters)-1
                sWarning = 'index provided is %d, but number of skinClusters is %d, choosing index %d' % (xChooseSkinCluster, len(sSkinClusters), iIndex)
                cmds.warning(sWarning)
                if _report: _report.addLogText(sWarning)
            else:
                iIndex = xChooseSkinCluster

            return sSkinClusters[-(iIndex+1)]
        else:
            raise Exception('choose skinCluster - needs to be either int number or skinCluster name (%s)' % xChooseSkinCluster)



def getGeoFromDeformer(sDeformer, bTransform=False):
    if not cmds.objExists(sDeformer):
        return None
    else:
        sGeo = None
        if isGeometryFilter(sDeformer):
            sGeo = cmds.deformer(sDeformer, q=True, g=True)[0]
        elif cmds.objectType(sDeformer) == 'nCloth':
            sGeo = cmds.listConnections('%s.inputMesh' % sDeformer)[0]
            if not bTransform:
                sGeo = utils.extendToShape(sGeo)

        if bTransform and cmds.objectType(sGeo) != 'transform':
            sGeo = cmds.listRelatives(sGeo, p=True)
            if not sGeo:
                raise Exception('Not able to get a geo (transform) from "%s"' % sDeformer)
            sGeo = sGeo[0]

        if sGeo == None:
            raise Exception('can\'t find geo from deformer "%s"' % sDeformer)

        return sGeo



def isGeometryFilter(sObj):
    if not (sObj):
        return None
    return 'geometryFilter' in cmds.nodeType(sObj, i=True)


def getWeightMaps(sDeformer, sGeoShape=None):
    sType = cmds.objectType(sDeformer)
    sMaps = []
    
    
    print('cmds.objectType(sDeformer): ', cmds.objectType(sDeformer))
    if sType == 'nCloth':
        sAttrs = [('%s.%s' % (sDeformer,sA), sA[:-len('PerVertex')]) for sA in cmds.listAttr(sDeformer) if sA.endswith('PerVertex')]
        sMaps += sAttrs
    
    else: #elif 'geometryFilter' in cmds.nodeType(sDeformer, i=True)
        iMeshIndex = 0
        if sGeoShape != None:
            sMeshShapes = cmds.deformer(sDeformer, q=True, g=True)
            for m,sMeshS in enumerate(sMeshShapes):
                if sMeshS.startswith(sGeoShape):
                    iMeshIndex = m
                    print ('m: ', m)
                    break
            else:
                raise Exception('"%s" is not found in meshes of %s (%s)' % (sGeoShape, sDeformer, sMeshShapes))

        if sType == 'blendShape':
            sMaps.append(('%s.inputTarget[%d].baseWeights' % (sDeformer, iMeshIndex), 'baseWeights'))
            for iTargetIndex, sTarget in list(getTargetsDictFromBlendShape(sDeformer).items()):
                sMaps.append(('%s.inputTarget[%d].inputTargetGroup[%s].targetWeights' % (sDeformer, iMeshIndex, sTarget), sTarget))
        else:
            if sType not in ['skinCluster']:
                sMaps.append(('%s.weightList[%d].weights' % (sDeformer, iMeshIndex), 'weights'))

    return sMaps




def createDeformer(sName, sType, sGeos, sInfluences=None, bAlwaysAddDefaultWeightsOnSkinCluster=False):
    if sType == 'ffd':
        return cmds.lattice(sGeos, name=sName)[0]
    elif sType != 'skinCluster':
        return cmds.deformer(sGeos, typ=sType, name=sName)[0]
    else: # skinCluster
        if utils.isNone(sInfluences):# == None:
            raise Exception('failed trying to create a skinCluster without influences, why would you do that?!')

        [cmds.createNode('joint', name=sI) for sI in sInfluences if not cmds.objExists(sI)]

        return skinMesh(sGeos, sInfluences, sName=sName, bAlwaysAddDefaultWeights=bAlwaysAddDefaultWeightsOnSkinCluster)



def decodeMapName(sMap, bReturnGeo=False, sReplaceDeformer=None, bJustCheckIfItExists=False):
    sSplits = sMap.split('.')
    sDeformer = sSplits[0] if sReplaceDeformer == None else sReplaceDeformer
    sSplits[0] = sDeformer

    sGeo = getGeoFromDeformer(sDeformer) #cmds.deformer(sDeformer, q=True, g=True)
    
    xTargetDict = None
    
    if '.inputTargetGroup[' in sMap:
        if xTargetDict == None: xTargetDict = getTargetsDictFromBlendShape(sDeformer, bPerTargetNames=True)
        sTargetName = sSplits[-2].split('[')[-1].split(']')[0]
        iTarget = xTargetDict.get(sTargetName, None)
        if iTarget == None:
            return ((None, None) if bReturnGeo else None)
        sSplits[-2] = 'inputTargetGroup[%d]' % iTarget

    if bReturnGeo:
        return '.'.join(sSplits), sGeo
    else:
        return '.'.join(sSplits)


# depricated!!! use blendShapes.getTargetsDictFromBlendShape instead
def getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=False):
    sAliases = cmds.aliasAttr(sBlendShape, q=True)
    if not sAliases:
        return {}
    sTargets = sAliases[::2]
    iIds = [utils.intFromComponent(sComponent) for sComponent in sAliases[1::2]]
    if bPerTargetNames:
        return dict(list(zip(sTargets, iIds)))
    else:
        return dict(list(zip(iIds, sTargets)))


# depricated!!! use blendShapes.getFirstAvailableTargetIndexFromBlendShape instead
def getFirstAvailableTargetIndexFromBlendShape(sBlendShape):
    dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    iIndices = list(dTargets.values())
    iIndices.sort()
    iFirstIndex = len(iIndices)
    for i,iIndex in enumerate(iIndices):
        if i != iIndex:
            iFirstIndex = i
            return iFirstIndex, False
    return iFirstIndex, True


def disconnectTargetsFromBlendShape(sBlendShape):
    sConns = cmds.listConnections(sBlendShape, s=True, d=False, c=True, p=True)
    for i in range(0, len(sConns), 2):
        sFrom, sTo = sConns[i + 0], sConns[i + 1]
        if sFrom.endswith('.inputGeomTarget'):
            cmds.disconnectAttr(sTo, sFrom)

# depricated!!! use blendShapes.addTargets instead
def addBlendShapeTargets(sGeometry, sTargets, bFoc=True, sAliasAttrs=None, bTopologyCheck=False):
    import kangarooTools.nodes as nodes
    sTargets = utils.toList(sTargets)

    if sAliasAttrs != None:
        sAliasAttrs = utils.toList(sAliasAttrs)
        if len(sAliasAttrs) != len(sTargets):
            raise Exception('if there are alias attributes specified, they need to have same length as targets')
        sAliasDuplicates = utils.getDuplicates(sAliasAttrs)
        if len(sAliasDuplicates):
            raise Exception('there are non unique aliases: %s' % utils.listToString(sAliasDuplicates))

    sBlendShapes = listAllDeformers(sGeometry, sFilterTypes=['blendShape'])
    bCleanIndices = False
    sReturnTargets = []
    if sBlendShapes:
        sBs = sBlendShapes[0]
        sGeo = cmds.deformer(sBs, q=True, g=True)[0]

        for t, sT in enumerate(sTargets):
            if sT == None:
                sReturnTargets.append(None)
                continue

            if bCleanIndices:
                iNewIndex += 1
            else:
                iNewIndex, bCleanIndices = getFirstAvailableTargetIndexFromBlendShape(sBs)

            if sAliasAttrs:
                sUniqueAliasAttr = getUniqueBlendShapeTargetName(sBs, sAliasAttrs[t]) # we rely on this being the exact name of target that cmds.blendShape will create
                cmds.blendShape(sBs, e=True, t=[sGeo, iNewIndex, sT, 1.0], topologyCheck=bTopologyCheck)

                if sT != sAliasAttrs[t]:
                    try:
                        cmds.aliasAttr(sUniqueAliasAttr, '%s.w[%d]' % (sBs, iNewIndex))
                    except Exception as e:
                        raise Exception('BLENDSHAPE: %s - %s' % (sBs, e))
                sReturnTargets.append('%s.%s' % (sBs,sUniqueAliasAttr))
            else:
                sReturnAttr = '%s.%s' % (sBs,sT.split('|')[-1])
                if not cmds.objExists(sReturnAttr):
                    cmds.blendShape(sBs, e=True, t=[sGeo, iNewIndex, sT, 1.0], topologyCheck=bTopologyCheck)
                    sReturnTargets.append(sReturnAttr)
                else:
                    sConnections = cmds.listConnections(sReturnAttr, s=True, d=False, p=True)
                    if not sConnections: # there's a blendshape with no connections. Let's just return that
                        sReturnTargets.append(sReturnAttr)
                    else:
                        sCurrentSource = sConnections[0]
                        sAddition = nodes.createAdditionNode([sCurrentSource])
                        cmds.connectAttr(sAddition, sReturnAttr, force=True)
                        sReturnTargets.append('%s.input1D[1]' % sAddition.split('.')[0])

    else:
        sNamespace, sG = utils.splitNamespace(sGeometry)
        sName = '%sblendShape__%s' % (sNamespace, sG)
        sBs = cmds.blendShape(sTargets, sGeometry, n=sName, foc=bFoc, topologyCheck=bTopologyCheck)[0]
        sReturnTargets = ['%s.%s' % (sBs, sT.split('|')[-1]) for sT in sTargets]
        if sAliasAttrs:
            for t,sTargetAttr in enumerate(sReturnTargets):
                if sTargetAttr.split('.')[-1] != sAliasAttrs[t]:
                    try:
                        cmds.aliasAttr(sAliasAttrs[t], '%s.w[%d]' % (sBs, t))
                    except Exception as e:
                        raise Exception('Blendshape: %s, Mesh: %s -> %s' % (sBs, sGeometry, e))

                    sReturnTargets[t] = '%s.%s' % (sBs, sAliasAttrs[t])

    return sReturnTargets



# depricated!! use blendShapes.getUniqueBlendShapeTargetName instead
def getUniqueBlendShapeTargetName(sBlendShape, sTarget):

    if not cmds.objExists('%s.%s' % (sBlendShape, sTarget)):
        return sTarget

    sTarget, iNumber = utils.getNumberAtEnd(sTarget)
    while True:
        iNumber += 1
        sNewTarget = '%s%d' % (sTarget, iNumber)
        if not cmds.objExists('%s.%s' % (sBlendShape, sNewTarget)):
            return sNewTarget




def addInbetweenTarget(sGeometry, sInbetween, fWeight, sBlendShape, iTarget):
    if sBlendShape == None:
        sBlendShape = listAllDeformers(sGeometry, sFilterTypes=['blendShape'])[0]
    if utils.isStringOrUnicode(iTarget):
        dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        iTarget = dTargets[iTarget]
    cmds.blendShape(sBlendShape, e=True, ib=True, t=[sGeometry, iTarget, sInbetween, fWeight])


def deleteTargets(sBlendShape, sTargets):
    dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    for sT in sTargets:
        sGeos = cmds.deformer(sBlendShape, q=True, g=True)
        for sG in sGeos:
            cmds.blendShape(sBlendShape, e=True, rm=True, t=[sG, dTargets[sT], sT, 1.0])




# def removeBlendShapeTargets(sGeometry, sTargets, sBlendShape):




# def stackSkinCluster(sSkinCluster, sToMesh, bBeforeLastSkinCluster=True, bFrontOfChain=True):
#     import kangarooTools.patch as patch
#
#     # get skinCluster info
#     sMesh = cmds.deformer(sSkinCluster, q=True, g=True)[0]
#     pMesh = patch.patchFromName(sMesh)
#     sMatrices = cmds.listConnections('%s.matrix[*]' % sSkinCluster, p=True)
#     aBindPreMatrices = np.array(cmds.getAttr('%s.bindPreMatrix[*]' % sSkinCluster)).reshape(-1, 16)
#     fnSkinCluster = OpenMayaAnim.MFnSkinCluster(utils.getDependNode(sSkinCluster))
#     mWeights, iInfCount = fnSkinCluster.getWeights(pMesh.mDagPath, pMesh.getIndexedComponents())
#
#     # get or create new skinCluster
#     sNewName = '%s_STACKED' % sSkinCluster
#     if cmds.objExists(sNewName):
#         cmds.warning('reusing skinCluster %s - it will be a disaster if connected influences are different')
#         sNewSkinCluster = sNewName
#     else:
#         if bBeforeLastSkinCluster:
#             sExistingSkinClusters = listAllDeformers(sToMesh, sFilterTypes=['skinCluster'])
#             sLastAlreadyExistingSkinCluster = sExistingSkinClusters[-1] if sExistingSkinClusters else None
#         sNewSkinCluster = cmds.deformer(sToMesh, type='skinCluster', foc=bFrontOfChain, n=sNewName)[0]
#         if bBeforeLastSkinCluster and sLastAlreadyExistingSkinCluster:
#             cmds.reorderDeformers(sLastAlreadyExistingSkinCluster, sNewSkinCluster, sToMesh)
#         for m,sM in enumerate(sMatrices):
#             cmds.connectAttr(sM, '%s.matrix[%d]' % (sNewSkinCluster,m))
#             cmds.setAttr('%s.bindPreMatrix[%d]' % (sNewSkinCluster,m), *list(aBindPreMatrices[m]), type='matrix')
#
#     fnNewSkinCluster = OpenMayaAnim.MFnSkinCluster(utils.getDependNode(sNewSkinCluster))
#     pToMesh = patch.patchFromName(sToMesh)
#     fnNewSkinCluster.setWeights(pToMesh.mDagPath, pToMesh.getIndexedComponents(),
#                                 OpenMaya2.MIntArray(range(iInfCount)), mWeights)
#
#     # quaternion skinning
#     iSkinningMethod = cmds.getAttr('%s.skinningMethod' % sSkinCluster)
#     cmds.setAttr('%s.skinningMethod' % sNewSkinCluster, iSkinningMethod)
#     if iSkinningMethod == 2:
#         mBlendWeights = fnSkinCluster.getBlendWeights(pMesh.mDagPath, pMesh.getIndexedComponents())
#         fnNewSkinCluster.setBlendWeights(pToMesh.mDagPath, pToMesh.getIndexedComponents(), mBlendWeights)
#
#     return sNewSkinCluster



def addInfluences(sSkinCluster, sInfluences):
    sAttrMissing = [sI for sI in sInfluences if not cmds.objExists('%s.liw' % (sI))]
    if sAttrMissing:
        sTempPoly = cmds.polyCube()[0]
        cmds.skinCluster(sTempPoly, sAttrMissing, tsb=True)

    # find the available matrix indices
    sCurrentJoints = cmds.listConnections('%s.matrix' % sSkinCluster, s=True, d=False)
    if sCurrentJoints:
        sAddInfluences = list(set(sInfluences) - set(sCurrentJoints))
        dSortArray = {sJ:j for j,sJ in enumerate(sInfluences)}
        sAddInfluences.sort(key=lambda a:dSortArray[a])
    else:
        sAddInfluences = list(sInfluences)

    sAllConnections = cmds.listConnections('%s.matrix' % sSkinCluster, s=True, d=False, c=True)
    if sAllConnections == None:
        aUseIndices = np.arange(len(sAddInfluences))
    else:
        aExistingMatrixIndices = [int(sC.split(']')[0].split('[')[1]) for sC in sAllConnections[::2]]
        aAllPossibles = np.arange(np.max(aExistingMatrixIndices) + 1 + len(sAddInfluences))
        aUseIndices = np.setdiff1d(aAllPossibles, aExistingMatrixIndices)[:len(sAddInfluences)]

    bAddedRefJoints = False
    for j, sJoint in enumerate(sAddInfluences):
        sMatrixAttr = '%s.worldMatrix' % sJoint
        cmds.connectAttr(sMatrixAttr, '%s.matrix[%d]' % (sSkinCluster, aUseIndices[j]))
        sPlug = '%s.bindPreMatrix[%d]' % (sSkinCluster, aUseIndices[j])

        # # for the unlikey case of left over connections (let's enable this as soon as there is actually a problem, until then let's see if there are errors)
        # sConns = cmds.listConnections(sPlug, s=True, d=False, p=True)
        # if sConns:
        #     cmds.disconnectAttr(sConns[0], sPlug)

        cmds.setAttr(sPlug,
                     *cmds.getAttr('%s.worldInverseMatrix' % sJoint), type='matrix')

        sRefAttr = '%s.%s' % (sJoint, kPostRefJointAttr)

        if cmds.objExists(sRefAttr):
            _refConnection(sSkinCluster, sJoint)

    if sAttrMissing:
        cmds.delete(sTempPoly)

    return bAddedRefJoints


def setCurrentReferencePose(sJoints):
    for sJ in utils.toList(sJoints):
        utils.addStringAttr(sJ, kPostRefJointAttr, cmds.getAttr('%s.worldInverseMatrix' % sJ))


def _refConnection(sSkinCluster, sJoint):
    sRefAttr = '%s.%s' % (sJoint, kPostRefJointAttr)
    sRefJ = cmds.getAttr(sRefAttr)

    # see if we have matrix value or matrix attribute
    fMatrix = None
    try:
        fMatrix = eval(sRefJ)
    except:
        pass

    # get the plug index
    sMatrixConnections = cmds.listConnections('%s.worldMatrix' % sJoint, p=True, t='skinCluster', s=False, d=True)
    if not sMatrixConnections:
        return
    sMatrixConnections = [sC for sC in sMatrixConnections if sC.startswith(sSkinCluster)]
    if not sMatrixConnections:
        return
    iIndex = utils.indexFromName(sMatrixConnections[0])


    if not utils.isNone(fMatrix):
        cmds.setAttr('%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex), fMatrix, type='matrix')
    else:
        if not cmds.objExists(sRefJ):
            return
        sInverseAttr = sRefJ if '.' in sRefJ else '%s.worldInverseMatrix' % sRefJ
        cmds.connectAttr(sInverseAttr, '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex), f=True)
        bAddedRefJoints = True
        return bAddedRefJoints



def connectRefsOnCurrentSkinClusters(sJoints):
    for sJoint in utils.toList(sJoints):
        sRefAttr = '%s.%s' % (sJoint, kPostRefJointAttr)
        if not cmds.objExists(sRefAttr):
            continue

        sRefJ = cmds.getAttr(sRefAttr)
        if not cmds.objExists(sRefJ):
            continue
        sMatrixConnections = cmds.listConnections('%s.worldMatrix' % sJoint, p=True, t='skinCluster', s=False, d=True)
        if not sMatrixConnections:
            continue
        for sMatrixConnection in sMatrixConnections:
            sSkinCluster = sMatrixConnection.split('.')[0]
            iIndex = utils.indexFromName(sMatrixConnection)

            if '.' in sRefJ:
                sInverseMatrix = sRefJ
            else:
                sInverseMatrix = '%s.worldInverseMatrix' % sRefJ

            sPlug = '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex)
            if not cmds.listConnections(sPlug, s=True, d=False):
                cmds.connectAttr(sInverseMatrix, sPlug)



def skinMesh(sMesh, sInfluences, bFoc=False, sName=None, bAlwaysAddDefaultWeights=False, bAlwaysCreateManually=False, _bSkipDeformerAdjustLogging=False):
    import kangarooTools.patch as patch

    if sName == None:
        sName = 'skinCluster__%s' % sMesh
    bAddZeroJoint = False
    if bAlwaysCreateManually or listAllDeformers(sMesh, sFilterTypes=['skinCluster']):
        sSkinCluster = cmds.deformer(sMesh, type='skinCluster', name=sName, frontOfChain=bFoc)[0]
        if cmds.objectType(sMesh) in ['transform', 'joint']:
            sMatrixNode = sMesh
        else:
            sMatrixNode = cmds.listRelatives(sMesh, p=True)[0]
        fGeoMatrix = cmds.xform(sMatrixNode, q=True, m=True, ws=True)
        cmds.setAttr('%s.geomMatrix' % sSkinCluster, *fGeoMatrix, type='matrix')
        for sA in ['t','r','s']:
            try: # if it's a reference, this would not work
                cmds.setAttr('%s.%s' % (sMatrixNode,sA), lock=True)
            except:
                pass
        if addInfluences(sSkinCluster, sInfluences):
            bAddZeroJoint = True
        if bAlwaysAddDefaultWeights:
            pMesh = patch.patchFromName(sMesh)
            aWeights2d = np.zeros((pMesh.getTotalCount(), len(sInfluences)), dtype='float64')
            aWeights2d[:,0] = 1.0
            pMesh.setSkinClusterWeights(aWeights2d=aWeights2d, sChooseSkinCluster=sSkinCluster, _bSkipDeformerAdjustLogging=_bSkipDeformerAdjustLogging)
    else:
        sMissing = [sI for sI in sInfluences if not cmds.objExists(sI)]
        if sMissing:
            raise Exception('missing influences: %s' % sMissing)
        sClashing = [sI for sI in cmds.ls(sInfluences) if '|' in sI]
        if sClashing:
            raise Exception('clashing names: %s' % sClashing)

        sSkinCluster = cmds.skinCluster(sMesh, sInfluences, tsb=True, name=sName, frontOfChain=bFoc)[0]
        sJointsWithRef = [sJ for sJ in sInfluences if cmds.objExists('%s.%s' % (sJ, kPostRefJointAttr))]
        if sJointsWithRef:
            [_refConnection(sSkinCluster, sJ) for sJ in sJointsWithRef]
            if len(sJointsWithRef) == len(sInfluences): # if all the joints are ref
                bAddZeroJoint = True

    if bAddZeroJoint:
        sAllJoints = cmds.listConnections('%s.matrix' % sSkinCluster, s=True, d=False)
        if 'jnt_m_zero' not in sAllJoints:
            sZeroJoint = utils.getZeroJoint()
            addInfluences(sSkinCluster, [sZeroJoint])

    return sSkinCluster


def skinYetiFeatherCluster(sTransform, sProxyFeather, sName=None):

    import kangarooTools.patch as patch
    import kangarooTools.xforms as xforms

    pProxy = patch.patchFromName(sProxyFeather)
    _, sInfluences, aFromWeights2d = pProxy.getSkinCluster()



    sShapes = cmds.listRelatives(sTransform, typ='nurbsCurve', c=True, ni=True, f=True)

    sClusters = []
    for sI in sInfluences:
        sCluster, sHandle = cmds.cluster(sTransform, n='%s_cluster' % sI)
        cmds.parentConstraint(sI, sHandle, mo=True)
        sClusters.append(sCluster)

    for i,sS in enumerate(sShapes):
        pShape = patch.patchFromName(sS)
        aMapVerts, aMapCoords, _ = barycentric.getVertexCoordinates([pProxy], patch.patchFromName(sS))
        aMultiplied = aFromWeights2d[aMapVerts] * aMapCoords[np.arange(pShape.getTotalCount())][..., np.newaxis]
        aShapeWeights2d = np.sum(aMultiplied, axis=1)

        for j,sCluster in enumerate(sClusters):
            cmds.setAttr('%s.weightList[%d].weights[0:%d]' % (sCluster, i, len(aShapeWeights2d)-1), *list(aShapeWeights2d[:,j]))

    # pMesh.setSkinClusterWeights(aWeights2d=aWeights2d, sChooseSkinCluster=sSkinCluster)




def skinYetiFeatherNotWorking(sTransform, sProxyFeather, bFoc=False, sName=None, bAlwaysAddDefaultWeights=False):

    import kangarooTools.patch as patch

    pProxy = patch.patchFromName(sProxyFeather)
    _, sInfluences, aFromWeights2d = pProxy.getSkinCluster()



    sShapes = cmds.listRelatives(sTransform, typ='nurbsCurve', c=True, ni=True, f=True)
    sSkinCluster = cmds.deformer(sShapes, type='skinCluster', name='skinCluster__%s' % sTransform.split('|')[0])[0]


    addInfluences(sSkinCluster, sInfluences)

    fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(utils.getDependNode(sSkinCluster))
    for i,sS in enumerate(sShapes[:1]):
        print('sS: ', sS)
        pShape = patch.patchFromName(sS)
        aMapVerts, aMapCoords, _ = barycentric.getVertexCoordinates([pProxy], patch.patchFromName(sS))
        aMultiplied = aFromWeights2d[aMapVerts] * aMapCoords[np.arange(pShape.getTotalCount())][..., np.newaxis]
        aShapeWeights2d = np.sum(aMultiplied, axis=1)
        # aWeights2d[pSelected.aIds, :] = np.sum(aMultiplied, axis=1)

        fnVtxComp = OpenMaya.MFnSingleIndexedComponent()
        mComponents = fnVtxComp.create(OpenMaya.MFn.kCurveCVComponent)
        print('pShape.getTotalCount(): ', pShape.getTotalCount())
        fnVtxComp.addElements(range(pShape.getTotalCount()))
        print('aShapeWeights2d: ', aShapeWeights2d)
        mWeights = OpenMaya.MDoubleArray(aShapeWeights2d.flatten())

        mShape = utils.getDagPath(sS)
        print('mShape: ', mShape)
        fnSkinCluster.setWeights(mShape, mComponents, OpenMaya.MIntArray(range(len(sInfluences))), mWeights)

    # pMesh.setSkinClusterWeights(aWeights2d=aWeights2d, sChooseSkinCluster=sSkinCluster)


'''
import kangarooTools.deformers as deformers
utils.reload2(deformers)
deformers.skinMultipleMeshes(['a','b'], ['joint1'], sName='newSkinCluster')


import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim
import kangarooTools.utilFunctions as utils


fnVtxComp = OpenMaya2.MFnSingleIndexedComponent()
mComponents = fnVtxComp.create( OpenMaya2.MFn.kMeshVertComponent )
fnVtxComp.addElements(range(382))
mSkinCluster = utils.getDependNode('newSkinCluster')
mShapeA = utils.getDagPath('aShape')

fnSkinCluster = OpenMayaAnim.MFnSkinCluster(mSkinCluster)
mWeights, iInfCount = fnSkinCluster.getWeights(mShapeA, mComponents) # gives less indices than what MFnNurbsSurface functions give
aWeights2d = np.array(list(mWeights), dtype='float64').reshape(-1, iInfCount)
return sSkinCluster, self.sInfluences, aWeights2d


'''



qClusterDialog = None
def clusterSel():
    global qClusterDialog
    def _clusterSel(sName):
        import kangarooTools.patch as patch
        for pPatch in patch.getSelectedPatches():
            sMesh = pPatch.getTransformName()
            sCluster, sHandle = cmds.cluster(sMesh, n=sName)

            aValues = np.zeros(pPatch.getTotalCount(), dtype='float64')
            if pPatch.aSofts != None:
                aValues[pPatch.aIds] = pPatch.aSofts
            else:
                aValues[pPatch.aIds] = 1.0

            pPatch.setMapValues('%s.weightList[0].weights' % sCluster, aValues,
                                aOverrideIds=np.arange(pPatch.getTotalCount()),
                                aOverrideSofts=np.ones(pPatch.getTotalCount()))
            aPoints = pPatch.getAllPoints()[aValues > 0.95]
            aMean = np.mean(aPoints, axis=0)
            cmds.move(aMean[0], aMean[1], aMean[2], '%s.scalePivot' % sHandle, '%s.rotatePivot' % sHandle)
            cmds.setAttr('%s.origin' % sHandle, aMean[0], aMean[1], aMean[2])

    qClusterDialog = utilsQt.QGetStringDialog(_clusterSel, sMessage='enter name for cluster')
    qClusterDialog.show()



qSkinDialog = None
def skinSel():
    global qClusterDialog
    def _skinSel(bPost, sSuffix):
        import kangarooTools.deformers as deformers
        import kangarooTools.utilFunctions as utils

        sMeshes = cmds.ls(sl=True, et='transform')
        sInfluences = cmds.ls(sl=True, et='joint')
        if bPost:
            sInfluences.append('jnt_m_zero')

        for sM in sMeshes:
            sName = '%sskinCluster__%s' % utils.splitNamespace(sM)

            if bPost:
                sName = '%s__%s' % (sName, sSuffix.upper().strip('_'))
            else:
                if cmds.objExists(sName):
                    sError = cmds.confirmDialog(m='SkinCluster with name "%s" already exists. Did you mean to add a Post SkinCluster?' % sName)
                    raise Exception(sError)

            deformers.skinMesh(sM, sInfluences, sName=sName,
                               bAlwaysAddDefaultWeights=True, bAlwaysCreateManually=True)

    qSkinDialog = utilsQt.QSkinDialog(_skinSel)
    qSkinDialog.show()




def deleteOtherSkinClusters():
    sSel = cmds.ls(sl=True, et='skinCluster')
    if not sSel:
        raise Exception('need to select skinCluster')
    sSkinCluster = sSel[0]
    sObject = cmds.deformer(sSkinCluster, q=True, g=True)[0]
    sAllSkinClusters = set(listAllDeformers(sObject, sFilterTypes=['skinCluster']))
    print('sSkinCluster: ', sSkinCluster)
    sAllSkinClusters.remove(sSkinCluster)
    print('sDelete: ', sAllSkinClusters)
    cmds.delete(sAllSkinClusters)



def lockAllInfluencesExcept(sMesh, sExceptJoints, sChooseSkinCluster=None):
    import kangarooTools.patch as patch
    pMesh = patch.patchFromName(sMesh)
    _, sInfluences = pMesh.getSkinCluster(bSkipWeights=True, sChooseSkinCluster=sChooseSkinCluster)
    for sInf in sInfluences:
        cmds.setAttr('%s.liw' % sInf, True)
    for sInf in sExceptJoints:
        cmds.setAttr('%s.liw' % sInf, False)


def createProximityWrap(sChild, sDrivers, sName=None, bCreateBaseMesh=False, fFalloffScale=10.0):
    sSelBefore = cmds.ls(sl=True)

    sWrapsBefore = cmds.ls(et='proximityWrap')
    cmds.select(sChild)
    cmds.ProximityWrap()
    sWrap = (set(cmds.ls(et='proximityWrap')) - set(sWrapsBefore)).pop()
    cmds.setAttr('%s.falloffScale' % sWrap, fFalloffScale)
    if sName:
        sWrap = cmds.rename(sWrap, sName)


    sBases = []
    for i,sDriver in enumerate(utils.toList(sDrivers)):
        sOrigs = cmds.deformableShape(sDriver, originalGeometry=True)
        if sOrigs and sOrigs[0]:
            sDriverOrig = sOrigs[0].split('.')[0]
        else:
            sFirstDeformableShapeReturn = cmds.deformableShape(sDriver, createOriginalGeometry=True)[0]
            sDriverOrig = sFirstDeformableShapeReturn.split('.')[0]

        cmds.connectAttr('%s.outMesh' % sDriverOrig, '%s.drivers[%d].driverBindGeometry' % (sWrap, i))
        cmds.connectAttr('%s.worldMesh[0]' % sDriver, '%s.drivers[%d].driverGeometry' % (sWrap, i))

        if bCreateBaseMesh:
            sBase = cmds.duplicate(sDriver, n='%s_proximityWrapBase' % sDriver)[0]
            cmds.connectAttr('%s.outMesh' % sBase, '%s.drivers[%d].driverBindGeometry' % (sWrap,i), force=True)
            sBases.append(sBase)

    cmds.select(sSelBefore)

    if bCreateBaseMesh:
        return sWrap, sBases
    else:
        return sWrap



def createDeltaMush(sMeshes, iIterations=10, fDisplacement=1.0, fEnvelope=1.0, bPinBorders=True, sSuffix='', sScale=None):
    sDeltaMushes = []
    for sMesh in utils.toList(sMeshes):
        sDeltaMush = 'deltaMush__%s' % sMesh
        if sSuffix:
            sDeltaMush = '%s__%s' % (sDeltaMush, sSuffix)
        cmds.deformer(sMesh, type='deltaMush', n=sDeltaMush)
        utils._connectOrSet(fDisplacement, '%s.displacement' % sDeltaMush)
        utils._connectOrSet(iIterations, '%s.smoothingIterations' % sDeltaMush)
        utils._connectOrSet(fEnvelope, '%s.envelope' % sDeltaMush)
        cmds.setAttr('%s.pinBorderVertices' % sDeltaMush, bPinBorders)
        sDeltaMushes.append(sDeltaMush)
        if not utils.isNone(sScale):
            cmds.connectAttr(sScale, '%s.scaleX' % sDeltaMush)
            cmds.connectAttr(sScale, '%s.scaleY' % sDeltaMush)
            cmds.connectAttr(sScale, '%s.scaleZ' % sDeltaMush)
    return sDeltaMushes



def createWrap(sChildren, sParent, bExclusiveBind=True):
    '''
    it's faster with bExlcusiveBind as True
    '''
    sChildren = utils.toList(sChildren)

    sSelBefore = cmds.ls(sl=True)
    cmds.select(sChildren, sParent)

    sWrapsBefore = set(cmds.ls(et='wrap'))
    cmds.CreateWrap()
    sWrapsAfter = set(cmds.ls(et='wrap'))

    sUnorderedWraps = list(sWrapsAfter - sWrapsBefore)
    for sWrap in sUnorderedWraps:
        cmds.setAttr('%s.exclusiveBind' % sWrap, bExclusiveBind)

    sBase = cmds.listConnections('%s.basePoints' % sUnorderedWraps[0])[0]

    cmds.select(sSelBefore)
    return sUnorderedWraps, sBase




def createMorph(sChild, sParent, aWeights=None, sSuffix=None):
    sSelBefore = cmds.ls(sl=True)
    cmds.select(sChild, sParent)

    sMorphsBefore = set(cmds.ls(et='morph'))
    cmds.Morph()
    sMorphsAfter = set(cmds.ls(et='morph'))
    sMorph = list(sMorphsAfter - sMorphsBefore)[0]

    sName = 'morph__%s' % sChild
    if not utils.isNone(sSuffix):
        sName = '%s__%s' % (sName, sSuffix)

    if not utils.isNone(aWeights):
        import kangarooTools.patch as patch
        patch.patchFromName(sChild).setMapValues('%s.weightList[0].weights' % sMorph, aWeights)

    sMorph = cmds.rename(sMorph, sName)
    cmds.select(sSelBefore)
    return sMorph



def setNewBindPose(sJoint):
    cConns = cmds.listConnections('%s.worldMatrix' % sJoint, p=True, t='skinCluster') or []
    for sMatrixPlug in cConns:
        iIndex = utils.indexFromName(sMatrixPlug)
        sSkinCluster = sMatrixPlug.split('.')[0]
        sBindMatrixAttr = '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex)
        cmds.setAttr(sBindMatrixAttr, cmds.getAttr('%s.worldInverseMatrix' % sJoint), type='matrix')


def getInbetweens(sBlendShape, iTargetIndex=0):
    mBlendShape = utils.getDependNodeOldApi(sBlendShape)
    fnBlendShape = OpenMayaAnim.MFnBlendShapeDeformer(mBlendShape)
    sBaseGeo = getGeoFromDeformer(sBlendShape)
    mBase = utils.getDagPathOldApi(sBaseGeo).node()
    mResult = OpenMaya.MIntArray()
    fnBlendShape.targetItemIndexList(iTargetIndex, mBase, mResult)

    fInbetweenWeights = []
    for iIndex in mResult:
        if iIndex < 6000 and iIndex > 5000:
            fInbetweenWeights.append(round((iIndex-5000) * 0.001, 3))

    return fInbetweenWeights


# this is because foc doesn't work when there is a lattice box on the mesh
def preDeformationBlendshapeHack(sTargets, sMesh, **kwargs):

    sAllDeformers = listAllDeformers(sMesh)

    if sTargets:
        sBlendShapes = cmds.blendShape(sTargets, sMesh, **kwargs)
    else:
        sBlendShapes = cmds.blendShape(sMesh, **kwargs)
    if sAllDeformers:
        cmds.reorderDeformers(sAllDeformers[-1], sBlendShapes[0], sMesh)

    return sBlendShapes


def applyLattice(sLatAndBase, sMesh):
    sLat, sLatBase = sLatAndBase
    sNewLatDeformer, sTempLat, sTempLatBase = cmds.lattice(sMesh, n='%s__ffd' % (sMesh))
    cmds.connectAttr('%sShape.latticeOutput' % sLat, '%s.deformedLatticePoints' % sNewLatDeformer, f=True)
    cmds.connectAttr('%sShape.worldMatrix[0]' % sLat, '%s.deformedLatticeMatrix' % sNewLatDeformer, f=True)
    cmds.connectAttr('%sShape.worldMatrix[0]' % sLatBase, '%s.baseLatticeMatrix' % sNewLatDeformer, f=True)
    cmds.setAttr('%s.outsideLattice' % sNewLatDeformer, 1)
    cmds.delete(sTempLat, sTempLatBase)
    return sNewLatDeformer


def disconnectLattice(sDeformer):
    for sA in ['deformedLatticePoints', 'deformedLatticeMatrix', 'baseLatticeMatrix']:
        sAttr = '%s.%s' % (sDeformer, sA)
        sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
        if sConns:
            cmds.disconnectAttr(sConns[0], sAttr)


def transferLattice(sLatDeformer, sMesh):
    sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
    sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]

    sNewLatDeformer, sTempLat, sTempLatBase = cmds.lattice(sMesh, n='%s__%s' % (sMesh, sLatDeformer))

    cmds.connectAttr('%sShape.latticeOutput' % sLat, '%s.deformedLatticePoints' % sNewLatDeformer, f=True)
    cmds.connectAttr('%sShape.worldMatrix[0]' % sLat, '%s.deformedLatticeMatrix' % sNewLatDeformer, f=True)
    cmds.connectAttr('%sShape.worldMatrix[0]' % sLatBase, '%s.baseLatticeMatrix' % sNewLatDeformer, f=True)
    cmds.delete(sTempLat, sTempLatBase)

    cmds.setAttr('%s.localInfluenceS' % sNewLatDeformer, cmds.getAttr('%s.localInfluenceS' % sLatDeformer))
    cmds.setAttr('%s.localInfluenceT' % sNewLatDeformer, cmds.getAttr('%s.localInfluenceT' % sLatDeformer))
    cmds.setAttr('%s.localInfluenceU' % sNewLatDeformer, cmds.getAttr('%s.localInfluenceU' % sLatDeformer))
    cmds.setAttr('%s.outsideLattice' % sNewLatDeformer, cmds.getAttr('%s.outsideLattice' % sLatDeformer))

    import kangarooTabTools.weights as weights
    weights.transferWeightMaps('%s.weightList[0].weights' % sLatDeformer, sMaps=['%s.weightList[0].weights' % sNewLatDeformer], _bSkipDeformerAdjustLogging=True)

    return sNewLatDeformer



# depricated!!! use constraints.parallelTransformAsDeformers() instead
kRotateByNeighborVerts = 'bRotateByNeighborVerts'
def blendShapeSkinClusterToPositions2(sMesh, iIds, sBlendShape=None, bDoSkinCluster=False, fInfluenceWeightLimit=0.01, fTargetMinimumDistance=0.001, sParent=None,
                                     sSkinClusters=[], funcConvertPlugName=None, sScaleJoint=None, ssIgnoreTargets=[], bRotateByNeighborVerts=[], bConnectEnvelopes=True):
    import kangarooTools.patch as patch
    import kangarooTools.nodes as nodes
    import kangarooTools.curves as curves

    report.report.refreshIcon(True)
    for sSkinCluster in sSkinClusters:
        if not cmds.objExists(sSkinCluster) or cmds.objectType(sSkinCluster) not in ['skinCluster', 'ffd']:
            raise Exception('SkinCluster/Lattice %s doesn\'t exist' % sSkinCluster)

    if sBlendShape == None:
        sBlendShapes = listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]

    sConnections = []
    aIds = np.array(iIds, dtype=int)
    aUniqueIds = np.unique(np.array(iIds, dtype=int))
    aIdsOrder = utils.findOneArrayInAnother(aUniqueIds, iIds)
    if -1 in aIdsOrder:
        raise Exception('there are issues with iIds array: %s' % str(iIds))


    sScaleAttr = None
    if sScaleJoint:
        sScaleAttr = nodes.getScaleFromXform(sScaleJoint)

    pMesh = patch.patchFromName(sMesh)
    pMesh.aIds = aUniqueIds
    aDefaultPoints = pMesh.getAllPoints()
    # aDefaultPointsInds = aDefaultPoints[aIds]




    iiVectors = []
    aaNbs = pMesh.getNeighbors(bExcludeNeighborsNotInIds=False)
    iIds3 = []
    for i, iInd in enumerate(aIdsOrder):
        bVectors = True if i < len(bRotateByNeighborVerts) and bRotateByNeighborVerts[i] else False
        iId = aUniqueIds[iInd]
        if not bVectors:
            iiVectors.append(None)
            iIds3 += [iId, iId, iId]
        else:
            aNbs = aaNbs[iInd]
            xPairInfos = []
            for m in range(0, len(aNbs), 1):
                for n in range(m + 1, len(aNbs), 1):
                    aPointM = aDefaultPoints[aNbs[m]] - aDefaultPoints[iId]
                    aPointN = aDefaultPoints[aNbs[n]] - aDefaultPoints[iId]
                    fLengthM = np.linalg.norm(aPointM)
                    fLengthN = np.linalg.norm(aPointN)
                    aPointM /= fLengthM
                    aPointN /= fLengthN
                    fDot = np.dot(aPointM, aPointN)
                    # fMin = min(fLengthM, fLengthN)
                    xPairInfos.append([[aNbs[m], aNbs[n]], fDot, fLengthM, fLengthN])

            xPairInfos.sort(key=lambda x: min(x[2], x[3]), reverse=True)
            xPairInfos = xPairInfos[:len(xPairInfos) / 2]
            xPairInfos.sort(key=lambda x: abs(x[1]))
            iBestVector = xPairInfos[0][0]
            if xPairInfos[0][2] < xPairInfos[0][3]:
                iBestVector[0], iBestVector[1] = iBestVector[1], iBestVector[0]
            iiVectors.append(iBestVector)
            iIds3 += [iId, iBestVector[0], iBestVector[1]]


    sBlendShapePositions = []
    sBlendShapeRotations = []
    if not sBlendShape:
        ssThreeSums = []
        for i, iInd in enumerate(aIdsOrder):
            aPoint = aDefaultPoints[aUniqueIds[iInd]]
            sBlendShapePositions.append(aPoint)
            sBlendShapeRotations.append([0,0,0])
            sThreeSums = [aPoint]
            if isinstance(iiVectors[i], (list,tuple)):
                sThreeSums.append(aDefaultPoints[iiVectors[i][0]])
                sThreeSums.append(aDefaultPoints[iiVectors[i][1]])
            ssThreeSums.append(sThreeSums)

    else:
        dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        sTargets = list(dTargets.keys())

        sAttrs = ['%s.%s' % (sBlendShape,sT) for sT in sTargets]
        for t,sT in enumerate(sTargets):
            sConns = cmds.listConnections(sAttrs[t], s=True, d=False, p=True)
            if not sConns:
                sConnections.append(sAttrs[t])
            else:
                sDriver = sConns[0]
                sConnections.append(sDriver)
                cmds.disconnectAttr(sDriver, sAttrs[t])
            cmds.setAttr(sAttrs[t], 0)

        dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

        aTargetPoints = []
        dInbetweenPoints = {}
        for t, sT in enumerate(sTargets):
            cmds.setAttr(sAttrs[t], 1.0)
            aTargetPoints.append(pMesh.getAllPoints())

            fInbetweens = getInbetweens(sBlendShape, iTargetIndex=dTargets[sT])
            dInbetweenPoints[sT] = []
            for fWeight in fInbetweens:
                cmds.setAttr(sAttrs[t], fWeight)
                dInbetweenPoints[sT].append([fWeight, pMesh.getPoints()])

            cmds.setAttr(sAttrs[t], 0.0)


        ssThreeSums = []
        for i, iInd in enumerate(aIdsOrder):
            iId = aUniqueIds[iInd]
            bVectors = True if i < len(bRotateByNeighborVerts) and bRotateByNeighborVerts[i] else False

            ssMultipls = [[aDefaultPoints[iId]]]
            if bVectors:
                ssMultipls += [[aDefaultPoints[iiVectors[i][0]]], [aDefaultPoints[iiVectors[i][1]]]]
            for t, sT in enumerate(sTargets):
                bIgnoreThisTarget = False
                if i < len(ssIgnoreTargets):
                    for sIgnoreT in ssIgnoreTargets[i]:
                        sIgnoreT = sIgnoreT.split('.')[-1]
                        if sT == sIgnoreT:
                            bIgnoreThisTarget = True
                            break
                if bIgnoreThisTarget:
                    continue

                iDoIds = [iId]
                if bVectors:
                    iDoIds += iiVectors[i]
                for a, iDoId in enumerate(iDoIds):
                    aVector = aTargetPoints[t][iDoId] - aDefaultPoints[iDoId]
                    if np.linalg.norm(aVector) >= fTargetMinimumDistance:
                        if not dInbetweenPoints[sT]:
                            ssMultipls[a].append(nodes.createVectorMultiplyNode(aVector, sConnections[t], bVectorByScalar=True,
                                             sName='generatePosition_%s_%s_vtx%d' % (sMesh,sT,iDoId)))
                        else:
                            fWeights = []
                            fTargets = []
                            for fW, aTargets in dInbetweenPoints[sT]:
                                fWeights.append(fW)
                                fTargets.append(aTargets[i]-aDefaultPoints[iDoId])
                            fWeights = [0.0] + fWeights + [1.0]
                            fTargets = [[0.0, 0.0, 0.0]] + [list(fT) for fT in fTargets] + [list(aVector)]
                            sDrivenKeys = [nodes.setDrivenKey(sConnections[t], fWeights, None, [fT[a] for fT in fTargets],
                                                              sInTanType='linear', sOutTanType='linear') for a in [0,1,2]]
                            ssMultipls[a].append(sDrivenKeys)

            sThreeSums = []
            for a, sMultipl in enumerate(ssMultipls):
                sSum = nodes.createVectorAdditionNode(sMultipl, sName='generatePosition_%s_vtx%d' % (sMesh,iId))
                if bConnectEnvelopes:
                    sSum = nodes.createBlendNode('%s.envelope' % sBlendShape, sSum, aDefaultPoints[iId], bVector=True,
                                                                    sName='generatePosition_%s_vtx%d' % (sMesh,iId))
                sThreeSums.append(sSum)

            ssThreeSums.append(sThreeSums)

        # connect them back
        for t, sT in enumerate(sTargets):
            if sConnections[t] != sAttrs[t]:
                nodes._connectOrSet(sConnections[t], sAttrs[t])

    report.report.refreshIcon()
    sLocs = []
    for l in aIdsOrder:
        sLocatorName = utils.getUniqueName('loc_%sPosition_%03d' % (sMesh, aIds[aIdsOrder[l]]))
        sLocs.append(cmds.spaceLocator(n=sLocatorName)[0])


    if not bDoSkinCluster:
        for i, iInd in enumerate(aIdsOrder):
            nodes._connectOrSetVector(sThreeSums[0][i], '%s.t' % sLocs[i])

    else: #bDoSkinCluster:
        ssSkinClusterResults = [[] for _ in range(len(aIdsOrder))]
        print('ssSkinClusterResults: ', ssSkinClusterResults)
        for i, iInd in enumerate(aIdsOrder):
            for a, sSum in enumerate(ssThreeSums[i]): # 1 or 3
                print('sSum: ', sSum)
                ssSkinClusterResults[i].append(nodes.createComposeMatrixNode(sSum, sName='generatePosition_%s_%d_vtx%d' % (sMesh, a, aUniqueIds[iInd])))


        if not sSkinClusters:
            sSkinClusters = [None] # do we need this??

        else:
            bCurve = False
            for sSkinCluster in sSkinClusters:
                if not cmds.objectType(sSkinCluster) == 'skinCluster':
                    bCurve = True

            aUniqueIds3 = np.unique(iIds3)
            aIdsOrder3 = utils.findOneArrayInAnother(aUniqueIds3, iIds3).reshape(-1,3)
            pMesh3 = patch.patchFromName(sMesh)
            pMesh3.aIds = aUniqueIds3

            if bCurve:
                import kangarooTabTools.weights as weights
                sCurveJoints = []
                for i, iInds3 in enumerate(aIdsOrder3):
                    if not (i % 5):
                        report.report.refreshIcon()

                    for a, sSkinClusterResult in enumerate(ssSkinClusterResults[i]):  # 1 or 3 times
                        iInd = iInds3[a]
                        iId = aUniqueIds3[iInd]
                        sJ = cmds.createNode('joint', n='%s_curveJoint_%03d' % (sMesh, iId))
                        nodes.createDecomposeMatrix(sSkinClusterResult, sTargetPos='%s.t' % sJ)
                        sCurveJoints.append(sJ)
                fPositions = [cmds.getAttr('%s.t' % sJ)[0] for sJ in sCurveJoints]
                sCurve = cmds.curve(p=fPositions, d=1)
                cmds.skinCluster(sCurve, sCurveJoints, tsb=True) #blendShape skinCluster
                cmds.parent(sCurve, sCurveJoints, sParent)

                for sSkinCluster in sSkinClusters:
                    if cmds.objectType(sSkinCluster) == 'skinCluster':
                        weights.transferSkinCluster([patch.patchFromName(sCurve)], sFrom=sSkinCluster, bCreateNewSkinCluster=True)
                    elif cmds.objectType(sSkinCluster) == 'ffd':
                        transferLattice(sSkinCluster, sCurve)

                fParams = curves.getParamsFromPoints(sCurve, fPositions)
                j = 0
                for i, iInds3 in enumerate(aIdsOrder3):
                    if not (i % 5):
                        report.report.refreshIcon()
                    for a, sSkinClusterResult in enumerate(ssSkinClusterResults[i]):  # 1 or 3 times
                        iInd = iInds3[a]
                        iId = aUniqueIds3[iInd]
                        _, sPointOnCurve = curves.createPointInfoNode(sCurve, fParam=fParams[j])
                        ssSkinClusterResults[i][a] = nodes.createComposeMatrixNode(sPointOnCurve)
                        j += 1
            else:
                for sSkinCluster in sSkinClusters:
                    sGotSkinCluster, sInfluences, aWeights2d3 = pMesh3.getSkinCluster(sChooseSkinCluster=sSkinCluster)
                    if sGotSkinCluster == None:
                        raise Exception('skinCluster %s is not on %s' % (sSkinCluster, sMesh))

                    aInfluences = np.array(sInfluences)
                    for i, iInds3 in enumerate(aIdsOrder3):
                        if not (i % 5):
                            report.report.refreshIcon()

                        for a, sSkinClusterResult in enumerate(ssSkinClusterResults[i]): # 1 or 3 times
                            iInd = iInds3[a]
                            iId = aUniqueIds3[iInd]

                            aIdWeights = aWeights2d3[iInd]
                            aNonZero = np.where(aIdWeights > fInfluenceWeightLimit)[0]
                            aInfs = aInfluences[aNonZero]
                            aWeights = aIdWeights[aNonZero]
                            aWeights /= np.sum(aWeights)

                            sMultipls = []
                            sMatrix = str(sSkinClusterResult)
                            for sInf in aInfs:
                                sConns = cmds.listConnections('%s.worldMatrix' % sInf, t='skinCluster', p=True) or []
                                sPlugs = [sC for sC in sConns if sC.split('.')[0] == sGotSkinCluster]
                                sPlug = sPlugs[0]
                                iPlugIndex = int(sPlug.split('[')[-1].split(']')[0])
                                sBindPreMatrixAttr = '%s.bindPreMatrix[%d]' % (sGotSkinCluster, iPlugIndex)
                                sInverseMatrix = cmds.listConnections(sBindPreMatrixAttr, s=True, d=False, p=True)
                                if sInverseMatrix:
                                    sInverseMatrix = sInverseMatrix[0]
                                    if funcConvertPlugName:
                                        sInverseMatrix = funcConvertPlugName(sInverseMatrix)
                                        if not cmds.objExists(sInverseMatrix):
                                            raise Exception('inverse matrix %s doesn\'t exist' % sInverseMatrix)
                                else:
                                    sInverseMatrix = cmds.getAttr(sBindPreMatrixAttr)

                                sInfMatrix = '%s.worldMatrix' % sInf
                                if funcConvertPlugName:
                                    sNewInfMatrix = funcConvertPlugName(sInfMatrix)
                                    if not cmds.objExists(sNewInfMatrix):
                                        raise Exception('joint matrix %s doesn\'t exist (taken from %s)' % (sNewInfMatrix, sInfMatrix))
                                    sInfMatrix = sNewInfMatrix

                                sMultipls.append(nodes.createMultMatrixNode([sMatrix,
                                                                             sInverseMatrix,
                                                                             sInfMatrix],
                                                 sName='generatePosition_%s_multiplyOffset_to_%s_vtx%d' % (sMesh, sInfMatrix.split('.')[0], iId)))

                            ssSkinClusterResults[i][a] = nodes.createBlendMatrixNode(sMultipls, aWeights, sName='generatePosition_%s_vtx%d' % (sMesh, iId))

        report.report.refreshIcon()

        for i, iInd in enumerate(aIdsOrder):
            sDecompose = nodes.createDecomposeMatrix(ssSkinClusterResults[i][0], sTargetPos='%s.t' % sLocs[i], sName='generatePosition_%s_vtx%d' % (sMesh, iId))
            if len(ssSkinClusterResults[i]) == 1:
                cmds.connectAttr('%s.outputRotate' % sDecompose.split('.')[0], '%s.r' % sLocs[i])

            if len(ssSkinClusterResults[i]) > 1:
                sAimConstraint = cmds.createNode('aimConstraint', n='generatePositionAim_%s_vtx%d' % (sMesh, iId), p=sParent)
                cmds.connectAttr(sDecompose, '%s.constraintRotateTranslate' % sAimConstraint)

                nodes.createDecomposeMatrix(ssSkinClusterResults[i][1], sTargetPos='%s.target[0].targetTranslate' % sAimConstraint)
                cmds.setAttr('%s.worldUpType' % sAimConstraint, 1)
                cmds.connectAttr(ssSkinClusterResults[i][2], '%s.worldUpMatrix' % sAimConstraint)
                cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sLocs[i])
            if sScaleAttr:
                cmds.connectAttr(sScaleAttr, '%s.s' % sLocs[i])

    if sParent != None:
        cmds.parent(sLocs, sParent)
    return sLocs



# depricated!!! use constraints.parallelTransformAsDeformers() instead
def blendShapeSkinClusterToPositions(sMesh, iIds, sBlendShape=None, bDoSkinCluster=False, fInfluenceWeightLimit=0.01, fTargetMinimumDistance=0.001, sParent=None,
                                     sSkinClusters=[], funcConvertPlugName=None, sScaleJoint=None, ssIgnoreTargets=[], bConnectEnvelopes=True):
    import kangarooTools.patch as patch
    import kangarooTools.nodes as nodes
    import kangarooTools.xforms as xforms

    for sSkinCluster in sSkinClusters:
        if not cmds.objExists(sSkinCluster) or cmds.objectType(sSkinCluster) != 'skinCluster':
            raise Exception('SkinCluster %s doesn\'t exist' % sSkinCluster)

    if sBlendShape == None:
        sBlendShapes = listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]

    sConnections = []
    aIds = np.array(iIds, dtype=int)
    aUniqueIds = np.unique(np.array(iIds, dtype=int))
    aIdsOrder = utils.findOneArrayInAnother(aUniqueIds, iIds)
    if -1 in aIdsOrder:
        raise Exception('there are issues with iIds array: %s' % str(iIds))


    sScaleAttr = None
    if sScaleJoint:
        sScaleAttr = nodes.getScaleFromXform(sScaleJoint)

    pMesh = patch.patchFromName(sMesh)
    pMesh.aIds = aUniqueIds
    aDefaultPoints = pMesh.getAllPoints()[aIds]

    sBlendShapeResults = []
    if not sBlendShape:
        for i, iInd in enumerate(aIdsOrder):
            sBlendShapeResults.append(list(aDefaultPoints[i]))
    else:
        dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        sTargets = list(dTargets.keys())

        sAttrs = ['%s.%s' % (sBlendShape,sT) for sT in sTargets]
        for t,sT in enumerate(sTargets):
            sConns = cmds.listConnections(sAttrs[t], s=True, d=False, p=True)
            if not sConns:
                sConnections.append(sAttrs[t])
            else:
                sDriver = sConns[0]
                sConnections.append(sDriver)
                cmds.disconnectAttr(sDriver, sAttrs[t])
            cmds.setAttr(sAttrs[t], 0)

        dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

        aTargetPoints = []
        dInbetweenPoints = {}
        for t, sT in enumerate(sTargets):
            cmds.setAttr(sAttrs[t], 1.0)
            aTargetPoints.append(pMesh.getAllPoints()[aIds])

            fInbetweens = getInbetweens(sBlendShape, iTargetIndex=dTargets[sT])
            dInbetweenPoints[sT] = []
            for fWeight in fInbetweens:
                cmds.setAttr(sAttrs[t], fWeight)
                dInbetweenPoints[sT].append([fWeight, pMesh.getPoints()])

            cmds.setAttr(sAttrs[t], 0.0)


        for i, iInd in enumerate(aIdsOrder):
            iId = aUniqueIds[iInd]
            sMultipls = [aDefaultPoints[i]]
            for t, sT in enumerate(sTargets):
                bIgnoreThisTarget = False
                if i < len(ssIgnoreTargets):
                    for sIgnoreT in ssIgnoreTargets[i]:
                        sIgnoreT = sIgnoreT.split('.')[-1]
                        if sT == sIgnoreT:
                            bIgnoreThisTarget = True
                            break
                if bIgnoreThisTarget:
                    continue

                aVector = aTargetPoints[t][i]-aDefaultPoints[i]
                if np.linalg.norm(aVector) >= fTargetMinimumDistance:
                    if not dInbetweenPoints[sT]:
                        sMultipls.append(nodes.createVectorMultiplyNode(aVector, sConnections[t], bVectorByScalar=True,
                                         sName='generatePosition_%s_%s_vtx%d' % (sMesh,sT,iId)))
                    else:
                        fWeights = []
                        fTargets = []
                        for fW, aTargets in dInbetweenPoints[sT]:
                            fWeights.append(fW)
                            fTargets.append(aTargets[i]-aDefaultPoints[i])
                        fWeights = [0.0] + fWeights + [1.0]
                        fTargets = [[0.0, 0.0, 0.0]] + [list(fT) for fT in fTargets] + [list(aVector)]
                        sDrivenKeys = [nodes.setDrivenKey(sConnections[t], fWeights, None, [fT[a] for fT in fTargets],
                                                          sInTanType='linear', sOutTanType='linear') for a in [0,1,2]]
                        sMultipls.append(sDrivenKeys)


            sSum = nodes.createVectorAdditionNode(sMultipls, sName='generatePosition_%s_vtx%d' % (sMesh,iId))
            if bConnectEnvelopes:
                sBlendShapeResults.append(nodes.createBlendNode('%s.envelope' % sBlendShape, sSum, aDefaultPoints[i], bVector=True,
                                                                sName='generatePosition_%s_vtx%d' % (sMesh,iId)))
            else:
                sBlendShapeResults.append(sSum)

        # connect them back
        for t, sT in enumerate(sTargets):
            if sConnections[t] != sAttrs[t]:
                nodes._connectOrSet(sConnections[t], sAttrs[t])


    sLocs = []
    for l in aIdsOrder:
        sLocatorName = utils.getUniqueName('loc_%sPosition_%03d' % (sMesh, aIds[aIdsOrder[l]]))
        sLocs.append(cmds.spaceLocator(n=sLocatorName)[0])


    if not bDoSkinCluster:
        for i, iInd in enumerate(aIdsOrder):
            nodes._connectOrSetVector(sBlendShapeResults[i], '%s.t' % sLocs[i])

    else: #bDoSkinCluster:
        sSkinClusterResults = [nodes.createComposeMatrixNode(sBlendShapeResults[i], sName='generatePosition_%s_vtx%d' % (sMesh,aUniqueIds[iInd]))
                               for i, iInd in enumerate(aIdsOrder)]

        if not sSkinClusters:
            sSkinClusters = [None]

        for sSkinCluster in sSkinClusters:

            sGotSkinCluster, sInfluences, aWeights2d = pMesh.getSkinCluster(sChooseSkinCluster=sSkinCluster)
            if sGotSkinCluster == None:
                raise Exception('skinCluster %s is not on %s' % (sSkinCluster, sMesh))

            aInfluences = np.array(sInfluences)
            for i, iInd in enumerate(aIdsOrder):
                iId = aUniqueIds[iInd]
                aIdWeights = aWeights2d[iInd]
                aNonZero = np.where(aIdWeights > fInfluenceWeightLimit)[0]
                aInfs = aInfluences[aNonZero]
                aWeights = aIdWeights[aNonZero]
                aWeights /= np.sum(aWeights)

                sMultipls = []
                sMatrix = str(sSkinClusterResults[i])
                for sInf in aInfs:
                    sConns = cmds.listConnections('%s.worldMatrix' % sInf, t='skinCluster', p=True) or []
                    sPlugs = [sC for sC in sConns if sC.split('.')[0] == sGotSkinCluster]
                    sPlug = sPlugs[0]
                    iPlugIndex = int(sPlug.split('[')[-1].split(']')[0])
                    sBindPreMatrixAttr = '%s.bindPreMatrix[%d]' % (sGotSkinCluster, iPlugIndex)
                    sInverseMatrix = cmds.listConnections(sBindPreMatrixAttr, s=True, d=False, p=True)
                    if sInverseMatrix:
                        sInverseMatrix = sInverseMatrix[0]
                        if funcConvertPlugName:
                            sInverseMatrix = funcConvertPlugName(sInverseMatrix)
                            if not cmds.objExists(sInverseMatrix):
                                raise Exception('inverse matrix %s doesn\'t exist' % sInverseMatrix)
                    else:
                        sInverseMatrix = cmds.getAttr(sBindPreMatrixAttr)

                    sInfMatrix = '%s.worldMatrix' % sInf
                    if funcConvertPlugName:
                        sNewInfMatrix = funcConvertPlugName(sInfMatrix)
                        if not cmds.objExists(sNewInfMatrix):
                            raise Exception('joint matrix %s doesn\'t exist (taken from %s)' % (sNewInfMatrix, sInfMatrix))
                        sInfMatrix = sNewInfMatrix

                    sMultipls.append(nodes.createMultMatrixNode([sMatrix,
                                                                 sInverseMatrix,
                                                                 sInfMatrix],
                                     sName='generatePosition_%s_multiplyOffset_to_%s_vtx%d' % (sMesh, sInfMatrix.split('.')[0], iId)))

                sSkinClusterResults[i] = nodes.createBlendMatrixNode(sMultipls, aWeights, sName='generatePosition_%s_vtx%d' % (sMesh, iId))

        for i, iInd in enumerate(aIdsOrder):
            nodes.createDecomposeMatrix(sSkinClusterResults[i], sTargetPos='%s.t' % sLocs[i],
                                                                sTargetRot='%s.r' % sLocs[i], sName='generatePosition_%s_vtx%d' % (sMesh, iId))
            if sScaleAttr:
                cmds.connectAttr(sScaleAttr, '%s.s' % sLocs[i])

    if sParent != None:
        cmds.parent(sLocs, sParent)
    return sLocs



def exportMapToImage(sMesh, sDeformer, sFile):
    '''
    sFile = C:/Users/thoma/OneDrive/Dokumente/maya/projects/default/sourceimages/test2.jpg
    '''

    cmds.select(sMesh)
    try:
        mel.eval('artAttrCtx artAttrCtx1')
    except: pass

    mel.eval('setToolTo artAttrCtx1')

    sType = cmds.objectType(sDeformer)

    mel.eval('artSetToolAndSelectAttr("artAttrCtx", "%s.%s.weights")' % (sType, sDeformer))
    mel.eval('artExportFileTypeValue "JPEG" artAttrCtx')
    mel.eval('artAttrCtx -e -exportfilesave "%s" `currentCtx` ' % sFile)


#
# not done yet!!
#
def importMapToDeformer(sMesh, sDeformer, sFile):
    '''
    sFile = C:/Users/thoma/OneDrive/Dokumente/maya/projects/default/sourceimages/test2.jpg
    '''

    cmds.select(sMesh)
    try:
        mel.eval('artAttrCtx artAttrCtx1')
    except: pass

    mel.eval('setToolTo artAttrCtx1')

    sType = cmds.objectType(sDeformer)

    mel.eval('artSetToolAndSelectAttr("artAttrCtx", "%s.%s.weights")' % (sType, sDeformer))
    mel.eval('artExportFileTypeValue "JPEG" artAttrCtx')

    mel.eval('artAttrCtx -e -importfileload "%s" `currentCtx`' % sFile)



def optimizeMemberShips(sGeo, sDeformer):
    iCount = cmds.polyEvaluate(sGeo, vertex=True)

    aMap = np.array(cmds.getAttr('%s.weightList[0].weights[0:%d]' % (sDeformer, iCount-1)), dtype='float64')
    iZeroInds = np.where(aMap < 0.0001)[0]
    sSet = '%sSet' % sDeformer
    sVerts = ['%s.vtx[%s]' % (sGeo, sStr) for sStr in utils.createMayaStringFromList(iZeroInds)]
    cmds.sets(sVerts, remove=sSet)


def connectJointReferencesFromAttr(sJoints, sSkinClusterFilter=[], sPostRefJointAttrPrefix=''):
    for sJ in utils.toList(sJoints):
        sRefAttr = '%s.%s%s' % (sJ, kPostRefJointAttr, sPostRefJointAttrPrefix)
        sRefMatrix = cmds.getAttr(sRefAttr)

        if '.' not in sRefMatrix:
            sRefMatrix = '%s.worldInverseMatrix' % sRefMatrix

        if not cmds.objExists(sRefMatrix):
            cmds.warning('Reference joint %s doesn\'t exist' % sRefMatrix)
            continue

        sConns = cmds.listConnections('%s.worldMatrix' % sJ, s=False, d=True, p=True, t='skinCluster') or []
        for sPlug in sConns:
            if sSkinClusterFilter:
                sSkinCluster = sPlug.split('.')[0]
                if sSkinCluster not in sSkinClusterFilter:
                    continue

            sSkinClustlerAttr, iIndex = utils.indexFromName(sPlug, bAlsoReturnPrefix=True)
            cmds.connectAttr(sRefMatrix, '%s.bindPreMatrix[%d]' % (sPlug.split('.')[0], iIndex), force=True)


def resetJointReferences(sJoints, sSkinClusterFilter=[]):
    for sJ in utils.toList(sJoints):
        sPlugs = cmds.listConnections('%s.worldMatrix' % sJ, s=False, d=True, p=True, t='skinCluster') or []
        for sPlug in sPlugs:
            if sSkinClusterFilter:
                sSkinCluster = sPlug.split('.')[0]
                if sSkinCluster not in sSkinClusterFilter:
                    continue

            sSkinClustlerAttr, iIndex = utils.indexFromName(sPlug, bAlsoReturnPrefix=True)
            sInverseMatrix = cmds.getAttr('%s.worldInverseMatrix' % sJ)
            cmds.setAttr('%s.bindPreMatrix[%d]' % (sPlug.split('.')[0], iIndex), sInverseMatrix, type='matrix')


def resetJointReferencesSkinCluster(sSkinCluster):
    sJoints = cmds.skinCluster(sSkinCluster, q=True, wi=True)

    for sJ in utils.toList(sJoints):
        sPlugs = cmds.listConnections('%s.worldMatrix' % sJ, s=False, d=True, p=True, t='skinCluster') or []
        sPlugs = [sP for sP in sPlugs if sP.startswith(sSkinCluster)]
        for sPlug in sPlugs:
            sSkinClustlerAttr, iIndex = utils.indexFromName(sPlug, bAlsoReturnPrefix=True)
            sInverseMatrix = cmds.getAttr('%s.worldInverseMatrix' % sJ)
            cmds.setAttr('%s.bindPreMatrix[%d]' % (sPlug.split('.')[0], iIndex), sInverseMatrix, type='matrix')


# depricated!! we should not use the _ref post fix anymore. use connectJointReferencesFromAttr instead
def connectJointReferences(sJoints, sPostfix='_ref'):
    for sJ in sJoints:
        sRefJ = '%s%s' % (sJ, sPostfix)
        if not cmds.objExists(sRefJ):
            cmds.warning('Reference joint %s doesn\'t exist' % sRefJ)
            continue

        sConns = cmds.listConnections('%s.worldMatrix' % sJ, s=False, d=True, p=True, t='skinCluster')
        if sConns:
            sPlug = sConns[0]
            sSkinClustlerAttr, iIndex = utils.indexFromName(sPlug, bAlsoReturnPrefix=True)
            cmds.connectAttr('%s.worldInverseMatrix' % sRefJ, '%s.bindPreMatrix[%d]' % (sPlug.split('.')[0], iIndex))



def connectAllJointReferencesFromSkinClusters(sSkinClusters, sPostfix='_ref'):
    # connect ref joints
    for sSkinCluster in sSkinClusters: #in cmds.ls('*__POSThandles', '*__ZIPPER', 'skinCluster__Hoodie_low__EXTRA*', 'mesh_copyHoodieSkinCluster', et='skinCluster'):
        sConns = cmds.listConnections('%s.matrix' % sSkinCluster, s=True, d=False, c=True, p=True)
        for i in range(0, len(sConns), 2):
            sPlug, sMatrix = sConns[i], sConns[i + 1]
            sRefJoint = '%s%s' % (sMatrix.split('.')[0], sPostfix)
            if cmds.objExists(sRefJoint):
                iIndex = utils.indexFromName(sPlug)
                cmds.connectAttr('%s.worldInverseMatrix' % sRefJoint, '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex))


def bakeBlendShapesSelection():
    sBs = cmds.ls(sl=True, et='blendShape')[0]
    sMesh = cmds.ls(sl=True, et='transform')[0]
    print('sMesh: ', sMesh)
    print('sBlendShape: ', sBs)
    sTargets = bakeBlendShapes(sMesh, sBlendShape=sBs)

    sShapes = cmds.deformer(sBs, q=True, g=True)

    sAllTransforms = [cmds.listRelatives(sS, p=True, f=True)[0] for sS in sShapes]

    for sTransform in sAllTransforms:
        if sTransform.split('|')[-1] == sMesh.split('|')[-1]:
            continue
        # print('sTransform: ', sTransform)
        sTargets += bakeBlendShapes(sTransform, sBlendShape=sBs, sPrefix='%s__' % sTransform.split('|')[-1], bIgnoreUnChanged=True)

    cmds.select(sTargets)



# depricated!!! use blendShapes.getTargetsDictFromBlendShape instead
def bakeBlendShapes(sMesh=None, sBlendShape=None, bReturnTargetAliases=False, sPrefix='', bIgnoreUnChanged=False):
    dDict = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    sResult = []
    dPrevious = {}

    dCombinationShapes = {}

    if bIgnoreUnChanged:
        aDefaultPoints = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True)).reshape(-1, 3)

    for sTarget in list(dDict.keys()):
        sAttr = '%s.%s' % (sBlendShape, sTarget)
        sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)

        if sConns:
            sNode = sConns[0].split('.')[0]
            if cmds.objectType(sNode) == 'combinationShape':
                dCombinationShapes[sAttr] = cmds.listConnections(sNode, s=True, d=False, p=True)
            else:
                cmds.disconnectAttr(sConns[0], sAttr)
                dPrevious[sAttr] = sConns[0]
                cmds.setAttr(sAttr, 0)
        else:
            dPrevious[sAttr] = cmds.getAttr(sAttr)
            cmds.setAttr(sAttr, 0)


    for sTarget in list(dDict.keys()):
        sAttr = '%s.%s' % (sBlendShape, sTarget)
        if sAttr in dCombinationShapes:
            for sA in dCombinationShapes[sAttr]:
                cmds.setAttr(sA, 1.0)
        else:
            cmds.setAttr(sAttr, 1.0)

        if bIgnoreUnChanged:
            aTargetPoints = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True)).reshape(-1,3)
            aDiff = aTargetPoints - aDefaultPoints
            aLengths = np.linalg.norm(aDiff, axis=-1)
            if not len(np.where(aLengths > 0.001)[0]):
                continue

        sTargetName = '%s%s' % (sPrefix, sTarget)
        sDupl = cmds.duplicate(sMesh, n=sTargetName)[0]
        if sDupl.split('|')[-1] != sTargetName:
            sDupl = cmds.rename(sDupl, sTargetName)
            print('sDupl: ', sDupl)
        sResult.append(sDupl)

        if sAttr in dCombinationShapes:
            for sA in dCombinationShapes[sAttr]:
                cmds.setAttr(sA, 0.0)
        else:
            cmds.setAttr(sAttr, 0.0)



    for sAttr, xValue in list(dPrevious.items()):
        if utils.isStringOrUnicode(xValue):
            cmds.connectAttr(xValue, sAttr)
        else:
            cmds.setAttr(sAttr, xValue)

    if bReturnTargetAliases:
        return sResult, list(dDict.keys())
    else:
        return sResult



def makeNotExport(sDeformers):
    for sDeformer in utils.toList(sDeformers):
        if not cmds.attributeQuery('noExport', node=sDeformer, exists=True):
            cmds.addAttr(sDeformer, ln='noExport', at='bool', defaultValue=True, k=True)


def makeBlendShapesNoExport(sMeshes):
    for sMesh in utils.toList(sMeshes):
        sBlendShapes = listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        for sBlendShape in sBlendShapes:
            makeNotExport(sBlendShape)



def getDeformerSuffix(sDeformer):
    sSplits = sDeformer.split('__')
    if len(sSplits) >= 3:
        return sSplits[2]
    else:
        return ''



# for t, sT in enumerate(sTargets):
#     sConns = cmds.listConnections(sAttrs[t], s=True, d=False, p=True)
#     if not sConns:
#         sConnections.append(sAttrs[t])
#     else:
#         sDriver = sConns[0]
#         sConnections.append(sDriver)
#         cmds.disconnectAttr(sDriver, sAttrs[t])
#     cmds.setAttr(sAttrs[t], 0)
