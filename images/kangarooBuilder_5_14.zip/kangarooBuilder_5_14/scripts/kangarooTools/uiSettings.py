###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import inspect
from collections import OrderedDict
import kangarooTools.controls as controls
import kangarooTools.utilFunctions as utils




def addToUI(sTab=None, sModuleButton=None, sRunButton='Run', bReloadBeforeRun=True, dControls = {}, sTabControls = [],
            sTopControls = [], tRefreshControlsAfterRun=[], bAddDefaultButton=None, bDisableOnServer=False, bCheckAsset=False, sToolTip=None, sDocumentationLink=None):
    def addToUI_inside(func):
        def _uiFunction_(*args, **kwargs):
            return func(*args, **kwargs)
        
        _uiFunction_.bAddToUI = True
        
        args, _, _, defaults = inspect.getfullargspec(func)[0:4]
        _uiFunction_.args = []
        _uiFunction_.defaults = []
        _uiFunction_._args = []
        for i, arg in enumerate(args):
            if arg.startswith('_'):
                _uiFunction_._args.append(arg)
            else:
                _uiFunction_.args.append(arg)
                _uiFunction_.defaults.append(defaults[i])

        _uiFunction_.bPassApplyButton = '_qApplyButton' in args
        _uiFunction_.sFuncName = func.__name__
        _uiFunction_.sTab = sTab
        _uiFunction_.sModuleButton = sModuleButton if sModuleButton else _uiFunction_.sFuncName
        _uiFunction_.sRunButton = sRunButton if sRunButton else 'Run'
        _uiFunction_.dControls = dict(dControls)
        _uiFunction_.bReloadBeforeRun=bReloadBeforeRun
        _uiFunction_.sDoc = func.__doc__
        _uiFunction_.bIntoTabLayout = False #bIntoTabLayout
        _uiFunction_.tRefreshControlsAfterRun = list(tRefreshControlsAfterRun)
        _uiFunction_.sTabControls = list(sTabControls)
        _uiFunction_.sTopControls = list(sTopControls)
        _uiFunction_.bAddDefaultButton = bAddDefaultButton
        _uiFunction_.bDisableOnServer = bDisableOnServer
        _uiFunction_.bCheckAsset = bCheckAsset
        _uiFunction_.sToolTip = sToolTip
        _uiFunction_.sDocumentationLink = sDocumentationLink
        return _uiFunction_
    
    return addToUI_inside




class Settings(object):
    def __init__(self, funcRuns=None, sModuleNameForDebug=None):
        self.dDefaultValues = OrderedDict()
        self.dControls = {}
        self.dIntoSecondLayout = None
        self.sModuleNameForDebug = sModuleNameForDebug
        if funcRuns != None:
            self.dIntoSecondLayout = {}
            for funcRun in funcRuns:
                for arg, xValue in zip(funcRun.args,funcRun.defaults):
                    self.dDefaultValues[arg] = xValue
                    self.dIntoSecondLayout[arg] = funcRun.bIntoTabLayout
                if hasattr(funcRun, 'dControls'):
                    self.dControls.update(funcRun.dControls)


    def buildControls(self, qtLayout, qtSecondLayout=None, qThirdLayout=None, qtWindow=None, sTabControls=[], sTopControls=[], dApplyButtons={}):

        for sAttr, xValue in list(self.dDefaultValues.items()):
            #print '\n\nBUILDING CONTROL (%s): ' % self.sModuleNameForDebug, sAttr
            try:
                self.dControls[sAttr] = qtSecondLayout.dControlList[sAttr]
                continue
            except:
                pass

            try:
                self.dControls[sAttr] = qThirdLayout.dControlList[sAttr]
                continue
            except:
                pass


            if sAttr not in list(self.dControls.keys()):
                if type(xValue) == bool:
                    self.dControls[sAttr] = controls.BoolControl()
                elif type(xValue) == int or type(xValue) == float:
                    self.dControls[sAttr] = controls.SliderControl([0,xValue*2 if type(xValue) == int else 1.0])
                elif isinstance(xValue, list):
                    self.dControls[sAttr] = controls.SelectionControl(bList=True)
                elif isinstance(xValue, dict):
                    self.dControls[sAttr] = controls.DictionaryControl()
                elif utils.isStringOrUnicode(xValue) :
                    self.dControls[sAttr] = controls.SelectionControl(bList=False)
                else:
                    cmds.warning('there is no control type for attribute type %s (%s) ' % (type(xValue), sAttr))
                    continue

            if sAttr in sTabControls:
                if sAttr not in list(qtSecondLayout.dControlList.keys()):
                    self.dControls[sAttr].build(qtSecondLayout, sAttr, xValue, qtWindow=qtWindow)
                    qtSecondLayout.dControlList[sAttr] = self.dControls[sAttr]
                else:
                    self.dControls[sAttr] = qtSecondLayout.dControlList[sAttr]

            elif sAttr in sTopControls:
                if sAttr not in list(qThirdLayout.dControlList.keys()):
                    self.dControls[sAttr].build(qThirdLayout, sAttr, xValue, qtWindow=qtWindow)
                    qThirdLayout.dControlList[sAttr] = self.dControls[sAttr]
                else:
                    self.dControls[sAttr] = qThirdLayout.dControlList[sAttr]

            else:
                self.dControls[sAttr].build(qtLayout, sAttr, xValue, qtWindow=qtWindow)

            self.dControls[sAttr].settings = self
            self.dControls[sAttr].dApplyButtons = dApplyButtons

    def updateDictFromControls(self, dValues):
        for sAttr, tbControl in list(dValues.items()):
            if sAttr in list(self.dControls.keys()):
                xValue = self.dControls[sAttr].getValue()
                dValues[sAttr] = xValue


    def subtractSettings(self, tbOtherSettings):
        for sOtherAttr, sOtherValue in list(tbOtherSettings.dDefaultValues.items()):
            if sOtherAttr in list(self.dDefaultValues.keys()):
                del self.dDefaultValues[sOtherAttr]



