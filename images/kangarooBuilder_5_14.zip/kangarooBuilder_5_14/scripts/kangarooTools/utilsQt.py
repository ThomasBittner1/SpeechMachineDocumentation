###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.settings as settings


if cmds.about(v=True) >= '2025':
    from PySide6 import QtWidgets, QtGui, QtCore
    from shiboken6 import wrapInstance

else:
    from PySide2 import QtWidgets, QtGui, QtCore
    from shiboken2 import wrapInstance


import maya.OpenMayaUI as OpenMayaUI

import platform

if platform.system() == 'Windows':
    from ctypes import windll

import kangarooTools.utilFunctions as utils


def getMayaWindow():
    ptr = OpenMayaUI.MQtUtil.mainWindow()
    return wrapInstance(int(ptr), QtWidgets.QWidget)



def makeWidgetFromLayout(qLayout, parent=None):
    qW = QtWidgets.QFrame(parent)
    qW.setLayout(qLayout)
    return qW



class QNoWheelComboBox(QtWidgets.QComboBox):
    def __init__(self, parent=None):
        QtWidgets.QComboBox.__init__(self, parent=parent)
        self.parent = parent

    def wheelEvent(self, *args, **kwargs):
        return self.parent.wheelEvent(*args, **kwargs)


class QGetStringDialog(QtWidgets.QDialog):

    def __init__(self, funcCallback, sMessage, sDefault=None, parent=None, bLine=True):
        super(QGetStringDialog, self).__init__(parent=parent)#, QtCore.Qt.WindowStaysOnTopHint)


        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qMessage = QtWidgets.QLabel(sMessage)


        self.qMessage.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

        self.bLine = bLine
        if self.bLine:
            self.qComments = QtWidgets.QLineEdit()
        else:
            self.qComments = QtWidgets.QTextBrowser()
            self.qComments.setReadOnly(False)

        layout.addWidget(self.qMessage)
        layout.addWidget(self.qComments)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        self.qComments.returnPressed.connect(self.okClicked)

        layout.addWidget(qOkButton)

        self.funcCallback = funcCallback
        if sDefault != None:
            if self.bLine:
                self.qComments.setText(str(sDefault))
            else:
                self.qComments.append(str(sDefault))


    def okClicked(self):
        if self.bLine:
            sComments = self.qComments.text()
        else:
            sComments = self.qComments.toPlainText()
        self.close()
        self.funcCallback(sComments)



class QSkinDialog(QtWidgets.QDialog):

    def __init__(self, funcCallback, parent=None):
        super(QSkinDialog, self).__init__(parent=parent)


        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qPostCheckBox = QtWidgets.QCheckBox('Post')
        self.qSuffix = QtWidgets.QLineEdit('TWEAKER')

        layout.addWidget(self.qPostCheckBox)
        layout.addWidget(self.qSuffix)

        qOkButton = QtWidgets.QPushButton('Skin')
        qOkButton.clicked.connect(self.okClicked)
        self.qSuffix.returnPressed.connect(self.okClicked)

        layout.addWidget(qOkButton)

        def _changePost(bChecked):
            self.qSuffix.setDisabled(not bChecked)

        self.qPostCheckBox.stateChanged.connect(_changePost)

        self.qPostCheckBox.setCheckState(QtCore.Qt.Unchecked)
        _changePost(False)
        self.funcCallback = funcCallback


    def okClicked(self):
        sSuffix = self.qSuffix.text()
        bPost = self.qPostCheckBox.isChecked()
        self.close()
        self.funcCallback(bPost, sSuffix)


# DEPRICATED! instead of getting dpi, we should always just grab the default size from the current widgets and factor those
# This function used to really grab the dpi through some messy functions, but it started causeing issues when porting
# to linux and mac
pix_per_inch = None
def getDpi():
    '''
    This function returns an estimation of dpi based on default header size
    '''
    global pix_per_inch
    if pix_per_inch == None:
        qTempWidget = QtWidgets.QTableWidget()
        pix_per_inch = round((qTempWidget.verticalHeader().defaultSectionSize()) * 3.2)
    return pix_per_inch


    '''
    global pix_per_inch
    if pix_per_inch == None:

        if platform.system() == 'Windows':
            LOGPIXELSX = 88
            LOGPIXELSY = 90
            user32 = windll.user32
            user32.SetProcessDPIAware()
            dc = user32.GetDC(0)
            pix_per_inch = windll.gdi32.GetDeviceCaps(dc, LOGPIXELSX)
            user32.ReleaseDC(0, dc)
        elif platform.system() == 'Linux':
            pix_per_inch = 96
            # print ('trying to get new pix_per_inch')
            # import subprocess
            # sOutput = subprocess.check_output("xdpyinfo", encoding="utf-8")
            # for sLine in sOutput.splitlines():
            #     if "dots per inch" in sLine:
            #         print(sLine)
            #         sPixPerInch = sLine.rsplit('x')[1].split(' ')[0]
            #         pix_per_inch = int(sPixPerInch) * 2
            #         break

        elif platform.system() == 'Darwin':  # macOS
            # try:
            #     from AppKit import NSScreen
            #     screen = NSScreen.mainScreen()
            #     if screen:
            #         dpi = screen.backingScaleFactor() * 72  # 72 is the base DPI
            #         pix_per_inch = int(dpi)
            #     else:
            #         pix_per_inch = 72  # fallback default
            # except Exception as e:
            #     print("Failed to get macOS DPI:", e)
            #     pix_per_inch = 72  # fallback
            pix_per_inch = 72  # fallback

        else:
            raise Exception('trying to get the dpi, but cannot recognize the platform "%s"' % platform.system())

    return pix_per_inch
    '''


class QFloatValidator(QtGui.QValidator):
    def validate(self, sInput, pos):
        if not sInput:
            return QtGui.QValidator.Intermediate, sInput, pos

        if not self.isValid(sInput):
            return QtGui.QValidator.Invalid, sInput, pos
        try:
            float(sInput)
            return QtGui.QValidator.Acceptable, sInput, pos
        except ValueError:
            return QtGui.QValidator.Intermediate, sInput, pos


    def isValid(self, sInput):
        if sInput.count('.') > 1:
            return False
        if sInput.count('-') > 1 or (sInput.find('-') > 0):
            return False
        for sChar in sInput:
            if not (sChar.isdigit() or sChar in ['.', '-']):
                return False
        return True



def createFloatSlider(qParentLayout, sLabel, fMin, fMax, fDefault):
    qLayout = QtWidgets.QHBoxLayout()
    qParentLayout.addLayout(qLayout)
    qLayout.addWidget(QtWidgets.QLabel('%s  ' % sLabel))

    qLine = QtWidgets.QLineEdit('')
    qLine.setMaximumWidth(100)
    qLayout.addWidget(qLine)
    
    qSlider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
    qSlider.setRange(0, 100)
    qLayout.addWidget(qSlider)

    def sliderAdjusted(iValue):
        fValue = utils.projectToRange(iValue, 0, 100, fMin, fMax)
        qLine.blockSignals(True)
        qLine.setText('%.2f' % fValue)
        qLine.blockSignals(False)
    qSlider.valueChanged.connect(sliderAdjusted)
    
    def lineAdjusted(sText):
        try:
            fValue = eval(sText)
            iValue = utils.projectToRange(fValue, fMin, fMax, 0, 100)
        except:
            iValue = 0
        qSlider.blockSignals(True)
        qSlider.setValue(iValue)
        qSlider.blockSignals(False)
    qLine.textChanged.connect(lineAdjusted)
    
    qLine.setText('%0.2f' % fDefault)
    
    return qLine



def createGroupBoxLayout(qParentLayout, sLabel, bHorizontalLayout=False, iWidgetMaximumWidth=None):
    qBox = QtWidgets.QGroupBox(sLabel)
    if bHorizontalLayout:
        qLayout = QtWidgets.QHBoxLayout()
    else:
        qLayout = QtWidgets.QVBoxLayout()
    qBox.setLayout(qLayout)
    if not utils.isNone(qParentLayout):
        qParentLayout.addWidget(qBox)
    if iWidgetMaximumWidth:
        qBox.setMaximumWidth(iWidgetMaximumWidth)
    return qLayout



def clearLayout(qLayout, bRemoveLayout=False):
    if qLayout is not None:
        while qLayout.count():
            item = qLayout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            else:
                clearLayout(item.layout())
        if bRemoveLayout:
            qLayout.deleteLater()


class QFilter(QtWidgets.QWidget):
    changed = QtCore.Signal(object)

    def __init__(self, iLockdWidth=None):
        QtWidgets.QWidget.__init__(self)
        qLayout = QtWidgets.QHBoxLayout()
        qLayout.setSpacing(0)
        qLayout.setContentsMargins(0, 0, 0, 0)
        self.qLine = QtWidgets.QLineEdit()
        qButton = QtWidgets.QPushButton('clear')
        qLayout.addWidget(self.qLine)
        qLayout.addWidget(qButton)
        if iLockdWidth:
            self.qLine.setMaximumWidth(iLockdWidth - 100)
            self.qLine.setMinimumWidth(iLockdWidth - 100)

        qButton.setMaximumWidth(100)
        qButton.setMaximumHeight(30)
        if iLockdWidth:
            self.qLine.setSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)

        self.setLayout(qLayout)
        # qLayout.setSizeConstraint(QtWidgets.QLayout.SizeConstraint.SetMaximumSize)
        self.qLine.textChanged.connect(self.changedEmit)
        self.qLine.returnPressed.connect(self.changedEmit)
        qButton.clicked.connect(lambda: self.qLine.setText(''))


    def getFilter(self):
        return self.qLine.text().strip().split(' ')

    def changedEmit(self, _=None):
        sTextFromLine = self.qLine.text()
        self.changed.emit(sTextFromLine.strip().split(' '))

    def clearFilter(self, bBlockSignals=False):
        if bBlockSignals:
            self.qLine.blockSignals(True)

        self.qLine.setText('')

        if bBlockSignals:
            self.qLine.blockSignals(False)


class QFadingText(QtWidgets.QDialog):
    def __init__(self, sMessage, parent=None):
        super(QFadingText, self).__init__(parent, QtCore.Qt.WindowStaysOnTopHint)
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)

        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qMessage = QtWidgets.QLabel(sMessage)
        layout.addWidget(self.qMessage)

qFadingTextWindow = None
def showFadingText(sText, fFullSeconds=1.0, fFadeOutSeconds=1.0):
    global qFadingTextWindow
    qCursor = QtGui.QCursor()
    qFadingTextWindow = QFadingText(sText)
    qFadingTextWindow.show()
    qFadingTextWindow.move(qCursor.pos())

    def _fadeOut():
        qFadingTextWindow.qAnimation = QtCore.QPropertyAnimation(qFadingTextWindow, b"windowOpacity")
        qFadingTextWindow.qAnimation.setDuration(fFadeOutSeconds * 1000.0)
        qFadingTextWindow.qAnimation.setStartValue(1.0)
        qFadingTextWindow.qAnimation.setEndValue(0.0)
        qFadingTextWindow.qAnimation.start()
        qFadingTextWindow.qQuitTimer = QtCore.QTimer.singleShot(fFadeOutSeconds * 1000.0, lambda: qFadingTextWindow.close())

    qFadingTextWindow.qStartFading = QtCore.QTimer.singleShot(fFullSeconds * 1000.0, _fadeOut)





class QGetFloatDialog(QtWidgets.QDialog):

    def __init__(self, funcCallback, sMessage, sDefault=None, parent=None, bLine=True):
        super(QGetFloatDialog, self).__init__(parent=parent)#, QtCore.Qt.WindowStaysOnTopHint)

        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qMessage = QtWidgets.QLabel(sMessage)


        self.qMessage.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

        self.qComments = QtWidgets.QLineEdit()

        layout.addWidget(self.qMessage)
        layout.addWidget(self.qComments)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

        self.funcCallback = funcCallback
        if sDefault != None:
            self.qComments.setText(sDefault)


    def okClicked(self):
        sComments = self.qComments.text()
        fValue = float(sComments)
        self.close()
        self.funcCallback(fValue)




class QGetFloatDialogExec(QtWidgets.QDialog):

    def __init__(self, sMessage, fDefault=None, parent=None):
        super(QGetFloatDialogExec, self).__init__(parent=parent)#, QtCore.Qt.WindowStaysOnTopHint)

        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qMessage = QtWidgets.QLabel(sMessage)


        self.qMessage.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

        self.qComments = QtWidgets.QLineEdit()

        layout.addWidget(self.qMessage)
        layout.addWidget(self.qComments)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

        if fDefault != None:
            self.qComments.setText(str(fDefault))


    def okClicked(self):
        sComments = self.qComments.text()
        self.fValue = float(sComments)
        self.accept()


def getFloatValueFromDialog(sMessage, fDefault, sConfigKey=None):
    import kangarooTools.settings as settings

    dConfig = settings.getSettingsFileDict()
    if not utils.isNone(sConfigKey):
        fDefault = dConfig.get(sConfigKey, fDefault)

    qDialog = QGetFloatDialogExec(sMessage, fDefault)


    qDialog.exec_()

    if not utils.isNone(sConfigKey):
        dConfig[sConfigKey] = qDialog.fValue
    settings.updateConfigFileDict(dConfig)

    return qDialog.fValue



class QStatusWindow(QtWidgets.QDialog):
    def __init__(self, sTitle):
        super().__init__()
        self.setWindowTitle(sTitle)
        self.setFixedSize(500, getDpi() // 4)
        self.setWindowFlags(self.windowFlags() & ~QtCore.Qt.WindowContextHelpButtonHint | QtCore.Qt.WindowStaysOnTopHint)
        self.qProgressBar = QtWidgets.QProgressBar(self)
        self.qProgressBar.setAlignment(QtCore.Qt.AlignCenter)
        pLayout = QtWidgets.QVBoxLayout(self)
        pLayout.setContentsMargins(0,0,0,0)
        pLayout.addWidget(self.qProgressBar, stretch=1)
        self.iCurrent = 0

        self.qProgressBar.setValue(0)
        self._center_on_screen()
        self.show()
        self.qProgressBar.setMaximum(100)
        self.qProgressBar.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        QtWidgets.QApplication.processEvents()


    def setCount(self, iCount):
        if iCount > 0:
            self.qProgressBar.setMaximum(iCount)


    def increment(self):
        self.iCurrent += 1
        self.qProgressBar.setValue(self.iCurrent)
        QtWidgets.QApplication.processEvents()


    def end(self):
        self.close()


    def _center_on_screen(self):
        screen = QtWidgets.QApplication.primaryScreen().availableGeometry()
        size = self.frameGeometry()
        self.move((screen.width() - size.width()) // 2, (screen.height() - size.height()) // 2 - screen.height() // 4)





class QLineEditWithCompleter(QtWidgets.QLineEdit):
    gotFocus = QtCore.Signal() # this is a good signal to use for calling this.qCompleterModel.setStringList(sStrings)

    def __init__(self, parent=None, bMatchContain=False):
        super().__init__(parent)

        pCompleter = QtWidgets.QCompleter()
        self.qCompleterModel = QtCore.QStringListModel()

        self.qCompleterModel.setStringList([])
        pCompleter.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        if bMatchContain:
            pCompleter.setFilterMode(QtCore.Qt.MatchContains)
        pCompleter.setModel(self.qCompleterModel)

        self.setCompleter(pCompleter)


    def focusInEvent(self, event):
        self.gotFocus.emit()


    def event(self, event):
        if event.type() == QtCore.QEvent.Type.KeyPress and event.key() == QtCore.Qt.Key_Tab: # used to be event.KeyPress
            self.keyPressEvent(event)
            return True # Event handled, don't pass to focus system
        else:
            return super().event(event)



    def keyPressEvent(self, event): # the activate signal from the completer is not working stable, so we'll have to do it manually
        if event.key() in [QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter, QtCore.Qt.Key_Tab]:
            qPopup = self.completer().popup()
            qIndex = qPopup.currentIndex()
            if qIndex.isValid():
                sText = qIndex.data()
                self.setText(sText.split(' ')[0])
                self.completer().popup().hide()
                return
        super().keyPressEvent(event)




class FilteredComboBox(QtWidgets.QComboBox):
    def __init__(self, parent=None, sSaveName='noname', bFilterBoxDefault=False):
        super().__init__(parent)

        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.markingMenu)
        self.sSaveName = sSaveName

        bFilterBox = settings.getSettingsFileEntry(self._getFilterBoxKey(), bFilterBoxDefault)
        if bFilterBox:
            self.setFilterBox()


    def setFilterBox(self):
        self.setEditable(True)
        self.completer = QtWidgets.QCompleter([], self)
        self.completer.setCompletionMode(QtWidgets.QCompleter.PopupCompletion)
        self.completer.setFilterMode(QtCore.Qt.MatchContains)
        self.completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.setCompleter(self.completer)
        self.lineEdit().textChanged.connect(self.update_filter)


    def _getFilterBoxKey(self):
        return '%s_filterBox' % self.sSaveName

    def markingMenu(self, vPos):
        if self.isEditable():
            def _func():
                self.setEditable(False)
                settings.updateConfigFileDict({self._getFilterBoxKey():False})

            qMenu = QtWidgets.QMenu()
            qMenu.addAction('Remove Filter Box', _func)
            qMenu.exec_(self.mapToGlobal(vPos))

        else:
            def _func():
                self.setFilterBox()
                settings.updateConfigFileDict({self._getFilterBoxKey(): True})

            qMenu = QtWidgets.QMenu()
            qMenu.addAction('Add Filter Box', _func)
            qMenu.exec_(self.mapToGlobal(vPos))



        return qMenu


    def set_items(self, items: list[str]):
        self.clear()
        self.addItems(items)
        self.completer.setModel(QtCore.QStringListModel(items))


    def update_filter(self, text):
        filtered_items = [self.itemText(i) for i in range(self.count()) if text.lower() in self.itemText(i).lower()]
        self.completer.setModel(QtCore.QStringListModel(filtered_items))



def copyWithProgressBar(sSource, sDest, sLabel='Copy File Tree'):
    import os
    import shutil

    iFileCount = sum(len(files) for _, _, files in os.walk(sSource))

    qStatusWindow = QStatusWindow(sLabel)
    qStatusWindow.setCount(iFileCount)

    try:
        if not os.path.exists(sDest):
            os.makedirs(sDest)
        for root, dirs, files in os.walk(sSource):
            for dir_ in dirs:
                sSourceDir = os.path.join(root, dir_)
                sDestDir = os.path.join(sDest, os.path.relpath(sSourceDir, sSource))
                os.makedirs(sDestDir, exist_ok=True)

            for file_ in files:
                sSource_file = os.path.join(root, file_)
                sDest_file = os.path.join(sDest, os.path.relpath(sSource_file, sSource))
                shutil.copy2(sSource_file, sDest_file)
                qStatusWindow.increment()
                # QApplication.processEvents()
    except:
        raise
    finally:
        qStatusWindow.end()



# Utility to get the QWidget from Maya workspaceControl
def get_qwidget(name):
    ptr = OpenMayaUI.MQtUtil.findControl(name)
    if ptr:
        return wrapInstance(int(ptr), QtWidgets.QWidget)
    return None


def makeActionItalic(qAction):
    qFont = qAction.font()
    qFont.setItalic(True)
    qAction.setFont(qFont)
