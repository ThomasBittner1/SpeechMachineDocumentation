###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import numpy as np
import maya.api.OpenMaya as OpenMaya2
import kangarooTools.nodes as nodes
import kangarooTools.patch as patch




def getParamsFromPoints(sSurface, fPoints, bReturnNumpy=False):
    fnSurface = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sSurface))

    fParams = []
    for fP in fPoints:
        mPoint = OpenMaya2.MPoint(fP)
        _, fU, fV = fnSurface.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        fParams.append([fU,fV])

    if bReturnNumpy:
        return np.array(fParams, dtype='float64')
    else:
        return fParams




def createPointInfoNode(sSurface, fParamU=0.0, fParamV=0.0, sTargetPos=None, sName='noname'):
    sNode = cmds.createNode('pointOnSurfaceInfo', n='pointOnSurfaceInfo_%s' % sName)
    cmds.connectAttr('%s.worldSpace[0]' % sSurface, '%s.inputSurface' % sNode)
    nodes._connectOrSet(fParamU, '%s.parameterU' % sNode)
    nodes._connectOrSet(fParamV, '%s.parameterV' % sNode)
    if sTargetPos:
        cmds.connectAttr('%s.position' % sNode, sTargetPos)

    return sNode, '%s.position' % sNode




def createClosestPointNode(sSurface, xPos, sTargetPos=None, sName='noname'):
    sNode = cmds.createNode('closestPointOnSurface', n='closestPointOnSurface_%s' % sName)
    cmds.connectAttr('%s.worldSpace[0]' % sSurface, '%s.inputSurface' % sNode)
    nodes._connectOrSetVector(xPos, '%s.inPosition' % sNode)

    if sTargetPos:
        cmds.connectAttr('%s.position' % sNode, sTargetPos)

    return sNode, '%s.position' % sNode



def selectAllCvsSelected():
    sSel = cmds.ls(sl=True)
    sCurves = list(set([sS.split('.')[0] for sS in sSel]))
    sCvs = ['%s.cv[*][*]' % sC for sC in sCurves]
    cmds.select(sCvs)


def getMatrixOnSurface(sSurface, fParamU, fParamV, sName='noname', bNegateNormal=False, bNegateU=False, bNegateV=False):
    sLocInfoNode, _ = createPointInfoNode(sSurface, fParamU, fParamV, sName=sName)

    sNormal = ['%s.nnx' % sLocInfoNode, '%s.nny' % sLocInfoNode, '%s.nnz' % sLocInfoNode]
    if bNegateNormal:
        sNegativeNode = nodes.createVectorMultiplyNode(sNormal, -1, bVectorByScalar=True)
        sNormal = ['%sX' % sNegativeNode, '%sY' % sNegativeNode, '%sZ' % sNegativeNode]

    sTangentU = ['%s.nux' % sLocInfoNode, '%s.nuy' % sLocInfoNode, '%s.nuz' % sLocInfoNode]
    if bNegateU:
        sNegativeNode = nodes.createVectorMultiplyNode(sTangentU, -1, bVectorByScalar=True)
        sTangentU = ['%sX' % sNegativeNode, '%sY' % sNegativeNode, '%sZ' % sNegativeNode]

    sTangentV = ['%s.nvx' % sLocInfoNode, '%s.nvy' % sLocInfoNode, '%s.nvz' % sLocInfoNode]
    if bNegateV:
        sNegativeNode = nodes.createVectorMultiplyNode(sTangentV, -1, bVectorByScalar=True)
        sTangentV = ['%sX' % sNegativeNode, '%sY' % sNegativeNode, '%sZ' % sNegativeNode]

    sSurfaceMatrix = nodes.createFourByFourMatrixNode(
        xValueList0=sTangentU,
        xValueList1=sTangentV,
        xValueList2=sNormal,
        xValueList3=['%s.positionX' % sLocInfoNode, '%s.positionY' % sLocInfoNode, '%s.positionZ' % sLocInfoNode], sName=sName)
    return sLocInfoNode, sSurfaceMatrix

