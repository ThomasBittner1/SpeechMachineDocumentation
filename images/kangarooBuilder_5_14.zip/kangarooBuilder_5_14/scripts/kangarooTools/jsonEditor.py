###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt
import kangarooTools.clipboard as clipboard


qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)

_kRowHeight = utilsQt.getDpi() / 4



class JsonTable(QtWidgets.QTableWidget):
    copy = QtCore.Signal()
    paste = QtCore.Signal()
    duplicate = QtCore.Signal()
    rename = QtCore.Signal()

    def keyPressEvent(self, event):
        super().keyPressEvent(event)
        if event.key() == QtCore.Qt.Key_C and (event.modifiers() & QtCore.Qt.ControlModifier):
            self.copy.emit()

        elif event.key() == QtCore.Qt.Key_V and (event.modifiers() & QtCore.Qt.ControlModifier):
            self.paste.emit()

        elif event.key() == QtCore.Qt.Key_D and (event.modifiers() & QtCore.Qt.ControlModifier):
            self.duplicate.emit()

        elif event.key() == QtCore.Qt.Key_R and (event.modifiers() & QtCore.Qt.ControlModifier):
            self.rename.emit()




class QJsonUi(QtWidgets.QDialog):

    def __init__(self, sInput, funcReturn, sTitle='jsonEditor'):
        super(QJsonUi, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)

        self.sInput = sInput
        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qStatusLabel = QtWidgets.QLabel('')
        self.qStatusLabel.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.layout.addWidget(self.qStatusLabel)
        self.setWindowTitle('Kangaroo JSON Editor')
        self.rowLayout = QtWidgets.QHBoxLayout()
        self.rowTableAndLayout = []
        self.layout.addLayout(self.rowLayout)
        self.addColumn(sInput, 0, None)
        self.saveButton = QtWidgets.QPushButton('Save')
        self.saveButton.clicked.connect(self.save)
        self.rowLayout.setAlignment(QtCore.Qt.AlignLeft)
        self.layout.addWidget(self.saveButton)
        self.saveButton.setEnabled(False)
        self.funcReturn = funcReturn
        self.resize(1500, 500)
        self.setWindowTitle('JSON Editor - %s' % sTitle.strip())


    def addColumn(self, sInput, iIndex, qParentItem):

        xxInput = None
        try:
            xxInput = eval(sInput)
        except Exception as e:
            print('not able to eval "%s"' % sInput)
            print(e)
            pass

        if isinstance(xxInput, (dict,list)) and xxInput:

            for i in range(iIndex+1, len(self.rowTableAndLayout), 1):
                _, qTableLayout = self.rowTableAndLayout[i]
                utilsQt.clearLayout(qTableLayout, bRemoveLayout=True)
            self.rowTableAndLayout = self.rowTableAndLayout[:iIndex] # this means iIndex will be the next appended

            qTable = JsonTable()
            qTable.setMaximumWidth(600)
            if isinstance(xxInput, dict):
                dInput = dict(xxInput)
                qTable.bList = False
            else:
                dInput = {a:b for a,b in enumerate(xxInput)}
                qTable.bList = True


            qTable.qParentItem = qParentItem
            qTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
            qTableLayout = QtWidgets.QVBoxLayout()
            qTableLayout.setSpacing(0)

            if not qTable.bList:
                qFilter = utilsQt.QFilter(iLockdWidth=600)
                qTableLayout.addWidget(qFilter)
                def _filterChanged(sFilters, qTable=qTable):
                    for iRow in range(qTable.rowCount()):
                        if not sFilters:
                            qTable.setRowHidden(iRow, False)
                        else:
                            bHidden = True
                            for sFilter in sFilters:
                                if sFilter.upper() in qTable._verticalHeaderLabels[iRow].upper():
                                    bHidden = False
                                    break
                            qTable.setRowHidden(iRow, bHidden)

                qFilter.changed.connect(_filterChanged)

            qTableLayout.addWidget(qTable)
            self.rowLayout.addLayout(qTableLayout)

            self.rowTableAndLayout.append((qTable, qTableLayout))


            if not qTable.bList:
                def _changeSize(_qTable=qTable, bBigger=True):
                    _qTable.blockSignals(True)
                    try:
                        qHeader = qTable.verticalHeader()
                        iCurrentHeaderWidth = qHeader.width()
                        qHeader.setFixedWidth(iCurrentHeaderWidth * 1.2 if bBigger else iCurrentHeaderWidth * 0.8)
                        _qTable.setVerticalHeaderLabels(_qTable._verticalHeaderLabels)
                    except:
                        raise
                    finally:
                        _qTable.blockSignals(False)

                qSizingButtonLayout = QtWidgets.QHBoxLayout()
                qSmallerButton = QtWidgets.QPushButton('<<')
                qSmallerButton.clicked.connect(lambda:_changeSize(bBigger=False))
                qSmallerButton.setMaximumHeight(_kRowHeight * 0.8)
                qSizingButtonLayout.addWidget(qSmallerButton)
                qBiggerButton = QtWidgets.QPushButton('>>')
                qBiggerButton.clicked.connect(lambda:_changeSize(bBigger=True))
                qBiggerButton.setMaximumHeight(_kRowHeight * 0.8)
                qSizingButtonLayout.addWidget(qBiggerButton)
                qSizingButtonLayout.setSpacing(0)
                qTableLayout.addLayout(qSizingButtonLayout)

            if qTable.bList:
                def moveRows(_qTable=qTable, bUp=True):
                    qSelectionModel = _qTable.selectionModel()
                    iSelectedRows = sorted([qR.row() for qR in qSelectionModel.selectedRows() if not _qTable.isRowHidden(qR.row())], reverse=not bUp)
                    if not iSelectedRows:
                        return
                    if (bUp and iSelectedRows[0] == 0) or (not bUp and iSelectedRows[0] == _qTable.rowCount() - 1):
                        return
                    qTable.clearSelection()
                    qTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
                    try:
                        for iRow in iSelectedRows:
                            iToRow = iRow - 1 if bUp else iRow + 1
                            sRow = _qTable.item(iRow, 0).text()
                            sToRow = _qTable.item(iToRow, 0).text()
                            _qTable.item(iRow, 0).setText(sToRow)
                            _qTable.item(iToRow, 0).setText(sRow)
                            qTable.selectRow(iToRow)
                    except:
                        raise
                    finally:
                        qTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)


                qMovingButtonLayout = QtWidgets.QHBoxLayout()
                qMoveUpButton = QtWidgets.QPushButton('up')
                qMoveUpButton.clicked.connect(lambda:moveRows(bUp=True))
                qMoveUpButton.setMaximumHeight(_kRowHeight * 0.8)
                qMovingButtonLayout.addWidget(qMoveUpButton)
                qMoveDownButton = QtWidgets.QPushButton('down')
                qMoveDownButton.clicked.connect(lambda:moveRows(bUp=False))
                qMoveDownButton.setMaximumHeight(_kRowHeight * 0.8)
                qMovingButtonLayout.addWidget(qMoveDownButton)
                qMovingButtonLayout.setSpacing(0)
                qTableLayout.addLayout(qMovingButtonLayout)
                qMoveUpButton.setEnabled(False)
                qMoveDownButton.setEnabled(False)

                def selectionChangedForMoveButtons(_qTable=qTable):
                    qSelectionModel = _qTable.selectionModel()
                    bSomethingSelected = True if qSelectionModel.selectedRows() else False
                    qMoveUpButton.setEnabled(bSomethingSelected)
                    qMoveDownButton.setEnabled(bSomethingSelected)

                qTable.itemSelectionChanged.connect(selectionChangedForMoveButtons)


            qTable.setColumnCount(1)
            qTable.setRowCount(len(dInput))
            qTable.horizontalHeader().setStretchLastSection(True)
            qTable.verticalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.Interactive) # this is not actually working... :-(
            qTable.setHorizontalHeaderLabels(['values'])

            qTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)




            def _copy(_qTable=qTable):
                qSelectionModel = _qTable.selectionModel()
                iRows = [qR.row() for qR in qSelectionModel.selectedRows() if not _qTable.isRowHidden(qR.row())]
                sCopy = []
                for iRow in iRows:
                    sKey = _qTable._verticalHeaderLabels[iRow]
                    sCopy.append((sKey, _qTable.item(iRow,0).text()))

                clipboard.put('jsonEditor.%s' % str(sCopy))


            def _paste(_qTable=qTable, _iIndex=iIndex):
                sClipboard = clipboard.get()
                if not sClipboard.startswith('jsonEditor.'):
                    return
                sClipboard = eval(sClipboard[sClipboard.find('.')+1:])

                sAdditionalKeys = []
                sAdditionalValues = []

                print ('sClipboard: ', sClipboard)
                for sKey, sText in sClipboard:
                    if _qTable.bList:
                        sAdditionalKeys.append(_qTable.rowCount())
                    else:
                        sAdditionalKeys.append(utils.getUniqueNameFromList(sKey, _qTable._verticalHeaderLabels+sAdditionalKeys))

                    sAdditionalValues.append(sText)

                iOldRowCount = _qTable.rowCount()

                _qTable.blockSignals(True)
                try:
                    _qTable.setRowCount(iOldRowCount+len(sAdditionalKeys))
                    _qTable._verticalHeaderLabels += sAdditionalKeys
                    _qTable.setVerticalHeaderLabels([str(sLabel) for sLabel in _qTable._verticalHeaderLabels])
                    for i, sValue in enumerate(sAdditionalValues):
                        qItem = QtWidgets.QTableWidgetItem(sValue)
                        _qTable.setItem(iOldRowCount+i, 0, qItem)

                except:
                    raise
                finally:
                    _qTable.blockSignals(False)

                _qTable.clearSelection()
                qTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
                for iNewRow in range(len(sAdditionalKeys)):
                    _qTable.selectRow(iOldRowCount + iNewRow)
                qTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)


                self.saveButton.setEnabled(True)
                self._itemChanged(_iIndex)


            qTable.copy.connect(_copy)
            qTable.paste.connect(_paste)


            def _removeItems(_qTable=qTable,_iIndex=iIndex, iRows=[]):
                _qTable.blockSignals(True)
                try:
                    for iRow in iRows[::-1]:
                        _qTable.removeRow(iRow)
                        del _qTable.sAttrs[iRow]
                except:
                    raise
                finally:
                    _qTable.blockSignals(False)
                self.saveButton.setEnabled(True)
                self._itemChanged(_iIndex)


            def _duplicateItems(_qTable=qTable,_iIndex=iIndex):
                qSelectionModel = _qTable.selectionModel()
                iRows = [qR.row() for qR in qSelectionModel.selectedRows() if not _qTable.isRowHidden(qR.row())]

                sAdditionalKeys = []
                sAdditionalValues = []

                for iRow in iRows:
                    sKey = _qTable._verticalHeaderLabels[iRow]

                    if _qTable.bList:
                        sAdditionalKeys.append(_qTable.rowCount())
                    else:
                        sAdditionalKeys.append(utils.getUniqueNameFromList(sKey, _qTable._verticalHeaderLabels+sAdditionalKeys))

                    sAdditionalValues.append(_qTable.item(iRow,0).text())

                iOldRowCount = _qTable.rowCount()

                _qTable.blockSignals(True)
                try:
                    _qTable.setRowCount(iOldRowCount+len(sAdditionalKeys))
                    _qTable._verticalHeaderLabels += sAdditionalKeys
                    _qTable.setVerticalHeaderLabels([str(sLabel) for sLabel in _qTable._verticalHeaderLabels])
                    for i, sValue in enumerate(sAdditionalValues):
                        qItem = QtWidgets.QTableWidgetItem(sValue)
                        _qTable.setItem(iOldRowCount+i, 0, qItem)
                except:
                    raise
                finally:
                    _qTable.blockSignals(False)

                _qTable.clearSelection()
                qTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
                for iNewRow in range(len(sAdditionalKeys)):
                    _qTable.selectRow(iOldRowCount + iNewRow)
                qTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

                self.saveButton.setEnabled(True)
                self._itemChanged(_iIndex)

            qTable.duplicate.connect(_duplicateItems)



            def _renameItems(_qTable=qTable, _iIndex=iIndex):
                qSelectionModel = _qTable.selectionModel()
                iRow = [qR.row() for qR in qSelectionModel.selectedRows() if not _qTable.isRowHidden(qR.row())][0]

                def __rename(sInput, __qTable=_qTable, _iRow=iRow):
                    self.saveButton.setEnabled(True)
                    sLabels = _qTable._verticalHeaderLabels
                    sLabels[iRow] = sInput
                    _qTable.setVerticalHeaderLabels(sLabels)
                    self._itemChanged(_iIndex)

                self.qDialog = utilsQt.QGetStringDialog(__rename, sMessage='Enter New Name', parent=self, bLine=True,
                                                        sDefault=_qTable._verticalHeaderLabels[iRow])
                self.qDialog.show()
            qTable.rename.connect(_renameItems)


            def _setFromSelection(_qTable=qTable, _iIndex=iIndex, iRow=None):
                self.saveButton.setEnabled(True)
                qItem = _qTable.item(iRow, 0)
                sSel = cmds.ls(sl=True)
                sSel = [str(sObj) for sObj in sSel]
                qItem.setText(str(sSel))
                self._itemChanged(_iIndex)


            def _select(_qTable=qTable, _iIndex=iIndex, iRow=None):
                qItem = _qTable.item(iRow, 0)
                sText = qItem.text()
                sSelection = eval(sText)
                cmds.select(sSelection)


            def _markingMenu(vPos, _qTable=qTable):
                qMenu = QtWidgets.QMenu()
                qSelectionModel = _qTable.selectionModel()
                iRows = [qR.row() for qR in qSelectionModel.selectedRows() if not _qTable.isRowHidden(qR.row())]

                qRemove = qMenu.addAction('remove', lambda:_removeItems(iRows=iRows))
                qDuplicate = qMenu.addAction('duplicate\t\tCTRL+D', _duplicateItems)
                qCopy = qMenu.addAction('copy \t\tCTRL+C', _copy)
                qPaste = qMenu.addAction('paste \t\tCTRL+P', _paste)

                sClipboard = clipboard.get()
                if not sClipboard or not sClipboard.startswith('jsonEditor.'):
                    qPaste.setEnabled(False)


                if len(iRows) == 0:
                    qRemove.setEnabled(False)
                    qDuplicate.setEnabled(False)
                    qCopy.setEnabled(False)

                if len(iRows) == 1:
                    qMenu.addAction('rename \t\tCTRL+R', _renameItems)
                    qMenu.addAction('set from selection', lambda:_setFromSelection(iRow=iRows[0]))
                    qMenu.addAction('select', lambda:_select(iRow=iRows[0]))

                qMenu.exec_(_qTable.mapToGlobal(vPos))
                return qMenu

            qTable.customContextMenuRequested.connect(_markingMenu)

            qTable.sAttrs = list(dInput.keys())
            qTable.sAttrs.sort()

            qTable._verticalHeaderLabels = qTable.sAttrs

            sLabels = list(qTable.sAttrs)
            if qTable.bList:
                sLabels = [str(i) for i in qTable.sAttrs]
            else:
                for i in range(len(sLabels)):
                    if len(sLabels[i]) > 18:
                        sLabels[i] = '%s...%s' % (sLabels[i][:5], sLabels[i][-10:])
            qTable.setVerticalHeaderLabels(sLabels)

            for a, sAttr in enumerate(qTable.sAttrs):
                xValue = dInput[sAttr]
                qItem = QtWidgets.QTableWidgetItem()

                if utils.isStringOrUnicode(xValue):
                    qItem.setText("'%s'" % xValue)
                else:
                    qItem.setText(str(xValue))
                qTable.setItem(0,a, qItem)
                qTable.setRowHeight(a, _kRowHeight)

            qTable.itemChanged.connect(lambda: self.saveButton.setEnabled(True))

            def _itemSelectionChanged(_iIndex=iIndex):
                self._itemSelectionChanged(_iIndex)
            qTable.itemSelectionChanged.connect(_itemSelectionChanged)

            def _itemChanged(qItem, _iIndex=iIndex):
                sNewText = qItem.text()
                try:
                    eval(sNewText)
                except:
                    qTable.blockSignals(True)
                    qItem.setText("'%s'" % sNewText)
                    qTable.blockSignals(False)

                self._itemChanged(_iIndex)
            qTable.itemChanged.connect(_itemChanged)


    def _getStringFromWidget(self, iIndex):
        qTable, _ = self.rowTableAndLayout[iIndex]

        sValues = [qTable.item(i,0).text() for i in range(qTable.rowCount())]
        if qTable.bList:
            xList = [eval(b) for b in sValues]
            return str(xList)
        else:
            dDict = {a:eval(b) for a,b in zip(qTable._verticalHeaderLabels, sValues)}
            return str(dDict)


    def _itemChanged(self, iIndex):
        sNewStr = self._getStringFromWidget(iIndex)
        qTable, _ = self.rowTableAndLayout[iIndex]
        qParentItem = qTable.qParentItem

        if isinstance(qParentItem, type(None)):
            self.sInput = sNewStr
            self.saveButton.setEnabled(True)
        else:
            qParentItem.setText(sNewStr)



    def _itemSelectionChanged(self, iIndex):
        qTable, _ = self.rowTableAndLayout[iIndex]
        qSelectedItems = qTable.selectedItems()


        for i in range(iIndex+1, len(self.rowTableAndLayout), 1):
            qTable, qTableLayout = self.rowTableAndLayout[i]
            # qTableLayout.setParent(None)
            utilsQt.clearLayout(qTableLayout, bRemoveLayout=True)
            # self.rowTableAndLayout[i].deleteLater()
            # self.rowTableAndLayout[i].setParent(None)
        self.rowTableAndLayout = self.rowTableAndLayout[:iIndex+1]

        if len(qSelectedItems) == 1:
            sText = qSelectedItems[0].text()
            self.addColumn(sText, iIndex+1, qSelectedItems[0])
            qTable, _ = self.rowTableAndLayout[iIndex]
            self.qStatusLabel.setText(str(qTable.sAttrs[qSelectedItems[0].row()]))
        else:
            self.qStatusLabel.setText('')



    def save(self):
        self.funcReturn(self.sInput)
        self.close()

