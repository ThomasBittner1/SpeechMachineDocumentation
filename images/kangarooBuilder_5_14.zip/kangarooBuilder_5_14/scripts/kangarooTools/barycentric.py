###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.cmds as cmds
import numpy as np
import kangarooTools.utilFunctions as utils
import math
import kangarooTools.topology as topology
from functools import reduce



# to fix: cmds.kt_findClosestPoints() for curves is not working if the curves are in local space
def getVertexCoordinates(pFromPatches, pToPatch, bMirror=False, bClosestVertex=False, fProgressBarFunc=None, iiSkipVertOrFaceIds=None, bUvs=False, aOverrideIds=None):

    pFromPatches = utils.toList(pFromPatches)
    iVertCount = pToPatch.getTotalCount()
    aTargetPositionsTotal = pToPatch.getPoints()
    if bMirror:
        aTargetPositionsTotal[:,0] *= -1
    
    aIds = aOverrideIds if not utils.isNone(aOverrideIds) else pToPatch.aIds
    xSourcePositionsTotal = []
    xVertIds, xClosests, xFaceIds, xSourcePositions, xFaceCounts = [], [], [], [], []
    
    aDistances = np.zeros((len(pFromPatches), aIds.size), dtype='float64')

    for s, tbSourcePatch in enumerate(pFromPatches):
        if not bClosestVertex:
            xFaceCounts.append(tbSourcePatch.getTotalFaceCount())
        aSourcePositionsTotal = tbSourcePatch.getAllPoints() # changed from getPoints() - because it caused error when verts where selected in mirror by point
        xSourcePositionsTotal.append(aSourcePositionsTotal)
        
        if isinstance(iiSkipVertOrFaceIds, list) and not utils.isNone(iiSkipVertOrFaceIds[s]):
            sSkipComponents = ' '.join(utils.createMayaStringFromList(iiSkipVertOrFaceIds[s]))
        else:
            if pToPatch.isSameGeo(tbSourcePatch) and not bMirror and aIds.size < iVertCount:
                if bClosestVertex:
                    sSkipComponents = ' '.join(utils.createMayaStringFromList(aIds))
                else:
                    iAllFacesToSkip = topology.getAllVertexFaces(pToPatch.mDagPath, aIds=aIds)
                    iAllFacesToSkip = list(set(reduce(lambda a,b:a+b, iAllFacesToSkip)))
                    iAllFacesToSkip.sort()
                    if iAllFacesToSkip[0] == -1:
                        iAllFacesToSkip = iAllFacesToSkip[1:]
                    sSkipComponents = ' '.join(utils.createMayaStringFromList(iAllFacesToSkip))
            else:
                sSkipComponents = ''

        sTargetShape = pToPatch.getName()
        fClosestArray = cmds.kt_findClosestPoints(fromMesh=sTargetShape, toMesh=tbSourcePatch.getName(),
                                           skip=sSkipComponents, vertex=bClosestVertex, returnFaces=True,
                                           mirror=bMirror, doUvs=bUvs, arv=True, returnDistances=True)

        if not utils.isNone(fProgressBarFunc):# != None:
            fProgressBarFunc()

        if bClosestVertex:
            aClosestArray = np.array(fClosestArray, dtype='float64')
            aClosestArray = aClosestArray.reshape(-1,2)
            aVertIds = np.array(aClosestArray[aIds,0], dtype=int)
            xClosests.append(aSourcePositionsTotal[aVertIds])
            xVertIds.append(aVertIds)
            aDistances[s] = np.array(aClosestArray[aIds,1])
        else:
            aClosestArray = np.array(fClosestArray, dtype='float64')
            aClosestArray = aClosestArray.reshape(-1,5)
            xClosests.append(aClosestArray[aIds,0:3])
            xFaceIds.append(np.array(aClosestArray[aIds,4], dtype=int))
            aDistances[s] = aClosestArray[aIds,3]
                
    aClosestMeshes = np.argmin(aDistances, axis=0)
    if bClosestVertex:
        aClosestIndexAll = np.array(xVertIds, dtype=int).reshape(len(pFromPatches), -1)
        aIndsSelected = aClosestIndexAll[aClosestMeshes, np.arange(aIds.size)]
        return aIndsSelected, None, aClosestMeshes
    
    aFaceVerticesAll = np.zeros(aIds.size * 4, dtype=int).reshape(-1,4)
    aCoordsAll = np.zeros(aIds.size * 4, dtype='float64').reshape(-1,4)

    for s, tbSourcePatch in enumerate(pFromPatches):
        iFaceVertices = tbSourcePatch.getAllFaceVertices()
        aInds = np.array(np.where(aClosestMeshes == s)[0], dtype=int)
        aClosests = xClosests[s][aInds]
        aFaceIds = xFaceIds[s][aInds]

        aUsedFaces = np.unique(aFaceIds)
        iUsedFaces = aUsedFaces.size
        aFaceVertices = np.empty(iUsedFaces*4, dtype=int).reshape(-1,4)
        aFaceVertices.fill(-1)
        aFaceIdMapper = np.zeros(xFaceCounts[s], dtype=int)
        aFaceIdMapper[aUsedFaces] = np.arange(iUsedFaces, dtype=int)
        for i in range(iUsedFaces):
            mFaceVertices = iFaceVertices[aUsedFaces[i]]
            for k in range(min(len(mFaceVertices),4)):
                aFaceVertices[i,k] = mFaceVertices[k]

        # make array that holds all source vertices for each target vertex
        #
        aPositions = xSourcePositionsTotal[s][aFaceVertices]
        idsMapped = aFaceIdMapper[aFaceIds]
        aSourcePositionsMapped = aPositions[idsMapped]
        aFaceVertexCounts = np.where(aFaceVertices[idsMapped,3] == -1, 3, 4)
        aFaceVerticesAll[aInds] = aFaceVertices[idsMapped]
        aCoordsAll[aInds] = getBarycentricCoords(aClosests, aSourcePositionsMapped, aFaceVertexCounts)

    return aFaceVerticesAll, aCoordsAll, aClosestMeshes




def getBarycentricCoords(aClosests, aSourcePositions, aFaceVertexCounts, iSizeLimit=4):
    aCoords = np.zeros(aClosests.shape[0] * iSizeLimit, dtype='float64').reshape(-1,iSizeLimit)
    # quads
    #
    aQuadVerts = np.where(aFaceVertexCounts == 4)[0]
    if aQuadVerts.size:
        aSourcePositionsQuad = aSourcePositions[aQuadVerts]
        
        aEdgeLengths = np.zeros(aSourcePositionsQuad.shape[0]*4, dtype='float64').reshape(-1,4)
        aEdgeDiffs = np.zeros_like(aSourcePositionsQuad)
        aEdgeNorms = np.zeros_like(aSourcePositionsQuad)
        for i in range(4):
            aEdgeDiffs[:,i] = aSourcePositionsQuad[:,(i+1)%4] - aSourcePositionsQuad[:,i]
            aEdgeLengths[:,i] = np.sqrt(np.sum(np.square(aEdgeDiffs[:,i]), axis=-1))
            aEdgeNorms[:,i] = aEdgeDiffs[:,i] / aEdgeLengths[:,i][:,np.newaxis]
        # get the middle points that we need for barycentric coordinates on quads, using closest points on line calculations
        #
        aLengthsToLines = np.zeros(aClosests[aQuadVerts].shape[0] * 4).reshape(-1,4)
        for i in range(4):
            aDiff = aClosests[aQuadVerts] - aSourcePositionsQuad[:,i]
            aDot = np.sum((aEdgeNorms[:,i] * aDiff), axis=-1)
            ts = aDot / aEdgeLengths[:,i]
            ts = ts[:,np.newaxis]
            aVec = aSourcePositionsQuad[:,i] * (1-ts)  + aSourcePositionsQuad[:,(i+1)%4] * (ts)
            aLengthsToLines[:,i] = np.sqrt(np.sum(np.square(aClosests[aQuadVerts] - aVec), axis=1))
    
        aHeightPercs = (aLengthsToLines[:,0] / (aLengthsToLines[:,2] + aLengthsToLines[:,0]))[:,np.newaxis]
        aHeightPercs = np.nan_to_num(aHeightPercs)
        
        
        aWidthPerc = (aLengthsToLines[:,3] / (aLengthsToLines[:,3] + aLengthsToLines[:,1]))[:,np.newaxis]
        aWidthPerc = np.nan_to_num(aWidthPerc)
        aMids = np.zeros(aClosests[aQuadVerts].shape[0] * 4 * 3, dtype='float64').reshape(-1,4,3)
        aMids[:,0] = aSourcePositionsQuad[:,1] * aWidthPerc + aSourcePositionsQuad[:,0] * (1-aWidthPerc)
        aMids[:,2] = aSourcePositionsQuad[:,2] * aWidthPerc + aSourcePositionsQuad[:,3] * (1-aWidthPerc)
        aMids[:,1] = aSourcePositionsQuad[:,2] * aHeightPercs + aSourcePositionsQuad[:,1] * (1-aHeightPercs)
        aMids[:,3] = aSourcePositionsQuad[:,3] * aHeightPercs + aSourcePositionsQuad[:,0] * (1-aHeightPercs)
        
        
        # now calculate the areas using those middle points
        #
        def getQuadAreas(As, Bs, Cs, Ds):
            a = np.sqrt(np.sum(np.square(Bs-As), axis=1))
            b = np.sqrt(np.sum(np.square(Cs-Bs), axis=1))
            c = np.sqrt(np.sum(np.square(As-Cs), axis=1))
            s = (a + b + c) * 0.5
            aAreas = np.sqrt(s*(s-a)*(s-b)*(s-c))
            a = np.sqrt(np.sum(np.square(Ds-As), axis=1))
            b = np.sqrt(np.sum(np.square(Cs-Ds), axis=1))
            s = (a + b + c) * 0.5
            aAreas += np.sqrt(s*(s-a)*(s-b)*(s-c))
            return aAreas
        
        aAreas = np.ones(aClosests[aQuadVerts].shape[0] * 4, dtype='float64').reshape(-1,4)
        aAreas[:,0] = getQuadAreas(aSourcePositionsQuad[:,2], aMids[:,1], aClosests[aQuadVerts], aMids[:,2] )
        aAreas[:,1] = getQuadAreas(aSourcePositionsQuad[:,3], aMids[:,3], aClosests[aQuadVerts], aMids[:,2] )
        aAreas[:,2] = getQuadAreas(aSourcePositionsQuad[:,0], aMids[:,0], aClosests[aQuadVerts], aMids[:,3] )
        aAreas[:,3] = getQuadAreas(aSourcePositionsQuad[:,1], aMids[:,0], aClosests[aQuadVerts], aMids[:,1] )
        
        aAreas = np.nan_to_num(aAreas)
        # and finally the coordinates using the areas
        #
        aTotalAreas = np.sum(aAreas, axis=-1)
        aCoords[aQuadVerts] = aAreas / aTotalAreas[:,np.newaxis]
        aZeroAreas = np.where(aTotalAreas == 0)[0]
        aCoords[aZeroAreas] = np.array([0.25, 0.25, 0.25, 0.25])

    # triangles..
    #
    aTriangledVerts = np.where(aFaceVertexCounts == 3)[0]
    if aTriangledVerts.size:
        def getTriangleAreas(As, Bs, Cs):
            a = np.sqrt(np.sum(np.square(Bs-As), axis=1))
            b = np.sqrt(np.sum(np.square(Cs-Bs), axis=1))
            c = np.sqrt(np.sum(np.square(As-Cs), axis=1))
            s = (a + b + c) * 0.5
            aAreaSquared = s*(s-a)*(s-b)*(s-c)
            aAreaSquared = np.where(aAreaSquared < 0.0000000001, 0.0000000001, aAreaSquared)
            aAreas = np.sqrt(aAreaSquared)
            return aAreas
        aAreas = np.ones(aTriangledVerts.size * 3, dtype='float64').reshape(-1,3)
        aAreas[:,0] = getTriangleAreas(aClosests[aTriangledVerts], aSourcePositions[aTriangledVerts,1], aSourcePositions[aTriangledVerts,2])
        aAreas[:,1] = getTriangleAreas(aClosests[aTriangledVerts], aSourcePositions[aTriangledVerts,0], aSourcePositions[aTriangledVerts,2])
        aAreas[:,2] = getTriangleAreas(aClosests[aTriangledVerts], aSourcePositions[aTriangledVerts,0], aSourcePositions[aTriangledVerts,1])
        aTotalAreas = np.sum(aAreas, axis=-1)
        aCoords[aTriangledVerts,0:3] = aAreas / aTotalAreas[:,np.newaxis]

    # lines..
    #
    aLineVerts = np.where(aFaceVertexCounts == 2)[0]
    if aLineVerts.size:
        aVerts = aSourcePositions[aLineVerts,0:2]
        aRepeated = np.repeat(aClosests[aLineVerts].reshape(-1,1,3), 2, axis=1)
        aDiff = aVerts - aRepeated
        aLengths = np.sqrt(np.sum(np.square(aDiff), axis=-1))
        aLengths /= np.sum(aLengths, axis=-1)[:,np.newaxis]
        aCoords[aLineVerts,0:2] = 1-aLengths
        
    # points..
    #
    aPointVerts = np.where(aFaceVertexCounts == 1)[0]
    if aPointVerts.size:
        aCoords[aPointVerts,0] = 1
    
    return aCoords


def getNormalFrom3Points(xPoints=[], bNorm=True):
    aaPoints = np.array(xPoints, dtype='float64')
    x = aaPoints[1]-aaPoints[0]
    y = aaPoints[2]-aaPoints[0]
    aCross = np.cross(x,y)
    if bNorm:
        aCross /= np.linalg.norm(aCross)
    return aCross


def closestPointOnNormalPlane(xFromPoint, xPlanePoint, fPlaneNormal):
    fFromPoint = _xPointToVectorArray(xFromPoint)
    fPlanePoint = _xPointToVectorArray(xPlanePoint)

    fPlaneNormal = np.array(fPlaneNormal, dtype='float64')
    d = np.sum(fPlanePoint*fPlaneNormal)
    fClosestPoint = fFromPoint + (d - np.sum(fFromPoint*fPlaneNormal))*fPlaneNormal
    
    return fClosestPoint



def closestPointOn3PointPlane(xFromPoint, xPoints=[]):
    fFromPoint = _xPointToVectorArray(xFromPoint)
    fPoints = [_xPointToVectorArray(xP) for xP in xPoints]

    fPlaneNormal = np.cross(fPoints[1]-fPoints[0], fPoints[2]-fPoints[0])
    fPlaneNormal /= np.sum(np.linalg.norm(fPlaneNormal))
    
    d = np.sum(fPlanePoint*fPlaneNormal)
    fClosestPoint = fFromPoint + (d - np.sum(fFromPoint*fPlaneNormal))*fPlaneNormal
    
    return fClosestPoint


def closestPointOnLine(xFromPoint, xPointA, xPointB, bReturnT=False):
    fFromPoint = _xPointToVectorArray(xFromPoint)
    fPointA = _xPointToVectorArray(xPointA)
    fPointB = _xPointToVectorArray(xPointB)

    direction = fPointB - fPointA
    fDistance = np.linalg.norm(direction)
    direction /= fDistance
    fLength = np.sum(direction * (fFromPoint - fPointA))
    if bReturnT:
        if fDistance > 0.00001:
            return fLength / fDistance
        else:
            return 0.0
    else:
        fClosestPoint = fPointA + direction*fLength
        return fClosestPoint


def closestPointsOnLineNumpy(aFromPoints, aPointA, aPointB):
    aDirection = aPointB - aPointA
    aDirection /= np.linalg.norm(aDirection)
    aTs = np.sum(aDirection * (aFromPoints - aPointA), axis=1)
    aClosestPoints = aPointA + aDirection * aTs[:,np.newaxis]
    return aClosestPoints


def intersectionRayAndPlane(planeNormal, planePoint, rayDirection, rayPoint, epsilon=1e-6):
    ndotu = planeNormal.dot(rayDirection)
    if abs(ndotu) < epsilon:
        raise RuntimeError("no intersection or line is within plane")

    w = rayPoint - planePoint
    si = -planeNormal.dot(w) / ndotu
    Psi = w + si * rayDirection + planePoint
    return Psi


def distanceBetween(xA, xB):
    fA = _xPointToVectorArray(xA)
    fB = _xPointToVectorArray(xB)
    return np.linalg.norm(fB-fA)


def _xPointToVectorArray(xPoint):
    if isinstance(xPoint, np.ndarray):
        return xPoint
    elif isinstance(xPoint, (list,tuple)):
        return np.array(xPoint)
    else:
        print ('xPoint: ', xPoint)
        return np.array(cmds.xform(xPoint, q=True, ws=True, t=True), dtype='float64')



def angleBetween(v1, v2, bDegrees=True):
    v1 /= np.linalg.norm(v1)
    v2 /= np.linalg.norm(v2)
    fAngle = np.arccos(np.clip(np.dot(v1, v2), -1.0, 1.0))
    if bDegrees:
        fAngle = math.degrees(fAngle)
    return fAngle


def boundingBoxDiagLength(aPoints):
    a = np.array([[np.min(aPoints[:, 0]), np.min(aPoints[:, 1]), np.min(aPoints[:, 2])],
                  [np.max(aPoints[:, 0]), np.max(aPoints[:, 1]), np.max(aPoints[:, 2])]],
                 dtype='float64')
    return np.linalg.norm(a[1] - a[0])


def findShortestPath(iiNbs, iFrom, iTos, iStopperIds=[], iInbetweenMaxCount=3):

    aTracks = np.empty(len(iiNbs), dtype=int)
    aTracks.fill(-1)
    aTracks[iFrom] = aTracks[iFrom]

    iLastReached = [iFrom]
    iPathCount = None
    iFoundTo = None
    for x in range(iInbetweenMaxCount+1): # it's +1 because the actual iTo point is not included in that count
        if iFoundTo != None:
            break
        iReached = []
        for ii in iLastReached:
            if iFoundTo != None:
                break
            for iii in iiNbs[ii]:
                if iii in iStopperIds:
                    continue
                if aTracks[iii] == -1:
                    aTracks[iii] = ii
                    iReached.append(iii)
                    if iii in iTos and iii != iFrom:
                        iPathCount = x+1
                        iFoundTo = iii
                        break
            iLastReached = iReached

    if iPathCount == None:
        return []
    else:
        iPath = [iFoundTo]
        for x in range(iPathCount):
            iPath.append(aTracks[iPath[-1]])
        return iPath[::-1]

