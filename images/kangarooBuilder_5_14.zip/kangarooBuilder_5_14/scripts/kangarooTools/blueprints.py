###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import numpy as np
import kangarooTabTools.ctrls as ctrls
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.deformers as deformers
import kangarooTools.xforms as xforms
from collections import defaultdict

kNamespace = 'connected'
if not cmds.namespace(exists=kNamespace):
    cmds.namespace(add=kNamespace)

fSizeMultipl = 1.5


iWarpPriorityCounter = 0

def resetWarpCounter():
    global iWarpPriorityCounter
    iWarpPriorityCounter = 0

def addWarpPriorityAttr(sCtrl):
    global iWarpPriorityCounter
    cmds.addAttr(sCtrl, ln='iWarpPriority', dv=iWarpPriorityCounter, k=True)
    iWarpPriorityCounter += 1


def overwriteWarpPriority(sCtrl, fValue):
    cmds.setAttr('%s.iWarpPriority' % sCtrl, fValue)



def getAllWarpCtrls():
    sCtrls = cmds.ls('ctrl_*', et='transform')
    dCtrls = defaultdict(list)
    for sC in sCtrls:
        sPriorityAttr = '%s.warpPriority' % sC
        if cmds.objExists(sPriorityAttr):
            iPriority = cmds.getAttr(sPriorityAttr)
            dCtrls[iPriority].append(sC)

    sCtrls = []
    for iPriority in sorted(list(dCtrls.keys()), reverse=True):
        sCtrls += dCtrls[iPriority]

    return sCtrls


def createNamespacedBlueprints(sJoints, sBpSkelGrp):
    if not cmds.namespace(exists=kNamespace):
        cmds.namespace(add=kNamespace)

    sGrpConnected = '%s:%s' % (kNamespace, sBpSkelGrp)
    if not cmds.objExists(sGrpConnected):
        # cmds.createNode('transform', name=sGrpConnected)
        cmds.duplicate(sBpSkelGrp, n=sGrpConnected, po=True)[0]

    if sJoints:
        sRoots = xforms.getRoots(sJoints)
        sDuplRoots = cmds.duplicate(sRoots, rr=True)
        cmds.parent(sDuplRoots, sGrpConnected)
        for sDuplRoot, sRoot in zip(sDuplRoots, sRoots):
            sDuplRoot = cmds.rename(sDuplRoot, '%s:%s' % (kNamespace, sRoot.split('|')[-1]))
            sChildren = cmds.listRelatives(sDuplRoot, ad=True, typ='joint', f=True)
            if sChildren:
                sChildren.sort(reverse=True)
                [cmds.rename(sJ, '%s:%s' % (kNamespace, sJ.split('|')[-1])) for sJ in sChildren]



def createCtrl(sJoint, sSide='m', xCtrl=None, sParent=None, bNoRotation=False, iColorIndex=0, bSuper=False):
    sJoint = '%s:%s' % (kNamespace, sJoint)

    if utils.isStringOrUnicode(xCtrl):
        if bNoRotation:
            sLockHide = ['s', 'v', 'r']
            fSize = cmds.getAttr('%s.radius' % sJoint) * fSizeMultipl * 1.25
            sShape = 'sphere'
        else:
            sLockHide = ['s', 'v']
            fSize = cmds.getAttr('%s.radius' % sJoint) * fSizeMultipl * 2.0
            sShape = 'matrix'

        cCtrl = ctrls.TbCtrl().create(sName=xCtrl, sLockHide = sLockHide, sMatch=sJoint, sShape=sShape, sParent=sParent, sSide=sSide,
                                        fSize=fSize, iColorIndex=iColorIndex, bSuper=bSuper)
        addWarpPriorityAttr(cCtrl.sCtrl)

        if bSuper:
            cmds.setAttr('%s.superVIS' % cCtrl.sCtrl, True)

    elif isinstance(xCtrl, ctrls.TbCtrl):
        cCtrl = xCtrl
    else:
        raise Exception('createBlueprintBone xRoots - I don\'t know what %s is (%s)' % (xRoot, type(xRoot)))

    sConstrs = cmds.pointConstraint(cCtrl.sCtrl, sJoint) # NOT sOut because that's used for the child limbs
    sConstrs += cmds.orientConstraint(cCtrl.sCtrl, sJoint) # NOT sOut because that's used for the child limbs
    cmds.parent(sConstrs, sParent)

    return cCtrl



def createGroupCtrl(sJoint, sSide='m', xCtrl=None, sParent=None, fCtrlSize=1.0):

    fJointRadius = cmds.getAttr('%s.radius' % sJoint)

    if utils.isStringOrUnicode(xCtrl):
        cCtrl = ctrls.TbCtrl().create(sName=xCtrl, sLockHide = ['v'], fMatchPos=sJoint, sShape='locator', sParent=sParent, sSide=sSide,
                                        fSize=fCtrlSize*fJointRadius, iColorIndex=2)
        addWarpPriorityAttr(cCtrl.sCtrl)
    elif isinstance(xCtrl, ctrls.TbCtrl):
        cCtrl = xCtrl
    else:
        raise Exception('createBlueprintBone xRoots - I don\'t know what %s is (%s)' % (xRoot, type(xRoot)))



    return cCtrl


def createOrGetGlobalCtrl():
    if not cmds.objExists('_blueprintRig'):
        cmds.createNode('transform', n='_blueprintRig')
    cGlobal = ctrls.TbCtrl().create(sName='bpGlobal', sLockHide = ['v'], sShape='triangle', fSize=10.0, bReturnIfAlreadyExists=True,
                                         sParent='_blueprintRig', iColorIndex=2, bUniformScale=True)
    return cGlobal


def innerOuterCtrlSetup(sOuterNames = [], cOuterCtrls = [], cInnerCtrls=[], fSize=1.0, sParent=None, sSide='m', sPolePos=None):

    cCtrls = []
    for i in range(2):
        cC = ctrls.TbCtrl().create(sName=sOuterNames[i], sLockHide = ['r','s','v'], sMatch=cOuterCtrls[i].sCtrl, sShape='locator',
                    sParent=sParent, sSide=sSide, fSize=fSize, iOffsetCount=1, iColorIndex=3)
        addWarpPriorityAttr(cC.sCtrl)
        cCtrls.append(cC)

    curves.createPoleVectorLine(cCtrls[0], cCtrls[1].sOut)

    sAiming = cmds.createNode('transform', name='%s_%s_aimingGroup' % (sSide, sOuterNames[0]), p=sParent)
    cmds.pointConstraint(cCtrls[0].sCtrl, sAiming)

    sPole = cmds.createNode('transform', name='%s_%s_upVector' % (sSide, sOuterNames[0]), p=sParent)
    cmds.delete(cmds.pointConstraint(sPolePos, sPole))
    cmds.parentConstraint(cCtrls[0].sCtrl, sPole, mo=True)

    sDistance = nodes.createDistanceNode(cCtrls[0].sCtrl, cCtrls[1].sCtrl, fNormalized=1.0, sDivide='bpGlobal_ctrl.sx', sName='%s_%s' % (sSide, cOuterCtrls[0].sName), bByPassDivisionByZeroError=True)
    for sAttr in ['sx','sy','sz']:
        cmds.connectAttr(sDistance, '%s.%s' % (sAiming,sAttr))

    cmds.aimConstraint(cCtrls[1].sCtrl, sAiming, aim=[1,0,0], wu=[0,1,0], wut='object', wuo=sPole)

    cmds.parentConstraint(cCtrls[0].sCtrl, cOuterCtrls[0].sPasser, mo=True)
    cmds.parentConstraint(cCtrls[1].sCtrl, cOuterCtrls[1].sPasser, mo=True)

    for cInner in cInnerCtrls:
        cmds.parentConstraint(sAiming, cInner.sPasser, mo=True)

    return cCtrls


def createChainCtrls(sJoints, sSide='m', dMirrorOrients={}, bParentAimUnderRoot=False, sParent=None, xRoot=None, xAim=None,
                     xPole=None, xElbows=[], fUpVector=(0,-1,0), fUpVectorDistanceMultipl=1.0, iColorIndexOffset=0, bLockTz=True):

    bMaintainAimConstraintOffset = True
    if cmds.objExists('_blueprints.maintainAimConstraintOffset'):
        bMaintainAimConstraintOffset = False

    sJoints = ['%s:%s' % (kNamespace, sJ) for sJ in sJoints]

    fSideMultipl = -1.0 if sSide == 'r' else 1.0
    sConstraints = []

    if utils.isStringOrUnicode(xRoot):
        cRoot = ctrls.TbCtrl().create(sName=xRoot, sLockHide = ['r','s','v'], sMatch=sJoints[0], sShape='cube', sParent=sParent,
                                    sSide=sSide, fSize=cmds.getAttr('%s.radius' % sJoints[0])*fSizeMultipl, iColorIndex=iColorIndexOffset+0)
        addWarpPriorityAttr(cRoot.sCtrl)
    elif isinstance(xRoot, ctrls.TbCtrl):
        cRoot = xRoot
    else:
        raise Exception('createBlueprintBone xRoots - I don\'t know what %s is (%s)' % (xRoot, type(xRoot)))

    if utils.isStringOrUnicode(xAim):
        cAim = ctrls.TbCtrl().create(sName=xAim, sLockHide = ['r','s','v'], sMatch=sJoints[-1], sShape='cube', sParent=sParent,
                                    sSide=sSide, fSize=cmds.getAttr('%s.radius' % sJoints[-1])*fSizeMultipl, iColorIndex=iColorIndexOffset+0)

    elif isinstance(xRoot, ctrls.TbCtrl):
        cAim = xAim
    else:
        raise Exception('createBlueprintBone xAims - I don\'t know what %s is (%s)' % (xRoot, type(xRoot)))
    addWarpPriorityAttr(cAim.sCtrl)

    if utils.isStringOrUnicode(xPole):
        sTemp = cmds.createNode('transform', p=sJoints[1] if len(sJoints) > 2 else sJoints[0])
        fDistance = xforms.distanceBetween(sJoints[0], sJoints[-1])
        fPolePosFactor = fDistance * 0.5 * fUpVectorDistanceMultipl

        if dMirrorOrients.get(sJoints[0].split(':')[-1], True):
            fUpVectorPass = [fUpVector[0]*fPolePosFactor*fSideMultipl, fUpVector[1]*fPolePosFactor*fSideMultipl, fUpVector[2]*fPolePosFactor*fSideMultipl]
        else:
            fUpVectorPass = [fUpVector[0]*fPolePosFactor, fUpVector[1]*fPolePosFactor, fUpVector[2]*fPolePosFactor]

        cmds.setAttr('%s.t' % sTemp, *fUpVectorPass)
        cPole = ctrls.TbCtrl().create(sName=xPole, sLockHide = ['r','s','v'], sMatch=sTemp, sShape='locator', sParent=sParent, sSide=sSide,
                                    fMatchPos=sTemp, fSize=cmds.getAttr('%s.radius' % sJoints[1])*fSizeMultipl, iOffsetCount=1, iColorIndex=iColorIndexOffset+0)
        addWarpPriorityAttr(cPole.sCtrl)

        cmds.delete(sTemp)


    elif isinstance(xRoot, ctrls.TbCtrl):
        cPole = xPole
    else:
        raise Exception('createBlueprintBone xPole - I don\'t know what %s is (%s)' % (xRoot, type(xRoot)))

    if bParentAimUnderRoot:
        cmds.parent(cAim.sPasser, cRoot.sOut)
        cmds.parent(cPole.sPasser, cRoot.sOut)

    # create elbow joints
    sElbowShape = 'squareY'
    if len(sJoints) > 2:
        iElbowCount = len(sJoints) - 2
        cElbows = []
        if len(xElbows) < iElbowCount:
            xElbows += [None] * (iElbowCount-len(xElbows))
        for j, sJoint in enumerate(sJoints[1:-1]):
            if isinstance(xElbows[j], ctrls.TbCtrl):
                cElbows.append(xElbows[j])
            elif utils.isStringOrUnicode(xElbows[j]):
                sLockHide = ['tz','r','s','v'] if bLockTz else ['r','s','v']
                cC = ctrls.TbCtrl().create(sName=xElbows[j], sLockHide = sLockHide, sMatch=sJoint, sShape=sElbowShape, fRotateShape=[0,0,90],
                                sParent=cRoot.sOut, sSide=sSide, fSize=cmds.getAttr('%s.radius' % sJoint)*fSizeMultipl, iColorIndex=iColorIndexOffset+0)
                addWarpPriorityAttr(cC.sCtrl)

                cElbows.append(cC)
            else:
                sLockHide = ['tz','r','s','v'] if bLockTz else ['r','s','v']
                sElbowName = '%sElbow%03d' % (cRoot.sName,j) if iElbowCount == 1 else '%sElbow' % cRoot.sName
                cC = ctrls.TbCtrl().create(sName=sElbowName, iIndex=j, sLockHide=sLockHide, iColorIndex=iColorIndexOffset + 0, fRotateShape=[0, 0, 90],
                                           sMatch=sJoint, sShape=sElbowShape, sParent=cRoot.sOut, sSide=sSide, fSize=cmds.getAttr('%s.radius' % sJoint) * fSizeMultipl)
                addWarpPriorityAttr(cC.sCtrl)
                cElbows.append(cC)

    else:
        cElbows = []


    try:
        sConstraints += cmds.pointConstraint(cRoot.sOut, sJoints[0])
    except: pass
    cmds.parentConstraint(cRoot.sOut, cPole.sPasser, mo=True)
    if len(sJoints) == 2:
        fAimValue = fSideMultipl if dMirrorOrients.get(sJoints[0].split(':')[-1],True) else 1

        if dMirrorOrients.get(sJoints[0].split(':')[-1], True):
            fUpVectorPass = [fUpVector[0] * fSideMultipl, fUpVector[1] * fSideMultipl, fUpVector[2] * fSideMultipl]
        else:
            fUpVectorPass = [fUpVector[0], fUpVector[1], fUpVector[2]]
        sConstraints += cmds.aimConstraint(cAim.sOut, sJoints[0], aim=[fAimValue,0,0],
                                        u=fUpVectorPass, mo=bMaintainAimConstraintOffset,
                                        wut='object', wuo=cPole.sOut)
        sDistance = nodes.createDistanceNode(cAim.sOut, cRoot.sOut, fNormalized=cmds.getAttr('%s.tx' % sJoints[1]),
                                                sName='%s_%s' % (sSide, cAim.sName), sDivide='bpGlobal_ctrl.sx')

        nodes.fromEquation('%s * %s' % (sDistance, '%s.sx' % sParent), sTarget='%s.tx' % sJoints[1], sName='%s_%s' % (sSide, cAim.sName))
        curves.createPoleVectorLine(cPole, sJoints[0], sExtraParents=[cC.sCtrl for cC in [cAim, cRoot]])

    elif len(sJoints) > 2:
        sAiming = cmds.createNode('transform', name='%s_%s_aimingGroup' % (sSide, cAim.sName), p=sParent)
        cmds.pointConstraint(cRoot.sOut, sAiming)
        
        sDistance = nodes.createDistanceNode(cRoot.sOut, cAim.sOut, fNormalized=1.0, sDivide='bpGlobal_ctrl.sx', sName='%s_%s' % (sSide, cAim.sName))
        for sAttr in ['sx','sy','sz']:
            cmds.connectAttr(sDistance, '%s.%s' % (sAiming,sAttr))

        cmds.aimConstraint(cAim.sOut, sAiming, aim=[fSideMultipl,0,0], wu=[0,fSideMultipl,0], wut='object', wuo=cPole.sOut, mo=bMaintainAimConstraintOffset)


        cRootCtrl = cRoot
        for j, sJoint in enumerate(sJoints[:-1]):
            if j < len(cElbows):
                cmds.parentConstraint(sAiming, cElbows[j].sPasser, mo=True)
                cAimCtrl = cElbows[j]
            else:
                cAimCtrl = cAim

            if dMirrorOrients.get(sJoints[j].split(':')[-1], True):
                fAimValue = fSideMultipl
                fUpVectorPass = [fUpVector[0]*fSideMultipl,fUpVector[1]*fSideMultipl,fUpVector[2]*fSideMultipl]
            else:
                fAimValue = 1
                fUpVectorPass = [fUpVector[0],fUpVector[1],fUpVector[2]]

            sConstraints += cmds.aimConstraint(cAimCtrl.sOut, sJoints[j], aim=[fAimValue,0,0],
                                               u=fUpVectorPass,
                                               wut='object', wuo=cPole.sOut, mo=bMaintainAimConstraintOffset)
            sDistance = nodes.createDistanceNode(cRootCtrl.sCtrl, cAimCtrl.sCtrl, fNormalized=cmds.getAttr('%s.tx' % sJoints[j+1]),
                                                 sDivide='bpGlobal_ctrl.sx', sName='%s_%s' % (sSide, cAim.sName))
            nodes.fromEquation('%s * %s' % (sDistance, '%s.sx' % sParent), sTarget='%s.tx' % sJoints[j+1], sName='%s_%s' % (sSide, cAim.sName))
            cRootCtrl = cAimCtrl

        curves.createPoleVectorLine(cPole, sJoints[1], sExtraParents=[cC.sCtrl for cC in [cAim, cRoot]+cElbows])

    cmds.parent(sConstraints, sParent)

    if cElbows:

        cmds.controller(cElbows[0].sCtrl, cRoot.sCtrl, parent=True)

        cmds.controller(cPole.sCtrl, cElbows[-1].sCtrl, parent=True)
        for i in range(len(cElbows)-1):
            cmds.controller(cElbows[i+1].sCtrl, cElbows[i].sCtrl, parent=True)
        cmds.controller(cAim.sCtrl, cPole.sCtrl, parent=True)
    else:
        cmds.controller(cPole.sCtrl, cRoot.sCtrl, parent=True)
        cmds.controller(cAim.sCtrl, cPole.sCtrl, parent=True)


    return [cRoot] + cElbows + [cPole] + [cAim]




def createMirrorBpSetup(tLeftLimb, tRightLimb):


    sMirrorGlobalAttr = utils.addAttr('bpGlobal_ctrl', ln='%sMirror' % tLeftLimb.sName, at='enum', en='noMirror:leftToRight:rightToLeft', k=True, dv=1)

    sLeftNode = tLeftLimb.sBlueprintCurves[0] if tLeftLimb.sBlueprintCurves else tLeftLimb.dBlueprints[list(tLeftLimb.dBlueprints.keys())[0]]
    sLeftCopyGlobalAttr = utils.addAttr('connected:%s' % sLeftNode,
                                    ln='%sSymmetry' % tLeftLimb.sName, at='enum', en='noMirror:leftToRight:rightToLeft', k=True, dv=1, bReturnIfExists=True)

    sRightNode = tRightLimb.sBlueprintCurves[0] if tRightLimb.sBlueprintCurves else tRightLimb.dBlueprints[list(tLeftLimb.dBlueprints.keys())[0]]
    sRightCopyGlobalAttr = utils.addAttr('connected:%s' % sRightNode,
                                    ln='%sSymmetry' % tRightLimb.sName, at='enum', en='noMirror:leftToRight:rightToLeft', k=True, dv=1, bReturnIfExists=True)
    cmds.setAttr(sMirrorGlobalAttr, cmds.getAttr(sLeftCopyGlobalAttr))
    cmds.connectAttr(sMirrorGlobalAttr, sLeftCopyGlobalAttr)
    cmds.connectAttr(sMirrorGlobalAttr, sRightCopyGlobalAttr)


    bDoMirror = True
    if len(tRightLimb.sBlueprintCurves) != len(tLeftLimb.sBlueprintCurves):
        bDoMirror = False
    else:
        for c in range(len(tLeftLimb.sBlueprintCurves)):
            print('counts: ', curves.cvCount(tLeftLimb.sConnectedBlueprintCurves[c]), ' -> ', curves.cvCount(tRightLimb.sConnectedBlueprintCurves[c]))
            if curves.cvCount(tLeftLimb.sConnectedBlueprintCurves[c]) != curves.cvCount(tRightLimb.sConnectedBlueprintCurves[c]):
                bDoMirror = False

    if bDoMirror:
        for c in range(len(tLeftLimb.sBlueprintCurves)):
            for tLimb in [tLeftLimb, tRightLimb]:
                sOldBs = '%s_defaultBs' % tLimb.sConnectedBlueprintCurves[c].split(':')[-1]
                if cmds.objExists(sOldBs):
                    cmds.delete(sOldBs)
                cmds.select(tLimb.sConnectedBlueprintCurves[c])


            sLeftTargets = deformers.addBlendShapeTargets(tLeftLimb.sConnectedBlueprintCurves[c],
                                            [tLeftLimb.sRigBlueprintCurves[c], tRightLimb.sRigBlueprintCurves[c]],
                                            bTopologyCheck=True, bFoc=False)
            #blendshapes
            nodes.createChoiceNode(sMirrorGlobalAttr, [1,1,0], sTarget=sLeftTargets[0])
            nodes.createChoiceNode(sMirrorGlobalAttr, [0,0,1], sTarget=sLeftTargets[1])

            nodes.createChoiceNode(sMirrorGlobalAttr, [0,0,1], sTarget='%s.v' % tLeftLimb.sConnectedBlueprintCurves[c])
            nodes.createChoiceNode(sMirrorGlobalAttr, [1,1,0], sTarget='%s.v' % tLeftLimb.sRigBlueprintCurves[c])

            # bandage fix to make sure old behavior stays the same:
            if hasattr(tLeftLimb.__class__, 'iFixCurveMirrorBehavior') and tLeftLimb.__class__.iFixCurveMirrorBehavior == 1: # fix
                sRightTargets = deformers.addBlendShapeTargets(tRightLimb.sConnectedBlueprintCurves[c],
                                                               [tRightLimb.sRigBlueprintCurves[c], tLeftLimb.sRigBlueprintCurves[c]], bFoc=False)
                nodes.createChoiceNode(sMirrorGlobalAttr, [1, 0, 1], sTarget=sRightTargets[0])
                nodes.createChoiceNode(sMirrorGlobalAttr, [0, 1, 0], sTarget=sRightTargets[1])
            else: # old (bad behavior)
                sRightTargets = deformers.addBlendShapeTargets(tRightLimb.sConnectedBlueprintCurves[c],
                                               [tLeftLimb.sRigBlueprintCurves[c], tRightLimb.sRigBlueprintCurves[c]], bFoc=False)
                nodes.createChoiceNode(sMirrorGlobalAttr, [1,1,0], sTarget=sRightTargets[0])
                nodes.createChoiceNode(sMirrorGlobalAttr, [0,0,1], sTarget=sRightTargets[1])

            nodes.createChoiceNode(sMirrorGlobalAttr, [0,1,0], sTarget='%s.v' % tRightLimb.sConnectedBlueprintCurves[c])
            nodes.createChoiceNode(sMirrorGlobalAttr, [1,0,1], sTarget='%s.v' % tRightLimb.sRigBlueprintCurves[c])

    else: # no mirror
        for c in range(len(tLeftLimb.sBlueprintCurves)):
            cmds.blendShape(tLeftLimb.sRigBlueprintCurves[c], tLeftLimb.sConnectedBlueprintCurves[c], w=[0, 1])
        for c in range(len(tRightLimb.sBlueprintCurves)):
            cmds.blendShape(tRightLimb.sRigBlueprintCurves[c], tRightLimb.sConnectedBlueprintCurves[c], w=[0, 1])
        cmds.setAttr(sMirrorGlobalAttr, 0)
        cmds.setAttr(sMirrorGlobalAttr, lock=True)




    for s,bFromLeft in enumerate([True, False]):
        if tRightLimb.sBlueprintMirrorPlane != tLeftLimb.sBlueprintMirrorPlane:
            raise Exception('%s and %s have different sBlueprintMirrorPlane' % (tLeftLimb.sLimbName, tRightLimb.sLimbName))
        else:
            sBlueprintMirrorPlane = tLeftLimb.sBlueprintMirrorPlane if tLeftLimb.sBlueprintMirrorPlane else None

        sMirrorParentNeg = cmds.createNode('transform', name='grp_mirrorNEG_%s_%s' % ('l' if bFromLeft else 'r', tLeftLimb.sName),
                                        parent=tRightLimb.sBpTopGrp if bFromLeft else tLeftLimb.sBpTopGrp)
        cmds.setAttr('%s.inheritsTransform' % sMirrorParentNeg, False)

        if sBlueprintMirrorPlane:
            sMirrorJoint, sAxis = sBlueprintMirrorPlane.split('.')
            cmds.parentConstraint('connected:%s' % sMirrorJoint, sMirrorParentNeg)
            cmds.setAttr('%s.s%s' % (sMirrorParentNeg, sAxis.lower()), -1)
        else:
            cmds.setAttr('%s.sx' % sMirrorParentNeg, -1)

        sMirrorParentPos = cmds.createNode('transform', name='grp_mirrorPOS_%s_%s' % ('l' if bFromLeft else 'r', tLeftLimb.sName),
                                        parent=tRightLimb.sBpTopGrp if bFromLeft else tLeftLimb.sBpTopGrp)
        cmds.setAttr('%s.inheritsTransform' % sMirrorParentPos, False)
        if sBlueprintMirrorPlane:
            sMirrorJoint, sAxis = sBlueprintMirrorPlane.split('.')
            cmds.parentConstraint('connected:%s' % sMirrorJoint, sMirrorParentPos)


        sMirrorAttr = nodes.createConditionNode(sMirrorGlobalAttr, '==', 1 if bFromLeft else 2, True, False)
        sMirrorAttrRev = nodes.createReverseNode(sMirrorAttr)

        sJoints = list(tRightLimb.dBlueprints.values()) if bFromLeft else list(tLeftLimb.dBlueprints.values())
        sJoints = ['%s:%s' % (kNamespace,sJ) for sJ in sJoints]
        cBpAll = tRightLimb.cBpAll if bFromLeft else tLeftLimb.cBpAll
        for cC in cBpAll:
            cmds.connectAttr(sMirrorAttrRev, '%s.v' % cC.sPasser)


        for sJoint in sJoints:
            sMirrorJoint = utils.getMirrorName(sJoint)
            if not cmds.objExists(sMirrorJoint):
                continue
            for funcConstraint in [cmds.aimConstraint, cmds.pointConstraint, cmds.parentConstraint, cmds.orientConstraint]:

                bMirrorOrient = True
                # sJointParent = cmds.listRelatives(sJoint, p=True)[0].split(':')[-1]
                sJointKey = sJoint.split(':')[-1]
                if sJointKey in tLeftLimb.dMirrorOrients: bMirrorOrient = tLeftLimb.dMirrorOrients[sJointKey]
                elif sJointKey in tRightLimb.dMirrorOrients: bMirrorOrient = tRightLimb.dMirrorOrients[sJointKey]

                sConstraint = funcConstraint(sJoint, q=True)
                sMirrorConstraint = funcConstraint(sMirrorJoint, q=True)
                if sConstraint:
                    sAim = funcConstraint(sJoint, q=True, tl=True)[0]
                    sMirrorAim = utils.getMirrorName(sAim)
                    if cmds.objExists(sMirrorAim):
                        sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sMirrorAim, '%s.worldInverseMatrix' % sMirrorParentPos])
                        if funcConstraint == cmds.orientConstraint and not bMirrorOrient:
                            # we could get rid of sMirrorNegParent...
                            sMirrorNegParent = cmds.createNode('transform', name='%s_mirroredParent_%s' % (sMirrorAim, funcConstraint.__name__), parent=sMirrorParentNeg)
                            sMirrorNeg = cmds.createNode('transform', n='%s_mirrored_%s' % (sMirrorAim, funcConstraint.__name__), parent=sMirrorNegParent)
                            cmds.setAttr('%s.sx' % sMirrorNegParent, -1)
                            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sMirrorNegParent, sTargetRot='%s.r' % sMirrorNegParent)
                            xforms.resetJoint(sMirrorNeg)
                        else:
                            sMirrorNeg = cmds.createNode('transform', name='%s_mirrored_%s' % (sMirrorAim, funcConstraint.__name__), parent=sMirrorParentNeg)
                            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sMirrorNeg, sTargetRot='%s.r' % sMirrorNeg)

                        sConstr = funcConstraint(sMirrorNeg, sJoint)[0]

                        sTargets = funcConstraint(sConstr, q=True, tl=True)
                        cmds.connectAttr(sMirrorAttrRev, '%s.%sW0' % (sConstr,sTargets[0]))
                        cmds.connectAttr(sMirrorAttr, '%s.%sW1' % (sConstr,sTargets[1]))
                    if funcConstraint == cmds.aimConstraint:
                        sUpTransforms = cmds.listConnections('%s.worldUpMatrix' % sConstraint)
                        if sUpTransforms:
                            sUp = sUpTransforms[0]
                            sMirrorUp = utils.getMirrorName(sUp)
                            sMirrorNeg = cmds.createNode('transform', name='%s_mirrored' % sMirrorUp, parent=sMirrorParentNeg)
                            sUpMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sMirrorUp, '%s.worldInverseMatrix' % sMirrorParentPos])
                            nodes.createDecomposeMatrix(sUpMatrix, sTargetPos='%s.t' % sMirrorNeg)
                            nodes.createChoiceNode(sMirrorAttr, ['%s.worldMatrix' % sUp, '%s.worldMatrix' % sMirrorNeg], sTarget='%s.worldUpMatrix' % sConstraint, bForce=True)


            # translate X connection mirror
            sConvs = []
            sConvs += cmds.listConnections('%s.tx' % sJoint, p=True, s=True, d=False, t='multiplyDivide', c=True) or []
            sConvs += cmds.listConnections('%s.tx' % sJoint, p=True, s=True, d=False, t='unitConversion', c=True) or []
            if sConvs:
                _, sConv = sConvs #[u'connected:bp_l_fingerPinky_tip.translateX', u'MD_l_fingerPinkyEnd_001.outputX']

                sMirrorJoint = utils.getMirrorName(sJoint)
                sMirrorConv = cmds.listConnections('%s.tx' % sMirrorJoint, s=True, d=False, p=True)[0]

                if bMirrorOrient:
                    sTxAttr = nodes.fromEquation('%s * -1' % sMirrorConv)
                else:
                    sTxAttr = sMirrorConv
                nodes.createConditionNode(sMirrorAttr, '==', 0, sConv, sTxAttr, sTarget = '%s.tx' % sJoint, bForce=True)





def createMiddleMirrorBpSetup(tLimb):
    if not tLimb.cBpSymmetry:
        return

    iDefault = 1 if tLimb.bSymmetricWhenMiddle else 0


    sMirrorGlobalAttr = utils.addAttr('bpGlobal_ctrl', ln='%sSymmetry' % tLimb.sName, at='enum', en='unsymmetrical:symmetrical', k=True, dv=iDefault)

    cmds.select(tLimb.dBlueprints[list(tLimb.dBlueprints.keys())[0]])
    sCopyGlobalAttr = utils.addAttr('connected:%s' % tLimb.dBlueprints[list(tLimb.dBlueprints.keys())[0]],
                                    ln='%sSymmetry' % tLimb.sName, at='enum', en='unsymmetrical:symmetrical', k=True, dv=iDefault, bReturnIfExists=True)
    cmds.setAttr(sMirrorGlobalAttr, cmds.getAttr(sCopyGlobalAttr))
    cmds.connectAttr(sMirrorGlobalAttr, sCopyGlobalAttr)

    for cCtrl in tLimb.cBpSymmetry:
        sMiddle = cmds.createNode('transform', p=cCtrl.sCtrl, n='%s_symmetry' % cCtrl.sCtrl)

        if tLimb.sBlueprintMirrorPlane:
            sMirrorJoint, sAxis = tLimb.sBlueprintMirrorPlane.split('.')
            sMirrorPlaneGrp = cmds.createNode('transform', n='mirrorPlaneMiddle_%s_%s' % (sMirrorJoint, tLimb.sLimbName), p=cCtrl.sCtrl)
            cmds.setAttr('%s.inheritsTransform' % sMirrorPlaneGrp, False)
            cmds.parent(sMiddle, sMirrorPlaneGrp)
            cmds.parentConstraint('connected:%s' % sMirrorJoint, sMirrorPlaneGrp)
            cmds.parentConstraint(cCtrl.sCtrl, sMiddle)
            if sAxis.lower() == 'x':
                cmds.transformLimits(sMiddle, tx=[0, 0], etx=[True, True])
            elif sAxis.lower() == 'y':
                cmds.transformLimits(sMiddle, ty=[0, 0], ety=[True, True])
            elif sAxis.lower() == 'z':
                cmds.transformLimits(sMiddle, tz=[0, 0], etz=[True, True])
        else:
            cmds.setAttr('%s.inheritsTransform' % sMiddle, False)
            cmds.parentConstraint(cCtrl.sCtrl, sMiddle)
            cmds.transformLimits(sMiddle, tx=[0, 0], etx=[True, True])

        sConstr = cmds.parentConstraint(cCtrl.sCtrl, sMiddle, cCtrl.sOut)[0]
        nodes.createReverseNode(sMirrorGlobalAttr, sTarget='%s.%sW0' % (sConstr,cCtrl.sCtrl))
        cmds.connectAttr(sMirrorGlobalAttr, '%s.%sW1' % (sConstr, sMiddle))


    for sJ in list(tLimb.dBlueprints.values()):
        sConn = 'connected:%s' % sJ
        sAimConstraint = cmds.aimConstraint(sConn, q=True)
        if sAimConstraint:
            sOffsetAttr = '%s.offset' % sAimConstraint
            nodes.createBlendNode(sMirrorGlobalAttr, [0,0,0], cmds.getAttr(sOffsetAttr)[0], bVector=True, sTarget=sOffsetAttr)









