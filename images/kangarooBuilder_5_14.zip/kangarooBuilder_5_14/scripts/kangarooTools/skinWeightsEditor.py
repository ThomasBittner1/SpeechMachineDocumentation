###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np

import kangarooTools.utilsQt as utilsQt
import kangarooTools.deformers as deformers
import kangarooTools.patch as patch

from collections import defaultdict

import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()

qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)

_kRowHeight = utilsQt.getDpi() / 4

mainWin = None

# to do: implement add/remove row on marking menu
class QWeightsUi(QtWidgets.QDialog):

    def __init__(self):
        super(QWeightsUi, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)

        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.setWindowTitle('Kangaroo Skincluster Weights Editor')
        self.rowLayout = QtWidgets.QHBoxLayout()
        self.rowWidgets = []
        self.layout.addLayout(self.rowLayout)
        self.rowLayout.setAlignment(QtCore.Qt.AlignLeft)
        self.resize(1500, 500)
        self.iSelectionScriptJob = cmds.scriptJob(e=["SelectionChanged", self.mayaSelectionChanged])

        self.qSkinClusters = QtWidgets.QComboBox()
        self.qSkinClusters.currentIndexChanged.connect(self.skinClusterSwapped)
        self.layout.addWidget(self.qSkinClusters)

        self.qEditLine = QtWidgets.QLineEdit()
        self.layout.addWidget(self.qEditLine)
        self.qEditLine.editingFinished.connect(self.editLineFinished)


        self.qTable = QtWidgets.QTableWidget()
        self.layout.addWidget(self.qTable)

        self.qTable.currentItemChanged.connect(self.changeCurrent)
        # self.layout.addStretch()
        self.dSelect = {}
        self.mayaSelectionChanged()




    def editLineFinished(self):
        self.qEditLine.selectAll()
        fValue = float(self.qEditLine.text())

        dRows = defaultdict(list)
        for qItem in self.qTable.selectedItems():
            dRows[qItem.row()].append(qItem.column())

        self.dSelect = {}

        for iRow, iColumns in dRows.items():
            aColumns = np.array(iColumns, dtype=int)

            aInfluenceInds = self.aInfOrder[aColumns]
            self.dSelect[iRow] = aInfluenceInds
            fSetSum = len(aInfluenceInds) * fValue

            aOtherColumns = np.setdiff1d(np.arange(self.aaWeights.shape[1]), aInfluenceInds)
            fCurrentOtherSum = np.sum(self.aaWeights[iRow, aOtherColumns])

            if fSetSum > 1.0 or fCurrentOtherSum < 0.00000001:
                fValue = 1.0 / len(aInfluenceInds)
                fSetSum = 1.0
            fOtherSum = 1.0 - fSetSum

            self.aaWeights[iRow, aInfluenceInds] = fValue
            if fCurrentOtherSum >= 0.00000001:
                self.aaWeights[iRow, aOtherColumns] *= fOtherSum / fCurrentOtherSum
            else:
                self.aaWeights[iRow, aOtherColumns] = 0.0


        sSkinCluster = self.qSkinClusters.currentText()
        self.pGeo.setSkinClusterWeights(self.aaWeights, sChooseSkinCluster=sSkinCluster)
        self.mayaSelectionChanged()



    def changeCurrent(self, qItem):
        if qItem:
            self.qEditLine.setText(qItem.text())
            self.qEditLine.selectAll()
            self.qEditLine.setFocus()


    def mayaSelectionChanged(self):
        # print ('selection changed')
        sVerts = [sO for sO in cmds.ls(sl=True, flatten=True) if '.vtx[' in sO]
        dObjects = defaultdict(list)
        for sV in sVerts:
            sGeo, iVertex = utils.indexFromName(sV, bAlsoReturnPrefix=True)
            dObjects[sGeo].append(iVertex)


        self.sMainGeo = None
        self.iVerts = []

        for sGeo, _iVerts in dObjects.items():
            if len(_iVerts) > len(self.iVerts):
                self.sMainGeo = sGeo.split('.')[0]
                self.iVerts = _iVerts

        try:
            self.qSkinClusters.blockSignals(True)
            bDoUpdate = False
            if self.sMainGeo:
                self.qSkinClusters.clear()
                sSkinClusters = deformers.listAllDeformers(self.sMainGeo, sFilterTypes=['skinCluster'])
                for sSkinCluster in sSkinClusters:
                    self.qSkinClusters.addItem(sSkinCluster)
                bDoUpdate = True
            else:
                print ('no geo found')

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            self.qSkinClusters.blockSignals(False)

        if bDoUpdate:
            self.skinClusterSwapped()


    def skinClusterSwapped(self):
        sSkinCluster = self.qSkinClusters.currentText()
        self.pGeo = patch.patchFromName(self.sMainGeo)
        self.pGeo.aIds = np.array(self.iVerts)
        _, self.sInfluences, self.aaWeights = self.pGeo.getSkinCluster(sChooseSkinCluster=sSkinCluster)
        self.qTable.clear()
        self.qTable.setColumnCount(len(self.sInfluences))
        self.qTable.setRowCount(len(self.iVerts))
        [self.qTable.setRowHeight(a, _kRowHeight) for a in range(len(self.iVerts))]

        self.qTable.setVerticalHeaderLabels([str(iV) for iV in self.iVerts])

        aInfSums = np.sum(self.aaWeights, axis=0)
        self.aInfOrder = np.argsort(aInfSums)[::-1]

        self.sInfluences = np.array(self.sInfluences)[self.aInfOrder]

        self.qTable.setHorizontalHeaderLabels(self.sInfluences)

        for iInd, aWeights in enumerate(self.aaWeights):
            for j in range(len(aWeights)):
                iInfluenceInd = self.aInfOrder[j]
                fValue = aWeights[iInfluenceInd]
                qItem = QtWidgets.QTableWidgetItem(str(fValue))

                self.qTable.setItem(iInd, j, qItem)
                if iInd in self.dSelect:
                    if iInfluenceInd in self.dSelect[iInd]:
                        qItem.setSelected(True)


    def closeEvent(self, *args, **kwargs):
        cmds.scriptJob(kill=self.iSelectionScriptJob)
        print('closing...')




def showUI():

    global mainWin
    if mainWin != None:
        mainWin.close()
    mainWin = QWeightsUi()
    mainWin.show()




