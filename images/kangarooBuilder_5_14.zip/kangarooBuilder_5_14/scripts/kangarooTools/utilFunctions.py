###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.OpenMaya as OpenMaya
import maya.cmds as cmds
import maya.mel as mel
from collections import Counter

import numpy as np
import re
import os
import inspect
import math
import subprocess
import json
import kangarooTools
import string
from collections import OrderedDict
import sys
import importlib
import shutil
import time
import pickle
from functools import reduce

kPythonVersion = None
def getPythonVersion():
    global kPythonVersion
    if kPythonVersion == None:
        kPythonVersion = int(sys.version[0])
    return kPythonVersion


dSameTransformAttrs = {}
dSameTransformAttrs['tx'] = ['tx','translateX']
dSameTransformAttrs['ty'] = ['ty','translateY']
dSameTransformAttrs['tz'] = ['tz','translateZ']
dSameTransformAttrs['translateX'] = ['tx','translateX']
dSameTransformAttrs['translateY'] = ['ty','translateY']
dSameTransformAttrs['translateZ'] = ['tz','translateZ']

dLongAttributes = {}
dLongAttributes['tx'] = 'translateX'
dLongAttributes['ty'] = 'translateY'
dLongAttributes['tz'] = 'translateZ'
dLongAttributes['rx'] = 'rotateX'
dLongAttributes['ry'] = 'rotateY'
dLongAttributes['rz'] = 'rotateZ'
dLongAttributes['sx'] = 'scaleX'
dLongAttributes['sy'] = 'scaleY'
dLongAttributes['sz'] = 'scaleZ'
dLongAttributes['v'] = 'visibility'



kShapeEditorComboModeInfoAttr = 'sComboModeInfoAttr'


# depricated, since later we'll just deal with 'M', 'S'
class ComboCombineMode(object):
    product = 0
    minimum = 1


def decideCombineMode(sTargets, bReturnString=False):
    bIncludesMouthClose = False
    bIncludesCorner = False
    bIncludesJawOpen = False
    for sT in list(sTargets):
        if sT.startswith('mouthClose'):
            bIncludesMouthClose = True
        if sT.startswith('jawOpen'):
            bIncludesJawOpen = True
        if sT.startswith('corner'):
            bIncludesCorner = True

    iCombineMode = ComboCombineMode.minimum
    if bIncludesMouthClose:
        iCombineMode = ComboCombineMode.product
    if bIncludesJawOpen and bIncludesCorner:
        iCombineMode = ComboCombineMode.product
    elif 'browSplinesSplitJointsDown' in sTargets:
        iCombineMode = ComboCombineMode.product

    if bReturnString:
        return ['M', 'S'][iCombineMode]
    else:
        return iCombineMode



def importQtModules():
    if cmds.about(v=True) >= '2025':
        from PySide6 import QtWidgets, QtGui, QtCore
    else:
        from PySide2 import QtWidgets, QtGui, QtCore
    return QtWidgets, QtGui, QtCore


def getQtUserRole():
    QtWidgets, QtGui, QtCore = importQtModules()
    return QtCore.Qt.UserRole

# QtWidgets, QtGui, QtCore = importQtModules()


def getLongAttrName(sAttr):
    sNode, sA = sAttr.split('.')
    return '%s.%s' % (sNode, dLongAttributes.get(sA, sA))


def reload2(modModule):
    if getPythonVersion() == 2:
        return reload(modModule)
    else:
        return importlib.reload(modModule)


def isStringOrUnicode(xValue):
    if getPythonVersion() == 2:
        return isinstance(xValue, (str, unicode))
    else:
        return isinstance(xValue, str)


def raiseExceptionNoChaining(sError):
    if getPythonVersion() == 3:
        exec('raise Exception(sError) from None')
    else:
        exec('raise Exception(sError)')


def isNumber(xValue):
    if getPythonVersion() == 2:
        return isinstance(xValue, (int, long, float))
    else:
        return isinstance(xValue, (int, float))


def getStringInQuota(sMainString, bReturnIfNoQuota=False):
    print ('sMainString: ', sMainString)
    if '\'' not in sMainString:
        if bReturnIfNoQuota:
            return sMainString
        else:
            raise Exception('no quotas (\') in string "%s"' % sMainString)
    else:
        sSplits = sMainString.split('\'')
        sName = sSplits[1].split('.')[-1]
        return sName


def getLetter(iIndex, bLower=False):
    sLetter = string.ascii_lowercase[iIndex]
    if bLower:
        return sLetter
    else:
        return sLetter.upper()


def getNumberFromLetters(sLetters):
    sLetters = sLetters.lower()
    iCount = len(sLetters)
    iNumber = 0
    for i in range(iCount):
        iIndex = string.ascii_lowercase.index(sLetters[i])
        iNumber += iIndex * pow(26,iCount-i-1)
    return iNumber



def getDagPath(sName):
    selList = OpenMaya2.MSelectionList()
    try:
        selList.add(sName)
    except Exception as e:
        sLs = cmds.ls(sName)
        if len(sLs) > 1:
            raise Exception('There is more than one object with the name of "%s" (utils.getDatPath())' % sName)
        elif not sLs:
            raise Exception('No object with the name of "%s" (utils.getDatPath())' % sName)
        else:
            raise Exception('Unable to create dagPath with "%s" - %s (utils.getDatPath())' % (sName, e))
    return selList.getDagPath(0)


def getPlug(sAttr):
    mSelectionList = OpenMaya2.MSelectionList()
    mSelectionList.add(sAttr)
    mPlug = mSelectionList.getPlug(0)
    return mPlug



def getDagPathOldApi(sName):
    selList = OpenMaya.MSelectionList()
    try:
        selList.add(sName)
    except Exception as e:
        sLs = cmds.ls(sName)
        if len(sLs) > 1:
            raise Exception('There is more than one object with the name of "%s" (utils.getDatPath())' % sName)
        elif not sLs:
            raise Exception('No object with the name of "%s" (utils.getDatPath())' % sName)
        else:
            raise Exception('Unable to create dagPath with "%s" - %s (utils.getDatPath())' % (sName, e))
    tmp = OpenMaya.MDagPath()
    selList.getDagPath(0, tmp)
    return tmp


def getDependNode(sName):
    selList = OpenMaya2.MSelectionList()
    selList.add(sName)
    return selList.getDependNode(0)


def getDependNodeOldApi(sName):
    selList = OpenMaya.MSelectionList()
    try:
        selList.add(sName)
    except Exception as e:
        raise Exception('Error getting api object of "%s". It might not exist? (%s)' % (sName, str(e)))
    tmp = OpenMaya.MObject()
    selList.getDependNode(0, tmp)
    return tmp


def getPlugOnNode(mNode, sAttr):
    depNodeFn = OpenMaya2.MFnDependencyNode(mNode)
    attrObject = depNodeFn.attribute(sAttr)
    plug = OpenMaya2.MPlug(mNode, attrObject )
    return plug



def matchJointRadius(sJoints, sFromJoint, fFactor=1.0):
    fFromJointRadius = cmds.getAttr('%s.radius' % sFromJoint)
    for sJ in toList(sJoints):
        cmds.setAttr('%s.radius' % sJ, fFromJointRadius*fFactor)


def hideRoots(sSkip=[], bDeleteThem=False):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]

    sOutsideNodes = set(sOutsideNodes) - set(cmds.ls(sSkip))
    for sN in sOutsideNodes:
        if bDeleteThem:
            if cmds.objExists(sN):
                cmds.delete(sN)
        else:
            cmds.setAttr('%s.v' % sN, False)



def extendToShape(sGeo):
    mGeo = getDagPath(sGeo)
    mGeo.extendToShape()
    sShape = mGeo.partialPathName()
    return sShape


def objFromArg(sString, bErrorIfNone=True, sType='mesh'):
    if sString:
        sMesh = toList(sString)[0]
        return sMesh
    else:
        if bErrorIfNone:
            raise Exception('no %s given' % sType)



def openExplorer(sLocation):
    sLocation = sLocation.replace('\\', '/')
    print('open explorer: %s' % sLocation)

    sSystem = cmds.about(operatingSystem=True)


    if not os.path.exists(sLocation):
        print ('path doesn\'t exist ("%s"), cutting it..' % sLocation)
        sDir = os.path.dirname(sLocation)
        for i in range(10):
            if not os.path.exists(sDir):
                sDir = os.path.normpath(os.path.join(sDir, os.pardir))
        sLocation = sDir

    if sSystem.startswith('win'):
        if os.path.isfile(sLocation):
            subprocess.call(r'explorer /select, "%s"' % sLocation.replace('/', '\\'))
        else:
            subprocess.call(['explorer', sLocation.replace('/', '\\')])
    elif sSystem.startswith('linux'):
        subprocess.call(['xdg-open', sLocation])
    elif sSystem == 'mac':
        subprocess.call(['open', '-R', sLocation])



def beautifyVariableName(sString, bExcludeFirstLetterIfOne=True):
    if len(sString) == 1:
        return sString.upper()
    sSeparated = re.sub('(?!^)([A-Z][a-z]+)', r' \1', sString)
    if bExcludeFirstLetterIfOne and sSeparated[1] == ' ':
        sSeparated = sSeparated[2:]
    sSeparated = '%s%s' % (sSeparated[0].upper(), sSeparated[1:])
    return sSeparated


def getFirstLetterUpperCase(sText):
    if not sText:
        return ''
    elif len(sText) == 1:
        return sText.upper()
    else:
        return '%s%s' % (sText[0].upper(), sText[1:])


def getFirstLetterLowerCase(sText):
    if not sText:
        return ''
    elif len(sText) == 1:
        return sText.lower()
    else:
        return '%s%s' % (sText[0].lower(), sText[1:])


def minStringFloat(fValue, iMaxDecCount=3):
    return str(round(fValue, iMaxDecCount))


def getStringFloatValue(sAttr):
    return minStringFloat(cmds.getAttr(sAttr), 3)


def intFromComponent(sComp, bReturnPatch=False):
    import kangarooTools.patch as patch

    sId = sComp.split('[')[-1].split(']')[0]
    iId = int(sId)

    if bReturnPatch:
        sName = sComp.split('.')[0]
        if cmds.objExists(sName):
            pPatch = patch.patchFromName(sName)
        else:
            pPatch = None
        return pPatch, iId
    else:
        return iId


def replaceStringStart(sText, sSearch, sReplace):
    if sText.startswith(sSearch):
        return '%s%s' % (sReplace, sText[len(sSearch):])
    else:
        return sText

def replaceStringEnd(sText, sSearch, sReplace):
    if sText.endswith(sSearch):
        return '%s%s' % (sText[:-len(sSearch)], sReplace)
    else:
        return sText


def evalValueFromString(xValue):
    try: xVal = eval(xValue)
    except: xVal = str(xValue)
    return xVal


fIdentityMatrix = (1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0)


def matrixFromPoints(aim, up, cross, pos):
    matrix = OpenMaya2.MMatrix([aim.x, aim.y, aim.z, 0.0,
                                up.x, up.y, up.z, 0.0,
                                cross.x, cross.y, cross.z, 0.0,
                                pos.x, pos.y, pos.z, 1.0])
    return matrix


def numpyMatrixFromVectors(aPos, aAim, aUp, aCross=None, bNormalize=False):
    if bNormalize:
        aAim = aAim / np.linalg.norm(aAim)
        aUp = aUp / np.linalg.norm(aUp)
    if isNone(aCross):
        aCross = np.cross(aAim, aUp)

    aMatrix = np.zeros((4,4), dtype='float64')
    aMatrix[3,3] = 1.0
    aMatrix[3,0:3] = aPos
    aMatrix[0,0:3] = aAim
    aMatrix[1,0:3] = aUp
    aMatrix[2,0:3] = aCross
    return aMatrix

def matrixFromPos(pos):
    matrix = OpenMaya2.MMatrix([1, 0, 0, 0.0,
                                0, 1, 0, 0.0,
                                0, 0, 1, 0.0,
                                pos[0], pos[1], pos[2], 1.0])
    return matrix


def matrixFromLists(aim, up, cross, pos):
    matrix = OpenMaya2.MMatrix([aim[0], aim[1], aim[2], 0.0,
                                up[0], up[1], up[2], 0.0,
                                cross[0], cross[1], cross[2], 0.0,
                                pos[0], pos[1], pos[2], 1.0])
    return matrix


def invertFlatMatrix(fMatrix):
    aMatrix = np.array(fMatrix, dtype='float64').reshape(4,4)
    aInvMatrix = np.linalg.inv(aMatrix)
    return flattenedList(aInvMatrix)


def numpify2dList(xList, bReturnSizes=False, iEmptyValue=-1, iMaxCount=None, dtype=int):
    '''
    if iEmptyValue is set to None, the missing ones are filled with the last item
    '''
    aSizes = np.array([len(xL) for xL in xList], dtype=int)

    iBiggest = np.max(aSizes)
    if iMaxCount and iBiggest > iMaxCount:
        aSizes = np.clip(aSizes, 0, iMaxCount)
        iBiggest = iMaxCount

    aReturn = np.empty((len(xList),iBiggest), dtype=dtype)
    aReturn.fill(iEmptyValue if iEmptyValue != None else -5)

    for l,xL in enumerate(xList):
        aReturn[l,:aSizes[l]] = xL[0:min(iBiggest,len(xL))]
        if iEmptyValue == None and aSizes[l] < iBiggest:
            aReturn[l,aSizes[l]:] = aReturn[l,aSizes[l]-1]

    if bReturnSizes:
        return aReturn, aSizes
    else:
        return aReturn


def isProject(sName):
    return sName.startswith('__') and sName.endswith('__') and '.' not in sName and sName[2:-2].isupper()


def listToString(sList, sSeparator=', ', iMaxCount=None, bQuotations=False):
    if bQuotations:
        sList = ['"%s"' % sO for sO in sList]

    if iMaxCount and len(sList) > iMaxCount:
        iMore = len(sList) - iMaxCount
        return '%s, and %d more' % (sSeparator.join(sList[:iMaxCount]), iMore)
    else:
        return sSeparator.join(sList)


def listToMPointArray(aPoints):
    return OpenMaya2.MPointArray(aPoints)

    # arr = OpenMaya2.MPointArray()
    # for aP in aPoints:
    #     arr.append(OpenMaya2.MPoint(aP))
    # return arr


def geoEqual(sA, sB):
    if sA == sB:
        return True

    bATransform = True if cmds.objectType(sA) == 'transform' else False
    bBTransform = True if cmds.objectType(sB) == 'transform' else False

    if bATransform and bBTransform:
        return False
    if bATransform and sB in cmds.listRelatives(sA, s=True) or []:
        return True
    if bBTransform and sA in cmds.listRelatives(sB, s=True) or []:
        return True
    if not bATransform and not bBTransform:
        sParentsA = cmds.listRelatives(sA, p=True)
        sParentsB = cmds.listRelatives(sB, p=True)
        if not sParentsA or not sParentsB:
            return False
        if sParentsA[0] == sParentsB[0]:
            return True

    return False



def indexFromName(sName, bAlsoReturnPrefix=False):
    sSplits = sName.split('[')
    sIndex = sSplits[1].split(']')[0]
    return (sSplits[0], int(sIndex)) if bAlsoReturnPrefix else int(sIndex)


def toList(item):
    if isinstance(item, (list,tuple)):
        return item
    elif isinstance(item, (type(list({}.keys())), type(list({}.values())))):
        return list(item)
    elif isinstance(item, dict):
        return list(item.keys())
    else:
        return [item]

'''
def listsAreEqual(sListA, sListB):
    if not set(sListA) - set(sListB) and not set(sListB) - set(sListA):
        return True
    else:
        return False
'''


def bSpline3(fThreeValues, iCount=5, aValues=None, bReachLengthMinusOne=False):
    if isinstance(aValues,np.ndarray):
        a = aValues
    elif isinstance(aValues, (list,tuple)):
        a = np.array(aValues, dtype='float64')
    else:
        if bReachLengthMinusOne:
            a = np.linspace(0.0, float(iCount-1)/iCount, iCount)
        else:
            a = np.linspace(0.0, 1.0, iCount)
    aResult =   fThreeValues[0] * np.power((1-a), 2) + \
                fThreeValues[1] * 2*a*(1-a) + \
                fThreeValues[2] * np.power(a,2)
    return aResult

    # a = np.linspace(0.0, 1.0, iCount)
    # aResult =   fThreeValues[0] * np.power((1-a), 2) + \
    #             fThreeValues[1] * 2*a*(1-a) + \
    #             fThreeValues[2] * np.power(a,2)
    # return aResult


def bSpline4(fFourValues, iCount=5, aValues=None, bReachLengthMinusOne=False):

    if isinstance(aValues,np.ndarray):
        a = aValues
    elif isinstance(aValues, (list,tuple)):
        a = np.array(aValues, dtype='float64')
    else:
        if bReachLengthMinusOne:
            a = np.linspace(0.0, float(iCount-1)/iCount, iCount)
        else:
            a = np.linspace(0.0, 1.0, iCount)
    aResult =   fFourValues[0] * np.power(1-a, 3) + \
                fFourValues[1] * 3 * a * np.power(1-a,2) + \
                fFourValues[2] * 3 * np.power(a,2) * (1-a) + \
                fFourValues[3] * np.power(a, 3)
    return aResult


def smoothOneRange(fValue, fFourValues=[0,0,1,1]):
    aResult =   fFourValues[0] * np.power(1-fValue, 3) + \
                fFourValues[1] * 3 * fValue * np.power(1-fValue,2) + \
                fFourValues[2] * 3 * np.power(fValue,2) * (1-fValue) + \
                fFourValues[3] * np.power(fValue, 3)
    return aResult


def addTangents(fPercs=[0,1,2,3,4,5], bRemoveMains=False):
    '''
    bRemoveMains is not used yet
    '''
    if bRemoveMains:
        fNewPercs = []
        for i,fP in enumerate(fPercs):
            if i == 0:
                fNewPercs.append(fPercs[0])
            if i > 0:
                fNewPercs.append(fPercs[i-1] * 0.25 + fPercs[i] * 0.75)
            if i < len(fPercs)-1:
                fNewPercs.append(fPercs[i] * 0.75 + fPercs[i+1] * 0.25)
            if i == len(fPercs)-1:
                fNewPercs.append(fPercs[-1])
        return fNewPercs

    else:
        fPercs = list(fPercs)
        i = 1
        while i < len(fPercs):
            fPercs.insert(i, fPercs[i-1] * 0.3333333333333333 + fPercs[i] *   0.6666666666666667)
            fPercs.insert(i, fPercs[i-1] * 0.6666666666666667 + fPercs[i+1] * 0.3333333333333333)
            i += 3
        return fPercs



def bSpline4Sequence(fArray=[0.0, 0.5, 1.0, 1.0], iCount=20, bStartFlat=False, bEndFlat=False):
    iPartsCount = len(fArray)-1

    mmTangents = []

    for v,fV in enumerate(fArray):
        if v == 0:
            if bStartFlat:
                mTangents = [OpenMaya2.MVector(0.33, 0.0, 0.0)]
            else:
                mLocalAfter = OpenMaya2.MVector(1.0, fArray[v + 1] - fArray[v], 0)
                mTangents = [mLocalAfter * 0.33 / mLocalAfter.x]
        elif v == len(fArray)-1:
            if bEndFlat:
                mTangents = [OpenMaya2.MVector(-0.33, 0.0, 0.0)]
            else:
                mLocalBefore = OpenMaya2.MVector(-1.0, fArray[v - 1] - fArray[v], 0)
                mTangents = [mLocalBefore * -0.33 / mLocalBefore.x]

        else:
            mLocalBefore = OpenMaya2.MVector(-1.0, fArray[v-1] - fArray[v], 0)
            mLocalAfter = OpenMaya2.MVector(1.0, fArray[v+1] - fArray[v], 0)

            fLocalBeforeLength = mLocalBefore.length()
            fLocalAfterLength = mLocalAfter.length()
            mLocalBefore /= fLocalBeforeLength
            mLocalAfter /= fLocalAfterLength

            mAverage = (-mLocalBefore + mLocalAfter)
            mAverage.normalize()

            mTangents = [-mAverage * fLocalBeforeLength * 0.33, mAverage * fLocalAfterLength * 0.33]
            mTangents[0] *= -0.33 / mTangents[0].x
            mTangents[1] *= 0.33 / mTangents[1].x

        mmTangents.append(mTangents)

    fAllValues = []
    for iPart in range(iPartsCount):
        iSize = iCount / iPartsCount
        if iPart >= iPartsCount-1:
            iSize += iCount % iPartsCount
        fAllValues += list(bSpline4([fArray[iPart],
                                     fArray[iPart] + mmTangents[iPart][-1].y,
                                     fArray[iPart+1] + mmTangents[iPart+1][0].y,
                                     fArray[iPart+1]], iSize, bReachLengthMinusOne=True))

    if False: # debug locators
        import kangarooTools.xforms as xforms
        for a,b in enumerate(fAllValues):
            xforms.createLocator('loc_%d' % a, xPos=[a*0.1, b, 0], fSize=0.1)

        for iKey in range(len(fArray)):
            sLoc = cmds.polyCube(n='key_%d' % iKey)[0]
            cmds.setAttr('%s.t' % sLoc, iKey, fArray[iKey], 0)
            cmds.setAttr('%s.s' % sLoc, 0.1, 0.1, 0.1)
            cmds.makeIdentity(sLoc, apply=True, s=True)
            xforms.createLocator('tangentA_%d' % iKey, sParent=sLoc, xPos=mmTangents[iKey][0], fSize=0.1)
            xforms.createLocator('tangentB_%d' % iKey, sParent=sLoc, xPos=mmTangents[iKey][-1], fSize=0.1)

    return fAllValues


def pointSequenceLength(aPoints):
    fLength = 0
    for p,aP in enumerate(aPoints):
        if p > 0:
            fLength += np.linalg.norm(aP - aPoints[p-1])
    return fLength


def convertMiddleSequenceToSides(iCount, bZipped=False):

    if iCount == 1:
        return ['m'], np.array([0])

    kSides =  ['l','m','r']
    iHalf = iCount // 2
    aSides = np.empty(iCount, dtype=int)
    aSides.fill(2)
    aInds = np.zeros(iCount, dtype=int)
    iMiddle = iHalf if iCount % 2 else None
    if iMiddle:
        aSides[iMiddle] = 1
    aSides[:iHalf] = 0

    aInds[:iHalf] = np.arange(iHalf)[::-1]
    if iMiddle:
        aInds[(iHalf + 1):] = np.arange(iHalf)
    else:
        aInds[iHalf:] = np.arange(iHalf)

    sSides = [kSides[a] for a in aSides]
    if bZipped:
        return list(zip(sSides, list(aInds)))
    else:
        return sSides, aInds

def makePointsRelative(aPoints, sTransform):
    aaTransformInv = np.linalg.inv(getNumpyMatrixFromTransform(sTransform))
    return np.dot(makePoint4Array(aPoints), aaTransformInv)[:, 0:3]


def makePoint4Array(aPoints):
    aPoints4 = np.ones((aPoints.shape[0],4), dtype='float64')
    aPoints4[:,0:3] = aPoints
    return aPoints4

def makePoint4(aPoint):
    aPoint4 = np.ones(4, dtype='float64')
    aPoint4[0:3] = aPoint
    return aPoint4


# bOutIsVector is not tested  yet
def projectToRange(fValue, fInMin, fInMax, fOutMin, fOutMax, bOutIsVector=False):
    if fInMin > fInMax:
        fInMin, fInMax = fInMax, fInMin
        fOutMin, fOutMax = fOutMax, fOutMin

    if fValue <= fInMin:
        return fOutMin
    elif fValue >= fInMax:
        return fOutMax
    else:
        fT = (fValue-fInMin) / float(fInMax-fInMin)
        
        if bOutIsVector: # not tested  yet
            return list(np.array(fOutMax, dtype='float64') * fT + np.array(fOutMin, dtype='float64') * (1.0-fT))
        else:
            return fOutMax * fT + fOutMin * (1.0-fT)



def fPruneSmallValues(fVector, fPrune=0.00001):
    return [0.0 if abs(fV) < fPrune else fV for fV in fVector]


def multiDimensionInterp(fTime, aKeyTimes, aKeyValues):
    iStart = np.searchsorted(aKeyTimes, fTime)-1
    iEnd = iStart + 1
    if iStart >= len(aKeyTimes)-1:
        return aKeyValues[-1]
    elif iStart < 0:
        return aKeyValues[0]
    else:
        fT = (fTime-aKeyTimes[iStart]) / float(aKeyTimes[iEnd]-aKeyTimes[iStart])
        return aKeyValues[iEnd] * fT + aKeyValues[iStart] * (1.0-fT)



def findOneArrayInAnother(aMain, aFind, iMissingIndex=-1, bSkipMissing=False):
    # returns array in the size of aFind, indices at where those are in aMain
    if not len(aMain):
        aIndexed = np.empty(len(aFind), dtype=int)
        aIndexed.fill(iMissingIndex)
        return aIndexed
    aMain = np.array(aMain)
    aSort = np.argsort(aMain)
    aMainSorted = aMain[aSort]
    aSearchSorted = np.searchsorted(aMainSorted, aFind)
    aIndexed = np.append(aSort,-1)[aSearchSorted]
    for i, iInd in enumerate(aIndexed):
        if iInd != iMissingIndex and aMain[iInd] != aFind[i]:
            aIndexed[i] = iMissingIndex

    if bSkipMissing:
        aIndexed = aIndexed[aIndexed != iMissingIndex]

    return aIndexed


def intersectionSets(xSets):
    outSet = xSets[0]
    for xS in xSets[1:]:
        outSet = outSet.intersection(xS)
    return outSet


def intersectionLists(xLists):
    return list(intersectionSets([set(xL) for xL in xLists]))


def mergeDict(a,b):
    c = dict(a)
    c.update(b)
    return c


def createEmptyTextFile(sFilePath):
    with open(sFilePath, 'w+') as file:
        file.write('')


def createTextFile(sFilePath, sText):
    with open(sFilePath, 'w+') as file:
        for sLine in toList(sText):
            file.write(sLine)
    return sFilePath

def readFile(sFilePath):
    with open(sFilePath) as myFile:
        sAllLines = list(myFile)
    return sAllLines


def removeRequiresLines(sFilePath):
    '''
    removes lines like this:
    requires "rivetConstraint" "1.0";
    '''
    sLines = readFile(sFilePath)

    iStart = None
    iEnd = None

    l = -1
    bFoundRequiresLine = False
    while l < len(sLines) - 1:
        l += 1

        if l > 200 and iStart == None:
            break

        if sLines[l].startswith('requires '):
            bFoundRequiresLine = True
            if iStart == None:
                iStart = l+1 # because we want to keep the first requires line
            for ll in range(l,len(sLines),1):
                if ';' in sLines[ll]:
                    l = ll
                    break
        else:
            if iStart != None:
                iEnd = l
                break


    if bFoundRequiresLine: #iStart != None and iEnd != None:
        sNewLines = sLines[:iStart] + sLines[iEnd:] # sNewLines = sLines[:iStart] + sLines[iEnd+1:].
        sResult = 'removing %d "required ..." lines from "%s"' % (iEnd-iStart, sFilePath)
        createTextFile(sFilePath, sNewLines)
    else:
        sResult = 'no required lines found'

    return sResult


def getLatestVersion(sDir):
    sAllVersions = os.listdir(sDir)
    if not sAllVersions:
        return None
    sFirsts = [sV.split('_')[0] for sV in sAllVersions]
    iNumbers = [getNumberAtEnd(sF)[1] for sF in sFirsts]
    iMaxVersion = np.argmax(iNumbers)
    sVersion = sAllVersions[iMaxVersion]
    return sVersion


def getNumberAtEnd(sName, iDefault=0):
    m = re.search(r'\d+$', sName)
    if m:
        sNumber = m.group()
        return sName[:-len(sNumber)], int(sNumber)
    else:
        return sName, iDefault


def sortByNumber(sStrings):
    iNumbers = [getNumberAtEnd(sS)[1] for sS in sStrings]
    aSort = np.argsort(iNumbers)
    return np.array(sStrings)[aSort]


def fPercToStr(fPerc):
    return str(int(round(fPerc*100)))


def sPercToFloat(sPerc):
    return float(sPerc) / 100


def createMayaStringFromList(iIdList, bIdListIsAlreadySorted=False):
    if not bIdListIsAlreadySorted:
        iIdList.sort()

    iArrayLength = len(iIdList)
    iNextFace = -1
    i = 0
    iIslandStarts = []
    while i < iArrayLength:
        iIslandStarts.append(int(i))
        for k in range(i,iArrayLength,1):
            if iIdList[k] == iNextFace or iNextFace == -1:
                iNextFace = iIdList[k] + 1
                i += 1
            else:
                break
        iNextFace = -1

    iIslandStarts.append(iArrayLength)
    sStrings = []
    for i in range(len(iIslandStarts)-1):
        iCurrent = iIdList[iIslandStarts[i]]
        iNext = iIdList[iIslandStarts[i+1]-1]
        if iCurrent != iNext:
            sStrings.append('%d:%d' % (iCurrent, iNext))
        else:
            sStrings.append('%d' % (iCurrent))

    return sStrings


def mayaCompStringsToList(sComps):
    sComps = toList(sComps)
    xList = []
    for sC in sComps:
        sInds = sC.split('[')[-1]
        if sInds.endswith(']'):
            sInds = sInds[:-1]
        if ':' in sInds:
            sSplit = sInds.split(':')
            xList += range(int(sSplit[0]), int(sSplit[1])+1, 1)
        else:
            xList.append(int(sInds))
    xList.sort()
    return xList



def listMeshes(sGrp):
    sShapes = cmds.listRelatives(sGrp, ad=True, typ='mesh', f=True) or []
    return list(set(cmds.listRelatives(sShapes, p=True) or []))


def listGeometries(sGrp):
    sShapes = cmds.listRelatives(sGrp, ad=True, typ='mesh', f=True) or []
    sShapes += cmds.listRelatives(sGrp, ad=True, typ='nurbsCurve', f=True) or []
    sShapes += cmds.listRelatives(sGrp, ad=True, typ='nurbsSurface', f=True) or []
    return list(set(cmds.listRelatives(sShapes, p=True) or []))


def listCurves(sGrp):
    sShapes = cmds.listRelatives(sGrp, ad=True, typ='nurbsCurve', f=True) or []
    return list(set(cmds.listRelatives(sShapes, p=True) or []))


def getMirrorName(sName):
    sUnderscoreSplits = sName.split('__')
    if len(sUnderscoreSplits) == 5:
        sUnderscoreSplits[1] = getMirrorName(sUnderscoreSplits[1])
        return '__'.join(sUnderscoreSplits)

    if 'LFT' in sName: return sName.replace('LFT','RGT')
    if 'RGT' in sName: return sName.replace('RGT', 'LFT')


    if sName[0:2].isupper():
        if sName[0] == 'L': return 'R%s' % sName[1:]
        if sName[0] == 'R': return 'L%s' % sName[1:]
    if sName.startswith('l_'): return 'r_%s' % sName[2:]
    if sName.startswith('L_'): return 'R_%s' % sName[2:]
    if sName.startswith('r_'): return 'l_%s' % sName[2:]
    if sName.startswith('R_'): return 'L_%s' % sName[2:]
    if '_l_' in sName: return sName.replace('_l_','_r_')
    if '_r_' in sName: return sName.replace('_r_','_l_')
    if '_left' in sName: return sName.replace('_left', '_right')
    if '_right' in sName: return sName.replace('_right', '_left')
    if '_L_' in sName: return sName.replace('_L_','_R_')
    if '_R_' in sName: return sName.replace('_R_','_L_')
    if 'Left.' in sName: return sName.replace('Left.','Right.')
    if 'Right.' in sName: return sName.replace('Right.','Left.')
    if 'L.' in sName: return sName.replace('L.','R.')
    if 'R.' in sName: return sName.replace('R.','L.')
    if sName.endswith('Left'): return '%sRight' % sName[:-len('Left')]
    if sName.endswith('Right'): return '%sLeft' % sName[:-len('Right')]
    if sName.endswith('LEFT'): return '%sRIGHT' % sName[:-len('LEFT')]
    if sName.endswith('RIGHT'): return '%sLEFT' % sName[:-len('RIGHT')]
    if sName.endswith('left'): return '%sright' % sName[:-len('left')]
    if sName.endswith('right'): return '%sleft' % sName[:-len('right')]
    if sName.endswith('_Lt'): return '%s_Rt' % sName[:-len('_Rt')]
    if sName.endswith('_Rt'): return '%s_Lt' % sName[:-len('_Lt')]
    if sName.endswith('L'): return '%sR' % sName[:-len('L')]
    if sName.endswith('R'): return '%sL' % sName[:-len('R')]
    if sName.startswith('Left'): return 'Right%s' % sName[len('Left'):]
    if sName.startswith('Right'): return 'Left%s' % sName[len('Right'):]

    if '_L.' in sName: return sName.replace('_L.', '_R.')
    if '_R.' in sName: return sName.replace('_R.', '_L.')
    if '_l.' in sName: return sName.replace('_l.', '_r.')
    if '_r.' in sName: return sName.replace('_r.', '_l.')
    if sName.endswith('_L'): return '%s_R' % sName[:-2]
    if sName.endswith('_R'): return '%s_L' % sName[:-2]

    if sName.endswith('_l'): return '%s_r' % sName[:-2]
    if sName.endswith('_r'): return '%s_l' % sName[:-2]

    return sName

sSidesFirstUpper = ['Left', 'Right']
sSides = ['left','right']
sSides3 = ['LFT','RGT']
sSides1 = ['l','r']

dLongAttr = {}
dLongAttr['tx'] = 'translateX'
dLongAttr['ty'] = 'translateY'
dLongAttr['tz'] = 'translateZ'
dLongAttr['rx'] = 'rotateX'
dLongAttr['ry'] = 'rotateY'
dLongAttr['rz'] = 'rotateZ'
dLongAttr['sx'] = 'scaleX'
dLongAttr['sy'] = 'scaleY'
dLongAttr['sz'] = 'scaleZ'



def getSide(sName):
    if 'LFT' in sName: return 'l'
    if 'RGT' in sName: return 'r'
    if sName[0:2].isupper():
        if sName[0] == 'L': return 'l'
        if sName[0] == 'R': return 'r'
    if sName.startswith('l_'): return 'l'
    if sName.startswith('r_'): return 'r'
    if sName.endswith('_l'): return 'l'
    if sName.endswith('_r'): return 'r'
    if '_l_' in sName: return 'l'
    if '_r_' in sName: return 'r'
    if '_L_' in sName: return 'l'
    if '_R_' in sName: return 'r'
    if sName.endswith('Left'): return 'l'
    if sName.endswith('Right'): return 'r'
    if sName.endswith('_L'): return 'l'
    if sName.endswith('_R'): return 'r'
    if sName.endswith('_Lt'): return 'l'
    if sName.endswith('_Rt'): return 'r'
    if '_L.' in sName: return 'l'
    if '_R.' in sName: return 'r'
    if '_l.' in sName: return 'l'
    if '_r.' in sName: return 'r'
    if sName.startswith('Left'): return 'l'
    if sName.startswith('Right'): return 'r'
    return 'm'


def getSideIndex(sName):
    if 'LFT' in sName: return 0
    if 'RGT' in sName: return 1

    if sName[0:2].isupper():
        if sName[0] == 'L': return 0
        if sName[0] == 'R': return 1
    if sName.startswith('l_'): return 0
    if sName.startswith('r_'): return 1
    if '_l_' in sName: return 0
    if '_r_' in sName: return 1
    if '_L_' in sName: return 0
    if '_R_' in sName: return 1
    if sName.endswith('Left'): return 0
    if sName.endswith('Right'): return 1
    if sName.endswith('_L'): return 0
    if sName.endswith('_R'): return 1
    if sName.endswith('_Lt'): return 0
    if sName.endswith('_Rt'): return 1
    if '_L.' in sName: return 0
    if '_R.' in sName: return 1
    if sName.startswith('Left'): return 0
    if sName.startswith('Right'): return 1
    return 'm'




def copyFilePathToClipboard():
    sFile = cmds.file(q=True, sn=True)
    copyToClipBoard(sFile)
    import kangarooTools.utilsQt as utilsQt
    utilsQt.showFadingText('Copied to Clipboard: "%s"' % sFile)


def selectMirrors(bAdd=False):
    sSelection = cmds.ls(sl=True)
    sMirrors = [getMirrorName(sObj) for sObj in sSelection]
    cmds.select(sMirrors, add=bAdd)



def mirrorList(sList):
    for i in range(len(sList)):
        sList[i] = getMirrorName(sList[i])
    return sList


def mirrorListREC(xListOrString):
    if isinstance(xListOrString, (tuple, list)):
        tempList = []
        for o in xListOrString:
            tempList.append(mirrorListREC(o))
        xListOrString = tuple(tempList) if isinstance(xListOrString, tuple) else tempList
    else:
        xListOrString = getMirrorName(xListOrString)

    return xListOrString


def getIdsToIndicesMapper(aIds, iTotalCount=None, iFillNonUsed=None):
    if isNone(iTotalCount):
        iTotalCount = np.max(aIds)+1

    aAllIdsMapper = np.zeros(iTotalCount, dtype=int)
    if not isNone(iFillNonUsed):
        aAllIdsMapper.fill(iFillNonUsed)

    aAllIdsMapper[aIds] = np.arange(len(aIds))
    return aAllIdsMapper


def getJointsBoundingBoxDiagonal(sJoints):
    aPoints = np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sJoints], dtype='float64')
    aMin = np.min(aPoints, axis=0)
    aMax = np.max(aPoints, axis=0)
    fDiag = np.linalg.norm(aMax-aMin)
    return fDiag




def getModelBoundingBoxDiagonal(sModel):
    sModels = toList(sModel)
    sModelsCheck = []
    for m,sMesh in enumerate(sModels):
        sShapes = cmds.listRelatives(sMesh, s=True)
        if sShapes:
            sModelsCheck.append(sShapes[0])
        else:
            sModelsCheck.append(sMesh)

    bb = np.array(cmds.exactWorldBoundingBox(sModelsCheck)).reshape(2,3)
    return np.linalg.norm(bb[0]-bb[1])


def deleteNoneShapeChildren(sTransform):
    sChildren = cmds.listRelatives(sTransform, c=True, f=True) or []
    sDeleteChildren = [sChild for sChild in sChildren if
                    cmds.objectType(sChild) not in ['mesh', 'nurbsCurve', 'nurbsSurface']]
    if len(sDeleteChildren):
        cmds.delete(sDeleteChildren)


def _duplicateGeoClean(sMesh, sName=None, bSetToOrigMesh=False, bParentToOrigin=False):
    sDupl = cmds.duplicate(sMesh, rr=True)[0]
    if sName and cmds.objExists(sName):
        raise Exception('%s already exists!' % sName)
    if bParentToOrigin:
        try: cmds.parent(sDupl, w=True)
        except: pass
    sAllShapes = cmds.listRelatives(sDupl, s=True, f=True)
    sNoIntermShapes = cmds.listRelatives(sDupl, s=True, ni=True, f=True)
    sShapes = set(sAllShapes) - set(sNoIntermShapes)
    if sShapes:
        cmds.delete(list(sShapes))
    if sName:
        sDupl = cmds.rename(sDupl, sName)

    if bSetToOrigMesh:
        sAllShapes = cmds.listRelatives(sMesh, s=True)
        sNoIntermShapes = cmds.listRelatives(sMesh, s=True, ni=True)
        sShapes = set(sAllShapes) - set(sNoIntermShapes)

        if sShapes:
            sOrig = sShapes.pop()
        else:
            sOrig = sAllShapes[0]

        cmds.connectAttr('%s.outMesh' % sOrig, '%s.inMesh' % sDupl)

    return sDupl


def freezeGeo(sMeshTransform):
    cmds.delete(sMeshTransform, ch=True)
    sAllShapes = cmds.listRelatives(sMeshTransform, s=True, f=True) or []
    sNoIntermShapes = cmds.listRelatives(sMeshTransform, s=True, ni=True, f=True) or []
    sShapes = set(sAllShapes) - set(sNoIntermShapes)
    if sShapes:
        cmds.delete(list(sShapes))


def getParentFolder(sFolder):
    return os.path.abspath(os.path.join(sFolder, os.pardir))

def getToolsDir():
    return os.path.dirname(kangarooTools.__file__)

def getScriptsDir():
    return os.path.abspath(os.path.join(getToolsDir(), os.pardir))

def findEnvFile():
    sEnvFile = os.path.join(os.path.dirname(__file__), 'pathsEnv.mel')
    for i in range(5):
        print('trying env file: ', sEnvFile)
        if not os.path.isfile(sEnvFile):
            sEnvFile = os.path.join(os.path.dirname(sEnvFile), os.pardir, 'pathsEnv.mel')
        else:
            return sEnvFile

def sourceEnvs():
    #sEnvFile = os.path.join(__file__, os.pardir, os.pardir, os.pardir, 'pathsEnv.mel')
    print ('running find sEnvFile')
    sEnvFile = findEnvFile()
    print ('sEnvFile: ', sEnvFile)
    sPathsEnvFile = os.path.normpath(sEnvFile).replace('\\', '/')
    print ('\n\n\n ============================= sourcing ENVS')

    if '\\' in ''.join(readFile(sPathsEnvFile)):
        cmds.confirmDialog(m=f'"{sPathsEnvFile}" includes \\, these need to be replaced with /')
    mel.eval(f'source "{sPathsEnvFile}"')



def getJsonContent(sFile):
    with open(sFile) as file:
        print('loading json file %s...' % sFile)
        xContent = json.load(file)
    return xContent


def setJsonContent(sFile, dContent, iIndent=2):
    with open(sFile, 'w') as outfile:
        json.dump(dContent, outfile, indent=iIndent)


def getCustomAttacherTransformName(sLimb, sAttacher):
    return 'grp_customTransform__%s__%s' % (sLimb, sAttacher)


def getLineNumberInFile(sFile, sText):
    with open(sFile) as myFile:
        for num, line in enumerate(myFile):
            if sText in line:
                return num+1


def listFilesInFolder(sFolder, bAbsolute=False, sEndswith=[]):
    sFiles = []
    for sF in os.listdir(sFolder):
        if os.path.isfile(os.path.join(sFolder,sF)):
            if not sEndswith:
                sFiles.append(sF)
            else:
                for sEW in sEndswith:
                    if sF.endswith(sEW):
                        sFiles.append(sF)
                        break
    if bAbsolute:
        sFiles = [os.path.join(sFolder, sF) for sF in sFiles]
    return sFiles


def listFoldersInFolder(sFolder, bAbsolute=False):
    sFolders = []
    for sF in os.listdir(sFolder):
        if os.path.isdir(os.path.join(sFolder,sF)):
            sFolders.append(sF)
    if bAbsolute:
        sFolders = [os.path.join(sFolder, sF) for sF in sFolders]
    return sFolders



class uiColors():
    blue = '#3f51b5'
    darkBlue = '#36459b'
    green = '#52af50'
    lightGreen = '#8bc34a'
    red = '#ea4963'
    orange = '#ffae00'
    orangeDark = '#af7800'
    yellow = '#ffeb3b'
    darkYellow = '#786f1c'
    white = '#ffffff'
    default = '#d9d9d9'
    disabled = '#363636'
    blue = '#39a9f4'
    violet = '#9000ed'


class browSplinesSplitOptions():
    none = 0
    jointsDown = 1
    jointsUp = 2
    ctrlsDown = 3
    ctrlsUp = 4


def getLineNumberInFile(sFile, sText):
    with open(sFile) as myFile:
        for num, line in enumerate(myFile):
            if sText in line:
                return num+1


def isNone(xInput):
    return isinstance(xInput, type(None))


def isTextInFile(sFile, sText):
    with open(sFile) as myFile:
        sAllLines = '\n'.join(myFile)
        if sText in sAllLines:
            return True
    return False


def removeCurveShadingAttrs(sShape):
    for sAttr in ['aiCurveShaderB', 'aiRenderCurve', 'aiCurveWidth', 'aiSampleRate', 'aiCurveShaderR', 'aiCurveShaderG']:
        try:
            cmds.setAttr('%s.%s' % (sShape, sAttr), k=False)
        except:
            pass

def removeLocatorShapeAttrs(sShape):
    for sAttr in ['localPositionX', 'localPositionY', 'localPositionZ', 'localScaleX', 'localScaleY', 'localScaleZ']:
        try:
            cmds.setAttr('%s.%s' % (sShape, sAttr), k=False, cb=False)
        except:
            pass


def filterArgs(dArgs, func):
    if isinstance(func, (tuple,list)):
        sFilterArgs = func
    else:
        sFilterArgs = inspect.getfullargspec(func)[0]
    sCommonKeys = set(sFilterArgs).intersection(set(dArgs.keys()))
    return {sA: dArgs[sA] for sA in sCommonKeys}


def removeSelfFromArgs(dArgs):
    dArgs.pop('self')
    return dArgs


def getClassNameFromClass(TClass):
    return str(TClass).split('.')[-1].split('\'')[0]


def getConstraintFunctionFromType(sConstraintType):
    dLogic = {'parentConstraint': cmds.parentConstraint,
              'pointConstraint': cmds.pointConstraint,
              'orientConstraint': cmds.orientConstraint}
    return dLogic[sConstraintType]



def fileSizeNice(size, decimal_places=0):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB', 'PB']:
        if size < 1024.0 or unit == 'PB':
            break
        size /= 1024.0
    return f"{size:.{decimal_places}f} {unit}"




def secondsNice(fSeconds):
    iMinutes = math.floor(fSeconds / 60.0)
    sTime = ''
    if iMinutes == 1:
        fSeconds = fSeconds % 60.0
        sTime = '1 minute and '
    elif iMinutes > 1:
        fSeconds = fSeconds % 60.0
        sTime = '%d minutes and ' % iMinutes

    sTime += '%d seconds' % round(fSeconds)
    return sTime


def fullTimeUnits(fTime):
    fAgo = fTime
    fDivs = [1, 60, 60, 24, 7, 4.29, 12]
    sNames = ['seconds', 'minutes', 'hours', 'days', 'weeks', 'months', 'years']
    sNamesSingular = ['second', 'minute', 'hour', 'day', 'week', 'month', 'year']

    fPrevAgo = fAgo
    for i in range(1, len(fDivs), 1):
        fAgo /= fDivs[i]
        if fAgo < 1.0:
            iPrevAgo = round(fPrevAgo)
            return '%d %s' % (iPrevAgo, sNamesSingular[i-1] if iPrevAgo <= 1.0 else sNames[i-1])
        fPrevAgo = fAgo

    iPrevAgo = round(fPrevAgo)
    return '%d %s' % (iPrevAgo, sNamesSingular[-1] if iPrevAgo <= 1.0 else sNames[-1])


# fUnityMatrixAsList = [1.0, 0.0, 0.0,  0.0,
#                       0.0, 1.0, 0.0, 0.0,
#                       0.0, 0.0, 1.0, 0.0,
#                       0.0, 0.0, 0.0, 1.0]


def getNumpyMatrixFromTransform(sTransform, bWorld=True, bThreeByThree=False):
    fMatrix = cmds.xform(sTransform, q=True, m=True, ws=bWorld)
    if bThreeByThree:
        return np.array(fMatrix, dtype='float64').reshape(4, 4)[0:3,0:3]
    else:
        return np.array(fMatrix, dtype='float64').reshape(4,4)


def getOrthoMatrixFromVectors(aPos, aLocalX, aY):
    aLocalY = aY - aPos
    aLocalX /= np.linalg.norm(aLocalX)
    aLocalY /= np.linalg.norm(aLocalY)
    aLocalZ = np.cross(aLocalX, aLocalY)
    aLocalY = np.cross(aLocalX, aLocalZ)
    aLocalZ = np.cross(aLocalX, aLocalY)
    aMatrix = np.zeros((4,4), dtype='float64')
    aMatrix[0,0:3] = aLocalX
    aMatrix[1,0:3] = aLocalY
    aMatrix[2,0:3] = aLocalZ
    aMatrix[3,0:3] = aPos
    aMatrix[3,3] = 1.0
    return aMatrix



def inverseMatrixAttrValue(fMatrix):
    aMatrix = np.array(fMatrix, dtype='float64').reshape(4,4)
    aInverse = np.linalg.inv(aMatrix)
    return list(aInverse.flatten())


def multiplyMatrixAttrValues(fMatrices, bReturnNumpy=False):
    aMatrices = [np.array(fM, dtype='float64').reshape(4,4) for fM in fMatrices]
    aMatrixSum = aMatrices[0]
    for aM in aMatrices[1:]:
        aMatrixSum = np.dot(aMatrixSum, aM)

    if bReturnNumpy:
        return aMatrixSum
    else:
        return list(aMatrixSum.flatten())



def multiplyPositionByMatrix(fVector, aMatrix, bInverseMatrix=False, bReturnNumpy=False):

    if isStringOrUnicode(aMatrix):#isinstance(aMatrix, (str,unicode)):
        if '.' in aMatrix:
            aMatrix = np.array(cmds.getAttr(aMatrix), dtype='float64').reshape(4,4)
        else:
            aMatrix = np.array(cmds.xform(aMatrix, q=True, m=True, ws=True), dtype='float64').reshape(4, 4)
    elif isinstance(aMatrix, (list,tuple)):
        aMatrix = np.array(aMatrix, dtype='float64').reshape(4, 4)
    if len(fVector) < 4:
        aVector = np.array([0,0,0,1], dtype='float64')
        aVector[:len(fVector)] = fVector
    else:
        aVector = np.array(list(fVector), dtype='float64')

    if bInverseMatrix:
        aMatrix = np.linalg.inv(aMatrix)

    aDot = np.dot(aVector, aMatrix)[:3]

    if bReturnNumpy:
        return aDot
    else:
        return list(aDot)


def pointPositionsMatch(aPointsA, aPointsB):
    aDiffs = abs(aPointsA - aPointsB)
    aChangedIds = np.where(aDiffs > 0.01)[0]
    if len(aChangedIds):
        return False
    else:
        return True



def multiplyPositionByMatrix3(fVector, aMatrix, bInverseMatrix=False, bReturnNumpy=False):

    if isStringOrUnicode(aMatrix):
        aMatrix = np.array(cmds.xform(aMatrix, q=True, m=True, ws=True), dtype='float64').reshape(4,4)
        aMatrix = aMatrix[:3,:3]

    if bInverseMatrix:
        aMatrix = np.linalg.inv(aMatrix)

    aVector = np.array(list(fVector), dtype='float64')
    aDot = np.dot(aVector, aMatrix)

    if bReturnNumpy:
        return aDot
    else:
        return list(aDot)


def getUniqueName(sName, bRemoveIllegalCharacters=True):

    if bRemoveIllegalCharacters:
        sName = sName.replace("'", "")

    if not cmds.objExists(sName):
        return sName

    sName, iNumber = getNumberAtEnd(sName)
    while True:
        iNumber += 1
        sNewName = '%s%d' % (sName, iNumber)
        if not cmds.objExists(sNewName):
            return sNewName


def getUniqueNameFromList(sName, sList, bRemoveIllegalCharacters=True, bCheckCapitalEnding=False):

    if bRemoveIllegalCharacters:
        sName = sName.replace("'", "")

    sList = set(sList)
    if sName not in sList:
        return sName

    if bCheckCapitalEnding:
        sBaseName, sEnding = capitalEnding(sName)
        if len(sEnding):
            iNumber = getNumberFromLetters(sEnding)
            for iNewNumber in range(iNumber + 1, iNumber + 2001, 1):
                sNewName = '%s%s' % (sBaseName, getLettersFromNumber(iNewNumber, bUpper=True, iMinCount=len(sEnding)))
                if sNewName not in sList:
                    return sNewName

    sBaseName, iOffset = getNumberAtEnd(sName)
    iNumberLetterCount = len(sBaseName) - len(sBaseName)
    for iNewNumber in range(iOffset + 1, iOffset + 2001, 1):
        sNewName = ('%s' + '%0' + str(iNumberLetterCount) + 'd') % (sBaseName, iNewNumber)
        if sNewName not in sList:
            return sNewName


# fixed recently! this was a strange try/except solution instead of the settable flag
def _getAnimAttrsFromNode(sCtrl):
    sAttrs = cmds.listAttr(sCtrl, keyable=False, channelBox=True, scalar=True, visible=True, leaf=True) or []
    sAttrs += cmds.listAttr(sCtrl, keyable=True, scalar=True, visible=True, leaf=True) or []

    dAttrs = {}
    for sAttr in sAttrs:
        sFullAttr = '%s.%s' % (sCtrl, sAttr)
        if cmds.objExists(sFullAttr):
            if cmds.getAttr(sFullAttr, settable=True):
                dAttrs[sAttr] = cmds.getAttr(sFullAttr)

    return dAttrs


def getAnimNode(sAttr):
    sConnectedNodes = cmds.listConnections(sAttr, s=True, d=False)
    if sConnectedNodes and cmds.objectType(sConnectedNodes).startswith('animCurve'):
        return sConnectedNodes[0]
    else:
        return None


def searchReplaceFile(sFile, sSearch, sReplace):
    with open(sFile, 'r') as file:
        filedata = file.read()

    filedata = filedata.replace(sSearch, sReplace)

    with open(sFile, 'w') as file:
        file.write(filedata)


def getLineNumber(sFile, sString):
    with open(sFile) as myFile:
        sAllLines = list(myFile)

    for i, sLine in enumerate(sAllLines):
        if sString in sLine:
            return i

    return -1


def createFolderIfNotExists(sFile):
    sDir = os.path.dirname(sFile)
    if not os.path.exists(sDir):
        os.makedirs(sDir)


def readTextGridFile(sFile):

    with open(sFile) as myFile:
        sAllLines = list(myFile)

    dCurrentDict = {}
    dStartDict = dCurrentDict
    xItems = []
    dStartDict['items'] = xItems

    for sLine in sAllLines:
        sLine = sLine.replace('\n', '')
        if sLine.startswith('	item ['):
            dCurrentDict = {}
            xItems.append(dCurrentDict)
            xIntervals = []
            dCurrentDict['intervals'] = xIntervals
        elif ' = ' in sLine:
            sLineSplits = sLine.split(' = ')
            sValue = sLineSplits[1].replace('"','')
            try:
                xValue = float(sValue)
            except:
                xValue = sValue
            dCurrentDict[sLineSplits[0].replace('\t','')] = xValue
        elif sLine.startswith('\t\t\tintervals ['):
            dCurrentDict = {}
            xIntervals.append(dCurrentDict)

    return dStartDict



def getDefaultAttrValue(sAttr):
    sCtrl, sA = sAttr.split('.')
    sDefaultAttribute = '%s.dDefaultAttrs' % sCtrl
    if cmds.objExists(sDefaultAttribute):
        dDefaultAttrs = eval(cmds.getAttr(sDefaultAttribute))
    else:
        raise Exception('attribute %s doesn\'t exist' % sDefaultAttribute)

    sAttrName = sA
    if sAttrName not in dDefaultAttrs:
        raise Exception('default attribute "%s" missing on ctrl "%s"' % (sAttrName, sCtrl))
    return dDefaultAttrs[sAttrName]


def getGitHash():
    result = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=getScriptsDir())
    return result.split('\n')[-2]


def namespacifyClashingNode(sNode, sNamespace):
    sSplits = sNode.split('|')

    sSplits2 = ['%s%s' % (sNamespace,sN) for sN in sSplits]
    sNamespacedNode = '|'.join(sSplits2)
    return sNamespacedNode



sMayaImportExtensions = ['.ma', '.MA', '.mb', '.MB', '.obj', '.OBJ', '.fbx', '.FBX', '.ma']

def importMayaFiles(sFiles, sNamespace=None, bReference=False, _report=None, bReturnAllNodes=False):
    import kangarooTools.xforms as xforms

    sBefore = cmds.ls(dag=True)

    for sFile in toList(sFiles):
        if _report:
            _report.addLogText('importing file: %s' % sFile)
            _report.incrementProgress()

        if not os.path.isfile(sFile):
            cmds.warning('skipping file, because it doesn\'t exist: %s' % sFile)
            if _report: _report.addLogText('skipping, doesn\'t exist')
            continue

        if sFile.endswith('.mb'):
            sType = 'mayaBinary'
        elif sFile.endswith('.ma'):
            sType = 'mayaAscii'
        elif sFile.endswith('obj') or sFile.endswith('OBJ'):
            sType = 'OBJ'
        elif sFile.endswith('fbx') or sFile.endswith('FBX'):
            sType = 'FBX'
        elif sFile.endswith('abc'):
            sType = 'Alembic'
        elif sFile.endswith('usd') or sFile.endswith('USD'):
            sType = 'USD Import'
        else:
            raise Exception('unknown file ending: %s' % sFile)
        print('\n\n\nTYPE: ', sType)

        try:
            if sType == 'FBX':
                print('sFile: ', sFile)
                sPreviousBlendShapes = cmds.ls(et='blendShape')
                mel.eval('FBXImport -f "%s"' % sFile.replace('\\', '/'))
                sBlendShapes = set(cmds.ls(et='blendShape')) - set(sPreviousBlendShapes)
                for sBs in sBlendShapes:
                    sConns = cmds.listConnections('%s.inputTarget' % sBs, s=True, d=False)
                    if sConns: cmds.delete(sConns)
            else:
                print ('now import ', sFile)
                if bReference:
                    if sNamespace:
                        cmds.file(sFile, r=True, type=sType, namespace=sNamespace, ignoreVersion=True, prompt=False, loadReferenceDepth='topOnly')
                    else:
                        cmds.file(sFile, r=True, type=sType, namespace=':', ignoreVersion=True, prompt=False, loadReferenceDepth='topOnly')
                else:
                    if sNamespace:
                        cmds.file(sFile, i=True, type=sType, namespace=sNamespace, ignoreVersion=True, prompt=False, loadReferenceDepth='none')
                    else:
                        cmds.file(sFile, i=True, type=sType, ignoreVersion=True, prompt=False, loadReferenceDepth='none')
        except Exception as e:
            cmds.warning('errors happened when importing: %s' % e)
    sAfter = cmds.ls(dag=True)
    sNewNodes = list(set(sAfter) - set(sBefore))


    sRoots = xforms.getRoots(sNewNodes)
    if not bReference:
        for sRoot in sRoots:
            print ('adding attr to "%s"...' % sRoot)
            try:
                addStringAttr(sRoot, 'sImportedFrom', os.path.basename(sFile))
            except Exception as e:
                print ('skipping adding attribute - %s' % str(e))

    if bReturnAllNodes:
        return sNewNodes
    else:
        return sRoots


def getDictFromPickleOrNumpyFile(sFilepath):
    if sFilepath.endswith('.npz'):
        print ('trying to load: ', sFilepath)
        loadedDict = np.load(sFilepath, allow_pickle=True)
    else: # old
        iPythonVersion = getPythonVersion()
        with open(sFilepath, 'rb') as handle:
            if iPythonVersion == 2:
                loadedDict = pickle.load(handle)
            elif iPythonVersion == 3:
                loadedDict = pickle.load(handle, encoding='latin1')
    return loadedDict


def encodeAudioLipsString(sString):
    sList = ['%d' % ((ord(sStr)+1055)*3) for sStr in sString]
    return '('.join(sList)


def decodeAudioLipsString(sString):
    print('decoding string: ', sString)
    iList = [int(sStr)/3-1055 for sStr in sString.split('(')]
    print('iList: ', iList)
    return ''.join([chr(iStr) for iStr in iList])


def createDictFromDecodedAudioLipsString(sString):
    sDecoded = decodeAudioLipsString(sString)
    dDict = {}
    for sSp in sDecoded.replace(' ','').split('/'):
        sSplitsB = sSp.split('?')
        dDict[sSplitsB[0]] = [float(a) for a in sSplitsB[1:]]
    return dDict


kNoneString = '<None>'
kCustomString = '<Custom>'


def combineOutputInfo(sLimb, sOutput, sAttrName, fWeight):
    return '@'.join([sLimb, sOutput, sAttrName, '%0.3f' % fWeight])


def extractOutputInfo(sOutput, iIndex=0):

    sOutputSplitted = tempOutputSplit(sOutput)
    sOutputLimb, sOutputName = sOutputSplitted[0:2]
    if len(sOutputSplitted) > 2:
        sOutputAttrName = sOutputSplitted[2]
    else:
        sOutputAttrName = sOutputLimb.split('_')[-1]

    if len(sOutputSplitted) > 3:
        if sOutputSplitted[3]:
            fDefaultWeight = float(sOutputSplitted[3])
        else:
            fDefaultWeight = -1
    else:
        fDefaultWeight = 1.0 if iIndex == 0 else 0.0


    return sOutputLimb, sOutputName, sOutputAttrName, fDefaultWeight


# should get rid of this, onces it's all converted to @ instead of __ or .
def tempOutputSplit(sOutput):
    if '@' in sOutput:
        sOutputSplitted = sOutput.split('@')
    elif '__' in sOutput:
        sOutputSplitted = sOutput.split('__')
    else:
        sOutputSplitted = sOutput.split('.')
    return sOutputSplitted



def getZeroJoint(sModulesGrp='modules'):
    sSuffix = sModulesGrp[len('modules'):]
    sJoint = 'jnt_m_zero%s' % sSuffix
    if not cmds.objExists(sJoint):
        cmds.createNode('joint', n=sJoint, p=sModulesGrp)
    else:
        parentTo(sJoint, sModulesGrp)

    return sJoint


def getMasterName(sRigNamespace=''):
    for sMaster in ['master', 'Rig_Grp']:
        if cmds.objExists(sMaster):
            return sMaster


def getModulesOfType(sModuleType='LFinger'):
    sModules = [sGrp for sGrp in cmds.listRelatives('modules', c=True) if 'Module' in sGrp]
    sReturnTypes = []
    for sM in sModules:
        sClassTypeAttr = '%s.sClassType' % sM
        if cmds.objExists(sClassTypeAttr) and cmds.getAttr(sClassTypeAttr) == sModuleType:
            sReturnTypes.append(sM)
    return sReturnTypes


def isNone(xVariable):
    return isinstance(xVariable, type(None))


def translateCtrlName(sCtrlName):
    if sCtrlName.endswith('_ctrl') or sCtrlName.endswith('_Ctrl'):
        return sCtrlName
    else:
        sSplits = sCtrlName.split('_')
        sSide = sSplits[1]
        if sSide == 'l':
            sSideName = 'LFT'
        elif sSide == 'r':
            sSideName = 'RGT'
        else:
            sSideName = ''

        return '%s%s_ctrl' % ('_'.join(sSplits[2:]), sSideName)
    # else:
    #     if sCtrlName.endswith('_ctrl'):
    #         raise Exception, 'not supported yet (%s, converting to normal' % sCtrlName
    #     else:
    #         return sCtrlName

def parentToWorld(sObj):
    if not isNone(cmds.listRelatives(sObj, p=True)):
        cmds.parent(sObj, w=True)


def parentTo(sObjs, sParent):
    for sObj in toList(sObjs):
        sParents = cmds.listRelatives(sObj, p=True, c=False)
        if sParents and sParents[0] == sParent:
            continue
        else:
            try:
                cmds.parent(sObj, sParent)
            except Exception as e:
                raise Exception('Error trying to parent: %s' % e)


def stringOrListToObjects(sString):
    sObjects = []
    for sStr in toList(sString):
        sObjects += cmds.ls(sStr)
    return sObjects



def getFrameRate():
    sQueried = cmds.currentUnit(q=True, t=True)
    dFrameRates = {'game': 15, 'film': 24, 'pal': 25, 'ntsc': 30, 'show': 48, 'palf': 50, 'ntscf': 60}

    if sQueried in dFrameRates:
        fFramesPerSecond = float(dFrameRates[sQueried])
    elif sQueried.endswith('fps'):
        sFramesPerSecond = sQueried[:-3]
        fFramesPerSecond = float(sFramesPerSecond)
    else:
        raise Exception('unrecognized frame rate: %s' % sQueried)

    fFrameLength = 1.0 / fFramesPerSecond
    return fFramesPerSecond, fFrameLength


def printSelectedList(bCopyToClipBoard=False):
    sList = cmds.ls(sl=True)
    sPrint = '[%s]' % ', '.join(["'%s'" % sO for sO in sList])
    print(sPrint)
    if bCopyToClipBoard:
        copyToClipBoard(sPrint)


def extendMirrorList(sList):
    sMirrorList = []
    for sO in sList:
        sMirrorO = getMirrorName(sO)
        if sMirrorO != sO and cmds.objExists(sMirrorO):
            sMirrorList.append(sMirrorO)

    return sList + sMirrorList


def flattenedList(ssList):
    def _flattenREC(xObj, xResultList):
        if isinstance(xObj, (list,tuple,np.ndarray)):
            for sO in xObj:
                _flattenREC(sO, xResultList)
        else:
            xResultList.append(xObj)
    sReturnList = []
    _flattenREC(ssList, sReturnList)
    return sReturnList


def capitalEnding(sString):
    for i in range(len(sString)):
        sEnding = (sString[len(sString) - i - 1:])
        if not sEnding.isupper():
            sEnding = sEnding[1:]
            sName = sString[:len(sString)-len(sEnding)]
            break
    return sName, sEnding


def getLettersFromNumber(iNumber, bUpper=True, iMinCount=0):
    sLetters = []
    for i in range(5):
        sLetters.append(string.ascii_lowercase[iNumber % 26])
        iNumber //= 26
        if iNumber == 0:
            break

    sSequence = ''.join(sLetters[::-1])
    if iMinCount > len(sSequence):
        sSequence = '%s%s' % ('a' * (iMinCount-len(sSequence)), sSequence)

    if bUpper:
        sSequence = sSequence.upper()

    return sSequence


def copyToClipBoard(sText):
    import kangarooTools.clipboard
    kangarooTools.clipboard.put(sText)


def getFromClipBoard():
    import kangarooTools.clipboard
    return kangarooTools.clipboard.get()



def getLetter(iIndex):
    return string.ascii_uppercase[iIndex]



def getDuplicates(xList):
    xDuplicates = [item for item, count in list(Counter(xList).items()) if count > 1]
    return xDuplicates


def anyExists(sList):
    for sO in sList:
        if cmds.objExists(sO):
            return True




def getShadersFromSelection():
    # get shapes of selection:
    shapesInSel = cmds.ls(dag=1, o=1, s=1, sl=1)
    # get shading groups from shapes:
    shadingGrps = cmds.listConnections(shapesInSel, type='shadingEngine')
    # get the shaders:
    shaders = cmds.ls(cmds.listConnections(shadingGrps), materials=1)
    return shaders


def addListKey(dDict, sKey):
    if sKey not in dDict:
        dDict[sKey] = []


def getVersionFromName(sName):
    sSplits = sName.split('_')
    sVersionString = sSplits[-1].split('.')[0]
    if sVersionString.startswith('workv'):
        sVersion = sVersionString[5:]
    elif sVersionString.startswith('v'):
        sVersion = sVersionString[1:]
    else:
        return -1

    try:
        iVersion = int(sVersion)
        return iVersion
    except:
        return -1


def sortFilesByVersions(sFiles):
    dVersions = {sF: getVersionFromName(sF.split('_')[0]) for sF in sFiles}
    sFiles.sort(key=lambda a: dVersions[a], reverse=True)
    return sFiles



def getNamespace(sObj):
    sSplits = sObj.split('.')[0].split(':')
    if len(sSplits) <= 1:
        return ''
    else:
        return '%s:' % ':'.join(sSplits[:-1])


def splitNamespace(sObj):
    if ':' not in sObj:
        return '', sObj
    else:
        sSplits = sObj.split(':')
        sNamespace = '%s:' % ':'.join(sSplits[:-1])
        return sNamespace, sSplits[-1]


def createOrderedDictWithInsertedAtIndex(dDict, xPair, iIndex=0):
    if iIndex >= len(dDict):
        raise Exception('iIndex out of range (%d -> %d)' % (iIndex, len(dDict)))

    i = 0
    dNewDict = OrderedDict()
    for a, b in list(dDict.items()):
        if iIndex == i:
            dNewDict[xPair[0]] = xPair[1]
        dNewDict[a] = b
        i += 1

    return dNewDict



def hasNonZeroValues(fList, fThreshhold=0.001):
    for fO in fList:
        if abs(fO) > fThreshhold:
            return True
    return False


iDoDebugPrint = 0
def toggleDebugPrint(bMessageBox=True, bStrong=False):
    global iDoDebugPrint
    if iDoDebugPrint == 0:
        iDoDebugPrint = 2 if bStrong else 1
    else:
        iDoDebugPrint = 0

    print ('iDoDebugPrint is %s' % iDoDebugPrint)
    if bMessageBox:
        cmds.confirmDialog(m='iDoDebugPrint is now: %s' % (str(iDoDebugPrint) if iDoDebugPrint else 'OFF'))



def debugPrint(*sMessage):
    global iDoDebugPrint
    if iDoDebugPrint != 0:
        print (' '.join([str(sM) for sM in sMessage]))


def debugPrintStrong(*sMessage):
    global iDoDebugPrint
    if iDoDebugPrint == 2:
        print (' '.join([str(sM) for sM in sMessage]))




def saveBackupFile(sFilePath, sFolderName='_backup'):
    # now save it
    sBackupBuildDir = os.path.join(os.path.dirname(sFilePath), sFolderName)

    if not os.path.exists(sBackupBuildDir):
        os.makedirs(sBackupBuildDir)

    xCurrentBackups = []
    for sContent in os.listdir(sBackupBuildDir):
        sContentName = sContent.split('.')[0]
        if sContentName.count('_') == 1:
            sSep = sContentName.rfind('_')
            sFile, sTime = sContentName[:sSep], sContentName[sSep+1:]
            # sFile, sTime = sContentName.split('_')
            iTime = int(sTime)
            xCurrentBackups.append([sContent, iTime])

    xCurrentBackups = sorted(xCurrentBackups, key=lambda x:x[1], reverse=True)

    iMaxFiles = 20
    if len(xCurrentBackups) > iMaxFiles:
        for sContent, _ in xCurrentBackups[iMaxFiles:]:
            sFile = os.path.join(sBackupBuildDir, sContent)
            os.remove(sFile)


    sFilenameSplits = os.path.basename(sFilePath).split('.')
    sBackupFileName = '%s_%d.%s' % (sFilenameSplits[0], int(time.time()), sFilenameSplits[1])
    sBackupBuildFile = os.path.join(sBackupBuildDir, sBackupFileName) #'build_%d.bld' % int(time.time()))
    shutil.copy(sFilePath, sBackupBuildFile)





# an alternative to cmds.setAttr() - might be more elegant but would need cmdsUndo to support it
def setPlugWeights(sAttr, fWeights):
    mSelectionList = OpenMaya2.MSelectionList()
    mSelectionList.add(sAttr)
    mPlug = mSelectionList.getPlug(0)

    for i in range(len(fWeights)):
        mPlug.elementByLogicalIndex(i).setFloat(fWeights[i])




def replaceTextureNodes(sSearch=r'D:\Megascans Library', sReplace=r'C:\projectsRoot\sven\handover\Megascans Library'):
    sNodes = cmds.ls(et='file')

    sSearch = sSearch.replace('\\','/')
    sReplace = sReplace.replace('\\','/')

    for sN in sNodes:
        sFile = cmds.getAttr('%s.fileTextureName' % sN).replace('\\','/')

        if sSearch in sFile:
            sNewFile = sFile.replace(sSearch, sReplace)
            print('replacing path of "%s"...' % sN)
            cmds.setAttr('%s.fileTextureName' % sN, sNewFile, type='string')


def removeDuplicatesKeepOrder(sList):
    seen = set()
    seen_add = seen.add
    return [x for x in sList if not (x in seen or seen_add(x))]


def openPycharm(sFilePath, iLine=None):
    import kangarooTools.settings as settings
    sPycharm = settings.getSettingsFileEntry('sPycharmExePath').strip('"')

    if not isNone(sPycharm) and os.path.exists(sPycharm.strip()):
        sPycharm = sPycharm.strip()

        sFilePath = os.path.normpath(sFilePath)

        if iLine == None:
            sPassArguments = [sPycharm, sFilePath]
        else:
            sPassArguments = [sPycharm, '--line', '%03d' % (iLine), sFilePath]

        subprocess.Popen(sPassArguments)#, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    else: # try notepad++
        print('Pycharm.exe not ("%s") found. Trying notepad++ instead' % sPycharm)
        sPassArguments = [r"C:/Program Files/Notepad++/notepad++.exe", sFilePath, '-n%d' % iLine]
        subprocess.Popen(sPassArguments) #, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)



def getFilteredFromAvoidIndices(iOriginalLength, iSkipUnitCount=2, bForceKeepEnds=False):
    iMiddle = iOriginalLength // 2
    a = np.arange(iMiddle - 1 - iSkipUnitCount, -1, -iSkipUnitCount - 1)[::-1]
    b = [iMiddle]
    c = np.arange(iMiddle + 1 + iSkipUnitCount, iOriginalLength, iSkipUnitCount + 1)

    if bForceKeepEnds:
        if 0 not in a:
            a = np.concatenate([[0], a])
        if iOriginalLength-1 not in c:
            c = np.concatenate([c, [iOriginalLength-1]])
    return np.concatenate([a, b, c])


def undoUntilBreak():
    while True:
        try:
            cmds.undo()
        except:
            break


def flushUndo():
    cmds.flushUndo()
    import kangarooTools.utilsQt as utilsQt
    utilsQt.showFadingText('Undo Queue Emptied')


def toggleEval():
    import kangarooTools.utilsQt as utilsQt

    sCurrentEval = cmds.evaluationManager(q=True, mode=True)[0]
    if sCurrentEval != 'parallel':
        cmds.evaluationManager(mode='parallel')
        utilsQt.showFadingText('Swithced to Parallel')
    else:
        cmds.evaluationManager(mode='off')
        utilsQt.showFadingText('Swithced to Off')


def _connectOrSet(xValue, sAttr, bForce=False):
    if isinstance(xValue, (list, tuple, np.ndarray)) and len(xValue) == 16:
        sHoldMatrix = cmds.createNode('holdMatrix')
        cmds.setAttr('%s.inMatrix' % sHoldMatrix, xValue, type='matrix')
        cmds.connectAttr('%s.outMatrix' % sHoldMatrix, sAttr)
    else:
        try:
            fValue = float(xValue)
        except:
            fValue = None

        if fValue != None:
            cmds.setAttr(sAttr, fValue)
        else:
            cmds.connectAttr(xValue, sAttr, f=bForce)







def addAttr(*args, **kwargs):

    try:
        bReturnIfExists = kwargs['bReturnIfExists']
        del kwargs['bReturnIfExists']
    except:
        bReturnIfExists = False

    try:
        bCb = kwargs['cb']
        del kwargs['cb']
    except:
        bCb = False

    try:
        sTarget = kwargs['sTarget']
        del kwargs['sTarget']
    except:
        sTarget = None

    try:
        sConnect = kwargs['sConnect']
        del kwargs['sConnect']
    except:
        sConnect = None

    try:
        bLock = kwargs['bLock']
        del kwargs['bLock']
    except:
        bLock = False

    try:
        sAddSidePostFix = kwargs['sAddSidePostFix']
        del kwargs['sAddSidePostFix']
    except:
        sAddSidePostFix = None
    if sAddSidePostFix != None:
        sLn = kwargs['ln']
        if sAddSidePostFix.startswith('l'):
            sLn = '%sLeft' % sLn
        elif sAddSidePostFix.startswith('r'):
            sLn = '%sRight' % sLn
        elif sAddSidePostFix.startswith('m'):
            sLn = '%sMiddle' % sLn
        else:
            raise Exception('don\'t recognize what side "%s" is' % sAddSidePostFix)
        kwargs['ln'] = sLn

    sAttr = '%s.%s' % (args[0], kwargs['ln'])
    if cmds.objExists(sAttr):
        if bReturnIfExists:
            return sAttr
        else:
            raise Exception('attribute %s already exists!' % sAttr)

    try:
        fMultipl = kwargs['fMultipl']
        del kwargs['fMultipl']
    except:
        fMultipl = None


    cmds.addAttr(*args, **kwargs)

    if kwargs.get('at', 'double').endswith('3'):
        kChildrenArgs = dict(kwargs)
        sAttrName = kwargs['ln']
        kChildrenArgs['at'] = kwargs['at'][:-1]
        kChildrenArgs['p'] = sAttrName
        for i in range(3):
            kChildrenArgs['ln'] = '%s%s' % (sAttrName, ['X','Y','Z'][i])
            cmds.addAttr(*args, **kChildrenArgs)

    if bCb:
        cmds.setAttr(sAttr, cb=True)

    if sTarget:
        _connectTarget(sAttr, sTarget)

    if not isNone(sConnect):
        _connectOrSet(sConnect, sAttr, bForce=True)

    if bLock:
        cmds.setAttr(sAttr, lock=True)

    if fMultipl:
        sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True)
        cmds.connectAttr(sAttr, '%s.input1X' % sMultipl)
        cmds.setAttr('%s.input2X' % sMultipl, fMultipl)
        return '%s.%s' % (sMultipl, 'outputX')
    else:
        return sAttr



def _connectTarget(sOutput, sTarget, bForce=False):
    if sTarget == None:
        return
    sTargets = toList(sTarget)
    for Ts in sTargets:
        cmds.connectAttr(sOutput, Ts, force=bForce)


def _connectTargetIfNotNone(sTarget, sOutput, bForce=False):
    if sTarget:
        if isinstance(sTarget, list):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT)
        else:
            cmds.connectAttr(sOutput, sTarget, force=bForce)



def lockAndHide(sObj, sAttrs=[]):
    for sAttr in sAttrs:
        cmds.setAttr('%s.%s' % (sObj, sAttr), lock=True, keyable=False, channelBox=False)


def getSelectedChannelBoxAttributes():
    '''
    TODO: make it work for other than just attributes on main nodes
    '''
    sAttrs = cmds.channelBox('mainChannelBox', q=True, sma=True) or []
    sAttrs += cmds.channelBox('mainChannelBox', q=True, ssa=True) or []
    # sAttrs += cmd.channelBox('mainChannelBox', q=True, sha=True)
    return sAttrs


def roundValueOrList(fValue, bDigits=3):
    print ('fValue: ', fValue)
    if isinstance(fValue, (list, tuple)):
        return [round(fV, bDigits) for fV in fValue]
    else:
        return round(fValue, bDigits)


def clipBoardSetAttrCommands():
    sSelection = cmds.ls(sl=True)
    sChannelAttrs = set(getSelectedChannelBoxAttributes())
    sAttrs = []
    sLines = []

    for sTrs in 'trs':
        sThreeAttrs = set(['%sx' % sTrs, '%sy' % sTrs, '%sz' % sTrs])
        if len(sChannelAttrs.intersection(sThreeAttrs)) == 3:
            sChannelAttrs -= sThreeAttrs
            sAttrs.append(sTrs)
    for sA in sChannelAttrs:
        sAttrs.append(sA)

    if sSelection and sAttrs:
        for sObj in sSelection:
            for sAttr in sAttrs:
                sFullAttr = '%s.%s' % (sObj, sAttr)
                if cmds.objExists(sFullAttr): # it might not exist if more objects with different attributes are selected
                    fValue = cmds.getAttr(sFullAttr)
                    if isinstance(fValue, (list,tuple)):
                        sValue = ', '.join([str(fV) for fV in roundValueOrList(fValue[0])])
                        sLines.append(f"cmds.setAttr('{sFullAttr}', {sValue})")
                    else:
                        sLines.append(f"cmds.setAttr('{sFullAttr}', {fValue})")

    for sLine in sLines:
        print (sLine)
    copyToClipBoard('\n'.join(sLines))



def addOffOnAttr(sNode, sAttr, bDefaultValue=True, bLock=False, bReturnNonIfExists=False, bReturnIfExists=False, sTarget=[], bNoAnim=False, bForce=False, bChannelBox=True):
    if bReturnNonIfExists and cmds.objExists('%s.%s' % (sNode,sAttr)):
        return None
    elif bReturnIfExists and cmds.objExists('%s.%s' % (sNode,sAttr)):
        sAttr = '%s.%s' % (sNode,sAttr)
    else:
        sAttr = addAttr(sNode, ln=sAttr, at='enum', en='Off:On', defaultValue=bDefaultValue, k=False if bNoAnim else True, cb=bChannelBox)
        if bLock:
            cmds.setAttr(sAttr, lock=True)

    for sT in toList(sTarget):
        try:
            cmds.connectAttr(sAttr, sT, force=bForce)
        except:
            raise Exception('Cannot connect %s -> %s' % (sAttr, sT))
    return sAttr


def addStringAttr(sGrp, sAttr, sText, bLock=False, bSkipIfAlreadyThere=False):
    if bSkipIfAlreadyThere and cmds.attributeQuery(sAttr, node=sGrp, exists=True):
        return '%s.%s' % (sGrp, sAttr)
    sAttr = addAttr(sGrp, ln=sAttr, dt='string', k=False, bReturnIfExists=True)
    bLockedBefore = cmds.getAttr(sAttr, lock=True)
    cmds.setAttr(sAttr, q=True, lock=False)
    cmds.setAttr(sAttr, sText, type='string')
    if bLockedBefore or bLock: cmds.setAttr(sAttr, lock=True)
    return sAttr


def transferStringAttr(sFromAttr, sToObj, bErrorIfNotExists=True):
    if not cmds.objExists(sFromAttr):
        if bErrorIfNotExists:
            raise Exception('attribute doesn\'t exist: %s' % sFromAttr)
        else:
            return None

    addStringAttr(sToObj, sFromAttr.split('.')[-1], cmds.getAttr(sFromAttr))



def getStringAttr(sGrp, sAttr, sDefault, bCreateIfNotExists=False):
    sFullAttr = '%s.%s' % (sGrp, sAttr)
    if cmds.objExists(sFullAttr):
        return cmds.getAttr(sFullAttr)
    else:
        if bCreateIfNotExists:
            addStringAttr(sGrp, sAttr, sDefault, bLock=True)
        return sDefault


def addToListStringAttr(sGrp, sAttr, sAdd=[], bLock=False):
    sCurrent = eval(getStringAttr(sGrp, sAttr, '[]'))
    addStringAttr(sGrp, sAttr, sCurrent+sAdd, bLock=bLock)


def updateDictStringAttr(sGrp, sAttr, dUpdate={}, bLock=False):
    dCurrent = eval(getStringAttr(sGrp, sAttr, '{}'))
    dCurrent.update(dUpdate)
    addStringAttr(sGrp, sAttr, str(dCurrent), bLock=bLock)


def deleteDictKeys(sGrp, sAttr, sKeys, bLock=False):
    dCurrent = eval(getStringAttr(sGrp, sAttr, '{}'))
    for sKey in toList(sKeys):
        if sKey in dCurrent:
            del dCurrent[sKey]
    addStringAttr(sGrp, sAttr, str(dCurrent), bLock=bLock)






kGeneralDataNode = '__generalData__'
kExportNode = '__export__'
kBodyDataNode = '__bodyData__'
kFaceDataNode = '__faceData__'
kCostumeDataNode = '__costumeData__'
# kPosesDataNode = '__posesData__'
kSkipKeyImportAttrs = 'sSkipKeyImportAttrs'

kIgnoreAttachTargetsAttr = 'ignoreAttachTargets'

class data:

    @staticmethod
    def store(sAttr, xValue, sNode=kGeneralDataNode):
        if not cmds.objExists(sNode):
            sSelBefore = cmds.ls(sl=True)
            cmds.createNode('transform', n=sNode)
            cmds.select(sSelBefore)

        sAttrName = '%s.%s' % (sNode,sAttr)
        if not cmds.objExists(sAttrName):
            addAttr(sNode, ln=sAttr, dt='string', k=False)

        sValue = str(xValue).replace('array', 'np.array')
        cmds.setAttr(sAttrName, sValue, type='string')


    @staticmethod
    def exists(sAttr, sNode='__generalData__'):
        if cmds.objExists('%s.%s' % (sNode, sAttr)):
            return True
        else:
            return False


    @staticmethod
    def get(sAttr, sNode='__generalData__', xDefault=None, bForceString=False):
        sAttr = '%s.%s' % (sNode, sAttr)
        if cmds.objExists(sAttr):
            sValue = cmds.getAttr(sAttr)
            if bForceString:
                return sValue
            else:
                return evalValueFromString(sValue)
        else:
            return xDefault

    @staticmethod
    def addToList(sAttr, sList, sNode = '__generalData__'):
        sAttrName = '%s.%s' % (sNode, sAttr)
        if cmds.objExists(sAttrName):
            sValue = cmds.getAttr(sAttrName)
            sCurrentList = evalValueFromString(sValue)
            if not isinstance(sCurrentList, list):
                raise Exception('the value of %s is not a list (%s)' % (sAttrName, sValue))
        else:
            sCurrentList = []

        sCurrentList += sList
        data.store(sAttr, sCurrentList, sNode=sNode)


    @staticmethod
    def updateDict(sAttr, dDict, sNode = '__generalData__'):
        sAttrName = '%s.%s' % (sNode, sAttr)
        if cmds.objExists(sAttrName):
            sValue = cmds.getAttr(sAttrName)
            dCurrentDict = evalValueFromString(sValue)
            if not isinstance(dCurrentDict, dict):
                raise Exception('the value of %s is not a list (%s)' % (sAttrName, sValue))
        else:
            dCurrentDict = {}

        dCurrentDict.update(dDict)
        data.store(sAttr, dCurrentDict, sNode=sNode)

    @staticmethod
    def addToDict(sAttr, sKey, xItem, sNode = '__generalData__'):
        sAttrName = '%s.%s' % (sNode, sAttr)
        if cmds.objExists(sAttrName):
            sValue = cmds.getAttr(sAttrName)
            dCurrentDict = evalValueFromString(sValue)
            if not isinstance(dCurrentDict, dict):
                raise Exception('the value of %s is not a dict (%s)' % (sAttrName, sValue))
        else:
            dCurrentDict = {}

        dCurrentDict[sKey] = xItem
        data.store(sAttr, dCurrentDict, sNode=sNode)




def camelToChain(sString):
    sChainedString = re.sub(r'(?<!^)(?=[A-Z])', '_', sString).lower()
    return sChainedString

def chainToCamel(sString):
    sCamel = ''.join([getFirstLetterUpperCase(sStr) for sStr in sString.split('_')])
    return sCamel


def getFfMpegExe():
    sFfmpeg = os.path.join(os.path.dirname(__file__), os.pardir, 'kangarooAnimation/ffmpeg.exe').replace('\\', '/')
    if os.path.exists(sFfmpeg):
        return os.path.normpath(sFfmpeg)

    sFfmpeg = os.path.join(os.path.dirname(__file__), os.pardir, 'kangarooAnimation/ffmpeg/bin/ffmpeg.exe').replace('\\', '/')
    if os.path.exists(sFfmpeg):
        return os.path.normpath(sFfmpeg)

    raise Exception('ffmpeg.exe not found, please check https://kangaroobuilder.com/animationTools/#mp4-playblast for how to install.')


def ffMpegCodex(sInputFile, sOutputFile):
    sFfmpeg = getFfMpegExe()
    print ('found %s' % sFfmpeg)
    sPassArguments = [sFfmpeg, '-y', '-i', sInputFile, '-vf', 'pad=ceil(iw/2)*2:ceil(ih/2)*2', '-pix_fmt', 'yuv420p', '-max_muxing_queue_size', '9999', sOutputFile]
    mpegProcess = subprocess.Popen(sPassArguments, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    sResult = mpegProcess.communicate()
    print(sResult[0])
    print(sResult[1])



def connectPosesLocVis(sLocs):
    sMaster = getMasterName()
    if sMaster and cmds.objExists(sMaster):
        sVisAttr = addOffOnAttr(sMaster, 'posesLocVIS', bDefaultValue=True, bReturnIfExists=True)
        for sLoc in toList(sLocs):
            sShape = cmds.listRelatives(sLoc, c=True, typ='locator')[0]
            cmds.connectAttr(sVisAttr, '%s.v' % sShape, force=True)


def getCurrentFunctionDatas():
    import kangarooTools.assets as assets
    sBuildFile = assets.getCurrentBuildFile()
    print ('sBuildFile: ', sBuildFile)
    dBuildContent = {} if isNone(sBuildFile) else getJsonContent(sBuildFile)
    dFunctionDatas = dBuildContent.get('__FUNCTIONDATAS__', {})
    return dFunctionDatas


def updateCurrentFunctionDatas(dFunctionDatas):
    import kangarooTools.assets as assets
    sBuildFile = assets.getCurrentBuildFile()
    print ('sBuildFile: ', sBuildFile)
    dBuildContent = {} if isNone(sBuildFile) else getJsonContent(sBuildFile)
    dBuildContent['__FUNCTIONDATAS__'] = dFunctionDatas
    setJsonContent(sBuildFile, dBuildContent)


def getFunctionArg(sFunc, sArg, xDefault=None):
    dAllFunctionDatas = getCurrentFunctionDatas()

    dFunctionDatas = dAllFunctionDatas.get(sFunc, [{}])
    dFunctionData = dFunctionDatas[0]

    dFileArgs = dFunctionData.get('dFileArgs', xDefault)
    return dFileArgs[sArg]


def setFunctionArg(sFunc, sArg, xData):
    dAllFunctionDatas = getCurrentFunctionDatas()

    dFunctionDatas = dAllFunctionDatas.get(sFunc, [{}])
    dFunctionData = dFunctionDatas[0]

    dFileArgs = dFunctionData.get('dFileArgs', {})

    dFileArgs[sArg] = xData

    dFunctionData['dFileArgs'] = dFileArgs
    dFunctionDatas[0] = dFunctionData
    dAllFunctionDatas[sFunc] = dFunctionDatas
    updateCurrentFunctionDatas(dAllFunctionDatas)

    import kangarooTabTools.builder as builder
    builder.refresh()





def getAttrIfExists(sAttr, xDefault):
    if cmds.objExists(sAttr):
        return cmds.getAttr(sAttr)
    else:
        return xDefault




def _emptyFunc():
    pass




def registerRedoAndUndo(funcRedo=None, funcUndo=None):
    dSetUIData = {'funcRedo': _emptyFunc if isNone(funcRedo) else funcRedo,
                  'funcUndo': _emptyFunc if isNone(funcUndo) else funcUndo}
    cmds.kt_cmdUndo(dt=str(id(dSetUIData)))


def isOnOrigin(sNode, fSmallNumber=0.00001):
    fDefault = [0, 0, 0, 0, 0, 0, 1, 1, 1]
    sAttrs = ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']
    _sParent = sNode
    while True:
        for sA, fDef in zip(sAttrs, fDefault):
            fDiff = cmds.getAttr('%s.%s' % (_sParent, sA)) - fDef
            if abs(fDiff) > fSmallNumber:
                return False

        sParents = cmds.listRelatives(_sParent, p=True, c=False, f=True)
        if not sParents:
            break
        else:
            _sParent = sParents[0]

    return True




def getMuscleAttrValue(sMuscle, sAttrName, xDefault=None):
    sAttr = '%s.%s' % (sMuscle, sAttrName)
    if cmds.objExists(sAttr):
        sValue = cmds.getAttr(sAttr)
        if xDefault == None:
            return sValue
        else:
            xType = type(xDefault)
            return xType(sValue)
    else:
        return xDefault


def stringsFromEnumClass(enumClass):
    return [sO for sO in enumClass.__dict__ if not sO.startswith('__')]




def getZeroJoint(sParent='modules'):
    sZeroJoint = 'jnt_m_zero'
    if not cmds.objExists(sZeroJoint):
        cmds.createNode('joint', n=sZeroJoint, p=sParent)
    return sZeroJoint



def setLocatorColor(sCurve=None, fColor=None):
    sShapes = cmds.listRelatives(sCurve, s=True, typ='locator') or []
    for sO in sShapes:
        cmds.setAttr('%s.overrideEnabled' % sO, True)
        cmds.setAttr('%s.overrideRGBColors' % sO, True)
        cmds.setAttr('%s.overrideColorRGB' % sO, *fColor)



def setCurveColor(sCurve=None, fColor=None):
    sShapes = cmds.listRelatives(sCurve, s=True, typ='nurbsCurve') or []
    for sO in sShapes:
        cmds.setAttr('%s.overrideEnabled' % sO, True)
        cmds.setAttr('%s.overrideRGBColors' % sO, True)
        cmds.setAttr('%s.overrideColorRGB' % sO, *fColor)


def getCurveColor(sCurve):
    sShapes = cmds.listRelatives(sCurve, s=True, typ='nurbsCurve') or []
    if not sShapes:
        return None
    else:
        return cmds.getAttr('%s.overrideColorRGB' % sShapes[0])[0]



def getMayaImportFilePath(sFileName):
    sFile = os.path.join(os.path.dirname(__file__), os.pardir, 'mayaImport', sFileName)
    return sFile


def findNextSettableDisplayPlug(sCtrl):
    sSlaveAttr = '%s.v' % sCtrl
    while True:
        if cmds.getAttr(sSlaveAttr, settable=True):
            break
        else:
            _sCtrl = sSlaveAttr.split('.')[0]
            _sParents = cmds.listRelatives(_sCtrl, p=True)
            if not _sParents:
                raise Exception('no vis attribute found for "%s"' % sCtrl)
            else:
                sSlaveAttr = '%s.v' % _sParents[0]
    return sSlaveAttr


def displayTag(sDisplayAttr, cCtrls):
    if sDisplayAttr and '.' in sDisplayAttr:
        sDisplayCtrl, sDisplayA = sDisplayAttr.split('.')
        if cmds.objExists(sDisplayCtrl):
            for cC in cCtrls:
                sDisplayAttr = findNextSettableDisplayPlug(cC.sSuper if cC.sSuper else cC.sCtrl)
                addOffOnAttr(sDisplayCtrl, sDisplayA, bDefaultValue=True, bNoAnim=True, bChannelBox=True,
                                   bReturnIfExists=True, sTarget=sDisplayAttr)


def unlockAttr(sAttr):
    cmds.setAttr(sAttr, lock=False, channelBox=True)
    cmds.setAttr(sAttr, keyable=True)


import difflib


def getMostSimilarStringFromList(sString, sList):
    import difflib
    best_match = None
    best_ratio = 0.0

    for sWord in sList:
        ratio = difflib.SequenceMatcher(None, sString, sWord).ratio()
        if ratio > best_ratio:
            best_match, best_ratio = sWord, ratio

    return best_match, best_ratio



def applyOnList(inList, func):
    if isinstance(inList, list):
        return [applyOnList(x, func) for x in inList]
    else:
        return func(inList)


kSelectionSiblingNodesAttr = 'sSelectionSiblingNodes'

def selectSelectionSiblingNodes():
    sSel = cmds.ls(sl=True)
    sSelect = []
    for sNode in sSel:
        if cmds.attributeQuery(kSelectionSiblingNodesAttr, node=sNode, exists=True):
            sOtherNodes = eval(cmds.getAttr('%s.%s' % (sNode, kSelectionSiblingNodesAttr)))
            sSelect.extend(sOtherNodes)
        else:
            sSplits = sNode.split('_')
            sSplits[-1] = '*'
            sSearchString = '_'.join(sSplits)
            sSelect += cmds.ls(sSearchString, et=cmds.objectType(sNode))
    cmds.select(sSelect)

def setSelectionSiblingNodes(sNodes):
    sNodes = [sN for sN in sNodes if sN]
    for sNode in sNodes:
        addStringAttr(sNode, kSelectionSiblingNodesAttr, str(sNodes), bLock=True)

def setAttrCheckLimit(sAttr, fValue):
    _sCtrl, _sA = sAttr.split('.')
    if _sA in cmds.listAttr(_sCtrl, userDefined=True):
        fMax = cmds.addAttr(sAttr, q=True, max=True) or 99999999999
    else:
        fMax = 99999999999

    cmds.setAttr(sAttr, min(fValue, fMax))



def setListLength(xList, iLength, sMissingItem=''):
    for i in range(len(xList), iLength):
        xList.append(sMissingItem)
    xList = xList[:iLength]
    return xList


def isInteger(sString):
    try:
        int(sString)
        return True
    except ValueError:
        return False


