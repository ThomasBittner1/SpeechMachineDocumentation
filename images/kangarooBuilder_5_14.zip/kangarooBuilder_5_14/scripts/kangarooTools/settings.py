###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import os
import json
import kangarooTools.utilFunctions as utils
# import kangarooTools.utilsQt as utilsQt
QtWidgets, QtGui, QtCore = utils.importQtModules()

if cmds.about(v=True) >= '2025':
    from shiboken6 import wrapInstance

else:
    from shiboken2 import wrapInstance


window = None
def showSettingsUI(funcUpdateAssets=None):
    global window
    window = QConfigWindow(funcUpdateAssets=funcUpdateAssets)
    window.show()


dDefaultSettings = {'iMaximumCount':8}



def getSettingsFile():
    return os.path.join(cmds.internalVar(userPrefDir=True), 'kangarooBuilder.config')


def getDefaultSettingsFile():
    return os.path.join(utils.getScriptsDir(), os.pardir, 'kangarooBuilderDefault.config')


def getSettingsFileEntry(sKey, xDefault=None):
    utils.debugPrintStrong('=== getSettingsFileEntry()')
    dDict = getSettingsFileDict()
    utils.debugPrintStrong('= getSettingsFileEntry()')
    return dDict.get(sKey, xDefault)


def getSettingsFileDict():
    utils.debugPrintStrong('=== getSettingsFileDict()')
    sConfigFile = getSettingsFile()
    utils.debugPrintStrong('sConfigFile: %s' % sConfigFile)
    try:
        if os.path.exists(sConfigFile):
            utils.debugPrintStrong('config file exists')
            with open(sConfigFile) as file:
                dConfig = json.load(file)
        else:
            utils.debugPrintStrong('config file doesn\'t exist')
            dConfig = {}
    except Exception as e:
        print(e)
        raise Exception('Error to load config file "%s"' % sConfigFile)
    utils.debugPrintStrong('= getSettingsFileDict()')
    return dConfig


def updateConfigFileDict(dConfig):
    dPrevConfig = getSettingsFileDict()
    dPrevConfig.update(dConfig)

    with open(os.path.join(cmds.internalVar(userPrefDir=True), 'kangarooBuilder.config'), 'w') as fp:
        json.dump(dPrevConfig, fp, indent=2)



def getMayaWindow():
    import maya.OpenMayaUI as OpenMayaUI

    ptr = OpenMayaUI.MQtUtil.mainWindow()
    return wrapInstance(int(ptr), QtWidgets.QWidget)


class QConfigWindow(QtWidgets.QDialog):

    def __init__(self, parent=getMayaWindow(), funcUpdateAssets=None):
        super(QConfigWindow, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)

        self.setWindowTitle('Settings')
        sDefaultSettings = getDefaultSettingsFile()
        dSettings = utils.getJsonContent(sDefaultSettings)
        self.dDefaultSettings = dict(dSettings)

        self.sSettingsFile = getSettingsFile()
        if os.path.exists(self.sSettingsFile):
            dCurrentContent = utils.getJsonContent(self.sSettingsFile)
        else:
            dCurrentContent = {}

        dSettings.update(dCurrentContent)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qElements = {}
        for sItem, xValue in list(self.dDefaultSettings.items()):
            # if sItem == 'iMaximumTempFiles':
            #     continue
            xCurrent = dSettings[sItem]

            rowLayout = QtWidgets.QHBoxLayout(self)
            layout.addLayout(rowLayout)
            qLabel = QtWidgets.QLabel('%s: ' % utils.beautifyVariableName(sItem))
            rowLayout.addWidget(qLabel)
            qLine = QtWidgets.QLineEdit()
            qLine.setText(str(xCurrent))
            rowLayout.addWidget(qLine)
            self.qElements[sItem] = qLine

            if sItem == 'sAssetsLocalDir':
                def goToFolderxx(_=None, _sItem=sItem):
                    qLine = self.qElements[_sItem]
                    sFolder = qLine.text()
                    utils.openExplorer(sFolder)
                qButton = QtWidgets.QPushButton('Explorer')
                rowLayout.addWidget(qButton)
                qButton.clicked.connect(goToFolderxx)



        self.qSave = QtWidgets.QPushButton('Save')
        self.qSave.clicked.connect(self.okClicked)

        self.qExplorerSettingsFile = QtWidgets.QPushButton('Show Config File')
        self.qExplorerSettingsFile.clicked.connect(lambda: utils.openExplorer(self.sSettingsFile))

        layout.addWidget(self.qSave)
        layout.addWidget(self.qExplorerSettingsFile)
        self.funcUpdateAssets = funcUpdateAssets


    # TODO: create dContent based on dPreContent? It's strange that it's not doing that, but risky to change
    def okClicked(self):
        self.sSettingsFile = getSettingsFile()
        if os.path.exists(self.sSettingsFile):
            dPrevContent = utils.getJsonContent(self.sSettingsFile)
        else:
            dPrevContent = {}

        dContent = {}
        sRestartChanges = set()
        kAskToRestartOnEntries = ['sAssetsLocalDir']
        kUpdateAssets = ['sAssetsLocalDir']
        bRunUpdateAssets = False
        for sE, qE in list(self.qElements.items()):
            xType = type(self.dDefaultSettings[sE])
            xValue = xType(qE.text().strip())
            dContent[sE] = xValue
            if sE in kAskToRestartOnEntries:
                if sE not in dPrevContent or xValue != dPrevContent[sE]:
                    sRestartChanges.add(sE)
            if sE in kUpdateAssets:
                if sE not in dPrevContent or xValue != dPrevContent[sE]:
                    bRunUpdateAssets = True

        utils.setJsonContent(self.sSettingsFile, dContent)
        self.close()


        if bRunUpdateAssets: # and not utils.isNone(self.funcUpdateAssets):
            self.funcUpdateAssets()

        if sRestartChanges:
            cmds.confirmDialog(m=str('You changed %s, so it\'s important restart Maya!' % ', '.join(sRestartChanges)),
                               button=['ok'])


