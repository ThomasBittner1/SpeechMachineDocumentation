###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np
import re
import importlib
import kangarooTools.utilFunctions as utils

QtWidgets, QtGui, QtCore = utils.importQtModules()

import os
import kangarooTools.nodes as nodes
import kangarooTools.settings as settings
import kangarooTools.report as report
import kangarooTools.utilsQt as utilsQt
import sys
import shutil
import json
import traceback
import time
import getpass
# import subprocess
from collections import Counter, OrderedDict
from functools import reduce

kToolRootFolder =  os.path.join(utils.getScriptsDir(), os.pardir)
# kPathInfoFile = os.path.join(kToolRootFolder, 'paths.txt')

utils.sourceEnvs()
# def getPath(sName):
#     with open(kPathInfoFile) as myFile:
#         sLines = list(myFile)
#     for line in sLines:
#         if '=' in line:
#             sSplits = line.split('=')
#             if sName in sSplits[0]:
#                 sPath = sSplits[1].strip().replace('\n', '')
#                 return sPath


# def getPathDict(sIgnore=[]):
#     dDict = OrderedDict()
#     if not os.path.exists(kPathInfoFile):
#         return {}
#     with open(kPathInfoFile) as myFile:
#         sLines = list(myFile)
#     for sLine in sLines:
#         if sLine.strip().startswith('#'):
#             continue
#         if '=' in sLine:
#             sSplits = sLine.split('=')
#             sKey = sSplits[0].strip()
#             if sKey not in sIgnore:
#                 dDict[sKey] = sSplits[1].strip().replace('\n', '')
#     return dDict



def getBuildFolders():
    dBuildFolders = OrderedDict()
    try:
        sExtraPath = os.environ.get("KANGAROO_EXTRABUILDS_PATH", None) # if "KANGAROO_EXTRA_PATH" in os.environ else getPathDict().get('extraBuilds', None)
        if utils.isNone(sExtraPath):
            dBuildFolders = {}
        else:
            for sPathComb in sExtraPath.split(';'):
                sPathComb = sPathComb.strip()
                if sPathComb:
                    sName, sPath = sPathComb.split('@')
                    sNormPath = os.path.normpath(os.path.join(kToolRootFolder, sPath)).replace('\\','/')
                    if not os.path.exists(sNormPath):
                        utils.debugPrint('path "%s" (%s) doesn\'t exist. Please check your paths.txt file' % (sNormPath, sName))
                    dBuildFolders[sName.strip()] = sNormPath
        dBuildFolders['default'] = os.path.join(utils.getToolsDir(), os.pardir, 'kangarooBuilds')
        return dBuildFolders
    except Exception as e:
        cmds.confirmDialog(m='Error getting Build Folders, possibly issues with the environment variable syntax.\nCheck Script Editor for more info')
        raise


def getServers():
    try:
        dServerPaths = OrderedDict()
        sServerPaths = os.environ.get('KANGAROO_SERVER_PATH', '') # if 'KANGAROO_SERVER_PATH' in os.environ else getPathDict().get('servers', '')
        sServerPaths += '; %s' % settings.getSettingsFileEntry('sExtraServers', '')

        for sPathComb in sServerPaths.split(';'):
            sPathComb = sPathComb.strip()
            if not sPathComb:
                continue
            if sPathComb:
                sName, sPath = sPathComb.split('@')
                sNormPath = os.path.normpath(os.path.join(kToolRootFolder, sPath)).replace('\\','/')
                if not os.path.exists(sNormPath):
                    print('server path "%s" (%s) doesn\'t exist. Please check your paths.txt file' % (sNormPath, sName))
                dServerPaths[sName.strip()] = sNormPath
    except Exception as e:
        cmds.confirmDialog(m='Error getting Servers, possibly issues with the environment variable syntax.\nCheck Script Editor for more info')
        raise

    return dServerPaths


def getAllServerAssetRoots():
    return list(getServers().values())

bAskToCreateAssetLocalIfNotExists = True

def getAssetsFromRoots(sRoots, sProject='', bReturnDict=False):
    utils.debugPrintStrong('=== getAssetsFromRoots()')
    utils.debugPrintStrong('sRoots: %s' % sRoots)
    utils.debugPrintStrong('sProject: %s' % sProject)
    utils.debugPrintStrong('bReturnDict: %s' % bReturnDict)

    dAssets = {}
    for sRoot in utils.toList(sRoots):
        if not sRoot:
            continue
        if not os.path.exists(sRoot):
            print('Assets Root folder doesn\'t exist:\n"%s\n' % (sRoot))
            cmds.confirmDialog(m='Assets Root folder doesn\'t exist!:'
                                '\n\n"%s"\nIf it\'s set wrong, fix it in the Settings or directly in "%s". \n\nAnd restart Maya after that!' \
                                 % (sRoot, settings.getSettingsFile()), button=['ok'])
            dAssets[sRoot] = []
        else:
            sProjectRoot = os.path.join(sRoot, sProject)
            if os.path.exists(sProjectRoot):
                sAssets = [sF for sF in os.listdir(sProjectRoot) if sF[0] != '_' and '.' not in sF]
                sAssets.sort(key=lambda x:x.upper())
                dAssets[sRoot] = list(sAssets)

    sList = reduce(lambda x, y: x + y, list(dAssets.values())) if dAssets else []
    sDuplicates = [sAsset for sAsset, iCount in list(Counter(sList).items()) if iCount > 1]
    if sDuplicates:
        sDuplicatesInfo = []
        for sDuplicate in sDuplicates:
            sRoots = []
            for sRoot, sAssets in dAssets.items():
                if sDuplicate in sAssets:
                    sRoots.append(sRoot)
            sDuplicatesInfo.append('%s in %s' % (sDuplicate, ', '.join(sRoots)))
        sError = 'There are some duplicated assets in different roots.. %s' % '\n'.join(sDuplicatesInfo)
        cmds.confirmDialog(m=sError)
        raise Exception(sError)

    utils.debugPrintStrong('= getAssetsFromRoots()')

    if bReturnDict:
        return dAssets
    else:
        return sList


def getProjectsFromRoots(sRoots, bReturnDict=False):
    dProjects = {}
    for sRoot in utils.toList(sRoots):
        if not sRoot or not os.path.exists(sRoot):
            # cmds.confirmDialog(m='Assets Root folder doesn\'t exist:\n"%s\nEither recreate it, or change it in \n%s (B)' % (sRoot, settings.getSettingsFile()))
            dProjects[sRoot] = []
        else:
            sProjects = [sF for sF in os.listdir(sRoot) if utils.isProject(sF)]
            dProjects[sRoot] = list(sProjects)

    if bReturnDict:
        return dProjects
    else:
        sList = reduce(lambda x, y: x + y, list(dProjects.values()))
        return sList


def checkServerBox(bChecked):
    if assetManager:
        assetManager.checkServerBox(bChecked, bTurnOffSignals=False)


def refresh():
    if assetManager:
        assetManager.refresh()


def getLocalAssetRoot():
    sAssetLocalDir = os.environ["KANGAROO_WORK_PATH"] if 'KANGAROO_WORK_PATH' in os.environ else settings.getSettingsFileEntry('sAssetsLocalDir', None)
    if sAssetLocalDir:
        sAssetLocalDir = sAssetLocalDir.replace('\\','/').strip()
    return sAssetLocalDir



def sysAppendLocalAssetRoot():
    sAssetRoot = getLocalAssetRoot()
    if sAssetRoot:
        utils.debugPrint('sys.path.append sAssetRoot: ', sAssetRoot)
        sToAppend = os.path.abspath(os.path.join(sAssetRoot))
        if sToAppend not in sys.path:
            utils.debugPrint('before appending %s..' % sToAppend)
            sys.path.append(sToAppend)
            utils.debugPrint('appended.')
        utils.debugPrint ('done appending stuff')
sysAppendLocalAssetRoot()



# def sysAppendServerAssetRoots():
#     sRoots = getAllServerAssetRoots()
#     for sRoot in sRoots:
#         utils.debugPrint('sys.path.append Server Root: ', sRoot)
#         sToAppend = os.path.join(sRoot, os.pardir)
#         if sToAppend not in sys.path:
#             sys.path.append(sToAppend)
# sysAppendServerAssetRoots()

assetManager = None


def getCurrentAssetRoot():
    if assetManager:
        return assetManager.getCurrentAssetPath()




def getCurrentProject():
    if assetManager:
        return assetManager.getCurrentProject()[0]



def getCurrentAsset():
    if assetManager:
        return assetManager.getCurrentAsset()[0]



def getCurrentAssetRootName():
    sRoot = getCurrentAssetRoot().split(os.sep)
    return sRoot[-1]


def getCurrentVersionPath():
    if assetManager:
        return assetManager.getCurrentVersionPath()



def getCurrentBuildFile():
    if assetManager:
        sBuildFile = os.path.join(assetManager.getCurrentVersionPath(), 'build.bld')
        return sBuildFile


def isServer():
    if assetManager:
        return assetManager.isServer()


kTempFileType = 'mayaAscii'


class TempFile(object):
    def __init__(self, sAssetPath):  # , _report=None):
        self.sAssetPath = sAssetPath
        self.sDir = os.path.join(sAssetPath, '_temp')
        self.sExt = 'mb' if kTempFileType == 'mayaBinary' else 'ma'
        # self._report = _report
        if not os.path.exists(self.sDir):
            os.makedirs(self.sDir)

    def getCurrentFiles(self, bAbsolute=False, bAllFiles=False):
        dCurrentFiles = {}
        iZeroCounter = 0
        for sF in os.listdir(self.sDir):
            if (bAllFiles and '.ma' in sF) or re.match('temp[0-9]+\.ma', sF):
                _, iNumber = utils.getNumberAtEnd(sF.split('.')[0])
                if iNumber == 0: # since there will be more 0s, we'll create a number like 0.1, 0.12342, ...
                    iNumber = iZeroCounter / (pow(10, len(str(iZeroCounter))))
                    iZeroCounter += 1
                if bAbsolute:
                    dCurrentFiles[iNumber] = os.path.join(self.sDir, sF).replace('\\','/')
                else:
                    dCurrentFiles[iNumber] = sF
        return dCurrentFiles

    def getLatestTempFile(self):
        dFiles = self.getCurrentFiles()
        if not dFiles:
            report.report.addLogText('Pull: there is no file yet', bPrint=True)
            return
        else:
            iLatest = max(dFiles.keys())
            return os.path.join(self.sDir, dFiles[iLatest]).replace('\\','/')

    def saveNew(self, bRemoveRequiresLines=False):
        iMaximumTempFiles = settings.getSettingsFileEntry('iMaximumTempFiles')

        dCurrentFiles = self.getCurrentFiles()
        if dCurrentFiles:
            iNewNumber = max(dCurrentFiles.keys()) + 1
        else:
            iNewNumber = 0
        sNewFile = 'temp%d.%s' % (iNewNumber, self.sExt)
        sFilePath = os.path.join(self.sDir, sNewFile).replace('\\','/')

        try:
            cmds.file(rename=sFilePath)
            cmds.file(save=True, typ=kTempFileType)
            if bRemoveRequiresLines:
                utils.removeRequiresLines(sFilePath)
            cmds.flushUndo()
            report.report.addLogText('Saved New Scene "%s" (%0.3f MB)' %
                                     (sFilePath, os.path.getsize(sFilePath) / 1000000), bClearFirst=True, bPrint=True)
        except:
            cmds.confirmDialog(title='Error saving File',
                               message='Error saving File, \ncheck Script Editor for Details',
                               button=['ok'])
            raise

        dCurrentFiles = self.getCurrentFiles()
        if iMaximumTempFiles > 0:
            iAllNumbers = sorted(list(dCurrentFiles.keys()), reverse=True)
            if iMaximumTempFiles < len(iAllNumbers):
                for iNumber in iAllNumbers[iMaximumTempFiles:]:
                    sDeleteFile = dCurrentFiles[iNumber]
                    report.report.addLogText(
                        'Deleting File "%s" (set "Maximum Temp Files" higher than %d if you would like to keep files in future)' % (
                        sDeleteFile, iMaximumTempFiles), bPrint=True)
                    os.remove(os.path.join(self.sDir, sDeleteFile))


tDisableOnServerButtons = []
tDisableOnServerControls = []


def createTopGroups(sMaster='master', sModel='model', sPostFix='', iModelVisDefault=2, iRigVisDefault=0, iSkeletonVisDefault=0):
    sMaster = '%s%s' % (sMaster, sPostFix)

    if not cmds.objExists(sMaster):
        cmds.createNode('transform', n=sMaster)
    sModelVis = utils.addAttr(sMaster, ln='modelVis', at='enum', en='Off:On:Reference', defaultValue=iModelVisDefault, k=True,
                              bReturnIfExists=True)
    sRigVis = utils.addAttr(sMaster, ln='rigVis', at='enum', en='Off:On', defaultValue=iRigVisDefault, k=True, bReturnIfExists=True)
    sCtrlVis = utils.addAttr(sMaster, ln='ctrlVis', at='enum', en='Off:On:Proximity', defaultValue=1, k=True,
                             bReturnIfExists=True)
    sSkeletonVis = utils.addAttr(sMaster, ln='skeletonVis', at='enum', en='Off:On', defaultValue=iSkeletonVisDefault, k=True,
                                 bReturnIfExists=True)
    utils.addStringAttr(sMaster, '__asset__', assetManager.getCurrentAsset(), bLock=True)
    utils.addStringAttr(sMaster, '__project__', assetManager.getCurrentProject(), bLock=True)

    sModules = 'modules%s' % sPostFix
    sSkeleton = 'skeleton%s' % sPostFix
    sCtrls = 'ctrls%s' % sPostFix
    sModel = '%s%s' % (sModel, sPostFix)

    sStoredModelGroupName = utils.data.get('sModelGroupName')
    if sStoredModelGroupName:
        sModel = sStoredModelGroupName
    else:
        utils.data.store('sModelGroupName', sModel)

    if not cmds.objExists(sModules):
        cmds.createNode('transform', n=sModules, p=sMaster)
        cmds.connectAttr(sRigVis, '%s.v' % sModules)

    if not cmds.objExists(sSkeleton):
        cmds.createNode('transform', n=sSkeleton, p=sMaster)
        cmds.connectAttr(sSkeletonVis, '%s.v' % sSkeleton)

    if not cmds.objExists(sCtrls):
        cmds.createNode('transform', n=sCtrls, p=sMaster)
        cmds.connectAttr(sCtrlVis, '%s.v' % sCtrls)

    if not cmds.objExists(sModel):
        cmds.createNode('transform', n=sModel, p=sMaster)
        nodes.createConditionNode(sModelVis, '==', 0, False, True, sTarget='%s.v' % sModel)
        cmds.setAttr('%s.overrideEnabled' % sModel, True)
        nodes.createConditionNode(sModelVis, '==', 2, 2, 0, sTarget='%s.overrideDisplayType' % sModel)

    return sMaster, sModules, sSkeleton, sCtrls, sModel


def createAssetManager(qLayout):  # , _report=None):
    global assetManager
    if assetManager == None:
        assetManager = AssetManager(qLayout)
        # assetManager._report = _report
    return assetManager


# class ServerCheckBox(QtWidgets.QCheckBox):
#     def __init__(self, parent=None):
#         QtWidgets.QCheckBox.__init__(self, parent)



class AssetManager(object):
    def __init__(self, qLayout):
        # global assetManager
        # assetManager = self

        dConfig = settings.getSettingsFileDict()
        # sSavedCurrentAsset = dConfig.get('sCurrentAsset', None)
        bSavedServer = dConfig.get('bServer', None)

        self.connectedFileControls = []
        self.serverDisabledControls = []
        qLineLayout = QtWidgets.QHBoxLayout()
        qLayout.addLayout(qLineLayout)

        self.qProjectSelector = utilsQt.FilteredComboBox(sSaveName='ProjectsSelector')
        qLineLayout.addWidget(self.qProjectSelector)

        self.qAssetSelector = utilsQt.FilteredComboBox(sSaveName='AssetsSelector', bFilterBoxDefault=True)
        qLineLayout.addWidget(self.qAssetSelector)

        self.qVersionSelector = QtWidgets.QComboBox()
        qLineLayout.addWidget(self.qVersionSelector)
        self.qServer = QtWidgets.QCheckBox('Server')

        qLineLayout.addWidget(self.qServer)
        self.checkServerBox(False)

        # self.fillProjects()

        self.qPublishButton = QtWidgets.QPushButton('Publish')
        self.qPublishButton.clicked.connect(self.publishAsset)
        qLineLayout.addWidget(self.qPublishButton)
        self.qPublishButton.setEnabled(True)

        self.qLocalizeButton = QtWidgets.QPushButton('Localize')
        self.qLocalizeButton.clicked.connect(self.localizeAsset)
        qLineLayout.addWidget(self.qLocalizeButton)
        self.qLocalizeButton.setEnabled(False)

        self.qSettingsButton = QtWidgets.QPushButton('Settings')
        self.qSettingsButton.clicked.connect(self.funcSetLocalAssetFolder)
        self.qSettingsButton.setToolTip('Your local settings. \nThose are saved in the config file that you can also get through this UI')
        qLineLayout.addWidget(self.qSettingsButton)

        self.qServer.setMaximumWidth(110)
        self.qLocalizeButton.setMaximumWidth(110)
        self.qPublishButton.setMaximumWidth(110)
        self.qSettingsButton.setMaximumWidth(100)

        qRefreshButton = QtWidgets.QPushButton('')
        sIconFile = os.path.join(utils.getToolsDir(), 'refresh.png')
        _kIconSize = 30
        qRefreshButton.setIconSize(QtCore.QSize(_kIconSize, _kIconSize))  # <---

        qRefreshButton.setIcon(QtGui.QIcon(sIconFile))
        qRefreshButton.setMaximumWidth(_kIconSize)
        qRefreshButton.setMinimumWidth(_kIconSize)
        qRefreshButton.setMaximumHeight(_kIconSize)
        qRefreshButton.setMinimumHeight(_kIconSize)
        qRefreshButton.clicked.connect(self.refresh)
        qLineLayout.addWidget(qRefreshButton)
        qRefreshButton.setToolTip('Refreshes the combo boxes. Click this when you changed the paths outside of this tool')
        qTempSaveLayout = QtWidgets.QHBoxLayout()
        qLayout.addLayout(qTempSaveLayout)
        dButtons = {}
        for sButton, func, bLatestOption, sToolTip in [('hold scene', self.hold, False, 'Saves a Temp File (Right click to save specific name)'),
                                                     ('pull scene', self.pull, False, 'Opens the last Temp File (Right click to reference or copy either current or older one)'),
                                                     ('import rig', self.importPublished, True, 'Imports the Rig in the _published folder'),
                                                     ('reference rig', self.referencePublished, True, 'References the Rig in the _published folder'),
                                                     ('open rig', self.openPublished, True, 'Opens the Rig in the _published folder'),
                                                     ('clipboard rig', self.clipboardRig, True, 'Copys the Rig Location in the _published folder to Clipboard, so you can paste it'),
                                                     ('explorer rig', self.openPublishedExplorer, True, 'Opens the Explorer on the rig in the _published folder'),
                                                     ('+', self.biggerUi, False, 'Makes the UI bigger. In Maya 2025 it sometimes doesn\'t work by dragging when it\'s docked'),
                                                     ('-', self.smallerUI, False, 'Makes the UI smaller. In Maya 2025 it sometimes doesn\'t work by dragging when it\'s docked')]:

            if sButton in ['+','-'] and cmds.about(version=True) != '2025':
                continue
            qButton = QtWidgets.QPushButton(sButton)
            qButton.setToolTip(sToolTip)
            qTempSaveLayout.addWidget(qButton)
            qButton.clicked.connect(func)
            if bLatestOption:
                def markingMenu(vPos, qB=qButton, fF=func):
                    qMenu = QtWidgets.QMenu()
                    qMenu.addAction('latest', lambda: fF(bLatest=True))
                    qMenu.exec_(qB.mapToGlobal(vPos))
                    return qMenu

                qButton.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
                qButton.customContextMenuRequested.connect(markingMenu)
            dButtons[sButton] = qButton


        self.qServerButton = QtWidgets.QPushButton('')
        self.qServerButton.dPaths = getServers() #getPathDict(sIgnore=['extraBuilds'])
        self.qServerButton.clicked.connect(self.serverMarkingMenu)
        self.qServerButton.setToolTip('Use this to specify differnet server')
        qTempSaveLayout.addWidget(self.qServerButton)


        # pull marking menu
        qPullButton = dButtons['pull scene']

        def pullSceneMarkingMenu(vPos):
            qMenu = QtWidgets.QMenu()
            tempFile = TempFile(self.getCurrentAssetPath())  # , self._report)
            dFiles = tempFile.getCurrentFiles(bAbsolute=True, bAllFiles=True)
            utils.debugPrint('dFiles: ', dFiles)
            iFiles = sorted(list(dFiles.keys()), reverse=True)
            sTexts = []
            for iF in iFiles:
                def _openFile(sFilePath=dFiles[iF]):
                    report.report.addLogText('Pulling Scene... (%s)' % sFilePath, bClearFirst=True, bPrint=True)
                    cmds.file(sFilePath, o=True, f=True)

                sTimeAgo = utils.fullTimeUnits(time.time() - os.path.getmtime(dFiles[iF]))
                sText = '%s (%s MB, %s ago)' % (os.path.basename(dFiles[iF]), os.path.getsize(dFiles[iF]) / 1000000, sTimeAgo)
                sTexts.append(sText)
                qMenu.addAction(sText, _openFile)

            qReferenceMenu = qMenu.addMenu('Reference...')
            for i,iF in enumerate(iFiles):
                def _referenceFile(sFilePath=dFiles[iF]):
                    report.report.addLogText('Pulling (Reference) Scene... (%s)' % sFilePath, bClearFirst=True, bPrint=True)
                    sNamespace = sFilePath.replace('\\','/').split('/')[-1].split('.')[0]
                    cmds.file(sFilePath, r=True, namespace=sNamespace, ignoreVersion=True, prompt=False)
                qReferenceMenu.addAction(sTexts[i], _referenceFile)

            qClipboardMenu = qMenu.addMenu('Copy to Clipboard...')
            for i,iF in enumerate(iFiles):
                def _copyFile(sFilePath=dFiles[iF]):
                    report.report.addLogText('Copying to clipboard... (%s)' % sFilePath.replace('\\','/'), bClearFirst=True, bPrint=True)
                    utils.copyToClipBoard(sFilePath)
                qClipboardMenu.addAction(sTexts[i], _copyFile)


            qMenu.exec_(qPullButton.mapToGlobal(vPos))
            return qMenu

        qPullButton.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        qPullButton.customContextMenuRequested.connect(pullSceneMarkingMenu)

        # push marking menu
        qHoldButton = dButtons['hold scene']

        def holdSceneMarkingMenu(vPos):
            qMenu = QtWidgets.QMenu()

            qMenu.addAction('hold non-destructable', self.holdNondestructable)
            qMenu.exec_(qHoldButton.mapToGlobal(vPos))
            return qMenu

        qHoldButton.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        qHoldButton.customContextMenuRequested.connect(holdSceneMarkingMenu)

        self.qAssetSelector.currentIndexChanged.connect(self.assetChanged)
        self.qProjectSelector.currentIndexChanged.connect(self.projectChanged)
        self.qServer.clicked.connect(self.serverSwitched)
        self.qVersionSelector.currentIndexChanged.connect(self.refreshFilePathControls)


        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.timerUpdate)
        self.timer.start(3000)



    def serverMarkingMenu(self):
        utils.debugPrint ('server clicked')
        if self.qServer.isChecked():
            return

        qMenu = QtWidgets.QMenu()
        dPaths = self.qServerButton.dPaths
        sProject, sKey = self.getCurrentProject()
        sAssetRoot = getLocalAssetRoot()
        sServerFile = os.path.join(sAssetRoot, sProject, 'server.txt')
        for sKey, sPath in dPaths.items():
            def switchTo(sKey=sKey, sPath=sPath):
                self.qServerButton.setText(sKey)
                utils.createTextFile(sServerFile, sKey)
            qMenu.addAction(sKey, switchTo)

        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())
        return qMenu



    def timerUpdate(self):
        try:
            self.updateStatusColor()
        except:
            print('error happened on updateColor - we\'ll stop update\n\n')
            self.timer.stop()
            raise


    def closeEvent(self):
        self.timer.stop()



    def setVersionColor(self, sColor=None):
        if sColor == None:
            self.qProjectSelector.setStyleSheet('')
            self.qAssetSelector.setStyleSheet('')
            self.qVersionSelector.setStyleSheet('')
        else:
            sStyleSheet = 'QComboBox{background-color: %s}' % sColor
            self.qProjectSelector.setStyleSheet(sStyleSheet)
            self.qAssetSelector.setStyleSheet(sStyleSheet)
            self.qVersionSelector.setStyleSheet(sStyleSheet)


    def reloadAfterLocalAssetsSettingsUpdate(self):
        if not self.qServer.isChecked():
            sysAppendLocalAssetRoot()
            self.fillProjects()


    def funcSetLocalAssetFolder(self):
        # reload(settings)
        settings.showSettingsUI(funcUpdateAssets=self.reloadAfterLocalAssetsSettingsUpdate)


    def checkServerBox(self, bChecked, bTurnOffSignals=True):
        if bTurnOffSignals:
            bSignalsBefore = self.qServer.signalsBlocked()
            self.qServer.blockSignals(True)

        self.qServer.setChecked(bChecked)

        if bTurnOffSignals:
            self.qServer.blockSignals(bSignalsBefore)



    def localizeAsset(self):
        report.report.clearLogText()
        # self._report.setProgressBarColor(utils.uiColors.blue)
        sVersion = self.getCurrentVersion()
        sAssetRoot = getLocalAssetRoot()
        if not sAssetRoot:
            raise Exception('no asset root specified')

        # sLocalVersion = os.path.join(sAssetRoot, self.getCurrentAsset(), '_build', sVersion)
        # if os.path.exists(sLocalVersion):
        #     report.report.addLogText('Local already exists. Delete Local if you really want to localize', bPrint=True)
        #     report.report.addLogText(sLocalVersion, bPrint=True)
        #     report.report.setProgressBarColor(utils.uiColors.red)
        #     report.report.setToFull()
        #     return

        # report.report.addLogText('Localizing version: %s' % sVersion, bPrint=True)
        # report.report.addLogText(sLocalVersion, bPrint=True)

        sCurrentProject, sServerKey = self.getCurrentProject()
        shareAsset(sCurrentProject, self.getCurrentAsset(), sVersion, bServerToLocal=True, sServerKey=sServerKey)

        self.checkServerBox(False)
        self.fillProjects(bSwitchServerTo=False, sSwitchAssetTo=self.getCurrentAsset(), sSwitchProjectTo=self.getCurrentProject())
        sVersions = [self.qVersionSelector.itemText(i) for i in range(self.qVersionSelector.count())]
        iVersionIndex = sVersions.index(sVersion)
        self.qVersionSelector.setCurrentIndex(iVersionIndex)


    def publishAsset(self):
        report.report.clearLogText()

        ddMasters = utils.data.get('ddMasters',
                                   xDefault={'master': {'sFilename': 'RIG_%s_[v].ma' % self.getCurrentAsset()}},
                                   sNode=utils.kExportNode)

        self.publishUI = PublishUI(ddMasters, self._publishAsset)
        self.publishUI.show()


    def _publishAsset(self, ddMasters):
        utils.debugPrint('ddMasters: ', ddMasters)
        publishRig(self.getCurrentProject()[0], self.getCurrentAsset(), self.getCurrentVersion(), ddMasters)  # , _report=self._report)


    def isServer(self):
        return True if self.qServer.isChecked() else False


    def getCurrentAssetRoots(self, bForceServer=None):
        if bForceServer == None:
            return getAllServerAssetRoots() if self.qServer.isChecked() else [getLocalAssetRoot()]
        elif bForceServer == True:
            return getAllServerAssetRoots()
        elif bForceServer == False:
            return [getLocalAssetRoot()]


    def findAssetPath(self, sAsset, sProject='', bForceServer=None):
        sRoots = self.getCurrentAssetRoots(bForceServer=bForceServer)
        # dProjects = getProjectsFromRoots(sRoots, bReturnDict=True)
        dAssets = getAssetsFromRoots(sRoots, sProject=sProject, bReturnDict=True)

        for sRoot, sAssets in list(dAssets.items()):
            if sAsset in sAssets:
                return os.path.join(sRoot, sProject, sAsset)
        return None




    def fillProjects(self, bRefreshControls=True, sSwitchProjectTo=[None, None], sSwitchAssetTo=None, bSwitchServerTo=False):
        utils.debugPrint('\n\n\n\n\n\n =================================== fillAsset() ====================================\n\n\n\n')

        utils.debugPrint ('sSwitchProjectTo: ', sSwitchProjectTo)
        utils.debugPrint ('sSwitchAssetTo: ', sSwitchAssetTo)
        utils.debugPrint ('bSwitchServerTo: ', bSwitchServerTo)

        if not isinstance(sSwitchProjectTo, (list,tuple)):
            sSwitchProjectTo = [sSwitchProjectTo, None]
        elif len(sSwitchProjectTo) == 1:
            sSwitchProjectTo = [sSwitchProjectTo[0], None]


        bBlockedState = self.qVersionSelector.signalsBlocked()
        self.qVersionSelector.blockSignals(True)
        self.qProjectSelector.blockSignals(True)
        self.qAssetSelector.blockSignals(True)
        try:
            if bSwitchServerTo:
                self.checkServerBox(bSwitchServerTo)

            self.qLocalizeButton.setEnabled(True if bSwitchServerTo else False)
            self.qPublishButton.setEnabled(False if bSwitchServerTo else True)

            self.qProjectSelector.clear()
            self.qAssetSelector.clear()
            self.qVersionSelector.clear()

            if bSwitchServerTo:
                dServers = getServers()

                iIndex = 0
                for sKey, sServerPath in dServers.items():
                    utils.debugPrint ('\n sKey: ', sKey, 'sServerPath: ', sServerPath)
                    sProjects = [sF for sF in os.listdir(sServerPath) if utils.isProject(sF)]
                    utils.debugPrint ('sServerPath: ', sServerPath, ' -> ', sProjects)
                    for sProject in sProjects:
                        sAddProject = '%s (%s)' % (sProject[2:-2], sKey)

                        self.qProjectSelector.addItem(sAddProject)
                        utils.debugPrint ('adding project to server: ', sAddProject)
                        utils.debugPrint ('comparing: ', sSwitchProjectTo[0], sProject, '...',  sSwitchProjectTo[1], sKey)
                        if sSwitchProjectTo[0] == sProject and sSwitchProjectTo[1] in [sKey, None]:
                            self.qProjectSelector.setCurrentIndex(iIndex)
                            utils.debugPrint ('switch to ', iIndex)
                        iIndex += 1

            else:
                utils.debugPrint ('switch server to local')
                sRoot = getLocalAssetRoot()
                if sRoot and os.path.exists(sRoot):
                    sProjects = [sF for sF in os.listdir(sRoot) if utils.isProject(sF)]

                    sAllKeys = []
                    for iIndex, sProject in enumerate(sProjects):
                        sKeyFile = os.path.join(sRoot, sProject, 'server.txt')
                        sAllKeys.append(getServerKeyFromFile(sKeyFile))


                    for iIndex, sProject in enumerate(sProjects):
                        sKeyFile = os.path.join(sRoot, sProject, 'server.txt')
                        sKey = getServerKeyFromFile(sKeyFile)

                        sAddProject = '%s (%s)' % (sProject[2:-2], sKey)

                        self.qProjectSelector.addItem(sAddProject)
                        utils.debugPrint ('adding project to local: ', sAddProject)
                        utils.debugPrint ('comparing: ', sSwitchProjectTo[0], sProject, '...', sSwitchProjectTo[1], sKey)

                        if sSwitchProjectTo[0] == sProject and sSwitchProjectTo[1] in [sKey, None]:
                            self.qProjectSelector.setCurrentIndex(iIndex)


        except:
            print ('exception from fillProject')
            raise
        finally:
            self.qVersionSelector.blockSignals(bBlockedState)
            self.qAssetSelector.blockSignals(bBlockedState)
            self.qProjectSelector.blockSignals(bBlockedState)
            utils.debugPrint ('blocked (01)')


        utils.debugPrint('calling projectChanged A')
        self.projectChanged(bRefreshControls=bRefreshControls, sSwitchAssetTo=sSwitchAssetTo)
        utils.debugPrint ('after projectChanged')
        if bRefreshControls:
            utils.debugPrint('call self.refreshFilePathControls D')
            self.refreshFilePathControls()


    def _getLatestPublished(self, sFilename=None, bErrorIfNotExists=True):
        sAssetPath = self.getCurrentAssetPath()
        sPublishedPath = os.path.join(sAssetPath, '_published')
        sList = os.listdir(sPublishedPath)
        sVersionFolders = [sF for sF in sList if sF.startswith('v') and '.' not in sF]
        iHighestF = -1
        iHighestNumber = -1
        for f, sF in enumerate(sVersionFolders):
            utils.debugPrint('sF: ', sF)
            sName, iNumber = utils.getNumberAtEnd(sF)
            if iHighestF == -1 or iNumber > iHighestNumber:
                iHighestF = f
                iHighestNumber = iNumber
            utils.debugPrint(sName, iNumber)
        sVersionFolder = sVersionFolders[iHighestF]

        sDir = os.path.join(sPublishedPath, sVersionFolder)
        if sFilename:
            sFilePath = os.path.join(sDir, sFilename)
        else:
            sFile = None
            for sF in os.listdir(sDir):
                if sF.startswith('RIG_') and (sF.endswith('.ma') or sF.endswith('mb')):
                    sFile = sF
            if not sFile: # in case there's no file starting with RIG but ending with .ma or .mb (this part is not fully tested yet)
                for sF in os.listdir(sDir):
                    if sF.endswith('.ma') or sF.endswith('mb'):
                        sFile = sF
            if not sFile:
                raise Exception('No file found in %s' % sDir)
            sFilePath = os.path.join(sDir, sFile)
            utils.debugPrint('sFilePath: ', sFilePath)

        if not os.path.exists(sFilePath):
            if sFilePath.endswith('.mb'):
                sFilePath = utils.replaceStringEnd(sFilePath, '.mb', '.ma')
            elif sFilePath.endswith('.ma'):
                sFilePath = utils.replaceStringEnd(sFilePath, '.ma', '.mb')
            if not os.path.exists(sFilePath):
                if bErrorIfNotExists:
                    raise Exception('file doesn\'t exist: %s' % sFilePath)
                else:
                    cmds.warning('file doesn\'t exist: %s' % sFilePath)

        return sFilePath.replace('\\','/')


    def getCurrentProject(self):

        sSplits = self.qProjectSelector.currentText().split(' ')
        if len(sSplits) == 1:
            sSplits = [sSplits[0], 'default']
        else:
            sSplits[1] = sSplits[1].split('(')[-1].split(')')[0]
        return '__%s__' % sSplits[0], sSplits[1]


    def projectChanged(self, iProjectIndex=-1, bRefreshControls=True, sSwitchAssetTo=None):
        utils.debugPrint('\n\n\n\n\n\n =================================== projectChanged (old fillAsset()) ====================================\n\n\n\n')
        utils.debugPrint('bRefreshControls: ', bRefreshControls)
        sCurrentAssetRoots = self.getCurrentAssetRoots()
        utils.debugPrint ('sCurrentAssetRoots: ', sCurrentAssetRoots)

        bBlockedState = self.qVersionSelector.signalsBlocked()
        self.qVersionSelector.blockSignals(True)
        self.qProjectSelector.blockSignals(True)
        self.qAssetSelector.blockSignals(True)
        # self.qServer.blockSignals(True)
        utils.debugPrint ('blocked (02)')

        sProject, sKey = self.getCurrentProject()
        try:
            self.qAssetSelector.clear()

            sAssets = getAssetsFromRoots(sCurrentAssetRoots, sProject=sProject)
            for sFolder in sAssets:
                self.qAssetSelector.addItem(sFolder)

            if sSwitchAssetTo == None:
                dConfig = settings.getSettingsFileDict()
                dDefaultAssets = dConfig.get('dDefaultAssets', {})
                sSwitchAssetTo = dDefaultAssets.get(sProject, 0)

            if utils.isStringOrUnicode(sSwitchAssetTo) and sSwitchAssetTo in sAssets:
                iSwitchIndexTo = sAssets.index(sSwitchAssetTo)
                self.qAssetSelector.setCurrentIndex(iSwitchIndexTo)
            elif isinstance(sSwitchAssetTo, int) and sSwitchAssetTo < len(sAssets):
                iSwitchIndexTo = sSwitchAssetTo
                self.qAssetSelector.setCurrentIndex(iSwitchIndexTo)
        except:
            raise
        finally:
            self.qVersionSelector.blockSignals(bBlockedState)
            self.qProjectSelector.blockSignals(bBlockedState)
            self.qAssetSelector.blockSignals(bBlockedState)
            # self.qServer.blockSignals(bBlockedState)
            utils.debugPrint ('blocked (03)')
            utils.debugPrint ('xxx')

        utils.debugPrint ('b')
        if iProjectIndex >= 0:
            settings.updateConfigFileDict({'sCurrentProject': [sProject, sKey]})
        utils.debugPrint ('c')
        self.assetChanged(-1, bRefreshControls=False)
        utils.debugPrint ('d')
        if bRefreshControls:
            self.refreshFilePathControls()
        utils.debugPrint ('aaa')


    def _getCurrentPublished(self, sFilename=None, bErrorIfNotExists=True):
        sAssetPath = self.getCurrentAssetPath()
        # utils.debugPrint ('sAssetPath: ', sAssetPath)
        sPublishedPath = os.path.join(sAssetPath, '_published')
        # sList = os.listdir(sPublishedPath)
        sVersionFolder = self.getCurrentVersion()

        sDir = os.path.join(sPublishedPath, sVersionFolder)
        if not os.path.exists(sDir):
            return None
        if sFilename:
            sFilePath = os.path.join(sDir, sFilename)
        else:
            sFile = None
            for sF in os.listdir(sDir):
                if sF.endswith('.ma') or sF.endswith('mb'):
                    sFile = sF
            if not sFile:
                raise Exception('No file found in %s' % sDir)
            sFilePath = os.path.join(sDir, sFile)

        if not os.path.exists(sFilePath):
            if sFilePath.endswith('.mb'):
                sFilePath = utils.replaceStringEnd(sFilePath, '.mb', '.ma')
            elif sFilePath.endswith('.ma'):
                sFilePath = utils.replaceStringEnd(sFilePath, '.ma', '.mb')
            if not os.path.exists(sFilePath):
                if bErrorIfNotExists:
                    raise Exception('file doesn\'t exist: %s' % sFilePath)
                else:
                    cmds.warning('file doesn\'t exist: %s' % sFilePath)

        return sFilePath

    def importPublished(self, bLatest=False):
        if bLatest:
            sFile = self._getLatestPublished()
        else:
            sFile = self._getCurrentPublished()

        if not sFile:
            report.report.addLogText('no file found', bClearFirst=True, bPrint=True)
        else:
            report.report.addLogText('importing %s' % sFile, bClearFirst=True, bPrint=True)
            utils.importMayaFiles(sFile, sNamespace=None, bReference=False)


    def openPublished(self, bLatest=False):
        if bLatest:
            sFile = self._getLatestPublished()
        else:
            sFile = self._getCurrentPublished()
        report.report.addLogText('open %s' % sFile, bClearFirst=True, bPrint=True)
        cmds.file(sFile, open=True, force=True)


    def clipboardRig(self, bLatest=False):
        if bLatest:
            sFile = self._getLatestPublished()
        else:
            sFile = self._getCurrentPublished()
        sFile = sFile.replace('\\', '/')
        report.report.addLogText('copy to clipboard %s' % sFile, bClearFirst=True, bPrint=True)
        utils.copyToClipBoard(sFile.strip().rstrip(r'\n'))

    def biggerUi(self):
        iCurrentWidith = cmds.dockControl('kangarooDock', q=True, width=True)
        cmds.dockControl('kangarooDock', e=True, sizeable=False, width=iCurrentWidith * 1.1)

    def smallerUI(self):
        iCurrentWidith = cmds.dockControl('kangarooDock', q=True, width=True)
        cmds.dockControl('kangarooDock', e=True, sizeable=False, width=iCurrentWidith * (1.0/1.1))

    def openPublishedExplorer(self, bLatest=False):
        if bLatest:
            sFile = self._getLatestPublished(bErrorIfNotExists=False)
        else:
            sFile = self._getCurrentPublished(bErrorIfNotExists=False)

        utils.debugPrint('sFile: ', sFile)
        if not sFile:
            raise Exception('published file not found (%s)' % sFile)
        sDir = os.path.dirname(sFile)
        report.report.addLogText('open explorer %s' % sDir, bClearFirst=True, bPrint=True)

        utils.openExplorer(sDir)


    def referencePublished(self, bLatest=False):
        utils.debugPrint('bLatest: ', bLatest)
        if bLatest:
            sFile = self._getLatestPublished()
        else:
            sFile = self._getCurrentPublished()
        if not sFile:
            report.report.addLogText('no file found', bClearFirst=True, bPrint=True)
        else:
            report.report.addLogText('referencing %s' % sFile, bClearFirst=True, bPrint=True)

            sFileName = sFile.split(os.sep)[-1]
            sNamespace = sFileName.split('.')[0]
            utils.importMayaFiles(sFile, sNamespace=sNamespace, bReference=True)

    def hold(self):
        tempFile = TempFile(self.getCurrentAssetPath())  # , _report=self._report)
        tempFile.saveNew(bRemoveRequiresLines=True)
        # tempFile.saveNew(bRemoveRequiresLines=True if utils.getPythonVersion() == 3 else False)
        cmds.flushUndo()

    def holdNondestructable(self):
        import kangarooTools.utilsQt as utilsQt

        def _hold(sFilename):
            if sFilename.startswith('temp'):
                cmds.confirmDialog(m='A Nondestructable file cannot start with "temp"')
                return

            sTempPath = os.path.join(self.getCurrentAssetPath(), '_temp')
            if not os.path.exists(sTempPath):
                os.makedirs(sTempPath)
            sFilePath = os.path.join(sTempPath, sFilename.split('.')[0])
            cmds.file(rename=sFilePath)
            cmds.file(save=True, typ=kTempFileType)
            cmds.flushUndo()

        self.qClusterDialog = utilsQt.QGetStringDialog(_hold, sMessage='enter scene name')
        self.qClusterDialog.show()

    def pull(self):
        tempFile = TempFile(self.getCurrentAssetPath())  # , _report=self._report)
        sFilePath = tempFile.getLatestTempFile()
        report.report.addLogText('Pulling Scene... (%s)' % sFilePath, bClearFirst=True, bPrint=True)
        cmds.file(sFilePath, o=True, f=True)


    def saveCurrentScene(self):
        cmds.file(force=True, type='mayaAscii', save=True)
        sFile = cmds.file(l=True, q=True)[0]


    def getCurrentAssetPath(self, sProject=None, bForceServer=None):  # where it all starts
        if sProject == None:
            sProject, sKey = self.getCurrentProject()
        sAssetPath = self.findAssetPath(self.getCurrentAsset(), sProject=sProject, bForceServer=bForceServer)
        return sAssetPath


    def getCurrentVersionPath(self, sSubPath=None):
        sVersionPath = os.path.join(self.getCurrentAssetPath(), '_build', self.getCurrentVersion())
        utils.debugPrint('============================= sVersionPath: ', sVersionPath)
        if sSubPath:
            sVersionPath = os.path.join(sVersionPath, sSubPath)
            if sVersionPath:
                sVersionPath = sVersionPath.replace('\\','/')
        return sVersionPath


    def getCurrentVersion(self):
        return self.qVersionSelector.currentText()


    def getModelPath(self, sAsset='__self__', sVersion='__latest__', bErrorIfNotExist=True, bForceServer=None):
        if sAsset == '__self__':
            sModelPath = os.path.join(self.getCurrentAssetPath(), '_model')
        else:
            sModelPath = os.path.join(self.getCurrentAssetPath(), os.pardir, sAsset, '_model')
        if not os.path.exists(sModelPath):
            if bErrorIfNotExist:
                raise Exception('path "%s" doesn\'t exist!' % sModelPath)
            else:
                cmds.warning('path "%s" doesn\'t exist!' % sModelPath)
                return None

        if sVersion == '__latest__':
            sVersion = utils.getLatestVersion(sModelPath)

        if sVersion:
            sVersionPath = os.path.join(sModelPath, sVersion)

            if not os.path.isdir(sVersionPath):
                if bErrorIfNotExist:
                    raise Exception('path %s doesn\'t exist!' % sVersionPath)
                else:
                    cmds.warning('path %s doesn\'t exist!' % sVersionPath)
                    return None
        else:
            sVersionPath = None

        return sVersionPath


    def updateStatusColor(self):
        bServer = self.qServer.isChecked()
        if bServer:
            self.setVersionColor(None)
        else:

            bWrongAsset = checkIfWrongAsset()
            if bWrongAsset:
                self.setVersionColor(utils.uiColors.violet)
            else:
                sCurrentAssetPath = self.getCurrentAssetPath()
                if not sCurrentAssetPath:
                    return
                sCharPath = os.path.join(sCurrentAssetPath, '_build')

                sLocalVersions = [sF for sF in os.listdir(sCharPath) if
                             sF[0] not in ['.', '_'] and os.path.isdir(os.path.join(sCharPath, sF))]

                sLocalVersions = utils.sortByNumber(sLocalVersions)

                sCurrentServerAssetPath = self.getCurrentAssetPath(bForceServer=True)
                if not sCurrentServerAssetPath:
                    self.setVersionColor(None)
                else:
                    sServerCharPath = os.path.join(sCurrentServerAssetPath, '_build')
                    try:
                        sContents = os.listdir(sServerCharPath)
                    except Exception as e:
                        cmds.warning('skipping reading server path ("%s")' % str(e))
                        sContents = []

                    sServerVersions = [sF for sF in sContents if
                                       sF[0] not in ['.', '_'] and os.path.isdir(os.path.join(sServerCharPath, sF))]

                    sServerVersions = utils.sortByNumber(sServerVersions)
                    # added the sLocalVersions length check later so it doesn't error when there are no local versions but a folder
                    if len(sServerVersions) and (len(sLocalVersions) and utils.getNumberAtEnd(sLocalVersions[-1])[1] < utils.getNumberAtEnd(sServerVersions[-1])[1]):
                        self.setVersionColor(utils.uiColors.red)  # out of date
                    else:
                        # added the sLocalVersions length check later so it doesn't error when there are no local versions but a folder
                        if (len(sLocalVersions) and self.getCurrentVersion() != sLocalVersions[-1]):
                            self.setVersionColor(utils.uiColors.orangeDark)  # up to date
                        else:
                            self.setVersionColor(None)  # up to date

                    
    def getCurrentAsset(self):
        return self.qAssetSelector.currentText()

    def assetChanged(self, iIndex, bRefreshControls=True):

        utils.debugPrint('\n\n\n\n\n\n =================================== assetChanged() ====================================\n\n\n\n')
        bServer = self.qServer.isChecked()
        # self.getCurrentAsset() = self.qAssetSelector.currentText()
        # if not self.getCurrentAsset():
        #     return

        bBlockedState = self.qVersionSelector.signalsBlocked()
        self.qProjectSelector.blockSignals(True)
        self.qVersionSelector.blockSignals(True)
        self.qAssetSelector.blockSignals(True)
        # self.qServer.blockSignals(True)
        utils.debugPrint ('blocked (04)')

        sProject, sKey = self.getCurrentProject()

        try:
            # sCharPath = os.path.join(self.getCurrentAssetRoot(), self.getCurrentAsset(), '_build')
            sCurrentAssetPath = self.getCurrentAssetPath()
            if not sCurrentAssetPath:
                return

            if not sCurrentAssetPath:
                cmds.warning('skipping %s, because it doesn\'t exist on current root' % self.getCurrentAsset())
            else:
                sCharPath = os.path.join(sCurrentAssetPath, '_build')

                self.qVersionSelector.clear()
                utils.debugPrint('sCharPath: ', sCharPath)
                sVersions = [sF for sF in os.listdir(sCharPath) if
                             sF[0] not in ['.', '_'] and os.path.isdir(os.path.join(sCharPath, sF))]

                sVersions = utils.sortByNumber(sVersions)

                for sV in sVersions:
                    self.qVersionSelector.addItem(sV)
                self.qVersionSelector.setCurrentIndex(len(sVersions) - 1)

            for sInitFile in [os.path.join(sCurrentAssetPath, '__init__.py'), # this has the confusing error when settings file doesn't exist!!
                              os.path.join(sCurrentAssetPath, '_build', '__init__.py'),
                              os.path.join(sCurrentAssetPath, os.pardir, '__init__.py')]:
                if not os.path.exists(sInitFile):
                    try:
                        utils.createEmptyTextFile(sInitFile)
                    except Exception as e:
                        cmds.warning('couldn\'t create %s (%s)' % (sInitFile, e))



            self.updateStatusColor()


        except:
            raise
        finally:
            self.qProjectSelector.blockSignals(bBlockedState)
            self.qVersionSelector.blockSignals(bBlockedState)
            self.qAssetSelector.blockSignals(bBlockedState)
            # self.qServer.blockSignals(bBlockedState)
            utils.debugPrint ('blocked (05)')

        utils.debugPrint('bRefreshControls in assetChanged: ', bRefreshControls)
        if bRefreshControls:
            utils.debugPrint('call self.refreshFilePathControls B')
            self.refreshFilePathControls()


        if iIndex >= 0:
            dConfig = settings.getSettingsFileDict()
            dDefaultAssets = dConfig.get('dDefaultAssets', {})
            dDefaultAssets[sProject] = self.getCurrentAsset()
            utils.debugPrint('\n\n\n\n\n=================== = = = = == = iIndex: ', iIndex)
            settings.updateConfigFileDict({'sCurrentProject': [sProject, sKey], 'dDefaultAssets':dDefaultAssets})


    def serverSwitched(self, bChecked=None):
        if bChecked == None:
            bChecked = self.qServer.isChecked()

        sPreviousProject, sPreviousKey = self.getCurrentProject()
        sPreviousAsset = self.getCurrentAsset()
        bFillEverything = True
        if bChecked:
            sCurrentAssetPath = self.getCurrentAssetPath(bForceServer=False)
            if sCurrentAssetPath and os.path.exists(sCurrentAssetPath):

                sServerFilePath = os.path.join(sCurrentAssetPath, os.pardir, 'server.txt')
                sKey = getServerKeyFromFile(sServerFilePath)
                dServers = getServers()
                if sKey not in dServers:
                    cmds.confirmDialog(m='server key "%s" not found. Please check your Environment Variables' % sKey)
                    self.checkServerBox(False)
                    bFillEverything = False
                else:
                    sServerPath = dServers.get(sKey)
                    if not os.path.exists(sServerPath):
                        cmds.confirmDialog(m='server path "%s" not found. Please check your Environment Variables' % sServerPath)
                        self.checkServerBox(False)
                        bFillEverything = False
                    else:
                        sProjects = [sF for sF in os.listdir(sServerPath) if utils.isProject(sF)]
                        if sPreviousProject not in sProjects:
                            if cmds.confirmDialog(m='project "%s" doesn\'t exist on "%s". Sure you want to switch to Server?' % (sPreviousProject, sServerPath),
                                                  button=['yes','no']) == 'no':
                                self.checkServerBox(False)
                                bFillEverything = False
                        else:
                            sProjectPath = os.path.join(sServerPath,sPreviousProject)
                            sAssets = [sF for sF in os.listdir(sProjectPath)]
                            if sPreviousAsset not in sAssets:
                                if cmds.confirmDialog(m='asset "%s" doesn\'t exist on "%s". Sure you want to switch to Server?' % (sPreviousAsset, sProjectPath),
                                        button=['yes', 'no']) == 'no':
                                    self.checkServerBox(False)
                                    bFillEverything = False


        else:
            utils.debugPrint ('SERVER to LOCAL')
            # if assets root not exist -> go back
            pass




        if bFillEverything == True:

            utils.debugPrint ('sPreviousProject: ', sPreviousProject)

            utils.debugPrint('\n\n\n\n\n\n =================================== serverSwitched() ====================================\n\n\n\n')
            self.qLocalizeButton.setEnabled(True if bChecked else False)
            self.qPublishButton.setEnabled(False if bChecked else True)

            # self.getCurrentAsset() = self.qAssetSelector.currentText()
            utils.debugPrint ('self.getCurrentAsset(): ', self.getCurrentAsset())
            bBlockedState = self.qVersionSelector.signalsBlocked()
            self.qProjectSelector.blockSignals(True)
            self.qVersionSelector.blockSignals(True)
            self.qAssetSelector.blockSignals(True)
            # self.qServer.blockSignals(True)
            try:
                utils.debugPrint('filling projects (2)')
                self.fillProjects(bRefreshControls=False, bSwitchServerTo=bChecked, sSwitchProjectTo=[sPreviousProject, sPreviousKey])
            except:
                raise
            finally:
                self.qProjectSelector.blockSignals(bBlockedState)
                self.qVersionSelector.blockSignals(bBlockedState)
                self.qAssetSelector.blockSignals(bBlockedState)
                # self.qServer.blockSignals(bBlockedState)

            settings.updateConfigFileDict({'bServer': bChecked})
            utils.debugPrint ('self.getCurrentAsset(): ', self.getCurrentAsset())
            utils.debugPrint('call self.refreshFilePathControls A')
            self.refreshFilePathControls()


    def refreshFilePathControls(self):
        utils.debugPrint('\n\n\n\n\n\n ---------------------------------------------------------- refreshFilePathControls() ----------------------------------------------------------\n\n\n\n')

        if not self.getCurrentAsset():
            cmds.warning('no asset specified, skipping refreshFilePathControls')
            return

        sCurrentProject, sKey = self.getCurrentProject()
        sPath = os.path.join(self.getCurrentAssetPath(sProject=sCurrentProject), '_build', self.qVersionSelector.currentText())
        # sPath = os.path.join(self.getCurrentAssetRoot(), self.getCurrentAsset(), '_build', self.qVersionSelector.currentText())
        for control in self.connectedFileControls:
            control.changeTopFolder(sPath)

        bServer = self.qServer.isChecked()
        utils.debugPrint('refreshing the enables')
        for tButton in tDisableOnServerButtons:
            tButton.setEnabled(not bServer)
        for tControl in tDisableOnServerControls:
            tControl.serverSwitch(bServer)


        self.updateServerButton()



    def refresh(self):
        self.fillProjects(sSwitchProjectTo=self.getCurrentProject(), sSwitchAssetTo=self.getCurrentAsset(), bSwitchServerTo=self.qServer.isChecked())


    def getCurrentServerKeyFromFile(self):
        try:
            sCurrentProject, sKey = self.getCurrentProject()

            sCurrentAssetPath = self.getCurrentAssetPath(sProject=sCurrentProject)

            sServerFilePath = os.path.join(sCurrentAssetPath, os.pardir, 'server.txt')
            sKey = getServerKeyFromFile(sServerFilePath)
            utils.debugPrint ('sKey: ', sKey)
            return sKey
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise


    def updateServerButton(self):
        utils.debugPrint ('\n\n\n\n ======================== updating server button... ')
        sKey = self.getCurrentServerKeyFromFile()
        utils.debugPrint ('sKey: ', sKey)
        try:
            bServer = self.qServer.isChecked()
            self.qServerButton.blockSignals(True)
            self.qServerButton.setEnabled(not bServer)
            utils.debugPrint ('sKey: ', sKey)
            self.qServerButton.setText(sKey if not bServer else '')
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            self.qServerButton.blockSignals(False)



def getServerKeyFromFile(sFile):
    dPaths = getServers()
    sServerInfo = utils.readFile(sFile) if os.path.exists(sFile) else []
    if not sServerInfo:
        try:
            sKey = 'default' if 'default' in dPaths else list(dPaths.keys())[0]
        except Exception as e:
            raise Exception('Problem getting server paths maybe your Envir Variables are not setup-ed ("%s")' % e)
    else:
        sKey = sServerInfo[0]
    return sKey




def pull():
    assetManager.pull()


def shareAsset(sProject, sAsset, sVersion, bServerToLocal, sServerAssetRoot=None, funcPre=None, funcPost=None,
               sComments='no comments', _report=None, sServerKey='default'):
    utils.debugPrint('sServerAssetRoot: ', sServerAssetRoot)

    # get the asset on the server
    if not sServerAssetRoot:
        dAssets = getAssetsFromRoots(getAllServerAssetRoots(), sProject=sProject, bReturnDict=True)
        for sRoot, sAssets in list(dAssets.items()):
            if sAsset in sAssets:
                sServerAssetRoot = sRoot  # os.path.join(sRoot, sAsset)

    utils.debugPrint('sServerAssetRoot: ', sServerAssetRoot)
    if not sServerAssetRoot:
        raise Exception('cannot find asset on server').with_traceback(sServerAssetRoot)

    if bServerToLocal:
        sFromRoot = sServerAssetRoot
        sToRoot = getLocalAssetRoot()
    else:
        sFromRoot = getLocalAssetRoot()
        sToRoot = sServerAssetRoot

    sFromAssetFolder = os.path.join(sFromRoot, sProject, sAsset)
    sToAssetFolder = os.path.join(sToRoot, sProject, sAsset)

    if funcPre:
        sNewToAssetFolder = funcPre(sProject, sAsset, sToRoot)
        if sNewToAssetFolder:
            sToAssetFolder = sNewToAssetFolder

    for sDir in ['_build', '_model', '_published']:
        sAbsToDir = os.path.join(sToAssetFolder, sDir)
        if not os.path.exists(sAbsToDir):
            os.makedirs(sAbsToDir)

    if bServerToLocal:
        sServerFile = os.path.join(sToRoot, sProject, 'server.txt')
        utils.createTextFile(sServerFile, sServerKey)



    for sInitFile in [os.path.join(sToAssetFolder, '__init__.py'),
                      os.path.join(sToAssetFolder, '_build', '__init__.py')]:
        if not os.path.exists(sInitFile):
            try:
                utils.createEmptyTextFile(sInitFile)
            except Exception as e:
                cmds.warning('couldn\'t create %s (%s)' % (sInitFile, e))

    report.report.incrementProgress()

    sFromVersionFolder = os.path.join(sFromAssetFolder, '_build', sVersion).replace('\\', '/')
    sToVersionFolder = os.path.join(sToAssetFolder, '_build', sVersion).replace('\\', '/')
    bCopyBuildFolder = True
    if os.path.exists(sToVersionFolder):
        sButtonReturn = cmds.confirmDialog(m='%s already exists, what to do?' % sToVersionFolder, button=['skip', 'rename old and localize new'])
        if sButtonReturn == 'skip':
            bCopyBuildFolder = False
        elif sButtonReturn.startswith('rename'):
            i = 0
            while True:
                sMovedOldVersionFolder = os.path.join(sToAssetFolder, '_build', '_old_%s_%d' % (sVersion, i)).replace('\\', '/')
                if not os.path.exists(sMovedOldVersionFolder):
                    break
                i += 1
            os.rename(sToVersionFolder, sMovedOldVersionFolder)

    if bCopyBuildFolder:
        utilsQt.copyWithProgressBar(sFromVersionFolder, sToVersionFolder, '%s %s of %s' % ('localizing' if bServerToLocal else 'publishing', sVersion, sAsset))

    report.report.incrementProgress()

    # copy model if needed
    #
    sBuildFile = os.path.join(sFromVersionFolder, 'build.bld').replace('\\', '/')
    utils.debugPrint('loading json file %s...' % sBuildFile)
    with open(sBuildFile) as file:
        dBuildData = json.load(file)
    dDatas = dBuildData['__FUNCTIONDATAS__']

    try:
        sModelVersionString = dDatas['importModel']['dFileArgs']['sVersion']
    except:
        sModelVersionString = '__latest__'

    sCurrentModelVersionFolder = assetManager.getModelPath(sAsset, sModelVersionString, bForceServer=bServerToLocal, bErrorIfNotExist=False)
    if sCurrentModelVersionFolder:
        sToModelFolder = os.path.join(sToAssetFolder, '_model', sCurrentModelVersionFolder.split(os.sep)[-1])
        if os.path.exists(sToModelFolder):
            report.report.addLogText('model already exists: %s ' % sToModelFolder, bPrint=True)
        else:
            report.report.addLogText('copying model to %s ' % sToModelFolder, bPrint=True)
            if os.path.exists(sToModelFolder):
                report.report.addLogText('WARNING: not publishing model, since that folder already exists:  %s ' % sToModelFolder, bPrint=True)
            else:
                utilsQt.copyWithProgressBar(sCurrentModelVersionFolder, sToModelFolder, 'copying model')
                # shutil.copytree(sCurrentModelVersionFolder, sToModelFolder)



    if os.path.exists(os.path.join(sFromAssetFolder, '_published', sVersion)):
        sPublishContents = [sVersion]
    else:
        sPublishContents = []
        sPublishedDir = os.path.join(sFromAssetFolder, '_published')
        if os.path.exists(sPublishedDir):
            sContents = os.listdir(sPublishedDir)
            for sC in sContents:
                if '%s.' % sVersion in sC or sC.startswith('%s ' % sVersion):
                    sPublishContents.append(sC)


    for sFileName in sPublishContents:
        sFromRig = os.path.join(sFromAssetFolder, '_published', sFileName).replace('\\', '/')
        if os.path.exists(sFromRig):
            sToRig = os.path.join(sToAssetFolder, '_published', sFileName).replace('\\', '/')

            bCopyPublishedFolder = True
            if os.path.exists(sToRig):
                sButtonReturn = cmds.confirmDialog(m='%s already exists, what to do?' % sToRig,
                                                   button=['skip', 'rename old and localize new'])
                if sButtonReturn == 'skip':
                    bCopyPublishedFolder = False
                elif sButtonReturn.startswith('rename'):
                    i = 0
                    while True:
                        sMovedOldRig = os.path.join(sToAssetFolder, '_published', '_old_%s_%d' % (sFileName, i)).replace('\\', '/')
                        if not os.path.exists(sMovedOldRig):
                            break
                        i += 1
                    os.rename(sToRig, sMovedOldRig)

            if bCopyPublishedFolder:
                report.report.addLogText('copying published folder to: %s ' % sToRig, bPrint=True)
                if os.path.isdir(sFromRig):
                    utilsQt.copyWithProgressBar(sFromRig, sToRig, 'copying _published')
                else:
                    shutil.copy(sFromRig, sToRig)
    if funcPost:
        funcPost(sProject, sToAssetFolder, sComments)


utils.kExportNode = '__export__'


def publishRig(sProject, sAsset, sVersion, ddMasters):
    report.report.resetProgress(6)

    bVersionFolders = utils.data.get('bVersionFolders', xDefault=True, sNode=utils.kExportNode)
    # sServerAssetPathEntry = utils.data.get('sServerAssetPathEntry', xDefault='serverAssetPath', sNode=utils.kExportNode)
    sShareFuncPre = utils.data.get('sShareFuncPre', xDefault=None, sNode=utils.kExportNode, bForceString=True)
    sShareFuncPost = utils.data.get('sShareFuncPost', xDefault=None, sNode=utils.kExportNode, bForceString=True)
    sPublishFuncPre = utils.data.get('sPublishFuncPre', xDefault=None, sNode=utils.kExportNode, bForceString=True)
    bOpenRigFile = utils.data.get('bOpenRigFile', xDefault=False, sNode=utils.kExportNode)
    bOpenCopiedRigFile = utils.data.get('bOpenCopiedRigFile', xDefault=False, sNode=utils.kExportNode)
    bSaveInsteadOfExport = utils.data.get('bSaveInsteadOfExport', xDefault=False, sNode=utils.kExportNode)

    if bSaveInsteadOfExport and len(ddMasters) > 1:
        raise Exception('bSaveInsteadOfExport can only be True if there is just one master')

    dConfirms = utils.data.get('dConfirms', xDefault={}, sNode=utils.kExportNode)
    for sMessage, xOptions in list(dConfirms.items()):
        dOptions = dict(xOptions)
        sResult = cmds.confirmDialog(t='confirm', m=sMessage, button=[xO[0] for xO in xOptions])
        if dOptions[sResult] == False:
            utils.debugPrint('canceling')
            return

    utils.debugPrint('sShareFuncPre: ', sShareFuncPre)
    if sShareFuncPre:
        sSplits = sShareFuncPre.split('.')
        mod = importlib.import_module('.'.join(sSplits[:-1]))
        funcSharePre = getattr(mod, sSplits[-1])
    else:
        funcSharePre = None

    if sShareFuncPost:
        sSplits = sShareFuncPost.split('.')
        mod = importlib.import_module('.'.join(sSplits[:-1]))
        funcSharePost = getattr(mod, sSplits[-1])
    else:
        funcSharePost = None

    if sPublishFuncPre:
        sSplits = sPublishFuncPre.split('.')
        mod = importlib.import_module('.'.join(sSplits[:-1]))
        funcPublishPre = getattr(mod, sSplits[-1])
        funcPublishPre()

    try:
        sServerKey = getServerKeyFromFile(os.path.join(getLocalAssetRoot(), sProject, 'server.txt'))

        sAssetFolder = os.path.join(getLocalAssetRoot(), sProject, sAsset)
        dServers = getServers()
        if sServerKey not in dServers:
            raise Exception('server key "%s" not in paths.txt' % sServerKey)
        sServerAssetRoot = dServers[sServerKey]

        if not os.path.exists(sServerAssetRoot):
            raise Exception('server path doesn\'t exist: %s' % sServerAssetRoot)

        sServerAssetFolder = os.path.join(sServerAssetRoot, sProject, sAsset)

        sLocalPublishFolder = os.path.join(sAssetFolder, '_published')
        sServerPublishFolder = os.path.join(sServerAssetFolder, '_published')


        sVersionParentFolders = [os.path.join(sAssetFolder, '_build'), sLocalPublishFolder,
                                 os.path.join(sServerAssetFolder, '_build'), sServerPublishFolder]

        iCurrentHighestExistingVersion = 0
        for sParentFolder in sVersionParentFolders:
            if os.path.exists(sParentFolder):
                for sContent in os.listdir(sParentFolder):
                    try:
                        sVersionText, iNumber = utils.getNumberAtEnd(sContent)
                        if sVersionText == 'v' and iNumber > iCurrentHighestExistingVersion:
                            iCurrentHighestExistingVersion = iNumber
                    except Exception as e:
                        print('skipping checking "%s" - %s' % (sContent, str(e)))

        sNewVersion = 'v%d' % (iCurrentHighestExistingVersion + 1)
        sNewVersionFolder = os.path.join(sAssetFolder, '_build', sNewVersion)
        # sServerNewVersionFolder = os.path.join(sServerAssetFolder, '_build', sNewVersion)

        if bVersionFolders:
            sLocalPublishFolder = os.path.join(sLocalPublishFolder, sNewVersion)
            sServerPublishFolder = os.path.join(sServerPublishFolder, sNewVersion)

        for sMaster, dData in list(ddMasters.items()):
            sFilename = dData['sFilename'].replace('[v]', sNewVersion)
            # sNewRig = os.path.join(sLocalPublishFolder, sFilename)
            # sServerNewRig = os.path.join(sServerPublishFolder, sFilename)


        utils.debugPrint('version: ', sNewVersion)

        sUsername = getpass.getuser()

        # version attr
        sCurrentVersion = sVersion
        utils.debugPrint('ddMasters...: ', ddMasters)
        sRigFilePath = None
        for sMaster, dData in list(ddMasters.items()):
            sDelete = dData.get('sDelete', [])
            if sDelete:
                sDeleteNodes = []
                for sD in sDeleteNodes:
                    sDeleteNodes += cmds.ls(sD)
                if sDeleteNodes:
                    cmds.delete(sDeleteNodes)

            utils.debugPrint('sMaster: ', sMaster)
            sComments = dData['sComments']
            bMasterIsFile = dData.get('bMasterIsFile', False)
            if not bMasterIsFile:
                utils.addStringAttr(sMaster, '__project__', sProject, bLock=True)
                utils.addStringAttr(sMaster, '__asset__', sAsset, bLock=True)
                utils.addStringAttr(sMaster, '__version__', sNewVersion, bLock=True)
                utils.addStringAttr(sMaster, '__user__', sUsername, bLock=True)
                utils.addStringAttr(sMaster, '__comments__', sComments, bLock=True)

                sModelVersion = None
                sModel = utils.data.get('sModelGroupName', xDefault=utils.replaceStringStart(sMaster, 'master', 'model'))
                if sModel != sMaster and cmds.objExists(sModel):
                    for sGrp in cmds.listRelatives(sModel, typ='transform', p=False, c=True) or []:
                        if 'MODEL' in sGrp.split('_')[0]:
                            utils.addStringAttr(sMaster, '__model__', sGrp, bLock=True)
                            sModelVersion = sGrp
                            break

                # report.report.addLogText('\ngetting git hash.... ')
                # try:
                #     sGitHash = utils.getGitHash()
                #     report.report.addLogText(sGitHash)
                # except Exception as e:
                #     sGitHash = 'Error getting Git Hash'
                #     report.report.addLogText('error getting Git Hash', e)

                # utils.addStringAttr(sMaster, '__gitHash__', sGitHash, bLock=True)
            report.report.incrementProgress()

            # saving rig
            sNewRigName = dData['sFilename'].replace('[v]', sNewVersion)
            sNewRig = os.path.join(sLocalPublishFolder, sNewRigName)
            sRigFilePath = sNewRig
            report.report.addLogText('\nsaving to: %s' % sNewRig, bPrint=True)
            sDir = os.path.dirname(sNewRig)
            if not os.path.exists(sDir):
                os.makedirs(sDir)
            for sObj in ['__faceData__']:
                if cmds.objExists(sObj):
                    cmds.delete(sObj)
            # cmds.file(rename=sNewRig)
            # cmds.file(type='mayaAscii', save=True)

            if bMasterIsFile:
                shutil.copyfile(sMaster, sNewRig)
            else:
                if bSaveInsteadOfExport:
                    sDeleteInfoNodes = []

                    for sT in cmds.ls(et='transform'):
                        if not cmds.listRelatives(sT, p=True):
                            if sT.startswith('__') and sT.endswith('__'):
                                sDeleteInfoNodes.append(sT)
                            if sT in ['_blueprints', '_blueprintsTemp']:
                                sDeleteInfoNodes.append(sT)

                    if sDeleteInfoNodes:
                        cmds.delete(sDeleteInfoNodes)

                    cmds.file(rename=sNewRig)
                    cmds.file(save=True, typ='mayaAscii' if sNewRig.endswith('.ma') else 'mayaBinary') # if this errors, it could be disk full
                else:
                    cmds.select(sMaster)
                    sAdditionalNodes = dData.get('sAdditionalNodes', [])
                    if sAdditionalNodes:
                        cmds.select(sAdditionalNodes, add=True)

                    cmds.file(sNewRig, pr=False, es=True, force=True,
                              typ='mayaAscii' if sNewRig.endswith('.ma') else 'mayaBinary',
                              options="v=0;", constructionHistory=True)

            # creating comments
            try:
                sCommentsWithModel = sComments + '\n\nmodel: %s\n' % sModelVersion
            except:
                sCommentsWithModel = sComments

            sCommentsPath = os.path.join(sDir, '_comments_.txt')
            file = open('%s' % sCommentsPath, 'w')
            file.write(time.strftime('Published on %a, %d %b %Y %H:%M:%S\n', time.gmtime()))
            file.write('by %s\n\n' % sUsername)
            file.write(sCommentsWithModel)
            file.close()

            sComments2Formatted = sComments.replace('\n', ' ').replace('\\', '').replace('/', '').replace(':', '-')
            sComments2Formatted = ' '.join(sComments2Formatted.split(None))
            sComments2Path = os.path.join(sDir, '%s %s - %s' % (sNewVersion, sComments2Formatted, sUsername))
            try:
                file = open('%s' % sComments2Path, 'w')
                file.close()
            except:
                report.report.addLogText('couldn\'t create file with comments: "%s"' % sComments2Path, bPrint=True)
            # end of creating comments

            report.report.incrementProgress()
            sCopyOutputToFolder = dData.get('sCopyOutputToFolder', None)
            report.report.addLogText('sCopyOutputToFolder: ', sCopyOutputToFolder, bPrint=True)
            if sCopyOutputToFolder:
                sCopyOutputToFolder = sCopyOutputToFolder.replace('[v]', sNewVersion)
                report.report.addLogText('copy output to: %s ("sCopyOutputToFolder")' % sCopyOutputToFolder, bPrint=True)

                if not os.path.exists(sCopyOutputToFolder):
                    os.makedirs(sCopyOutputToFolder)
                shutil.copy(sNewRig, sCopyOutputToFolder)
                shutil.copy(sCommentsPath, sCopyOutputToFolder)
                sCopiedRigFilePath = os.path.join(sCopyOutputToFolder, os.path.basename(sNewRig))

            sExtraFiles = dData.get('sExtraFiles')
            if sExtraFiles:
                for sExtraFile in utils.toList(sExtraFiles):
                    sAbsExtraFile = os.path.join(sAssetFolder, '_build', sVersion, sExtraFile).replace('\\', '/')
                    if not os.path.exists(sAbsExtraFile):
                        report.report.addLogText('WARNING: "%s" doesn\'t exist' % sAbsExtraFile, bPrint=True)
                        continue
                    report.report.addLogText('sAbsExtraFile: %s' % sAbsExtraFile, bPrint=True)
                    utils.debugPrint('sExtraFile: ', sExtraFile)
                    sSplits = sExtraFile.split('/')[-1].split('.')
                    sNewFileName = '%s_%s.%s' % (sSplits[0], sNewVersion, sSplits[1])
                    shutil.copy(sAbsExtraFile, os.path.join(sLocalPublishFolder.replace('\\', '/'), sNewFileName))
                    if sCopyOutputToFolder:
                        shutil.copy(sAbsExtraFile, os.path.join(sCopyOutputToFolder.replace('\\', '/'), sNewFileName))

        # copying _build version folder
        report.report.addLogText('creating new version %s' % sNewVersionFolder, bPrint=True)
        sCopyFrom = os.path.join(sAssetFolder, '_build', sCurrentVersion)
        utils.debugPrint('copy tree: %s -> %s' % (sCopyFrom, sNewVersionFolder))
        utilsQt.copyWithProgressBar(sCopyFrom, sNewVersionFolder, 'copying to new version folder')
        # shutil.copytree(sCopyFrom, sNewVersionFolder)
        report.report.incrementProgress()

        shareAsset(sProject, sAsset, sNewVersion, bServerToLocal=False, funcPre=funcSharePre, funcPost=funcSharePost,
                   sComments=sComments, sServerAssetRoot=sServerAssetRoot)

        report.report.incrementProgress()

        # reload the assets to increment
        report.report.addLogText('reloading assets in UI', bPrint=True)
        utils.debugPrint('filling projects (1)')
        assetManager.fillProjects(sSwitchProjectTo=assetManager.getCurrentProject(),
                                  sSwitchAssetTo=assetManager.getCurrentAsset(),
                                  bSwitchServerTo=assetManager.qServer.isChecked())
        cmds.refresh()

        if bOpenRigFile:
            report.report.addLogText('opening file "%s"' % sRigFilePath, bRefresh=True, bPrint=True)
            cmds.file(sRigFilePath, o=True, f=True, prompt=False)
        elif bOpenCopiedRigFile:
            report.report.addLogText('opening copied file file "%s"' % sCopiedRigFilePath, bRefresh=True, bPrint=True)
            cmds.file(sCopiedRigFilePath, o=True, f=True, prompt=False)


    except Exception:
        sError = traceback.format_exc()
        sError = 'RELOAD ERROR: %s' % sError
        report.report.addLogText(sError, sColor=utils.uiColors.red, bQuotationsToLink=True, bPrint=True)
        report.report.setProgressBarColor(utils.uiColors.red)
        report.report.setToFull()
        raise Exception(traceback.format_exc())


def _createScrollLayout(qParentWidget):
    qScrollArea = QtWidgets.QScrollArea()
    qScrollArea.setWidgetResizable(True)
    qParentWidget.addWidget(qScrollArea)
    qReturnLayout = QtWidgets.QVBoxLayout()
    qReturnLayout.setAlignment(QtCore.Qt.AlignTop)
    qToolControlsLayoutWidget = QtWidgets.QWidget()
    qToolControlsLayoutWidget.setLayout(qReturnLayout)
    qScrollArea.setWidget(qToolControlsLayoutWidget)
    return qReturnLayout


class PublishUI(QtWidgets.QDialog):

    def __init__(self, ddMasters, funcCallback):
        super(PublishUI, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qComments = QtWidgets.QTextBrowser()
        self.qComments.setReadOnly(False)
        layout.addWidget(self.qComments)
        self.ddMasters = ddMasters
        utils.debugPrint('self.ddMasters.keys(): ', list(self.ddMasters.keys()))
        self.dCommentsMasters = {}

        if len(self.ddMasters) > 1:
            qScrollLayout = _createScrollLayout(layout)
            for sMaster in list(self.ddMasters.keys()):
                qLabel = QtWidgets.QLabel(sMaster)
                qScrollLayout.addWidget(qLabel)
                qComments = QtWidgets.QTextBrowser()
                qComments.setReadOnly(False)
                # qComments.setMinimumHeight(500)
                qScrollLayout.addWidget(qComments)
                self.dCommentsMasters[sMaster] = qComments

        self.funcCallback = funcCallback

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

    def okClicked(self):
        sMainComments = self.qComments.toPlainText()

        for sMaster in list(self.ddMasters.keys()):
            if sMaster in self.dCommentsMasters:
                sComments = '%s\n%s' % (sMainComments, self.dCommentsMasters[sMaster].toPlainText())
            else:
                sComments = sMainComments
            self.ddMasters[sMaster]['sComments'] = sComments

        self.close()
        self.funcCallback(self.ddMasters)



def projectNameNice(sProject):
    if not len(sProject):
        return 'ROOT'
    else:
        return sProject[2:-2]



def checkIfAssetWasBuiltInCurrentAssetConfirmBox():
    sBuiltAsset = utils.data.get('sBuildingAsset', xDefault=[])
    bDoIt = True
    if len(sBuiltAsset):
        sProject, sAsset = sBuiltAsset
        sCurrentProject = getCurrentProject()
        sCurrentAsset = assetManager.getCurrentAsset()
        if sProject != sCurrentProject or sAsset != sCurrentAsset:
            sNo = 'No, Cancel'
            if cmds.confirmDialog(title='Different Asset',
                                  message='The asset that was built was %s/%s, but you are in %s/%s. Continue?' % (
                                          sProject, sAsset, sCurrentProject, sCurrentAsset),
                                  button=['Yes', sNo],
                                  defaultButton='Yes', cancelButton=sNo, dismissString=sNo) == sNo:
                bDoIt = False
    return bDoIt


def checkIfWrongAsset():
    sBuiltAsset = utils.data.get('sBuildingAsset', xDefault=[])
    if len(sBuiltAsset):
        sProject, sAsset = sBuiltAsset
        sCurrentProject = getCurrentProject()
        sCurrentAsset = assetManager.getCurrentAsset()
        if sProject != sCurrentProject or sAsset != sCurrentAsset:
            return True


