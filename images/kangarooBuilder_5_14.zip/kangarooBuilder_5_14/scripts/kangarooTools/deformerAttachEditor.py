###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt
import kangarooTools.deformers as deformers


qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)
qBoldFont = QtGui.QFont()
qBoldFont.setBold(True)
# _kRowHeight = utilsQt.getDpi() / 4


class QDeformerAttachUi(QtWidgets.QDialog):

    def __init__(self, sCurrentText, funcReturn):
        super(QDeformerAttachUi, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)

        self.sCurrentText = sCurrentText

        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.setWindowTitle('Kangaroo DeformerAttach Editor')

        self.qMeshLayout = QtWidgets.QHBoxLayout()
        self.layout.addLayout(self.qMeshLayout)
        self.qMeshField = QtWidgets.QLineEdit()
        # self.qMeshField.setText(sMesh)
        qMeshButton = QtWidgets.QPushButton('<<')
        qMeshButton.clicked.connect(self.meshClicked)
        self.qMeshLayout.addWidget(self.qMeshField)
        self.qMeshLayout.addWidget(qMeshButton)

        self.qDeformerTable = QtWidgets.QTableWidget()
        self.qDeformerTable.setColumnCount(1)
        self.qDeformerTable.horizontalHeader().setStretchLastSection(True)
        self.qDeformerTable.horizontalHeader().hide()
        self.qDeformerTable.verticalHeader().hide()
        self.qDeformerTable.itemSelectionChanged.connect(self.updateResult)
        self.layout.addWidget(self.qDeformerTable)

        qVertexIdLayout = QtWidgets.QHBoxLayout()
        qVertexIdLayout.addWidget(QtWidgets.QLabel('Vertex Id:'))
        self.qVertexId = QtWidgets.QLineEdit('')
        qVertexIdLayout.addWidget(self.qVertexId)
        self.qVertexId.textChanged.connect(self.updateResult)
        self.layout.addLayout(qVertexIdLayout)

        qIntValidator = QtGui.QIntValidator(self)
        self.qVertexId.setValidator(qIntValidator)
        qVertexIdButton = QtWidgets.QPushButton('Set from Selected Vertex')
        qVertexIdButton.clicked.connect(self.setVertexIdFromSelection)
        qVertexIdLayout.addWidget(qVertexIdButton)

        self.qResultString = QtWidgets.QLineEdit()
        self.qResultString.setEnabled(False)
        self.layout.addWidget(self.qResultString)

        self.saveButton = QtWidgets.QPushButton('Save')
        self.saveButton.clicked.connect(self.save)
        self.layout.addWidget(self.saveButton)
        self.saveButton.setEnabled(False)

        self.updateFromText(self.sCurrentText)

        self.funcReturn = funcReturn
        self.resize(1500, 500)

    def setVertexIdFromSelection(self):
        for sObj in cmds.ls(sl=True, flatten=True):
            if '.vtx[' in sObj:
                iVertexId = utils.indexFromName(sObj)
                self.qVertexId.setText(str(iVertexId))



    def updateResult(self):
        sMesh = self.qMeshField.text()
        qDeformers = self.qDeformerTable.selectedItems()
        sDeformers = [qD.data(QtCore.Qt.UserRole) for qD in qDeformers]
        sResultList = ['deformers', sMesh] + sorted(sDeformers)
        sResult = ';'.join(sResultList)
        sResult = '%s+%s' % (sResult, self.qVertexId.text())
        self.qResultString.setText(sResult)
        self.saveButton.setEnabled(self.sCurrentText != sResult)


    def updateFromText(self, sText):
        sAtSplits = sText.split('+')
        sFirstText = sAtSplits[0]
        iVertexId =  int(sAtSplits[1]) if len(sAtSplits) > 1 and sAtSplits[1] else None

        sSplits = sFirstText.split(';') if ';' in sFirstText else sFirstText.split(':')

        if len(sSplits) > 1:
            sMesh = sSplits[1]
            self.qMeshField.setText(sMesh)
            if len(sSplits) > 2:
                sDeformers = sSplits[2:]
                self.updateDeformersFromMesh(sMesh, sDeformers)
        self.qVertexId.setText('' if utils.isNone(iVertexId) else str(iVertexId))


    def meshClicked(self):
        sMesh = cmds.ls(sl=True)[0]
        self.qMeshField.setText(sMesh)
        self.updateDeformersFromMesh(sMesh)
        self.updateResult()


    def updateDeformersFromMesh(self, sMesh, sCurrentTextDeformers=[]):
        sExistingDeformers = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape', 'skinCluster'])
        sAllDeformers = utils.removeDuplicatesKeepOrder(sExistingDeformers + sCurrentTextDeformers)

        self.qDeformerTable.clear()
        self.qDeformerTable.setRowCount(len(sAllDeformers))
        self.qDeformerTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
        for d,sD in enumerate(sAllDeformers):

            if sD in sExistingDeformers:
                sName = sD
                qFont = qBoldFont
            else:
                sName = '%s (not existing)' % sD
                qFont = qItalicFont

            qDeformer = QtWidgets.QTableWidgetItem(sName)
            qDeformer.setFont(qFont)

            qDeformer.setData(QtCore.Qt.UserRole, sD)
            self.qDeformerTable.setItem(d,0, qDeformer)
            if sD in sCurrentTextDeformers:
                self.qDeformerTable.selectRow(d)
        self.qDeformerTable.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)


    def save(self):
        self.funcReturn(self.qResultString.text())
        self.close()

