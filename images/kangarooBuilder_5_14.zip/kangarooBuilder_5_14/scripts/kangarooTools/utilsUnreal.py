###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2
import numpy as np
import math
import os
import re
import kangarooTools.utilFunctions as utils
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTabTools.ctrls7 as ctrls7
from collections import defaultdict
bOrganizeInFunction = False

kUnrealControlsToShape = 'sUnrealControlsToShape'
kUnrealCodeLines = 'sUnrealCodeLines'
# kUnrealMocapCodeLines = 'sUnrealMocapCodeLines'
kUnrealBackwardsCodeLines = 'sUnrealBackwardsCodeLines'
kUnrealControlReplacements = 'kUnrealControlReplacements' # remove!!
kUnrealOutputReplacements = 'kUnrealOutputReplacements' # remove!!

kUnrealFaceNodeTag = 'unrealFaceNode'
kBlendShapeTargetList = 'blendShapeTargetList'
kBlendShapeTargetInbetweensList = 'blendShapeTargetInbetweenList'
kCreatedUnrealCtrls = 'sCreatedUnrealCtrls'
kCreatedUnrealSliderCtrls = 'sCreatedUnrealSliderCtrls'
kBodyBlendShapeTargetList = 'bodyBlendShapeTargetList'


dFileSuffixesFromKeys = {}
dFileSuffixesFromKeys[kUnrealCodeLines] = ''
dFileSuffixesFromKeys[kUnrealBackwardsCodeLines] = '_backwards'



dControlRigCtrlShapes = {}
dControlRigCtrlShapes['cylinder'] = ['Circle_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['wedge'] = ['Box_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['cube'] = ['Box_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['squareX'] = ['Square_Thick', (0,0,-90), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['squareY'] = ['Square_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['squareZ'] = ['Square_Thick', (90,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['circleX'] = ['Circle_Thick', (0,0,-90), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['circleY'] = ['Circle_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['circleZ'] = ['Circle_Thick', (90,0,0), (0,0,0), (1,1,1)] # Not tested yet. guessed the number from SquareZ
dControlRigCtrlShapes['locator'] = ['Sphere_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['halfCircleY'] = ['HalfCircle_Thick', (0,-90,0), (0,0,0), (1,1,1)] # tried: (0,0,-90), (90,0,0), then (0,90,0), and (0,0,-90)
dControlRigCtrlShapes['arrowCurveX'] = ['Sphere_Thick', (0,0,0), (0,0,0), (0.005,1,1)]
dControlRigCtrlShapes['circleCrossX'] = ['Sphere_Thick', (0,0,0), (0,0,0), (0.005,1,1)]
dControlRigCtrlShapes['sphere'] = ['Sphere_Thick', (0,0,0), (0,0,0), (0.005,1,1)]
dControlRigCtrlShapes['revL_y'] = ['Square_Thick', (0,0,0), (0,0,0), (1,1,1)]
dControlRigCtrlShapes['revL_z'] = ['Square_Thick', (90,0,0), (0,0,0), (1,1,1)]


dMetahumanTwistReplacements = {}
dMetahumanTwistReplacements['jnt_l_arm_upperTwist_000'] = 'game:upperarm_l'
dMetahumanTwistReplacements['jnt_l_arm_lowerTwist_000'] = 'game:lowerarm_l'
dMetahumanTwistReplacements['jnt_r_arm_upperTwist_000'] = 'game:upperarm_r'
dMetahumanTwistReplacements['jnt_r_arm_lowerTwist_000'] = 'game:lowerarm_r'
dMetahumanTwistReplacements['jnt_l_leg_upperTwist_000'] = 'game:thigh_l'
dMetahumanTwistReplacements['jnt_l_leg_lowerTwist_000'] = 'game:calf_l'
dMetahumanTwistReplacements['jnt_r_leg_upperTwist_000'] = 'game:thigh_r'
dMetahumanTwistReplacements['jnt_r_leg_lowerTwist_000'] = 'game:calf_r'


def startFunction(sName, bSequencer=False, sWriteCommands=[]):
    sWriteCommands.append("nodes.startFunction('%s', bSequencer=%s)" % (sName, bSequencer))


def endCurrentfunction(sWriteCommands=[]):
    sWriteCommands.append("nodes.endCurrentFunction()")


def setNewColumn(sWriteCommands=[]):
    sWriteCommands.append('controllers.setNewColumn()')


def newSequencerPlug(sWriteCommands=[]):
    sWriteCommands.append('nodes.newSequencerPlug()')


def commentsBoxOpen(sComment, sWriteCommands=[]):
    if not isinstance(sWriteCommands, list):
        raise Exception('sWriteCommands needs to be a list')
    sWriteCommands.append("controllers.openCommentBox('%s')" % sComment)

def commentsBoxClose(sComment, sWriteCommands=[]):
    if not isinstance(sWriteCommands, list):
        raise Exception('sWriteCommands needs to be a list')
    sWriteCommands.append("controllers.closeCommentBox('%s')" % sComment)

def addCtrlOffset(cCtrl, sOffsetName, sWriteCommands=[]):
    sNullName = 'eStr%s_%s' % (cCtrl.sCtrl, sOffsetName)
    sWriteCommands.append("%s = %s.addOffset('%s')" % (sNullName, cCtrl.sCtrl, sOffsetName))
    return sNullName


def getUnrealCtrlName(sCtrlName):
    if sCtrlName.endswith('__'):
        sCtrlName = utils.replaceStringEnd(sCtrlName, '__', '_ctrl')
    return sCtrlName


sFilteredChannelStrings = {}
sFilteredChannelStrings['t'] = ['TRANSLATION_X', 'TRANSLATION_Y', 'TRANSLATION_Z']
sFilteredChannelStrings['tx'] = ['TRANSLATION_X']
sFilteredChannelStrings['ty'] = ['TRANSLATION_Z']
sFilteredChannelStrings['tz'] = ['TRANSLATION_Y']
sFilteredChannelStrings['translateX'] = ['TRANSLATION_X']
sFilteredChannelStrings['translateY'] = ['TRANSLATION_Z']
sFilteredChannelStrings['translateZ'] = ['TRANSLATION_Y']
sFilteredChannelStrings['r'] = ['PITCH', 'YAW', 'ROLL']
sFilteredChannelStrings['ro'] = []
sFilteredChannelStrings['rx'] = ['PITCH']
sFilteredChannelStrings['ry'] = ['ROLL']
sFilteredChannelStrings['rz'] = ['YAW']
sFilteredChannelStrings['rotateX'] = ['PITCH']
sFilteredChannelStrings['rotateY'] = ['ROLL']
sFilteredChannelStrings['rotateZ'] = ['YAW']
sFilteredChannelStrings['s'] = ['SCALE_X', 'SCALE_Y', 'SCALE_Z']
sFilteredChannelStrings['scaleUF'] = ['SCALE_X', 'SCALE_Y', 'SCALE_Z']
sFilteredChannelStrings['scaleX'] = ['SCALE_X']
sFilteredChannelStrings['scaleY'] = ['SCALE_Z']
sFilteredChannelStrings['scaleZ'] = ['SCALE_Y']
sChannelOrder = ['TRANSLATION_X', 'TRANSLATION_Y', 'TRANSLATION_Z', 'PITCH', 'YAW', 'ROLL', 'SCALE_X', 'SCALE_Y', 'SCALE_Z']
dChannelOrder = {sV:i for sV,i in zip(sChannelOrder, range(len(sChannelOrder)))}


def getFilteredChannelsFromAttrs(sAttrs):
    sFilteredChannels = []
    for sAttr in sAttrs:
        sFilteredChannels.extend(sFilteredChannelStrings.get(sAttr, []))
    sFilteredChannels = list(set(sFilteredChannels))
    sFilteredChannels = sorted(list(set(sFilteredChannels)), key=lambda x:dChannelOrder[x])
    return sFilteredChannels


def createUnrealCtrl(cCtrl, sParentVar='eOrigin', fSize=5.0, sShapeName=None, fCtrlOrient=(0,0,0), bOut=False, bOffsets=False, sSkipOffsets=[], sTrsValuesOnOffsets=[],
                     bNoPasser=False, bMatchPasser=False, bProxy=False, eStrDrivenControls=[], bExtraSliderScale=False, fOverwriteColor=None, sWriteCommands=[], sShapeParent=None):
    ffMatrix, fSliderScale = mayaToUnrealMatrix(cCtrl, bMatchPasserPositionWhenCtrl=bMatchPasser)
    # EXCLUDE START CONTROLRIG
    if sShapeName == None:
        sMayaShapeName = cmds.getAttr('%s.__sShape__' % cCtrl.sCtrl)
        sShapeName, fShapeOrient, fShapeTranslate, fShapeScale = dControlRigCtrlShapes.get(sMayaShapeName, ['Circle_Thin', (0,0,0), (0,0,0), (1,1,1)])
    else:
        fShapeOrient, fShapeTranslate, fShapeScale = (0,0,0), (0,0,0), (1,1,1)

    sCtrlName = getUnrealCtrlName(cCtrl.sCtrl)

    sCtrlIndex = '' if utils.isNone(cCtrl.iIndex) else '%03d' % cCtrl.iIndex
    fOrientSum = [fCtrlOrient[0]+fShapeOrient[0], fCtrlOrient[1]+fShapeOrient[1], fCtrlOrient[2]+fShapeOrient[2]]
    ffShapeMatrix = eulerToMatrix(fOrientSum, bFlipAxesToUnreal=False)
    ffShapeMatrix = setScaleToMatrix(ffShapeMatrix, [fSize*fShapeScale[0], fSize*fShapeScale[1], fSize*fShapeScale[2]])
    ffUnrealShapeMatrix = flipMatrixAxesToUnreal(ffShapeMatrix)

    sControlType = 'transform'
    bTranslationSettable = cmds.getAttr('%s.tx' % cCtrl.sCtrl, settable=True) or cmds.getAttr('%s.ty' % cCtrl.sCtrl, settable=True) or cmds.getAttr('%s.tz' % cCtrl.sCtrl, settable=True)
    bRotationSettable = cmds.getAttr('%s.rx' % cCtrl.sCtrl, settable=True) or cmds.getAttr('%s.ry' % cCtrl.sCtrl, settable=True) or cmds.getAttr('%s.rz' % cCtrl.sCtrl, settable=True)
    bScaleSettable = cmds.getAttr('%s.sx' % cCtrl.sCtrl, settable=True) or cmds.getAttr('%s.sy' % cCtrl.sCtrl, settable=True) or cmds.getAttr('%s.sz' % cCtrl.sCtrl, settable=True)
    if bTranslationSettable and not bRotationSettable and not bScaleSettable:
        sControlType = 'translation'
    elif bRotationSettable and not bTranslationSettable and not bScaleSettable:
        sControlType = 'rotation'
    elif bScaleSettable and not bTranslationSettable and not bRotationSettable:
        sControlType = 'scale'

    sAttrs = utils._getAnimAttrsFromNode(cCtrl.sCtrl)
    sFilteredChannels = getFilteredChannelsFromAttrs(sAttrs)
    if utils.isNone(fOverwriteColor):
        fOverwriteColor = ctrls7.getCurveColor(cCtrl.sCtrl)
    # sOverwriteColor = 'None' if utils.isNone(fOverwriteColor) else '[%0.3f, %0.3f, %0.3f]' % (fOverwriteColor[0], fOverwriteColor[1], fOverwriteColor[2])

    sOffsetKeys = []
    dOffsetMatrices = {}
    if bOffsets:
        for sOffset in cCtrl.sOffsets:
            sOffsetKey = sOffset.split('Offset')[-1].lower()
            if sOffsetKey not in sSkipOffsets:
                sOffsetKeys.append(sOffsetKey)
                if sOffsetKey in sTrsValuesOnOffsets:
                    dOffsetMatrices[sOffsetKey] = mayaToUnrealMatrix(sOffset, bWorld=False)[0]

    sCommand = (f"{sCtrlName} = hierarchy.Ctrl().create(sName='{cCtrl.sName}{sCtrlIndex}', sSide='{cCtrl.sSide}', ffMatrix={ffMatrix}, fSliderScale={fSliderScale}, sShape='{sShapeName}', ffShapeMatrix={ffUnrealShapeMatrix}, "
                f"eParent={sParentVar}, fOverwriteColor={fOverwriteColor}, sControlType='{sControlType}', sFilteredChannels={sFilteredChannels}, bOut={bOut}, sOffsets={str(sOffsetKeys)}, dOffsetMatrices={str(dOffsetMatrices)}, "
                f"bPasser={not bNoPasser}, bProxy={bProxy}, bExtraSliderScale={bExtraSliderScale}, eDrivenControls={listNice(['%s.eControl' % eStrC for eStrC in eStrDrivenControls])})") \

    utils.data.addToList(kUnrealControlsToShape, [sCtrlName])
    utils.data.addToList(kCreatedUnrealCtrls, [sCtrlName])

    ffShapeOrientMatrix = setScaleToMatrix(ffShapeMatrix, [1, 1, 1])
    utils.addStringAttr(cCtrl.sCtrl, 'ffShapeOrientMatrix', str(ffShapeOrientMatrix))
    if not utils.isNone(sShapeParent):
        utils.addStringAttr(cCtrl.sCtrl, 'sShapeParent', sShapeParent)

    sWriteCommands.append(sCommand)

    # EXCLUDE END CONTROLRIG

    return sCtrlName


def createUnrealSliderCtrl(cCtrl):
    ffMatrix, fSliderScale = mayaToUnrealMatrix(cCtrl)

    sUnrealShape = 'Default'
    sMayaShape = cmds.getAttr('%s.__sShape__' % cCtrl.sCtrl)

    if cCtrl.sCtrl in ['mouthBot_ctrl', 'mouthTop_ctrl']:
        utils.data.addToList(kUnrealControlsToShape, [cCtrl.sCtrl])
        sUnrealShape = 'Box_Thick'
    else:
        if sMayaShape == 'doubleArrowSquareY':
            sUnrealShape = 'Arrow2_Solid'
        elif sMayaShape == 'cube':
            sUnrealShape = 'Box_Solid'

    sCtrlName = cCtrl.sCtrl
    dSliderData = eval(cmds.getAttr('%s.dSliderData' % sCtrlName))

    fRangeY = dSliderData.get('fRangeY', None)
    fRangeZ = dSliderData.get('fRangeZ', None)
    if not utils.isNone(fRangeY):
        dSliderData['fRangeZ'] = fRangeY
    if not utils.isNone(fRangeZ):
        dSliderData['fRangeY'] = fRangeZ

    sAttrs = utils._getAnimAttrsFromNode(cCtrl.sCtrl)
    sFilteredChannels = getFilteredChannelsFromAttrs(sAttrs)
    sCommand = (f"{sCtrlName} = hierarchy.SliderCtrl().create(sName='{cCtrl.sName}', sSide='{cCtrl.sSide}', ffMatrix={ffMatrix}, fSliderScale={fSliderScale}, sShape='{sUnrealShape}', "
                f"\n\t\t\t\tdSliderData={dSliderData}, eParent=eOrigin, sFilteredChannels={sFilteredChannels})")

    # utils.data.addToList(kUnrealControlsToShape, [sCtrlName])
    return sCommand


def ctrlInitFromExisting(sCtrl, sWriteCommands):
    sWriteCommands.append(f"{sCtrl} = hierarchy.Ctrl().initFromExisting('{sCtrl}')")
    return sCtrl


def listNice(sList, bAddQuotation=False):
    sNewList = list(sList)
    print ('sNewList: ', sNewList)
    for i in range(len(sList)):
        if 'kangarooTabTools.ctrls' in str(type(sList[i])):
            sNewList[i] = sList[i].sCtrl
        elif isinstance(sList[i], (np.ndarray, list, tuple)):
            sNewList[i] = str(list(sList[i]))
        elif isinstance(sNewList[i], float):
            sNewList[i] = '%0.6f' % sList[i]
    print ('sNewList: ',sNewList)

    if bAddQuotation:
        sNewList = ["'%s'" % sS for sS in sNewList]
    return '[%s]' % ', '.join(sNewList)



def tagFaceNode(sNodeOrAttribute):
    utils.addAttr(sNodeOrAttribute.split('.')[0], ln=kUnrealFaceNodeTag, k=True, bReturnIfExists=True)



def generateSliderCtrlsCode(sSkipCtrls=[]):
    sAllSliderCtrls = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('dSliderData', node=sT, exists=True)]

    sCommands = []
    sCommands.append("unrealUI.logMessage('Slider Controls...')")
    sCommands.append("unrealUI.incrementProgress()")

    sCommands.append('\n\n#Creating Slider Controls...\n')
    sCreatedCtrls = []

    # dUnrealCtrlReplacements = {}
    for sCtrl in sAllSliderCtrls:
        if sCtrl in sSkipCtrls or cmds.attributeQuery('bSkipUnrealCreation', node=sCtrl, exists=True):
            continue
        cCtrl = ctrls7.ctrlFromName(sCtrl)
        sCommands.append(createUnrealSliderCtrl(cCtrl))

        if sCtrl in ['blink_l_ctrl', 'blink_r_ctrl']:
            sMayaAttr = '%s.upCurveBlink' % sCtrl
            print ('sMayaAttr: ', sMayaAttr)
            if cmds.objExists(sMayaAttr):
                # sAttrVariableName = '%s_upCurveBlink' % sCtrl
                sCommands.append("hierarchy.createFloatControl('upCurveBlink', eParent=%s.eControl, fRange=[%0.3f,%0.3f], fDefault=%0.3f)" %
                                 (sCtrl,
                                  cmds.addAttr(sMayaAttr, q=True, min=True), cmds.addAttr(sMayaAttr, q=True, max=True),
                                  cmds.getAttr(sMayaAttr)))
        sCreatedCtrls.append(sCtrl)
    utils.data.addToList(kCreatedUnrealSliderCtrls, sCreatedCtrls)
    utils.data.addToList(kCreatedUnrealCtrls, sCreatedCtrls)

    utils.data.addToList(kUnrealCodeLines, sCommands)
    dumpUnrealCodeLinesToFile()



def setControlShapeCommand(sUnrealCtrlName):
    import kangarooTools.patch as patch

    if cmds.objExists(sUnrealCtrlName):
        sCtrl = sUnrealCtrlName
    elif sUnrealCtrlName.endswith('_ctrl'):
        sCtrl = utils.replaceStringEnd(sUnrealCtrlName, '_ctrl', '__')
    else:
        raise Exception('trouble getting shape of ctrl "%s"' % sUnrealCtrlName)

    sShape = cmds.getAttr('%s.__sShape__' % sCtrl)

    if cmds.objectType(sCtrl) == 'joint': # might do it differently once we found out better solution for joint ctrls
        aPoints = patch.patchFromName(sCtrl).getPoints(bWorld=True)
        aParentMatrix = utils.getNumpyMatrixFromTransform(cmds.listRelatives(sCtrl, p=True)[0])
        aInvParentMatrix = np.linalg.inv(aParentMatrix)
        aPoints4 = np.dot(utils.makePoint4Array(aPoints), aInvParentMatrix)
        aPoints = aPoints4[:,0:3]
    else:
        if cmds.attributeQuery('sShapeParent', node=sCtrl, exists=True):
            aParentMatrix = utils.getNumpyMatrixFromTransform(cmds.getAttr('%s.sShapeParent' % sCtrl))
            aInvParentMatrix = np.linalg.inv(aParentMatrix)
            aPoints = patch.patchFromName(sCtrl).getPoints(bWorld=True)
            aPoints4 = np.dot(utils.makePoint4Array(aPoints), aInvParentMatrix)
            aPoints = aPoints4[:, 0:3]
        else:
            aPoints = patch.patchFromName(sCtrl).getPoints(bWorld=False)

    aMin = np.min(aPoints, axis=0)
    aMax = np.max(aPoints, axis=0)
    aTranslate = (aMin+aMax) * 0.5

    sShapeMatrixAttr = '%s.ffShapeOrientMatrix' % sCtrl
    if not cmds.objExists(sShapeMatrixAttr):
        # return f"# skipping '{sCtrl}', attribute 'ffShapeOrientMatrix' doesn\'t exist"
        ffShapeMatrix = np.array(list(utils.fIdentityMatrix), dtype='float64').reshape(4,4)
    else:
        ffShapeMatrix = eval(cmds.getAttr(sShapeMatrixAttr))

    aaShapeMatrix = np.array(ffShapeMatrix, dtype='float64')
    aaShapeMatrix = setScaleToMatrix(aaShapeMatrix, [1,1,1])

    aScale = np.abs(aMin-aMax) * 0.1
    aScale = np.dot(aScale, np.linalg.inv(aaShapeMatrix[0:3,0:3]))

    if sShape in ['arrowCurveX', 'circleCrossX']:
        aScale[0] = max(aScale[1], aScale[2]) * 0.01
    elif sShape.startswith('circle') or sShape.startswith('square'):
        aScale[1] = max(aScale[0], aScale[2])
    elif sShape == 'cylinder':
        aScale[1] *= 100.0
    elif sShape == 'halfCircleY':
        aScale[2] *= -2.0
        aTranslate[0] = 0.0
    elif sShape == 'revL_y':  # used for eyelids/brows
        aScale[1] = max(aScale[0], aScale[2])
    elif sShape == 'revL_z': #  # used for lips
        aScale[1] = max(aScale[0], aScale[2])
    ffShapeMatrix = setScaleToMatrix(ffShapeMatrix, aScale)
    ffShapeMatrix = setTranslationToMatrix(ffShapeMatrix, aTranslate)

    return "hierarchy.setControlShapeFromMatrix('%s', %s)" % (sUnrealCtrlName, str(flipMatrixAxesToUnreal(ffShapeMatrix)))



def createUnrealFloatControl(sAttrName, eStrParent, sWriteCommands=None):
    if utils.isNone(sWriteCommands):
        raise Exception('need to pass sWriteCommands as a list')
    sWriteCommands.append("%s = hierarchy.createFloatControl('%s', eParent=%s, fRange=[0, 100])" % (sAttrName, sAttrName, eStrParent))
    return sAttrName


def createUnrealNull(sName, sMatch, sParentVariable='eOrigin', sWriteCommands=None, sMatchOrientScale=None, bAssignToVariable=True):
    if utils.isNone(sWriteCommands):
        raise Exception('need to pass sWriteCommands as a list')
    ffMatrix, _ = mayaToUnrealMatrix(sMatch)
    if sMatchOrientScale:
        ffMatrixOrientScale, _= mayaToUnrealMatrix(sMatchOrientScale)
        ffMatrix[0] = ffMatrixOrientScale[0]
        ffMatrix[1] = ffMatrixOrientScale[1]
        ffMatrix[2] = ffMatrixOrientScale[2]

    sCommand = "hierarchy.createNull(sName='%s', ffMatrix=%s, eParent=%s)" % (sName, ffMatrix, sParentVariable)
    if bAssignToVariable:
        sCommand = '%s = %s' % (sName, sCommand)
    sWriteCommands.append(sCommand)
    return sName


def createFkChainCtrls(cCtrls, fSize=5.0, bAllUnderRoot=False, bAllUnderParent=False, sParentVar='eOrigin', fCtrlOrient=[0,0,0], sWriteCommands=[]):
    if utils.isNone(sWriteCommands):
        raise Exception('need to pass sWriteCommands as a list')

    sCommands = []
    cStrCtrls = []
    if bAllUnderRoot and bAllUnderParent:
        raise Exception('bAllUnderRoot and bAllUnderParent cannot be used the same time')

    for c,cC in enumerate(cCtrls):
        cStrVar = createUnrealCtrl(cC, sParentVar=sParentVar, fSize=fSize, fCtrlOrient=fCtrlOrient, sWriteCommands=sCommands)
        cStrCtrls.append(cStrVar)
        if bAllUnderParent:
            pass # sParentVar doesn't get changed
        else:
            if bAllUnderRoot and c > 0:
                continue
            else:
                sParentVar = '%s.eOut' % cStrVar

    sWriteCommands.extend(sCommands)
    return cStrCtrls


def quotaStringList(sList, bCommaJoined=False):
    sList = ["'%s'" % sO for sO in sList]
    if bCommaJoined:
        return ', '.join(sList)
    else:
        return sList


dMayaToUnrealAxis = {'X':'X', 'Y':'Z', 'Z':'Y'}


def mayaToUnrealMatrix(xTransform, bMatchPasserPositionWhenCtrl=False, bWorld=True):

    if isinstance(xTransform, str):
        aMatrix = utils.getNumpyMatrixFromTransform(xTransform, bWorld=bWorld)
        fSliderScale = [1,1,1]

    else:
        aMatrix = utils.getNumpyMatrixFromTransform(xTransform.sPasser, bWorld=bWorld)
        aPositionMatrix = utils.getNumpyMatrixFromTransform(xTransform.sPasser if bMatchPasserPositionWhenCtrl else xTransform.sCtrl, bWorld=bWorld)
        aMatrix[3] = aPositionMatrix[3]
        fSliderScale = cmds.getAttr('%s.s' % xTransform.sSlider)[0] if xTransform.sSlider else [1,1,1]

    return flipMatrixAxesToUnreal(aMatrix), flipVectorToUnreal(fSliderScale)


def getTwistInfo(sLimb, sJoint, sUnrealJoint=None):
    sNoTwistParent = 'grp_%s_upperTwistNoTwistCalculateParent' % sLimb

    aaNoTwistMatrix = utils.getNumpyMatrixFromTransform(sNoTwistParent)
    aaJointMatrix = utils.getNumpyMatrixFromTransform(sJoint)
    aaUnrealJointMatrix = utils.getNumpyMatrixFromTransform(sUnrealJoint)

    # straight matrix:
    aaUnrealDifference = np.dot(aaUnrealJointMatrix, np.linalg.inv(aaJointMatrix))
    aaUnrealNoTwistMatrix = np.dot(aaUnrealDifference, aaNoTwistMatrix)

    aaLocalMatrix = np.dot(aaUnrealNoTwistMatrix, np.linalg.inv(aaUnrealJointMatrix))
    fStraightRotateOffset = matrixToEuler(list(aaLocalMatrix.flatten()), bFlipAxesToUnreal=False)
    fStraightRotateOffset = [-fStraightRotateOffset[0], fStraightRotateOffset[1], -fStraightRotateOffset[2]]


    # planeaxis:
    sPlaneAxis = utils.data.get('sPlaneAxis_%s' % sLimb)
    aPlaneVector = np.array([0,0,0,1], dtype='float64')
    aPlaneVector['XYZ'.index(sPlaneAxis)] = 1.0

    aWorldPlaneVector = np.dot(aPlaneVector, aaJointMatrix)
    aUnrealPlaneVector = np.dot(aWorldPlaneVector, np.linalg.inv(aaUnrealJointMatrix))
    iBiggestAxis = np.argmax(np.abs(aUnrealPlaneVector[:3]))
    sUnrealPlaneAxis = 'XYZ'[iBiggestAxis]

    # lower Up axis
    sLowerUpAxis = utils.data.get('sLowerUpAxis_%s' % sLimb)

    return fStraightRotateOffset, sUnrealPlaneAxis, sLowerUpAxis



def flipMatrixAxesToUnreal(ffMatrix):
    aMatrix = np.array(ffMatrix, dtype='float64').reshape(4,4)
    return  [[aMatrix[0, 0], aMatrix[0, 2], aMatrix[0, 1], 0.0],
             [aMatrix[2, 0], aMatrix[2, 2], aMatrix[2, 1], 0.0],
             [aMatrix[1, 0], aMatrix[1, 2], aMatrix[1, 1], 0.0],
             [aMatrix[3, 0], aMatrix[3, 2], aMatrix[3, 1], 1.0]]

def numpyToListMatrix(aMatrix):
    return [list(aMatrix[0]), list(aMatrix[1]), list(aMatrix[2]), list(aMatrix[3])]


def eulerToMatrix(fEuler, bFlipAxesToUnreal=True):
    mEuler = OpenMaya2.MEulerRotation(math.radians(fEuler[0]), math.radians(fEuler[1]), math.radians(fEuler[2]))
    mMatrix = mEuler.asMatrix()
    aMatrix = np.array(mMatrix).reshape(4,4)
    ffMatrix = numpyToListMatrix(aMatrix)
    if bFlipAxesToUnreal:
        ffMatrix = flipMatrixAxesToUnreal(ffMatrix)
    return ffMatrix


def matrixToEuler(ffMatrix, bFlipAxesToUnreal=True):
    mMatrix = OpenMaya2.MMatrix(ffMatrix)
    mTransform = OpenMaya2.MTransformationMatrix(mMatrix)
    mEuler = mTransform.rotation()
    fValues = [math.degrees(mEuler.x), math.degrees(mEuler.y), math.degrees(mEuler.z)]
    if bFlipAxesToUnreal:
        fValues = flipVectorToUnreal(fValues, bEuler=True)
    return fValues


def setScaleToMatrix(ffMatrix, fScale=[1.0, 1.0, 1.0]):
    bNumpy = isinstance(ffMatrix, np.ndarray)
    aaMatrix = np.array(ffMatrix, dtype='float64')
    for i in range(3):
        aaMatrix[i,0:3] *= fScale[i] / np.linalg.norm(aaMatrix[i,0:3])

    if bNumpy:
        return aaMatrix
    else:
        return numpyToListMatrix(aaMatrix)


def setTranslationToMatrix(ffMatrix, fTranslation=[1.0, 1.0, 1.0]):
    bNumpy = isinstance(ffMatrix, np.ndarray)
    aaMatrix = np.array(ffMatrix, dtype='float64')

    aaMatrix[3,0:3] = fTranslation

    if bNumpy:
        return aaMatrix
    else:
        return numpyToListMatrix(aaMatrix)


def flipVectorToUnreal(fVector, bBoneSpace=False, bEuler=False, iRoundDigits=7):
    fVector = [round(fVector[0], iRoundDigits), round(fVector[1], iRoundDigits), round(fVector[2], iRoundDigits)]
    if bBoneSpace:
        if bEuler:
            return [fVector[0], -fVector[1], -fVector[2]] # ?! not sure
        else:
            return [fVector[0], -fVector[1], fVector[2]]
    else:
        if bEuler:
            return [-fVector[0], fVector[1], -fVector[2]] # ?! not sure
        else:
            return [fVector[0], fVector[2], fVector[1]]


def flipVectorListToUnreal(fVectors, bBoneSpace=False, bEuler=False, iRoundDigits=7):
    return [flipVectorToUnreal(fV, bBoneSpace=bBoneSpace, bEuler=bEuler, iRoundDigits=iRoundDigits) for fV in fVectors]




def processLimbsForControlRig(dCreatedLimbs, dMergedDatas, dChildren):

    sUnrealCodeLines = []

    # EXCLUDE START CONTROLRIG
    print('dCreatedLimbs.items(): ', dCreatedLimbs.items())

    sSkippedLimbs = []

    sCreatedLimbs = list(dCreatedLimbs.keys())
    sSolvedAvoidForwardLimbs = []
    sSolvedAvoidBackwardsLimbs = []
    sAvoidForwardLimbs = utils.data.get('sUnrealAvoidForwardLimbs')
    for sAvoidLimbPattern in sAvoidForwardLimbs:
        for sL in sCreatedLimbs:
            if re.match('%s$' % sAvoidLimbPattern, sL):
                sSolvedAvoidForwardLimbs.append(sL)

    sAvoidBackwardsLimbs = utils.data.get('sUnrealAvoidBackwardsLimbs')
    for sAvoidLimbPattern in sAvoidBackwardsLimbs:
        for sL in sCreatedLimbs:
            if re.match('%s$' % sAvoidLimbPattern, sL):
                sSolvedAvoidBackwardsLimbs.append(sL)



    # CREATE FORWARD FEATURES & BLEND BETWEEN FEATURES
    ddUsedFeatures = {}
    ddUsedFeatures['forward'] = defaultdict(list)
    for sLimbName, lLimb in list(dCreatedLimbs.items()):
        print ('\n\n ============= Doing Unreal Limb: "%s"' % sLimbName)
        if sLimbName in sSolvedAvoidForwardLimbs:
            continue
        dMergedData = dMergedDatas[sLimbName]

        for sF in dMergedData['sFeatures']:
            if dMergedData['%s.bCheckedFILE' % sF] == True:
                sUnrealFunc = 'unreal_%s' % sF
                sUnrealCheckFunc = 'unrealCheck_%s' % sF
                if hasattr(lLimb, sUnrealCheckFunc):
                    funcCheck = getattr(lLimb, sUnrealCheckFunc)
                    if not funcCheck():
                        continue
                if hasattr(lLimb, sUnrealFunc):
                    ddUsedFeatures['forward'][sLimbName].append(sF)

        if not ddUsedFeatures['forward'][sLimbName]:
            sSkippedLimbs.append(sLimbName)
            sUnrealCodeLines.append('# skipping because no supported limbs for unreal')
            continue

        if len(ddUsedFeatures['forward'][sLimbName]) == 1:
            bSwitchFeatures = False
        elif len(ddUsedFeatures['forward'][sLimbName]) == 2:
            bSwitchFeatures = True
        else:
            raise Exception('wrong numbers of features: %d' % len(ddUsedFeatures['forward'][sLimbName]))

        sUnrealCodeLines.append('\n\n# PIECE.START: %s' % lLimb.sLimbName)
        sUnrealCodeLines.append("unrealUI.logMessage('Building \"%s\"...')" % lLimb.sLimbName)
        sUnrealCodeLines.append("unrealUI.incrementProgress()")
        sUnrealCodeLines.append("# PIECE.OUTPUTS: %s" % str(list(lLimb.dOutputs.values())))
        sUnrealCodeLines.append("# PIECE.INPUTS: %s # default inputs" % str(lLimb.sDefaultUnrealPieceInputs))

        cStrGlobalCtrl = None
        if lLimb.sFeatureShape and cmds.objExists(lLimb.sFeatureShape) and cmds.objectType(lLimb.sFeatureShape) == 'transform':
            cGlobalCtrl = ctrls7.ctrlFromName(lLimb.sFeatureShape)
            cStrGlobalCtrl = createUnrealCtrl(cGlobalCtrl, sWriteCommands=sUnrealCodeLines)
            # cStrGlobalCtrl = lLimb.sFeatureShape
        setNewColumn(sWriteCommands=sUnrealCodeLines)

        if bSwitchFeatures:
            startFunction(sLimbName, bSequencer=False, sWriteCommands=sUnrealCodeLines)

        sUnrealCodeLines.append(ENTRYKEY(sLimbName, sFeature='-general-', sPart='CustomAttacherTransforms'))


        if bSwitchFeatures:
            sStartFeature = dMergedData.get('sStartFeatureFILE', None)
            bDefault = True if sStartFeature == 'feature_ik' else False

            sUnrealCodeLines.append('#%s Blend' % lLimb.sLimbName)
            sUnrealCodeLines.append(f"sSwitchAttrs = functions.createBlendingSetup('{lLimb.sName}', '{lLimb.sSide}', [%s], bDefault={bDefault}, eGlobalCtrl={cStrGlobalCtrl}.eControl)" %
                                    (','.join(["'%s'" % sF for sF in ddUsedFeatures['forward'][sLimbName]])))

        if bSwitchFeatures:
            setNewColumn(sWriteCommands=sUnrealCodeLines)
            sUnrealCodeLines.append("nodes.createBranchExecuteNode(sSwitchAttrs[0])")

        dUnrealFeatureInfo = {}
        for sFeature in ddUsedFeatures['forward'][sLimbName]:
            sUnrealFunc = 'unreal_%s' % sFeature
            fUnrealFunc = getattr(lLimb, sUnrealFunc)
            sUnrealCodeLines.append('\n#%s ' % sFeature)
            sCommands, sReturnCtrls = fUnrealFunc()[:2]
            sUnrealCodeLines += sCommands
            dUnrealFeatureInfo[sFeature] = sReturnCtrls
            if bSwitchFeatures:
                sUnrealCodeLines.append('controllers.goToParentExecute()')
            sUnrealCodeLines.append("unrealUI.incrementProgress()\n")

        # Global Ctrl:
        if cStrGlobalCtrl:
            setNewColumn(sWriteCommands=sUnrealCodeLines)
            cGlobalCtrl = ctrls7.ctrlFromName(lLimb.sFeatureShape)
            sDecompose = cmds.listConnections('%s.t' % cGlobalCtrl.sPasser, s=True, d=False)[0]
            sParent = cmds.getAttr('%s.matrixParentConstraintTarget' % sDecompose)
            sUnrealCodeLines.append("nodes.createParentConstraintExecuteNode([(library.getElementKey('%s', 'Bone'), 1.0)], library.getElementKey('%s', 'Null'), bMaintainOffset=True)" % \
                                    (sParent, utils.replaceStringStart(cGlobalCtrl.sPasser, 'grp_', '')))

        # backwards:
        setNewColumn(sWriteCommands=sUnrealCodeLines)
        if bSwitchFeatures:
            bDoFeatureSnap = False
            for sFeature in ddUsedFeatures['forward'][sLimbName]:
                sUnrealBackwardsFunc = 'unrealBackwards_%s' % sFeature
                if hasattr(lLimb, sUnrealBackwardsFunc):
                    bDoFeatureSnap = True
                    break

            if bDoFeatureSnap:
                # newSequencerPlug(sWriteCommands=sUnrealCodeLines)
                setNewColumn(sWriteCommands=sUnrealCodeLines)
                sUnrealCodeLines.append("nodes.createBranchExecuteNode(sSwitchAttrs[0])")

                for sFeature in ddUsedFeatures['forward'][sLimbName][::-1]:
                    sUnrealBackwardsFunc = 'unrealBackwards_%s' % sFeature
                    if hasattr(lLimb, sUnrealBackwardsFunc):
                        fUnrealBackwardsFunc = getattr(lLimb, sUnrealBackwardsFunc)
                        setNewColumn(sWriteCommands=sUnrealCodeLines)
                        sUnrealCodeLines.append('\n#%s (backwards)' % sFeature)
                        sUnrealCodeLines.extend(fUnrealBackwardsFunc(bCreateBlendNodes=False))
                        sUnrealCodeLines.append("unrealUI.incrementProgress()\n")
                    if bSwitchFeatures:
                        sUnrealCodeLines.append('controllers.goToParentExecute()')


        # control vis connections. We could (should) get rid of the execute connections!
        if bSwitchFeatures:
            sReturnCtrlsFk = dUnrealFeatureInfo['feature_fk']
            sReturnCtrlsIk = dUnrealFeatureInfo['feature_ik']
            sUnrealCodeLines.append('#%s Connecting to Blend' % lLimb.sLimbName)
            sUnrealCodeLines.append("functions.connectControlsToSwitches([%s, %s])" %
                                    (str(sReturnCtrlsFk), str(sReturnCtrlsIk)))
            sUnrealCodeLines.append("unrealUI.incrementProgress()\n")


        # if bSwitchFeatures:
        #     newSequencerPlug(sWriteCommands=sUnrealCodeLines)

        for sDetail in dMergedData['sDetails']:
            if dMergedData['%s.bCheckedFILE' % sDetail] == True:
                sUnrealDetailFunc = 'unreal_%s' % sDetail
                if hasattr(lLimb, sUnrealDetailFunc):
                    fUnrealFunc = getattr(lLimb, sUnrealDetailFunc)
                    sUnrealCodeLines.append('\n#%s ' % sDetail)
                    setNewColumn(sWriteCommands=sUnrealCodeLines)
                    sCommands = fUnrealFunc()
                    sUnrealCodeLines += sCommands
                    sUnrealCodeLines.append("unrealUI.incrementProgress()\n")


        if bSwitchFeatures:
            endCurrentfunction(sWriteCommands=sUnrealCodeLines)


        sUnrealCodeLines.append('\n\n# PIECE.END: %s' % lLimb.sLimbName)



    sUnrealBackwardsCodeLines = []
    sUnrealBackwardsCodeLines.append('\n\n# Backwards Limbs')
    newSequencerPlug(sWriteCommands=sUnrealBackwardsCodeLines)
    sUnrealBackwardsCodeLines.append("nodes.newSequencerPlug()")
    # sUnrealBackwardsCodeLines.append("controllers.openCommentBox()")


    # CREATE BACKWARDS FEATURES & BLEND BETWEEN FEATURES (could remove the blend nodes?)
    # sDoBackwardsLimbs = utils.data.get('sDoBackwardsLimbs')
    for sLimbName, lLimb in list(dCreatedLimbs.items()):
        if sLimbName in sSolvedAvoidForwardLimbs:
            continue
        # sUnrealBackwardsCodeLines.append("nodes.newSequencerPlug()")
        dMergedData = dMergedDatas[sLimbName]

        sUnrealBackwardsCodeLines.append('\n\n# PIECE.START: %s' % lLimb.sLimbName)
        sUnrealBackwardsCodeLines.append('\n\n#===============\n #%s' % lLimb.sLimbName)
        sUnrealBackwardsCodeLines.append("unrealUI.logMessage('Building \"%s\"...')" % lLimb.sLimbName)
        sUnrealBackwardsCodeLines.append("unrealUI.incrementProgress()")
        sUnrealBackwardsCodeLines.append("# PIECE.OUTPUTS: %s" % str(list(lLimb.dOutputs.values())))
        sUnrealBackwardsCodeLines.append("# PIECE.INPUTS: %s # default inputs" % str(lLimb.sDefaultUnrealPieceInputs))

        ddUsedFeatures['backwards'] = defaultdict(list)
        for sF in dMergedData['sFeatures']:
            if dMergedData['%s.bCheckedFILE' % sF] == True:
                sUnrealFunc = 'unrealBackwards_%s' % sF
                sUnrealCheckFunc = 'unrealCheck_%s' % sF
                if hasattr(lLimb, sUnrealCheckFunc):
                    funcCheck = getattr(lLimb, sUnrealCheckFunc)
                    if not funcCheck():
                        continue
                if hasattr(lLimb, sUnrealFunc):
                    ddUsedFeatures['backwards'][sLimbName].append(sF)


        if not ddUsedFeatures['backwards'][sLimbName]:
            sUnrealBackwardsCodeLines.append('# skipping because no supported limbs for unreal')
            continue

        sUnrealBackwardsCodeLines.append(ENTRYKEY(sLimbName, sFeature='-general-', sPart='CustomAttacherTransforms'))

        dUnrealFeatureInfo = {}
        for sFeature in ddUsedFeatures['backwards'][sLimbName]:
            sUnrealFunc = 'unrealBackwards_%s' % sFeature

            fUnrealFunc = getattr(lLimb, sUnrealFunc)
            sUnrealBackwardsCodeLines.append('\n#%s ' % sFeature)
            sCommands = fUnrealFunc()
            sUnrealBackwardsCodeLines += sCommands


        sUnrealBackwardsCodeLines.append('\n\n# PIECE.END: %s' % lLimb.sLimbName)



    print('\n\n\n\n================= unreal control rig attachers.. =================')
    setNewColumn(sWriteCommands=sUnrealCodeLines)
    dAttacherLines = defaultdict(list)

    # setup the attachers (a lot here is duplicated code from baseLimb.py)
    dCtrlReplacements = {a:b for a,b in utils.data.get(kUnrealControlReplacements, xDefault=[])}
    dOutputReplacements = {a:b for a,b in utils.data.get(kUnrealOutputReplacements, xDefault=[])}
    sCreatedUnrealCtrls = utils.data.get(kCreatedUnrealCtrls)
    dAllUsedOutputs = {}
    for sLimbName, lLimb in list(dCreatedLimbs.items()):
        if sLimbName in sSolvedAvoidForwardLimbs:
            continue
        report.report.addLogText('unreal limb "%s"...' % sLimbName)
        print ('\n\nATTACHERS for %s...' % sLimbName)
        dMergedData = dMergedDatas[sLimbName]

        dFeaturesPerAttacher = {}
        sAttachers = dMergedData['sAttachers']
        for sA in sAttachers:
            dFeaturesPerAttacher[sA] = list(set(ddUsedFeatures['forward'][sLimbName] + ddUsedFeatures['backwards'][sLimbName]))
        for sFeature in list(set(ddUsedFeatures['forward'][sLimbName] + ddUsedFeatures['backwards'][sLimbName])): #dMergedData['sFeatures']:
            sFeatureAttachers = dMergedData['%s.sAttachers' % sFeature]
            sAttachers += sFeatureAttachers
            for sA in sFeatureAttachers:
                dFeaturesPerAttacher[sA] = [sFeature]


        dTrs = {}
        sAttachersPlusSplit = []
        for sA in list(set(sAttachers)):
            sAttachersPlusSplit.append(sA)
            if dMergedData['%s.bSplitFILE' % sA] == True:
                sChildA = '%s(1)' % sA
                sAttachersPlusSplit.append(sChildA)
                dTrs[sA] = 't'
                dTrs[sChildA] = 'r'
            else:
                dAttacherPredifinedData = lLimb.dMergedData['%s.dPredefinedData' % sA]
                dTrs[sA] = dAttacherPredifinedData.get('sTrs', 'tr')

        for sA in sAttachersPlusSplit:
            if '.' in sA:
                sFeature, _ = sA.split('_')
                if not dMergedData.get('%s.bCheckedFILE' % sFeature, True):
                    continue
            sShortA = sA.split('(')[0]

            sLocalAttacherOutputs = lLimb.dLocalAttacherOutputs.get(sShortA, [])

            sOutputs = sLocalAttacherOutputs + dMergedData['%s.sOutputsFILE' % sA]
            dLocalOutputs = dMergedData.get('%s.dLocalOutputsFILE' % sA, {})
            sOutputs = [sO for sO in sOutputs if not sO.startswith(utils.kNoneString)]
            if not sOutputs:
                cmds.warning('attacher %s was not filled in %s )' % (sA, lLimb.sLimbName))
                continue

            # for iCount, sAttacherBuildData in enumerate(lLimb.ddAllAttacherBuildDatas[sShortA]):
            if not len(lLimb.ddAllAttacherBuildDatas[sShortA]):
                print ('"%s" (%s) has no attacher, probably because that feature was not built' % (sShortA, sLimbName))
            else:
                sAttacherBuildData = lLimb.ddAllAttacherBuildDatas[sShortA][0]
                sOutputsShort = []
                sOutputTransforms = []
                iDefaultWeights = []

                mAttacherDagPath, cAttacherBlendCtrl = sAttacherBuildData
                sOutputLimbs = []
                sCustomAttacherLines = []
                for i, sOutput in enumerate(sOutputs):
                    if i < len(sLocalAttacherOutputs):
                        sOutput, sOutputTransform = utils.tempOutputSplit(sOutput)
                        if sOutput in dLocalOutputs:
                            sO, sW = utils.tempOutputSplit(dLocalOutputs[sOutput])
                            sOutputsShort.append(sO)
                            fWeight = float(sW)
                        else:
                            sOutputsShort.append(sOutput)
                            fWeight = 0
                        sOutputLimbs.append(None)
                    else:
                        sOutputLimb, sOutputName, sShortName, fWeight = utils.extractOutputInfo(sOutput, iIndex=i)

                        if sOutputLimb == utils.kCustomString:
                            sCustomAttacherName = utils.getCustomAttacherTransformName(sLimbName, sA)
                            sCustomAttacherLines.extend(['# CUSTOMATTACHER %s' % sCustomAttacherName])#, 'controllers.setNewColumn()'])
                            setNewColumn(sWriteCommands=sCustomAttacherLines)
                            sOutputTransform = sCustomAttacherName
                        else:
                            tOutputLimb = dCreatedLimbs[sOutputLimb]
                            sOutputTransform = tOutputLimb.dOutputs[sOutputName]
                            dAllUsedOutputs[sOutputTransform] = tOutputLimb.sLimbName


                        sOutputsShort.append(sShortName)
                        sOutputLimbs.append(sOutputLimb)
                        if not sOutputTransform:
                            raise Exception('output "%s" missing from limb "%s"' % (sOutputName, lLimb.sLimbName))
                    sOutputTransforms.append(sOutputTransform)
                    iDefaultWeights.append(fWeight)

                if not np.any(iDefaultWeights):
                    iDefaultWeights[0] = 1.0


                sTrs = dTrs[sA]

                if sTrs == 'c':
                    continue
                else:
                    # sTrsName = ''
                    if sTrs == 'tr' or sTrs == 'rt':
                        sTrsName = ''
                    elif sTrs == 't':
                        sTrsName = '_T'
                    elif sTrs == 'r':
                        sTrsName = '_R'
                    elif sTrs == 's':
                        continue
                        sTrsName = '_S'
                    else:
                        raise Exception('invalid trs: "%s"' % sTrs)

                    if lLimb.sCreateReplacerAttachers:
                        for o, sO in enumerate(sOutputTransforms):
                            if sO in lLimb.sCreateReplacerAttachers:
                                sOutputTransforms[o] = lLimb.getReplacerAttacher(sO)

                    sChild = '%s.ePasser' % cAttacherBlendCtrl.sCtrl if cAttacherBlendCtrl else None

                    eStrConstrainers = []
                    for sOutputLimb, sOutputTransform, sShortA, fDefault in zip(sOutputLimbs, sOutputTransforms, sOutputsShort, iDefaultWeights):
                        if sOutputLimb == utils.kCustomString:
                            eStrConstrainers.append(sOutputTransform)
                        elif sOutputTransform in dOutputReplacements:
                            eStrConstrainers.append("library.getElementKey('%s', 'Bone')" % dOutputReplacements[sOutputTransform])
                        elif sOutputTransform in dCtrlReplacements:
                            sCtrl = dCtrlReplacements[sOutputTransform]
                            if sCtrl in sCreatedUnrealCtrls:
                                eStrConstrainers.append('%s.eOut' % sCtrl)
                            else:
                                eStrConstrainers.append("library.getElementKey('%s', 'Control')" % sCtrl)
                        elif sOutputTransform.startswith('jnt_'):
                            eStrConstrainers.append("library.getElementKey('%s', 'Bone')" % sOutputTransform)
                        elif sOutputLimb == None: # custom attacher. not incrementing eStrConstrainers
                            print ('limb: ', sLimbName)
                        else:
                            raise Exception('Don\'t know what type of output "%s" is (for attacher "%s")' % (sOutputTransform, sChild))


                    sLineKeyCustomAttacherTransforms = ENTRYKEY(sLimbName, sFeature='-general-', sPart='CustomAttacherTransforms')
                    dAttacherLines[sLineKeyCustomAttacherTransforms] += sCustomAttacherLines

                    sNameOfA = sA.split('(')[0]
                    sFeatures = dFeaturesPerAttacher[sNameOfA]
                    sPieceInputs = []
                    for sFeature in sFeatures:
                        sLineKeyExtendAttachers = ENTRYKEY(sLimbName, sFeature=sFeature, sPart='extendAttachersWithUserStuff')
                        sLineKeyCreateChannelAttributes = ENTRYKEY(sLimbName, sFeature=sFeature, sPart='createBlendChannelAttributes')
                        sLineKeyConnectBlendNodes = ENTRYKEY(sLimbName, sFeature=sFeature, sPart='connectBlendNodes')
                        sLineKeyBlendNodes = ENTRYKEY(sLimbName, sFeature=sFeature, sPart='blendNodes')
                        sNodeVariable = '%s_%s_node' % (sLimbName, sFeature)
                        iLocalAttacherCount = len(sOutputs) - len(eStrConstrainers)

                        if len(eStrConstrainers):
                            if 't' in sTrs:
                                dAttacherLines[sLineKeyExtendAttachers].append("dAttachers_%s['ATTACHER_%s_t'].extend([%s])" % (sFeature, sNameOfA, ', '.join(eStrConstrainers)))
                            if 'r' in sTrs:
                                dAttacherLines[sLineKeyExtendAttachers].append("dAttachers_%s['ATTACHER_%s_r'].extend([%s])" % (sFeature, sNameOfA, ', '.join(eStrConstrainers)))

                            print ('eStrConstrainers: ', eStrConstrainers)
                            for eStrC in eStrConstrainers:
                                if eStrC.startswith('grp_customTransform'):
                                    continue
                                sPieceInputs.append(utils.getStringInQuota(eStrC, bReturnIfNoQuota=True))

                        if len(sOutputs) > 1:

                            sOutputsShortFinal = ['space_%s%s' % (sShortO, sTrsName) for sShortO in sOutputsShort]
                            dAttacherLines[sLineKeyCreateChannelAttributes].append("functions.blendAttributesElements(eAttrParent=%s.eControl, sAttrNames=%s, xWeights=%s)" % (cAttacherBlendCtrl.sCtrl, str(sOutputsShortFinal), str(iDefaultWeights)))
                            sNodeBaseName = 'sBlendAttributes_%s_%s_%s' % (sLimbName, sFeature, cAttacherBlendCtrl.sCtrl)
                            dAttacherLines[sLineKeyBlendNodes].append("%s%s = functions.blendAttributesFunction(eAttrParent=%s.eControl, sAttrNames=%s, xWeights=%s)" %
                                                                      (sNodeBaseName, sTrsName, cAttacherBlendCtrl.sCtrl, str(sOutputsShortFinal), str(iDefaultWeights)))
                            for o in range(iLocalAttacherCount + len(eStrConstrainers)):
                                if 't' in sTrs:
                                    dAttacherLines[sLineKeyConnectBlendNodes].append("pins.connectToPin1D('%%s.OutAttr_%d' %% %s%s, '%%s.ATTACHER_%s_t.%d.Weight' %% %s)" %
                                                                                     (o, sNodeBaseName, sTrsName, sNameOfA, o, sNodeVariable))
                                if 'r' in sTrs:
                                    dAttacherLines[sLineKeyConnectBlendNodes].append("pins.connectToPin1D('%%s.OutAttr_%d' %% %s%s, '%%s.ATTACHER_%s_r.%d.Weight' %% %s)" %
                                                                                     (o, sNodeBaseName, sTrsName, sNameOfA, o, sNodeVariable))
                            # TODO: add spaces if no bSpaceBlend and sTrsName is 'tr' or 'rt'. Local attacher transforms sort of would have to go into the eStrConstrainers though.
                            # if sTrsName in ['tr', 'rt'] and not bSpaceBlend:
                                # dAttacherLines[sLineKeyConnectBlendNodes].append("%s.addSpaces([%s])" % (sChild.split('.')[0], ', '.join(eStrConstrainers)))

                    if sPieceInputs:
                        dAttacherLines[sLineKeyExtendAttachers].append("# PIECE.INPUTS: %s" % str(sPieceInputs))

    utils.data.store('dAllUsedOutputs', dAllUsedOutputs)



    for sKey, sLines in dAttacherLines.items():
        if sKey.endswith(' blendNodes'):
            sLines.insert(0, 'controllers.setNewColumn() # 5')
        for l in range(len(sUnrealCodeLines)):
            if sUnrealCodeLines[l] == sKey:
                for ll in range(len(sLines)):
                    sUnrealCodeLines.insert(l + 1 + ll, sLines[ll])


        for l in range(len(sUnrealBackwardsCodeLines)):
            if sUnrealBackwardsCodeLines[l] == sKey:
                for ll in range(len(sLines)):
                    sUnrealBackwardsCodeLines.insert(l + 1 + ll, sLines[ll])




    # EXCLUDE END CONTROLRIG
    sUnrealCodeLines.extend(['# Muscle Joints'])
    sUnrealBackwardsCodeLines.extend(['# Muscle Joints'])


    utils.data.store(kUnrealCodeLines, sUnrealCodeLines)
    dumpUnrealCodeLinesToFile(bStartFromTemplate=False)

    utils.data.addToList(kUnrealBackwardsCodeLines, sUnrealBackwardsCodeLines)
    dumpUnrealCodeLinesToFile(sKey=kUnrealBackwardsCodeLines)





def generateControlShapeCode(sSkipLimbs=[]):
    print('================= unreal shape ctrls.. =================')
    sCommands = []
    sCommands.append('\n\n#Shaping Controls...\n')
    sCommands.append("unrealUI.logMessage('Shaping Controls...')")
    sCommands.append("unrealUI.incrementProgress()")

    sAllCtrls = list(set(utils.data.get(kUnrealControlsToShape, xDefault=[]))) # we create set because from backwards/mocap there could be lots of duplicates

    for sCtrl in sAllCtrls:
        sLimbNameAttr = '%s.sLimbCtrl' % sCtrl
        if cmds.objExists(sLimbNameAttr):
            sLimbName = cmds.getAttr(sLimbNameAttr)
            if sLimbName in sSkipLimbs:
                continue
        sCommands.append(setControlShapeCommand(sCtrl))

    utils.data.addToList(kUnrealCodeLines, sCommands)
    dumpUnrealCodeLinesToFile()
    # utils.data.addToList(kUnrealMocapCodeLines, sCommands)
    # dumpUnrealCodeLinesToFile(sKey=kUnrealMocapCodeLines)


def generateMuscleJointsCode(dUnrealJointsMapper={}, sCodeLineKeys=[kUnrealCodeLines], bPieceLines=False):

    sUnrealCodeLines = []
    sUnrealCodeLines.append('\n\n# Muscle Joints')
    # sUnrealCodeLines.append("nodes.newSequencerPlug()")

    sMuscleJoints = [sJ for sJ in cmds.ls('muscleJntU_?_*', 'game:muscleJnt_?_*', et='joint') if not sJ.endswith('End')]
    for sJ in sMuscleJoints:
        print ('sMuscleJoint: ', sJ)
        sPieceInputs = []
        if bPieceLines:
            sUnrealCodeLines.append('# PIECE.START: %s' % sJ.split(':')[-1])
        setNewColumn(sWriteCommands=sUnrealCodeLines)

        sEndJ = '%sEnd' % sJ.split(':')[-1]
        fEndPoint = cmds.xform(sEndJ, q=True, ws=True, t=True)
        fLength = abs(cmds.getAttr('%s.tx' % sEndJ))
        aEndPoint4 = np.array(list(fEndPoint)+[1.0], dtype='float64')
        if not cmds.objExists(sEndJ):
            raise Exception('%s doesn\'t exist' % sEndJ)
        sEndSpace = cmds.getAttr('%s.endSpace' % sJ)
        sEndSpace = 'game:%s' % dUnrealJointsMapper.get(sEndSpace, sEndSpace)
        sStartSpace = cmds.getAttr('%s.startSpace' % sJ)
        sStartSpace = 'game:%s' % dUnrealJointsMapper.get(sStartSpace, sStartSpace)

        fSquashValues = [cmds.getAttr('%s.%s' % (sJ, sA)) for sA in
                         ['squashYPos', 'squashYNeg', 'squashZPos', 'squashZNeg']] # fSquashPosY, fSquashNegY, fSquashPosZ, fSquashNegZ
        # unreal flip
        fSquashValues[0], fSquashValues[1] = fSquashValues[1], fSquashValues[0]

        aEndSpaceMatrix = utils.getNumpyMatrixFromTransform(sEndSpace)
        aLocalEndPoint4 = np.dot(aEndPoint4, np.linalg.inv(aEndSpaceMatrix))
        fUnrealLocalEndPoint = [aLocalEndPoint4[0], -aLocalEndPoint4[1], aLocalEndPoint4[2]]

        bMayaLimitAttrs = []
        for sA in ['EndLimitPosX', 'EndLimitNegX', 'EndLimitPosY', 'EndLimitNegY', 'EndLimitPosZ', 'EndLimitNegZ']:
            sAttr = '%s.%s' % (sJ, sA)
            bMayaLimitAttrs.append(cmds.getAttr(sAttr) if cmds.objExists(sAttr) else False)

        if np.any(bMayaLimitAttrs):
            sEndSpaceParentAttr = '%s.endSpaceParent' % sJ
            sEndSpaceParentMaya = cmds.getAttr(sEndSpaceParentAttr)
            sEndSpaceParent = 'game:%s' % dUnrealJointsMapper.get(sEndSpaceParentMaya, sEndSpaceParentMaya)
            bLimitAttrs = [False] * 6
            ffLimitAxes = [(1,0,0), (-1,0,0), (0,1,0), (0,-1,0), (0,0,1), (0,0,-1)]
            aaParentOrientMaya = utils.getNumpyMatrixFromTransform(sEndSpaceParentMaya, bThreeByThree=True)
            aaParentOrientUnrealInv = np.linalg.inv(utils.getNumpyMatrixFromTransform(sEndSpaceParent, bThreeByThree=True))

            for a in range(6):
                if bMayaLimitAttrs[a]:
                    aAxisWorld = np.dot(ffLimitAxes[a], aaParentOrientMaya)
                    aAxisGame = np.dot(aAxisWorld, aaParentOrientUnrealInv)
                    aBiggestAbs = np.argmax(np.abs(aAxisGame))
                    iSign = 1 if aAxisGame[aBiggestAbs] < 0 else 0
                    bLimitAttrs[aBiggestAbs*2 + iSign] = True

            #unreal swapping under bone space:
            bLimitAttrs[2], bLimitAttrs[3] = bLimitAttrs[3], bLimitAttrs[2]

            aEndSpaceParentMatrix = utils.getNumpyMatrixFromTransform(sEndSpaceParent)
            aLocalLimitEndPoint4 = np.dot(aEndPoint4, np.linalg.inv(aEndSpaceParentMatrix))
            fUnrealLocalLimitEndPoint = [aLocalLimitEndPoint4[0], -aLocalLimitEndPoint4[1], aLocalLimitEndPoint4[2]]

            sLimitsFlag = ", sLimitParent='%s', bLimits=[%s]" % \
                          (sEndSpaceParent.split(':')[-1], ','.join('True' if bL else 'False' for bL in bLimitAttrs))

            sPieceInputs.append(sEndSpaceParent.split(':')[-1])
        else:
            sLimitsFlag = ''

        sEndSpace = sEndSpace.split(':')[-1]
        sStartSpace = sStartSpace.split(':')[-1]
        bAttachEnd = True if cmds.getAttr('%s.attachEnd' % sJ) else False
        sUnrealCodeLines.append(f"functions.createMuscleJointFunction('{sJ.split(':')[-1]}', '{sEndJ.split(':')[-1]}', '{utils.getSide(sJ)}', '{sEndSpace}', "
                                f"\n\t\t\t\t{fSquashValues[0]}, {fSquashValues[1]}, {fSquashValues[2]}, {fSquashValues[3]}, fStretch={cmds.getAttr('%s.stretch' % sJ)}, bAttachEnd={bAttachEnd} {sLimitsFlag})")

        sPieceInputs.extend([sEndSpace, sStartSpace])
        if bPieceLines:
            sUnrealCodeLines.append("# PIECE.INPUTS: %s" % str(sPieceInputs))
            sUnrealCodeLines.append("# PIECE.TYPE: muscleJoint")
            sUnrealCodeLines.append("# PIECE.OUTPUTS: %s" % str([sJ.split(':')[-1]]))
            sUnrealCodeLines.append("# PIECE.END: %s" % sJ)

    return sUnrealCodeLines

    # for sKey in sCodeLineKeys:
    #     utils.data.addToList(sKey, sUnrealCodeLines)
    #     dumpUnrealCodeLinesToFile(sKey=sKey)


# depricated!! that causes issues when saving in unreal and is also inconvenient
def generateMuscleJointsCodeLoop(dUnrealJointsMapper={}):

    sCommands = []

    sCommands.append('\n\ndMuscles = OrderedDict()')

    sMuscleJoints = [sJ for sJ in cmds.ls('muscleJntU_?_*', 'game:muscleJnt_?_*', et='joint') if
                     not sJ.endswith('End')]

    if sMuscleJoints:
        for sJ in sMuscleJoints:
            # sParents = cmds.listRelatives(sJ, p=True, c=False)
            sStartSpace = cmds.getAttr('%s.startSpace' % sJ)
            sStartSpace = 'game:%s' % dUnrealJointsMapper.get(sStartSpace)
            sEndSpace = cmds.getAttr('%s.endSpace' % sJ)
            sEndSpace = 'game:%s' % dUnrealJointsMapper.get(sEndSpace)



            sEndJ = '%sEnd' % sJ.split(':')[1]
            if not cmds.objExists(sEndJ):
                raise Exception('%s doesn\'t exist' % sEndJ)
            fLength = abs(cmds.getAttr('%s.tx' % sEndJ))
            fEndPoint = cmds.xform(sEndJ, q=True, ws=True, t=True)
            aEndPoint4 = np.array(list(fEndPoint) + [1.0], dtype='float64')
            aEndSpaceMatrix = utils.getNumpyMatrixFromTransform(sEndSpace)
            aLocalEndPoint4 = np.dot(aEndPoint4, np.linalg.inv(aEndSpaceMatrix))
            fUnrealLocalEndPoint = [aLocalEndPoint4[0], -aLocalEndPoint4[1], aLocalEndPoint4[2]]


            fSquashValues = [cmds.getAttr('%s.%s' % (sJ, sA)) for sA in
                             ['squashZPos', 'squashZNeg', 'squashYPos', 'squashYNeg']] # Y and Z are swapped because of unreal
            # sSquashValues = ', '.join('%0.3f' % fV for fV in fSquashValues)

            # start limit. placeholder for if we end up adding it later...
            # sStartParentParent = ''
            # sStartLimitValues = ''

            # end limit
            sEndParentParent = 'None'
            sEndLimitValues = 'None'
            sEndParentParentAttr = '%s.endSpaceParent' % sJ
            if cmds.objExists(sEndParentParentAttr):
                sEndParentParent = cmds.getAttr(sEndParentParentAttr)
                if cmds.objExists(sEndParentParent):
                    fEndLimitValues = [cmds.getAttr('%s.%s' % (sJ, sA)) for sA in
                                       ['endLimitMinX', 'endLimitMinY', 'endLimitMinZ', 'endLimitMaxX', 'endLimitMaxY',
                                        'endLimitMaxZ']]
                    # in maya it's the space of the joint orient, while in unreal it's the space of the parentparent (sEndParentParent)
                    # which means we have to convert it now:
                    # outstanding issue: sometimes negative becaomes positive. Gotta figure out what to do then
                    aMapAxis = xforms.mapAxisSigned(sEndJ, sEndParentParent)
                    aMappedLimitValues = np.array(fEndLimitValues)[aMapAxis]
                    for i in range(3): # make sure minimums are smaller than maximums
                        if aMappedLimitValues[i] > aMappedLimitValues[i+3]:
                            aMappedLimitValues[i], aMappedLimitValues[i+3] = aMappedLimitValues[i+3], aMappedLimitValues[i]

                    sEndLimitValues = '[ %s ]' %', '.join('%0.3f' % fV for fV in aMappedLimitValues)



            sCommands.append("dMuscles['%s'] = [%s, %0.3f, '%s', '%s', %0.3f, %0.3f, %0.3f, %0.3f, '%s', %s]" % \
                               (sJ.split(':')[-1], str(fUnrealLocalEndPoint), fLength, utils.getSide(sJ), \
                                sEndSpace.split(':')[-1], fSquashValues[0], fSquashValues[1], fSquashValues[2], fSquashValues[3], \
                                sEndParentParent.split(':')[-1], sEndLimitValues))

        # sCommands.append("nodes.newSequencerPlug()")
        sCommands.append("functions.muscleJointLoop(dMuscles)")

        utils.data.addToList(kUnrealCodeLines, sCommands)

        dumpUnrealCodeLinesToFile()
    return sCommands


def createOutFilePath(sKey=kUnrealCodeLines):
    sSuffix = dFileSuffixesFromKeys[sKey]
    import kangarooTools.assets as assets
    sVersionFolder = assets.assetManager.getCurrentVersionPath()
    sAsset = assets.assetManager.getCurrentAsset()
    sOutFile = os.path.join(sVersionFolder, '%s_ueControlRig%s.py' % (sAsset, sSuffix)).replace('\\', '/')
    return sOutFile


def dumpUnrealCodeLinesToFile(bStartFromTemplate=False, sKey=kUnrealCodeLines):
    '''
    takes sKey (kUnrealCodeLines) data and puts it into the file.
    Then clears the sKey  data
    '''
    sUnrealCodeLines = utils.data.get(sKey)

    # sFileSuffix = dFileSuffixesFromKeys[sKey]
    sOutFile = createOutFilePath(sKey)

    sControlRigDir = os.path.normpath(os.path.join(os.path.dirname(__file__), os.pardir, 'controlRig')).replace('\\','/')
    if bStartFromTemplate:
        sTemplateFile = os.path.join(sControlRigDir, 'template.py')
    else:
        sTemplateFile = sOutFile


    if not os.path.exists(sTemplateFile):
        cmds.warning('Skipping. File "%s" doesn\'t exist' % sTemplateFile)
    else:
        sFileLines = utils.readFile(sTemplateFile)
        if bStartFromTemplate:
            sFileLines = [sLine.replace('CONTROLRIGFOLDER', "'%s'" % sControlRigDir) for sLine in sFileLines]

        for sLine in sUnrealCodeLines:
            if isinstance(sLine, str):
                sFileLines.append('\n%s' % sLine)

        sFileLines.append('\n\n\n')

        utils.createTextFile(sOutFile, sFileLines)

        utils.data.store(sKey, '[]')

        report.report.addLogText('py "%s"' % sOutFile, bQuotationsToLink=True)




def ENTRYKEY(sLimb, sFeature='', sPart='', sWriteCommands=None):
    sKey = '# ===ENTRYKEY=== for "%s" - %s - %s' % (sLimb, str(sFeature), str(sPart))
    if not utils.isNone(sWriteCommands):
        sWriteCommands.append(sKey)
    return sKey


def initiateAttacherDictCommand(sFeature, sWriteCommands=None):
    sWriteCommands.append("dAttachers_%s = defaultdict(list)" % sFeature)


def createKey_connectUserAttachers(sLimbName, sFeature, sFunctionNodeName, bForward=True, sWriteCommands=None):
    ENTRYKEY(sLimbName, sFeature, 'extendAttachersWithUserStuff', sWriteCommands=sWriteCommands)
    sWriteCommands.append("for sAttacher, eElements in dAttachers_%s.items():" % sFeature)
    sWriteCommands.append("    pins.connectToPinConstraintParentArray(eElements, '%%s.%%s' %% (%s, sAttacher))" % sFunctionNodeName) # before: pins.setConstraintParentArray(
    if bForward:
        ENTRYKEY(sLimbName, sFeature, 'createBlendChannelAttributes', sWriteCommands=sWriteCommands)
    ENTRYKEY(sLimbName, sFeature, 'connectBlendNodes', sWriteCommands=sWriteCommands)


def createKey_createBlendNodes(sLimbName, sFeature, sWriteCommands=None):
    ENTRYKEY(sLimbName, sFeature, 'blendNodes', sWriteCommands=sWriteCommands)
    setNewColumn(sWriteCommands=sWriteCommands)
    # sWriteCommands.append("controllers.setNewColumn()")



# C:\Users\thoma\OneDrive\Dokumente\Unreal Projects\MyProject2\Content\Characters\Mannequins\Rigs\CR_Mannequin_Body.uasset