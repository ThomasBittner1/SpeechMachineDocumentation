###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt
import numpy as np

import importlib
importlib.reload(utilsQt)

import kangarooAnimation.KangarooMatchTools as KangarooMatchTools

qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)

_kRowHeight = utilsQt.getDpi() / 4
_ButtonHeight = int(utilsQt.getDpi() * 0.3)

import time

class QDependencyEditorUi(QtWidgets.QDialog):

    def __init__(self, xFields, sWindowTitle, parent=utilsQt.getMayaWindow()):
        super(QDependencyEditorUi, self).__init__(parent, QtCore.Qt.Tool)
        self.setWindowTitle(sWindowTitle)
        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qqCombos = []
        for xField in xFields:
            qFieldLayout = QtWidgets.QHBoxLayout()
            self.layout.addLayout(qFieldLayout)
            sKey, xOptions, iComboDepth = xField
            print ('xOptions: ', xOptions)
            qFieldLayout.addWidget(QtWidgets.QLabel(sKey))

            # [('m_spine.spine_end', {'m_placement': ['main'], 'm_cog': ['main']})]

            qComboRow = []
            for i in range(iComboDepth):
                qNewCombo = QtWidgets.QComboBox()
                qFieldLayout.addWidget(qNewCombo)
                qComboRow.append(qNewCombo)

            sStartOptions = xOptions if isinstance(xOptions, (list,tuple)) else list(xOptions.keys())
            for sOption in sStartOptions:
                qComboRow[0].addItem(sOption)

            for i in range(iComboDepth-1):
                def _changedIndex(iIndex, qLeftCombo=qComboRow[0], qComboToChange=qComboRow[i+1], dOptions=xOptions):
                    sOptions = dOptions[qLeftCombo.currentText()]
                    for sOption in sOptions:
                        qComboToChange.clear()
                        qComboToChange.addItem(sOption)
                qComboRow[i].currentIndexChanged.connect(_changedIndex)
                # _changedIndex(0)

            iEstimatedIndex = np.searchsorted(sStartOptions, sKey)
            if iEstimatedIndex > 0:
                iEstimatedIndex -= 1
            qComboRow[0].setCurrentIndex(iEstimatedIndex)


            self.qqCombos.append(qComboRow)

        self.layout.addStretch()

        qApplyButton = QtWidgets.QPushButton('Apply')
        qApplyButton.clicked.connect(self.apply)
        self.layout.addWidget(qApplyButton)



    def apply(self):
        self.xResult = []
        for qComboRow in self.qqCombos:
            sComboTexts = tuple([qCombo.currentText() for qCombo in qComboRow])
            self.xResult.append(sComboTexts)

        self.close()


    def closeEvent(self, event):
        pass





_DependencyEditor = None
def showUi(xFields, sWindowTitle):
    global _DependencyEditor
    _DependencyEditor = QDependencyEditorUi(xFields, sWindowTitle)
    _DependencyEditor.exec()
    return ['@'.join(xR) for xR in _DependencyEditor.xResult]