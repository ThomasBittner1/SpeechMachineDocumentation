###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import importlib
import numpy as np
import traceback
import os
import time
import hashlib
from collections import defaultdict
from functools import reduce
import subprocess

import maya.cmds as cmds
import maya.mel as mel

import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()

mainWin = None

import kangarooTools.nodes as nodes
import kangarooTools.utilsQt as utilsQt
import kangarooTools.uiSettings as uiSettings
import kangarooTools.settings as settings
import kangarooTools.assets as assets
import kangarooTools.report as report

kPythonVersion = 3

utils.sourceEnvs()


def getLicenseInfo():
    sPythonFile = os.path.realpath(__file__)
    sPythonFile = utils.replaceStringEnd(sPythonFile, '.pyc', '.py')
    sLicense = ''
    utils.debugPrint('sPythonFile: ', sPythonFile)
    with open(sPythonFile) as myFile:
        sAllLines = list(myFile)
        for sL in sAllLines:
            utils.debugPrint('sL: ', sL)
            if sL.startswith('#'):
                sLicense += '%s ' % sL.replace('#', '').strip()
    return sLicense


sUpdateFile = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, 'update.txt')
sVersion = utils.readFile(sUpdateFile)[0]



def showUI():
    utils.debugPrint('starting showUI')

    global mainWin

    sLoadedPlugins = cmds.pluginInfo(query=True, listPlugins=True)
    for sPlugin in ['kt_cmdUndo', 'kt_edgeFlowMirror', 'kt_findClosestPoints', 'poseInterpolator', 'matrixNodes', 'quatNodes']:
        if sPlugin not in sLoadedPlugins:
            try:
                cmds.loadPlugin(sPlugin)
            except:
                pass

    if mainWin:
        toggleCollapsed()
        return

    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)

    if mainWin != None:
        utils.debugPrint("reloading UI...")
        mainWin.close()

    mainWin = KangarooBuilderTools()

    mainWin.dockUI()

    mainWin.bIsCollapsed = False
    np.set_printoptions(suppress=True)



def toggleCollapsed():

    if cmds.about(version=True) < '2025':
        global mainWin
        if not mainWin:
            showUI()
        else:
            if not hasattr(mainWin, 'bIsCollapsed'):
                mainWin.bIsCollapsed = True
                cmds.confirmDialog(m='bCollapsed attribute missing, please restart maya and open UI again. ')
            bCollapse = not mainWin.bIsCollapsed
            utils.debugPrint('collapse mainWin: ', mainWin)
            cmds.dockControl('kangarooDock', e=True, vis=not bCollapse)
            mainWin.bIsCollapsed = bCollapse

    else:
        sFullDockName = '%sWorkspaceControl' % kWorkspaceDockName

        if cmds.workspaceControl(sFullDockName, q=True, exists=True):
            if cmds.workspaceControl(sFullDockName, q=True, visible=True):
                cmds.workspaceControl(sFullDockName, e=True, visible=False)
            else:
                cmds.workspaceControl(sFullDockName, e=True, visible=True)
        else:
            print ('not exist yet. show it')
            DockableWidgetUIScript()





def initiateImportantStuff():
    sLoadedPlugins = cmds.pluginInfo(query=True, listPlugins=True)
    for sPlugin in ['kt_cmdUndo', 'kt_edgeFlowMirror', 'kt_findClosestPoints', 'poseInterpolator', 'matrixNodes', 'quatNodes']:
        if sPlugin not in sLoadedPlugins:
            try:
                cmds.loadPlugin(sPlugin)
            except:
                pass

    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)

    cmds.selectPref(tso=True)

    import numpy as np
    np.set_printoptions(suppress=True)



import maya.OpenMayaUI as OpenMayaUI
customMixinWindow = None

kWorkspaceDockName = 'kangarooMayaMixinWindow'


def DockableWidgetUIScript(restore=False):
    global customMixinWindow

    ''' When the control is restoring, the workspace control has already been created and
        all that needs to be done is restoring its UI.
    '''
    if restore == True:
        # Grab the created workspace control with the following.
        restoredControl = OpenMayaUI.MQtUtil.getCurrentParent()

    if customMixinWindow is None:
        # Create a custom mixin widget for the first time
        customMixinWindow = KangarooBuilderTools()
        customMixinWindow.setObjectName(kWorkspaceDockName)


    if restore == True:
        # Add custom mixin widget to the workspace control
        mixinPtr = OpenMayaUI.MQtUtil.findControl(customMixinWindow.objectName())
        OpenMayaUI.MQtUtil.addWidgetToMayaLayout(int(mixinPtr), int(restoredControl))
    else:
        # Create a workspace control for the mixin widget by passing all the needed parameters. See workspaceControl command documentation for all available flags.
        customMixinWindow.show(dockable=True, height=600, width=480, uiScript='import kangarooTools.UI3 as UI3; UI3.DockableWidgetUIScript(restore=True)')

    return customMixinWindow


class Tab(object):
    def __init__(self, sName):
        self.sName = sName
        self.modModule = None

        self.dFuncRuns = defaultdict(list)  # keys: sModules
        self.dFuncModules = defaultdict(list)  # keys: sModules
        self.sFuncOrder = []
        self.qSwitchButtons = []


class TModuleButton(QtWidgets.QPushButton):
    def __init__(self, parent=None):
        QtWidgets.QPushButton.__init__(self, parent)
        # self.setText("Press me")

    def mouseReleaseEvent(self, event):
        if not self.isChecked():
            QtWidgets.QPushButton.mouseReleaseEvent(self, event)
            if self.isChecked() and event.button() == QtCore.Qt.LeftButton:
                self.run()

    def run(self, bFromPush=False):
        self.setEnabled(False)
        self.UI.sLastButtonClicked = self.sModule
        for sOtherModule in list(self.dCurrentTabButtons.keys()):
            if sOtherModule != self.sModule:
                self.dCurrentTabButtons[sOtherModule].setChecked(False)
                self.dCurrentTabWidgets[sOtherModule].setHidden(True)
                self.dCurrentTabButtons[sOtherModule].setChecked(False)
                self.dCurrentTabButtons[sOtherModule].setEnabled(True)

        self.dCurrentTabWidgets[self.sModule].setHidden(False)

        for sControlName, tbControl in list(self.qtSecondLayout.dControlList.items()):
            if not tbControl.bIsChild:
                if sControlName in self.funcArgs:
                    tbControl.setEnabled(True)
                else:
                    tbControl.setEnabled(False)

        for sControlName in self.funcArgs:
            if sControlName in list(self.tbModuleSettings2.dControls.keys()):
                self.tbModuleSettings2.dControls[sControlName].runControlOtherControl()


class TApplyButton(QtWidgets.QPushButton):
    def __init__(self, parent=None):
        QtWidgets.QPushButton.__init__(self, parent)
        self.setMinimumWidth(5)
        self.bDisableOnServer = False

    def mouseReleaseEvent(self, event):
        if self.isDown() and event.button() == QtCore.Qt.LeftButton:
            try:
                self.run()
            except:
                raise
            finally:
                QtWidgets.QPushButton.mouseReleaseEvent(self, event)
        else:
            QtWidgets.QPushButton.mouseReleaseEvent(self, event)

    def run(self):
        report.report.clearLogText()
        report.report.setProgressBarColor(utils.uiColors.blue)
        report.report.addLogText('--- running %s ---' % (self.text()), iSize=9, bPrint=False)
        fTimeBefore = time.time()
        modModule = importlib.import_module('kangarooTabTools.%s' % self.sModuleImport)
        self.tbModuleSettings2.updateDictFromControls(self.dCombinedValues)

        sRun = self.funcRun.sFuncName
        try:
            if self.funcRun.bReloadBeforeRun:
                utils.reload2(modModule)
        except Exception as e:
            sError = traceback.format_exc()
            sError = 'RELOAD ERROR: %s' % sError
            report.report.addLogText(sError, sColor=utils.uiColors.red, bQuotationsToLink=True, bPrint=False)
            report.report.setProgressBarColor(utils.uiColors.red)
            report.report.setToFull()
            raise Exception(traceback.format_exc())

        funcRunReloaded = getattr(modModule, sRun)
        if funcRunReloaded.bCheckAsset:
            if not assets.checkIfAssetWasBuiltInCurrentAssetConfirmBox():
                return

        dDefaultsCombined = dict(list(zip(funcRunReloaded.args, funcRunReloaded.defaults)))

        sCommonAttrs = set(self.dCombinedValues.keys()).intersection(set(funcRunReloaded.args))
        dCommonValues = {sAttr: self.dCombinedValues[sAttr] for sAttr in sCommonAttrs}

        sLogParams = []
        for sParam, xValue in list(dCommonValues.items()):
            if dDefaultsCombined[sParam] != xValue:
                sLogParams.append(sParam)

        sValuesStrings = []
        for sParam in sLogParams:
            sValue = str(dCommonValues[sParam])
            if not sValue:
                sValue = 'None'
            elif len(sValue) > 200:
                sValue = '%s...' % sValue[:200]
            sValuesStrings.append(sValue)

        sParamsText = ['%s=%s' % (sParam, sVal) for sParam, sVal in zip(sLogParams, sValuesStrings)]
        report.report.addLogText('import kangarooTabTools.%s as %s' % (self.sModuleImport, self.sModuleImport),
                                 sWeight='bold', iSize=6, bPrint=False)
        report.report.addLogText('%s.%s(%s)' % (self.sModuleImport, self.funcRun.sFuncName, ', '.join(sParamsText)),
                                 sWeight='bold', iSize=6, bPrint=False)

        if '_report' in funcRunReloaded._args:
            dCommonValues['_report'] = report.report

        if self.funcRun.bPassApplyButton:
            print ('passing _qApplyButton...')
            dCommonValues['_qApplyButton'] = self


        try:
            bReturn = funcRunReloaded(**dCommonValues)
        except Exception:
            sError = traceback.format_exc()

            sErrorsSplit = sError.split('\n')
            iHighestBuilderErrorInd = -1
            for i in range(len(sErrorsSplit)):
                if 'builder.py' in sErrorsSplit[i]:
                    iHighestBuilderErrorInd = i
            if iHighestBuilderErrorInd != -1 and iHighestBuilderErrorInd < len(sErrorsSplit):
                sErrorsSplit = sErrorsSplit[iHighestBuilderErrorInd + 1:]
            sErrorsCombined = '\n'.join(sErrorsSplit)
            sError = 'TOOL ERROR: %s' % sErrorsCombined

            report.report.addLogText(sError, sColor=utils.uiColors.red, bQuotationsToLink=True, bPrint=False)
            report.report.setProgressBarColor(utils.uiColors.red)
            report.report.setToFull()
            utils.raiseExceptionNoChaining(traceback.format_exc())
        finally:
            utils.debugPrint('')

        fSeconds = time.time() - fTimeBefore
        report.report.addLogText('Done! It took: %s (%s)' % (utils.secondsNice(fSeconds), time.ctime()), sColor=utils.uiColors.green, bPrint=False)
        report.report.setProgressBarColor(utils.uiColors.yellow if bReturn == False else utils.uiColors.green)
        report.report.setToFull()

        for tRefreshControl in self.funcRun.tRefreshControlsAfterRun:
            tRefreshControl.refresh()  # (sRefreshControl)


class TDefaultButton(QtWidgets.QPushButton):
    def __init__(self, parent=None):
        QtWidgets.QPushButton.__init__(self, parent)

    def mouseReleaseEvent(self, event):
        if self.isDown() and event.button() == QtCore.Qt.LeftButton:
            try:
                self.run()
            except:
                raise
            finally:
                QtWidgets.QPushButton.mouseReleaseEvent(self, event)
        else:
            QtWidgets.QPushButton.mouseReleaseEvent(self, event)

    def run(self):
        for tbControl in list(self.tbModuleSettings.dControls.values()):
            tbControl.setToDefault()



from maya.app.general.mayaMixin import MayaQWidgetDockableMixin


_baseClasses = (QtWidgets.QDialog if cmds.about(version=True) < '2025' else MayaQWidgetDockableMixin, QtWidgets.QWidget)
class KangarooBuilderTools(*_baseClasses):

    def __init__(self, parent=None):

        super(KangarooBuilderTools, self).__init__(parent=parent)

        qtTopLayout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom)
        utils.debugPrint('reloading assets..')
        utils.reload2(assets)
        assets.tDisableOnServerButtons = []  # not necessary but if we decide to remove the reload(asset) line..

        self.setWindowTitle('Kangaroo Builder')
        report.createReport(self)
        # global _report
        # _report = report.report
        self.qLicenceRow = QtWidgets.QHBoxLayout()
        self.qLicenseInfoText = QtWidgets.QLabel('Standard free license', parent=self)
        self.qLicenceButton = QtWidgets.QPushButton('License Info and Update')
        self.qLicenceRow.addWidget(self.qLicenseInfoText)
        self.qLicenceRow.addWidget(self.qLicenceButton)

        self.qLicenceButton.clicked.connect(lambda: self.updateLicense(bShowDialog=True))

        self.assetManager = assets.createAssetManager(qtTopLayout)  # , _report=self._report)

        qWidgetAllTabs = QtWidgets.QTabWidget()
        self.setObjectName('kangarooDock_window')

        def _switchTabs(ind, UI=self, qWidgetAllTabs=qWidgetAllTabs):
            pass

        qWidgetAllTabs.currentChanged.connect(_switchTabs)

        self.dBTabs = getBTabsDictFromFiles()

        # sTabOrder = ['Poser', 'Face', 'Builder', 'Puppet', 'Export', 'SkinCluster', 'WeightMaps', 'Geometry', 'Ctrls']
        sTabOrder = ['Builder', 'Puppet', 'Export', 'SkinCluster', 'Ctrls', 'Geometry', 'WeightMaps', 'Unreal']
        sTabKeys = list(self.dBTabs.keys())
        aKeysInOrder = utils.findOneArrayInAnother(sTabOrder, sTabKeys, iMissingIndex=len(sTabOrder))
        aKeysSorted = np.argsort(aKeysInOrder)

        self.qLicenseRequiredLabels = []
        for iKeySorted in aKeysSorted:
            sTab = sTabKeys[iKeySorted]
            bTab = self.dBTabs[sTab]

            qTab = QtWidgets.QWidget()
            qWidgetAllTabs.addTab(qTab, sTab)

            qSplitLayout = QtWidgets.QHBoxLayout(qTab)
            qSplitLayout.setAlignment(QtCore.Qt.AlignTop)
            qSplitLayout.setSpacing(3)
            qSplitLayout.setAlignment(QtCore.Qt.AlignTop | QtCore.Qt.AlignLeft)
            qMenuLayout = QtWidgets.QVBoxLayout()
            qMenuLayout.setAlignment(QtCore.Qt.AlignTop | QtCore.Qt.AlignLeft)
            qToolSettingsLayout = QtWidgets.QVBoxLayout()
            qTabSettingsLayout = QtWidgets.QVBoxLayout()
            qTabSettingsLayout.setAlignment(QtCore.Qt.AlignTop)

            qTabControlsLayout = _createScrollLayout(qTabSettingsLayout)
            qTabControlsLayout.dControlList = {}  # to manage controls, that we don't have one control twice

            qSplitLayout.addLayout(qMenuLayout)

            qSplitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
            qSplitter.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
            qSplitLayout.addWidget(qSplitter)

            qSplitter.addWidget(utilsQt.makeWidgetFromLayout(qToolSettingsLayout, parent=self))
            qSplitter.addWidget(utilsQt.makeWidgetFromLayout(qTabSettingsLayout, parent=self))

            qSplitter.setSizes([100, 0])
            # qSplitter.setStretchfactor()

            dCurrentTabWidgets = {}  # keys: module names
            dCurrentTabButtons = {}  # keys: module names

            qThirdLayout = QtWidgets.QVBoxLayout()
            qThirdLayout.dControlList = {}  # to manage controls, that we don't have one control twice
            qToolSettingsLayout.addLayout(qThirdLayout)

            for sModule in bTab.sFuncOrder:
                funcRuns = bTab.dFuncRuns[sModule]

                qLayoutToolSettings = QtWidgets.QVBoxLayout()
                qLayoutToolSettings.setContentsMargins(0, 0, 0, 0)
                qLayoutToolSettings.setAlignment(QtCore.Qt.AlignTop)
                qToolSettingsWidget = utilsQt.makeWidgetFromLayout(qLayoutToolSettings, parent=self)
                qToolSettingsLayout.addWidget(qToolSettingsWidget)

                tbModuleSettings = uiSettings.Settings(funcRuns=funcRuns, sModuleNameForDebug='module - %s' % sModule)
                dCombinedValues = tbModuleSettings.dDefaultValues.copy()

                bAddDefaultButton = False
                qRunButtons = []
                dApplyButtons = {}
                for f, funcRun in enumerate(funcRuns):
                    sButtonName = funcRun.sRunButton
                    qButtonApply = TApplyButton(sButtonName)
                    qButtonApply.sModuleImport = bTab.dFuncModules[sModule][f]
                    qButtonApply.sModule = sModule
                    qButtonApply.funcRun = funcRun
                    qButtonApply.tbModuleSettings2 = tbModuleSettings
                    qButtonApply.dCombinedValues = dCombinedValues
                    qButtonApply.setToolTip(funcRun.sToolTip if funcRun.sToolTip else sButtonName)
                    qRunButtons.append(qButtonApply)
                    if funcRun.bAddDefaultButton != None:
                        bAddDefaultButton = funcRun.bAddDefaultButton
                    # qButtonApply._report = self._report
                    if funcRun.bDisableOnServer:
                        assets.tDisableOnServerButtons.append(qButtonApply)
                    dApplyButtons[sButtonName] = qButtonApply

                iBPR = 3
                iButtonCount = len(funcRuns)
                bAddDefaultButton = False # because it was useless?! Never clicked that button
                if bAddDefaultButton:
                    iButtonCount += 1
                iRowCount = iButtonCount // iBPR
                if (iButtonCount % iBPR) != 0:
                    iRowCount += 1

                qLayoutRunButtonsVert = QtWidgets.QVBoxLayout()
                qLayoutRunButtonsHorizs = []
                for iRow in range(iRowCount):
                    qLayoutHoriz = QtWidgets.QHBoxLayout()
                    qLayoutRunButtonsVert.addLayout(qLayoutHoriz)
                    qLayoutRunButtonsHorizs.append(qLayoutHoriz)
                for f, qBtn in enumerate(qRunButtons):
                    qLayoutRunButtonsHorizs[f // iBPR].addWidget(qBtn)
                if bAddDefaultButton:
                    qButtonDefault = TDefaultButton('Default')
                    qButtonDefault.tbModuleSettings = tbModuleSettings
                    qLayoutRunButtonsHorizs[-1].addWidget(qButtonDefault)

                qLayoutControls = _createScrollLayout(qLayoutToolSettings)
                qLayoutToolSettings.addLayout(qLayoutRunButtonsVert)

                # left module switch layout
                #
                qButtonSwitch = TModuleButton(sModule)
                qButtonSwitch.setFixedWidth(120)
                qButtonSwitch.setCheckable(True)

                if len(bTab.sFuncOrder) == 1:
                    qButtonSwitch.setHidden(True)

                sDocs = [funcRun.sDoc for funcRun in funcRuns if funcRun.sDoc]
                if sDocs:
                    sDoc = ''.join(sDocs)
                    sDoc = sDoc.strip()
                    sDoc = sDoc.replace('\n    ', '\n')
                    qDocSpace = QtWidgets.QSpacerItem(40, 10, QtWidgets.QSizePolicy.Expanding,
                                                      QtWidgets.QSizePolicy.Minimum)
                    qText = QtWidgets.QLabel(sDoc, parent=self)
                    qText.setWordWrap(True)
                    qText.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)

                    qLayoutControls.addWidget(qText)
                    qLayoutControls.addItem(qDocSpace)

                sDocumentationLinks = [funcRun.sDocumentationLink for funcRun in funcRuns if funcRun.sDocumentationLink]
                if sDocumentationLinks:
                    qDocumentationLink = QtWidgets.QLabel('<a href="%s"><i>Go to Documentation..</i></a>' % sDocumentationLinks[0])
                    qDocumentationLink.setOpenExternalLinks(True)  # opens links in default browser
                    qDocumentationLink.setTextInteractionFlags(QtCore.Qt.TextBrowserInteraction)
                    qLayoutControls.addWidget(qDocumentationLink)

                sAllTabControlsInModules = reduce((lambda x, y: x + y), [fR.sTabControls for fR in funcRuns])
                sAllTopControlsInModules = reduce((lambda x, y: x + y), [fR.sTopControls for fR in funcRuns])
                tbModuleSettings.buildControls(qLayoutControls, qtSecondLayout=qTabControlsLayout,
                                               qThirdLayout=qThirdLayout, qtWindow=self,
                                               sTabControls=sAllTabControlsInModules,
                                               sTopControls=sAllTopControlsInModules, dApplyButtons=dApplyButtons)
                tbModuleSettings.qSplitter = qSplitter

                for tControl in list(tbModuleSettings.dControls.values()):
                    if tControl.bDisableOnServer:
                        assets.tDisableOnServerControls.append(tControl)

                qToolSettingsWidget.setHidden(True)
                dCurrentTabWidgets[sModule] = qToolSettingsWidget
                qMenuLayout.addWidget(qButtonSwitch)
                dCurrentTabButtons[sModule] = qButtonSwitch

                funcArgs = reduce((lambda x, y: x + y), [fR.args for fR in funcRuns])
                qButtonSwitch.sModule = sModule
                qButtonSwitch.dCurrentTabButtons = dCurrentTabButtons
                qButtonSwitch.tbModuleSettings2 = tbModuleSettings
                qButtonSwitch.dCurrentTabWidgets = dCurrentTabWidgets
                qButtonSwitch.funcArgs = funcArgs
                qButtonSwitch.UI = self
                qButtonSwitch.qtSecondLayout = qTabControlsLayout

                bTab.qSwitchButtons.append(qButtonSwitch)

            bTab.qSwitchButtons[0].run()
            bTab.qSwitchButtons[0].setChecked(True)

            if not len(list(qTabControlsLayout.dControlList.keys())):
                qTabSettingsLayout.parent().setHidden(True)

        utils.debugPrint('done')
        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.hideWidget = QtWidgets.QWidget(self)
        self.layout2 = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.hideWidget.setLayout(self.layout2)

        self.layout.addWidget(self.hideWidget)

        self.layout2.addLayout(qtTopLayout)

        qVertSplitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        qVertSplitter.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.layout2.addWidget(qVertSplitter)
        qVertSplitter.setStretchFactor(95, 1)

        qVertSplitter.addWidget(qWidgetAllTabs)
        qVertSplitter.addWidget(report.report.qLog)
        self.layout2.addWidget(report.report.qProgress)

        self.layout2.addLayout(self.qLicenceRow)
        # self.resize(3000, 800)

        self.setMinimumWidth(10)

        dConfig = settings.getSettingsFileDict()
        # sSwitchAssetTo = dConfig.get('sCurrentAsset', None)
        bSwitchServerTo = dConfig.get('bServer', False)
        sSwitchProjectTo = dConfig.get('sCurrentProject', [None, None])
        # dAssetIndices = dConfig.get('dAssetIndices', {})
        dDefaultAssets = dConfig.get('dDefaultAssets', {})
        utils.debugPrint('filling projects')

        sProject = utils.toList(sSwitchProjectTo)[0]
        utils.debugPrint('bSwitchServerTo from UI: ', bSwitchServerTo)
        self.assetManager.fillProjects(bRefreshControls=False, sSwitchProjectTo=sSwitchProjectTo,
                                       sSwitchAssetTo=dDefaultAssets.get(sProject, 0), bSwitchServerTo=bSwitchServerTo)

        self.assetManager.refreshFilePathControls()
        self.updateLicense()

        initiateImportantStuff()

    def dockUI(self):
        if cmds.dockControl('kangarooDock', q=True, ex=True):
            cmds.deleteUI('kangarooDock')

        floatingLayout = cmds.paneLayout(configuration='single')

        cmds.dockControl('kangarooDock', area='right', aa=['left', 'right'], content=floatingLayout,
                         label='Kangaroo Builder %s' % sVersion, sizeable=True, width=700)
        cmds.control('kangarooDock_window', e=True, p=floatingLayout)
        return True


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            utils.debugPrint('ESCAPE WAS PUSHED')


    def updateLicense(self, bShowDialog=False):
        utils.debugPrint('udpateLicense called...')
        iLicenseType, sCompanyName, sLicenseTitle, sLicenseText = validateLicense()
        utils.debugPrint('setting license: ', sLicenseText)
        if utils.isNone(sCompanyName):
            self.qLicenseInfoText.setText('Trial License')
            self.qLicenseInfoText.setStyleSheet("QLabel { color : %s; }" % utils.uiColors.red)
        else:
            self.qLicenseInfoText.setText('Licensed to %s' % sCompanyName)
            self.qLicenseInfoText.setStyleSheet("QLabel { color : %s; }" % utils.uiColors.default)


        # if iLicenseType >= 1:
        #     self.qLicenseInfoText.setStyleSheet("")
        # else:
        #     self.qLicenseInfoText.setStyleSheet("QLabel { color : %s; }" % utils.uiColors.red)

        if bShowDialog:
            cmds.confirmDialog(title='%s (%d)' % (sLicenseTitle, kPythonVersion),
                               m='"%s" - %s' % (sLicenseTitle, sLicenseText))

        for qLabel in self.qLicenseRequiredLabels:
            qLabel.setHidden(True if iLicenseType > 0 else False)
            # print ('setting %s to %s' % (qLabel, (True if iLicenseType > 0 else False)))
        print ('iLicenseType: ', iLicenseType)
        print ('self.qLicenseRequiredLabels: ', self.qLicenseRequiredLabels)


def getBTabsDictFromFiles():
    dBTabs = {}

    sToolPath = os.path.join(utils.getToolsDir(), '..', 'kangarooTabTools')
    utils.debugPrint('sToolPath: ', sToolPath)
    sFiles = [sFile for sFile in os.listdir(sToolPath) if sFile.endswith('.py')]
    sModules = [sFile.split('.')[0] for sFile in sFiles]
    sPaths = [os.path.join(sToolPath, sFile) for sFile in sFiles]

    for m, sModule in enumerate(sModules):
        utils.debugPrint('sModule: ', sModule)
        try:
            modModule = importlib.import_module('kangarooTabTools.%s' % sModule)
            modModule = utils.reload2(modModule)
        except Exception:
            raise Exception(traceback.format_exc())

        sAttrsInModule = dir(modModule)

        sSourcedRuns = np.array([sAttr for sAttr in sAttrsInModule if hasattr(getattr(modModule, sAttr), 'bAddToUI')])
        sRuns = []
        funcs = []
        iLineNumbers = []
        for sRun in sSourcedRuns:
            iLine = utils.getLineNumberInFile(sPaths[m], 'def %s' % sRun)
            if iLine != None:
                sRuns.append(sRun)
                funcs.append(getattr(modModule, sRun))
                iLineNumbers.append(iLine)

        iSortRuns = np.argsort(iLineNumbers)

        for ind in iSortRuns:
            func = funcs[ind]
            sModuleButton = func.sModuleButton
            sTab = func.sTab

            if sTab in list(dBTabs.keys()):
                bTab = dBTabs[sTab]
            else:
                bTab = Tab(sTab)

            if sModuleButton not in bTab.sFuncOrder:
                bTab.sFuncOrder.append(sModuleButton)
            bTab.dFuncRuns[sModuleButton].append(func)
            bTab.dFuncModules[sModuleButton].append(sModule)
            dBTabs[sTab] = bTab

    utils.debugPrint('returning tabs')
    return dBTabs


def _createScrollLayout(qParentWidget):
    qScrollArea = QtWidgets.QScrollArea()
    qScrollArea.setWidgetResizable(True)
    qParentWidget.addWidget(qScrollArea)
    qReturnLayout = QtWidgets.QVBoxLayout()
    qReturnLayout.setAlignment(QtCore.Qt.AlignTop)
    qToolControlsLayoutWidget = QtWidgets.QWidget()
    qToolControlsLayoutWidget.setLayout(qReturnLayout)
    qScrollArea.setWidget(qToolControlsLayoutWidget)
    return qReturnLayout


def validateLicense():
    sPassword = 'dasgymBildshirmDreifachRadVergroesserer'
    iLicenseType, sCompanyName, sLicenseTitle, sLicenseText = 0, None, 'Trial License', 'This free trial license can only be used for Student and Hobby projects that don\'t generate any money or other income'
    sLicenseText = '''
This free trial license can only be used for Student and Hobby projects that don\'t generate any money or other income.
If you are working for content that generates money or any other type of income, a license must be purchased.

Furthermore, the author (Thomas Bittner) does not take any responsibility/liability for any damage caused by any of those scripts/tools inside the Kangaroo Builder.
'''

    sPythonFile = os.path.realpath(__file__)
    # utils.debugPrint ('sPythonFile: ', sPythonFile)
    sLicenseDir = os.environ.get('KANGAROO_LICENSE_PATH', os.path.normpath(os.path.join(os.path.dirname(sPythonFile), os.pardir, os.pardir, 'license')))
    if os.path.exists(sLicenseDir):
        sLicenseDir = os.path.normpath(sLicenseDir)
        sFiles = [sF for sF in os.listdir(sLicenseDir) if not sF.startswith('_') and not os.path.isdir(os.path.join(sLicenseDir, sF))]
    else:
        sFiles = []
    try:
        if sFiles:
            iTimes = [os.path.getmtime(os.path.join(sLicenseDir, sF)) for sF in sFiles]
            iMostRecentTime = np.argmax(iTimes)

            sFile = sFiles[iMostRecentTime]
            sLicenseFileInfo = readFile(os.path.join(sLicenseDir, sFile))
            print ('sLicenseFileInfo: ', sLicenseFileInfo)
            sLicenseKey_ = sLicenseFileInfo[0].strip()
            sCompanyName_ = sLicenseFileInfo[1].strip()
            iLicenseType_ = int(sLicenseFileInfo[2].strip())
            sLicenseTitle_ = sLicenseFileInfo[3].strip()
            sLicenseText_ = sLicenseFileInfo[4].strip()

            sEmail = sFile[:-4]
            iLicenseType = int(sLicenseKey_[:2])
            sShaLicense = sLicenseKey_[2:]

            sString = '%02d%s%s%s%s%s' % (
            iLicenseType_, sPassword, sEmail.strip(), sCompanyName_.strip(), sLicenseTitle_.strip(),
            sLicenseText_.strip())

            sCalculatedLicense = hashlib.sha256(sString.encode()).hexdigest()

            if len(sShaLicense) > 20 and sCalculatedLicense.startswith(sShaLicense):
                iLicenseType, sCompanyName, sLicenseTitle, sLicenseText = iLicenseType_, sCompanyName_, sLicenseTitle_, sLicenseText_
            else:
                print ('license key not matching')

    except Exception as e:
        cmds.confirmDialog(m='error getting license: "%s"' % e)
        raise
    finally:
        return iLicenseType, sCompanyName, sLicenseTitle, sLicenseText


def readFile(sFilePath):
    with open(sFilePath) as myFile:
        sAllLines = list(myFile)
    return sAllLines


