###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from maya import cmds


xCopiedSel = None
def copySel():
    global xCopiedSel
    xCopiedSel = cmds.ls(sl=True)


def pasteSel():
    global xCopiedSel
    if xCopiedSel:
        cmds.select(xCopiedSel)


def pasteSelAdd():
    global xCopiedSel
    if xCopiedSel:
        cmds.select(xCopiedSel, add=True)


def pasteSelAddFirst():
    global xCopiedSel
    if xCopiedSel:
        cmds.select(xCopiedSel, addFirst=True)


def pasteSelDeselect():
    global xCopiedSel
    if xCopiedSel:
        cmds.select(xCopiedSel, deselect=True)

