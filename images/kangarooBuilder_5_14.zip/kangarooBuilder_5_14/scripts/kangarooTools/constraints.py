###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import numpy as np
import copy
import maya.api.OpenMaya as OpenMaya2
from collections import defaultdict
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.nodes as nodes
import kangarooTools.deformers as deformers
import kangarooTools.patch as patch
import kangarooTools.curves as curves
import kangarooTabTools.weights as weights


def setupAllPuppetCustomAttachments(bRotateByNeighborVerts=False, bLegacyWrongDeformerOrder=False, bLegacyIgnoreScale=False, bConnectEnvelopes=False, bIgnoreDeformers=False, bIgnoreTransforms=False):

    report.report.addLogText('setup All Puppet Custom Attachments...')

    sTransforms = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.sPuppetParentAttachment' % sT) and ':' not in sT]
    dMeshAttach = defaultdict(list)
    bSkippedSomething = False
    print('sTransforms: ', sTransforms)
    dScaleTransforms = {}
    dScaleTransformOuts = {}
    for sT in sTransforms:
        if not bLegacyIgnoreScale:
            sScaleTransform  = cmds.getAttr('%s.sPuppetParentAttachmentScaleTransform' % sT)
            dScaleTransforms[sT] = sScaleTransform
            if sScaleTransform not in dScaleTransformOuts:
                dScaleTransformOuts[sScaleTransform] = nodes.getScaleFromXform(sScaleTransform)

        print('checking %s...' % sT)

        sParent = cmds.getAttr('%s.sPuppetParentAttachment' % sT)

        if '+' in sParent:
            sParent, sVertexId = sParent.split('+')[:2]
            iVertexId = int(sVertexId) if sVertexId.strip() else None
        else:
            iVertexId = None

        if sParent.startswith('deformers:'):
            sParent = sParent.replace(':', ';')

        if not bIgnoreTransforms and not sParent.startswith('deformers;'):
            sFirstSplit = sParent.split('.')[0]
            if not cmds.objExists(sFirstSplit):
                report.report.addLogText('skipping custom attacher for Limb "%s" ("%s"), constrainer "%s" not found (0)' % ( cmds.getAttr('%s.sLimb' % sT), sT, sFirstSplit))
                bSkippedSomething = True
                continue

        if sParent.startswith('deformers;'):
            if not bIgnoreDeformers:
                sSplits = sParent.split(';')
                if sSplits[0] == 'deformers':
                    sMeshCheck = sSplits[1]
                    if not cmds.objExists(sMeshCheck):
                        report.report.addLogText('Mesh "%s" doesn\'t exist (%s)' % (sMeshCheck, sT))
                        bSkippedSomething = True
                        continue
                    dMeshAttach[sParent].append((sT, iVertexId))

        elif '.' in sParent:
            sSplits = sParent.split('.')
            if len(sSplits) == 2 and sSplits[1].startswith('allDeformersExceptLast'): # legacy.. deformersExceptLast would work also
                if not bIgnoreDeformers:
                    raise Exception('allDeformersExceptLast not supported anymore')
            elif len(sSplits) == 2 and sSplits[1] == 'geo':
                if not bIgnoreDeformers:
                    dMeshAttach['%s.geo.00' % sParent.split('.')[0]].append([sT, iVertexId])
            else:
                if not bIgnoreTransforms:
                    report.report.addLogText('skipping custom attacher for Limb "%s" ("%s"), constrainer "%s" not found (1)' % (
                    cmds.getAttr('%s.sLimb' % sT), sT, sParent))
                    bSkippedSomething = True
                    continue
        else:
            if not bIgnoreTransforms:
                matrixParentConstraint(sParent, sT, mo=True)

    print('dMeshAttach: ', dMeshAttach)
    if not bIgnoreDeformers:
        for sMeshInfo, xTransforms in list(dMeshAttach.items()):
            sTransforms, iVertexIds = list(zip(*xTransforms))

            sLimbs = list(set([cmds.getAttr('%s.sLimb' % sT) for sT in sTransforms]))
            try:
                if sMeshInfo.startswith('deformers;'):
                    sSplits = sMeshInfo.split(';')
                    sMesh = sSplits[1]
                    sInputDeformers = sSplits[2:]

                    # for costumes being attached to external body
                    if sMesh.startswith('body:'):
                        sMaster = xforms.getRootOfNode(sTransforms[0])
                        sCostume = cmds.getAttr('%s.sCostumeName' % sMaster)
                        def funcConvertPlugName(sPlug):
                            sObject, sAttr = sPlug.split('.')
                            sNewObject = '%s_%s' % (sObject.split(':')[-1], sCostume)
                            return '%s.%s' % (sNewObject, sAttr)
                    else:
                        funcConvertPlugName = None

                    aPoints = xforms.getPositionArray(sTransforms)
                    aIds = xforms.getClosestIdsFromPoints(sMesh, aPoints)

                    for i, sT in enumerate(sTransforms):
                        if not utils.isNone(iVertexIds[i]):
                            aIds[i] = iVertexIds[i]
                    #     sAttr = '%s.parallelAttachmentVertexId' % sT
                    #     if cmds.objExists(sAttr):
                    #         aIds[i] = int(cmds.getAttr(sAttr))

                    sDeformersOnMesh = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape', 'skinCluster', 'ffd'])
                    sDeformers = [sD for sD in sDeformersOnMesh if sD in sInputDeformers]
                    sLocsParent = xforms.createIfNotExists('grp_customTransforms', sParent='modules')

                    sDeformers = sDeformers[::-1]
                    sLocs = parallelTransformAsDeformers2(sMesh, aIds, sParent=sLocsParent, sDeformers=sDeformers, bRotateByNeighborVerts=bRotateByNeighborVerts, funcConvertPlugName=funcConvertPlugName)
                    for t, sTransform in enumerate(sTransforms):
                        matrixParentConstraint(sLocs[t], sTransform, mo=True)
                        if not bLegacyIgnoreScale:
                            sScaleTransform = dScaleTransforms[sTransform]
                            cmds.scaleConstraint(sScaleTransform, sLocs[t])
                else:
                    sMesh, sType, sSkipDeformers = sMeshInfo.split('.')
                    if sType == 'allDeformersExceptLast':
                        raise Exception('allDeformersExceptLast is not supported anymore (%s)' % sMeshInfo)

                        if iSkipDeformers:
                            sDeformers = sDeformers[iSkipDeformers:]
                        sLocsParent = xforms.createIfNotExists('grp_customTransforms', sParent='modules')

                        if not bLegacyWrongDeformerOrder:
                            sDeformers = sDeformers[::-1]
                        sLocs = parallelTransformAsDeformers(sMesh, aIds, sParent=sLocsParent, sBlendShape=True,
                                                                   sDeformers=sDeformers, bRotateByNeighborVerts=bRotateByNeighborVerts, bConnectEnvelopes=bConnectEnvelopes)
                        for t, sTransform in enumerate(sTransforms):
                            matrixParentConstraint(sLocs[t], sTransform, mo=True)
                            if not bLegacyIgnoreScale:
                                sScaleTransform = dScaleTransforms[sTransform]
                                cmds.scaleConstraint(sScaleTransform, sLocs[t])

                    elif sType == 'geo':
                        aPoints = xforms.getPositionArray(sTransforms)
                        fClosestIds = xforms.getClosestInfoFromPoints(sMesh, aPoints, bVertex=True)[:,0]
                        for t,sTransform in enumerate(sTransforms):
                            sLoc = getLocatorFromNeighborVerts(sMesh, int(fClosestIds[t]), sParent='modules')
                            matrixParentConstraint(sLoc, sTransform, mo=True)

                    else:
                        raise Exception('don\'t know what type %s is' % sType)

            except Exception as e:
                report.report.addLogText('problems running custom attacher %s: %s' % (utils.listToString(sLimbs), e))
                raise

    if bSkippedSomething:
        return False



def getLocatorFromNeighborVerts(sMesh, iVertex, sParent=None):
    sGrp = cmds.createNode('transform', n='grp_geoAttach_%s_%d' % (sMesh, iVertex), p=sParent)

    mMesh = utils.getDagPath(sMesh)
    mVertexIter = OpenMaya2.MItMeshVertex(mMesh)
    fnMesh = OpenMaya2.MFnMesh(mMesh)
    mVertexIter.setIndex(iVertex)
    iNeighborIds = np.array(mVertexIter.getConnectedVertices(), dtype=int)
    aPoints = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True), dtype='float64').reshape(-1,3)
    aLocalPoints = aPoints[iNeighborIds] - aPoints[iVertex]
    iBiggestInd = np.argmax(np.linalg.norm(aLocalPoints, axis=1))
    iBiggestId = iNeighborIds[iBiggestInd]
    aFirstVector = aPoints[iBiggestId] - aPoints[iVertex]
    aDots = np.sum(aFirstVector * aLocalPoints, axis=-1)
    iMostNormal = np.argmin(np.abs(aDots))
    iMostNormalId = iNeighborIds[iMostNormal]

    iEdges = mVertexIter.getConnectedEdges()
    iEdge0 = None
    iEdge1 = None
    bEdgeReverse0 = None
    bEdgeReverse1 = None
    for iEdge in iEdges:
        iVertIds = fnMesh.getEdgeVertices(iEdge)
        if iBiggestId in iVertIds:
            iEdge0 = iEdge
            bEdgeReverse0 = True if iBiggestId == iVertIds[0] else False
        if iMostNormalId in iVertIds:
            iEdge1 = iEdge
            bEdgeReverse1 = True if iMostNormalId == iVertIds[0] else False

    sCurve0 = cmds.duplicateCurve('%s.e[%d]' % (sMesh, iEdge0), n=utils.getUniqueName('curve_biggestVertEdgeFrom_%s_%d' % (sMesh,iVertex)))[0]
    sCurve1 = cmds.duplicateCurve('%s.e[%d]' % (sMesh, iEdge1), n=utils.getUniqueName('curve_biggestVertEdgeFrom_%s_%d' % (sMesh,iVertex)))[0]

    sCurveInfoMain = curves.createPointInfoNode(sCurve0, fParam=1 if bEdgeReverse0 else 0, bFakePercentage=True)[1]
    sCurveInfoBiggest = curves.createPointInfoNode(sCurve0, fParam=0 if bEdgeReverse0 else 1, bFakePercentage=True)[1]
    sCurveInfoMostNormal = curves.createPointInfoNode(sCurve1, fParam=0 if bEdgeReverse1 else 1, bFakePercentage=True)[1]

    sLocator = xforms.createLocator(utils.getUniqueName('loc_geoAttach_%s_%d' % (sMesh, iVertex)), xPos = cmds.getAttr(sCurveInfoMain)[0])
    cmds.connectAttr(sCurveInfoMain, '%s.t' % sLocator)

    aimConstraintFromLocalPoints(sLocator, sAim=sCurveInfoBiggest, sUp=sCurveInfoMostNormal, sParent=sGrp)

    cmds.parent(sLocator, sCurve0, sCurve1, sGrp)
    cmds.setAttr('%s.v' % sCurve0, False)
    cmds.setAttr('%s.v' % sCurve1, False)

    return sLocator



# to do:
# 1. take rotate order and specify in the decompose node
def matrixParentConstraint(sMaster, sChild, mo=False, skipTranslate=[], skipRotate=[], skipScale=[], bChildParentIsInOrigin=False,
                           sParentAttr='matrixParentConstraintTarget', bJustReturnMatrix=False, bForce=False, bAvoidCycle=False, bKeepJointOrient=False, sJumpOverTransforms=[]):

    if skipTranslate == True:
        skipTranslate = ['x','y','z']
    if skipRotate == True:
        skipRotate = ['x','y','z']
    if skipScale == True:
        skipScale = ['x','y','z']


    if cmds.objectType(sChild) == 'joint':
        if not bKeepJointOrient:
            cmds.setAttr('%s.jo' % sChild, lock=False)
            xforms.jointOrientToRotation(sChild)
            cmds.setAttr('%s.jo' % sChild, lock=True)

    if bAvoidCycle:
        sParents = cmds.listRelatives(sChild, p=True, c=False)
        if sParents:
            sParentInverse = '%s.worldInverseMatrix' % sParents[0]
        else:
            sParentInverse = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0]
    else:
        sParentInverse = '%s.parentInverseMatrix' % sChild


    if mo == True:
        fOffset = utils.multiplyMatrixAttrValues([cmds.getAttr('%s.worldMatrix' % sChild), cmds.getAttr('%s.worldInverseMatrix' % sMaster)])
        if bChildParentIsInOrigin:
            sMultiply = nodes.createMultMatrixNode([fOffset,
                                                    '%s.worldMatrix' % sMaster], sName='PC_%s_' % sMaster)
        else:
            if sJumpOverTransforms:
                sMultiply = nodes.createMultMatrixNode([fOffset,
                                                        '%s.worldMatrix' % sMaster,
                                                        '%s.worldInverseMatrix' % sJumpOverTransforms[0],
                                                        '%s.worldMatrix' % sJumpOverTransforms[1],
                                                        sParentInverse], sName='PC_%s__' % sMaster)
            else:
                sMultiply = nodes.createMultMatrixNode([fOffset,
                                                        '%s.worldMatrix' % sMaster,
                                                        sParentInverse], sName='PC_%s_' % sMaster)

    else:
        if bChildParentIsInOrigin:
            sMultiply = '%s.worldMatrix' % sMaster
        else:
            if sJumpOverTransforms:
                sMultiply = nodes.createMultMatrixNode(['%s.worldMatrix' % sMaster,
                                                        '%s.worldInverseMatrix' % sJumpOverTransforms[0],
                                                        '%s.worldMatrix' % sJumpOverTransforms[1],
                                                        sParentInverse], sName='PC_%s_' % sMaster)
            else:
                sMultiply = nodes.createMultMatrixNode(['%s.worldMatrix' % sMaster,
                                                        sParentInverse], sName='PC_%s_' % sMaster)

    if bJustReturnMatrix:
        return sMultiply
    else:
        sDecompose = nodes.createDecomposeMatrix(sMultiply, sName='PC_%s__' % sMaster).split('.')[0]
        utils.addStringAttr(sDecompose, 'sParent', sMaster)
        if not skipTranslate:
            cmds.connectAttr('%s.outputTranslate' % sDecompose, '%s.t' % sChild, force=bForce)
        else:
            for a, sAxis in enumerate(['x','y','z']):
                if sAxis not in skipTranslate:
                    cmds.connectAttr('%s.outputTranslate%s' % (sDecompose, sAxis.upper()), '%s.t%s' % (sChild, sAxis), force=bForce)

        if not skipRotate:
            if bKeepJointOrient:
                try:
                    cmds.setAttr('%s.jo' % sChild, lock=True)
                except: pass
                sJointOrientToQuat = cmds.createNode('eulerToQuat', n='jointOrientToQuad')
                nodes._connectOrSetVector('%s.jo' % sChild, '%s.inputRotate' % sJointOrientToQuat)
                sQuatInverse = cmds.createNode('quatInvert', n='quatInvert')
                cmds.connectAttr('%s.outputQuat' % sJointOrientToQuat, '%s.inputQuat' % sQuatInverse)
                sQuatProduct = cmds.createNode('quatProd', n='quatProd')
                cmds.connectAttr('%s.outputQuat' % sDecompose, '%s.input1Quat' % sQuatProduct)
                cmds.setAttr('%s.input2Quat' % sQuatProduct, *cmds.getAttr('%s.outputQuat' % sQuatInverse)[0])
                nodes.createQuatToEulerNode('%s.outputQuat' % sQuatProduct, '%s.r' % sChild, bForce=bForce)
                cmds.delete(sJointOrientToQuat, sQuatInverse)
            else:
                cmds.connectAttr('%s.outputRotate' % sDecompose, '%s.r' % sChild, force=bForce)
        else:
            for a, sAxis in enumerate(['x','y','z']):
                if sAxis not in skipRotate:
                    cmds.connectAttr('%s.outputRotate%s' % (sDecompose, sAxis.upper()), '%s.r%s' % (sChild, sAxis), force=bForce)

        if not skipScale:
            cmds.connectAttr('%s.outputScale' % sDecompose, '%s.s' % sChild, force=bForce)
        else:
            for a, sAxis in enumerate(['x','y','z']):
                if sAxis not in skipScale:
                    cmds.connectAttr('%s.outputScale%s' % (sDecompose, sAxis.upper()), '%s.s%s' % (sChild, sAxis), force=bForce)


        utils.addStringAttr(sDecompose.split('.')[0], sParentAttr, sMaster)
        utils.addStringAttr(sMultiply.split('.')[0], sParentAttr, sMaster)

        return sMultiply, sDecompose


def getParentConstrainer(sSourceObjectOrAttr):
    sDecomposes = [sN for sN in (cmds.listConnections(sSourceObjectOrAttr, t='decomposeMatrix') or []) if '_PC_' in sN]
    if sDecomposes:
        return cmds.getAttr('%s.matrixParentConstraintTarget' % sDecomposes[0]) #was: %s.sParent



kRotateByNeighborVerts = 'bRotateByNeighborVerts'
# do to:
# 1) fix: if there's no connection into the blendShape target, he'll reset it.
# 2) optimize to avoid duplicated nodes (tricky because of ssIgnoreTargets (might not be worth it)
def parallelTransformAsDeformers(sMesh, iIds, sBlendShape=True, fInfluenceWeightLimit=0.01, fTargetMinimumDistance=0.001, sParent=None,
                                 sDeformers=[], funcConvertPlugName=None, sScaleJoint=None, ssIgnoreTargets=[], bRotateByNeighborVerts=[], bConnectEnvelopes=True):

    fAverageJointRadius = xforms.getAverageJointRadius()

    bCurve = False
    for sDeformer in sDeformers:
        if not isinstance(sDeformer, (list,tuple)) and cmds.objectType(sDeformer) != 'skinCluster':
            bCurve = True

    if bRotateByNeighborVerts == True or bCurve:
        bRotateByNeighborVerts = [True for _ in range(len(iIds))]
    elif bRotateByNeighborVerts == False:
        bRotateByNeighborVerts = [False for _ in range(len(iIds))]


    report.report.refreshIcon(True)
    for sSkinCluster in sDeformers:
        if not isinstance(sSkinCluster, (list,tuple)) and (not cmds.objExists(sSkinCluster) or cmds.objectType(sSkinCluster) not in ['skinCluster', 'ffd']):
            raise Exception('SkinCluster/Lattice %s doesn\'t exist' % sSkinCluster)

    if sBlendShape == True:
        sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]
        else:
            sBlendShape = False

    sConnections = []
    aIds = np.array(iIds, dtype=int)
    aUniqueIds = np.unique(np.array(iIds, dtype=int))
    aIdsOrder = utils.findOneArrayInAnother(aUniqueIds, iIds)
    if -1 in aIdsOrder:
        raise Exception('there are issues with iIds array: %s' % str(iIds))


    sScaleAttr = None
    if sScaleJoint:
        sScaleAttr = nodes.getScaleFromXform(sScaleJoint)

    pMesh = patch.patchFromName(sMesh)
    pMesh.aIds = aUniqueIds
    aDefaultPoints = pMesh.getAllPoints()


    iiVectors = []
    aaNbs = pMesh.getNeighbors(bExcludeNeighborsNotInIds=False)
    iIds3 = []
    for i, iInd in enumerate(aIdsOrder):
        bVectors = True if i < len(bRotateByNeighborVerts) and bRotateByNeighborVerts[i] else False
        iId = aUniqueIds[iInd]
        if not bVectors:
            iiVectors.append(None)
            iIds3 += [iId, iId, iId]
        else:
            aNbs = aaNbs[iInd]
            if not len(aNbs):
                raise Exception('not finding neighbor vertices from "%s", id %d' % (sMesh, iId))

            xPairInfos = []
            for m in range(0, len(aNbs), 1):
                for n in range(m + 1, len(aNbs), 1):
                    aPointM = aDefaultPoints[aNbs[m]] - aDefaultPoints[iId]
                    aPointN = aDefaultPoints[aNbs[n]] - aDefaultPoints[iId]
                    fLengthM = np.linalg.norm(aPointM)
                    fLengthN = np.linalg.norm(aPointN)
                    aPointM /= fLengthM
                    aPointN /= fLengthN
                    fDot = np.dot(aPointM, aPointN)
                    xPairInfos.append([[aNbs[m], aNbs[n]], fDot, fLengthM, fLengthN])

            xPairInfos.sort(key=lambda x: min(x[2], x[3]), reverse=True)
            if len(xPairInfos) > 2:
                xPairInfos = xPairInfos[:len(xPairInfos) // 2]
            xPairInfos.sort(key=lambda x: abs(x[1]))
            iBestVector = xPairInfos[0][0]
            if xPairInfos[0][2] < xPairInfos[0][3]:
                iBestVector[0], iBestVector[1] = iBestVector[1], iBestVector[0]
            iiVectors.append(iBestVector)
            iIds3 += [iId, iBestVector[0], iBestVector[1]]


    sBlendShapePositions = []
    if not sBlendShape:
        ssBlendShapeThreeSums = []
        for i, iInd in enumerate(aIdsOrder):
            aPoint = aDefaultPoints[aUniqueIds[iInd]]
            sBlendShapePositions.append(aPoint)
            sThreeSums = [aPoint]
            if isinstance(iiVectors[i], (list,tuple)):
                sThreeSums.append(aDefaultPoints[iiVectors[i][0]])
                sThreeSums.append(aDefaultPoints[iiVectors[i][1]])
            ssBlendShapeThreeSums.append(sThreeSums)

    else:
        dTargets = deformers.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        sTargets = list(dTargets.keys())

        sAttrs = ['%s.%s' % (sBlendShape,sT) for sT in sTargets]
        for t,sT in enumerate(sTargets):
            sConns = cmds.listConnections(sAttrs[t], s=True, d=False, p=True)
            if not sConns:
                sConnections.append(sAttrs[t])
            else:
                sDriver = sConns[0]
                sConnections.append(sDriver)
                cmds.disconnectAttr(sDriver, sAttrs[t])
            cmds.setAttr(sAttrs[t], 0)

        dTargets = deformers.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

        aTargetPoints = []
        dInbetweenPoints = {}
        for t, sT in enumerate(sTargets):
            cmds.setAttr(sAttrs[t], 1.0)
            aTargetPoints.append(pMesh.getAllPoints())

            fInbetweens = deformers.getInbetweens(sBlendShape, iTargetIndex=dTargets[sT])
            dInbetweenPoints[sT] = []
            for fWeight in fInbetweens:
                cmds.setAttr(sAttrs[t], fWeight)
                dInbetweenPoints[sT].append([fWeight, pMesh.getPoints()])

            cmds.setAttr(sAttrs[t], 0.0)


        ssBlendShapeThreeSums = []
        for i, iInd in enumerate(aIdsOrder):
            iId = aUniqueIds[iInd]

            ssMultipls3 = [[aDefaultPoints[iId]]]
            if bVectors:
                ssMultipls3 += [[aDefaultPoints[iiVectors[i][0]]], [aDefaultPoints[iiVectors[i][1]]]]
            for t, sT in enumerate(sTargets):
                bIgnoreThisTarget = False
                if i < len(ssIgnoreTargets):
                    for sIgnoreT in ssIgnoreTargets[i]:
                        sIgnoreT = sIgnoreT.split('.')[-1]
                        if sT == sIgnoreT:
                            bIgnoreThisTarget = True
                            break
                if bIgnoreThisTarget:
                    continue

                iDoIds = [iId]
                if bVectors:
                    iDoIds += iiVectors[i]
                for a, iDoId in enumerate(iDoIds):
                    aVector = aTargetPoints[t][iDoId] - aDefaultPoints[iDoId]
                    if np.linalg.norm(aVector) >= fTargetMinimumDistance:
                        if not dInbetweenPoints[sT]:
                            ssMultipls3[a].append(nodes.createVectorMultiplyNode(aVector, sConnections[t], bVectorByScalar=True,
                                             sName='generatePositionE_%s_%s_vtx%d' % (sMesh,sT,iDoId)))
                        else:
                            fWeights = []
                            fTargets = []
                            for fW, aTargets in dInbetweenPoints[sT]:
                                fWeights.append(fW)
                                fTargets.append(aTargets[i]-aDefaultPoints[iDoId])
                            fWeights = [0.0] + fWeights + [1.0]
                            fTargets = [[0.0, 0.0, 0.0]] + [list(fT) for fT in fTargets] + [list(aVector)]
                            sDrivenKeys = [nodes.setDrivenKey(sConnections[t], fWeights, None, [fT[a] for fT in fTargets],
                                                              sInTanType='linear', sOutTanType='linear') for a in [0,1,2]]
                            ssMultipls3[a].append(sDrivenKeys)

            sThreeSums = []
            for a, sMultipls in enumerate(ssMultipls3):
                sSum = nodes.createVectorAdditionNode(sMultipls, sName='generatePositionF_%s_vtx%d' % (sMesh,iId))
                if bConnectEnvelopes:
                    sSum = nodes.createBlendNode('%s.envelope' % sBlendShape, sSum, sMultipls[0], bVector=True, # aDefaultPoint[iId] seems wrong!!
                                                                    sName='generatePositionG_%s_vtx%d' % (sMesh,iId))
                sThreeSums.append(sSum)

            ssBlendShapeThreeSums.append(sThreeSums)

        # connect them back
        for t, sT in enumerate(sTargets):
            if sConnections[t] != sAttrs[t]:
                nodes._connectOrSet(sConnections[t], sAttrs[t])

    report.report.refreshIcon()
    sLocs = []
    fLocatorSize = xforms.getAverageJointRadius()
    for l in aIdsOrder:
        sLocatorName = utils.getUniqueName('loc_%sPosition_%03d' % (sMesh, aIds[aIdsOrder[l]]))
        sLocator = cmds.spaceLocator(n=sLocatorName)[0]
        cmds.setAttr('%s.localScale' % sLocator, fLocatorSize, fLocatorSize, fLocatorSize)
        sLocs.append(sLocator)



    if not sDeformers:
        for i, iInd in enumerate(aIdsOrder):
            sThreeSums = ssBlendShapeThreeSums[i]
            if len(sThreeSums) == 1:
                nodes._connectOrSetVector(sThreeSums[0], '%s.t' % sLocs[i])
            else: # length = 3
                pointAndAimConstraint(sLocs[i], sThreeSums[0], sThreeSums[1], sThreeSums[2], sParent=sParent)

    else: #bDoSkinCluster:
        ssDeformerResults = [[] for _ in range(len(aIdsOrder))]
        for i, iInd in enumerate(aIdsOrder):
            for a, sSum in enumerate(ssBlendShapeThreeSums[i]): # 1 or 3
                ssDeformerResults[i].append(nodes.createComposeMatrixNode(sSum, sName='generatePositionA_%s_%d_vtx%d' % (sMesh, a, aUniqueIds[iInd])))

        if sDeformers:

            aUniqueIds3 = np.unique(iIds3)
            aIdsOrder3 = utils.findOneArrayInAnother(aUniqueIds3, iIds3).reshape(-1,3)
            pMesh3 = patch.patchFromName(sMesh)
            pMesh3.aIds = aUniqueIds3

            if bCurve:
                sCurveJoints = []
                for i, iInds3 in enumerate(aIdsOrder3):
                    if not (i % 5):
                        report.report.refreshIcon()

                    for a, sDeformerResult in enumerate(ssDeformerResults[i]):  # 1 or 3 times
                        iInd = iInds3[a]
                        iId = aUniqueIds3[iInd]
                        sJ = cmds.createNode('joint', n='%s_curveJoint_%03d' % (sMesh, iId))
                        cmds.setAttr('%s.radius' % sJ, fAverageJointRadius)
                        nodes.createDecomposeMatrix(sDeformerResult, sTargetPos='%s.t' % sJ, sName='point_%s_' % ['a','b','c'][a])
                        sCurveJoints.append(sJ)
                fPositions = [cmds.getAttr('%s.t' % sJ)[0] for sJ in sCurveJoints]
                sCurve = cmds.curve(p=fPositions, d=1, n=utils.getUniqueName('curve_%s_attach' % sMesh))
                curves.fixShapeName(sCurve)
                cmds.skinCluster(sCurve, sCurveJoints, tsb=True) #blendShape skinCluster
                cmds.parent(sCurve, sCurveJoints, sParent)

                for sDeformer in sDeformers:
                    if cmds.objectType(sDeformer) == 'skinCluster':
                        sNewSkinCluster = weights.transferSkinCluster([patch.patchFromName(sCurve)], sFrom=sDeformer, bCreateNewSkinCluster=True,
                                                                      iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster, _bSkipDeformerAdjustLogging=True)[0]
                        cmds.connectAttr('%s.envelope' % sDeformer, '%s.envelope' % sNewSkinCluster)
                    elif cmds.objectType(sDeformer) == 'ffd':
                        sNewLattice = deformers.transferLattice(sDeformer, sCurve)
                        cmds.connectAttr('%s.envelope' % sDeformer, '%s.envelope' % sNewLattice)

                fParams = curves.getParamsFromPoints(sCurve, fPositions)
                j = 0
                for i, iInds3 in enumerate(aIdsOrder3):
                    if not (i % 5):
                        report.report.refreshIcon()
                    for a, sDeformerResult in enumerate(ssDeformerResults[i]):  # 1 or 3 times
                        iInd = iInds3[a]
                        iId = aUniqueIds3[iInd]
                        _, sPointOnCurve = curves.createPointInfoNode(sCurve, fParam=fParams[j])
                        ssDeformerResults[i][a] = nodes.createComposeMatrixNode(sPointOnCurve)
                        j += 1
            else: # only skinClusters and transform/joint
                for sSkinCluster in sDeformers:
                    print ('=========================== sSkincluster: ', sSkinCluster)
                    if isinstance(sSkinCluster, (list,tuple)):
                        sGotSkinCluster, sInfluences, aWeights2d3 = None, [sSkinCluster[i]], np.array([1.0], dtype='float64').reshape(1,1)
                    else: # skinCluster
                        sGotSkinCluster, sInfluences, aWeights2d3 = pMesh3.getSkinCluster(sChooseSkinCluster=sSkinCluster)
                        if sGotSkinCluster == None:
                            raise Exception('skinCluster %s is not on %s' % (sSkinCluster, sMesh))
                        
                        sRevEnvelope = nodes.createReverseNode('%s.envelope' % sSkinCluster)
                    aInfluences = np.array(sInfluences)
                    for i, iInds3 in enumerate(aIdsOrder3):
                        if not (i % 5):
                            report.report.refreshIcon()

                        for a, sDeformerResult in enumerate(ssDeformerResults[i]): # 1 or 3 times
                            iInd = iInds3[a]
                            iId = aUniqueIds3[iInd]

                            if sGotSkinCluster:
                                aIdWeights = aWeights2d3[iInd] # index 3 is out of bounds for axis 0 with size 1
                                aNonZero = np.where(aIdWeights > fInfluenceWeightLimit)[0]
                                aInfs = aInfluences[aNonZero]
                                aWeights = aIdWeights[aNonZero]
                                aWeights /= np.sum(aWeights)
                            else:
                                aInfs = [sSkinCluster[i]]
                                
                            sMultipls = []
                            sMatrix = str(sDeformerResult)
                            
                            for sInf in aInfs:
                                if isinstance(sSkinCluster, (list,tuple)):
                                    sInverseMatrix = list(np.linalg.inv(utils.getNumpyMatrixFromTransform(sSkinCluster[i])).flatten())
                                else: # sSkinCluster
                                    sConns = cmds.listConnections('%s.worldMatrix' % sInf, t='skinCluster', p=True) or []
                                    sPlugs = [sC for sC in sConns if sC.split('.')[0] == sGotSkinCluster]
                                    sPlug = sPlugs[0]
                                    iPlugIndex = int(sPlug.split('[')[-1].split(']')[0])
                                    sBindPreMatrixAttr = '%s.bindPreMatrix[%d]' % (sGotSkinCluster, iPlugIndex)
                                    sInverseMatrix = cmds.listConnections(sBindPreMatrixAttr, s=True, d=False, p=True)
                                    if sInverseMatrix:
                                        sInverseMatrix = sInverseMatrix[0]
                                        if funcConvertPlugName:
                                            sInverseMatrix = funcConvertPlugName(sInverseMatrix)
                                            if not cmds.objExists(sInverseMatrix):
                                                raise Exception('inverse matrix %s doesn\'t exist' % sInverseMatrix)
                                    else:
                                        sInverseMatrix = cmds.getAttr(sBindPreMatrixAttr)

                                sInfMatrix = '%s.worldMatrix' % sInf
                                if funcConvertPlugName:
                                    sNewInfMatrix = funcConvertPlugName(sInfMatrix)
                                    if not cmds.objExists(sNewInfMatrix):
                                        raise Exception('joint matrix %s doesn\'t exist (taken from %s)' % (sNewInfMatrix, sInfMatrix))
                                    sInfMatrix = sNewInfMatrix

                                sMultipls.append(nodes.createMultMatrixNode([sMatrix,
                                                                             sInverseMatrix,
                                                                             sInfMatrix],
                                                 sName='generatePositionB_%s_multiplyOffset_to_%s_vtx%d' % (sMesh, sInfMatrix.split('.')[0], iId)))

                            if sGotSkinCluster:
                                sNewResult = nodes.createBlendMatrixNode(sMultipls, aWeights, sName='generatePositionC_%s_vtx%d' % (sMesh, iId))
                            else:
                                sNewResult = sMultipls[0]
                            
                            if sGotSkinCluster and bConnectEnvelopes:
                                ssDeformerResults[i][a] = nodes.createBlendMatrixNode([sNewResult, ssDeformerResults[i][a]],
                                                                                        ['%s.envelope' % sSkinCluster, sRevEnvelope],
                                                                                        sName='blendEnvelope_%s_vtx%d' % (sMesh, iId))
                            else:
                                ssDeformerResults[i][a] = sNewResult

        report.report.refreshIcon()

        for i, iInd in enumerate(aIdsOrder):
            sDecompose = nodes.createDecomposeMatrix(ssDeformerResults[i][0], sName='generatePositionD_%s_vtx%d' % (sMesh, iId))
            if len(ssDeformerResults[i]) == 1:
                cmds.connectAttr(sDecompose, '%s.t' % sLocs[i])
                cmds.connectAttr('%s.outputRotate' % sDecompose.split('.')[0], '%s.r' % sLocs[i])

            if len(ssDeformerResults[i]) > 1:
                sDecomposeAim = nodes.createDecomposeMatrix(ssDeformerResults[i][1], sName='generateAim_%s_vtx%d' % (sMesh, iId))
                sDecomposeUp = nodes.createDecomposeMatrix(ssDeformerResults[i][2], sName='generateUp_%s_vtx%d' % (sMesh, iId))
                pointAndAimConstraint(sLocs[i], sDecompose, sDecomposeAim, sDecomposeUp, sParent=sParent)
            if sScaleAttr:
                cmds.connectAttr(sScaleAttr, '%s.s' % sLocs[i])

    if sParent != None:
        cmds.parent(sLocs, sParent)
    return sLocs

dRecordedBlendShapesPoints = {}
dRecordedTargets = {}
dRecordedTargetConnections = {}

# do to:
# 1) blendShape inbetweens - the code is there, but must be cleaned up on next version with inbetweens
# 2) bring back the bConnectEnvelopes
def parallelTransformAsDeformers2(sMesh, iIds, fInfluenceWeightLimit=0.01, fTargetMinimumDistance=0.001, sParent=None,
                                 sDeformers=[], funcConvertPlugName=None, sScaleJoint=None, ssIgnoreTargets=[], sIgnoreTargetsAll=[], bRotateByNeighborVerts=[], bParentIsNotOrigin=False):

    if bRotateByNeighborVerts == True:
        bRotateByNeighborVerts = [True for _ in range(len(iIds))]
    elif bRotateByNeighborVerts == False:
        bRotateByNeighborVerts = [False for _ in range(len(iIds))]


    sScaleAttr = None
    if sScaleJoint:
        sScaleAttr = nodes.getScaleFromXform(sScaleJoint)


    report.report.refreshIcon(True)
    for sDeformer in sDeformers:
        if not isinstance(sDeformer, (list,tuple)) and (not cmds.objExists(sDeformer) or cmds.objectType(sDeformer) not in ['skinCluster', 'ffd', 'blendShape']):
            raise Exception('SkinCluster/Lattice %s doesn\'t exist' % sDeformer)


    pMesh = patch.patchFromName(sMesh)
    aaNbs = pMesh.getNeighbors(bExcludeNeighborsNotInIds=False)

    aDefaultPoints = pMesh.getAllPoints()


    # first find ot which needs 2 extra vectors (rotation)
    iiIds3 = []
    for i, iId in enumerate(iIds):
        bVectors = True if i < len(bRotateByNeighborVerts) and bRotateByNeighborVerts[i] else False
        if isinstance(iId, (list,tuple)):
            if len(iId) != 3:
                raise Exception('bad input: %s' % str(iId))
            iiIds3.append(list(iId))
        elif not bVectors:
            iiIds3.append([iId])
        else:
            aNbs = aaNbs[iId]
            if not len(aNbs):
                raise Exception('not finding neighbor vertices from "%s", id %d' % (sMesh, iId))

            xPairInfos = []
            for m in range(0, len(aNbs), 1):
                for n in range(m + 1, len(aNbs), 1):
                    aPointM = aDefaultPoints[aNbs[m]] - aDefaultPoints[iId]
                    aPointN = aDefaultPoints[aNbs[n]] - aDefaultPoints[iId]
                    fLengthM = np.linalg.norm(aPointM)
                    fLengthN = np.linalg.norm(aPointN)
                    aPointM /= fLengthM
                    aPointN /= fLengthN
                    fDot = np.dot(aPointM, aPointN)
                    xPairInfos.append([[aNbs[m], aNbs[n]], fDot, fLengthM, fLengthN])

            xPairInfos.sort(key=lambda x: min(x[2], x[3]), reverse=True)
            if len(xPairInfos) > 2:
                xPairInfos = xPairInfos[:max(len(xPairInfos) // 2, 2)]
            xPairInfos.sort(key=lambda x: abs(x[1]))
            iBestVector = xPairInfos[0][0]
            if xPairInfos[0][2] < xPairInfos[0][3]:
                iBestVector[0], iBestVector[1] = iBestVector[1], iBestVector[0]
            iiIds3.append([iId, iBestVector[0], iBestVector[1]])

    


    aUniqueIds = np.unique(np.array(utils.flattenedList(iiIds3), dtype=int))
    aaIdsFind = [utils.findOneArrayInAnother(aUniqueIds, x) for x in iiIds3]
    if -1 in utils.flattenedList(aaIdsFind):
        raise Exception('there are issues with iIds array: %s' % str(iIds))

    pMesh3 = patch.patchFromName(sMesh)
    pMesh3.aIds = aUniqueIds

    ssBlendShapePoints3 = [[] for _ in range(len(iiIds3))]
    ssMatrices3 = [[] for _ in range(len(iiIds3))]
    
    for i, iIds3 in enumerate(iiIds3):
        for a, iId in enumerate(iIds3):  # 1 or 3 times
            ssMatrices3[i].append(list(utils.matrixFromPos(aDefaultPoints[iId])))
            ssBlendShapePoints3[i].append(aDefaultPoints[iId])
    

    for d,sDef in enumerate(sDeformers):
        
        if isinstance(sDef, (list,tuple)): # a list of transforms, possibly Passers
            # sGotSkinCluster, sInfluences, aWeights2d3 = None, [sDef[i]], np.array([1.0], dtype='float64').reshape(1,1)
            for i, iIds3 in enumerate(iiIds3):
                for a, iId in enumerate(iIds3):  # 1 or 3 times
                    sInverseMatrix = list(np.linalg.inv(utils.getNumpyMatrixFromTransform(sDef[i])).flatten())
                    sInfMatrix = '%s.worldMatrix' % sDef[i]

                    ssMatrices3[i][a] = nodes.createMultMatrixNode([ssMatrices3[i][a],
                                                                 sInverseMatrix,
                                                                 sInfMatrix], sName='Passer_%s_FINAL_FromTransform' % (sDef[i]))
        
        elif cmds.objectType(sDef) == 'blendShape':
            if d != 0:
                raise Exception('blendShape can only be the first deformer')
            
            if sDef in dRecordedTargets:
                sTargets = dRecordedTargets[sDef]
                aaTargetPoints = dRecordedBlendShapesPoints[sDef]
                sConnections = dRecordedTargetConnections[sDef]
            else:
                dTargets = deformers.getTargetsDictFromBlendShape(sDef, bPerTargetNames=True)
                sTargets = sorted(list(set(dTargets.keys()) - set(sIgnoreTargetsAll)))

                # disconnect all the blendShapes first
                sAttrs = ['%s.%s' % (sDef, sT) for sT in sTargets]
                sConnections = []
                for t, sT in enumerate(sTargets):
                    sConns = cmds.listConnections(sAttrs[t], s=True, d=False, p=True)
                    if not sConns:
                        sConnections.append(cmds.getAttr(sAttrs[t]))
                    else:
                        sDriver = sConns[0]
                        sConnections.append(sDriver)
                        cmds.disconnectAttr(sDriver, sAttrs[t])
                        utils.addStringAttr(sDriver.split('.')[0], 'sTarget', sT)
                    cmds.setAttr(sAttrs[t], 0)
        
        
                # now that we got all the blendShapes disconnected, go throgh them and record
                aaTargetPoints = []
                dInbetweenPoints = {}
                for t, sT in enumerate(sTargets):
                    cmds.setAttr(sAttrs[t], 1.0)
                    aaTargetPoints.append(pMesh.getAllPoints())
            
                    fInbetweens = deformers.getInbetweens(sDef, iTargetIndex=dTargets[sT])
                    dInbetweenPoints[sT] = []
                    for fWeight in fInbetweens:
                        cmds.setAttr(sAttrs[t], fWeight)
                        dInbetweenPoints[sT].append([fWeight, pMesh.getPoints()])
            
                    cmds.setAttr(sAttrs[t], 0.0)

                # connect back the previos blendShape connections - needs to handle the non connections, too
                for t, sT in enumerate(sTargets):
                    # if isinstance(sConnections[t], str):
                    nodes._connectOrSet(sConnections[t], sAttrs[t])

                dRecordedTargets[sDef] = sTargets
                dRecordedBlendShapesPoints[sDef] = aaTargetPoints
                dRecordedTargetConnections[sDef] = sConnections

            # do the magic
            for i, iIds3 in enumerate(iiIds3):
                for a, iId in enumerate(iIds3):  # 1 or 3 times

                    sMultipls = [aDefaultPoints[iId]]
                    
                    for t, sT in enumerate(sTargets):
                        bIgnoreThisTarget = False
                        if i < len(ssIgnoreTargets):
                            for sIgnoreT in ssIgnoreTargets[i]:
                                sIgnoreT = sIgnoreT.split('.')[-1]
                                if sT == sIgnoreT:
                                    bIgnoreThisTarget = True
                                    break
                        if bIgnoreThisTarget:
                            continue
        
                        aChangeVector = aaTargetPoints[t][iId] - aDefaultPoints[iId]
                        if np.linalg.norm(aChangeVector) >= fTargetMinimumDistance:
                            if True: #not dInbetweenPoints[sT]:
                                sMultipls.append(
                                    nodes.createVectorMultiplyNode(aChangeVector, sConnections[t], bVectorByScalar=True,
                                                                   sName='%s_%s_vtx%d' % (sDef, sT, iId)))
                            else:
                                fWeights = []
                                fTargets = []
                                for fW, aTargets in dInbetweenPoints[sT]:
                                    fWeights.append(fW)
                                    fTargets.append(aTargets[i] - aDefaultPoints[iId])
                                fWeights = [0.0] + fWeights + [1.0]
                                fTargets = [[0.0, 0.0, 0.0]] + [list(fT) for fT in fTargets] + [list(aChangeVector)]
                                sDrivenKeys = [
                                    nodes.setDrivenKey(sConnections[t], fWeights, None, [fT[a] for fT in fTargets],
                                                       sInTanType='linear', sOutTanType='linear') for a in [0, 1, 2]]
                                sMultipls.append(sDrivenKeys)
        

                    # now set the matrix
                    sFinalBlendShapedPoint = nodes.createVectorAdditionNode(sMultipls, sName='%s_sum_vtx%d' % (sDef, iId))
                    ssMatrices3[i][a] = nodes.createComposeMatrixNode(xTranslate=sFinalBlendShapedPoint, sName='%s_FINAL_vtx%d' % (sDef, iId))
    
            
        elif cmds.objectType(sDef) == 'ffd':
            sLattice = cmds.listConnections('%s.deformedLatticeMatrix' % sDef, s=True, d=False)[0]
            sLatticeBaseBox = cmds.listConnections('%s.baseLatticeMatrix' % sDef, s=True, d=False)[0]
            pLatticeBox = patch.patchFromName(sLattice)
            sLatticeParent = '%s_locatorParent' % sLattice

            aLatticeWeights = pMesh3.getMapValues('%s.weightList[0].weights' % sDef)
            
            if not cmds.objExists(sLatticeParent):
                sLatticeParents = cmds.listRelatives(sLattice, p=True)
                if not sLatticeParents:
                    raise Exception('there seems to be a lattice deformer without a proper lattice box ("%s")' % sDef)
                cmds.createNode('transform', n=sLatticeParent, p=sLatticeParents[0])
                
                sLatticeDeformers = deformers.listAllDeformers(sLattice, sFilterTypes=['skinCluster'])
                if sLatticeDeformers:
                    sCorners = parallelTransformAsDeformers2(sLattice, range(pLatticeBox.getTotalCount()), sDeformers=sLatticeDeformers, sParent=sLatticeParent, bParentIsNotOrigin=True)
                else:
                    raise Exception('Lattice "%s" is not deformed' % sLatticeDeformers)
                    
            else:
                sCorners = sorted(cmds.listRelatives(sLatticeParent, c=True))

            aaDefaultMatrix = utils.getNumpyMatrixFromTransform(sLattice)
            aScale = np.linalg.norm(aaDefaultMatrix[0:3][0:3], axis=-1)
            aaDefaultMatrix[0:3][0:3] /= aScale[:, np.newaxis]
            aaDefaultMatrixInv = np.linalg.inv(aaDefaultMatrix)
            sGlobalBaseCornerMatrix = nodes.createMultMatrixNode(
                [nodes.createComposeMatrixNode(xTranslate=[-0.5, -0.5, -0.5], xScale=1.0 / aScale),
                 '%s.worldMatrix' % sLatticeBaseBox])

            iDims = pLatticeBox.getDimensions(bNumpy=True)
            aaaIdsMapper = pLatticeBox.getIdsMapper()
            for iZ in range(iDims[2]-1):
                for iY in range(iDims[1]-1):
                    for iX in range(iDims[0]-1):
                        
                        aStart4 = utils.makePoint4(np.array(cmds.xform(sCorners[aaaIdsMapper[iX,iY,iZ]], q=True, ws=True, t=True), dtype='float64'))
                        aEnd4 = utils.makePoint4(np.array(cmds.xform(sCorners[aaaIdsMapper[iX+1,iY+1,iZ+1]], q=True, ws=True, t=True), dtype='float64'))
                        aOrigLocal4 = np.dot(aStart4, aaDefaultMatrixInv)
                        aEndLocal4 = np.dot(aEnd4, aaDefaultMatrixInv)
                        aScale4 = aEndLocal4 - aOrigLocal4
                        
                        if False: # visualize cubes
                            aCenterLocal4 = (aOrigLocal4 + aEndLocal4) * 0.5
                            aCenter4 = np.dot(aCenterLocal4, aaDefaultMatrix)
                            sCube = cmds.polyCube()[0]
                            aaCubeMatrix = np.copy(aaDefaultMatrix)
                            aaCubeMatrix[0:3][0:3] *= aScale4[0:3,np.newaxis]
                            aaCubeMatrix[3,0:3] = aCenter4[0:3]
                            cmds.xform(sCube, m=list(aaCubeMatrix.flatten()))
                        
                        aaCubeMatrix = np.copy(aaDefaultMatrix)
                        aaCubeMatrix[3,0:3] = aStart4[0:3]
                        aaInvCubeMatrix = np.linalg.inv(aaCubeMatrix)
                        
                        sBaseCornerMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xTranslate=[aScale[0] * (iX/(iDims[0]-1)),
                                                                                                                  aScale[1] * (iY/(iDims[1]-1)),
                                                                                                                  aScale[2] * (iZ/(iDims[2]-1))]), sGlobalBaseCornerMatrix])
                        sBaseCornerInvMatrix = nodes.createInverseMatrix(sBaseCornerMatrix)
                        
                        if False: #visualize locs
                            sBaseCornerLoc = cmds.spaceLocator(n='cornerLoc_')[0]
                            nodes.createDecomposeMatrix(sBaseCornerMatrix, sTargetPos='%s.t' % sBaseCornerLoc, sTargetRot='%s.r' % sBaseCornerLoc, sTargetScale='%s.s' % sBaseCornerLoc)
                        
                        aEachScale = aScale / (iDims-1)

                        for i, iIds3 in enumerate(iiIds3):
                            for a, iId in enumerate(iIds3):  # 1 or 3 times
                                iInd = aaIdsFind[i][a]
    
                                fWeight = aLatticeWeights[iInd]
                                
                                if fWeight < 0.001:
                                    continue

                                # the following block changed later. It used to do cmds.getAttr(ssMatrices3[i][a], but caused issues because in rare cases it was a list.....
                                xMatrix = ssMatrices3[i][a]
                                fMatrix = cmds.getAttr(xMatrix) if isinstance(xMatrix, str) else xMatrix
                                aMatrixPoint4 = fMatrix[12:16]


                                sMatrixPoint = nodes.createDecomposeMatrix(ssMatrices3[i][a])
                                aLocalMatrixPoint4 = np.dot(aMatrixPoint4, aaInvCubeMatrix)
                                
                                if (iX == 0 or aLocalMatrixPoint4[0] > 0.0) and (iX == iDims[0]-2 or aLocalMatrixPoint4[0] <= aScale4[0]) and \
                                   (iY == 0 or aLocalMatrixPoint4[1] > 0.0) and (iY == iDims[1]-2 or aLocalMatrixPoint4[1] <= aScale4[1]) and \
                                   (iZ == 0 or aLocalMatrixPoint4[2] > 0.0) and (iZ == iDims[2]-2 or aLocalMatrixPoint4[2] <= aScale4[2]):
                                    sPointInCornerMatrix = nodes.createPointByMatrixNode(sMatrixPoint, sBaseCornerInvMatrix)
                                    sNormalizedValues = nodes.createVectorMultiplyNode(sPointInCornerMatrix, aEachScale, sOperation='divide')
                                    
                                    sA0 = nodes.createBlendNode('%sY' % sNormalizedValues, nodes.getWorldPoint(sCorners[aaaIdsMapper[iX,iY+1,iZ]]),
                                                                nodes.getWorldPoint(sCorners[aaaIdsMapper[iX,iY,iZ]]), bVector=True, bInfinity=True, sName='%s_A0_' % sDef)
                                    sA1 = nodes.createBlendNode('%sY' % sNormalizedValues, nodes.getWorldPoint(sCorners[aaaIdsMapper[iX+1,iY+1,iZ]]),
                                                                nodes.getWorldPoint(sCorners[aaaIdsMapper[iX+1,iY,iZ]]), bVector=True, bInfinity=True, sName='%s_A1_' % sDef)
                                    sB0 = nodes.createBlendNode('%sY' % sNormalizedValues, nodes.getWorldPoint(sCorners[aaaIdsMapper[iX,iY+1,iZ+1]]),
                                                                nodes.getWorldPoint(sCorners[aaaIdsMapper[iX,iY,iZ+1]]), bVector=True, bInfinity=True, sName='%s_B0_' % sDef)
                                    sB1 = nodes.createBlendNode('%sY' % sNormalizedValues, nodes.getWorldPoint(sCorners[aaaIdsMapper[iX+1,iY+1,iZ+1]]),
                                                                nodes.getWorldPoint(sCorners[aaaIdsMapper[iX+1,iY,iZ+1]]), bVector=True, bInfinity=True, sName='%s_B1_' % sDef)
                                    
                                    sC0 = nodes.createBlendNode('%sX' % sNormalizedValues, sA1, sA0, bVector=True, sName='%s_C0_' % sDef, bInfinity=True)
                                    sC1 = nodes.createBlendNode('%sX' % sNormalizedValues, sB1, sB0, bVector=True, sName='%s_C1_' % sDef, bInfinity=True)
                                    
                                    sResult = nodes.createBlendNode('%sZ' % sNormalizedValues, sC1, sC0, bVector=True, sName='%s_Final_' % sDef, bInfinity=True)
                                    
                                    sPreviousDecompose = nodes.createDecomposeMatrix(ssMatrices3[i][a])
                                    if fWeight < 0.97:
                                        sResult = nodes.createBlendNode(fWeight, sResult, sPreviousDecompose, bVector=True, sName='%s_Weight_' % sDef)
                                    
                                    ssMatrices3[i][a] = nodes.createComposeMatrixNode(xTranslate=sResult,
                                                                                     xRotate='%s.outputRotate' % sPreviousDecompose.split('.')[0], sName='%s_FINAL' % sDef)



        elif cmds.objectType(sDef) == 'skinCluster': # skinCluster
            sGotSkinCluster, sInfluences, aWeights2d3 = pMesh3.getSkinCluster(sChooseSkinCluster=sDef)
            if sGotSkinCluster == None:
                raise Exception('skinCluster %s is not on %s' % (sDef, sMesh))
            
        
        
            aInfluences = np.array(sInfluences)
            for i, iIds3 in enumerate(iiIds3):
                for a, iId in enumerate(iIds3):  # 1 or 3 times
    
                    iInd = aaIdsFind[i][a]
                    aIdWeights = aWeights2d3[iInd] # index 3 is out of bounds for axis 0 with size 1
                    aNonZero = np.where(aIdWeights > fInfluenceWeightLimit)[0]
                    aNonZeroInfs = aInfluences[aNonZero]
                    aNonZeroWeights = aIdWeights[aNonZero]
                    aNonZeroWeights /= np.sum(aNonZeroWeights)
                    
                    sMultipls = []
                    
                    for sInf in aNonZeroInfs:
                        sConns = cmds.listConnections('%s.worldMatrix' % sInf, t='skinCluster', p=True) or []
                        sPlugs = [sC for sC in sConns if sC.split('.')[0] == sGotSkinCluster]
                        sPlug = sPlugs[0]
                        iPlugIndex = int(sPlug.split('[')[-1].split(']')[0])
                        sBindPreMatrixAttr = '%s.bindPreMatrix[%d]' % (sGotSkinCluster, iPlugIndex)
                        sInverseMatrix = cmds.listConnections(sBindPreMatrixAttr, s=True, d=False, p=True)
                        if sInverseMatrix:
                            sInverseMatrix = sInverseMatrix[0]
                            if funcConvertPlugName:
                                sInverseMatrix = funcConvertPlugName(sInverseMatrix)
                                if not cmds.objExists(sInverseMatrix):
                                    raise Exception('inverse matrix %s doesn\'t exist' % sInverseMatrix)
                        else:
                            sInverseMatrix = cmds.getAttr(sBindPreMatrixAttr)

                        sInfMatrix = '%s.worldMatrix' % sInf
                        if funcConvertPlugName:
                            sNewInfMatrix = funcConvertPlugName(sInfMatrix)
                            if not cmds.objExists(sNewInfMatrix):
                                raise Exception('joint matrix %s doesn\'t exist (taken from %s)' % (sNewInfMatrix, sInfMatrix))
                            sInfMatrix = sNewInfMatrix

                        sMultipls.append(nodes.createMultMatrixNode([ssMatrices3[i][a],
                                                                     sInverseMatrix,
                                                                     sInfMatrix],
                                         sName='%s_generatePositionB_multiplyOffset_to_%s_vtx%d' % (sDef, sInfMatrix.split('.')[0], iId)))

                    if len(sMultipls) > 1:
                        sNewResult = nodes.createBlendMatrixNode(sMultipls, aNonZeroWeights, sName='%s_FINAL_vtx%d' % (sDef, iId))
                    else:
                        sNewResult = sMultipls[0]
                        
                    ssMatrices3[i][a] = sNewResult




    # now that we have ssMatrices3 made from all deformers let's pass them to locators
    sLocs = []
    fLocatorSize = xforms.getAverageJointRadius()

    report.report.refreshIcon()
    for i, iIds3 in enumerate(iiIds3):
        sLocator = xforms.createLocator('loc_%sPosition_%03d_' % (sMesh, iIds3[0]), fSize=fLocatorSize)
        sLocs.append(sLocator)

        sResultMatrix0 = ssMatrices3[i][0]
        if bParentIsNotOrigin:
            sResultMatrix0 = nodes.createMultMatrixNode([sResultMatrix0, cmds.getAttr('%s.worldInverseMatrix' % sParent)])


        if len(ssMatrices3[i]) == 1:
            sDecompose = nodes.createDecomposeMatrix(sResultMatrix0, sName='generatePositionD_%s_vtx%d' % (sMesh, iId))
            cmds.connectAttr(sDecompose, '%s.t' % sLocs[i])
            cmds.connectAttr('%s.outputRotate' % sDecompose.split('.')[0], '%s.r' % sLocs[i])

        elif len(ssMatrices3[i]) == 3:
            sResultMatrix1 = ssMatrices3[i][1]
            if bParentIsNotOrigin:
                sResultMatrix1 = nodes.createMultMatrixNode([sResultMatrix1, cmds.getAttr('%s.worldInverseMatrix' % sParent)])
            sResultMatrix2 = ssMatrices3[i][2]
            if bParentIsNotOrigin:
                sResultMatrix2 = nodes.createMultMatrixNode([sResultMatrix2, cmds.getAttr('%s.worldInverseMatrix' % sParent)])

            sDecomposeAim = nodes.createDecomposeMatrix(sResultMatrix1, sName='generateAim_%s_vtx%d' % (sMesh, iId))
            sDecomposeUp = nodes.createDecomposeMatrix(sResultMatrix2, sName='generateUp_%s_vtx%d' % (sMesh, iId))
            # pointAndAimConstraint(sLocs[i], sDecompose, sDecomposeAim, sDecomposeUp, sParent=sParent)
            sAimMatrix = nodes.createAimMatrixNode(sResultMatrix0, sDecomposeAim, sDecomposeUp, bAlignUp=False)
            nodes.createDecomposeMatrix(sAimMatrix, sTargetPos='%s.t' % sLocs[i], sTargetRot='%s.r' % sLocs[i])
        if sScaleAttr:
            cmds.connectAttr(sScaleAttr, '%s.s' % sLocs[i])

    if sParent != None:
        cmds.parent(sLocs, sParent)
    return sLocs




def pointAndAimConstraint(sTransform, sPointPos, sPointAim, sPointUp, aim=[1,0,0], up=[0,1,0], sParent=None):
    '''
    sPointPos, sPointAim, sPointUp are transforms in same space as sTransform
    '''
    if not sParent:
        sParent = sTransform
    sAimConstraint = cmds.createNode('aimConstraint', n='aimConstraint_%s' % sTransform, p=sParent)

    nodes._connectOrSetVector(sPointPos, '%s.t' % sTransform)
    nodes._connectOrSetVector(sPointPos, '%s.constraintRotateTranslate' % sAimConstraint)
    nodes._connectOrSetVector(sPointAim, '%s.target[0].targetTranslate' % sAimConstraint)
    nodes.createVectorAdditionNode([sPointUp, sPointPos], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)
    cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
    cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sTransform)
    nodes._connectOrSetVector(aim, '%s.aimVector' % sAimConstraint)
    nodes._connectOrSetVector(up, '%s.upVector' % sAimConstraint)

    return sAimConstraint




def aimConstraintFromTransforms(sTransform, sAim, sUp=None, aim=[1,0,0], up=[0,1,0], fOrientAxis=[0,1,0],
                         bOrientUp=False, sParent=None, sName=None, mo=False, bUpIsLocal=False, bAimIsLocal=False):
    '''
    sTransform, sAim and sUp are transforms/joints
    '''

    sAimConstraint = cmds.createNode('aimConstraint',
                                     n='aimConstraint_%s' % sTransform if utils.isNone(sName) else sName,
                                     p=sParent)

    if mo:
        fMatrix = cmds.xform(sTransform, q=True, ws=True, m=True)

    if bAimIsLocal:
        cmds.connectAttr('%s.t' % sAim, '%s.target[0].targetTranslate' % sAimConstraint)
    else:
        sPointAim = nodes.getWorldPoint(sAim)
        nodes.createPointByMatrixNode(sPointAim, '%s.parentInverseMatrix' % sTransform, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

    if sUp != None:
        cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
        if bOrientUp:
            if bUpIsLocal:
                cmds.connectAttr('%s.worldMatrix' % sUp, '%s.worldUpMatrix' % sAimConstraint)
            else:
                nodes.createMultMatrixNode(['%s.worldMatrix' % sUp, '%s.parentInverseMatrix' % sTransform], sTarget='%s.worldUpMatrix' % sAimConstraint)
            cmds.setAttr('%s.worldUpVector' % sAimConstraint, *fOrientAxis)
        else:
            if bUpIsLocal:
                sPointUpLocal = '%s.t' % sUp
            else:
                sPointUp = nodes.getWorldPoint(sUp)
                sPointUpLocal = nodes.createPointByMatrixNode(sPointUp, '%s.parentInverseMatrix' % sTransform)
            nodes.createVectorAdditionNode([sPointUpLocal, '%s.t' % sTransform], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)

    cmds.connectAttr('%s.t' % sTransform, '%s.constraintRotateTranslate' % sAimConstraint)

    if cmds.objectType(sTransform) == 'joint':
        cmds.connectAttr('%s.jo' % sTransform, '%s.constraintJointOrient' % sAimConstraint)
    cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sTransform)
    nodes._connectOrSetVector(aim, '%s.aimVector' % sAimConstraint)
    nodes._connectOrSetVector(up, '%s.upVector' % sAimConstraint)

    if mo:
        fOffset = nodes.createMultMatrixNode([fMatrix, cmds.getAttr('%s.worldInverseMatrix' % sTransform)], bJustValues=True)
        nodes.createDecomposeMatrix(fOffset, sTargetRot='%s.offset' % sAimConstraint, bJustValues=True)

    return sAimConstraint


def aimConstraintFromLocalPoints(sTransform, sAim, sUp=None, aim=[1,0,0], up=[0,1,0], sParent=None, sName=None, mo=False, sBlend=None):
    '''
    sTransform, sAim and sUp are points
    '''

    sAimConstraint = cmds.createNode('aimConstraint',
                                     n='aimConstraint_%s' % sTransform if utils.isNone(sName) else sName,
                                     p=sParent)

    if mo:
        fMatrix = cmds.xform(sTransform, q=True, ws=True, m=True)

    cmds.connectAttr(sAim, '%s.target[0].targetTranslate' % sAimConstraint)

    if sUp != None:
        cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
        nodes.createVectorAdditionNode([sUp, '%s.t' % sTransform], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)

    cmds.connectAttr('%s.t' % sTransform, '%s.constraintRotateTranslate' % sAimConstraint)

    if cmds.objectType(sTransform) == 'joint':
        cmds.connectAttr('%s.jo' % sTransform, '%s.constraintJointOrient' % sAimConstraint)
        
    sOutputRotate = '%s.constraintRotate' % sAimConstraint
    if sBlend:
        sOutputRotate = nodes.createBlendNode(sBlend, sOutputRotate, cmds.getAttr('%s.r' % sTransform)[0], bVector=True)
    cmds.connectAttr(sOutputRotate, '%s.r' % sTransform)
    nodes._connectOrSetVector(aim, '%s.aimVector' % sAimConstraint)
    nodes._connectOrSetVector(up, '%s.upVector' % sAimConstraint)

    if mo:
        fOffset = nodes.createMultMatrixNode([fMatrix, cmds.getAttr('%s.worldInverseMatrix' % sTransform)], bJustValues=True)
        nodes.createDecomposeMatrix(fOffset, sTargetRot='%s.offset' % sAimConstraint, bJustValues=True)

    return sAimConstraint



def aimConstraintEmpty(sTransform, aim=[1,0,0], up=[0,1,0], sParent=None, sName=None, bConnectJointOrient=True, bDriversAreInWorld=False, bOrientUp=True, bIgnoreConstraintRotateTranslateConnection=False):

    if sParent == None:
        sParent = sTransform

    sAimConstraint = cmds.createNode('aimConstraint',
                                     n='aimConstraint_%s' % sTransform if utils.isNone(sName) else sName,
                                     p=sParent)

    if bDriversAreInWorld:
        cmds.connectAttr('%s.parentInverseMatrix' % sTransform, '%s.constraintParentInverseMatrix' % sAimConstraint)

    if not bIgnoreConstraintRotateTranslateConnection:
        cmds.connectAttr('%s.t' % sTransform, '%s.constraintRotateTranslate' % sAimConstraint)

    if bConnectJointOrient and cmds.objectType(sTransform) == 'joint':
        cmds.connectAttr('%s.jo' % sTransform, '%s.constraintJointOrient' % sAimConstraint)
    cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sTransform)
    nodes._connectOrSetVector(aim, '%s.aimVector' % sAimConstraint)
    nodes._connectOrSetVector(up, '%s.upVector' % sAimConstraint)
    if bOrientUp:
        cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
    else:
        cmds.setAttr('%s.worldUpType' % sAimConstraint, 1)


    return sAimConstraint


# not tested yet!
def aimConstraintNoTransform(sPosition, aim=[1,0,0], up=[0,1,0], sParent=None, sName=None):

    sAimConstraint = cmds.createNode('aimConstraint',
                                     n='aimConstraint' if utils.isNone(sName) else sName,
                                     p=sParent)


    cmds.connectAttr(sPosition, '%s.constraintRotateTranslate' % sAimConstraint)

    nodes._connectOrSetVector(aim, '%s.aimVector' % sAimConstraint)
    nodes._connectOrSetVector(up, '%s.upVector' % sAimConstraint)
    # if bOrientUp:
    cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)


    return '%s.constraintRotate' % sAimConstraint, sAimConstraint



def computeAimOffset(sConstraint, sComputeOffsetToTransform):
    print ('sConstraint: ', sConstraint)
    sAimingTransform = cmds.listConnections('%s.constraintRotate' % sConstraint, '%s.constraintRotateX' % sConstraint, s=False, d=True)[0]
    if isinstance(sComputeOffsetToTransform, (list,tuple,np.ndarray)):
        fComputeOffsetToTransform = list(sComputeOffsetToTransform)
    else:
        fComputeOffsetToTransform = cmds.getAttr('%s.worldMatrix' % sComputeOffsetToTransform)
    fOffsetMatrix = nodes.createMultMatrixNode([fComputeOffsetToTransform,
                                                cmds.getAttr('%s.worldInverseMatrix' % sAimingTransform)], bJustValues=True)
    fValues = nodes.createDecomposeMatrix(fOffsetMatrix, bReturnRotate=True, bJustValues=True) #[0]
    cmds.setAttr('%s.offset' % sConstraint, *fValues)


def addOffsetAttrs(sCtrl, sJoint, sAttrCtrl=None, sAttrSuffix='', bResetCtrlRotations=False):
    sJointCopy = cmds.createNode('joint')
    cmds.xform(sJointCopy, m=cmds.xform(sJoint, q=True, m=True, ws=True), ws=True)
    
    sSkipTranslate = [sA[-1] for sA in ['tx','ty','tz'] if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True)]
    sSkipRotate = [sA[-1] for sA in ['rx','ry','rz'] if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True)]
    sParentConstraint = cmds.parentConstraint(sJointCopy, sCtrl, mo=True, skipTranslate=sSkipTranslate, skipRotate=sSkipRotate)[0]

    fTranslateOffset = cmds.getAttr('%s.target[0].targetOffsetTranslate' % sParentConstraint)[0]
    fRotateOffset = cmds.getAttr('%s.target[0].targetOffsetRotate' % sParentConstraint)[0]

    if sAttrCtrl == None:
        sAttrCtrl = sCtrl
    utils.addStringAttr(sAttrCtrl, 'parentConstraintOffset%s' % sAttrSuffix, [fTranslateOffset, fRotateOffset], bLock=True)
    
    cmds.delete(sParentConstraint)
    cmds.delete(sJointCopy)

    # this is becasue on right side it sometimes adds some bad values
    if bResetCtrlRotations:
        [cmds.setAttr('%s.%s' % (sCtrl,sA), 0.0) for sA in ['rx', 'ry', 'rz'] if cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True)]

    
def addParentOffsetAttrsOldRig(sCtrl, sJoint, sAttrCtrl=None, sRotatePlugs=None):
    sSkipTranslate = [sA[-1] for sA in ['tx','ty','tz'] if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True)]
    sSkipRotate = [sA[-1] for sA in ['rx','ry','rz'] if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True)]
    sParentConstraint = cmds.parentConstraint(sJoint, sCtrl, mo=True, skipTranslate=sSkipTranslate, skipRotate=sSkipRotate)[0]
    
    fTranslateOffset = cmds.getAttr('%s.target[0].targetOffsetTranslate' % sParentConstraint)[0]
    fRotateOffset = cmds.getAttr('%s.target[0].targetOffsetRotate' % sParentConstraint)[0]
    
    if sAttrCtrl == None:
        sAttrCtrl = sCtrl
    utils.addStringAttr(sAttrCtrl, 'parentConstraintOffsetOldRig', [sJoint.split(':')[-1], fTranslateOffset, fRotateOffset, sSkipTranslate, sSkipRotate, sRotatePlugs], bLock=True)
    
    cmds.delete(sParentConstraint)
    
    
def addAimOffsetAttrsOldRig(sCtrl, sJoint, fAim, fUp, fWorldUp):
    sAimConstraint = cmds.aimConstraint(sJoint, sCtrl, mo=True, wut='objectrotation', wuo=cmds.listRelatives(sCtrl, p=True)[0], aim=fAim, u=fUp, wu=fWorldUp)[0]
    
    fRotateOffset = cmds.getAttr('%s.offset' % sAimConstraint)[0]
    
    utils.addStringAttr(sCtrl, 'aimConstraintOffsetOldRig', [sJoint.split(':')[-1], fRotateOffset, fAim, fUp, fWorldUp], bLock=True)
    
    cmds.delete(sAimConstraint)
    
    
def createLiveOffsetAttr(sCtrl, sJoint):
    sOffsetTransform = cmds.createNode('transform', p='modules', n='liveMatchingOffset2_%s' % sJoint)
    xforms.matrixParentConstraint(sJoint, sOffsetTransform)
    utils.addStringAttr(sCtrl, 'liveOffset', sOffsetTransform, bLock=True)

