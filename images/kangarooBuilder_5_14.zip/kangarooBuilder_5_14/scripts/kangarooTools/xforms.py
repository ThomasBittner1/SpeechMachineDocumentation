###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import numpy as np
import kangarooTools.nodes as nodes
from collections import defaultdict
import kangarooTools.barycentric as barycentric
import kangarooTools.curves as curves
import kangarooTools.patch as patch
import kangarooTools.topology as topology
from collections import Counter

iSwapRotateOrders = [5, 3, 4, 1, 2, 0]
sRotateOrders = ['xyz', 'yzx', 'zxy', 'xzy', 'yxz', 'zyx']

def getMMatrixFromTransform(sTransform, bWorldspace=True, bTransformationMatrix=False):
    fMatrix = cmds.xform(sTransform, q=True, m=True, ws=bWorldspace)
    mMatrix = OpenMaya2.MMatrix(fMatrix)
    if bTransformationMatrix:
        return OpenMaya2.MTransformationMatrix(mMatrix)
    else:
        return mMatrix


def getNumpyMatrixFromTransform(sTransform, bWorldspace=True):
    fMatrix = cmds.xform(sTransform, q=True, m=True, ws=bWorldspace)
    return np.array(fMatrix, dtype='float64').reshape(4,4)



def getPositionArray(sXforms, bWorld=True, bVector4=False):
    if bWorld:
        fPositions = [cmds.xform(sX, q=True, ws=True, t=True) for sX in sXforms]
    else:
        fPositions = [cmds.xform(sX, q=True, os=True, t=True) for sX in sXforms]

    aPoints = np.array(fPositions, dtype='float64')
    if bVector4:
        aNewPoints = np.ones((aPoints.shape[0], 4), dtype='float64')
        aNewPoints[:,0:3] = aPoints
        return aNewPoints
    else:
        return aPoints


def mapAxis(sSource, sTarget):
    aSourceMatrix = np.array(cmds.xform(sSource, q=True, ws=True, m=True), dtype='float64').reshape(4, 4)[0:3, 0:3]
    aTargetMatrix = np.array(cmds.xform(sTarget, q=True, ws=True, m=True), dtype='float64').reshape(4, 4)[0:3, 0:3]

    aReturn = np.zeros(3, dtype=int)
    for a in [0,1,2]:
        aCrosses = np.array([np.cross(aSourceMatrix[a], aTargetMatrix[0]), np.cross(aSourceMatrix[a], aTargetMatrix[1]), np.cross(aSourceMatrix[a], aTargetMatrix[2])])
        aNorms = np.linalg.norm(aCrosses, axis=1)
        aReturn[a] = np.argmin(aNorms)

    return aReturn


def mapAxisSigned(sSource, sTarget):
    '''
    returns 6, plus and negatives
    '''
    aSourceMatrix = np.array(cmds.xform(sSource, q=True, ws=True, m=True), dtype='float64').reshape(4, 4)[0:3, 0:3]
    aTargetMatrix = np.array(cmds.xform(sTarget, q=True, ws=True, m=True), dtype='float64').reshape(4, 4)[0:3, 0:3]
    aSourceMatrix = np.concatenate([aSourceMatrix, aSourceMatrix*-1])
    aTargetMatrix = np.concatenate([aTargetMatrix, aTargetMatrix*-1])

    aReturn = np.zeros(6, dtype=int)
    for a in range(6):
        aDots = np.array([np.dot(aSourceMatrix[a], aTargetMatrix[0]), np.dot(aSourceMatrix[a], aTargetMatrix[1]), np.dot(aSourceMatrix[a], aTargetMatrix[2]),
                          np.dot(aSourceMatrix[a], aTargetMatrix[3]), np.dot(aSourceMatrix[a], aTargetMatrix[4]), np.dot(aSourceMatrix[a], aTargetMatrix[5])])
        aReturn[a] = np.argmax(aDots)

    return aReturn



def localizePoints(aPoints, sTransform):
    aPoints4 = np.ones((len(aPoints),4), dtype='float64')
    aPoints4[:,:3] = aPoints

    aMatrix = np.array(cmds.xform(sTransform, q=True, m=True, ws=True), dtype='float64').reshape(4, 4)
    aLocals4 = np.dot(aPoints4, np.linalg.inv(aMatrix))
    return aLocals4[:,0:3]



def createSimpleTransforms(sJoints, sNames=None):
    sTempDupls = []
    if sNames == None:
        sNames = sJoints
    for sJ,sN in zip(sJoints,sNames):
        sNode = cmds.createNode('transform', name='tempDupl_%s' % sN)
        cmds.delete(cmds.parentConstraint(sJ, sNode))
        sTempDupls.append(sNode)
    return sTempDupls



def scalePointsFromTransform(aPoints, fScale, sTransform):
    aPoints4 = np.ones((len(aPoints),4), dtype='float64')
    aPoints4[:,:3] = aPoints

    aMatrix = np.array(cmds.xform(sTransform, q=True, m=True, ws=True), dtype='float64').reshape(4, 4)
    aLocals4 = np.dot(aPoints4, np.linalg.inv(aMatrix))
    aLocals4[:,0:3] *= fScale
    aGlobals4 = np.dot(aLocals4, aMatrix)
    return aGlobals4[:,0:3]


def orientThreePoints(sTransform, sAim, sUp, fAimVector=[1,0,0], fUpVector=[0,1,0], bDeleteConstraint=True, bMaintainOffset=False, bOjectRotation=False):
    if isinstance(sAim, (list,tuple,np.ndarray)):
        sAimTransform = cmds.createNode('transform')
        fPos = cmds.xform(sTransform, q=True, ws=True, t=True)
        cmds.setAttr('%s.t' % sAimTransform, fPos[0]+sAim[0], fPos[1]+sAim[1], fPos[2]+sAim[2])
        bCreatedAimTransform = True
    else:
        sAimTransform = sAim
        bCreatedAimTransform = False


    if isinstance(sUp, (list,tuple,np.ndarray)):
        sUpTransform = cmds.createNode('transform')
        fPos = cmds.xform(sTransform, q=True, ws=True, t=True)
        cmds.setAttr('%s.t' % sUpTransform, fPos[0]+sUp[0], fPos[1]+sUp[1], fPos[2]+sUp[2])
        bCreatedUpTransform = True
    else:
        sUpTransform = sUp
        bCreatedUpTransform = False

    sAimConstraint = cmds.aimConstraint(sAimTransform, sTransform,
                                        aimVector=fAimVector,
                                        upVector=fUpVector,
                                        worldUpType='objectrotation' if bOjectRotation else 'object',
                                        worldUpObject=sUpTransform,
                                        maintainOffset=bMaintainOffset)

    if bDeleteConstraint:
        cmds.delete(sAimConstraint)
        if bCreatedAimTransform:
            cmds.delete(sAimTransform)
        if bCreatedUpTransform:
            cmds.delete(sUpTransform)
    if bDeleteConstraint:
        return None
    else:
        return sAimConstraint[0]


def createOrReturnTopGroup(sGrpName, sParent=None):
    if not cmds.objExists(sGrpName):
        cmds.createNode('transform', name=sGrpName)
        if sParent:
            cmds.parent(sGrpName, sParent)
    return sGrpName


def getRoots(sTransforms):
    if not isinstance(sTransforms, list):
        raise Exception('%s needs to be a list' % sTransforms)
    if not len(sTransforms):
        return []
    sTransforms = [sT for sT in sTransforms if sT]
    sTransformsLn = cmds.ls(sTransforms, l=True)
    if len(sTransforms) != len(sTransformsLn):
        raise Exception('something is not right with %s' % sTransforms)
    aSorts = np.argsort(sTransformsLn)
    sRoots = [sTransformsLn[aSorts[0]]]

    for iJ in aSorts[1:]:
        bIsRoot = True
        for sR in sRoots:
            if sTransformsLn[iJ].startswith('%s|' % sR):
                bIsRoot = False
                break
        if bIsRoot:
            sRoots.append(sTransformsLn[iJ])

    return [sR.split('|')[-1] for sR in sRoots]


def getRootOfNode(sNode):
    sParents = [sNode]
    while True:
        sNewParents = cmds.listRelatives(sParents[0], p=True, c=False)
        if not sNewParents:
            return sParents[0]
        sParents = sNewParents


def createLocator(sName, fSize=1.0, sParent=None, sMatch=None, xPos=None):
    sName = utils.getUniqueName(sName)

    sLoc = cmds.spaceLocator(n=sName)[0]
    cmds.setAttr('%s.localScale' % cmds.listRelatives(sLoc, s=True)[0], fSize, fSize, fSize)

    if sParent:
        cmds.parent(sLoc, sParent)
        if sMatch:
            cmds.delete(cmds.parentConstraint(sMatch,sLoc))
        else:
            cmds.setAttr('%s.t' % sLoc, 0,0,0)
            cmds.setAttr('%s.r' % sLoc, 0,0,0)
            cmds.setAttr('%s.s' % sLoc, 1,1,1)
    elif sMatch:
        cmds.delete(cmds.parentConstraint(sMatch,sLoc))

    if isinstance(xPos, OpenMaya2.MVector) or not utils.isNone(xPos):# != None:
        nodes._connectOrSetVector(xPos, '%s.t' % sLoc, ['tx','ty','tz'])

    return sLoc


def createTransform(sName, fSize=1.0, sParent=None, sMatch=None, sMatchXform=None, bErrorIfExists=False):
    if bErrorIfExists and cmds.objExists(sName):
        raise Exception('A transform with the name of "%s" already exists' % sName)

    sName = utils.getUniqueName(sName)
    # if cmds.objExists(sName):
    #     raise Exception, 'an object with the name of %s already exists' % sName

    sNode = cmds.createNode('transform', n=sName, p=sParent)
    if sParent:
        cmds.setAttr('%s.t' % sNode, 0,0,0)
        cmds.setAttr('%s.r' % sNode, 0,0,0)
        cmds.setAttr('%s.s' % sNode, 1,1,1)
    if sMatch:
        cmds.delete(cmds.parentConstraint(sMatch, sNode))
    if sMatchXform:
        matchXform(sMatchXform, sNode)
    return sNode


def matchXform(sFrom, sTo, bRotateOrder=False):
    if bRotateOrder:
        cmds.setAttr('%s.ro' % sTo, cmds.getAttr('%s.ro' % sFrom))
    cmds.xform(sTo, m=cmds.xform(sFrom, q=True, m=True, ws=True), ws=True)


def matchLocalTransformAttributes(sFrom,sTo, bRotateOrder=False):
    if bRotateOrder:
        cmds.setAttr('%s.ro' % sTo, cmds.getAttr('%s.ro' % sFrom))
    for sA in ['tx','ty','tz','rx','ry','rz','sx','sy','sz']:
        sToAttr = '%s.%s' % (sTo,sA)
        if cmds.getAttr(sToAttr, settable=True):
            cmds.setAttr(sToAttr, cmds.getAttr('%s.%s' % (sFrom,sA)))


def createJoint(sName, fSize=1.0, sParent=None, sMatch=None, xPos=None):
    sJoint = cmds.createNode('joint', n=sName, p=sParent)
    cmds.setAttr('%s.radius' % sJoint, fSize)
    if sParent:
        cmds.setAttr('%s.t' % sJoint, 0,0,0)
        cmds.setAttr('%s.r' % sJoint, 0,0,0)
        cmds.setAttr('%s.s' % sJoint, 1,1,1)

    if sMatch:
        cmds.delete(cmds.parentConstraint(sMatch,sJoint))

    if isinstance(xPos, OpenMaya2.MVector) or not utils.isNone(xPos):# != None:
        nodes._connectOrSetVector(xPos, '%s.t' % sJoint, ['tx','ty','tz'])

    return sJoint


def createReverseChild(sTransform, sBlendAttr=None):
    sPrevChildren = cmds.listRelatives(sTransform, c=True, typ='transform')

    sChildR = cmds.createNode('transform', n='revT_%s' % sTransform, p=sTransform)
    sChildT = cmds.createNode('transform', n='revR_%s' % sTransform, p=sChildR)
    nodes.createChoiceNode('%s.ro' % sTransform, iSwapRotateOrders, sTarget='%s.ro' % sChildR)

    sRevRotation = nodes.createVectorMultiplyNode('%s.r' % sTransform, [-1,-1,-1])
    sRevTranslation = nodes.createVectorMultiplyNode('%s.t' % sTransform, [-1,-1,-1])

    if sBlendAttr:
        nodes.createVectorMultiplyNode(sRevRotation, sBlendAttr, bVectorByScalar=True, sTarget='%s.r' % sChildR)
        nodes.createVectorMultiplyNode(sRevTranslation, sBlendAttr, bVectorByScalar=True, sTarget='%s.t' % sChildT)
    else:
        cmds.connectAttr(sRevRotation, sTarget='%s.r' % sChildR)
        cmds.connectAttr(sRevTranslation, sTarget='%s.t' % sChildT)


    print('sPrevChildren: ', sPrevChildren)
    print('sChildT: ', sChildT)

    if sPrevChildren:
        cmds.parent(sPrevChildren, sChildT)



def setMatrix(sTo, sFrom, bWorldspace=True):
    fMatrix = cmds.xform(sFrom, q=True, ws=bWorldspace, m=True)
    cmds.xform(sTo, m=fMatrix, ws=bWorldspace)


def insertParent(sNode, sName, bMatchParentTransform=False, sType='transform'):
    sName = utils.getUniqueName(sName)

    sOldParent = cmds.listRelatives(sNode, p=True)
    sParent = cmds.createNode(sType, name=sName)
    if sOldParent:
        cmds.parent(sParent, sOldParent[0])
    # else:
    if bMatchParentTransform and sOldParent:
        fValuesBefore = []
        for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
            fValuesBefore.append(cmds.getAttr('%s.%s' % (sNode,sA)))
        fMatrix = cmds.xform(sOldParent, q=True, ws=True, m=True)
        cmds.xform(sParent, m=fMatrix, ws=True)
    else:
        fMatrix = cmds.xform(sNode, q=True, ws=True, m=True)
        cmds.xform(sParent, m=fMatrix, ws=True)

    cmds.parent(sNode, sParent)

    # if it's getting matched to the parent, the node shouldn't have any different values than before.
    # but because of some maya bug, sometimes it has different values
    if bMatchParentTransform and sOldParent:
        for sA, fV in zip(['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz'], fValuesBefore):
            try:
                cmds.setAttr('%s.%s' % (sNode,sA), fV)
            except:
                pass
    return sParent


def distanceBetween(sTransformA, sTransformB):
    a = np.array(cmds.xform(sTransformA, q=True, ws=True, t=True))
    b = np.array(cmds.xform(sTransformB, q=True, ws=True, t=True))
    return np.linalg.norm(a-b)


def constraintBlend(sTransform, sTargetA, sTargetB, sCtrl, sAttr, func=cmds.parentConstraint, fDefault=0.0, bMaintainOffset=False, kwargs={}):
    '''
    if blend value is 0, it's targetA. If it's 1, it's targetB
    '''



    if '.' in sAttr:
        sBlendAttr = sAttr
    else:
        sBlendAttr = '%s.%s' % (sCtrl, sAttr)

    if isinstance(sTransform, (list,tuple,np.ndarray)):
        raise Exception('sTransform needs to be simple string, not list: %s' % sTransform)


    if isinstance(sTargetA, (list,tuple,np.ndarray)):
        raise Exception('targetA needs to be simple string, not list: %s' % sTargetA)

    if isinstance(sTargetB, (list,tuple,np.ndarray)):
        raise Exception('targetB needs to be simple string, not list: %s' % sTargetB)


    if not cmds.objExists(sBlendAttr):
        sC, sA = sBlendAttr.split('.')
        utils.addAttr(sC, ln=sA, at='double', defaultValue=fDefault, minValue=0.0, maxValue=1.0, k=True)

    sReverse = nodes.createReverseNode(sBlendAttr, sName='blendConstraint_%s' % sCtrl)

    sConstr = func(sTargetA, sTargetB, sTransform, mo=bMaintainOffset, **kwargs)[0]
    if func in [cmds.parentConstraint, cmds.orientConstraint]:
        cmds.setAttr('%s.interpType' % sConstr, 2)

    cmds.connectAttr(sBlendAttr, '%s.%sW1' % (sConstr, sTargetB))
    cmds.connectAttr(sReverse, '%s.%sW0' % (sConstr, sTargetA))

    return sBlendAttr


def additiveConstraintBlend(sTransform, sTargets, sAttrNames, sAttrObject=None, bMaintainOffset=True):
    if sAttrObject == None:
        sAttrObject = sTransform
    sAttrs = []
    for t, sT in enumerate(sTargets):
        if t == 0:
            sAttrs.append(1.0)
        else:
            sAttrs.append(utils.addAttr(sAttrObject, ln=sAttrNames[t], minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True))

    sConstr = cmds.parentConstraint(sTargets, sTransform, mo=bMaintainOffset)[0]
    for t, sT in enumerate(sTargets):
        sConstraintAttr = '%s.%sW%d' % (sConstr, sT, t)
        if t < len(sTargets) - 1:
            sDifference = nodes.createAdditionNode(sAttrs[t:], sOperation='minus')
            nodes.createClampNode(sDifference, 0, 1, sTarget=sConstraintAttr)
        else:
            cmds.connectAttr(sAttrs[t], sConstraintAttr)


def orientToApproximateWorldspace(sTransform):
    fMatrix = cmds.getAttr('%s.matrix' % sTransform)
    aMatrix = np.array(fMatrix, dtype='float64').reshape(4,4)[:3,:3]
    aMatrixNeg = aMatrix * -1.0
    aMatrixDouble = np.concatenate([aMatrix,aMatrixNeg]).reshape(6,3)

    aYDistances = np.linalg.norm(aMatrixDouble - [0,1,0], axis=1)
    iYClosest = np.argmin(aYDistances)
    aXDistances = np.linalg.norm(aMatrixDouble - [1,0,0], axis=1)
    iXClosest = np.argmin(aXDistances)
    aZDistances = np.linalg.norm(aMatrixDouble - [0,0,1], axis=1)
    iZClosest = np.argmin(aZDistances)

    fMatrix[0:3] = aMatrixDouble[iXClosest]
    fMatrix[4:7] = aMatrixDouble[iYClosest]
    fMatrix[8:11] = aMatrixDouble[iZClosest]

    cmds.xform(sTransform, m=fMatrix)

    return iXClosest % 3, iYClosest % 3, iZClosest % 3


# bKeepScale - changed to True.... it was risky! But should be ok
def alignToWorldAxis(sTransform, iWorldAxisToAlign=1, iPoleAxisToMaintain=0, bFromLocal=True, bNegative=False, bKeepScale=True):
    if iWorldAxisToAlign == iPoleAxisToMaintain:
        raise Exception('world and pole axis cannot be the same')
    
    if bFromLocal:
        fMatrix = cmds.getAttr('%s.matrix' % sTransform)
    else:
        fMatrix = cmds.getAttr('%s.worldMatrix' % sTransform)


    fScaleBefore = cmds.getAttr('%s.s' % sTransform)[0]
    aMatrix = np.array(fMatrix, dtype='float64').reshape(4,4)[:3,:3]
    aPrevLengths = np.linalg.norm(aMatrix, axis=-1)

    aAim = np.array([0,0,0], dtype='float64')
    aAim[iWorldAxisToAlign] = -1.0 if bNegative else 1.0
    aPole = aMatrix[iPoleAxisToMaintain]
    aCross = np.cross(aPole, aAim)
    aPole = np.cross(aAim, aCross)
    aCross = np.cross(aPole, aAim)
    
    iAxes = set([0,1,2])
    iAxes.remove(iWorldAxisToAlign)
    iAxes.remove(iPoleAxisToMaintain)
    iCross = iAxes.pop()

    aMatrix[iWorldAxisToAlign] = aAim
    aMatrix[iPoleAxisToMaintain] = aPole
    aMatrix[iCross] = aCross
    
    aMatrix *= aPrevLengths[:,np.newaxis] / np.linalg.norm(aMatrix, axis=-1)

    fMatrix[0:3] = aMatrix[0]
    fMatrix[4:7] = aMatrix[1]
    fMatrix[8:11] = aMatrix[2]

    if bFromLocal:
        cmds.xform(sTransform, m=fMatrix)
    else:
        cmds.xform(sTransform, m=fMatrix, ws=True)

    if bKeepScale:
        cmds.setAttr('%s.s' % sTransform, *fScaleBefore)


def orientToNearestStraightMatrix(sTransform, bFromLocal=True, bCrossProductOnDuplicates=True):
    '''
    bCrossProductOnDuplicates was False. Changing it was risky, hopefully it's ok.
    '''
    aDirections = np.repeat(np.diag([1, 1, 1]), 2, axis=0).reshape(6, 3)
    aDirections[1::2] *= -1
    '''
    # aDirection is this:
    [[ 1  0  0]
     [-1  0  0]
     [ 0  1  0]
     [ 0 -1  0]
     [ 0  0  1]
     [ 0  0 -1]]
    '''

    if bFromLocal:
        fMatrix = cmds.getAttr('%s.matrix' % sTransform)
    else:
        fMatrix = cmds.getAttr('%s.worldMatrix' % sTransform)

    aMatrix = np.array(fMatrix, dtype='float64').reshape(4,4)[:3,:3]
    iDirections = []
    for a in [0,1,2]:
        aDist = np.linalg.norm(aDirections - aMatrix[a], axis=1)
        iMin = np.argmin(aDist)
        iDirections.append(int(iMin))
        aMatrix[a] = aDirections[iMin]

    if bCrossProductOnDuplicates:
        iDuplicates = [iDirection for iDirection,iCount in Counter(iDirections).items() if iCount > 1]
        if iDuplicates:
            iIndex = iDirections.index(iDuplicates[0])
            iOthers = set([0,1,2])
            iOthers.remove(iIndex)
            aMatrix[iIndex] = np.cross(aMatrix[iOthers.pop()], aMatrix[iOthers.pop()])

    fMatrix[0:3] = aMatrix[0]
    fMatrix[4:7] = aMatrix[1]
    fMatrix[8:11] = aMatrix[2]

    if bFromLocal:
        cmds.xform(sTransform, m=fMatrix)
    else:
        cmds.xform(sTransform, m=fMatrix, ws=True)


def connectInverseScales(sJoints):
    for j in range(len(sJoints)-1):
        try:
            cmds.connectAttr('%s.s' % sJoints[j], '%s.inverseScale' % sJoints[j+1], force=True)
        except:
            pass
        cmds.setAttr('%s.segmentScaleCompensate' % sJoints[j], True)



def duplicateHierarchy(sRoot, sNewRoot, sPostFix, sTypefilter=['joint','transform']):
    sChildren = cmds.listRelatives(sRoot, ad=True)
    sNodes = []
    sOldNames = []
    for sChild in sChildren:
        sType = cmds.objectType(sChild)
        if sType == 'joint' or sType == 'transform':
            sNodes.append(cmds.rename(sChild, '%s____' % sChild))
            sOldNames.append(sChild)

    sNewRoot = cmds.duplicate(sRoot, n=sNewRoot, rc=True)[0]
    sChildren = cmds.listRelatives(sNewRoot, ad=True)
    sNewNodes = []
    for sChild in sChildren:
        sType = cmds.objectType(sChild)
        if isinstance(sTypefilter, (list,tuple,np.ndarray)) and sType not in sTypefilter:
            cmds.delete(sChild)
        else:
            sNewNodes.append(cmds.rename(sChild, '%s%s' % (sChild.split('____')[0], sPostFix)))

    #rename old ones back:
    for n,sN in enumerate(sNodes):
        cmds.rename(sN, sOldNames[n])

    return sNewRoot



# bDeleteBranches is not tested yet
def duplicateJoinChain(sJoints, sPostfix=None, bSwapBpPrefix=True, sParent=None, bScaleComp=False,
                       bDeleteBranches=False, bFreezeOrients=False, bPostSnap=False):

    sNewJoints = cmds.duplicate(sJoints, renameChildren=True, returnRootsOnly=True)

    for j in range(len(sJoints)):
        sName = sJoints[j]
        if bSwapBpPrefix and (sJoints[j].startswith('bp_') or sJoints[j].startswith('bpJnt_')):
            sName = 'jnt_%s' % '_'.join(sJoints[j].split('_')[1:])
        elif bSwapBpPrefix and sJoints[j].startswith('muscleBp'):
            sName = 'muscleJnt_%s' % '_'.join(sJoints[j].split('_')[1:])
        if sPostfix:
            sName = '%s_%s' % (sName, sPostfix)
        # print 'sNewJoints[j]: ', sNewJoints[j], sName
        sNewJoints[j] = cmds.rename(sNewJoints[j], sName)

    if bDeleteBranches:
        sBranches = cmds.listRelatives(sNewJoints, c=True)
        sNonReturns = set(sNewJoints).difference(set(sBranches))
        if sNonReturns:
            cmds.delete(sNonReturns)

    sRestChildren = cmds.listRelatives(sNewJoints[j], c=True)
    if sRestChildren:
        cmds.delete(sRestChildren)

    if sParent:
        try: cmds.parent(sNewJoints[0], sParent)
        except: pass

    if bScaleComp:
        connectInverseScales(sNewJoints)
    else:
        for sJoint in sNewJoints:
            cmds.setAttr('%s.segmentScaleCompensate' % sJoint, bScaleComp)

    if bFreezeOrients:
        cmds.makeIdentity(sNewJoints, r=True, apply=True)

    if bPostSnap:
        for j,sJ in enumerate(sNewJoints):
            sOldMatrix = cmds.xform(sJoints[j], q=True, m=True, ws=True)
            cmds.xform(sJ, m=sOldMatrix, ws=True)

    return sNewJoints



def matchRadius(sJoint, sFromJoint, fMultipl=1.0):
    cmds.setAttr('%s.radius' % sJoint, cmds.getAttr('%s.radius' % sFromJoint) * fMultipl)


def createDebugCubes(sJoints, fSize=1.0):
    sCubes = []
    for sJ in sJoints:
        sCube = cmds.polyCube()[0]
        cmds.parent(sCube, sJ)
        cmds.setAttr('%s.t' % sCube, 0,0,0)
        cmds.setAttr('%s.r' % sCube, 0,0,0)
        cmds.setAttr('%s.s' % sCube, fSize, fSize, fSize)
        sCubes.append(sCube)
    return sCubes


def createDebugCubesSelection():
    sCubes = createDebugCubes(cmds.ls(sl=True))
    cmds.select(sCubes)



def resampleJointChainOld(sJoints, iJointCount, sName='noname', sParent=None, bDeleteLast=False):
    fPoints = [cmds.xform(sJ, q=True,ws=True,t=True) for sJ in sJoints]
    sTempCurve = cmds.curve(p=fPoints, d=2 if len(fPoints) > 2 else 1)
    sTempFitCurve = cmds.fitBspline(sTempCurve)[0]

    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sTempFitCurve))
    fCurveLength = fnCurve.length()
    fLengthsOnCurve = []
    for j in range(len(sJoints)):
        _, fParam = fnCurve.closestPoint(OpenMaya2.MPoint(fPoints[j]))
        fLengthsOnCurve.append(fnCurve.findLengthFromParam(fParam))

    fNewLengths = np.interp(np.linspace(0.0, fCurveLength, iJointCount),
                            np.linspace(0.0, fCurveLength, num=len(fLengthsOnCurve)),
                            fLengthsOnCurve)

    # bad, we should be using sTempFitCurve, but can't change it on this function
    fPoints = curves.getPointsFromPercs(sTempCurve, fNewLengths / fCurveLength)

    sNewJoints = []
    for p, fP in enumerate(fPoints):
        sJ = cmds.createNode('joint', n='jnt_%s_%03d' % (sName,p))

        cmds.setAttr('%s.t' % sJ, *fP)
        if sJ == 0:
            cmds.delete(cmds.orientConstraint(sJoints[0], sJ))
        sNewJoints.append(sJ)

    sTempUp = cmds.createNode('transform')
    cmds.setAttr('%s.t' % sTempUp, 0,1,0)
    cmds.setAttr('%s.t' % sTempUp, lock=True)
    iOldFromPrevIndex = None

    fFactor = len(sJoints) / float(len(sNewJoints))
    for j, sNewJ in enumerate(sNewJoints[:-1]):
        iFromPrevIndex = int(round(j * fFactor))
        iFromPrevIndex = min(iFromPrevIndex, len(sJoints)-1)
        if iFromPrevIndex != iOldFromPrevIndex:
            cmds.parent(sTempUp, sJoints[iFromPrevIndex])
        iOldFromPrevIndex = iFromPrevIndex

        iChildOfPrev = iFromPrevIndex+1
        if iChildOfPrev >= len(sJoints):
            iChildOfPrev = len(sJoints)-1
        fSignFromPrev = 1.0 if cmds.getAttr('%s.tx' % sJoints[iChildOfPrev]) > 0.0 else -1.0
        cmds.delete(cmds.aimConstraint(sNewJoints[j+1], sNewJ, aim=[1*fSignFromPrev,0,0], wu=[0,-1,0], wut='object', wuo=sTempUp))

        cmds.makeIdentity(sNewJ, apply=True, r=True)

        cmds.parent(sNewJoints[j+1], sNewJ)
        matchRadius(sNewJ, sJoints[iFromPrevIndex])

    cmds.delete(cmds.orientConstraint(sNewJoints[-2], sNewJoints[-1]))
    cmds.makeIdentity(sNewJoints[-1], apply=True, r=True)

    matchRadius(sNewJoints[-1], sJoints[-1])
    cmds.delete(sTempUp, sTempCurve, sTempFitCurve)

    if sParent:
        cmds.parent(sNewJoints[0], sParent)

    if bDeleteLast:
        cmds.delete(sNewJoints[-1])
        sNewJoints = sNewJoints[:-1]

    return sNewJoints


# this is depricated!!! use resampleJointChain2 instead
def resampleJointChain(sJoints, iJointCount, sName='noname', sParent=None, bDeleteLast=False, bzeroLastJoint=False, sPrefix='jnt'):
    fPoints = [cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sJoints]
    sTempCurve = cmds.curve(p=fPoints, d=2 if len(fPoints) > 2 else 1)
    sTempFitCurve = cmds.fitBspline(sTempCurve)[0]

    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sTempFitCurve))
    fCurveLength = fnCurve.length()
    fLengthsOnCurve = []
    for j in range(len(sJoints)):
        _, fParam = fnCurve.closestPoint(OpenMaya2.MPoint(fPoints[j]))
        fLengthsOnCurve.append(fnCurve.findLengthFromParam(fParam))

    fNewLengths = np.interp(np.linspace(0.0, fCurveLength, iJointCount),
                            np.linspace(0.0, fCurveLength, num=len(fLengthsOnCurve)),
                            fLengthsOnCurve)

    fPoints = curves.getPointsFromPercs(sTempFitCurve, fNewLengths / fCurveLength)

    sNewJoints = []
    for p, fP in enumerate(fPoints):
        sJ = cmds.createNode('joint', n='%s_%s_%03d' % (sPrefix, sName, p))

        cmds.setAttr('%s.t' % sJ, *fP)
        if sJ == 0:
            cmds.delete(cmds.orientConstraint(sJoints[0], sJ))
        sNewJoints.append(sJ)

    sTempUp = cmds.createNode('transform')
    cmds.setAttr('%s.t' % sTempUp, 0, 1, 0)
    cmds.setAttr('%s.t' % sTempUp, lock=True)
    iOldFromPrevIndex = None

    fFactor = len(sJoints) / float(len(sNewJoints))
    for j, sNewJ in enumerate(sNewJoints[:-1]):
        iFromPrevIndex = int(round(j * fFactor))
        iFromPrevIndex = min(iFromPrevIndex, len(sJoints) - 1)
        if iFromPrevIndex != iOldFromPrevIndex:
            cmds.parent(sTempUp, sJoints[iFromPrevIndex])
        iOldFromPrevIndex = iFromPrevIndex

        iChildOfPrev = iFromPrevIndex + 1
        if iChildOfPrev >= len(sJoints):
            iChildOfPrev = len(sJoints) - 1
        fSignFromPrev = 1.0 if cmds.getAttr('%s.tx' % sJoints[iChildOfPrev]) > 0.0 else -1.0
        cmds.delete(
            cmds.aimConstraint(sNewJoints[j + 1], sNewJ, aim=[1 * fSignFromPrev, 0, 0], wu=[0, -1, 0], wut='object',
                               wuo=sTempUp))

        cmds.makeIdentity(sNewJ, apply=True, r=True)

        cmds.parent(sNewJoints[j + 1], sNewJ)
        matchRadius(sNewJ, sJoints[iFromPrevIndex])

    if bzeroLastJoint:
        cmds.setAttr('%s.jo' % sNewJoints[-1], 0,0,0)

    cmds.delete(cmds.orientConstraint(sNewJoints[-2], sNewJoints[-1]))
    cmds.makeIdentity(sNewJoints[-1], apply=True, r=True)

    matchRadius(sNewJoints[-1], sJoints[-1])
    cmds.delete(sTempUp, sTempCurve, sTempFitCurve)

    if sParent:
        cmds.parent(sNewJoints[0], sParent)

    if bDeleteLast:
        cmds.delete(sNewJoints[-1])
        sNewJoints = sNewJoints[:-1]

    return sNewJoints




def resampleJointChain2(sOldJoints, iJointCount, sName='noname', sParent=None, bDeleteLast=False, bzeroLastJoint=False, sPrefix='jnt'):
    fOldPoints = [cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sOldJoints]
    sTempCurve = cmds.curve(p=fOldPoints, d=2 if len(fOldPoints) > 2 else 1)
    sTempFitCurve = cmds.fitBspline(sTempCurve)[0]

    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sTempFitCurve))
    fCurveLength = fnCurve.length()
    fLengthsOnCurve = []
    for j in range(len(sOldJoints)):
        _, fParam = fnCurve.closestPoint(OpenMaya2.MPoint(fOldPoints[j]))
        fLengthsOnCurve.append(fnCurve.findLengthFromParam(fParam))

    fNewLengths = np.interp(np.linspace(0.0, fCurveLength, iJointCount),
                            np.linspace(0.0, fCurveLength, num=len(fLengthsOnCurve)),
                            fLengthsOnCurve)

    aNewPercs = fNewLengths / fCurveLength
    aNewPoints = curves.getPointsFromPercs(sTempFitCurve, aNewPercs, bReturnNumpy=True)
    aOldPercs = curves.getPercsFromPoints(sTempFitCurve, fOldPoints, bReturnNumpy=True)
    sNewJoints = []
    for p, fP in enumerate(aNewPoints):
        sJ = cmds.createNode('joint', n='%s_%s_%03d' % (sPrefix, sName, p))

        cmds.setAttr('%s.t' % sJ, *list(fP))
        if sJ == 0:
            cmds.delete(cmds.orientConstraint(sOldJoints[0], sJ))
        sNewJoints.append(sJ)

    xWeightings = getCtrlWeightings(aNewPercs, aOldPercs)
    sTempUp = cmds.createNode('transform')
    for j, sNewJ in enumerate(sNewJoints[:-1]):
        iOldInd0, iOldInd1, fWeight = xWeightings[j]
        fSignFromOld = -1.0 if cmds.getAttr('%s.tx' % sOldJoints[max(iOldInd0,1)]) < 0.0 else 1.0

        if iOldInd0 == iOldInd1:
            sOrientConstraint = cmds.orientConstraint(sOldJoints[iOldInd0], sTempUp)[0]
        else:
            sOrientConstraint = cmds.orientConstraint(sOldJoints[iOldInd0], sOldJoints[iOldInd1], sTempUp)[0]
            cmds.setAttr('%s.%sW0' % (sOrientConstraint, sOldJoints[iOldInd0]), 1.0-fWeight)
            cmds.setAttr('%s.%sW1' % (sOrientConstraint, sOldJoints[iOldInd1]), fWeight)
            cmds.setAttr('%s.interpType' % sOrientConstraint, 2)

        matchRadius(sNewJ, sOldJoints[iOldInd0])

        cmds.delete(cmds.aimConstraint(sNewJoints[j + 1], sNewJ, aim=[fSignFromOld, 0, 0], wut='objectrotation', wuo=sTempUp))
        cmds.delete(sOrientConstraint)
        cmds.makeIdentity(sNewJ, apply=True, r=True)

        cmds.parent(sNewJoints[j + 1], sNewJ)
    
    matchRadius(sNewJoints[-1], sOldJoints[-1])

    if bzeroLastJoint:
        cmds.setAttr('%s.jo' % sNewJoints[-1], 0,0,0)

    cmds.delete(cmds.orientConstraint(sNewJoints[-2], sNewJoints[-1]))
    cmds.makeIdentity(sNewJoints[-1], apply=True, r=True)

    cmds.delete(sTempUp, sTempCurve, sTempFitCurve)

    if sParent:
        cmds.parent(sNewJoints[0], sParent)

    if bDeleteLast:
        cmds.delete(sNewJoints[-1])
        sNewJoints = sNewJoints[:-1]

    return sNewJoints



def getJointHierarchyBoundingDiagonal(sRoot):
    sRoot = utils.toList(sRoot)
    sJoints = []
    for sR in sRoot:
        sJoints += cmds.listRelatives(sR, ad=True, typ='joint') or []

    if not sJoints:
        return 1.0
    sJoints += sRoot
    aPositions = np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sJoints], dtype='float64')
    aMins = np.min(aPositions, axis=0)
    aMaxs = np.max(aPositions, axis=0)
    return np.linalg.norm(aMaxs-aMins)


def jointChainFromRoot(sRoot):
    sJoints = cmds.listRelatives(sRoot, ad=True, typ='joint')
    if not sJoints:
        return [sRoot]
    return [sRoot] + sJoints



def createJointChain(ffPoints = [], sNames=[], sParent=None, fRadius=1.0, sSide='l', bSegmentScaleCompensate=True):
    sPrevJoint = None
    sReturnJoints = []
    cmds.select(d=True)
    for fP,fN in zip(ffPoints, sNames):
        sJoint = cmds.joint(p=fP, n=fN)
        if sPrevJoint:
            cmds.joint(sPrevJoint, e=True, zso=True, oj='xyz', sao='yup');
        sPrevJoint = sJoint
        sReturnJoints.append(sJoint)

    cmds.setAttr('%s.jo' % sReturnJoints[-1], 0, 0, 0)

    if sSide == 'r':
        [cmds.setAttr('%s.tx'%sJ, -cmds.getAttr('%s.tx'%sJ)) for sJ in sReturnJoints[1:]]
        cmds.setAttr('%s.rz'%sReturnJoints[0], 180)
        cmds.makeIdentity(sReturnJoints[0], apply=True, r=True)

    if sParent:
        cmds.parent(sReturnJoints[0], sParent)

    if fRadius != 1.0:
        [cmds.setAttr('%s.radius' % sJ, fRadius) for sJ in sReturnJoints]

    if not bSegmentScaleCompensate:
        [cmds.setAttr('%s.segmentScaleCompensate' % sJ, False) for sJ in sReturnJoints]

    return sReturnJoints


def resetTransform(sTransform, t=True, r=True, s=True, jo=False):
    if t:
        cmds.setAttr('%s.t' % sTransform, 0, 0, 0)
    if r:
        cmds.setAttr('%s.r' % sTransform, 0, 0, 0)
    if s:
        cmds.setAttr('%s.s' % sTransform, 1, 1, 1)
    if jo and cmds.objectType(sTransform) == 'joint':
        cmds.setAttr('%s.jo' % sTransform, 0,0,0)


# DEPRICATED
def softResetTransform(sTransform):
    for sA in ['tx','ty','tz','rx','ry','rz']:#,'sx','sy','sz']:
        try:
            cmds.setAttr('%s.%s' % (sTransform, sA), 0.0)
        except Exception as e:
            pass


def resetTrsWithReturn(sTransform):
    dReturn = {}
    for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx','sy','sz']:
        sAttr = '%s.%s' % (sTransform, sA)
        print ('sAttr: ', sAttr)
        if cmds.getAttr(sAttr, settable=True):
            print ('sAttr: ', sAttr)
            dReturn[sAttr] = cmds.getAttr(sAttr)
            cmds.setAttr(sAttr, 0.0)
    return dReturn


def setTrsValuesBack(dValues):
    for sAttr, fValue in dValues.items():
        cmds.setAttr(sAttr, fValue)


# depricated, please use resetTransform()
def resetJoint(sJoint, t=True, r=True, jo=True):
    if t:
        cmds.setAttr('%s.t' % sJoint, 0, 0, 0)
    if r:
        cmds.setAttr('%s.r' % sJoint, 0, 0, 0)
    if jo and cmds.objectType(sJoint) == 'joint':
        cmds.setAttr('%s.jo' % sJoint, 0, 0, 0)


def fPoleVectorPos(sUparm, sElbow, sWrist, bOpposite=False, fThresholdAngle=None, fFurtherAwayFactor=1.0):

    fUparm = barycentric._xPointToVectorArray(sUparm)
    fElbow = barycentric._xPointToVectorArray(sElbow)
    fWrist = barycentric._xPointToVectorArray(sWrist)


    if fThresholdAngle:
        fAngle = barycentric.angleBetween(fUparm-fElbow, fWrist-fElbow)
        if 180.0-abs(fAngle) < fThresholdAngle:
            fSideMultipl = -1.0 if utils.getSide(sElbow) == 'r' else 1.0
            fLength = np.linalg.norm(fElbow-fUparm)
            fPos = nodes.createPointByMatrixNode([0,2 * -fLength * fSideMultipl, 0], '%s.worldMatrix' % sElbow, bJustValues=True)
            return fPos

    fMiddle = barycentric.closestPointOnLine(fElbow, fUparm, fWrist)
    fDirection = fElbow-fMiddle
    fDirection /= np.linalg.norm(fDirection)
    fDirection *= barycentric.distanceBetween(fUparm, fWrist) * 0.75 * fFurtherAwayFactor
    if bOpposite:
        fDirection *= -1.0

    return fElbow + fDirection



def createIk(sJointA, sJointB, sPole=None, sParent=None, sName=None, bOppositePole=False):
    sHandle, sEff = cmds.ikHandle(sj=sJointA, ee=sJointB, sol='ikRPsolver')
    if sPole:
        cmds.poleVectorConstraint(sPole, sHandle)
    if sParent:
        cmds.parent(sHandle, sParent)
    if sName:
        sHandle = cmds.rename(sHandle, sName)
    if bOppositePole:
        cmds.setAttr('%s.twist' % sHandle, 180)
    return sHandle


def getLocked(sInfluences):
    bLocks = np.array([cmds.getAttr('%s.liw' % influence) for influence in sInfluences],
                      dtype=bool)
    return bLocks



# def mirrorJoints(sRoot):
#     cmds.mirrorJoint(sRoot, mirrorYZ=True, mirrorBehavior=True, searchReplace=('_l_','_r_'))

def createIfNotExists(sTransform, sParent=None):
    if not cmds.objExists(sTransform):
        cmds.createNode('transform', n=sTransform)
        if sParent:
            cmds.parent(sTransform, sParent)
    return sTransform


def mirrorIfNotExists(sTransform, bDeleteNewChildren=False, sMirrorMesh=None, aMirrorTable=None):
    '''
    returns the mirrored one - different to curves.mirrorIfNotExists()
    '''
    sMirror = utils.getMirrorName(sTransform)
    if cmds.objExists(sMirror):
        return sMirror
    else:
        sTemp = cmds.createNode('transform')
        sMirror = cmds.duplicate(sTransform, n=sMirror)[0]
        if bDeleteNewChildren:
            cmds.delete(cmds.listRelatives(sMirror, c=True, f=True))
        cmds.parent(sMirror, sTemp)
        cmds.setAttr('%s.sx' % sTemp, -1)
        cmds.parent(sMirror, cmds.listRelatives(sTransform, p=True)[0])

        if sMirrorMesh:
            aMeshPoints = patch.patchFromName(sMirrorMesh).getPoints()
            aPoint = np.array(cmds.xform(sTransform, q=True, ws=True, t=True), dtype='float64').reshape(-1,3)
            aClosestPoint = getClosestIdsFromPoints(sMirrorMesh, aPoint)[0]
            aOffset = aPoint - aMeshPoints[aClosestPoint]
            aOffset[0] *= -1.0

            aOpposite = aMeshPoints[aMirrorTable[0][aClosestPoint]] + aOffset
            cmds.xform(sMirror, t=list(aOpposite[0]), ws=True)

        return sMirror


def findClosestJointsToPatchComponents(tbPatch, sJoints, bIncludeChildrenNotInInputJoints=True, sProjectAttrs=[], bJointLines=True):
    aPoints = tbPatch.getPoints()
    return findClosestJoints(aPoints, sJoints,
                             bIncludeChildrenNotInInputJoints=bIncludeChildrenNotInInputJoints,
                             sProjectAttrs=sProjectAttrs, bJointLines=bJointLines)


def findClosestPoints(aFromPoints, aToPoints):
    '''
    result is in the length of aFromPoints
    '''
    iPointCount = len(aFromPoints)
    iJointCount = len(aToPoints)

    aToPointsRep = np.repeat(aToPoints[np.newaxis,:], iPointCount, axis=0).reshape(iPointCount,iJointCount,3)
    aFromPointsRep = np.repeat(aFromPoints, iJointCount, axis=0).reshape(iPointCount,iJointCount,3)

    aDistances = np.linalg.norm(aToPointsRep - aFromPointsRep, axis=-1)
    iClosests = np.argmin(aDistances, axis=1)

    return iClosests


def findClosestFloats(aFromFloats, aToFloats):
    '''
    result is in the length of aFromFloats
    '''
    iPointCount = len(aFromFloats)
    iJointCount = len(aToFloats)

    aToFloatsRep = np.repeat(aToFloats[np.newaxis,:], iPointCount, axis=0).reshape(iPointCount,iJointCount)
    aFromFloatsRep = np.repeat(aFromFloats, iJointCount, axis=0).reshape(iPointCount,iJointCount)

    aDistances = np.abs(aToFloatsRep - aFromFloatsRep)
    iClosests = np.argmin(aDistances, axis=1)

    return iClosests

# depricated - please use getCtrlWeightings2 instead
def getCtrlWeightings(fJointPercs, fCtrlPercs):

    if not isinstance(fJointPercs, np.ndarray):
        fJointPercs = np.array(fJointPercs, dtype='float64')
    if not isinstance(fCtrlPercs, np.ndarray):
        fCtrlPercs = np.array(fCtrlPercs, dtype='float64')

    iClosestCtrls = findClosestFloats(fJointPercs, fCtrlPercs)

    xCtrlWeightings = []
    for j in range(len(fJointPercs)):
        iCtrl0 = iClosestCtrls[j]
        iCtrl1 = iClosestCtrls[j]
        if fJointPercs[j] < fCtrlPercs[iCtrl0]:
            if iCtrl0 > 0:
                iCtrl0 = iCtrl0 - 1
        elif fJointPercs[j] > fCtrlPercs[iCtrl0]:
            if iCtrl1 < len(fCtrlPercs) - 1:
                iCtrl1 = iCtrl1 + 1
        fBlend = utils.projectToRange(fJointPercs[j], fCtrlPercs[iCtrl0], fCtrlPercs[iCtrl1], 0, 1)

        xCtrlWeightings.append([iCtrl0, iCtrl1, fBlend])

    return xCtrlWeightings


# Handles fCtrlPercs with different orders. Also supports closed curves
def getCtrlWeightings2(fJointPercs, fCtrlPercs, fIsCircleWithParamLength=None):

    aCtrlOrder = np.argsort(fCtrlPercs)
    aCtrlPercs = np.array(fCtrlPercs, dtype='float64')[aCtrlOrder]

    if not utils.isNone(fIsCircleWithParamLength):
        aCtrlPercs = np.concatenate([[aCtrlPercs[-1] - fIsCircleWithParamLength], aCtrlPercs])

    iCircleLengthSubtract = 1 if not utils.isNone(fIsCircleWithParamLength) else 0

    if not isinstance(fJointPercs, np.ndarray):
        fJointPercs = np.array(fJointPercs, dtype='float64')

    iClosestCtrls = findClosestFloats(fJointPercs, aCtrlPercs)

    xCtrlWeightings = []
    for j in range(len(fJointPercs)):
        iCtrl0 = iClosestCtrls[j]
        iCtrl1 = iClosestCtrls[j]
        if fJointPercs[j] < aCtrlPercs[iCtrl0]:
            if iCtrl0 > 0:
                iCtrl0 = iCtrl0 - 1
        elif fJointPercs[j] > aCtrlPercs[iCtrl0]:
            if iCtrl1 < len(aCtrlPercs) - 1:
                iCtrl1 = iCtrl1 + 1
        fBlend = utils.projectToRange(fJointPercs[j], aCtrlPercs[iCtrl0], aCtrlPercs[iCtrl1], 0, 1)

        xCtrlWeightings.append([aCtrlOrder[iCtrl0-iCircleLengthSubtract], aCtrlOrder[iCtrl1-iCircleLengthSubtract], fBlend])

    return xCtrlWeightings


def findClosestJoints(aFromPoints, sJoints, bIncludeChildrenNotInInputJoints=True, bReturnNames=False, sProjectAttrs=[],
                      bReturnOrderedDistances=False, bAlsoReturnDistances=False, bJointLines=True):
    '''
    result is in the length of aFromPoints
    '''
    iPoints, iJoints = len(aFromPoints), len(sJoints)

    sProjectJoints = list(sJoints)
    for sAttr in sProjectAttrs:
        for j, sJ in enumerate(sProjectJoints):
            sFullAttr = '%s.%s' % (sJ,sAttr)
            if cmds.objExists(sFullAttr):
                sParentJoint = cmds.getAttr(sFullAttr)
                if sParentJoint not in sProjectJoints and cmds.objExists(sParentJoint):
                    sProjectJoints[j] = sParentJoint


    aJoints = np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sProjectJoints], dtype='float64')
    aClosestJoints = np.repeat(aJoints[np.newaxis,:], iPoints, axis=0).reshape(iPoints,iJoints,3)

    # create lines
    if bJointLines:
        fLineStartPoints, fLineEndPoints = [], []
        aJointLineMapper = np.zeros(len(sProjectJoints), dtype=int)
        aJointLineMapper.fill(-1)
        for j, sJoint in enumerate(sProjectJoints):
            sChildren = cmds.listRelatives(sJoint, c=True, typ='joint', f=True)

            if sChildren and not bIncludeChildrenNotInInputJoints:
                sChildren = [i for i in sChildren if i in cmds.ls(sProjectJoints, l=True)]

            if sChildren:
                aChildren = np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sChildren], dtype='float64')
                aDistances = np.linalg.norm(aChildren - aJoints[j], axis=1)
                aChildrenIndices = np.array(np.where(aDistances > 0.00001)[0], dtype=int)
                if len(aChildrenIndices):
                    aJointLineMapper[j] = len(fLineStartPoints)
                    for iChild in aChildrenIndices:
                        fLineStartPoints.append(aJoints[j])
                        fLineEndPoints.append(aChildren[iChild])
        aLinePointsA = np.array(fLineStartPoints, dtype='float64')
        aLinePointsB = np.array(fLineEndPoints, dtype='float64')
        iLineCount = len(fLineStartPoints)
    else:
        iLineCount = 0

    if iLineCount > 0:
        # get vectors between joint and child to calculate closest point on line
        fLineLengthMultipl = 0.999
        aLineVectors = aLinePointsB - aLinePointsA
        aLineLengths = np.linalg.norm(aLineVectors, axis=-1)
        aLineDirections = aLineVectors / aLineLengths[:,np.newaxis]

        aLineLengths *= fLineLengthMultipl
        aLinePointsB = aLinePointsA + aLineVectors * fLineLengthMultipl

        aPointsRepLines = np.repeat(aFromPoints, iLineCount, axis=0).reshape(iPoints,iLineCount,3)
        aPs = aPointsRepLines - aLinePointsA
        aTs = np.sum((aPs * aLineDirections.reshape(1,iLineCount,3)), axis=-1) / aLineLengths
        aTs = np.clip(aTs, 0, 1)

        # now we got the parameters (t), reshape them and the joint positions to get the closest points on the bones
        aTsReshaped = aTs.reshape(iPoints,iLineCount,1)
        aLinePointsARep = np.repeat(aLinePointsA[np.newaxis,:], iPoints, axis=0).reshape(iPoints,iLineCount,3)
        aLinePointsBRep = np.repeat(aLinePointsB[np.newaxis,:], iPoints, axis=0).reshape(iPoints,iLineCount,3)
        aClosestsLines = aLinePointsARep * (1-aTsReshaped) + aLinePointsBRep * aTsReshaped

        # for each joint, find the closest line (joint to child connection)
        for j, sJoint in enumerate(sProjectJoints):
            iStartIndex = aJointLineMapper[j]
            if iStartIndex == -1:
                continue
            iEndIndex = iLineCount
            for i in range(j+1, len(aJointLineMapper), 1):
                if aJointLineMapper[i] != -1:
                    iEndIndex = aJointLineMapper[i]
                    break
            aClosestsAllLinesFromJoint = aClosestsLines[:,iStartIndex:iEndIndex]
            aVectorsToLines = aClosestsAllLinesFromJoint - aPointsRepLines[:,iStartIndex:iEndIndex]
            aDistancesAllLinesFromJoint = np.linalg.norm(aVectorsToLines, axis=-1)
            iClosestLineFromJoint = np.argmin(aDistancesAllLinesFromJoint, axis=-1)
            aClosestJoints[:,j] = aClosestsAllLinesFromJoint[np.arange(len(aFromPoints)), iClosestLineFromJoint]

    aPointsPerJoints = np.repeat(aFromPoints, iJoints, axis=0).reshape(iPoints, iJoints, 3)
    aDistances = np.linalg.norm(aClosestJoints - aPointsPerJoints, axis=-1)

    if bReturnOrderedDistances:
        aReturnInds = np.argsort(aDistances, axis=1) # 3 dim array
    else:
        aReturnInds = np.argmin(aDistances, axis=1) # 2 dim array

    if bReturnNames:
        aReturn = np.array(sJoints)[aReturnInds]
    else:
        aReturn = aReturnInds

    if bAlsoReturnDistances:
        aDistancesReturn = []
        for a,b in zip(aDistances, aReturnInds):
            aDistancesReturn.append(a[b])
        return aReturn, np.array(aDistancesReturn, dtype='float64') # not tested yet for  bReturnOrderedDistances=False
    else:
        return aReturn




def warpTransforms(sSourceMesh, sTargetMesh, sJoints, bOrient=False):

    sSelBefore = cmds.ls(sl=True)
    mSourceDagPath = utils.getDagPath(sSourceMesh)
    mMeshIter = OpenMaya2.MItMeshPolygon(mSourceDagPath)
    mMeshFn = OpenMaya2.MFnMesh(mSourceDagPath)
    aMeshPoints = np.array(cmds.xform('%s.vtx[*]' % sSourceMesh, q=True, ws=True, t=True)).reshape(-1,3)
    aMeshPointsTarget = np.array(cmds.xform('%s.vtx[*]' % sTargetMesh, q=True, ws=True, t=True)).reshape(-1,3)
    iJointCount = len(sJoints)

    aHits = np.zeros((iJointCount,3,2,3), dtype='float64')
    aFacePoints = np.zeros((iJointCount,3,2,3), dtype=int)
    aFaceBarys = np.zeros((iJointCount,3,2,3), dtype='float64')
    aParams = np.zeros((iJointCount,3,2), dtype='float64')
    aTwoPoints = np.ones((iJointCount,3), dtype=bool)
    aParams.fill(-1)

    bIsOutsideMesh = [False] * iJointCount
    aJointMatrices = []
    aOrigins = np.zeros(iJointCount*3).reshape(-1,3)
    bOrients = bOrient if isinstance(bOrient,list) else [bOrient] * len(sJoints)
    xClosestOutsideIndices = []

    aJointRange = np.arange(len(sJoints))

    mAccelParams = mMeshFn.autoUniformGridParams()
    iOutsideFacePoints, iOutsideHits, fOutsideBarys, fOutsideParams = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)

    for j, sJoint in enumerate(sJoints):
        aMatrix = utils.getNumpyMatrixFromTransform(sJoint)
        aPos = aMatrix[3,0:3]
        aJointMatrices.append(aMatrix)
        mFromFloatPoint = OpenMaya2.MFloatPoint(*list(aPos))
        mFromPoint = OpenMaya2.MPoint(*list(aPos))
        aOrigins[j] = aPos

        iAxeErrorCounter = 0

        for a in range(3):
            if bIsOutsideMesh[j]: continue
            mMainDir = np.array(aMatrix[a,0:3], dtype='float64')
            for s, mDir in enumerate([OpenMaya2.MFloatVector(mMainDir), OpenMaya2.MFloatVector(mMainDir*-1)]): # iterating in both direction of that direction
                xIntersect = mMeshFn.closestIntersection(mFromFloatPoint, mDir, OpenMaya2.MSpace.kWorld , 1000, False, accelParams=mAccelParams)
                if utils.isNone(xIntersect) or xIntersect[2] == -1: # no intersection
                    iAxeErrorCounter += 1
                    aTwoPoints[j,a] = False
                    break
                else:
                    mPoint, param, iFace, iTri, fB1, fB2 = xIntersect
                    aHits[j,a,s] = [mPoint.x, mPoint.y, mPoint.z]
                    aParams[j,a,s] = max(0.00001, param)
                    mMeshIter.setIndex(iFace)
                    _, iPoints = mMeshIter.getTriangle(iTri)
                    aFacePoints[j,a,s] = iPoints
                    aFaceBarys[j,a,s] = [fB1, fB2, 1-fB1-fB2]


        if iAxeErrorCounter >= 2:
            bIsOutsideMesh[j] = True
            aTwoPoints[j,0] = True
            mClosestPoint, iFace = mMeshFn.getClosestPoint(mFromPoint, space=OpenMaya2.MSpace.kWorld)
            mDir = OpenMaya2.MFloatVector(mClosestPoint - mFromPoint).normalize()
            xxIntersectResult = mMeshFn.allIntersections(mFromFloatPoint, mDir, OpenMaya2.MSpace.kWorld, 100000, False, accelParams=mAccelParams)
            if utils.isNone(xxIntersectResult) or not xxIntersectResult[1]:
                mPoints, fIntersectParams, iFaces = [mClosestPoint], [OpenMaya2.MFloatVector(mClosestPoint - mFromPoint).length()], [iFace]
            else:
                mPoints, fIntersectParams, iFaces, iTriangles, fBary1, fBary2 = xxIntersectResult

            aIntersectParams = np.array(fIntersectParams, dtype='float64')
            aIntersectParamOrder = np.argsort(aIntersectParams)

            # skip params that are too close together
            iUsedIntersectParams = [aIntersectParamOrder[0]]
            for i in range(1,aIntersectParamOrder.size,1):
                if abs(aIntersectParams[aIntersectParamOrder[i]]-aIntersectParams[aIntersectParamOrder[0]]) > 0.000001:
                    iUsedIntersectParams.append(aIntersectParamOrder[i])
                    break

            for s,p in enumerate(iUsedIntersectParams):
                aHits[j,0,s] = [mPoints[p].x, mPoints[p].y, mPoints[p].z]
                fParam = fIntersectParams[p]
                fOutsideParams[j].append(fParam)

                iFace = iFaces[p]
                mMeshIter.setIndex(iFace)
                _, iPoints = mMeshIter.getTriangle(iTriangles[p])
                aFacePoints[j,0,s] = iPoints

                aFaceBarys[j,0,s] = [fBary1[p], fBary2[p], 1.0-fBary1[p]-fBary2[p]]
                iOutsideFacePoints[j].append(np.array(iPoints))
                iOutsideHits[j].append(np.array([mPoints[p].x, mPoints[p].y, mPoints[p].z], dtype='float64'))
                fOutsideBarys[j].append(np.array([fBary1[p], fBary2[p], 1.0-fBary1[p]-fBary2[p]], dtype='float64'))
                if s == 0 and bOrients[j] or len(iUsedIntersectParams) == 1:
                    fps = aMeshPoints[iPoints]
                    fp = np.array([mPoints[p].x, mPoints[p].y, mPoints[p].z], dtype='float64').reshape(-1,3)
                    aDists = np.sum(np.square(fps - fp), axis=1)
                    furthestVertex = iPoints[int(np.argmax(aDists))]
                    xClosestOutsideIndices.append([iPoints, aFaceBarys[j,0,s], furthestVertex])


    aParamSums = np.sum(aParams, axis=-1)
    aParamSums = np.where(aParamSums >= 0, aParamSums, np.inf)

    aBary2D = 1 - aParams / aParamSums[...,np.newaxis]
    aShortest = np.argsort(aParamSums, axis=-1)
    aMainAxes = aShortest[:,0]

    aSelectedBary2D = aBary2D[aJointRange, aMainAxes]
    aSelectedHits = aHits[aJointRange, aMainAxes]
    aLongerHits = np.argmin(aSelectedBary2D, axis=-1)
    aAimHits = aSelectedHits[aJointRange, aLongerHits]
    aUpAxes = aShortest[:,1]
    aUpBary2D = aBary2D[aJointRange, aUpAxes]
    aLongerUps = np.argmax(aUpBary2D, axis=-1) # used to be argmin
    aUpHits = aHits[aJointRange, aUpAxes]
    aUpHits = aUpHits[aJointRange, aLongerUps]


    aTargetPositions = np.array(cmds.xform('%s.vtx[*]' % sTargetMesh, q=True, ws=True, t=True)).reshape(-1,3)
    aAllHitsTarget = aTargetPositions[aFacePoints] * aFaceBarys[...,np.newaxis]
    aAllHitsTarget = np.sum(aAllHitsTarget, axis=-2)

    aHitsTarget = aAllHitsTarget[aJointRange,aMainAxes]
    aUpHitsTarget = aAllHitsTarget[aJointRange,aUpAxes]
    aUpHitsTarget = aUpHitsTarget[aJointRange, aLongerUps]
    aAimHitsTarget = aHitsTarget[aJointRange, aLongerHits]
    aNewOrigins = aHitsTarget * aSelectedBary2D[...,np.newaxis]
    aNewOrigins = np.sum(aNewOrigins, axis=-2)

    aSourceoutsideOrientMatrices = []
    aTargetOutsideOrientMatrices = []
    for i, xData in enumerate(xClosestOutsideIndices):
        iTrianglePoints, fBarys, iFurthestVertex = xData
        aMainPoint = np.sum(aMeshPoints[iTrianglePoints] * np.array(fBarys, dtype='float64')[:,np.newaxis], axis=0)
        aNormal = barycentric.getNormalFrom3Points(aMeshPoints[iTrianglePoints])
        aFurthestVertex = aMeshPoints[iFurthestVertex] - aMainPoint
        aCross = np.cross(aNormal, aFurthestVertex)
        aMatrix = utils.numpyMatrixFromVectors(aMainPoint, aNormal, aFurthestVertex, aCross)
        aSourceoutsideOrientMatrices.append(aMatrix)

        aMainPoint = np.sum(aMeshPointsTarget[iTrianglePoints] * np.array(fBarys, dtype='float64')[:,np.newaxis], axis=0)
        aNormal = barycentric.getNormalFrom3Points(aMeshPointsTarget[iTrianglePoints])
        aFurthestVertex = aMeshPointsTarget[iFurthestVertex] - aMainPoint
        aCross = np.cross(aNormal, aFurthestVertex)
        aMatrix = utils.numpyMatrixFromVectors(aMainPoint, aNormal, aFurthestVertex, aCross)
        aTargetOutsideOrientMatrices.append(aMatrix)

    iOutsideOrientCounter = 0

    try:
        cmds.undoInfo(openChunk=True)
        for j, sJoint in enumerate(sJoints):
            if not bIsOutsideMesh[j]:
                aTargetPos = aNewOrigins[j]
                cmds.move(aTargetPos[0], aTargetPos[1], aTargetPos[2], sJoint, a=True)

                if bOrients[j]:
                    aPos = aJointMatrices[j][3,0:3]
                    aParent = utils.numpyMatrixFromVectors(aPos, aAimHits[j] - aPos, aUpHits[j] - aPos, bNormalize=True)
                    aParentTarget = utils.numpyMatrixFromVectors(aTargetPos, aAimHitsTarget[j] - aTargetPos, aUpHitsTarget[j] - aTargetPos, bNormalize=True)

                    aLocalMatrix = np.dot(aJointMatrices[j], np.linalg.inv(aParent))
                    aNewMatrix = np.dot(aLocalMatrix, aParentTarget)
                    sTemp = cmds.createNode('transform')
                    cmds.xform(sTemp, m=list(aNewMatrix.flatten()))
                    sConstr = cmds.orientConstraint(sTemp, sJoint)
                    cmds.delete(sTemp, sConstr)

            else:
                bFoundTwo = len(iOutsideFacePoints[j]) > 1

                if bFoundTwo:
                    a0 = fOutsideParams[j][1] - fOutsideParams[j][0]
                    b0 = fOutsideParams[j][0]
                    aVectorTarget = np.array([aAllHitsTarget[j,0,0][0] - aAllHitsTarget[j,0,1][0],
                                              aAllHitsTarget[j,0,0][1] - aAllHitsTarget[j,0,1][1],
                                              aAllHitsTarget[j,0,0][2] - aAllHitsTarget[j,0,1][2]], dtype='float64')
                    fVectorLength = np.linalg.norm(aVectorTarget)
                    aVectorTarget /= fVectorLength
                    b1 = b0 * (fVectorLength/a0)
                    aFinalPoint = aAllHitsTarget[j,0,0] + aVectorTarget * b1
                    cmds.move(aFinalPoint[0], aFinalPoint[1], aFinalPoint[2], sJoint, a=True)

                if bOrients[j] or not bFoundTwo:
                    aLocalMatrix = np.dot(aJointMatrices[j] , np.linalg.inv(aSourceoutsideOrientMatrices[iOutsideOrientCounter]))
                    aNewMatrix = np.dot(aLocalMatrix, aTargetOutsideOrientMatrices[iOutsideOrientCounter])
                    sTemp = cmds.createNode('transform')
                    cmds.xform(sTemp, m=list(aNewMatrix.flatten()))
                    if bOrients[j]: cmds.delete(cmds.orientConstraint(sTemp, sJoint))
                    if not bFoundTwo:
                        fTemp = cmds.xform(sTemp, q=True, ws=True, t=True)
                        cmds.move(fTemp[0], fTemp[1], fTemp[2], sJoint, a=True)
                        # cmds.delete(cmds.pointConstraint(sTemp, sJoint))
                    cmds.delete(sTemp)
                    iOutsideOrientCounter += 1

        cmds.select(sSelBefore)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def constraintLikeSkinCluster(sMesh, sTransforms, iMaxJoints=None):
    pMesh = patch.patchFromName(sMesh)
    sTransforms = np.array(utils.toList(sTransforms))
    aPoints = getPositionArray(sTransforms)
    aClosests = findClosestPoints(aPoints, pMesh.getPoints())
    aClosestSorted = np.argsort(aClosests)

    aClosests = aClosests[aClosestSorted]
    sTransforms = sTransforms[aClosestSorted]

    _, sInfluences, aWeights2d = pMesh.getSkinCluster(aOverrideIds=aClosests)

    for t, sT in enumerate(sTransforms):
        aW = aWeights2d[t]
        aNonZero = np.arange(len(aW))[aW > 0.0]

        if iMaxJoints:
            aSorted = np.argsort(aW)[::-1]
            aNonZero = aNonZero[aSorted[:iMaxJoints]]

        for iInfluence in aNonZero:
            sConstr = cmds.parentConstraint(sInfluences[iInfluence], sT, w=aW[iInfluence], mo=True)[0]
        cmds.setAttr('%s.interpType' % sConstr, 2)



def bugFixCleanConstraint2018(sJoint):
    '''
    in maya 2018 reparenting joints that have a constraint, moves them. This is an update problem,
    and deleting and reconnecting the constraintJointOrient attribute fixes it
    '''
    sConstraints = []
    for func in [cmds.parentConstraint, cmds.aimConstraint, cmds.orientConstraint]:
        sConstr = func(sJoint, q=True)
        if sConstr:
            sConstraints.append(sConstr)

    for sConstr in sConstraints:
        sAttr = '%s.constraintJointOrient' % sConstr
        sSourceAttrs = cmds.listConnections(sAttr, s=True, d=False, p=True)
        if sSourceAttrs:
            sSource = sSourceAttrs[0]
            cmds.disconnectAttr(sSource, sAttr)
            cmds.connectAttr(sSource, sAttr)


def getClosestIdsFromPoints(sMesh, aPoints, aSkipVerts=None, bReturnDistances=False):
    if not cmds.objExists(sMesh):
        raise Exception('mesh doesn\'t exist: %s' % sMesh)
    bAddOne = False
    if len(aPoints) == 0:
        return []
    elif len(aPoints) == 1:
        bAddOne = True
        aPoints = list(aPoints)
        aPoints.append([0,0,0])

    sCurve = cmds.curve(p=aPoints, d=1)

    if not utils.isNone(aSkipVerts):# != None:
        sSkipComponents = ' '.join(utils.createMayaStringFromList(aSkipVerts))
    else:
        sSkipComponents = None


    fClosest = cmds.kt_findClosestPoints(fromMesh=sCurve, toMesh=sMesh, vertex=True, returnDistances=bReturnDistances, skip=sSkipComponents)
    if bAddOne:
        fClosest = fClosest[:(-2 if bReturnDistances else -1)]

    cmds.delete(sCurve)

    if bReturnDistances:
        return np.array(fClosest[::2], dtype=int), np.array(fClosest[1::2], dtype='float64')
    else:
        return np.array(fClosest, dtype=int)


def getClosestInfoFromPoints(sMesh, aPoints, bReturnNormals=False, bReturnFaces=False, bVertex=False):
    bAddOne = False

    iOrigCount = len(aPoints)

    if len(aPoints) == 0:
        return []
    elif len(aPoints) == 1:
        bAddOne = True
        aPoints = list(aPoints)
        aPoints.append([0,0,0])
    print('aPoints: ', aPoints)
    sCurve = cmds.curve(p=aPoints, d=1)

    fClosest = cmds.kt_findClosestPoints(fromMesh=sCurve, toMesh=sMesh, vertex=bVertex, returnFaces=bReturnFaces, returnNormals=bReturnNormals)
    if bAddOne:
        fClosest = fClosest[:-1]

    cmds.delete(sCurve)

    return np.array(fClosest, dtype='float64').reshape(iOrigCount,-1)


def getClosestAxis(sTransform, sFromTransform, iFromAxis, bSigned=False):
    aMatrix = getNumpyMatrixFromTransform(sTransform)[0:3,0:3]
    aVectors = np.concatenate([aMatrix, -aMatrix])
    aFromMatrix = getNumpyMatrixFromTransform(sFromTransform)[0:3,0:3]
    aFromPos = aFromMatrix[iFromAxis]
    iClosestAxis = findClosestPoints([aFromPos], aVectors)[0]
    if bSigned:
        return iClosestAxis
    else:
        return iClosestAxis % 3


def jointOrientToRotation(sJoints):
    for sJoint in utils.toList(sJoints):
        fJointOrient = cmds.getAttr('%s.jo' % sJoint)[0]
        if abs(fJointOrient[0]) > 0.0001 or abs(fJointOrient[1]) > 0.0001 or abs(fJointOrient[2]) > 0.0001:
            sTemp = cmds.createNode('transform')
            cmds.delete(cmds.orientConstraint(sJoint, sTemp))
            cmds.setAttr('%s.jo' % sJoint, 0,0,0)
            try:
                cmds.delete(cmds.orientConstraint(sTemp, sJoint))
            except Exception as e:
                cmds.warning('couldn\'t orient %s - %s' % (sJoint, e))
            cmds.delete(sTemp)



# DEPRICATED! Please use the same function from constraints.py
def matrixParentConstraint(sMaster, sChild, mo=False, skipTranslate=[], skipRotate=[], skipScale=[], bChildParentIsInOrigin=False,
                           sParentAttr='matrixParentConstraintTarget', bJustReturnMatrix=False, bForce=False, bAvoidCycle=False, bKeepJointOrient=False, sJumpOverTransforms=[]):

    if skipTranslate == True:
        skipTranslate = ['x','y','z']
    if skipRotate == True:
        skipRotate = ['x','y','z']
    if skipScale == True:
        skipScale = ['x','y','z']


    if cmds.objectType(sChild) == 'joint':
        if not bKeepJointOrient:
            cmds.setAttr('%s.jo' % sChild, lock=False)
            jointOrientToRotation(sChild)
            cmds.setAttr('%s.jo' % sChild, lock=True)

    if bAvoidCycle:
        sParents = cmds.listRelatives(sChild, p=True, c=False)
        if sParents:
            sParentInverse = '%s.worldInverseMatrix' % sParents[0]
        else:
            sParentInverse = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0]
    else:
        sParentInverse = '%s.parentInverseMatrix' % sChild


    if mo == True:
        fOffset = utils.multiplyMatrixAttrValues([cmds.getAttr('%s.worldMatrix' % sChild), cmds.getAttr('%s.worldInverseMatrix' % sMaster)])
        if bChildParentIsInOrigin:
            sMultiply = nodes.createMultMatrixNode([fOffset,
                                                    '%s.worldMatrix' % sMaster], sName='PC_%s_' % sMaster)
        else:
            if sJumpOverTransforms:
                sMultiply = nodes.createMultMatrixNode([fOffset,
                                                        '%s.worldMatrix' % sMaster,
                                                        '%s.worldInverseMatrix' % sJumpOverTransforms[0],
                                                        '%s.worldMatrix' % sJumpOverTransforms[1],
                                                        sParentInverse], sName='PC_%s_' % sMaster)
            else:
                sMultiply = nodes.createMultMatrixNode([fOffset,
                                                        '%s.worldMatrix' % sMaster,
                                                        sParentInverse], sName='PC_%s_' % sMaster)

    else:
        if bChildParentIsInOrigin:
            sMultiply = '%s.worldMatrix' % sMaster
        else:
            if sJumpOverTransforms:
                sMultiply = nodes.createMultMatrixNode(['%s.worldMatrix' % sMaster,
                                                        '%s.worldInverseMatrix' % sJumpOverTransforms[0],
                                                        '%s.worldMatrix' % sJumpOverTransforms[1],
                                                        sParentInverse], sName='PC_%s_' % sMaster)
            else:
                sMultiply = nodes.createMultMatrixNode(['%s.worldMatrix' % sMaster,
                                                        sParentInverse], sName='PC_%s_' % sMaster)

    if bJustReturnMatrix:
        return sMultiply
    else:
        sDecompose = nodes.createDecomposeMatrix(sMultiply, sName='PC_%s_' % sMaster).split('.')[0]
        if not skipTranslate:
            cmds.connectAttr('%s.outputTranslate' % sDecompose, '%s.t' % sChild, force=bForce)
        else:
            for a, sAxis in enumerate(['x','y','z']):
                if sAxis not in skipTranslate:
                    cmds.connectAttr('%s.outputTranslate%s' % (sDecompose, sAxis.upper()), '%s.t%s' % (sChild, sAxis), force=bForce)

        if not skipRotate:
            if bKeepJointOrient:
                try:
                    cmds.setAttr('%s.jo' % sChild, lock=True)
                except: pass
                sJointOrientToQuat = cmds.createNode('eulerToQuat', n='jointOrientToQuad')
                nodes._connectOrSetVector('%s.jo' % sChild, '%s.inputRotate' % sJointOrientToQuat)
                sQuatInverse = cmds.createNode('quatInvert', n='quatInvert')
                cmds.connectAttr('%s.outputQuat' % sJointOrientToQuat, '%s.inputQuat' % sQuatInverse)
                sQuatProduct = cmds.createNode('quatProd', n='quatProd')
                cmds.connectAttr('%s.outputQuat' % sDecompose, '%s.input1Quat' % sQuatProduct)
                cmds.setAttr('%s.input2Quat' % sQuatProduct, *cmds.getAttr('%s.outputQuat' % sQuatInverse)[0])
                nodes.createQuatToEulerNode('%s.outputQuat' % sQuatProduct, '%s.r' % sChild, bForce=bForce)
                cmds.delete(sJointOrientToQuat, sQuatInverse)
            else:
                cmds.connectAttr('%s.outputRotate' % sDecompose, '%s.r' % sChild, force=bForce)
        else:
            for a, sAxis in enumerate(['x','y','z']):
                if sAxis not in skipRotate:
                    cmds.connectAttr('%s.outputRotate%s' % (sDecompose, sAxis.upper()), '%s.r%s' % (sChild, sAxis), force=bForce)

        if not skipScale:
            cmds.connectAttr('%s.outputScale' % sDecompose, '%s.s' % sChild, force=bForce)
        else:
            for a, sAxis in enumerate(['x','y','z']):
                if sAxis not in skipScale:
                    cmds.connectAttr('%s.outputScale%s' % (sDecompose, sAxis.upper()), '%s.s%s' % (sChild, sAxis), force=bForce)


        utils.addStringAttr(sDecompose.split('.')[0], sParentAttr, sMaster)
        utils.addStringAttr(sMultiply.split('.')[0], sParentAttr, sMaster)

        return sMultiply, sDecompose

def getWorldRoot(sNode):
    for i in range(100000):
        sParents = cmds.listRelatives(sNode, p=True, c=False)
        if not sParents:
            return sNode
        else:
            sNode = sParents[0]
    raise Exception('no parent found')



def intersectionPlaneRay(sPlanePoint, sPlaneNormal, sRayPoint, sRayDirection):
    sPlaneNormal = nodes.createNormalizedVector(sPlaneNormal)
    sRayDirection = nodes.createNormalizedVector(sRayDirection)

    ndotu = nodes.createDotProductNode(sPlaneNormal, sRayDirection)
    w = nodes.createVectorAdditionNode([sRayPoint, sPlanePoint], sOperation='minus')
    sDot = nodes.createDotProductNode(sPlaneNormal, w)
    si = nodes.fromEquation('-%s / %s' % (sDot, ndotu))
    return nodes.createVectorAdditionNode([w,
                                           nodes.createVectorMultiplyNode(sRayDirection, si, bVectorByScalar=True),
                                           sPlanePoint])




def intersectionSphereLine(xLineA, xLineB, sSphereMatrix, xRadius, bIgnoreFirst=False, bIgnoreSecond=False, sName='noname'):

    sSphereInverseMatrix = nodes.createInverseMatrix(sSphereMatrix, sName=sName)
    xLineA = nodes.createPointByMatrixNode(xLineA, sSphereInverseMatrix, sName='%sPointA' % sName)
    xLineB = nodes.createPointByMatrixNode(xLineB, sSphereInverseMatrix, sName='%sPointB' % sName)

    sLineDiff = nodes.createVectorAdditionNode([xLineB, xLineA], sOperation='minus', sName='%sLineDiff' % sName)
    a = nodes.createDotProductNode(sLineDiff, sLineDiff, sName='%s_a' % sName)

    sSphereMultSum = nodes.createDotProductNode(sLineDiff, xLineA, sName='%sSphereMultSum' % sName)
    b = nodes.createMultiplyNode(2, sSphereMultSum, sName='%s_b' % sName)

    sLineSquareASum = nodes.createDotProductNode(xLineA, xLineA, sName='%sPointASquareSum' % sName)
    # c got simplified after book because sphere center is at 0
    c = nodes.fromEquation('{0} - {1}^2'.format(sLineSquareASum, xRadius), sName='%s_c' % sName)

    sRoot = nodes.fromEquation('({1}^2 - 4*{0}*{2}) ^ 0.5'.format(a, b, c), sName='%sRoot' % sName)
    sDenom = nodes.createMultiplyNode(a, 2.0, sName='%sDenom' % sName)

    if bIgnoreFirst:
        sOutA = None
    else:
        sTa = nodes.fromEquation('(-%s + %s) / %s' % (b, sRoot, sDenom), sName='%sTa' % sName)
        sPointA = nodes.createVectorAdditionNode([xLineA,
                                        nodes.createVectorMultiplyNode(sLineDiff, sTa, bVectorByScalar=True)], sName='%sPointA' % sName)
        sOutA = nodes.createPointByMatrixNode(sPointA, sSphereMatrix, sName='%sOutA' % sName)

    if bIgnoreSecond:
        sOutB = None
    else:
        sTb = nodes.fromEquation('(-%s - %s) / %s' % (b, sRoot, sDenom), sName='%sTb' % sName)
        sPointB = nodes.createVectorAdditionNode([xLineA,
                                        nodes.createVectorMultiplyNode(sLineDiff, sTb, bVectorByScalar=True)], sName='%sPointB' % sName)
        sOutB = nodes.createPointByMatrixNode(sPointB, sSphereMatrix, sName='%sOutB' % sName)

    return sOutA, sOutB



def intersectionSphereRay(xPoint, sDirNormalized, xSphereMatrix, xRadius, bReturnSecondPoint=False, sName='noname'):

    if bReturnSecondPoint:
        sDirNormalized = nodes.createVectorMultiplyNode(sDirNormalized, -1, bVectorByScalar=True, sName='%sNegatedForSecondPoint' % sName)

    sDirPoint = nodes.createVectorAdditionNode([xPoint, sDirNormalized], sName='%sDirPoint' % sName)

    sSphereInverseMatrix = nodes.createInverseMatrix(xSphereMatrix, sName='%sInverseMatrix' % sName)

    xPoint = nodes.createPointByMatrixNode(xPoint, sSphereInverseMatrix, sName='%sPoint' % sName)
    sDirPoint = nodes.createPointByMatrixNode(sDirPoint, sSphereInverseMatrix, sName='%sDirPoint' % sName)
    sDir = nodes.createVectorAdditionNode([sDirPoint, xPoint], sOperation='minus', sName='%sDir' % sName)
    sDirNormalized = nodes.createNormalizedVector(sDir, bSafe=True, sName='%sDirNormalized' % sName)

    sE = nodes.createVectorAdditionNode([[0, 0, 0], xPoint], sOperation='minus', sName='%s_e' % sName)
    sSquaredE = nodes.createDotProductNode(sE, sE, sName='%sSquareE' % sName)
    sA = nodes.createDotProductNode(sE, sDirNormalized, sName='%s_a' % sName)
    sF = nodes.fromEquation('(%s^2 - %s + %s^2)^0.5' % (xRadius, sSquaredE, sA), sName='%s_f' % sName)

    sT = nodes.createAdditionNode([sA, sF], sOperation='minus', sName='%s_t' % sName)
    sPointA = nodes.createVectorAdditionNode([xPoint,
                                              nodes.createVectorMultiplyNode(sDirNormalized, sT, bVectorByScalar=True)], sName='%s_pointA' % sName)

    return nodes.createPointByMatrixNode(sPointA, xSphereMatrix, sName='%sOut' % sName)



def createBellCollider(sRingerJoint, sBellJoint, sSide, sName, fRingerScale=[15,1,1], fBellScale=[5,3,3], sBellOutJoint=None, sParent=None, bOutIsJoint=False, sCtrlForSwitch=None, fUpVector=[0,1,0]):
    '''
    TODO: make it work for unregular shapes. Currently the Circles aren't doing anything. Maybe they can be removed??
    :param sRingerJoint:
    :param sBellJoint:
    :param sSide:
    :param sName:
    :param fRingerScale:
    :param fBellScale:
    :param sBellOutJoint:
    :param sParent:
    :param bOutIsJoint:
    :param sCtrlForSwitch:
    :return:
    '''
    sFullName = '%s_%s' % (sSide, sName)

    sGroup = cmds.createNode('transform', n='grp_%sbellCollider' % sFullName)

    fSideMultipl = -1.0 if sSide == 'r' else 1.0

    if utils.isNone(sBellOutJoint):
        sBellOutJoint = cmds.duplicate(sBellJoint, n='%s_bellCollided', po=True)[0]
        cmds.parent(sBellOutJoint, sGroup)

    def _createCylinder(sName, bAddBaseCircle=False, bAddTopCircle=False):
        sCylinder = cmds.cylinder(n=sName)[0]
        # cmds.setAttr('%s.rz' % sCylinder, 90)
        cmds.setAttr('%s.tx' % sCylinder, 0.5)
        cmds.setAttr('%s.sx' % sCylinder, 0.5)
        cmds.move(0, 0, 0, ['%s.scalePivot' % sCylinder, '%s.rotatePivot' % sCylinder], a=True)
        cmds.makeIdentity(sCylinder, t=True, r=True, s=True, apply=True)

        cmds.parent(sCylinder, sGroup)
        # iFacesCount = cmds.polyEvaluate(sCylinder, face=True)
        # cmds.delete('%s.f[%d]' % (sCylinder, iFacesCount-1), '%s.f[%d]' % (sCylinder, iFacesCount-2))
        cmds.delete(sCylinder, ch=True)

        if bAddBaseCircle:
            sBaseCircle = cmds.circle(n='%s_circle' % sName)[0]
            cmds.setAttr('%s.ry' % sBaseCircle, 90)
            cmds.makeIdentity(sBaseCircle, t=True, r=True, s=True, apply=True)
            cmds.delete(sBaseCircle, ch=True)

        if bAddTopCircle:
            sTopCircle = cmds.circle(n='%s_topCircle' % sName)[0]
            cmds.setAttr('%s.ry' % sTopCircle, 90)
            cmds.setAttr('%s.tx' % sTopCircle, 1.0)
            cmds.makeIdentity(sTopCircle, t=True, r=True, s=True, apply=True)
            cmds.delete(sTopCircle, ch=True)

        if False:
            xDirections = [('front', 1, True),
                           ('back', 1, False),
                           ('out', 2, True),
                           ('in', 2, False)]
            sTargets = []
            sBaseCircleTargets = []
            sTopCircleTargets = []

            xGeos = [(sCylinder, sTargets)]
            if bAddBaseCircle:
                xGeos.append((sBaseCircle, sBaseCircleTargets))
            if bAddTopCircle:
                xGeos.append((sTopCircle, sTopCircleTargets))

            for sGeo, sList in xGeos:
                for sDirection, iAxis, bPositive in xDirections:
                    pGeo = patch.patchFromName(sGeo)
                    aDefaultPoints = pGeo.getAllPoints(bWorld=False)
                    aPoints = np.copy(aDefaultPoints)
                    aScalePointIds = np.where(aPoints[:,iAxis] > 0)[0] if bPositive else np.where(aPoints[:,iAxis] < 0)[0]
                    aPoints[aScalePointIds,iAxis] *= 2.0
                    sTarget = cmds.duplicate(sGeo, n='cylinderScale_%s' % sDirection)[0]
                    patch.patchFromName(sTarget).setPoints(aPoints, aIds=np.arange(len(aPoints)), bWorld=False)
                    sList.append(sTarget)

            for sGeo, sList in xGeos:
                sBlendShape = cmds.blendShape(sList + [sGeo])[0]
                sTargetAttrs = cmds.aliasAttr(sBlendShape, q=True)[::2]
                for d, sTargetAttr in enumerate(sTargetAttrs):
                    sAttr = utils.addAttr(sCylinder, ln='scale%s' % xDirections[d][0].title(), min=0.1, dv=1.0, k=False, bReturnIfExists=True)
                    nodes.createAdditionNode([sAttr, -1], sTarget='%s.%s' % (sBlendShape, sTargetAttr))
                cmds.delete(sList)

        sReturn = [sCylinder]
        if bAddBaseCircle:
            sReturn.append(sBaseCircle)
            cmds.parent(sBaseCircle, sCylinder)
        if bAddTopCircle:
            sReturn.append(sTopCircle)
            cmds.parent(sTopCircle, sCylinder)

        if not bAddBaseCircle and not bAddTopCircle:
            return sCylinder
        else:
            return sReturn

    sRingerCylinder = _createCylinder('%sRinger' % sFullName)
    cmds.setAttr('%s.s' % sRingerCylinder, *fRingerScale)
    sSideScaleMatrix = nodes.createComposeMatrixNode(xScale=[fSideMultipl, fSideMultipl, fSideMultipl])
    nodes.createMultMatrixNode([sSideScaleMatrix, '%s.worldMatrix' % sRingerJoint], sTarget='%s.offsetParentMatrix' % sRingerCylinder)

    sBellCylinder = _createCylinder('%sBell' % sFullName)

    sMultiplyFront = utils.addAttr(sBellCylinder, ln='multiplyFront', min=0.0, dv=1.0, k=True)
    sMultiplyBack = utils.addAttr(sBellCylinder, ln='multiplyBack', min=0.0, dv=1.0, k=True)
    sMultiplyOut = utils.addAttr(sBellCylinder, ln='multiplyOut', min=0.0, dv=1.0, k=True)
    sMultiplyIn = utils.addAttr(sBellCylinder, ln='multiplyIn', min=0.0, dv=1.0, k=True)

    cmds.setAttr('%s.v' % sBellCylinder, False)
    cmds.setAttr('%s.s' % sBellCylinder, *fBellScale)
    cmds.connectAttr('%s.worldMatrix' % sBellJoint, '%s.offsetParentMatrix' % sBellCylinder)

    sBellCylinderOut = _createCylinder('%sBellOut' % sFullName) #, sJoint=sGroup)
    if bOutIsJoint:
        nodes.createMultMatrixNode([sSideScaleMatrix, '%s.worldMatrix' % sBellOutJoint], sTarget='%s.offsetParentMatrix' % sBellCylinderOut)
    else:
        cmds.connectAttr('%s.worldMatrix' % sBellOutJoint, '%s.offsetParentMatrix' % sBellCylinderOut)

    for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:#, 'scaleFront', 'scaleBack', 'scaleIn', 'scaleOut']:
        cmds.connectAttr('%s.%s' % (sBellCylinder, sA), '%s.%s' % (sBellCylinderOut, sA))

    sRingerMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sRingerCylinder, '%s.worldInverseMatrix' % sBellCylinder])
    sInverseRingerMatrix = nodes.createInverseMatrix(sRingerMatrix)
    sRingerRotationMatrix = nodes.createPickMatrixNode(sRingerMatrix, bRotate=True, bScale=True)
    sRingerPosition = nodes.createDecomposeMatrix(sRingerMatrix)

    sDirectionOfRinger = nodes.createPointByMatrixNode([1,0,0], sRingerRotationMatrix)
    sDirectionOfRingerOrigLength = [0, '%sY' % sDirectionOfRinger, '%sZ' % sDirectionOfRinger]
    sDirectionOfRingerNormalized = nodes.createNormalizedVector(sDirectionOfRingerOrigLength)
    createLocator('direction', xPos=sDirectionOfRingerNormalized, sParent=sBellCylinder, fSize=0.1)


    # get bell points
    #
    if False:
        sCollapsedBell = nodes.createComposeMatrixNode(xScale=[0.001,
                                                               nodes.createMaximumNode(['%s.scaleFront' % sBellCylinder, '%s.scaleBack' % sBellCylinder]),
                                                               nodes.createMaximumNode(['%s.scaleIn' % sBellCylinder, '%s.scaleIn' % sBellCylinder])])
    else:
        sCollapsedBell = nodes.createComposeMatrixNode(xScale=[0.001, 1.0, 1.0])

    sBottomBellIntersected = intersectionSphereRay([0, '%sY' % sRingerPosition, '%sZ' % sRingerPosition],
                                                   sDirectionOfRingerNormalized, sCollapsedBell, 1.0, bReturnSecondPoint=True)

    if False:
        _, sBottomBellIntersectedOnCircleWorld = curves.createClosestPointNode(sBellCircle,
                                      nodes.createPointByMatrixNode(sBottomBellIntersected, '%s.worldMatrix' % sBellCylinder))
        sBottomBellIntersected = nodes.createPointByMatrixNode(sBottomBellIntersectedOnCircleWorld, '%s.worldInverseMatrix' % sBellCylinder)
    sTopBellPoint = nodes.createVectorAdditionNode([sBottomBellIntersected, [1, 0, 0]])

    createLocator('bellTop', xPos=sTopBellPoint, sParent=sBellCylinder, fSize=0.1)
    createLocator('bellBot', xPos=sBottomBellIntersected, sParent=sBellCylinder, fSize=0.1)

    # get ringer points
    #
    sAimPointOfRinger = nodes.createVectorAdditionNode([[0, '%sY' % sRingerPosition, '%sZ' % sRingerPosition], sDirectionOfRingerNormalized])
    createLocator('sAimPointOfRinger', xPos=sAimPointOfRinger, sParent=sBellCylinder, fSize=0.1)
    sAimPointOfRingerInRinger = nodes.createPointByMatrixNode(sAimPointOfRinger, sInverseRingerMatrix)
    sAimPointOfRingerInRingerNormalized = nodes.createNormalizedVector([0, '%sY' % sAimPointOfRingerInRinger, '%sZ' % sAimPointOfRingerInRinger])
    # aimMatrix is used to calculate if we should flip or not:
    sRingerAimMatrix = nodes.createAimMatrixNode(sRingerMatrix, sDirectionOfRinger, [1,0,0], bAlignAim=True)
    sAimPointOfRingerInAimMatrix = nodes.createPointByMatrixNode(sAimPointOfRinger, nodes.createInverseMatrix(sRingerAimMatrix))
    sFlipValue = nodes.createConditionNode('%sY' % sAimPointOfRingerInAimMatrix, '>', 0, -1.0, 1.0 )
    sAimPointOfRingerInRingerNormalized = nodes.createVectorMultiplyNode(sAimPointOfRingerInRingerNormalized, sFlipValue, bVectorByScalar=True)
    sBottomRingerPoint = nodes.createPointByMatrixNode(sAimPointOfRingerInRingerNormalized, sRingerMatrix)
    sTopRingerPoint = nodes.createPointByMatrixNode([1, '%sY' % sAimPointOfRingerInRingerNormalized, '%sZ' % sAimPointOfRingerInRingerNormalized], sRingerMatrix)
    createLocator('ringerBot', xPos=sBottomRingerPoint, sParent=sBellCylinder, fSize=0.1)
    createLocator('ringerTop', xPos=sTopRingerPoint, sParent=sBellCylinder, fSize=0.1)

    # get the rotate to point
    #
    sRotateToWorld, _ = intersectionSphereLine(nodes.createPointByMatrixNode(sBottomRingerPoint, '%s.worldMatrix' % sBellCylinder),
                                          nodes.createPointByMatrixNode(sTopRingerPoint, '%s.worldMatrix' % sBellCylinder),
                                        sSphereMatrix=nodes.createPickMatrixNode('%s.worldMatrix' % sBellCylinder, bTranslate=True),
                                        xRadius=nodes.createDistanceNode(nodes.createDecomposeMatrix('%s.worldMatrix' % sBellCylinder), nodes.createPointByMatrixNode(sTopBellPoint, '%s.worldMatrix' % sBellCylinder)),
                                        bIgnoreSecond=True, sName='%sBellCollider' % sFullName)
    sRotateTo = nodes.createPointByMatrixNode(sRotateToWorld, '%s.worldInverseMatrix' % sBellCylinder)


    createLocator('sRotateTo', xPos=sRotateTo, sParent=sBellCylinder, fSize=0.1)

    # do the rotation
    #
    sBellToOrigin = nodes.createMultMatrixNode(['%s.worldMatrix' % sBellCylinder, '%s.worldInverseMatrix' % sBellJoint])
    sRotateFromInOrigin = nodes.createPointByMatrixNode(sTopBellPoint, sBellToOrigin)
    sRotateToInOrigin = nodes.createPointByMatrixNode(sRotateTo, sBellToOrigin)

    sCross = nodes.createCrossProductNode(sRotateFromInOrigin, sRotateToInOrigin, sName='%sAxisAngleAxis' % sFullName)
    sAngle = nodes.createAngleNode(sRotateFromInOrigin, sRotateToInOrigin, sName='%sAngle' % sFullName)
    sPushedQuat = nodes.createAxisAngleToQuatNode(sCross, sAngle, sName='%sPushedQuaternion' % sFullName)
    sPushedEuler = nodes.createQuatToEulerNode(sPushedQuat, sName='%sPushedEuler' % sFullName)

    sCondHighEnough = nodes.createConditionNode('%sX' % sRotateToInOrigin, '<', '%sX' % sRotateFromInOrigin,
                                                sPushedEuler, [0,0,0], bVector=True, sName='%sHighEnough' % sFullName)
    sCondMoved = nodes.createConditionNode(nodes.createDistanceNode([0,0,0], sDirectionOfRingerOrigLength), '>', 0.0001, sCondHighEnough, [0,0,0], sName='%sDidMove' % sFullName, bVector=True)
    sResultMatrix = nodes.createComposeMatrixNode(xRotate=sCondMoved)


    # direction multiply attributes
    #
    sResultAimTarget = nodes.createPointByMatrixNode([1,0,0], sResultMatrix)
    sResultAimTargetSeparated = ['%sX' % sResultAimTarget, '%sY' % sResultAimTarget, '%sZ' % sResultAimTarget]
    sResultAimTargetMultiplied = [sResultAimTargetSeparated[0], 0, 0]
    sResultAimTargetMultiplied[1] = nodes.createConditionNode(sResultAimTargetSeparated[1], '>', 0.0,
                                                       nodes.createMultiplyNode(sResultAimTargetSeparated[1], sMultiplyFront),
                                                       nodes.createMultiplyNode(sResultAimTargetSeparated[1], sMultiplyBack))
    sResultAimTargetMultiplied[2] = nodes.createConditionNode(sResultAimTargetSeparated[2], '>', 0.0,
                                                       nodes.createMultiplyNode(sResultAimTargetSeparated[2], sMultiplyOut),
                                                       nodes.createMultiplyNode(sResultAimTargetSeparated[2], sMultiplyIn))

    sResultAimMatrix = nodes.createAimMatrixNode(None, sResultAimTargetMultiplied, fUpVector, up=fUpVector)
    sInOriginPushedEuler = nodes.createMultMatrixNode([sResultAimMatrix, '%s.worldMatrix' % sBellJoint, '%s.parentInverseMatrix' % sBellOutJoint])

    if utils.isNone(sCtrlForSwitch):
        sBlendedOutMatrix = sInOriginPushedEuler
    else:
        sAttr = utils.addAttr(sCtrlForSwitch, ln='ringerCollision', min=0, max=1, dv=1, k=True)
        sBlendedOutMatrix = nodes.createBlendMatrixNode([utils.fIdentityMatrix, sInOriginPushedEuler],
                                                        [nodes.createReverseNode(sAttr), sAttr])
    nodes.createDecomposeMatrix(sBlendedOutMatrix, sTargetPos='%s.t' % sBellOutJoint, sTargetRot='%s.r' % sBellOutJoint)

    if sParent:
        cmds.parent(sGroup, sParent)
    cmds.setAttr('%s.inheritsTransform' % sGroup, False)
    resetTransform(sGroup)
    return sRingerCylinder, sBellCylinder, sBellCylinderOut


# depricated!!
def mirrorJoints(sJoints, bMirrorBehavior=True):
    # sJoints = cmds.ls(sl=True, et='joint')
    print('sJoints: ', sJoints)

    sJoints = getRoots(utils.toList(sJoints))
    sReturns = []
    for sJ in sJoints:
        if '_l_' in sJ or '_r_' in sJ:
            sReturns += cmds.mirrorJoint(sJ, mirrorYZ=True, searchReplace=('_l_', '_r_'), mirrorBehavior=bMirrorBehavior)
        elif 'Left' in sJ or 'Right' in sJ:
            sReturns += cmds.mirrorJoint(sJ, mirrorYZ=True, searchReplace=('Left', 'Right'), mirrorBehavior=bMirrorBehavior)
    return sReturns



# used for the slider blueprints. xMirrorAxis is for the case that a face is not at 0 or pointing to a different angle
# should be able to merge that with the mirrorJointHierarchy() function, and depricate this one
def mirrorJoint(sJoint, xMirrorAxis=None):
    aJointMatrix = np.array(cmds.xform(sJoint, q=True, m=True, ws=True)).reshape(4,4)

    if isinstance(xMirrorAxis, (list,tuple)):
        sMirrorJoint, iAxis = xMirrorAxis
        aParentMatrix = np.array(cmds.xform(sMirrorJoint, q=True, m=True, ws=True)).reshape(4,4)
        aJointMatrix = np.dot(aJointMatrix, np.linalg.inv(aParentMatrix))
        iAxis = iAxis % 3
        iOtherAxes = np.array([a for a in [0,1,2] if a != iAxis], dtype=int)
    else:
        iAxis = 0
        iOtherAxes = np.array([1,2], dtype=int)

    aJointMatrix[0,iOtherAxes] *= -1.0
    aJointMatrix[1,iOtherAxes] *= -1.0
    aJointMatrix[2,iOtherAxes] *= -1.0
    aJointMatrix[3,iAxis] *= -1.0

    if isinstance(xMirrorAxis, (list,tuple)):
        aJointMatrix = np.dot(aJointMatrix, aParentMatrix)

    sMirror = utils.getMirrorName(sJoint)
    cmds.duplicate(sJoint, n=sMirror)
    cmds.xform(sMirror, m=aJointMatrix.flatten(), ws=True)

    return sMirror


def mirrorJointHierarchy(sRoot, iAxis=0):
    
    sHierarchy = sorted(cmds.ls(sRoot, dag=True, et='joint', l=True), key=lambda a: len(a))
    
    iOtherAxes = np.array([1, 2], dtype=int)

    for j,sJ in enumerate(sHierarchy):
        aJointMatrix = np.array(cmds.xform(sJ, q=True, m=True, os=True)).reshape(4, 4)
    
        aJointMatrix[0, iOtherAxes] *= -1.0
        aJointMatrix[1, iOtherAxes] *= -1.0
        aJointMatrix[2, iOtherAxes] *= -1.0
        aJointMatrix[3, iAxis] *= -1.0
        
        sMirror = utils.getMirrorName(sJ.split('|')[-1])
        if not cmds.objExists(sMirror):
            cmds.duplicate(sJ, n=sMirror, po=True)
            sParents = cmds.listRelatives(sJ, p=True)
            if sParents:
                parentJointNoTransform(sMirror, utils.getMirrorName(sParents[0].split('|')[-1]), bSkipIfAlreadyUnderThatParent=True)
                utils.parentTo(sMirror, utils.getMirrorName(sParents[0].split('|')[-1]))
                
        cmds.xform(sMirror, m=aJointMatrix.flatten(), os=True)
        
        if j == 0:
            sReturn = sMirror
            
    return sReturn



def mirrorCurveTransforms(sTransforms, iAxis=0):
    sTransforms = utils.toList(sTransforms)

    iOtherAxes = np.array([1, 2], dtype=int)

    for j,sT in enumerate(sTransforms):
        aTransformMatrix = np.array(cmds.xform(sT, q=True, m=True, os=True)).reshape(4, 4)

        aTransformMatrix[0, iOtherAxes] *= -1.0
        aTransformMatrix[1, iOtherAxes] *= -1.0
        aTransformMatrix[2, iOtherAxes] *= -1.0
        aTransformMatrix[3, iAxis] *= -1.0

        sMirror = utils.getMirrorName(sT.split('|')[-1])
        if not cmds.objExists(sMirror):
            cmds.duplicate(sT, n=sMirror)
            sParents = cmds.listRelatives(sT, p=True)
            if sParents:
                utils.parentTo(sMirror, utils.getMirrorName(sParents[0].split('|')[-1]))

        cmds.xform(sMirror, m=aTransformMatrix.flatten(), os=True)
        cmds.scale(-1, -1, -1, '%s.cv[*]' % sMirror)

        if j == 0:
            sReturn = sMirror

    return sReturn


# this is for the 'mirror' shelf button
def mirrorJointsSelection():

    cmds.undoInfo(openChunk=True)
    try:
        sAllSel = cmds.ls(sl=True, et='joint')
        sMuscleJoints = [sJ for sJ in cmds.ls('muscleBp_*', sl=True, et='joint') if not sJ.endswith('End')]
        sNonMuscleJoints = list(set(sAllSel) - set(sMuscleJoints))
        
        for sJ in sNonMuscleJoints:
            mirrorJointHierarchy(sJ)
        
        
        sNewJoints = []
        if sMuscleJoints:

            for sJ in sMuscleJoints:
    
                if utils.getSide(sJ) == 'm':
                    continue
    
                sMirror = mirrorJointHierarchy(sJ)

                sNewJoints.append(sMirror)

                bFlipLimits = False
                for sAttr in ['startSpace', 'endSpace', 'endSpaceParent']:
                    sValue = utils.getMuscleAttrValue(sJ, sAttr)
                    if not utils.isNone(sValue):
                        cmds.setAttr('%s.%s' % (sMirror, sAttr), utils.getMirrorName(sValue), type='string')
                        if sAttr == 'endSpaceParent' and utils.getSide(sValue) != 'm':
                            bFlipLimits = True

                # old limits
                for sLoc in ['start', 'end']:
                    for sPart in ['min', 'max']:
                        for sA in ['X', 'Y', 'Z']:
                            sAttr = '%sLimit%s%s' % (sLoc,  # endLimitMinX
                                                     utils.getFirstLetterUpperCase(sPart), sA)
                            sSourceAttr = '%s.%s' % (sJ, sAttr)
                            sMirrorAttr = '%s.%s' % (sMirror, sAttr)
                            if cmds.objExists(sSourceAttr):
                                if not cmds.objExists(sMirrorAttr):
                                    utils.addAttr(sMirror, ln=sAttr)
                                cmds.setAttr(sMirrorAttr, cmds.getAttr(sSourceAttr))

                # new limits
                for sA in ['X', 'Y', 'Z']:
                    sSourceAttrs = '%s.EndLimitPos%s' % (sJ, sA), '%s.EndLimitNeg%s' % (sJ, sA)
                    for p,sPart in enumerate(['Pos', 'Neg']):
                        sAttr = 'EndLimit%s%s' % (sPart, sA)
                        sSourceAttr = sSourceAttrs[1-p if bFlipLimits else p]
                        if cmds.objExists(sSourceAttr):
                            sMirrorAttr = '%s.%s' % (sMirror, sAttr)
                            if not cmds.objExists(sMirrorAttr):
                                utils.addOffOnAttr(sMirror, sAttr)
                            cmds.setAttr(sMirrorAttr, cmds.getAttr(sSourceAttr))

        cmds.select(sNewJoints)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)





def reorientJoints(sJoints):
    sSelBefore = cmds.ls(sl=True)
    for sJ in sJoints:
        sChildren = cmds.listRelatives(sJ, c=True, f=True)
        if sChildren:
            fSignFromPrev = 1.0 if cmds.getAttr('%s.tx' % sChildren[0]) > 0.0 else -1.0
            sChildren = cmds.parent(sChildren, w=True)
            sUp = cmds.createNode('transform', p=sJ)
            cmds.setAttr('%s.t' % sUp, 0,1,0)
            cmds.parent(sUp, w=True)
            cmds.delete(cmds.aimConstraint(sChildren[0], sJ, aim=[fSignFromPrev,0,0], wu=[0,1,0], wut='object', wuo=sUp))
            cmds.parent(sChildren, sJ)
            cmds.delete(sUp)
        else:
            cmds.setAttr('%s.jo' % sJ, 0,0,0)
            cmds.setAttr('%s.r' % sJ, 0,0,0)
    cmds.select(sSelBefore)




"""

Projects model differences between 2 models onto a 3rd model

written by Thomas Bittner, 2016


projectModels(baseName, changeName, poseNames, undoSupport=False)
baseName: old model
changeName: new model
poseNames: list of poses where we want to project the differences to
undoSupport is super slow on larger meshes, and should only be used when debugging


"""

import maya.OpenMaya as OpenMaya
import math
import maya.cmds as cmds


def getDagPath(name):
    sel = OpenMaya.MSelectionList()
    sel.add(name);
    obj = OpenMaya.MDagPath()
    component = OpenMaya.MObject()
    sel.getDagPath(0, obj, component)
    return obj


def intArrayToList(array):
    newList = [0] * len(array)
    for i in range(len(array)):
        newList[i] = array[i]
    return newList


def pointStr(point):
    return point.x, point.y, point.z


def printMatrix(matrix):
    print(matrix(0, 0), matrix(0, 1), matrix(0, 2), matrix(0, 3))
    print(matrix(1, 0), matrix(1, 1), matrix(1, 2), matrix(1, 3))
    print(matrix(2, 0), matrix(2, 1), matrix(2, 2), matrix(2, 3))
    print(matrix(3, 0), matrix(3, 1), matrix(3, 2), matrix(3, 3))


def createMatrixFromPos(pos):
    mat = OpenMaya.MMatrix()
    OpenMaya.MScriptUtil.createMatrixFromList([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, pos.x, pos.y, pos.z, 1], mat)
    return mat


def createMatrixFromList(matList):
    mat = OpenMaya.MMatrix()
    OpenMaya.MScriptUtil.createMatrixFromList(matList, mat)
    return mat


def getAveragePlanesFromVertexesIds(sMesh, iVertexIndices):


    pMesh = patch.patchFromName(sMesh)
    aPoints = pMesh.getPoints()
    xIds = []
    zIds = []
    xNegs = []
    zNegs = []

    iiConnVerts = topology.getAllVertexVertices(pMesh.mDagPath)
    iiConnFaces = topology.getAllVertexFaces(pMesh.mDagPath)
    iiVertsOnFaces = topology.getAllFaceVertices(pMesh.mDagPath)


    skipsCounter = 0

    # iterate through all vertices to get the space (matrix) for each vertex
    #
    for i, iVert in enumerate(iVertexIndices):
        xId = []
        zId = []
        xNeg = []
        zNeg = []


        # get a position that is between the sorrounding vertices - for more stable calculating of the angles
        #
        aConnVerts = np.array(iiConnVerts[iVert], dtype=int)
        aAveragePoint = np.average(aPoints[aConnVerts], axis=0)

        # get a matrix from every face, and compute the average from it
        #
        for f, iFace in enumerate(iiConnFaces[iVert]):

            # twoIds and twoVecs are the 2 vertices used to construct the matrix
            #
            twoIds = [-1, -1]
            twoVecs = [None, None]

            for iFaceVert in iiVertsOnFaces[iFace]:
                if iFaceVert != iVert and iFaceVert in aConnVerts:
                    for d in range(2):
                        if twoIds[d] == -1:
                            twoIds[d] = vert
                            twoVecs[d] = OpenMaya.MVector(basePositions[vert] - averagePos)
                            break

            if f == 0:
                firstVecs = list(twoVecs)
                xId.append(twoIds[0])
                zId.append(twoIds[1])
                xNeg.append(False)
                zNeg.append(False)

            # for computing averages, we need to bring them as close to the first matrix as possible,
            # checking the angle between the current vecs and the ones from the first face. This is done by
            # sometimes swapping x and z, and/or sometimes negating x and/or z
            #
            if f > 0:
                negs = [False, False]

                angle0 = twoVecs[0].angle(firstVecs[0])
                angle1 = twoVecs[1].angle(firstVecs[0])
                angle0neg = False
                angle1neg = False

                if angle0 > math.pi * 0.5:
                    angle0 = math.pi - angle0
                    angle0neg = True
                if angle1 > math.pi * 0.5:
                    angle1 = math.pi - angle1
                    angle1neg = True

                if angle0 < angle1:
                    xId.append(twoIds[0])
                    zId.append(twoIds[1])
                    xNeg.append(angle0neg)
                    zNeg.append(twoVecs[1].angle(firstVecs[1]) > math.pi * 0.5)

                else:
                    xId.append(twoIds[1])
                    zId.append(twoIds[0])
                    xNeg.append(angle1neg)
                    zNeg.append(twoVecs[0].angle(firstVecs[1]) > math.pi * 0.5)

        # we'll store them in an array, because we need to use them more than once later
        #
        xIds.append(xId)
        zIds.append(zId)
        xNegs.append(xNeg)
        zNegs.append(zNeg)




def scaleAllJointRadius(fScale):
    sAllJoints = cmds.ls(et='joint')
    for sJ in sAllJoints:
        fRadius = cmds.getAttr('%s.radius' % sJ)
        cmds.setAttr('%s.radius' % sJ, fRadius * fScale)


def scaleSelectedTranslations(fScale):
    for sObj in cmds.ls(sl=True):
        fPos = cmds.getAttr('%s.t' % sObj)[0]
        cmds.setAttr('%s.t' % sObj, fPos[0]*fScale, fPos[1]*fScale, fPos[2]*fScale)


def scaleSelectedScales(fScale):
    for sObj in cmds.ls(sl=True):
        fPos = cmds.getAttr('%s.s' % sObj)[0]
        cmds.setAttr('%s.s' % sObj, fPos[0]*fScale, fPos[1]*fScale, fPos[2]*fScale)



def addUniformScaleAttr(sTransform, bLockHideScale=True, bConnectToScale=True):
    sUnifScale = utils.addAttr(sTransform, ln='scaleUF', at='double',
                               defaultValue=1.0, minValue=0.001, k=True)
    for sAttr in ['sx', 'sy', 'sz']:
        cmds.setAttr('%s.%s' % (sTransform, sAttr), lock=False)
        if bConnectToScale:
            cmds.connectAttr(sUnifScale, '%s.%s' % (sTransform, sAttr))
    if bLockHideScale:
        for sAttr in ['sx', 'sy', 'sz']:
            cmds.setAttr('%s.%s' % (sTransform, sAttr), lock=True, keyable=False, channelBox=False)

    return sUnifScale


# Depricated!! Please use getSignedAngle3 instead
def twistDetector(sJoint, sParentJoint, iTwistAxis=0, sName='', sTarget=None, bMaintainOffset=False):
    if '.' in sJoint: # joint is matrix
        sJointMatrix = sJoint
        sJointPos = nodes.createDecomposeMatrix(sJointMatrix)
    else:
        sJointMatrix = '%s.worldMatrix' % sJoint
        sJointPos = nodes.getWorldPoint(sJoint)

    if '.' in sParentJoint: # parent joint is matrix
        sInputParentMatrix = sParentJoint
    else:
        sInputParentMatrix = '%s.worldMatrix' % sParentJoint

    if bMaintainOffset:
        fLocalMatrix = nodes.createMultMatrixNode([sInputParentMatrix, nodes.createInverseMatrix(sJointMatrix, bJustValues=True)], bJustValues=True)
        sJointMatrix = nodes.createMultMatrixNode([fLocalMatrix, sJointMatrix])
        sJointPos = nodes.createDecomposeMatrix(sJointMatrix)

    sParentRot = nodes.createDecomposeMatrix(sInputParentMatrix, bReturnRotate=True, sName='twistParentRot_%s' % sName)
    sParentMatrix = nodes.createComposeMatrixNode(xTranslate=sJointPos, xRotate=sParentRot, sName='twistParentMatrix_%s' % sName)
    sInverseParentMatrix = nodes.createInverseMatrix(sParentMatrix, sName='twistParentInverse_%s' % sName)

    sLocalMatrix = nodes.createMultMatrixNode([sJointMatrix, sInverseParentMatrix], sName='twistLocal_%s' % sName)
    fLocalMatrixRef = cmds.getAttr(sLocalMatrix)
    iForwAxis = (iTwistAxis+1) % 3
    fForwAxis = [0,0,0]
    fForwAxis[iForwAxis] = 1

    iSideAxis = (iTwistAxis+2) % 3
    fSideAxis = [0,0,0]
    fSideAxis[iSideAxis] = 1

    sFrontPoint = nodes.createPointByMatrixNode(fForwAxis, sLocalMatrix, sName='twistForw_%s' % sName)
    sFrontPoint = ['%sX' % sFrontPoint, '%sY' % sFrontPoint, '%sZ' % sFrontPoint]
    sFrontPoint[iTwistAxis] = 0.0

    sFrontPointRef = nodes.createPointByMatrixNode(fForwAxis, fLocalMatrixRef, sName='twistForwRef_%s' % sName)
    sFrontPointRef = ['%sX' % sFrontPointRef, '%sY' % sFrontPointRef, '%sZ' % sFrontPointRef]
    sFrontPointRef[iTwistAxis] = 0.0

    sAngle = nodes.createAngleNode(sFrontPoint, sFrontPointRef, sName='twistAngle_%s' % sName)

    sSidePointRef = nodes.createPointByMatrixNode(fSideAxis, fLocalMatrixRef, sName='twistSide_%s' % sName)
    sDot = nodes.createDotProductNode(sSidePointRef, sFrontPoint, sName='twistDot_%s' % sName)
    sSign = nodes.createConditionNode(sDot, '>', 0, 1.0, -1.0, sName='twistSign_%s' % sName)
    sOutput = nodes.createMultiplyNode(sAngle, sSign, sName='twistSigned_%s' % sName)

    if sTarget:
        if '.' not in sTarget:
            sTarget = utils.addAttr(sTarget, ln='twist', k=True)
        cmds.connectAttr(sOutput, sTarget)

    return sOutput

# DEPRICATED!! it gives bad results if parent has different orientation. Use getSignedAngle4() instead
def getSignedAngle(sJoint, sParentJoint, iAngleAxis=0, iUpAxis=1, sName='', sTarget=None, bMaintainOffset=True):
    if '.' in sJoint: # joint is matrix
        sJointMatrix = sJoint
        sJointPos = nodes.createDecomposeMatrix(sJointMatrix)
    else:
        sJointMatrix = '%s.worldMatrix' % sJoint
        sJointPos = nodes.getWorldPoint(sJoint)

    if '.' in sParentJoint: # parent joint is matrix
        sInputParentMatrix = sParentJoint
    else:
        sInputParentMatrix = '%s.worldMatrix' % sParentJoint

    if bMaintainOffset:
        fLocalMatrix = nodes.createMultMatrixNode([sInputParentMatrix, nodes.createInverseMatrix(sJointMatrix, bJustValues=True)], bJustValues=True)
        sJointMatrix = nodes.createMultMatrixNode([fLocalMatrix, sJointMatrix])
        sJointPos = nodes.createDecomposeMatrix(sJointMatrix)

    sParentRot = nodes.createDecomposeMatrix(sInputParentMatrix, bReturnRotate=True, sName='twistParentRot_%s' % sName)
    sParentMatrix = nodes.createComposeMatrixNode(xTranslate=sJointPos, xRotate=sParentRot, sName='twistParentMatrix_%s' % sName)
    sInverseParentMatrix = nodes.createInverseMatrix(sParentMatrix, sName='twistParentInverse_%s' % sName)

    sLocalMatrix = nodes.createMultMatrixNode([sJointMatrix, sInverseParentMatrix], sName='twistLocal_%s' % sName)
    fLocalMatrixRef = cmds.getAttr(sLocalMatrix)
    fUpAxis = [0,0,0]
    fUpAxis[iUpAxis] = 1

    iAllAxes = set([0,1,2])
    iAllAxes.remove(iAngleAxis)
    iAllAxes.remove(iUpAxis)

    iSideAxis = iAllAxes.pop() # (iAngleAxis+2) % 3
    fSideAxis = [0,0,0]
    fSideAxis[iSideAxis] = 1

    sFrontPoint = nodes.createPointByMatrixNode(fUpAxis, sLocalMatrix, sName='twistForw_%s' % sName)
    sFrontPoint = ['%sX' % sFrontPoint, '%sY' % sFrontPoint, '%sZ' % sFrontPoint]
    sFrontPoint[iAngleAxis] = 0.0

    sFrontPointRef = nodes.createPointByMatrixNode(fUpAxis, fLocalMatrixRef, sName='twistForwRef_%s' % sName)
    sFrontPointRef = ['%sX' % sFrontPointRef, '%sY' % sFrontPointRef, '%sZ' % sFrontPointRef]
    sFrontPointRef[iAngleAxis] = 0.0

    sAngle = nodes.createAngleNode(sFrontPoint, sFrontPointRef, sName='twistAngle_%s' % sName)

    sSidePointRef = nodes.createPointByMatrixNode(fSideAxis, fLocalMatrixRef, sName='twistSide_%s' % sName)
    sDot = nodes.createDotProductNode(sSidePointRef, sFrontPoint, sName='twistDot_%s' % sName)
    sSign = nodes.createConditionNode(sDot, '>', 0, 1.0, -1.0, sName='twistSign_%s' % sName)
    sOutput = nodes.createMultiplyNode(sAngle, sSign, sName='twistSigned_%s' % sName)

    if sTarget:
        if '.' not in sTarget:
            sTarget = utils.addAttr(sTarget, ln='twist', k=True)
        cmds.connectAttr(sOutput, sTarget)

    return sOutput


# depricated - please use getSignedAngle3 instead. This one takes the positions of the sJoint/sParentJoint, and thereofore can get unstable
def getSignedAngle2(sJoint, sParentJoint, iAngleAxis=0, iUpAxis=1, sName='', sTarget=None, bMaintainOffset=True, bComputeInParentSpace=False): # bComputeInParentSpace is not tested yet, maybe we'll remove
    if '.' in sJoint: # joint is matrix
        sJointMatrix = sJoint
    else:
        sJointMatrix = '%s.worldMatrix' % sJoint

    if '.' in sParentJoint: # parent joint is matrix
        sInputParentMatrix = sParentJoint
        sInputParentMatrixInverse = nodes.createInverseMatrix(sInputParentMatrix, bJustValues=True)
    else:
        sInputParentMatrix = '%s.worldMatrix' % sParentJoint
        sInputParentMatrixInverse = '%s.worldInverseMatrix' % sParentJoint
    
    
    if bComputeInParentSpace:
        fJointOffsetMatrix = nodes.createMultMatrixNode([sInputParentMatrix, nodes.createInverseMatrix(sJointMatrix, bJustValues=True)], bJustValues=True)
        sLocalMatrix = nodes.createMultMatrixNode([fJointOffsetMatrix, sJointMatrix, sInputParentMatrixInverse])
    else:
    
        sParentMatrixOffset = nodes.createMultMatrixNode([sJointMatrix, sInputParentMatrixInverse], bJustValues=True)
        sOffsettedParentMatrix = nodes.createMultMatrixNode([sParentMatrixOffset, sInputParentMatrix])
        sInverseParentMatrix = nodes.createInverseMatrix(sOffsettedParentMatrix)
        
        sLocalMatrix = nodes.createMultMatrixNode([sJointMatrix, sInverseParentMatrix], sName='twistLocal_%s' % sName)
    
    
    fLocalMatrixRef = cmds.getAttr(sLocalMatrix)
    fUpAxis = [0,0,0]
    fUpAxis[iUpAxis] = 1

    iAllAxes = set([0,1,2])
    iAllAxes.remove(iAngleAxis)
    iAllAxes.remove(iUpAxis)

    iSideAxis = iAllAxes.pop() # (iAngleAxis+2) % 3
    fSideAxis = [0,0,0]
    fSideAxis[iSideAxis] = 1

    sFrontPoint = nodes.createPointByMatrixNode(fUpAxis, sLocalMatrix, sName='twistForw_%s' % sName)
    sFrontPoint = ['%sX' % sFrontPoint, '%sY' % sFrontPoint, '%sZ' % sFrontPoint]
    sFrontPoint[iAngleAxis] = 0.0

    sFrontPointRef = nodes.createPointByMatrixNode(fUpAxis, fLocalMatrixRef, sName='twistForwRef_%s' % sName)
    sFrontPointRef = ['%sX' % sFrontPointRef, '%sY' % sFrontPointRef, '%sZ' % sFrontPointRef]
    sFrontPointRef[iAngleAxis] = 0.0

    sAngle = nodes.createAngleNode(sFrontPoint, sFrontPointRef, sName='twistAngle_%s' % sName)

    sSidePointRef = nodes.createPointByMatrixNode(fSideAxis, fLocalMatrixRef, sName='twistSide_%s' % sName)
    sDot = nodes.createDotProductNode(sSidePointRef, sFrontPoint, sName='twistDot_%s' % sName)
    sSign = nodes.createConditionNode(sDot, '>', 0, 1.0, -1.0, sName='twistSign_%s' % sName)
    sOutput = nodes.createMultiplyNode(sAngle, sSign, sName='twistSigned_%s' % sName)

    if sTarget:
        if '.' not in sTarget:
            sTarget = utils.addAttr(sTarget, ln='twist', k=True)
        cmds.connectAttr(sOutput, sTarget)

    return sOutput



# DEPRICATED! it 'freezes' parentMatrixInverse with the bJustValues flag, please use getSignedAngle4() instead
def getSignedAngle3(sJoint, sParentJoint, iAngleAxis=0, iUpAxis=1, sName='', sTarget=None, bMaintainOffset=True, bComputeInParentSpace=False, bDebugAttr=False): # bComputeInParentSpace is not tested yet, maybe we'll remove
    if '.' in sJoint: # joint is matrix
        sJointMatrix = sJoint
    else:
        sJointMatrix = '%s.worldMatrix' % sJoint
    sJointMatrix = nodes.getRotationMatrix(sJointMatrix)

    if '.' in sParentJoint: # parent joint is matrix
        sInputParentMatrix = sParentJoint
    else:
        sInputParentMatrix = '%s.worldMatrix' % sParentJoint

    sInputParentMatrix = nodes.getRotationMatrix(sInputParentMatrix)
    sInputParentMatrixInverse = nodes.createInverseMatrix(sInputParentMatrix, bJustValues=True)

    if bComputeInParentSpace:
        fJointOffsetMatrix = nodes.createMultMatrixNode([sInputParentMatrix, nodes.createInverseMatrix(sJointMatrix, bJustValues=True)], bJustValues=True)
        sLocalMatrix = nodes.createMultMatrixNode([fJointOffsetMatrix, sJointMatrix, sInputParentMatrixInverse])
    else:
        sParentMatrixOffset = nodes.createMultMatrixNode([sJointMatrix, sInputParentMatrixInverse], bJustValues=True)
        sOffsettedParentMatrix = nodes.createMultMatrixNode([sParentMatrixOffset, sInputParentMatrix])
        sInverseParentMatrix = nodes.createInverseMatrix(sOffsettedParentMatrix)
        sLocalMatrix = nodes.createMultMatrixNode([sJointMatrix, sInverseParentMatrix], sName='twistLocal_%s' % sName)

    fLocalMatrixRef = cmds.getAttr(sLocalMatrix)
    fUpAxis = [0,0,0]
    fUpAxis[iUpAxis] = 1

    iAllAxes = set([0,1,2])
    iAllAxes.remove(iAngleAxis)
    iAllAxes.remove(iUpAxis)

    iSideAxis = iAllAxes.pop() # (iAngleAxis+2) % 3
    fSideAxis = [0,0,0]
    fSideAxis[iSideAxis] = 1

    sFrontPoint = nodes.createPointByMatrixNode(fUpAxis, sLocalMatrix, sName='twistForw_%s' % sName)
    sFrontPoint = ['%sX' % sFrontPoint, '%sY' % sFrontPoint, '%sZ' % sFrontPoint]
    sFrontPoint[iAngleAxis] = 0.0

    sFrontPointRef = nodes.createPointByMatrixNode(fUpAxis, fLocalMatrixRef, sName='twistForwRef_%s' % sName)
    sFrontPointRef = ['%sX' % sFrontPointRef, '%sY' % sFrontPointRef, '%sZ' % sFrontPointRef]
    sFrontPointRef[iAngleAxis] = 0.0

    sAngle = nodes.createAngleNode(sFrontPoint, sFrontPointRef, sName='twistAngle_%s' % sName)

    sSidePointRef = nodes.createPointByMatrixNode(fSideAxis, fLocalMatrixRef, sName='twistSide_%s' % sName)
    sDot = nodes.createDotProductNode(sSidePointRef, sFrontPoint, sName='twistDot_%s' % sName)
    sSign = nodes.createConditionNode(sDot, '>', 0, 1.0, -1.0, sName='twistSign_%s' % sName)
    sOutput = nodes.createMultiplyNode(sAngle, sSign, sName='twistSigned_%s' % sName)

    if sTarget:
        if '.' not in sTarget:
            sTarget = utils.addAttr(sTarget, ln='twist', k=True)
        cmds.connectAttr(sOutput, sTarget)

    utils.addStringAttr(sOutput.split('.')[0], 'sJoint', sJoint)
    utils.addStringAttr(sOutput.split('.')[0], 'sInputParentMatrix', sInputParentMatrix)

    if bDebugAttr:
        sDebugAttr = utils.addAttr(sJoint, ln='twistDebug', k=True, bReturnIfExists=True)
        cmds.connectAttr(sOutput, sDebugAttr, force=True)

    return sOutput


# this should be the most stable one, and it's same algorithm as unreal one (functions.signedAngleFunction())
# bComputeInParentSpace is actually better as False. Should we change default, and adjust UE Conrol Rig?
def getSignedAngle4(sJoint, sParentJoint, iForwardAxis=0, iUpAxis=2, iAngleAxis=None, sName='', sTarget=None, bComputeInParentSpace=True):
    if '.' in sJoint: # joint is matrix
        sJointMatrix = sJoint
    else:
        sJointMatrix = '%s.worldMatrix' % sJoint
    sJointMatrix = nodes.getRotationMatrix(sJointMatrix)

    if '.' in sParentJoint: # parent joint is matrix
        sInputParentMatrix = sParentJoint
    else:
        sInputParentMatrix = '%s.worldMatrix' % sParentJoint

    sInputParentMatrix = nodes.getRotationMatrix(sInputParentMatrix)
    sInputParentMatrixInverse = nodes.createInverseMatrix(sInputParentMatrix)

    if bComputeInParentSpace:
        fJointOffsetMatrix = nodes.createMultMatrixNode([sInputParentMatrix, nodes.createInverseMatrix(sJointMatrix, bJustValues=True)], bJustValues=True)
        sLocalMatrix = nodes.createMultMatrixNode([fJointOffsetMatrix, sJointMatrix, sInputParentMatrixInverse])
    else:
        sParentMatrixOffset = nodes.createMultMatrixNode([sJointMatrix, sInputParentMatrixInverse], bJustValues=True)
        sOffsettedParentMatrix = nodes.createMultMatrixNode([sParentMatrixOffset, sInputParentMatrix])
        sInverseParentMatrix = nodes.createInverseMatrix(sOffsettedParentMatrix)
        sLocalMatrix = nodes.createMultMatrixNode([sJointMatrix, sInverseParentMatrix], sName='twistLocal_%s' % sName)


    sOutput = getLocalAngle(sLocalMatrix, iForwardAxis=iForwardAxis, iUpAxis=iUpAxis, iAngleAxis=iAngleAxis, sName=sName)

    if sTarget:
        if '.' not in sTarget:
            sTarget = utils.addAttr(sTarget, ln='twist', k=True)
        cmds.connectAttr(sOutput, sTarget)

    utils.addStringAttr(sOutput.split('.')[0], 'sJoint', sJoint)
    utils.addStringAttr(sOutput.split('.')[0], 'sInputParentMatrix', sInputParentMatrix)

    return sOutput


def getLocalAngle(sLocalMatrix, iForwardAxis=0, iUpAxis=2, iAngleAxis=None, sName='noname', bForwardNeg=False, bUpNeg=False):
    fForwardAxis = [0,0,0]
    fForwardAxis[iForwardAxis] = 1
    fUpAxis = [0,0,0]
    fUpAxis[iUpAxis] = -1 if bUpNeg else 1

    if utils.isNone(iAngleAxis):
        iAllAxes = set([0,1,2])
        iAllAxes.remove(iUpAxis)
        iAllAxes.remove(iForwardAxis)
        iAngleAxis = iAllAxes.pop()

    sFrontPoint = nodes.createPointByMatrixNode(fForwardAxis, sLocalMatrix, sName='twistForw_%s' % sName)
    sFrontPoint = ['%sX' % sFrontPoint, '%sY' % sFrontPoint, '%sZ' % sFrontPoint]
    sFrontPoint[iAngleAxis] = 0.0

    sAngle = nodes.createAngleNode(sFrontPoint, [-fV for fV in fForwardAxis] if bForwardNeg else fForwardAxis, sName='angleDetecttwistAngle_%s' % sName)

    sDot = nodes.createDotProductNode(fUpAxis, sFrontPoint, sName='angleDetecttwistDot_%s' % sName)
    sSign = nodes.createConditionNode(sDot, '>', 0, 1.0, -1.0, sName='angleDetecttwistSign_%s' % sName)
    return nodes.createMultiplyNode(sAngle, sSign, sName='angleDetectTwistSigned_%s' % sName)




def createBarycentricCornerWeightsAttrs(sInputVectorAttr, sInfoAttrNode, bShowAttrs=False):
    dOutputsPerHorizontal = {}, {}

    sHorizNames = ['out', 'in']

    sInputVectorFakeSum = nodes.createVectorAdditionNode([sInputVectorAttr])

    for x,fHorizSign in enumerate([1, -1]):
        sResultOutDowns = [None, None]
        sResultOuts = [None, None]
        sResultDowns = [None, None]

        if x == 0:
            sD = nodes.createClampNode(sInputVectorAttr, [0, -1, 0], [1, 1, 0], bVector=True)
        else:
            sD = nodes.createClampNode(sInputVectorAttr, [-1, -1, 0], [0, 1, 0], bVector=True)

        for i in range(2): # bot, top
            fLengthD = 1.0
            sLengthA = nodes.createDistanceNode(sD, [fHorizSign,0,0], sName='cornerBarycentric')
            sLengthB = nodes.createDistanceNode(sD, [0,0,0], sName='cornerBarycentric')
            sSeg = nodes.fromEquation('(%f + %s + %s) * 0.5' % (fLengthD, sLengthA, sLengthB), sName='cornerBarycentric')
            sAreaSquared = nodes.fromEquation('{0} * ({0}-{1}) * ({0}-{2}) * ({0}-{3})'.format(sSeg, '%0.5f' % fLengthD, sLengthA, sLengthB), sName='cornerBarycentric')
            sAreaTop = nodes.createMultiplyNode(nodes.createClampNode(sAreaSquared, 0, 1000), 0.5, sOperation='power', sName='cornerBarycentric') # NAN

            fLengthD = 1.0
            sLengthC = sLengthA
            sLengthB = nodes.createDistanceNode(sD, [fHorizSign,-1 if i == 0 else 1, 0], sName='cornerBarycentric')
            sSeg = nodes.fromEquation('(%f + %s + %s) * 0.5' % (fLengthD, sLengthC, sLengthB), sName='cornerBarycentric')
            sAreaSquared = nodes.fromEquation('{0} * ({0}-{1}) * ({0}-{2}) * ({0}-{3})'.format(sSeg, '%0.5f' % fLengthD, sLengthC, sLengthB), sName='cornerBarycentric')
            sAreaSide = nodes.createMultiplyNode(nodes.createClampNode(sAreaSquared, 0, 1000), 0.5, sOperation='power', sName='cornerBarycentric')

            sStrengthC = nodes.fromEquation('%s / 0.5' % sAreaTop, sName='cornerBarycentric%s' % sD.split('.')[0])
            sStrengthB = nodes.fromEquation('1.0 - %s - %s/0.5' % (sStrengthC, sAreaSide), sName='cornerBarycentric%s' % sD.split('.')[0])

            fLengthD = 1.0
            sLengthE = nodes.createDistanceNode(sD, [fHorizSign,-1 if i == 0 else 1,0], sName='cornerBarycentric')
            sLengthC = nodes.createDistanceNode(sD, [0,-1 if i == 0 else 1,0], sName='cornerBarycentric')
            sSeg = nodes.fromEquation('(%f + %s + %s) * 0.5' % (fLengthD, sLengthE, sLengthC), sName='cornerBarycentric')
            sAreaSquared = nodes.fromEquation('{0} * ({0}-{1}) * ({0}-{2}) * ({0}-{3})'.format(sSeg, '%0.5f' % fLengthD, sLengthE, sLengthC), sName='cornerBarycentric')
            sAreaBot = nodes.createMultiplyNode(nodes.createClampNode(sAreaSquared, 0, 1000), 0.5, sOperation='power', sName='cornerBarycentric')

            fLengthD = 1.0
            sLengthA = sLengthC
            sLengthE = nodes.createDistanceNode(sD, [0,0,0], sName='cornerBarycentric')
            sSeg = nodes.fromEquation('(%f + %s + %s) * 0.5' % (fLengthD, sLengthA, sLengthE), sName='cornerBarycentric')
            sAreaSquared = nodes.fromEquation('{0} * ({0}-{1}) * ({0}-{2}) * ({0}-{3})'.format(sSeg, '%0.5f' % fLengthD, sLengthA, sLengthE), sName='cornerBarycentric')
            sAreaLeft = nodes.createMultiplyNode(nodes.createClampNode(sAreaSquared, 0, 1000), 0.5, sOperation='power', sName='cornerBarycentric')

            sStrengthC2 = nodes.fromEquation('%s / 0.5' % sAreaLeft, sName='cornerBarycentric%s' % sD.split('.')[0])
            sStrengthE = nodes.fromEquation('1.0 - %s - %s/0.5' % (sStrengthC2, sAreaBot), sName='cornerBarycentric%s' % sD.split('.')[0])

            sDiagCompare = nodes.createMultiplyNode('%s.outputG' % sD, -1, sName='cornerBarycentric') if i == 0 else '%s.outputG' % sD
            sDiagCompareB = nodes.createMultiplyNode('%s.outputR' % sD, -1, sName='cornerBarycentric') if x == 1 else '%s.outputR' % sD
            sResultOutDowns[i] = nodes.createConditionNode(sDiagCompareB, '>=' if x == 0 else '>=', sDiagCompare, sStrengthC, sStrengthC2, sName='cornerBarycentric')
            sResultOuts[i] = nodes.createConditionNode(sDiagCompareB, '>=' if x == 0 else '>=', sDiagCompare, sStrengthB, 0.0, sName='cornerBarycentric')
            sResultDowns[i] = nodes.createConditionNode(sDiagCompareB, '>=' if x == 0 else '>=', sDiagCompare, 0.0, sStrengthE, sName='cornerBarycentric')


        dOutputsPerHorizontal[x]['%sDown' % sHorizNames[x]] = nodes.createConditionNode('%s.outputG' % sD, '>=', 0.0, 0.0, sResultOutDowns[0], sName='cornerOutDownChooseBotOrTop')


        dOutputsPerHorizontal[x][sHorizNames[x]] = nodes.createConditionNode('%s.outputG' % sD, '>=', 0.0, sResultOuts[1], sResultOuts[0], sName='cornerOutChooseBotOrTop') # sResultsOut[0] is correctly bottom, but is  is negative...
        dOutputsPerHorizontal[x]['down'] = nodes.createConditionNode('%s.outputG' % sD, '>=', 0.0, 0.0, sResultDowns[0], sName='cornerDownChooseBotOrTop')
        dOutputsPerHorizontal[x]['up'] = nodes.createConditionNode('%s.outputG' % sD, '>=', 0.0, sResultDowns[1], 0.0, sName='cornerUpChooseBotOrTop')
        dOutputsPerHorizontal[x]['%sUp' % sHorizNames[x]] = nodes.createConditionNode('%s.outputG' % sD, '>=', 0.0, sResultOutDowns[1], 0.0, sName='cornerOutUpChooseBotOrTop')

        dOutputsPerHorizontal[x]['%sDown' % sHorizNames[1-x]] = 0.0
        dOutputsPerHorizontal[x][sHorizNames[1-x]] = 0.0
        dOutputsPerHorizontal[x]['%sUp' % sHorizNames[1-x]] = 0.0


    for sTarget in ['out', 'down', 'up', 'in', 'outUp', 'outDown', 'inUp', 'inDown']:
        sInfoAttr = utils.addAttr(sInfoAttrNode, ln='barycentricCorner%s%s' % (sTarget[0].upper(), sTarget[1:]), k=False)
        nodes.createConditionNode('%sx' % sInputVectorFakeSum, '>=', 0.0, dOutputsPerHorizontal[0][sTarget], dOutputsPerHorizontal[1][sTarget], sTarget=sInfoAttr)



def scaleTranslationsSelection(fScale):
    for sJ in cmds.ls(sl=True):
        fPos = cmds.getAttr('%s.t' % sJ)[0]
        fPos = [fPos[0] * fScale, fPos[1] * fScale, fPos[2] * fScale]
        cmds.setAttr('%s.t' % sJ, fPos[0], fPos[1], fPos[2])


def removeTransformParent(sJoint):
    sParent = cmds.listRelatives(sJoint, p=True)[0]
    if sParent.startswith('transform'):
        cmds.setAttr('%s.s' % sParent, 1,1,1)
        cmds.setAttr('%s.s' % sJoint, 1,1,1)

        sTransformParent = cmds.listRelatives(sParent, p=True)[0]
        cmds.parent(sJoint, sTransformParent)
        cmds.delete(sParent)


def findTopGroup(sNode):

    while True:
        sParents = cmds.listRelatives(sNode, p=True)
        if not sParents:
            return sNode
        else:
            sNode = sParents[0]


def aimConstraintSmallObjects(sTarget, sObject, aimVector=[1,0,0], upVector=[0,1,0], xUpMatrix=None, bRotateUp=True, sName='noname'):
    sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(sTarget), '%s.worldInverseMatrix' % cmds.listRelatives(sObject, p=True)[0])
    nodes.createSimpleAimConstraint2(sAimTarget, sObject, sParent=sObject, xUpMatrix=xUpMatrix, bRotateUp=bRotateUp, xAimVector=aimVector, xUpVector=upVector, sName=sName)




def parentJointNoTransform(sJoint, sParent, bSkipIfAlreadyUnderThatParent=False):
    fMatrixBefore = cmds.xform(sJoint, q=True, m=True, ws=True)
    if bSkipIfAlreadyUnderThatParent:
        utils.parentTo(sJoint, sParent)
    else:
        cmds.parent(sJoint, sParent)
    sNewParent = cmds.listRelatives(sJoint, p=True)[0]
    if sNewParent != sParent:
        cmds.setAttr('%s.s' % sNewParent, 1,1,1)
        cmds.parent(sJoint, sParent)
        cmds.delete(sNewParent)
        sNewParent = cmds.listRelatives(sJoint, p=True)[0]
        if sNewParent != sParent:
            raise Exception('Cannot parent cleanly, it keeps creating that transform group :-(.. "%s"' % sJoint)
        cmds.xform(sJoint, m=fMatrixBefore, ws=True)



def getAverageJointRadius():
    sAllJoints = cmds.ls(et='joint')
    fRadien = [cmds.getAttr('%s.radius' % sJ) for sJ in sAllJoints]
    if fRadien:
        fJointRadius = np.sum(fRadien) / len(fRadien)
    else:
        fJointRadius = 1.0

    return fJointRadius



def unlockTrs(sObject):
    for sA in ['t', 'r', 's', 'tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
        cmds.setAttr('%s.%s' % (sObject, sA), lock=False)

def lockTrs(sObject):
    for sA in ['t', 'r', 's', 'tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
        cmds.setAttr('%s.%s' % (sObject, sA), lock=True)


def getNextParentOfType(sNode, sType):
    _sParent = sNode
    while True:
        sParents = cmds.listRelatives(_sParent, p=True)
        print ('sParents: ', sParents)
        if not sParents:
            return None
        else:
            _sParent = sParents[0]
            if cmds.objectType(_sParent) == sType:
                return _sParent


def getParent(sChild):
    return cmds.listRelatives(sChild, p=True)[0]



def addParentsForZV(sTransforms):
    for sTransform in utils.toList(sTransforms):
        bNegativeScale = utils.getSide(sTransform) == 'r'

        if bNegativeScale:
            sRevScale = insertParent(sTransform, '%s_zvRevScaleA' % sTransform)
            cmds.setAttr('%s.s' % sRevScale, -1, -1, -1)

        insertParent(sTransform, '%s_PH' % sTransform)
        insertParent(sTransform, '%s_SN' % sTransform)

        if bNegativeScale:
            sRevScale = insertParent(sTransform, '%s_zvRevScaleB' % sTransform)
            cmds.setAttr('%s.s' % sRevScale, -1, -1, -1)




def rotateBackToZero(fEuler, fDegrees, iRotateOrder=0):

    current_euler = OpenMaya2.MEulerRotation( math.radians(fEuler[0]), math.radians(fEuler[1]), math.radians(fEuler[2]), iRotateOrder)
    current_quat = current_euler.asQuaternion()

    identity_quat = OpenMaya2.MQuaternion()

    fDot = current_quat.x * identity_quat.x + \
          current_quat.y * identity_quat.y + \
          current_quat.z * identity_quat.z + \
          current_quat.w * identity_quat.w

    fDot = max(min(fDot, 1.0), -1.0)
    fAngleInRadians = 2 * math.acos(fDot)

    if fAngleInRadians == 0:
        cmds.warning("It\'s already at 0")
        return

    t = min(1.0, math.radians(fDegrees) / fAngleInRadians)

    new_quat = OpenMaya2.MQuaternion.slerp(current_quat, identity_quat, t)
    new_euler = new_quat.asEulerRotation()
    fNewEuler = [math.degrees(new_euler.x), math.degrees(new_euler.y), math.degrees(new_euler.z)]
    return fNewEuler
