###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.utilFunctions as utils
from kangarooLimbs.baseLimb import enumAttr

QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt
import kangarooTools.xforms as xforms
import kangarooTools.nodes as nodes
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.geometry as geometry
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.ctrls8 as ctrls8
from collections import OrderedDict, defaultdict
import kangarooShapeEditor.kangarooShapeEditorTools as tools
import kangarooShapeEditor.kangarooShapeEditorLibrary as library
import kangarooTools.report as report

utils.reload2(tools)
utils.reload2(library)

import importlib
import numpy as np
import os


import kangarooAnimation.KangarooMatchTools as KangarooMatchTools

qItalicFont = QtGui.QFont()
qItalicFont.setItalic(True)

_kRowHeight = utilsQt.getDpi() / 4
_ButtonHeight = int(utilsQt.getDpi() * 0.3)


kInterpTypes = ['signedAngle', 'cone', 'mayaPose', 'upleg', 'custom']#, 'attribute']
kCurveTypes = [x for x in blendShapes.DrivenKeyCurveType.__dict__ if not x.startswith('__')]
kTempString = '__xxxTEMPxxx__'
kConeRangeDefault = [80.0, 0.0]
# kAngleRangeDefault = [0, 90]
k3dPoseDefault = [0,0,0]
kCurveTypeDefault = 1
kTargetArrayMultipl = 'targetArrayMultipl'
kIsPoseEditorBlendShapeAttr = 'isPoseEditorBlendShapeAttr'
kMiddleCtrlMirrorPlaneAttr = 'iPoseMirrorPlane'

kIsEdgeFlowAttr = 'bMirrorIsEdgeFlow'
# kIsFacePoint = 'bMirrorIsFacePoint'
kIsSideAttr = 'bMirrorIsSide'
kPoseEditorNextIndexAttr = 'poseEditorNextIndex'
kExportPoseEditorBlendShapesSuffix = 'poseEditorBlendShapes'
kInverseExportAttr = 'bInverseExport'
kNoDriverSuffix = '(no driver)'

class QInterpolatorsTreeWidget(QtWidgets.QTreeWidget):
    def __init__(self):
        QtWidgets.QTreeWidget.__init__(self)
        self.setHeaderHidden(True)
        self.setColumnCount(2)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setDragEnabled(True)

    def resizeEvent(self, event):
        iWidthLeft = self.width() * 0.8
        self.setColumnWidth(0, iWidthLeft)
        self.setColumnWidth(1, self.width() - iWidthLeft - 100)





class QMeshesTreeWidget(QtWidgets.QTreeWidget):
    def __init__(self):
        QtWidgets.QTreeWidget.__init__(self)
        self.setColumnCount(1)
        self.setHeaderHidden(True)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)

    def resizeEvent(self, event):
        iWidthLeft = self.width() * 0.8
        self.setColumnWidth(0, iWidthLeft)
        self.setColumnWidth(1, self.width() - iWidthLeft - 100)



class qTargetsTree(QtWidgets.QTreeWidget):
    def __init__(self, funcDrop):
        QtWidgets.QTreeWidget.__init__(self)
        self.setAcceptDrops(True)
        self.funcDrop = funcDrop
        self.setColumnCount(1)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)



    def dropEvent(self, event):
        self.funcDrop(event)




class QPoseEditorUi(QtWidgets.QDialog):

    def __init__(self, parent=utilsQt.getMayaWindow()):
        super(QPoseEditorUi, self).__init__(parent, QtCore.Qt.Tool)
        self.setWindowTitle('Pose Editor')
        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.dInterpolators = {}
        self.funcRedoUndoStack = []
        self.dSliderValuesBeforeDrag = {}

        self.__sSavedAllCtrls = []


        qSplitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        qSplitter.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.layout.addWidget(qSplitter)

        qInterpolatorsTopLayout = QtWidgets.QHBoxLayout()
        qSplitter.addWidget(utilsQt.makeWidgetFromLayout(qInterpolatorsTopLayout, parent=self))

        qInterpolatorsLayout = utilsQt.createGroupBoxLayout(qInterpolatorsTopLayout, 'Interpolators', bHorizontalLayout=True)

        qInterpListLayout = QtWidgets.QVBoxLayout()
        qInterpListLayout.setSpacing(0)
        qInterpolatorsLayout.addLayout(qInterpListLayout)

        self.qAddInterpButton = QtWidgets.QPushButton('Add')
        self.qAddInterpButton.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.qAddInterpButton.clicked.connect(self.addInterpolatorMenu)
        self.qDefaultPoseButton = QtWidgets.QPushButton('Pose to Default')
        self.qDefaultPoseButton.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.qDefaultPoseButton.clicked.connect(self.defaultPoseolatorMenu)

        qRowLayout = QtWidgets.QHBoxLayout()
        qRowLayout.addWidget(self.qAddInterpButton)
        qRowLayout.addWidget(self.qDefaultPoseButton)
        qInterpListLayout.addLayout(qRowLayout)

        self.qInterpsIsolateButton = QtWidgets.QPushButton('Isolate')
        self.qInterpsIsolateButton.setCheckable(True)
        self.qInterpsIsolateButton.setMaximumHeight(30)
        self.qInterpsIsolateButton.clicked.connect(self.isolateInterpsClicked)


        self.qInterpsFilter = utilsQt.QFilter()
        self.qInterpsFilter.changed.connect(self.updateInterpsVisibilities)

        qInterpListLayout.addWidget(self.qInterpsFilter)
        qInterpListLayout.addWidget(self.qInterpsIsolateButton)

        self.qMainTree = QInterpolatorsTreeWidget()
        self.qMainTree.itemSelectionChanged.connect(self.mainTreeSelectionChanged)
        qInterpListLayout.addWidget(self.qMainTree)
        self.qMainTree.setMinimumWidth(50)
        # self.qMainTree.setMaximumWidth(500)
        self.qMainTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qMainTree.customContextMenuRequested.connect(self.markingMenuMain)

        def doubleClickInterp(qItem):
            dItem = qItem.data(0, QtCore.Qt.UserRole)
            if dItem['sType'] == 'pose':
                self.poseTo([dItem['sOutputAttr']])
        self.qMainTree.itemDoubleClicked.connect(doubleClickInterp)

        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.updateUiOutputValues)
        self.timer.start(100)

        # self.iCurrentSculptTarget = -1

        qRightSideLayout = QtWidgets.QVBoxLayout()
        qAttributesLabel = QtWidgets.QLabel('Attributes:')
        qAttributesLabel.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        qRightSideLayout.addWidget(qAttributesLabel)

        # self.qRebuildButton = QtWidgets.QPushButton('Rebuild')
        # self.qRebuildButton.clicked.connect(self.rebuildInterpolatorsButton)
        # qRightSideLayout.addWidget(self.qRebuildButton)
        # self.qRebuildButton.setHidden(True)

        self.qInterpAttributesLayoutDynamic = QtWidgets.QVBoxLayout()
        self.qInterpAttributesLayoutDynamic.addStretch()
        qRightSideLayout.addLayout(self.qInterpAttributesLayoutDynamic)
        qInterpolatorsLayout.addLayout(qRightSideLayout)

        self.resize(1500, 500)
        self.refreshInterpTreeFromScene()

        qBottomLayout = QtWidgets.QHBoxLayout()
        # self.layout.addLayout(qBottomLayout)
        qSplitter.addWidget(utilsQt.makeWidgetFromLayout(qBottomLayout, parent=self))

        # TARGETS TABLE
        #
        qTargetsLayout = utilsQt.createGroupBoxLayout(qBottomLayout, 'Targets (Pose Combinations)', bHorizontalLayout=True)

        self.qTargetsIsolateButton = QtWidgets.QPushButton('Isolate')
        self.qTargetsIsolateButton.setCheckable(True)
        self.qTargetsIsolateButton.setMaximumHeight(30)
        self.qTargetsIsolateButton.clicked.connect(self.isolateTargetsClicked)
        self.qTargetsFilter = utilsQt.QFilter()
        self.qTargetsFilter.changed.connect(self.updateTargetVisibilities)
        qVertLayout = QtWidgets.QVBoxLayout()
        qVertLayout.addWidget(self.qTargetsIsolateButton)
        qVertLayout.addWidget(self.qTargetsFilter)
        qVertLayout.setSpacing(0)


        self.qTargetsTree = qTargetsTree(self.posesDropEvent)
        self.qTargetsTree.setStyleSheet("QTreeWidget { background-color : #434343; }")
        self.qTargetsTree.setHeaderHidden(True)
        self.qTargetsTree.setColumnCount(1)
        self.qTargetsTree.itemSelectionChanged.connect(self.targetSelectionChanged)
        self.qTargetsTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qTargetsTree.customContextMenuRequested.connect(self.markingMenuTargets)

        qVertLayout.addWidget(self.qTargetsTree)
        qTargetsLayout.addLayout(qVertLayout)

        # MESHES TREE
        #

        qMeshesLayout = utilsQt.createGroupBoxLayout(qBottomLayout, 'Meshes', bHorizontalLayout=True, iWidgetMaximumWidth=300)
        self.qMeshesTree = QMeshesTreeWidget()
        self.qMeshesTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qMeshesTree.customContextMenuRequested.connect(self.markingMenuMeshes)
        self.qMeshesTree.header().setStretchLastSection(True)
        self.qMeshesTree.itemChanged.connect(self.userChecksOrUnchecksMesh)
        self.refreshMeshesTreeFromScene(bCheckLattices=True)
        qMeshesLayout.addWidget(self.qMeshesTree)


        qCtrlsLayout = utilsQt.createGroupBoxLayout(qBottomLayout, 'Ctrls', bHorizontalLayout=True, iWidgetMaximumWidth=300)
        qCtrlsLayoutB = QtWidgets.QVBoxLayout()
        qCtrlsLayoutB.setSpacing(0)
        qCtrlsLayout.addLayout(qCtrlsLayoutB)
        self.qAddActivateButton = QtWidgets.QPushButton('Add/Activate')
        self.qAddActivateCtrlsFontMetrics = QtGui.QFontMetrics(self.qAddActivateButton.font())
        self.qAddActivateButton.clicked.connect(self.addActivateCtrlButtonCall)

        self.qCtrlsTree = QMeshesTreeWidget()
        self.qCtrlsTree.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qCtrlsTree.customContextMenuRequested.connect(self.markingMenuCtrls)
        self.qCtrlsTree.header().setStretchLastSection(True)
        self.qCtrlsTree.itemChanged.connect(self.userChecksOrUnchecksCtrl)

        self.qCtrlsFilter = utilsQt.QFilter()
        self.qCtrlsFilter.changed.connect(self.updateCtrlsVisibilities)
        qCtrlsLayoutB.addWidget(self.qAddActivateButton)
        qCtrlsLayoutB.addWidget(self.qCtrlsFilter)
        qCtrlsLayoutB.addWidget(self.qCtrlsTree)

        self.refreshCtrlsTreeFromScene()


        self.refreshTargetsTreeFromScene()




        # TOOLS

        qToolsGroupLayout = utilsQt.createGroupBoxLayout(self.layout, 'Tools', bHorizontalLayout=True)
        self.qMasterMesh = QSetObject()
        self.qMasterMesh.build(qToolsGroupLayout, 'Master', 'sMasterMesh')

        self.qInbetweensBox = QtWidgets.QComboBox()
        [self.qInbetweensBox.addItem(sLabel) for sLabel in ['Main Target And Inbetweens', 'Only Main Targets', 'Only Closest Inbetween']]
        qToolsGroupLayout.addWidget(self.qInbetweensBox)

        qToolsButton = QtWidgets.QPushButton('TOOLS')
        qToolsGroupLayout.addWidget(qToolsButton)
        qToggleVisButton = QtWidgets.QPushButton('Toggle Master Vis')

        def _toggleSnapMeshVis():
            sMesh = self.qMasterMesh.getObject()
            bVis = cmds.getAttr('%s.v' % sMesh)
            cmds.setAttr('%s.v' % sMesh, not bVis)
        qToggleVisButton.clicked.connect(_toggleSnapMeshVis)
        qToolsGroupLayout.addWidget(qToggleVisButton)

        def _toolsMenu():
            sMaster = self.qMasterMesh.getObject()
            sMode = self.qInbetweensBox.currentText()
            bMasterIsMesh = sMaster and sMaster.strip() and cmds.objExists(sMaster) and cmds.listRelatives(sMaster, typ='mesh', c=True)
            bMasterIsCurve = sMaster and sMaster.strip() and cmds.objExists(sMaster) and cmds.listRelatives(sMaster, typ='nurbsCurve', c=True)

            qToolsMenu = QtWidgets.QMenu()
            dSelectedTargets = self._getTargetNames(bSelected=True, bReturnDict=True)
            sSelectedTargets = list(dSelectedTargets.keys())
            # qSelectedTargets = self._getTargetNames(bSelected=True, bReturnItems=True)
            iAllSelectedTargetsCount = len(dSelectedTargets)

            dSelectedBlendShapes = defaultdict(list)
            for sObj in cmds.ls(sl=True):
                sMesh = sObj.split('.')[0]
                sBlendShape = 'blendShape__%s' % sMesh
                if cmds.objExists(sBlendShape):
                    dSelectedBlendShapes[sBlendShape].append(sObj)


            sAllSelectionBefore = cmds.ls(sl=True)

            # dRigPoseAttrs = defaultdict(dict)
            # for sTarget in sSelectedTargets:
            #     qTarget = dSelectedTargets[sTarget]
            #     sTargetPoses = self._getTargetPoses(qTarget)
            #     for sTargetPose in sTargetPoses:
            #         sInterp, sPose = sTargetPose.split('.')
            #         sAttrValuePairs = self._getRotations(sInterp, sPose)
            #         dRigPoseAttrs[sTarget].update(dict(sAttrValuePairs))
            dRigPoseAttrs = self.getTargetDictForTools(sSelectedTargets)


            def _snap(sSelectedTargets=sSelectedTargets):
                sActivatedTarget = self.isAnyEditIActivated()
                if sActivatedTarget:
                    cmds.confirmDialog(
                        m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                    return

                try:
                    cmds.undoInfo(openChunk=True)
                    for sBlendShape, sComponents in dSelectedBlendShapes.items():
                        cmds.select(sComponents)
                        tools.snapSelectedMeshes(self.qMasterMesh.getObject(), sBlendShape, sTargets=sSelectedTargets,
                                                 iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            def _warp(sSelectedTargets=sSelectedTargets, bRigid=False, bUvs=False):
                sActivatedTarget = self.isAnyEditIActivated()
                if sActivatedTarget:
                    cmds.confirmDialog(
                        m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                    return

                try:
                    cmds.undoInfo(openChunk=True)
                    for sBlendShape, sComponents in dSelectedBlendShapes.items():
                        self.activateTargetsIfNotActive(sBlendShape, sSelectedTargets)
                        tools.warp(self.qMasterMesh.getObject(), sBlendShape, sTargets=sSelectedTargets, bRigid=bRigid, bUvs=bUvs,
                                   iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)
                    cmds.select(sAllSelectionBefore)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            def _blendIds(sSelectedTargets=sSelectedTargets):
                sActivatedTarget = self.isAnyEditIActivated()
                if sActivatedTarget:
                    cmds.confirmDialog(
                        m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                    return

                try:
                    cmds.undoInfo(openChunk=True)
                    for sBlendShape, sComponents in dSelectedBlendShapes.items():
                        cmds.select(sComponents)
                        try:
                            tools.blendIds(self.qMasterMesh.getObject(), sBlendShape, sTargets=sSelectedTargets,
                                           iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)
                        except Exception as e:
                            cmds.confirmDialog(m=str(e))
                            raise
                    cmds.select(sAllSelectionBefore)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            def _smoothVertices(sSelectedTargets=sSelectedTargets):
                def __smoothVertices(iIterations):
                    sActivatedTarget = self.isAnyEditIActivated()
                    if sActivatedTarget:
                        cmds.confirmDialog(
                            m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                        return

                    try:
                        cmds.undoInfo(openChunk=True)
                        for sBlendShape, sComponents in dSelectedBlendShapes.items():
                            cmds.select(sComponents)
                            tools.smoothVertices(sBlendShape, sTargets=sSelectedTargets, iInbetweensMode=self.qInbetweensBox.currentIndex(),
                                                 iIterations=iIterations, bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)
                        cmds.select(sAllSelectionBefore)
                    except:
                        raise
                    finally:
                        cmds.undoInfo(closeChunk=True)

                self.qSmoothDialog = utilsQt.QGetFloatDialog(__smoothVertices, sDefault='4', sMessage='Enter Factor')
                self.qSmoothDialog.show()


            def _wire(sSelectedTargets=sSelectedTargets):
                sActivatedTarget = self.isAnyEditIActivated()
                if sActivatedTarget:
                    cmds.confirmDialog(
                        m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                    return

                try:
                    cmds.undoInfo(openChunk=True)
                    for sBlendShape, sComponents in dSelectedBlendShapes.items():
                        cmds.select(sComponents)

                    tools.wireWarp([self.qMasterMesh.getObject()], sBlendShape, sTargets=sSelectedTargets,
                                   iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)


            def _multiply(sSelectedTargets=sSelectedTargets, bAlongTargetY=False):
                sActivatedTarget = self.isAnyEditIActivated()
                if sActivatedTarget:
                    cmds.confirmDialog(
                        m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                    return

                try:
                    utils.reload2(tools)
                    cmds.undoInfo(openChunk=True)
                    for sBlendShape, sComponents in dSelectedBlendShapes.items():
                        cmds.select(sComponents)
                        if bAlongTargetY:
                            tools.multiplyTargets(sBlendShape, sSelectedTargets, fFactor=None, sAlongTransformY=self.qMasterMesh.getObject(),
                                                  iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)
                        else:
                            tools.multiplyTargets(sBlendShape, sSelectedTargets, fFactor=None,
                                                  iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)

                    cmds.select(sAllSelectionBefore)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)


            qDisableActionsIfNoTargets = []

            if bMasterIsMesh:
                qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Warp to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _warp))
                qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Warp Rigid to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), lambda: _warp(bRigid=True)))
                qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Warp UVs to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), lambda: _warp(bUvs=True)))
                qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Snap to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _snap))
                qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Blend IDs to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _blendIds))
            else:
                for sAction in ['Snap', 'Warp', 'Warp Rigid', 'Warp UVs', 'Blend IDs']:
                    qDisabledAction = qToolsMenu.addAction('%s (Need to set Master Mesh!)' % sAction)
                    qDisabledAction.setEnabled(False)

            qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Multiply (%d Targets)' % iAllSelectedTargetsCount, _multiply))
            qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Multiply Along Y of "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), lambda: _multiply(bAlongTargetY=True)))
            qDisableActionsIfNoTargets.append(qToolsMenu.addAction('Smooth Vertices (%d Targets)' % iAllSelectedTargetsCount, _smoothVertices))

            if not iAllSelectedTargetsCount:
                [qAction.setEnabled(False) for qAction in qDisableActionsIfNoTargets]

            if bMasterIsCurve:
                qToolsMenu.addAction('Warp Wire to "%s" (%d Targets)' % (sMaster, iAllSelectedTargetsCount), _wire)
            else:
                qDisabledAction = qToolsMenu.addAction('Warp Wire')
                qDisabledAction.setEnabled(False)

            qToolsMenu.exec_(QtGui.QCursor().pos())

        qToolsButton.clicked.connect(_toolsMenu)


        switchAllToFk(bAsk=True)
        self.qStatusLabel = QtWidgets.QLabel('...')
        self.layout.addWidget(self.qStatusLabel)

        def updateAllTrees():
            self.refreshInterpTreeFromScene()
            self.refreshAttributes(0)
            self.refreshTargetsTreeFromScene()
            self.refreshMeshesTreeFromScene()
            self.refreshCtrlsTreeFromScene()
        self.iRefreshOnSceneOpenScriptJob = cmds.scriptJob(event=['SceneOpened', updateAllTrees])
        self.iSelectionChangedScriptJob = cmds.scriptJob(event=['SelectionChanged', self.updateAddActiveCtrlButton])


    def closeEvent(self, event):
        self.timer.stop()
        cmds.scriptJob(kill=self.iRefreshOnSceneOpenScriptJob)
        cmds.scriptJob(kill=self.iSelectionChangedScriptJob)
        # self.qButton.clicked.connect(lambda: qLine.setText(''))


    def getTargetDictForTools(self, sTargets):
        dRigPoseAttrs = defaultdict(dict)
        for sTarget in sTargets:
            qTarget = self._getTargetItemFromName(sTarget)
            sTargetPoses = self._getTargetPoses(qTarget)
            for sTargetPose in sTargetPoses:
                sInterp, sPose = sTargetPose.split('.')
                sAttrValuePairs = getPoseValues(sInterp, sPose, bAlsoReturnAttrs=True)
                dRigPoseAttrs[sTarget].update(dict(sAttrValuePairs))
        return dRigPoseAttrs

    def isolateTargetsClicked(self, bInput):
        self.qTargetsFilter.clearFilter(bBlockSignals=True)
        sSelectedTargets = self._getTargetNames(bSelected=True)

        for sTarget, qTarget in self._getTargetNames(bReturnDict=True).items():
            dTarget = qTarget.data(0, QtCore.Qt.UserRole)
            dTarget['bIsolated'] = sTarget in sSelectedTargets
            qTarget.setData(0, QtCore.Qt.UserRole, dTarget)

        self.refreshTargetsTreeFromScene()


    def updateAddActiveCtrlButton(self):
        sSelectedCtrls = cmds.ls('*_ctrl', sl=True)


        if self._getTargetNames(bSelected=True):
            if sSelectedCtrls:
                sText = 'Add/Activate %s' %  utils.listToString(sSelectedCtrls, iMaxCount=10, bQuotations=True)
                sText = self.qAddActivateCtrlsFontMetrics.elidedText(sText, QtCore.Qt.ElideRight, self.qAddActivateButton.width() - 10)
                self.qAddActivateButton.setText(sText)
                self.qAddActivateButton.setEnabled(True)
            else:
                self.qAddActivateButton.setText('Add ...')
                self.qAddActivateButton.setEnabled(False)

        else:
            if sSelectedCtrls:
                sText = 'Add %s' % utils.listToString(sSelectedCtrls, iMaxCount=10, bQuotations=True)
                sText = self.qAddActivateCtrlsFontMetrics.elidedText(sText, QtCore.Qt.ElideRight, self.qAddActivateButton.width() - 10)
                self.qAddActivateButton.setText(sText)
                self.qAddActivateButton.setEnabled(True)
            else:
                self.qAddActivateButton.setText('Add ...')
                self.qAddActivateButton.setEnabled(False)


    def addActivateCtrlButtonCall(self):
        sAllSelectedCtrls = cmds.ls('*_ctrl', sl=True, et='transform') + cmds.ls('*_ctrl', sl=True, et='joint')
        if self._getTargetNames(bSelected=True):
            self.addCtrlsAndActivate(sAllSelectedCtrls)
        else:
            sAllCtrlsInUI = [self._getCtrlNameFromItem(self.qCtrlsTree.invisibleRootItem().child(iCtrl)) for iCtrl in range(self.qCtrlsTree.invisibleRootItem().childCount())]
            selectedCtrlsNotInUI = [sCtrl for sCtrl in sAllSelectedCtrls if sCtrl not in sAllCtrlsInUI]
            self.addCtrls(selectedCtrlsNotInUI)



    def isolateInterpsClicked(self, bInput):
        self.qInterpsFilter.clearFilter(bBlockSignals=True)

        sSelectInterps = []
        for iInterp in range(self.qMainTree.invisibleRootItem().childCount()):
            qInterp = self.qMainTree.invisibleRootItem().child(iInterp)
            dInterp = qInterp.data(0, QtCore.Qt.UserRole)
            bIsolated = qInterp.isSelected()
            dInterp['bIsolated'] = bIsolated
            qInterp.setData(0, QtCore.Qt.UserRole, dInterp)
            sInterp = qInterp.text(0).split(' ')[0]
            if bIsolated:
                sSelectInterps.append(sInterp)

        self.refreshInterpTreeFromScene(sSelectInterps=sSelectInterps)







    # def updateTargetsFilter(self, sFilters):
    #     dTargets = self._getTargetNames(bReturnDict=True)
    #     for sTarget, qTarget in dTargets.items():
    #
    #         if not sFilters:
    #             qTarget.setHidden(False)
    #         else:
    #             bHidden = True
    #             for sFilter in sFilters:
    #                 if sFilter.upper() in sTarget.upper():
    #                     bHidden = False
    #                     break
    #             qTarget.setHidden(bHidden)


    def _getTargetPoses(self, qTarget):
        sTargetPoses = []
        for iPose in range(qTarget.childCount()):
            sTargetPoses.append(qTarget.child(iPose).text(0).split(' ')[0])
        return sTargetPoses


    def _getInterpPoses(self, qInterp):
        sInterpPoses = []
        sInterp = qInterp.text(0).split(' ')[0]
        for iPose in range(qInterp.childCount()):
            sInterpPoses.append('%s.%s' % (sInterp, qInterp.child(iPose).text(0)))
        return sInterpPoses


    # def _getRotations(self, sInterp, sPose):
    #     sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
    #
    #     if cmds.getAttr('%s.sInterpType' % sInterp) == 'cone':
    #         fRotation = cmds.getAttr('%s_%s_cone.r' % (sInterp, sPose))[0]
    #         return [('%s.rx' % sCtrl, fRotation[0]), ('%s.ry' % sCtrl, fRotation[1]), ('%s.rz' % sCtrl, fRotation[2])]
    #     else:
    #         xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
    #         for p, xPose in enumerate(xPoses):
    #             if sPose == xPose[0]:
    #                 fRotation = xPose[1:4]
    #                 return [('%s.rx' % sCtrl, fRotation[0]), ('%s.ry' % sCtrl, fRotation[1]), ('%s.rz' % sCtrl, fRotation[2])]


    def _getTargetNames(self, bSelected=False, bCountPoseSelectionAsSelected=False, bReturnDict=False):
        sTargets = []
        qTargets = []
        for t in range(self.qTargetsTree.invisibleRootItem().childCount()):
            qTarget = self.qTargetsTree.invisibleRootItem().child(t)

            if not bSelected:
                bAppendIt = True
            if bSelected:
                if qTarget.isSelected():
                    bAppendIt = True
                else:
                    bAppendIt = False
                    if bCountPoseSelectionAsSelected:
                        for iPose in range(qTarget.childCount()):
                            if qTarget.child(iPose).isSelected():
                                bAppendIt = True
                                break

            if bAppendIt:
                # QTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
                sTargets.append(self._targetNameFromTargetItem(qTarget))
                qTargets.append(qTarget)

        if bReturnDict:
            return dict(zip(sTargets, qTargets))
        else:
            return sTargets



    def _getTargetItemFromName(self, sTarget):
        for iTarget in range(self.qTargetsTree.invisibleRootItem().childCount()):
            qTarget = self.qTargetsTree.invisibleRootItem().child(iTarget)
            # qTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
            # if qTargetWidget.qName.getName() == sTarget:
            if self._targetNameFromTargetItem(qTarget) == sTarget:
                return qTarget


    def _getTargetNameFromItem(self, qTarget):
        QTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
        sTarget = QTargetWidget.qName.getName()
        return sTarget


    def sliderPressed(self, sTarget, qTargetWidget):

        sSelectedTargets = self._getTargetNames(bSelected=True, )
        self.dCtrlsBefore = {}
        self.iSlidersBefore = {}

        sDoTargets = sSelectedTargets if sTarget in sSelectedTargets else [sTarget]

        dAllTargets = self._getTargetNames(bReturnDict=True)
        self.dTargetsFromBlendShapesForSlider = {}
        for sTarget, qTarget in dAllTargets.items():
            self.dTargetsFromBlendShapesForSlider[sTarget] = self._getTargetPoses(qTarget)


        for sT in sDoTargets:
            sPoses = self.dTargetsFromBlendShapesForSlider[sT]
            self.recordCtrls(sPoses, self.dCtrlsBefore, self.iSlidersBefore)




    def sliderReleased(self, sTarget, qTargetWidget):
        cmds.undoInfo(openChunk=True)
        try:

            sSelectedTargets = self._getTargetNames(bSelected=True)
            sDoTargets = sSelectedTargets if sTarget in sSelectedTargets else [sTarget]
            qDoTargetWidgets = [self.qTargetsTree.itemWidget(self._getTargetItemFromName(sTarget), 0) for sTarget in sDoTargets]
            # dTargetsFromBlendShapes = self._getAllTargetsFromBlendShapesAndCtrls()
            
            dCtrlsAfter = {}
            for sT in sDoTargets:
                sPoses = self.dTargetsFromBlendShapesForSlider[sT]
                self.recordCtrls(sPoses, dCtrlsAfter)

            dRedoSliders = {qTargetWidget.qSlider:qTargetWidget.qSlider.value() for qTargetWidget in qDoTargetWidgets}
            def _redo(dCtrlsAfter=dCtrlsAfter, dRedoSliders=dRedoSliders):
                cmds.undoInfo(swf=False)
                try:
                    for sCtrlAttr, fV in dCtrlsAfter.items():
                        cmds.setAttr(sCtrlAttr, fV)
                    for qSlider, iValue in dRedoSliders.items():
                        qSlider.blockSignals(True)
                        qSlider.setValue(iValue)
                        qSlider.blockSignals(False)
                        self.recordSliderValue(qSlider)

                except:
                    raise
                finally:
                    cmds.undoInfo(swf=True)

            dUndoSliders = {qTargetWidget.qSlider:self.dSliderValuesBeforeDrag[qTargetWidget.qSlider] for qTargetWidget in qDoTargetWidgets}
            def _undo(dCtrlsBefore=self.dCtrlsBefore, dUndoSliders=dUndoSliders):
                cmds.undoInfo(swf=False)
                try:
                    for sCtrlAttr, fV in dCtrlsBefore.items():
                        cmds.setAttr(sCtrlAttr, fV)
                    for qSlider, iValue in dUndoSliders.items():
                        qSlider.blockSignals(True)
                        qSlider.setValue(iValue)
                        qSlider.blockSignals(False)
                        self.recordSliderValue(qSlider)
                except:
                    raise
                finally:
                    cmds.undoInfo(swf=True)


            for qTargetWidget in qDoTargetWidgets:
                self.recordSliderValue(qTargetWidget.qSlider)


            # self.funcRedoUndoStack is just to make sure the functions are stayhing in memory
            self.funcRedoUndoStack.append(_redo)
            self.funcRedoUndoStack.append(_undo)
            if len(self.funcRedoUndoStack) > 50:
                self.funcRedoUndoStack = self.funcRedoUndoStack[-50:]

            dSetUiData = {'funcRedo':_redo, 'funcUndo':_undo}
            cmds.kt_cmdUndo(dt=str(id(dSetUiData)))
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)




    def sliderValueChanged(self, sTarget, qTargetWidget, iValue):
        cmds.undoInfo(swf=False)
        try:
            sSelectedTargets = self._getTargetNames(bSelected=True)
            sDoTargets = sSelectedTargets if sTarget in sSelectedTargets else [sTarget]

            # dTargetsFromBlendShapes = self._getAllTargetsFromBlendShapesAndCtrls()
            for sT in sDoTargets:
                sPoses = self.dTargetsFromBlendShapesForSlider[sT]
                self.poseTo(sPoses, iValue * 0.01, bSkipReverse=True)

            for sTarget in sDoTargets: # moves the actual one again, but who cares, the value is identical anyway
                qTarget = self._getTargetItemFromName(sTarget)
                qTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
                qTargetWidget.qSlider.blockSignals(True)
                qTargetWidget.qSlider.setValue(iValue)
                qTargetWidget.qSlider.blockSignals(False)
        except:
            raise
        finally:
            cmds.undoInfo(swf=True)




    def activateTargetsIfNotActive(self, sBlendShape, sTargets):
        for sTarget in utils.toList(sTargets):
            sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
            if not cmds.objExists(sTargetAttr):
                blendShapes.addEmptyTarget(sBlendShape, sTarget)
            if not cmds.listConnections(sTargetAttr, s=True, d=False):


                cmds.connectAttr(getComboOutput(getTargetArrayMultiplName(sTarget)), sTargetAttr)

        self.refreshMeshesTreeFromScene()


    def editClicked(self, sTarget, bStatus, qEditButton):
        print ('edit clicked..', bStatus)

        def _unCheckButton():
            qEditButton.blockSignals(True)
            qEditButton.setChecked(False)
            qEditButton.setText('EDIT MESH')
            qEditButton.blockSignals(False)

        if bStatus:
            sSelBefore = cmds.ls(sl=True)
            sBlendShapes = []
            sMeshes = []

            sSelectedObjects = [sObj.split('.')[0] for sObj in cmds.ls(sl=True, et='transform')]
            for sObj in set(sSelectedObjects):
                sMesh = sObj.split('.')[0]
                if sMesh not in sMeshes:
                    _sBlendShape = 'blendShape__%s' % sMesh.split('.')[0]
                    if not cmds.objExists(_sBlendShape):
                        cmds.confirmDialog(m=f'{sMesh} is not a mesh with a blendShape. Add it to the list first')
                    else:
                        sBlendShapes.append(_sBlendShape)
                        sMeshes.append(sMesh)


            if not sBlendShapes:
                utils.registerRedoAndUndo(funcRedo=_unCheckButton())
            else:
                cmds.undoInfo(openChunk=True)
                try:

                    utils.registerRedoAndUndo(funcUndo=_unCheckButton)

                    sCurrentSculptBlendShapes = []
                    for sBlendShape in sBlendShapes:
                        utils.addAttr(sBlendShape, ln=kIsPoseEditorBlendShapeAttr, k=True, bReturnIfExists=True)

                        self.activateTargetsIfNotActive(sBlendShape, sTarget)

                        dTargets = blendShapes.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
                        iTarget = dTargets[sTarget]

                        cmds.sculptTarget(sBlendShape, e=True, t=iTarget)
                        sCurrentSculptBlendShapes.append(sBlendShape)

                    def _checkButton():
                        qEditButton.blockSignals(True)
                        qEditButton.setChecked(True)
                        qEditButton.setText('EDIT (%s)' % utils.listToString(sMeshes))
                        qEditButton.blockSignals(False)
                    utils.registerRedoAndUndo(funcRedo=_checkButton)

                    cmds.select(sSelBefore)
                    utils.data.store('sCurrentSculptBlendShapes', sCurrentSculptBlendShapes)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

        else: # user deactivates
            sButtonText = qEditButton.text()
            def _checkButton(sButtonText=sButtonText):
                qEditButton.blockSignals(True)
                qEditButton.setChecked(True)
                qEditButton.setText(sButtonText)
                qEditButton.blockSignals(False)
            try:
                cmds.undoInfo(openChunk=True)
                utils.registerRedoAndUndo(funcUndo=_checkButton)

                sCurrentSculptBlendShapes = utils.data.get('sCurrentSculptBlendShapes')
                for sBlendShape in sCurrentSculptBlendShapes:
                    cmds.sculptTarget(sBlendShape, e=True, t=-1)

                utils.registerRedoAndUndo(funcRedo=lambda: qEditButton.setText('EDIT MESH'))
            except:
                raise
            finally:
                cmds.undoInfo(closeChunk=True)
    def targetNameChanged(self, sTarget, sNewTarget, qTargetWidget):
        try:
            print ('target name changed...')
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshCtrlsTreeFromScene)

            sBlendShapes = _getBlendShapes()
            sUndoMessage = None
            if self._getTargetNames().count(sNewTarget) >= 2:
               sUndoMessage = 'There is already a target called "%s", remove that and try again' % sNewTarget
            else:
                sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)
                if not cmds.objExists(sTargetArrayMultipl):
                    raise Exception('%s doesn\t exist' % sTargetArrayMultipl)
                cmds.rename(sTargetArrayMultipl, '%s__%s' % (kTargetArrayMultipl, sNewTarget))

                for sBlendShape in sBlendShapes:
                    if cmds.objExists('%s.%s' % (sBlendShape, sNewTarget)):
                        sUndoMessage = '%s already has a target called "%s", remove that and try again' % (sBlendShape, sNewTarget)
                        break

                if not sUndoMessage:
                    for sPoseLoc in cmds.ls(f'_poseLocEditor__*__{sTarget}'):
                        sSplits = sPoseLoc.split('__')
                        sSplits[-1] = sNewTarget
                        cmds.rename(sPoseLoc, '__'.join(sSplits))
                    for sWeightNode in cmds.ls(f'WEIGHT__*__{sTarget}__?'):
                        sSplits = sWeightNode.split('__')
                        sSplits[2] = sNewTarget
                        cmds.rename(sWeightNode, '__'.join(sSplits))

            if sUndoMessage:
                cmds.confirmDialog(m=sUndoMessage)
                qTargetWidget.blockSignals(True)
                qTargetWidget.qName.setName(sTarget)
                qTargetWidget.blockSignals(False)
                return
            else:
                for sBlendShape in sBlendShapes:
                    if cmds.objExists('%s.%s' % (sBlendShape, sTarget)):
                        blendShapes.renameTarget(sBlendShape, sTarget, sNewTarget)

            utils.registerRedoAndUndo(funcRedo=self.refreshCtrlsTreeFromScene)

        except Exception as e:
            cmds.confirmDialog(m=str(e))
        finally:
            cmds.undoInfo(closeChunk=True)

    def postChanged(self, sTarget, bState):
        print ('post changed: ', sTarget, bState)
        sArrayMultipl = getTargetArrayMultiplName(sTarget)
        cmds.setAttr('%s.bPost' % sArrayMultipl, bState)


    def comboModeChanged(self, sTarget, sMode):
        try:
            cmds.undoInfo(openChunk=True)
            sSelectionBefore = cmds.ls(sl=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)
            getTargetArrayMultipl(sTarget, bForceRecreate=True, sMode=sMode)
            cmds.select(sSelectionBefore)
            utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene)

        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def addTargetToTree(self, sTarget, sPoseOutputs, iNonDriverInputs=set(), bSelect=False, bIsolated=False, bPost=False, sMode='M'):
        print ('adding target to tree: ', sTarget)
        qTargetWidget = QTargetWidget(sTarget, self.qTargetsTree, bPost=bPost, sMode=sMode)
        qTargetWidget.sliderPressed.connect(self.sliderPressed)
        qTargetWidget.sliderValueChanged.connect(self.sliderValueChanged)
        qTargetWidget.sliderReleased.connect(self.sliderReleased)
        qTargetWidget.editClicked.connect(self.editClicked)
        qTargetWidget.targetNameChanged.connect(self.targetNameChanged)
        qTargetWidget.postChanged.connect(self.postChanged)
        qTargetWidget.comboModeChanged.connect(self.comboModeChanged)
        qTarget = QtWidgets.QTreeWidgetItem(self.qTargetsTree)
        self.qTargetsTree.setItemWidget(qTarget, 0, qTargetWidget)
        qTarget.setData(0, QtCore.Qt.UserRole, {'bIsolated':bIsolated})
        self.qTargetsTree.invisibleRootItem().addChild(qTarget)
        if bSelect:
            qTarget.setSelected(True)
        for p, sPoseKey in enumerate(sPoseOutputs):
            qPose = QtWidgets.QTreeWidgetItem(qTarget)
            if p in iNonDriverInputs:
                qPose.setText(0, '%s %s' % (sPoseKey, kNoDriverSuffix))
                qPose.setFont(0, qItalicFont)
            else:
                qPose.setText(0, sPoseKey)
            qPose.setFlags(qPose.flags() & ~QtCore.Qt.ItemIsDropEnabled)

        if len(sPoseOutputs) <= 1:
            qTargetWidget.qComboButton.setHidden(True)

        self.recordSliderValue(qTargetWidget.qSlider)

        return qTarget


    def refreshTargetsTreeFromScene(self, sSelectTargets=None):

        sPreviousExpandedTargets = []
        sPreviousSelectedTargets = []
        sPreviousIsolatedTargets = []
        for iTarget in range(self.qTargetsTree.invisibleRootItem().childCount()):
            qTarget = self.qTargetsTree.invisibleRootItem().child(iTarget)
            sTarget = self._targetNameFromTargetItem(qTarget)
            if qTarget.isExpanded():
                sPreviousExpandedTargets.append(sTarget)
            if qTarget.isSelected():
                sPreviousSelectedTargets.append(sTarget)
            if qTarget.data(0, QtCore.Qt.UserRole)['bIsolated']:
                sPreviousIsolatedTargets.append(sTarget)

        iScrollPos = self.qTargetsTree.verticalScrollBar().value()

        self.qTargetsTree.clear()

        # dTargets = self._getAllTargetsFromBlendShapesAndCtrls()
        sTargetMultipls = cmds.ls('%s__*' % kTargetArrayMultipl)
        for sTargetMultipl in sTargetMultipls:

            sTarget = sTargetMultipl.split('__')[1]
            bIsolated = sTarget in sPreviousIsolatedTargets
            sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetMultipl))
            iNonDriverInputs = eval(cmds.getAttr('%s.iNonDriverInputs' % sTargetMultipl))
            qTarget = self.addTargetToTree(sTarget, sPoseOutputs, iNonDriverInputs, bIsolated=bIsolated, bPost=cmds.getAttr('%s.bPost' % sTargetMultipl),
                                           sMode=utils.getAttrIfExists('%s.sMode' % sTargetMultipl, 'M')) #, bSelect=sTarget in sSelectTargets)
            if sTarget in sPreviousExpandedTargets:
                qTarget.setExpanded(True)
            if sTarget in (sSelectTargets if not utils.isNone(sSelectTargets) else sPreviousSelectedTargets):
                qTarget.setSelected(True)
                dTarget = qTarget.data(0, QtCore.Qt.UserRole)
                dTarget['bIsolated'] = True
                qTarget.setData(0, QtCore.Qt.UserRole, dTarget)
        self.updateTargetVisibilities()

        self.qTargetsTree.verticalScrollBar().setSliderPosition(iScrollPos)


    def updateTargetVisibilities(self, _=None):
        sFilters = self.qTargetsFilter.getFilter()
        for sTarget, qTarget in self._getTargetNames(bReturnDict=True).items():
            if self.qTargetsIsolateButton.isChecked() and not qTarget.data(0, QtCore.Qt.UserRole)['bIsolated']:
                qTarget.setHidden(True)
            elif sFilters:
                bHidden = True
                for sFilter in sFilters:
                    if sFilter.upper() in sTarget.upper():
                        bHidden = False
                        break
                qTarget.setHidden(bHidden)

    def createNewTargetFromDrop(self, qPoses):
        qSelectedCtrls = self.qCtrlsTree.selectedItems()

        sFirstInterpTransform = self._transformFromInterpItem(qPoses[0].parent())

        sSplits = sFirstInterpTransform.split('_')
        if sSplits[0] == 'interp':
            del sSplits[0]
        else:
            sSplits[0] = sSplits[0].replace('Interp', '')


        sTarget = '%s_%s' % ('_'.join(sSplits), qPoses[0].text(0))
        sTarget = utils.getUniqueNameFromList(sTarget, self._getTargetNames())
        sPoseOutputs = ['%s.%s' % (self._transformFromInterpItem(qPose.parent()), qPose.text(0)) for qPose in qPoses]

        sTargetArrayMultipl = getTargetArrayMultipl(sTarget, sPoseOutputs)

        utils.addAttr(sTargetArrayMultipl.split('.')[0], ln='bPost', at='bool', k=True, dv=False, bReturnIfExists=True)
        qSelectedMeshes = self.qMeshesTree.selectedItems()
        for qMesh in qSelectedMeshes:
            sMesh = self._getMeshNameFromItem(qMesh)
            sBlendShape = 'blendShape__%s' % sMesh
            sTargetAttr = blendShapes.addEmptyTarget(sBlendShape, sTarget)
            cmds.connectAttr(sTargetArrayMultipl, sTargetAttr)

        for qCtrl in qSelectedCtrls:
            reconnectPoseLoc(self._getCtrlNameFromItem(qCtrl), sTarget)# , sPoseOutputs)



        self.refreshTargetsTreeFromScene([sTarget])



    def mirrorTargetsMiddle(self, bMeshes=False, bCtrls=False, bLeftToRight=True, sCtrlsMask=None):
        dTargets = self._getTargetNames(bSelected=True, bReturnDict=True)
        sTargets = list(dTargets.keys())

        try:
            cmds.undoInfo(openChunk=True)
            if bCtrls:
                utils.registerRedoAndUndo(funcUndo=self.refreshCtrlsTreeFromScene)

            if bMeshes:
                utils.reload2(tools)
                sGeoTargets = []
                pSelectedMeshes = [pMesh for pMesh in patch.getSelectedPatches() if cmds.objExists('blendShape__%s' % pMesh.getTransformName())]

                for m, pMesh in enumerate(pSelectedMeshes):
                    sMesh = pMesh.getTransformName()
                    sBlendShape = 'blendShape__%s' % sMesh
                    dRigPoseAttrs = self.getTargetDictForTools(sGeoTargets)
                    tools.mirrorTargets(sBlendShape, sTargets, sMeshes=[sMesh], iDirection=tools.MirrorDirection.leftToRight if bLeftToRight else tools.MirrorDirection.rightToLeft,
                                        bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)

            if bCtrls:
                sAllCtrls = sCtrlsMask or self._getAllCtrlsInScene()
                for sTarget in sTargets:
                    for sCtrl in sAllCtrls:
                        sSide = utils.getSide(sCtrl)
                        if sSide == 'r' and bLeftToRight:
                            continue
                        elif sSide == 'l' and not bLeftToRight:
                            continue

                        sPoseLoc = f'_poseLocEditor__{sCtrl}__{sTarget}'
                        if cmds.objExists(sPoseLoc):
                            sToCtrl = utils.getMirrorName(sCtrl)

                            createCtrlPosesSetup(sToCtrl, [sTarget])
                            bIsConnected = cmds.objExists(getWeightMultiplName(sCtrl, sTarget, 't'))
                            print ('bIsConnected:', bIsConnected)
                            if not bIsConnected:
                                print ('trying to disconnect:')
                                disconnectPoseLoc(sToCtrl, sTarget)

                            utils.addStringAttr(sToCtrl, 'poseEditor', sToCtrl)
                            self.__sSavedAllCtrls.append(sToCtrl)
                            sToPoseLoc = f'_poseLocEditor__{sToCtrl}__{sTarget}'
                            for sA in 'trs':
                                cmds.setAttr('%s.%s' % (sToPoseLoc, sA), *cmds.getAttr('%s.%s' % (sPoseLoc, sA))[0])

                            if utils.getSide(sCtrl) == 'm':
                                iPlane = int(utils.getAttrIfExists('%s.%s' % (sCtrl, kMiddleCtrlMirrorPlaneAttr), 1))
                                sNegateTranslateAttr = ['tx', 'ty', 'tz'][iPlane]
                                cmds.setAttr('%s.%s' % (sToPoseLoc, sNegateTranslateAttr),
                                             -cmds.getAttr('%s.%s' % (sToPoseLoc, sNegateTranslateAttr)))

                                iNegateRotations = set([0, 1, 2]) - set([iPlane])
                                for iNegateR in iNegateRotations:
                                    sNegateRotateAttr = ['rx', 'ry', 'rz'][iNegateR]
                                    cmds.setAttr('%s.%s' % (sToPoseLoc, sNegateRotateAttr),
                                                 -cmds.getAttr('%s.%s' % (sToPoseLoc, sNegateRotateAttr)))

            if bCtrls:
                utils.registerRedoAndUndo(funcRedo=self.refreshCtrlsTreeFromScene)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)




    def mirrorTargets(self, bToSelected=False, bMeshes=False, bCtrls=False, bSplitCurrentShape=False, fSplitMeshRadius=None, sCtrlsMask=None):

        dTargets = self._getTargetNames(bSelected=True, bReturnDict=True)
        sAllTargets = self._getTargetNames()

        if bMeshes:
            sActivatedTarget = self.isAnyEditIActivated()
            if sActivatedTarget:
                cmds.confirmDialog(m='All EDIT buttons must be deactivated for this. Currently "%s" is activated' % sActivatedTarget)
                return

            if bSplitCurrentShape:
                if len(dTargets) > 1:
                    if cmds.confirmDialog(m='You chose Split Meshes but selected more than one target. This could give unwanted results. \nContinue?', button=['yes', 'no']) == 'no':
                        return

                if fSplitMeshRadius == None:
                    fSplitMeshRadius = utilsQt.getFloatValueFromDialog('Enter Split Radius', 2.0, sConfigKey='_poseEditorSplitRadius')

        sSelectionBefore = cmds.ls(sl=True)
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)
            if bMeshes:
                utils.registerRedoAndUndo(funcUndo=self.refreshMeshesTreeFromScene)
            if bCtrls:
                utils.registerRedoAndUndo(funcUndo=self.refreshCtrlsTreeFromScene)

            sSelectTargets = []

            sTargets = []
            sToTargets = []
            sSkipTargets = set()
            for sTarget, qTarget in dTargets.items():
                sToTarget = utils.getMirrorName(sTarget)

                if bToSelected:
                    if sToTarget not in sAllTargets:
                        print ('skipping because %s doesn\'t exist' % sToTarget)
                        continue
                    sTarget, sToTarget = sToTarget, sTarget
                    qTarget = self._getTargetItemFromName(sTarget)

                sTargets.append(sTarget)
                sToTargets.append(sToTarget)

                sToPoseOutputs = []
                sPoseOutputs = []
                iNonDriverInputs = set()
                for p in range(qTarget.childCount()):
                    sPoseText = qTarget.child(p).text(0)
                    sPoseOutput = sPoseText.split(' ')[0]
                    if kNoDriverSuffix in sPoseText:
                        iNonDriverInputs.add(p)

                    sPoseOutputs.append(sPoseOutput)
                    sToPoseOutput = utils.getMirrorName(sPoseOutput)
                    sToPoseOutputs.append(sToPoseOutput if cmds.objExists(sToPoseOutput) else sPoseOutput)

                if sorted(sToPoseOutputs) == sorted(sPoseOutputs):
                    cmds.confirmDialog(m=f'Skipping "{sTarget}", the mirror would have the same pose(s). \nCheck that its interpolator(s) have mirror interpolator(s)')
                    sSkipTargets.add(sTarget)
                    continue

                sMode = cmds.getAttr('%s.sMode' % getTargetArrayMultiplName(sTarget))
                sToTargetArrayMultipl = getTargetArrayMultipl(sToTargets[-1], sToPoseOutputs, iNonDriverInputs=iNonDriverInputs, bForceRecreate=True, sMode=sMode)

                for sBlendShape in _getBlendShapes():
                    if cmds.objExists('%s.%s' % (sBlendShape, sTargets[-1])):
                        sToTargetAttr = '%s.%s' % (sBlendShape, sToTargets[-1])
                        if not cmds.objExists(sToTargetAttr):
                            blendShapes.addEmptyTarget(sBlendShape, sToTargets[-1])
                        if not cmds.listConnections(sToTargetAttr, s=True, d=False):
                            cmds.connectAttr(sToTargetArrayMultipl, sToTargetAttr)

            self.refreshTargetsTreeFromScene(sSelectTargets=sSelectTargets)

            if bMeshes:
                utils.reload2(geometry)
                cmds.select(sSelectionBefore)

                pSelectedMeshes = [pMesh for pMesh in patch.getSelectedPatches() if cmds.objExists('blendShape__%s' % pMesh.getTransformName())]
                if bSplitCurrentShape:
                    for sTarget, sToTarget in zip(sTargets, sToTargets):

                        if sTarget in sSkipTargets:
                            continue
                        qToTarget = self._getTargetItemFromName(sToTarget)
                        qTarget = self._getTargetItemFromName(sTarget)

                        self.poseTo(qTarget, bResetFirst=True)
                        self.poseTo(qToTarget, bResetFirst=False)
                        aaaPoints = [pMesh.getAllPoints() for pMesh in pSelectedMeshes]

                        for m,pMesh in enumerate(pSelectedMeshes):
                            sBlendShape = 'blendShape__%s' % pMesh.getTransformName()
                            dTargetIndices = blendShapes.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

                            for sT in [sTarget, sToTarget]:
                                sTargetAttr = '%s.%s' % (sBlendShape, sT)
                                print ('sTargetAttr: ', sTargetAttr)
                                sConns = cmds.listConnections(sTargetAttr, s=True, d=False, p=True)
                                if sConns:
                                    sPrev = sConns[0]
                                    cmds.disconnectAttr(sPrev, sTargetAttr)
                                else:
                                    sPrev = cmds.getAttr(sTargetAttr)

                                cmds.setAttr(sTargetAttr, 0)
                                aPointsAtTarget0 = pMesh.getAllPoints()

                                cmds.setAttr(sTargetAttr, 1.0)
                                cmds.sculptTarget(sBlendShape, e=True, t=dTargetIndices[sT])
                                pMesh.setPoints(aPointsAtTarget0)
                                if sConns:
                                    cmds.connectAttr(sPrev, sTargetAttr)
                                else:
                                    cmds.setAttr(sTargetAttr, sPrev)


                            # blendShapes.resetTargetDeltasFull(sBlendShape, dTargetIndices[sTarget])
                            # blendShapes.resetTargetDeltasFull(sBlendShape, dTargetIndices[sToTarget])
                            aaCurrentPoints = pMesh.getAllPoints()
                            aaSplitWeights = geometry.getSplitWeights(pMesh.getTransformName(), fRadius=fSplitMeshRadius)
                            iSideIndices = [1,0] if utils.getSide(sTarget) == 'r' else [0,1]

                            for s, sT, qT in [(0, sTarget, qTarget),
                                              (1, sToTarget, qToTarget)]:
                                if s == 0:
                                    iSide = iSideIndices[s]
                                    aSidePoints = aaaPoints[m] * aaSplitWeights[iSide][:,np.newaxis] + aaCurrentPoints * (1.0-aaSplitWeights[iSide])[:,np.newaxis]
                                else:
                                    aSidePoints = aaaPoints[m]
                                cmds.sculptTarget(sBlendShape, e=True, t=dTargetIndices[sT])
                                pMesh.setPoints(aSidePoints)

                        cmds.sculptTarget(sBlendShape, e=True, t=-1)
                        goToDefaultPose()
                else:
                    utils.reload2(tools)
                    sGeoTargets, sGeoToTargets = [], []
                    for sTarget, sToTarget in zip(sTargets, sToTargets):
                        if sTarget not in sSkipTargets:
                            sGeoTargets.append(sTarget)
                            sGeoToTargets.append(sToTarget)

                    if sGeoTargets:
                        for m, pMesh in enumerate(pSelectedMeshes):
                            sMesh = pMesh.getTransformName()
                            sBlendShape = 'blendShape__%s' % sMesh

                            iExistingTargets = []
                            for t,sT in enumerate(sGeoTargets):
                                if cmds.attributeQuery(sT, node=sBlendShape, exists=True):
                                    iExistingTargets.append(t)
                            sGeoTargets = [sGeoTargets[t] for t in iExistingTargets]
                            sGeoToTargets = [sGeoToTargets[t] for t in iExistingTargets]

                            for sToT in sGeoToTargets:
                                if not cmds.attributeQuery(sToT, node=sBlendShape, exists=True):
                                    sTargetAttr = blendShapes.addEmptyTarget(sBlendShape, sToT)
                                    cmds.connectAttr(getComboOutput(getTargetArrayMultiplName(sToT)), sTargetAttr)

                            dRigPoseAttrs = self.getTargetDictForTools(sGeoTargets + sGeoToTargets)
                            tools.mirrorTargets(None, sGeoToTargets, sMeshes=[sMesh],
                                                sFromTargets=sGeoTargets, iDirection=tools.MirrorDirection.flip, bCheckForFaceCombos=False, dRigPoseAttrs=dRigPoseAttrs)


            if bCtrls:
                sAllCtrls = sCtrlsMask or self._getAllCtrlsInScene()
                for sTarget, sToTarget in zip(sTargets, sToTargets):
                    if sTarget in sSkipTargets:
                        continue
                    for sCtrl in sAllCtrls:
                        sPoseLoc = f'_poseLocEditor__{sCtrl}__{sTarget}'
                        if cmds.objExists(sPoseLoc):
                            sToCtrl = utils.getMirrorName(sCtrl)

                            createCtrlPosesSetup(sToCtrl, [sToTarget])
                            bIsConnected = cmds.objExists(getWeightMultiplName(sCtrl, sTarget, 't'))
                            if not bIsConnected:
                                disconnectPoseLoc(sToCtrl, sToTarget)

                            utils.addStringAttr(sToCtrl, 'poseEditor', sToCtrl)
                            self.__sSavedAllCtrls.append(sToCtrl)
                            sToPoseLoc = f'_poseLocEditor__{sToCtrl}__{sToTarget}'
                            for sA in 'trs':
                                cmds.setAttr('%s.%s' % (sToPoseLoc, sA), *cmds.getAttr('%s.%s' % (sPoseLoc, sA))[0])

                            if utils.getSide(sCtrl) == 'm':
                                iPlane = int(utils.getAttrIfExists('%s.%s' % (sCtrl, kMiddleCtrlMirrorPlaneAttr), 1))
                                sNegateTranslateAttr = ['tx','ty','tz'][iPlane]
                                cmds.setAttr('%s.%s' % (sToPoseLoc, sNegateTranslateAttr), -cmds.getAttr('%s.%s' % (sToPoseLoc, sNegateTranslateAttr)))

                                iNegateRotations = set([0, 1, 2]) - set([iPlane])
                                for iNegateR in iNegateRotations:
                                    sNegateRotateAttr = ['rx','ry','rz'][iNegateR]
                                    cmds.setAttr('%s.%s' % (sToPoseLoc, sNegateRotateAttr), -cmds.getAttr('%s.%s' % (sToPoseLoc, sNegateRotateAttr)))

            cmds.select(sSelectionBefore)
            utils.registerRedoAndUndo(funcRedo=lambda: self.refreshTargetsTreeFromScene(sSelectTargets=sToTargets))
            if bMeshes:
                utils.registerRedoAndUndo(funcRedo=self.refreshMeshesTreeFromScene)
            if bCtrls:
                utils.registerRedoAndUndo(funcRedo=self.refreshCtrlsTreeFromScene)

        except Exception as e:
            cmds.confirmDialog(m=str(e))

            raise
        finally:
            cmds.undoInfo(closeChunk=True)
            # self.refreshTargetsTreeFromScene(sSelectTargets=sSelectTargets)


    def isAnyEditIActivated(self):
        for sTarget, qTarget in self._getTargetNames(bReturnDict=True).items():
            qTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
            if qTargetWidget.qEditButton.isChecked():
                return sTarget


    # not used much, because it would make things complicated (but not impossible) with undo
    def resetAllEditButtons(self):
        for sBlendShape in cmds.ls(et='blendShape'):
            cmds.sculptTarget(sBlendShape, e=True, t=-1)
        for sTarget, qTarget in self._getTargetNames(bReturnDict=True).items():
            qTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
            qTargetWidget.resetEditButton()



    def posesDropEvent(self, event):
        print ('posesDropEvent() event: ', event)
        try:
            qSourceItems = event.source().selectedItems()
            dSourceDatas = [qSourceItem.data(0, QtCore.Qt.UserRole) for qSourceItem in qSourceItems]

            if dSourceDatas[0]['sType'] == 'pose':
                qDroppedOnItem = self.qTargetsTree.itemAt(event.pos())
                if utils.isNone(qDroppedOnItem):
                    self.createNewTargetFromDrop(qSourceItems)
                else:
                    qTarget = qDroppedOnItem if not qDroppedOnItem.parent() else qDroppedOnItem.parent()
                    self.addPosesToTarget(qSourceItems, qTarget=qTarget, bDoSelect=True)

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise


    def addPosesToTarget(self, qPoses, qTarget, bDoSelect=False):
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)

            # sPoseOutputs = [qTarget.child(p).text(0) for p in range(qTarget.childCount())]
            sPoseOutputs = self._getTargetPoses(qTarget)
            sNewPoses = []
            for p,qPose in enumerate(qPoses):
                sPoseOutput = '%s.%s' % (self._transformFromInterpItem(qPose.parent()), qPose.text(0))
                if sPoseOutput not in sPoseOutputs:
                    sNewPoses.append(sPoseOutput)

            sTarget = self._getTargetNameFromItem(qTarget)
            getTargetArrayMultipl(sTarget, sPoseOutputs+sNewPoses)
            utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def updateUiOutputValues(self):
        for iInterp in range(self.qMainTree.invisibleRootItem().childCount()):
            qInterp = self.qMainTree.invisibleRootItem().child(iInterp)
            if qInterp.isExpanded():
                for iPose in range(qInterp.childCount()):
                    qPose = qInterp.child(iPose)
                    dPose = qPose.data(0, QtCore.Qt.UserRole)
                    sAttr = dPose['sOutputAttr']
                    if cmds.objExists(sAttr):
                        fValue = cmds.getAttr(sAttr)
                        qPose.setText(1, '%d %%' % round(fValue * 100.0, 0))
                        # print ('setting %s to %0.3f' % (sAttr, fValue))
                    else:
                        # print ('attribute not exist: ', sAttr)
                        pass

        for iTarget in range(self.qTargetsTree.invisibleRootItem().childCount()):
            qTarget = self.qTargetsTree.invisibleRootItem().child(iTarget)
            qTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)

            sMultiplyName = getTargetArrayMultiplName(qTargetWidget.qName.getName())

            fPerc = cmds.getAttr(getComboOutput(sMultiplyName))
            qTargetWidget.qName.updatePerc(fPerc)


    def _getInterpsFromItems(self, qMainItems):
        qInterps = []
        for qMainItem in qMainItems:
            dData = qMainItem.data(0, QtCore.Qt.UserRole)
            if dData['sType'] == 'interp':
                qInterp = qMainItem
            elif dData['sType'] == 'pose':
                qInterp = qMainItem.parent()
            else:
                raise Exception('Don\'t know what "%s" is' % dData['sType'])
            qInterps.append(qInterp)
        return list(set(qInterps))


    def refreshInterpTreeFromScene(self, sSelectInterps=[]):
        print ('refresh... sSelectInterps: ', sSelectInterps)
        self.qMainTree.blockSignals(True)

        sExpandedInterps = []
        sIsolatedInterps = []
        for iInterp in range(self.qMainTree.invisibleRootItem().childCount()):
            qInterp = self.qMainTree.invisibleRootItem().child(iInterp)
            if qInterp.isExpanded():
                sExpandedInterps.append(self._transformFromInterpItem(qInterp))
            if qInterp.data(0, QtCore.Qt.UserRole)['bIsolated']:
                sIsolatedInterps.append(self._transformFromInterpItem(qInterp))
        sIsolatedInterps.extend(sSelectInterps)

        self.qMainTree.clear()
        self.qMainTree.blockSignals(False)
        sInterps = _findInterpolatorsInScene()# [sN for sN in cmds.ls(et='transform') if cmds.attributeQuery('sInterpType', node=sN, exists=True)]
        # sFilters = self.qInterpsFilter.getFilter()
        for sInterp in sorted(sInterps):
            sInterpType = cmds.getAttr('%s.sInterpType' % sInterp)
            qInterp = self.addInterpolatorToTree(sInterpType, sName=sInterp, bIsolated=sInterp in sIsolatedInterps)
            if sInterp in sSelectInterps:
                qInterp.setSelected(True)
                dInterp = qInterp.data(0, QtCore.Qt.UserRole)
                dInterp['bIsolated'] = True
                qInterp.setData(0, QtCore.Qt.UserRole, dInterp)

        self.updateInterpsVisibilities()


        for sInterp in sExpandedInterps:
            qInterp = self._findInterpItemFromName(sInterp)
            if not utils.isNone(qInterp):
                qInterp.setExpanded(True)


    def updateInterpsVisibilities(self, _=None):
        sFilters = self.qInterpsFilter.getFilter()
        for iInterp in range(self.qMainTree.invisibleRootItem().childCount()):
            qInterp = self.qMainTree.invisibleRootItem().child(iInterp)
            sInterp = qInterp.text(0).split(' ')[0]
            if self.qInterpsIsolateButton.isChecked() and not qInterp.data(0, QtCore.Qt.UserRole)['bIsolated']:
                qInterp.setHidden(True)
            else:
                if not sFilters:
                    qInterp.setHidden(False)
                else:
                    bHidden = True
                    for sFilter in sFilters:
                        if sFilter.upper() in sInterp.upper():
                            bHidden = False
                            break
                    qInterp.setHidden(bHidden)


    def updateCtrlsVisibilities(self, _=None):
        sFilters = self.qCtrlsFilter.getFilter()
        print('print sFilters', sFilters)
        for iRow in range(self.qCtrlsTree.invisibleRootItem().childCount()):
            qCtrl = self.qCtrlsTree.invisibleRootItem().child(iRow)
            if not sFilters:
                qCtrl.setHidden(False)
            else:
                sCtrlUpper = qCtrl.text(0).upper()
                bHidden = True
                for sFilter in sFilters:
                    if sFilter.upper() in sCtrlUpper:
                        bHidden = False
                        break
                qCtrl.setHidden(bHidden)


    def addInterpolatorToTree(self, sInterpType, sName='NewName', bIsolated=True):
        qInterpItem = QtWidgets.QTreeWidgetItem(self.qMainTree)
        qInterpItem.setText(0, '%s (%s)' % (sName, sInterpType))
        qInterpItem.setData(0, QtCore.Qt.UserRole, {'sType':'interp', 'sInterpType':sInterpType, 'dChanges':{}, 'bIsolated':bIsolated})
        qInterpItem.setFlags(qInterpItem.flags() & ~QtCore.Qt.ItemIsDragEnabled)

        self.qMainTree.invisibleRootItem().addChild(qInterpItem)

        xPoses = eval(cmds.getAttr('%s.xPoses' % sName))
        for p,xPose in enumerate(xPoses):
            self.addPoseToTree(qInterpItem, xPose[0])

        return qInterpItem



    def addPoseToTree(self, qInterp, sPoseName):
        qPoseItem = QtWidgets.QTreeWidgetItem(qInterp)
        qPoseItem.setText(0, sPoseName)
        sInterp = self._transformFromInterpItem(qInterp)
        sInterpType = qInterp.data(0, QtCore.Qt.UserRole)['sInterpType']

        sOutputAttr = '%s.%s' % (sInterp, sPoseName)


        qPoseItem.setData(0, QtCore.Qt.UserRole, {'sInterpName': sInterp,
                                                  'sType':'pose',
                                                  'sInterpType':sInterpType,
                                                  'dChanges':{},
                                                  'sPoseName':sPoseName,
                                                  'sOutputAttr':sOutputAttr})
        qPoseItem.setText(1, '1.00')

    def createNewInterpolator(self, sInterpType):
        try:
            cmds.undoInfo(openChunk=True)
            sInterpTransform = 'interp_uplegUp_l' if sInterpType == 'upleg' else utils.getUniqueName('interp_%s_NEW' % sInterpType)

            if sInterpType == 'signedAngle':
                sJoint = getJointFromSel()
                sCtrl = getCtrlFromSel()
                if not sJoint or not sCtrl:
                    raise Exception('Joint and Ctrl need to be selected')
                sJointParent = xforms.getNextParentOfType(sJoint, 'joint')
                interpolator.createSignedAngleInterpolator3(sInterpTransform, sJoint, sJointParent, '%s.rx' % sCtrl,
                                                            xPoses=[('forward', [0,90], blendShapes.DrivenKeyCurveType.easeIn),
                                                                    ('back', [0,-90], blendShapes.DrivenKeyCurveType.easeIn)], iAngleAxis=2, iUpAxis=0, bMirror=False, bComputeInParentSpace=False)
            elif sInterpType == 'cone':
                sJoint = getJointFromSel()
                sCtrl = getCtrlFromSel()
                if not sJoint or not sCtrl:
                    raise Exception('Joint and Ctrl need to be selected')

                interpolator.createConeInterpolator2(sInterpTransform, sJoint, sCtrl, sJointParent=None,
                                                            xPoses=[('forward', (90, 0, 0), kConeRangeDefault, kCurveTypeDefault, False),
                                                                    ('back', (-90, 0, 0), kConeRangeDefault, kCurveTypeDefault, False),
                                                                    ('left', (0, 0, 80), kConeRangeDefault, kCurveTypeDefault, False),
                                                                    ('right', (0, 0, -80), kConeRangeDefault, kCurveTypeDefault, False)], bMirror=False)

            elif sInterpType == 'mayaPose':
                sJoint = getJointFromSel()
                sCtrl = getCtrlFromSel()
                if not sJoint or not sCtrl:
                    raise Exception('Joint and Ctrl need to be selected')
                interpolator.createPoseInterpolator(sInterpTransform, sJoint, sCtrl, sJointParent=None,
                                                            xPoses=[('forward', 90, 0, 0, False),
                                                                    ('back', -90, 0, 0, False),
                                                                    ('left', 0, 0, 80, False),
                                                                    ('right', 0, 0, -80, False)], bMirror=False)

            elif sInterpType == 'upleg':
                interpolator.createUpLegInterpolator2(sInterpTransform, bMirror=False)

            # DEPRICATED
            elif sInterpType == 'attribute':
                utils.reload2(interpolator)
                sAttrs = utils.getSelectedChannelBoxAttributes()
                if not sAttrs:
                    raise Exception('select an attribute in the channelbox')
                sCtrl = cmds.ls(sl=True)[0]
                sCtrlAttr = '%s.%s' % (sCtrl, sAttrs[0])
                interpolator.createAttributeInterpolator(sInterpTransform, sCtrlAttr, sCtrlAttr, bMirror=False)

            elif sInterpType == 'custom':
                utils.reload2(interpolator)
                sChannelAttrs = utils.getSelectedChannelBoxAttributes()
                if not sChannelAttrs:
                    raise Exception('select one, two or three attributes in the channelbox')

                sSel = cmds.ls(sl=True)[0]
                sCtrlAttrs = utils.setListLength(['%s.%s' % (sSel, sA) for sA in sChannelAttrs], 3, '')
                fValues = [utils.getAttrIfExists(_sCtrlAttr, 0.0) for _sCtrlAttr in sCtrlAttrs]
                xPoses = [('on', fValues, blendShapes.DrivenKeyCurveType.easeIn)]

                interpolator.createCustomInterpolator(sInterpTransform, sCtrlAttrs, sCtrlAttrs[0], xPoses=xPoses)



            self.refreshInterpTreeFromScene(sSelectInterps=[sInterpTransform])
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def poseTo(self, sPoseOutputs=None, fWeight=1.0, bResetFirst=False, bSkipReverse=False):
        if bResetFirst:
            goToDefaultPose()
        if utils.isNone(sPoseOutputs):
            qMainItems = self.qMainTree.selectedItems()
            qPoses = [qItem for qItem in qMainItems if qItem.data(0, QtCore.Qt.UserRole)['sType'] == 'pose']
            sPoseOutputs = ['%s.%s' % (self._transformFromInterpItem(qPose.parent()), qPose.text(0)) for qPose in qPoses]
        elif not isinstance(sPoseOutputs, (list, tuple)):
            qTarget = sPoseOutputs
            sPoseOutputs = self._getTargetPoses(qTarget)

        poseToPoseOutputs(sPoseOutputs, fWeight=fWeight, bSkipReverse=bSkipReverse)

    def _print(self):
        qItems = self.qMainTree.selectedItems()
        for qI in qItems:
            print(qI.data(0, QtCore.Qt.UserRole))

    def getTargetsFromSelectedInterps(self):
        qMainItems = self.qMainTree.selectedItems()
        sInterpPoseOutputs = []
        for qItem in qMainItems:
            sType = qItem.data(0, QtCore.Qt.UserRole)['sType']
            if sType == 'pose':
                qInterp = qItem.parent()
                sInterpPoseOutputs.append('%s.%s' % (self._transformFromInterpItem(qInterp), qItem.text(0)))
            elif sType == 'interp':
                qInterp = qItem
                sInterpPoseOutputs.extend(self._getInterpPoses(qInterp))

        sAllTargets = self._getTargetNames()
        sReturnTargets = []
        for sTarget in sAllTargets:
            sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)
            if cmds.objExists(sTargetArrayMultipl):
                sTargetPoseOutputs = set(eval(cmds.getAttr('%s.sPoseOutputs' % sTargetArrayMultipl)))
                if sTargetPoseOutputs.intersection(set(sInterpPoseOutputs)):
                    sReturnTargets.append(sTarget)
        return sReturnTargets


    def selectTargetsFromSelectedPoses(self, bIsolate=False):
        sSelectTargets = self.getTargetsFromSelectedInterps()

        qTargets = [self._getTargetItemFromName(sTarget) for sTarget in sSelectTargets]
        self.qTargetsTree.clearSelection()
        for qTarget in qTargets:
            qTarget.setSelected(True)

        if bIsolate:
            self.qTargetsIsolateButton.setChecked(True)
            self.isolateTargetsClicked(False)
            self.isolateTargetsClicked(True)



    def getInterpsFromSelectedTargets(self):
        sReturnInterps = []
        dTargets = self._getTargetNames(bSelected=True, bReturnDict=True)
        for sTarget, qTarget in dTargets.items():
            for sPose in self._getTargetPoses(qTarget):
                sReturnInterps.append(sPose.split('.')[0])

        return list(set(sReturnInterps))


    def selectInterpolatorsFromSelectedTargets(self, bIsolate=False):
        sSelectInterps = self.getInterpsFromSelectedTargets()

        self.qMainTree.clearSelection()
        for iInterp in range(self.qMainTree.invisibleRootItem().childCount()):
            qInterp = self.qMainTree.invisibleRootItem().child(iInterp)
            if self._transformFromInterpItem(qInterp) in sSelectInterps:
                qInterp.setSelected(True)

        if bIsolate:
            self.qInterpsIsolateButton.setChecked(True)
            self.isolateInterpsClicked(False)
            self.isolateInterpsClicked(True)



    def selectPoseLocatorsOfTargets(self):
        sSelectedTargets = self._getTargetNames(bSelected=True)

        sLocs = []
        for sTarget in sSelectedTargets:
            sLocs.extend(cmds.ls(f'_poseLocEditor__*__{sTarget}', et='transform'))

        cmds.select(sLocs)



    def recordCtrls(self, sPoseOutputs=None, dCtrlsBefore={}, iSlidersBefore={}):

        if utils.isNone(sPoseOutputs):
            qMainItems = self.qMainTree.selectedItems()
            qPoses = [qItem for qItem in qMainItems if qItem.data(0, QtCore.Qt.UserRole)['sType'] == 'pose']
            sPoseOutputs = ['%s.%s' % (self._transformFromInterpItem(qPose.parent()), qPose.text(0)) for qPose in qPoses]

        for sOutput in sPoseOutputs:
            sInterp, sPose = sOutput.split('.')

            sPoseAttrs = eval(cmds.getAttr('%s.sPoseAttrs' % sInterp))
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)

            fPoseValues = getPoseValues(sInterp, sPose)
            for sA, fV in zip(sPoseAttrs, fPoseValues):
                if sA:
                    sAttr = sA if '.' in sA else '%s.%s' % (sCtrl, sA)
                    dCtrlsBefore[sAttr] = cmds.getAttr(sAttr)


    def recordSliderValue(self, qSlider):
        self.dSliderValuesBeforeDrag[qSlider] = qSlider.value()


    def removePoses(self):
        sConnectedTargets = self.getTargetsFromSelectedInterps()

        if sConnectedTargets:
            if cmds.confirmDialog(m='Can\'t delete, because there are %d targets connected to the selected poses(s).\nSelect them?' % len(sConnectedTargets),
                                  button=['yes', 'no']) == 'yes':
                qTargets = [self._getTargetItemFromName(sTarget) for sTarget in sConnectedTargets]
                self.qTargetsTree.clearSelection()
                for qTarget in qTargets:
                    qTarget.setSelected(True)
        else:

            try:
                cmds.undoInfo(openChunk=True)
                utils.registerRedoAndUndo(funcUndo=self.refreshInterpTreeFromScene)


                dInterpolatorPoses = self._getSelectedInterpolatorPoses()
                for qInterp, qPoses in dInterpolatorPoses.items():

                    for qPose in qPoses:
                        qInterp = qPose.parent()
                        dInterp = qInterp.data(0, QtCore.Qt.UserRole)
                        sRemovedPoses = dInterp['dChanges'].get('sRemovedPoses', [])
                        sRemovedPoses.append(qPose.text(0))
                        dInterp['dChanges']['sRemovedPoses'] = sRemovedPoses
                        qInterp.setData(0, QtCore.Qt.UserRole, dInterp)
                        qInterp.removeChild(qPose)

                    self.rebuildInterpolators([qInterp])

                utils.registerRedoAndUndo(funcRedo=self.refreshInterpTreeFromScene)
            except:
                raise
            finally:
                cmds.undoInfo(closeChunk=True)


    def swapPoseNames(self):

        try:
            cmds.undoInfo(openChunk=True)
            dInterpolatorPoses = self._getSelectedInterpolatorPoses()
            qInterp = list(dInterpolatorPoses.keys())[0]
            qPoses = dInterpolatorPoses[qInterp]

            sNameA = qPoses[0].text(0)
            sNameB = qPoses[1].text(0)

            utils.registerRedoAndUndo(funcUndo=self.refreshInterpTreeFromScene)
            qPoses[0].setText(0, sNameB)
            qPoses[1].setText(0, sNameA)
            self.rebuildInterpolators([qInterp])
            utils.registerRedoAndUndo(funcRedo=self.refreshInterpTreeFromScene)

        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def _getSelectedInterpolatorPoses(self):
        qMainItems = self.qMainTree.selectedItems()
        qPoses = [qItem for qItem in qMainItems if qItem.data(0, QtCore.Qt.UserRole)['sType'] == 'pose']

        dInterpolatorPoses = defaultdict(list)
        for qPose in qPoses:
            qInterp = qPose.parent()
            dInterpolatorPoses[qInterp].append(qPose)
        return dInterpolatorPoses


    def setStatusLine(self, sText, fFadeOutDuration=3000.0):
        self.qEffect = QtWidgets.QGraphicsOpacityEffect()
        self.qStatusLabel.setText(sText)
        self.qStatusLabel.setGraphicsEffect(self.qEffect)

        self.qAnimation = QtCore.QPropertyAnimation(self.qEffect, b"opacity")
        self.qAnimation.setDuration(fFadeOutDuration)
        self.qAnimation.setStartValue(1)
        self.qAnimation.setEndValue(0)
        self.qAnimation.start()


    def rebuildInterpolators(self, qInterpolators=None, dAdditionalChanges={}, dDefaultPoseValues={}):
        try:
            cmds.undoInfo(openChunk=True)
            sSelectionBefore = cmds.ls(sl=True)
            if utils.isNone(qInterpolators):
                qInterpolators = self._getInterpsFromItems(self.qMainTree.selectedItems())

            goToDefaultPose()
            for qInterp in qInterpolators:
                sInterpTransform = self._transformFromInterpItem(qInterp)
                self.setStatusLine('Rebuilding "%s"...' % sInterpTransform)
                print ('\n\nRebuilding %s...' % sInterpTransform)
                dInterp = qInterp.data(0, QtCore.Qt.UserRole)
                dInterpChanges = dInterp['dChanges']
                dInterpChanges.update(dAdditionalChanges)

                sInterpType = dInterpChanges.get('sInterpType', cmds.getAttr('%s.sInterpType' % sInterpTransform))

                sTempInterpTransform = '%s%s' % (kTempString, sInterpTransform)

                dChangedPoseNames = {}
                if sInterpType == 'signedAngle':
                    sJoint, sParentJoint = eval(cmds.getAttr('%s.sJoints' % sInterpTransform))
                    sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterpTransform)

                    iAngleAxis = eval(cmds.getAttr('%s.iAngleAxis' % sInterpTransform))
                    iUpAxis = eval(cmds.getAttr('%s.iUpAxis' % sInterpTransform))
                    ffRanges = eval(cmds.getAttr('%s.ffRanges' % sInterpTransform))
                    xPoses = []
                    for p in range(qInterp.childCount()):
                        qPose = qInterp.child(p)
                        dPose = qPose.data(0, QtCore.Qt.UserRole)
                        sPoseName = qPose.text(0)
                        sOldPoseName = dPose['sPoseName']
                        dPoseChanges = dPose['dChanges']
                        fAngleRange = dPoseChanges.get('fRange', ffRanges[p] if p < len(ffRanges) else [0, dDefaultPoseValues.get(sCtrlAttr, 90)])
                        iCurveType = utils.getAttrIfExists('%s.%s_curveType' % (sInterpTransform, sOldPoseName), kCurveTypeDefault)
                        xPoses.append((sPoseName, fAngleRange, iCurveType)) # [('twistBack90', [0,90], blendShapes.DrivenKeyCurveType.easeIn)]
                        if sPoseName != sOldPoseName:
                            dChangedPoseNames[sOldPoseName] = sPoseName
                    interpolator.createSignedAngleInterpolator3(sTempInterpTransform,
                                                               dInterpChanges.get('sJoint', sJoint),
                                                               dInterpChanges.get('sParentJoint', sParentJoint),
                                                               dInterpChanges.get('sCtrlAttr', sCtrlAttr),
                                                               iAngleAxis=dInterpChanges.get('iAngleAxis', iAngleAxis),
                                                               iUpAxis=dInterpChanges.get('iUpAxis', iUpAxis),
                                                               xPoses=xPoses, bMirror=False, bComputeInParentSpace=False)
                elif sInterpType == 'attribute':
                    sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterpTransform)
                    sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sInterpTransform)
                    ffRanges = eval(cmds.getAttr('%s.ffRanges' % sInterpTransform))
                    xPoses = []
                    for p in range(qInterp.childCount()):
                        qPose = qInterp.child(p)
                        dPose = qPose.data(0, QtCore.Qt.UserRole)
                        sPoseName = qPose.text(0)
                        sOldPoseName = dPose['sPoseName']
                        dPoseChanges = dPose['dChanges']
                        fRange = dPoseChanges.get('fRange', ffRanges[p] if p < len(ffRanges) else [0,dDefaultPoseValues.get(sCtrlAttr, 10)])
                        iCurveType = utils.getAttrIfExists('%s.%s_curveType' % (sInterpTransform, sOldPoseName), kCurveTypeDefault)
                        xPoses.append((sPoseName, fRange, iCurveType)) # [('twistBack90', [0,90], blendShapes.DrivenKeyCurveType.easeIn)]
                        if sPoseName != sOldPoseName:
                            dChangedPoseNames[sOldPoseName] = sPoseName

                    interpolator.createAttributeInterpolator(sTempInterpTransform,
                                                               dInterpChanges.get('sCtrlAttr', sCtrlAttr),
                                                               dInterpChanges.get('sDriverAttr', sDriverAttr),
                                                               xPoses=xPoses, bMirror=False)

                elif sInterpType == 'custom':
                    sCtrlAttrs = [cmds.getAttr('%s.sCtrlAttrX' % sInterpTransform),
                                  cmds.getAttr('%s.sCtrlAttrY' % sInterpTransform),
                                  cmds.getAttr('%s.sCtrlAttrZ' % sInterpTransform)]
                    sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sInterpTransform)

                    xPosesFromAttr = eval(cmds.getAttr('%s.xPoses' % sInterpTransform))
                    xPoses = []
                    for p in range(qInterp.childCount()):
                        qPose = qInterp.child(p)
                        dPose = qPose.data(0, QtCore.Qt.UserRole)
                        sPoseName = qPose.text(0)
                        sOldPoseName = dPose['sPoseName']
                        dPoseChanges = dPose['dChanges']
                        iCurveType = utils.getAttrIfExists('%s.%s_curveType' % (sInterpTransform, sOldPoseName), kCurveTypeDefault)
                        fValues = xPosesFromAttr[p][1:4]
                        print (' ===== fValues from attr: ', fValues)
                        print (' ===== fValues[0]: ', fValues[0])
                        print (' ===== dPoseChanges: ', dPoseChanges)
                        fValueX = dPoseChanges.get('fValueX', [fValues[0]])[0]
                        fValueY = dPoseChanges.get('fValueY', [fValues[1]])[0]
                        fValueZ = dPoseChanges.get('fValueZ', [fValues[2]])[0]
                        xPoses.append([sPoseName, [fValueX, fValueY, fValueZ], iCurveType])
                        if sPoseName != sOldPoseName:
                            dChangedPoseNames[sOldPoseName] = sPoseName

                    interpolator.createCustomInterpolator(sTempInterpTransform,
                                                       [dInterpChanges.get('sCtrlAttrX', sCtrlAttrs[0]),
                                                                 dInterpChanges.get('sCtrlAttrY', sCtrlAttrs[1]),
                                                                 dInterpChanges.get('sCtrlAttrZ', sCtrlAttrs[2])],
                                                                 dInterpChanges.get('sDriverAttr', sDriverAttr),
                                                                 xPoses=xPoses)
                elif sInterpType == 'cone':
                    sJoint = cmds.getAttr('%s.sJoint' % sInterpTransform)
                    sJointParent = cmds.getAttr('%s.sJointParent' % sInterpTransform)
                    sCtrl = cmds.getAttr('%s.sCtrl' % sInterpTransform)
                    bJointAngleFactor = utils.getAttrIfExists('%s.bJointAngleFactor' % sInterpTransform, 0.0)
                    xPosesPass = []
                    # xPosesValue = eval(cmds.getAttr('%s.xPoses' % sInterpTransform))
                    for p in range(qInterp.childCount()):
                        qPose = qInterp.child(p)
                        dPose = qPose.data(0, QtCore.Qt.UserRole)
                        sPoseName = qPose.text(0)
                        sOldPoseName = dPose['sPoseName']
                        sConeTransform = '%s_%s_cone' % (sInterpTransform, sOldPoseName)
                        if sPoseName != sOldPoseName:
                            dChangedPoseNames[sOldPoseName] = sPoseName

                        dPoseChanges = dPose['dChanges']

                        fInnerOuterRange = [utils.getAttrIfExists('%s.startAngle' % sConeTransform, kConeRangeDefault[0]),
                                            utils.getAttrIfExists('%s.endAngle' % sConeTransform, kConeRangeDefault[1])]
                        fInnerOuterRange = dPoseChanges.get('fInnerOuterRange', fInnerOuterRange)

                        iCurveType = utils.getAttrIfExists('%s.curveType' % sConeTransform, 0)
                        if cmds.objExists(sConeTransform):
                            fRotation = cmds.getAttr('%s.r' % sConeTransform)[0]
                        else:
                            fRotation = dDefaultPoseValues.get(sCtrl, k3dPoseDefault)

                        fRotation = dPoseChanges.get('fRotation', fRotation)

                        bReverse = dPoseChanges.get('bReverse', utils.getAttrIfExists('%s.bReverse' % sConeTransform, 0.0))
                        xPosesPass.append((sPoseName, dPoseChanges.get('fRotation', fRotation), fInnerOuterRange, iCurveType, bReverse)) # [('default',(0,0,0), (0,45)]


                    iCtrlTwistAxis = dInterpChanges.get('iCtrlTwistAxis', int(utils.getAttrIfExists('%s.iCtrlTwistAxis' % sInterpTransform, 1.0)))

                    interpolator.createConeInterpolator2(sTempInterpTransform,
                                                       dInterpChanges.get('sJoint', sJoint),
                                                       dInterpChanges.get('sCtrl', sCtrl),
                                                       dInterpChanges.get('sJointParent', sJointParent),
                                                       bJointAngleFactor=dInterpChanges.get('bJointAngleFactor', bJointAngleFactor),
                                                       iCtrlTwistAxis=iCtrlTwistAxis,
                                                       xPoses=xPosesPass,
                                                       bMirror=False)

                elif sInterpType == 'mayaPose':
                    sJoint = cmds.getAttr('%s.sJoint' % sInterpTransform)
                    sJointParent = cmds.getAttr('%s.sJointParent' % sInterpTransform)
                    sCtrl = cmds.getAttr('%s.sCtrl' % sInterpTransform)
                    xPosesPass = []
                    xPosesValue = eval(cmds.getAttr('%s.xPoses' % sInterpTransform)) # [('side', 0, 0, 90), ('forward', 90, 0, 0), ('forwardExtreme', 110, 0, 0), ('back', -50, 0, 0)]
                    bRevs = eval(cmds.getAttr('%s.bRevs' % sInterpTransform))
                    for p in range(qInterp.childCount()):
                        qPose = qInterp.child(p)
                        dPose = qPose.data(0, QtCore.Qt.UserRole)
                        sPoseName = qPose.text(0)
                        # sConeTransform = '%s_%s_cone' % (sInterpTransform, sPoseName)
                        # print ('adding pose from transform %s' % sConeTransform)
                        dPoseChanges = qPose.data(0, QtCore.Qt.UserRole)['dChanges']
                        # fDefault = dDefaultPoseValues.get(sCtrl, k3dPoseDefault)
                        fRotation = dPoseChanges.get('fRotation', xPosesValue[p][1:4] if p < len(xPosesValue) else dDefaultPoseValues.get(sCtrl, k3dPoseDefault))
                        bReverse = dPoseChanges.get('bReverse', bRevs[p] if p < len(bRevs) else False)
                        xPosesPass.append((sPoseName, fRotation[0], fRotation[1], fRotation[2], bReverse)) # [('up', 0, 0, 0)]
                        sOldPoseName = dPose['sPoseName']
                        if sPoseName != sOldPoseName:
                            dChangedPoseNames[sOldPoseName] = sPoseName

                    # if xPosesPass[0][0] == 'default':
                    #     xPosesPass = xPosesPass[1:]
                    interpolator.createPoseInterpolator(sTempInterpTransform,
                                                        dInterpChanges.get('sJoint', sJoint),
                                                        dInterpChanges.get('sCtrl', sCtrl),
                                                        dInterpChanges.get('sJointParent', sJointParent),
                                                        xPoses=xPosesPass,
                                                       bMirror=False)

                elif sInterpType == 'upleg':
                    sPoseNames = []
                    fKneeStarts = []
                    fTurnOffOnIns = []
                    fUpRotations = []
                    bReverses = []
                    xPosesValue = eval(cmds.getAttr('%s.xPoses' % sInterpTransform))
                    for p in range(qInterp.childCount()):
                        qPose = qInterp.child(p)
                        dPose = qPose.data(0, QtCore.Qt.UserRole)
                        dPoseChanges = qPose.data(0, QtCore.Qt.UserRole)['dChanges']

                        sPoseName = qPose.text(0)
                        sOldPoseName = dPose['sPoseName']

                        sKneeStartAttr = '%s.kneeStart_%s' % (sInterpTransform, sOldPoseName)
                        sTurnOffOnInAttr = '%s.turnOffOnIn_%s' % (sInterpTransform, sOldPoseName)
                        sReverseAttr = '%s.reverse_%s' % (sInterpTransform, sOldPoseName)
                        fKneeStart = cmds.getAttr(sKneeStartAttr) if cmds.objExists(sKneeStartAttr) else 0.0
                        fTurnOffOnIn = cmds.getAttr(sTurnOffOnInAttr) if cmds.objExists(sTurnOffOnInAttr) else 1.0
                        bReverse = cmds.getAttr(sReverseAttr) if cmds.objExists(sReverseAttr) else 0.0

                        sPoseNames.append(sPoseName)
                        fKneeStarts.append(fKneeStart)
                        fTurnOffOnIns.append(fTurnOffOnIn)
                        bReverses.append(bReverse)
                        fRotation = dPoseChanges.get('fRotation', [xPosesValue[p][1]] if p < len(xPosesValue) else [90.0])[0]
                        fUpRotations.append(fRotation)

                        if sPoseName != sOldPoseName:
                            dChangedPoseNames[sOldPoseName] = sPoseName

                    interpolator.createUpLegInterpolator2(sTempInterpTransform, sPoseNames=sPoseNames, fKneeStarts=fKneeStarts, bReverses=bReverses, fTurnOffOnIns=fTurnOffOnIns, fUpRotations=fUpRotations, bMirror=False)

                else:
                    raise Exception('%s not yet set for rebuild' % sInterpType)

                moveConnectionsAndDelete(sTempInterpTransform, dChangedPoseNames=dChangedPoseNames) #, sRemovedPoses=dInterpChanges.get('sRemovedPoses', []))

                dInterp['dChanges'] = {}
                qInterp.setData(0, QtCore.Qt.UserRole, dInterp)
                for p in range(qInterp.childCount()):
                    qPose = qInterp.child(p)
                    dPose = qPose.data(0, QtCore.Qt.UserRole)
                    dPose['dChanges'] = {}
                    dPose['sPoseName'] = qPose.text(0)
                    qPose.setData(0, QtCore.Qt.UserRole, dPose)

                self.updateOutputAttrs(qInterp)

            self.refreshAttributes(None)
            cmds.select([sObj for sObj in sSelectionBefore if cmds.objExists(sObj)])
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def convertToMayaPose(self, qConeInterp):
        sConeInterp = self._transformFromInterpItem(qConeInterp)
        sJoint = cmds.getAttr('%s.sJoint' % sConeInterp)
        sJointParent = cmds.getAttr('%s.sJointParent' % sConeInterp)
        sCtrl = cmds.getAttr('%s.sCtrl' % sConeInterp)
        sPoseNames = [qConeInterp.child(p).text(0) for p in range(qConeInterp.childCount())]

        sConeTransforms = ['%s_%s_cone' % (sConeInterp, sPoseName) for sPoseName in sPoseNames]
        dRotationValues = {sPoseName:cmds.getAttr('%s.r' % sConeTransform)[0] for sPoseName, sConeTransform in zip(sPoseNames, sConeTransforms)}

        xPosesPass = [(sPoseName, dRotationValues[sPoseName][0], dRotationValues[sPoseName][1], dRotationValues[sPoseName][2], False) for sPoseName in sPoseNames]

        sTempInterpTransform = '%s%s' % (sConeInterp, kTempString)
        interpolator.createPoseInterpolator(sTempInterpTransform,
                                            sJoint,
                                            sCtrl,
                                            sJointParent,
                                            xPoses=xPosesPass,
                                            bMirror=False)
        moveConnectionsAndDelete(sTempInterpTransform)
        sMayaPoseInterp = sConeInterp
        self.refreshInterpTreeFromScene([sMayaPoseInterp])


    def convertToCone(self, qMayaPoseInterp):
        sMayaPoseInterp = self._transformFromInterpItem(qMayaPoseInterp)

        sJoint = cmds.getAttr('%s.sJoint' % sMayaPoseInterp)
        sJointParent = cmds.getAttr('%s.sJointParent' % sMayaPoseInterp)
        sCtrl = cmds.getAttr('%s.sCtrl' % sMayaPoseInterp)
        xPosesValue = eval(cmds.getAttr('%s.xPoses' % sMayaPoseInterp))  # [('side', 0, 0, 90), ('forward', 90, 0, 0), ('forwardExtreme', 110, 0, 0), ('back', -50, 0, 0)]

        dRotations = {xP[0]: (xP[1], xP[2], xP[3]) for xP in xPosesValue}
        sPoseNames = [xP[0] for xP in xPosesValue]

        xPosesPass = [(sPoseName, dRotations[sPoseName], kConeRangeDefault, kCurveTypeDefault, False) for sPoseName in sPoseNames]
        sTempInterpTransform = '%s%s' % (sMayaPoseInterp, kTempString)
        interpolator.createConeInterpolator2(sTempInterpTransform,
                                             sJoint,
                                             sCtrl,
                                             sJointParent,
                                             xPoses=xPosesPass,
                                             bMirror=False)

        moveConnectionsAndDelete(sTempInterpTransform)
        sConeInterp = sMayaPoseInterp
        self.refreshInterpTreeFromScene([sConeInterp])


    def targetSelectionChanged(self):
        self.refreshMeshesTreeFromScene()
        self.refreshCtrlsTreeFromScene(bCheckAllTransformsAndJointsCheckCtrls=False)
        self.updateAddActiveCtrlButton()

    def _getMeshNameFromItem(self, qMesh):
        return qMesh.data(0, QtCore.Qt.UserRole)['sMesh']


    def _getCtrlNameFromItem(self, qCtrl):
        return qCtrl.text(0).split(' ')[0]





    # def refreshTweakNodeScriptJob(self, sMeshes):
    #     # block tweak nodes (for when user accidently moves verts without Edit button clicked:
    #     self.killBlockTweakScriptJobs()
    #     self.bTweakScriptJobsActive = True
    #     sBlockTweakNodes = []
    #     for sM in sMeshes:
    #         sTweakNodes = [sN for sN in cmds.listHistory(sM) if cmds.objectType(sN) == 'tweak']
    #         if not sTweakNodes:
    #             cmds.deformer(sM, type='tweak')
    #             sTweakNodes = [sN for sN in cmds.listHistory(sM) if cmds.objectType(sN) == 'tweak']
    #
    #         sBlockTweakNodes += sTweakNodes
    #
    #     for sTweak in set(sBlockTweakNodes):
    #         def _block(_sTweak=sTweak):
    #             if self.bTweakScriptJobsActive:
    #                 cmds.warning('resetting tweak node %s...' % _sTweak)
    #                 self.bTweakScriptJobsActive = False
    #                 ffChanges = cmds.getAttr('%s.vlist[0].vertex[*]' % _sTweak)
    #                 iCount = len(ffChanges)
    #                 cmds.setAttr('%s.vlist[0].vertex[*]' % _sTweak, *([0] * iCount * 3))
    #             else:
    #                 self.bTweakScriptJobsActive = True
    #
    #         iScriptJob = cmds.scriptJob(attributeChange=['%s.vlist[0].vertex' % sTweak, _block])
    #         self.iTweakBlockScriptJobs.append(iScriptJob)
    #


    def refreshMeshesTreeFromScene(self, sSelect=None, bCheckLattices=False):
        try:
            self.qMeshesTree.blockSignals(True)
            sSelectedTargets = self._getTargetNames(bSelected=True, bCountPoseSelectionAsSelected=True)
            sBlendShapes = _getBlendShapes()

            if utils.isNone(sSelect):
                sSelect = [self._getMeshNameFromItem(qMesh) for qMesh in self.qMeshesTree.selectedItems()]

            iScrollPos = self.qMeshesTree.verticalScrollBar().value()

            self.qMeshesTree.clear()

            sMeshes = [sBlendShape.split('__')[-1] for sBlendShape in sBlendShapes]


            for sMesh, sBlendShape in zip(sMeshes, sBlendShapes):
                if bCheckLattices:
                    checkLatticeDeformers(sMesh)
                qMesh = QtWidgets.QTreeWidgetItem(self.qMeshesTree)

                sFlags = []

                sMirrorFlagAttr = '%s.sMirrorFlag' % sMesh
                if cmds.objExists(sMirrorFlagAttr):
                    sFlags.append(cmds.getAttr(sMirrorFlagAttr))
                if utils.getAttrIfExists('%s.%s' % (sMesh, kInverseExportAttr), False):
                    sFlags.append('InvExp')
                else:
                    sFlags.append('PosedExp')

                if sFlags:
                    sMeshText = '%s (%s)' % (sMesh, ', '.join(sFlags))
                else:
                    sMeshText = sMesh

                qMesh.setText(0, sMeshText)

                if sSelectedTargets:
                    qMesh.setCheckState(0, QtCore.Qt.PartiallyChecked)

                self.qMeshesTree.invisibleRootItem().addChild(qMesh)
                if sMesh in sSelect:
                    qMesh.setSelected(True)
                qMesh.setData(0, QtCore.Qt.UserRole, {'sMesh':sMesh})

                if sSelectedTargets:
                    bTargetsActive = []
                    for sTarget in sSelectedTargets:
                        sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
                        if not cmds.objExists(sTargetAttr):
                            bTargetsActive.append(False)
                        elif not cmds.listConnections(sTargetAttr, s=True, d=False):
                            bTargetsActive.append(False)
                        else:
                            bTargetsActive.append(True)

                    if np.all(bTargetsActive):
                        qMesh.setCheckState(0, QtCore.Qt.Checked)
                    elif np.any(bTargetsActive):
                        qMesh.setCheckState(0, QtCore.Qt.PartiallyChecked)
                    else:
                        qMesh.setCheckState(0, QtCore.Qt.Unchecked)

            self.qMeshesTree.verticalScrollBar().setSliderPosition(iScrollPos)

            # self.refreshTweakNodeScriptJob(sMeshes)

        except:
            raise
        finally:
            self.qMeshesTree.blockSignals(False)



    def refreshCtrlsTreeFromScene(self, sSelect=None, bCheckAllTransformsAndJointsCheckCtrls=True):
        try:
            sFilters = self.qCtrlsFilter.getFilter()
            self.qCtrlsTree.blockSignals(True)
            sSelectedTargets = self._getTargetNames(bSelected=True, bCountPoseSelectionAsSelected=True)

            if utils.isNone(sSelect):
                sSelect = [self._getCtrlNameFromItem(qCtrl) for qCtrl in self.qCtrlsTree.selectedItems()]

            iScrollPos = self.qCtrlsTree.verticalScrollBar().value()

            self.qCtrlsTree.clear()

            sAllCtrls = self._getAllCtrlsInScene(bCheckAllTransformsAndJoints=bCheckAllTransformsAndJointsCheckCtrls)

            for sCtrl in sAllCtrls:
                # sTransform = _getTransformFromCtrl(sCtrl)
                qCtrl = QtWidgets.QTreeWidgetItem(self.qCtrlsTree)
                sText = sCtrl
                if utils.getSide(sCtrl) == 'm':
                    iMirrorPlane = utils.getAttrIfExists('%s.%s' % (sCtrl, kMiddleCtrlMirrorPlaneAttr), 1)
                    sText = '%s (%s)' % (sCtrl, ['YZ', 'XZ', 'XY'][int(iMirrorPlane)])
                qCtrl.setText(0, sText)


                if sFilters:
                    bHidden = True
                    for sFilter in sFilters:
                        if sFilter.upper() in sCtrl.upper():
                            bHidden = False
                            break
                    qCtrl.setHidden(bHidden)

                if sSelectedTargets:
                    qCtrl.setCheckState(0, QtCore.Qt.PartiallyChecked)

                self.qCtrlsTree.invisibleRootItem().addChild(qCtrl)
                if sCtrl in sSelect:
                    qCtrl.setSelected(True)

                if sSelectedTargets:
                    bTargetsActive = []
                    for sTarget in sSelectedTargets:
                        sPoseLoc = f'_poseLocEditor__{sCtrl}__{sTarget}'
                        if not cmds.objExists(sPoseLoc):
                            bTargetsActive.append(False)
                        elif not cmds.objExists(f'WEIGHT__{sCtrl}__{sTarget}__t'):
                            bTargetsActive.append(False)
                        else:
                            bTargetsActive.append(True)

                    if np.all(bTargetsActive):
                        qCtrl.setCheckState(0, QtCore.Qt.Checked)
                    elif np.any(bTargetsActive):
                        qCtrl.setCheckState(0, QtCore.Qt.PartiallyChecked)
                    else:
                        qCtrl.setCheckState(0, QtCore.Qt.Unchecked)

            self.qCtrlsTree.verticalScrollBar().setSliderPosition(iScrollPos)

        except:
            raise
        finally:
            self.qCtrlsTree.blockSignals(False)


    def userChecksOrUnchecksMesh(self, qMesh, _):
        qCheckState = qMesh.checkState(0)
        if qCheckState == QtCore.Qt.PartiallyChecked:
            return
        bIsChecked = True if qCheckState == QtCore.Qt.Checked else False

        sMesh = self._getMeshNameFromItem(qMesh)
        sBlendShape = 'blendShape__%s' % sMesh

        dSelectedTargets = self._getTargetNames(bSelected=True, bCountPoseSelectionAsSelected=True, bReturnDict=True)
        if not dSelectedTargets:
            return

        for sTarget, qTarget in dSelectedTargets.items():
            sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
            sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)
            sPoseOutputs = self._getTargetPoses(qTarget)
            # sPoseOutputs = [qTarget.child(p).text(0) for p in range(qTarget.childCount())]

            if bIsChecked:
                if not cmds.objExists(sTargetAttr):
                    blendShapes.addEmptyTarget(sBlendShape, sTarget)
                if not cmds.objExists(sTargetArrayMultipl):
                    _reconnectTargetAttr(sBlendShape, sTarget, sPoseOutputs)
                cmds.connectAttr(getComboOutput(sTargetArrayMultipl), sTargetAttr)

            else:
                if cmds.objExists(sTargetArrayMultipl):
                    if cmds.listConnections(sTargetAttr, s=True, d=False):
                        cmds.disconnectAttr(getComboOutput(sTargetArrayMultipl), sTargetAttr)
                        cmds.setAttr(sTargetAttr, 0.0)



    def userChecksOrUnchecksCtrl(self, qCtrl, _):
        qCheckState = qCtrl.checkState(0)
        if qCheckState == QtCore.Qt.PartiallyChecked:
            return
        bIsChecked = True if qCheckState == QtCore.Qt.Checked else False

        # sMesh = qCtrl.text(0)
        sCtrl = self._getCtrlNameFromItem(qCtrl)
        # sTransform = _getTransformFromCtrl(sCtrl)

        sSelectedTargets = self._getTargetNames(bSelected=True, bCountPoseSelectionAsSelected=True)
        if not sSelectedTargets:
            return

        for sTarget in sSelectedTargets:
            if bIsChecked:
                sLocs = reconnectPoseLoc(sCtrl, sTarget)
                if sLocs:
                    cmds.select(sLocs)
            else:
                disconnectPoseLoc(sCtrl, sTarget)


    def addMesh(self, sMeshes, bSetToInv=False):
        sMeshes = utils.toList(sMeshes)
        for sMesh in sMeshes:
            if not utils.isOnOrigin(sMesh):
                if cmds.confirmDialog(
                        m='"%s" is not on origin, \nContinue?' % sMesh,
                        button=['Abort', 'Continue']) == 'Abort':
                    return


        for sMesh in sMeshes:
            checkLatticeDeformers(sMesh)

            sBlendShape = 'blendShape__%s' % sMesh

            _getBlendShapes()

            if not cmds.objExists(sBlendShape):
                cmds.blendShape(sMesh, n=sBlendShape, foc=True)
            if bSetToInv:
                utils.addAttr(sMesh, ln=kInverseExportAttr, at='bool', dv=True, bReturnIfExists=True)

            utils.addAttr(sBlendShape, ln=kIsPoseEditorBlendShapeAttr, bReturnIfExists=True)

        self.refreshMeshesTreeFromScene([sMesh])


    def addCtrls(self, sCtrls, bUndoMagic=True):
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshCtrlsTreeFromScene)

            dSelectedTargets = self._getTargetNames(bSelected=True, bReturnDict=True)
            for sCtrl in sCtrls:
                createCtrlPosesSetup(sCtrl, list(dSelectedTargets.keys()))
                utils.addStringAttr(sCtrl, 'poseEditor', sCtrl)
                if utils.getSide(sCtrl) == 'm':
                    if not cmds.attributeQuery(kMiddleCtrlMirrorPlaneAttr, node=sCtrl, exists=True):
                        utils.addAttr(sCtrl, ln=kMiddleCtrlMirrorPlaneAttr, dv=1, k=False)

                self.__sSavedAllCtrls.append(sCtrl)
            # self.refreshCtrlsTreeFromScene(sCtrls)
            utils.registerRedoAndUndo(funcRedo=lambda: self.refreshCtrlsTreeFromScene(sCtrls))
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def addCtrlsAndActivate(self, sCtrls):
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshCtrlsTreeFromScene)

            self.addCtrls(sCtrls)

            sSelectedTargets = self._getTargetNames(bSelected=True, bCountPoseSelectionAsSelected=True)
            sAllLocs = []

            for sCtrl in sCtrls:
                for sTarget in sSelectedTargets:
                    sLocs = reconnectPoseLoc(sCtrl, sTarget)
                    sAllLocs.extend(sLocs)

            self.refreshCtrlsTreeFromScene()

            self._selectLocatorsFromCtrls(sCtrls, sTargets=sSelectedTargets)

            utils.registerRedoAndUndo(funcRedo=lambda: self.refreshCtrlsTreeFromScene(sCtrls))

        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def markingMenuMeshes(self, vPos):
        qMenu = QtWidgets.QMenu()
        sSelection = [sNode for sNode in cmds.ls(sl=True, et='transform')
                      if cmds.listRelatives(sNode, c=True, typ='mesh')
                      or cmds.listRelatives(sNode, c=True, typ='nurbsCurve')
                      or cmds.listRelatives(sNode, c=True, typ='nurbsSurface')]
        if sSelection:
            qMenu.addAction('Add "%s"' % utils.listToString(sSelection, bQuotations=True), lambda: self.addMesh(sSelection, bSetToInv=True))

        qSelectedMeshes = self.qMeshesTree.selectedItems()
        if qSelectedMeshes:
            qSetMirrorTable = qMenu.addMenu('Set Mirror Table')
            if qSelectedMeshes:
                def _setMirrorTableE():
                    self.setMirrorTableMiddleMeshes(qSelectedMeshes, 'E')
                def _setMirrorTableV():
                    self.setMirrorTableMiddleMeshes(qSelectedMeshes, 'V')
                def _setMirrorTableF():
                    self.setMirrorTableMiddleMeshes(qSelectedMeshes, 'F')
                qSetMirrorTable.addAction('middle mesh, edgeflow', _setMirrorTableE)
                qSetMirrorTable.addAction('middle mesh, vertex positions', _setMirrorTableV)
                qSetMirrorTable.addAction('middle mesh, face points', _setMirrorTableF)

                def _setMirrorTableSideMeshesI():
                    self.setMirrorTableSideMeshes(qSelectedMeshes, sType='I')
                def _setMirrorTableSideMeshesV():
                    self.setMirrorTableSideMeshes(qSelectedMeshes, sType='V')
                def _setMirrorTableSideMeshesF():
                    self.setMirrorTableSideMeshes(qSelectedMeshes, sType='F')
                qSetMirrorTable.addAction('side meshes, ids', _setMirrorTableSideMeshesI)
                qSetMirrorTable.addAction('side meshes, vertex positions', _setMirrorTableSideMeshesV)
                qSetMirrorTable.addAction('side meshes, face points', _setMirrorTableSideMeshesF)
            qMenu.addSeparator()
            qMenu.addAction('Select Mesh (Scene)', lambda: cmds.select([qS.text(0) for qS in qSelectedMeshes]))
            qMenu.addAction('Select BlendShape (Scene)', lambda: cmds.select(['blendShape__%s' % qS.text(0) for qS in qSelectedMeshes]))
            qMenu.addSeparator()
            def _toggleInverseExport():
                try:
                    cmds.undoInfo(openChunk=True)
                    utils.registerRedoAndUndo(funcUndo=self.refreshMeshesTreeFromScene)
                    sSelectedMeshes = [qS.text(0).split(' ')[0] for qS in qSelectedMeshes]
                    for sMesh in sSelectedMeshes:
                        if not cmds.attributeQuery(kInverseExportAttr, node=sMesh, exists=True):
                            utils.addAttr(sMesh, ln=kInverseExportAttr, at='bool', dv=False)
                        cmds.setAttr('%s.%s' % (sMesh, kInverseExportAttr), not cmds.getAttr('%s.%s' % (sMesh, kInverseExportAttr)))

                    utils.registerRedoAndUndo(funcRedo=self.refreshMeshesTreeFromScene)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            qMenu.addAction('Toggle Inverse Export', _toggleInverseExport)
            qMenu.addSeparator()
            def _selectTargetsFromMesh(bIsolate=False):
                try:
                    sSelectedMeshes = [qS.text(0).split(' ')[0] for qS in qSelectedMeshes]
                    sTargets = set()
                    for sMesh in sSelectedMeshes:
                        sBlendShape = 'blendShape__%s' % sMesh
                        sConnections = cmds.listConnections(sBlendShape, s=True, d=False) or []
                        for sConn in sConnections:
                            if sConn.startswith('%s__' % kTargetArrayMultipl):
                                sTargets.add(sConn.split('__')[1])

                    qTargets = [self._getTargetItemFromName(sTarget) for sTarget in sTargets]
                    self.qTargetsTree.clearSelection()
                    for qTarget in qTargets:
                        qTarget.setSelected(True)

                    if bIsolate:
                        self.qTargetsIsolateButton.setChecked(True)
                        self.isolateTargetsClicked(False)
                        self.isolateTargetsClicked(True)

                except Exception as e:
                    cmds.confirmDialog(m=str(e))

            qMenu.addAction('Select Targets (UI)', _selectTargetsFromMesh)
            qMenu.addAction('Isolate Targets (UI)', lambda: _selectTargetsFromMesh(bIsolate=True))

            qMenu.addSeparator()

            def removeSelectedMeshes():
                cmds.undoInfo(openChunk=True)
                try:
                    utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)
                    utils.registerRedoAndUndo(funcUndo=self.refreshMeshesTreeFromScene)

                    for qMesh in qSelectedMeshes:
                        sMesh = self._getMeshNameFromItem(qMesh)

                        sBlendShape = 'blendShape__%s' % sMesh

                        if cmds.objExists(sBlendShape):
                            cmds.delete(sBlendShape)

                        self.refreshMeshesTreeFromScene([sMesh])

                    utils.registerRedoAndUndo(funcRedo=self.refreshMeshesTreeFromScene)
                    utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene)
                except Exception as e:
                    cmds.confirmDialog(m=str(e))
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            qMenu.addAction('Delete BlendShape', removeSelectedMeshes)



        qMenu.exec_(self.qMeshesTree.mapToGlobal(vPos))



    def _selectCtrlsInUI(self, sCtrls):
        qSelectCtrls = []
        self.qCtrlsTree.clearSelection()
        for iCtrl in range(self.qCtrlsTree.invisibleRootItem().childCount()):
            qCtrl = self.qCtrlsTree.invisibleRootItem().child(iCtrl)
            if self._getCtrlNameFromItem(qCtrl) in sCtrls:
                qCtrl.setSelected(True)
                qSelectCtrls.append(qCtrl)
        return qSelectCtrls


    def _selectLocatorsFromCtrls(self, sCtrls, bStrongest=False, sTargets=None):
        try:
            # qSelectedCtrls = self.qCtrlsTree.selectedItems()
            # sCtrls = [self._getCtrlNameFromItem(qCtrl) for qCtrl in qSelectedCtrls]

            if not bStrongest:
                sSelect = []
                for sCtrl in sCtrls:
                    sSelect.extend(cmds.ls(f'_poseLocEditor__{sCtrl}__*', et='transform'))
                if not utils.isNone(sTargets):
                    sSelect = [sLoc for sLoc in sSelect if sLoc.split('__')[-1] in sTargets]
                cmds.select(sSelect)
            else:
                sSelect = []
                for sCtrl in sCtrls:
                    sPoseLocs = cmds.ls(f'_poseLocEditor__{sCtrl}__*', et='transform')
                    fWeights = []
                    for sLoc in sPoseLocs:
                        sWeightConnections = cmds.listConnections('%s.t' % sLoc, s=True, d=True)
                        if sWeightConnections:
                            fWeights.append(cmds.getAttr('%s.input2X' % sWeightConnections[0]))
                        else:
                            fWeights.append(0)
                    iBiggest = np.argmax(fWeights)
                    sSelect.append(sPoseLocs[iBiggest])
                cmds.select(sSelect)
        except Exception as e:
            cmds.confirmDialog(m=str(e))



    def _selectTargetsFromCtrls(self, sCtrls, bIsolate=False):
        try:
            # qSelectedCtrls = self.qCtrlsTree.selectedItems()
            # sCtrls = [self._getCtrlNameFromItem(qCtrl) for qCtrl in qSelectedCtrls]
            sTargets = set()
            for sCtrl in sCtrls:
                sPoseLocs = cmds.ls(f'_poseLocEditor__{sCtrl}__*', et='transform')
                for sLoc in sPoseLocs:
                    sTargets.add(sLoc.split('__')[2])

            qTargets = [self._getTargetItemFromName(sTarget) for sTarget in sTargets]
            self.qTargetsTree.clearSelection()
            for qTarget in qTargets:
                qTarget.setSelected(True)

            if bIsolate:
                self.qTargetsIsolateButton.setChecked(True)
                self.isolateTargetsClicked(False)
                self.isolateTargetsClicked(True)

        except Exception as e:
            cmds.confirmDialog(m=str(e))





    def markingMenuCtrls(self, vPos):
        qMenu = QtWidgets.QMenu()
        sAllCtrlsInUI = [self._getCtrlNameFromItem(self.qCtrlsTree.invisibleRootItem().child(iCtrl)) for iCtrl in range(self.qCtrlsTree.invisibleRootItem().childCount())]
        sAllSelectedCtrls = cmds.ls('*_ctrl', sl=True, et='transform') + cmds.ls('*_ctrl', sl=True, et='joint')
        # selectedCtrlsNotInUI = [sCtrl for sCtrl in sAllSelectedCtrls if sCtrl not in sAllCtrlsInUI]

        # sSelectedTargets = self._getTargetNames(bSelected=True)
        # if len(sAllSelectedCtrls) > 0:
        #     if sSelectedTargets:
        #         qMenu.addAction('Add/Activate "%s"' % utils.listToString(sAllSelectedCtrls, iMaxCount=3), lambda: self.addCtrlsAndActivate(sAllSelectedCtrls))
        #     else:
        #         if selectedCtrlsNotInUI:
        #             qMenu.addAction('Add "%s"' % utils.listToString(selectedCtrlsNotInUI, iMaxCount=3), lambda: self.addCtrls(selectedCtrlsNotInUI))
        #         else:
        #             qDisabledAction = qMenu.addAction('Add ...')
        #             qDisabledAction.setEnabled(False)
        # else:
        #     qDisabledAction = qMenu.addAction('Add ...')
        #     qDisabledAction.setEnabled(False)


        sSelectedCtrlsInUI = set(sAllCtrlsInUI).intersection(set(sAllSelectedCtrls))
        if sSelectedCtrlsInUI:
            qMenu.addAction('Select "%s" (UI)' % utils.listToString(list(sSelectedCtrlsInUI), iMaxCount=3), lambda: self._selectCtrlsInUI(sSelectedCtrlsInUI))
        else:
            qDisabledAction = qMenu.addAction('Select ... (UI)')
            qDisabledAction.setEnabled(False)

        qMarkedCtrls = self.qCtrlsTree.selectedItems()
        sMarkedCtrls = [self._getCtrlNameFromItem(qCtrl) for qCtrl in qMarkedCtrls]
        qMenu.addSeparator()


        qMenu.addAction('Select Most Activated Locator(s) (Scene)', lambda:self._selectLocatorsFromCtrls(sMarkedCtrls, bStrongest=True))
        qSelectedTargets = self.qTargetsTree.selectedItems()

        qSelectLocatorsOfSelectedTargets = qMenu.addAction('Select Locators of Selected Targets (Scene)', lambda: self._selectLocatorsFromCtrls(sMarkedCtrls, sTargets=[self._getTargetNameFromItem(qT) for qT in qSelectedTargets]))
        if not qSelectedTargets:
            qSelectLocatorsOfSelectedTargets.setEnabled(False)


        qMenu.addAction('Select All Locators (Scene)', lambda:self._selectLocatorsFromCtrls(sMarkedCtrls))
        qMenu.addSeparator()
        qMenu.addAction('Select All Targets (UI)', lambda: self._selectTargetsFromCtrls(sMarkedCtrls))
        qMenu.addAction('Isolate All Targets (UI)', lambda: self._selectTargetsFromCtrls(sMarkedCtrls, bIsolate=True))
        qMenu.addSeparator()
        qMiddleCtrlActions = []

        def _setMiddlePlane(iPlane):
            # qSelectedCtrls = self.qCtrlsTree.selectedItems()
            # sCtrls = [self._getCtrlNameFromItem(qCtrl) for qCtrl in qSelectedCtrls]
            for sCtrl in sMarkedCtrls:
                if utils.getSide(sCtrl) == 'm':
                    utils.addAttr(sCtrl, ln=kMiddleCtrlMirrorPlaneAttr, dv=iPlane, bReturnIfExists=True)
                    cmds.setAttr('%s.%s' % (sCtrl, kMiddleCtrlMirrorPlaneAttr), iPlane)
            self.refreshCtrlsTreeFromScene()

        qMiddleCtrlActions.append(qMenu.addAction('Set Middle Ctrl Mirror Plane to YZ', lambda:_setMiddlePlane(0)))
        qMiddleCtrlActions.append(qMenu.addAction('Set Middle Ctrl Mirror Plane to XZ', lambda:_setMiddlePlane(1)))
        qMiddleCtrlActions.append(qMenu.addAction('Set Middle Ctrl Mirror Plane to XY', lambda:_setMiddlePlane(2)))
        if not np.any([utils.getSide(sCtrl) == 'm' for sCtrl in sMarkedCtrls]):
            for qAction in qMiddleCtrlActions:
                qAction.setEnabled(False)

        # qMenu.addSeparator()
        # qMenu.addAction('Select Ctrls from Scene Selection (UI)', self._selectCtrlsInUI)
        qMenu.addSeparator()
        def _selectCtrl(bTransform=False):
            # qSelectedCtrls = self.qCtrlsTree.selectedItems()
            # sCtrls = [self._getCtrlNameFromItem(qCtrl) for qCtrl in qSelectedCtrls]
            if bTransform:
                sTransforms = [_getTransformFromCtrl(self._getCtrlNameFromItem(qCtrl)) for qCtrl in qMarkedCtrls]
                cmds.select(sTransforms)
            else:
                cmds.select(sMarkedCtrls)
        qMenu.addAction('Select Ctrls (Scene)', _selectCtrl)
        qMenu.addAction('Select Transforms (Scene)', lambda:_selectCtrl(True))
        qMenu.addSeparator()



        def _check(bChecked=False):
            try:
                cmds.undoInfo(openChunk=True)
                utils.registerRedoAndUndo(funcRedo=None, funcUndo=self.refreshCtrlsTreeFromScene)

                for qCtrl in qMarkedCtrls:
                    qCtrl.setCheckState(0, QtCore.Qt.Checked if bChecked else QtCore.Qt.Unchecked)

                utils.registerRedoAndUndo(funcRedo=self.refreshCtrlsTreeFromScene, funcUndo=None)

            except:
                raise
            finally:
                cmds.undoInfo(closeChunk=True)

        qMenu.addAction('Uncheck', lambda:_check(bChecked=False))
        qMenu.addAction('Check', lambda:_check(bChecked=True))



        def _removeCtrl():
            # qSelectedCtrls = self.qCtrlsTree.selectedItems()
            # sCtrls = [qCtrl.text(0) for qCtrl in qSelectedCtrls]
            sTransforms = [_getTransformFromCtrl(sCtrl) for sCtrl in sMarkedCtrls]
            try:
                cmds.undoInfo(openChunk=True)
                utils.registerRedoAndUndo(funcRedo=None, funcUndo=self.refreshTargetsTreeFromScene)
                utils.registerRedoAndUndo(funcRedo=None, funcUndo=self.refreshCtrlsTreeFromScene)
                for sTransform, sCtrl in zip(sTransforms, sMarkedCtrls):
                    sChildren = cmds.listRelatives(sTransform, c=True)
                    xValuesBefore = [xforms.resetTrsWithReturn(sChild) for sChild in sChildren]

                    cmds.parent(sChildren, cmds.listRelatives(sTransform, p=True)[0])
                    sPoseLocs = cmds.ls(f'_poseLocEditor__{sCtrl}__*', et='transform')
                    cmds.delete(sPoseLocs + [sTransform])

                    [xforms.setTrsValuesBack(dValuesBefore) for dValuesBefore in xValuesBefore]
                    cmds.deleteAttr('%s.poseEditor' % sCtrl)

                    for sWeightMultiplNode in cmds.ls(getWeightMultiplName(sCtrl, '*', '?')):
                        nodes.deleteConnectionsAndItself3(sWeightMultiplNode)

                utils.registerRedoAndUndo(funcRedo=self.refreshCtrlsTreeFromScene, funcUndo=None)
                utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene, funcUndo=None)

            except:
                raise
            finally:
                cmds.undoInfo(closeChunk=True)

        qMenu.addAction('Remove', _removeCtrl)

        qMenu.exec_(self.qCtrlsTree.mapToGlobal(vPos))



    def markingMenuTargets(self, vPos):

        qMenu = QtWidgets.QMenu()
        sSelectedTargets = self._getTargetNames(bSelected=True)
        if sSelectedTargets:

            def _deleteSelectedTargets():
                sBlendShapes = _getBlendShapes()
                cmds.undoInfo(openChunk=True)
                try:
                    utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)
                    utils.registerRedoAndUndo(funcUndo=self.refreshMeshesTreeFromScene)
                    utils.registerRedoAndUndo(funcUndo=self.refreshCtrlsTreeFromScene)

                    for sBlendShape in sBlendShapes:
                        for sTarget in sSelectedTargets:
                            sBlendShapeMultiplNode = getTargetArrayMultiplName(sTarget)
                            if cmds.objExists(sBlendShapeMultiplNode):
                                cmds.delete(sBlendShapeMultiplNode)

                        blendShapes.deleteBlendShapeTarget(sBlendShape, sSelectedTargets, bErrorIfNotExists=False)

                    sAllCtrls = self._getAllCtrlsInScene()

                    for sCtrl in sAllCtrls:
                        # sTransform = _getTransformFromCtrl(sCtrl)
                        sPoseLocs = cmds.ls(f'_poseLocEditor__{sCtrl}__*', et='transform')
                        for sLoc in sPoseLocs:
                            _, sCtrl, sTarget = sLoc.split('__') # _poseLocEditor__grp_l_testOffsetPoseEditor__uparm_l_up
                            if sTarget in sSelectedTargets:
                                xforms.resetTransform(sLoc)
                                for sA in 'trs':
                                    sWeightNode = f'WEIGHT__{sCtrl}__{sTarget}__{sA}'# WEIGHT__grp_l_testOffsetPoseEditor__elbow_l_bend__r
                                    if cmds.objExists(sWeightNode):
                                        nodes.deleteConnectionsAndItself3(sWeightNode)
                                cmds.delete(sLoc)

                    for sTarget in sSelectedTargets:
                        sTargetMultipl = '%s__%s' % (kTargetArrayMultipl, sTarget)
                        if cmds.objExists(sTargetMultipl) and not cmds.listConnections(getComboOutput(sTargetMultipl), s=False, d=True):
                            nodes.deleteConnectionsAndItself3(sTargetMultipl)

                    utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene)
                    utils.registerRedoAndUndo(funcRedo=self.refreshMeshesTreeFromScene)
                    utils.registerRedoAndUndo(funcRedo=self.refreshCtrlsTreeFromScene)

                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)


            sSelectedCtrls = cmds.ls('*_ctrl', sl=True)
            sCtrlsMask = sSelectedCtrls if sSelectedCtrls else None
            import importlib
            importlib.reload(utils)
            sCtrlsString = utils.listToString(sSelectedCtrls, iMaxCount=3, bQuotations=True) if sSelectedCtrls else 'ALL CTRLS'


            qMenu.addAction('Delete', _deleteSelectedTargets)
            qMirrorMenu = qMenu.addMenu(f'Mirror from Selected')
            qMirrorMenu.addAction('Just Pose Combinations', lambda:self.mirrorTargets(bToSelected=False, bMeshes=False, bCtrls=False))
            qMirrorMenu.addSeparator()
            qMirrorMenu.addAction('Side: Pose Combinations and Flip Meshes (Selected Meshes in Scene)', lambda:self.mirrorTargets(bToSelected=False, bMeshes=True, bCtrls=False))
            qMirrorMenu.addAction('Side: Pose Combinations and Split Current Combined Shape into Left/Right (Selected Meshes in Scene)', lambda:self.mirrorTargets(bToSelected=False, bMeshes=True, bCtrls=False, bSplitCurrentShape=True))
            qMirrorMenu.addAction('Side: Pose Combinations and Ctrls (%s)' % sCtrlsString, lambda:self.mirrorTargets(bToSelected=False, bMeshes=False, bCtrls=True, sCtrlsMask=sCtrlsMask))
            qMirrorMenu.addSeparator()
            qMirrorMenu.addAction('Middle: Meshes Left -> Right (Selected Meshes in Scene)', lambda:self.mirrorTargetsMiddle(bMeshes=True, bCtrls=False, bLeftToRight=True))
            qMirrorMenu.addAction('Middle: Meshes Right -> Left (Selected Meshes in Scene)', lambda:self.mirrorTargetsMiddle(bMeshes=True, bCtrls=False, bLeftToRight=False))
            qMirrorMenu.addAction('Middle: Ctrls Left -> Right (%s)' % sCtrlsString, lambda:self.mirrorTargetsMiddle(bMeshes=False, bCtrls=True, bLeftToRight=True, sCtrlsMask=sCtrlsMask))
            qMirrorMenu.addAction('Middle: Ctrls Right -> Left (%s)' % sCtrlsString, lambda:self.mirrorTargetsMiddle(bMeshes=False, bCtrls=True, bLeftToRight=False, sCtrlsMask=sCtrlsMask))


            qMirrorMenu = qMenu.addMenu(f'Mirror to Selected')
            qMirrorMenu.addAction('Side: Just Pose Combinations', lambda:self.mirrorTargets(bToSelected=True, bMeshes=False, bCtrls=False))
            qMirrorMenu.addAction('Side: Pose Combinations and Meshes (Selected Meshes in Scene)', lambda:self.mirrorTargets(bToSelected=True, bMeshes=True, bCtrls=False))
            qMirrorMenu.addAction('Side: Pose Combinations and Ctrls (All Locators of Targets)', lambda:self.mirrorTargets(bToSelected=True, bMeshes=False, bCtrls=True))

            def _resetBlendShapes():
                pSelection = patch.getSelectedPatches()
                sTargets = self._getTargetNames(bSelected=True)
                try:
                    cmds.undoInfo(openChunk=True)
                    for pMesh in pSelection:
                        sBlendShape = 'blendShape__%s' % pMesh.getTransformName()
                        if cmds.objExists(sBlendShape):
                            dTargetIndices = blendShapes.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
                            for sT in sTargets:
                                if sT not in dTargetIndices:
                                    continue
                                iTarget = dTargetIndices[sT]
                                sTargetAttr = '%s.%s' % (sBlendShape, sT)
                                sConnections = cmds.listConnections(sTargetAttr, s=True, d=False, p=True)
                                if sConnections:
                                    sPrevPlug = sConnections[0]
                                    cmds.disconnectAttr(sPrevPlug, sTargetAttr)
                                else:
                                    sPrevPlug = cmds.getAttr(sTargetAttr)
                                cmds.setAttr(sTargetAttr, 0.0)

                                aaDefaultPoints = pMesh.getAllPoints()
                                cmds.setAttr(sTargetAttr, 1.0)
                                aaTargetPoints = pMesh.getAllPoints()

                                aValues = np.zeros(pMesh.getTotalCount(), dtype='float64')
                                if utils.isNone(pMesh.aSofts):
                                    aValues[pMesh.aIds] = 1.0
                                else:
                                    aValues[pMesh.aIds] = pMesh.aSofts
                                aaPoints = aaDefaultPoints * aValues[:,np.newaxis] + aaTargetPoints * (1.0-aValues[:,np.newaxis])

                                cmds.sculptTarget(sBlendShape, e=True, t=iTarget)
                                pMesh.setPoints(aaPoints)
                                cmds.sculptTarget(sBlendShape, e=True, t=-1)

                                utils._connectOrSet(sPrevPlug, sTargetAttr)
                except:
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)
            qMenu.addAction('Erase BlendShape Target', _resetBlendShapes)


            def _selectMultiplNode():
                sArrayMultipls = [getTargetArrayMultiplName(sT) for sT in sSelectedTargets]
                cmds.select(sArrayMultipls)
            qMenu.addAction('Select Combination Node', _selectMultiplNode)

            qMenu.addSeparator()

            qMenu.addAction('Select Interpolators', self.selectInterpolatorsFromSelectedTargets)
            qMenu.addAction('Isolate Interpolators', lambda:self.selectInterpolatorsFromSelectedTargets(bIsolate=True))
            qMenu.addSeparator()
            qMenu.addAction('Select Pose Locators', self.selectPoseLocatorsOfTargets)


        qSelectedTargetPoses = [qItem for qItem in self.qTargetsTree.selectedItems() if qItem.parent()]
        if qSelectedTargetPoses: # selected poses
            def _removePosesFromTarget():
                try:
                    cmds.undoInfo(openChunk=True)
                    utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)

                    for qPoseToDelete in qSelectedTargetPoses:
                        sPoseToDelete = qPoseToDelete.text(0)
                        qTarget = qPoseToDelete.parent()
                        sTarget = self._targetNameFromTargetItem(qTarget)
                        sPoseOutputs = self._getTargetPoses(qTarget)
                        # sPoseOutputs = [qTarget.child(p).text(0) for p in range(qTarget.childCount())]
                        sPoseOutputs.remove(sPoseToDelete)
                        getTargetArrayMultipl(sTarget, sPoseOutputs)

                    utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene)

                except Exception as e:
                    cmds.confirmDialog(m=str(e))
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)


            def _toggleDisabled():
                try:
                    cmds.undoInfo(openChunk=True)
                    utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)

                    for qPoseToToggle in qSelectedTargetPoses:
                        sPoseToToggle = qPoseToToggle.text(0).split(' ')[0]
                        qTarget = qPoseToToggle.parent()
                        sTarget = self._targetNameFromTargetItem(qTarget)

                        sTargetArrayMutlipl = getTargetArrayMultiplName(sTarget)

                        sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetArrayMutlipl))
                        iPose = sPoseOutputs.index(sPoseToToggle)
                        iNonDriverInputs = eval(cmds.getAttr('%s.iNonDriverInputs' % sTargetArrayMutlipl))
                        if iPose in iNonDriverInputs:
                            iNonDriverInputs.remove(iPose)
                        else:
                            iNonDriverInputs.add(iPose)

                        sPoseOutputs.index(sPoseToToggle)
                        getTargetArrayMultipl(sTarget, sPoseOutputs, iNonDriverInputs=iNonDriverInputs, bForceRecreate=True)

                    utils.registerRedoAndUndo(funcRedo=self.refreshTargetsTreeFromScene)

                except Exception as e:
                    cmds.confirmDialog(m=str(e))
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            qMenu.addAction('Remove Poses from Target', _removePosesFromTarget)
            qMenu.addAction('Toggle Disabled', _toggleDisabled)

        qMenu.exec_(self.qTargetsTree.mapToGlobal(vPos))


    def copy(self):
        qInterps = self.getSelectedInterpolators()
        xInterpolators = _serializeInterpolators([qI.text(0).split(' ')[0] for qI in qInterps])
        utils.copyToClipBoard('interpolators:%s' % str(xInterpolators))


    def paste(self):
        import importlib
        importlib.reload(utils)
        sClipboard = utils.getFromClipBoard()
        if sClipboard.startswith('interpolators:'):
            xInterpolators = eval(utils.replaceStringStart(sClipboard, 'interpolators:', ''))

            sExistingInterps = [sN for sN in cmds.ls(et='transform') if cmds.attributeQuery('sInterpType', node=sN, exists=True)]
            sNewInterps = []

            try:
                cmds.undoInfo(openChunk=True)
                utils.registerRedoAndUndo(funcUndo=self.refreshInterpTreeFromScene)

                for dInterp in xInterpolators:
                    sNewName = utils.getUniqueNameFromList(dInterp['sName'], sExistingInterps)
                    dInterp['sName'] = sNewName
                    sExistingInterps.append(sNewName)
                    sNewInterps.append(sNewName)
                    _buildInterpFromDict(dInterp)

                utils.registerRedoAndUndo(funcRedo=lambda: self.refreshInterpTreeFromScene(sNewInterps))

            except:
                raise
            finally:
                cmds.undoInfo(closeChunk=True)

    def markingMenuMain(self, vPos):
        qMenu = QtWidgets.QMenu()

        qMainItem = self.qMainTree.currentItem()
        dMainItem = qMainItem.data(0, QtCore.Qt.UserRole)

        if dMainItem['sType'] == 'interp':
            qInterp = qMainItem
            qMenu.addAction('Mirror From Selected', self.mirrorInterp)
            qMenu.addAction('Mirror From Opposite', lambda: self.mirrorInterp(bToSelected=True))
            qMenu.addSeparator()
            qMenu.addAction('Duplicate', lambda: self.duplicateInterp())
            qMenu.addSeparator()
            qMenu.addAction('Add Pose', self.createNewPose)
            qMenu.addAction('Force Rebuild', self.rebuildInterpolators)
            qMenu.addAction('Delete', self.deleteInterp)
            qMenu.addAction('Create ROM Animation', self.createRomAnimation)
            qMenu.addSeparator()
            qMenu.addAction('Copy', self.copy)
            qMenu.addAction('Paste', self.paste)



            dInterp = qInterp.data(0, QtCore.Qt.UserRole)
            if dInterp['sInterpType'] == 'cone':
                def convertToMayaPose(qConeInterp=qInterp):
                    self.convertToMayaPose(qConeInterp)
                qMenu.addAction('Convert to MayaPose', convertToMayaPose)
            elif dInterp['sInterpType'] == 'mayaPose':
                def convertToCone(qMayaPoseInterp=qInterp):
                    self.convertToCone(qMayaPoseInterp)
                qMenu.addAction('Convert to Cone', convertToCone)

            qMenu.addSeparator()
            qMenu.addAction('Select Ctrl (Scene)', self.selectCtrl)
            qMenu.addSeparator()
            qMenu.addAction('Select Targets (UI)', self.selectTargetsFromSelectedPoses)
            qMenu.addAction('Isolate Targets (UI)', lambda:self.selectTargetsFromSelectedPoses(bIsolate=True))


            qMenu.exec_(self.qMainTree.mapToGlobal(vPos))

        elif dMainItem['sType'] == 'pose':
            qMenu.addAction('Remove Poses', self.removePoses)

            qSwapAction = qMenu.addAction('Swap Names of 2 Poses', self.swapPoseNames)
            dInterpolatorPoses = self._getSelectedInterpolatorPoses()
            if len(dInterpolatorPoses) != 1 or len(dInterpolatorPoses[list(dInterpolatorPoses.keys())[0]]) != 2:
                qSwapAction.setDisabled(True)

            qMenu.addAction('Pose to', self.poseTo)
            qMenu.addSeparator()
            qMenu.addAction('Select Targets (UI)', self.selectTargetsFromSelectedPoses)
            qMenu.addAction('Isolate Targets (UI)', lambda:self.selectTargetsFromSelectedPoses(bIsolate=True))
            qMenu.addSeparator()
            qMenu.addAction('_print', self._print)
            qMenu.exec_(self.qMainTree.mapToGlobal(vPos))
        return qMenu

    def deleteInterp(self):
        sConnectedTargets = self.getTargetsFromSelectedInterps()

        if sConnectedTargets:
            if cmds.confirmDialog(m='Can\'t delete, because there are %d targets connected to the selected interpolator(s).\nSelect them?' % len(sConnectedTargets),
                                  button=['yes', 'no']) == 'yes':
                qTargets = [self._getTargetItemFromName(sTarget) for sTarget in sConnectedTargets]
                self.qTargetsTree.clearSelection()
                for qTarget in qTargets:
                    qTarget.setSelected(True)
        else:
            try:
                cmds.undoInfo(openChunk=True)
                utils.registerRedoAndUndo(funcUndo=self.refreshInterpTreeFromScene)
                sInterps = [self._transformFromInterpItem(qI) for qI in self.getSelectedInterpolators()]
                cmds.delete(sInterps)
                self.refreshInterpTreeFromScene()
                utils.registerRedoAndUndo(funcRedo=self.refreshInterpTreeFromScene)
            except Exception as e:
                cmds.confirmDialog(m=str(e))
                raise
            finally:
                cmds.undoInfo(closeChunk=True)

    def createNewPose(self):
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshInterpTreeFromScene)

            qInterps = self.getSelectedInterpolators()
            dDefaultPoseValues = {}

            for qInterp in qInterps:
                sCurrentPoses = [qInterp.child(p).text(0) for p in range(qInterp.childCount())]
                sNewPoseName = utils.getUniqueNameFromList('newPose', sCurrentPoses)
                self.addPoseToTree(qInterp, sNewPoseName)

                dInterp = qInterp.data(0, QtCore.Qt.UserRole)
                sInterp = self._transformFromInterpItem(qInterp)
                if dInterp['sInterpType'] in ['cone', 'mayaPose']:
                    sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
                    dDefaultPoseValues[sCtrl] = cmds.getAttr('%s.r' % sCtrl)[0]
                elif dInterp['sInterpType'] in ['signedAngle', 'attribute']:
                    sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterp)
                    dDefaultPoseValues[sCtrlAttr] = cmds.getAttr(sCtrlAttr)

            self.rebuildInterpolators(qInterps, dDefaultPoseValues=dDefaultPoseValues)

            for xCtrl, fValue in dDefaultPoseValues.items():
                if '.' not in xCtrl:
                    cmds.setAttr('%s.r' % xCtrl, *fValue)
                else:
                    cmds.setAttr(xCtrl, fValue)

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def createRomAnimation(self):
        sInterps = [self._transformFromInterpItem(qI) for qI in self.getSelectedInterpolators()]
        sAlreadyAdded = set()
        sPairs = []
        for sInterp in sInterps:
            if sInterp in sAlreadyAdded:
                continue
            sMirrorInterp = utils.getMirrorName(sInterp)
            if sMirrorInterp != sInterp and sMirrorInterp in sInterps:
                sPairs.append([sInterp, sMirrorInterp])
                sAlreadyAdded.add(sInterp)
                sAlreadyAdded.add(sMirrorInterp)
            else:
                sPairs.append([sInterp])
                sAlreadyAdded.add(sInterp)

        print ('sPairs: ', sPairs)
        iTimeOffset = 0
        for sInterps in sPairs:
            xxPoses = [eval(cmds.getAttr('%s.xPoses' % sI)) for sI in sInterps]
            sCtrls = [cmds.getAttr('%s.sCtrl' % sI) for sI in sInterps]

            for i,sI in enumerate(sInterps):
                setRotationKeyframe(sCtrls[i], [0,0,0], iTimeOffset)

                for p,xPose in enumerate(xxPoses[i]):
                    iTime = 1 if p == 0 else p * 10
                    fEuler = xPose[1:4]
                    setRotationKeyframe(sCtrls[i], fEuler, iTimeOffset + iTime)
                iTime += 10
                setRotationKeyframe(sCtrls[i], [0,0,0], iTimeOffset + iTime)

            iTimeOffset += iTime

        fMinTime = cmds.playbackOptions(q=True, minTime=True)
        fMaxTime = cmds.playbackOptions(q=True, maxTime=True)
        cmds.playbackOptions(e=True, minTime=min(fMinTime, 1), maxTime=max(fMaxTime, iTimeOffset))

    def selectCtrl(self):
        sCtrls = []
        for qInterp in self.getSelectedInterpolators():
            sInterp = self._transformFromInterpItem(qInterp)
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
            sCtrls.append(sCtrl)
        cmds.select(sCtrls)

    def getSelectedInterpolators(self):
        qSelectedInterps = []
        for qItem in self.qMainTree.selectedItems():
            dItem = qItem.data(0, QtCore.Qt.UserRole)
            if dItem['sType'] == 'interp':
                qSelectedInterps.append(qItem)
        return qSelectedInterps



    def duplicateInterp(self):
        qSelectedInterps = self.getSelectedInterpolators()
        sSelectedInterps = [self._transformFromInterpItem(qI) for qI in qSelectedInterps]
        sAllInterps = _findInterpolatorsInScene()
        sNewInterps = []

        cmds.undoInfo(openChunk=True)
        try:
            utils.registerRedoAndUndo(funcUndo=lambda:self.refreshInterpTreeFromScene(sSelectedInterps))

            for sInterp, qInterp in zip(sSelectedInterps, qSelectedInterps):
                dInterp = _serializeInterpolators([sInterp])[0]
                sNewName = utils.getUniqueNameFromList(dInterp['sName'], sAllInterps)
                dInterp['sName'] = sNewName
                _buildInterpFromDict(dInterp)

                sAllInterps.append(sNewName)
                sNewInterps.append(sNewName)

            utils.registerRedoAndUndo(funcRedo=lambda:self.refreshInterpTreeFromScene(sNewInterps))
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def mirrorInterp(self, bToSelected=False):
        try:
            cmds.undoInfo(openChunk=True)
            sSelectWhenDone = []
            utils.registerRedoAndUndo(funcUndo=self.refreshInterpTreeFromScene)
            utils.registerRedoAndUndo(funcUndo=self.refreshTargetsTreeFromScene)

            qSelectedInterps = self.getSelectedInterpolators()
            sSelectedInterps = [self._transformFromInterpItem(qI) for qI in qSelectedInterps]

            for sSelectedI in sSelectedInterps:
                qSelectedI = self._findInterpItemFromName(sSelectedI)
                sInterpTransform = self._transformFromInterpItem(qSelectedI)
                sMirrorInterpTransform = utils.getMirrorName(sInterpTransform)

                if bToSelected:
                    sToInterp, sFromInterp = sInterpTransform, sMirrorInterpTransform
                    qFromInterp = self._findInterpItemFromName(sMirrorInterpTransform)
                else:
                    sFromInterp, sToInterp = sInterpTransform, sMirrorInterpTransform
                    qFromInterp = qSelectedI

                dFromInterp = qFromInterp.data(0, QtCore.Qt.UserRole)
                sInterpType = dFromInterp['sInterpType']

                sPoseNames = [qFromInterp.child(p).text(0) for p in range(qFromInterp.childCount())]

                if sInterpType == 'signedAngle':
                    sJoint, sParentJoint = eval(cmds.getAttr('%s.sJoints' % sFromInterp))
                    sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sFromInterp)
                    iAngleAxis = eval(cmds.getAttr('%s.iAngleAxis' % sFromInterp))
                    iUpAxis = eval(cmds.getAttr('%s.iUpAxis' % sFromInterp))
                    ffRanges = eval(cmds.getAttr('%s.ffRanges' % sFromInterp))
                    # sPoseNames = [qFromInterp.child(p).text(0) for p in range(qFromInterp.childCount())]
                    dRanges = {sPoseName: ffRanges[p] for p, sPoseName in enumerate(sPoseNames)}
                    dCurveTypes = {sPoseName:cmds.getAttr('%s.%s_curveType' % (sFromInterp, sPoseName)) for sPoseName in sPoseNames}

                    xPoses = [(sPoseName, dRanges[sPoseName], dCurveTypes[sPoseName]) for sPoseName in sPoseNames]
                    sTempInterpTransform = '%s%s' % (sToInterp, kTempString)
                    interpolator.createSignedAngleInterpolator3(sTempInterpTransform,
                                                                utils.getMirrorName(sJoint),
                                                                utils.getMirrorName(sParentJoint),
                                                                utils.getMirrorName(sCtrlAttr),
                                                                iAngleAxis=iAngleAxis,
                                                                iUpAxis=iUpAxis,
                                                                xPoses=xPoses,
                                                                bMirror=False, bComputeInParentSpace=False)


                elif sInterpType == 'custom':
                    sCtrlAttrX = cmds.getAttr('%s.sCtrlAttrX' % sFromInterp)
                    sCtrlAttrY = cmds.getAttr('%s.sCtrlAttrY' % sFromInterp)
                    sCtrlAttrZ = cmds.getAttr('%s.sCtrlAttrZ' % sFromInterp)
                    sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sFromInterp)
                    xPosesValue = eval(cmds.getAttr('%s.xPoses' % sFromInterp))

                    sPoseNames = [xP[0] for xP in xPosesValue]
                    dValues = {xP[0]:(xP[1],xP[2],xP[3]) for xP in xPosesValue}
                    dCurveTypes = {sPoseName:cmds.getAttr('%s.%s_curveType' % (sFromInterp, sPoseName)) for sPoseName in sPoseNames}

                    xPoses = [(sPoseName, dValues[sPoseName], dCurveTypes[sPoseName]) for sPoseName in sPoseNames]
                    sTempInterpTransform = '%s%s' % (sToInterp, kTempString)

                    interpolator.createCustomInterpolator(sTempInterpTransform,
                                                                [utils.getMirrorName(sCtrlAttrX), utils.getMirrorName(sCtrlAttrY), utils.getMirrorName(sCtrlAttrZ)],
                                                                utils.getMirrorName(sDriverAttr),
                                                                xPoses=xPoses)

                elif sInterpType == 'attribute':
                    sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sFromInterp)
                    sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sFromInterp)
                    ffRanges = eval(cmds.getAttr('%s.ffRanges' % sFromInterp))
                    # sPoseNames = [qFromInterp.child(p).text(0) for p in range(qFromInterp.childCount())]
                    dRanges = {sPoseName: ffRanges[p] for p, sPoseName in enumerate(sPoseNames)}
                    dCurveTypes = {sPoseName:cmds.getAttr('%s.%s_curveType' % (sFromInterp, sPoseName)) for sPoseName in sPoseNames}

                    xPoses = [(sPoseName, dRanges[sPoseName], dCurveTypes[sPoseName]) for sPoseName in sPoseNames]
                    sTempInterpTransform = '%s%s' % (sToInterp, kTempString)
                    interpolator.createAttributeInterpolator(sTempInterpTransform,
                                                                utils.getMirrorName(sCtrlAttr),
                                                                utils.getMirrorName(sDriverAttr),
                                                                xPoses=xPoses,
                                                                bMirror=False)


                elif sInterpType == 'cone':
                    sJoint = cmds.getAttr('%s.sJoint' % sFromInterp)
                    sJointParent = cmds.getAttr('%s.sJointParent' % sFromInterp)
                    sCtrl = cmds.getAttr('%s.sCtrl' % sFromInterp)

                    sConeTransforms = ['%s_%s_cone' % (sFromInterp, sPoseName) for sPoseName in sPoseNames]
                    dCurveTypes = {sPoseName:cmds.getAttr('%s.curveType' % sConeTransform) for sPoseName,sConeTransform in zip(sPoseNames, sConeTransforms)}
                    dRotationValues = {sPoseName:cmds.getAttr('%s.r' % sConeTransform)[0] for sPoseName, sConeTransform in zip(sPoseNames, sConeTransforms)}
                    dInnerOuterRanges = {sPoseName: [cmds.getAttr('%s.startAngle' % sConeTransform), cmds.getAttr('%s.endAngle' % sConeTransform)] for
                                         sPoseName, sConeTransform in zip(sPoseNames, sConeTransforms)}
                    dRevs = {sPoseName:utils.getAttrIfExists('%s.bReverse' % sConeTransform, 0.0) for sPoseName,sConeTransform in zip(sPoseNames, sConeTransforms)}

                    xPosesPass = [(sPoseName, dRotationValues[sPoseName], dInnerOuterRanges[sPoseName], dCurveTypes[sPoseName], dRevs[sPoseName]) for sPoseName in sPoseNames if sPoseName != 'default']  # [('default',(0,0,0), (0,45)]

                    sTempInterpTransform = '%s%s' % (sToInterp, kTempString)
                    interpolator.createConeInterpolator2(sTempInterpTransform,
                                                        utils.getMirrorName(sJoint),
                                                        utils.getMirrorName(sCtrl),
                                                        utils.getMirrorName(sJointParent),
                                                        xPoses=xPosesPass,
                                                        # sJointParent=utils.getMirrorName(sJointParent),
                                                        bMirror=False)


                elif sInterpType == 'mayaPose':
                    sJoint = cmds.getAttr('%s.sJoint' % sFromInterp)
                    sJointParent = cmds.getAttr('%s.sJointParent' % sFromInterp)
                    sCtrl = cmds.getAttr('%s.sCtrl' % sFromInterp)
                    xPosesValue = eval(cmds.getAttr('%s.xPoses' % sFromInterp))  # [('side', 0, 0, 90), ('forward', 90, 0, 0), ('forwardExtreme', 110, 0, 0), ('back', -50, 0, 0)]
                    bRevs = eval(cmds.getAttr('%s.bRevs' % sFromInterp))
                    dRotations = {xP[0]:(xP[1], xP[2], xP[3]) for xP in xPosesValue}
                    dRevs = {sPoseName:bReverse for sPoseName, bReverse in zip(sPoseNames, bRevs)}

                    xPosesPass = [(sPoseName, dRotations[sPoseName][0], dRotations[sPoseName][1], dRotations[sPoseName][2], dRevs[sPoseName]) for sPoseName in sPoseNames]
                    sTempInterpTransform = '%s%s' % (sToInterp, kTempString)
                    interpolator.createPoseInterpolator(sTempInterpTransform,
                                                        utils.getMirrorName(sJoint),
                                                        utils.getMirrorName(sCtrl),
                                                        utils.getMirrorName(sJointParent),
                                                        xPoses=xPosesPass,
                                                        bMirror=False)

                elif sInterpType == 'upleg':
                    sTempInterpTransform = '%s%s' % (sToInterp, kTempString)
                    xPosesValue = eval(cmds.getAttr('%s.xPoses' % sFromInterp))  # [('side', 0, 0, 90), ('forward', 90, 0, 0), ('forwardExtreme', 110, 0, 0), ('back', -50, 0, 0)]
                    sPoseNames = [xP[0] for xP in xPosesValue]
                    fUpRotations = [xP[1] for xP in xPosesValue]
                    fKneeStarts = [cmds.getAttr('%s.kneeStart_%s' % (sInterpTransform, sPoseName)) for sPoseName in sPoseNames]
                    fTurnOffOnIns = [cmds.getAttr('%s.turnOffOnIn_%s' % (sInterpTransform, sPoseName)) for sPoseName in sPoseNames]
                    bReverses = [cmds.getAttr('%s.reverse_%s' % (sInterpTransform, sPoseName)) for sPoseName in sPoseNames]
                    interpolator.createUpLegInterpolator2(sTempInterpTransform, sPoseNames=sPoseNames, fKneeStarts=fKneeStarts, fTurnOffOnIns=fTurnOffOnIns, fUpRotations=fUpRotations, bReverses=bReverses, bMirror=False)

                else:
                    raise Exception('%s is not setup-ed for mirror yet' % sInterpType)

                # to this point the interpolators still have temp names and need to be re-wired in case they already existed before

                qToInterp = self._findInterpItemFromName(sToInterp)
                if qToInterp:
                    sOldPoseNames = [qToInterp.child(p).text(0) for p in range(qToInterp.childCount())]

                dChangedPoseNames = {}
                if qToInterp:
                    for p,sPose in enumerate(sOldPoseNames):
                        if sPose not in sPoseNames:
                            sMostSimilar, fRating = utils.getMostSimilarStringFromList(sPose, sPoseNames)
                            dChangedPoseNames[sPose] = sMostSimilar if not utils.isNone(sMostSimilar) else sPoseNames[0]

                print ('dChangedPoseNames: ', dChangedPoseNames)
                moveConnectionsAndDelete(sTempInterpTransform, dChangedPoseNames=dChangedPoseNames)

                sSelectWhenDone.append(sToInterp)

                self.refreshInterpTreeFromScene(sSelectWhenDone)
                self.refreshTargetsTreeFromScene()

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def mainTreeSelectionChanged(self):
        qSelectedItems = self.qMainTree.selectedItems()
        utilsQt.clearLayout(self.qInterpAttributesLayoutDynamic)

        if len(qSelectedItems) == 1:
            qMainItem = qSelectedItems[0]
            self.refreshAttributes(qMainItem)
        else:
            self.qInterpAttributesLayoutDynamic.addStretch()

        sSelect = []
        for qItem in qSelectedItems:
            dItem = qItem.data(0, QtCore.Qt.UserRole)
            if dItem['sType'] == 'interp':
                sSelect.append(self._transformFromInterpItem(qItem))
            elif dItem['sType'] == 'pose':
                qInterp = qItem.parent()
                dInterp = qInterp.data(0, QtCore.Qt.UserRole)
                sInterp = self._transformFromInterpItem(qInterp)
                if dInterp['sInterpType'] == 'cone':
                    sSelect.append('%s_%s_cone' % (sInterp, qItem.text(0)))
                else:
                    sSelect.append(sInterp)
        cmds.select([sObj for sObj in sSelect if cmds.objExists(sObj)])

    def updateOutputAttrs(self, qInterp):
        for iPose in range(qInterp.childCount()):
            qPose = qInterp.child(iPose)
            dPose = qPose.data(0, QtCore.Qt.UserRole)
            dPose['sOutputAttr'] = '%s.%s' % (self._transformFromInterpItem(qInterp), qPose.text(0))
            qPose.setData(0, QtCore.Qt.UserRole, dPose)

    def refreshAttributes(self, _=None):
        qSelectedItems = self.qMainTree.selectedItems()

        utilsQt.clearLayout(self.qInterpAttributesLayoutDynamic)

        if len(qSelectedItems) != 1:
            return

        qMainItem = qSelectedItems[0]
        dData = qMainItem.data(0, QtCore.Qt.UserRole)
        sType = dData['sType']
        if sType =='interp':

            sInterpTransform = self._transformFromInterpItem(qMainItem)
            # cmds.select(sInterpTransform)
            sInterpType = cmds.getAttr('%s.sInterpType' % sInterpTransform)

            qNameLayout = QtWidgets.QHBoxLayout()
            qName = QtWidgets.QLineEdit(sInterpTransform)
            def changedName(qName=qName):
                try:
                    cmds.undoInfo(openChunk=True)
                    sNewName = qName.text().strip()
                    if sNewName:
                        for sChild in cmds.listRelatives(sInterpTransform, c=True, p=False, typ='transform') or []:
                            if sChild.endswith('_cone'):
                                cmds.rename(sChild, utils.replaceStringStart(sChild, sInterpTransform, sNewName))
                        cmds.rename(sInterpTransform, sNewName)

                    sTargetMultipls = cmds.ls('%s__*' % kTargetArrayMultipl)
                    for sTargetMultipl in sTargetMultipls:
                        sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetMultipl))
                        for p in range(len(sPoseOutputs)):
                            if sPoseOutputs[p].startswith('%s.' % sInterpTransform):
                                sPoseOutputs[p] = utils.replaceStringStart(sPoseOutputs[p], sInterpTransform, sNewName)
                        cmds.setAttr('%s.sPoseOutputs' % sTargetMultipl, str(sPoseOutputs), type='string')

                    qMainItem.setText(0, '%s (%s)' % (sNewName, sInterpType))

                    self.updateOutputAttrs(qMainItem)
                    self.refreshAttributes(qMainItem)
                    self.refreshTargetsTreeFromScene()
                except Exception as e:
                    cmds.confirmDialog(m=str(e))
                finally:
                    cmds.undoInfo(closeChunk=True)

            qName.editingFinished.connect(changedName)
            qNameLayout.addWidget(QtWidgets.QLabel('Name:'))
            qNameLayout.addWidget(qName)
            self.qInterpAttributesLayoutDynamic.addLayout(qNameLayout)

            if sInterpType == 'signedAngle':
                sJoint, sParentJoint = eval(cmds.getAttr('%s.sJoints' % sInterpTransform))
                sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterpTransform)
                iAngleAxis = eval(cmds.getAttr('%s.iAngleAxis' % sInterpTransform))
                iUpAxis = eval(cmds.getAttr('%s.iUpAxis' % sInterpTransform))
                self._addNodeItemData(qMainItem, 'Joint: ',  'joint', sValueFromRig=sJoint, sKey='sJoint')
                self._addNodeItemData(qMainItem, 'ParentJoint: ','joint', sValueFromRig=sParentJoint, sKey='sParentJoint')
                self._addNodeItemData(qMainItem, 'CtrlAttr', None, sValueFromRig=sCtrlAttr, sKey='sCtrlAttr', bIsAttribute=True)
                self._addComboItemData(qMainItem, 'Angle Axis (Joint)','XYZ', sValueFromRig='XYZ'[iAngleAxis], sKey='iAngleAxis')
                self._addComboItemData(qMainItem, 'Up Axis (Joint)', 'XYZ', sValueFromRig='XYZ'[iUpAxis], sKey='iUpAxis')

            if sInterpType == 'attribute':
                sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterpTransform)
                sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sInterpTransform)
                self._addNodeItemData(qMainItem, 'CtrlAttr', 'transform', sValueFromRig=sCtrlAttr, sKey='sCtrlAttr')
                self._addNodeItemData(qMainItem, 'sDriverAttr', 'transform', sValueFromRig=sDriverAttr, sKey='sDriverAttr')

            if sInterpType == 'custom':
                sCtrlAttrX = cmds.getAttr('%s.sCtrlAttrX' % sInterpTransform)
                sCtrlAttrY = cmds.getAttr('%s.sCtrlAttrY' % sInterpTransform)
                sCtrlAttrZ = cmds.getAttr('%s.sCtrlAttrZ' % sInterpTransform)
                sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sInterpTransform)
                self._addNodeItemData(qMainItem, 'Ctrl Attr X', sValueFromRig=sCtrlAttrX, sKey='sCtrlAttrX', bIsAttribute=True)
                self._addNodeItemData(qMainItem, 'Ctrl Attr Y', sValueFromRig=sCtrlAttrY, sKey='sCtrlAttrY', bIsAttribute=True)
                self._addNodeItemData(qMainItem, 'Ctrl Attr Z', sValueFromRig=sCtrlAttrZ, sKey='sCtrlAttrZ', bIsAttribute=True)
                self._addNodeItemData(qMainItem, 'Driver Attr', sValueFromRig=sDriverAttr, sKey='sDriverAttr', bIsAttribute=True)

            elif sInterpType == 'cone':
                sJoint = cmds.getAttr('%s.sJoint' % sInterpTransform)
                sCtrl = cmds.getAttr('%s.sCtrl' % sInterpTransform)
                sJointParent = cmds.getAttr('%s.sJointParent' % sInterpTransform)
                iCtrlTwistAxis = int(utils.getAttrIfExists('%s.iCtrlTwistAxis' % sInterpTransform, 1.0))
                bJointAngleFactor = bool(utils.getAttrIfExists('%s.bJointAngleFactor' % sInterpTransform, 0.0))
                self._addNodeItemData(qMainItem, 'Joint: ',  'joint', sValueFromRig=sJoint, sKey='sJoint')
                self._addNodeItemData(qMainItem, 'JointParent: ','joint', sValueFromRig=sJointParent, sKey='sJointParent')
                self._addNodeItemData(qMainItem, 'Ctrl: ', 'transform', sValueFromRig=sCtrl, sKey='sCtrl')
                # self._addVectorData(qMainItem, 'Ctrl Twist Axis', ['X', 'Y', 'Z'], fCtrlTwistAxis, sKey='fCtrlTwistAxis', bGoToPoseOnEdit=False, bIsOnPose=False)
                self._addComboItemData(qMainItem, 'Ctrl Twist Axis','XYZ', sValueFromRig='XYZ'[iCtrlTwistAxis], sKey='iCtrlTwistAxis')
                self._addCheckBoxData(qMainItem, 'Joint Angle Factor', bValueFromRig=bJointAngleFactor, sKey='bJointAngleFactor', bIsOnPose=False)


            elif sInterpType == 'mayaPose':
                sJoint = cmds.getAttr('%s.sJoint' % sInterpTransform)
                sJointParent = cmds.getAttr('%s.sJointParent' % sInterpTransform)
                sCtrl = cmds.getAttr('%s.sCtrl' % sInterpTransform)
                self._addNodeItemData(qMainItem, 'Joint: ',  'joint', sValueFromRig=sJoint, sKey='sJoint')
                self._addNodeItemData(qMainItem, 'JointParent: ',  'joint', sValueFromRig=sJointParent, sKey='sJointParent')
                self._addNodeItemData(qMainItem, 'Ctrl: ', 'transform', sValueFromRig=sCtrl, sKey='sCtrl')


        elif sType == 'pose':
            sPoseName = qMainItem.text(0)
            qInterp = qMainItem.parent()

            qNameLayout = QtWidgets.QHBoxLayout()
            qName = QtWidgets.QLineEdit(sPoseName)
            def changedName(qName=qName, sOldName=sPoseName):
                sNewName = qName.text().strip()
                if sNewName:
                    sCurrentPoseNames = [qInterp.child(p).text(0) for p in range(qInterp.childCount())]
                    if sNewName in sCurrentPoseNames or cmds.attributeQuery(sNewName, node=sInterpTransform, exists=True) or sNewName in ['out']:
                        qName.blockSignals(True)
                        qName.setText(sOldName)
                        qName.blockSignals(False)
                        self.setStatusLine('A pose or attribute with the name of "%s" already exists in this interpolator' % sNewName)
                    else:
                        qMainItem.setText(0, sNewName)
                        dData = qMainItem.data(0, QtCore.Qt.UserRole)
                        dData['dChanges']['sName'] = sNewName
                        qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                        self.rebuildInterpolators([qMainItem.parent()])
                        # self.refreshInterpTreeFromScene()
                        # self.refreshAttributes(qMainItem)
                        self.refreshTargetsTreeFromScene()

            qName.editingFinished.connect(changedName)

            qNameLayout.addWidget(QtWidgets.QLabel('Name:'))
            qNameLayout.addWidget(qName)
            self.qInterpAttributesLayoutDynamic.addLayout(qNameLayout)

            sInterpTransform = self._transformFromInterpItem(qInterp)
            sInterpType = cmds.getAttr('%s.sInterpType' % sInterpTransform)
            # iPoseIndex = dData['iPoseIndex']
            iPoseIndex = qInterp.indexOfChild(qMainItem)
            if sInterpType == 'signedAngle':
                ffRanges = eval(cmds.getAttr('%s.ffRanges' % sInterpTransform))
                fRange = ffRanges[iPoseIndex] if iPoseIndex < len(ffRanges) else kConeRangeDefault
                self._addVectorData(qMainItem, '', ['min', 'max'], fRange, sKey='fRange')
                self._addComboItemLive('', kCurveTypes, '%s.%s_curveType' % (sInterpTransform, sPoseName))

            if sInterpType == 'attribute':
                ffRanges = eval(cmds.getAttr('%s.ffRanges' % sInterpTransform))
                fRange = ffRanges[iPoseIndex] if iPoseIndex < len(ffRanges) else kConeRangeDefault
                self._addVectorData(qMainItem, '', ['min', 'max'], fRange, sKey='fRange')
                self._addComboItemLive('', kCurveTypes, '%s.%s_curveType' % (sInterpTransform, sPoseName))

            if sInterpType == 'custom':
                xPoses = eval(cmds.getAttr('%s.xPoses' % sInterpTransform))
                fValues = xPoses[iPoseIndex][1:4]
                self._addVectorData(qMainItem, '', ['X'], [fValues[0]], sKey='fValueX')
                self._addVectorData(qMainItem, '', ['Y'], [fValues[1]], sKey='fValueY')
                self._addVectorData(qMainItem, '', ['Z'], [fValues[2]], sKey='fValueZ')
                self._addComboItemLive('', kCurveTypes, '%s.%s_curveType' % (sInterpTransform, sPoseName))

            elif sInterpType == 'cone':
                sConeTransform = '%s_%s_cone' % (sInterpTransform, sPoseName)

                bJointAngleFactor = bool(utils.getAttrIfExists('%s.bJointAngleFactor' % sInterpTransform, 0.0))
                if bJointAngleFactor:
                    self._addVectorData(qMainItem, 'Rotation', ['', '', ''], cmds.getAttr('%s.r' % sConeTransform)[0], sKey='fRotation')
                else:
                    self._addVectorLive(qMainItem, 'Rotation (live)', ['', '', ''], ['%s.rx' % sConeTransform, '%s.ry' % sConeTransform, '%s.rz' % sConeTransform])
                self._addComboItemLive( '', kCurveTypes,  '%s.curveType' % sConeTransform)
                if bJointAngleFactor:
                    self._addVectorData(qMainItem, 'Range (angle diff):', ['start', 'end'], [cmds.getAttr('%s.startAngle' % sConeTransform), cmds.getAttr('%s.endAngle' % sConeTransform)], bGoToPoseOnEdit=[False, True], sKey='fInnerOuterRange')
                else:
                    self._addVectorLive(qMainItem, 'Range (angle diff, live):', ['start', 'end'], ['%s.startAngle' % sConeTransform, '%s.endAngle' % sConeTransform], bGoToPoseOnEdit=[False, True])


                self._addCheckBoxData(qMainItem, 'Reverse ', bValueFromRig=bool(utils.getAttrIfExists('%s.bReverse' % sConeTransform, 0.0)), sKey='bReverse')

            elif sInterpType == 'mayaPose':
                xxPoses = eval(cmds.getAttr('%s.xPoses' % sInterpTransform))
                bRevs = eval(cmds.getAttr('%s.bRevs' % sInterpTransform))
                print ('bRevs: ', bRevs)
                print ('iPoseIndex: ', iPoseIndex)
                fRotation = xxPoses[iPoseIndex][1:4] if iPoseIndex < len(xxPoses) else k3dPoseDefault
                bReverse = bRevs[iPoseIndex]
                self._addVectorData(qMainItem, 'Rotation', ['', '', ''], fRotation, sKey='fRotation')
                self._addCheckBoxData(qMainItem, 'Reverse ', bValueFromRig=bReverse, sKey='bReverse')

            elif sInterpType == 'upleg':
                xxPoses = eval(cmds.getAttr('%s.xPoses' % sInterpTransform))
                fRotation = xxPoses[iPoseIndex][1] if iPoseIndex < len(xxPoses) else 90.0
                self._addVectorLive(qMainItem, 'knee start:', ['start'], ['%s.kneeStart_%s' % (sInterpTransform, sPoseName)], bGoToPoseOnEdit=False)
                self._addVectorLive(qMainItem, 'turn off on in:', [''], ['%s.turnOffOnIn_%s' % (sInterpTransform, sPoseName)], bGoToPoseOnEdit=False)
                self._addVectorData(qMainItem, '', ['Rotate X'], [fRotation], sKey='fRotation', bGoToPoseOnEdit=True)
                self._addCheckBoxLive( 'Reverse', '%s.reverse_%s' % (sInterpTransform, sPoseName))

        self.qInterpAttributesLayoutDynamic.addStretch()
        # self.updateRebuildNeeded(qMainItem)


    def defaultPoseolatorMenu(self):
        goToDefaultPose()

    def addInterpolatorMenu(self):
        qMenu = QtWidgets.QMenu()
        dInfos = {}
        dInfos['signedAngle'] = 'Select Attribute of Ctrl and Joint'
        dInfos['cone'] = 'Select Ctrl and Joint'
        dInfos['mayaPose'] = 'Select Ctrl and Joint'
        dInfos['upleg'] = 'No Selection needed'
        dInfos['custom'] = 'Select Attributes (one, two or three) in Channel Box'
        # dInfos['attribute'] = 'DEPRICATED - Select Attribute in Channel Box - DEPRICATED'
        for sInterpType in kInterpTypes:
            def _addInterp(sInterpType=sInterpType):
                self.createNewInterpolator(sInterpType = sInterpType)
            qMenu.addAction('%s \t\t %s' % (sInterpType, dInfos[sInterpType]), _addInterp)
        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())




    def _addVectorData(self, qMainItem, sLabel, sAttributes, fValuesFromRig, sKey='', bGoToPoseOnEdit=True, bIsOnPose=True):
        if len(sAttributes) != len(fValuesFromRig):
            raise Exception('sAttributes and fValuesFromRig need same length')

        qHorizLayout = QtWidgets.QHBoxLayout()
        qHorizLayout.addWidget(QtWidgets.QLabel(sLabel))

        dChanges = qMainItem.data(0, QtCore.Qt.UserRole)['dChanges']
        fDataValues = dChanges.get(sKey, [])

        qFields = []
        for a,sA in enumerate(sAttributes):
            qHorizLayout.addWidget(QtWidgets.QLabel(sA))
            fValue = fDataValues[a] if fDataValues else fValuesFromRig[a]
            qTextField = QtWidgets.QLineEdit(str(round(fValue,2)))
            qTextField.setMaximumWidth(100)
            qHorizLayout.addWidget(qTextField)
            qFields.append(qTextField)


        for i, qTextField in enumerate(qFields):

            def updateData(i=i, qFields=qFields, sKey=sKey, bGoToPoseOnEdit=bGoToPoseOnEdit, bIsOnPose=bIsOnPose):
                cmds.undoInfo(openChunk=True)
                try:
                    utils.registerRedoAndUndo(funcUndo=self.refreshAttributes)

                    fValues = [float(qTextField.text()) for qTextField in qFields]
                    dData = qMainItem.data(0, QtCore.Qt.UserRole)
                    dData['dChanges'][sKey] = fValues
                    qMainItem.setData(0, QtCore.Qt.UserRole, dData)

                    if bIsOnPose:
                        qInterp = qMainItem.parent()
                    else:
                        qInterp = qMainItem
                    self.rebuildInterpolators([qInterp])
                    sInterp = self._transformFromInterpItem(qInterp)

                    sPose = qMainItem.text(0)
                    if isinstance(bGoToPoseOnEdit, (list,tuple)):
                        if bGoToPoseOnEdit[i]:
                            self.poseTo(['%s.%s' % (sInterp, sPose)])
                    elif bGoToPoseOnEdit:
                        self.poseTo(['%s.%s' % (sInterp, sPose)])

                except Exception as e:
                    cmds.confirmDialog(m=str(e))
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            qTextField.editingFinished.connect(updateData)

        qHorizLayout.addStretch()
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)


    def _addVectorLive(self, qMainItem, sLabel, sAttributes, sAttrsFromRig, bGoToPoseOnEdit=True):
        if not cmds.objExists(sAttrsFromRig[0]): # rebuild might be needed
            return

        if len(sAttributes) != len(sAttrsFromRig):
            raise Exception('sAttributes and fValuesFromRig need same length')

        qHorizLayout = QtWidgets.QHBoxLayout()
        qHorizLayout.addWidget(QtWidgets.QLabel(sLabel))

        qFields = []
        for a,sA in enumerate(sAttributes):
            qHorizLayout.addWidget(QtWidgets.QLabel(sA))
            fValue = cmds.getAttr(sAttrsFromRig[a])
            qTextField = QtWidgets.QLineEdit(str(round(fValue,2)))
            qTextField.setMaximumWidth(100)
            qHorizLayout.addWidget(qTextField)
            qFields.append(qTextField)

        for i, qTextField in enumerate(qFields):
            def updateRig(i=i, qFields=qFields, sAttrsFromRig=sAttrsFromRig, bGoToPoseOnEdit=bGoToPoseOnEdit):
                cmds.undoInfo(openChunk=True)
                try:
                    utils.registerRedoAndUndo(funcUndo=self.refreshAttributes)

                    for qTextField, sAttrFromRig in zip(qFields, sAttrsFromRig):
                        fValue = float(qTextField.text())
                        cmds.setAttr(sAttrFromRig, fValue)

                    qInterp = qMainItem.parent()
                    sInterp = self._transformFromInterpItem(qInterp)
                    sPose = qMainItem.text(0)
                    if isinstance(bGoToPoseOnEdit, (list,tuple)):
                        if bGoToPoseOnEdit[i]:
                            self.poseTo(['%s.%s' % (sInterp, sPose)])
                    elif bGoToPoseOnEdit:
                        self.poseTo(['%s.%s' % (sInterp, sPose)])

                except Exception as e:
                    cmds.confirmDialog(m=str(e))
                    raise
                finally:
                    cmds.undoInfo(closeChunk=True)

            qTextField.editingFinished.connect(updateRig)

        qHorizLayout.addStretch()
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)


    def _addComboItemData(self, qMainItem, sLabel, sEntries, sValueFromRig, sKey=None):
        dChanges = qMainItem.data(0, QtCore.Qt.UserRole).get('dChanges', {})
        qHorizLayout = QtWidgets.QHBoxLayout()

        dPoseTypeCombo = QtWidgets.QComboBox()
        [dPoseTypeCombo.addItem(sT) for sT in sEntries]

        if sKey.startswith('s'): # string
            dPoseTypeCombo.setCurrentText(dChanges.get(sKey, sValueFromRig))
            def updateData(iIndex, sEntries=sEntries, sKey=sKey):
                dData = qMainItem.data(0, QtCore.Qt.UserRole)
                dData['dChanges'][sKey] = sEntries[iIndex]
                qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                # self.updateRebuildNeeded(qMainItem)
                self.rebuildInterpolators([qMainItem])
        else: # numeric
            dPoseTypeCombo.setCurrentIndex(dChanges.get(sKey, sEntries.index(sValueFromRig)))
            def updateData(iIndex, sEntries=sEntries, sKey=sKey):
                dData = qMainItem.data(0, QtCore.Qt.UserRole)
                dData['dChanges'][sKey] = iIndex
                qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                # self.updateRebuildNeeded(qMainItem)
                self.rebuildInterpolators([qMainItem])
        dPoseTypeCombo.currentIndexChanged.connect(updateData)


        qHorizLayout.addWidget(QtWidgets.QLabel(sLabel))
        qHorizLayout.addWidget(dPoseTypeCombo)
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)


    def _addComboItemLive(self, sLabel, sEntries, sAttrFromRig):
        if not cmds.objExists(sAttrFromRig): # rebuild might be needed
            return
        qHorizLayout = QtWidgets.QHBoxLayout()

        dPoseTypeCombo = QtWidgets.QComboBox()
        [dPoseTypeCombo.addItem(sT) for sT in sEntries]

        dPoseTypeCombo.setCurrentIndex(cmds.getAttr(sAttrFromRig))
        def updateAttr(iIndex, sAttrFromRig=sAttrFromRig):
            cmds.setAttr(sAttrFromRig, iIndex)
        dPoseTypeCombo.currentIndexChanged.connect(updateAttr)


        qHorizLayout.addWidget(QtWidgets.QLabel(sLabel))
        qHorizLayout.addWidget(dPoseTypeCombo)
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)


    def _addNodeItemData(self, qMainItem, sLabel, sMayaType=None, sValueFromRig='', sKey='', bIsAttribute=False):
        dChanges = qMainItem.data(0, QtCore.Qt.UserRole).get('dChanges', {})
        qHorizLayout = QtWidgets.QHBoxLayout()

        qTextField = QtWidgets.QLineEdit()

        if sKey in dChanges:
            qTextField.setText(dChanges[sKey])
        else:
            qTextField.setText(sValueFromRig)

        def updateData(qMainItem=qMainItem, qTextField=qTextField, sValueFromRig=sValueFromRig):
            sNewText = qTextField.text().strip()
            dData = qMainItem.data(0, QtCore.Qt.UserRole)
            if sNewText != sValueFromRig:
                dData['dChanges'][sKey] = sNewText
                qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                # self.updateRebuildNeeded(qMainItem)
                self.rebuildInterpolators([qMainItem])

            elif sKey in dData['dChanges']: # it's the same as the default. In case key already exists, let's delete it
                del dData['dChanges'][sKey]
                qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                self.rebuildInterpolators([qMainItem])

        qTextField.editingFinished.connect(updateData)

        if bIsAttribute:
            qSetButton = QtWidgets.QPushButton('Sel. Attr')
        else:
            qSetButton = QtWidgets.QPushButton('Selected')

        def setField(_=None, qTextField=qTextField, sMayaType=sMayaType, bIsAttribute=bIsAttribute):
            if sMayaType:
                sSelected = cmds.ls(sl=True, et=sMayaType)
            else:
                sSelected = cmds.ls(sl=True)
            if sSelected:
                sObj = sSelected[0]
                if bIsAttribute:
                    sSelectedAttributes = utils.getSelectedChannelBoxAttributes()
                    if sSelectedAttributes:
                        sObj = '%s.%s' % (sObj, sSelectedAttributes[0])
                    else:
                        raise Exception('You need to select an attribute in the Channel Box')
                qTextField.setText(sObj)
                updateData()

        qSetButton.clicked.connect(setField)
        qHorizLayout.addWidget(QtWidgets.QLabel(sLabel))
        qHorizLayout.addWidget(qTextField)
        qHorizLayout.addWidget(qSetButton)
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)

    def _addCheckBoxData(self, qMainItem, sLabel, bValueFromRig=False, sKey='', bIsOnPose=True):
        dChanges = qMainItem.data(0, QtCore.Qt.UserRole).get('dChanges', {})
        qHorizLayout = QtWidgets.QHBoxLayout()

        qCheckBox = QtWidgets.QCheckBox(sLabel)

        if sKey in dChanges:
            qCheckBox.setChecked(dChanges[sKey])
        else:
            qCheckBox.setChecked(bValueFromRig)

        def updateData(_, qMainItem=qMainItem, qCheckBox=qCheckBox, bValueFromRig=bValueFromRig):
            bNewChecked = qCheckBox.isChecked()
            dData = qMainItem.data(0, QtCore.Qt.UserRole)
            if bNewChecked != bValueFromRig:
                dData['dChanges'][sKey] = bNewChecked
                qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                if bIsOnPose:
                    qInterp = qMainItem.parent()
                else:
                    qInterp = qMainItem
                self.rebuildInterpolators([qInterp])

            elif sKey in dData['dChanges']: # it's the same as the default. In case key already exists, let's delete it
                del dData['dChanges'][sKey]
                qMainItem.setData(0, QtCore.Qt.UserRole, dData)
                qInterp = qMainItem.parent()
                self.rebuildInterpolators([qInterp])

        qCheckBox.stateChanged.connect(updateData)

        qHorizLayout.addWidget(qCheckBox)
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)


    def _addCheckBoxLive(self, sLabel, sAttrFromRig):
        if not cmds.objExists(sAttrFromRig):  # rebuild might be needed
            return
        qHorizLayout = QtWidgets.QHBoxLayout()

        qCheckBox = QtWidgets.QCheckBox(sLabel)
        qCheckBox.setChecked(cmds.getAttr(sAttrFromRig))

        def updateAttr(qCheckedState, sAttrFromRig=sAttrFromRig):
            print ('qCheckedState: ', qCheckedState)
            cmds.setAttr(sAttrFromRig, True if qCheckedState else False)

        qCheckBox.stateChanged.connect(updateAttr)

        qHorizLayout.addWidget(QtWidgets.QLabel(sLabel))
        qHorizLayout.addWidget(qCheckBox)
        self.qInterpAttributesLayoutDynamic.addLayout(qHorizLayout)


    def _transformFromInterpItem(self, qItem):
        return qItem.text(0).split(' ')[0].strip()

    def _targetNameFromTargetItem(self, qTarget):
        qTargetWidget = self.qTargetsTree.itemWidget(qTarget, 0)
        return qTargetWidget.qName.getName()


    def _findInterpItemFromName(self, sInterp):
        for iInterp in range(self.qMainTree.invisibleRootItem().childCount()):
            qInterp = self.qMainTree.invisibleRootItem().child(iInterp)
            if self._transformFromInterpItem(qInterp) == sInterp:
                return qInterp

    def _findPoseItemFromName(self, qInterp, sPoseName):
        for iPose in range(qInterp.childCount()):
            qPose = qInterp.child(iPose)
            if qPose.text(0) == sPoseName:
                return qPose


    def setMirrorTableMiddleMeshes(self, qMeshes, sType='I'):
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshMeshesTreeFromScene)

            utils.reload2(tools)
            sMeshes = []
            for qMesh in qMeshes:
                sMeshes.append(qMesh.text(0).split(' ')[0])
            tools.setMirrorTableMiddleMeshes(sMeshes, sType)

            utils.registerRedoAndUndo(funcRedo=self.refreshMeshesTreeFromScene)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def setMirrorTableSideMeshes(self, qMeshes, sType='I'):  # iType: I=ids, V=vertex, F=faces
        try:
            cmds.undoInfo(openChunk=True)
            utils.registerRedoAndUndo(funcUndo=self.refreshMeshesTreeFromScene)

            utils.reload2(tools)
            sMeshes = []
            for qMesh in qMeshes:
                sMeshes.append(qMesh.text(0).split(' ')[0])
            tools.setMirrorTableSideMeshes(sMeshes, sType)

            utils.registerRedoAndUndo(funcRedo=self.refreshMeshesTreeFromScene)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def _getAllCtrlsInScene(self, bCheckAllTransformsAndJoints=True):
        if bCheckAllTransformsAndJoints:
            sAllCtrls = [sNode for sNode in cmds.ls(et='transform') + cmds.ls(et='joint')
                         if cmds.attributeQuery('poseEditor', node=sNode, exists=True)]
            self.__sSavedAllCtrls.clear()
            self.__sSavedAllCtrls.extend(sAllCtrls)
            return sorted(sAllCtrls)
        else:
            sAllCtrls = set([sNode for sNode in self.__sSavedAllCtrls if cmds.attributeQuery('poseEditor', node=sNode, exists=True)])
            return sorted(sAllCtrls)







_poseEditor = None
def showUi():
    utils.reload2(interpolator)
    global _poseEditor
    _poseEditor = QPoseEditorUi()
    _poseEditor.show()


def moveConnectionsAndDelete(sTempInterpTransform, dChangedPoseNames={}):

    print ('\n\n ====== moveConnectionsAndDelete (%s)' % moveConnectionsAndDelete)
    sOld = sTempInterpTransform.replace(kTempString, '')
    if cmds.objExists(sOld):
        # connections going into the interpTransform (only disconnecting them to not have important stuff auto deleted on removing the old interpolator):
        #
        sSourceConnections = cmds.listConnections(sOld, s=True, d=False, p=True, c=True)
        for i in range(0, len(sSourceConnections), 2):
            cmds.disconnectAttr(sSourceConnections[i + 1], sSourceConnections[i])

        # connections going from the interpTransform (mainly output poses):
        sDestConnections = cmds.listConnections(sOld, s=False, d=True, p=True, c=True) or []
        for i in range(0, len(sDestConnections), 2):
            if sDestConnections[i].endswith('.coneVis') or sDestConnections[i].endswith('.coneScale'):
                continue
            cmds.disconnectAttr(sDestConnections[i], sDestConnections[i+1])
            sPlugOnNew = sDestConnections[i].replace('%s.' % sOld, '%s.' % sTempInterpTransform)
            for sOldPoseName, sNewPoseName in dChangedPoseNames.items():
                sPlugOnNew = sPlugOnNew.replace('.%s' % sOldPoseName, '.%s' % sNewPoseName)

            if cmds.objExists(sPlugOnNew): # wouldn't exist if poses got removed
                cmds.connectAttr(sPlugOnNew, sDestConnections[i+1])

        cmds.delete(sOld)

    sInterpTransform = cmds.rename(sTempInterpTransform, sOld)

    # if it's cones, also rename the cone transforms
    for sCone in cmds.listRelatives(sInterpTransform, c=True, typ='transform') or []:
        cmds.rename(sCone, sCone.replace(kTempString, ''))

    dChangedPoseOutputs = {'%s.%s' % (sInterpTransform, sPoseName):'%s.%s' % (sInterpTransform, sNewPoseName) for sPoseName,sNewPoseName in dChangedPoseNames.items()}
    sTargetMultipls = cmds.ls('%s__*' % kTargetArrayMultipl)
    for sTargetMultipl in sTargetMultipls:
        sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetMultipl))
        for p in range(len(sPoseOutputs)):
            sPoseOutputs[p] = dChangedPoseOutputs.get(sPoseOutputs[p], sPoseOutputs[p])
        cmds.setAttr('%s.sPoseOutputs' % sTargetMultipl, str(sPoseOutputs), type='string')


def getJointFromSel():
    for sObj in cmds.ls(sl=True):
        if cmds.objectType(sObj) == 'joint' and not sObj.endswith('_ctrl'):
            return sObj

def getCtrlFromSel():
    for sObj in cmds.ls(sl=True):
        if sObj.endswith('_ctrl'):
            return sObj



def switchAllToFk(bAsk=False):
    sSwitchAttrs = []
    for sCtrl in cmds.ls('*Global*_ctrl'):
        sSwitchAttr = '%s.fk2ik' % sCtrl
        if cmds.objExists(sSwitchAttr):
            if cmds.getAttr(sSwitchAttr) != 0.0:
                sSwitchAttrs.append(sSwitchAttr)

    if sSwitchAttrs:
        if not bAsk or cmds.confirmDialog(m='set those to FK? \n%s' % ', '.join(sSwitchAttrs), button=['yes', 'no']) == 'yes':
            [cmds.setAttr(sAttr, 0.0) for sAttr in sSwitchAttrs]


def setRotationKeyframe(sNode, fRotation, iTime):
    for a, sA in enumerate(['rx', 'ry', 'rz']):
        try:
            cmds.setKeyframe('%s.%s' % (sNode, sA), v=fRotation[a], t=iTime)
        except:
            pass







class QTargetWidget(QtWidgets.QWidget):
    sliderPressed = QtCore.Signal(str, object)
    sliderValueChanged = QtCore.Signal(str, object, float)
    sliderReleased = QtCore.Signal(str, object)
    editClicked = QtCore.Signal(str, bool, object)
    targetNameChanged = QtCore.Signal(str, str, object)
    postChanged = QtCore.Signal(str, bool)
    comboModeChanged = QtCore.Signal(str, str)
    def __init__(self, sName, qTargetsTree, bPost, sMode):
        QtWidgets.QWidget.__init__(self)

        self.iSelectOrder = None

        self.qTargetsTree = qTargetsTree
        layout = QtWidgets.QHBoxLayout(self.qTargetsTree)
        layout.setContentsMargins(0, 0, 0, 0)
        self.bDontRunSetValueOnOthers = False

        self.qParent = self.qTargetsTree


        # self.qKeyButton = QtWidgets.QPushButton('K')
        # self.qKeyButton.setMaximumWidth(50)
        # self.qKeyButton.clicked.connect(self.keyButtonClicked)

        self.qSlider = QNoWheelSlider(self.qTargetsTree)
        # self.qSlider.setMaximumWidth(200)
        self.qSlider.setMinimum(0)
        self.qSlider.setMaximum(100)
        self.qName = QEditLabel(sName, qTreeWidget=self.qTargetsTree)
        self.qName.userChangedText.connect(self._targetNameChanged)

        self.qComboButton = QtWidgets.QPushButton(sMode)
        self.qComboButton.setMinimumWidth(30)
        self.qComboButton.setMaximumWidth(30)
        self.qComboButton.clicked.connect(self.comboButtonClicked)

        self.qEditButton = QtWidgets.QPushButton('EDIT MESH')
        self.qEditButton.setMinimumWidth(300)
        self.qEditButton.setMaximumWidth(300)
        self.qEditButton.setMinimumHeight(_ButtonHeight)
        self.qEditButton.setMaximumHeight(_ButtonHeight)
        self.qEditButton.setCheckable(True)
        sRed = '#ea4963'
        self.qEditButton.setStyleSheet('QPushButton:checked{background-color: %s; border: none}' % sRed)
        self.qEditButton.clicked.connect(self._editClicked)


        # Post Checkbox turned out too difficult. For now it's just hidden
        self.qPostCheckbox = QtWidgets.QCheckBox('Post')
        self.qPostCheckbox.stateChanged.connect(self._postChanged)
        self.qPostCheckbox.setChecked(True if bPost else False)
        self.qPostCheckbox.setHidden(True)
        # layout.addWidget(self.qKeyButton)
        layout.addWidget(self.qSlider)
        layout.addWidget(self.qName)

        layout.addWidget(self.qPostCheckbox)
        layout.addWidget(self.qComboButton)
        layout.addWidget(self.qEditButton)

        self.setLayout(layout)
        self.bSliderPressed = False

        self.bFiltered = True
        self.bIsolated = True


        self.bSliderIsPressed = False
        fValue = 0.0
        self.qSlider.setValue(int(fValue*100))
        self.qSlider.sliderPressed.connect(self._sliderPressed)
        self.qSlider.valueChanged.connect(self._sliderValueChanged)
        self.qSlider.sliderReleased.connect(self._sliderReleased)

        self.iMoveRowsTogether = []


    def comboButtonClicked(self):
        qMenu = QtWidgets.QMenu()
        def _changeCombo(sMode):
            self.qComboButton.setText(sMode)
            self.comboModeChanged.emit(self.qName.getName(), sMode)
        qMenu.addAction('Multiply', lambda: _changeCombo('M'))
        qMenu.addAction('Smallest', lambda: _changeCombo('S'))
        # qMenu.addAction('Biggest', lambda: _changeCombo('B'))

        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())



    def _sliderValueChanged(self, iValue):
        if self.bSliderIsPressed: # this is because of qt weirdness that it calls sliderValueChanged before pressed
            self.sliderValueChanged.emit(self.qName.getName(), self, iValue)

    def _sliderPressed(self):
        self.sliderPressed.emit(self.qName.getName(), self)
        self.bSliderIsPressed = True
        self.sliderValueChanged.emit(self.qName.getName(), self, self.qSlider.value()) # this is for cases when we just click but not actually drag it

    def _sliderReleased(self):
        self.sliderReleased.emit(self.qName.getName(), self)
        self.bSliderIsPressed = False


    def _editClicked(self):
        bIsChecked = self.qEditButton.isChecked()
        self.editClicked.emit(self.qName.getName(), bIsChecked, self.qEditButton)

    def _postChanged(self, qCheckState):
        self.postChanged.emit(self.qName.getName(), qCheckState)

    def _targetNameChanged(self, sTarget, sNewTarget):
        self.targetNameChanged.emit(sTarget, sNewTarget, self)


    def resetEditButton(self):
        if self.qEditButton.isChecked():
            self.qEditButton.setChecked(False)
            self.editClicked()

    def isEnabled(self):
        if not utils.isNone(self.qEnabledCheckBox):
            return self.qEnabledCheckBox.isChecked()
        else:
            return True




class QNoWheelSlider(QtWidgets.QSlider):
    def __init__(self, parent=None):
        QtWidgets.QSlider.__init__(self, QtCore.Qt.Horizontal, parent=parent)
        self.parent = parent
        # self.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)

    def wheelEvent(self, *args, **kwargs):
        return self.parent.wheelEvent(*args, **kwargs)



class QEditLabel(QtWidgets.QWidget):
    userChangedText = QtCore.Signal(object, object)
    def __init__(self, sText, qTreeWidget):
        self.qTargetsTreeWidget = qTreeWidget
        QtWidgets.QWidget.__init__(self)
        qLayout = QtWidgets.QHBoxLayout()
        self.setLayout(qLayout)

        self.qLabel = QDoubleClickLabel(sText)
        self.qLine = QFocusCheckLineEdit()
        self.qLabel.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.qLine.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.qLine.setHidden(True)
        qLayout.addWidget(self.qLine)
        self.qLabel.clickedTwice.connect(self.showLineEdit)
        self.qLine.finishedSettingText.connect(self.showLabel)
        self.qTargetsTreeWidget.itemSelectionChanged.connect(self.showLabel)
        # self.sBlendShape = sBlendShape

        qLayout.addWidget(self.qLabel)


    def setFont(self, qFont):
        self.qLabel.setFont(qFont)


    def showLineEdit(self):
        self.qLabel.setHidden(True)
        self.qLine.setText(self.getName())
        self.qLine.setHidden(False)
        self.qLine.setSelection(0, len(self.qLine.text()))
        self.qLine.setFocus()


    def showLabel(self):
        if not self.qLine.isHidden():
            self.qLine.setHidden(True)
            sNewName = self.qLine.text()
            sPreviousName = self.getName()
            self.qLabel.setHidden(False)
            if sNewName != sPreviousName:
                self.qLabel.setText(sNewName)
                self.userChangedText.emit(sPreviousName, sNewName)


    def setText(self, sText):
        if self.qLine != None:
            self.qLine.setText(sText)
        self.qLabel.setText(sText)


    def setName(self, sName):
        self.qName.setText(self._getTextString(sName,self.fPerc))


    def text(self):
        return self.qLabel.text()

    def getName(self):
        return self.text().split(' ')[0]


    def _getTextString(self, sName, fPerc):
        return '%s (%d %%)' % (sName, round(fPerc * 100.0, 0))


    def updatePerc(self, fPerc=0.0):
        self.fPerc = fPerc
        if not self.qLabel.isHidden():
            self.setText(self._getTextString(self.getName(), fPerc))


class QDoubleClickLabel(QtWidgets.QLabel):
    clickedTwice = QtCore.Signal()
    def mouseDoubleClickEvent(self, *args, **kwargs):
        self.clickedTwice.emit()



class QFocusCheckLineEdit(QtWidgets.QLineEdit):
    finishedSettingText = QtCore.Signal()
    def focusOutEvent(self, *args, **kwargs):
        self.finishedSettingText.emit()
    def keyPressEvent(self, event):
        key = event.key()
        if key == QtCore.Qt.Key_Enter or key == 16777220:
            self.finishedSettingText.emit()
        else:
            QtWidgets.QLineEdit.keyPressEvent(self, event)





def _getBlendShapes():
    return  sorted([sBlendShape for sBlendShape in cmds.ls(et='blendShape') if cmds.attributeQuery(kIsPoseEditorBlendShapeAttr, node=sBlendShape, exists=True)])



def _getTransformFromCtrl(sCtrl):
    sOffset = ctrls8.ctrlFromName(sCtrl).getOffsetByName('poseeditor', bReturnNoneIfNotExists=True)
    if sOffset == None:
        cCtrl = ctrls8.ctrlFromName(sCtrl)
        sOffset = cCtrl.appendOffsetGroup('poseeditor')
    return sOffset


def _getCtrlFromTransform(sTransform):
    if sTransform.lower().endswith('poseEditor'):
        sCtrlNodes = [sNode for sNode in cmds.listRelatives(sTransform, c=True, ad=True) if sNode.endswith('_ctrl')]
        return sorted(sCtrlNodes, key=lambda x: len(x))[0]
    else:
        return sTransform


def getPoseLoc(sCtrl, sTarget):
    sPoseLoc = f'_poseLocEditor__{sCtrl}__{sTarget}'

    if not cmds.objExists(sPoseLoc):
        sTransform = _getTransformFromCtrl(sCtrl)
        sPoseLoc = xforms.createLocator(sPoseLoc, sParent=cmds.listRelatives(sTransform, p=True)[0])#, sMatch=sTransform)
        utils.connectPosesLocVis(sPoseLoc)
        # cmds.connectAttr('%s.posesLocVIS' % utils.getMasterName(), '%s.v' % sPoseLoc)
    return sPoseLoc


def getWeightMultiplName(sCtrl, sTarget, sA):
    return f'WEIGHT__{sCtrl}__{sTarget}__{sA}'


def disconnectPoseLoc(sCtrl, sTarget):
    for a,sA in enumerate('trs'):
        # sCtrl = _getCtrlFromTransform(sTransform)
        sMultipl = getWeightMultiplName(sCtrl, sTarget, sA)

        if cmds.objExists(sMultipl):
            sConnections = cmds.listConnections('%s.output' % sMultipl, s=False, d=True, p=True)[0]
            cmds.disconnectAttr('%s.output' % sMultipl, sConnections)
            cmds.setAttr(sConnections, 0,0,0)
            nodes.deleteConnectionsAndItself3(sMultipl)


def reconnectPoseLoc(sCtrl, sTarget):
    # sTargetArrayMultiplName = getTargetArrayMultiplName(sTarget)
    sLocs = _createAndConnectWeightMultipls(sCtrl, sTarget)
    return sLocs



def _getScaleShrink(sPoseLoc):
    sScaleShrinkNode = '%s_scaleShrinkNode' % sPoseLoc
    if not cmds.objExists(sScaleShrinkNode):
        nodes.createVectorAdditionNode(['%s.s' % sPoseLoc, [-1, -1, -1]], sFullName=sScaleShrinkNode)
    return '%s.output3D' % sScaleShrinkNode


def _createAndConnectWeightMultipls(sCtrl, sTarget):
    # sCtrl = _getCtrlFromTransform(sTransform)
    sLocs = []
    if not cmds.objExists(getWeightMultiplName(sCtrl, sTarget, 't')):

        sTargetMultipl = getComboOutput(getTargetArrayMultiplName(sTarget))
        for sA in 'trs':
            sPoseLoc = getPoseLoc(sCtrl, sTarget)
            sLocs.append(sPoseLoc)
            sPoseLocOutA = _getScaleShrink(sPoseLoc) if sA == 's' else '%s.%s' % (sPoseLoc, sA)
            sMultipl = nodes.createVectorMultiplyNode(sPoseLocOutA, sTargetMultipl, bVectorByScalar=True,
                                                      sFullName=getWeightMultiplName(sCtrl, sTarget, sA))

            sTransform = _getTransformFromCtrl(sCtrl)
            sAdditionNode = cmds.listConnections('%s.%s' % (sTransform, sA), s=True, d=False, skipConversionNodes=True)[0]
            if cmds.objectType(sAdditionNode) == 'blendColors':
                sAdditionNode = cmds.listConnections('%s.color1' % sAdditionNode, s=True, d=False, skipConversionNodes=True)[0]

            iIndexFromAttr = _getNextPoseIndex(sTransform)
            cmds.connectAttr(sMultipl, '%s.input3D[%d]' % (sAdditionNode, iIndexFromAttr + 1 if sA == 's' else iIndexFromAttr))
            if sA == 't':
                cmds.connectAttr(sTargetMultipl, '%s.v' % sPoseLoc, f=True)
        _incrementNextPoseIndex(sTransform)

    return sLocs


def _getNextPoseIndex(sTransform):
    sAttr = '%s.%s' % (sTransform, kPoseEditorNextIndexAttr)
    if not cmds.objExists(sAttr):
        utils.addAttr(sTransform, ln=kPoseEditorNextIndexAttr, at='long', dv=0, k=True, bReturnIfExists=True)
    return cmds.getAttr(sAttr)


def _incrementNextPoseIndex(sTransform):
    sAttr = '%s.%s' % (sTransform, kPoseEditorNextIndexAttr)
    cmds.setAttr(sAttr, cmds.getAttr(sAttr) + 1)


def addTargetPosesToCtrl(sCtrl, sTarget):
    # sCtrl = _getCtrlFromTransform(sTransform)

    sPoseLoc = getPoseLoc(sCtrl, sTarget)

    for a,sA in enumerate('trs'):
        sPoseLocOutA = _getScaleShrink(sPoseLoc) if sA == 's' else '%s.%s' % (sPoseLoc, sA)

    _createAndConnectWeightMultipls(sCtrl, sTarget)





def createCtrlPosesSetup(sCtrl, sTargets):
    for a,sA in enumerate('trs'):
        sTransform = _getTransformFromCtrl(sCtrl)
        sAttr = '%s.%s' % (sTransform, sA)
        if not cmds.listConnections(sAttr, s=True, d=False):
            nodes.createVectorAdditionNode([[1,1,1]] if sA == 's' else [], sTarget=sAttr, bForce=True)

    for sTarget in sTargets:
        addTargetPosesToCtrl(sCtrl, sTarget)



def getPoseValues(sInterp, sPose, bAlsoReturnAttrs=False):
    sInterpType = cmds.getAttr('%s.sInterpType' % sInterp)
    if bAlsoReturnAttrs:
        sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)

    if sInterpType == 'cone':
        sConeTransform = '%s_%s_cone' % (sInterp, sPose)
        fRotation = cmds.getAttr('%s.r' % sConeTransform)[0]
        fEndAngle = cmds.getAttr('%s.endAngle' % sConeTransform)

        fFullRotationAngle = cmds.getAttr('%s.fullRotationAngle' % sConeTransform)
        if abs(fFullRotationAngle) < 0.00001 :
            cmds.warning('rotation angle is 0, it could mean that all ctrl values are 0, or you are twisting along the twist axis')
            fFactor = 0.0
        else:
            fFactor = (fFullRotationAngle - fEndAngle) / fFullRotationAngle
        fReturnRotation = [fRotation[0] * fFactor, fRotation[1] * fFactor, fRotation[2] * fFactor]

        if bAlsoReturnAttrs:
            return [('%s.rx' % sCtrl, fReturnRotation[0]), ('%s.ry' % sCtrl, fReturnRotation[1]), ('%s.rz' % sCtrl, fReturnRotation[2])]
        else:
            return fReturnRotation

    elif sInterpType != '':
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))

        iPose = None
        for p,xPose in enumerate(xPoses):
            if xPose[0] == sPose:
                iPose = p
        if utils.isNone(iPose):
            raise Exception('pose "%s" not found in interpolator "%s"' % (sPose, sInterp))

        fReturnRotation = xPoses[iPose][1], xPoses[iPose][2], xPoses[iPose][3]
        if bAlsoReturnAttrs:
            sPoseAttrs = eval(cmds.getAttr('%s.sPoseAttrs' % sInterp))
            sPoseAttrs = [(sA if '.' in sA else '%s.%s' % (sCtrl, sA)) for sA in sPoseAttrs]
            return zip(sPoseAttrs, fReturnRotation)
        else:
            return fReturnRotation





class QSetObject(object):
    def build(self, qLayout, sLabel, sAttr, bIsIndex=False, bIsNamespace=False):

        self.qTopLayout = QtWidgets.QVBoxLayout()
        self.qNamespaceLayout = QtWidgets.QHBoxLayout()
        self.qTopLayout.addLayout(self.qNamespaceLayout)
        self.qLine = QtWidgets.QLineEdit('')
        self.qNamespaceLayout.addWidget(QtWidgets.QLabel(sLabel))
        self.qNamespaceLayout.addWidget(self.qLine)
        self.qLine.setEnabled(False)


        self.iClearScriptJob = None

        self.sAttr = sAttr
        self.bIsIndex = bIsIndex
        self.bIsNamespace = bIsNamespace
        qSetButton = QtWidgets.QPushButton('<<')
        qSetButton.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        qSetButton.clicked.connect(self.setClicked)
        self.qNamespaceLayout.addWidget(qSetButton)

        qLayout.addLayout(self.qTopLayout)



    def setClicked(self, sObject=None):

        if utils.isNone(sObject) or isinstance(sObject, bool):
            sObject = cmds.ls(sl=True)[0]

        if self.bIsIndex:
            sNumber = sObject.split('[')[-1].split(']')[0]
            self.qLine.setText(sNumber)
        elif self.bIsNamespace:
            if ':' not in sObject:
                return
            sNamespace = '%s:' % sObject.split(':')[0]
            self.qLine.setText(sNamespace)
        else:
            self.qLine.setText(sObject)


    def getObject(self):
        sText = self.qLine.text()
        if self.bIsIndex:
            return int(sText)
        else:
            return sText


def getTargetArrayMultiplName(sTarget):
    sBlendShapeMultipl = '%s__%s' % (kTargetArrayMultipl, sTarget)
    return sBlendShapeMultipl


def getComboOutput(sTargetArrayMultipl):
    sOutType = cmds.objectType(sTargetArrayMultipl)
    if sOutType == 'multiplyDivide':
        return '%s.outputX' % sTargetArrayMultipl
    elif sOutType == 'condition':
        return '%s.outColorR' % sTargetArrayMultipl
    else:
        raise Exception('Don\'t know what to do with outType "%s" ("%s")' % (sOutType, sTargetArrayMultipl))


def getTargetArrayMultipl(sTarget, sPoseOutputs=None, iNonDriverInputs=set(), bForceRecreate=False, sMode=None):
    sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)

    if not cmds.objExists(sTargetArrayMultipl):
        createMultiplyArrayNode(sPoseOutputs, bForce=True, sLastFullName=sTargetArrayMultipl, iNonDriverInputs=iNonDriverInputs, sMode=sMode or 'M')
    elif bForceRecreate or sorted(sPoseOutputs) != sorted(eval(cmds.getAttr('%s.sPoseOutputs' % sTargetArrayMultipl))):
        if utils.isNone(sPoseOutputs):
            sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetArrayMultipl))

        sPlugsBefore = cmds.listConnections(getComboOutput(sTargetArrayMultipl), s=False, d=True, p=True) or []
        nodes.deleteConnectionsAndItself3([sTargetArrayMultipl])

        if utils.isNone(sMode):
            sMode = utils.getAttrIfExists('%s.sMode' % sTargetArrayMultipl, 'M')
        createMultiplyArrayNode(sPoseOutputs, bForce=True, sLastFullName=sTargetArrayMultipl, iNonDriverInputs=iNonDriverInputs, sMode=sMode)
        for sPlug in sPlugsBefore:
            cmds.connectAttr(getComboOutput(sTargetArrayMultipl), sPlug)


    return getComboOutput(sTargetArrayMultipl)





def _reconnectTargetAttr(sBlendShape, sTarget, sPoseOutputs):
    sTargetArrayMultipl = getTargetArrayMultipl(sTarget, sPoseOutputs)

    cmds.connectAttr(sTargetArrayMultipl, '%s.%s' % (sBlendShape, sTarget))


def poseToPoseOutputs(sPoseOutputs, fWeight=1.0, bSkipReverse=False):
    try:
        cmds.undoInfo(openChunk=True)
        for sOutput in sPoseOutputs:
            if bSkipReverse:
                if cmds.listConnections(sOutput, s=True, d=False, t='reverse'):
                    continue
                sI,sA = sOutput.split('.')
                sReverseA = 'reverse_%s' % sA
                if cmds.attributeQuery(sReverseA, node=sI, exists=True):
                    if cmds.getAttr('%s.%s' % (sI, sReverseA)):
                        continue

            sInterp, sPose = sOutput.split('.')
            sPoseAttrs = eval(cmds.getAttr('%s.sPoseAttrs' % sInterp))
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)

            fPoseValues = getPoseValues(sInterp, sPose)
            for sA, fV in zip(sPoseAttrs, fPoseValues):
                if sA:
                    sAttr = sA if '.' in sA else '%s.%s' % (sCtrl, sA)
                    if cmds.getAttr(sAttr, settable=True):
                        cmds.setAttr(sAttr, fV * fWeight)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def goToDefaultPose():
    KangarooMatchTools.goToDefaultPoseSelected(bSkipDisplayAttrs=True)
    resetPoseEditorResetAttrs(None)


def _serializeInterpolators(sInterps):
    xInterpolators = []
    for sInterp in sorted(sInterps):
        sInterpType = cmds.getAttr('%s.sInterpType' % sInterp)
        dInterp = {'sInterpType': sInterpType, 'sName': sInterp}

        if sInterpType == 'signedAngle':
            sJoint, sParentJoint = eval(cmds.getAttr('%s.sJoints' % sInterp))
            sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterp)
            iAngleAxis = eval(cmds.getAttr('%s.iAngleAxis' % sInterp))
            iUpAxis = eval(cmds.getAttr('%s.iUpAxis' % sInterp))
            ffRanges = eval(cmds.getAttr('%s.ffRanges' % sInterp))
            xPosesAttr = eval(cmds.getAttr('%s.xPoses' % sInterp))  # "[('bend', -90, 0, 0)]";
            sPoseNames = [xPose[0] for xPose in xPosesAttr]

            dRanges = {sPoseName: ffRanges[p] for p, sPoseName in enumerate(sPoseNames)}
            dCurveTypes = {sPoseName: cmds.getAttr('%s.%s_curveType' % (sInterp, sPoseName)) for sPoseName in
                           sPoseNames}
            xPosesPass = [(sPoseName, dRanges[sPoseName], dCurveTypes[sPoseName]) for sPoseName in sPoseNames]

            dInterp['sTwist'] = sJoint
            dInterp['sParent'] = sParentJoint
            dInterp['sCtrlAttr'] = sCtrlAttr
            dInterp['iAngleAxis'] = iAngleAxis
            dInterp['iUpAxis'] = iUpAxis
            dInterp['xPoses'] = xPosesPass
            # dInterp['bMirror'] = False
            dInterp['bComputeInParentSpace'] = False
            xInterpolators.append(dInterp)

        elif sInterpType == 'attribute':
            sCtrlAttr = cmds.getAttr('%s.sCtrlAttr' % sInterp)
            sDriverAttr = cmds.getAttr('%s.sDriverAttr' % sInterp)
            ffRanges = eval(cmds.getAttr('%s.ffRanges' % sInterp))
            xPosesAttr = eval(cmds.getAttr('%s.xPoses' % sInterp))  # "[('bend', -90, 0, 0)]";
            sPoseNames = [xPose[0] for xPose in xPosesAttr]

            dRanges = {sPoseName: ffRanges[p] for p, sPoseName in enumerate(sPoseNames)}
            dCurveTypes = {sPoseName: cmds.getAttr('%s.%s_curveType' % (sInterp, sPoseName)) for sPoseName in
                           sPoseNames}
            xPosesPass = [(sPoseName, dRanges[sPoseName], dCurveTypes[sPoseName]) for sPoseName in sPoseNames]

            dInterp['sCtrlAttr'] = sCtrlAttr
            dInterp['sDriverAttr'] = sDriverAttr
            dInterp['xPoses'] = xPosesPass
            # dInterp['bMirror'] = False
            # dInterp['bComputeInParentSpace'] = False
            xInterpolators.append(dInterp)

        elif sInterpType == 'custom':
            # def createCustomInterpolator(sName, sCtrlAttrs, sDriverAttr,
            #                                  xPoses=[('on', [0, 0, 0], blendShapes.DrivenKeyCurveType.easeIn)],
            #                                  sMaster=None):

            xPosesAttr = eval(cmds.getAttr('%s.xPoses' % sInterp))  # "[('bend', -90, 0, 0)]";
            sPoseNames = [xPose[0] for xPose in xPosesAttr]

            dCurveTypes = {sPoseName: cmds.getAttr('%s.%s_curveType' % (sInterp, sPoseName)) for sPoseName in
                           sPoseNames}
            xPosesPass = [(xP[0], [xP[1], xP[2], xP[3]], dCurveTypes[xP[0]]) for xP in xPosesAttr]

            dInterp['sCtrlAttrs'] = [cmds.getAttr('%s.sCtrlAttrX' % sInterp), cmds.getAttr('%s.sCtrlAttrY' % sInterp), cmds.getAttr('%s.sCtrlAttrZ' % sInterp)]
            dInterp['sDriverAttr'] = cmds.getAttr('%s.sDriverAttr' % sInterp)
            dInterp['xPoses'] = xPosesPass
            xInterpolators.append(dInterp)

        elif sInterpType == 'cone':
            sJoint = cmds.getAttr('%s.sJoint' % sInterp)
            sJointParent = cmds.getAttr('%s.sJointParent' % sInterp)
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
            xPosesAttr = eval(cmds.getAttr('%s.xPoses' % sInterp))  # "[('bend', -90, 0, 0)]";
            sPoseNames = [xPose[0] for xPose in xPosesAttr]

            sConeTransforms = ['%s_%s_cone' % (sInterp, sPoseName) for sPoseName in sPoseNames]
            dCurveTypes = {sPoseName: cmds.getAttr('%s.curveType' % sConeTransform) for sPoseName, sConeTransform in
                           zip(sPoseNames, sConeTransforms)}
            dRotationValues = {sPoseName: cmds.getAttr('%s.r' % sConeTransform)[0] for sPoseName, sConeTransform in
                               zip(sPoseNames, sConeTransforms)}
            dInnerOuterRanges = {
                sPoseName: [cmds.getAttr('%s.startAngle' % sConeTransform),
                            cmds.getAttr('%s.endAngle' % sConeTransform)] for
                sPoseName, sConeTransform in zip(sPoseNames, sConeTransforms)}
            dRevs = {sPoseName: utils.getAttrIfExists('%s.bReverse' % sConeTransform, 0.0) for sPoseName, sConeTransform in zip(sPoseNames, sConeTransforms)}

            xPosesPass = [(sPoseName, dRotationValues[sPoseName], dInnerOuterRanges[sPoseName], dCurveTypes[sPoseName], dRevs[sPoseName])
                          for
                          sPoseName in sPoseNames if sPoseName != 'default']  # [('default',(0,0,0), (0,45)]

            dInterp['sJoint'] = sJoint
            dInterp['sJointParent'] = sJointParent
            dInterp['sCtrl'] = sCtrl
            dInterp['xPoses'] = xPosesPass
            dInterp['iCtrlTwistAxis'] = utils.getAttrIfExists('%s.iCtrlTwistAxis' % sInterp, 1)
            dInterp['bJointAngleFactor'] = utils.getAttrIfExists('%s.bJointAngleFactor' % sInterp, 0)
            # dInterp['bMirror'] = False
            xInterpolators.append(dInterp)



        elif sInterpType == 'mayaPose':
            sJoint = cmds.getAttr('%s.sJoint' % sInterp)
            sJointParent = cmds.getAttr('%s.sJointParent' % sInterp)
            sCtrl = cmds.getAttr('%s.sCtrl' % sInterp)
            xPosesValue = eval(cmds.getAttr(
                '%s.xPoses' % sInterp))  # [('side', 0, 0, 90), ('forward', 90, 0, 0), ('forwardExtreme', 110, 0, 0), ('back', -50, 0, 0)]

            dRotations = {xP[0]: (xP[1], xP[2], xP[3]) for xP in xPosesValue}
            sPoseNames = [xP[0] for xP in xPosesValue]

            xPosesPass = [(sPoseName, dRotations[sPoseName][0], dRotations[sPoseName][1], dRotations[sPoseName][2]) for
                          sPoseName in sPoseNames]

            dInterp['sJoint'] = sJoint
            dInterp['sJointParent'] = sJointParent
            dInterp['sCtrl'] = sCtrl
            dInterp['xPoses'] = xPosesPass
            # dInterp['bMirror'] = False
            xInterpolators.append(dInterp)

        elif sInterpType == 'upleg':
            xPosesValue = eval(cmds.getAttr('%s.xPoses' % sInterp))  # [('side', 0, 0, 90), ('forward', 90, 0, 0), ('forwardExtreme', 110, 0, 0), ('back', -50, 0, 0)]
            sPoseNames = [xP[0] for xP in xPosesValue]
            fUpRotations = [xP[1] for xP in xPosesValue]
            dInterp['sPoseNames'] = sPoseNames
            dInterp['fKneeStarts'] =  [cmds.getAttr('%s.kneeStart_%s' % (sInterp, sPoseName)) for sPoseName in sPoseNames]
            dInterp['fTurnOffOnIns'] =  [cmds.getAttr('%s.turnOffOnIn_%s' % (sInterp, sPoseName)) for sPoseName in sPoseNames]
            dInterp['bReverses'] =  [(True if cmds.getAttr('%s.reverse_%s' % (sInterp, sPoseName)) else False) for sPoseName in sPoseNames]
            dInterp['fUpRotations'] =  fUpRotations
            xInterpolators.append(dInterp)
        else:
            raise Exception('not sure what interpType "%s" (%s)' % (sInterpType, sInterp))

    return xInterpolators


def _findInterpolatorsInScene():
    sInterps = []
    for sInterp in [sT for sT in cmds.ls('*', et='transform') if cmds.attributeQuery('sInterpType', node=sT, exists=True)]:
        sNoExportAttr = '%s.noExport' % sInterp
        if cmds.objExists(sNoExportAttr) and cmds.getAttr(sNoExportAttr) == True:
            continue
        sInterps.append(sInterp)
    return sInterps

#
## BUILDER FUNCTINS
#
def fillAndExportFromScene(_uiArgs=None):

    switchAllToFk(bAsk=True)

    sInterps = _findInterpolatorsInScene()


    xInterpolators = _serializeInterpolators(sInterps)
    ddInterpolators = {}
    for xI in xInterpolators:
        sName = xI['sName']
        del xI['sName']
        ddInterpolators[sName] = xI
    _uiArgs['ddInterpolators'].setText(str(ddInterpolators))
    fillPosesData(_uiArgs=_uiArgs)


def groupLocsByCtrls(sPoseLocs):
    dPoseLocs = defaultdict(list)
    for sLoc in sPoseLocs:
        sCtrl = sLoc.split('__')[1]
        dPoseLocs[sCtrl].append(sLoc)
    return dict(dPoseLocs)


# not tested yet
def groupLocsByTargets(sPoseLocs):
    dPoseLocs = defaultdict(list)
    for sLoc in sPoseLocs:
        sTarget = sLoc.split('__')[1]
        dPoseLocs[sTarget].append(sLoc)
    return dict(dPoseLocs)




def fillPosesData(_uiArgs=None):
    print ('filling posesData...')
    sTargetArrayMultiplyNodes = cmds.ls('%s__*' % kTargetArrayMultipl)
    dTargets = {}
    for sNode in sTargetArrayMultiplyNodes:
        sTarget = sNode.split('__')[1]
        sMode = utils.getAttrIfExists('%s.sMode' % sNode, 'M')
        dTargets[sTarget] = [eval(cmds.getAttr('%s.sPoseOutputs' % sNode)), list(eval(cmds.getAttr('%s.iNonDriverInputs' % sNode))), sMode]

    # disabled blendShape Targets
    #
    dDisabledBlendShapeTargets = defaultdict(list)
    sBlendShapes = _getBlendShapes()
    for sBlendShape in sBlendShapes:
        sMesh = sBlendShape.split('__')[1]
        for sTarget in blendShapes.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True).keys():
            sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
            if not cmds.listConnections(sTargetAttr, s=True, d=False):
                dDisabledBlendShapeTargets[sMesh].append(sTarget)

    # pose locators
    #
    dPoseLocs = groupLocsByCtrls(cmds.ls(f'_poseLocEditor__*__*', et='transform'))
    dDisabledLocs = defaultdict(list)

    dLocs = {}
    for sCtrl, sPoseLocs in dPoseLocs.items():
        dTrsValues = {}
        for sLoc in sPoseLocs:
            dTrsValues[sLoc] = [utils.fPruneSmallValues(cmds.getAttr('%s.t' % sLoc)[0]),
                             utils.fPruneSmallValues(cmds.getAttr('%s.r' % sLoc)[0]),
                             utils.fPruneSmallValues(cmds.getAttr('%s.s' % sLoc)[0])]
            sSplits = sLoc.split('__')
            sTarget = sSplits[-1]
            sWeightMultiplName = getWeightMultiplName(sCtrl, sTarget, 't')
            if not cmds.objExists(sWeightMultiplName):
                dDisabledLocs[sCtrl].append(sLoc)
        dLocs[sCtrl] = dTrsValues


    ddPoseData = {'dTargets': dTargets, 'dDisabledBlendShapeTargets':dict(dDisabledBlendShapeTargets), 'dLocs':dLocs, 'dDisabledLocs':dict(dDisabledLocs)}


    _uiArgs['ddPoseData'].setText(str(ddPoseData))

    createBakedBlendShapeMeshesForExport(dTargetsForSort=dTargets)

def showBakedBlendShapeMeshesInExplorer():
    sFile = _getPoseEditorExportsPath()
    utils.openExplorer(sFile)


def openBakedBlendShapeFile():
    sFile = _getPoseEditorExportsPath()
    cmds.file(sFile, open=True, force=True)


def createBakedBlendShapeMeshesForExport(dTargetsForSort={}):

    sBlendShapes = _getBlendShapes()

    sGroup = 'poseEditor_export'
    if cmds.objExists(sGroup):
        cmds.delete(sGroup)
    cmds.createNode('transform', n=sGroup)

    iProgressCount = 0
    for sBlendShape in sBlendShapes:
        iProgressCount += len([sT for sT in blendShapes.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True).keys() if cmds.objExists(getTargetArrayMultiplName(sT))])

    qStatusWindow = utilsQt.QStatusWindow('Create BlendShape Meshes')
    if iProgressCount:
        qStatusWindow.setCount(iProgressCount)
    try:

        for sBlendShape in sBlendShapes:
            cmds.setAttr('%s.envelope' % sBlendShape, 1.0)
            sMesh = sBlendShape.split('__')[-1]
            bInverseExport = utils.getAttrIfExists('%s.%s' % (sMesh, kInverseExportAttr), False)
            goToDefaultPose()
            sMeshDupl = cmds.duplicate(sMesh, n='%s_%s' % (sMesh, kExportPoseEditorBlendShapesSuffix))[0]

            utils.addAttr(sMeshDupl, ln=kInverseExportAttr, dv=False, bReturnIfExists=True)
            cmds.setAttr('%s.%s' % (sMeshDupl, kInverseExportAttr), bInverseExport)

            cmds.parent(sMeshDupl, sGroup)

            sMeshTargets = blendShapes.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True).keys()
            sMeshTargets = sorted(sMeshTargets, key=lambda x: (len(dTargetsForSort.get(x, [[], None])[0]), x))  # to make sure that combinations of more happen later


            sDoTargets = []
            xPrevPlugs = []
            for sTarget in sMeshTargets:
                sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)
                if cmds.objExists(sTargetArrayMultipl): # could be another blendShape we don't care about
                    sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
                    sDoTargets.append(sTarget)
                    sPlugs = cmds.listConnections(sTargetAttr, s=True, d=False, p=True)
                    if sPlugs:
                        cmds.disconnectAttr(sPlugs[0], sTargetAttr)
                        xPrevPlugs.append([sTarget, sPlugs[0]])
                        cmds.setAttr(sTargetAttr, 0.0)
                    else:
                        xPrevPlugs.append([sTarget, cmds.getAttr(sTargetAttr)])
                        cmds.setAttr(sTargetAttr, 0.0)

            if bInverseExport:
                goToDefaultPose()
                for sTarget, sPlug in xPrevPlugs:
                    qStatusWindow.increment()
                    sTargetAttr = '%s.%s' % (sBlendShape, sTarget)

                    sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)
                    if not cmds.objExists(sTargetArrayMultipl):  # could be another blendShape we don't care about
                        continue

                    cmds.setAttr(sTargetAttr, 1.0)

                    if not cmds.listConnections(sTargetAttr, s=True, d=False):
                        cmds.setAttr(sTargetAttr, 1.0)

                    blendShapes.addTargets(sMeshDupl, sMesh, sAliasAttrs=sTarget, bDisconnectGeo=True)

                    cmds.setAttr(sTargetAttr, 0.0)

                for sTarget, sPlug in xPrevPlugs:
                    sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
                    if isinstance(sPlug, str):
                        cmds.connectAttr(sPlug, sTargetAttr)
                    else:
                        cmds.setAttr(sTargetAttr, sPlug)

            else: # default way of posed meshes
                for sTarget, sPlug in xPrevPlugs:
                    qStatusWindow.increment()
                    sTargetAttr = '%s.%s' % (sBlendShape, sTarget)

                    if isinstance(sPlug, str):
                        cmds.connectAttr(sPlug, sTargetAttr)
                    else:
                        cmds.setAttr(sTargetAttr, sPlug)
                    sTargetArrayMultipl = getTargetArrayMultiplName(sTarget)
                    if not cmds.objExists(sTargetArrayMultipl): # could be another blendShape we don't care about
                        continue
                    goToDefaultPose()
                    if not cmds.listConnections(sTargetAttr, s=True, d=False):
                        cmds.setAttr(sTargetAttr, 1.0)
                    sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetArrayMultipl))
                    poseToPoseOutputs(sPoseOutputs)
                    blendShapes.addTargets(sMeshDupl, sMesh, sAliasAttrs=sTarget, bDisconnectGeo=True)
                    if not cmds.listConnections(sTargetAttr, s=True, d=False):
                        cmds.setAttr(sTargetAttr, 0.0)

        goToDefaultPose()

        clearFromSets(sGroup)

        sFile = _getPoseEditorExportsPath()

        cmds.select(sGroup)
        cmds.setAttr('%s.v' % sGroup, False)
        print ('sFile: ', sFile)
        cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=True)
    except:
        raise
    finally:
        qStatusWindow.end()


def clearFromSets(sParent):
    sNodes = cmds.ls(sParent, dag=True)
    sAllSets = cmds.ls(et='objectSet')
    if sAllSets:
        for sNode in sNodes:
            sSets = [sSet for sSet in sAllSets if cmds.sets(sNode, isMember=sSet)]
            for sSet in sSets:
                print(f'removing "{sNode}" from "{sSet}"..')
                cmds.sets(sNode, rm=sSet)


def _getPoseEditorExportsPath():
    import kangarooTools.assets as assets
    sDir = assets.assetManager.getCurrentVersionPath()
    sMayaImportDir = os.path.join(sDir, 'mayaImport')
    if not os.path.exists(sMayaImportDir):
        os.makedirs(sMayaImportDir)
    sFile = os.path.join(sMayaImportDir, 'poseEditorExports.ma')
    return sFile

def _buildInterpFromDict(dInterp):
    sInterpType = dInterp['sInterpType']
    del dInterp['sInterpType']
    dInterp['bMirror'] = False
    if sInterpType == 'signedAngle':
        interpolator.createSignedAngleInterpolator3(**dInterp)
    elif sInterpType == 'cone':
        interpolator.createConeInterpolator2(**dInterp)
    elif sInterpType == 'mayaPose':
        interpolator.createPoseInterpolator(**dInterp)
    elif sInterpType == 'upleg':
        interpolator.createUpLegInterpolator2(**dInterp)
    elif sInterpType == 'attribute':
        interpolator.createAttributeInterpolator(**dInterp)
    elif sInterpType == 'custom':
        interpolator.createCustomInterpolator(**dInterp)
    else:
        raise Exception('don\'t know what type "%s" ("%s")' % sInterpType, dInterp['sInterp'])


def poseEditorApply(ddInterpolators={}, ddPoseData={}, bSkipBlendShapes=False, bSkipLocators=False, bSkipDisabledLocators=True, bReport=False):

    switchAllToFk(bAsk=False)

    for sInterp, dInterp in ddInterpolators.items():
        dInterp['sName'] = sInterp
        _buildInterpFromDict(dInterp)

    sBlendShapeMeshes = cmds.ls('*_%s' % kExportPoseEditorBlendShapesSuffix, et='transform')

    dTargetMeshes = defaultdict(list)
    sAllMeshes = set()
    for sBlendShapeMesh in sBlendShapeMeshes:
        sMeshName = utils.replaceStringEnd(sBlendShapeMesh, '_%s' % kExportPoseEditorBlendShapesSuffix, '')
        sBlendShape = 'blendShape__%s' % sBlendShapeMesh
        sMeshes, sTargets, sSkipped = blendShapes.bake(sBlendShapeMesh, sBlendShape, sPrefix='%s__' % sMeshName, bSkipDoubleUnderscored=True)
        for sMesh,sTarget in zip(sMeshes, sTargets):
            utils.addAttr(sMesh, ln=kInverseExportAttr, bReturnIfExists=True)
            cmds.setAttr('%s.%s' % (sMesh, kInverseExportAttr), utils.getAttrIfExists('%s.%s' % (sBlendShapeMesh, kInverseExportAttr), False))

            dTargetMeshes[sTarget].append(sMeshName)
        sAllMeshes.add(sMeshName)

    goToDefaultPose()


    if not bSkipLocators:
        dTargets = ddPoseData.get('dTargets', {})
        dLocs = ddPoseData.get('dLocs', {})
        dDisabledLocs = ddPoseData.get('dDisabledLocs', {})
        for sCtrl, dTrsValues in dLocs.items():
            sDisabledLocs = dDisabledLocs.get(sCtrl, [])
            # sTransform = _getTransformFromCtrl(sCtrl)
            createCtrlPosesSetup(sCtrl, [])
            utils.addStringAttr(sCtrl, 'poseEditor', sCtrl)


            for sLoc, ffValues in dTrsValues.items():
                if bSkipDisabledLocators and sLoc in sDisabledLocs:
                    continue

                sTarget = sLoc.split('__')[-1]
                sMode = dTargets[sTarget][2] if len(dTargets[sTarget]) > 2 else 'M'
                getTargetArrayMultipl(sTarget, dTargets[sTarget][0], sMode=sMode) # #  [['scapula.up'], []]
                addTargetPosesToCtrl(sCtrl, sTarget)

                # reconnectPoseLoc(sTransform, sTarget, dTargets[sTarget])
                for a, sA in enumerate('trs'):
                    cmds.setAttr('%s.%s' % (sLoc, sA), *ffValues[a])

                if sLoc in sDisabledLocs:
                    disconnectPoseLoc(sCtrl, sTarget)

        goToDefaultPose()


    if not bSkipBlendShapes:
        dTargets = ddPoseData.get('dTargets', {})
        # creating the empty blendShapes
        #
        for sMesh in sAllMeshes:
            sBlendShape = 'blendShape__%s' % sMesh
            utils.addAttr(sMesh, ln=kInverseExportAttr, at='bool', dv=False, bReturnIfExists=True)

            if not cmds.objExists(sBlendShape):
                deformers.preDeformationBlendshapeHack([], sMesh, n=sBlendShape)
                utils.addAttr(sBlendShape, ln=kIsPoseEditorBlendShapeAttr, bReturnIfExists=True)

        # just create target nodes so they show in the UI
        #
        for sTarget, xPoseOutputs in dTargets.items():
            sPoseOutputs, iNonDriverInputs = xPoseOutputs[0:2]
            sMode = dTargets[sTarget][2] if len(dTargets[sTarget]) > 2 else 'M'
            getTargetArrayMultipl(sTarget, sPoseOutputs, iNonDriverInputs=iNonDriverInputs, sMode=sMode)


        # apply the blendShape targets
        #
        sMeshTargets = [sT for sT in dTargetMeshes.keys() if not sT.startswith('__')]
        sMeshTargets = sorted(sMeshTargets, key=lambda x:(len(dTargets.get(x, [[], None])[0]), x)) #  to make sure that combinations of more happen later

        if bReport:
            report.report.resetProgress(len(sMeshTargets))

        for sTarget in sMeshTargets:
            if bReport:
                report.report.addLogText('"%s"...' % sTarget)
                report.report.incrementProgress()

            sMeshes = dTargetMeshes[sTarget]
            if sTarget not in dTargets:
                report.report.addLogText('Skipping Target Geo "%s", because Target is missing in dTarget dict of ddPoseData' % sTarget)
                continue

            goToDefaultPose()
            sTargetArrayMultipl = getTargetArrayMultiplName(sTarget) #, dTargets[sTarget])
            sPoseOutputs = eval(cmds.getAttr('%s.sPoseOutputs' % sTargetArrayMultipl))
            poseToPoseOutputs(sPoseOutputs)

            for sMesh in sMeshes:
                sBlendShape = 'blendShape__%s' % sMesh
                sTargetGeo = '%s__%s' % (sMesh, sTarget)
                bInverseExport = cmds.getAttr('%s.%s' % (sTargetGeo, kInverseExportAttr))
                cmds.setAttr('%s.%s' % (sMesh, kInverseExportAttr), bInverseExport)

                cmds.setAttr('%s.v' % sTargetGeo, False)
                if cmds.objExists(sTargetGeo):
                    if bInverseExport:
                        sInvert = sTargetGeo
                    else:
                        sInvert = geometry.invertShapeDeformers(sTargetGeo, sMesh, sInvertName='%s_inverted' % sTargetGeo, sComboBlendShape=sBlendShape)
                    sTargetAttr = blendShapes.addTargets(sMesh, [sInvert], sAliasAttrs=[sTarget])[0]
                    utils.addAttr(sTargetAttr.split('.')[0], ln=kIsPoseEditorBlendShapeAttr, k=True, bReturnIfExists=True)

                    if sTarget not in ddPoseData['dDisabledBlendShapeTargets'].get(sMesh, []):
                        _reconnectTargetAttr(sBlendShape, sTarget, sPoseOutputs)
                    cmds.setAttr('%s.v' % sInvert, False)
        goToDefaultPose()


    KangarooMatchTools.goToDefaultPoseSelected()


def createMultiplyArrayNode(xInputs, sTarget=None, sLastFullName=None, iNonDriverInputs=set(), bForce=False, sMode='M'):
    xInputs = list(xInputs)
    xAttrInputs = list(xInputs)

    for iIndex in iNonDriverInputs:
        xInputs[iIndex] = 1.0


    if len(xInputs) == 1:
        xInputs.append(1.0)

    sPrev = xInputs[0]
    # sNode = None

    print ('sMode: ', sMode)
    for i, xInput in enumerate(xInputs[1:]):
        if sMode in ['M', None]:
            sNode = cmds.createNode('multiplyDivide', name='ARRAYMULT_')
            utils._connectOrSet(sPrev, '%s.input1X' % sNode)
            utils._connectOrSet(xInput, '%s.input2X' % sNode)
            sPrev = '%s.outputX' % sNode
        elif sMode in ['S', 'B']:
            sNode = cmds.createNode('condition', name='ARRAYMULT_')
            cmds.setAttr('%s.operation' % sNode, 4)
            utils._connectOrSet(xInput, '%s.firstTerm' % sNode)
            utils._connectOrSet(sPrev, '%s.secondTerm' % sNode)
            if sMode == 'S':
                utils._connectOrSet(xInput, '%s.colorIfTrueR' % sNode)
                utils._connectOrSet(sPrev, '%s.colorIfFalseR' % sNode)
            elif sMode == 'B':
                utils._connectOrSet(xInput, '%s.colorIfFalseR' % sNode)
                utils._connectOrSet(sPrev, '%s.colorIfTrueR' % sNode)
            sPrev = '%s.outColorR' % sNode
        else:
            raise Exception('not sure what Mode "%s" is' % sMode)

    sOutput = sPrev
    if sTarget:
        utils._connectOrSet(sOutput, sTarget, bForce=bForce)

    sNode = sOutput.split('.')[0]
    utils.addStringAttr(sNode, 'sPoseOutputs', str(xAttrInputs))
    utils.addStringAttr(sNode, 'iNonDriverInputs', str(set(iNonDriverInputs)))
    utils.addStringAttr(sNode, 'sMode', sMode)
    utils.addAttr(sNode, ln='bPost', at='bool', k=True, dv=False)

    if sLastFullName:
        sOutputNode, sOutputAttr = sOutput.split('.')
        sOutputNode = cmds.rename(sOutputNode, sLastFullName)
        sOutput = '%s.%s' % (sOutputNode, sOutputAttr)

    return sOutput



def modelChangeWarp():
    sSel = cmds.ls(sl=True, et='transform')
    sBlendShapeMesh = None
    sNewModel = None
    for sObj in sSel:
        if sObj.endswith('_%s' % kExportPoseEditorBlendShapesSuffix):
            sBlendShapeMesh = sObj
        else:
            sNewModel = sObj

    sBlendShape = 'blendShape__%s' % sBlendShapeMesh
    sOldBlendShape = cmds.rename(sBlendShape, '%s_old' % sBlendShape)
    sOldBlendShapeMesh = cmds.rename(sBlendShapeMesh, '%s_old' % sBlendShapeMesh)

    sUnorderedWraps, sBase = deformers.createWrap(sNewModel, sOldBlendShapeMesh)
    dTargets = blendShapes.getTargetsDictFromBlendShape(sOldBlendShape, bPerTargetNames=True)
    sNewTargets = []
    for sTarget in dTargets.keys():
        if sTarget.startswith('__'):
            continue
        sTargetAttr = '%s.%s' % (sOldBlendShape, sTarget)
        if cmds.getAttr(sTargetAttr, lock=True):
            continue
        cmds.setAttr(sTargetAttr, 1.0)
        sNewTargets.append(cmds.duplicate(sNewModel, n=sTarget)[0])
        cmds.setAttr(sTargetAttr, 0.0)

    cmds.delete(sUnorderedWraps, sBase)


    sBlendShapeMesh = cmds.duplicate(sNewModel, n='%s_%s' % (sNewModel, kExportPoseEditorBlendShapesSuffix))[0]
    if cmds.attributeQuery(kInverseExportAttr, node=sOldBlendShapeMesh, exists=True):
        utils.addAttr(sBlendShapeMesh, ln=kInverseExportAttr, at='bool', dv=cmds.getAttr('%s.%s' % (sOldBlendShapeMesh, kInverseExportAttr)), k=True)
    sParent = cmds.listRelatives(sOldBlendShapeMesh, p=True)
    if sParent:
        utils.parentTo(sBlendShapeMesh, sParent[0])
    blendShapes.addTargets(sBlendShapeMesh, sNewTargets)
    cmds.delete(sNewTargets)



def modelChangeBlendShape():
    sSel = cmds.ls(sl=True, et='transform')
    sBlendShapeMesh = None
    sNewModel = None
    for sObj in sSel:
        if sObj.endswith('_%s' % kExportPoseEditorBlendShapesSuffix):
            sBlendShapeMesh = sObj
        else:
            sNewModel = sObj



    sBlendShape = 'blendShape__%s' % sBlendShapeMesh

    if not cmds.objExists(sBlendShape):
        raise Exception('problem with "%s" - "%s" doesn\'t exist' % (sBlendShapeMesh, sBlendShape))

    sInvertAttr = '%s.%s' % (sBlendShapeMesh, kInverseExportAttr)
    if not cmds.objExists(sInvertAttr) or not cmds.getAttr(sInvertAttr):
        if cmds.confirmDialog(m=str('"%s" was exported as posed. The wrap warp will be better for this.' % (sBlendShapeMesh),
                                 button=['abort', 'do it anyway with blendShapes'])) == 'abort':
            return


    if cmds.attributeQuery('__modelChange', node=sBlendShape, exists=True):
        blendShapes.deleteBlendShapeTarget(sBlendShape, ['__modelChange'])

    sTargetAttr = blendShapes.addTargets(sBlendShapeMesh, [sNewModel], sAliasAttrs=['__modelChange'])[0]

    cmds.setAttr(sTargetAttr, 1.0)
    print ('successfully added __modelChange blendShape')


def resetPoseEditorResetAttrs(dResetAttrs):
    cmds.undoInfo(openChunk=True)
    try:

        if not utils.isNone(dResetAttrs):
            utils.data.store('dPoseEditorResetAttrs', str(dResetAttrs))
            bStoreValuesBefore = True
        else:
            dResetAttrs = utils.data.get('dPoseEditorResetAttrs')
            bStoreValuesBefore = False

        print ('resetAttrs: ', dResetAttrs)
        dValuesBefore = {}
        for sAttr,fValue in dResetAttrs.items():
            if cmds.objExists(sAttr) and cmds.getAttr(sAttr, settable=True):
                dValuesBefore[sAttr] = cmds.getAttr(sAttr)
                cmds.setAttr(sAttr, fValue)

        if bStoreValuesBefore:
            utils.data.store('dPoseEditorBeforeResetValues', str(dValuesBefore))
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def recoverPoseEditorResetAttrs():
    dValuesBefore = utils.data.get('dPoseEditorBeforeResetValues')

    cmds.undoInfo(openChunk=True)
    try:
        for sAttr, fValue in dValuesBefore.items():
            cmds.setAttr(sAttr, fValue)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def checkLatticeDeformers(sMesh):
    sLattices = deformers.listAllDeformers(sMesh, sFilterTypes=['ffd'])
    if sLattices:
        if cmds.confirmDialog(m='Lattices found on "%s" (%s) \nThose can screw with some of the PoseEditor Tools, temporarily delete them?' % (sMesh, utils.listToString(sLattices)),
                              button=['yes', 'no']) == 'yes':
            cmds.delete(sLattices)

