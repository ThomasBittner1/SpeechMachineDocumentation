###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import numpy as np
import maya.api.OpenMaya as OpenMaya2
import maya.OpenMaya as OpenMaya
import kangarooTools.nodes as nodes
import kangarooTools.patch as patch
import kangarooTools.utilsQt as utilsQt



def createCurveFromJoints(sJoints, iDegree=2, sName='noname', sParent=None, bFit=False):
    fPoints = [cmds.xform(sJ, q=True,ws=True,t=True) for sJ in sJoints]
    return createCurveFromPoints(fPoints, iDegree=iDegree, sName=sName, sParent=sParent, bFit=bFit)


def createCurveFromPoints(aPoints, iDegree=2, sName='noname', sParent=None, bFit=False):
    fPoints = list(aPoints)

    if bFit and np.linalg.norm(np.array(fPoints[0]) - np.array(fPoints[-1])) < 0.0001:
        raise Exception('if bFit is True, the first point cannot be the same as the last point')

    sCurve = cmds.curve(p=fPoints, d=iDegree)
    if bFit:
        sCurveNew = cmds.fitBspline(sCurve)[0]
        cmds.delete(sCurve)
        sCurve = cmds.rename(sCurveNew, sName)
    else:
        sCurve = cmds.rename(sCurve, sName)

    if sParent != None:
        try: cmds.parent(sCurve, sParent)
        except: pass
    return sCurve


def createJointsFromCurve(sCurve, iJointCount=10, sName='noname', sParent=None):
    import xforms as xforms
    aPercs = np.arange(iJointCount) / float(iJointCount-1)
    aPoints = getPointsFromPercs(sCurve, aPercs)
    sJoints = xforms.createJointChain(aPoints, sNames=['jnt_%s_%03d' % (sName,j) for j in range(iJointCount)])
    if sParent:
        try:
            cmds.parent(sJoints[0], sParent)
        except:
            pass

    return sJoints


def fixShapeName(sCurves):
    for sCurve in utils.toList(sCurves):
        for sShape in cmds.listRelatives(sCurve, s=True, typ='nurbsCurve', f=True):
            cmds.rename(sShape, utils.getUniqueName('%sShape' % sCurve.split('|')[-1]))


def getLength(sCurve):
    mCurve = utils.getDagPath(sCurve)
    return OpenMaya2.MFnNurbsCurve(mCurve).length()


def cvCount(sCurve):
    return len(cmds.ls('%s.cv[*]' % sCurve, flatten=True))


def createSplineHandle(sStartJoint, sEndJoint, sCurve=None, sName='noname', sParent=None, sMaster=None):
    '''
    creates an ik spline handle, and handles the master attribute to make sure there's a separate
    solver node for each master'''


    # get master first:
    sMaster = None
    sNode = sStartJoint
    for i in range(100000):
        sParents = cmds.listRelatives(sNode, p=True, c=False)
        if not sParents:
            sMaster = sNode
            break
        else:
            sNode = sParents[0]

    # now create handle and take care of master attribute
    sHandle, sEff, sDefaultCurve = cmds.ikHandle(sj=sStartJoint, ee=sEndJoint, sol='ikSplineSolver', n=sName)
    sSolver = cmds.listConnections('%s.ikSolver' % sHandle, s=True, d=False)[0]
    sMasterAttr = '%s.master' % sSolver

    if not cmds.objExists(sMasterAttr):
        cmds.addAttr(sSolver, ln='master', dt='string')
        cmds.setAttr(sMasterAttr, sMaster, type='string')
    else:
        sSolverMaster = cmds.getAttr(sMasterAttr)
        if sSolverMaster != sMaster:
            sSolver = cmds.duplicate(sSolver)[0]
            cmds.connectAttr('%s.message' % sSolver, '%s.ikSolver' % sHandle, force=True)
            sMasterAttr = '%s.master' % sSolver
            cmds.setAttr(sMasterAttr, sMaster, type='string')

    # take care of the curve
    if sCurve:
        cmds.delete(sDefaultCurve)
        cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.inCurve' % sHandle)
    else:
        sCurve = sDefaultCurve

    if sParent:
        try:
            cmds.parent(sHandle, sParent)
        except:
            pass
    cmds.select(sHandle)

    return sHandle, sCurve


def createPointInfoNode(sCurve, fParam=0.0, sTargetPos=None, sName='noname', bFakePercentage=False, bLocal=False, sFullName=None):
    if sFullName == None:
        sFullName = 'pointOnCurveInfo_%s' % sName

    sNode = cmds.createNode('pointOnCurveInfo', n=sFullName)

    if bLocal:
        cmds.connectAttr('%s.local' % sCurve, '%s.inputCurve' % sNode)
    else:
        cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.inputCurve' % sNode)
    nodes._connectOrSet(fParam, '%s.parameter' % sNode)
    if bFakePercentage:
        cmds.setAttr('%s.turnOnPercentage' % sNode, True)
    if sTargetPos:
        cmds.connectAttr('%s.position' % sNode, sTargetPos)

    return sNode, '%s.position' % sNode


def createCurveIntersect(sCurve1, sCurve2, fDirection=[0,0,1], sTarget=None, sName='noname'):
    sNode = cmds.createNode('curveIntersect',  n='curveIntersect_%s' % sName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve1, '%s.inputCurve1' % sNode)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve2, '%s.inputCurve2' % sNode)
    cmds.setAttr('%s.useDirection' % sNode, True)
    nodes._connectOrSetVector(fDirection, '%s.direction' % sNode)
    sOutput = '%s.parameter1[0]' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sNode, sOutput


def createMotionPath(sCurve, fU=0, bLengthPerc=False, sName='noname', sTargetTransform=None, sTarget=None, sFullName=None):
    if sFullName == None:
        sFullName = 'motionPath_%s' % sName
    sMotionPath = cmds.createNode('motionPath', n=sFullName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.geometryPath' % sMotionPath)
    cmds.setAttr('%s.frontAxis' % sMotionPath, 0)
    cmds.setAttr('%s.upAxis' % sMotionPath, 2)
    nodes._connectOrSet(fU, '%s.uValue' % sMotionPath)
    if bLengthPerc:
        cmds.setAttr('%s.fractionMode' % sMotionPath, True)

    sOutput = '%s.allCoordinates' % sMotionPath

    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    if sTargetTransform:
        cmds.connectAttr(sOutput, '%s.t' % sTargetTransform)
        cmds.connectAttr('%s.r' % sMotionPath, '%s.r' % sTargetTransform)

    return sMotionPath, sOutput



def createClosestPointNode(sCurve, sPosition, sTargetPos=None, sTargetParam=None, sName='noname'):

    if utils.isStringOrUnicode(sPosition) and '.' not in sPosition:
        sPosition = nodes.createDecomposeMatrix('%s.worldMatrix' % sPosition, sName=sName)

    sNode = cmds.createNode('nearestPointOnCurve', n='nearestPointOnCurve_%s' % sName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.inputCurve' % sNode)
    nodes._connectOrSetVector(sPosition, '%s.inPosition' % sNode)
    if sTargetPos:
        cmds.connectAttr('%s.position' % sNode, sTargetPos)
    if sTargetParam:
        cmds.connectAttr('%s.parameter' % sNode, sTargetParam)

    return sNode, '%s.position' % sNode




def createCurveLengthNode(sCurve, sTarget=None, sName='noname', sSide='m', fNormalized=None, sDivide=None):
    sInfoNode = cmds.createNode('curveInfo', name=sName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.inputCurve' % sInfoNode)
    sOutput = '%s.arcLength' % sInfoNode

    if sDivide != None:
        sOutput = nodes.fromEquation('%s / %s' % (sOutput, sDivide), sName='%sDivide' % sName)

    if fNormalized != None:
        sOutput = nodes.fromEquation('%s * %f' % (sOutput, fNormalized/cmds.getAttr(sOutput)), sName='%sNormalize' % sName)

    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sInfoNode, sOutput


def getParamLength(sCurve):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    mKnots = fnCurve.knots()
    return mKnots[len(mKnots)-1]


def getPointsFromParams(sCurve, fParams=[], bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    iLenCvs = len(fParams)

    mPoints = OpenMaya2.MPointArray()
    mPoints.setLength(iLenCvs)
    for p, fParam in enumerate(fParams):
        mPoints[p] = fnCurve.getPointAtParam(fParam, space=OpenMaya2.MSpace.kWorld)

    result = [list(mP)[:3] for mP in mPoints]
    if bReturnNumpy:
        result = np.array(result, dtype='float64')
    return result


def getPointsFromPercs(sCurve, fPercs=[0.0, 0.1, 0.5, 0.9, 1.0], bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    fCurveLength = fnCurve.length()
    iLenCvs = len(fPercs)

    mPoints = OpenMaya2.MPointArray()
    mPoints.setLength(iLenCvs)
    for p, fPerc in enumerate(fPercs):
        fParam = fnCurve.findParamFromLength(fPerc * fCurveLength) # works in old api 2016
        mPoints[p] = fnCurve.getPointAtParam(fParam, space=OpenMaya2.MSpace.kWorld)

    result = [list(mP)[:3] for mP in mPoints]
    if bReturnNumpy:
        result = np.array(result, dtype='float64')
    return result


# bOldApi is only because in some cases the new MFNCurve.findParamFromLength() function errors for no reason
def getParamsFromPercs(sCurve, fPercs=[0.0, 0.1, 0.5, 0.9, 1.0], bOldApi=False):
    if bOldApi:
        fnCurve = OpenMaya.MFnNurbsCurve(utils.getDagPathOldApi(sCurve))
        fCurveLength = fnCurve.length()
        fParams = []
        for p, fPerc in enumerate(fPercs):
            fLength = fPerc * fCurveLength
            try:
                fParams.append(fnCurve.findParamFromLength(fLength))
            except Exception as e:
                print ('sCurve: ', sCurve)
                print ('fLength: ', fLength)
                raise Exception('Some mysterious maya bug is happening (old Api).. restart maya and run again. (%s)' % e)
    else:
        fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
        fCurveLength = fnCurve.length()
        fParams = []
        for p, fPerc in enumerate(fPercs):
            fLength = fPerc * fCurveLength
            try:
                fParams.append(fnCurve.findParamFromLength(fLength))
            except Exception as e:
                print ('sCurve: ', sCurve)
                print ('fLength: ', fLength)
                raise Exception('Some mysterious maya bug is happening.. restart maya and run again. (%s)' % e)
    return fParams



def rebuildWithCvCount(sCurve, iCvCount=5, iDegree=2, sNewName=None):
    if sNewName:
        sCurve = cmds.duplicate(sCurve, n=sNewName)[0]

    cmds.rebuildCurve(sCurve, d=iDegree, s=iCvCount-iDegree, end=True)

    return sCurve


def rebuildWithPercs(sCurve, fPercs=[0.0, 0.1, 0.5, 0.9, 1.0], iDegree=2, bCreateNew=False, sName=None, sParent=None, bFit=False, bOldApi=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    fLength = fnCurve.length()
    iLenCvs = len(fPercs)

    mPoints = OpenMaya2.MPointArray() # new cv points
    mPoints.setLength(iLenCvs)
    fParams = [None] * iLenCvs
    for p, fPerc in enumerate(fPercs):
        if fPerc <= 1.0:
            fParam = fnCurve.findParamFromLength(fPerc * fLength)
            mPoints[p] = fnCurve.getPointAtParam(fParam, space=OpenMaya2.MSpace.kWorld)
            fParams[p] = fParam
        elif fPerc > 1.0:
            mKnots = fnCurve.knots()
            fEndParam = mKnots[len(mKnots)-1]
            mPoints[p] = fnCurve.getPointAtParam(fEndParam, space=OpenMaya2.MSpace.kWorld) + \
                         fnCurve.tangent(fEndParam).normal() * ((fPerc-1.0) * fnCurve.length())

    mTargets = [OpenMaya2.MPoint(mP) for mP in mPoints]


    if bCreateNew:
        sDupl = cmds.duplicate(sCurve)[0]
        if sName:
            sDupl = cmds.rename(sDupl, sName)
        if sParent:
            try:
                cmds.parent(sDupl, sParent)
            except: pass
    else:
        sDupl = sCurve

    cmds.rebuildCurve(sDupl, d=iDegree, s=iLenCvs-iDegree, end=True)
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sDupl))
    fnCurve.setCVPositions(mPoints)


    fBiggestPerc = max(fPercs)
    fNewParams = getParamsFromPercs(sDupl, np.array(fPercs) / fBiggestPerc, bOldApi=bOldApi)

    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sDupl))

    if bFit:
        for iIter in range(5):
            for p, fPerc in enumerate(fPercs):
                if fPerc <= 1.0:
                    mCurrentCurvePoint = fnCurve.getPointAtParam(fNewParams[p], space=OpenMaya2.MSpace.kWorld)
                    mPoints[p] += mTargets[p] - mCurrentCurvePoint

            fnCurve.setCVPositions(mPoints)

    return sDupl





def getPercsFromTransforms(sCurve, sTransforms, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    
    fLengths = []
    for sT in sTransforms:
        mPoint = OpenMaya2.MPoint(cmds.xform(sT, q=True, ws=True, t=True))
        _, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        fLengths.append(fnCurve.findLengthFromParam(fParam) / fnCurve.length())
    
    if bReturnNumpy:
        return np.array(fLengths, dtype='float64')
    else:
        return fLengths


def getPercsFromPoints(sCurve, fPoints, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    fLengths = []
    for fP in fPoints:
        mPoint = OpenMaya2.MPoint(fP)
        _, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        fLengths.append(fnCurve.findLengthFromParam(fParam) / fnCurve.length())

    if bReturnNumpy:
        return np.array(fLengths, dtype='float64')
    else:
        return fLengths


def getPointsFromPoints(sCurve, fPoints, bReturnNumpy=False): # not tested yet
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    mPoints = OpenMaya2.MPointArray()
    mPoints.setLength(len(fPoints))
    for p,fP in enumerate(fPoints):
        mPoint = OpenMaya2.MPoint(fP)
        _, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        mPoints[p] = fnCurve.getPointAtParam(fParam, space=OpenMaya2.MSpace.kWorld)

    result = [list(mP)[:3] for mP in mPoints]
    if bReturnNumpy:
        result = np.array(result, dtype='float64')
    return result


def getDistancesFromPoints(sCurve, fPoints):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    mPoints = OpenMaya2.MPointArray()
    mPoints.setLength(len(fPoints))
    for p,fP in enumerate(fPoints):
        mPoint = OpenMaya2.MPoint(fP)
        _, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        mPoints[p] = fnCurve.getPointAtParam(fParam, space=OpenMaya2.MSpace.kWorld)

    aPoints = np.array([list(mP)[:3] for mP in mPoints], dtype='float64')
    aVectors = aPoints - np.array(fPoints, dtype='float64')
    aDistances = np.linalg.norm(aVectors, axis=-1)
    return aDistances



def getTangentsFromPoints(sCurve, fPoints, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    fTangents = []
    for fP in fPoints:
        mPoint = OpenMaya2.MPoint(fP)
        _, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        fTangents.append(list(fnCurve.tangent(fParam, space=OpenMaya2.MSpace.kWorld)))

    if bReturnNumpy:
        return np.array(fTangents, dtype='float64')
    else:
        return fTangents



def getTangentsFromPercs(sCurve, fPercs, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))
    fCurveLength = fnCurve.length()

    fTangents = []
    for fP in fPercs:
        fParam = fnCurve.findParamFromLength(fP * fCurveLength)
        fTangents.append(list(fnCurve.tangent(fParam, space=OpenMaya2.MSpace.kWorld)))

    if bReturnNumpy:
        return np.array(fTangents, dtype='float64')
    else:
        return fTangents


def getTangentsFromParams(sCurve, fParams, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    fTangents = []
    for fP in fParams:
        fTangents.append(list(fnCurve.tangent(fP, space=OpenMaya2.MSpace.kWorld)))

    if bReturnNumpy:
        return np.array(fTangents, dtype='float64')
    else:
        return fTangents


def getPercsFromParams(sCurve, fParams, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    fLengths = []
    for fP in fParams:
        fLengths.append(fnCurve.findLengthFromParam(fP) / fnCurve.length())  # not getting that in 2016

    if bReturnNumpy:
        return np.array(fLengths, dtype='float64')
    else:
        return fLengths



def getParamsFromPoints(sCurve, fPoints, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    fParams = []
    for fP in fPoints:
        mPoint = OpenMaya2.MPoint(fP)
        _, fP = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
        fParams.append(fP)

    if bReturnNumpy:
        return np.array(fParams, dtype='float64')
    else:
        return fParams



def getParamsFromTransforms(sCurve, sTransforms, bReturnNumpy=False):
    fnCurve = OpenMaya2.MFnNurbsCurve(utils.getDagPath(sCurve))

    fParams = []
    for sT in sTransforms:
        mPoint = OpenMaya2.MPoint(cmds.xform(sT, q=True, ws=True, t=True))
        _, fParam = fnCurve.closestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)

        fParams.append(fParam)

    if bReturnNumpy:
        return np.array(fParams, dtype='float64')
    else:
        return fParams


def createPoleVectorLine(cPole, sJoint, sExtraParents=[]):
    sLines = []
    for p,sParent in enumerate([cPole.sOut] + sExtraParents):
        sLine = cmds.curve(p=[[0, 0, 0], [1, 0, 0]], d=1, n=utils.getUniqueName('%sLine' % cPole.sOut), os=True)
        cmds.setAttr('%s.overrideEnabled' % sLine, True)
        cmds.setAttr('%s.overrideDisplayType' % sLine, 1)
        cmds.parent(sLine, sParent)
        if p == 0:
            cmds.setAttr('%s.t' % sLine, 0,0,0)
            cmds.aimConstraint(sJoint, sLine)
            nodes.createDistanceNode(sJoint, cPole.sOut, sTarget='%s.sx' % sLine, sDivide='%sX' % nodes.getScaleFromXform(cPole.sPasser))
        else:
            sMultMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sLines[0], '%s.worldInverseMatrix' % sParent])
            nodes.createDecomposeMatrix(sMultMatrix, sTargetPos='%s.t' % sLine, sTargetRot='%s.r' % sLine, sTargetScale='%s.s' % sLine)
        sLines.append(sLine)
    return sLines



def addShapeWithPoints(sTransform, aPoints, iDegree=1):
    sCurve = cmds.curve(d=iDegree, p=aPoints)
    sShape = cmds.listRelatives(sCurve, c=True, s=True)[0]
    sNewShape = cmds.parent(sShape, sTransform, s=True, add=True)
    sReturnShape = cmds.rename(sNewShape[0], '%sShape' % sTransform)
    utils.removeCurveShadingAttrs(sReturnShape)
    cmds.delete(sCurve)
    return sReturnShape


def getTrackedSelectedOrderedPoints(bReturnPoints=False):
    sSel = cmds.ls(orderedSelection=True, flatten=True)
    if bReturnPoints:
        aPoints = np.array([cmds.xform(sS, q=True, ws=True, t=True) for sS in sSel], dtype='float64')
        return aPoints
    else:
        return np.array([int(sS.split('[')[-1].split(']')[0]) for sS in sSel], dtype=int)


def getSelectedOrderedPoints(bReturnPoints=False, bForceOneLine=True):
    pSelection = patch.getSelectedPatches()
    if not pSelection:
        raise Exception('need to select vertices')

    pMesh = pSelection[0]
    if not utils.isNone(pMesh.aSofts):
        iInds = np.where(pMesh.aSofts == 1)[0]
        pMesh.aIds = pMesh.aIds[iInds]

    iNbsArray = pMesh.getNeighbors(bExcludeNeighborsNotInIds=True)
    aIdsMapper = utils.getIdsToIndicesMapper(pMesh.aIds)

    iNbsMapped = []
    for iNbs in iNbsArray:
        iNbsMapped.append([aIdsMapper[n] for n in iNbs])

    print('iNbsMapped before: ', iNbsMapped)
    # return

    iLeft = [0]
    iRight = [0]
    bLeftReachedEnd = False
    bRightReachedEnd = False

    xQueues = []
    for _ in range(pMesh.aIds.size): # just security, will likely cancel after first
        print('run')
        for i in range(pMesh.aIds.size): # maybe should go longer to make sure?
            if i == 0:
                iPair = iNbsMapped[iLeft[0]]
                if len(iPair) > 2:
                    raise Exception('need to select a line, can\'t have any forks or stars')
                iLeft.append(iPair[0])
                if len(iPair) == 1:
                    bRightReachedEnd = True
                elif len(iPair) == 2:
                    iRight.append(iPair[1])
                iNbsMapped[iLeft[0]] = None

            else:
                bDidSomething = False
                if not bLeftReachedEnd: # and len(iLeft) > i - 1: # if before we didn't assign anything, then this would fail
                    iPreviousInd = iLeft[-1]
                    iNextPair = iNbsMapped[iPreviousInd]
                    if iNextPair != None:
                        if len(iNextPair) == 1:
                            bLeftReachedEnd = True
                            bDidSomething = True
                        elif len(iNextPair) == 2:
                            iNextIndex = iNextPair[0] if iNbsMapped[iNextPair[1]] == None else iNextPair[1]
                            if iNextIndex != iLeft[-2]:
                                iLeft.append(iNextIndex)
                                bDidSomething = True
                        else:
                            raise Exception('need to select a line, can\'t have any forks or stars')
                        iNbsMapped[iPreviousInd] = None
                if not bRightReachedEnd and len(iRight) > i - 1:
                    iPreviousInd = iRight[-1]
                    iNextPair = iNbsMapped[iPreviousInd]
                    if iNextPair != None:
                        if len(iNextPair) == 1:
                            bRightReachedEnd = True
                            bDidSomething = True
                        elif len(iNextPair) == 2:
                            iNextIndex = iNextPair[0] if iNbsMapped[iNextPair[1]] == None else iNextPair[1]
                            if iNextIndex != iRight[-2]:
                                iRight.append(iNextIndex)
                                bDidSomething = True
                        else:
                            raise Exception('need to select a line, can\'t have any forks or stars')
                        iNbsMapped[iPreviousInd] = None

                if not bDidSomething:
                    break


        print('iNbsMapped after: ', iNbsMapped)

        bClosed = False
        iShrinkRight = 0
        for i in range(len(iRight)-1):
            if iRight[-(1+i)] in iLeft:
                iShrinkRight += 1
            else:
                break
        if iShrinkRight > 0:
            bClosed = True
            iRight = iRight[:-iShrinkRight]

        iLeft.reverse()
        iBoth = iLeft[:-1] + iRight
        xQueues.append(iBoth)

        bNothingLeft = True
        for i in range(len(iNbsMapped)):
            if iNbsMapped[i] != None:
                iLeft = [i]
                iRight = [i]
                bLeftReachedEnd = False
                bRightReachedEnd = False
                bNothingLeft = False
        if bNothingLeft:
            break
    print('xQueues: ,', xQueues)
    if len(xQueues) != 1:
        if bForceOneLine:
            raise Exception('more than one queues is not supported for getSelectedOrderedPoints(), use getTracktedSelectedOrderedPoints() instead')
        else:
            aPoints = pMesh.getPoints()
            print('aPoints: ', aPoints)
            xReturn = []
            for q,iPath in enumerate(xQueues):
                aPath = np.array(iPath, dtype=int)
                if bReturnPoints:
                    print('aPoints[aPath]: ', aPoints[aPath])
                    xReturn.append(aPoints[aPath])
                else:
                    xReturn.append(pMesh.aIds[aPath])
            return xReturn

    else:
        aPath = np.array(xQueues[0], dtype=int)

        if bReturnPoints:
            aPoints = pMesh.getPoints()
            return aPoints[aPath]
        else:
            return pMesh.aIds[aPath]

    '''
    
    import kangarooTools.curves as curves
    reload(curves)
    curves.createCurveFromSelectedVerts()

    '''


def createCurveFromSelectedVerts(sName='noname', sParent=None, fDirection=None, bTrackedSelectionOrder=False, iDegree=1):

    if bTrackedSelectionOrder:
        aPoints = getTrackedSelectedOrderedPoints(bReturnPoints=True)
    else:
        aPoints = getSelectedOrderedPoints(bReturnPoints=True)

    if fDirection != None:
        aDirection = np.array(fDirection)
        aCurveDirection = aPoints[-1] - aPoints[0]
        if np.sum(aDirection*aCurveDirection) < 0.0:
            aPoints = aPoints[::-1]


    sCurve = cmds.curve(p=aPoints, d=iDegree if len(aPoints) > 2 else 1, n=sName)
    if sParent:
        cmds.parent(sCurve, sParent)

    return sCurve


def separateCurveUsingSeparationLocs(sCurve, sLocA, sLocB, sCurveNameA, sCurveNameB, fDirection=[0,1,0]):
    import kangarooTools.xforms as xforms
    pCurve = patch.patchFromName(sCurve)
    aPoints = pCurve.getPoints()
    aCornerIds = xforms.getClosestIdsFromPoints(sCurve, [cmds.xform(sLocA, q=True, ws=True, t=True), cmds.xform(sLocB, q=True, ws=True, t=True)])
    if aCornerIds[1] > aCornerIds[0]:
        aCurve0 = np.arange(aCornerIds[0], aCornerIds[1]+1, 1)
        aCurve1 = np.concatenate([np.arange(aCornerIds[0], -1, -1), np.arange(len(aPoints)-1, aCornerIds[1]-1,-1)])
    else:
        aCurve0 = np.arange(aCornerIds[0], aCornerIds[1]-1, -1)
        aCurve1 = np.concatenate([np.arange(aCornerIds[0], len(aPoints), 1), np.arange(0,aCornerIds[1]+1,1)])

    aMiddle0 = aCurve0[len(aCurve0) // 2]
    aMiddle1 = aCurve1[len(aCurve1) // 2]
    aDirCurves = aPoints[aMiddle1]-aPoints[aMiddle0]

    fDot = np.sum(np.array(fDirection) * aDirCurves)
    if fDot < 0:
        aCurve0, aCurve1 = aCurve1, aCurve0

    iDegree = cmds.getAttr('%s.degree' % sCurve)
    sCurveA = cmds.curve(p=aPoints[aCurve0], n=sCurveNameA, d=iDegree)
    sCurveB = cmds.curve(p=aPoints[aCurve1], n=sCurveNameB, d=iDegree)
    fixShapeName(sCurveA)
    fixShapeName(sCurveB)
    return sCurveA, sCurveB

def abovePlane(aPoints, aPlanePoint, aPlaneNormal):
    aLocals = aPoints-aPlanePoint
    aDots = np.sum(aLocals*aPlaneNormal, axis=1)
    return np.where(aDots > 0, True, False)


def createCurveWithSeparationLocs(sName='curve_m_noname0', fDirection=[1,0,0], sParent=None):

    sNameToken = '_'.join(sName.split('_')[1:])
    sLocA = 'locA_%s' % sNameToken
    sLocB = 'locB_%s' % sNameToken
    if cmds.objExists(sName):
        sButtons = ['yes, keep them', 'no, redo them']
        if cmds.confirmDialog(title='keep old locators',
                               message='keep old locators for curve %s?' % sName,
                               button=sButtons,
                               defaultButton=sButtons[0], cancelButton=sButtons[1]) == sButtons[0]:
            fLocA = cmds.xform(sLocA, q=True, ws=True, t=True)
            fLocB = cmds.xform(sLocB, q=True, ws=True, t=True)
            bLocsExisted = True
        else:
            bLocsExisted = False
        cmds.delete(sName)
    else:
        bLocsExisted = False

    cmds.select(cmds.polyListComponentConversion(cmds.ls(sl=True), toVertex=True))
    aVertexLoop = getSelectedOrderedPoints(bReturnPoints=False)

    pSelection = patch.getSelectedPatches()
    aPoints = pSelection[0].getAllPoints()
    aIsAbove = abovePlane(aPoints[aVertexLoop], np.mean(aPoints[aVertexLoop], axis=0), np.array(fDirection, dtype='float64'))

    sCurve = cmds.curve(p=aPoints[aVertexLoop], d=1, n=sName)
    cmds.addAttr(sCurve, ln='brokenCircle', k=True)

    iDotIndexDistances = 2
    aLeftIds = aVertexLoop[(np.arange(len(aVertexLoop)) - iDotIndexDistances) % len(aVertexLoop)]
    aRightIds = aVertexLoop[(np.arange(len(aVertexLoop)) + iDotIndexDistances) % len(aVertexLoop)]

    aLeftLocals = aPoints[aLeftIds] - aPoints[aVertexLoop]
    aRightLocals = aPoints[aRightIds] - aPoints[aVertexLoop]
    aLeftLocals /= np.linalg.norm(aLeftLocals, axis=-1)[:,np.newaxis]
    aRightLocals /= np.linalg.norm(aRightLocals, axis=-1)[:,np.newaxis]
    aDots = np.sum(aLeftLocals * aRightLocals, axis=-1)

    aBelowInds = utils.findOneArrayInAnother(aVertexLoop, aVertexLoop[~aIsAbove])
    aAboveInds = utils.findOneArrayInAnother(aVertexLoop, aVertexLoop[aIsAbove])

    aBelowDots = aDots[aBelowInds]
    aAboveDots = aDots[aAboveInds]

    iStrongestBelowDotInd = np.argmax(aBelowDots)
    iStrongestAboveDotInd = np.argmax(aAboveDots)

    aTwoCornerInds = [aAboveInds[iStrongestAboveDotInd], aBelowInds[iStrongestBelowDotInd]]
    if aTwoCornerInds[1] > aTwoCornerInds[0]:
        aBotLoop = aVertexLoop[aTwoCornerInds[0]:aTwoCornerInds[1]+1]
        aTopLoop = np.concatenate([aVertexLoop[aTwoCornerInds[1]:], aVertexLoop[0:aTwoCornerInds[0]+1]])
    else:
        aBotLoop = aVertexLoop[aTwoCornerInds[1]:aTwoCornerInds[0]+1]
        aTopLoop = np.concatenate([aVertexLoop[aTwoCornerInds[0]:], aVertexLoop[0:aTwoCornerInds[1]+1]])

    aBotPoints = aPoints[aBotLoop]
    aTopPoints = aPoints[aTopLoop]

    if np.mean(aBotPoints, axis=0)[1] > np.mean(aTopPoints, axis=0)[1]:
        aBotPoints, aTopPoints = aTopPoints, aBotPoints

    if aBotPoints[0,0] > aBotPoints[-1,0]:
        aBotPoints = aBotPoints[::-1]
    if aTopPoints[0,0] > aTopPoints[-1,0]:
        aTopPoints = aTopPoints[::-1]

    #now check with Direction


    sLocA = cmds.spaceLocator(n=sLocA)[0]
    sLocB = cmds.spaceLocator(n=sLocB)[0]
    if bLocsExisted:
        cmds.setAttr('%s.t' % sLocA, *fLocA)
        cmds.setAttr('%s.t' % sLocB, *fLocB)
    else:
        aDirection = np.array(fDirection)
        aBotCurveDirection = aBotPoints[-1] - aBotPoints[0]
        if np.sum(aDirection * aBotCurveDirection) < 0.0:
            aBotPoints = aBotPoints[::-1]
        cmds.setAttr('%s.t' % sLocA, *list(aBotPoints[0]))
        cmds.setAttr('%s.t' % sLocB, *list(aBotPoints[-1]))


    fLength = getLength(sCurve)
    fScale = fLength*0.025
    for sL in [sLocA,sLocB]:
        sShape = cmds.listRelatives(sL, c=True, s=True)[0]
        for sAttr in ['localScaleX', 'localScaleY', 'localScaleZ']:
            cmds.setAttr('%s.%s' % (sShape, sAttr), fScale)

    if sParent:
        cmds.parent(sLocA, sLocB, sCurve, sParent)
    fixShapeName(sCurve)
    return sCurve, sLocA, sLocB



def mirrorIfNotExists(sCurve, sMirrorMesh=None, aMirrorTable=None, sErrorAddition=''):
    '''
    returns the mirrored one - different to xforms.mirrorIfNotExists()
    '''

    import kangarooTools.xforms as xforms
    import kangarooTabTools.geometry as geometry

    if cmds.objExists(sCurve):
        return sCurve
    sMirror = utils.getMirrorName(sCurve)
    if not cmds.objExists(sMirror):
        raise Exception('%s doesn\'t exist, and its mirror (%s) doesn\'t exist either.\n %s' % (sCurve, sMirror, sErrorAddition))
    geometry.meshMirrorNoBase([patch.patchFromName(sMirror)])

    if sMirrorMesh:
        aMeshPoints = patch.patchFromName(sMirrorMesh).getPoints()
        pMirror = patch.patchFromName(sMirror)
        aPoints = pMirror.getPoints()
        aClosestPoints = xforms.getClosestIdsFromPoints(sMirrorMesh, aPoints)
        aOffsets = aPoints-aMeshPoints[aClosestPoints]
        aOffsets[0] *= -1.0
        aOpposites = aMeshPoints[aMirrorTable[0][aClosestPoints]] + aOffsets
        patch.patchFromName(sCurve).setPoints(aOpposites)


    return sCurve




def intersectionOneDegreeCurveAndPlane(sCurve, planePoint, planeNormal, epsilon=1e-6):

    aPlaneNormal = np.array(planeNormal, dtype='float64')
    aPlainPoint = np.array(planePoint, dtype='float64')
    aPoints = np.array(cmds.xform('%s.cv[*]' % sCurve, q=True, ws=True, t=True), dtype='float64').reshape(-1,3)
    aDiffs = aPoints[1:] - aPoints[:-1]
    aLengths = np.linalg.norm(aDiffs, axis=-1)
    aDirections = aDiffs / aLengths[:,np.newaxis]

    ndotus = np.sum(aPlaneNormal * aDirections, axis=-1)
    aParallels = abs(ndotus) < epsilon
    ndotus[aParallels] = 1.0
    ws = aPoints[:-1] - aPlainPoint
    aDistances = -np.sum(aPlaneNormal*ws, axis=-1) / ndotus

    aVector = aDistances[:,np.newaxis] * aDirections
    aIntersectionsOnRays = ws + aVector + aPlainPoint

    aInRange = (aDistances < aLengths) & (aDistances >= 0.0) & (aParallels == False)

    return aIntersectionsOnRays[aInRange]




def makeCurveGoThroughCvs(sCurve, iIterations=5):
    pCurve = patch.patchFromName(sCurve)
    aTargetCvPoints = pCurve.getPoints()
    fParams = getParamsFromPoints(sCurve, aTargetCvPoints)

    aCurrentCvPoints = aTargetCvPoints
    for i in range(iIterations):
        aCurrentPoints = getPointsFromParams(sCurve, fParams)
        aDifferences = aTargetCvPoints - aCurrentPoints
        pCurve.setPoints(aCurrentCvPoints + aDifferences)
        aCurrentCvPoints = pCurve.getPoints()



def selectAllCvsSelected(bIncludeSurfaces=False):
    sSel = cmds.ls(sl=True)
    sCurves = list(set([sS.split('.')[0] for sS in sSel]))
    sCvs = ['%s.cv[*]' % sC for sC in sCurves]
    sCvs += ['%s.cv[*][*]' % sC for sC in sCurves]
    sCvs = [sCv for sCv in sCvs if cmds.objExists(sCv)]
    cmds.select(sCvs)


def createMuscleSpline(sName, sSide, sTransforms, sCtrl, iNumJoints=4):
    sSplineShape = cmds.createNode('cMuscleSpline', n='muscleSpline_%s_%sShape' % (sSide,sName))
    sSpline = cmds.listRelatives(sSplineShape, p=True)[0]
    sSpline = cmds.rename(sSpline, 'muscleSpline_%s_%s' % (sSide,sName))

    for i in range(len(sTransforms)):
        cmds.setAttr('%s.ocdata[%d].opy' % (sSplineShape,i), 1)
        cmds.setAttr('%s.ocdata[%d].opjy' % (sSplineShape,i), 1)
        cmds.setAttr('%s.ocdata[%d].otgy' % (sSplineShape,i), 1)
        cmds.setAttr('%s.ocdata[%d].oux' % (sSplineShape,i), 1)

    for i in range(len(sTransforms)):
        cmds.connectAttr('%s.worldMatrix' % sTransforms[i], '%s.controlData[%d].insertMatrix' % (sSplineShape,i))

    for sAttr in ['tangentLength', 'jiggle', 'jiggleX', 'jiggleY', 'jiggleZ', 'rest', 'jiggleImpactStart', 'jiggleImpactStop', 'jiggleImpact']:
        sFrom = utils.addAttr(sCtrl, at='double', ln=sAttr, k=True)
        sTo = '%s.controlData[1].%s' % (sSplineShape, sAttr)
        cmds.setAttr(sFrom, cmds.getAttr(sTo))
        cmds.connectAttr(sFrom, sTo)

    sJoints = []
    for i in range(iNumJoints):
        u = i / (iNumJoints - 1.0)
        sJoint = cmds.createNode('joint', n= 'muscleJnt_%s_%sSpline_%03d' % (sSide,sName,i))
        cmds.setAttr('%s.readData[%d].readU' % (sSplineShape,i), u)
        cmds.setAttr('%s.readData[%d].readRotOrder' % (sSplineShape,i), cmds.getAttr('%s.ro' % sJoint))
        cmds.connectAttr('%s.outputData[%d].outTranslate' % (sSplineShape,i), '%s.t' % sJoint)
        cmds.connectAttr('%s.outputData[%d].outRotate' % (sSplineShape,i), '%s.r' % sJoint)
        sJoints.append(sJoint)

    return sSpline, sJoints




qCurvesDialog = None
def createSpineCurves(sName=None, sParent=None):
    global qCurvesDialog

    def _curvesSel(_sName):
        try:
            cmds.undoInfo(openChunk=True)
            if '_' not in _sName:
                _sName = 'm_%s' % _sName
            cmds.select(cmds.polyListComponentConversion(tv=True))

            aaLines = getSelectedOrderedPoints(bReturnPoints=True, bForceOneLine=False)
            if len(aaLines) != 2:
                raise Exception('there need to be 2 loops selected')
            if np.linalg.norm(aaLines[0][0] - aaLines[1][0]) > np.linalg.norm(aaLines[0][0] - aaLines[1][-1]):
                aaLines[1] = aaLines[1][::-1]
            sCurveA = cmds.curve(p=aaLines[0], d=2)
            sCurveB = cmds.curve(p=aaLines[1], d=2)
            fLength = getLength(sCurveA)
            sCurveC = cmds.duplicate(sCurveA, n='bpCurve_%s' % _sName)[0]
            cmds.blendShape(sCurveB, sCurveC, w=[0,0.5])
            aMidLine = patch.patchFromName(sCurveC).getPoints()
            aDelta = aaLines[1] - aMidLine
            aDeltaNorm = aDelta / (np.linalg.norm(aDelta, axis=-1)[:,np.newaxis])

            aPoleLine = aMidLine + aDeltaNorm * 1.5 #fLength*0.1
            sPoleCurve = cmds.curve(p=aPoleLine, d=2, n='bpUpCurve_%s' % _sName)
            cmds.delete(sCurveA, sCurveB)
            cmds.select(sCurveC, sPoleCurve)
            if sParent:
                cmds.parent(sCurveC, sPoleCurve, sParent)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


    if sName == None:
        qCurvesDialog = utilsQt.QGetStringDialog(_curvesSel, sMessage='enter module name')
        qCurvesDialog.show()
    else:
        _curvesSel(sName)

def setLineWidth(sCurve, fWidth=1.0):
    cmds.setAttr('%sShape.lineWidth' % sCurve, fWidth)