###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np

import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.nodes as nodes
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers


class LSingleBone(baseLimb._LBaseLimb):
    def __init__(self, sName='singleBone', sSide='m',
                bRemoveEndSkinJoint=False, bForceParentSkeletonToRoot=False, iSegmentsPriority=-1, bIsBpBarent=False, bPostRefJoint=False, sBlueprintMirrorPlane=''):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide, bRemoveEndSkinJoint=bRemoveEndSkinJoint,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,bIsBpBarent=bIsBpBarent, sBlueprintMirrorPlane=sBlueprintMirrorPlane)

        self.bPostRefJoint = bPostRefJoint

        self.dOutputs['main'] = None
        self.dOutputs['end'] = None

        # self.bSegmentPlanes = bSegmentPlanes
        self.iSegmentsPriority = iSegmentsPriority

        self.sDefaultFeatures = ['feature_fk']



    def getDefaultParentOutput(self):
        return 'main'


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':False},
                'scale': {'sTrs':'s', 'bMulti':False}}


    def generateAttachers_fk(self, **kwargs):
        return {'main': {'sTrs':'tr', 'bMulti':True}}


    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(0,0,0, 0,0,-1), (0,1,0, 0,0,-1)]], [['main', 'end']])
        self.sBlueprintJoints = [self.dBlueprints[sN] for sN in ['main', 'end']]
        return sNewJoints


    def feature_fk(self, sCtrlShape='cube', fScaleCtrlShape=(1.0, 1.0, 1.0), fAdjustAxisOrientation=[0,0,0], iColorIndex=1,
                   bAddSuperCtrl=False, bAddPivotCtrl=False, bAddChildCtrl=False, sDoRotation='xyz', iRotateOrder=2, sDoTranslation='xyz', sDoScale='', iSlider=2, bAddRotationOrderAttribute=True,
                   bSpring=False, bOrientToNearestStraightMatrix=False, iFaceExtraMove=0, _dComboboxItems={'iSlider':['off', 'on', 'on negate right'], 'iFaceExtraMove':['off', 'Bend Ctrls']}):


        dAttacherBuildData = {}

        fks = xforms.duplicateJoinChain(self.sBlueprintJoints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)

        sAttrs = []
        sAttrs += ['t%s' % a for a in set(sDoTranslation)]
        sAttrs += ['r%s' % a for a in set(sDoRotation)]
        if sDoScale == 'uniform':
            sAttrs.append('scaleUF')
        else:
            sAttrs += ['s%s' % a for a in set(sDoScale)]
        if not bAddRotationOrderAttribute:
            sAttrs.append('ro')


        if sCtrlShape == 'square': # let's remove that in future
            sCtrlShape = 'squareY'

        if sCtrlShape == 'wedge':
            self.cCtrl = self._createCtrl7(sName='', sMatch=self.dBlueprints['main'], sAttrs=sAttrs, iColorIndex=iColorIndex, iSlider=iSlider,
                                        fSize=cmds.getAttr('%s.radius' % self.dBlueprints['main'])*5, sShape='wedge', fRotateShape=(0,0,-90),
                                        bSuper=bAddSuperCtrl, bPivot=bAddPivotCtrl, bChild=bAddChildCtrl, iRotateOrder=iRotateOrder)
        elif sCtrlShape == 'sphere':
            self.cCtrl = self._createCtrl7(sName='', fSize=cmds.getAttr('%s.radius' % self.dBlueprints['main'])*5, sAttrs=sAttrs, iSlider=iSlider,
                             sMatch=self.dBlueprints['main'], iRotateOrder=iRotateOrder, iColorIndex=iColorIndex,
                             sShape='sphere', bSuper=bAddSuperCtrl, bPivot=bAddPivotCtrl, bChild=bAddChildCtrl)
        else:
            self.cCtrl = self._createCtrl7(sName='', sMatch=self.dBlueprints['main'], sAttrs=sAttrs, bSuper=bAddSuperCtrl, bPivot=bAddPivotCtrl, bChild=bAddChildCtrl, iSlider=iSlider,
                                          iColorIndex=iColorIndex, sShape=sCtrlShape, fSize=cmds.getAttr('%s.radius' % self.dBlueprints['main'])*5, fScaleShape=fScaleCtrlShape, iRotateOrder=iRotateOrder)


        if bOrientToNearestStraightMatrix:
            self.cCtrl.orientToNearestStraightMatrix()


        if bSpring:
            sEnable = utils.addOffOnAttr(self.cCtrl.sCtrl, 'springEnable', bDefaultValue=False, bNoAnim=True)
            # sStartFrame = utils.addAttr(self.cCtrl.sCtrl, ln='springStartFrame', at='long', defaultValue=1, k=False, cb=True)
            sStartFrame = utils.addAttr('master', ln='dynamicsStartFrame', at='long', defaultValue=1, k=False, cb=True, bReturnIfExists=True)

            sStrength = utils.addAttr(self.cCtrl.sCtrl, ln='springStrength', minValue=0.0, maxValue=1.0,
                                      defaultValue=1.0, k=True)
            sStrengthEnable = nodes.createConditionNode(sEnable, '==', 1, sStrength, 0.0)
            sStiffness = utils.addAttr(self.cCtrl.sCtrl, ln='springStiffness', minValue=0.0, maxValue=1.0,
                                       defaultValue=0.1, k=True)
            sSpringOffset = self.cCtrl.appendOffsetGroup('spring')
            sDamping = utils.addAttr(self.cCtrl.sCtrl, ln='springDamping', minValue=0.0, maxValue=1.0, defaultValue=0.1, k=True)
            sPrevFrame = utils.addAttr(self.cCtrl.sCtrl, ln='springPrevFrame', minValue=0.0, maxValue=1.0, defaultValue=0)
            utils.addAttr(self.cCtrl.sCtrl, ln='velocityX')
            utils.addAttr(self.cCtrl.sCtrl, ln='velocityY')
            utils.addAttr(self.cCtrl.sCtrl, ln='velocityZ')
            sVelocity = '%s.velocity' % self.cCtrl.sCtrl

            sPosOut = xforms.createLocator(self._createNodeName('springOut', 'loc'), sParent=self.cCtrl.sPasser)
            cmds.setAttr('%s.inheritsTransform' % sPosOut, False)

            sTargetWorld = cmds.createNode('transform', n=self._createNodeName('springIn', 'grp'), p=self.cCtrl.sPasser)
            sPosDefault = cmds.createNode('transform', n=self._createNodeName('springDefault', 'grp'), p=self.cCtrl.sPasser)
            cmds.setAttr('%s.inheritsTransform' % sTargetWorld, False)
            cmds.delete(cmds.pointConstraint(self.dBlueprints['end'], sTargetWorld))
            cmds.delete(cmds.pointConstraint(self.dBlueprints['end'], sPosDefault))
            cmds.parentConstraint(cmds.listRelatives(sSpringOffset, p=True)[0], sTargetWorld, mo=True)

            sN, sA = sStrengthEnable.split('.')
            xforms.constraintBlend(sSpringOffset, sPosDefault, sPosOut, sN, sA, func=cmds.aimConstraint)
            utils.addStringAttr(self.cCtrl.sCtrl, 'sDynamicJoint', sSpringOffset)

            sExpr = '''

    if (frame == {5})
    {{
        {2}X = 0;
        {2}Y = 0;
        {2}Z = 0;
        {4}.tx = {3}.tx;
        {4}.ty = {3}.ty;
        {4}.tz = {3}.tz;
    }}
    else
    {{
        vector $target = <<{3}.translateX, {3}.translateY, {3}.translateZ>>;
        vector $vel = <<{2}X, {2}Y, {2}Z>>;
        vector $posDyn = <<{4}.translateX, {4}.translateY, {4}.translateZ>>;

        $acc = ($target - $posDyn) * {0} - $vel * {1};
        $vel += $acc;

        $posDyn += $vel;

        {4}.tx = $posDyn.x;
        {4}.ty = $posDyn.y;
        {4}.tz = $posDyn.z;
        {2}X = $vel.x;
        {2}Y = $vel.y;
        {2}Z = $vel.z; 
    }}
    {6} = frame;

                '''.format(sStiffness, sDamping, sVelocity, sTargetWorld, sPosOut, sStartFrame, sPrevFrame)
            sExpression = cmds.expression(s=sExpr, ae=True, n=self._createNodeName('spring', 'exp'))
            nodes.createConditionNode(sEnable, '==', True, 0, 1, sTarget='%s.nodeState' % sExpression)


        if self.bPostRefJoint:
            sRefJ = cmds.createNode('joint', n=self._createNodeName('ref', 'jnt'), p=self.cCtrl.sPasser)
            cmds.setAttr('%s.radius' % sRefJ, self.fBlueprintsDiagonal * 0.025)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sRefJ)

            utils.addStringAttr(fks[0], deformers.kPostRefJointAttr, sRefJ)
            if not cmds.objExists('jnt_m_zero'):
                cmds.createNode('joint', n='jnt_m_zero', p='modules')



        if np.any(fAdjustAxisOrientation):
            self.cCtrl.adjustAxisOrientation(fAdjustAxisOrientation, bRotateShape=True)

        if iFaceExtraMove:
            import kangarooTabTools.ctrls6 as ctrls6
            sExtraMove = self.cCtrl.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
            xforms.matrixParentConstraint(self.cCtrl.sOut, fks[0], skipScale=[], sJumpOverTransforms=[sExtraMove, self.cCtrl.sPasser])
        else:
            xforms.matrixParentConstraint(self.cCtrl.sOut, fks[0], skipScale=[])

        sAttacherOffset = self.cCtrl.appendOffsetGroup('attacher')
        dAttacherBuildData['root'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)
        dAttacherBuildData['main'] = (utils.getDagPath(sAttacherOffset), self.cCtrl)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)

        cmds.addAttr(fks[0], ln='_forceKeepForGames_', k=True)

        return fks, [self.cCtrl], dAttacherBuildData



    def unreal_feature_fk(self):
        if self.sLimbName == 'm_global':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal

            sCommands = []
            sCommands.append('controllers.setNewColumn()')

            utilsUnreal.createUnrealCtrl(self.cCtrl, sWriteCommands=sCommands)

            utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk', sWriteCommands=sCommands)

            sJoint = self.getOutputFullNames()[0]
            sFunctionNodeName = '%s_feature_fk_node' % self.sLimbName
            sCommands.append(f"{sFunctionNodeName} = functions.createSingleBoneFunction({self.cCtrl.sCtrl}, '{sJoint}')")

            utilsUnreal.initiateAttacherDictCommand('feature_fk', sWriteCommands=sCommands)
            utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, sWriteCommands=sCommands)

            return sCommands, [], []



    def unrealBackwards_feature_fk(self):
        import kangarooTools.utilsUnreal as utilsUnreal

        sCommands = []
        sCommands.append('controllers.setNewColumn()')


        utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk', sWriteCommands=sCommands)

        sJoint = self.getOutputFullNames()[0]
        sFunctionNodeName = '%s_feature_fk_node' % self.sLimbName
        sCommands.append(f"{sFunctionNodeName} = functions.createSingleBoneFunction_BACKWARDS({self.cCtrl.sCtrl}, '{sJoint}')")

        utilsUnreal.initiateAttacherDictCommand('feature_fk', sWriteCommands=sCommands)
        utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, sWriteCommands=sCommands)

        return sCommands




    def buildBlueprintRig(self, lParent=None):
        # reload(blueprints)
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        # if self.sLimbName == 'r_eye':
        #     print 'self.dMirrorOrients: ', self.dMirrorOrients
        #     print "self.dBlueprints['main']", self.dBlueprints['main']

        cCtrls = blueprints.createChainCtrls([self.dBlueprints['main'], self.dBlueprints['end']],
                                                sSide=self.sSide,
                                                dMirrorOrients=self.dMirrorOrients,
                                                xRoot='%sMain' % self.sName,
                                                xAim='%sMainEnd' % self.sName,
                                                xPole='%sPole' % self.sName,
                                                sParent=self.sBpTopGrp)

        self.cBpRoots = [cCtrls[0]]
        # del self.cBpRoots[-2]
        self.cBpAll = cCtrls


        self.dBpOutputs['main'] = cCtrls[0]
        self.dBpOutputs['end'] = cCtrls[1]

        self.cBpSymmetry = cCtrls
        self.cLastBp = cCtrls[1]



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        # if not self.bSegmentPlanes:
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'bDisable':True})
        # else:
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'iPriority':self.iSegmentsPriority})
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'bIsRoot':self.bSegmentsRoot})



