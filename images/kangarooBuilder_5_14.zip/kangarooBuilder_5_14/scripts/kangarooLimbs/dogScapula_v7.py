###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.utilFunctions as utils
import kangarooTools.constraints as constraints
import kangarooTabTools.segments as segments
import kangarooLimbs.baseLimb as baseLimb



class LDogScapula(baseLimb._LBaseLimb):

    def __init__(self, sName='scapula', sSide='l', #bMirror=False,
                bForceParentSkeletonToRoot=False, iSegmentsPriority=50, sDisplayAttr='display_ctrl.body'):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     bRemoveEndSkinJoint=False, iSegmentsPriority=iSegmentsPriority)
        self.dOutputs['start'] = None
        self.dOutputs['end'] = None
        self.tArm = None
        self.sDefaultFeatures = ['feature_fk']

        self.sDisplayAttr = sDisplayAttr
        self.cDisplayCtrls = []


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':True},
                'scale': {'sTrs':'s', 'bMulti':False}}

    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(5,-5,5, 0,0,1), (5, 0, 0, 0,0,1)], [(-15.2,0,1.5, 0,0,1)]], [['start', 'end'], ['pivot']])
        return sNewJoints


    def feature_fk(self, fHorizLinearFront=0.5, fHorizLinearBack=1.0, fPivotOnEnd=1.0, iOrientToNearestStraightMatrix=0, _dComboboxItems={'iOrientToNearestStraightMatrix': ['off', 'on', 'maintainWorldY']}):

        dAttacherBuildData = {}
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end', 'pivot']]

        sFkJoints = xforms.duplicateJoinChain(sBlueprints[0:2], sPostfix='fk', sParent=self.sCurrentFeatureGrp)
        fSize = cmds.getAttr('%s.radius' % sBlueprints[1]) * 10.0
        self.cCtrl = self._createCtrl9(sName='', sMatch=self.dBlueprints['start'], sAttrs=['rx', 'ty', 'tz'], sShape='cube',
                               fSize=fSize, bChild=True, fTranslateShape=(0, fSize*0.5, 0))

        self.cCtrl.adjustAxisOrientation([0,-90,-90])

        aaBlueprints = xforms.getPositionArray(sBlueprints[0:2])
        aPivotPos = aaBlueprints[1] * fPivotOnEnd + aaBlueprints[0] * (1.0-fPivotOnEnd)
        cmds.setAttr('%s.t' % self.cCtrl.sPasser, *list(aPivotPos))

        if iOrientToNearestStraightMatrix == 1:
            xforms.orientToNearestStraightMatrix(self.cCtrl.sPasser, bFromLocal=False)
        elif iOrientToNearestStraightMatrix == 2:
            xforms.alignToWorldAxis(self.cCtrl.sPasser, bNegative=self.sSide=='r')

        self.sAutoConstrainer = self.cCtrl.appendOffsetGroup('auto', bBelowPivot=True)
        sSlideUpDownAttr = utils.addAttr(self.cCtrl.sCtrl, ln='slideUpDown', k=True)
        sSlideUpDownGrp = xforms.insertParent(self.cCtrl.sOut, sName=self._createNodeName('upDown', 'grp'), bMatchParentTransform=True)
        cmds.connectAttr(sSlideUpDownAttr, '%s.ty' % sSlideUpDownGrp)

        sPushOutAttr = utils.addAttr(self.cCtrl.sCtrl, ln='pushOut', k=True)
        sRotzAttr = utils.addAttr(self.cCtrl.sCtrl, ln='rotOut', k=True)
        sTwistAttr = utils.addAttr(self.cCtrl.sCtrl, ln='twist', k=True)

        # ribcagePivot is the magic transform that gets aimed, and moved back/forward based on the linear settings
        #
        self.sRibcagePivotPoint = self._createTransform(sName='ribcagePivotPoint', sMatch=self.dBlueprints['pivot'], sParent=self.cCtrl.sPasser)

        # the regular attachments...
        #
        dAttacherBuildData['root'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.sRibcagePivotPoint)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cCtrl.sPasser)

        # calculate how much linear should be
        #
        sHorizLinearFront = utils.addAttr(self.cCtrl.sPasser, ln='horizLinearFront', k=True, min=0, max=1, dv=fHorizLinearFront)
        sHorizLinearBack = utils.addAttr(self.cCtrl.sPasser, ln='horizLinearBack', k=True, min=0, max=1, dv=fHorizLinearBack)
        sBackForward = '%sZ' % nodes.createPointByMatrixNode(nodes.getWorldPoint(self.cCtrl.sOut), '%s.worldInverseMatrix' % self.cCtrl.sPasser)
        sHorizLinear = nodes.createConditionNode(sBackForward, '<' if self.sSide == 'l' else '>', 0, sHorizLinearFront, sHorizLinearBack)

        # move the ribcagePivot in Z by how much sHorizLinear there is
        #
        sDecompCtrl = nodes.createDecomposeMatrix('%s.worldMatrix' % self.cCtrl.sOut)
        sDecompPasser = nodes.createDecomposeMatrix('%s.worldMatrix' % self.cCtrl.sPasser, bReturnRotate=True)
        sCtrlNoRot = nodes.createComposeMatrixNode(xTranslate=sDecompCtrl, xRotate=sDecompPasser)
        fRigCagePivotOffset = nodes.createPointByMatrixNode(nodes.getWorldPoint(self.sRibcagePivotPoint), nodes.createInverseMatrix(sCtrlNoRot, bJustValues=True), bJustValues=True)

        sRigCagePivotOffsetScaled = nodes.createVectorMultiplyNode(fRigCagePivotOffset, '%sX' % nodes.getScaleFromXform(self.cCtrl.sPasser), bVectorByScalar=True)
        sWorldRibcage = nodes.createPointByMatrixNode(sRigCagePivotOffsetScaled, sCtrlNoRot)
        sLocalRibcagePivotAttachedToCtrl = nodes.createPointByMatrixNode(sWorldRibcage, '%s.worldInverseMatrix' % self.cCtrl.sPasser)
        nodes.createBlendNode(sHorizLinear, '%sZ' % sLocalRibcagePivotAttachedToCtrl, cmds.getAttr('%sZ' % sLocalRibcagePivotAttachedToCtrl), sTarget='%s.tz' % self.sRibcagePivotPoint)

        # aimConstraint the ribcagePivot to the ctrl out, and also take its up vector
        #
        sAimConstraint = constraints.aimConstraintEmpty(self.sRibcagePivotPoint)
        nodes.createPointByMatrixNode(nodes.getWorldPoint(self.cCtrl.sOut), '%s.worldInverseMatrix' % self.cCtrl.sPasser, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
        nodes.createMultMatrixNode(['%s.worldMatrix' % self.cCtrl.sOut, '%s.worldInverseMatrix' % self.cCtrl.sPasser], sTarget='%s.worldUpMatrix' % sAimConstraint)


        cRevPoint = self._createCtrl9(sName='_revPoint', sMatch=self.dBlueprints['start'], sAttrs=['t'], sShape='cube',
                               fSize=fSize, fTranslateShape=(0, fSize*0.5, 0), iColorIndex=1)
        cRevPoint.adjustAxisOrientation([0,-90,-90])
        cSecondary = self._createCtrl9(sName='_secondary', sMatch=self.dBlueprints['start'], sAttrs=['t', 'r'], sShape='cube',
                               fSize=fSize * 0.9, fTranslateShape=(0, fSize*0.5, 0), iColorIndex=1, sParent=cRevPoint.sOut)
        cSecondary.adjustAxisOrientation([0,-90,-90])

        # use matrix nodes to constrain attach the sFkJoints[0] to the aiming Ribcage, with the added sPushOutAttr, sTwistAttr and sRotzAttr
        #
        fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cRevPoint.sPasser, '%s.worldInverseMatrix' % self.sRibcagePivotPoint], bJustValues=True)
        sJointMatrix = nodes.createMultMatrixNode([fOffset,
                                                   '%s.worldMatrix' % self.sRibcagePivotPoint,
                                                   '%s.parentInverseMatrix' % cRevPoint.sPasser], sName=self._createNodeName('attachJointAndAddExtraAnimAttrs', 'multMatrix'))

        sTopPivotInSecondaryPasser = nodes.createMultMatrixNode(['%s.worldMatrix' % self.cCtrl.sPasser, '%s.worldInverseMatrix' % cRevPoint.sPasser], bJustValues=True)
        sJointMatrix2 = nodes.createMultMatrixNode([nodes.createInverseMatrix(sTopPivotInSecondaryPasser, bJustValues=True),
                                    nodes.createComposeMatrixNode([nodes.createMultiplyNode(sPushOutAttr, self.fSideMultipl), 0, 0], [0, sTwistAttr, sRotzAttr]),
                                    sTopPivotInSecondaryPasser,
                                    sJointMatrix,
                                    ])

        nodes.createDecomposeMatrix(sJointMatrix2, sTargetPos='%s.t' % cRevPoint.sPasser, sTargetRot='%s.r' % cRevPoint.sPasser, sTargetScale='%s.s' % cRevPoint.sPasser)


        fAimInPasser = nodes.createPointByMatrixNode(nodes.getWorldPoint(sFkJoints[1]), '%s.worldInverseMatrix' % cRevPoint.sPasser, bJustValues=True)
        # sCtrlInPasser = nodes.createMultMatrixNode(['%s.worldMatrix' % cRevPoint.sCtrl, '%s.worldInverseMatrix' % cRevPoint.sPasser])
        # sNonRotateCtrlInPasser = nodes.createPickMatrixNode(sCtrlInPasser, bTranslate=True)
        # sAimInNonRotatePasser = nodes.createPointByMatrixNode(fAimInPasser, nodes.createInverseMatrix(sNonRotateCtrlInPasser))
        # sAimTarget = nodes.createPointByMatrixNode(sAimInNonRotatePasser, '%s.worldMatrix' % cRevPoint.sCtrl)

        sAimTarget = nodes.createPointByMatrixNode(fAimInPasser, '%s.worldMatrix' % cRevPoint.sPasser)


        fAimStartMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sFkJoints[0], '%s.worldInverseMatrix' % cRevPoint.sCtrl], bJustValues=True)
        sAimStartMatrix = nodes.createMultMatrixNode([fAimStartMatrix, '%s.worldMatrix' % cRevPoint.sCtrl])

        fUpTarget = nodes.createPointByMatrixNode([0,1,0], '%s.worldMatrix' % sFkJoints[0], bJustValues=True)
        fLocalUp = nodes.createPointByMatrixNode(fUpTarget, '%s.worldInverseMatrix' % cRevPoint.sCtrl, bJustValues=True)
        sUp = nodes.createPointByMatrixNode(fLocalUp, '%s.worldMatrix' % cRevPoint.sCtrl)

        sAimMatrix = nodes.createAimMatrixNode(sAimStartMatrix, sAimTarget, sUp, bAlignUp=False, aim=[self.fSideMultipl, 0,0])

        sAimMatrixBySecondaryB = nodes.createMultMatrixNode([sAimMatrix,
                                                             '%s.worldInverseMatrix' % cSecondary.sSlider,
                                                             '%s.matrix' % cSecondary.sCtrl,
                                                             '%s.worldMatrix' % cSecondary.sSlider,
                                                             ])

        sAimLocal = nodes.createMultMatrixNode([sAimMatrixBySecondaryB, '%s.parentInverseMatrix' % sFkJoints[0]])

        xforms.jointOrientToRotation(sFkJoints[0])
        cmds.setAttr('%s.jo' % sFkJoints[0], lock=True)

        nodes.createDecomposeMatrix(sAimLocal, sTargetPos='%s.t' % sFkJoints[0], sTargetRot='%s.r' % sFkJoints[0])
        nodes.createDistanceNode(nodes.getWorldPoint(cRevPoint.sOut), sAimTarget, fNormalized=cmds.getAttr('%s.tx' % sFkJoints[1]), sDivide='%sX' % nodes.getScaleFromXform(self.cCtrl.sCtrl),
                                 sTarget='%s.tx' % sFkJoints[1])

        utils.addOffOnAttr(self.cCtrl.sCtrl, 'secondaryCtrlVis', True, sTarget=['%s.v' % cSecondary.sPasser, '%s.v' % cRevPoint.sPasser])

        self.cDisplayCtrls.extend([self.cCtrl, cRevPoint, cSecondary])

        return sFkJoints, [self.cCtrl, cRevPoint, cSecondary], dAttacherBuildData


    def unreal_feature_fk(self):
        if self.sLimbName == 'm_globazl':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal

            sAutoDriverLimb = self.tArm.sLimbName


            sCommands = []
            sCommands.append('controllers.setNewColumn()')

            sPivot = utilsUnreal.createUnrealNull('eStrPivot_%s' % self.sLimbName, list(self.dBlueprints.values())[2], sWriteCommands=sCommands)
            cStrCtrl = utilsUnreal.createUnrealCtrl(self.cCtrl, sWriteCommands=sCommands)

            utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk', sWriteCommands=sCommands)


            sJoint = self.getOutputFullNames()[0]
            sFunctionNodeName = '%s_feature' % self.sLimbName


            sCommands.append(f"{sFunctionNodeName} = functions.createScapulaFunction('{self.sSide}', {cStrCtrl}, '{sJoint}', '{cmds.listRelatives(sJoint, p=True)[0]}', {sPivot}, '{sAutoDriverLimb}')")

            utilsUnreal.initiateAttacherDictCommand('feature_fk', sWriteCommands=sCommands)
            utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, sWriteCommands=sCommands)

            return sCommands, [], []



    def childrenConnect_LDogArmLeg(self, _lChildren):
        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm
        if hasattr(tArm, 'bAutoClavicle') and tArm.bAutoClavicle:
            if len(tArm.sClavAimTransformPerFeature) > 1:
                sArmOutMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % sT for sT in tArm.sClavAimTransformPerFeature],
                                                            ['%s.weight' % sF for sF in tArm.sFeatureGrps])
            else:
                sArmOutMatrix = '%s.worldMatrix' % tArm.sClavAimTransformPerFeature[0]

            sAutoHorizAttr = utils.addAttr(self.cCtrl.sCtrl, ln='autoHoriz', min=0.0, max=1.0, k=True)
            sAutoVertAttr = utils.addAttr(self.cCtrl.sCtrl, ln='autoVert', min=0.0, max=1.0, k=True)
            sAutoRotAttr = utils.addAttr(self.cCtrl.sCtrl, ln='autoRot', min=0.0, max=1.0, k=True)
            sAutoOutput = nodes.createDecomposeMatrix(sArmOutMatrix)
            sLocalAutoOutput = nodes.createPointByMatrixNode(sAutoOutput, '%s.worldInverseMatrix' % cmds.listRelatives(self.sAutoConstrainer, p=True)[0])
            fDefaultLocalAutoOutput = cmds.getAttr(sLocalAutoOutput)[0]
            sOffsetAutoValues = nodes.createVectorAdditionNode([sLocalAutoOutput, fDefaultLocalAutoOutput], sOperation='minus')
            nodes.createBlendNode(sAutoHorizAttr, '%sz' % sOffsetAutoValues, 0, sTarget='%s.tz' % self.sAutoConstrainer)
            nodes.createBlendNode(sAutoVertAttr, '%sy' % sOffsetAutoValues, 0, sTarget='%s.ty' % self.sAutoConstrainer)


            fAutoDefaultWorldMatrix = cmds.getAttr('%s.worldMatrix' % self.sAutoConstrainer)
            sAimConstraint = constraints.aimConstraintEmpty(self.sAutoConstrainer, aim=[0,-1,0], up=[1,0,0])
            cmds.setAttr('%s.worldUpVector' % sAimConstraint, 1,0,0)
            sArmOutLocalMatrix = nodes.createMultMatrixNode([sArmOutMatrix, '%s.worldInverseMatrix' % cmds.listRelatives(self.sAutoConstrainer, p=True)[0]])
            nodes.createDecomposeMatrix(sArmOutLocalMatrix, sTargetPos='%s.target[0].targetTranslate' % sAimConstraint)
            constraints.computeAimOffset(sAimConstraint, fAutoDefaultWorldMatrix)
            sAimResultMatrix = nodes.createComposeMatrixNode(xRotate='%s.constraintRotate' % sAimConstraint)
            sAimBlended = nodes.createBlendMatrixNode([sAimResultMatrix, utils.fIdentityMatrix], [sAutoRotAttr, nodes.createReverseNode(sAutoRotAttr)])
            nodes.createDecomposeMatrix(sAimBlended, sTargetRot='%s.r' % self.sAutoConstrainer, bForce=True)

            # the replacement for attacher "root_clav"
            for mDag in tArm.mAttachToClavicleTransformsOnAuto:
                xforms.matrixParentConstraint(self.dOutputs['start'], mDag.partialPathName(), mo=True, skipScale=['x','y','z'])
            tArm.sUnrealAttachRootToClavicle = "library.getElementKey('%s', 'Control')" % self.cCtrl.sCtrl


    def childrenConnect_LHorseArmLeg(self, _lChildren): # this is an exact copy of the LDogArmLeg version
        self.childrenConnect_LDogArmLeg(_lChildren)


    def childrenConnect_LArmLeg(self, _lChildren):
        self.childrenConnect_LDogArmLeg(_lChildren)


    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]

        cClavCtrls = blueprints.createChainCtrls([sBlueprints[0], sBlueprints[1]], sSide=self.sSide, xRoot='clavicle', xAim='%sclavicleEnd' % self.sName,
                                                 xPole='%sPoleClavicle' % self.sName, sParent=self.sBpTopGrp)

        cPivot = blueprints.createCtrl(self.dBlueprints['pivot'], sSide=self.sSide, xCtrl='%sPivot' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)


        self.cBpArmAttach = cClavCtrls[0]

        self.cBpAll = cClavCtrls
        self.cBpRoots = [cClavCtrls[0], cClavCtrls[-1], cPivot]



    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):

        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)

        # xAutoConnectData =  xData['connect_arm']
        if lChildren:
            tArm = lChildren[0]
            cArmRoot = tArm.cBpRoots[0]
            cArmRoot.convertToSimpleTransforms()
            cmds.parentConstraint(self.cBpArmAttach.sOut, cArmRoot.sPasser, mo=True)



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)
        utils.displayTag(self.sDisplayAttr, self.cDisplayCtrls)



    def generateOutputs_poseJoint(self, **kwargs):
        return {}, []





    def getDefaultParentOutput(self):
        return 'start'



