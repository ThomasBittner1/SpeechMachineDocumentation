###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import math

import maya.cmds as cmds
import numpy as np
from collections import OrderedDict

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.blueprints as blueprints
import kangarooTools.curves as curves
import kangarooTools.match as match

import kangarooTabTools.segments as segments
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTools.utilFunctions as utils

dLegCtrlNames = {'elbow': 'knee', 'wrist': 'ankle', 'fingers': 'toes', 'hand': 'foot', 'fingersMid':'toesMid'}




class LDogArmLeg(baseLimb._LBaseLimb):
    
    def __init__(self, sName='dogArm', sSide='l', bAutoScapula=False, bIsBackLeg=False,
                 bRemoveEndSkinJoint=False, bForceParentSkeletonToRoot=False,
                 bSquashStretch=True,
                 fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0),
                 fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0), iFeatureCtrlType=0, sCustomFeatureCtrlName='', iSegmentsPriority=0,
                 _dComboboxItems={'iWristScale': ['no scale', 'uniform', 'length (bad for fingers)'],
                                  'iFeatureCtrlType': ['shape on all ctrls', 'new global ctrl', 'custom ctrl']}):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bRemoveEndSkinJoint=bRemoveEndSkinJoint, bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset, iSegmentsPriority=iSegmentsPriority,
                                     iFeatureCtrlType=iFeatureCtrlType, sCustomFeatureCtrlName=sCustomFeatureCtrlName)
        self.bAutoScapula = bAutoScapula

        self.dOutputs['upper'] = None
        self.dOutputs['elbow'] = None
        self.dOutputs['wrist'] = None
        self.dOutputs['fingers'] = None
        self.dOutputs['fingersMid'] = None
        self.dOutputs['end'] = None
        
        # self.bRevRoll = bRevRoll
        self.bSquashStretch = bSquashStretch

        if self.bAutoScapula:
            self.dOutputs['_autoClavicle'] = None

        self.dCtrlNames = dLegCtrlNames if bIsBackLeg else {sK:sK for sK,_ in list(dLegCtrlNames.items())}
        self.bIsBackLeg = bIsBackLeg
        self.bLimbsAreScaling = bSquashStretch
        self.tClavicle = None
        self.sDefaultFeatures = ['feature_fk', 'feature_ik']

        if self.iFeatureCtrlType == 1:
            self.dFeatureCtrlParent = {'sOutputKey':'wrist', 'sBlueprintKey':'wrist'}



    def guessBlueprintFromOutput(self, sOutputKey, iBlueprintCount=None):
        if sOutputKey.startswith('upper'):
            return 'up'
        elif sOutputKey.startswith('lower'):
            return 'elbow'
        elif sOutputKey == 'wrist':
            return 'wrist'
        elif sOutputKey == 'fingers':
            return 'fingers'
        elif sOutputKey == 'end':
            return 'fingersEnd'


    def getDefaultParentOutput(self):
        return 'wrist'


    def generateAttachers_init(self):
        dAttachers = {}
        if self.bAutoScapula:
            dAttachers['root_noScap'] = {'sTrs': 'tr', 'bMulti': False}
            dAttachers['root_scap'] = {'sTrs': 'tr', 'bMulti': False}
        else:
            dAttachers['root'] = {'sTrs': 'tr', 'bMulti': False}

        dAttachers['scale'] = {'sTrs': 's', 'bMulti': False}

        return dAttachers



    def createOrSetBlueprints(self, lParent=None):
        sBlueprintNames = [['up', 'elbow', 'wrist', 'fingers', 'fingersMid', 'end'],
                            ['print',[['toesPivot'],['heelPivot'],['outPivotA'],['outPivotB'],['inPivotA'],['inPivotB']]]]
        if self.bIsBackLeg:
            sNewJoints = self._fillBlueprints([[(0,0,0, 0,0,-1), (0,-5.6,2, 0,0,-1), (0,-9.0,-3, 0,0,-1), (0,-13.8,-3.0, 0,-0.5,-1), (0,-15,-1.7, 0,-0.5,-1), (0,-15,-0.5 ,0,-0.5,-1)],
                                [(0,-15,-3, 0,1,0, 'yz', 'zy'),[[(0,-15,0.5)],[(0,-15,-3.8)],[(1.1,-15,-3.0)],[(1.1,-15,-1.5)],[(-2.5,-15,-3.0)],[(-2.5,-15,-1.5)]]]],
                                sBlueprintNames, sRefMainKey='wrist')
        else:
            sNewJoints = self._fillBlueprints([[(0,0,0, 0,0,-1), (0,-5.6,-3, 0,0,-1), (0,-11.0,-3, 0,0,-1), (0,-13.8,-3.0, 0,-0.5,-1),(0,-15,-1.7, 0,-0.5,-1), (0,-15,-0.5 ,0,-0.5,-1)],
                                [(0,-15,-3, 0,1,0, 'yz', 'zy'),[[(0,-15,0.5)],[(0,-15,-3.8)],[(1.1,-15,-3.0)],[(1.1,-15,-1.5)],[(-2.5,-15,-3.0)],[(-2.5,-15,-1.5)]]]],
                                sBlueprintNames, sRefMainKey='wrist')

        [cmds.setAttr('%s.radius' % sJ, 0.1) for sJ in sNewJoints if 'Pivot' in sJ or 'print' in sJ]

        self.fStartLengthA = cmds.getAttr('%s.tx' % self.dBlueprints['elbow']) * self.fSideMultipl
        self.fStartLengthB = cmds.getAttr('%s.tx' % self.dBlueprints['wrist']) * self.fSideMultipl

        return sNewJoints


    def generateAttachers_fk(self, **kwargs):
        if self.bAutoScapula:
            return {'upper_noScap': {'sTrs':'r', 'bMulti':True},
                    'wrist_noScap': {'sTrs':'r', 'bMulti':True}}
        else:
            return {'upper': {'sTrs':'r', 'bMulti':True},
                    'wrist': {'sTrs':'r', 'bMulti':True, 'sLocals':['local']}}


    def feature_fk(self, bLockBreak=False):

        sBlueprints = [self.dBlueprints[sN] for sN in ['up', 'elbow', 'wrist', 'fingers', 'fingersMid', 'end']]
            
        sFkJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='fk', sParent=self.sCurrentFeatureGrp, bFreezeOrients=True)

        cUpper = self._createCtrl3(sName='upper', sMatch=self.dBlueprints['up'], sAttrs = ['r'], iRotateOrder='yzx',
                                  fSize=cmds.getAttr('%s.radius' % sBlueprints[0])*5, sShape='wedge')
        cUpper.adjustAxisOrientation([0,90,-90])

        dAttacherBuildData = {}
        dAttacherBuildData['root'] = (utils.getDagPath(cUpper.sPasser), None)
        dAttacherBuildData['root_scap'] = (utils.getDagPath(cUpper.sPasser), None)

        sUpperAttacher = cUpper.appendOffsetGroup('attacher')
        dAttacherBuildData['upper'] = (utils.getDagPath(sUpperAttacher), cUpper)
        dAttacherBuildData['upper_noScap'] = (utils.getDagPath(sUpperAttacher), cUpper)

        cElbow = self._createCtrl3(sName=self.dCtrlNames['elbow'], sMatch=self.dBlueprints['elbow'],
                                  sAttrs = ['r'], fSize=cmds.getAttr('%s.radius' % sBlueprints[0])*5, sShape='wedge', iRotateOrder='yzx')
        cElbow.adjustAxisOrientation([0,90,-90])

        xforms.matrixParentConstraint(cUpper.sOut, cElbow.sPasser, mo=True, skipScale=['x','y','z'])

        cWrist = self._createCtrl3(sName=self.dCtrlNames['wrist'], sMatch=self.dBlueprints['wrist'],
                                  sAttrs = ['r'], fSize=cmds.getAttr('%s.radius' % sBlueprints[0])*5, sShape='wedge', iRotateOrder='yzx')
        cWrist.adjustAxisOrientation([0,90,-90])
        xforms.matrixParentConstraint(cElbow.sOut, cWrist.sPasser, mo=True, skipRotate=['x','y','z'], skipScale=['x','y','z'])


        cFinger = self._createCtrl3(sName=self.dCtrlNames['fingers'], sMatch=self.dBlueprints['fingers'],
                                  sAttrs = ['r'], fSize=cmds.getAttr('%s.radius' % sBlueprints[0])*5, sShape='wedge',)
        cFinger.adjustAxisOrientation([0,90,-90])
        cFingerMid = self._createCtrl3(sName=self.dCtrlNames['fingersMid'], sMatch=self.dBlueprints['fingersMid'],
                                  sAttrs = ['rx'], fSize=cmds.getAttr('%s.radius' % sBlueprints[0])*5, sShape='wedge',)
        cFingerMid.adjustAxisOrientation([0,90,-90])

        xforms.matrixParentConstraint(cWrist.sOut, cFinger.sPasser, mo=True, skipScale=['x','y','z'])
        xforms.matrixParentConstraint(cFinger.sOut, cFingerMid.sPasser, mo=True, skipScale=['x','y','z'])
        sWristAttach = cWrist.appendOffsetGroup('attach')
        dAttacherBuildData['wrist_noScap'] = (utils.getDagPath(sWristAttach), cWrist)
        self.dLocalAttacherOutputs['wrist_noScap'] = ['local.%s' % cElbow.sOut]
        dAttacherBuildData['wrist'] = (utils.getDagPath(sWristAttach), cWrist)
        self.dLocalAttacherOutputs['wrist'] = ['local.%s' % cElbow.sOut]

        xforms.matrixParentConstraint(cUpper.sOut, sFkJoints[0], skipScale=['x','y','z'])
        xforms.matrixParentConstraint(cElbow.sOut, sFkJoints[1], skipTranslate=['x','y','z'], skipScale=['x','y','z'])
        xforms.matrixParentConstraint(cWrist.sOut, sFkJoints[2], skipTranslate=['x','y','z'], skipScale=['x','y','z'])
        xforms.matrixParentConstraint(cFinger.sOut, sFkJoints[3], skipTranslate=['x','y','z'], skipScale=['x','y','z'])
        xforms.matrixParentConstraint(cFingerMid.sOut, sFkJoints[4], skipTranslate=['x','y','z'], skipScale=['x','y','z'])

        if self.bAutoScapula:
            sAcParent = self._createTransform('autoClavParent', sMatch=self.dBlueprints['up'])
            sAc = self._createTransform('autoClav', sParent=sAcParent, sMatch=self.dBlueprints['up'])
            cmds.rotate(0,90,-90, sAcParent, r=True, os=True)
            sAcOut = self._createTransform('autoClavOut', sParent=sAc, sMatch=self.dBlueprints['elbow'])
            cmds.connectAttr('%s.r' % cUpper.sCtrl, '%s.r' % sAc)
            dAttacherBuildData['root_noScap'] = (utils.getDagPath(sAcParent), None)
        else:
            sAcOut = None


        if self.bSquashStretch:
            cUpper.unlockAttrs(['sy'])
            cElbow.unlockAttrs(['sy'])
            cWrist.unlockAttrs(['sy'])
            nodes.fromEquation('%s.sy * %s' % (cUpper.sCtrl, cmds.getAttr('%s.tx' % sFkJoints[1])),
                               sTarget='%s.tx' % sFkJoints[1], sName=self._createNodeName('upperScale'))
            nodes.fromEquation('%s.sy * %s' % (cElbow.sCtrl, cmds.getAttr('%s.tx' % sFkJoints[2])),
                               sTarget='%s.tx' % sFkJoints[2], sName=self._createNodeName('lowerScale'))


        sOuts = list(sFkJoints)
        if self.bAutoScapula:
            sOuts.append(sAcOut)

        cCtrls = [cUpper, cElbow, cWrist, cFinger, cFingerMid]

        cmds.controller(cElbow.sCtrl, cUpper.sCtrl, parent=True)
        cmds.controller(cWrist.sCtrl, cElbow.sCtrl, parent=True)
        cmds.controller(cFinger.sCtrl, cWrist.sCtrl, parent=True)
        cmds.controller(cFingerMid.sCtrl, cFinger.sCtrl, parent=True)

        #global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        for sPasser in [cUpper.sPasser, cElbow.sPasser, cWrist.sPasser]:
            cmds.scaleConstraint(self.sCurrentFeatureGrp, sPasser)

        cmds.scaleConstraint(self.sCurrentFeatureGrp, cFinger.sPasser)

        sMatchScript = ''
        sMatchScript += match.generateMatchingConstrainCommand2(0, sOuts[:-1], cUpper.sCtrl, iConstraintType=match.Type.parentConstraint)
        sMatchScript += match.generateMatchingConstrainCommand2(1, sOuts[:-1], cElbow.sCtrl, iConstraintType=match.Type.parentConstraint)
        sMatchScript += match.generateMatchingConstrainCommand2(2, sOuts[:-1], cWrist.sCtrl, iConstraintType=match.Type.parentConstraint)
        sMatchScript += match.generateMatchingConstrainCommand2(3, sOuts[:-1], cFinger.sCtrl, iConstraintType=match.Type.parentConstraint)
        sMatchScript += match.generateMatchingConstrainCommand2(4, sOuts[:-1], cFingerMid.sCtrl, iConstraintType=match.Type.parentConstraint)

        if self.bSquashStretch:
            sMatchScript += "\nsetDistance(NAMESPACE, '{0}', '{1}', %f, '%s.sy')" % (1.0/self.fStartLengthA, cUpper.sCtrl)
            sMatchScript += "\nsetDistance(NAMESPACE, '{1}', '{2}', %f, '%s.sy')" % (1.0/self.fStartLengthB, cElbow.sCtrl)


        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)

        return sOuts, cCtrls, dAttacherBuildData



    def generateAttachers_ik(self, **kwargs):
        # if self.bAutoScapula:
        if self.bAutoScapula:
            return {'pole_noScap': {'sTrs': 'tr', 'bMulti': True, 'sLocals':['follow']},
                    'hand_noScap': {'sTrs': 'tr', 'bMulti': True}}
        else:
            return {'pole': {'sTrs': 'tr', 'bMulti': True, 'sLocals':['follow']},
                    'hand': {'sTrs': 'tr', 'bMulti': True}}



    # L_polevectorConnectSpace_rotate_move_LOC
    def feature_ik(self, bLengthAttrs=True, bSoftIk=True, bAutoScapulaFollowIk=True, bWorldOrientIkCtrl=True, bOppositePole=True, _dComboboxItems={}):

        sBlueprints = [self.dBlueprints[sN] for sN in ['up', 'elbow', 'wrist', 'fingers', 'fingersMid', 'end']]

        sIkJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='ikBef', sParent=self.sCurrentFeatureGrp, bFreezeOrients=True)
        cCtrls = []

        cPrint = self._createCtrl3(sName='ik', sMatch=self.dBlueprints['print'], fMatchPos=self.dBlueprints['fingers'], sAttrs = ['t','r'], iRotateOrder='zxy',
                                  sShape='squareY', fSize=1.0, fRotateShape=(0,0,90), bSuper=True, bIsJoint=bWorldOrientIkCtrl)
        if bWorldOrientIkCtrl:
            sTemp = cmds.createNode('transform')
            cmds.setAttr('%s.ro' % sTemp, cmds.getAttr('%s.ro' % cPrint.sCtrl))
            cmds.delete(cmds.parentConstraint(cPrint.sCtrl, sTemp))
            if self.sSide == 'r':
                cmds.setAttr('%s.r' % cPrint.sPasser, 180,0,0)
            else:
                cmds.setAttr('%s.r' % cPrint.sPasser, 0,0,0)
            cmds.delete(cmds.parentConstraint(sTemp, cPrint.sCtrl, skipTranslate=['x','y','z']))
            cmds.makeIdentity(cPrint.sCtrl, r=True, apply=True)
            cmds.delete(sTemp)




        # sPivotsCtrlVis = utils.addOffOnAttr(cPrint.sCtrl, 'pivotCtrlsVIS', bDefaultValue=True)
        sPoleVis = utils.addOffOnAttr(cPrint.sCtrl, 'upVIS', bDefaultValue=True)

        fPolePos = xforms.fPoleVectorPos(self.dBlueprints['up'], self.dBlueprints['elbow'], self.dBlueprints['wrist'], bOpposite=bOppositePole)
        cPole = self._createCtrl3(sName='pole', sAttrs = ['t'], fMatchPos=fPolePos, sShape='locator', iColorIndex=1, iSlider=3, fSize=cmds.getAttr('%s.radius' % sIkJoints[0]) * 5)

        sOutJoints = sIkJoints

        sOuts = list(sOutJoints)

        sHandTransform = self._createTransform('hand', fMatchPos=cmds.xform(self.dBlueprints['wrist'], q=True, ws=True, t=True))
        sRootAttachTransform = self._createTransform('rootAttach', sMatch=self.dBlueprints['up'])

        cmds.delete(cmds.orientConstraint(self.dBlueprints['heelPivot'], sHandTransform))

        sIkHandle = xforms.createIk(sIkJoints[0], sIkJoints[2], cPole.sOut, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('ikMain','ik'),
                                    bOppositePole=bOppositePole)
        cmds.pointConstraint(sHandTransform, sIkHandle)

        dAttacherBuildData = {}

        if self.bAutoScapula:
            sAutoClavicleOut = self._createTransform('outTransformAc')
            sOuts.append(sAutoClavicleOut)
            if bAutoScapulaFollowIk:
                sAutoClavicleParent = self._createTransform('outTransformParentAc')
                xforms.matrixParentConstraint(sRootAttachTransform, sAutoClavicleParent)
                cmds.parent(sAutoClavicleOut, sAutoClavicleParent)
                cmds.delete(cmds.pointConstraint(self.dBlueprints['elbow'], sAutoClavicleOut))
                cmds.pointConstraint(sHandTransform, sAutoClavicleOut, mo=True, skip=['x','y'])
            else:
                sAcBlueprints = [self.dBlueprints[sN] for sN in ['up', 'elbow', 'wrist']]
                iksAc = xforms.duplicateJoinChain(sAcBlueprints, sPostfix='ikAc', sParent=self.sCurrentFeatureGrp, bFreezeOrients=True)
                sIkHandleAc = xforms.createIk(iksAc[0], iksAc[2], cPole.sOut, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('autoClav', 'IK'))
                cmds.pointConstraint(sHandTransform, sIkHandleAc)
                cmds.pointConstraint(iksAc[1], sAutoClavicleOut)
                xforms.matrixParentConstraint(sRootAttachTransform, iksAc[0], skipScale=['x','y','z'])
        cCtrls.append(cPole)


        cToesEnd = self._createCtrl3(sName='EndRev', sMatch=self.dBlueprints['print'], fMatchPos=self.dBlueprints['toesPivot'],
                                    sAttrs = ['r'], sShape='arrowCurve', fSize=0.5, bIsNoCtrl=True)
        # cToesEnd.convertToSimpleTransforms()

        cBallRev = self._createCtrl3(sName='lift', sMatch=self.dBlueprints['fingers'], fMatchPos=self.dBlueprints['fingersMid'],
                                     sAttrs=['t','r'], sShape='cylinder', fSize=1.5,
                                     fRotateShape=(0,0,90), sParent=cToesEnd.sOut, bIsNoCtrl=True)
        cmds.setAttr('%s.r' % cBallRev.sSlider, 0,-90,0)

        sLiftSibling = self._createTransform('lift', sMatch=cBallRev.sCtrl,
                                             sParent=cmds.listRelatives(cBallRev.sCtrl, p=True)[0])


        cmds.connectAttr('%s.r' % cBallRev.sCtrl, '%s.r' % sLiftSibling)
        nodes.createClampNode('%s.t' % cBallRev.sCtrl, [-10000, 0, -10000], [10000, 10000, 10000], bVector=True, sTarget='%s.t' % sLiftSibling)
        cmds.parent(cBallRev.sOut, sLiftSibling)

        cWristRev = self._createCtrl3(sName='%sRev' % self.dCtrlNames['wrist'], sMatch=self.dBlueprints['print'], fMatchPos=self.dBlueprints['fingers'],
                                     sAttrs = ['r'], sShape='arrowCurve', fSize=10.0,
                                     fRotateShape=(0,0,0), sParent=cBallRev.sOut, bIsNoCtrl=True)

        # cmds.select(cWristRev.sCtrl)
        # cWristRev.convertToSimpleTransforms()
        cHeel = self._createCtrl3(sName='heel', fMatchPos=self.dBlueprints['heelPivot'], sMatch=self.dBlueprints['print'],
                                    sAttrs = ['r'], sShape='arrowCurve', fSize=0.5, bIsNoCtrl=True)
        cmds.rotate(0,180,0, cHeel.sPasser, os=True, r=True )
        # cHeel.convertToSimpleTransforms()

        cInOuts = []
        for sDir, fDirection in [('in',1),('out',-1)]:
            aPositions = xforms.getPositionArray([self.dBlueprints['%sPivotA' % sDir], self.dBlueprints['%sPivotB' % sDir]])
            aPos = (aPositions[0]+aPositions[1])*0.5
            cInOuts.append(self._createCtrl3(sName=sDir, sMatch=self.dBlueprints['print'], bIsNoCtrl=True,
                            fMatchPos=aPos, sAttrs = ['r'], sShape='arrowCurve', fSize=0.5))
            # cInOuts[-1].convertToSimpleTransforms()

            aSidePivots = xforms.getPositionArray([self.dBlueprints['%sPivotA' % sDir], self.dBlueprints['%sPivotB' % sDir]])
            aDirection = aSidePivots[1] - aSidePivots[0]
            aPrintMatrix = np.array(cmds.xform(self.dBlueprints['print'], q=True, ws=True, m=True)).reshape(4,4)
            fUp = aPrintMatrix[1,0:3]
            xforms.orientThreePoints(cInOuts[-1].sPasser, fUp, aDirection, fAimVector=[0,1,0], fUpVector=[fDirection,0,0])

            if self.sSide == 'r':
                cmds.rotate(0,180,0, cInOuts[-1].sPasser, os=True, r=True)

        # cmds.delete(cInOuts[0].sShape)
        # cmds.delete(cInOuts[1].sShape)
        cmds.parent(cHeel.sPasser, cPrint.sOut)
        cmds.parent(cInOuts[0].sPasser, cInOuts[1].sCtrl)
        cmds.parent(cInOuts[1].sPasser, cHeel.sCtrl)

        sRotUp = self._createTransform('fingerRevUp', sParent=cBallRev.sOut)

        sLastToeAim = self._createTransform('wristAim', sParent=cToesEnd.sOut, sMatch=sOutJoints[-1])
        sToeAim = self._createTransform('toeAim', sParent=cBallRev.sOut, sMatch=sOutJoints[4])
        cmds.aimConstraint(cWristRev.sOut, sOutJoints[2], aim=[self.fSideMultipl,0,0], wut='objectrotation', wuo=cWristRev.sOut, wu=[1,0,0], u=[0,0,1], mo=True)
        cmds.aimConstraint(sToeAim, sOutJoints[3], aim=[self.fSideMultipl,0,0], wut='objectrotation', wuo=cBallRev.sOut, wu=[1,0,0], u=[0,0,1], mo=True)

        # toe bend
        cToeFk = self._createCtrl3(sName='toeFk', sMatch=self.dBlueprints['fingersMid'], sAttrs=['r'],
                            sShape='arrowCurve',  sParent=self.sCurrentFeatureGrp, bIsNoCtrl=True, iSlider=0)


        xforms.matrixParentConstraint(sIkJoints[3], cToeFk.sPasser, mo=True)

        cmds.aimConstraint(sLastToeAim, cToeFk.sPasser, aim=[self.fSideMultipl,0,0], wut='objectrotation', wuo=sRotUp, wu=[1,0,0], u=[0,0,1], mo=True)
        xforms.matrixParentConstraint(cToeFk.sCtrl, sOutJoints[4], skipScale=['x','y','z'], skipTranslate=['x','y','z'])


        sAnkleAimOffset = cWristRev.appendOffsetGroup('aim')
        sRootAttachChild = self._createTransform('rootAttachChild', sMatch=sRootAttachTransform, sParent=sRootAttachTransform)

        # that was here before - but why??
        # xforms.matrixParentConstraint(cPrint.sOut, sRootAttachChild, skipTranslate=['x','y'], skipRotate=['x','y','z'], skipScale=['x','y','z'])
        cmds.aimConstraint(sRootAttachChild, sAnkleAimOffset, wut='objectrotation', wuo=cPrint.sOut, wu=[1,0,0], aim=[0,1,0], u=[1,0,0], mo=True)[0]


        if self.bAutoScapula:
            dAttacherBuildData['root_noScap'] = (utils.getDagPath(sRootAttachTransform), None)
            dAttacherBuildData['root_scap'] = (utils.getDagPath(sIkJoints[0]), None)
        else:
            dAttacherBuildData['root'] = (utils.getDagPath(sRootAttachTransform), None)
            xforms.matrixParentConstraint(sRootAttachTransform, sIkJoints[0], mo=True, skipRotate=['x','y','z'], skipScale=['x','y','z'])

        dAttacherBuildData['hand'] = (utils.getDagPath(sHandTransform), cPrint)
        dAttacherBuildData['hand_noScap'] = (utils.getDagPath(sHandTransform), cPrint)

        dAttacherBuildData['pole'] = (utils.getDagPath(cPole.sPasser), cPole) # should be spine if autoClav
        dAttacherBuildData['pole_noScap'] = (utils.getDagPath(cPole.sPasser), cPole) # should be spine if autoClav

        cmds.controller(cPrint.sCtrl, cPole.sCtrl, parent=True)
        # cmds.controller(cToesEnd.sCtrl, cWristRev.sCtrl, parent=True)
        # cmds.controller(cWristRev.sCtrl, cHeel.sCtrl, parent=True)
        # cmds.controller(cInOuts[0].sCtrl, cHeel.sCtrl, parent=True)
        # cmds.controller(cInOuts[1].sCtrl, cHeel.sCtrl, parent=True)
        # cmds.controller(cHeel.sCtrl, cPrint.sCtrl, parent=True)

        # create the ctrl shape for cPrint
        #
        aPrintMatrix = np.array(cmds.xform(self.dBlueprints['print'], q=True, m=True, ws=True), dtype='float64').reshape(4,4)
        aGrids = xforms.getPositionArray([self.dBlueprints[sK] for sK in ['toesPivot', 'outPivotA', 'heelPivot', 'inPivotA']])
        aGrids4 = np.ones((len(aGrids), 4), dtype='float64')
        aGrids4[:,0:3] = aGrids
        aLocals4 = np.dot(aGrids4, np.linalg.inv(aPrintMatrix))
        aLengths = aLocals4[np.arange(4),np.array([2,0,2,0])]
        aSigns = np.sign(aLengths)
        aSigns[2] = -aSigns[0]
        aLengths += aSigns * (np.max(aLengths) * 0.1)

        aCorners4 = np.ones((4,4), dtype='float64')
        for i, iXY in enumerate([(1,0), (1,2), (3,2), (3,0)]):
            aCorners4[i,0:3] = (aLengths[iXY[0]], 0, aLengths[iXY[1]])



        aCorners4World = np.dot(aCorners4, aPrintMatrix)
        aCorners4Super = np.copy(aCorners4)
        aCorners4Super[:,0:3] *= 1.2
        aCorners4WorldSuper = np.dot(aCorners4Super, aPrintMatrix)
        for iCv in range(5):
            iInd = iCv if iCv < 4 else 0
            cmds.move(aCorners4World[iInd,0], aCorners4World[iInd,1], aCorners4World[iInd,2], '%s.cv[%d]' % (cPrint.sCtrl, iCv), a=True, ws=True)
            cmds.move(aCorners4WorldSuper[iInd,0], aCorners4WorldSuper[iInd,1], aCorners4WorldSuper[iInd,2], '%s.cv[%d]' % (cPrint.sSuper, iCv), a=True, ws=True)

        # aim setup for foot
        #
        sAnkleAim = self._createTransform('aimAnkle', sParent=cToesEnd.sOut, sMatch=sOutJoints[3])
        xforms.matrixParentConstraint(cWristRev.sOut, sAnkleAim, skipTranslate=['x','y','z'], skipScale=['x','y','z'])

        cmds.parent(cToesEnd.sPasser, cInOuts[0].sCtrl)
        cmds.parent(sHandTransform, cWristRev.sCtrl)

        cCtrls += [cPrint] #, cWristRev, cBallRev, cToesEnd]
        dAttacherBuildData['hand'] = (utils.getDagPath(cPrint.sPasser), cPrint) # should be spine if autoClav
        dAttacherBuildData['hand_noScap'] = (utils.getDagPath(cPrint.sPasser), cPrint) # should be spine if autoClav


        # pole vector follow
        sPoleFollowTransform = self._createTransform('poleFollow', sMatch=self.dBlueprints['up'], sParent=self.sCurrentFeatureGrp)
        cmds.aimConstraint(cWristRev.sOut, sPoleFollowTransform, wut='objectrotation', wuo=cPrint.sOut, aim=[self.fSideMultipl,0,0], wu=[1,0,0])
        self.sMetaFollowTransform = self._createTransform('metaFollow', sMatch=self.dBlueprints['up'], sParent=self.sCurrentFeatureGrp)
        # cmds.pointConstraint(sOutJoints[3], self.sMetaFollowTransform)
        # cmds.aimConstraint(sOutJoints[2], self.sMetaFollowTransform, wut='objectrotation', wuo=cPrint.sOut, aim=[self.fSideMultipl,0,0], wu=[0,0,1])

        self.dLocalAttacherOutputs['pole'] = ['follow.%s' % sPoleFollowTransform]
        self.dLocalAttacherOutputs['pole_noScap'] = ['follow.%s' % sPoleFollowTransform]

        xforms.matrixParentConstraint(sRootAttachTransform, sPoleFollowTransform, skipRotate=['x','y','z'], skipScale=['x','y','z'])

        if self.bSquashStretch: # was bLengthAttrs, but that gives issues with matching scripts...
            sUpperStretchAttr = utils.addAttr(cPrint.sCtrl, ln='upperScale', at='double', defaultValue=1.0, minValue=0.1, maxValue=10.0, k=bLengthAttrs)
            sLowerStretchAttr = utils.addAttr(cPrint.sCtrl, ln='lowerScale', at='double', defaultValue=1.0, minValue=0.1, maxValue=10.0, k=bLengthAttrs)


        if self.bSquashStretch:
            sStretchAttr = utils.addAttr(cPrint.sCtrl, ln='stretch', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
            sStretchedDistance = nodes.fromEquation('%s*%f + %s*%f' % (sUpperStretchAttr, self.fStartLengthA, sLowerStretchAttr, self.fStartLengthB),
                                                    bDoUnitConversionNodes=True )
        else:
            sStretchedDistance = '%f' % (self.fStartLengthA + self.fStartLengthB)

        if self.bSquashStretch or bSoftIk:
            sIkJointGrp = self._createTransform('ikJoint0Transform') # to avoid cycle
            cmds.pointConstraint(sIkJoints[0], sIkJointGrp)
            sDistance = nodes.createDistanceNode('%s.t' % sIkJointGrp, sHandTransform, sName=self._createNodeName('distanceIk'), sDivide='%s.sx' % self.sCurrentFeatureGrp)
            sDistanceNormalized = nodes.fromEquation('%s / %s' % (sDistance, sStretchedDistance))

        if bSoftIk:
            fSoftDefaultValue = (1.0 - cmds.getAttr(sDistance) / (self.fStartLengthA + self.fStartLengthB)) * 10.0
            sSoftAttr = utils.addAttr(cPrint.sCtrl, ln='softIk', at='double', defaultValue=fSoftDefaultValue, minValue=0.0, k=True, fMultipl=0.1)
            sSoftAttrRev = nodes.createReverseNode(sSoftAttr)
            cmds.pointConstraint(sIkJoints[0], sIkHandle)
            sConstr = cmds.pointConstraint(sIkHandle, q=True)
            sExpr = '%s * (1.0 - (%0.8f ^ ((%s - %s) / %s))) + %s' % (sSoftAttr, math.e, sSoftAttrRev, sDistanceNormalized, sSoftAttr, sSoftAttrRev)
            sSoftExpr = nodes.fromEquation(sExpr, sName=self._createNodeName('softIk'))
            sCondDistanceBiggerThanOne = nodes.createConditionNode(sDistanceNormalized, '>', 1.0, 1.0, sDistanceNormalized)
            sCondSoftBiggerThanOne = nodes.createConditionNode(sSoftAttr, '>', 0.0, sSoftExpr, sCondDistanceBiggerThanOne)
            sSoft = nodes.createConditionNode(sDistanceNormalized, '>', sSoftAttrRev, sCondSoftBiggerThanOne, sCondDistanceBiggerThanOne)
            sSoftRatio = nodes.fromEquation('%s / %s' % (sDistanceNormalized, sSoft))
            if self.bSquashStretch:
                sConstrWeight = nodes.fromEquation('%s + (1.0 - %s) / %s' % (sStretchAttr, sStretchAttr, sSoftRatio))
            else:
                sConstrWeight = nodes.fromEquation('1.0 / %s' % sSoftRatio)
            cmds.connectAttr(sConstrWeight, '%s.%sW0' % (sConstr, sHandTransform))
            cmds.connectAttr(nodes.createReverseNode(sConstrWeight), '%s.%sW1' % (sConstr, sIkJoints[0]))


        if self.bSquashStretch:
            if bSoftIk:
                sScaleClamped = nodes.fromEquation('%s * %s + 1.0 - %s' % (sSoftRatio, sStretchAttr, sStretchAttr))
            else:
                sDistanceClamped = nodes.createClampNode(sDistanceNormalized, 1, 100000, sName=self._createNodeName('scaleClamp', 'distance'))
                sScaleClamped = nodes.createRangeNode(sStretchAttr, 0, 1, 1.0, sDistanceClamped, sName=self._createNodeName('scaleClamp', 'clamp'))

            if bLengthAttrs:
                nodes.createMultiplyArrayNode([sScaleClamped, self.fStartLengthA*self.fSideMultipl, sUpperStretchAttr],
                                   sTarget = '%s.tx' % sIkJoints[1], sName=self._createNodeName('scaleUpper'))
                nodes.createMultiplyArrayNode([sScaleClamped, self.fStartLengthB*self.fSideMultipl, sLowerStretchAttr],
                                   sTarget = '%s.tx' % sIkJoints[2], sName=self._createNodeName('scaleLower'))
            else:
                nodes.createMultiplyArrayNode([sScaleClamped, self.fStartLengthA*self.fSideMultipl],
                                   sTarget = '%s.tx' % sIkJoints[1], sName=self._createNodeName('scaleUpper'))
                nodes.createMultiplyArrayNode([sScaleClamped, self.fStartLengthB*self.fSideMultipl],
                                   sTarget = '%s.tx' % sIkJoints[2], sName=self._createNodeName('scaleLower'))
        else:
            if bLengthAttrs:
                nodes.createMultiplyArrayNode([sUpperStretchAttr, self.fStartLengthA], bDoUnitConversionNodes=True,
                                   sTarget = '%s.tx' % sIkJoints[1], sName=self._createNodeName('scaleUpper'))
                nodes.createMultiplyArrayNode([sLowerStretchAttr, self.fStartLengthB], bDoUnitConversionNodes=True,
                                   sTarget = '%s.tx' % sIkJoints[2], sName=self._createNodeName('scaleLower'))
                self.bLimbsAreScaling = True

        # cmds.connectAttr(sPivotsCtrlVis, '%s.v' % cHeel.sPasser)


        sLine = curves.createPoleVectorLine(cPole, sIkJoints[1])

        # pole vector roll
        sRollAttr = utils.addAttr(cPrint.sCtrl, ln='upRoll', at='double', defaultValue=0.0, k=True)
        if bOppositePole:
            sRollAttr = nodes.createAdditionNode([sRollAttr, 180])

        if self.sSide == 'l':
            cmds.connectAttr(sRollAttr, '%s.twist' % sIkHandle)
        else:
            nodes.createMultiplyNode(sRollAttr, -1, sTarget='%s.twist' % sIkHandle)

        cmds.setAttr('%s.v' % cPole.sCtrl, lock=False)
        cmds.connectAttr(sPoleVis, '%s.v' % cPole.sCtrl)
        cmds.connectAttr(sPoleVis, '%s.v' % sLine)


        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        for sPasser in [cPole.sPasser, cPrint.sPasser]:
            cmds.scaleConstraint(self.sCurrentFeatureGrp, sPasser)


        sInGrp = cInOuts[0].appendOffsetGroup('attr')
        sOutGrp = cInOuts[1].appendOffsetGroup('attr')
        sFootRockerAttr = utils.addAttr(cPrint.sCtrl, ln='%sRocker' % self.dCtrlNames['hand'], k=True)
        nodes.createRangeNode(sFootRockerAttr, 0, 1000, 0, 1000, sTarget='%s.rx' % sOutGrp)
        nodes.createRangeNode(sFootRockerAttr, 0, -1000, 0, 1000, sTarget='%s.rx' % sInGrp)


        sHeelRollGrp = cHeel.appendOffsetGroup('attr')
        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='heelRoll', k=True), '%s.rx' % sHeelRollGrp)
        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='heelSide', k=True), '%s.ry' % sHeelRollGrp)


        sToeAttrGrp = cToesEnd.appendOffsetGroup('attr')
        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='toeRoll', k=True), '%s.rx' % sToeAttrGrp)
        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='toeSide', k=True), '%s.ry' % sToeAttrGrp)

        self.sToeCurlAttr = utils.addAttr(cPrint.sCtrl, ln='toeCurl', k=True, minValue=0.0)
        cmds.connectAttr(self.sToeCurlAttr, '%s.rz' % cToeFk.sCtrl)

        # cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ballRoll', k=True), '%s.rx' % cBallRev.sCtrl)
        # cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ankleLift', minValue=0.0, k=True), '%s.ty' % cBallRev.sCtrl)

        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ankleRoll', k=True), '%s.rx' % cWristRev.sCtrl)
        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ankleSide', k=True), '%s.rz' % cWristRev.sCtrl)
        cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ankleTwist', k=True), '%s.ry' % cWristRev.sCtrl)

        self.sBallRollAttr = utils.addAttr(cPrint.sCtrl, ln='ballRoll', minValue=0.0, k=True)
        cmds.connectAttr(self.sBallRollAttr, '%s.rx' % cBallRev.sCtrl)
        # cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ballSide', k=True), '%s.ry' % cBallRev.sCtrl)
        # cmds.connectAttr(utils.addAttr(cPrint.sCtrl, ln='ballTwist', k=True), '%s.rz' % cBallRev.sCtrl)

        # ctrls3.removeCtrlSuffix([cBallRev, cToesEnd, cWristRev])

        sMatchScript = ''
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.softIk', 0)" % cPrint.sCtrl

        sAngleAttr = '%s.rz' % sOuts[4]
        sMatchScript += match.generateMatchingConstrainCommand2(3, sOuts[:-1], cPrint.sCtrl,
                                                               iConstraintType=match.Type.parentConstraint,
                                                                xCondition=['{4}.rz', '>=', cmds.getAttr(sAngleAttr)],
                                                                bLiveOffset=True)
        sMatchScript += match.generateMatchingConstrainCommand2(4, sOuts[:-1], cPrint.sCtrl,
                                                               iConstraintType=match.Type.parentConstraint,
                                                                xCondition=['{4}.rz', '<', cmds.getAttr(sAngleAttr)],
                                                                bLiveOffset=True)


        sMatchScript += match.generateApplyAngleCommand(4, 3, sOutJoints, 0, 1, '%s.toeCurl' % cPrint.sCtrl, False,
                                                        sNegativeAttrToSet='%s.ballRoll' % cPrint.sCtrl)

        sMatchScript += match.generateMatchingConstrainCommand2(2, sOuts[:-1], cWristRev.sCtrl,
                                                               iConstraintType=match.Type.orientConstraint,
                                                                sTransferToAttrs=['%s.ankleRoll' % cPrint.sCtrl,
                                                                                  '%s.ankleTwist' % cPrint.sCtrl,
                                                                                  '%s.ankleSide' % cPrint.sCtrl])


        if self.bSquashStretch:
            sMatchScript += "\nsetDistance(NAMESPACE, '{0}', '{1}', %f, '%s')" % (1.0/self.fStartLengthA, sUpperStretchAttr)
            sMatchScript += "\nsetDistance(NAMESPACE, '{1}', '{2}', %f, '%s')" % (1.0/self.fStartLengthB, sLowerStretchAttr)

        sMatchScript += "\nplacePoleVector(NAMESPACE, '{0}', '{1}', '{2}', '%s', %s)" % (cPole.sCtrl, bOppositePole)
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.upRoll', 0)" % cPrint.sCtrl

        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)


        # nodes.moveCustomAttributes(cPrint.sCtrl, self.sCurrentFeatureGrp, ['toeCurl', 'ballRoll'], bDeleteOldAttr=False, bConnectOldToNew=True)
        # utils.addStringAttr(self.sCurrentFeatureGrp, 'sBlendAttrs', ['toeCurl', 'ballRoll'], bLock=True)

        return sOuts, cCtrls, dAttacherBuildData




    def generateOutputs_twist(self, **kwargs):
        dOutputs = OrderedDict()
        fUpperParams, fLowerParams = self._getTwistInputParams(kwargs['fUpperParams'], kwargs['fLowerParams'])
        
        for i, fParam in enumerate(fUpperParams):
            dOutputs[self._getTwistName('upper',i)] = None
        for i, fParam in enumerate(fLowerParams):
            dOutputs[self._getTwistName('lower',i)] = None

        sRemoveOutputs = ['upper', 'elbow']

        return dOutputs, sRemoveOutputs


    def _getTwistName(self, sPart, iNumber):
        return '%sTwist%03d' % (sPart, iNumber)


    def _getTwistInputParams(self, fUpperParams, fLowerParams):
        if fUpperParams[0] != 0:
            fUpperParams.insert(0, 0.0)
        if fLowerParams[0] != 0:
            fLowerParams.insert(0, 0.0)
        return [fUpperParams, fLowerParams]


    def detail_twist(self, fUpperParams=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
                     fLowerParams=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
                     iKneeControls=0,
                     _dComboboxItems={'iKneeControls':['off', 'on', 'onWithDoubleKnee']}):

        if len(fUpperParams) <= 0:
            raise Exception('fUpperParam needs to have one or more items (%s)' % self.sLimbName)
        if len(fLowerParams) <= 0:
            raise Exception('fLowerParam needs to have one or more items (%s)' % self.sLimbName)

        fSideMultipl = -1 if self.sSide == 'r' else 1

        ffParams = self._getTwistInputParams(fUpperParams, fLowerParams)
        cCtrls = []
        dAttacherBuildData = {} # self.createEmptyAttacherDict()

        dAttacherBuildData['scale'] = (utils.getDagPath(self.sDetailsGrp), None)


        sCurrentOuts = list(self.dOutputs.values())
        sLengthAttrs = ['%s.tx' % sCurrentOuts[1], '%s.tx' % sCurrentOuts[2], '%s.tx' % self.dOutputs['fingers']]

        # sLengthAttrs = ['%s.tx' % sElbowOut, '%s.tx' % sWristOut, '%s.tx' % self.dOutputs['fingers']]

        fCtrlSize = cmds.getAttr('%s.radius' % sCurrentOuts[0]) * 10


        if iKneeControls != 0:
            cKneeStretches = [self._createCtrl3(sName='%sStretch' % self.dCtrlNames['elbow'], fMatchPos=self.dBlueprints['elbow'],
                                            sAttrs=['t'], sShape='locator', fSize=fCtrlSize),
                             self._createCtrl3(sName='%sStretch' % self.dCtrlNames['wrist'], fMatchPos=self.dBlueprints['wrist'],
                                            sAttrs=['t'], sShape='locator', fSize=fCtrlSize)]

            xforms.matrixParentConstraint(self.dOutputs['elbow'], cKneeStretches[0].sPasser, mo=True, skipScale=True)
            xforms.matrixParentConstraint(self.dOutputs['wrist'], cKneeStretches[1].sPasser, mo=True, skipScale=True)

            xforms.matrixParentConstraint(self.sDetailsGrp, cKneeStretches[0].sPasser, mo=True, skipTranslate=True, skipRotate=True)
            xforms.matrixParentConstraint(self.sDetailsGrp, cKneeStretches[1].sPasser, mo=True, skipTranslate=True, skipRotate=True)

            sKneeVis = utils.addOffOnAttr(self.sFeatureShape, '%sVIS' % self.dCtrlNames['elbow'], bDefaultValue=True)

            for cStretch in cKneeStretches:

                cmds.scaleConstraint(self.sCurrentFeatureGrp, cStretch.sPasser, mo=True)

                cmds.connectAttr(sKneeVis, '%s.v' % cStretch.sShape)

                sOrientConstraint = cmds.orientConstraint(self.dOutputs['upper'], self.dOutputs['elbow'], cStretch.appendOffsetGroup('orient'))[0]
                cmds.rotate(90,-90,0, cStretch.appendOffsetGroup('default'), r=True, os=True)
                cmds.setAttr('%s.interpType' % sOrientConstraint, 2)

            cCtrls += cKneeStretches

            cmds.pointConstraint(self.dOutputs['elbow'], cKneeStretches[0].sPasser)
            cmds.pointConstraint(self.dOutputs['wrist'], cKneeStretches[1].sPasser)

            sCurrentOuts[0] = self._createTransform('upperOut')
            cmds.pointConstraint(self.dOutputs['upper'], sCurrentOuts[0])
            cmds.scaleConstraint(self.dOutputs['upper'], sCurrentOuts[0])
            sCurrentOuts[1] = self._createTransform('lowerOut', sParent=cKneeStretches[0].sOut)
            sCurrentOuts[2] = self._createTransform('wristOut', sParent=cKneeStretches[1].sOut)

            if iKneeControls == 2:
                sUpperEnd = self._createTransform('upperEnd', sParent=cKneeStretches[0].sOut)
                sElbowEnd = self._createTransform('elbowEnd', sParent=cKneeStretches[1].sOut)
                sDoubleKneeAttr = utils.addAttr(cKneeStretches[0].sCtrl, ln='doubleKnee',
                                                defaultValue=0.5, minValue=0.0, maxValue=1.0, k=True)
                sLocalTop = nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['upper']),
                                                          '%s.worldInverseMatrix' % self.dOutputs['elbow'])
                sLocalBot = nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['wrist']),
                                                          '%s.worldInverseMatrix' % self.dOutputs['elbow'])
                sAngle = nodes.createAngleNode(sLocalTop, sLocalBot)
                sAngleRange = nodes.createRangeNode(sAngle, 90, 0, 0, 1)
                if self.bIsBackLeg:
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, cmds.getAttr('%s.tx' % self.dOutputs['elbow'])*0.2, sAngleRange],
                                          sTarget='%s.ty' % sUpperEnd)
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, -cmds.getAttr('%s.tx' % self.dOutputs['wrist'])*0.2, sAngleRange],
                                          sTarget='%s.ty' % sCurrentOuts[1])
                    # nodes.createMultiplyArrayNode([sDoubleKneeAttr, -cmds.getAttr('%s.tx' % self.dOutputs['fingers'])*0.2, sAngleRange],
                    #                       sTarget='%s.ty' % sCurrentOuts[2])
                else:
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, cmds.getAttr('%s.tx' % self.dOutputs['elbow'])*0.2, sAngleRange],
                                          sTarget='%s.ty' % sUpperEnd)
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, -cmds.getAttr('%s.tx' % self.dOutputs['wrist'])*0.2, sAngleRange],
                                          sTarget='%s.ty' % sCurrentOuts[1])
                    # nodes.createMultiplyArrayNode([sDoubleKneeAttr, cmds.getAttr('%s.tx' % self.dOutputs['fingers'])*0.2, sAngleRange],
                    #                       sTarget='%s.tx' % sCurrentOuts[2])
            else:
                sUpperEnd = cKneeStretches[0].sOut
                sElbowEnd = cKneeStretches[1].sOut

            cmds.aimConstraint(sUpperEnd, sCurrentOuts[0], worldUpObject=self.dOutputs['upper'],
                               upVector=[0, 1, 0], aimVector=[fSideMultipl, 0, 0], worldUpType='objectrotation')
            cmds.aimConstraint(sElbowEnd, sCurrentOuts[1], worldUpObject=self.dOutputs['elbow'],
                               upVector=[0, 1, 0], aimVector=[fSideMultipl, 0, 0], worldUpType='objectrotation')
            cmds.aimConstraint(self.dOutputs['fingers'], sCurrentOuts[2], worldUpObject=self.dOutputs['wrist'],
                               upVector=[0, 1, 0], aimVector=[fSideMultipl, 0, 0], worldUpType='objectrotation')

            sLengthAttrs[0] = '%sX' % nodes.createPointByMatrixNode(nodes.getWorldPoint(sUpperEnd), '%s.worldInverseMatrix' % sCurrentOuts[0],
                                                                    sFullName=self._createNodeName('upperLength', 'pointByMatrix'))
            sLengthAttrs[1] = '%sX' % nodes.createPointByMatrixNode(nodes.getWorldPoint(sElbowEnd), '%s.worldInverseMatrix' % sCurrentOuts[1],
                                                                    sFullName=self._createNodeName('lowerLength', 'pointByMatrix'))
            sLengthAttrs[2] = '%sX' % nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['fingers']), '%s.worldInverseMatrix' % sCurrentOuts[2],
                                                                    sFullName=self._createNodeName('wristLength', 'pointByMatrix'))
        else:
            sCurrentOuts[2] = self._createTransform('wristOut', sParent=self.dOutputs['wrist'])


        sNoTwistsParentUpper = self._createTransform('upperNoTwistParent')
        cmds.delete(cmds.parentConstraint(self.dBlueprints['up'], sNoTwistsParentUpper))
        dAttacherBuildData['root'] = (utils.getDagPath(sNoTwistsParentUpper), None)
        dAttacherBuildData['root_scap'] = (utils.getDagPath(sNoTwistsParentUpper), None)

        sNoTwistsParentLower = self._createTransform('lowerNoTwistParent')
        cmds.delete(cmds.parentConstraint(self.dBlueprints['elbow'], sNoTwistsParentLower))
        cmds.delete(cmds.pointConstraint(self.dBlueprints['wrist'], sNoTwistsParentLower))
        xforms.matrixParentConstraint(sCurrentOuts[1], sNoTwistsParentLower, mo=True, skipScale=['x','y','z'])

        sNoTwistParents = [sNoTwistsParentUpper, sNoTwistsParentLower]

        dTwistJoints = {}
        dTwistOutputs = {}

        sScales = []
        if self.bLimbsAreScaling:
            for p,sPart in enumerate(['upper','elbow', 'wrist']):
                sScales.append(nodes.fromEquation('%s * %f' % (sLengthAttrs[p], 1.0 / cmds.getAttr(sLengthAttrs[p])),
                              sName=self._createNodeName('scaleTwist'), bDoUnitConversionNodes=True))

        # create curves
        for sPart, p, sJoint, sMeasure in \
                [('upper', 0, sCurrentOuts[0], sCurrentOuts[0]),
                ('lower', 1, sCurrentOuts[1], self.dOutputs['wrist'])]:

            sChildJoint = list(self.dOutputs.values())[p+1]

            iCount = len(ffParams[p])

            if iCount == 0:
                continue
            fLength = abs(cmds.getAttr(sLengthAttrs[p]))
            sNoTwists = xforms.createJointChain([[0,0,0], [0,fLength*0.33*self.fSideMultipl,0]],
                                                self._createNodeName('%sNoTwist'%sPart,'jnt',iCount=2), sParent=self.sDetailsGrp, fRadius=0.5, sSide=self.sSide)
            cmds.parent(sNoTwists[0], sNoTwistParents[p])
            cmds.scaleConstraint(self.sDetailsGrp, sNoTwists[0])

            if sPart == 'lower':
                cmds.pointConstraint(sChildJoint, sNoTwists[0])

            if sPart == 'upper':
                xforms.resetJoint(sNoTwists[0])
            else:
                cmds.delete(cmds.orientConstraint(sCurrentOuts[1], sNoTwists[0]))

            cmds.makeIdentity(sNoTwists[0], apply=True, r=True)
            sNoTwistIkParent = self._createTransform('%sNoTwistIkParent' % sPart, sParent=self.sDetailsGrp)
            xforms.matrixParentConstraint(sMeasure, sNoTwistIkParent, skipScale=['x','y','z'])
            xforms.createIk(sNoTwists[0], sNoTwists[1], sNoTwists[0], sParent=sNoTwistIkParent, sName=self._createNodeName('unTwist','ik'))
            sMeasureTwist = self._createTransform('%sMeasureTwist' % sPart, sParent=sNoTwists[0], fLocalPos=[0,0,0])
            cmds.orientConstraint(sMeasure, sMeasureTwist, skip=['y','z'])

            aPoints = np.zeros((iCount,3), dtype='float64')
            fLenghParam = float(len(ffParams[p]))
            fShrinkedToLastLength = fLength if ffParams[p][-1] < 1.0 else fLength  * ((fLenghParam-1.0) / fLenghParam)
            aPoints[:,0] = np.array(ffParams[p], dtype='float64') * fShrinkedToLastLength * self.fSideMultipl
            sTwists = xforms.createJointChain(aPoints, self._createNodeName('%sTwist' % sPart, 'jnt', iCount=iCount),
                                              sParent=self.sDetailsGrp, fRadius=cmds.getAttr('%s.radius' % self.dBlueprints['up']), sSide=self.sSide)
            cmds.setAttr('%s.jo' % sTwists[0], 0, 0, 0)

            sNoRotateTransform = sCurrentOuts[1] if p == 1 else sNoTwists[0]

            xforms.matrixParentConstraint(sNoRotateTransform, sTwists[0], skipScale=['x', 'y', 'z'])
            dTempTwistValues = {}
            for i in range(1, iCount, 1):
                fTwistValue = ffParams[p][i]-ffParams[p][i-1]
                try:
                    sTwistMultipl = dTempTwistValues[fTwistValue]
                except:
                    sTwistMultipl = nodes.fromEquation('%s.rx * %f' % (sMeasureTwist, fTwistValue),
                                                       sName=self._createNodeName('twistAmount%03d' % round(fTwistValue*100)))
                cmds.connectAttr(sTwistMultipl, '%s.rx' % sTwists[i])
                dTempTwistValues[fTwistValue] = sTwistMultipl

            if self.bLimbsAreScaling:
                for sT in sTwists[1:]:
                    nodes.fromEquation('%s * %f' % (sScales[p], cmds.getAttr('%s.tx' % sT)), sTarget='%s.tx' % sT,
                                       sName=self._createNodeName('twistScalePerJoint'), bDoUnitConversionNodes=True)

            dTwistJoints[sPart] = sTwists
            dTwistOutputs[sPart] = OrderedDict()
            for i,sT in enumerate(sTwists):
                dTwistOutputs[sPart][self._getTwistName(sPart,i)] = sT


        # if not self.bIsBackLeg:
        #     sTempAim = cmds.createNode('transform', n='tempAim')
        #     cmds.delete(cmds.pointConstraint(self.dBlueprints['elbow'], sTempAim))
        #     fUpPos = cmds.xform(self.dBlueprints['up'], q=True, ws=True, t=True)
        #     cmds.setAttr('%s.ty' % sTempAim, fUpPos[1])
        #     cmds.delete(cmds.aimConstraint(sTempAim, sNoTwistsParentUpper, worldUpObject=self.dBlueprints['up'],
        #                                    upVector=[0,1,0], aimVector=[fSideMultipl,0,0], worldUpType='objectrotation'))
        #     cmds.delete(sTempAim)


        self.dOutputs.update(dTwistOutputs['upper'])
        self.dOutputs.update(dTwistOutputs['lower'])

        cmds.parent(dTwistJoints['lower'][0], dTwistJoints['upper'][-1]) # that gives issue in maya 2018
        xforms.bugFixCleanConstraint2018(dTwistJoints['lower'][0])

        sPrevWrist = cmds.rename(self.dOutputs['wrist'], self._createNodeName('prevOutWrist', 'joint'))
        sPrevFingers = cmds.rename(self.dOutputs['fingers'], self._createNodeName('prevOutFingers', 'joint'))
        sPrevFingersMid = cmds.rename(self.dOutputs['fingersMid'], self._createNodeName('prevOutFingersMid', 'joint'))
        sPrevEnd = cmds.rename(self.dOutputs['end'], self._createNodeName('prevOutEnd', 'joint'))

        sWristOutJoint = xforms.createJoint(self.dOutputs['wrist'], sParent=dTwistOutputs['lower'][list(dTwistOutputs['lower'].keys())[-1]],
                                            fSize=cmds.getAttr('%s.radius' % sPrevWrist))
        xforms.createJoint(self.dOutputs['fingers'], sParent=sWristOutJoint, fSize=cmds.getAttr('%s.radius' % sPrevFingers))
        xforms.createJoint(self.dOutputs['fingersMid'], sParent=self.dOutputs['fingers'], fSize=cmds.getAttr('%s.radius' % sPrevFingers))
        xforms.createJoint(self.dOutputs['end'], sParent=self.dOutputs['fingersMid'], fSize=cmds.getAttr('%s.radius' % sPrevEnd))

        xforms.matrixParentConstraint(sCurrentOuts[2], self.dOutputs['wrist'])
        xforms.matrixParentConstraint(sPrevFingers, self.dOutputs['fingers'])
        xforms.matrixParentConstraint(sPrevFingersMid, self.dOutputs['fingersMid'])
        xforms.matrixParentConstraint(sPrevEnd, self.dOutputs['end'])

        self.sSkinJoints = list(dTwistOutputs['upper'].values()) + list(dTwistOutputs['lower'].values()) + [self.dOutputs['wrist'], self.dOutputs['fingers'], self.dOutputs['fingersMid'], self.dOutputs['end']]
        return cCtrls, dAttacherBuildData




    def childrenConnect_LFinger(self, _lChildren):
        sMetasParent = self._createTransform('metaParent')
        xforms.matrixParentConstraint(self.dOutputs['wrist'], sMetasParent)

        for f, tToe in enumerate(_lChildren):
            if tToe.iIsThumb == 1:
                xforms.matrixParentConstraint(self.dOutputs['wrist'], tToe.cFkCtrls[0].sPasser, mo=True)
            elif tToe.iIsThumb == 2:
                xforms.matrixParentConstraint(self.dOutputs['fingers'], tToe.cFkCtrls[0].sPasser, mo=True)
            elif tToe.iIsThumb == 0:
                # for sTransform in tToe.sArmConnectWristTransforms:
                xforms.matrixParentConstraint(self.dOutputs['wrist'], tToe.cFkCtrls[0].sPasser, mo=True, skipScale=['x', 'y', 'z'])
                xforms.matrixParentConstraint(self.dOutputs['wrist'], tToe.sMetaStartTransform, mo=True, skipScale=['x', 'y', 'z'])

                xforms.matrixParentConstraint(self.dOutputs['fingers'], tToe.cMetaIk.sPasser, mo=True, skipRotate=['x', 'y', 'z'], skipScale=['x','y','z']) # translation
                xforms.matrixParentConstraint(self.dOutputs['wrist'], tToe.cMetaIk.sPasser, mo=True, skipTranslate=['x', 'y', 'z'], skipScale=['x','y','z']) # rotation

                xforms.matrixParentConstraint(self.dOutputs['fingers'], tToe.cFkCtrls[0].appendOffsetGroup('parentToFinger') , mo=True, skipScale=['x','y','z'], skipTranslate=['x','y','z'])

                cmds.scaleConstraint(self.dOutputs['wrist'], tToe.sMetaStartTransform, mo=True)
                cmds.scaleConstraint(self.dOutputs['wrist'], tToe.sCurrentFeatureGrp, mo=True)
                cmds.scaleConstraint(self.dOutputs['wrist'], tToe.cFkCtrls[0].sPasser, mo=True)

                # self.sArmConnectionScaleTransforms += [sMetaStartTransform, self.sCurrentFeatureGrp]
                # if iFkIk in [0, 2]:
                #     self.sArmConnectionScaleTransforms.append(self.cFkCtrls[0].sPasser)

                # for sTransform in tToe.sArmConnectionScaleTransforms:
                #

                tToe.sSkeletonParent = (self.dOutputs['wrist'], self, 'wrist')

                # segments tag
                sMetaOutput = utils.replaceStringEnd(tToe.dOutputs['meta'], 'Scale', '')
                sCrossHierarchy = _lChildren[f+1].dOutputs['meta'] if f < len(_lChildren)-1 else None
                if sCrossHierarchy:
                    sCrossHierarchy = utils.replaceStringEnd(sCrossHierarchy, 'Scale', '')

                dSegmentsTag = {'iPriority':len(_lChildren)-f, 'sCrossHierarchy':sCrossHierarchy}
                segments.updateTagAttr(sMetaOutput, dSegmentsTag)
                cmds.select(tToe.dOutputs['meta'])

        #
        # BAKED IK
        #
        sAdjustGrp = cmds.createNode('transform', n='grp_adjustToeIks')
        sTempGrp = cmds.createNode('transform', n='grp_tempToeIkStuff')


        sMidJoint = self.dOutputs['fingersMid']  # 'jnt_%s_%sFingersMid' % (sSide,sLimb)
        sSignedAngle = nodes.createAdditionNode(['%s.rz' % sMidJoint, cmds.getAttr('%s.rz' % sMidJoint)], sOperation='minus')
        sSignedAngle = nodes.createMultiplyNode(sSignedAngle, -1)

        for f, tToe in enumerate(_lChildren):
            if not tToe.iIsThumb:
                sChain = [tToe.dOutputs['base']]#['jnt_%s_%sBase' % (sSide, sName)]

                if not cmds.objExists(sChain[0]):
                    continue

                for i in range(100):
                    sChain.append(cmds.listRelatives(sChain[-1], c=True, p=False, typ='joint')[0])
                    if sChain[-1].endswith('END'):
                        break

                sAttrs = ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']
                sTempIkGrp = cmds.createNode('transform', n='grp_tempIk_%s' % tToe.sLimbName, p=sTempGrp)
                cmds.delete(cmds.parentConstraint(sChain[0], sTempIkGrp))
                cmds.select(sChain[0], sTempIkGrp)

                # cmds.parentConstraint('jnt_%s_%sMeta' % (sSide, sName), sTempIkGrp, mo=True)
                cmds.parentConstraint(tToe.dOutputs['meta'], sTempIkGrp, mo=True)
                sTempIkChain = xforms.duplicateJoinChain(sChain, 'tempIk_%s' % tToe.sLimbName, sParent=sTempIkGrp)
                [cmds.makeIdentity(sJ, r=True, apply=True) for sJ in sTempIkChain]
                sTempIk = xforms.createIk(sTempIkChain[0], sTempIkChain[-2], sParent=sTempGrp)
                sTempLoc = xforms.createLocator('loc_%sTempLoc' % tToe.sLimbName, sMatch=sTempIk, sParent=sAdjustGrp)
                cmds.parentConstraint(sTempLoc, sTempIkChain[-2], skipTranslate=['x','y','z'], mo=True)
                cmds.delete(cmds.parentConstraint(sTempIk, sTempLoc))
                cmds.parentConstraint(sTempLoc, sTempIk)

                sDistance = nodes.createDistanceNode(sTempIkGrp, sTempLoc, fNormalized=1.0)
                nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sTempIkChain[1]), sDistance, sTarget='%s.tx' % sTempIkChain[1])
                nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sTempIkChain[2]), sDistance, sTarget='%s.tx' % sTempIkChain[2])

                for p,cCtrl in enumerate(tToe.cFkCtrls[:3]):
                    sOffset = cCtrl.appendOffsetGroup('inversekinematic')

                    sTempTransform = xforms.createTransform('temp', sMatch=sOffset, sParent=sTempIkChain[p])
                    fDrivers = tToe.fBakedIkBallRollLimit * np.arange(tToe.iBakedIkKeyCount) / (tToe.iBakedIkKeyCount-1)
                    ffValues = []
                    for i in range(tToe.iBakedIkKeyCount):
                        cmds.setAttr(self.sBallRollAttr, fDrivers[i])
                        cmds.delete(cmds.parentConstraint(sTempTransform, sOffset))
                        ffValues.append([cmds.getAttr('%s.%s' % (sOffset,sA)) for sA in sAttrs])
                    # cmds.delete(sTempTransform)
                    aaValues = np.array(ffValues, dtype='float64').T
                    if len(sAttrs) != len(aaValues):
                        raise 'wrong length: %d %d' % (len(sAttrs), len(aaValues))

                    cmds.setAttr(self.sBallRollAttr, 0.0)
                    for sA, fValues in zip(sAttrs, aaValues):
                        nodes.setDrivenKey(sSignedAngle, fDrivers, '%s.%s' % (sOffset, sA), fValues, sInTanType='linear', sOutTanType='linear')

                #
                # toe Curl
                #
                fRotStrenghes = [0.1, 0.3, 0.6]
                fNegAngle = nodes.createConditionNode(sSignedAngle, '<', 0, nodes.createMultiplyNode(sSignedAngle, -1), 0)
                for cCtrl in tToe.cFkCtrls:
                    sOffset = cCtrl.appendOffsetGroup('toecurl')
                    nodes.createMultiplyNode(fNegAngle, fRotStrenghes[p], sTarget='%s.rx' % sOffset)

        cmds.delete(sTempGrp, sAdjustGrp)




    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        # if lChildren:
        #     segments.updateTagAttr(self.dOutputs['fingers'], {'bDisable':True})



    def buildBlueprintRig(self, lParent=None, buildBlueprintRig=0):
        
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        self.cGroupHand = blueprints.createGroupCtrl(self.dBlueprints['wrist'], sSide=self.sSide, xCtrl='%sGrpHand' % self.sName, sParent=self.sBpTopGrp, fCtrlSize=5.0)

        cArmCtrls = blueprints.createChainCtrls([self.dBlueprints['up'], self.dBlueprints['elbow'], self.dBlueprints['wrist']],
                                                sSide=self.sSide, xRoot='%sUpper' % self.sName, xAim='%sHand' % self.sName, xPole='%sPole' % self.sName, sParent=self.sBpTopGrp)
        
        cWristCtrls = blueprints.createChainCtrls([self.dBlueprints['wrist'], self.dBlueprints['fingers']], sSide=self.sSide, sParent=self.sBpTopGrp, fUpVectorDistanceMultipl=5.0,
                                                xRoot=cArmCtrls[-1], xAim='%sFingers' % self.sName, xPole='%sPoleWrist' % self.sName, bParentAimUnderRoot=True)

        cFingerCtrls = blueprints.createChainCtrls([self.dBlueprints['fingers'], self.dBlueprints['fingersMid'], self.dBlueprints['end']], sSide=self.sSide, sParent=self.sBpTopGrp, fUpVectorDistanceMultipl=5.0,
                                                xRoot=cWristCtrls[-1], xAim='%sFingersEnd' % self.sName, xPole='%sPoleFingers' % self.sName, bParentAimUnderRoot=True)


        cHeelCtrl = blueprints.createCtrl(self.dBlueprints['heelPivot'], sSide=self.sSide, xCtrl='%sHeel' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cToesCtrl = blueprints.createCtrl(self.dBlueprints['toesPivot'], sSide=self.sSide, xCtrl='%sToes' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cIkCtrl = blueprints.createCtrl(self.dBlueprints['print'], sSide=self.sSide, xCtrl='%sPrint' % self.sName, sParent=self.sBpTopGrp, iColorIndex=3) #, iRotateOrder='zxy')
        cInCtrlA = blueprints.createCtrl(self.dBlueprints['inPivotA'], sSide=self.sSide, xCtrl='%sInA' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cOutCtrlA = blueprints.createCtrl(self.dBlueprints['outPivotA'], sSide=self.sSide, xCtrl='%sOutA' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cInCtrlB = blueprints.createCtrl(self.dBlueprints['inPivotB'], sSide=self.sSide, xCtrl='%sInB' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cOutCtrlB = blueprints.createCtrl(self.dBlueprints['outPivotB'], sSide=self.sSide, xCtrl='%sOutB' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)

        for cC in [cHeelCtrl, cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB]:
            cmds.setAttr('%s.ty' % cC.sCtrl, lock=True)

        self.cBpRoots = [cArmCtrls[0], self.cGroupHand]
        cBpAll = cArmCtrls + cWristCtrls + cFingerCtrls + [cHeelCtrl, cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB, cIkCtrl, self.cGroupHand]
        self.cBpAll = list(set(cBpAll))
        
        for cC in cWristCtrls + cFingerCtrls + [cIkCtrl]:
            if not cmds.parentConstraint(cC.sPasser, q=True):
                cmds.parentConstraint(self.cGroupHand.sOut, cC.sPasser, mo=True)
        for cC in [cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB, cHeelCtrl]:
            cmds.parentConstraint(cIkCtrl.sOut, cC.sPasser, mo=True)






    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):
        
        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)
        
        tThumbs = [tC for tC in lChildren if 'thumb' in tC.sLimbName]
        for tThumb in tThumbs:
            for cRoot in tThumb.cBpRoots:
                xforms.matrixParentConstraint(self.cGroupHand.sOut, cRoot.sPasser, mo=True, skipScale=['x','y','z'])


        tToes = [tC for tC in lChildren if 'kangarooLimbs.finger_' in str(type(tC)) and 'thumb' not in tC.sLimbName]

        if len(tToes) >= 3:

            tOuterFingers = (tToes[0], tToes[-1])
            tInnerFingers = tToes[1:-1]

            cBpCtrls = []
            cBpCtrls += blueprints.innerOuterCtrlSetup(['%sMetaOuterStart' % self.sName, '%sMetaOuterEnd' % self.sName],
                                                        cOuterCtrls=[tOuterFingers[0].cBpRoots[0], tOuterFingers[1].cBpRoots[0]],
                                                        cInnerCtrls=[tF.cBpRoots[0] for tF in tInnerFingers],
                                                        sParent=self.sBpTopGrp, sSide=self.sSide, fSize=1,
                                                        sPolePos=tOuterFingers[0]._cBpMetaPole.sOut)
            cBpCtrls += blueprints.innerOuterCtrlSetup(['%sBaseOuterStart' % self.sName, '%sBaseOuterEnd' % self.sName],
                                                        cOuterCtrls=[tOuterFingers[0].cBpRoots[1], tOuterFingers[1].cBpRoots[1]],
                                                        cInnerCtrls=[tF.cBpRoots[1] for tF in tInnerFingers],
                                                        sParent=self.sBpTopGrp, sSide=self.sSide, fSize=1,
                                                        sPolePos=tOuterFingers[0]._cBpBasePole.sOut)
            cBpCtrls += blueprints.innerOuterCtrlSetup(['%sEndOuterStart' % self.sName, '%sEndOuterEnd' % self.sName],
                                                        cOuterCtrls=[tOuterFingers[0].cBpRoots[2], tOuterFingers[1].cBpRoots[2]],
                                                        cInnerCtrls=[tF.cBpRoots[2] for tF in tInnerFingers],
                                                        sParent=self.sBpTopGrp, sSide=self.sSide, fSize=1,
                                                        sPolePos=tOuterFingers[0]._cBpBasePole.sOut)

            for cCtrl in cBpCtrls:
                cmds.parentConstraint(self.cGroupHand.sOut, cCtrl.sPasser, mo=True)

            self.cBpAll += cBpCtrls

        else: # only 2 or less fingers
            for tToe in tToes:
                for cRoot in tToe.cBpRoots:
                    cmds.parentConstraint(self.cGroupHand.sOut, cRoot.sPasser, mo=True)


