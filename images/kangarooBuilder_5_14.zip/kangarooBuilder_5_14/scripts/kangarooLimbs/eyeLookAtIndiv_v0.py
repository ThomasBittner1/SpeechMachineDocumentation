###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.cmds as cmds
import numpy as np

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTools.constraints as constraints
import kangarooTools.barycentric as barycentric
import kangarooTools.blueprints as blueprints
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils


class LEyeLookAtIndiv(baseLimb._LBaseLimb):
    def __init__(self, sName='eyeLookAtIndiv', sSide='m', bForceParentSkeletonToRoot=False,
                fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0),
                fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0), bEyelidBlink=False, fLidFollowDefault=0.5):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset)

        self.bEyelidBlink = bEyelidBlink
        self.sDefaultFeatures = ['feature_lookAt']
        self.fLidFollowDefault = fLidFollowDefault


    def generateAttachers_init(self, **args):
        return {'root': {'sTrs':'tr', 'bMulti':True},
                'scale': {'sTrs':'s', 'bMulti':False},
                'eye': {'sTrs': 'c', 'bMulti': False}}


    def createOrSetBlueprints(self, lParent=None):
        return self._fillBlueprints([[(0, 0, 5)]], [['main']])


    def generateAttachers_lookat(self, **args):
        return {} #['lookAt']


    def feature_lookAt(self):
        dAttacherBuildData = {}
        self.cLookAt = self._createCtrl4(sName='', sAttrs=['t'],
                                    fSize=cmds.getAttr('%s.radius' % self.dBlueprints['main']) * 5.0, sShape='locator', sMatch=self.dBlueprints['main'])

        dAttacherBuildData['root'] = (utils.getDagPath(self.cLookAt.sPasser), self.cLookAt)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        dAttacherBuildData['eye'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cLookAt.sPasser)

        return [], [self.cLookAt], dAttacherBuildData



    def connectEye(self, tEye):
        self.tEye = tEye
        aLookAtStart = np.array(cmds.xform(self.dBlueprints['main'], q=True, ws=True, t=True), dtype='float64')

        aStartPosition = np.array(cmds.xform(tEye.dBlueprints['main'], q=True, ws=True, t=True), dtype='float64')
        aEndPosition = np.array(cmds.xform(tEye.dBlueprints['end'], q=True, ws=True, t=True), dtype='float64')


        aDir = aEndPosition - aStartPosition
        aDir /= np.linalg.norm(aDir)

        fDistance = np.linalg.norm(aLookAtStart - aStartPosition)
        aLookAtNew = aStartPosition + aDir*fDistance
        sMatchEyeDirectionOffset = self.cLookAt.appendOffsetGroup('matcheyedirection')
        cmds.move(aLookAtNew[0], aLookAtNew[1], aLookAtNew[2], sMatchEyeDirectionOffset, ws=True, a=True)

        # mLookAtMatrix = OpenMaya2.MMatrix(cmds.xform(self.cLookAt.sCtrl, q=True, m=True, ws=True))




        sAimOffset = tEye.cCtrl.appendOffsetGroup('aim')
        sAim = self._createTransform('%sAim' % tEye.sLimbName, sParent=tEye.cTransform.sOut)

        sPasserTransformCopy = xforms.createTransform(sName='grp_%s_eyeTransformPasserCopy' % tEye.sSide,
                                                      sParent=tEye.cTransform.sPasser)
        sCopyAimConstraint = constraints.aimConstraintEmpty(sPasserTransformCopy)
        nodes.createVectorAdditionNode([[1, 0, 0]], sTarget='%s.target[0].targetTranslate' % sCopyAimConstraint)
        nodes.createMultMatrixNode(
            ['%s.worldMatrix' % tEye.cTransform.sOut, '%s.parentInverseMatrix' % sPasserTransformCopy],
            sTarget='%s.worldUpMatrix' % sCopyAimConstraint)

        nodes.createPointByMatrixNode(nodes.getWorldPoint(self.cLookAt.sOut),
                                      '%s.worldInverseMatrix' % sPasserTransformCopy, sTarget='%s.t' % sAim)  #####
        fSideMultipl = -1.0 if tEye.sSide == 'r' else 1.0
        constraints.aimConstraintFromTransforms(sAimOffset, sAim, tEye.cTransform.sOut, bOrientUp=True,
                                                sParent=self.sCurrentFeatureGrp, aim=[1, 0, 0],
                                                up=[0, fSideMultipl, 0])
        curves.createPoleVectorLine(self.cLookAt, tEye.dOutputs['main'])

        # mAimMatrix = OpenMaya2.MMatrix(cmds.xform(self.cLookAt.sCtrl, q=True, ws=True, m=True))
        # mLocalAimMatrix = OpenMaya2.MTransformationMatrix(mAimMatrix * mLookAtMatrix.inverse())
        # aLocalPositions[e] = mLocalAimMatrix.translation(OpenMaya2.MSpace.kWorld)


        sEyeJoints = [tEye.dOutputs['main'], tEye.dOutputs['end']]
        sPupilAttr = utils.addAttr(self.cLookAt.sCtrl, ln='pupilScale', minValue=0.2, maxValue=3, defaultValue=1.0, k=True)
        cmds.connectAttr(sPupilAttr, '%s.sx' % sEyeJoints[1])
        cmds.connectAttr(sPupilAttr, '%s.sy' % sEyeJoints[1])
        cmds.connectAttr(sPupilAttr, '%s.sz' % sEyeJoints[1])

        # help attr for the eyespecs
        utils.addStringAttr(self.cLookAt.sCtrl, 'sEyeJoint', tEye.dOutputs['main'])

        # follow plugs
        sLidFollow = utils.addAttr(self.cLookAt.sCtrl, ln='lidFollow', minValue=0.0, maxValue=10,
                                   defaultValue=self.fLidFollowDefault, k=True)

        # sFollowParent = cmds.createNode('transform', n='grp_%s_followMeasureParent%s' % (tEye.sSide, tEye.sName))
        self.sEndPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(sEyeJoints[1]),
                                                       '%s.worldInverseMatrix' % tEye.cCtrl.sPasser)
        sLookX = utils.addAttr(self.cLookAt.sPasser, ln='lookHoriz', k=False, cb=True)
        sLookY = utils.addAttr(self.cLookAt.sPasser, ln='lookVert', k=False, cb=True)

        fLength = cmds.getAttr('%s.tx' % sEyeJoints[1])

        sResetLook = nodes.createVectorAdditionNode([['%sZ' % self.sEndPoint, '%sY' % self.sEndPoint, 0],
                                                     [cmds.getAttr('%sZ' % self.sEndPoint),
                                                      cmds.getAttr('%sY' % self.sEndPoint), 0]],
                                                    sOperation='minus')

        if fLength < 0:
            sResetLook = nodes.createVectorMultiplyNode(sResetLook, -1, bVectorByScalar=True)

        sAdjustedLook = nodes.createVectorMultiplyNode(sResetLook, sLidFollow, bVectorByScalar=True)
        cmds.connectAttr('%sX' % sAdjustedLook, sLookX)
        cmds.connectAttr('%sY' % sAdjustedLook, sLookY)

        sLookDown = utils.addAttr(self.cLookAt.sPasser, ln='lookVertDown', k=False, cb=True)
        nodes.createConditionNode(sLookY, '<', 0, nodes.createMultiplyNode(sLookY, -1), 0, sTarget=sLookDown)
        sLookUp = utils.addAttr(self.cLookAt.sPasser, ln='lookVertUp', k=False, cb=True)
        nodes.createConditionNode(sLookY, '>', 0, sLookY, 0, sTarget=sLookUp)


    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        cCtrl = blueprints.createCtrl(self.dBlueprints['main'],
                                      sSide=self.sSide,
                                      xCtrl='%sMain' % self.sName,
                                      sParent=self.sBpTopGrp)
        cCtrls = [cCtrl]
        self.cBpRoots = cCtrls
        self.cBpAll = cCtrls




    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)
        sAttr = '%s.eye0' % (self.sCurrentFeatureGrp)
        if not cmds.objExists(sAttr):
            return
        sObj = cmds.listConnections(sAttr)[0]
        sEyeLimb = cmds.getAttr('%s.sLimbName' % sObj)
        tEye = dCreatedLimbs[sEyeLimb]

        self.connectEye(tEye)
