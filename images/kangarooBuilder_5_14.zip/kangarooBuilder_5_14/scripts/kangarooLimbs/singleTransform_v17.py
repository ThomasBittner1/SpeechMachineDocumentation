###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import math
import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTabTools.segments as segmentsTools
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.constraints as constraints

import kangarooTools.utilsUnreal as utilsUnreal


class LSingleTransform(baseLimb._LBaseLimb):
    def __init__(self, sName='singleTransform', sSide='m',
                bSegmentPlanes=True, bNoJoint=False, iColorIndex=0,
                bForceParentSkeletonToRoot=False, bMirrorOrient=True, iSegmentsPriority=0, bIsBpBarent=False, sBlueprintMirrorPlane='', sDisplayAttr='display_ctrl.body'):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide, bIsBpBarent=bIsBpBarent,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot, iSegmentsPriority=iSegmentsPriority, sBlueprintMirrorPlane=sBlueprintMirrorPlane)

        # self.bPostRefJoint = bPostRefJoint
        self.sDisplayAttr = sDisplayAttr

        self.bNoJoint = bNoJoint

        self.dOutputs['main'] = None

        self.bSegmentPlanes = bSegmentPlanes
        self.bMirrorOrient = bMirrorOrient

        self.sDefaultFeatures = ['feature_fk']

        self.iColorIndex = iColorIndex


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':False},
                'scale': {'sTrs':'s', 'bMulti':False}}


    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(0,0,0,1,0,0, None, None, self.bMirrorOrient)]], [['main']])
        self.sBlueprintJoints = [self.dBlueprints[sN] for sN in ['main']]
        return sNewJoints


    def generateAttachers_fk(self, **kwargs):
        dMain = {'sTrs':'tr', 'bMulti':True}
        if kwargs['bLocalAttacher']:
            dMain['sLocals'] = ['local']
        return {'main':dMain}




    def feature_fk(self, bNoCtrl=False,
                   sCtrlShape='cube', fScaleCtrlShape=(1.0, 1.0, 1.0), fRotateCtrlShape=(0.0, 0.0, 0.0),
                   sDoTranslation='xyz', sDoRotation='xyz', sDoScale='', iRotateOrder=2, bAddRotationOrderAttribute=True, iSlider=2,
                   bAddSuperCtrl=False, bAddChildCtrl=False, bAddPivotCtrl=False,
                   bSpring=False, bLocalAttacher=False, iFaceExtraMove=0, bPostRefJoint=False, _dComboboxItems={'iSlider':['off', 'on', 'on negate right'], 'iFaceExtraMove':['off', 'SquashStretch Ctrls']}):

        self.fRotateCtrlShape = fRotateCtrlShape
        dAttacherBuildData = {}

        if self.bNoJoint:
            fks = [self._createTransform('transform')]
        else:
            fks = xforms.duplicateJoinChain(self.sBlueprintJoints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)
        sAttrs = []

        sAttrs += ['t%s' % a for a in set(sDoTranslation)]
        sAttrs += ['r%s' % a for a in set(sDoRotation)]
        if sDoScale == 'uniform':
            sAttrs.append('scaleUF')
        else:
            sAttrs += ['s%s' % a for a in set(sDoScale)]
        if bAddRotationOrderAttribute:
            sAttrs.append('ro')

        fScaleCtrlShape = list(fScaleCtrlShape)

        if sCtrlShape == 'square':
            sCtrlShape = 'squareY'
        self.cCtrl = self._createCtrl9(sName='', sMatch=self.dBlueprints['main'], sAttrs=sAttrs, bSuper=bAddSuperCtrl, bChild=bAddChildCtrl, bPivot=bAddPivotCtrl, iRotateOrder=iRotateOrder,
                                        sShape=sCtrlShape, fSize=cmds.getAttr('%s.radius' % self.dBlueprints['main'])*5, fRotateShape=fRotateCtrlShape, fScaleShape=fScaleCtrlShape, iColorIndex=self.iColorIndex, iSlider=iSlider)


        if bSpring:
            sEnable = utils.addOffOnAttr(self.cCtrl.sCtrl, 'springEnable', bDefaultValue=False, bNoAnim=True)
            # sStartFrame = utils.addAttr(self.cCtrl.sCtrl, ln='springStartFrame', at='long', defaultValue=1, k=False, cb=True)
            sStartFrame = utils.addAttr('master', ln='dynamicsStartFrame', at='long', defaultValue=1, k=False, cb=True, bReturnIfExists=True)
            sStrength = utils.addAttr(self.cCtrl.sCtrl, ln='springStrength', minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True)
            sStrengthEnable = nodes.createConditionNode(sEnable, '==', 1, sStrength, 0.0)
            sStiffness = utils.addAttr(self.cCtrl.sCtrl, ln='springStiffness', minValue=0.0, maxValue=1.0, defaultValue=0.1, k=True)
            sSpringOffset = self.cCtrl.appendOffsetGroup('spring')
            sDamping = utils.addAttr(self.cCtrl.sCtrl, ln='springDamping', minValue=0.0, maxValue=1.0, defaultValue=0.1, k=True)
            sPrevFrame = utils.addAttr(self.cCtrl.sCtrl, ln='springPrevFrame', minValue=0.0, maxValue=1.0, defaultValue=0)
            utils.addAttr(self.cCtrl.sCtrl, ln='velocityX')
            utils.addAttr(self.cCtrl.sCtrl, ln='velocityY')
            utils.addAttr(self.cCtrl.sCtrl, ln='velocityZ')
            sVelocity = '%s.velocity' % self.cCtrl.sCtrl

            sPosOut = xforms.createLocator(self._createNodeName('springOut', 'loc'), sParent=self.cCtrl.sPasser)
            cmds.setAttr('%s.v' % sPosOut, False)
            cmds.setAttr('%s.inheritsTransform' % sPosOut, False)

            sTargetWorld = cmds.createNode('transform', n=self._createNodeName('springIn', 'grp'), p=self.cCtrl.sPasser)
            cmds.setAttr('%s.inheritsTransform' % sTargetWorld, False)
            cmds.pointConstraint(cmds.listRelatives(sSpringOffset, p=True)[0], sTargetWorld)

            sN,sA = sStrengthEnable.split('.')
            xforms.constraintBlend(sSpringOffset, cmds.listRelatives(sSpringOffset, p=True)[0], sPosOut, sN, sA, func=cmds.pointConstraint)
            utils.addStringAttr(self.cCtrl.sCtrl, 'sDynamicJoint', sSpringOffset, bLock=True)
            utils.addStringAttr(self.cCtrl.sCtrl, 'sDynamicSwitch', sEnable, bLock=True)

            sExpr = '''

if (frame == {5})
{{
	{2}X = 0;
	{2}Y = 0;
	{2}Z = 0;
	{4}.tx = {3}.tx;
	{4}.ty = {3}.ty;
	{4}.tz = {3}.tz;
}}
else
{{
    vector $target = <<{3}.translateX, {3}.translateY, {3}.translateZ>>;
    vector $vel = <<{2}X, {2}Y, {2}Z>>;
    vector $posDyn = <<{4}.translateX, {4}.translateY, {4}.translateZ>>;

    $acc = ($target - $posDyn) * {0} - $vel * {1};
    $vel += $acc;
    
    $posDyn += $vel;
      
    {4}.tx = $posDyn.x;
    {4}.ty = $posDyn.y;
    {4}.tz = $posDyn.z;
    {2}X = $vel.x;
    {2}Y = $vel.y;
    {2}Z = $vel.z; 
}}
{6} = frame;

            '''.format(sStiffness, sDamping, sVelocity, sTargetWorld, sPosOut, sStartFrame, sPrevFrame)
            sExpression = cmds.expression(s=sExpr, ae=True, n=self._createNodeName('spring', 'exp'))
            nodes.createConditionNode(sEnable, '==', True, 0, 1, sTarget='%s.nodeState' % sExpression)

        sAttacherOffset = self.cCtrl.appendOffsetGroup('attacher')

        if iFaceExtraMove:
            self.cCtrl.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND', 'skinCluster__*face*__BENDTOP'])
            constraints.matrixParentConstraint(self.cCtrl.sOut, fks[0], sJumpOverTransforms=[self.cCtrl.sExtraMove, self.cCtrl.sPasser], mo=True)
        else:
            xforms.matrixParentConstraint(self.cCtrl.sOut, fks[0], skipScale=[])

        dAttacherBuildData['root'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)
        dAttacherBuildData['main'] = (utils.getDagPath(sAttacherOffset), self.cCtrl)


        if bPostRefJoint:
            sRefJ = cmds.createNode('joint', n=self._createNodeName('ref', 'jnt'), p=sAttacherOffset)
            xforms.matchXform(fks[0], sRefJ)
            cmds.setAttr('%s.radius' % sRefJ, self.fBlueprintsDiagonal * 0.025)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sRefJ)

            utils.addStringAttr(fks[0], deformers.kPostRefJointAttr, sRefJ)
            if not cmds.objExists('jnt_m_zero'):
                cmds.createNode('joint', n='jnt_m_zero', p='modules')

            if iFaceExtraMove:
                constraints.matrixParentConstraint(sAttacherOffset, sRefJ, sJumpOverTransforms=[self.cCtrl.sExtraMove, self.cCtrl.sPasser], mo=True)


        if bLocalAttacher:
            self.dLocalAttacherOutputs['main'] = ['local.%s' % self.cCtrl.sPasser]


        if bNoCtrl:
            self.cCtrl.convertToSimpleTransforms()
            cReturnCtrls = []
        else:
            cReturnCtrls = [self.cCtrl]

        if not self.bNoJoint:
            cmds.addAttr(fks[0], ln='_forceKeepForGames_', k=True)

        # self.dCtrlReplacements[self.getOutputFullNames()[0]] = self.cCtrl.sCtrl
        return fks, cReturnCtrls, dAttacherBuildData


    def unreal_feature_fk(self):
        if self.sLimbName == 'm_global':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal
            sCommands = []
            sCommands.append('### SINGLETRANSFORM 12')
            # sCommands.append('controllers.setNewColumn()')

            sCtrl = utilsUnreal.createUnrealCtrl(self.cCtrl, fCtrlOrient=self.fRotateCtrlShape, sWriteCommands=sCommands)


            sJoint = self.getOutputFullNames()[0]
            if self.bNoJoint:
                if self.sLimbName == 'm_placement' and cmds.objExists('game:root'):
                    sJoint = 'root'
                else:
                    sJoint = None

            sFunctionNodeName = '%s_feature_fk_node' % self.sLimbName

            utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk', sWriteCommands=sCommands)

            sChildMaintainBoneString = "'spine_01'" if self.sLimbName=='m_hips' and utils.data.get('bMetahumanJoints', xDefault=False) else 'None'
            sCommands.append(f"{sFunctionNodeName} = functions.createSingleBoneFunction({sCtrl}, '{sJoint}', sChildMaintainBone={sChildMaintainBoneString})")
            utilsUnreal.initiateAttacherDictCommand('feature_fk', sWriteCommands=sCommands)
            utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, sWriteCommands=sCommands)

            return sCommands, [], []



    def unrealBackwards_feature_fk(self):
        import kangarooTools.utilsUnreal as utilsUnreal

        sCommands = []
        sCommands.append('controllers.setNewColumn()')

        utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk', sWriteCommands=sCommands)

        sJoint = self.getOutputFullNames()[0]
        if self.sLimbName == 'm_cog':
            sJoint = 'jnt_m_spineSpine_000'

        sFunctionNodeName = '%s_feature_fk_node' % self.sLimbName
        sCommands.append(f"{sFunctionNodeName} = functions.createSingleBoneFunction_BACKWARDS({self.cCtrl.sCtrl}, '{sJoint}')")

        utilsUnreal.initiateAttacherDictCommand('feature_fk', sWriteCommands=sCommands)
        utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, sWriteCommands=sCommands)

        return sCommands





    def buildBlueprintRig(self, lParent=None):
        # utils.reload2(blueprints)
        baseLimb._LBaseLimb.buildBlueprintRig(self)
        cCtrl = blueprints.createCtrl(self.dBlueprints['main'],
                                      sSide=self.sSide,
                                      xCtrl='%sMain' % self.sName,
                                      sParent=self.sBpTopGrp,
                                      bSuper=False)

        self.cBpRoots = [cCtrl]
        self.cBpAll = [cCtrl]
        self.dBpOutputs['main'] = cCtrl
        self.cLastBp = cCtrl


    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        if not self.bSegmentPlanes:
            segmentsTools.updateTagAttr(self.dOutputs['main'], {'bDisable':True})
        else:
            segmentsTools.updateTagAttr(self.dOutputs['main'], {'bIsRoot':True, 'iPriority':self.iSegmentsPriority})

        utils.displayTag(self.sDisplayAttr, [self.cCtrl])



