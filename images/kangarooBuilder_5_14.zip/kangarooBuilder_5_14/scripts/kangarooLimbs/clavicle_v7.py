###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.constraints as constraints
import kangarooTools.utilFunctions as utils
import kangarooTabTools.segments as segments

import kangarooLimbs.baseLimb as baseLimb



class LClavicle(baseLimb._LBaseLimb):

    def __init__(self, sName='clavicle', sSide='l', #bMirror=False,
                bForceParentSkeletonToRoot=False,
                fBlueprintsCreationTranslationOffset = (0.0, 0.0, 1.0),
                fBlueprintsCreationRotationOffset = (0.0, 0.0, 0.0), bRemoveEndSkinJoint=False, iSegmentsPriority=50):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset,
                                     bRemoveEndSkinJoint=bRemoveEndSkinJoint, iSegmentsPriority=iSegmentsPriority)
        self.dOutputs['main'] = None
        self.dOutputs['end'] = None
        self.tArm = None

        self.sDefaultFeatures = ['feature_fk']


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':True},
                'scale': {'sTrs':'s', 'bMulti':False}}


    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(0.2,0,1.5, 0,0,1), (5.2,0,1.5, 0,0,1)]], [['start', 'end']])
        return sNewJoints


    def feature_fk(self, fkCtrl=True, bChildCtrl=False, bScale=False, bTranslate=False, bWorldspaceOrient=True):
        dAttacherBuildData = {}
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]
        sJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)
        cCtrls = []
        print('fkCtrl: ', fkCtrl)
        sAttrs = ['r']
        if bTranslate:
            sAttrs.append('t')
        if bScale:
            sAttrs.append('scaleUF')
        self.cFk = self._createCtrl2(sName='', sMatch=self.dBlueprints['start'], sAttrs=sAttrs,
                                    sShape='clavicle',
                                     fSize=cmds.getAttr('%s.radius' % self.dBlueprints['start'])*2,
                                    bIsNoCtrl=not fkCtrl, bChild=bChildCtrl)
        self.cFk.adjustAxisOrientation([0, 90, -90])
        if bWorldspaceOrient:
            self.cFk.orientToNearestStraightMatrix()

        if not fkCtrl:
            cmds.setAttr('%s.v' % self.cFk.sShape, False)

        dAttacherBuildData['root'] = (utils.getDagPath(self.cFk.sPasser), self.cFk)


        xforms.matrixParentConstraint(self.cFk.sOut, sJoints[0], skipRotate=True)
        self.cIk = self._createCtrl2(sName='ik', sMatch=self.dBlueprints['start'], fMatchPos=self.dBlueprints['end'], sAttrs=['t'], sShape='locator',
                               fSize=cmds.getAttr('%s.radius' % self.dBlueprints['start'])*2, bIsNoCtrl=not fkCtrl, iColorIndex=2, bChild=bChildCtrl)
        self.cIk.adjustAxisOrientation([-90, 0, 0]) # this would keep y up
        # self.cFk.adjustAxisOrientation([0, 90, -90])
        if bWorldspaceOrient:
            self.cIk.orientToNearestStraightMatrix()
        cCtrls.append(self.cIk)
        cmds.controller(self.cIk.sCtrl, self.cFk.sCtrl, parent=True)


        xforms.matrixParentConstraint(self.cFk.sOut, self.cIk.sPasser, mo=True)
        fAimVector = cmds.xform(sJoints[1], q=True, os=True, t=True)
        sUpVector = self._createTransform('upVector', fLocalPos=[0,0,2], sParent=sJoints[0])
        cmds.parent(sUpVector, self.sCurrentFeatureGrp)
        # cmds.aimConstraint(self.cIk.sOut, sJoints[0], aim=fAimVector, wut='objectrotation', wuo=self.cFk.sOut)
        constraints.aimConstraintFromTransforms(sJoints[0], self.cIk.sOut, self.cFk.sOut, aim=fAimVector, bOrientUp=True, sParent=self.sCurrentFeatureGrp)
        self.sAimTarget = self.cIk.sOut
        self.mAimJoint = utils.getDagPath(sJoints[0])

        cmds.parentConstraint(self.cFk.sPasser, sUpVector, mo=True)

        sMultMatrix = nodes.createMultMatrixNode(['%s.worldMatrix[0]' % self.cIk.sOut, '%s.worldInverseMatrix[0]' % self.cFk.sOut])
        sDecompPos = nodes.createDecomposeMatrix(sMultMatrix)

        sDistance = nodes.createDistanceNode((0,0,0), sDecompPos)
        if self.sSide == 'r':
            nodes.fromEquation('%s * -1' % sDistance, sTarget='%s.tx' % sJoints[1])
        else:
            cmds.connectAttr(sDistance, '%s.tx' % sJoints[1])

        #global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cFk.sPasser)
        # cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cIk.sPasser)

        return sJoints, [self.cFk, self.cIk], dAttacherBuildData




    def generateOutputs_scale(self, **kwargs):
        dOutputs = {}

        if kwargs['bScaleJoint']:
            dOutputs['scale'] = None

        return dOutputs, []


    def detail_scale(self, bScaleJoint=False):

        if bScaleJoint:
            sOutput = list(self.dOutputs.keys())[0]
            sJoint = list(self.dOutputs.values())[0]
            sChild = list(self.dOutputs.values())[1]
            sSquashJoint = cmds.createNode('joint', n=sJoint.replace('Main', 'Squash'), p=sJoint)

            cmds.setAttr('%s.radius' % sSquashJoint, cmds.getAttr('%s.radius' % sJoint) * 1.5)
            cmds.setAttr('%s.segmentScaleCompensate' % sSquashJoint, False)

            self.dOutputs = utils.createOrderedDictWithInsertedAtIndex(self.dOutputs, ['%sScale' % sOutput, sSquashJoint], 1)

            nodes.createMultiplyNode('%s.tx' % sChild, cmds.getAttr('%s.tx' % sChild), sOperation='divide', sTarget='%s.sx' % sSquashJoint)
            self.sSkinJoints.append(sSquashJoint)

            utils.addStringAttr(sSquashJoint, 'skinParent', sJoint, bLock=True)
            segments.updateTagAttr(sSquashJoint, {'bDisable': True})
            segments.updateTagAttr(sJoint, {'sSearchReplace': 'Twist;TwistSquash'})


        return [], {}






    def childrenConnect_LArmLeg(self, _lChildren):
        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm

        if not hasattr(tArm, 'sClavAimTransformPerFeature'):
            raise Exception('this clavicle version (%s) needs to have an arm with version than v4 or higher (%s)' % (self.sLimbName, tArm.sLimbName))

        if tArm.bAutoClavicle:
            sAim = self._createTransform(sName='aimer')
            sAimDefault = self._createTransform(sName='aimerDefault', sParent=self.cFk.sPasser, sMatch=self.dBlueprints['end'])
            sAimAuto = self._createTransform(sName='aimerAuto')

            if len(tArm.sClavAimTransformPerFeature) > 1:
                sArmOutMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % sT for sT in tArm.sClavAimTransformPerFeature],
                                                            ['%s.weight' % sF for sF in tArm.sFeatureGrps])
            else:
                sArmOutMatrix = '%s.worldMatrix' % tArm.sClavAimTransformPerFeature[0]

            nodes.createDecomposeMatrix(sArmOutMatrix, sTargetPos='%s.t' % sAimAuto)
            cmds.delete(cmds.pointConstraint(sAimAuto, sAimDefault))

            xforms.constraintBlend(sAim, sAimDefault, sAimAuto, self.cFk.sOut, '%s.auto' % self.cFk.sCtrl, cmds.pointConstraint, fDefault=0.0)

            sPoleAc = self._createTransform(sName='poleAc', sParent=self.cFk.sPasser, fLocalPos=[0,self.fSideMultipl,0])
            sAimGrp = self.cFk.appendOffsetGroup('aim')
            cmds.aimConstraint(sAim, sAimGrp, aim=[0,1,0], wu=[1,0,0], wut='object', wuo=sPoleAc, mo=True)
            # constraints.aimConstraintFromTransforms(sAimGrp, sAim, sPoleAc, aim=[0,self.fSideMultipl,0], up=[1,0,0], bOrientUp=False,
            #                                  sParent=self.sCurrentFeatureGrp, mo=True, sName='testAutoClavicle')

            # the replacement for attacher "root_clav"
            for mDag in tArm.mAttachToClavicleTransformsOnAuto:
                xforms.matrixParentConstraint(self.dOutputs['end'], mDag.partialPathName(), mo=True, skipScale=['x','y','z'])



    def unreal_childrenConnect_LArmLeg(self, _lChildren):
        sCommands = []
        if hasattr(_lChildren[0], 'cFkCtrls'):
            cFkCtrls = _lChildren[0].cFkCtrls
            sCommands.append("hierarchy.parentElements(%s.ePasser, %s.eOut) # clavicle parenting" % (cFkCtrls[0].sCtrl, self.cFk.sCtrl))

        return sCommands



    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)
        
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]
        
        cClavCtrls = blueprints.createChainCtrls([sBlueprints[0], sBlueprints[1]], sSide=self.sSide, xRoot='%sClavicle' % self.sName, xAim='%sclavicleEnd' % self.sName,
                                                 xPole='%sPoleClavicle' % self.sName, sParent=self.sBpTopGrp)

        self.cBpAll = cClavCtrls
        self.cBpRoots = [cClavCtrls[0]]#, cClavCtrls[-1]]
        self.cLastBp = cClavCtrls[-1]


    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):

        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)

        # xAutoConnectData =  xData['connect_arm']
        if lChildren:
            tArm = lChildren[0]
            if 'LArmLeg' in str(type(tArm)):
                cArmRoot = tArm.cBpRoots[0]
                cArmRoot.convertToSimpleTransforms()
                cmds.parentConstraint(self.cLastBp.sOut, cArmRoot.sPasser, mo=True)
                cmds.controller(tArm.cBpElbow.sCtrl, self.cLastBp.sCtrl, parent=True)

    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)
        segments.updateTagAttr(self.dOutputs['end'] , {'bDisable':True})


    def unreal_feature_fk(self):
        if self.sLimbName == 'm_global':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal

            sCommands = []
            sCommands.append("controllers.openCommentBox()")

            sCtrl, sCommand = utilsUnreal.createUnrealCtrl(self.cFk, sShapeName='Circle_Thick')
            sCommands.append(sCommand)
            sJoint = self.getOutputFullNames()[0]
            sCommands.append("nodes.createParentConstraintExecuteNode([%s.eControl], library.getElementKey('%s', 'Bone'), bMaintainOffset=True)" % (sCtrl, sJoint))
            sCommands.append(['ATTACH', sCtrl, '%s.root' % self.sLimbName])

            sCommands.append("controllers.closeCommentBox('%s (SingleBone)', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

            return sCommands, [], []





