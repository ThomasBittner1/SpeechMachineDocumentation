###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
from collections import OrderedDict

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.constraints as constraints

import kangarooTools.blueprints as blueprints
import kangarooTabTools.segments as segments

import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils
import kangarooTabTools.weights as weights
import kangarooTools.utilsUnreal as utilsUnreal


class LFinger(baseLimb._LBaseLimb):

    def __init__(self, sName='index', sSide='l', iBoneCount=4,
                 bForceParentSkeletonToRoot=False, iBakedIkKeyCount=5, fBakedIkBallRollLimit=65,
                 fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0),
                 fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0)):
        self._sBlueprintNames = ['meta','base','mid','tip','end']
        
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset)
        self.dOutputs.clear()
        for i in range(iBoneCount):
            self.dOutputs[self._sBlueprintNames[i]] = None
        self.dOutputs['END'] = None
        self.iBoneCount = min(iBoneCount, len(self._sBlueprintNames)-1)

        self.sArmConnectionScaleTransforms = []

        self.sArmConnectWristTransforms = []
        self.sArmConnectBaseTransforms = []
        self.sArmConnectFingersTransforms = []
        self.sArmConnectFingersMidTransforms = []
        self.sDefaultFeatures = ['feature_default']

        self.iBakedIkKeyCount = iBakedIkKeyCount
        self.fBakedIkBallRollLimit = fBakedIkBallRollLimit

        self.xFkPairs = []

    def createOrSetBlueprints(self, lParent=None):

        bToeLayout = False
        if type(lParent).__name__ == 'LDogArmLeg':
            bToeLayout = True
        if type(lParent).__name__ == 'LArmLeg' and lParent.bIsLeg:
            bToeLayout = True

        if bToeLayout:
            sNewJoints =  self._fillBlueprints([[(3.5,-0.6,2.9, 0,1,0), (3.5,-1.1,4.1, 0,1,0), (3.5,-1.1,4.6, 0,1,0),
                                   (3.5,-1.1,5.1, 0,1,0), (3.5,-1.1,5.6, 0,1,0)][:self.iBoneCount+1]],
                                    [self._sBlueprintNames[:self.iBoneCount+1]])
        else:
            sNewJoints = self._fillBlueprints([[(0.5,0,0.5, 0,1,0), (2.0,0,0.5, 0,1,0), (2.5,0,0.5, 0,1,0),
                                   (3.0,0,0.5, 0,1,0), (3.5,0,0.5, 0,1,0)][:self.iBoneCount+1]],
                                    [self._sBlueprintNames[:self.iBoneCount+1]])
        return sNewJoints



    def feature_default(self, iIsThumb=0, iFkIk=0, iBallRollFakeIk=1, fBallRollFakeIkStretch=1.0, _dComboboxItems={'iFkIk':['fk', 'ik', 'fkIkBlend'],
                                                                                              'iIsThumb':['no thumb', 'thumb on wrist joint', 'thumb on finger joint'],
                                                                                              'iBallRollFakeIk':['OFF', 'ON']}):
        self.iIsThumb = iIsThumb
        self.iBallRollFakeIk = iBallRollFakeIk
        self.fBallRollFakeIkStretch = fBallRollFakeIkStretch
        
        if self.iIsThumb: # just for thumb
            self.iFkIk = 0
            self.sMetaStartTransform = None
            self.cMetaIk = None

            sBlueprints = [self.dBlueprints[sN] for sN in self._sBlueprintNames[:self.iBoneCount + 1]]
            sJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)
            fSize = cmds.getAttr('%s.radius' % sBlueprints[0]) * 3.0
            self.cFkCtrls = [] #maybe we can get rid of it since we have self.xFkPairs
            sPrev = 'ctrls'
            cPrev = None
            for j, sJ in enumerate(sJoints[:-1]):

                cC = self._createCtrl4(sName=self._sBlueprintNames[j], sMatch=sJ,
                                       sAttrs=['t', 'r', 'sy'], fSize=fSize, sShape='circleY',
                                       sParent=sPrev, iColorIndex=1)

                # cC.appendOffsetGroup('poses')
                cC.adjustAxisOrientation([0, 90, -90])

                cC.sPreOut = xforms.insertParent(cC.sOut, '%sPre' % cC.sOut, bMatchParentTransform=True)
                nodes.createVectorMultiplyNode([1, 1, 1],
                                               ['%s.sx' % cC.sCtrl, '%s.sy' % cC.sCtrl, '%s.sz' % cC.sCtrl],
                                               sOperation='divide', sTarget='%s.s' % cC.sPreOut)

                if cPrev != None:
                    cmds.controller(cC.sCtrl, cPrev.sCtrl, parent=True)

                if j >= 1:
                    nodes.createVectorMultiplyNode(cmds.getAttr('%s.t' % cC.sPasser)[0],
                                                   '%s.sy' % self.cFkCtrls[-1].sCtrl, bVectorByScalar=True,
                                                   sTarget='%s.t' % cC.sPasser)

                self.cFkCtrls.append(cC)
                self.xFkPairs.append((cC, sJ))
                cPrev = cC
                sPrev = cC.sOut
                cC.mJoint = utils.getDagPath(sJ)

            for c, cC in enumerate(self.cFkCtrls):
                j = c
                sTipAim = self._createTransform('tipAimFk', sParent=self.cFkCtrls[c + 1].sCtrl if c < len(
                    self.cFkCtrls) - 1 else cC.sCtrl, sMatch=sBlueprints[c + 1])
                sTipUpFk = self._createTransform('tipUpFk', sParent=cC.sOut, fLocalPos=[0, 1, 0])
                # cmds.aimConstraint(sTipAim, sJoints[j], wut='object', aim=[self.fSideMultipl, 0, 0], u=[0, 1, 0], wuo=sTipUpFk)
                constraints.aimConstraintFromTransforms(sJoints[j], sTipAim, sTipUpFk, aim=[self.fSideMultipl, 0, 0],
                                                        up=[0, 1, 0], sParent=self.sCurrentFeatureGrp)

                if c == 0:
                    cmds.pointConstraint(cC.sOut, sJoints[j])
                else:
                    sDistance = nodes.createDistanceNode(nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sOut),
                                                                                       '%s.worldInverseMatrix' %
                                                                                       self.cFkCtrls[c - 1].sOut),
                                                         [0, 0, 0])
                    if self.sSide == 'r':
                        sDistance = nodes.createMultiplyNode(sDistance, -1)

                    cmds.connectAttr(sDistance, '%s.tx' % sJoints[j])

                    if c == len(self.cFkCtrls) - 1:
                        sLastJointTx = nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sJoints[-1]), '%s.sy' % cC.sCtrl)
                        cmds.connectAttr(sLastJointTx, '%s.tx' % sJoints[-1])

            cMeta, cBase = self.cFkCtrls[0:2]
            self._cFks = self.cFkCtrls[2:]
            return sJoints, self.cFkCtrls, {}

        else:
            self.iFkIk = iFkIk
            print('feature finger: ', self.sLimbName)
            sBlueprints = [self.dBlueprints[sN] for sN in self._sBlueprintNames[:self.iBoneCount + 1]]
            sJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='tipIkPre', sParent=self.sCurrentFeatureGrp)

            cmds.makeIdentity(sJoints, apply=True, r=True)
            [cmds.setAttr('%s.segmentScaleCompensate' % sJ, False) for sJ in sJoints]
            self.sMetaStartTransform = self._createTransform('metaStart', sMatch=sJoints[0])
            fSize = cmds.getAttr('%s.radius' % sBlueprints[0]) * 3.0

            cmds.pointConstraint(self.sMetaStartTransform, sJoints[0])
            self.cMetaIk = self._createCtrl4(sName='baseIk', sMatch=sBlueprints[0], fMatchPos=sBlueprints[1], sShape='locator', iColorIndex=1, fSize=fSize,
                                       sAttachScaleTo=self.sMetaStartTransform, sAttrs=['t','ry'])
            self.cMetaIk.adjustAxisOrientation([0, 90, -90])
            self.cMetaIk.appendOffsetGroup('poses')
            nodes.createVectorMultiplyNode([1, 1, 1],
                                           ['%s.sy' % self.cMetaIk.sCtrl, '%s.sz' % self.cMetaIk.sCtrl, '%s.sx' % self.cMetaIk.sCtrl],
                                           sOperation='divide', sTarget='%s.s' % self.cMetaIk.sOut)

            # if self.sSide == 'r':
            #     sSliderMeta = self.cMetaIk.appendOffsetGroup('slider')
            #     cmds.setAttr('%s.s' % sSliderMeta, -1,-1,-1)

            fPrevOrient, fPrevJointOrient = cmds.getAttr('%s.rz' % sJoints[2]), cmds.getAttr('%s.joz' % sJoints[2])
            cmds.setAttr('%s.joz' % sJoints[2], fPrevJointOrient-10)
            cmds.setAttr('%s.rz' % sJoints[2], fPrevOrient+10)

            if self.iFkIk in [1,2]: # do ik
                self.cTipIk = self._createCtrl4(sName='tipIk', sMatch=sBlueprints[3], sShape='locator', iColorIndex=1, fSize=fSize,
                                          sAttachScaleTo=self.sMetaStartTransform, sAttrs=['t','r', 'sx'])
                self.cTipIk.appendOffsetGroup('poses')
                utils.addStringAttr(self.cTipIk.sCtrl, 'sPickwalkKey', 'tipIk')
                # if self.sSide == 'r':
                #     sSliderTip = self.cTipIk.appendOffsetGroup('slider')
                #     cmds.setAttr('%s.s' % sSliderTip, -1, -1, -1)

                sIkLengthScale = utils.addAttr(self.cTipIk.sCtrl, ln='lengthScale', min=0.1, max=10, dv=1, k=True)

                sJointIkLengths = [nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sJoints[2]), sIkLengthScale),
                                 nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sJoints[3]), sIkLengthScale)]

                sLastJointTxIk = nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sJoints[-1]), '%s.sx' % self.cTipIk.sCtrl)

            if self.iFkIk == 2:
                sIkBlendAttr = utils.addAttr(self.cMetaIk.sCtrl, ln='fkIk', minValue=0.0, maxValue=1.0, k=True)
                sIkBlendRev = nodes.createReverseNode(sIkBlendAttr)

            self.cFkCtrls = []
            if self.iFkIk in [0,2]: # do fk
                sPrev = 'ctrls'
                cPrev = None
                for j, sJ in enumerate(sJoints[:-1]):
                    if j == 0:
                        continue
                    cC = self._createCtrl4(sName=self._sBlueprintNames[j], sMatch=sJ,
                                            sAttrs= ['t','r','sy'], fSize=fSize, sShape='circleY',
                                            sParent=sPrev, iColorIndex=1)
                    cC.appendOffsetGroup('poses')

                    cC.adjustAxisOrientation([0, 90, -90])

                    cC.sPreOut = xforms.insertParent(cC.sOut, '%sPre' % cC.sOut, bMatchParentTransform=True)
                    nodes.createVectorMultiplyNode([1,1,1],
                                                   ['%s.sx' % cC.sCtrl, '%s.sy' % cC.sCtrl, '%s.sz' % cC.sCtrl],
                                                   sOperation='divide', sTarget='%s.s' % cC.sPreOut)
                    sPrev = cC.sOut
                    if j >= 2:
                        nodes.createVectorMultiplyNode(cmds.getAttr('%s.t' % cC.sPasser)[0], '%s.sy' % self.cFkCtrls[-1].sCtrl, bVectorByScalar=True,
                                                       sTarget='%s.t' % cC.sPasser)

                    cC.mJoint = utils.getDagPath(sJ)
                    self.cFkCtrls.append(cC)
                    self.xFkPairs.append((cC, self.getOutputFullNames()[j]))

                for c,cC in enumerate(self.cFkCtrls):
                    j = c+1
                    sTipAim = self._createTransform('tipAimFk', sParent=self.cFkCtrls[c+1].sCtrl if c < len(self.cFkCtrls)-1 else cC.sOut, sMatch=sBlueprints[c+2])
                    sTipUpFk = self._createTransform('tipUpFk', sParent=cC.sOut, fLocalPos=[0,1,0])
                    # cmds.aimConstraint(sTipAim, sJoints[j], wut='object', aim=[self.fSideMultipl,0,0], u=[0,1,0], wuo=sTipUpFk)
                    constraints.aimConstraintFromTransforms(sJoints[j], sTipAim, sTipUpFk, aim=[self.fSideMultipl,0,0], up=[0,1,0], sParent=self.sCurrentFeatureGrp)
                    # cmds.pointConstraint(cC.sOut, sJoints[j])
                    if c == 0:
                        cmds.pointConstraint(cC.sOut, sJoints[j])
                    else:
                        sDistance = nodes.createDistanceNode(nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sOut),
                                                                                           '%s.worldInverseMatrix' % self.cFkCtrls[c-1].sOut),
                                                 [0, 0, 0])
                        if self.sSide == 'r':
                            sDistance = nodes.createMultiplyNode(sDistance, -1)

                        if self.iFkIk == 0:
                            cmds.connectAttr(sDistance, '%s.tx' % sJoints[j])
                        elif self.iFkIk == 2:
                            iIkIndex = j-2
                            print ('iIkIndex: ', iIkIndex)
                            nodes.createBlendNode(sIkBlendAttr,
                                                  sJointIkLengths[iIkIndex] if iIkIndex >= 0 and iIkIndex < 2 else cmds.getAttr('%s.tx' % sJoints[j]),
                                                  sDistance, sTarget='%s.tx' % sJoints[j])

                        if c == len(self.cFkCtrls)-1:
                            sLastJointTxFk = nodes.createMultiplyNode(cmds.getAttr('%s.tx' % sJoints[-1]), '%s.sy' % cC.sCtrl)
                            if self.iFkIk == 0:
                                cmds.connectAttr(sLastJointTxFk, '%s.tx' % sJoints[-1])
                            elif self.iFkIk == 2:
                                nodes.createBlendNode(sIkBlendAttr, sLastJointTxIk,
                                                      sLastJointTxFk, sTarget='%s.tx' % sJoints[-1])

                    if cPrev != None:
                        cmds.controller(cC.sCtrl, cPrev.sCtrl, parent=True)
                    else:
                        cmds.controller(cC.sCtrl, self.cMetaIk.sCtrl, parent=True)

                    if self.iFkIk == 2:
                        cmds.connectAttr(sIkBlendRev, '%s.v' % cmds.listRelatives(cC.sCtrl, p=True)[0], force=True)

                    cPrev = cC

                sFirstFkOffset = self.cFkCtrls[0].appendOffsetGroup('parenttometa', bBelowPasser=True, bMatchParentTransform=True)
                xforms.matrixParentConstraint(self.cMetaIk.sOut, sFirstFkOffset, skipScale=['x','y','z'], mo=True)



            # cmds.aimConstraint(self.cMetaIk.sOut, sJoints[0], wut='objectrotation', aim=[self.fSideMultipl,0,0], u=[0,self.fSideMultipl,0], wuo=self.cMetaIk.sOut)
            constraints.aimConstraintFromTransforms(sJoints[0], self.cMetaIk.sOut, self.cMetaIk.sOut, aim=[self.fSideMultipl,0,0], up=[0,1,0],
                                             bOrientUp=True, sParent=self.sCurrentFeatureGrp)
            cIkCtrls = []
            if self.iFkIk in [1,2]: # do ik
                # self.cTipIk = self._createCtrl4(sName='tipIk', sMatch=sBlueprints[3], sShape='locator', iColorIndex=1, fSize=2.0,
                #                           sAttachScaleTo=self.sMetaStartTransform, sAttrs=['t','r', 'sy'])
                # self.cTipIk.appendOffsetGroup('poses')
                # if self.sSide == 'r':
                #     sSliderTip = self.cTipIk.appendOffsetGroup('slider')
                #     cmds.setAttr('%s.s' % sSliderTip, -1, -1, -1)
                #
                # sIkLengthScale = utils.addAttr(self.cTipIk.sCtrl, ln='lengthScale', min=0.1, max=10, dv=1, k=True)


                sPoleParent = self._createTransform('poleParent', sParent=self.cTipIk.sOut)
                # cmds.aimConstraint(self.cMetaIk.sOut, sPoleParent, wut='objectrotation', wuo=self.cTipIk.sOut, wu=[0,0,1])
                constraints.aimConstraintFromTransforms(sPoleParent, self.cMetaIk.sOut, self.cTipIk.sOut, bOrientUp=True, fOrientAxis=[0,0,1],
                                                 sParent=self.sCurrentFeatureGrp)

                sPole = self._createTransform('pole', sParent=sPoleParent, fLocalPos=[0,0,1])
                sIkHandle = xforms.createIk(sJoints[1], sJoints[3], sPole, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('ikTip','ik'))

                cmds.pointConstraint(self.cTipIk.sOut, sIkHandle)
                cIkCtrls.append(self.cTipIk)

                if self.iFkIk == 2:
                    cmds.connectAttr(sIkBlendAttr, '%s.ikBlend' % sIkHandle)

                sTipAim = self._createTransform('tipAimIk', sParent=self.cTipIk.sOut, sMatch=sBlueprints[-1])
                sTipUpIk = self._createTransform('tipUpIk', sParent=self.cTipIk.sOut, fLocalPos=[0,self.fSideMultipl,0])
                print('sJoints[-2]: ', sJoints[-2])


                if self.iFkIk == 1:
                    constraints.aimConstraintFromTransforms(sJoints[-2], sTipAim, sTipUpIk, aim=[self.fSideMultipl, 0, 0], up=[0, 1, 0],
                                                     sParent=self.sCurrentFeatureGrp)
                else: # blend with previous aim
                    sAimConstraint = cmds.listConnections(sJoints[-2], s=True, d=False, t='aimConstraint')[0]
                    print('sAimConstraint: ',sAimConstraint)
                    sFkTarget = cmds.listConnections('%s.target[0].targetTranslate' % sAimConstraint, s=True, d=False, p=True)[0]



                    sAdditionNode = cmds.listConnections('%s.worldUpVector' % sAimConstraint, s=True, d=False)[0]
                    sLocalizeNode = cmds.listConnections('%s.input3D[0]' % sAdditionNode, s=True, d=False)[0]
                    sFkWorldVector = cmds.listConnections('%s.input1' % sLocalizeNode, s=True, d=False, p=True)[0]
                    nodes.createBlendNode(sIkBlendAttr, nodes.getWorldPoint(sTipUpIk), sFkWorldVector,
                                          bVector=True, sTarget='%s.input1' % sLocalizeNode, bForce=True)

                    nodes.createBlendNode(sIkBlendAttr,
                                          nodes.createPointByMatrixNode(nodes.getWorldPoint(sTipAim), '%s.parentInverseMatrix' % sJoints[-2]),
                                          sFkTarget, bVector=True,
                                          sTarget='%s.target[0].targetTranslate' % sAimConstraint, bForce=True)
                    # sWeightAttrs = cmds.listAttr(sAimConstraint, k=True)[-2:]
                    # cmds.connectAttr(sIkBlendRev, '%s.%s' % (sAimConstraint, sWeightAttrs[0]))
                    # cmds.connectAttr(sIkBlendAttr, '%s.%s' % (sAimConstraint, sWeightAttrs[1]))
                    # nodes.createBlendMatrixNode([sFkUpMatrix, '%s.worldMatrix' % sTipUpIk],
                    #                             [sIkBlendRev, sIkBlendAttr],
                    #                             sTarget='%s.worldUpMatrix' % sAimConstraint, bForce=True)
                    cmds.connectAttr(sIkBlendAttr, '%s.v' % cmds.listRelatives(self.cTipIk.sCtrl, p=True)[0])


            cCtrls = [self.cMetaIk] + self.cFkCtrls + cIkCtrls

            return sJoints, cCtrls, {}



    def unreal_feature_default(self):

        sCommands = ['\n\n ## %s finger' % self.sLimbName]
        cStrMeta, sCreateMetaCtrlCommand = utilsUnreal.createUnrealCtrl(self.cMetaIk)
        sCommands.append(sCreateMetaCtrlCommand)

        cStrFkCtrls, sFkCommands = utilsUnreal.createFkChainCtrls(self.cFkCtrls, bAllUnderRoot=True,
                                                                        sParentVar='%s.eOut' % cStrMeta)
        sCommands.extend(sFkCommands)

        sMetaIkParentJoint = constraints.getParentConstrainer('%s.t' % self.cMetaIk.sPasser)

        sJoints = list(self.dOutputs.values())[1:len(cStrFkCtrls) + 1]
        cPassCtrls = cStrFkCtrls

        fMetaDefaultLength = xforms.distanceBetween(self.dOutputs['meta'], self.dOutputs['base'])

        sCommands.append("functions.createDogToeFunction('%s', '%s', %s, [%s], %s, %0.3f, bNegative=%s, bMocap=%s)" % (
        sMetaIkParentJoint, self.dOutputs['meta'], cStrMeta, ', '.join(cPassCtrls), sJoints, fMetaDefaultLength, True if self.fSideMultipl==-1.0 else False, False))

        return sCommands, [], []




    def unreal_finalCleanup(self):


        ssCommands = [[], []]
        for i in range(2):
            ssCommands[i].append('\n\n# %s (finger)' % self.sLimbName)
            cStrMeta, sCreateMetaCtrlCommand = utilsUnreal.createUnrealCtrl(self.cMetaIk)
            ssCommands[i].append(sCreateMetaCtrlCommand)

            if i == 0:
                cStrFkCtrls, sFkCommands = utilsUnreal.createFkChainCtrls(self.cFkCtrls, bAllUnderRoot=True,
                                                                                sParentVar='%s.eOut' % cStrMeta)
                ssCommands[0].extend(sFkCommands)



            sMetaIkParentJoint = constraints.getParentConstrainer('%s.t' % self.cMetaIk.sPasser)

            if i == 0:
                sJoints = list(self.dOutputs.values())[1:len(cStrFkCtrls)+1]
                cPassCtrls = cStrFkCtrls
            else: # mocap
                sJoints = [list(self.dOutputs.values())[1]]
                cPassCtrls = [cStrMeta]

            ssCommands[i].append("functions.createDogToeFunction('%s', '%s', %s, [%s], %s, bMocap=%s)" % (sMetaIkParentJoint, self.dOutputs['meta'], cStrMeta, ', '.join(cPassCtrls), sJoints, str(i==1)))


        return ssCommands[0], [], ssCommands[1]



    def effectsOutputs_blends(self, **kwargs):
        dBlendOutputs = OrderedDict()
        
        for sOutput in list(self.dOutputs.keys()):
            dBlendOutputs['%sBlend' % sOutput] = None
    
        return dBlendOutputs


    def effects_blends(self, _sAttachers=[]):

        sOrients = []
        for sName, sJoint in list(self.dOutputs.items()):
            sOrient = cmds.createNode('joint', name=self._createNodeName('%sBlend' % sName,'jnt'), p=sJoint)
            cmds.setAttr('%s.t' % sOrient, 0,0,0)
            sOrients.append(sOrient)
            cmds.setAttr('%s.radius' % sOrient, cmds.getAttr('%s.radius' % sJoint) * 1.5)
            nodes.createVectorMultiplyNode('%s.r' % sJoint, (-0.5,-0.5,-0.5), sTarget = '%s.r' % sOrient, sName=self._createNodeName('%sHalf' % sName))
            self.dOutputs['%sBlend' % sName] = sOrient
            
            segments.updateTagAttr(sOrient, {'bDisable':True})

        dAttacherBuildData = {}
        return sOrients, None, dAttacherBuildData



    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        sBlueprints = [self.dBlueprints[sN] for sN in self._sBlueprintNames[:self.iBoneCount+1]]

        cMetaCtrls = blueprints.createChainCtrls(sBlueprints[:2], sSide=self.sSide, xRoot='%sMeta' % self.sName, xAim='%sBase' % self.sName,
                                                 xPole='%sPoleMeta' % self.sName, iColorIndexOffset=1,
                                                sParent=self.sBpTopGrp, fUpVector=[0,1,0])

        cBaseCtrls = blueprints.createChainCtrls(sBlueprints[1:], sSide=self.sSide, xRoot=cMetaCtrls[-1], xAim='%sEnd' % self.sName, xPole='%sPole' % self.sName,
                                                xElbows=['%sMid' % self.sName, '%sTip' % self.sName], sParent=self.sBpTopGrp, fUpVector=[0,2.5,0], iColorIndexOffset=1)

        self.cBpRoots = [cMetaCtrls[0], cBaseCtrls[0], cBaseCtrls[-1]]
        self.cBpAll = list(set(cMetaCtrls + cBaseCtrls))

        self._cBpMetaPole = cMetaCtrls[-1]
        self._cBpBasePole = cBaseCtrls[-1]



    def generateOutputs_postScale(self, **kwargs):
        return {}, []



    def detail_postScale(self, bMetaScale=False, bCtrlThicknessScales=False):
        if bMetaScale:
            sMeta = self.dOutputs['meta']
            sMetaScale = xforms.createJoint(sName='jnt_%sMetaScale' % self.sLimbName,
                                            sParent=sMeta,
                                            fSize=cmds.getAttr('%s.radius' % sMeta) * 1.5)
            sMetaTxAttr = '%s.tx' % self.dOutputs['base']
            nodes.createMultiplyNode(sMetaTxAttr, 1.0 / cmds.getAttr(sMetaTxAttr), sTarget='%s.sx' % sMetaScale)
            # self.dOutputs['meta'] = sMetaScale

            segments.updateTagAttr(sMetaScale, {'bDisable': True})
            segments.updateTagAttr(sMeta, {'sSearchReplace':'Meta;MetaScale'})

            if bCtrlThicknessScales and hasattr(self, 'cMetaIk') and self.cMetaIk:
                self.cMetaIk.unlockAttrs(['sx','sz'])
                cmds.connectAttr('%s.sx' % self.cMetaIk.sCtrl, '%s.sz' % sMetaScale)
                cmds.connectAttr('%s.sz' % self.cMetaIk.sCtrl, '%s.sy' % sMetaScale)


        if bCtrlThicknessScales:

            for c,cC in enumerate(self.cFkCtrls):
                sJoint = cC.mJoint.partialPathName()
                sChild = cmds.listRelatives(sJoint, p=False, c=True)[0]
                sLengthScale = nodes.createMultiplyNode('%s.tx' % sChild, cmds.getAttr('%s.tx' % sChild), sOperation='divide')
                cC.unlockAttrs(['sx','sz'])
                sScaleJoint = '%sScale' % sJoint
                if not cmds.objExists(sScaleJoint):
                    sScaleJoint = xforms.createJoint(sName=sScaleJoint,
                                                    sParent=sJoint,
                                                    fSize=cmds.getAttr('%s.radius' % sJoint) * 1.5)
                cmds.connectAttr('%s.sx' % cC.sCtrl, '%s.sz' % sScaleJoint)
                cmds.connectAttr('%s.sz' % cC.sCtrl, '%s.sy' % sScaleJoint)

                if not cmds.listConnections('%s.sx' % sScaleJoint, s=True, d=False):
                    cmds.connectAttr(sLengthScale, '%s.sx' % sScaleJoint)

                # sOutputKey = list(self.dOutputs.keys())[c+1]
                # self.dOutputs[sOutputKey] = sScaleJoint

                segments.updateTagAttr(sScaleJoint, {'bDisable': True})

                sName = sJoint.split('_')[-1]
                segments.updateTagAttr(sJoint, {'sSearchReplace': '%s;%sScale' % (sName,sName)})

        return [], {}


    @classmethod
    def rightClickCommand_transferToSquashJointsSelectedMeshes(cls, ddData):
        sLimbName = '%s_%s' % (ddData['dArgsFILE']['sSide'], ddData['dArgsFILE']['sName'])
        dMove = {}
        for sSuffix in ['Meta','Base','Mid','Tip']:
            dMove['jnt_%s%s' % (sLimbName,sSuffix)] = 'jnt_%s%sScale' % (sLimbName, sSuffix)
        weights.moveSkinClusterWeights(xJoints=dMove)

    @classmethod
    def rightClickCommand_transferFromSquashToRegularJointsSelectedSelectedMeshes(cls, ddData):
        sLimbName = '%s_%s' % (ddData['dArgsFILE']['sSide'], ddData['dArgsFILE']['sName'])
        dMove = {}
        for sSuffix in ['Meta','Base','Mid','Tip']:
            dMove['jnt_%s%sScale' % (sLimbName,sSuffix)] = 'jnt_%s%s' % (sLimbName, sSuffix)
        weights.moveSkinClusterWeights(xJoints=dMove)

