###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2

import numpy as np
import inspect
import math

from collections import defaultdict, OrderedDict, Counter
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.utilFunctions as utils
import kangarooTools.report as report
import kangarooTools.constraints as constraints
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls2 as ctrls2
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.ctrls5 as ctrls5
import kangarooTabTools.ctrls6 as ctrls6
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.ctrls8 as ctrls8
import kangarooTabTools.ctrls9 as ctrls9
import kangarooTabTools.segments as segments



kOutputsAttr = '__outputs__'
kCtrlsAttr = '__ctrls__'
kFeatureSwitchesAttr = '__featureSwitches__'

class enumAttr():
    __rigEnumAttr__ = True



class _LBaseLimb(object):
    def __init__(self, sSide='l', sName='name', fBlueprintsCreationTranslationOffset=(0,0,0), fBlueprintsCreationRotationOffset=(0,0,0),
                 bRemoveEndSkinJoint=False, bForceParentSkeletonToRoot=False, sCreateReplacerAttachers=[], iSegmentsPriority=0, bIsBpBarent=True,
                 iFeatureCtrlType=0, sCustomFeatureCtrlName='', sBlueprintMirrorPlane=''):
        self.sName = sName
        self.sSide = sSide
        self.fSideMultipl = -1 if sSide == 'r' else 1
        self.sLimbName = '%s_%s' % (self.sSide, self.sName)
        self.dOutputs = OrderedDict() # values filled by fillOutputs() using createOutput()'s data. Keys needs to be filled with None values in each limb's __init__ function.
        self.sSkinJoints = [] # gets filled after self.dOutputs is created in baseLimb, and will get adjusted in the effects function
        self.sEndJoints = [] # optional - gets filled by some limbs, includes joints that will be unparented before the sSkinJoints parenting process happens

        self.dFeatureData = OrderedDict() # _LBaseLimb takes the return of limbs' feature functions and puts it in there
        self.sFeatureGrps = []

        self.detailData = None # like self.dFeatureData, but there can only be one effects
        self.fBlueprintsCreationTranslationOffset = fBlueprintsCreationTranslationOffset
        self.fBlueprintsCreationRotationOffset = fBlueprintsCreationRotationOffset

        self.ddAllAttacherBuildDatas = defaultdict(list) # gets info from returns of feature builds
        self.dLocalAttacherOutputs = defaultdict(list)
        # self.dCtrlReplacements = {} # for unreal
        self.dDetailReplacements = {} # for unreal
        self.bRemoveEndSkinJoint = bRemoveEndSkinJoint

        self.dSkinJointSubstitutes = {}

        self.bForceParentSkeletonToRoot = bForceParentSkeletonToRoot
        self.sDefaultFeatures = []
        self.finalSetAttrs = {}
        self.mBpRefOrientation = OpenMaya2.MMatrix()
        self.cBpSymmetry = []
        self.sCreateReplacerAttachers = sCreateReplacerAttachers
        self.report = None
        self.lParent = None

        self.cAllCtrls = []
        self.cDetailCtrls = []
        self.aAllCtrlPoints = []
        self.bSymmetricWhenMiddle = True # CAN WE REMOVE THIS??
        self.iSegmentsPriority = iSegmentsPriority

        self.bIsBpBarent = bIsBpBarent

        self.report = report.report

        self.iFeatureCtrlType = iFeatureCtrlType
        self.sCustomFeatureCtrlName = sCustomFeatureCtrlName
        self.sFeatureAttrPrefix = '%s_' % self.sLimbName if self.iFeatureCtrlType == 2 else ''

        # once control rig is more built out with spaces, this one is too simple and may have to be replaced
        self.dAttacherInfo = {} # this gets filled when creating the attachers, for post functions such as unreal control rig creation
        self.bDoControlRigFunction = False
        self.sDefaultUnrealPieceInputs = []

        self.sBlueprintMirrorPlane = sBlueprintMirrorPlane.strip()


    @classmethod
    def staticPostSetup(cls):
        pass

    def __repr__(self):
        return '<TLimb: %s> (%s)' % (self.sLimbName, utils.getClassNameFromClass(type(self)))


    def __str__(self):
        return '<TLimb: %s> (%s)' % (self.sLimbName, utils.getClassNameFromClass(type(self)))


    def getDefaultParentOutput(self):
        return list(self.dOutputs.keys())[-1]


    def guessBlueprintFromOutput(self, sOutputKey, iBlueprintCount=None):

        sConsiderBlueprints = list(self.dBlueprints.keys())[:iBlueprintCount]
        sConsiderOutputs = [sO for sO in list(self.dOutputs.keys()) if not sO.startswith('_')]

        if sOutputKey not in sConsiderOutputs:
            return None

        iOutput = sConsiderOutputs.index(sOutputKey)
        if len(sConsiderBlueprints) == len(sConsiderOutputs):
            return sConsiderBlueprints[iOutput]

        fOutput = float(iOutput) / float(len(sConsiderOutputs))
        fBlueprint = fOutput * float(len(sConsiderBlueprints))
        iBlueprint = int(math.floor(fBlueprint))
        if iBlueprint < len(sConsiderBlueprints):
            return sConsiderBlueprints[iBlueprint]
        else:
            return None


    def generateAttachers_init(self):
        return {}


    def getOutputFullNames(self):
        sNames = list(self.dOutputs.keys())
        if len(sNames) == 1:
            return ['jnt_%s_%s' % (self.sSide, self.sName)]
        else:
            return ['jnt_%s_%s%s%s' % (self.sSide, self.sName, sN[0].upper(), sN[1:]) for sN in sNames]


    def fillOutputs(self, sOutputs):
        if len(sOutputs) != len(list(self.dOutputs.keys())):
            raise Exception('%s: outputs count (%d -> %s) doesn\'t match the dOutputs length (%d -> %s)' % \
                    (self.sLimbName, len(sOutputs), sOutputs, len(list(self.dOutputs.keys())), list(self.dOutputs.keys())))
        for sO, sKey in zip(sOutputs, list(self.dOutputs.keys())):
            self.dOutputs[sKey] = sO


    def createOutoutputsAttr(self):
        utils.addStringAttr(self.sTopGrp, kOutputsAttr, str(self.dOutputs), bLock=True)


    def createRig(self):
        pass


    def hideBPs(self):
        cmds.setAttr('%s.v' % self.sBlueprints[0], False)


    def buildTopGroups(self):
        self.sTopGrp = cmds.createNode('transform', name='grp_%s_%sModule' % (self.sSide, self.sName))
        self.sCtrlGrp = cmds.createNode('transform', name='grp_%s_%sCtrls' % (self.sSide, self.sName),
                                        p=self.sTopGrp)
        self.sOutGrp = cmds.createNode('transform', name='grp_%s_%sOut' % (self.sSide, self.sName),
                                        p=self.sTopGrp)
        self.sRigGrp = cmds.createNode('transform', name='grp_%s_%sRig' % (self.sSide, self.sName),
                                        p=self.sTopGrp)
        cmds.parent(self.sTopGrp, self.sModulesGlobal)

        utils.addStringAttr(self.sTopGrp, 'sClassType', str(type(self)).split('\'')[1].split('.')[-1], bLock=True)



    def buildFeature(self, sFuncName, dFeatureArgs):
        print('---------------- buildFeature %s, %s' % (self.sLimbName, sFuncName))
        func = getattr(self, sFuncName)
        self.sCurrentFeatureGrp = cmds.createNode('transform', name='grp_%s_%s_%s' % (self.sSide, self.sName, sFuncName),
                                        p=self.sTopGrp)

        sInspectedFeatArgs = inspect.getfullargspec(func)[0]
        sPassFeatArgs = set(sInspectedFeatArgs).intersection(set(dFeatureArgs.keys()))

        xFuncResult = func(**{sA:dFeatureArgs[sA] for sA in sPassFeatArgs})
        sOuts, cCtrls, xAttachers = xFuncResult[:3]

        # utils.setSelectionSiblingNodes(sOuts)
        utils.setSelectionSiblingNodes([cC.sCtrl for cC in cCtrls])

        # # this needs to happen after creation

        for sA, xData in list(xAttachers.items()): #dAttacherBuildData['root'] = (utils.getDagPath(cCtrls[0].sPasser), cCtrls[0])
            mAttacherDagPath, cCtrl = xData
            sAttacherTransform = mAttacherDagPath.partialPathName()
            sAttacherTransformNamesAttr = '%s.sAttacherTransformNames' % sAttacherTransform

            if cmds.objExists(sAttacherTransformNamesAttr):
                sAttacherTransformNames = eval(cmds.getAttr(sAttacherTransformNamesAttr))
            else:
                sAttacherTransformNames = []
            sAttacherTransformNames.append(sA)
            utils.addStringAttr(sAttacherTransform, 'sAttacherTransformNames', sAttacherTransformNames)
            utils.addStringAttr(sAttacherTransform, 'sAttacherTransformLimbName', self.sLimbName)
        # end of ..


        utils.addStringAttr(self.sCurrentFeatureGrp, kCtrlsAttr, ','.join([cC.sCtrl for cC in cCtrls]), bLock=True)

        self.dFeatureData[sFuncName] = (sOuts, cCtrls, xAttachers)
        cmds.setAttr('%s.v' % self.sCurrentFeatureGrp, False)

        for sShortKey, dData in list(xAttachers.items()):
            self.ddAllAttacherBuildDatas[sShortKey].append(dData)

        self.sFeatureGrps.append(self.sCurrentFeatureGrp)

        self.cAllCtrls += cCtrls


    def buildDetail(self, sFuncName, dDetailArgs):
        print('---------------- buildDetail %s' % sFuncName)
        self.sDetailsGrp = cmds.createNode('transform', name='grp_%s_%s_%s' % (self.sSide, self.sName, sFuncName),
                                p=self.sTopGrp)
        func = getattr(self, sFuncName)
        sInspectedDetailArgs = inspect.getfullargspec(func)[0]
        sPassDetailArgs = set(sInspectedDetailArgs).intersection(set(dDetailArgs.keys()))
        xxResult = func(**{sA:dDetailArgs[sA] for sA in sPassDetailArgs})

        if len(xxResult) != 2:
            raise Exception('wrong return on detail function for %s' % self.sLimbName)
        cCtrls, xAttachers = xxResult

        utils.setSelectionSiblingNodes([cC.sCtrl for cC in cCtrls])
        utils.setSelectionSiblingNodes(self.sSkinJoints)

        for sJ in self.sSkinJoints:
            if not cmds.objExists('%s.sLimbJoint' % sJ):
                utils.addStringAttr(sJ, 'sLimbJoint', self.sLimbName, bLock=True)

        for sShortKey, dData in list(xAttachers.items()):
            self.ddAllAttacherBuildDatas[sShortKey].append(dData)

        if self.iFeatureCtrlType == 0:
            for cC in cCtrls:
                cC.addFeatureShape(self.sFeatureShape)

        self.cAllCtrls += cCtrls
        self.cDetailCtrls = cCtrls


    def runConnect(self, sFuncName, tLimbs, connectArgs):
        func = getattr(self, sFuncName)
        func(tLimbs, **connectArgs)


    def setGlobalGroups(self, sMaster, sModules, sSkeleton, sCtrls, sModel):
        self.sMasterGlobal = sMaster
        self.sModulesGlobal = sModules
        self.sSkeletonGlobal = sSkeleton
        self.sCtrlsGlobal = sCtrls
        self.sModelGlobal = sModel


    def createFeatureShape(self):
        if self.iFeatureCtrlType == 0:
            sDeleteCurve = cmds.curve(name='__features__', p=[[0, 0, 0], [0, 0, 0]], d=1)
            self.sFeatureShape = cmds.listRelatives(sDeleteCurve, s=True)[0]
            self.sFeatureShape = cmds.rename(self.sFeatureShape, '__%s_%s_Features__' % (self.sSide, self.sName))
            cmds.setAttr('%s.v' % self.sFeatureShape, False)
            utils.removeLocatorShapeAttrs(self.sFeatureShape)
            cmds.addAttr(sDeleteCurve, ln='tempFeatureCurveDelete')
        elif self.iFeatureCtrlType == 1:
            sBlueprintKey = self.dFeatureCtrlParent['sBlueprintKey']
            sBlueprint = self.dBlueprints[sBlueprintKey]
            self.cExtraCtrl = ctrls9.create('%sGlobal' % self.sName, self.sSide, fMatchPos=sBlueprint, sShape='cross',
                                            fSize=cmds.getAttr('%s.radius' % sBlueprint) * 5, sParent='ctrls', fRotateShape=(90,0,0),
                                            iSlider=3)
            if hasattr(self, 'sDisplayAttr'):
                utils.displayTag(self.sDisplayAttr, [self.cExtraCtrl])

            utils.addStringAttr(self.cExtraCtrl.sCtrl, 'sLimbCtrl', self.sLimbName)
            self.sFeatureShape = self.cExtraCtrl.sCtrl
        elif self.iFeatureCtrlType == 2:
            self.sFeatureShape = self.sCustomFeatureCtrlName


    def attachFeatureCtrl(self):
        if self.iFeatureCtrlType == 1:
            sOutputKey = self.dFeatureCtrlParent['sOutputKey']
            sOutput = self.dOutputs[sOutputKey]
            constraints.matrixParentConstraint(sOutput, self.cExtraCtrl.sPasser, mo=True)


    def createOutputs(self, sDefaultFeature):
        if len(list(self.dFeatureData.keys())) == 0:
            raise Exception('%s has no features. Turn on features!' % self.sLimbName)

        if len(list(self.dFeatureData.keys())) == 1:
            sOneFeat = list(self.dFeatureData.keys())[0]
            sOutputs, cCtrls, xSpace = self.dFeatureData[sOneFeat]
            if len(sOutputs) == 0:
                return

            cmds.parent(xforms.getRoots(sOutputs), self.sOutGrp)
            sOutputNames = self.getOutputFullNames()

            for i, sO in enumerate(sOutputs):
                if len(sOutputNames) >= i+1:
                    sOutputs[i] = cmds.rename(sO, sOutputNames[i])

            utils.setSelectionSiblingNodes(sOutputs)

            self.dFeatureData[sOneFeat] = sOutputs, cCtrls, xSpace
            self.sBlendFeatures = [sOneFeat]

            if self.iFeatureCtrlType == 0:
                for cC in cCtrls:
                    cC.addFeatureShape(self.sFeatureShape)
            utils.addAttr(self.sFeatureGrps[0], ln='weight', minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True)

            sBlendAttrsAttr = '%s.sBlendAttrs' % self.sFeatureGrps[0]
            if cmds.objExists(sBlendAttrsAttr):
                sBlendAttrs = eval(cmds.getAttr(sBlendAttrsAttr))
                nodes.moveCustomAttributes(self.sFeatureGrps[0], self.sTopGrp, sBlendAttrs,
                                           bDeleteOldAttr=False, bConnectOldToNew=True)


        else: # there are more than 2 features
            self.sBlendFeatures = list(self.dFeatureData.keys())
            sFeaturesShort = [sF.split('_')[-1] for sF in self.sBlendFeatures]

            ssAllOuts = [self.dFeatureData[sF][0] for sF in list(self.dFeatureData.keys())]

            sAllCtrls = [self.dFeatureData[sF][1] for sF in list(self.dFeatureData.keys())]
            if self.iFeatureCtrlType == 0:
                for cCtrls in sAllCtrls:
                    for cC in cCtrls:
                        cC.addFeatureShape(self.sFeatureShape)


            sOutputs = cmds.duplicate(ssAllOuts[0], rr=True, rc=True, po=True)
            sOutputs = [cmds.rename(sO, sN) for sO, sN in zip(sOutputs, self.getOutputFullNames())]
            utils.setSelectionSiblingNodes(sOutputs)

            cmds.parent(xforms.getRoots(sOutputs), self.sOutGrp)

            sWeightInfoAttrs = [utils.addAttr(self.sFeatureGrps[f], ln='weight', minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True)
                           for f in range(len(self.sFeatureGrps))]

            sAttrs = []
            if len(list(self.dFeatureData.keys())) == 2:
                sAttrs.append(1.0)
                sSwitchAttr = utils.addAttr(self.sFeatureShape, ln='%s%s2%s' % (self.sFeatureAttrPrefix, sFeaturesShort[0], sFeaturesShort[1]),
                                            minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)

                sAttrs.append(sSwitchAttr)
                utils.addStringAttr(self.sFeatureGrps[0], kFeatureSwitchesAttr, str({'NAMESPACE%s' % sSwitchAttr:0.0}), bLock=True)
                utils.addStringAttr(self.sFeatureGrps[1], kFeatureSwitchesAttr, str({'NAMESPACE%s' % sSwitchAttr:1.0}), bLock=True)

            else: # more than 2 attributes gives the additive fanciness
                for f, sFeat in enumerate(self.sBlendFeatures):
                    if f == 0:
                        sDefaultAttr = utils.addAttr(self.sFeatureShape,
                                                     ln='%s%s' % (self.sFeatureAttrPrefix, sFeaturesShort[f]), minValue=0.0,
                                                     maxValue=1.0, defaultValue=1.0, k=True)
                        cmds.setAttr(sDefaultAttr, lock=True)
                        sAttrs.append(1.0)
                    else:
                        sAttrs.append(utils.addAttr(self.sFeatureShape, ln='%s%s' % (self.sFeatureAttrPrefix, sFeaturesShort[f]),
                                                    minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True))

                # this hasn't been properly tested yet:
                for f, sFeat in enumerate(self.sBlendFeatures):
                    dSwitch = {} if f == 0 else {'NAMESPACE%s' % sAttrs[f]:1.0}
                    if f < len(self.sBlendFeatures)-1:
                        for sA in sAttrs[f+1:]:
                            dSwitch['NAMESPACE%s' % sA] = 0.0
                    utils.addStringAttr(self.sFeatureGrps[f], kFeatureSwitchesAttr, str(dSwitch), bLock=True)


            sConstrWeightAttrs = []
            for f, sFeat in enumerate(self.sBlendFeatures):
                if f < len(self.sBlendFeatures) - 1:
                    sDifference = nodes.createAdditionNode(sAttrs[f:], sOperation='minus',
                                                           sName='featBlend_%s' % sFeaturesShort[0])
                    sConstrWeightAttrs.append(nodes.createClampNode(sDifference, 0, 1,
                                  sName='spaceBlend_%s' % sFeaturesShort[0]))
                else:
                    sConstrWeightAttrs.append(sAttrs[f])
                cmds.connectAttr(sConstrWeightAttrs[-1], sWeightInfoAttrs[f])

            # create constraints and connect the blend values
            for o, sOut in enumerate(sOutputs):
                sTargets = [ssAllOuts[i][o] for i in range(len(ssAllOuts))]
                sConstr = cmds.parentConstraint(sTargets, sOut)[0]

                cmds.setAttr('%s.interpType' % sConstr, 2)

                for i, sT in enumerate(sTargets):
                    cmds.connectAttr(sConstrWeightAttrs[i], '%s.%sW%d' % (sConstr, sT, i))

                bDoScaleBlend = False
                for sT in sTargets:
                    for sA in ['s','sx','sy','sz']:
                        if cmds.listConnections('%s.%s' % (sT,sA), s=True, d=False):
                            bDoScaleBlend = True
                            break
                    if bDoScaleBlend:
                        break

                if bDoScaleBlend:
                    sProducts = []
                    for f, sFeat in enumerate(self.sBlendFeatures):
                        sProducts.append(nodes.createVectorMultiplyNode('%s.s' % ssAllOuts[f][o], sConstrWeightAttrs[f], bVectorByScalar=True))
                    nodes.createVectorAdditionNode(sProducts, sTarget = '%s.s' % sOut, sName=self._createNodeName('scaleBlend'))

            # sSwitchesNode = utils.data.get('sSwitchesNode', xDefault=None)
            # if sSwitchesNode:
            #     sAllOrBoth = 'Both' if len(list(self.dFeatureData.keys())) == 2 else 'All'
            #     sShowAllAttr = utils.addOffOnAttr(sSwitchesNode, '%s_show%sFeatureCtrls' % (self.sLimbName, sAllOrBoth), bDefaultValue=False)
            # else:
            sShowAllAttr = utils.addOffOnAttr(self.sFeatureShape, '%sshowAllFeatureCtrls' % self.sFeatureAttrPrefix, bDefaultValue=False)


            # create logic for ctrl visibility and connect
            #
            for f, sFeat in enumerate(self.sBlendFeatures):

                sCondB0 = nodes.createConditionNode(sConstrWeightAttrs[f], '>', 0.5, True, False, sName='visB0')
                sEndVisCond = nodes.createConditionNode(sShowAllAttr, '==', True, True, sCondB0, sName='visB1')

                cCtrls = self.dFeatureData[sFeat][1]
                for cC in cCtrls:
                    print ('cC.sPasser: ', cC.sPasser)
                    try:
                        cmds.connectAttr(sEndVisCond, '%s.v' % cC.sPasser)
                    except Exception as e:
                        print ('not connecting to %s.v because of error: %s' % (cC.sPasser, str(e)))

            # set default feature
            #
            if sDefaultFeature:
                if sDefaultFeature in self.sBlendFeatures:
                    iIndex = self.sBlendFeatures.index(sDefaultFeature)
                    if iIndex > 0:
                        print('sAttrs: ', sAttrs)
                        nodes._connectOrSet(1.0, sAttrs[iIndex])

            # blend attributes if there are any
            #
            sBlendAttrsAttr = '%s.sBlendAttrs' % self.sFeatureGrps[0]
            if cmds.objExists(sBlendAttrsAttr):
                sBlendAttrs = eval(cmds.getAttr(sBlendAttrsAttr))
                nodes.moveCustomAttributes(self.sFeatureGrps[0], self.sTopGrp, sBlendAttrs,
                                           bDeleteOldAttr=False)

                for sAttr in sBlendAttrs:
                    sBlendProducts = [nodes.createMultiplyNode('%s.weight' % sFeatureG, '%s.%s' % (sFeatureG, sAttr))
                                      for sFeatureG in self.sFeatureGrps]
                    nodes.createAdditionNode(sBlendProducts, sTarget='%s.%s' % (self.sTopGrp, sAttr))




        self.fillOutputs(sOutputs)
        self.sSkinJoints = [self.dOutputs[sN] for sN in list(self.dOutputs.keys()) if not sN.startswith('_')]


        for sO in self.sSkinJoints:
            utils.addStringAttr(sO, 'sLimbName', self.sLimbName, bLock=True)




    def fillAllCtrlLists(self):
        self.aAllCtrlPoints = xforms.getPositionArray([cC.sCtrl for cC in self.cAllCtrls])
        utils.addStringAttr(self.sTopGrp, '__ctrls__', [cC.sCtrl for cC in self.cAllCtrls])
        [utils.addStringAttr(cC.sCtrl, 'sModule', self.sTopGrp) for cC in self.cAllCtrls]


    def _createCtrl(self, *args, **kwargs):
        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        try:
            bNoBoundingBoxScale = kwargs['bNoBoundingBoxScale']
            del kwargs['bNoBoundingBoxScale']
        except:
            bNoBoundingBoxScale = False

        if not bNoBoundingBoxScale:
            kwargs['fBoundingDiagonal'] = self.fBlueprintsDiagonal

        return ctrls.TbCtrl().create(**kwargs)


    def _createCtrl2(self, *args, **kwargs):

        print('kwargs: ', kwargs)


        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal
        print('kwargs2: ', kwargs)

        return ctrls2.Ctrl().create(**kwargs)


    def _createCtrl3(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls3.Ctrl().create(**kwargs)


    def _createCtrl4(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls4.Ctrl().create(**kwargs)

    def _createCtrl5(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls5.Ctrl().create(**kwargs)

    def _createCtrl6(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls6.Ctrl().create(**kwargs)

    def _createCtrl7(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls7.Ctrl().create(**kwargs)

    def _createCtrl8(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls8.Ctrl().create(**kwargs)


    def _createCtrl9(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls9.Ctrl().create(**kwargs)


    def _createCtrl9(self, *args, **kwargs):

        sName = kwargs['sName']
        if 'sSide' not in list(kwargs.keys()):
            kwargs['sSide'] = self.sSide

        if sName:
            kwargs['sName'] = '%s%s%s' % (self.sName, sName[0].upper(), sName[1:])
        else:
            kwargs['sName'] = self.sName

        if 'sParent' not in kwargs or kwargs['sParent'] == None:
            kwargs['sParent'] = self.sCtrlsGlobal

        return ctrls9.Ctrl().create(**kwargs)


    def _createTransform(self, sName, sParent=None, fLocalPos=None, fLocalRot=None, sMatch=None, fMatchPos=None, iIndex=None, bLocator=False):
        sFullName = 'grp_%s_%s_%s' % (self.sSide, self.sName, sName)
        if iIndex != None:
            sFullName = '%s_%03d' % (sFullName, iIndex)

        if bLocator:
            sTransform = cmds.spaceLocator(n=sFullName)[0]
            cmds.parent(sTransform, sParent if sParent else self.sRigGrp)
            xforms.resetTransform(sTransform)
        else:
            sTransform = cmds.createNode('transform', n=sFullName, p=sParent if sParent else self.sRigGrp)

        if sMatch != None:
            cmds.delete(cmds.parentConstraint(sMatch, sTransform))
        else:
            if fLocalPos != None:
                cmds.setAttr('%s.t' % sTransform, *fLocalPos)
            if fLocalRot != None:
                cmds.setAttr('%s.r' % sTransform, *fLocalRot)
        if not utils.isNone(fMatchPos):# != None:
            cmds.move(fMatchPos[0], fMatchPos[1], fMatchPos[2], sTransform, a=True, ws=True)
        return sTransform


    def _createJoint(self, sName, sParent=None, fLocalPos=None, fLocalRot=None, sMatch=None, fMatchPos=None, iIndex=None, fSize=1.0):
        sFullName = 'jnt_%s_%s_%s' % (self.sSide, self.sName, sName)
        if iIndex != None:
            sFullName = '%s_%03d' % (sFullName, iIndex)

        sTransform = cmds.createNode('joint', n=sFullName, p=sParent if sParent else self.sRigGrp)

        cmds.setAttr('%s.radius' % sTransform, fSize)

        if sMatch != None:
            cmds.delete(cmds.parentConstraint(sMatch, sTransform))
        else:
            if fLocalPos != None:
                cmds.setAttr('%s.t' % sTransform, *fLocalPos)
            if fLocalRot != None:
                cmds.setAttr('%s.r' % sTransform, *fLocalRot)
        if fMatchPos != None:
            cmds.move(fMatchPos[0], fMatchPos[1], fMatchPos[2], sTransform, a=True, ws=True)
        return sTransform


    def _createNodeName(self, sName, sType=None, iIndex=None, iCount=None):
        if iCount == None:
            sSplits = [sStr for sStr in [sType, self.sSide, self.sName, sName, '%03d' % iIndex if iIndex != None else None] if sStr]
            return '_'.join(sSplits)
        else:
            if sType:
                return ['%s_%s_%s_%s_%03d' % (sType, self.sSide, self.sName, sName, i) for i in range(iCount)]
            else:
                return ['%s_%s_%s_%03d' % (self.sSide, self.sName, sName, i) for i in range(iCount)]



    def buildBlueprintRig(self, lParent=None):
        self.createOrSetBlueprints(lParent=lParent)
        sTopGrp = '_blueprintRig'
        if not cmds.objExists(sTopGrp):
            cmds.createNode('transform', name=sTopGrp)

        if list(self.dBlueprints.values()) or self.sBlueprintCurves:
            blueprints.createNamespacedBlueprints(list(self.dBlueprints.values()), self.sBpSkelGrp)

        self.sBpTopGrp = cmds.createNode('transform', name='grp_%s_%sBlueprint' % (self.sSide, self.sName), p=sTopGrp)

        cGlobal = blueprints.createOrGetGlobalCtrl()
        cmds.parentConstraint(cGlobal.sCtrl, self.sBpTopGrp, mo=True)
        cmds.scaleConstraint(cGlobal.sCtrl, self.sBpTopGrp)

        self.dBpOutputs = {} # here we can add group controls in the limbs, that constrain other limbs
        self.cLastBp = None


    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):
        sOutputList =  xData.get('root.sOutputsFILE', None)
        if sOutputList:
            sKey, sOutputName = utils.extractOutputInfo(sOutputList[0])[:2]
            if sKey == utils.kNoneString or sKey == utils.kCustomString:
                return
            try:
                lParentLimb = dLimbsDict[sKey]
            except:
                raise Exception('limb with key "%s" not found in: %s' % (sKey, dLimbsDict))

            if lParentLimb.bIsBpBarent:
                if sOutputName in list(lParentLimb.dBpOutputs.keys()):
                    for cC in self.cBpRoots:
                        cParent = dLimbsDict[sKey].dBpOutputs[sOutputName]
                        cmds.parentConstraint(cParent.sSuper if cParent.sSuper else cParent.sOut, cC.sPasser, mo=True)


        # for selecting option from puppet tool
        for cCtrl in self.cBpAll:
            utils.addStringAttr(cCtrl.sCtrl, 'sBlueprintCtrl', self.sLimbName)


        if self.cLastBp != None:
            for lChild in lChildren:
                for cRoot in lChild.cBpRoots:
                    cmds.controller(cRoot.sCtrl, self.cLastBp.sCtrl, parent=True)


    def pickwalkChildrenSetups(self, lChildren):
        dCtrls = defaultdict(list)
        for lChild in lChildren:
            for sFeature, xData in lChild.dFeatureData.items():
                cChildCtrls = xData[1]
                cParentLessCtrls = [cC for cC in cChildCtrls if not cmds.controller(cC.sCtrl, q=True, p=True)]
                for cC in cParentLessCtrls:
                    sCtrlKey = utils.getStringAttr(cC.sCtrl, 'sPickwalkKey', '')
                    dCtrls['%s.%s.%s' % (type(lChild), sFeature, sCtrlKey)].append(cC)

            # maybe remove this because of the bug of first ctrls in group walking to first controls of other groups?
            cParentLessCtrls = [cC for cC in lChild.cDetailCtrls if not cmds.controller(cC.sCtrl, q=True, p=True)]
            for cC in cParentLessCtrls:
                sCtrlKey = utils.getStringAttr(cC.sCtrl, 'sPickwalkKey', '')
                dCtrls['%s.%s.%s' % (type(lChild), 'detail', sCtrlKey)].append(cC)


        for _, cCtrls in dCtrls.items():
            cmds.controller([cC.sCtrl for cC in cCtrls], g=True)
            sFirstTag = cmds.controller(cCtrls[0].sCtrl, q=True)[0]
            sControllerGroup = cmds.listConnections('%s.parent' % sFirstTag, d=True, s=False)[0]
            sControllerGroup = cmds.rename(sControllerGroup, 'groupController_%s' % '_'.join([cC.sCtrl for cC in cCtrls]))
            if hasattr(self, 'sFeatureShape') and cmds.objectType(self.sFeatureShape) == 'transform':
                sParentCtrl = self.sFeatureShape
            else:
                aCtrlPoints = [cmds.xform(cC.sCtrl, q=True, t=True, ws=True) for cC in cCtrls]
                iClosestParentCtrls = xforms.findClosestPoints(aCtrlPoints, self.aAllCtrlPoints)
                iMostFrequentClosest = np.bincount(iClosestParentCtrls).argmax()
                sParentCtrl = self.cAllCtrls[iMostFrequentClosest].sCtrl

            sParentTag = cmds.controller(sParentCtrl, q=True)[0]
            sChildrenAttrOnParent = '%s.children' % sParentTag
            iCurrentChildrenCount = len(cmds.listConnections(sChildrenAttrOnParent, s=True, d=False) or [])
            cmds.connectAttr('%s.parent' % sControllerGroup, '%s[%d]' % (sChildrenAttrOnParent,iCurrentChildrenCount))
            cmds.connectAttr('%s.prepopulate' % sParentTag, '%s.prepopulate' % sControllerGroup)



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        for sAttr, fValue in list(self.finalSetAttrs.items()):
            if cmds.objExists(sAttr):
                cmds.setAttr(sAttr, fValue)


        # # parent control tags
        # if self.lParentLimb:
        #     if len(self.cAllCtrls) and len(self.lParentLimb.aAllCtrlPoints):
        #         for cC, aP in zip(self.cAllCtrls, self.aAllCtrlPoints):
        #             if not cmds.controller(cC.sCtrl, q=True, p=True):
        #                 iClosestParentCtrl = xforms.findClosestPoints([aP], self.lParentLimb.aAllCtrlPoints)[0]
        #                 cmds.controller(cC.sCtrl, self.lParentLimb.cAllCtrls[iClosestParentCtrl].sCtrl, parent=True)

        for cC in self.cAllCtrls:
            utils.addStringAttr(cC.sCtrl, 'sLimbCtrl', self.sLimbName)
            sClass = self.__class__
            utils.addStringAttr(cC.sCtrl, 'sLimbType', str(sClass).split('.')[1])

        # segments
        if self.iSegmentsPriority > 0:
            sRoots = xforms.getRoots(cmds.ls(self.sSkinJoints, et='joint'))
            sRoots = [sR for sR in sRoots if not sR.endswith('End')]
            if sRoots:
                segments.updateTagAttr(sRoots[0], {'iPriority': self.iSegmentsPriority, 'bIsRoot': True})
        elif self.iSegmentsPriority < 0:
            for sJ in self.sSkinJoints:
                segments.updateTagAttr(sJ, {'bDisable': True})


    def _fillBlueprints(self, fPoints, sNames, sRefMainKey=None, fJointRadius=None, sParent=None):

        if fJointRadius == None:
            fJointRadius = xforms.getAverageJointRadius()
        self.dBlueprints = OrderedDict()
        self.sBlueprintCurves = []
        if fPoints == None:
            return

        if sParent == None:
            sParent = self.sBpSkelGrp
            if not cmds.objExists(self.sBpSkelGrp):
                cmds.createNode('transform', name=self.sBpSkelGrp)

        self.fBlueprintsCreationRotationOffset = np.array(self.fBlueprintsCreationRotationOffset, dtype='float64')
        self.fBlueprintsCreationTranslationOffset = np.array(self.fBlueprintsCreationTranslationOffset, dtype='float64')
        mTransformOffset = OpenMaya2.MTransformationMatrix()
        if self.sSide == 'r':
            self.fBlueprintsCreationTranslationOffset[0] *= -1.0
            self.fBlueprintsCreationRotationOffset[1] *= -1.0
            self.fBlueprintsCreationRotationOffset[2] *= -1.0

        mTransformOffset.setTranslation(OpenMaya2.MVector(self.fBlueprintsCreationTranslationOffset), OpenMaya2.MSpace.kWorld)
        mOffsetEuler = OpenMaya2.MEulerRotation([math.radians(v) for v in self.fBlueprintsCreationRotationOffset])
        mTransformOffset.setRotation(mOffsetEuler)
        mOffset = mTransformOffset.asMatrix()


        sUp, sAim = cmds.createNode('transform'), cmds.createNode('transform')
        sCreatedJoints = []
        self.dMirrorOrients = {}
        def __createJointsREC(fTransform, sName, sPrevJoint=None, aNextPos=None):

            if isinstance(sName, list) and not isinstance(fTransform, list):
                raise Exception('passed names is list but points not: %s -> %s (%s)' % (sName, fTransform, self.sName))
            if not isinstance(sName, list) and isinstance(fTransform, list):
                raise Exception('passed names is not list and points is: %s -> %s (%s)' % (sName, fTransform, self.sName))
            elif isinstance(sName, list): #both are list now
                if len(sName) != len(fTransform):
                    raise Exception('passed points and names don\'t have same length: %d -> %d ... %s -> %s (%s)' % (len(sName), len(fTransform), sName, fTransform, self.sName))
                sPrevBefore = sPrevJoint
                iNextInd = 0
                for fP, sN in zip(fTransform, sName):
                    iNextInd += 1
                    aNewNextPos = None
                    if iNextInd < len(fTransform):
                        aPossibleNextPos = fTransform[iNextInd]
                        for i in range(10):
                            if isinstance(aPossibleNextPos, tuple):
                                aNewNextPos = np.array(aPossibleNextPos[:3], dtype='float64')
                                break
                            elif isinstance(aPossibleNextPos, list):
                                aPossibleNextPos = aPossibleNextPos[0]
                            else:
                                raise Exception('something went wrong. %s is not a list and not a tuple' % aPossibleNextPos)
                            if i == 9:
                                raise Exception('something went wrong with finding pos to aim to. Maybe a loop issue?')

                    sPrevJoint = __createJointsREC(fP, sN, sPrevJoint=sPrevJoint, aNextPos=aNewNextPos)
                return sPrevBefore
            else:
                sJoint = 'bp_%s_%s' % (self.sLimbName, sName)
                sFlipOnMirror = 'xy' if len(fTransform) < 7 or fTransform[6] == None else fTransform[6]
                sAimAxis = 'xy' if len(fTransform) < 8 or fTransform[7] == None else fTransform[7]
                bMirror = True if len(fTransform) < 9 or fTransform[8] == None else fTransform[8]

                if not isinstance(sFlipOnMirror, str):
                    raise Exception('%s: index 6 is not an axis (%s)' % (self.sLimbName, str(fTransform)))
                self.dMirrorOrients[sJoint] = bMirror
                if not cmds.objExists(sJoint):
                    sJoint = cmds.createNode('joint', n=sJoint, p=sPrevJoint if sPrevJoint else sParent)
                    cmds.setAttr('%s.jox' % sJoint, k=True)
                    cmds.setAttr('%s.joy' % sJoint, k=True)
                    cmds.setAttr('%s.joz' % sJoint, k=True)

                    fCurrentRadius = fJointRadius
                    if utils.getSide(sJoint) != 'm':
                        sMirrorRadius = '%s.radius' % utils.getMirrorName(sJoint)
                        if cmds.objExists(sMirrorRadius):
                            fCurrentRadius = cmds.getAttr(sMirrorRadius)
                    cmds.setAttr('%s.radius' % sJoint, fCurrentRadius)

                    if len(fTransform) >= 6:
                        aPos = list(fTransform[:3])
                        aUp = fTransform[3:6]
                    elif len(fTransform) == 3:
                        aPos = np.copy(fTransform)
                        aUp = np.array([0,1,0], dtype='float64')
                    else:
                        raise Exception('position array must be either 3 or 6 or more items - %s in %s' % (fTransform, self.sName))

                    if bMirror and self.sSide == 'r':
                        aPos[0] *= -1.0
                        if not utils.isNone(aNextPos):
                           aNextPos[0] *= -1

                    cmds.move(float(aPos[0]), float(aPos[1]), float(aPos[2]), sJoint, a=True, ws=True)

                    if not utils.isNone(aNextPos):# != None:
                        fAimVector = [0,0,0]
                        fAimVector['xyz'.index(sAimAxis[0])] = self.fSideMultipl if bMirror and sAimAxis[0] in sFlipOnMirror else 1
                        fUpVector = [0,0,0]
                        fUpVector['xyz'.index(sAimAxis[1])] = self.fSideMultipl if bMirror and sAimAxis[1] in sFlipOnMirror else 1
                        xforms.orientThreePoints(sJoint, aNextPos-aPos, aUp, fAimVector, fUpVector)

                    sCreatedJoints.append(sJoint)
                self.dBlueprints[sName] = sJoint
                return sJoint

        __createJointsREC(fPoints, sNames, None)
        self.fBlueprintsDiagonal = xforms.getJointHierarchyBoundingDiagonal(list(self.dBlueprints.values()))
        cmds.delete(sUp, sAim)


        if sRefMainKey:
            sJoint = self.dBlueprints[sRefMainKey]
        else:
            sJoint = list(self.dBlueprints.values())[-1]
        mMatrix = OpenMaya2.MMatrix(cmds.xform(sJoint, q=True, ws=True, m=True))
        mTransform = OpenMaya2.MTransformationMatrix(mMatrix)
        mTransform.setTranslation(OpenMaya2.MVector(0, 0, 0), OpenMaya2.MSpace.kWorld)
        self.mBpRefOrientation = mTransform.asMatrix()


        if sCreatedJoints:
            for sRoot in xforms.getRoots(sCreatedJoints):
                mMatrix = OpenMaya2.MMatrix(cmds.xform(sRoot, q=True, ws=True, m=True))
                mTransformed = mMatrix * mOffset

                if self.lParent:
                    sBp = self.sApproximateParentBlueprint
                    if sBp:
                        sOutputParent = self.lParent.dBlueprints[sBp]
                        aParent = np.array(cmds.xform(sOutputParent, q=True, m=True, ws=True), dtype='float64').reshape(4,4)
                        if True: # not taking the parent orientation
                            aParent[0] = [1,0,0,0]
                            aParent[1] = [0,1,0,0]
                            aParent[2] = [0,0,1,0]
                            mParent = OpenMaya2.MMatrix(list(aParent))
                            mTransformed = mTransformed * mParent
                        else: # taking the parent orientation
                            mParent = OpenMaya2.MMatrix(list(aParent))
                            mLocal = mTransformed * self.lParent.mBpRefOrientation.inverse()
                            mTransformed = mLocal * mParent
                cmds.xform(sRoot, ws=True, m=list(mTransformed))

            if self.report:
                self.report.addLogText('"%s" - added %d Blueprint Joints (%s)' % (self.sLimbName, len(sCreatedJoints), ', '.join(sCreatedJoints)))

        for sBlueprint in list(self.dBlueprints.values()):
            utils.addStringAttr(sBlueprint, 'sBlueprintJoint', self.sLimbName)

        return sCreatedJoints


    def setBpRefOrientationMatrix(self, sJoint):
        mMatrix = OpenMaya2.MMatrix(cmds.xform(sJoint, q=True, ws=True, m=True))
        mTransform = OpenMaya2.MTransformationMatrix(mMatrix)
        mTransform.setTranslation(OpenMaya2.MVector(0, 0, 0), OpenMaya2.MSpace.kWorld)
        self.mBpRefOrientation = mTransform.asMatrix()


    def _getFinalOutputFromKey(self, sKey):
        return self.dOutputs[sKey]


    def _replaceOutput(self, sKey, sNewParent, bSkipIfNotExist=False, bAttach=True, bAttachScale=False):
        try:
            sJoint = self.dOutputs[sKey]
        except:
            if not bSkipIfNotExist:
                raise Exception('%s does not exist in self.dOutputs (%s)' % (sKey, self.sLimbName))
            else:
                sJoint = None
        if sJoint:
            sOld = cmds.rename(sJoint, '%s_isReplaced' % sJoint)
            sJoint = cmds.createNode('joint', n=sJoint, p=sNewParent)
            cmds.setAttr('%s.radius' % sJoint, cmds.getAttr('%s.radius' % sOld))
            if bAttach:
                xforms.matrixParentConstraint(sOld, sJoint, skipScale=[] if bAttachScale else ['x','y','z'])
            else:
                cmds.delete(cmds.parentConstraint(sOld, sJoint))
            return sJoint
        else:
            return None


    def createMiddleMirrorBpSetup(self, sMirrorGlobalAttr):
        return False


    def removeEndSkinJoint(self):
        if self.bRemoveEndSkinJoint:
            sOutputKey = list(self.dOutputs.keys())[-1]
            sOutputJoint = self.dOutputs[sOutputKey]

            if cmds.objectType(sOutputJoint) == 'joint':
                sParentJoint = cmds.listRelatives(sOutputJoint, p=True)[0]
                sParentGroup = cmds.createNode('transform', n='%s__substituteJointParent' % sParentJoint, p=self.sModulesGlobal)
                xforms.matrixParentConstraint(sParentJoint, sParentGroup, skipScale=[])
                cmds.parent(sOutputJoint, sParentGroup)

            self.dSkinJointSubstitutes[sOutputJoint] = sParentJoint


    def parentSkeleton(self, dCreatedLimbs): # getting called at very end, after unparentNotSkinnedJoints()

        sParentTransform = self.sSkeletonGlobal
        sParentLimb = self.dMergedData['__parent__']
        self.lParentLimb = dCreatedLimbs[sParentLimb] if sParentLimb else None

        if sParentLimb and not self.bForceParentSkeletonToRoot:
            sParentOutput = self.dMergedData['parentOutputFILE']
            dParentOutputs = self.lParentLimb.dOutputs
            try:
                sParentTransform = dParentOutputs[sParentOutput]
            except:
                sParentTransform = dParentOutputs[list(dParentOutputs.keys())[0]]

            if cmds.objectType(sParentTransform) != 'joint':

                sJointParentTransforms = [sO for sO in list(dParentOutputs.values()) if cmds.objectType(sO) == 'joint']
                if sJointParentTransforms:
                    aPoints = [cmds.xform(sParentTransform, q=True, ws=True, t=True)]
                    iClosest = xforms.findClosestJoints(aPoints, sJointParentTransforms)[0]
                    sParentTransform = sJointParentTransforms[iClosest]
                else:
                    sParentTransform = self.sSkeletonGlobal

            if sParentTransform in self.lParentLimb.dSkinJointSubstitutes:
                sParentTransform = self.lParentLimb.dSkinJointSubstitutes[sParentTransform]

            sReplaceParentAttr = '%s.replaceParent' % sParentTransform
            if cmds.objExists(sReplaceParentAttr):
                sParentTransform = cmds.getAttr(sReplaceParentAttr)

        if not len(self.sSkinJoints):
            return

        sRoots = xforms.getRoots(self.sSkinJoints)
        sRootJoints = [sR for sR in sRoots if cmds.objectType(sR) == 'joint' if sR not in self.dSkinJointSubstitutes]

        if sRootJoints:
            cmds.parent(sRootJoints, sParentTransform)
            for sR in sRootJoints:
                xforms.bugFixCleanConstraint2018(sR)

        # # parent scaling from joints is handled in puppet.py, but here we have to deal with
        # sRootNotJoints = list(set(sRoots) - set(sRootJoints))
        # if sRootNotJoints:
        #     pass


    def replaceAttachers(self, sFrom, sTo):
        # jnt_m_jawFaceOrigin
        pass


    def getReplacerAttacher(self, sAttacher):
        sTransform = xforms.createOrReturnTopGroup('%s_REPLACER' % sAttacher)
        try:
            cmds.parent(sTransform, self.sModulesGlobal)
        except: pass
        cmds.delete(cmds.parentConstraint(sAttacher, sTransform))
        return sTransform


    def connectAttachers(self, dCreatedLimbs):
        dMergedData = self.dMergedData
        sAttachers = dMergedData['sAttachers']
        for sFeature in dMergedData['sFeatures']:
            sAttachers += dMergedData['%s.sAttachers' % sFeature]

        sAttachers.sort() # to make sure that scale is after root


        # for the mesh attachments
        sScaleTransform = None
        if 'scale' in sAttachers:
            sOutputs = dMergedData['scale.sOutputsFILE']
            if sOutputs:
                sOutputLimb, sOutputName, sShortName, fWeight = utils.extractOutputInfo(sOutputs[0])

                if sOutputLimb == utils.kCustomString:
                        sScaleTransform = sOutputName
                elif sOutputLimb == utils.kNoneString:
                    pass
                else:
                    tOutputLimb = dCreatedLimbs[sOutputLimb]
                    sScaleTransform = tOutputLimb.dOutputs[sOutputName]


        dSwitchAttrs = defaultdict(list)
        # if self.sLimbName == 'm_singleBone':
        #     print 'sAttachers: ', sAttachers
        #     for sA in sAttachers:
        #         print 'split: ', dMergedData['%s.bSplitFILE' % sA]

        dTrs = {}
        sAttachersPlusSplit = []
        for sA in sAttachers:
            sAttachersPlusSplit.append(sA)
            if dMergedData['%s.bSplitFILE' % sA] == True:
                sChildA = '%s(1)' % sA
                sAttachersPlusSplit.append(sChildA)
                # self.ddAllAttacherBuildDatas[sChildA] = sA
                dTrs[sA] = 't'
                dTrs[sChildA] = 'r'
            else:
                dAttacherPredifinedData = self.dMergedData['%s.dPredefinedData' % sA]
                dTrs[sA] = dAttacherPredifinedData.get('sTrs', 'tr')

        for sA in sAttachersPlusSplit:
            try:
                if '.' in sA:
                    sFeature, _ = sA.split('_')
                    if not dMergedData.get('%s.bCheckedFILE' % sFeature, True):
                        continue
                sShortA = sA.split('(')[0]
    
                # if utils.data.get('bAllSplitAttachersTakeLocals', xDefault=True) == True: # in future this should just ignore that check
                sLocalAttacherOutputs = self.dLocalAttacherOutputs.get(sShortA, [])
                # else:
                #     sLocalAttacherOutputs = self.dLocalAttacherOutputs.get(sA, [])
    
                sOutputs = sLocalAttacherOutputs + dMergedData['%s.sOutputsFILE' % sA]
                dLocalOutputs = dMergedData.get('%s.dLocalOutputsFILE' % sA, {})
                sOutputs = [sO for sO in sOutputs if not sO.startswith(utils.kNoneString)]
                if not sOutputs:
                    cmds.warning('attacher %s was not filled in %s )' % (sA, self.sLimbName))
                    continue
    
                # self.dAttacherInfo[sA] = sOutputs
    
                bSpaceBlend = dMergedData.get('%s.bDoBlendFILE' % sA, False)
    
                for sAttacherBuildData in self.ddAllAttacherBuildDatas[sShortA]:
                    dAttacherPredifinedData = self.dMergedData['%s.dPredefinedData' % sShortA]
                    if not sAttacherBuildData:
                        continue
                    sOutputsShort = []
                    sOutputTransforms = []
                    iDefaultWeights = []
                    sOutputLimbs = [] # added for unreal..?
    
                    mAttacherDagPath, cAttacherBlendCtrl = sAttacherBuildData
                    sAttacherTransform = mAttacherDagPath.partialPathName()
    
                    for i, sOutput in enumerate(sOutputs):  # if it's more than one, we'll blend
                        if i < len(sLocalAttacherOutputs):
                            sOutput, sOutputTransform = utils.tempOutputSplit(sOutput)
                            if sOutput in dLocalOutputs:
                                sO,sW = utils.tempOutputSplit(dLocalOutputs[sOutput])
                                sOutputsShort.append(sO)
                                fWeight = float(sW)
                            else:
                                sOutputsShort.append(sOutput)
                                fWeight = 0
                            sOutputLimb = None # for unreal
                        else:
                            sOutputLimb, sOutputName, sShortName, fWeight = utils.extractOutputInfo(sOutput, iIndex=i)
    
                            if sOutputLimb == utils.kCustomString:
                                if not len(sOutputName):
                                    raise Exception('"%s" there is a custom output but nothing defined ("%s")' % (self.sLimbName, sA))
                                if not cmds.objExists(sOutputName) or sOutputName.endswith('.mesh') or '.deformers' in sOutputName:
                                    sOutputTransform = xforms.createTransform(utils.getCustomAttacherTransformName(self.sLimbName, sA), sMatch=sAttacherTransform,
                                                                              sParent=xforms.createIfNotExists('grp_customTransforms', sParent=self.sModulesGlobal), bErrorIfExists=False)
    
                                    # print 'sScaleTransform: "%s"' % sScaleTransform
                                    utils.addStringAttr(sOutputTransform, 'sPuppetParentAttachment', sOutputName)
                                    if sScaleTransform:
                                        utils.addStringAttr(sOutputTransform, 'sPuppetParentAttachmentScaleTransform', sScaleTransform)
                                    utils.addStringAttr(sOutputTransform, 'sLimb', self.sLimbName)
                                else:
                                    sOutputTransform = sOutputName
                            else:
                                tOutputLimb = dCreatedLimbs[sOutputLimb]
                                sOutputTransform = tOutputLimb.dOutputs[sOutputName]
    
                            sOutputsShort.append(sShortName)
                            if not sOutputTransform:
                                raise Exception('output "%s" missing from limb "%s"' % (sOutputName, self.sLimbName))
    
                        sOutputTransforms.append(sOutputTransform) # for unreal
                        sOutputLimbs.append(sOutputLimb) # for unreal
    
                        iDefaultWeights.append(fWeight)
                    if not np.any(iDefaultWeights):
                        iDefaultWeights[0] = 1.0
    
                    self.dAttacherInfo[sA] = sOutputLimbs, sOutputTransforms # for unreal
    
                    bMaintainOffset = dAttacherPredifinedData.get('bMaintainOffset', True)
                    # funcConstraint = dAttachData.get('func', cmds.parentConstraint)
                    constraintArgs = dAttacherPredifinedData.get('constraintArgs', {})
                    # sTrs = dAttacherPredifinedData.get('sTrs', 'tr')
                    sTrs = dTrs[sA]
    
                    if sTrs == 'c':
                        for t, sTransform in enumerate(sOutputTransforms):
                            sMessageAttr = utils.addAttr(sAttacherTransform, ln='%s%d' % (sA, t), at='message')
                            cmds.connectAttr('%s.message' % sTransform, sMessageAttr)
                        funcConstraint = None
    
                    else:
                        # sTrsName = ''
                        if sTrs == 'tr' or sTrs == 'rt':
                            funcConstraint = cmds.parentConstraint
                            sTrsName = ''
                        elif sTrs == 't':
                            funcConstraint = cmds.parentConstraint
                            constraintArgs['skipRotate'] = ['x', 'y', 'z']
                            sTrsName = '_T'
                        elif sTrs == 'r':
                            funcConstraint = cmds.parentConstraint
                            constraintArgs['skipTranslate'] = ['x', 'y', 'z']
                            sTrsName = '_R'
                        elif sTrs == 's':
                            funcConstraint = cmds.scaleConstraint
                            sTrsName = '_S'
                        else:
                            raise Exception('invalid trs: "%s"' % sTrs)
    
                        if self.sCreateReplacerAttachers:
                            for o, sO in enumerate(sOutputTransforms):
                                if sO in self.sCreateReplacerAttachers:
                                    sOutputTransforms[o] = self.getReplacerAttacher(sO)
    
                        if len(sOutputs) == 1:
                            sConnectedDecompose = cmds.listConnections(sAttacherTransform, s=True, d=False, t='decomposeMatrix')
                            if funcConstraint == cmds.scaleConstraint and \
                            sConnectedDecompose and \
                            cmds.objExists('%s.matrixParentConstraintTarget' % sConnectedDecompose[0]) and \
                            cmds.getAttr('%s.matrixParentConstraintTarget' % sConnectedDecompose[0]) == sOutputTransforms[0]:
                                cmds.connectAttr('%s.outputScale' % sConnectedDecompose[0], '%s.s' % sAttacherTransform)
                            elif funcConstraint != cmds.parentConstraint:
                                funcConstraint(sOutputTransforms[0], sAttacherTransform, mo=bMaintainOffset, **constraintArgs)[0]
                            else:
                                if cmds.parentConstraint(sAttacherTransform, q=True):
                                    cmds.parentConstraint(sOutputTransforms[0], sAttacherTransform, mo=bMaintainOffset, **constraintArgs)
                                else:
                                    if 'skipScale' not in constraintArgs:
                                        constraintArgs['skipScale'] = ['x','y','z']
                                    xforms.matrixParentConstraint(sOutputTransforms[0], sAttacherTransform, mo=bMaintainOffset, **constraintArgs)
    
                            if funcConstraint == cmds.scaleConstraint and not cmds.listConnections('%s.s' % self.sOutGrp, s=True, d=False):
                                cmds.scaleConstraint(sOutputTransforms[0], self.sOutGrp)
    
    
                        elif len(sOutputs) >= 2:
                            sOutputsShort = [(sO if sO else 'space') for sO in sOutputsShort]
    
                            if bSpaceBlend:
                                sConstr = funcConstraint(*(sOutputTransforms + [sAttacherTransform]), mo=bMaintainOffset,
                                                         **constraintArgs)[0]
                                if funcConstraint != cmds.scaleConstraint:
                                    cmds.setAttr('%s.interpType' % sConstr, 2)
    
                                if not cAttacherBlendCtrl:
                                    raise Exception('attacher "%s" can only take one output (%s)' % (sA, self.sLimbName))
                                try:
                                    nodes.addSeparatorAttr(cAttacherBlendCtrl.sCtrl, 'spaces')
                                except:
                                    pass
    
                                dCheckDuplicates = Counter(sOutputsShort)
                                for sAttr, iCount in dCheckDuplicates.items():
                                    if iCount > 1:
                                        raise Exception('For "%s" one of your attachers has multiple same names ("%s")' % (self.sLimbName, sAttr))
    
                                sAttrs = [None] * len(sOutputs)
                                for o in range(len(sOutputs)):
                                    if o == 0:
                                        sDefaultAttr = utils.addAttr(cAttacherBlendCtrl.sCtrl,
                                                                     ln='%s%s' % (sOutputsShort[o], sTrsName),
                                                                     minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True, bReturnIfExists=True) # reason why bReturnIfExists is for when there are only local attachers
                                        cmds.setAttr(sDefaultAttr, lock=True)
                                        sAttrs[o] = 1.0
                                    else:
                                        sAttrs[o] = utils.addAttr(cAttacherBlendCtrl.sCtrl,
                                                                  ln='%s%s' % (sOutputsShort[o], sTrsName),
                                                                  minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
                                
                                for o, sOutput in enumerate(sOutputs):
                                    sConstraintAttr = '%s.%sW%d' % (sConstr, sOutputTransforms[o], o)
                                    if o < len(sOutputs)-1:
                                        sDifference = nodes.createAdditionNode(sAttrs[o:], sOperation='minus', sName='spaceBlend_%s_%s' % (sOutputsShort[0], sTrsName))
                                        nodes.createClampNode(sDifference, 0, 1, sName='spaceBlend_%s_%s' % (sOutputsShort[0], sTrsName), sTarget=sConstraintAttr)
                                    else:
                                        cmds.connectAttr(sAttrs[o], sConstraintAttr)
    
                                    if o > 0:
                                        cmds.setAttr(sAttrs[o], iDefaultWeights[o])
                                dSwitchAttrs[cAttacherBlendCtrl.sCtrl].append((True, sAttrs, sOutputsShort, sTrs))
    
                            else:
                                iBiggestDefaultWeight = np.argmax(iDefaultWeights)
                                sSwitchAttr = utils.addAttr(cAttacherBlendCtrl.sCtrl, ln='space%s' % sTrsName,
                                                            at='enum', en=':'.join(sOutputsShort), k=True)
                                dSwitchAttrs[cAttacherBlendCtrl.sCtrl].append((False, sSwitchAttr, sOutputsShort, sTrs))
    
                                cmds.setAttr(sSwitchAttr, int(iBiggestDefaultWeight))
    
                                sOutMatrices = []
                                for sO in sOutputTransforms:
                                    fOffset = utils.multiplyMatrixAttrValues([cmds.getAttr('%s.worldMatrix' % sAttacherTransform),
                                                                              cmds.getAttr( '%s.worldInverseMatrix' % sO)])
                                    sMultiply = nodes.createMultMatrixNode([fOffset,
                                                                            '%s.worldMatrix' % sO,
                                                                            '%s.parentInverseMatrix' % sAttacherTransform], sName='spaceSwitch_%s_%s' % (sO, sTrsName))
                                    sOutMatrices.append(sMultiply)
    
                                sSwitchMatrix = nodes.createChoiceNode(sSwitchAttr, sOutMatrices, sName='spaceSwitch_%s_%s' % (sAttacherTransform, sTrsName))
                                if sTrs == 'tr' or sTrs == 'rt':
                                    nodes.createDecomposeMatrix(sSwitchMatrix, sTargetPos='%s.t' % sAttacherTransform, sTargetRot='%s.r' % sAttacherTransform,
                                                                sName='spaceSwitch_%s_%s' % (sAttacherTransform, sTrsName))
                                elif sTrs == 't':
                                    nodes.createDecomposeMatrix(sSwitchMatrix, sTargetPos='%s.t' % sAttacherTransform,
                                                                sName='spaceSwitch_%s_%s' % (sAttacherTransform, sTrsName))
                                elif sTrs == 'r':
                                    nodes.createDecomposeMatrix(sSwitchMatrix, sTargetRot='%s.r' % sAttacherTransform,
                                                                sName='spaceSwitch_%s_%s' % (sAttacherTransform, sTrsName))
                                elif sTrs == 's':
                                    nodes.createDecomposeMatrix(sSwitchMatrix, sTargetScale='%s.t' % sAttacherTransform,
                                                                sName='spaceSwitch_%s_%s' % (sAttacherTransform, sTrsName))
                                else:
                                    raise Exception('invalid trs: "%s"' % sTrs)
            except Exception:
                cmds.confirmDialog(m='Problem with attacher "%s" of limb "%s" (see script editor for more detail)' % (sA, self.sLimbName))
                raise

        for sCtrl, xAttrs in list(dSwitchAttrs.items()):
            utils.addStringAttr(sCtrl, '__switchInfo__', str(xAttrs), bLock=True)

