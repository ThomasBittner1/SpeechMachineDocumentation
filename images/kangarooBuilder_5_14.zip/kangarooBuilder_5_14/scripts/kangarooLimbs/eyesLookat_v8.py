###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.api.OpenMaya as OpenMaya2
import maya.cmds as cmds
import numpy as np

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTools.constraints as constraints
import kangarooTools.barycentric as barycentric
import kangarooTools.blueprints as blueprints
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils
import kangarooTools.utilsUnreal as utilsUnreal
import kangarooTabTools.unreal as unreal


class LEyesLookAt(baseLimb._LBaseLimb):
    def __init__(self, sName='eyesLookAt', sSide='m', bForceParentSkeletonToRoot=False,
                fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0),
                fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0), bEyelidBlink=False, fLidFollowDefault=0.5, sBlueprintMirrorPlane=''):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset, sBlueprintMirrorPlane=sBlueprintMirrorPlane)

        self.bEyelidBlink = bEyelidBlink
        self.sDefaultFeatures = ['feature_lookAt']
        self.fLidFollowDefault = fLidFollowDefault


    def generateAttachers_init(self, **args):
        return {'root': {'sTrs':'tr', 'bMulti':True},
                'scale': {'sTrs':'s', 'bMulti':False},
                'eyes': {'sTrs': 'c', 'bMulti': True}}


    def createOrSetBlueprints(self, lParent=None):
        return self._fillBlueprints([[(0, 0, 5)]], [['main']])


    def generateAttachers_lookat(self, **args):
        return {} #['lookAt']


    def feature_lookAt(self, bShortCtrlNames=True, bPupilScale=False, bIrisScale=False):
        dAttacherBuildData = {}
        self.bShortCtrlNames = bShortCtrlNames
        self.cLookAt = self._createCtrl4(sName='' if self.bShortCtrlNames else 'lookAt', sAttrs=['t', 'r'], sSide='m',
                                    fSize=2.0, sShape='squareZ', sMatch=self.dBlueprints['main'])

        self.bPupilScale = bPupilScale
        self.bIrisScale = bIrisScale
        dAttacherBuildData['root'] = (utils.getDagPath(self.cLookAt.sPasser), self.cLookAt)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        dAttacherBuildData['eyes'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cLookAt.sPasser)
        return [], [self.cLookAt], dAttacherBuildData


    def unreal_feature_lookAt(self):
        sCommands = []
        sCommands.append('controllers.setNewColumn()')

        sCtrl = utilsUnreal.createUnrealCtrl(self.cLookAt, sWriteCommands=sCommands)

        # sJoint = self.getOutputFullNames()[0]
        sFunctionNodeName = '%s_feature_lookAt_node' % self.sLimbName

        utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_lookAt', sWriteCommands=sCommands)

        sCommands.append("%s = functions.createSingleCtrlFunction(%s)" % (sFunctionNodeName, sCtrl))
        utilsUnreal.initiateAttacherDictCommand('feature_lookAt', sWriteCommands=sCommands)
        utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_lookAt', sFunctionNodeName, sWriteCommands=sCommands)

        for cAim,tEye in zip(self.cAims, self.tEyes):
            sCommands.append('controllers.setNewColumn()')
            utilsUnreal.createUnrealCtrl(cAim, sShapeName='Default', fCtrlOrient=[0, 0, 0], sParentVar='%s.eControl' % self.cLookAt.sCtrl, sWriteCommands=sCommands)

            # ffLineShapeMatrix = [[0.1,0,0,0], [0,0.015,0,0], [0,0,0.015,0], [0,0,0,1]]
            # sCommands.append("eLine = hierarchy.createControl('line_%s', sShape='Box_Solid', eParent=%s.eControl, bNoSelect=True, fOverwriteColor=[0.5,0.5,0.5], ffShapeMatrix=%s)" % (cAim.sCtrl.replace('_ctrl',''), cAim.sCtrl, str(ffLineShapeMatrix)))

            fEndPointDefault = [cmds.getAttr('%sZ' % self.sEndPoint), cmds.getAttr('%sY' % self.sEndPoint), 0]
            sCommands.append(f"sEyeAimFunctionNode = functions.createEyeAimFunction({cAim.sCtrl}, '{tEye.dOutputs['main']}', '{tEye.dOutputs['iris']}', '{tEye.dOutputs['transform']}', {self.fLidFollowDefault})")
            sCommands.append('controllers.setNewColumn()')
            sCommands.append(f"vLookVert_{tEye.sLimbName} = hierarchy.newVariable('lookVert_{tEye.sLimbName}', bLocal=False)")
            sCommands.append(f"nodes.createSetVariableExecuteNode(vLookVert_{tEye.sLimbName}, '%s.LookVert' % sEyeAimFunctionNode)")

            sCommands.append(f"vLookHoriz_{tEye.sLimbName} = hierarchy.newVariable('lookHoriz_{tEye.sLimbName}', bLocal=False)")
            sCommands.append(f"nodes.createSetVariableExecuteNode(vLookHoriz_{tEye.sLimbName}, '%s.LookHoriz' % sEyeAimFunctionNode)")

        return sCommands, [], []



    def connectEyes(self, tEyes):

        aLookAtStart = np.array(cmds.xform(self.dBlueprints['main'], q=True, ws=True, t=True), dtype='float64')

        aStartPositions = xforms.getPositionArray([tE.dBlueprints['main'] for tE in tEyes])
        aEndPositions = xforms.getPositionArray([tE.dBlueprints['end'] for tE in tEyes])

        aMeanStart = np.mean(aStartPositions, axis=0)
        aMeanEnd = np.mean(aEndPositions, axis=0)
        aMeanDir = aMeanEnd - aMeanStart
        aMeanDir /= np.linalg.norm(aMeanDir)

        fDistance = np.linalg.norm(aMeanStart - aLookAtStart)
        aLookAtNew = aMeanStart + aMeanDir*fDistance
        sMatchEyeDirectionOffset = self.cLookAt.appendOffsetGroup('matcheyedirection')
        cmds.move(aLookAtNew[0], aLookAtNew[1], aLookAtNew[2], sMatchEyeDirectionOffset, ws=True, a=True)

        mLookAtMatrix = OpenMaya2.MMatrix(cmds.xform(self.cLookAt.sCtrl, q=True, m=True, ws=True))
        aLocalPositions = np.empty((len(tEyes),3), dtype='float64')

        sCtrlAttrs = ['t']
        if self.bPupilScale:
            sCtrlAttrs.append('sz')
        if self.bIrisScale:
            sCtrlAttrs.append('sx')
            sCtrlAttrs.append('sy')

        self.cAims = []
        for e, tEye in enumerate(tEyes):
            aDir = aEndPositions[e] - aStartPositions[e]
            aLength = np.linalg.norm(aDir)
            aDir /= aLength
            fSideMultipl = -1.0 if cmds.getAttr('%s.tx' % tEye.dBlueprints['end']) < 0.0 else 1.0
            aPlanePoint = barycentric.intersectionRayAndPlane(aMeanDir, aLookAtNew, aDir, aStartPositions[e])
            sCtrlName = '' if self.bShortCtrlNames else '%slookAt' % tEye.sName
            cAim = self._createCtrl4(sName=sCtrlName, sSide=tEye.sSide, sAttrs=sCtrlAttrs, iSlider=3,
                                       fSize=aLength, sShape='locator', sParent=self.cLookAt.sCtrl, fMatchPos=aPlanePoint)

            sAimOffset = tEye.cCtrl.appendOffsetGroup('aim')
            sAim = self._createTransform('%sAim' % tEye.sLimbName, sParent=tEye.cTransform.sOut)

            sPasserTransformCopy = xforms.createTransform(sName='grp_%s_eyeTransformPasserCopy' % tEye.sSide, sParent=tEye.cTransform.sPasser)
            sCopyAimConstraint = constraints.aimConstraintEmpty(sPasserTransformCopy)
            nodes.createVectorAdditionNode([[1,0,0]], sTarget='%s.target[0].targetTranslate' % sCopyAimConstraint)
            nodes.createMultMatrixNode(['%s.worldMatrix' % tEye.cTransform.sOut, '%s.parentInverseMatrix' % sPasserTransformCopy],
                                       sTarget='%s.worldUpMatrix' % sCopyAimConstraint)

            nodes.createPointByMatrixNode(nodes.getWorldPoint(cAim.sOut), '%s.worldInverseMatrix' % sPasserTransformCopy, sTarget='%s.t' % sAim) #####

            constraints.aimConstraintFromTransforms(sAimOffset, sAim, tEye.cTransform.sOut, bOrientUp=True, sParent=self.sCurrentFeatureGrp, aim=[1,0,0], up=[0,fSideMultipl,0])
            curves.createPoleVectorLine(cAim, tEye.dOutputs['main'])

            mAimMatrix = OpenMaya2.MMatrix(cmds.xform(cAim.sCtrl, q=True, ws=True, m=True))
            mLocalAimMatrix = OpenMaya2.MTransformationMatrix(mAimMatrix * mLookAtMatrix.inverse())
            aLocalPositions[e] = mLocalAimMatrix.translation(OpenMaya2.MSpace.kWorld)

            cmds.controller(cAim.sCtrl, self.cLookAt.sCtrl, parent=True)

            sEyeJoints = [tEye.dOutputs['main'], tEye.dOutputs['iris'], tEye.dOutputs['pupil']]
            # sPupilAttr = utils.addAttr(cAim.sCtrl, ln='pupilScale', minValue=0.2, maxValue=3, defaultValue=1.0, k=True)

            if self.bIrisScale:
                cmds.connectAttr('%s.sx' % cAim.sCtrl, '%s.sz' % sEyeJoints[1])
                cmds.connectAttr('%s.sy' % cAim.sCtrl, '%s.sy' % sEyeJoints[1])
                sScaleDiff = nodes.createVectorAdditionNode(['%s.s' % cAim.sCtrl, [1,1,1]], sOperation='minus')
                sHalfScaleDiff = nodes.createVectorMultiplyNode(sScaleDiff, 0.5, bVectorByScalar=True)
                nodes.createAdditionNode([1.0, '%sX' % sHalfScaleDiff, '%sY' % sHalfScaleDiff], sTarget='%s.sx' % sEyeJoints[1])

                # cmds.connectAttr('%s.sy' % cAim.sCtrl, '%s.sx' % sEyeJoints[1])
            if self.bPupilScale:
                cmds.connectAttr('%s.sz' % cAim.sCtrl, '%s.sx' % sEyeJoints[2])
                cmds.connectAttr('%s.sz' % cAim.sCtrl, '%s.sy' % sEyeJoints[2])
                cmds.connectAttr('%s.sz' % cAim.sCtrl, '%s.sz' % sEyeJoints[2])

            # help attr for the eyespecs
            utils.addStringAttr(cAim.sCtrl, 'sEyeJoint', tEye.dOutputs['main'])

            # follow plugs
            sLidFollow = utils.addAttr(cAim.sCtrl, ln='lidFollow', minValue=0.0, maxValue=10, defaultValue=self.fLidFollowDefault, k=True)

            # sFollowParent = cmds.createNode('transform', n='grp_%s_followMeasureParent%s' % (tEye.sSide, tEye.sName))
            self.sEndPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(sEyeJoints[1]),
                                                      '%s.worldInverseMatrix' % tEye.cCtrl.sPasser)
            sLookX = utils.addAttr(cAim.sPasser, ln='lookHoriz', k=False, cb=True)
            sLookY = utils.addAttr(cAim.sPasser, ln='lookVert', k=False, cb=True)

            fLength = cmds.getAttr('%s.tx' % sEyeJoints[1])

            sResetLook = nodes.createVectorAdditionNode([['%sZ' % self.sEndPoint, '%sY' % self.sEndPoint, 0],
                                                         [cmds.getAttr('%sZ' % self.sEndPoint), cmds.getAttr('%sY' % self.sEndPoint), 0]],
                                                        sOperation='minus')

            if fLength < 0:
                sResetLook = nodes.createVectorMultiplyNode(sResetLook, -1, bVectorByScalar=True)

            sAdjustedLook = nodes.createVectorMultiplyNode(sResetLook, sLidFollow, bVectorByScalar=True)
            cmds.connectAttr('%sX' % sAdjustedLook, sLookX)
            cmds.connectAttr('%sY' % sAdjustedLook, sLookY)

            sLookDown = utils.addAttr(cAim.sPasser, ln='lookVertDown', k=False, cb=True)
            nodes.createConditionNode(sLookY, '<', 0, nodes.createMultiplyNode(sLookY, -1), 0, sTarget=sLookDown)
            sLookUp = utils.addAttr(cAim.sPasser, ln='lookVertUp', k=False, cb=True)
            nodes.createConditionNode(sLookY, '>', 0, sLookY, 0, sTarget=sLookUp)

            self.cAims.append(cAim)
            self.sDefaultUnrealPieceInputs.append(tEye.dOutputs['main']) # this is so the eye controls get built before this




        fOffset = np.max(np.abs(aLocalPositions)) * 0.2
        aMax = np.max(aLocalPositions, axis=0)
        aMin = np.min(aLocalPositions, axis=0)
        aLengths = np.array([aMin[0], aMax[1], aMax[0], aMin[1]], dtype='float64')
        aLengths += np.array([-1, 1, 1, -1], dtype='float64') * fOffset
        cmds.move(aLengths[0], aLengths[1], 0, '%s.cv[0]' % self.cLookAt.sCtrl, a=True, ls=True)
        cmds.move(aLengths[2], aLengths[1], 0, '%s.cv[1]' % self.cLookAt.sCtrl, a=True, ls=True)
        cmds.move(aLengths[2], aLengths[3], 0, '%s.cv[2]' % self.cLookAt.sCtrl, a=True, ls=True)
        cmds.move(aLengths[0], aLengths[3], 0, '%s.cv[3]' % self.cLookAt.sCtrl, a=True, ls=True)
        cmds.move(aLengths[0], aLengths[1], 0, '%s.cv[4]' % self.cLookAt.sCtrl, a=True, ls=True)

        self.tEyes = tEyes


    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        cCtrl = blueprints.createCtrl(self.dBlueprints['main'],
                                      sSide=self.sSide,
                                      xCtrl='%sMain' % self.sName,
                                      sParent=self.sBpTopGrp)
        cCtrls = [cCtrl]
        self.cBpRoots = cCtrls
        self.cBpAll = cCtrls




    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        tEyes = []
        for i in range(100):
            sAttr = '%s.eyes%d' % (self.sCurrentFeatureGrp, i)
            if not cmds.objExists(sAttr):
                break
            sObj = cmds.listConnections(sAttr)[0]
            sEyeLimb = cmds.getAttr('%s.sLimbName' % sObj)
            tEyes.append(dCreatedLimbs[sEyeLimb])

        self.connectEyes(tEyes)

