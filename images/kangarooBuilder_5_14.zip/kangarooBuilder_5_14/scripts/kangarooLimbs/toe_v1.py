###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
from collections import OrderedDict

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms

import kangarooTools.blueprints as blueprints
import kangarooTabTools.segments as segments

import kangarooLimbs.baseLimb as baseLimb

class LToe(baseLimb._LBaseLimb):

    def __init__(self, sName='index', sSide='l', iBoneCount=4,
                 bForceParentSkeletonToRoot=False,
                 fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0),
                 fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0)):
        self._sBlueprintNames = ['meta','base','mid','tip','end']
        
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset)
        self.dOutputs.clear()
        for i in range(iBoneCount):
            self.dOutputs[self._sBlueprintNames[i]] = None
        self.dOutputs['END'] = None
        self.iBoneCount = min(iBoneCount, len(self._sBlueprintNames)-1)

        self.sArmConnectionScaleTransforms = []

        self.sArmConnectWristTransforms = []
        self.sArmConnectBaseTransforms = []
        self.sArmConnectFingersTransforms = []
        self.sArmConnectFingersMidTransforms = []
        self.sDefaultFeatures = ['feature_default']


    def createOrSetBlueprints(self, lParent=None):

        bToeLayout = False
        if type(lParent).__name__ == 'LDogArmLeg':
            bToeLayout = True
        if type(lParent).__name__ == 'LArmLeg' and lParent.bIsLeg:
            bToeLayout = True

        if bToeLayout:
            sNewJoints =  self._fillBlueprints([[(3.5,-0.6,2.9, 0,1,0), (3.5,-1.1,4.1, 0,1,0), (3.5,-1.1,4.6, 0,1,0),
                                   (3.5,-1.1,5.1, 0,1,0), (3.5,-1.1,5.6, 0,1,0)][:self.iBoneCount+1]],
                                    [self._sBlueprintNames[:self.iBoneCount+1]], fJointRadius=0.25)
        else:
            sNewJoints = self._fillBlueprints([[(0.5,0,0.5, 0,1,0), (2.0,0,0.5, 0,1,0), (2.5,0,0.5, 0,1,0),
                                   (3.0,0,0.5, 0,1,0), (3.5,0,0.5, 0,1,0)][:self.iBoneCount+1]],
                                    [self._sBlueprintNames[:self.iBoneCount+1]], fJointRadius=0.25)
        return sNewJoints



    def feature_simpleFk(self, bBreak=False):

        sBlueprints = [self.dBlueprints[sN] for sN in self._sBlueprintNames[:self.iBoneCount+1]]
        sJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)
        
        cCtrls = []
        sPrev = 'ctrls'
        cPrev = None
        for j, sJ in enumerate(sJoints[:-1]):
            sLockHide = ['t','s','v']
            if j >= 2 and not bBreak: sLockHide += ['ry','rz']
            
            cC = self._createCtrl(sName=self._sBlueprintNames[j], sMatch=sJ, iOffsetCount=0,
                                sLockHide=sLockHide, fSize=2.0, sShape='circleY',
                                sParent=sPrev, iColorIndex=1)
            cC.appendOffsetGroup('poses')
            cC.adjustAxisOrientation([0,90,-90])

            cCtrls.append(cC)
            sPrev = cC.sOut

            xforms.matrixParentConstraint(cC.sOut, sJ, skipScale=['x','y','z'])

            if cPrev != None:
                cmds.controller(cC.sCtrl, cPrev.sCtrl, parent=True)
            cPrev = cC

        cMeta, cBase = cCtrls[0:2]
        self._cFks = cCtrls[2:]
        self.sArmConnectWristTransforms.append(cMeta.sPasser)
        self.sArmConnectionScaleTransforms += [cMeta.sPasser, self.sCurrentFeatureGrp]

        return sJoints, cCtrls, {}



    def feature_default(self, iFkIk=0, iIkIndex=2, _dComboboxItems={'iFkIk':['fk', 'ik']}):#, 'fk/ik switch']}):
        print('feature finger: ', self.sLimbName)
        sBlueprints = [self.dBlueprints[sN] for sN in self._sBlueprintNames[:self.iBoneCount + 1]]
        sJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='tipIkPre', sParent=self.sCurrentFeatureGrp)

        if iFkIk == 2:
            sIkJoints = xforms.duplicateJoinChain(sBlueprints[1:], sPostfix='tipFkIk', sParent=self.sCurrentFeatureGrp)


        cmds.makeIdentity(sJoints, apply=True, r=True)
        sMetaStartTransform = self._createTransform('metaStart', sMatch=sJoints[0])

        cmds.pointConstraint(sMetaStartTransform, sJoints[0])
        cMetaIk = self._createCtrl3(sName='baseIk', sMatch=sBlueprints[0], fMatchPos=sBlueprints[1], sShape='locator', iColorIndex=1, fSize=2.0,
                                   sAttachScaleTo=sMetaStartTransform, sAttrs=['rx'])#sLockHide=['ry','rz','ro','s','v'])
        cMetaIk.appendOffsetGroup('poses')

        sSliderMeta = cMetaIk.appendOffsetGroup('slider')
        if self.sSide == 'r':
            cmds.setAttr('%s.s' % sSliderMeta, -1,-1,-1)

        fPrevOrient, fPrevJointOrient = cmds.getAttr('%s.rz' % sJoints[2]), cmds.getAttr('%s.joz' % sJoints[2])
        cmds.setAttr('%s.joz' % sJoints[2], fPrevJointOrient-10)
        cmds.setAttr('%s.rz' % sJoints[2], fPrevOrient+10)

        self.cFkCtrls = []
        if iFkIk in [0,2]: # do fk
            sPrev = 'ctrls'
            cPrev = None
            for j, sJ in enumerate(sJoints[:-1]):
                if j == 0:
                    continue

                cC = self._createCtrl3(sName=self._sBlueprintNames[j], sMatch=sJ,
                                      sAttrs=['t','r'], fSize=2.0, sShape='circleY',
                                      sParent=sPrev, iColorIndex=1)
                cC.adjustAxisOrientation([0, 90, -90])

                if j == 1:
                    sFirstFkOffset2 = cC.appendOffsetGroup('parentToFinger')

                if j >= 1:
                    cC.appendOffsetGroup('inversekinematic')
                cC.appendOffsetGroup('poses')


                self.cFkCtrls.append(cC)
                sPrev = cC.sOut

                if cPrev != None:
                    cmds.controller(cC.sCtrl, cPrev.sCtrl, parent=True)
                else:
                    cmds.controller(cC.sCtrl, cMetaIk.sCtrl, parent=True)

                cPrev = cC

            xforms.matrixParentConstraint(cMetaIk.sOut, self.cFkCtrls[0].sPasser, skipScale=['x','y','z'], mo=True)


        for c, cC in enumerate(self.cFkCtrls):
            if c == 0:
                cmds.pointConstraint(self.cFkCtrls[c].sOut, sJoints[c+1])
                cmds.aimConstraint(self.cFkCtrls[c+1].sOut, sJoints[c+1], aim=[self.fSideMultipl,0,0], wut='objectrotation', wuo=cC.sOut)
            else:
                xforms.matrixParentConstraint(cC.sOut, sJoints[c+1], skipScale=['x', 'y', 'z'])



        cmds.aimConstraint(cMetaIk.sOut, sJoints[0], wut='objectrotation', aim=[self.fSideMultipl,0,0], u=[0,self.fSideMultipl,0], wuo=cMetaIk.sOut)
        # cmds.aimConstraint(cMetaIk.sOut, sJoints[0], wut='objectrotation', aim=[self.fSideMultipl,0,0], u=[0,self.fSideMultipl,0], wuo=sMetaStartTransform)

        cIkCtrls = []
        if iFkIk == 1: # do ik
            cTipIk = self._createCtrl3(sName='tipIk', sMatch=sBlueprints[iIkIndex], sShape='locator', iColorIndex=1, fSize=2.0,
                                      sAttachScaleTo=sMetaStartTransform)
            cTipIk.appendOffsetGroup('poses')

            sPointerJoints = sJoints if iFkIk == 1 else sIkJoints
            sPoleParent = self._createTransform('poleParent', sParent=cTipIk.sOut)
            cmds.aimConstraint(cMetaIk.sOut, sPoleParent, wut='objectrotation', wuo=cTipIk.sOut, wu=[0,0,1])

            sPole = self._createTransform('pole', sParent=sPoleParent, fLocalPos=[0,0,1])
            sIkHandle = xforms.createIk(sPointerJoints[1], sPointerJoints[iIkIndex], sPole, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('ikTip','ik'))

            cmds.pointConstraint(cTipIk.sOut, sIkHandle)
            sTipAim = self._createTransform('tipAim', sParent=cTipIk.sOut, sMatch=sBlueprints[-1])
            cmds.aimConstraint(sTipAim, sPointerJoints[-2], wut='objectrotation', aim=[self.fSideMultipl,0,0], u=[0,self.fSideMultipl,0], wuo=cTipIk.sOut)
            sDistance = nodes.createDistanceNode(sMetaStartTransform, nodes.getWorldPoint(cMetaIk.sOut), sDivide='%s.sx' % sMetaStartTransform)

            if self.sSide == 'l':
                cmds.connectAttr(sDistance, '%s.tx' % sPointerJoints[1])
            else:
                nodes.createMultiplyNode(sDistance, -1, sTarget='%s.tx' % sPointerJoints[1])

            cIkCtrls.append(cTipIk)

        self.sArmConnectWristTransforms += [sMetaStartTransform]
        self.sArmConnectionScaleTransforms += [sMetaStartTransform, self.sCurrentFeatureGrp]

        if iFkIk in [0,2]:
            self.sArmConnectionScaleTransforms.append(self.cFkCtrls[0].sPasser)

        self.sArmConnectBaseTransforms += [cMetaIk.sPasser]

        if iFkIk == 1:
            self.sArmConnectFingersMidTransforms += [cTipIk.sPasser]
        else:
            self.sArmConnectFingersMidTransforms += [sFirstFkOffset2]#, bAboveCtrl=True)]

        cCtrls = [cMetaIk] + self.cFkCtrls + cIkCtrls


        return sJoints, cCtrls, {}



    def effectsOutputs_blends(self, **kwargs):
        dBlendOutputs = OrderedDict()
        
        for sOutput in list(self.dOutputs.keys()):
            dBlendOutputs['%sBlend' % sOutput] = None
    
        return dBlendOutputs


    def effects_blends(self, _sAttachers=[]):

        sOrients = []
        for sName, sJoint in list(self.dOutputs.items()):
            sOrient = cmds.createNode('joint', name=self._createNodeName('%sBlend' % sName,'jnt'), p=sJoint)
            cmds.setAttr('%s.t' % sOrient, 0,0,0)
            sOrients.append(sOrient)
            cmds.setAttr('%s.radius' % sOrient, cmds.getAttr('%s.radius' % sJoint) * 1.5)
            nodes.createVectorMultiplyNode('%s.r' % sJoint, (-0.5,-0.5,-0.5), sTarget = '%s.r' % sOrient, sName=self._createNodeName('%sHalf' % sName))
            self.dOutputs['%sBlend' % sName] = sOrient
            
            segments.updateTagAttr(sOrient, {'bDisable':True})

        dAttacherBuildData = {}
        return sOrients, None, dAttacherBuildData


    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        sBlueprints = [self.dBlueprints[sN] for sN in self._sBlueprintNames[:self.iBoneCount+1]]

        cMetaCtrls = blueprints.createChainCtrls(sBlueprints[:2], sSide=self.sSide, xRoot='%sMeta' % self.sName, xAim='%sBase' % self.sName,
                                                 xPole='%sPoleMeta' % self.sName, iColorIndexOffset=1,
                                                sParent=self.sBpTopGrp, fUpVector=[0,1,0])

        cBaseCtrls = blueprints.createChainCtrls(sBlueprints[1:], sSide=self.sSide, xRoot=cMetaCtrls[-1], xAim='%sEnd' % self.sName, xPole='%sPole' % self.sName,
                                                xElbows=['%sMid' % self.sName, '%sTip' % self.sName], sParent=self.sBpTopGrp, fUpVector=[0,2.5,0], iColorIndexOffset=1)

        self.cBpRoots = [cMetaCtrls[0], cBaseCtrls[0], cBaseCtrls[-1]]
        self.cBpAll = list(set(cMetaCtrls + cBaseCtrls))

        self._cBpMetaPole = cMetaCtrls[-1]
        self._cBpBasePole = cBaseCtrls[-1]



    def generateOutputs_postScale(self, **kwargs):
        return {}, []



    def detail_postScale(self, bMetaScale=False):
        if bMetaScale:
            sMeta = self.dOutputs['meta']
            sMetaScale = xforms.createJoint(sName='jnt_%sMetaScale' % self.sLimbName,
                                            sParent=sMeta,
                                            fSize=cmds.getAttr('%s.radius' % sMeta) * 1.5)
            sMetaTxAttr = '%s.tx' % self.dOutputs['base']
            nodes.createMultiplyNode(sMetaTxAttr, 1.0 / cmds.getAttr(sMetaTxAttr), sTarget='%s.sx' % sMetaScale)
            self.dOutputs['meta'] = sMetaScale

            utils.addStringAttr(sMetaScale, 'skinParent', sMeta, bLock=True)

            segments.updateTagAttr(sMetaScale, {'bDisable':True})
            segments.updateTagAttr(sMeta, {'sSearchReplace':'Meta;MetaScale'})
        return [], {}

