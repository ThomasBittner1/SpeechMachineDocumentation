###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np

import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.nodes as nodes
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils


class LEye(baseLimb._LBaseLimb):
    def __init__(self, sName='eye', sSide='m',
                fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0), fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0),
                iSegmentsPriority=-1):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide, fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset)

        self.dOutputs['transform'] = None
        self.dOutputs['main'] = None
        self.dOutputs['end'] = None

        # self.bSegmentPlanes = bSegmentPlanes
        self.iSegmentsPriority = iSegmentsPriority

        self.sDefaultFeatures = ['feature_fk']



    def getDefaultParentOutput(self):
        return 'main'


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':False},
                'scale': {'sTrs':'s', 'bMulti':False}}


    def generateAttachers_fk(self, **kwargs):
        return {}


    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(0,0,0, 0,0,-1), (0,1,0, 0,0,-1)]], [['main', 'end']])
        self.sBlueprintJoints = [self.dBlueprints[sN] for sN in ['main', 'end']]
        return sNewJoints


    def feature_fk(self, fScaleCtrlShape=(1.0, 1.0, 1.0), iColorIndex=2, iRotateOrder=2):


        dAttacherBuildData = {}


        fLength = xforms.distanceBetween(self.dBlueprints['main'], self.dBlueprints['end'])
        sFks = xforms.duplicateJoinChain(self.sBlueprintJoints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)

        sTransformJoint = cmds.duplicate(sFks[0], n=sFks[0].replace('_main_','_transform_'), po=True)[0]
        cmds.parent(sFks[0], sTransformJoint)
        self.cTransform = self._createCtrl3(sName='transform', sMatch=self.dBlueprints['main'], sAttrs=['t','r','s'], iSlider=2,
                                      iColorIndex=iColorIndex, sShape='locator', fSize=fLength*2, fScaleShape=fScaleCtrlShape, iRotateOrder=iRotateOrder)
        self.cTransform.adjustAxisOrientation([0,90,0], bAdjustSliderInsteadOfPasser=True)

        self.cCtrl = self._createCtrl3(sName='', sMatch=self.dBlueprints['main'], sAttrs=['r'], iSlider=2, sParent=self.cTransform.sOut,
                                      iColorIndex=iColorIndex, sShape='cube', fSize=fLength*0.25, fScaleShape=fScaleCtrlShape, iRotateOrder=iRotateOrder)


        xforms.matrixParentConstraint(self.cCtrl.sOut, sFks[0], skipScale=[])
        xforms.matrixParentConstraint(self.cTransform.sOut, sTransformJoint, skipScale=[])

        dAttacherBuildData['root'] = (utils.getDagPath(self.cTransform.sPasser), self.cCtrl)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.cTransform.sPasser), self.cCtrl)

        return [sTransformJoint]+sFks, [self.cCtrl], dAttacherBuildData


    def unreal_feature_fk(self):
        if self.sLimbName == 'm_global':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal

            sCommands = []
            sCommands.append("# (eye limb)")
            sCommands.append("controllers.openCommentBox()")

            sCtrl, sCommand = utilsUnreal.createUnrealCtrl(self.cCtrl)
            sCommands.append(sCommand)
            sJoint = self.getOutputFullNames()[1]

            sCommands.append(utilsUnreal.ENTRYKEY(self.sLimbName))

            sCommands.append("nodes.createParentConstraintExecuteNode([%s.eControl], unreal.RigElementKey('%s', 'Bone'), bMaintainOffset=True)" % (sCtrl, sJoint))
            # sCommands.append(['ATTACH', sCtrl, '%s.root' % self.sLimbName])

            sCommands.append("controllers.closeCommentBox('%s (Eye)', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

            return sCommands, [], []



    def buildBlueprintRig(self, lParent=None):
        # reload(blueprints)
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        # if self.sLimbName == 'r_eye':
        #     print 'self.dMirrorOrients: ', self.dMirrorOrients
        #     print "self.dBlueprints['main']", self.dBlueprints['main']

        cCtrls = blueprints.createChainCtrls([self.dBlueprints['main'], self.dBlueprints['end']],
                                                sSide=self.sSide,
                                                dMirrorOrients=self.dMirrorOrients,
                                                xRoot='%sMain' % self.sName,
                                                xAim='%sMainEnd' % self.sName,
                                                xPole='%sPole' % self.sName,
                                                sParent=self.sBpTopGrp)

        self.cBpRoots = [cCtrls[0]]
        # del self.cBpRoots[-2]
        self.cBpAll = cCtrls


        self.dBpOutputs['main'] = cCtrls[0]
        self.dBpOutputs['end'] = cCtrls[1]

        self.cBpSymmetry = cCtrls
        self.cLastBp = cCtrls[1]



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        # if not self.bSegmentPlanes:
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'bDisable':True})
        # else:
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'iPriority':self.iSegmentsPriority})
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'bIsRoot':self.bSegmentsRoot})



