###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import math

import maya.cmds as cmds
import numpy as np
from collections import OrderedDict, defaultdict
import itertools

import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.blueprints as blueprints
import kangarooTools.curves as curves
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.constraints as constraints

import kangarooTabTools.segments as segments
import kangarooTabTools.weights as weights
import kangarooTools.utilFunctions as utils

dLegCtrlNames = {'elbow': 'knee', 'wrist': 'ankle', 'fingers': 'toes', 'finger': 'toe', 'hand': 'foot'}


class LArmLeg(baseLimb._LBaseLimb):
    
    def __init__(self, sName='arm', sSide='l', bAutoClavicle=False, bIsLeg=False,
                 bRemoveEndSkinJoint=False, bForceParentSkeletonToRoot=False,
                 iWristScale=1, iShoesCount=0,
                 fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0), iFeatureCtrlType=1,
                 fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0), iSegmentsPriority=0, sCustomFeatureCtrlName='',
                _dComboboxItems={'iWristScale':['no scale', 'uniform', 'length (bad for fingers)'], 'iFeatureCtrlType':['shape on all ctrls', 'new global ctrl', 'custom ctrl']}):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bRemoveEndSkinJoint=bRemoveEndSkinJoint, bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset, iSegmentsPriority=iSegmentsPriority,
                                     iFeatureCtrlType=iFeatureCtrlType, sCustomFeatureCtrlName=sCustomFeatureCtrlName)
        self.bAutoClavicle = bAutoClavicle
        self.dOutputs['upper'] = None
        self.dOutputs['elbow'] = None
        self.dOutputs['wrist'] = None
        self.dOutputs['fingers'] = None
        self.dOutputs['end'] = None

        self.iWristScale = iWristScale

        self.dCtrlNames = dLegCtrlNames if bIsLeg else {sK:sK for sK,_ in list(dLegCtrlNames.items())}
        self.bIsLeg = bIsLeg
        self.tClavicle = None
        self.iShoesCount = iShoesCount

        self.cLastBp = None

        self.sDefaultFeatures = ['feature_fk', 'feature_ik']

        self.sClavAimTransformPerFeature = []
        self.mAttachToClavicleTransformsOnAuto = []

        if self.iFeatureCtrlType == 1:
            self.dFeatureCtrlParent = {'sOutputKey':'wrist', 'sBlueprintKey':'wrist'}

        self.bDoControlRigFunction = False



    def guessBlueprintFromOutput(self, sOutputKey, iBlueprintCount=None):
        if sOutputKey.startswith('upper'):
            return 'up'
        elif sOutputKey.startswith('elbow'):
            return 'elbow'
        elif sOutputKey == 'wrist':
            return 'wrist'
        elif sOutputKey == 'fingers':
            return 'fingers'
        elif sOutputKey == 'end':
            return 'fingersEnd'


    def getDefaultParentOutput(self):
        return 'wrist'


    def generateAttachers_init(self):
        dAttachers = {}
        if self.bAutoClavicle:
            dAttachers['root_noClav'] = {'sTrs': 'tr', 'bMulti': False}
        else:
            dAttachers['root'] = {'sTrs': 'tr', 'bMulti': False}

        dAttachers['scale'] = {'sTrs': 's', 'bMulti': False}

        return dAttachers


    def createOrSetBlueprints(self, lParent=None):
        sBlueprintNames = [['up', 'elbow', 'wrist', 'fingers', 'fingersEnd']]
        sBlueprintNames.append(['print',[['toesPivot'],['heelPivot'],['outPivotA'],['outPivotB'],['inPivotA'],['inPivotB']]])
        for f in range(self.iShoesCount):
            sLetter = utils.getLetter(f)
            sBlueprintNames.append(['print%s' % sLetter, [['toesPivot%s' % sLetter], ['heelPivot%s' % sLetter], ['outPivotA%s' % sLetter], ['outPivotB%s' % sLetter], ['inPivotA%s' % sLetter], ['inPivotB%s' % sLetter]]])

        if self.bIsLeg:
            ffPositions = [[(3,0,1.8,0,0,-1), (3,-5.6,4.2,0,0,-1), (3,-11.7,2.6,0,0,-1), (3,-13.2,4.16,0,-0.5,-1), (3,-14.3,6,0,-0.5,-1)]]
            ffPositions.append([(3, -15, 3, 0,1,0, 'yz', 'zy'),[[(3,-15,7)],[(3,-15,2)],[(4.1,-15,4.0)],[(4.1,-15,5.4)],[(1.5,-15,4.0)],[(1.5,-15,5.4)]]])
            for f in range(self.iShoesCount):
                fOffsetY = (f+1) * (-1.5)
                ffPositions.append([(3, -15+fOffsetY, 3, 0, 1, 0, 'yz', 'zy'), [[(3, -15+fOffsetY, 7)], [(3, -15+fOffsetY, 2)], [(4.1, -15+fOffsetY, 4.0)],
                                                                                [(4.1, -15+fOffsetY, 5.4)], [(1.5, -15+fOffsetY, 4.0)], [(1.5, -15+fOffsetY, 5.4)]]])

            sNewJoints = self._fillBlueprints(ffPositions, sBlueprintNames, sRefMainKey='wrist')
        else:
            ffPositions = [[(0,0,0,0,0,1), (14,0,-0.15, 0,0,1), (22,0,1.5, 0,0,1), (24,0,1.8, 0,0,1), (26,0,1.8, 0,0,1)]]
            ffPositions.append([(22,-1,1.5, 0,1,0, 'yz', 'zy'), [[(27.0,-1,1.9)], [(20,-1,1.5)], [(21,-1,0.4)], [(24.0,-1,0.4)], [(21,-1,3)], [(24.0,-1,3)]]])
            sNewJoints = self._fillBlueprints(ffPositions, sBlueprintNames, sRefMainKey='wrist')

        [cmds.setAttr('%s.radius' % sJ, 0.1) for sJ in sNewJoints if 'Pivot' in sJ or 'print' in sJ]

        self.fStartLengthA = cmds.getAttr('%s.tx' % self.dBlueprints['elbow']) * self.fSideMultipl
        self.fStartLengthB = cmds.getAttr('%s.tx' % self.dBlueprints['wrist']) * self.fSideMultipl

        return sNewJoints


    def generateAttachers_fk(self, **kwargs):
        if self.bAutoClavicle:
            dDict = {'upper_noClav': {'sTrs':'r', 'bMulti':True},
                    'wrist_noClav': {'sTrs':'r', 'bMulti':True, 'sLocals':['local']}}
            dDict['elbow_noClav'] = {'sTrs':'tr', 'bMulti':True, 'sLocals':['local']}
        else:
            dDict = {'upper': {'sTrs':'r', 'bMulti':True},
                    'wrist': {'sTrs':'r', 'bMulti':True, 'sLocals':['local']}}
            dDict['elbow'] = {'sTrs':'tr', 'bMulti':True, 'sLocals':['local']}

        return dDict


    def feature_fk(self, bLockBreak=False, bSuperCtrls=False, bChildCtrls=True, bFingerCtrl=True, bOrientWristToWorldMatrix=False):

        sBlueprints = [self.dBlueprints[sN] for sN in ['up', 'elbow', 'wrist', 'fingers', 'fingersEnd']]
        sFkJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='fk', sParent=self.sCurrentFeatureGrp, bFreezeOrients=True)

        sUpperAttrs = ['r', 'ro', 'sy']
        cUpper = self._createCtrl3(sName='upper', sMatch=self.dBlueprints['up'], sAttrs=sUpperAttrs, iRotateOrder='yzx' if self.bIsLeg else 'yxz',
                                  fSize=cmds.getAttr('%s.radius' % sBlueprints[0])*5, sShape='wedge', bSuper=bSuperCtrls, bChild=bChildCtrls)
        cUpper.adjustAxisOrientation([0,90,-90])
        sUpperNoScale = self._createTransform('upperNoScale', sParent=cUpper.sOut)
        nodes.createMultiplyNode(1, '%s.sy' % cUpper.sCtrl, sOperation='divide', sTarget='%s.sx' % sUpperNoScale)


        dAttacherBuildData = {}
        dAttacherBuildData['root'] = (utils.getDagPath(cUpper.sPasser), None)
        # dAttacherBuildData['root_clav'] = (utils.getDagPath(cUpper.sPasser), None)
        self.mAttachToClavicleTransformsOnAuto.append(utils.getDagPath(cUpper.sPasser))
        sAttacherOffset = cUpper.appendOffsetGroup('attacher', iRotateOrder=0)
        dAttacherBuildData['upper'] = (utils.getDagPath(sAttacherOffset), cUpper)
        dAttacherBuildData['upper_noClav'] = (utils.getDagPath(sAttacherOffset), cUpper)

        sElbowAttrs = ['t','rx', 'ro']
        if not bLockBreak:
            sElbowAttrs += ['ry','rz', 'sy']

        cElbow = self._createCtrl3(sName=self.dCtrlNames['elbow'], sMatch=self.dBlueprints['elbow'],
                                  sAttrs=sElbowAttrs, fSize=cmds.getAttr('%s.radius' % sBlueprints[1])*5, sShape='wedge', iRotateOrder='zyx' if self.bIsLeg else 'yzx',
                                  bSuper=bSuperCtrls, bChild=bChildCtrls)
        sElbowNoScale = self._createTransform('elbowNoScale', sParent=cElbow.sOut)
        nodes.createMultiplyNode(1, '%s.sy' % cElbow.sCtrl, sOperation='divide', sTarget='%s.sx' % sElbowNoScale)

        sElbowAttach = cElbow.appendOffsetGroup('attach')
        cElbow.adjustAxisOrientation([0,90,-90])


        sElbowPreAttach = self._createTransform('elbowPreAttach', sParent=cElbow.sSlider, sMatch=sElbowAttach)
        xforms.matrixParentConstraint(cUpper.sOut, sElbowPreAttach, skipRotate=['x','y','z'], skipScale=['x','y','z'], mo=True)
        xforms.matrixParentConstraint(sUpperNoScale, sElbowPreAttach, skipTranslate=['x','y','z'], skipScale=['x','y','z'], mo=True)


        dAttacherBuildData['elbow'] = (utils.getDagPath(sElbowAttach), cElbow)
        dAttacherBuildData['elbow_noClav'] = (utils.getDagPath(sElbowAttach), cElbow)
        self.dLocalAttacherOutputs['elbow'] = ['local.%s' % sElbowPreAttach]
        self.dLocalAttacherOutputs['elbow_noClav'] = ['local.%s' % sElbowPreAttach]

        xforms.matrixParentConstraint(sUpperNoScale, cElbow.sPasser, mo=True, skipScale=['x','y','z'])

        sWristAttrs = ['t','r','ro']
        if self.iWristScale:
            sWristAttrs.append('scaleUF')
        cWrist = self._createCtrl3(sName=self.dCtrlNames['wrist'], sMatch=self.dBlueprints['wrist'],
                                  sAttrs=sWristAttrs, fSize=cmds.getAttr('%s.radius' % sBlueprints[2])*5, sShape='wedge', iRotateOrder='xyz' if self.bIsLeg else 'xzy',
                                  bSuper=bSuperCtrls, bChild=bChildCtrls)
        cWrist.adjustAxisOrientation([0,90,-90])

        if bOrientWristToWorldMatrix:
            cWrist.orientToNearestStraightMatrix()

        xforms.matrixParentConstraint(cElbow.sOut, cWrist.sPasser, mo=True, skipRotate=['x','y','z'], skipScale=['x','y','z'])

        if bFingerCtrl:
            cFinger = self._createCtrl3(sName='%sFK' % self.dCtrlNames['fingers'], sMatch=self.dBlueprints['fingers'],
                                      sAttrs = ['r','ro'], fSize=cmds.getAttr('%s.radius' % sBlueprints[3])*5, sShape='wedge',
                                      bSuper=bSuperCtrls, bChild=bChildCtrls)
            cFinger.adjustAxisOrientation([0,90,-90])

            xforms.matrixParentConstraint(cWrist.sOut, cFinger.sPasser, mo=True) #, skipScale=['x','y','z'])
            xforms.matrixParentConstraint(cFinger.sOut, sFkJoints[3]) #, skipTranslate=['x','y','z']) #, skipScale=['x','y','z'])
            cmds.controller(cFinger.sCtrl, cWrist.sCtrl, parent=True)


        sWristAttacher = cWrist.appendOffsetGroup('attacher')
        dAttacherBuildData['wrist_noClav'] = (utils.getDagPath(sWristAttacher), cWrist)
        self.dLocalAttacherOutputs['wrist_noClav'] = ['local.%s' % sElbowNoScale]
        dAttacherBuildData['wrist'] = (utils.getDagPath(sWristAttacher), cWrist)
        self.dLocalAttacherOutputs['wrist'] = ['local.%s' % sElbowNoScale]

        xforms.matrixParentConstraint(sUpperNoScale, sFkJoints[0], skipRotate=['x','y','z'], skipScale=['x','y','z'])
        constraints.aimConstraintFromTransforms(sFkJoints[0], cElbow.sOut, sUpperNoScale, aim=[self.fSideMultipl,0,0], bOrientUp=True, sParent=self.sCurrentFeatureGrp)

        xforms.matrixParentConstraint(cElbow.sOut, sFkJoints[1], skipScale=True)
        xforms.matrixParentConstraint(cWrist.sOut, sFkJoints[2], skipTranslate=True) # skipTranslate=['x','y','z']) #, skipScale=['x','y','z'])
        cmds.pointConstraint(cWrist.sOut, sFkJoints[2])

        if self.bAutoClavicle:
            sAcParent = self._createTransform('autoClavParent', sMatch=self.dBlueprints['up'])
            sAc = self._createTransform('autoClav', sParent=sAcParent, sMatch=self.dBlueprints['up'])
            cmds.rotate(0,90,-90, sAcParent, r=True, os=True)
            sAcOut = self._createTransform('autoClavOut', sParent=sAc, sMatch=self.dBlueprints['elbow'])
            cmds.connectAttr('%s.r' % cUpper.sCtrl, '%s.r' % sAc)
            dAttacherBuildData['root_noClav'] = (utils.getDagPath(sAcParent), None)
            self.sClavAimTransformPerFeature.append(sAcOut)


            # we'll need to get this back in case we remove the elbow ik
            # nodes.fromEquation('%s.sy * %s' % (cUpper.sCtrl, cmds.getAttr('%s.tx' % sFkJoints[1])),
            #                    sTarget='%s.tx' % sFkJoints[1], sName=self._createNodeName('upperScale'))
            # nodes.fromEquation('%s.sy * %s' % (cElbow.sCtrl, cmds.getAttr('%s.tx' % sFkJoints[2])),
            #                    sTarget='%s.tx' % sFkJoints[2], sName=self._createNodeName('lowerScale'))

        if self.iWristScale == 2:
            cWrist.unlockAttrs(['sy'])



        cCtrls = [cUpper, cElbow, cWrist]

        if bFingerCtrl:
            cCtrls.append(cFinger)
        self.cFkCtrls = list(cCtrls)

        cmds.controller(cElbow.sCtrl, cUpper.sCtrl, parent=True)
        cmds.controller(cWrist.sCtrl, cElbow.sCtrl, parent=True)

        #global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        for cC in cCtrls: #[cUpper.sPasser, cElbow.sPasser, cWrist.sPasser]: #, cFinger.sPasser]:
            cmds.scaleConstraint(self.sCurrentFeatureGrp, cC.sPasser)

        # sSkip = "['y','z']" if bLockBreak else "['y']"
        sMatchScript = ''

        sMatchScript += "\nsetAttr(NAMESPACE, '%s.tx', 0)" % cWrist.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.ty', 0)" % cWrist.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.tz', 0)" % cWrist.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.tx', 0)" % cElbow.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.ty', 0)" % cElbow.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.tz', 0)" % cElbow.sCtrl

        if bChildCtrls:
            sChildCtrls =  [cUpper.sChild, cElbow.sChild, cWrist.sChild]
            if bFingerCtrl:
                sChildCtrls.append(cFinger.sChild)
            for sCtrl in sChildCtrls:
                sMatchScript += "\nsetAttr(NAMESPACE, '%s.tx', 0)" % sCtrl
                sMatchScript += "\nsetAttr(NAMESPACE, '%s.ty', 0)" % sCtrl
                sMatchScript += "\nsetAttr(NAMESPACE, '%s.tz', 0)" % sCtrl
                sMatchScript += "\nsetAttr(NAMESPACE, '%s.rx', 0)" % sCtrl
                sMatchScript += "\nsetAttr(NAMESPACE, '%s.ry', 0)" % sCtrl
                sMatchScript += "\nsetAttr(NAMESPACE, '%s.rz', 0)" % sCtrl

        sMatchScript += "\nsetDistance(NAMESPACE, '{0}', '{1}', %f, '%s.sy')" % (1.0/self.fStartLengthA, cUpper.sCtrl)
        sMatchScript += "\nsetDistance(NAMESPACE, '{1}', '{2}', %f, '%s.sy')" % (1.0/self.fStartLengthB, cElbow.sCtrl)

        sMatchScript += match.generateMatchingConstrainCommand2(0, sFkJoints, cUpper.sCtrl, iConstraintType=match.Type.orientConstraint)
        sMatchScript += match.generateMatchingConstrainCommand2(1, sFkJoints, cElbow.sCtrl, iConstraintType=match.Type.orientConstraint)
        sMatchScript += match.generateMatchingConstrainCommand2(2, sFkJoints, cWrist.sCtrl, iConstraintType=match.Type.orientConstraint)
        if bFingerCtrl:
            sMatchScript += match.generateMatchingConstrainCommand2(3, sFkJoints, cFinger.sCtrl, iConstraintType=match.Type.orientConstraint)


        for i in [2,3,4]: # could do all joints, but just to be safe
            cmds.setAttr('%s.segmentScaleCompensate' % sFkJoints[i], False)

        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)
        return sFkJoints, cCtrls, dAttacherBuildData


    def unreal_feature_fk(self):
        import kangarooTools.utilsUnreal as utilsUnreal

        sCommands = []
        sCommands.append("controllers.openCommentBox()")

        cStrControls, sFkCommands = utilsUnreal.createFkChainCtrls(self.cFkCtrls[:None if self.bIsLeg else -1])
        sCommands += sFkCommands

        sJoints = [self.dDetailReplacements.get(sJ,sJ) for sJ in self.getOutputFullNames()]
        xxCtrlBonePairs = "[%s]" % ','.join(["(%s, '%s')" % (sC,sJ) for sC,sJ in zip(cStrControls, sJoints)])

        sReturnExecutesVariable = 'sExecuteNodes_fk_%s' % self.sLimbName

        sCommands.append("%s = functions.createFkChainCtrlsSetup(%s, sComments=None, sSide='%s')" %
                         (sReturnExecutesVariable, xxCtrlBonePairs, self.sSide))
        sCommands.append(['ATTACH', cStrControls[0], '%s.root' % self.sLimbName])
        sCommands.append("controllers.closeCommentBox('%s FK', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

        return sCommands, cStrControls, sReturnExecutesVariable


    def unreal_feature_ik(self):
        import kangarooTools.utilsUnreal as utilsUnreal

        sCommands = []
        sCommands.append("controllers.openCommentBox()")

        cStrIk, sCommand = utilsUnreal.createUnrealCtrl(self.cPrint)
        sCommands.append(sCommand)

        cStrPole, sCommand = utilsUnreal.createUnrealCtrl(self.cPole)
        sCommands.append(sCommand)

        eStrRole, sCommand = utilsUnreal.createUnrealFloatControl('%sRoll' % self.sLimbName, eStrParent='%s.eControl' % cStrIk)
        sCommands.append(sCommand)
        sJoints = [self.dDetailReplacements.get(sJ,sJ) for sJ in self.getOutputFullNames()]
        sJoints = [sJoints[0], sJoints[1], sJoints[2], sJoints[3], sJoints[4]]
        sJointsListString = utilsUnreal.quotaStringList(sJoints, bCommaJoined=True)

        sReturnExecutesVariable = 'sExecuteNodes_ik_%s' % self.sLimbName

        sCommands.append("%s = functions.limbIkSetup(%s.eControl, %s.eControl, %s, [%s], sSide='%s', bIsLeg=%s)" %
                         (sReturnExecutesVariable, cStrIk, cStrPole, eStrRole,
                          sJointsListString, self.sSide, self.bIsLeg))

        sCommands.append("controllers.closeCommentBox('%s IK', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

        return sCommands, [cStrIk, cStrPole], sReturnExecutesVariable


    def unreal_detail_twist(self):
        import kangarooTools.utilsUnreal as utilsUnreal

        print ('dTwistOutputs: ', self.dTwistOutputs)
        sUpper = list(self.dTwistOutputs['upper'].values())
        sLower = list(self.dTwistOutputs['lower'].values())
        sCommands = []

        #lower
        sTwist = self.dOutputs['wrist']
        sCommands.append("controllers.openCommentBox()")

        sCommands.append("functions.twistLower('%s', [%s], sSide='%s')" %
                         (sTwist, utilsUnreal.quotaStringList(sLower[1:], bCommaJoined=True), self.sSide))
        sCommands.append("controllers.closeCommentBox('%s Lower Twist', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

        #upper
        sParent = cmds.listRelatives(sUpper[0], p=True)[0]
        sCommands.append("controllers.openCommentBox()")
        sCommands.append("functions.twistUpper('%s', '%s', '%s', [%s], sSide='%s', bLeg=True)" %
                         (sUpper[0], sParent, sLower[0], utilsUnreal.quotaStringList(sUpper[1:], bCommaJoined=True), self.sSide))
        sCommands.append("controllers.closeCommentBox('%s Upper Twist', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

        return sCommands


    def unreal_childrenConnect_LFinger(self, _lChildren):
        import kangarooTools.utilsUnreal as utilsUnreal

        ssStrCtrls = [None] * len(_lChildren)
        ssJoints = [None] * len(_lChildren)
        sCommands = []
        sCommands.append("controllers.openCommentBox()")

        for l,lChild in enumerate(_lChildren):
            ssStrCtrls[l], sCtrlsCommand = utilsUnreal.createFkChainCtrls([xPair[0] for xPair in lChild.xFkPairs], fSize=0.5, fCtrlOrient=[0,0,0])
            ssJoints[l] = [xPair[1] for xPair in lChild.xFkPairs]
            sCommands += sCtrlsCommand
            sCommands.append("controllers.setNewColumn()")
            sCommands.append("nodes.createParentConstraintExecuteNode([library.getElementKey('%s', 'Bone')], %s.ePasser, bMaintainOffset=True)" %
                             (self.getOutputFullNames()[2], ssStrCtrls[l][0]))
        xxCtrlBonePairs = "[%s]" % ','.join(["(%s, '%s')" % (sC,sJ) for sC,sJ in zip(itertools.chain(*ssStrCtrls), itertools.chain(*ssJoints))])


        sCommands.append("functions.createFkChainCtrlsSetup(%s, sComments=None, sSide='%s')" %
                         (xxCtrlBonePairs, self.sSide))

        sCommands.append("controllers.closeCommentBox('%s Fingers', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

        return sCommands






    def generateAttachers_ik(self, **kwargs):
        # if self.bAutoClavicle:
        if self.bAutoClavicle:
            return {'pole_noClav': {'sTrs': 'tr', 'bMulti': True, 'sLocals':['follow']},
                    'hand_noClav': {'sTrs': 'tr', 'bMulti': True}}
        else:
            return {'pole': {'sTrs': 'tr', 'bMulti': True, 'sLocals':['follow']},
                    'hand': {'sTrs': 'tr', 'bMulti': True}}



    def feature_ik(self, bSoftIk=True, bWorldOrientIkCtrl=False, bPoleFullRotation=False):

        sBlueprints = [self.dBlueprints[sN] for sN in ['up', 'elbow', 'wrist', 'fingers', 'fingersEnd']]

        sIkJoints = xforms.duplicateJoinChain(sBlueprints, sPostfix='ikBef', sParent=self.sCurrentFeatureGrp, bFreezeOrients=True)
        cCtrls = []

        sAttrs = ['t', 'r', 'ro']
        if self.iWristScale:
            sAttrs.append('scaleUF')
        self.cPrint = self._createCtrl3(sName='ik', sMatch=self.dBlueprints['print'], sAttrs=sAttrs, iRotateOrder='zxy',
                                  sShape='squareY', fSize=1.0, fRotateShape=(0,0,90), bSuper=True, bChild=True, bIsJoint=True)
        self.cPrint.tagShapeMirror(sNegate=[False, False, False])

        if bWorldOrientIkCtrl:
            sTemp = cmds.createNode('transform')
            cmds.setAttr('%s.ro' % sTemp, cmds.getAttr('%s.ro' % self.cPrint.sCtrl))
            cmds.delete(cmds.parentConstraint(self.cPrint.sCtrl, sTemp))
            if self.sSide == 'r':
                cmds.setAttr('%s.r' % self.cPrint.sPasser, 180,0,0)
            else:
                cmds.setAttr('%s.r' % self.cPrint.sPasser, 0,0,0)
            cmds.delete(cmds.parentConstraint(sTemp, self.cPrint.sCtrl, skipTranslate=['x','y','z']))
            cmds.makeIdentity(self.cPrint.sCtrl, r=True, apply=True)
            cmds.delete(sTemp)


        sPoleVis = utils.addOffOnAttr(self.cPrint.sCtrl, 'upVIS', bDefaultValue=True)

        fPolePos = xforms.fPoleVectorPos(self.dBlueprints['up'], self.dBlueprints['elbow'], self.dBlueprints['wrist'])
        self.cPole = self._createCtrl3(sName='pole', sAttrs = ['t'], fMatchPos=fPolePos, sShape='locator', iColorIndex=0, bSuper=True,
                                  iSlider=1, fSize=cmds.getAttr('%s.radius' % sBlueprints[1])*5)
        if self.sSide == 'r':
            cmds.setAttr('%s.s' % self.cPole.sSlider, -1,1,1)

        sOutJoints = sIkJoints

        # sOuts = list(sOutJoints)

        sHandTransform = self._createTransform('hand', fMatchPos=cmds.xform(self.dBlueprints['wrist'], q=True, ws=True, t=True))
        sRootAttachTransform = self._createTransform('rootAttach', sMatch=self.dBlueprints['up'])

        cmds.delete(cmds.orientConstraint(self.dBlueprints['heelPivot'], sHandTransform))

        sIkHandle = xforms.createIk(sIkJoints[0], sIkJoints[2], self.cPole.sCtrl, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('ikMain','ik'))
        cmds.pointConstraint(sHandTransform, sIkHandle)

        dAttacherBuildData = {}

        if self.bAutoClavicle:
            cmds.select(cl=True)
            sAcBlueprints = [self.dBlueprints[sN] for sN in ['up', 'elbow', 'wrist']]
            iksAc = xforms.duplicateJoinChain(sAcBlueprints, sPostfix='ikAc', sParent=self.sCurrentFeatureGrp, bFreezeOrients=True)
            sIkHandleAc = xforms.createIk(iksAc[0], iksAc[2], self.cPole.sCtrl, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('autoClav', 'IK'))
            cmds.pointConstraint(sHandTransform, sIkHandleAc)
            sAutoClavicleOut = self._createTransform('outTransformAc')
            cmds.pointConstraint(iksAc[1], sAutoClavicleOut)
            xforms.matrixParentConstraint(sRootAttachTransform, iksAc[0], skipScale=['x','y','z'])
            self.sClavAimTransformPerFeature.append(sAutoClavicleOut)
        cCtrls.append(self.cPole)


        cmds.delete(cmds.pointConstraint(self.dBlueprints['wrist'], self.cPrint.sPasser))
        cmds.delete(cmds.pointConstraint(self.dBlueprints['heelPivot'], self.cPrint.sOut))



        cAnkleRev = self._createCtrl3(sName='%sRev' % self.dCtrlNames['wrist'], sMatch=self.dBlueprints['print'], fMatchPos=self.dBlueprints['fingers'],
                                     sAttrs = ['r','ro'], sShape='arrowCurve', fSize=1.5,
                                     fRotateShape=(0,0,0))
        cmds.setAttr('%s.ro' % cAnkleRev.sCtrl, 1)
        cAnkleRev.convertToSimpleTransforms()


        if self.iShoesCount == 0:
            sShoeIndexAttr = 0
        else:
            sEnums = ':'.join(['%d' % f for f in range(self.iShoesCount+1)])
            sShoeIndexAttr = utils.addAttr(self.cPrint.sCtrl, ln='shoeIndex', at='enum', en=sEnums, k=False, cb=True)



        # heel ctrl
        sParent = self.cPrint.sOut
        cHeel = self._createCtrl3(sName='heel', sMatch=self.dBlueprints['print'], fMatchPos=self.dBlueprints['heelPivot'],
                                    sAttrs=['r','ro'], sShape='arrowCurve', fSize=0.5, iSlider=1, sParent=sParent)
        cmds.setAttr('%s.s' % cHeel.sPasser, 1, 1, 1)
        # cmds.rotate(0,180,0, cHeel.sPasser, os=True, r=True )
        cHeel.convertToSimpleTransforms()

        ffPivotMatrices, ffCompensateMatrices, sTempTransforms = [], [], []

        sLockLengthUpper = nodes.createDistanceNode(nodes.getWorldPoint(sOutJoints[0]), nodes.getWorldPoint(self.cPole.sOut))
        sLockLengthLower = nodes.createDistanceNode(nodes.getWorldPoint(self.cPrint.sCtrl), nodes.getWorldPoint(self.cPole.sOut))
        if self.sSide == 'r':
            sLockLengthUpper = nodes.createMultiplyNode(sLockLengthUpper, -1)
            sLockLengthLower = nodes.createMultiplyNode(sLockLengthLower, -1)

        for f in range(1+self.iShoesCount):
            sLetter = '' if f == 0 else utils.getLetter(f - 1)
            sTempTransforms.append(self._createTransform('shoeTransformHeel_%s' % sLetter, sMatch=self.dBlueprints['print%s' % sLetter],
                                                         fMatchPos=cmds.xform(self.dBlueprints['heelPivot%s' % sLetter], q=True, ws=True, t=True), sParent=sParent))
            ffPivotMatrices.append(cmds.getAttr('%s.matrix' % sTempTransforms[-1]))
            ffCompensateMatrices.append(nodes.createMultMatrixNode([cmds.getAttr('%s.worldMatrix' % sTempTransforms[0]), cmds.getAttr('%s.worldInverseMatrix' % sTempTransforms[-1])], bJustValues=True))

        sChosenPivot = nodes.createChoiceNode(sShoeIndexAttr, ffPivotMatrices, sFullName=self._createNodeName('choosePivotHeel', sType='choice'))
        sChosenCompensate = nodes.createChoiceNode(sShoeIndexAttr, ffCompensateMatrices, sFullName=self._createNodeName('choosePivotCompensateHeel', sType='choice'))
        nodes.createDecomposeMatrix(sChosenPivot, sTargetPos='%s.t' % cHeel.sPasser, sTargetRot='%s.r' % cHeel.sPasser, sFullName=self._createNodeName('choosePivotHeel', sType='decomposeMatrix'))
        nodes.createDecomposeMatrix(sChosenCompensate, sTargetPos='%s.t' % cHeel.sOut, sTargetRot='%s.r' % cHeel.sOut, sFullName=self._createNodeName('choosePivotCompensateHeel', sType='decomposeMatrix'))


        if self.bAutoClavicle:
            dAttacherBuildData['root_noClav'] = (utils.getDagPath(sRootAttachTransform), None)
            self.mAttachToClavicleTransformsOnAuto.append(utils.getDagPath(sIkJoints[0]))
        else:
            dAttacherBuildData['root'] = (utils.getDagPath(sRootAttachTransform), None)
            xforms.matrixParentConstraint(sRootAttachTransform, sIkJoints[0], mo=True, skipRotate=['x','y','z'], skipScale=['x','y','z'])


        dAttacherBuildData['hand'] = (utils.getDagPath(sHandTransform), self.cPrint)
        dAttacherBuildData['hand_noClav'] = (utils.getDagPath(sHandTransform), self.cPrint)

        dAttacherBuildData['pole'] = (utils.getDagPath(self.cPole.sPasser), self.cPole) # should be spine if autoClav
        dAttacherBuildData['pole_noClav'] = (utils.getDagPath(self.cPole.sPasser), self.cPole) # should be spine if autoClav


        cInOuts = []
        for sDir, fDirection in [('out',-1), ('in',1)]:
            aPositions = xforms.getPositionArray([self.dBlueprints['%sPivotA' % sDir], self.dBlueprints['%sPivotB' % sDir]])
            aPos = (aPositions[1]-aPositions[0]) * 0.5
            cInOuts.append(self._createCtrl3(sName=sDir, sMatch=self.dBlueprints['print'], fMatchPos=aPos, bIsNoCtrl=True,
                            sAttrs = ['rx'], sShape='arrowCurve', fSize=0.5, iSlider=1))
            cmds.setAttr('%s.s' % cInOuts[-1].sPasser, 1, 1, 1)

        sParents = [cHeel.sOut, cInOuts[0].sOut]


        for d, sDir, fDirection in [(0, 'out', -1), (1, 'in', 1)]:
            cmds.parent(cInOuts[d].sPasser, sParents[d])
            cmds.setAttr('%s.s' % cInOuts[d].sPasser, 1, 1, 1)


            ffPivotMatrices = []
            ffCompensateMatrices = []
            sTempTransforms = []
            for f in range(1+self.iShoesCount):
                sLetter = '' if f == 0 else utils.getLetter(f-1)

                fPos = np.average(xforms.getPositionArray([self.dBlueprints['%sPivotA%s' % (sDir,sLetter)], self.dBlueprints['%sPivotB%s' % (sDir,sLetter)]]), axis=0)
                sTempTransforms.append(self._createTransform('shoeTransform_%d_%s' % (d,sLetter), fMatchPos=fPos, sParent=sParents[d]))
                aSidePivots = xforms.getPositionArray([self.dBlueprints['%sPivotA%s' % (sDir,sLetter)], self.dBlueprints['%sPivotB%s' % (sDir,sLetter)]])
                aDirection = aSidePivots[1] - aSidePivots[0]
                aPrintMatrix = np.array(cmds.xform(self.dBlueprints['print%s' % sLetter], q=True, ws=True, m=True)).reshape(4,4)
                fUp = aPrintMatrix[1,0:3]
                xforms.orientThreePoints(sTempTransforms[-1], fUp, aDirection, fAimVector=[0,self.fSideMultipl,0], fUpVector=[fDirection*self.fSideMultipl,0,0])
                if self.sSide == 'r':
                    cmds.rotate(0,180,0, sTempTransforms[-1], os=True, r=True)

                ffPivotMatrices.append(cmds.getAttr('%s.matrix' % sTempTransforms[-1]))
                ffCompensateMatrices.append(nodes.createMultMatrixNode([cmds.getAttr('%s.worldMatrix' % sTempTransforms[0]), cmds.getAttr('%s.worldInverseMatrix' % sTempTransforms[-1])], bJustValues=True))

                # print 'ffPivotMatrices: ', ffPivotMatrices


            cmds.delete(sTempTransforms)

            sChosenPivot = nodes.createChoiceNode(sShoeIndexAttr, ffPivotMatrices)
            sChosenCompensate = nodes.createChoiceNode(sShoeIndexAttr, ffCompensateMatrices)

            nodes.createDecomposeMatrix(sChosenPivot, sTargetPos='%s.t' % cInOuts[d].sPasser, sTargetRot='%s.r' % cInOuts[d].sPasser)
            nodes.createDecomposeMatrix(sChosenCompensate, sTargetPos='%s.t' % cInOuts[d].sOut, sTargetRot='%s.r' % cInOuts[d].sOut)



        # toe rev
        sParent = cInOuts[1].sOut
        cToesEnd = self._createCtrl3(sName='%sRev' % self.dCtrlNames['fingers'],
                                    sAttrs=['r','ro'], sShape='arrowCurve', fSize=0.5, iSlider=1, sParent=sParent)
        cToesEnd.convertToSimpleTransforms()
        cmds.setAttr('%s.s' % cToesEnd.sPasser, 1, 1, 1)

        ffPivotMatrices = []
        ffCompensateMatrices = []
        sTempTransforms = []
        for f in range(1+self.iShoesCount):
            sLetter = '' if f == 0 else utils.getLetter(f - 1)
            sTempTransforms.append(self._createTransform('shoeTransform_%d_%s' % (d, sLetter), sMatch=self.dBlueprints['print%s' % sLetter],
                                                         fMatchPos=cmds.xform(self.dBlueprints['toesPivot%s' % sLetter], q=True, ws=True, t=True), sParent=sParent))
            ffPivotMatrices.append(cmds.getAttr('%s.matrix' % sTempTransforms[-1]))
            ffCompensateMatrices.append(nodes.createMultMatrixNode([cmds.getAttr('%s.worldMatrix' % sTempTransforms[0]), cmds.getAttr( '%s.worldInverseMatrix' % sTempTransforms[-1])], bJustValues=True))

        sChosenPivot = nodes.createChoiceNode(sShoeIndexAttr, ffPivotMatrices)
        sChosenCompensate = nodes.createChoiceNode(sShoeIndexAttr, ffCompensateMatrices)
        nodes.createDecomposeMatrix(sChosenPivot, sTargetPos='%s.t' % cToesEnd.sPasser, sTargetRot='%s.r' % cToesEnd.sPasser)
        nodes.createDecomposeMatrix(sChosenCompensate, sTargetPos='%s.t' % cToesEnd.sOut, sTargetRot='%s.r' % cToesEnd.sOut)

        # toes
        cToes = self._createCtrl3(sName='%sExtra' % self.dCtrlNames['fingers'], sMatch=self.dBlueprints['fingers'],
                                 sAttrs=['r','ro'], sShape='wedge', sParent=cToesEnd.sOut)
        cToes.adjustAxisOrientation([0,90,-90])
        cToes.convertToSimpleTransforms()


        cmds.controller(self.cPrint.sCtrl, self.cPole.sCtrl, parent=True)
        cmds.controller(cHeel.sCtrl, self.cPrint.sCtrl, parent=True)

        # create the ctrl shape for self.cPrint
        #
        aPrintMatrix = np.array(cmds.xform(self.dBlueprints['print'], q=True, m=True, ws=True), dtype='float64').reshape(4,4)
        aGrids = xforms.getPositionArray([self.dBlueprints[sK] for sK in ['toesPivot', 'outPivotA', 'heelPivot', 'inPivotA']])
        aGrids4 = np.ones((len(aGrids), 4), dtype='float64')
        aGrids4[:,0:3] = aGrids
        aLocals4 = np.dot(aGrids4, np.linalg.inv(aPrintMatrix))
        aLengths = aLocals4[np.arange(4),np.array([2,0,2,0])]
        aSigns = np.sign(aLengths)
        aSigns[2] = -aSigns[0]
        aLengths += aSigns * (np.max(aLengths) * 0.1)

        aCorners4 = np.ones((4,4), dtype='float64')
        for i, iXY in enumerate([(1,0), (1,2), (3,2), (3,0)]):
            aCorners4[i,0:3] = (aLengths[iXY[0]], 0, aLengths[iXY[1]])



        aCorners4World = np.dot(aCorners4, aPrintMatrix)
        aCorners4Super = np.copy(aCorners4)
        aCorners4Super[:,0:3] *= 1.2
        aCorners4WorldSuper = np.dot(aCorners4Super, aPrintMatrix)
        aCorners4Child = np.copy(aCorners4)
        aCorners4Child[:,0:3] *= 0.8
        aCorners4WorldChild = np.dot(aCorners4Child, aPrintMatrix)
        for iCv in range(5):
            iInd = iCv if iCv < 4 else 0
            cmds.move(aCorners4World[iInd,0], aCorners4World[iInd,1], aCorners4World[iInd,2], '%s.cv[%d]' % (self.cPrint.sCtrl, iCv), a=True, ws=True)
            cmds.move(aCorners4WorldSuper[iInd,0], aCorners4WorldSuper[iInd,1], aCorners4WorldSuper[iInd,2], '%s.cv[%d]' % (self.cPrint.sSuper, iCv), a=True, ws=True)
            cmds.move(aCorners4WorldChild[iInd,0], aCorners4WorldChild[iInd,1], aCorners4WorldChild[iInd,2], '%s.cv[%d]' % (self.cPrint.sChild, iCv), a=True, ws=True)


        # aim setup for foot
        #
        sAnkleAim = self._createTransform('aimAnkle', sParent=cToesEnd.sOut, sMatch=sOutJoints[3])
        xforms.matrixParentConstraint(cAnkleRev.sOut, sAnkleAim, skipTranslate=['x','y','z'], skipScale=['x','y','z'])
        constraints.aimConstraintFromTransforms(sOutJoints[2], sAnkleAim, sAnkleAim, aim=(self.fSideMultipl,0,0), up=[0,0,-1],
                                                     bOrientUp=True, sParent=self.sCurrentFeatureGrp, sName='wristAim', mo=True)
        sToesAim = self._createTransform('aimToes', sParent=cToes.sCtrl, sMatch=sOutJoints[4])
        constraints.aimConstraintFromTransforms(sOutJoints[3], sToesAim, sToesAim, aim=(self.fSideMultipl,0,0), up=[0,self.fSideMultipl,0],
                                                     bOrientUp=True, sParent=self.sCurrentFeatureGrp)

        cmds.parent(cAnkleRev.sPasser, cToesEnd.sOut)
        cmds.parent(sHandTransform, cAnkleRev.sCtrl)

        cCtrls += [self.cPrint]#, cAnkleRev, cToes, cToesEnd]
        dAttacherBuildData['hand'] = (utils.getDagPath(self.cPrint.sPasser), self.cPrint) # should be spine if autoClav
        dAttacherBuildData['hand_noClav'] = (utils.getDagPath(self.cPrint.sPasser), self.cPrint) # should be spine if autoClav


        # pole vector follow
        sPoleFollowTransform = self._createTransform('poleFollow', sMatch=self.dBlueprints['up'], sParent=self.sCurrentFeatureGrp)
        if bPoleFullRotation:
            xforms.matrixParentConstraint(self.cPrint.sCtrl, sPoleFollowTransform, skipScale=['x','y','z'])
        else:
            constraints.aimConstraintFromTransforms(sPoleFollowTransform, self.cPrint.sCtrl, self.cPrint.sCtrl, aim=[self.fSideMultipl,0,0], fOrientAxis=[1,0,0], bOrientUp=True, sParent=self.sCurrentFeatureGrp)
            xforms.matrixParentConstraint(sRootAttachTransform, sPoleFollowTransform, skipRotate=['x','y','z'], skipScale=['x','y','z'])




        self.dLocalAttacherOutputs['pole'] = ['follow.%s' % sPoleFollowTransform]
        self.dLocalAttacherOutputs['pole_noClav'] = ['follow.%s' % sPoleFollowTransform]

        sUpperStretchAttr = utils.addAttr(self.cPrint.sCtrl, ln='upperScale', at='double', defaultValue=1.0, minValue=0.1, maxValue=10.0, k=True)
        sLowerStretchAttr = utils.addAttr(self.cPrint.sCtrl, ln='lowerScale', at='double', defaultValue=1.0, minValue=0.1, maxValue=10.0, k=True)


        sStretchAttr = utils.addAttr(self.cPrint.sCtrl, ln='stretch', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sStretchedDistance = nodes.fromEquation('%s*%f + %s*%f' % (sUpperStretchAttr, self.fStartLengthA, sLowerStretchAttr, self.fStartLengthB),
                                                bDoUnitConversionNodes=True )

        sFullStretchAttr = utils.addAttr(self.cPrint.sCtrl, ln='fullStretch', min=0, max=1, k=True)

        sIkJointGrp = self._createTransform('ikJoint0Transform') # to avoid cycle
        cmds.pointConstraint(sIkJoints[0], sIkJointGrp)
        sDistance = nodes.createDistanceNode('%s.t' % sIkJointGrp, sHandTransform, sName=self._createNodeName('distanceIk'), sDivide='%s.sx' % self.sCurrentFeatureGrp)
        sDistanceNormalized = nodes.fromEquation('%s / %s' % (sDistance, sStretchedDistance))

        if bSoftIk:
            fSoftDefaultValue = (1.0 - cmds.getAttr(sDistance) / (self.fStartLengthA + self.fStartLengthB)) * 10.0
            sSoftAttr = utils.addAttr(self.cPrint.sCtrl, ln='softIk', at='double', defaultValue=fSoftDefaultValue, minValue=0.0, k=True, fMultipl=0.1)
            sSoftAttrSafe = nodes.createConditionNode(sSoftAttr, '==', 0, 1.0, sSoftAttr, sFullName=self._createNodeName('softIkSafe'))
            sSoftAttrRev = nodes.createReverseNode(sSoftAttr, sFullName=self._createNodeName('softStretch'))
            cmds.pointConstraint(sIkJoints[0], sIkHandle)
            sConstr = cmds.pointConstraint(sIkHandle, q=True)
            sExpr = '%s * (1.0 - (%0.8f ^ ((%s - %s) / %s))) + %s' % (sSoftAttr, math.e, sSoftAttrRev, sDistanceNormalized, sSoftAttrSafe, sSoftAttrRev)
            sSoftExpr = nodes.fromEquation(sExpr, sFullName=self._createNodeName('softIk'))
            sCondDistanceBiggerThanOne = nodes.createConditionNode(sDistanceNormalized, '>', 1.0, 1.0, sDistanceNormalized, sFullName=self._createNodeName('softStretchClampOne'))
            sCondSoftBiggerThanOne = nodes.createConditionNode(sSoftAttr, '>', 0.0, sSoftExpr, sCondDistanceBiggerThanOne, sFullName=self._createNodeName('softStretchClampZero'))
            sSoft = nodes.createConditionNode(sDistanceNormalized, '>', sSoftAttrRev, sCondSoftBiggerThanOne, sCondDistanceBiggerThanOne, sFullName=self._createNodeName('softStretch'))
            sSoftRatio = nodes.createMultiplyNode(sDistanceNormalized, sSoft, sOperation='divide', sFullName=self._createNodeName('softStretchRatio'))

            sSoftRatioSafe = nodes.createConditionNode(sSoftAttr, '==', 0, 1.0, sSoftRatio, sFullName=self._createNodeName('softStretchSafe'))
            sConstrWeight = nodes.fromEquation('%s + (1.0 - %s) / %s' % (sStretchAttr, sStretchAttr, sSoftRatioSafe), sFullName=self._createNodeName('ConstrWeight'))
            sConstrWeight = nodes.createBlendNode(sFullStretchAttr, 1, sConstrWeight)

            cmds.connectAttr(sConstrWeight, '%s.%sW0' % (sConstr, sHandTransform))
            cmds.connectAttr(nodes.createReverseNode(sConstrWeight), '%s.%sW1' % (sConstr, sIkJoints[0]))


        if bSoftIk:
            sScaleClamped = nodes.fromEquation('%s * %s + 1.0 - %s' % (sSoftRatio, sStretchAttr, sStretchAttr))
        else:
            sDistanceClamped = nodes.createClampNode(sDistanceNormalized, 1, 100000, sName=self._createNodeName('scaleClamp', 'distance'))
            sScaleClamped = nodes.createRangeNode(sStretchAttr, 0, 1, 1.0, sDistanceClamped, sName=self._createNodeName('scaleClamp', 'clamp'))

        sScaleDefaultUpper = nodes.createMultiplyArrayNode([sScaleClamped, self.fStartLengthA*self.fSideMultipl, sUpperStretchAttr],
                           sName=self._createNodeName('scaleUpper'))
        sScaleDefaultLower = nodes.createMultiplyArrayNode([sScaleClamped, self.fStartLengthB*self.fSideMultipl, sLowerStretchAttr],
                           sName=self._createNodeName('scaleLower'))

        sLockLengthUpper = nodes.createMultiplyNode(sLockLengthUpper, '%s.sx' % self.sCurrentFeatureGrp, sOperation='divide')
        sLockLengthLower = nodes.createMultiplyNode(sLockLengthLower, '%s.sx' % self.sCurrentFeatureGrp, sOperation='divide')
        nodes.createBlendNode(sFullStretchAttr, sLockLengthUpper, sScaleDefaultUpper, sTarget = '%s.tx' % sIkJoints[1])
        nodes.createBlendNode(sFullStretchAttr, sLockLengthLower, sScaleDefaultLower,  sTarget = '%s.tx' % sIkJoints[2])



        if self.iWristScale:
            cmds.scaleConstraint(self.cPrint.sOut, sIkJoints[2], mo=True)

        sLines = curves.createPoleVectorLine(self.cPole, sIkJoints[1], sExtraParents=[self.cPrint.sOut])


        # pole vector roll
        sRollAttr = utils.addAttr(self.cPrint.sCtrl, ln='upRoll', at='double', defaultValue=0.0, k=True)
        if self.sSide == 'l':
            cmds.connectAttr(sRollAttr, '%s.twist' % sIkHandle)
        else:
            nodes.fromEquation('%s * -1' % sRollAttr, sTarget='%s.twist' % sIkHandle)

        cmds.setAttr('%s.v' % self.cPole.sCtrl, lock=False)
        cmds.connectAttr(sPoleVis, '%s.v' % self.cPole.sCtrl)
        [cmds.connectAttr(sPoleVis, '%s.v' % sLine) for sLine in sLines]


        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        for sPasser in [self.cPole.sPasser, self.cPrint.sPasser]:
            cmds.scaleConstraint(self.sCurrentFeatureGrp, sPasser)


        # pivot attributes
        sAnkleRevAttrGroup = cAnkleRev.appendOffsetGroup('attr')
        sBallRollAttr = utils.addAttr(self.cPrint.sCtrl, ln='ballRoll', k=True)
        sBallSideAttr = utils.addAttr(self.cPrint.sCtrl, ln='ballSide', k=True)
        sBallTwistAttr = utils.addAttr(self.cPrint.sCtrl, ln='ballTwist', k=True)

        cmds.connectAttr(sBallRollAttr, '%s.rx' % sAnkleRevAttrGroup)
        cmds.connectAttr(sBallSideAttr, '%s.ry' % sAnkleRevAttrGroup)
        cmds.connectAttr(sBallTwistAttr, '%s.rz' % sAnkleRevAttrGroup)

        sToesBendGrp = cToes.appendOffsetGroup('attr')
        sToeBendAttr = utils.addAttr(self.cPrint.sCtrl, ln='%sBend' % self.dCtrlNames['finger'], k=True)
        # if self.sSide == 'r':
        nodes.createMultiplyNode(sToeBendAttr, -1, sTarget='%s.rx' % sToesBendGrp)
        # else:
        #     cmds.connectAttr(sToeBendAttr, '%s.rx' % sToesBendGrp)

        sHeelRollGrp = cHeel.appendOffsetGroup('attr')
        nodes.createMultiplyNode(utils.addAttr(self.cPrint.sCtrl, ln='heelRoll', minValue=0.0, k=True), -1.0, sTarget='%s.rx' % sHeelRollGrp)
        # cmds.connectAttr(utils.addAttr(self.cPrint.sCtrl, ln='heelRoll', minValue=0.0, k=True), '%s.rx' % sHeelRollGrp)
        cmds.connectAttr(utils.addAttr(self.cPrint.sCtrl, ln='heelSide', k=True), '%s.ry' % sHeelRollGrp)

        sToeAttrGrp = cToesEnd.appendOffsetGroup('attr')
        cmds.connectAttr(utils.addAttr(self.cPrint.sCtrl, ln='%sRoll' % self.dCtrlNames['finger'], k=True), '%s.rx' % sToeAttrGrp)
        cmds.connectAttr(utils.addAttr(self.cPrint.sCtrl, ln='%sSide' % self.dCtrlNames['finger'], k=True), '%s.ry' % sToeAttrGrp)

        sInGrp = cInOuts[1].appendOffsetGroup('attr')
        sOutGrp = cInOuts[0].appendOffsetGroup('attr')
        sFootRockerAttr = utils.addAttr(self.cPrint.sCtrl, ln='%sRocker' % self.dCtrlNames['hand'], k=True)
        nodes.createRangeNode(sFootRockerAttr, 0, 1000, 0, 1000*self.fSideMultipl, sTarget='%s.rx' % sOutGrp)
        nodes.createRangeNode(sFootRockerAttr, 0, -1000, 0, 1000*self.fSideMultipl, sTarget='%s.rx' % sInGrp)


        sMatchScript = ''
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.upRoll', 0)" % self.cPrint.sCtrl
        # sMatchScript += "\nsetAttr(NAMESPACE, '%s.heelRoll', 0)" % self.cPrint.sCtrl
        # sMatchScript += "\nsetAttr(NAMESPACE, '%s.heelSide', 0)" % self.cPrint.sCtrl
        # sMatchScript += "\nsetAttr(NAMESPACE, '%s.footRocker', 0)" % self.cPrint.sCtrl
        # sMatchScript += "\nsetAttr(NAMESPACE, '%s.toeSide', 0)" % self.cPrint.sCtrl
        # sMatchScript += "\nsetAttr(NAMESPACE, '%s.toeRoll', 0)" % self.cPrint.sCtrl
        # sMatchScript += "\nsetAttr(NAMESPACE, '%s.toeBend', 0)" % self.cPrint.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.softIk', 0)" % self.cPrint.sCtrl
        sMatchScript += "\nsetAttr(NAMESPACE, '%s.fullStretch', 0)" % self.cPrint.sCtrl
        # sMatchScript += match.generateApplyAngleCommand(3, 2, sOutJoints, 0, 1, '%s.ballRoll' % self.cPrint.sCtrl, True)

        sMatchScript += "\nsetDistance(NAMESPACE, '{0}', '{1}', %f, '%s')" % (1.0/self.fStartLengthA, sUpperStretchAttr)
        sMatchScript += "\nsetDistance(NAMESPACE, '{1}', '{2}', %f, '%s')" % (1.0/self.fStartLengthB, sLowerStretchAttr)


        sMatchScript += match.generateMatchingConstrainCommand2(3, sOutJoints, self.cPrint.sCtrl,
                                                               iConstraintType=match.Type.parentConstraint,
                                                                bLiveOffset=True)

        sMatchScript += match.generateMatchingConstrainCommand2(2, sOutJoints, sAnkleRevAttrGroup,
                                                               iConstraintType=match.Type.orientConstraint,
                                                               sTransferToAttrs= [sBallRollAttr, sBallSideAttr, sBallTwistAttr])


        sMatchScript += "\nplacePoleVector(NAMESPACE, '{0}', '{1}', '{2}', '%s')" % self.cPole.sCtrl


        for i in [2,3,4]: # could do all joints, but just to be safe
            cmds.setAttr('%s.segmentScaleCompensate' % sIkJoints[i], False)

        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)

        return sOutJoints, cCtrls, dAttacherBuildData


    def generateOutputs_twist(self, **kwargs):
        dOutputs = OrderedDict()
        fUpperParams, fLowerParams = self._getTwistInputParams(kwargs['fUpperParams'], kwargs['fLowerParams'], kwargs['bSpaceJointsEvenly'])

        sUppers = []
        sLowers = []

        iScale = kwargs['iSquashStretchJoints']
        for i, fParam in enumerate(fUpperParams):
            sTwistOutput = self._getTwistName('upper',i)
            dOutputs[sTwistOutput] = None
            sUppers.append(sTwistOutput)
            if iScale:
                sTwistOutput = sTwistOutput.replace('Twist', 'TwistSquash')
                dOutputs[sTwistOutput] = None
                sUppers.append(sTwistOutput)

        for i, fParam in enumerate(fLowerParams):
            sTwistOutput = self._getTwistName('lower',i)
            dOutputs[sTwistOutput] = None
            sLowers.append(sTwistOutput)
            if iScale:
                sTwistOutput = sTwistOutput.replace('Twist', 'TwistSquash')
                dOutputs[sTwistOutput] = None
                sLowers.append(sTwistOutput)

        sRemoveOutputs = ['upper', 'elbow']

        return dOutputs, sRemoveOutputs


    def _getTwistName(self, sPart, iNumber):
        return '%sTwist%03d' % (sPart, iNumber)


    def _getTwistInputParams(self, fUpperParams, fLowerParams, bSpaceJointsEvenly):
        fUpperParams = list(fUpperParams)
        fLowerParams = list(fLowerParams)
        if not bSpaceJointsEvenly: # if we are spacing evenly, it wouldn't matter if the first one is not 0
            if fUpperParams[0] != 0:
                fUpperParams.insert(0, 0.0)
            if fLowerParams[0] != 0:
                fLowerParams.insert(0, 0.0)
        return [fUpperParams, fLowerParams]



    def detail_twist(self, fUpperParams=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
                     fLowerParams=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0], iBendy=0, iUpperPlane=0,
                     bSpaceJointsEvenly=True, iKneeControl=0,
                     bFingerCtrl=False, iSquashStretchJoints=0, bArmTwistFromPoseT=True,
                     _dComboboxItems={'iBendy':['noBendy', 'bendy', 'roundElbow'],
                                      'iKneeControl':['off', 'on', 'onWithDoubleKnee'],
                                      'iSquashStretchJoints':['off','on no scale along X', 'on with scale along X'],
                                      'iUpperPlane':['Y','Z']}):
        if len(fUpperParams) <= 0:
            raise Exception('fUpperParam needs to have one or more items (%s)' % self.sLimbName)
        if len(fLowerParams) <= 0:
            raise Exception('fLowerParam needs to have one or more items (%s)' % self.sLimbName)

        # fSideMultipl = -1 if self.sSide == 'r' else 1

        fJointRadius = cmds.getAttr('%s.radius' % list(self.dBlueprints.values())[0])

        cCtrls = []



        ffParams = self._getTwistInputParams(fUpperParams, fLowerParams, bSpaceJointsEvenly)

        if bSpaceJointsEvenly:
            ffPosParams = [np.interp(np.arange(len(fUpperParams)), [0,len(fUpperParams)], [0,1]),
                           np.interp(np.arange(len(fLowerParams)), [0,len(fLowerParams)], [0,1])]
        else:
            ffPosParams = ffParams


        dAttacherBuildData = {} # self.createEmptyAttacherDict()

        dAttacherBuildData['scale'] = (utils.getDagPath(self.sDetailsGrp), None)

        # sCurrentOuts[0] = self.dOutputs['upper']
        # sCurrentOuts[1] = self.dOutputs['elbow']
        sCurrentOuts = list(self.dOutputs.values())
        sLengthAttrs = ['%s.tx' % sCurrentOuts[1], '%s.tx' % self.dOutputs['wrist']]
        if iKneeControl != 0:
            sMaster = utils.getMasterName()
            cKneeStretch = self._createCtrl3(sName='%sStretch' % self.dCtrlNames['elbow'], fMatchPos=self.dBlueprints['elbow'],
                                            sAttrs=['sx','sz', 't', 'ro'], sShape='locator', fSize=2.0, iColorIndex=1)
            xforms.matrixParentConstraint(self.dOutputs['elbow'], cKneeStretch.sPasser, mo=True, skipScale=True)
            xforms.matrixParentConstraint(self.sDetailsGrp, cKneeStretch.sPasser, mo=True, skipTranslate=True, skipRotate=True)

            sKneeStretchScaleMinusOne = nodes.createVectorAdditionNode(['%s.s' % cKneeStretch.sCtrl, [1,1,1]], sOperation='minus')
            sRevScale = xforms.insertParent(cKneeStretch.sOut, '%s_revScale' % cKneeStretch.sOut, bMatchParentTransform=True)
            nodes.createVectorMultiplyNode([1,1,1], '%s.s' % cKneeStretch.sCtrl, sOperation='divide', sTarget='%s.s' % sRevScale)
            cCtrls.append(cKneeStretch)

            cmds.scaleConstraint(self.sCurrentFeatureGrp, cKneeStretch.sPasser, mo=True)

            sKneeVis = utils.addOffOnAttr(self.sFeatureShape, '%s%sCtrlVIS' % (self.sFeatureAttrPrefix, self.dCtrlNames['elbow']), bDefaultValue=True)

            cmds.connectAttr(sKneeVis, '%s.v' % cKneeStretch.sShape)

            sOrientConstraint = cmds.orientConstraint(self.dOutputs['upper'], self.dOutputs['elbow'], cKneeStretch.appendOffsetGroup('orient'))[0]
            if self.bIsLeg:
                cmds.rotate(90,-90,0, cKneeStretch.appendOffsetGroup('default'), r=True, os=True)
            else:
                cmds.rotate(-90,0,0, cKneeStretch.appendOffsetGroup('default'), r=True, os=True)
            cmds.setAttr('%s.interpType' % sOrientConstraint, 2)
            cmds.pointConstraint(self.dOutputs['elbow'], cKneeStretch.sPasser)

            sCurrentOuts[0] = self._createJoint('upperOut', fSize=fJointRadius)
            cmds.pointConstraint(self.dOutputs['upper'], sCurrentOuts[0])
            cmds.scaleConstraint(self.dOutputs['upper'], sCurrentOuts[0])
            sCurrentOuts[1] = self._createJoint('lowerOut', sParent=cKneeStretch.sOut, fSize=fJointRadius)
            cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sCurrentOuts[0])
            cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sCurrentOuts[1])
            if iKneeControl == 2:
                sUpperEnd = self._createJoint('upperEnd', sParent=cKneeStretch.sOut, fSize=fJointRadius)
                cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sUpperEnd)
                sDoubleKneeAttr = utils.addAttr(cKneeStretch.sCtrl, ln='doubleKnee',
                                                defaultValue=0.5, minValue=0.0, maxValue=1.0, k=True)
                sLocalTop = nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['upper']),
                                                          '%s.worldInverseMatrix' % self.dOutputs['elbow'])
                sLocalBot = nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['wrist']),
                                                          '%s.worldInverseMatrix' % self.dOutputs['elbow'])
                sAngle = nodes.createAngleNode(sLocalTop, sLocalBot)
                sAngleRange = nodes.createRangeNode(sAngle, 90, 0, 0, 1)
                if self.bIsLeg:
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, cmds.getAttr('%s.tx' % self.dOutputs['elbow'])*0.2, sAngleRange],
                                          sTarget='%s.ty' % sUpperEnd)
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, -cmds.getAttr('%s.tx' % self.dOutputs['wrist'])*0.2, sAngleRange],
                                          sTarget='%s.ty' % sCurrentOuts[1])
                else:
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, -cmds.getAttr('%s.tx' % self.dOutputs['elbow'])*0.2, sAngleRange],
                                          sTarget='%s.tx' % sUpperEnd)
                    nodes.createMultiplyArrayNode([sDoubleKneeAttr, cmds.getAttr('%s.tx' % self.dOutputs['wrist'])*0.2, sAngleRange],
                                          sTarget='%s.tx' % sCurrentOuts[1])
            else:
                sUpperEnd = cKneeStretch.sOut

            constraints.aimConstraintFromTransforms(sCurrentOuts[0], sUpperEnd, self.dOutputs['upper'],  aim=[self.fSideMultipl, 0, 0],
                                             bOrientUp=True, sParent=self.sCurrentFeatureGrp)

            if iBendy:
                constraints.aimConstraintFromTransforms(sUpperEnd, self.dOutputs['upper'], self.dOutputs['upper'],
                                                 aim=[self.fSideMultipl, 0, 0], bOrientUp=True, sParent=self.sCurrentFeatureGrp)

            constraints.aimConstraintFromTransforms(sCurrentOuts[1], self.dOutputs['wrist'], self.dOutputs['elbow'],
                                             aim=[self.fSideMultipl, 0, 0], bOrientUp=True, sParent=self.sCurrentFeatureGrp)

            sLengthAttrs[0] = '%sX' % nodes.createPointByMatrixNode(nodes.getWorldPoint(sUpperEnd), '%s.worldInverseMatrix' % sCurrentOuts[0])
            sLengthAttrs[1] = '%sX' % nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['wrist']), '%s.worldInverseMatrix' % sCurrentOuts[1])

        sNoTwistsParentUpper = self._createTransform('upperNoTwistParent')
        cmds.delete(cmds.parentConstraint(self.dBlueprints['up'], sNoTwistsParentUpper))
        dAttacherBuildData['root'] = (utils.getDagPath(sNoTwistsParentUpper), None)
        self.mAttachToClavicleTransformsOnAuto.append(utils.getDagPath(sNoTwistsParentUpper))
        sNoTwistsParentLower = self._createTransform('lowerNoTwistParent')
        cmds.delete(cmds.parentConstraint(self.dBlueprints['elbow'], sNoTwistsParentLower))
        cmds.delete(cmds.pointConstraint(self.dBlueprints['wrist'], sNoTwistsParentLower))

        xforms.matrixParentConstraint(sCurrentOuts[1], sNoTwistsParentLower, mo=True, skipScale=['x','y','z'])
        # sNoTwistParents = [sNoTwistsParentUpper, sNoTwistsParentLower]

        dTwistJoints = {}
        self.dTwistOutputs = {}

        sScales = []
        for p,sPart in enumerate(['upper','lower']):
            sScales.append(nodes.fromEquation('%s * %f' % (sLengthAttrs[p], 1.0 / cmds.getAttr(sLengthAttrs[p])),
                          sName=self._createNodeName('scaleTwist'), bDoUnitConversionNodes=True))

        dSquashProductsY = defaultdict(list)
        dSquashProductsZ = defaultdict(list)


        # create curves
        if iBendy > 0:
            # sSwitchesNode = utils.data.get('sSwitchesNode', xDefault=None)
            # if sSwitchesNode:
            #     sBendVisAttr = utils.addOffOnAttr(sSwitchesNode, '%s_bendyCtrlsVIS' % self.sLimbName, bDefaultValue=False)
            # else:
            sBendVisAttr = utils.addOffOnAttr(self.sFeatureShape, '%sbendyCtrlsVIS' % self.sFeatureAttrPrefix, bDefaultValue=False)

            sCurves = []
            aaBpPoints = []
            fLengths = []
            for p, sPart in enumerate(['upper', 'lower']):

                aaBpPoints.append(xforms.getPositionArray([list(self.dBlueprints.values())[0 + p], list(self.dBlueprints.values())[1 + p]]))
                fLengths.append(np.linalg.norm(aaBpPoints[p][1] - aaBpPoints[p][0]))

            if iBendy == 1: # bendy
                cBendys = []

                for p, sPart in enumerate(['upper', 'lower']):

                    aPoints = [aaBpPoints[p][0]*(1.0-fT) + aaBpPoints[p][1]*fT for fT in [0.0, 0.5, 1.0]]
                    sCurve = cmds.curve(p=aPoints, n=self._createNodeName(sPart, 'curve'), d=2)
                    cmds.setAttr('%s.inheritsTransform' % sCurve, False)

                    cmds.parent(sCurve, self.sDetailsGrp)
                    cCtrl = self._createCtrl3(sName='bendy%s' % utils.getFirstLetterUpperCase(sPart), sShape='locator', sAttrs=['t','ry','sx','sz'],
                                             sMatch=list(self.dBlueprints.values())[p], fMatchPos=aaBpPoints[p][0], iColorIndex=1)
                    cCtrl.adjustAxisOrientation([0, 90, -90])

                    sScaleGrp = cCtrl.appendOffsetGroup('scale')

                    cmds.setAttr('%s.ty' % sScaleGrp, fLengths[p]*0.5)
                    nodes.fromEquation('%s * %0.5f' % (sLengthAttrs[p], 0.5 * self.fSideMultipl), sName=self._createNodeName('scaleTwist'),
                                       bDoUnitConversionNodes=True, sTarget='%s.ty' % sScaleGrp)
                    cmds.connectAttr(sBendVisAttr, '%s.v' % cCtrl.sPasser)
                    xforms.matrixParentConstraint(sCurrentOuts[p], cCtrl.sPasser, mo=True)
                    sCurves.append(sCurve)
                    cBendys.append(cCtrl)

                    # sJ = cBendys[p].addJoint('inf')
                    sJ = cmds.createNode('joint', n=self._createNodeName('bendyJoint%s' % utils.getFirstLetterUpperCase(sPart)), p=cBendys[p].sOut)
                    cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJ)
                    sBottomInf = sCurrentOuts[p+1]
                    if p == 0 and iKneeControl == 2:
                        sBottomInf = sUpperEnd
                    sInfluences = [sCurrentOuts[p], sJ, sBottomInf] #third is wrong
                    pCurve = patch.patchFromName(sCurves[p])
                    cmds.select(sCurves[p], sInfluences)
                    print('select: ', sCurves[p], sInfluences)
                    pCurve.setSkinClusterWeights(np.diag([1.0, 1.0, 1.0]), sInfluences=sInfluences)

                cCtrls += cBendys

            elif iBendy == 2: # bendy elbow
                aaPoints = []
                for p, sPart in enumerate(['upper', 'lower']):
                    aaPoints.append([aaBpPoints[p][0]*(1.0-fT) + aaBpPoints[p][1]*fT for fT in [0.0, 0.33333, 0.66667, 1.0]])
                    sCurve = cmds.curve(p=aaPoints[p], n=self._createNodeName(sPart, 'curve'), d=2)
                    cmds.setAttr('%s.inheritsTransform' % sCurve, False)
                    cmds.parent(sCurve, self.sDetailsGrp)
                    sCurves.append(sCurve)

                sRoundAttr = utils.addAttr(self.sFeatureShape, ln='%sroundness' % self.sFeatureAttrPrefix, k=True, defaultValue=0.5, minValue=0.0, maxValue=1.0)

                sOutAimerJoints = []
                sOutAimerJoints.append(cmds.createNode('joint', n=self._createNodeName('upperOutAimer', 'jnt'), p=sCurrentOuts[0]))
                sOutAimerJoints.append(cmds.createNode('joint', n=self._createNodeName('lowerOutAimer', 'jnt'), p=self.dOutputs['wrist']))

                sOutTangents = []
                sOutTangents.append(self._createTransform(sName='upperAimer', sParent=sCurrentOuts[1]))
                sOutTangents.append(self._createTransform(sName='LowerAimer', sParent=sCurrentOuts[1]))

                sAimerJoints = []
                sAimerJoints.append(cmds.createNode('joint', n=self._createNodeName('upperAimer', 'jnt'), p=sCurrentOuts[1]))
                sAimerJoints.append(cmds.createNode('joint', n=self._createNodeName('lowerAimer', 'jnt'), p=sCurrentOuts[1]))

                sLocals = []
                sLocals.append(nodes.createPointByMatrixNode(nodes.getWorldPoint(sCurrentOuts[0], bDecomposeMatrix=True),
                                                             '%s.worldInverseMatrix' % sCurrentOuts[1]))
                sLocals.append(nodes.createPointByMatrixNode(nodes.getWorldPoint(self.dOutputs['wrist'], bDecomposeMatrix=True),
                                                             '%s.worldInverseMatrix' % sCurrentOuts[1]))
                sSum = nodes.createVectorAdditionNode(sLocals, sOperation='minus')

                sTangents = []
                sTangents.append(self._createTransform(sName='upperAimer', sParent=sCurrentOuts[1]))
                sTangents.append(self._createTransform(sName='LowerAimer', sParent=sCurrentOuts[1]))
                nodes.createVectorMultiplyNode(sSum, 0.5, bVectorByScalar=True, sTarget='%s.t' % sTangents[0])
                nodes.createVectorMultiplyNode(sSum, -0.5, bVectorByScalar=True, sTarget='%s.t' % sTangents[1])
                # cmds.aimConstraint(sTangents[0], sAimerJoints[0])
                # cmds.aimConstraint(sTangents[1], sAimerJoints[1])
                constraints.aimConstraintFromTransforms(sAimerJoints[0], sTangents[0], sParent=self.sCurrentFeatureGrp)
                constraints.aimConstraintFromTransforms(sAimerJoints[1], sTangents[1], sParent=self.sCurrentFeatureGrp)

                cInnerBendy = []
                cInnerBendy.append(self._createCtrl3(sName='bendyUpperIn', sShape='locator', sAttachTo=sAimerJoints[0], sAttachScaleTo=self.sDetailsGrp,
                                 sAttrs=['t','r','s','ro'], sMatch=sCurrentOuts[0], fMatchPos=aaPoints[0][-1], iColorIndex=1, fSize=2.0))
                cInnerBendy.append(self._createCtrl3(sName='bendyLowerIn', sShape='locator', sAttachTo=sAimerJoints[1], sAttachScaleTo=self.sDetailsGrp,
                                 sAttrs=['t', 'r', 's','ro'], sMatch=sCurrentOuts[1], fMatchPos=aaPoints[1][0], iColorIndex=1, fSize=2.0))

                ssMultipls = [[sRoundAttr, -self.fSideMultipl*np.linalg.norm(aaPoints[0][-1]-aaPoints[0][-2])],
                              [sRoundAttr, self.fSideMultipl*np.linalg.norm(aaPoints[1][1]-aaPoints[1][0])]]
                ssMultipls[0].append(sScales[0])
                ssMultipls[1].append(sScales[1])
                nodes.createMultiplyArrayNode(ssMultipls[0], sTarget='%s.tx' % cInnerBendy[0].sOffsets[0])
                nodes.createMultiplyArrayNode(ssMultipls[1], sTarget='%s.tx' % cInnerBendy[1].sOffsets[0])

                # cmds.aimConstraint(cInnerBendy[0].sOut, sOutAimerJoints[0])
                # cmds.aimConstraint(cInnerBendy[1].sOut, sOutAimerJoints[1])
                constraints.aimConstraintFromTransforms(sOutAimerJoints[0], cInnerBendy[0].sOut, sParent=self.sCurrentFeatureGrp)
                constraints.aimConstraintFromTransforms(sOutAimerJoints[1], cInnerBendy[1].sOut, sParent=self.sCurrentFeatureGrp)

                cOuterBendy = []
                cOuterBendy.append(self._createCtrl3(sName='bendyUpperOut', sShape='locator', sAttachTo=sOutAimerJoints[0], sAttachScaleTo=self.sDetailsGrp,
                                 sAttrs=['t', 'r', 's','ro'], sMatch=sCurrentOuts[0], fMatchPos=aaPoints[0][1], fSize=2.0))
                cOuterBendy.append(self._createCtrl3(sName='bendyLowerOut', sShape='locator', sAttachTo=sOutAimerJoints[1], sAttachScaleTo=self.sDetailsGrp,
                                 sAttrs=['t', 'r', 's','ro'], sMatch=sCurrentOuts[1], fMatchPos=aaPoints[1][-2], fSize=2.0))


                for p, sPart in enumerate(['upper', 'lower']):
                    sOuterJoint = cmds.createNode('joint', n=self._createNodeName('%sOuterBendySkin' % sPart, 'jnt'), p=cOuterBendy[p].sOut)
                    sInnerJoint = cmds.createNode('joint', n=self._createNodeName('%sInnerBendySkin' % sPart, 'jnt'), p=cInnerBendy[p].sOut)
                    fNewPos = cmds.xform(sInnerJoint, q=True, ws=True, t=True)
                    if p == 0:
                        cmds.move(fNewPos[0], fNewPos[1], fNewPos[2], '%s.cv[%d]' % (sCurves[p], 2), a=True, ws=True)
                        sInfluences = [sCurrentOuts[p], sOuterJoint, sInnerJoint, sCurrentOuts[p+1]]
                    else:
                        cmds.move(fNewPos[0], fNewPos[1], fNewPos[2], '%s.cv[%d]' % (sCurves[p], 1), a=True, ws=True)
                        sInfluences = [sCurrentOuts[p], sInnerJoint, sOuterJoint, sCurrentOuts[p + 1]]
                    pCurve = patch.patchFromName(sCurves[p])
                    pCurve.setSkinClusterWeights(np.diag([1.0, 1.0, 1.0, 1.0]), sInfluences=sInfluences)

                    cmds.connectAttr(sBendVisAttr, '%s.v' % cInnerBendy[p].sPasser)
                    cmds.connectAttr(sBendVisAttr, '%s.v' % cOuterBendy[p].sPasser)


        sUpperNoTwistCalculateParent = self._createTransform('upperTwistNoTwistCalculateParent', sMatch=sCurrentOuts[0], sParent=sNoTwistsParentUpper)

        sUpperNoTwistTransform = self._createTransform('upperTwistNoTwist', sMatch=sCurrentOuts[0], sParent=sNoTwistsParentUpper)
        if not self.bIsLeg and bArmTwistFromPoseT:
            sTempAim = xforms.createLocator('temp', sMatch=sCurrentOuts[1])
            cmds.setAttr('%s.ty' % sTempAim, cmds.getAttr('%s.ty' % sCurrentOuts[0]))
            cmds.delete(cmds.aimConstraint(sTempAim, sUpperNoTwistCalculateParent, wut='objectrotation', wuo=sUpperNoTwistTransform, aim=[self.fSideMultipl,0,0]))
            cmds.delete(sTempAim)

        sUpperNoTwistsNew = self._createTransform('upperNoTwistNew', sParent=sUpperNoTwistCalculateParent, sMatch=sCurrentOuts[0])

        sPoleLoc = self._createTransform('polePos', sParent=sUpperNoTwistCalculateParent, bLocator=True)
        sLocalElbow = nodes.createPointByMatrixNode(nodes.getWorldPoint(sCurrentOuts[1]), '%s.worldInverseMatrix' % sUpperNoTwistCalculateParent)

        sNormalizedElbow = nodes.createNormalizedVector(sLocalElbow)
        self.fDefaultNormalizedElbow = cmds.getAttr(sNormalizedElbow)[0]

        if iUpperPlane == 0:
            self.sPlaneAxis = 'Y'
            self.fUpperUpVector = [0,0,-1]
        elif iUpperPlane == 1:
            self.sPlaneAxis = 'Z'
            self.fUpperUpVector = [0,-1,0]

        fPlaneVector = -np.cross(self.fDefaultNormalizedElbow, self.fUpperUpVector)
        sPolePos = nodes.createRangeNode(nodes.createAbsoluteNode('%s%s' % (sNormalizedElbow, self.sPlaneAxis)), 0, 1,
                                          nodes.createCrossProductNode(sNormalizedElbow, fPlaneVector),
                                          list(self.fUpperUpVector), bOutRangeIsVector=True)

        utils.data.store('fPlaneVector_%s' % self.sLimbName, fPlaneVector)
        utils.data.store('fDefaultNormalizedElbow_%s' % self.sLimbName, self.fDefaultNormalizedElbow)
        utils.data.store('sPlaneAxis_%s' % self.sLimbName, self.sPlaneAxis)
        utils.data.store('fUpperUpVector_%s' % self.sLimbName, self.fUpperUpVector)

        nodes._connectOrSetVector(sPolePos, '%s.t' % sPoleLoc, sSeparateItems=['tx','ty','tz'])
        cmds.aimConstraint(sCurrentOuts[1], sUpperNoTwistsNew, wut='object', wuo=sPoleLoc, aim=[self.fSideMultipl,0,0], u=self.fUpperUpVector)

        sUpperMeasureTwist = xforms.twistDetector( sCurrentOuts[0], sUpperNoTwistsNew)
        sLowerMeasureTwist = xforms.twistDetector(self.dOutputs['wrist'], sCurrentOuts[1], bMaintainOffset=True)


        for sPart, p, sJoint, sTwistValue in \
                [('upper', 0, sCurrentOuts[0], sUpperMeasureTwist),
                ('lower', 1, sCurrentOuts[1], sLowerMeasureTwist)]:

            fLength = abs(cmds.getAttr(sLengthAttrs[p]))
            iCount = len(ffParams[p])


            aPoints = np.zeros((iCount,3), dtype='float64')
            fLenghParam = float(len(ffPosParams[p]))
            fShrinkedToLastLength = fLength if ffPosParams[p][-1] < 1.0 else fLength  * ((fLenghParam-1.0) / fLenghParam)
            aPoints[:,0] = np.array(ffPosParams[p], dtype='float64') * fShrinkedToLastLength * self.fSideMultipl

            sTwists = xforms.createJointChain(aPoints, self._createNodeName('%sTwist' % sPart, 'jnt', iCount=iCount),
                                              sParent=self.sDetailsGrp, fRadius=cmds.getAttr('%s.radius' % self.dBlueprints['up']), sSide=self.sSide)

            cmds.setAttr('%s.jo' % sTwists[0], 0, 0, 0)

            sNoRotateTransform = sCurrentOuts[1] if p == 1 else sUpperNoTwistsNew

            if iBendy == 0:
                xforms.matrixParentConstraint(sNoRotateTransform, sTwists[0],
                                              skipScale=['x', 'y', 'z'])
                dTempTwistValues = {}
                for i in range(1, iCount, 1):
                    fTwistValue = ffParams[p][i]-ffParams[p][i-1]
                    try:
                        sTwistMultipl = dTempTwistValues[fTwistValue]
                    except:
                        sTwistMultipl = nodes.fromEquation('%s * %f' % (sTwistValue, fTwistValue),
                                                           sName=self._createNodeName('twistAmount%03d' % round(fTwistValue*100)))
                    cmds.connectAttr(sTwistMultipl, '%s.rx' % sTwists[i])
                    dTempTwistValues[fTwistValue] = sTwistMultipl

                for sT in sTwists[1:]:
                    nodes.fromEquation('%s * %f' % (sScales[p], cmds.getAttr('%s.tx' % sT)), sTarget='%s.tx' % sT,
                                       sName=self._createNodeName('twistScalePerJoint'), bDoUnitConversionNodes=True)


            else: # iBendy > 0
                xforms.matrixParentConstraint(sNoRotateTransform, sTwists[0],
                                              skipScale=['x', 'y', 'z'], skipRotate=['x','y','z'])

                fCurveParams = curves.getParamsFromPercs(sCurves[p], np.concatenate([ffPosParams[p], [1.0]]))
                sCurvePositions = []
                sGlobalScale = '%s.outputScaleX' % nodes.createDecomposeMatrix('%s.worldMatrix' % self.dOutputs['upper']).split('.')[0]

                aTwistValues = utils.bSpline3([0, 1, 0], len(ffParams[p])+1)
                for i in range(len(ffParams[p])+1):
                    fReducedCurveParam = fCurveParams[i] * (float(len(ffParams[p])) / float(len(ffParams[p])))
                    sInfoNode, sCurvePos = curves.createPointInfoNode(sCurves[p], fParam=fReducedCurveParam)
                    sCurvePositions.append(sCurvePos)
                    if i >= 1:
                        sRotateUp = self._createTransform('upVectorTwist%03d' % i, sParent=sNoRotateTransform)
                        fSideMultipl = self.fSideMultipl if p == 1 else 1.0
                        nodes.createMultiplyNode(sTwistValue, ffParams[p][i-1], sTarget='%s.rx' % sRotateUp)
                        sDistance = nodes.createDistanceNode(sCurvePositions[i - 1], sCurvePositions[i], sDivide=sGlobalScale)
                        if i < iCount:
                            if self.fSideMultipl == 1.0:
                                cmds.connectAttr(sDistance, '%s.tx' % sTwists[i])
                            else:
                                nodes.fromEquation('%s * -1.0' % sDistance, sTarget='%s.tx' % sTwists[i])

                        sAimConstraint = nodes.createSimpleAimConstraint2(sCurvePos, sTwists[i-1], bRotateUp=True, xUpMatrix='%s.worldMatrix' % sRotateUp,
                                                                          sName=self._createNodeName('%sTwist%03d' % (sPart, i)), sParent=self.sDetailsGrp,
                                                                          xAimVector=[self.fSideMultipl,0,0])
                        cmds.connectAttr('%s.parentInverseMatrix' % sTwists[i-1], '%s.constraintParentInverseMatrix' % sAimConstraint)
                        # nodes.createMultiplyNode('%s.ry' % cBendys[p].sCtrl, aTwistValues[i-1], sTarget='%s.offsetX' % sAimConstraint)

                if iSquashStretchJoints:
                    aMiddleWeights = utils.bSpline3([0,1,0], aValues=ffParams[p])
                    aKneeWeights = utils.bSpline3([0,0,1] if p == 0 else [1,0,0], aValues=ffParams[p])
                    sBendyMinusOne = nodes.createVectorAdditionNode(['%s.s' % cBendys[p].sCtrl, [1,1,1]], sOperation='minus')
                    for j,sTwist in enumerate(sTwists):
                        dSquashProductsY[sTwist].append([aMiddleWeights[j], '%sz' % sBendyMinusOne])
                        dSquashProductsZ[sTwist].append([aMiddleWeights[j], '%sx' % sBendyMinusOne])
                        dSquashProductsY[sTwist].append([aKneeWeights[j], '%sz' % sKneeStretchScaleMinusOne])
                        dSquashProductsZ[sTwist].append([aKneeWeights[j], '%sx' % sKneeStretchScaleMinusOne])
                    cmds.select(sTwists)

            dTwistJoints[sPart] = sTwists
            self.dTwistOutputs[sPart] = OrderedDict()
            for i,sT in enumerate(sTwists):
                self.dTwistOutputs[sPart][self._getTwistName(sPart,i)] = sT



        if bFingerCtrl:
            cFinger = self._createCtrl3(sName=self.dCtrlNames['fingers'], sMatch=self.dBlueprints['fingers'], #iOffsetCount=2,
                                      sAttrs = ['r','ro'], sShape='wedge', fSize=cmds.getAttr('%s.radius' % self.dBlueprints['fingers'])*5)
            cFinger.adjustAxisOrientation([0,90,-90])
            cCtrls.append(cFinger)
            cmds.scaleConstraint(self.sDetailsGrp, cFinger.sPasser)


            xforms.matrixParentConstraint(sCurrentOuts[3], cFinger.sPasser, mo=True, skipScale=['x','y','z'])


        cmds.parent(dTwistJoints['lower'][0], dTwistJoints['upper'][-1]) # that gives issue in maya 2018
        xforms.bugFixCleanConstraint2018(dTwistJoints['lower'][0])
        self.dOutputs.update(self.dTwistOutputs['upper'])
        self.dOutputs.update(self.dTwistOutputs['lower'])
        dLowerTwists = self.dTwistOutputs['lower']
        sNewWristParent = dLowerTwists[list(dLowerTwists.keys())[-1]]
        sNewWrist = self._replaceOutput('wrist', sNewWristParent, bAttachScale=True)

        sNewFinger = self.dOutputs['fingers']
        sNewEnd = self.dOutputs['end']
        if bFingerCtrl:
            sNewFinger = self._replaceOutput('fingers', sNewWrist, bAttach=False)
            xforms.matrixParentConstraint(cFinger.sOut, sNewFinger)
            cmds.parent(self.dOutputs['end'], sNewFinger)
            cmds.delete(cmds.parentConstraint(sNewEnd, q=True))
        else:
            cmds.parent(sNewFinger, sNewWrist)
            xforms.bugFixCleanConstraint2018(sNewFinger)
        self.sSkinJoints = list(self.dTwistOutputs['upper'].values()) + list(self.dTwistOutputs['lower'].values()) + [sNewWrist, sNewFinger, sNewEnd]

        self.dDetailReplacements[self.getOutputFullNames()[0]] = list(self.dTwistOutputs['upper'].values())[0]
        self.dDetailReplacements[self.getOutputFullNames()[1]] = list(self.dTwistOutputs['lower'].values())[0]


        if iSquashStretchJoints:
            # sAutoSquashAttr = utils.addAttr(self.sFeatureShape, ln='autoSquash', minValue=0.01, maxValue=10.0, defaultValue=1.0, k=True)

            for sOutput, sJoint in list(self.dOutputs.items()):
                if 'Twist' in sOutput:
                    sChild = cmds.listRelatives(sJoint, c=True)[0]

                    sSquashJoint = cmds.createNode('joint', n=sJoint.replace('Twist', 'TwistSquash'), p=sJoint)
                    cmds.setAttr('%s.radius' % sSquashJoint, cmds.getAttr('%s.radius' % sJoint) * 1.5)
                    cmds.setAttr('%s.segmentScaleCompensate' % sSquashJoint, False)
                    self.dOutputs['%sScale' % sOutput] = sSquashJoint

                    if iSquashStretchJoints == 2:
                        nodes.createMultiplyNode('%s.tx' % sChild, cmds.getAttr('%s.tx' % sChild), sOperation='divide', sTarget='%s.sx' % sSquashJoint)
                    self.sSkinJoints.append(sSquashJoint)

                    if dSquashProductsY[sJoint]:
                        sScaleY = nodes.createInfiniteDotProduct(dSquashProductsY[sJoint])
                        sScaleZ = nodes.createInfiniteDotProduct(dSquashProductsZ[sJoint])
                        sAddition = nodes.createVectorAdditionNode([[1,1,1], [1, sScaleY, sScaleZ]])
                        cmds.connectAttr('%sy' % sAddition, '%s.sy' % sSquashJoint)
                        cmds.connectAttr('%sz' % sAddition, '%s.sz' % sSquashJoint)

                    utils.addStringAttr(sSquashJoint, 'skinParent', sJoint, bLock=True)
                    segments.updateTagAttr(sSquashJoint, {'bDisable': True})
                    segments.updateTagAttr(sJoint, {'sSearchReplace': 'Twist;TwistSquash'})


        return cCtrls, dAttacherBuildData




    def childrenConnect_LFinger(self, _lChildren):

        for f, tFinger in enumerate(_lChildren):
            if tFinger.bIsThumb:
                xforms.matrixParentConstraint(self.dOutputs['wrist'], tFinger.cFkCtrls[0].sPasser, mo=True)
            else:
                if tFinger.sMetaStartTransform != None:
                    xforms.matrixParentConstraint(self.dOutputs['wrist'], tFinger.sMetaStartTransform, mo=True)#, skipScale=['x','y','z'])

                if tFinger.iFkIk in [0, 2]:
                    xforms.matrixParentConstraint(self.dOutputs['fingers'], tFinger.cFkCtrls[0].sPasser , mo=True, skipScale=['x','y','z'])
                    cmds.scaleConstraint(self.dOutputs['wrist'], tFinger.cFkCtrls[0].sPasser)

                if tFinger.iFkIk in [1, 2]:
                    xforms.matrixParentConstraint(self.dOutputs['fingers'], tFinger.cTipIk.sPasser , mo=True, skipScale=['x','y','z'])
                    cmds.scaleConstraint(self.dOutputs['wrist'], tFinger.cTipIk.sPasser)

                if tFinger.cMetaIk != None:
                    xforms.matrixParentConstraint(self.dOutputs['fingers'], tFinger.cMetaIk.sPasser , mo=True, skipScale=['x','y','z'])


            tFinger.sSkeletonParent = (self.dOutputs['wrist'], self, 'wrist')

            # segments tag
            sCrossHierarchy = _lChildren[f+1].dOutputs['meta'] if f < len(_lChildren)-1 else None
            dSegmentsTag = {'iPriority':len(_lChildren)-f, 'sCrossHierarchy':sCrossHierarchy}
            segments.updateTagAttr(tFinger.dOutputs['meta'], dSegmentsTag)


    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        if lChildren:
            segments.updateTagAttr(self.dOutputs['fingers'], {'bDisable':True})

        for sOutput, sOutputTransform in list(self.dOutputs.items()):
            if 'Twist' in sOutput:
                segments.updateTagAttr(sOutputTransform, {'sSearchReplace': 'Twist_;TwistSquash_'})




    def buildBlueprintRig(self, lParent=None):
        
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        self.cGroupHand = blueprints.createGroupCtrl(self.dBlueprints['wrist'], sSide=self.sSide, xCtrl='%sGrpHand' % self.sName, sParent=self.sBpTopGrp, fCtrlSize=5.0)


        cArmCtrls = blueprints.createChainCtrls([self.dBlueprints['up'], self.dBlueprints['elbow'], self.dBlueprints['wrist']],
                                                sSide=self.sSide, xRoot='%sUpper' % self.sName, xAim='%sHand' % self.sName, xPole='%sPole' % self.sName, sParent=self.sBpTopGrp)
        
        cWristCtrls = blueprints.createChainCtrls([self.dBlueprints['wrist'], self.dBlueprints['fingers']], sSide=self.sSide, sParent=self.sBpTopGrp, fUpVectorDistanceMultipl=5.0,
                                                xRoot=cArmCtrls[-1], xAim='%sFingers' % self.sName, xPole='%sPoleWrist' % self.sName, bParentAimUnderRoot=True)
        cFingerCtrls = blueprints.createChainCtrls([self.dBlueprints['fingers'], self.dBlueprints['fingersEnd']], sSide=self.sSide, sParent=self.sBpTopGrp, fUpVectorDistanceMultipl=5.0,
                                                xRoot=cWristCtrls[-1], xAim='%sFingersEnd' % self.sName, xPole='%sPoleFingers' % self.sName, bParentAimUnderRoot=True)



        cBpAll = cArmCtrls + cWristCtrls + cFingerCtrls + [self.cGroupHand]

        self.cPrintCtrls = []

        self.cPrintCtrl = blueprints.createCtrl(self.dBlueprints['print'], sSide=self.sSide, xCtrl='%sPrint' % self.sName, sParent=self.sBpTopGrp, iColorIndex=3)
        cHeelCtrl = blueprints.createCtrl(self.dBlueprints['heelPivot'], sSide=self.sSide, xCtrl='%sHeel' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cToesCtrl = blueprints.createCtrl(self.dBlueprints['toesPivot'], sSide=self.sSide, xCtrl='%sToes' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cInCtrlA = blueprints.createCtrl(self.dBlueprints['inPivotA'], sSide=self.sSide, xCtrl='%sInA' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cOutCtrlA = blueprints.createCtrl(self.dBlueprints['outPivotA'], sSide=self.sSide, xCtrl='%sOutA' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cInCtrlB = blueprints.createCtrl(self.dBlueprints['inPivotB'], sSide=self.sSide, xCtrl='%sInB' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        cOutCtrlB = blueprints.createCtrl(self.dBlueprints['outPivotB'], sSide=self.sSide, xCtrl='%sOutB' % self.sName, sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
        for cC in [cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB, cHeelCtrl]:
            cmds.parentConstraint(self.cPrintCtrl.sOut, cC.sPasser, mo=True)
        # for cC in [cHeelCtrl, cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB]:
        #     cmds.setAttr('%s.ty' % cC.sCtrl, lock=True)
        cBpAll += [cHeelCtrl, cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB, self.cPrintCtrl]
        self.cPrintCtrls.append(self.cPrintCtrl)

        for f in range(self.iShoesCount):
            sLetter = utils.getLetter(f)
            self.cPrintCtrl = blueprints.createCtrl(self.dBlueprints['print%s' % sLetter], sSide=self.sSide, xCtrl='%sPrint%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, iColorIndex=3)
            cHeelCtrl = blueprints.createCtrl(self.dBlueprints['heelPivot%s' % sLetter], sSide=self.sSide, xCtrl='%sHeel%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
            cToesCtrl = blueprints.createCtrl(self.dBlueprints['toesPivot%s' % sLetter], sSide=self.sSide, xCtrl='%sToes%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
            cInCtrlA = blueprints.createCtrl(self.dBlueprints['inPivotA%s' % sLetter], sSide=self.sSide, xCtrl='%sInA%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
            cOutCtrlA = blueprints.createCtrl(self.dBlueprints['outPivotA%s' % sLetter], sSide=self.sSide, xCtrl='%sOutA%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
            cInCtrlB = blueprints.createCtrl(self.dBlueprints['inPivotB%s' % sLetter], sSide=self.sSide, xCtrl='%sInB%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
            cOutCtrlB = blueprints.createCtrl(self.dBlueprints['outPivotB%s' % sLetter], sSide=self.sSide, xCtrl='%sOutB%s' % (self.sName, sLetter), sParent=self.sBpTopGrp, bNoRotation=True, iColorIndex=3)
            for cC in [cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB, cHeelCtrl]:
                cmds.parentConstraint(self.cPrintCtrl.sOut, cC.sPasser, mo=True)
            # for cC in [cHeelCtrl, cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB]:
            #     cmds.setAttr('%s.ty' % cC.sCtrl, lock=True)
            cBpAll += [cHeelCtrl, cToesCtrl, cInCtrlA, cInCtrlB, cOutCtrlA, cOutCtrlB, self.cPrintCtrl]
            self.cPrintCtrls.append(self.cPrintCtrl)


        self.cBpRoots = [cArmCtrls[0], self.cGroupHand]

        self.cBpAll = list(set(cBpAll))
        self.cLastBp = self.cGroupHand

        for cC in cWristCtrls + cFingerCtrls + self.cPrintCtrls:
            cmds.parentConstraint(self.cGroupHand.sOut, cC.sPasser, mo=True)

        self.cBpElbow = cArmCtrls[1]

        self.fLastWarpPriority = blueprints.iWarpPriorityCounter


    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):
        print ('post setup blueprint - %s' % self.sLimbName)
        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)

        tThumbs = [tC for tC in lChildren if 'thumb' in tC.sLimbName]
        for tThumb in tThumbs:
            for cRoot in tThumb.cBpRoots:
                xforms.matrixParentConstraint(self.cGroupHand.sOut, cRoot.sPasser, mo=True, skipScale=['x','y','z'])

        tFingers = [tC for tC in lChildren if 'kangarooLimbs.finger_' in str(type(tC)) and 'thumb' not in tC.sLimbName]

        if len(tFingers) >= 3:

            tOuterFingers = (tFingers[0], tFingers[-1])
            tInnerFingers = tFingers[1:-1]

            cBpCtrls = []
            cBpCtrls += blueprints.innerOuterCtrlSetup(['%sMetaOuterStart' % self.sName, '%sMetaOuterEnd' % self.sName],
                                                        cOuterCtrls=[tOuterFingers[0].cBpRoots[0], tOuterFingers[1].cBpRoots[0]],
                                                        cInnerCtrls=[tF.cBpRoots[0] for tF in tInnerFingers],
                                                        sParent=self.sBpTopGrp, sSide=self.sSide, fSize=1,
                                                        sPolePos=tOuterFingers[0]._cBpMetaPole.sOut)
            cBpCtrls += blueprints.innerOuterCtrlSetup(['%sBaseOuterStart' % self.sName, '%sBaseOuterEnd' % self.sName],
                                                        cOuterCtrls=[tOuterFingers[0].cBpRoots[1], tOuterFingers[1].cBpRoots[1]],
                                                        cInnerCtrls=[tF.cBpRoots[1] for tF in tInnerFingers],
                                                        sParent=self.sBpTopGrp, sSide=self.sSide, fSize=1,
                                                        sPolePos=tOuterFingers[0]._cBpBasePole.sOut)
            cBpCtrls += blueprints.innerOuterCtrlSetup(['%sEndOuterStart' % self.sName, '%sEndOuterEnd' % self.sName],
                                                        cOuterCtrls=[tOuterFingers[0].cBpRoots[2], tOuterFingers[1].cBpRoots[2]],
                                                        cInnerCtrls=[tF.cBpRoots[2] for tF in tInnerFingers],
                                                        sParent=self.sBpTopGrp, sSide=self.sSide, fSize=1,
                                                        sPolePos=tOuterFingers[0]._cBpBasePole.sOut)

            for cBpC in cBpCtrls:
                blueprints.overwriteWarpPriority(cBpC.sCtrl, self.fLastWarpPriority+0.1)

            for cCtrl in cBpCtrls:
                cmds.parentConstraint(self.cGroupHand.sOut, cCtrl.sPasser, mo=True)

            self.cBpAll += cBpCtrls

        else: # only 2 or less fingers
            for tFinger in tFingers:
                for cRoot in tFinger.cBpRoots:
                    cmds.parentConstraint(self.cGroupHand.sOut, cRoot.sPasser, mo=True)




    @classmethod
    def rightClickCommand_transferToSquashJointsSelected(cls, ddData):
        sLimbName = '%s_%s' % (ddData['dArgsFILE']['sSide'], ddData['dArgsFILE']['sName'])
        weights.moveSkinClusterWeights(xJoints={'jnt_%s_lowerTwist_???*' % sLimbName:'Twist,TwistSquash',
                                                'jnt_%s_upperTwist_???*' % sLimbName:'Twist,TwistSquash'})

    @classmethod
    def rightClickCommand_transferFromSquashToRegularJointsSelected(cls, ddData):
        sLimbName = '%s_%s' % (ddData['dArgsFILE']['sSide'], ddData['dArgsFILE']['sName'])
        weights.moveSkinClusterWeights(xJoints={'jnt_%s_lowerTwistSquash_???*' % sLimbName:'TwistSquash,Twist',
                                                'jnt_%s_upperTwistSquash_???*' % sLimbName:'TwistSquash,Twist'})


