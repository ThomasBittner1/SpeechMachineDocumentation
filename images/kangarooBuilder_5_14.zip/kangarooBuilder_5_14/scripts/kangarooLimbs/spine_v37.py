###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import numpy as np
from collections import OrderedDict, defaultdict

import kangarooTools.match as match
import kangarooTools.curves as curves
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTools.blueprints as blueprints
import kangarooTools.constraints as constraints
import kangarooTools.utilFunctions as utils
import kangarooTabTools.segments as segments
import kangarooTabTools.weights as weights
import kangarooTools.utilsUnreal as utilsUnreal

import kangarooLimbs.baseLimb as baseLimb

sFile = __file__  # .../spine_v6.py
sVersion = sFile.split('_')[-1].split('.')[0]


class StretchMode():
    clamp = 0
    fullyStretchSingleIk = 1 # depricated
    curveInfoNodesSoftTwist = 2
    curveInfoNodesRigidTwist = 3
    motionPathsSoftTwist = 4
    motionPathsRigidTwist = 5

sStretchModes = ['spline ik',
    'spline ik with stretch',
    'curveInfo nodes (soft twist)',
    'curveInfo nodes (rigid twist)',
    'motionPath nodes (soft twist)',
    'motionPath nodes (rigid twist)']


class LSpine(baseLimb._LBaseLimb):
    iFixCurveMirrorBehavior = 1
    def __init__(self, sName='spine', sSide='m', iSpineJointCount=5,
                 bForceParentSkeletonToRoot=False, iBlueprintCount=5, bBlueprintsCurve=False,
                 fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0),
                 fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0), bRemoveEndSkinJoint=False,
                 sCreateReplacerAttachers='[]', bSymmetricWhenMiddle=True,
                 iSegmentsPriority=0, fCtrlSize=1.0, iColorIndex=0, iFeatureCtrlType=0, sCustomFeatureCtrlName='',
                 _dComboboxItems={'iFeatureCtrlType': ['shape on all ctrls', 'new global ctrl', 'custom ctrl']}):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     sCreateReplacerAttachers=sCreateReplacerAttachers,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset,
                                     bRemoveEndSkinJoint=bRemoveEndSkinJoint,
                                     iSegmentsPriority=iSegmentsPriority,
                                     iFeatureCtrlType=iFeatureCtrlType, sCustomFeatureCtrlName=sCustomFeatureCtrlName)
        self.iSpineJointCount = iSpineJointCount
        self.iBlueprintCount = iBlueprintCount

        self.dOutputs['root'] = None
        for i in range(self.iSpineJointCount - 1):
            self.dOutputs['spine_%03d' % i] = None
        self.dOutputs['spine_end'] = None

        self.sDefaultFeatures = ['feature_fk']
        self.dTwistCtrlIndices = {}
        self.dTwistCtrlIndicesDistr = {}
        self.dScaleCtrlIndices = {}
        self.bBlueprintsCurve = bBlueprintsCurve
        self.iColorIndex = iColorIndex
        self.cDynamicBakeCtrls = []
        self.fCtrlSize = fCtrlSize

        if self.iFeatureCtrlType == 1:
            self.dFeatureCtrlParent = {'sOutputKey':'root', 'sBlueprintKey':'root'}

        self.bDoControlRigFunction = True

        self.bRemoveEndSkinJoint = bRemoveEndSkinJoint
        if self.bRemoveEndSkinJoint:
            sOuts = self.getOutputFullNames()
            self.dDetailReplacements[sOuts[-1]] = sOuts[-2]



    def getDefaultParentOutput(self):
        return 'spine_end'

    def generateAttachers_init(self, **args):
        return {'root': {'sTrs': 'tr', 'bMulti': True},
                'scale': {'sTrs': 's', 'bMulti': False}}

    def createOrSetBlueprints(self, lParent=None):
        if not self.bBlueprintsCurve:
            sBlueprints = ['spine_%03d' % i for i in range(self.iBlueprintCount - 1)] + ['spine_end']
            fPoints = [(0, 3.0 * i, 0, 0, 0, 1) for i in range(self.iBlueprintCount)]

            sNewJoints = self._fillBlueprints([fPoints], [sBlueprints])  # , sParent=sParent)
            return sNewJoints
        else:
            self.dBlueprints = OrderedDict()
            self.sBlueprintCurves = ['bpCurve_%s' % self.sLimbName, 'bpUpCurve_%s' % self.sLimbName]

            if not cmds.objExists(self.sBpSkelGrp):
                cmds.createNode('transform', name=self.sBpSkelGrp)

            iCount = self.iBlueprintCount
            aPoints = np.zeros((iCount, 3), dtype='float64')
            aPoints[:, 1] = np.arange(self.iBlueprintCount)

            for i in range(iCount):
                if i < iCount - 1:
                    sJoint = 'bp_%s_spine_%03d' % (self.sLimbName, i)
                else:
                    sJoint = 'bp_%s_spine_end' % (self.sLimbName)
                if cmds.objExists(sJoint):
                    aPoints[i] = cmds.xform(sJoint, q=True, t=True, ws=True)

            if self.sSide == 'r':
                aPoints[:, 0] *= -1.0

            fLength = np.linalg.norm(aPoints[0] - aPoints[-1])
            aUpPoints = np.copy(aPoints)
            aUpPoints[:, 0] += fLength * 0.2
            aaPoints = [aPoints, aUpPoints]

            for c,sCurve in enumerate(self.sBlueprintCurves): # 2 curves
                if not cmds.objExists(sCurve):
                    cmds.curve(p=aaPoints[c], d=2 if iCount > 2 else 1, n=sCurve)
                    curves.fixShapeName(sCurve)
                    cmds.parent(sCurve, self.sBpSkelGrp)
                    if self.sSide == 'r':
                        cmds.setAttr('%s.sx' % sCurve, -1.0)

                else: # it exists, let's fix transform values just in case
                    for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz', 't', 'r', 's']:
                         cmds.setAttr('%s.%s' % (sCurve, sA), lock=False)
                    pCurve = patch.patchFromName(sCurve)
                    aWorldPointsBefore = pCurve.getPoints()
                    cmds.setAttr('%s.t' % sCurve, 0,0,0)
                    cmds.setAttr('%s.r' % sCurve, 0,0,0)
                    cmds.setAttr('%s.s' % sCurve, 1,1,1)

                    if self.sSide == 'r':
                        cmds.setAttr('%s.sx' % sCurve, -1.0)

                    pCurve.setPoints(aWorldPointsBefore)

                for sA in ['t', 'r', 's']:
                    cmds.setAttr('%s.%s' % (sCurve, sA), lock=True)

            for sCurve in self.sBlueprintCurves:
                utils.addStringAttr(sCurve, 'sBlueprintJoint', self.sLimbName)

            return self.sBlueprintCurves[0], self.sBlueprintCurves[1]

    # to be run when blueprintsCurve is on
    def _createBpJointsFromCurves(self):

        sFirstJointName = 'bp_%s_spine_%03d' % (self.sLimbName, 0)
        if cmds.objExists(sFirstJointName):
            return

        sBpJoints = cmds.ls('bp_%s_spine' % self.sLimbName)
        if sBpJoints:
            raise Exception('You have set blueprintsCurve for %s, but there are joints (%s), please delete those joints' % (
            self.sLimbName, ', '.join(sBpJoints)))

        sJoints = []
        sBpCurve = 'bpCurve_%s' % self.sLimbName
        sBpUpCurve = 'bpUpCurve_%s' % self.sLimbName
        # fParams = np.arange(self.iSpineJointCount) * (curves.getParamLength(sBpCurve) / (self.iSpineJointCount - 1))
        fParams = curves.getParamsFromPercs(sBpCurve,
                                            np.arange(self.iSpineJointCount) / float(self.iSpineJointCount - 1.0))
        try:
            aPoints = curves.getPointsFromParams(sBpCurve, fParams, bReturnNumpy=True)
            aUpPoints = curves.getPointsFromParams(sBpUpCurve, fParams, bReturnNumpy=True)
        except Exception as e:
            print('error: ', e)
            raise Exception('Some issue with curve "%s", did you delete vertices without rebuilding the curve?' % sBpCurve)

        self.dBlueprints = OrderedDict()
        fJointRadius = xforms.getAverageJointRadius()

        for j in range(self.iSpineJointCount):
            sJointName = 'bp_%s_spine_%03d' % (self.sLimbName, j)
            if cmds.objExists(sJointName):
                raise Exception('joint name already exists: %s' % sJointName)
            sJ = xforms.createJoint(sJointName, fSize=fJointRadius)
            cmds.xform(sJ, t=aPoints[j], ws=True, a=True)
            sJoints.append(sJ)
            if j < self.iSpineJointCount - 1:
                self.dBlueprints['spine_%03d' % j] = sJ
            else:
                self.dBlueprints['spine_end'] = sJ

        sPrevJ = '_blueprintsTemp'
        if not cmds.objExists(sPrevJ):
            cmds.createNode('transform', n=sPrevJ)
            cmds.setAttr('%s.v' % sPrevJ, False)

        for j, sJ in enumerate(sJoints):
            if j < self.iSpineJointCount - 1:
                xforms.orientThreePoints(sJoints[j], sJoints[j + 1], aUpPoints[j] - aPoints[j],
                                         fAimVector=[self.fSideMultipl, 0, 0], fUpVector=[0, self.fSideMultipl, 0])
            if sPrevJ != None:
                cmds.parent(sJ, sPrevJ)
            sPrevJ = sJ
        cmds.setAttr('%s.jo' % sJoints[-1], 0, 0, 0)

        self.fBlueprintsDiagonal = xforms.getJointHierarchyBoundingDiagonal(list(self.dBlueprints.values()))

    def _duplicateBlueprintJoints(self, sPostFix):
        if self.iSpineJointCount == self.iBlueprintCount:
            sSpineJoints = xforms.duplicateJoinChain(list(self.dBlueprints.values()), sPostfix=sPostFix,
                                                     sParent=self.sCurrentFeatureGrp)
        else:
            sSpineJoints = xforms.resampleJointChain2(list(self.dBlueprints.values()), self.iSpineJointCount,
                                                     sName='%s_spine_%s' % (self.sLimbName, sPostFix),
                                                     sParent=self.sCurrentFeatureGrp)
        return sSpineJoints

    def _createMiddleCtrls(self, sPrefix, fMiddlePercs, sJoints, sShape, sAttrs=['t'], iRotateOrder=0,
                           bOrientToCurve=False, bPivotCtrls=False, bSuperCtrls=False, bChildCtrls=False, fRotateShape=None, iColorIndex=0,
                           iOrientToNearestStraightMatrix=False, sParent=None, fOrientOffset=[0,0,0]):

        fSize = cmds.getAttr('%s.radius' % sJoints[0]) * 5

        sMiddleCtrlsBlueprintCurveTemp = curves.createCurveFromJoints(sJoints, iDegree=2,
                                                                      bFit=True)  # 2 if len(sJoints) > 3 else 1)
        aFirstMatrix = xforms.getNumpyMatrixFromTransform(list(self.dBlueprints.values())[0])

        if isinstance(fMiddlePercs, (int, float)):
            fMiddlePercs = (np.arange(fMiddlePercs, dtype='float64') + 1) / (fMiddlePercs + 1.0)

        aUps = [aFirstMatrix[1, 0:3] for i in range(len(fMiddlePercs))]
        sChest = list(self.dBlueprints.values())[-1]
        sHips = list(self.dBlueprints.values())[0]

        fPointsOnCurve = curves.getPointsFromPercs(sMiddleCtrlsBlueprintCurveTemp, fMiddlePercs, bReturnNumpy=True)
        if bOrientToCurve:
            fTangentsOnCurve = curves.getTangentsFromPercs(sMiddleCtrlsBlueprintCurveTemp, fMiddlePercs)
            iJointInds = xforms.findClosestJoints(fPointsOnCurve, list(self.dBlueprints.values()))
            aUps = []
            for i in range(len(fMiddlePercs)):
                aMatrix = xforms.getNumpyMatrixFromTransform(list(self.dBlueprints.values())[iJointInds[i]])
                aUp = aMatrix[1, 0:3]  # * self.fSideMultipl
                aUps.append(aUp)
        else:
            aBotTop = xforms.getPositionArray([sHips, sChest])
            aTangent = aBotTop[1] - aBotTop[0]
            aTangent /= np.linalg.norm(aTangent)
            fTangentsOnCurve = [aTangent] * len(fMiddlePercs)
        cmds.delete(sMiddleCtrlsBlueprintCurveTemp)

        cMiddles = []

        sTempMatch = cmds.createNode('transform')

        for i in range(len(fMiddlePercs)):
            sName = '%s%s' % (sPrefix[0].upper(), sPrefix[1:])
            if len(fMiddlePercs) > 1:
                sName = '%s_%s' % (sName, utils.getLetter(i))

            cmds.setAttr('%s.t' % sTempMatch, *fPointsOnCurve[i])

            xforms.orientThreePoints(sTempMatch, fTangentsOnCurve[i], aUps[i],
                                     fAimVector=[self.fSideMultipl, 0, 0])  # , fUpVector=[0,1,0])
            cM = self._createCtrl5(sName=sName,
                                  sMatch=sTempMatch, bPivot=bPivotCtrls, bSuper=bSuperCtrls, bChild=bChildCtrls,
                                  sAttrs=sAttrs,
                                  fSize=fSize *self.fCtrlSize, sShape=sShape, iRotateOrder=iRotateOrder,
                                  fRotateShape=fRotateShape, iColorIndex=iColorIndex, sParent=sParent)
            cmds.transformLimits(cM.sCtrl, sx=[0.01, 1000], esx=[True, False])
            cmds.transformLimits(cM.sCtrl, sy=[0.01, 1000], esy=[True, False])
            cmds.transformLimits(cM.sCtrl, sz=[0.01, 1000], esz=[True, False])

            cM.adjustAxisOrientation([0, -90, -90])
            cM.sRevScale = xforms.insertParent(cM.sOut, sName='%sNegScale' % cM.sOut, bMatchParentTransform=True)
            nodes.createVectorMultiplyNode([1,1,1], '%s.s' % cM.sCtrl,
                                           sOperation='divide', sTarget='%s.s' % cM.sRevScale)

            if np.any(fOrientOffset):
                cM.adjustAxisOrientation(list(fOrientOffset)) 

            if iOrientToNearestStraightMatrix == 1:
                cM.orientToNearestStraightMatrix()
            elif iOrientToNearestStraightMatrix == 2:
                cM.alignToWorldAxis(1,0)
                # if self.sLimbName == 'm_neck':
                #     cmds.select(cM.sPasser)
                #     ooo

            cMiddles.append(cM)
        cmds.delete(sTempMatch)

        return cMiddles


    def generateAttachers_ikSpline(self, **kwargs):

        # print '\n\n\ngenerateAttachers_ikSpline: .......'

        iMiddleCtrlCount = len(kwargs.get('fCtrlPercs', [0.33, 0.66]))
        bAttachMiddlesToLine = kwargs.get('bAttachMiddlesToLine', True)
        dAttachers = OrderedDict()

        ## removed this because it should be handled by root
        # dAttachers['base'] = {'sTrs': 'tr', 'bMulti': True}
        dAttachers['top'] = {'sTrs': 'tr', 'bMulti': True, 'sLocals': ['base'] if bAttachMiddlesToLine else []}

        for i in range(iMiddleCtrlCount):
            dAttachers['ikSplineMiddle_%s' % utils.getLetter(i)] = {'sTrs': 'tr', 'bMulti': True, 'sLocals': ['local', 'base', 'top'] if bAttachMiddlesToLine else []}

        return dAttachers


    def feature_ikSpline(self, bChest=False, fCtrlPercs=[0.33, 0.66], iCvsPerCtrl=0,
                         fCtrlOrient=[0, 0, 0],
                         bOffsetJoints=False,
                         iOrient=0,
                         iOrientToNearestStraightMatrixBase=0, iOrientToNearestStraightMatrixMiddle=0,
                         iOrientToNearestStraightMatrixTop=0, iStretchMode=0, bAttachMiddlesToLine=True, iRemoveEndCtrls=0, fUpAxis=[0,1,0],
                         bPostRefJoints=False, bAutoTangents=False,
                         _dComboboxItems={'iCvsPerCtrl': ['one', 'two', 'three', 'oneLastSimplified'],
                                          'iOrient': ['Line', 'Curve'],
                                          'iRemoveEndCtrls':['no', 'remove start and end', 'remove start', 'remove end'],
                                          # 'iAimEnds':['no', 'aim start and end', 'aim start', 'aim top'],
                                          'iStretchMode': sStretchModes,
                                          'iOrientToNearestStraightMatrixBase':['off', 'on', 'maintainWorldY'],
                                          'iOrientToNearestStraightMatrixMiddle':['off', 'on', 'maintainWorldY'],
                                          'iOrientToNearestStraightMatrixTop':['off', 'on', 'maintainWorldY']},
                         _dInterpolateBehavior={'fCtrlPercs': 1}):

        self.bAttachMiddlesToLine = bAttachMiddlesToLine

        self.fIkCtrlOrient = fCtrlOrient

        bOrientToCurve = True if iOrient else False
        self.bIkChest = bChest
        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        dAttacherBuildData = {}

        if np.any(self.fIkCtrlOrient):
            fRevRotateCtrlShape = [-self.fIkCtrlOrient[0], -self.fIkCtrlOrient[1], -self.fIkCtrlOrient[2]]
        else:
            fRevRotateCtrlShape = None
        self.ikSplineCtrlParent = self._createTransform('ikSplineCtrlParent', sParent=self.sCtrlsGlobal, fLocalPos=cmds.xform(self.dBlueprints['spine_000'], q=True, ws=True, t=True))

        sBp = list(self.dBlueprints.values())[0]
        self.cIkSplineBase = self._createCtrl5(sName='baseIk', sMatch=sBp, sAttrs=['t', 'r'],
                                 fSize=cmds.getAttr('%s.radius' % sBp) * 3, fScaleShape=(1, 0.3, 1), fRotateShape=fRevRotateCtrlShape,
                                 iColorIndex=self.iColorIndex,
                                 bPivot=True, bSuper=True, bChild=True, sParent=self.ikSplineCtrlParent)
        self.cIkSplineBase.adjustAxisOrientation([0, -90, -90])
        self.cIkSplineBase.sRevScale = xforms.insertParent(self.cIkSplineBase.sOut, sName='%sNegScale' % self.cIkSplineBase.sOut, bMatchParentTransform=True)
        nodes.createVectorMultiplyNode([1, 1, 1], '%s.s' % self.cIkSplineBase.sCtrl,
                                       sOperation='divide', sTarget='%s.s' % self.cIkSplineBase.sRevScale)

        # sBaseR = self.cIkSplineBase.appendOffsetGroup('baserotation')

        if np.any(self.fIkCtrlOrient):
            self.cIkSplineBase.adjustAxisOrientation(list(self.fIkCtrlOrient))
        if iOrientToNearestStraightMatrixBase == 1:
            self.cIkSplineBase.orientToNearestStraightMatrix()
        elif iOrientToNearestStraightMatrixBase == 2:
            self.cIkSplineBase.alignToWorldAxis(1, 0)



        sChestBlueprint = list(self.dBlueprints.values())[-2 if self.bIkChest else -1]
        sChestName = 'chestIk' if self.bIkChest else 'topIk'
        self.cIkSplineChest = self._createCtrl5(sName=sChestName, sMatch=sChestBlueprint, iColorIndex=self.iColorIndex,
                                  sAttrs=['t', 'r'], fSize=cmds.getAttr('%s.radius' % sBp) * 3, fRotateShape=fRevRotateCtrlShape,
                                  fScaleShape=(1*self.fCtrlSize, 0.3*self.fCtrlSize, 1*self.fCtrlSize), bSuper=True, bPivot=True, bChild=True, sParent=self.ikSplineCtrlParent)
        self.cIkSplineChest.adjustAxisOrientation([0, -90, -90])
        self.cIkSplineChest.sRevScale = xforms.insertParent(self.cIkSplineChest.sOut, sName='%sNegScale' % self.cIkSplineChest.sOut, bMatchParentTransform=True)
        nodes.createVectorMultiplyNode([1, 1, 1], '%s.s' % self.cIkSplineChest.sCtrl,
                                       sOperation='divide', sTarget='%s.s' % self.cIkSplineChest.sRevScale)

        if np.any(self.fIkCtrlOrient):
            self.cIkSplineChest.adjustAxisOrientation(list(self.fIkCtrlOrient))
        if iOrientToNearestStraightMatrixTop == 1:
            self.cIkSplineChest.orientToNearestStraightMatrix()
        elif iOrientToNearestStraightMatrixTop == 2:
            self.cIkSplineChest.alignToWorldAxis(1, 0)

        # creating middle controls
        #
        cMiddles = self._createMiddleCtrls('midIk', fCtrlPercs,
                                           list(self.dBlueprints.values())[0:-1 if self.bIkChest else None], 'squareY',
                                           iRotateOrder=2,
                                           iOrientToNearestStraightMatrix=iOrientToNearestStraightMatrixMiddle,
                                           sAttrs=['t', 'r'], iColorIndex=self.iColorIndex,
                                           bOrientToCurve=bOrientToCurve, bPivotCtrls=True, bChildCtrls=True,
                                           fRotateShape=fRevRotateCtrlShape, sParent=self.ikSplineCtrlParent, fOrientOffset=self.fIkCtrlOrient)

        self.cIkSplineCtrls = [self.cIkSplineBase] + cMiddles + [self.cIkSplineChest] # for the unreal rig


        cmds.controller(cMiddles[0].sCtrl, self.cIkSplineBase.sCtrl, parent=True)
        if len(cMiddles) > 1:
            for c, cM in enumerate(cMiddles):
                if c > 0:
                    cmds.controller(cM.sCtrl, cMiddles[c - 1].sCtrl, parent=True)

        cmds.controller(self.cIkSplineChest.sCtrl, cMiddles[-1].sCtrl, parent=True)

        # attaching middle controls
        #
        sMiddleAimGrp = self._createTransform('middleAimIk', sParent=self.cIkSplineBase.sOut, fLocalPos=(0, 0, 0))
        self.sIkSplineMiddleAimScaledGrp = self._createTransform('middleAimScaledIk', sParent=self.cIkSplineBase.sOut, fLocalPos=(0, 0, 0))
        sMiddleUpGrp = self._createTransform('middleUpIk', sParent=list(self.dBlueprints.values())[0], fLocalPos=(0, 0, -1))
        cmds.parent(sMiddleUpGrp, self.cIkSplineBase.sOut)
        # cmds.aimConstraint(self.cIkSplineChest.sOut, sMiddleAimGrp, aim=[1, 0, 0], wu=(0, 0, -1), wut='object', wuo=sMiddleUpGrp)
        constraints.aimConstraintFromTransforms(sMiddleAimGrp, self.cIkSplineChest.sOut, sMiddleUpGrp, sParent=self.sCurrentFeatureGrp)

        sAimLocalPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(self.cIkSplineChest.sOut),
                                                       '%s.worldInverseMatrix' % sMiddleAimGrp)
        cmds.connectAttr('%s.r' % sMiddleAimGrp, '%s.r' % self.sIkSplineMiddleAimScaledGrp)
        nodes.createMultiplyNode('%sX' % sAimLocalPoint, 1.0 / cmds.getAttr('%sX' % sAimLocalPoint),
                                 sTarget='%s.sx' % self.sIkSplineMiddleAimScaledGrp)

        for m, cM in enumerate(cMiddles):
            sA = 'ikSplineMiddle_%s' % utils.getLetter(m)
            dAttacherBuildData[sA] = (utils.getDagPath(cM.sPasser), cM)
            if self.bAttachMiddlesToLine:
                self.dLocalAttacherOutputs[sA] = ['local.%s' % self.sIkSplineMiddleAimScaledGrp, 'base.%s' % self.cIkSplineBase.sOut, 'top.%s' % self.cIkSplineChest.sOut]
                # self.dLocalAttacherOutputs[sA] = ['local.%s' % self.sIkSplineMiddleAimScaledGrp, 'base.%s' % self.cIkSplineBase.sOut, 'topT.%s' % self.cIkSplineChest.sOut]



        cCtrls = [self.cIkSplineBase] + cMiddles + [self.cIkSplineChest]

        # create spline setup
        #
        # if iAimEnds in [1,2]:
        #     self.cIkSplineBase.sOut = self._createTransform('baseAim', sParent=self.cIkSplineBase.sOut)
        #     cmds.aimConstraint(cMiddles[0].sCtrl, self.cIkSplineBase.sOut, wut='objectrotation', aim=[self.fSideMultipl,0,0], wuo=self.cIkSplineBase.sCtrl, wu=[0,0,self.fSideMultipl])#, u=[0,0,1])
        #
        # if iAimEnds in [1,3]:
        #     self.cIkSplineChest.sOut = self._createTransform('chestAim', sParent=self.cIkSplineChest.sOut)
        #     cmds.aimConstraint(cMiddles[-1].sCtrl, self.cIkSplineChest.sOut, wut='objectrotation', aim=[-self.fSideMultipl,0,0], wuo=self.cIkSplineChest.sCtrl, wu=[0,0,self.fSideMultipl])#, u=[0,0,1])

        # if bTangentCtrls:
        cTangentBase = self._createCtrl5(sName='baseIkTangent', sMatch=self.cIkSplineBase.sOut,
                                         sAttrs=['r', 'sx'], sShape='orient',
                                         fSize=cmds.getAttr('%s.radius' % sBp) * 3,# fRotateShape=(0, -90, 0),
                                         iColorIndex=1, sParent=self.cIkSplineBase.sOut, bChild=True)
        self.cIkSplineBase.sTangent = cTangentBase.sOut
        cTangentChest = self._createCtrl5(sName='chestIkTangent', sMatch=self.cIkSplineChest.sOut,
                                         sAttrs=['r', 'sx'], sShape='orient',
                                         fSize=cmds.getAttr('%s.radius' % sBp) * 3, fRotateShape=(0, 180, 0),
                                         iColorIndex=1, sParent=self.cIkSplineChest.sOut, bChild=True)

        if bAutoTangents:
            cAimCtrls = [cTangentBase] + cMiddles + [cTangentChest]
            sChildAims = [xforms.insertParent(cC.sChild, utils.replaceStringEnd(cC.sPasser, 'Passer', 'autoTangents')) for cC in cAimCtrls]
            for c,cC in enumerate(cAimCtrls):
                sAimAttr = utils.addAttr(cC.sCtrl, ln='autoTangents', min=0, max=1, dv=1, k=True)
    
                if c == 0:
                    sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(cAimCtrls[c+1].sCtrl), '%s.worldInverseMatrix' % cC.sSlider)
                elif c == len(cAimCtrls) - 1:
                    sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(cAimCtrls[c-1].sCtrl), '%s.worldInverseMatrix' % cC.sSlider)
                else:
                    sAimTargetA = nodes.createPointByMatrixNode(nodes.getWorldPoint(cAimCtrls[c+1].sCtrl), '%s.worldInverseMatrix' % cC.sSlider)
                    sAimTargetB = nodes.createPointByMatrixNode(nodes.getWorldPoint(cAimCtrls[c-1].sCtrl), '%s.worldInverseMatrix' % cC.sSlider)
                    sAimTarget = nodes.createVectorAdditionNode([sAimTargetA, sAimTargetB], sOperation='minus')

                fAimTarget = cmds.getAttr(sAimTarget)[0]
                iAimAxis = np.argmax(fAimTarget)
                fSign = -1.0 if fAimTarget[iAimAxis] < 0.0 else 1.0
                fAim, fUp = [0,0,0], [0,0,0]
                fAim[iAimAxis] = fSign
                fUp[(iAimAxis+1) % 3] = fSign
                constraints.aimConstraintFromLocalPoints(sChildAims[c], sAimTarget, aim=fAim, up=fUp, mo=True, sParent=self.sCurrentFeatureGrp, sBlend=sAimAttr)
                

        
        
        self.cIkSplineChest.sTangent = cTangentChest.sOut
        utils.addOffOnAttr(self.cIkSplineBase.sCtrl, 'tangentCtrlVis', bDefaultValue=False, sTarget='%s.v' % cTangentBase.sPasser)
        utils.addOffOnAttr(self.cIkSplineChest.sCtrl, 'tangentCtrlVis', bDefaultValue=False, sTarget='%s.v' % cTangentChest.sPasser)

        sSplineTransforms = [cC.sTangent if hasattr(cC, 'sTangent') else cC.sOut for cC in cCtrls]

        sInfluences, sJoints, sCurve, _ = self._createGeneralSplineSetup('ikSpline',
                                                                 sSplineTransforms,
                                                                  iExtraCvsPerCtrl=iCvsPerCtrl,
                                                                  bOffsetJoints=bOffsetJoints,
                                                                  # sStraightCtrlsPerTransform=None,
                                                                  sAttrsCtrl=self.cIkSplineChest.sCtrl,
                                                                  iStretchMode=iStretchMode,
                                                                  fUpAxis=fUpAxis, sLastTransform=self.cIkSplineChest.sOut)
        if bPostRefJoints:
            sRefTransforms = []
            for c, cC in enumerate(cCtrls):
                sParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
                sRefTransform = cmds.createNode('transform', n=self._createNodeName('ref', 'transform', c), p=sParent)
                cmds.delete(cmds.parentConstraint(cC.sOut, sRefTransform))
                sRefTransforms.append(sRefTransform)

            sInfluencesRef, sJointsRef, sCurveRef, _ = self._createGeneralSplineSetup('ikSplineRef',
                                                                      sRefTransforms,
                                                                      iExtraCvsPerCtrl=iCvsPerCtrl,
                                                                      bOffsetJoints=bOffsetJoints,
                                                                      # sStraightCtrlsPerTransform=None,
                                                                      sAttrsCtrl=self.cIkSplineChest.sCtrl,
                                                                      iStretchMode=iStretchMode,
                                                                      fUpAxis=fUpAxis)
            for sJ, sRefJ in zip(sJoints, sJointsRef):
                utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)

        if iCvsPerCtrl != 0:
            for sI, cC in zip(sInfluences, cCtrls):
                sSharp = utils.addAttr(cC.sCtrl, ln='sharp', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
                cmds.select(sI)
                nodes.createRangeNode(sSharp, 0, 1, [1,1,1], [0.01, 0.01, 0.01], bOutRangeIsVector=True, sTarget='%s.s' % sI, bForce=True)

        sOuts = sJoints
        dAttacherBuildData['root'] = (utils.getDagPath(self.ikSplineCtrlParent), self.cIkSplineBase)
        # dAttacherBuildData['base'] = (utils.getDagPath(self.cIkSplineBase.sPasser), self.cIkSplineBase) # should be the same as root -> not useful
        dAttacherBuildData['top'] = (utils.getDagPath(self.cIkSplineChest.sPasser), self.cIkSplineChest)
        if self.bAttachMiddlesToLine:
            self.dLocalAttacherOutputs['top'] = ['base.%s' % self.cIkSplineBase.sOut]

        # scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)

        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.ikSplineCtrlParent)
        # for cCtrl in [self.cIkSplineBase] + cMiddles + [self.cIkSplineChest]:
        #     cmds.scaleConstraint(self.sCurrentFeatureGrp, cCtrl.sPasser)


        sMiddleCtrlsParent = self._createTransform('middleCtrlsParent', sParent=cmds.listRelatives(self.cIkSplineBase.sPasser, p=True)[0])
        if not self.bAttachMiddlesToLine:
            for cM in cMiddles:
                cmds.parent(cM.sPasser, sMiddleCtrlsParent)
        constraints.matrixParentConstraint(self.cIkSplineBase.sPasser, sMiddleCtrlsParent, mo=True)


        # match stuff
        sMatchScript = ''
        cOrderedCtrls =  [self.cIkSplineBase] + [self.cIkSplineChest] + cMiddles
        iClosestOuts = xforms.findClosestJoints(xforms.getPositionArray([cC.sCtrl for cC in cOrderedCtrls]), sOuts)
        for c, cC in enumerate(cOrderedCtrls):
            sMatchScript += match.generateMatchingConstrainCommand(iClosestOuts[c], sOuts, cC.sCtrl,
                                                                   iConstraintType=match.Type.parentConstraint,
                                                                   bOffsetR=True, bOffsetT=True)
        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)


        # root output
        sRootOut = self._createTransform('root_ikSpline', sParent=self.sCurrentFeatureGrp, sMatch=sOuts[0])
        constraints.matrixParentConstraint(self.cIkSplineBase.sOut, sRootOut, mo=True, skipScale=[])
        sOuts.insert(0, sRootOut)

        self.cDynamicBakeCtrls += cCtrls

        if iRemoveEndCtrls in [1,2]:
            cCtrls[0].convertToSimpleTransforms()
            cCtrls = cCtrls[1:]
        if iRemoveEndCtrls in [1,3]:
            cCtrls[-1].convertToSimpleTransforms()
            cCtrls = cCtrls[:-1]

        # self.dCtrlReplacements[self.getOutputFullNames()[0]] = self.cIkSplineBase.sCtrl
        # self.dCtrlReplacements[self.getOutputFullNames()[-1]] = self.cIkSplineChest.sCtrl

        return sOuts, cCtrls, dAttacherBuildData



    def generateAttachers_fkSpline(self, **kwargs):

        iMiddleCtrlCount = len(kwargs.get('fCtrlPercs', [0.33, 0.66]))
        dAttachers = OrderedDict()

        for i in range(iMiddleCtrlCount):
            dAttachers['fkSpline_%s' % utils.getLetter(i)] = {'sTrs': 'tr', 'bMulti': True, 'sLocals': ['base'] if i == 0 else ['local', 'base']}

        return dAttachers




    def feature_fkSpline(self,
                         bTranslation=True, fCtrlPercs=[0.25, 0.5, 0.75], bOffsetJoints=False, bPostCtrls=False,
                         fPostHipsPerc=0.3, fPostArcPerc=0.5,
                         iOrient=0, iOrientToNearestStraightMatrix=0,
                         iStretchMode=0, fUpAxis=[0,1,0],
                         _dComboboxItems={'iStretchMode':sStretchModes,
                                          'iOrient': ['Line', 'Curve'],
                                          'iOrientToNearestStraightMatrix':['off', 'on', 'maintainWorldY']},
                         _dInterpolateBehavior={'fCtrlPercs': 1}):


        bOrientToCurve = True if iOrient else False
        dAttacherBuildData = {}

        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        fCtrlPercs = list(fCtrlPercs)


        # self.fkSplineCtrlParent = self._createTransform('fkSplineCtrlParent', sParent='ctrls', sMatch=self.dBlueprints['spine_000'])
        self.fkSplineCtrlParent = self._createTransform('fkSplineCtrlParent', sParent=self.sCtrlsGlobal, fLocalPos=cmds.xform(self.dBlueprints['spine_000'], q=True, ws=True, t=True))


        # creating middle controls
        #
        sAttrs = ['r']
        if bTranslation: sAttrs.append('t')
        self.cFkSplineMiddles = self._createMiddleCtrls('splineFk', fCtrlPercs,
                                           list(self.dBlueprints.values()),
                                           'circleY', bOrientToCurve=bOrientToCurve, sAttrs=sAttrs, bSuperCtrls=True, bChildCtrls=True, bPivotCtrls=True,
                                           iRotateOrder=2, iColorIndex=self.iColorIndex, iOrientToNearestStraightMatrix=iOrientToNearestStraightMatrix, sParent=self.fkSplineCtrlParent)

        self.cFkSplineBase = self._createMiddleCtrls('Base', [0.0], list(self.dBlueprints.values()), 'circleY', iRotateOrder=2, bChildCtrls=True,
                                        iColorIndex=self.iColorIndex, bPivotCtrls=True, bOrientToCurve=bOrientToCurve, bSuperCtrls=True,
                                        sAttrs=['t', 'r'], iOrientToNearestStraightMatrix=iOrientToNearestStraightMatrix, sParent=self.fkSplineCtrlParent)[0]


        for c,cCtrl in enumerate(self.cFkSplineMiddles):
            sA = 'fkSpline_%s' % utils.getLetter(c)
            # sAttacherOffset = cCtrl.appendOffsetGroup('attacher')
            dAttacherBuildData[sA] = (utils.getDagPath(cCtrl.sPasser), cCtrl)

            cPrev = self.cFkSplineMiddles[c-1] if c > 0 else self.cFkSplineBase
            
            if c == 0:
                self.dLocalAttacherOutputs[sA] = ['base.%s' % self.cFkSplineBase.sOut]
            else:
                self.dLocalAttacherOutputs[sA] = ['local.%s' % cPrev.sOut, 'base.%s' % self.cFkSplineBase.sOut]


        sEndTransform = self._createTransform('endTransform', sParent=self.cFkSplineMiddles[-1].sOut)
        cmds.delete(cmds.pointConstraint(list(self.dBlueprints.values())[-1], sEndTransform))

        cCtrls = [self.cFkSplineBase] + list(self.cFkSplineMiddles)
        self.cDynamicBakeCtrls += [self.cFkSplineBase] + list(self.cFkSplineMiddles)
        # attaching middle controls
        #
        # for c, cC in enumerate(cCtrls[:-1]):
        #     constraints.matrixParentConstraint(cC.sOut, cCtrls[c + 1].sPasser, mo=True, skipScale=['x', 'y', 'z'])

        for c in range(len(cCtrls)):
            if c > 0:
                cmds.controller(cCtrls[c].sCtrl, cCtrls[c - 1].sCtrl, parent=True)

        # create spline setup
        #
        sTransforms = [cC.sOut for cC in cCtrls] + [sEndTransform]

        sInfluences, sJoints, sCurve, sIkHandle = self._createGeneralSplineSetup('fkSpline',
                                                                          sTransforms,
                                                                          iExtraCvsPerCtrl=0,
                                                                          bOffsetJoints=bOffsetJoints,
                                                                          sAttrsCtrl=self.cFkSplineMiddles[-1].sCtrl,
                                                                          iCurveDegree=2, iStretchMode=iStretchMode,
                                                                          fUpAxis=fUpAxis)

        # # for unreal:
        # fJointPercs = curves.getPercsFromTransforms(sCurve, sJoints)
        # xCtrlWeightings = xforms.getCtrlWeightings(fJointPercs, fCtrlPercs)
        # utils.addStringAttr(self.sCurrentFeatureGrp, 'xCtrlWeightings', xCtrlWeightings)

        self.cFkSplineCtrls = list(cCtrls)

        if bPostCtrls:
            pCurve = patch.patchFromName(sCurve)
            cHips = \
            self._createMiddleCtrls('hipsFk', [fPostHipsPerc], list(self.dBlueprints.values()), 'squareY', iRotateOrder=2,
                                    iColorIndex=1, bPivotCtrls=False, bOrientToCurve=bOrientToCurve,
                                    sAttrs=['t', 'r'], iOrientToNearestStraightMatrix=iOrientToNearestStraightMatrix)[0]

            cHips.cLocal = self._createCtrl5(sName='hipsFkLocal', sMatch=cHips.sCtrl, sAttrs=sAttrs,
                                            sShape='squareY', iRotateOrder=2, iColorIndex=self.iColorIndex,
                                            bIsNoCtrl=True, sParent=self.sCurrentFeatureGrp)

            cArch = \
            self._createMiddleCtrls('archFk', [fPostArcPerc], list(self.dBlueprints.values()), 'squareY', iRotateOrder=2,
                                    iColorIndex=1, bPivotCtrls=False, bOrientToCurve=bOrientToCurve,
                                    sAttrs=['t', 'r'], iOrientToNearestStraightMatrix=iOrientToNearestStraightMatrix)[0]
            cArch.cLocal = self._createCtrl5(sName='archFkLocal', sMatch=cArch.sCtrl, sAttrs=sAttrs,
                                            sShape='squareY', iRotateOrder=2,
                                            bIsNoCtrl=True, sParent=self.sCurrentFeatureGrp,
                                            iColorIndex=self.iColorIndex)

            cmds.setAttr('%s.inheritsTransform' % cHips.cLocal.sPasser, False)
            cmds.setAttr('%s.inheritsTransform' % cArch.cLocal.sPasser, False)

            sZeroJoint = cmds.createNode('joint', n=self._createNodeName('postHipZero', 'jnt'), p=cHips.cLocal.sPasser)
            sPostHipJoint = cmds.createNode('joint', n=self._createNodeName('postHip', 'jnt'), p=cHips.cLocal.sOut)
            sPostArchJoint = cmds.createNode('joint', n=self._createNodeName('postArch', 'jnt'), p=cArch.cLocal.sOut)

            sPostSkinCluster = deformers.skinMesh(sCurve, [sPostHipJoint, sPostArchJoint, sZeroJoint],
                                                  bAlwaysAddDefaultWeights=True, sName='skinCluster__postHip',
                                                  bFoc=True, _bSkipDeformerAdjustLogging=True)
            aCvPoints = pCurve.getAllPoints()

            iCvLength = len(aCvPoints)
            aWeights2d = np.zeros((iCvLength, 3), dtype='float64')

            iEndNoArchCvCount = 4
            aWeights2d[np.arange(2), 0] = 1.0
            aWeights2d[np.arange(2, iCvLength - iEndNoArchCvCount, 1), 1] = 1.0
            aWeights2d[np.arange(iCvLength - iEndNoArchCvCount, iCvLength), 2] = 1.0
            aOldWeights2d = np.copy(aWeights2d)

            aKeepInds = np.concatenate([np.array([0, 1]),
                                        np.arange(-iEndNoArchCvCount, 0, 1)])

            for i in range(2):
                aWeights2d = pCurve.smoothValues2d(aWeights2d, iIterations=1)
                aWeights2d[aKeepInds] = aOldWeights2d[aKeepInds]

            pCurve.setSkinClusterWeights(aWeights2d, sChooseSkinCluster=sPostSkinCluster, _bSkipDeformerAdjustLogging=True)

            constraints.matrixParentConstraint(cCtrls[0].sOut, cHips.sPasser, mo=True)
            cmds.connectAttr('%s.t' % cHips.sCtrl, '%s.t' % cHips.cLocal.sCtrl)
            cmds.connectAttr('%s.r' % cHips.sCtrl, '%s.r' % cHips.cLocal.sCtrl)

            constraints.matrixParentConstraint(cCtrls[-2].sOut, cArch.sPasser, mo=True)
            cmds.connectAttr('%s.t' % cArch.sCtrl, '%s.t' % cArch.cLocal.sCtrl)
            cmds.connectAttr('%s.r' % cArch.sCtrl, '%s.r' % cArch.cLocal.sCtrl)

            if sIkHandle:
                cmds.connectAttr('%s.worldMatrix' % cHips.sOut, '%s.dWorldUpMatrix' % sIkHandle, force=True)

        sOuts = sJoints

        dAttacherBuildData['root'] = (utils.getDagPath(self.fkSplineCtrlParent), cCtrls[0])
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        # for cCtrl in cCtrls:
        #     cmds.scaleConstraint(self.sCurrentFeatureGrp, cCtrl.sPasser)

        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.fkSplineCtrlParent)


        # match stuff
        sMatchScript = ''
        iClosestOuts = xforms.findClosestJoints(xforms.getPositionArray([cC.sCtrl for cC in cCtrls]), sOuts)
        for c, cC in enumerate(cCtrls):
            sMatchScript += match.generateMatchingConstrainCommand(iClosestOuts[c], sOuts, cC.sCtrl,
                                                                   iConstraintType=match.Type.parentConstraint,
                                                                   bOffsetR=True, bOffsetT=True)
        if bPostCtrls:
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.tx', 0)" % cHips.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.ty', 0)" % cHips.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.tz', 0)" % cHips.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.rx', 0)" % cHips.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.ry', 0)" % cHips.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.rz', 0)" % cHips.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.tx', 0)" % cArch.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.ty', 0)" % cArch.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.tz', 0)" % cArch.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.rx', 0)" % cArch.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.ry', 0)" % cArch.sCtrl
            sMatchScript += "\nsetAttr(NAMESPACE, '%s.rz', 0)" % cArch.sCtrl

        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)


        if bPostCtrls:
            cCtrls += [cHips, cArch]
            self.dTwistCtrlIndicesDistr['feature_fkSpline'] = [-2, -3]  # from hips (-2) to top (-3)
            self.dTwistCtrlIndices['feature_fkSpline'] = list(range(len(cCtrls)))

            self.dScaleCtrlIndices['feature_fkSpline'] = list(range(len(cCtrls) - 2))
        else:
            self.dTwistCtrlIndicesDistr['feature_fkSpline'] = [0, -1]
            self.dTwistCtrlIndices['feature_fkSpline'] = list(range(len(cCtrls)))
            self.dScaleCtrlIndices['feature_fkSpline'] = list(range(len(cCtrls)))

        # root output
        sRootOut = self._createTransform('root_fkSpline', sParent=self.sCurrentFeatureGrp, sMatch=sOuts[0])

        if bPostCtrls:
            # scale
            constraints.matrixParentConstraint(cCtrls[0].sPasser, sRootOut, mo=True, skipRotate=['x', 'y', 'z'],
                                          skipTranslate=['x', 'y', 'z'],
                                          skipScale=[])  # just scale. before it was: rotation and scale
            # translate
            constraints.matrixParentConstraint(cHips.sCtrl, sRootOut, mo=True, skipRotate=['x', 'y', 'z'],
                                          skipScale=['x', 'y', 'z'])  # position


            # rotate
            fHipsInPasserMatrix = nodes.createMultMatrixNode(
                ['%s.worldMatrix' % cHips.sOut, '%s.worldInverseMatrix' % cCtrls[0].sPasser], bJustValues=True)
            sDefaultHipsInPasserMatrix = nodes.createMultMatrixNode(
                [fHipsInPasserMatrix, '%s.worldMatrix' % cCtrls[0].sPasser])
            sHipTwist = xforms.twistDetector(cHips.sOut, sDefaultHipsInPasserMatrix)
            sTwistedMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xRotate=[sHipTwist, 0, 0]),
                                                         fHipsInPasserMatrix,
                                                         '%s.worldMatrix' % cCtrls[0].sPasser,
                                                         '%s.parentInverseMatrix' % sRootOut])
            sSwingMatrix = '%s.worldMatrix' % cHips.sOut
            sPropagateSwingAttr = utils.addAttr(cHips.sCtrl, ln='propagateSwing', minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True)
            sBlendedMatrix = nodes.createBlendMatrixNode([sTwistedMatrix, sSwingMatrix],
                                                         [nodes.createReverseNode(sPropagateSwingAttr), sPropagateSwingAttr])
            nodes.createDecomposeMatrix(sBlendedMatrix, sTargetRot='%s.r' % sRootOut)

        else:
            constraints.matrixParentConstraint(cCtrls[0].sPasser, sRootOut, mo=True, skipTranslate=['x', 'y', 'z'],
                                          skipScale=[])  # rotation and scale
            constraints.matrixParentConstraint(self.cFkSplineBase.sCtrl, sRootOut, mo=True, skipRotate=['x', 'y', 'z'],
                                          skipScale=['x', 'y', 'z'])  # position

        # self.dCtrlReplacements[self.getOutputFullNames()[0]] = self.cFkSplineBase.sCtrl
        # self.dCtrlReplacements[self.getOutputFullNames()[-1]] = self.cFkSplineMiddles[-1].sCtrl

        sOuts.insert(0, sRootOut)
        return sOuts, cCtrls, dAttacherBuildData


    def unreal_feature_ikSpline(self):
    
        sCommands = []
        utils.data.addToList(utilsUnreal.kUnrealControlReplacements,
                             [(self.getOutputFullNames()[0], self.cIkSplineBase.sCtrl),
                              (self.getOutputFullNames()[-1], self.cIkSplineChest.sCtrl)])
        
        self.eIkSplineOriginStr = '%s_ikSpline_origin' % (self.sLimbName)
        sCommands.append("%s = hierarchy.createNull('%s_fkSpline_origin')" % (self.eIkSplineOriginStr, self.sLimbName))

        cStrControls, sIkCommands = utilsUnreal.createFkChainCtrls(self.cIkSplineCtrls, bAllUnderRoot=True, fCtrlOrient=self.fIkCtrlOrient, sParentVar=self.eIkSplineOriginStr)
        sCommands += sIkCommands
        if self.bIkChest:
            sEndNull, sCreateNullCommand = utilsUnreal.createUnrealNull('grp_%s_end' % self.sLimbName, list(self.dBlueprints.values())[-1], sParentVariable='%s.eOut' % cStrControls[-1])
            sCommands.append(sCreateNullCommand)
        else:
            sEndNull = 'None'


        if self.bAttachMiddlesToLine:
            eStrMiddleScale = 'eMiddleScale_%s' % self.sLimbName
            sCommands.append(utilsUnreal.createUnrealNull(eStrMiddleScale, self.sIkSplineMiddleAimScaledGrp, self.eIkSplineOriginStr)[1])
            
            
        sOutputJoints = self.getOutputFullNames()[1:]
        if self.bRemoveEndSkinJoint:
            sOutputJoints = sOutputJoints[:-1]
        sJoints = ', '.join(["'%s'" % sJ for sJ in sOutputJoints])

        sWeightingsAttr = '%s.xCtrlWeightings' % self.sCurrentFeatureGrp
        if not cmds.objExists(sWeightingsAttr):
            raise Exception('Attribute "xCtrlWeightings" doesn\'t exist for %s - Stretch Mode may need to get set to curveInfo nodes' % self.sLimbName)

        sCtrlWeightings = cmds.getAttr(sWeightingsAttr)

        aUpLocal4 = np.array([0,1,0,1], dtype='float64')
        aOutMatrix = utils.getNumpyMatrixFromTransform(self.cIkSplineCtrls[0].sOut)
        aUp4 = np.dot(aUpLocal4, aOutMatrix)
        aCtrlMatrix = utils.getNumpyMatrixFromTransform(self.cIkSplineCtrls[0].sCtrl)
        aUpLocalCtrl = np.dot(aUp4, np.linalg.inv(aCtrlMatrix))[0:3]

        sCommands.extend(utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_ikSpline'))
        sFunctionNodeName = '%s_feature_ikSpline_node' % self.sLimbName
        if self.bAttachMiddlesToLine:
            fMiddleDistane = xforms.distanceBetween(self.cIkSplineCtrls[0].sCtrl, self.cIkSplineCtrls[-1].sCtrl)
        else:
            fMiddleDistane = 0
            
        sCommands.append("%s = functions.createIkSplineFunction(%s, cCtrls=[%s], eMiddle=%s, fMiddleDistance=%0.3f, \n\t\tsJoints=[%s], \n\t\tsSide='%s', xCtrlWeightings=%s, eEndNull=%s, fUpVector=%s)" %
                         (sFunctionNodeName, self.eIkSplineOriginStr, ', '.join(cStrControls), eStrMiddleScale, fMiddleDistane, sJoints, self.sSide, sCtrlWeightings, sEndNull, utilsUnreal.flipVectorToUnreal(list(aUpLocalCtrl))))

        sCommands.extend(utilsUnreal.initiateAttacherDictCommand('feature_ikSpline'))
        if self.bAttachMiddlesToLine:
            for c, cStrCtrl in enumerate(cStrControls[1:-1]):
                sCommands.append("dAttachers_feature_ikSpline['ATTACHER_ikSplineMiddle_%s_r'].extend([%s, %s.eControl, %s.eControl])" % (utils.getLetter(c), eStrMiddleScale, cStrControls[0], cStrControls[-1]))
                sCommands.append("dAttachers_feature_ikSpline['ATTACHER_ikSplineMiddle_%s_t'].extend([%s, %s.eControl, %s.eControl])" % (utils.getLetter(c), eStrMiddleScale, cStrControls[0], cStrControls[-1]))
            sCommands.append("dAttachers_feature_ikSpline['ATTACHER_top_r'].extend([%s.eControl])" % (cStrControls[0]))
            sCommands.append("dAttachers_feature_ikSpline['ATTACHER_top_t'].extend([%s.eControl])" % (cStrControls[0]))
        sCommands.extend(utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_ikSpline', sFunctionNodeName))

        return sCommands, [], []
    

    def unreal_feature_fkSpline(self):

        sCommands = []
        # sCommands.extend(utilsUnreal.createKey_createCustomAttacherTransforms(self.sLimbName))

        self.eFkSplineOriginStr = '%s_fkSpline_origin' % (self.sLimbName)
        sCommands.append("%s = hierarchy.createNull('%s_fkSpline_origin')" % (self.eFkSplineOriginStr, self.sLimbName))
        cStrControls, sFkCommands = utilsUnreal.createFkChainCtrls(self.cFkSplineCtrls, sParentVar=self.eFkSplineOriginStr)
        sCommands += sFkCommands
        sEndNull, sCreateNullCommand = utilsUnreal.createUnrealNull('grp_%s_end' % self.sLimbName, list(self.dBlueprints.values())[-1], sParentVariable='%s.eOut' % cStrControls[-1])
        sCommands.append(sCreateNullCommand)

        # sJoints = [self.dDetailReplacements.get(sJ, sJ) for sJ in self.getOutputFullNames()[1:]]
        # xxCtrlBonePairs = "[%s]" % ','.join(["(%s, '%s')" % (sC, sJ) for sC, sJ in zip(cStrControls, sJoints)])



        sOutputJoints = self.getOutputFullNames()[1:]
        if self.bRemoveEndSkinJoint:
            sOutputJoints = sOutputJoints[:-1]
        sJoints = ', '.join(["'%s'" % sJ for sJ in sOutputJoints])

        sWeightingsAttr = '%s.xCtrlWeightings' % self.sCurrentFeatureGrp
        if not cmds.objExists(sWeightingsAttr):
            raise Exception('Attribute "xCtrlWeightings" doesn\'t exist for %s - Stretch Mode may need to get set to curveInfo nodes' % self.sLimbName)


        sCtrlWeightings = cmds.getAttr(sWeightingsAttr)

        aUpLocal4 = np.array([0,1,0,1], dtype='float64')
        aOutMatrix = utils.getNumpyMatrixFromTransform(self.cFkSplineCtrls[0].sOut)
        aUp4 = np.dot(aUpLocal4, aOutMatrix)
        aCtrlMatrix = utils.getNumpyMatrixFromTransform(self.cFkSplineCtrls[0].sCtrl)
        aUpLocalCtrl = np.dot(aUp4, np.linalg.inv(aCtrlMatrix))[0:3]

        sCommands.extend(utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fkSpline'))
        sFunctionNodeName = '%s_feature_fkSpline_node' % self.sLimbName
        sCommands.append("%s = functions.createFkSplineFunction(%s, cCtrls=[%s], \n\t\tsJoints=[%s], \n\t\tsSide='%s', xCtrlWeightings=%s, eEndNull=%s, fUpVector=%s)" %
                         (sFunctionNodeName, self.eFkSplineOriginStr, ', '.join(cStrControls), sJoints, self.sSide, sCtrlWeightings, sEndNull, utilsUnreal.flipVectorToUnreal(list(aUpLocalCtrl))))

        sCommands.extend(utilsUnreal.initiateAttacherDictCommand('feature_fkSpline'))
        for c,cStrCtrl in enumerate(cStrControls):
            if c == 0:
                pass
            else:
                sCommands.append("dAttachers_feature_fkSpline['ATTACHER_fkSpline_%s_r'].extend([%s.eControl, %s.eControl])" % (utils.getLetter(c-1), cStrControls[c-1], cStrControls[0]))
                sCommands.append("dAttachers_feature_fkSpline['ATTACHER_fkSpline_%s_t'].extend([%s.eControl, %s.eControl])" % (utils.getLetter(c-1), cStrControls[c-1], cStrControls[0]))
        sCommands.extend(utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fkSpline', sFunctionNodeName))

        return sCommands, [], []




    def unrealBackwards_feature_fkSpline(self):

        sCommands = []
        # sCommands.extend(utilsUnreal.createKey_createCustomAttacherTransforms(self.sLimbName))

        sJoints = [self.dDetailReplacements.get(sJ,sJ) for sJ in self.getOutputFullNames()[1:]]

        sCtrls = [cC.sCtrl for cC in self.cFkSplineCtrls]
        aClosestJoints = xforms.findClosestJoints(xforms.getPositionArray(sCtrls), sJoints)

        sCtrlJoints = np.array(sJoints)[aClosestJoints]

        xxCtrlBonePairs = "[%s]" % ','.join(["(%s, '%s')" % (sC,sJ) for sC,sJ in zip(sCtrls, sCtrlJoints)])

        sCommands.extend(utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fkSpline'))

        sFunctionNodeName = '%s_feature_fkSpline_node' % self.sLimbName
        sCommands.append("%s = functions.createFkChainCtrlsSetupBACKWARDS(library.getElementKey('%s', 'Null'), %s, bSpline=True)" % (sFunctionNodeName, self.eFkSplineOriginStr, xxCtrlBonePairs))
        sCommands.extend(utilsUnreal.initiateAttacherDictCommand('feature_fkSpline'))

        for c,cStrCtrl in enumerate(sCtrls):
            if c > 0:
                sCommands.append("dAttachers_feature_fkSpline['ATTACHER_fkSpline_%s_r'].extend([%s.eControl, %s.eControl])" % (utils.getLetter(c-1), sCtrls[c-1], sCtrls[0]))
                sCommands.append("dAttachers_feature_fkSpline['ATTACHER_fkSpline_%s_t'].extend([%s.eControl, %s.eControl])" % (utils.getLetter(c-1), sCtrls[c-1], sCtrls[0]))

        sCommands.extend(utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fkSpline', sFunctionNodeName, bForward=False))

        return sCommands




    def unreal_feature_fk(self):

        sCommands = []
        # sCommands.extend(utilsUnreal.createKey_createCustomAttacherTransforms(self.sLimbName))

        self.eFkOriginStr = '%s_fk_origin' % (self.sLimbName)
        sCommands.append("%s = hierarchy.createNull('%s_fk_origin')" % (self.eFkOriginStr, self.sLimbName))
        cStrControls, sFkCommands = utilsUnreal.createFkChainCtrls(self.cFkCtrls, sParentVar=self.eFkOriginStr)
        sCommands += sFkCommands

        sJoints = [self.dDetailReplacements.get(sJ,sJ) for sJ in self.getOutputFullNames()[1:]]
        xxCtrlBonePairs = "[%s]" % ','.join(["(%s, '%s')" % (sC,sJ) for sC,sJ in zip(cStrControls, sJoints)])

        sFunctionNodeName = '%s_feature_fk_node' % self.sLimbName
        sCommands.extend(utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk'))
        sCommands.append("%s = functions.createFkChainCtrlsSetup(%s, %s)" % (sFunctionNodeName, self.eFkOriginStr, xxCtrlBonePairs))
        sCommands.extend(utilsUnreal.initiateAttacherDictCommand('feature_fk'))

        for c,cStrCtrl in enumerate(cStrControls):
            if c > 0:
                sCommands.append("dAttachers_feature_fk['ATTACHER_fk_%02d_r'].append(library.getElementKey('%s', 'Bone'))" % (c,sJoints[c-1]))
                sCommands.append("dAttachers_feature_fk['ATTACHER_fk_%02d_t'].append(library.getElementKey('%s', 'Bone'))" % (c,sJoints[c-1]))
        sCommands.extend(utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName))

        return sCommands, cStrControls, []


    def unrealBackwards_feature_fk(self):

        sCommands = []
        # sCommands.extend(utilsUnreal.createKey_createCustomAttacherTransforms(self.sLimbName))

        # cStrControls, sFkCommands = utilsUnreal.createFkChainCtrls(self.cFkCtrls, sParentVar=self.eFkOriginStr)
        # sCommands += sFkCommands
        cStrCtrls = [cC.sCtrl for cC in self.cFkCtrls]

        sJoints = [self.dDetailReplacements.get(sJ,sJ) for sJ in self.getOutputFullNames()[1:]]
        xxCtrlBonePairs = "[%s]" % ','.join(["(%s, '%s')" % (sC,sJ) for sC,sJ in zip(cStrCtrls, sJoints)])

        sCommands.extend(utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk'))

        sFunctionNodeName = '%s_feature_fk_node' % self.sLimbName
        sCommands.append("%s = functions.createFkChainCtrlsSetupBACKWARDS(library.getElementKey('%s', 'Null'), %s)" % (sFunctionNodeName, self.eFkOriginStr, xxCtrlBonePairs))
        sCommands.extend(utilsUnreal.initiateAttacherDictCommand('feature_fk'))

        for c,cStrCtrl in enumerate(cStrCtrls):
            if c > 0:
                sCommands.append("dAttachers_feature_fk['ATTACHER_fk_%02d_r'].append(library.getElementKey('%s', 'Bone'))" % (c, sJoints[c-1]))
                sCommands.append("dAttachers_feature_fk['ATTACHER_fk_%02d_t'].append(library.getElementKey('%s', 'Bone'))" % (c, sJoints[c-1]))
        sCommands.extend(utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, bForward=False))

        return sCommands


    def unreal_detail_postTwist(self):
        sMainJoints = list(self.getOutputFullNames())[1:]
        sScaleJoints = list(self.dOutputs.values())[1:len(sMainJoints)-1]

        fJointScalePercs = eval(cmds.getAttr('%s.fJointScalePercs' % self.sDetailsGrp))
        sCommands = []
        sCommands.append("functions.spineSquashStretch([%s], \n\t\t[%s], \n\t\t[%s])" %
                         (utilsUnreal.quotaStringList(sScaleJoints, bCommaJoined=True),
                          utilsUnreal.quotaStringList(sMainJoints, bCommaJoined=True),
                         ', '.join(['%0.3f' % fS for fS in fJointScalePercs])))

        return sCommands




    def _createGeneralSplineSetup(self, sPrefix, sTransforms, iExtraCvsPerCtrl, bOffsetJoints,
                           sAttrsCtrl, iCurveDegree=2, iStretchMode=0, fUpAxis=[0,0,1], sLastTransform=None):

        # bDoubleSpline = True if iStretchMode == 2 else False
        bClampStretch = True if iStretchMode == 0 else False

        iMiddleCtrlCount = len(sTransforms) - 2
        sJoints = self._duplicateBlueprintJoints(sPrefix)

        if len(sJoints) <= 3:
            raise Exception('%s: spline joint cound is too low (%d), please set it higher than 3' % (self.sLimbName, len(sJoints)))

        if bOffsetJoints:
            sSplineJoints = xforms.duplicateJoinChain(sJoints, sPostfix='%sSpline' % sPrefix,
                                                      sParent=self.sCurrentFeatureGrp, bScaleComp=False)
        else:
            sSplineJoints = sJoints

        xforms.connectInverseScales(sSplineJoints)
        sCurveShrink = cmds.curve(
            p=np.array([cmds.xform(sJ, q=True, ws=True, t=True) for sJ in sSplineJoints], dtype='float64'))
        sCurve = cmds.fitBspline(sCurveShrink, n=self._createNodeName('%sSplineCurve' % sPrefix, 'CRV'))[0]
        cmds.parent(sCurve, self.sCurrentFeatureGrp)

        curves.fixShapeName(sCurveShrink)
        curves.fixShapeName(sCurve)

        utils.addStringAttr(self.sTopGrp, 'sCurve', sCurve)
        cmds.select(sCurveShrink, sCurve, sSplineJoints)
        cmds.delete(sCurve, ch=True)
        cmds.delete(sCurveShrink)

        # rebuild curve with cvs for the tangents, and make it 1.5 of the previous length
        #
        fPercs = curves.getPercsFromTransforms(sCurve, sTransforms)
        if iExtraCvsPerCtrl == 0:  # single cvs
            fNewPercs = [0] * (len(fPercs) + 2)
            for p, fParam in enumerate(fPercs):
                fNewPercs[p + 1] = fPercs[p]
                if p == 0:
                    fNewPercs[p] = fPercs[p]
                    fNewPercs[p + 1] = fPercs[p] * 0.67 + fPercs[p + 1] * 0.33
                elif p < len(fPercs) - 1:
                    fNewPercs[p + 1] = fPercs[p]
                else:  # last fParam
                    fNewPercs[p + 1] = fPercs[p] * 0.67 + fPercs[p - 1] * 0.33
                    fNewPercs[p + 2] = fPercs[p]

        elif iExtraCvsPerCtrl == 1:  # double cvs
            fNewPercs = [0] * (len(fPercs) * 2)
            for p, fParam in enumerate(fPercs):
                if p == 0:
                    fNewPercs[p * 2 + 0] = 0
                else:
                    fNewPercs[p * 2 + 0] = fPercs[p - 1] * 0.25 + fPercs[p] * 0.75
                if p == len(fPercs) - 1:
                    fNewPercs[p * 2 + 1] = fPercs[-1]
                else:
                    fNewPercs[p * 2 + 1] = fPercs[p] * 0.75 + fPercs[p + 1] * 0.25

        elif iExtraCvsPerCtrl == 2:  # tripple cvs
            fNewPercs = [0] * (len(fPercs) * 3)
            for p, fParam in enumerate(fPercs):
                if p == 0:
                    fNewPercs[p * 3 + 0] = 0
                else:
                    fNewPercs[p * 3 + 0] = fPercs[p - 1] * 0.25 + fPercs[p] * 0.75
                    fNewPercs[p * 3 + 1] = fPercs[p]
                if p == len(fPercs) - 1:
                    fNewPercs[p * 3 + 2] = fPercs[-1]
                else:
                    fNewPercs[p * 3 + 2] = fPercs[p] * 0.75 + fPercs[p + 1] * 0.25

        elif iExtraCvsPerCtrl == 3:  # single cvs with last simple
            fNewPercs = [0] * (len(fPercs) + 1)
            for p, fParam in enumerate(fPercs):
                fNewPercs[p + 1] = fPercs[p]
                if p == 0:
                    fNewPercs[p] = fPercs[p]
                    fNewPercs[p + 1] = fPercs[p] * 0.67 + fPercs[p + 1] * 0.33
                elif p < len(fPercs) - 1:
                    fNewPercs[p + 1] = fPercs[p]
                else:  # last fParam
                    # fNewPercs[p + 1] = fPercs[p] * 0.67 + fPercs[p - 1] * 0.33
                    fNewPercs[p + 1] = fPercs[p]


        fNewPercs.append(1.0)
        if bClampStretch:
            fNewPercs.append(1.5)  # make it longer to allow some room not scaling
            fExtraLength = 0.5 * curves.getLength(sCurve)
        else:
            fNewPercs.append(1.0)  # make it longer to allow some room not scaling
            fExtraLength = 0.0  # 0.5 * curves.getLength(sCurve)

        curves.rebuildWithPercs(sCurve, fNewPercs, iDegree=iCurveDegree, bFit=True)

        if iStretchMode in [StretchMode.clamp, StretchMode.fullyStretchSingleIk]:
            sHandle, sCurve = curves.createSplineHandle(sStartJoint=sSplineJoints[0], sEndJoint=sSplineJoints[-2],
                                                        sCurve=sCurve,
                                                        sName=self._createNodeName('%sSpline' % sPrefix, 'IK'))
            cmds.parent(sHandle, self.sCurrentFeatureGrp)

        elif iStretchMode >= StretchMode.curveInfoNodesSoftTwist: # curveInfo nodes and motionPath nodes
            if iStretchMode in [StretchMode.curveInfoNodesSoftTwist, StretchMode.curveInfoNodesRigidTwist]:
                fParams = curves.getParamsFromTransforms(sCurve, sSplineJoints)
            elif iStretchMode in [StretchMode.motionPathsSoftTwist, StretchMode.motionPathsRigidTwist]:
                fMotionPathPercs = curves.getPercsFromTransforms(sCurve, sSplineJoints)

            sOutPoints = []
            for j,sJ in enumerate(sSplineJoints):
                if iStretchMode in [StretchMode.curveInfoNodesSoftTwist, StretchMode.curveInfoNodesRigidTwist]:
                    _, sPoint = curves.createPointInfoNode(sCurve, fParam=fParams[j], sFullName=self._createNodeName('softTwist', 'curveInfo', j))
                elif iStretchMode in [StretchMode.motionPathsSoftTwist, StretchMode.motionPathsRigidTwist]:
                    sMotionPath, sPoint = curves.createMotionPath(sCurve, bLengthPerc=True, fU=fMotionPathPercs[j], sFullName=self._createNodeName('softTwist', 'motionPath', j))
                else:
                    raise Exception('stretchmode shouldn\'t be %d at this point (%s)' % (iStretchMode, self.sLimbName))
                nodes.createPointByMatrixNode(sPoint, '%s.parentInverseMatrix' % sJ, sTarget='%s.t' % sJ, sName='curveInfoNode')
                sOutPoints.append(sPoint)

            fUpLength = xforms.distanceBetween(sTransforms[0], sTransforms[-1]) * 0.2

            fJointPercs = curves.getPercsFromTransforms(sCurve, sSplineJoints)
            xCtrlWeightings = xforms.getCtrlWeightings(fJointPercs, fPercs)
            utils.addStringAttr(self.sCurrentFeatureGrp, 'xCtrlWeightings', xCtrlWeightings)

            if iStretchMode in [StretchMode.curveInfoNodesSoftTwist, StretchMode.motionPathsSoftTwist]:  # soft twist - we make curve
                sUpJoints = []
                for c, sT in enumerate(sTransforms):
                    sUpJ = cmds.createNode('joint', n=self._createNodeName('twist', 'jnt', c),
                                           p=self.sCurrentFeatureGrp)
                    fLocalUpPoint = [fUpAxis[0]*fUpLength, fUpAxis[1]*fUpLength, fUpAxis[2]*fUpLength]
                    sUpMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(fLocalUpPoint),
                                                            '%s.worldMatrix' % sT])
                    nodes.createDecomposeMatrix(sUpMatrix, sTargetPos='%s.t' % sUpJ, sTargetRot='%s.r' % sUpJ)
                    sUpJoints.append(sUpJ)

                sTempUpCurve = curves.createCurveFromJoints(sUpJoints, iDegree=2 if len(sTransforms) > 2 else 1, sName='sTempUpCurve')  # , sParent=self.sDetailsGrp)
                sUpCurve = cmds.fitBspline(sTempUpCurve, n=self._createNodeName('%sUp' % sPrefix, 'curve'), ch=False)[0]
                cmds.delete(sTempUpCurve)
                cmds.parent(sUpCurve, self.sCurrentFeatureGrp)

                cmds.skinCluster(sUpCurve, sUpJoints, tsb=True)
                for sObj in [sUpCurve]+sUpJoints:
                    cmds.setAttr('%s.inheritsTransform' % sObj, False)

                sTempUpCurve = curves.createCurveFromPoints(xforms.getPositionArray(sTransforms), iDegree=2 if len(sTransforms) > 2 else 1)

                # fUpCurveParams = curves.getParamsFromPoints(sTempUpCurve, xforms.getPositionArray(sSplineJoints))
                fUpCurvePercs = curves.getPercsFromPoints(sTempUpCurve, xforms.getPositionArray(sSplineJoints))
                fUpCurveParams = curves.getParamsFromPercs(sUpCurve, fUpCurvePercs)

                cmds.delete(sTempUpCurve)
                sTempTransform = cmds.createNode('transform')
                sTempUpTransform = cmds.createNode('transform')
                for j, sJ in enumerate(sSplineJoints[:-1]):
                    if iStretchMode == StretchMode.curveInfoNodesSoftTwist:
                        _, sUpCurvePoint = curves.createPointInfoNode(sUpCurve, fParam=fUpCurveParams[j], sFullName=self._createNodeName('up', 'curveInfo', j))
                    else:
                        _, sUpCurvePoint = curves.createMotionPath(sUpCurve, bLengthPerc=True, fU=fMotionPathPercs[j], sFullName=self._createNodeName('up', 'motionPath', j))
                    sParentInverseMatrix = '%s.parentInverseMatrix' % sJ if j == 0 else '%s.worldInverseMatrix' % sSplineJoints[j-1]
                    constraints.aimConstraintFromLocalPoints(sJ, nodes.createPointByMatrixNode(sOutPoints[j+1], sParentInverseMatrix),
                                                             nodes.createPointByMatrixNode(sUpCurvePoint, sParentInverseMatrix),
                                                             sParent=self.sCurrentFeatureGrp, up=fUpAxis)
                xforms.matrixParentConstraint(sLastTransform if sLastTransform else sTransforms[-1], sSplineJoints[-1],
                                              skipTranslate=['x','y','z'], skipScale=['x','y','z'])
                cmds.delete(sTempTransform, sTempUpTransform)

            elif iStretchMode in [StretchMode.curveInfoNodesRigidTwist, StretchMode.motionPathsRigidTwist]:  # rigid twist (old way, each ctrl)
                if fPercs[0] > 0.0:
                    fPercs[0] = 0.0
                sCtrlUps = ['%s.worldMatrix' % cmds.createNode('transform', n='%sUp' % sT, p=sT) for sT in sTransforms]

                for j, sJ in enumerate(sSplineJoints[:-1]):
                    sCtrl = sTransforms[xCtrlWeightings[j][0]]
                    sLocalJointPerc = utils.addAttr(sJ, ln='twistBlend_%s' % sCtrl,
                                                    minValue=0.0, maxValue=1.0, defaultValue=xCtrlWeightings[j][2],
                                                    k=True)

                    sBlend = nodes.createBlendMatrixNode([sCtrlUps[xCtrlWeightings[j][1]], sCtrlUps[xCtrlWeightings[j][0]]],
                                                         [sLocalJointPerc,
                                                          nodes.createReverseNode(sLocalJointPerc)])


                    sParentInverseMatrix = '%s.parentInverseMatrix' % sJ if j == 0 else '%s.worldInverseMatrix' % sSplineJoints[j - 1]
                    sAimConstraint = constraints.aimConstraintEmpty(sJ, sParent=self.sCurrentFeatureGrp, up=fUpAxis)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, *fUpAxis)
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    nodes.createPointByMatrixNode(sOutPoints[j+1], sParentInverseMatrix, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                    nodes.createMultMatrixNode([sBlend, sParentInverseMatrix], '%s.worldUpMatrix' % sAimConstraint)




        # skin the curve
        #
        iEndCvs = 1
        sInfluences = []
        for c, sC in enumerate(sTransforms + [sTransforms[-1]]):
            sJ = cmds.createNode('joint', name=self._createNodeName('%sSplineSkinCurve' % sPrefix, 'JNT', c),
                                 parent=self.sCurrentFeatureGrp)
            cmds.setAttr('%s.radius' % sJ, self.fBlueprintsDiagonal * 0.15)
            constraints.matrixParentConstraint(sC, sJ)#, skipScale=['x', 'y', 'z'])
            sInfluences.append(sJ)

        if self.sLimbName == 'm_neck':
            cmds.select(sInfluences)

        if iExtraCvsPerCtrl == 1:
            aWeights2d = np.zeros((len(sTransforms) * 2 + iEndCvs, len(sTransforms) + 1), dtype='float64')
            for c in range(len(sTransforms)):
                aWeights2d[c * 2 + 0, c] = 1.0
                aWeights2d[c * 2 + 1, c] = 1.0
        elif iExtraCvsPerCtrl == 0:  # single cvs
            aWeights2d = np.zeros((len(sTransforms) + 2 + iEndCvs, len(sTransforms) + 1), dtype='float64')
            aWeights2d[0:2, 0] = 1.0
            for i in range(iMiddleCtrlCount):  #
                aWeights2d[2 + i, i + 1] = 1.0
            aWeights2d[-2 - iEndCvs:-iEndCvs, -2] = 1.0
        elif iExtraCvsPerCtrl == 2:
            aWeights2d = np.zeros((len(sTransforms) * 3 + iEndCvs, len(sTransforms) + 1), dtype='float64')
            for c in range(len(sTransforms)):
                aWeights2d[c * 3 + 0, c] = 1.0
                aWeights2d[c * 3 + 1, c] = 1.0
                aWeights2d[c * 3 + 2, c] = 1.0
        if iExtraCvsPerCtrl == 3:
            aWeights2d = np.zeros((len(sTransforms) + 1 + iEndCvs, len(sTransforms) + 1), dtype='float64')
            aWeights2d[0:2, 0] = 1.0
            for i in range(iMiddleCtrlCount):  #
                aWeights2d[2 + i, i + 1] = 1.0
            aWeights2d[-1 - iEndCvs:-iEndCvs, -2] = 1.0


        for i in range(iEndCvs):
            aWeights2d[-i - 1, -2] = 1.0

        pCurve = patch.patchFromName(sCurve)
        pCurve.setSkinClusterWeights(aWeights2d, sInfluences=sInfluences, _bSkipDeformerAdjustLogging=True)
        cmds.select(sInfluences)

        cmds.setAttr('%s.inheritsTransform' % sCurve, False)

        # straight controls
        #
        if iStretchMode < 2: # ik handle
            # ikhandle twist
            #
            fBlendValue = 1.0 - 1.0 / len(sSplineJoints)
            sBlendTwist = utils.addAttr(sTransforms[-1], ln='blendTwist', minValue=0.0, maxValue=1.0,
                                        defaultValue=fBlendValue, k=True)
            sBlendTransform = cmds.duplicate(sTransforms[-1], n=self._createNodeName('blendTwist', 'transform'), po=True)[0]
            sBlendConstr = cmds.orientConstraint(sTransforms[0], sTransforms[-1], sBlendTransform)[0]
            cmds.setAttr('%s.interpType' % sBlendConstr, 2)
            cmds.connectAttr(sBlendTwist, '%s.%sW1' % (sBlendConstr, sTransforms[-1]))
            nodes.createReverseNode(sBlendTwist, sTarget='%s.%sW0' % (sBlendConstr, sTransforms[0]))

            cmds.setAttr('%s.dTwistControlEnable' % sHandle, True)
            cmds.setAttr('%s.dWorldUpType' % sHandle, 4)
            cmds.connectAttr('%s.worldMatrix' % sTransforms[0], '%s.dWorldUpMatrix' % sHandle)
            cmds.connectAttr('%s.worldMatrix' % sBlendTransform, '%s.dWorldUpMatrixEnd' % sHandle)
            cmds.setAttr('%s.dForwardAxis' % sHandle, 1 if self.sSide == 'r' else 0)
            cmds.setAttr('%s.dWorldUpAxis' % sHandle, 1 if self.sSide == 'r' else 0)
            cmds.setAttr('%s.dWorldUpVector' % sHandle, 0, 1, 0)
            cmds.setAttr('%s.dWorldUpVectorEnd' % sHandle, 0, 1, 0)

            # squash/stretch - using tx
            #
            sCurveNode, sCurveLengthFromNode = curves.createCurveLengthNode(sCurve, sName=self._createNodeName('ikSpline'))
            sCurveLength = nodes.fromEquation('%s / %s.sx' % (sCurveLengthFromNode, self.sCurrentFeatureGrp),
                                              sName=self._createNodeName('scaleNormalize'))
            fDefaultLength = cmds.getAttr(sCurveLength)
            sScaleFactor = nodes.fromEquation(
                '(%s-%f) * %f' % (sCurveLength, fExtraLength, 1.0 / (fDefaultLength - fExtraLength)),
                sName=self._createNodeName('scaleFactor'))

            if bClampStretch:
                sMinStretch = utils.addAttr(sAttrsCtrl, ln='minStretch', at='double', defaultValue=0.8, minValue=0.1,
                                            maxValue=1.0, k=True, bReturnIfExists=True)
                sMaxStretch = utils.addAttr(sAttrsCtrl, ln='maxStretch', at='double', defaultValue=1.25, minValue=1.0,
                                            maxValue=10.0, k=True, bReturnIfExists=True)
                sScaleClamped = nodes.createClampNode(sScaleFactor, sMinStretch, sMaxStretch,
                                                      sName=self._createNodeName('scaleFactor'))
            else:
                sScaleClamped = sScaleFactor

            for j, sJoint in enumerate(sSplineJoints[1:-1 if bClampStretch else None]):
                fDefaultTx = cmds.getAttr('%s.tx' % sJoint)
                nodes.createMultiplyNode(fDefaultTx, sScaleClamped, sTarget='%s.tx' % sJoint,
                                         sName=self._createNodeName('txScale_%03d' % j))

            # last joint for squash/stretch
            #
            if bClampStretch:
                sPathTransform = self._createTransform('path', sParent=self.sCurrentFeatureGrp)
                cmds.setAttr('%s.inheritsTransform' % sPathTransform, False)
                sPath, sPathOutput = curves.createMotionPath(sCurve, bLengthPerc=True,
                                                             sName=self._createNodeName('endJoint'))

                nodes.fromEquation('%s * %f / %s' % (sScaleClamped, (fDefaultLength - fExtraLength), sCurveLength),
                                   sTarget='%s.uValue' % sPath,
                                   sFullName=self._createNodeName('getUValue'))
                nodes.createPointByMatrixNode(sPathOutput, '%s.worldInverseMatrix' % sSplineJoints[-2],
                                              sFullName=self._createNodeName('localPath'),
                                              sTarget='%s.t' % sSplineJoints[-1])
                cmds.connectAttr(sPathOutput, '%s.t' % sPathTransform)

                fUpPosition = utils.multiplyPositionByMatrix([0, xforms.distanceBetween(sJoints[0], sJoints[-1]), 0],
                                                             sJoints[-2])
                # cmds.aimConstraint(sPathTransform, sSplineJoints[-2], aim=(1, 0, 0), wu=(0, 1, 0), wut='objectrotation',
                #                    wuo=sTransforms[-1])
                constraints.aimConstraintFromTransforms(sSplineJoints[-2], sPathTransform, sTransforms[-1],
                                                        aim=(1, 0, 0), bOrientUp=True, sParent=self.sCurrentFeatureGrp)
                # last joint
                constraints.matrixParentConstraint(sLastTransform if sLastTransform else sTransforms[-1], sSplineJoints[-1], mo=True, skipTranslate=['x', 'y', 'z'], skipScale=['x', 'y', 'z'])

        else:
            sHandle = None

        # constrain the actual ik joints to the splineJoints
        #
        if bOffsetJoints:
            for j, sJ in enumerate(sJoints):
                constraints.matrixParentConstraint(sSplineJoints[j], sJ, mo=True, skipScale=['x', 'y', 'z'])
            cmds.setAttr('%s.v' % sSplineJoints[0], False)


        return sInfluences, sJoints, sCurve, sHandle


    def generateOutputs_postTwist(self, **kwargs):
        return {}, []


    def detail_postTwist(self, bCtrlScale=False, iCtrlTwist=0, bDistributeRotationStartToEnd=False, iDynamics=0, sDynamicsMasterCtrl='master', bLengthScale=False, fDefaultSquash=0.0, fUpAxis=[0,1,0],
                         _dComboboxItems={'iCtrlTwist': ['none', 'sharp', 'soft', 'distribute first ctrl to last ctrl'],
                                          'iDynamics': ['off', 'lock start', 'lock start and end']},
                         _dInterpolateBehavior={'fBotCtrlPercs': 1, 'fTopCtrlPercs': 1}):

        sFeatures = list(self.dFeatureData.keys())

        sJoints = [sO for sO in list(self.dOutputs.values()) if cmds.objectType(sO) == 'joint']

        sSwitchesNode = utils.data.get('sSwitchesNode', xDefault=None)
        if sSwitchesNode:
            sSquashStrengthOnCompressAttr = utils.addAttr(sSwitchesNode, ln='%s_autoSquashOnCompress' % self.sLimbName, at='double', defaultValue=fDefaultSquash, minValue=0.0, maxValue=10.0, k=True, bReturnIfExists=True)
            sSquashStrengthOnStretchAttr = utils.addAttr(sSwitchesNode, ln='%s_autoSquashOnStretch' % self.sLimbName, at='double', defaultValue=fDefaultSquash, minValue=0.0, maxValue=10.0, k=True, bReturnIfExists=True)
        else:
            sSquashStrengthOnCompressAttr = utils.addAttr(self.sFeatureShape, ln='%sautoSquashOnCompress' % self.sFeatureAttrPrefix, at='double', defaultValue=fDefaultSquash, minValue=0.0, maxValue=10.0, k=True, bReturnIfExists=True)
            sSquashStrengthOnStretchAttr = utils.addAttr(self.sFeatureShape, ln='%sautoSquashOnStretch' % self.sFeatureAttrPrefix, at='double', defaultValue=fDefaultSquash, minValue=0.0, maxValue=10.0, k=True, bReturnIfExists=True)

        sTempCurve = curves.createCurveFromJoints(sJoints, iDegree=2, sName='tempCurve')
        self.iDynamics = iDynamics
        if self.iDynamics > 0:
            # nodes.addSeparatorAttr(cCtrls[0].sCtrl, 'DYNAMICS')
            sMaster = utils.getMasterName()
            sStartFrameAttr = utils.addAttr(sMaster, ln='dynamicsStartFrame', at='long', defaultValue=1001, k=False,
                                            cb=True, bReturnIfExists=True)
            sEnabledAttr = utils.addOffOnAttr(sMaster, 'chainSimulationOnOff', bDefaultValue=False, bReturnIfExists=True)
            # sEnabledAttr = utils.addAttr(sMaster, ln='chainSimulationOnOff', at='enum', en='off:on', defaultValue=0, k=False,
            #                              cb=True, bReturnIfExists=True)

            sCurveDyn = curves.createCurveFromJoints(sJoints, iDegree=2,
                                                     sName=self._createNodeName('dynamics', 'curve'))

            dCurrentCurves = utils.data.get('dSpineDynamicCurves_%s' % sVersion, xDefault={})

            sCurrentCtrlCurves = dCurrentCurves.get(sDynamicsMasterCtrl, [])
            sCurrentCtrlCurves.append([sCurveDyn, self.iDynamics])
            dCurrentCurves[sDynamicsMasterCtrl] = sCurrentCtrlCurves

            utils.data.store('dSpineDynamicCurves_%s' % sVersion, dCurrentCurves)

            cmds.setAttr('%s.inheritsTransform' % sCurveDyn, False)


            cmds.skinCluster(sJoints, sCurveDyn, tsb=True)

            sTempOutCurve = cmds.duplicate(sCurveDyn, n='sCurveDyn_dynamicTempOut')[0]



        fPercs = utils.bSpline3([0.0, 1.0, 0.0], len(sJoints))

        utils.addStringAttr(self.sDetailsGrp, 'fJointScalePercs', str(list(fPercs)))

        sAutoSquashMultipls = []
        for j, sJ in enumerate(sJoints):
            sChildren = cmds.listRelatives(sJ, c=True, typ='joint')
            if sChildren:
                sChild = sChildren[0]
                sChildX = '%s.translateX' % sChild
                print ('sChildX: ', sChildX)
                sScaleMultipl = nodes.createMultiplyNode(sChildX, 1.0 / cmds.getAttr(sChildX), sName='%s_stretchMultipl_%03d' % (self.sLimbName, j))
                sSquashMultipl = nodes.createMultiplyNode(1, sScaleMultipl, sName='%s_squashMultipl_%d' % (self.sLimbName, j), sOperation='divide')

                sSquashValue = utils.addAttr(sJ, ln='autoSquash', defaultValue=fPercs[j], k=True)
                sSquashChosen = nodes.createConditionNode(sScaleMultipl, '<', 1, sSquashStrengthOnCompressAttr, sSquashStrengthOnStretchAttr)
                sSquashStrength = nodes.createMultiplyNode(sSquashChosen, sSquashValue, sName='%s_squashParam_%03d' % (self.sLimbName, j))

                sBlend = nodes.createBlendNode(sSquashStrength, sSquashMultipl, 1,
                                               sName='%s_autoSquashMultipl_%03d' % (self.sLimbName, j))

                sLengthScale = 1
                if bLengthScale:
                    sLengthScale = sScaleMultipl

                sAutoSquashMultipls.append(nodes.createVectorMultiplyNode([1, 1, 1], [sLengthScale, sBlend, sBlend],
                                                                          sName='%s_squashMultipl_%03d' % (
                                                                              self.sLimbName, j)))
            else:
                sAutoSquashMultipls.append(None)

        if bDistributeRotationStartToEnd:
            sStraightLine = cmds.createNode('transform', p=self.sTopGrp, n='grp_straightLine_%s' % self.sLimbName)
            cmds.pointConstraint(sJoints, sStraightLine)

            constraints.aimConstraintFromTransforms(sStraightLine, sJoints[-1], sJoints[len(sJoints) // 2], bOrientUp=True, sParent=self.sCurrentFeatureGrp)

        if bCtrlScale:
            ssCtrlScales = []
            for f, sF in enumerate(sFeatures):
                cFeatureCtrls = self.dFeatureData[sF][1]
                iScaleCtrlIndices = self.dScaleCtrlIndices.get(sF, list(range(len(cFeatureCtrls))))
                cCtrls = [cFeatureCtrls[iC] for iC in iScaleCtrlIndices]

                ssScales = []
                iClosestJoints = xforms.findClosestJoints(xforms.getPositionArray([cC.sCtrl for cC in cCtrls]), sJoints)
                # find the best scaling axis for each ctrl and set those up
                for c, cC in enumerate(cCtrls):
                    sJoint = sJoints[iClosestJoints[c]]

                    aAxisMapped = xforms.mapAxis(sJoint, cC.sCtrl)

                    sAxisY = ['sx', 'sy', 'sz'][aAxisMapped[1]]
                    sAxisZ = ['sx', 'sy', 'sz'][aAxisMapped[2]]

                    ssScales.append([1.0, '%s.%s' % (cC.sCtrl, sAxisY), '%s.%s' % (cC.sCtrl, sAxisZ)])
                    cmds.setAttr('%s.%s' % (cC.sCtrl, sAxisY), lock=False)
                    cmds.setAttr('%s.%s' % (cC.sCtrl, sAxisY), keyable=True)
                    cmds.setAttr('%s.%s' % (cC.sCtrl, sAxisZ), lock=False)
                    cmds.setAttr('%s.%s' % (cC.sCtrl, sAxisZ), keyable=True)

                fCtrlPercs = curves.getPercsFromTransforms(sTempCurve, [cC.sOut for cC in cCtrls])

                if fCtrlPercs[0] > 0.0:
                    fCtrlPercs[0] = 0.0

                fJointPercs = curves.getPercsFromTransforms(sTempCurve, sJoints)

                iBeforeCtrl = 0
                sCtrlMultipls = []

                for j, sJ in enumerate(sJoints):
                    if iBeforeCtrl < len(fCtrlPercs) and fJointPercs[j] >= fCtrlPercs[iBeforeCtrl]:
                        iBeforeCtrl += 1

                    if iBeforeCtrl >= len(fCtrlPercs):
                        iBlendCtrls = iBeforeCtrl
                        fBlendWeight = None
                    elif iBeforeCtrl == 0:
                        iBlendCtrls = iBeforeCtrl
                        fBlendWeight = None
                    else:
                        iBlendCtrls = [iBeforeCtrl - 1, iBeforeCtrl]
                        fLocalJointPerc = fJointPercs[j] - fCtrlPercs[iBeforeCtrl - 1]
                        fRange = fCtrlPercs[iBeforeCtrl] - fCtrlPercs[iBeforeCtrl - 1]
                        fBlendWeight = fLocalJointPerc / fRange
                        fBlendWeight = min(1, fBlendWeight)  # Shouldn't be higher than one. But just in case

                    if fBlendWeight != None:
                        sBlend = nodes.createBlendNode(fBlendWeight, ssScales[iBlendCtrls[1]],
                                                       ssScales[iBlendCtrls[0]], bVector=True, sFullName=self._createNodeName('blendWeights', sType='blend'))
                    else:
                        sBlend = ssScales[min(iBlendCtrls, len(cCtrls) - 1)]

                    sCtrlMultipls.append(
                        nodes.createVectorMultiplyNode(sBlend, '%s.weight' % self.sFeatureGrps[f], bVectorByScalar=True,
                                                       sName='ctrlByWeight_%d' % j))

                ssCtrlScales.append(sCtrlMultipls)

            sCtrlScales = []
            for j, sJ in enumerate(sJoints):
                sCtrlScales.append(
                    nodes.createVectorAdditionNode([ssCtrlScales[f][j] for f in range(len(sFeatures))]))

        if len(list(self.dFeatureData.keys())) == 1:
            sOneFeat = list(self.dFeatureData.keys())[0]
            sOutputs, cCtrls, xSpace = self.dFeatureData[sOneFeat]
            if len(sOutputs) == 0:
                return

        if iCtrlTwist:
            ssJointUps = []
            for f, sF in enumerate(sFeatures):
                cCtrls = self.dFeatureData[sF][1]

                if iCtrlTwist == 2:  # soft - we make curve
                    iCtrlIndices = self.dTwistCtrlIndices.get(sF, list(range(len(cCtrls))))
                    cCtrls = [cCtrls[iC] for iC in iCtrlIndices]

                    # sCtrlUps = ['%s.worldMatrix' % cmds.createNode('transform', n='%sUp' % cC.sOut, p=cC.sOut) for cC in
                    #             cCtrls]
                    # fCtrlPercs = curves.getPercsFromTransforms(sTempCurve, [cC.sOut for cC in cCtrls])
                    fUpLength = xforms.distanceBetween(cCtrls[0].sOut, cCtrls[-1].sOut) * 0.2

                    sUpJoints = []
                    for c, cC in enumerate(cCtrls):
                        sUpJ = cmds.createNode('joint', n=self._createNodeName('%sTwist' % sF, 'jnt', c),
                                               p=self.sDetailsGrp)
                        fAxisMatrix = list(utils.fIdentityMatrix)
                        fAxisMatrix[12], fAxisMatrix[13], fAxisMatrix[14] = [fUpAxis[0]*fUpLength, fUpAxis[1]*fUpLength, fUpAxis[2]*fUpLength]
                        if c == 0:
                            # nodes.createPointByMatrixNode(fUpAxisScaled, '%s.worldMatrix' % cC.sOut, sTarget='%s.t' % sUpJ)
                            sWorldUp = nodes.createMultMatrixNode([fAxisMatrix, '%s.worldMatrix' % cC.sOut])
                        else:
                            sParentBlendT = cmds.createNode('transform',
                                                            n=self._createNodeName('%sTwistParent' % sF, 'transform',
                                                                                   c), p=cC.sOut)
                            sBlendT = cmds.createNode('transform',
                                                      n=self._createNodeName('%sTwistParent' % sF, 'transform', c),
                                                      p=cC.sOut)
                            constraints.matrixParentConstraint(cCtrls[c - 1].sOut, sParentBlendT, mo=True)
                            sOrient = cmds.orientConstraint(cC.sOut, sParentBlendT, sBlendT)[0]
                            cmds.setAttr('%s.interpType' % sOrient, 2)
                            # nodes.createPointByMatrixNode(fUpAxisScaled, '%s.worldMatrix' % sBlendT, sTarget='%s.t' % sUpJ)
                            sWorldUp = nodes.createMultMatrixNode([fAxisMatrix, '%s.worldMatrix' % sBlendT])

                        nodes.createDecomposeMatrix(sWorldUp, '%s.t' % sUpJ, '%s.r' % sUpJ, '%s.s' % sUpJ)
                        sUpJoints.append(sUpJ)

                    sTempUpCurve = curves.createCurveFromJoints(sUpJoints, iDegree=2 if len(cCtrls) > 2 else 1, sName='sTempUpCurve')  # , sParent=self.sDetailsGrp)
                    sUpCurve = cmds.fitBspline(sTempUpCurve, n=self._createNodeName('%sUp' % sF, 'curve'), ch=False)[0]
                    cmds.delete(sTempUpCurve)
                    cmds.parent(sUpCurve, self.sDetailsGrp)

                    cmds.skinCluster(sUpCurve, sUpJoints, tsb=True)
                    for sObj in [sUpCurve] + sUpJoints:
                        cmds.setAttr('%s.inheritsTransform' % sObj, False)
                    sTempUpCurve = curves.createCurveFromPoints(xforms.getPositionArray([cC.sOut for cC in cCtrls]), iDegree=2 if len(cCtrls) > 2 else 1)
                    fUpCurveParams = curves.getParamsFromPoints(sTempUpCurve, xforms.getPositionArray(sJoints))
                    cmds.delete(sTempUpCurve)
                    sJointUpMatrices = []
                    for j, sJ in enumerate(sJoints):
                        sJointUpMatrices.append(nodes.createComposeMatrixNode(
                            xTranslate=curves.createPointInfoNode(sUpCurve, fParam=fUpCurveParams[j], sFullName=self._createNodeName('upMatrix', 'curveInfo', j))[1]))
                    ssJointUps.append(sJointUpMatrices)

                elif iCtrlTwist in [1,3]:  # ctrl twist or distribute
                    if iCtrlTwist == 1:
                        iCtrlIndices = self.dTwistCtrlIndices.get(sF, list(range(len(cCtrls))))
                    else:
                        iCtrlIndices = self.dTwistCtrlIndicesDistr.get(sF, [0,-1])

                    cCtrls = [cCtrls[iC] for iC in iCtrlIndices]

                    sCtrlUps = ['%s.worldMatrix' % cmds.createNode('transform', n='%sUp' % cC.sOut, p=cC.sOut) for cC in
                                cCtrls]
                    fCtrlPercs = curves.getPercsFromTransforms(sTempCurve, [cC.sOut for cC in cCtrls])
                    # fUpLength = xforms.distanceBetween(cCtrls[0].sOut, cCtrls[-1].sOut) * 0.2

                    if fCtrlPercs[0] > 0.0:
                        fCtrlPercs[0] = 0.0
                    fJointPercs = curves.getPercsFromTransforms(sTempCurve, sJoints)

                    iBeforeCtrl = 0
                    sCtrlMultipls = []
                    for j, sJ in enumerate(sJoints):
                        if iBeforeCtrl < len(fCtrlPercs) and fJointPercs[j] >= fCtrlPercs[iBeforeCtrl]:
                            iBeforeCtrl += 1
                        iCurrentBeforeCtrl = iBeforeCtrl
                        if iCurrentBeforeCtrl >= len(fCtrlPercs):
                            iCurrentBeforeCtrl -= 1
                            fLocalJointPerc = 1.0
                        else:
                            iBlendCtrls = [iCurrentBeforeCtrl - 1, iCurrentBeforeCtrl]
                            fLocalJointPerc = fJointPercs[j] - fCtrlPercs[iCurrentBeforeCtrl - 1]
                            fRange = fCtrlPercs[iCurrentBeforeCtrl] - fCtrlPercs[iCurrentBeforeCtrl - 1]
                            fLocalJointPerc = fLocalJointPerc / fRange

                        sCtrl = cCtrls[iCurrentBeforeCtrl].sCtrl
                        sLocalJointPerc = utils.addAttr(sJ, ln='twistBlend_%s_%s' % (sF, sCtrl),
                                                        minValue=0.0, maxValue=1.0, defaultValue=fLocalJointPerc,
                                                        k=True)

                        sBlend = nodes.createBlendMatrixNode([sCtrlUps[iBlendCtrls[1]], sCtrlUps[iBlendCtrls[0]]],
                                                             [sLocalJointPerc,
                                                              nodes.createReverseNode(sLocalJointPerc)])
                        sCtrlMultipls.append(sBlend)

                    ssJointUps.append(sCtrlMultipls)
                else:
                    raise Exception('Don\'t know what iCtrlTwist %d is' % iCtrlTwist)

            sJointUps = []
            for j, sJ in enumerate(sJoints):
                if len(sFeatures) > 1:
                    sBlendMatrix = nodes.createBlendMatrixNode([ssJointUps[f][j] for f in range(len(sFeatures))],
                                                               ['%s.weight' % self.sFeatureGrps[f] for f in
                                                                range(len(sFeatures))])
                else:
                    sBlendMatrix = ssJointUps[f][j]
                sJointUps.append(sBlendMatrix)

        if bDistributeRotationStartToEnd:
            aStraightWeights = utils.bSpline4([0, 0, 1, 1], len(sJoints))

        if self.iDynamics > 0:
            # experimential:
            sAttrCtrlSplits = sDynamicsMasterCtrl.split('.')
            sSystemName = sAttrCtrlSplits[1] if len(sAttrCtrlSplits) > 1 else ''

            aPoints = xforms.getPositionArray(sJoints)
            fParams = curves.getParamsFromPoints(sTempOutCurve, aPoints)
            self.sDynJoints = []
            for j, sJ in enumerate(sJoints):
                sDynJoint = cmds.createNode('joint', name='jnt_%sSpineDyn_%03d' % (self.sLimbName, j), parent=sJ)
                utils.addStringAttr(sDynJoint, 'skinParent', sJ, bLock=True)
                utils.transferStringAttr('%s.%s' % (sJ, deformers.kPostRefJointAttr), sDynJoint, bErrorIfNotExists=False)
                cmds.setAttr('%s.radius' % sDynJoint, cmds.getAttr('%s.radius' % sJ) * 1.75)

                sPointOnCurveNode, sPointOnCurve = curves.createPointInfoNode(sTempOutCurve, fParam=fParams[j], sFullName=self._createNodeName('dynamics', 'curveInfo', j))
                utils.addStringAttr(sPointOnCurveNode, 'sSwitchCurveLimbName', self.sLimbName)

                sLocalPoint = nodes.createPointByMatrixNode(sPointOnCurve, '%s.worldInverseMatrix' % sJ)
                sDynamicsMultiplAttr = utils.addAttr(self.sFeatureShape, ln='%sDynMultipl' % sSystemName, min=0, max=1, dv=1.0, k=True, bReturnIfExists=True)
                sDynamicsMultipl = nodes.createMultiplyNode(sEnabledAttr, sDynamicsMultiplAttr)
                nodes.createBlendNode(sDynamicsMultipl, sLocalPoint, [0, 0, 0], bVector=True, sTarget='%s.t' % sDynJoint, sFullName=self._createNodeName('enable', sType='blend'))
                self.sDynJoints.append(sDynJoint)
            for j, sJ in enumerate(sJoints[:-1]):
                # cmds.aimConstraint(self.sDynJoints[j + 1], self.sDynJoints[j], wut='objectrotation', wuo=sJ)
                constraints.aimConstraintFromTransforms(self.sDynJoints[j], self.sDynJoints[j+1], sJ, bOrientUp=True, aim=[self.fSideMultipl,0,0], sParent=self.sCurrentFeatureGrp)
            constraints.matrixParentConstraint(self.sDynJoints[-2], self.sDynJoints[-1], skipTranslate=['x','y','z'], skipScale=['x','y','z'], mo=True)

            cAllCtrls = []
            for f, sF in enumerate(sFeatures):
                cAllCtrls += self.dFeatureData[sF][1]
            sAllCtrls = [cC.sCtrl for cC in cAllCtrls]
            iClosestJoints = xforms.findClosestJoints(xforms.getPositionArray(sAllCtrls), self.sDynJoints)
            for c, sC in enumerate(sAllCtrls):
                sJoint = self.sDynJoints[iClosestJoints[c]]
                fMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sC, '%s.worldInverseMatrix' % sJoint],
                                                     bJustValues=True)
                nodes.addMatrixAttr(sC, 'dynMatrix', fMatrix)
                utils.addStringAttr(sC, 'dynJoint', sJoint)
        else:
            self.sDynJoints = sJoints

        # setting the joints
        sNewOutputs = []
        sSecondaryJoints = []
        for j, sJ in enumerate(self.sDynJoints):
            if not bCtrlScale and not sAutoSquashMultipls[j]:
                continue
            # sJ = sJoints[j]
            if bDistributeRotationStartToEnd and iCtrlTwist:  # we have both
                sNewJoints = [cmds.createNode('joint', name='jnt_%sSpineSquashA_%03d' % (self.sLimbName, j), parent=sJ)]
                sNewJoints.append(
                    cmds.createNode('joint', name='jnt_%sSpineSquash_%03d' % (self.sLimbName, j), parent=sNewJoints[0]))
            else:
                sNewJoints = [cmds.createNode('joint', name='jnt_%sSpineSquash_%03d' % (self.sLimbName, j), parent=sJ)]

            utils.addStringAttr(sNewJoints[-1], 'skinParent', sJ, bLock=True)
            utils.addStringAttr(sNewJoints[-1], 'replaceParent', sJ, bLock=True)
            utils.addStringAttr(sNewJoints[-1], 'unrealCollapseJoints', str([sJ] + sNewJoints[:-1]))

            for sNewJ in sNewJoints:
                utils.transferStringAttr('%s.%s' % (sJ, deformers.kPostRefJointAttr), sNewJ, bErrorIfNotExists=False)

            segments.updateTagAttr(sNewJoints, {'bDisable': True})
            segments.updateTagAttr(sJ, {'sSearchReplace': 'Spine;SpineSquash'})

            sNewOutputs.append(sNewJoints[-1])

            cmds.setAttr('%s.radius' % sNewJoints[0], cmds.getAttr('%s.radius' % sJoints[j]) * 1.25)
            cmds.setAttr('%s.radius' % sNewJoints[-1], cmds.getAttr('%s.radius' % sJoints[j]) * 1.5)

            if bCtrlScale:
                if sAutoSquashMultipls[j]:
                    nodes.createVectorMultiplyNode(sAutoSquashMultipls[j], sCtrlScales[j],
                                                   sTarget='%s.scale' % sNewJoints[0], sName='autoByCtrl_%d' % j)
                else:
                    cmds.connectAttr(sCtrlScales[j], '%s.scale' % sNewJoints[0])
            else:
                if sAutoSquashMultipls[j]:
                    nodes._connectOrSetVector(sAutoSquashMultipls[j], '%s.scale' % sNewJoints[0])
                    # cmds.connectAttr(sAutoSquashMultipls[j], '%s.scale' % sNewJoints[0])

            if bDistributeRotationStartToEnd:
                sBotToTop = utils.addAttr(sNewJoints[0], ln='botToTop', min=0, max=1, dv=aStraightWeights[j], k=True)
                sStrength = utils.addAttr(sNewJoints[0], ln='botToTopStrength', min=0, max=1, dv=1, k=True)
                if j > 0 and j < len(self.sDynJoints) - 1:
                    sParent = cmds.listRelatives(sNewJoints[0], p=True)[0]
                    sConstraint = cmds.orientConstraint([sParent, self.sDynJoints[0], self.sDynJoints[-1]], sNewJoints[0], mo=True)[0]
                    cmds.setAttr('%s.interpType' % sConstraint, 2)
                    nodes.createReverseNode(sStrength, sTarget='%s.%sW0' % (sConstraint, sParent))
                    nodes.createMultiplyNode(sStrength, nodes.createReverseNode(sBotToTop), sTarget='%s.%sW1' % (sConstraint, self.sDynJoints[0]))
                    nodes.createMultiplyNode(sStrength, sBotToTop, sTarget='%s.%sW2' % (sConstraint, self.sDynJoints[-1]))


            if iCtrlTwist and j < len(sJoints) - 1:
                if len(sNewJoints) == 1:
                    sNextJointPos = nodes.createDecomposeMatrix('%s.worldMatrix' % self.sDynJoints[j + 1])
                else:
                    fLocalPoint = nodes.createPointByMatrixNode(cmds.xform(self.sDynJoints[j + 1], q=True, ws=True, t=True),
                                                                '%s.worldInverseMatrix' % sNewJoints[0],
                                                                bJustValues=True)
                    sNextJointPos = nodes.createPointByMatrixNode(fLocalPoint, '%s.worldMatrix' % sNewJoints[0])

                sAimConstraint = constraints.aimConstraintEmpty(sNewJoints[-1], sParent=self.sCurrentFeatureGrp)
                cmds.setAttr('%s.worldUpType' % sAimConstraint, 1 if iCtrlTwist == 2 else 2)
                nodes.createPointByMatrixNode(sNextJointPos, '%s.parentInverseMatrix' % sNewJoints[-1], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                nodes.createMultMatrixNode([sJointUps[j], '%s.parentInverseMatrix' % sNewJoints[-1]], sTarget='%s.worldUpMatrix' % sAimConstraint)
                cmds.select(sNewJoints[-1])



        if self.iDynamics > 0:
            aCtrlPoints = xforms.getPositionArray([cC.sCtrl for cC in self.cDynamicBakeCtrls])
            aClosestJoints = xforms.findClosestJoints(aCtrlPoints, self.sDynJoints, sProjectAttrs=['skinParent'])
            sTempTransform = cmds.createNode('transform')

            for c,cC in enumerate(self.cDynamicBakeCtrls):
                sJoint = self.sDynJoints[aClosestJoints[c]]
                utils.addStringAttr(cC.sCtrl, 'sDynamicJoint', sJoint, bLock=True)
                # utils.addStringAttr(cC.sCtrl, 'sDynamicSwitch', '%s.simulationO' % sDynamicsMasterCtrl, bLock=True)
                cmds.parent(sTempTransform, cmds.listRelatives(cC.sCtrl, p=True)[0])
                cmds.setAttr('%s.ro' % sTempTransform, cmds.getAttr('%s.ro' % cC.sCtrl))
                cmds.xform(sTempTransform, m=cmds.xform(cC.sCtrl, q=True, m=True, ws=True), ws=True)

                sParentConstraint = cmds.parentConstraint(sJoint, sTempTransform, mo=True)[0]
                fOffsetTranslate = cmds.getAttr('%s.target[0].targetOffsetTranslate' % sParentConstraint)[0]
                fOffsetRotate = cmds.getAttr('%s.target[0].targetOffsetRotate' % sParentConstraint)[0]
                cmds.delete(sParentConstraint)

                utils.addStringAttr(cC.sCtrl, 'fDynamicOffsetTranslate', str(fOffsetTranslate), bLock=True)
                utils.addStringAttr(cC.sCtrl, 'fDynamicOffsetRotate', str(fOffsetRotate), bLock=True)
            cmds.delete(sTempTransform)


        j = 0
        for sName, sO in list(self.dOutputs.items()):
            if cmds.objectType(sO) == 'joint':
                if j < len(sNewOutputs) - 1:
                    self.dOutputs[sName] = sNewOutputs[j]
                    j += 1

        cmds.delete(sTempCurve)

        return [], {}


    @classmethod
    def staticPostSetup(cls):

        sInfoNodes = cmds.ls(et='pointOnCurveInfo')
        dSwitchPointInfoNodes = defaultdict(list)
        for sNode in sInfoNodes:
            sSwitchInfo = '%s.sSwitchCurveLimbName' % sNode
            if cmds.objExists(sSwitchInfo):
                dSwitchPointInfoNodes[cmds.getAttr(sSwitchInfo)].append(sNode)


        sGroup = cmds.createNode('transform', n='grp_dynamicsSpines_%s' % sVersion, p='modules')
        dCurves = utils.data.get('dSpineDynamicCurves_%s' % sVersion, xDefault=defaultdict(list))
        for sAttrCtrl, xCurves in list(dCurves.items()):

            sCurves = [xC[0] for xC in xCurves]
            iAllDynamics = [xC[1] for xC in xCurves]

            cmds.select(sCurves)
            mel.eval('makeCurvesDynamic 2 { "1", "0", "1", "1", "0"};')

            sFollicles = []
            for c,sCurveDyn in enumerate(sCurves):
                sSplits = sCurveDyn.split('_')
                sLimbName = '%s_%s' % (sSplits[1], sSplits[2])

                sFollicle = cmds.listRelatives(sCurveDyn, p=True)[0]
                cmds.parent(sFollicle, sCurveDyn, sGroup)
                cmds.setAttr('%s.pointLock' % sFollicle, 1 if iAllDynamics[c] == 1 else 3)
                sFollicle = cmds.rename(sFollicle, 'follicle_%s' % sLimbName)
                sFollicles.append(sFollicle)

                sOutCurve = cmds.listConnections('%s.outCurve' % sFollicle)[0]
                sOutCurve = cmds.rename(sOutCurve, '%sOUT' % sCurveDyn)

                sCurveInfoNodes = dSwitchPointInfoNodes[sLimbName]
                sOldOutCurve = cmds.listConnections('%s.inputCurve' % sCurveInfoNodes[0], s=True, d=False)
                for sCurveInfoNode in dSwitchPointInfoNodes[sLimbName]:
                    cmds.connectAttr('%s.worldSpace[0]' % sOutCurve, '%s.inputCurve' % sCurveInfoNode, force=True)
                cmds.delete(sOldOutCurve)

                cmds.setAttr('%s.inheritsTransform' % sOutCurve, False)
                cmds.parent(sOutCurve, sGroup)


            sHairSystem = cmds.listConnections('%s.currentPosition' % sFollicles[0])[0]
            if not cmds.listRelatives(sHairSystem, p=True): cmds.parent(sHairSystem, 'modules')

            # nodes.addSeparatorAttr(cCtrls[0].sCtrl, 'DYNAMICS')
            sMaster = utils.getMasterName()
            sStartFrameAttr = utils.addAttr(sMaster, ln='dynamicsStartFrame', at='long', defaultValue=1001, k=False,
                                            cb=True, bReturnIfExists=True)
            sEnabledAttr = utils.addAttr(sMaster, ln='chainSimulationOnOff', at='enum', en='off:on', defaultValue=0,
                                         k=False,
                                         cb=True, bReturnIfExists=True)

            sAttrCtrlSplits = sAttrCtrl.split('.')
            sSystemName = sAttrCtrlSplits[1] if len(sAttrCtrlSplits) > 1 else ''
            sAttrObject = sAttrCtrlSplits[0]
            if sAttrObject == 'master':
                sAttrObject = utils.getMasterName()

            if not cmds.objExists(sAttrObject):
                raise Exception('Attribute Object for Dynamics of Spine "%s" doesn\'t exist ("%s")' % (self.sLimbName, sAttrObject))
            sDampAttr = utils.addAttr(sAttrObject, ln='%sDynDamp' % sSystemName, k=True, defaultValue=1.0, bReturnIfExists=True)
            # sResistanceAttr = utils.addAttr(sAttrObject, ln='%sDynResistance' % sSystemName, k=True, defaultValue=1.0,
            #                                 bReturnIfExists=True)
            cmds.connectAttr(sDampAttr, '%s.damp' % sHairSystem)
            # cmds.connectAttr(sResistanceAttr, '%s.bendResistance' % sHairSystem)
            # cmds.connectAttr(sResistanceAttr, '%s.twistResistance' % sHairSystem)

            sNucleus = cmds.listConnections('%s.nextState' % sHairSystem)[0]
            cmds.connectAttr(sStartFrameAttr, '%s.startFrame' % sNucleus, force=True)
            cmds.connectAttr(sEnabledAttr, '%s.enable' % sNucleus, force=True)
            nodes.createConditionNode(sEnabledAttr, '==', False, 0, 3, sTarget='%s.simulationMethod' % sHairSystem)

            if not cmds.listRelatives(sNucleus, p=True): cmds.parent(sNucleus, 'modules')

            cmds.setAttr('%s.startCurveAttract' % sHairSystem, 1.0)
            cmds.setAttr("%s.attractionScale[0].attractionScale_Position" % sHairSystem, 0.8)
            cmds.setAttr("%s.attractionScale[0].attractionScale_FloatValue" % sHairSystem, 1)
            cmds.setAttr("%s.attractionScale[1].attractionScale_Position" % sHairSystem, 1)
            cmds.setAttr("%s.attractionScale[1].attractionScale_FloatValue" % sHairSystem, 0)

            cmds.setAttr('%s.collide' % sHairSystem, 0)


    def generateAttachers_fk(self, **kwargs):
        iPostRefJoints = kwargs['iPostRefJoints']
        dFkData = {'sTrs': 'tr', 'bMulti': True}
        if not iPostRefJoints:
            dFkData['sLocals'] = ['local']

        return {'fk_%02d' % j: dFkData for j in range(1, self.iSpineJointCount - 1, 1)}


    def feature_fk(self, bTranslation=True, bScale=False, bOrientToNearestStraightMatrix=False, iPostRefJoints=False, bChildCtrls=False, bSuperCtrls=False, bAimJoints=False,
                   _dComboboxItems={'iPostRefJoints':['OFF', 'ON (no attachers on fks)', 'ON (all fks have attacher)', 'OFF (all fks have attacher)']}):

        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        dAttacherBuildData = {}
        sJoints = self._duplicateBlueprintJoints('fk')

        if bAimJoints and iPostRefJoints in [1,2]:
            raise Exception('bAimJoints is not supported when PostRefJoints are ON (%s)' % self.sLimbName)

        self.cFkCtrls = []

        sPrev = None
        sAttrs = ['r']

        if bTranslation:
            sAttrs.append('t')
        if bScale:
            sAttrs.append('s')

        for j, sJoint in enumerate(sJoints[:-1]):
            cC = self._createCtrl5(sName=utils.getLetter(j), sMatch=sJoint, sAttrs=sAttrs, sShape='circleY',
                                  iColorIndex=self.iColorIndex, bChild=bChildCtrls, bSuper=bSuperCtrls,
                                  sParent=sPrev, fSize=cmds.getAttr('%s.radius' % sJoints[0])*3)

            if bOrientToNearestStraightMatrix:
                cC.orientToNearestStraightMatrix(bFromLocal=False)

            cC.adjustAxisOrientation([0, -90, -90])


            if j > 0:
                sOffset = cC.appendOffsetGroup('attach') if j == 0 else cC.sPasser
                dAttacherBuildData['fk_%02d' % j] = (utils.getDagPath(sOffset), cC)
                if iPostRefJoints == 0:
                    self.dLocalAttacherOutputs['fk_%02d' % j] = ['local.%s' % sPrev]

            self.cFkCtrls.append(cC)
            sPrev = cC.sOut

            if iPostRefJoints > 0:
                if iPostRefJoints < 3:
                    sRefJ = xforms.createJoint(self._createNodeName('ref', 'jnt', iIndex=j),
                                               sParent=cC.sPasser if iPostRefJoints in [2,3] else self.cFkCtrls[0].sPasser,
                                               sMatch=sJoint)
                    cmds.setAttr('%s.radius' % sRefJ, cmds.getAttr('%s.radius' % sJoint) * 1.25)
                    cmds.connectAttr('%s.rigVis' % self.sMasterGlobal, '%s.v' % sRefJ)

                    utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, sRefJ)
                    utils.getZeroJoint(self.sModulesGlobal)



                if iPostRefJoints in [2,3]:
                    cC.sScaleCompensateOut = cmds.createNode('transform', n='%sNoScale' % cC.sOut, p=cC.sCtrl)
                    fSliderScale = cmds.getAttr('%s.s' % cC.sSlider)[0]
                    cmds.setAttr('%s.s' % cC.sScaleCompensateOut, 1.0 / fSliderScale[0], 1.0 / fSliderScale[1], 1.0 / fSliderScale[2])
                    if j > 0:
                        sOverwriteGrp = cC.appendOffsetGroup('moveinparentspace', bBelowPasser=True, bMatchParentTransform=True)
                        sOverrideLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser,
                                                                           '%s.worldInverseMatrix' % cPrev.sPasser,
                                                                           '%s.worldMatrix' % cPrev.sScaleCompensateOut,
                                                                           '%s.worldInverseMatrix' % cC.sPasser])
                        nodes.createDecomposeMatrix(sOverrideLocalMatrix, sTargetPos='%s.t' % sOverwriteGrp, sTargetRot='%s.r' % sOverwriteGrp)
            cPrev = cC

        for c in range(len(self.cFkCtrls)):
            if bAimJoints and c < len(self.cFkCtrls)-1:
                constraints.matrixParentConstraint(self.cFkCtrls[c].sOut, sJoints[c], skipRotate=['x','y','z'])
                cmds.aimConstraint(self.cFkCtrls[c+1].sOut, sJoints[c], wuo=self.cFkCtrls[c].sOut, wut='objectrotation', aim=[self.fSideMultipl,0,0])
            else:
                constraints.matrixParentConstraint(self.cFkCtrls[c].sOut, sJoints[c])

            if c > 0:
                cmds.controller(self.cFkCtrls[c].sCtrl, self.cFkCtrls[c - 1].sCtrl, parent=True)

        # constrain last joint
        constraints.matrixParentConstraint(self.cFkCtrls[-1].sOut, sJoints[-1], mo=True, skipScale=['x', 'y', 'z'])
        # cmds.scaleConstraint(self.cFkCtrls[-1].sOut, sJoints[-1])

        dAttacherBuildData['root'] = (utils.getDagPath(self.cFkCtrls[0].sPasser), self.cFkCtrls[0])
        sOuts = sJoints

        # global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cFkCtrls[0].sPasser)

        # for matching we assume that there are as many self.cFkCtrls as sJoints
        sMatchScript = ''
        # aCtrls = xforms.getPositionArray([cC.sCtrl for cC in self.cFkCtrls])

        for c, cC in enumerate(self.cFkCtrls):
            sMatchScript += match.generateMatchingConstrainCommand(c, sOuts, cC.sCtrl,
                                                                   iConstraintType=match.Type.parentConstraint,
                                                                   bOffsetR=True, bOffsetT=True)
        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)

        # root output
        sRootOut = self._createTransform('root_fk', sParent=self.sCurrentFeatureGrp, sMatch=sOuts[0])
        constraints.matrixParentConstraint(self.cFkCtrls[0].sOut, sRootOut, mo=True, skipScale=[])
        sOuts.insert(0, sRootOut)

        self.cDynamicBakeCtrls += self.cFkCtrls
        return sOuts, self.cFkCtrls, dAttacherBuildData



    def generateAttachers_ikThreeJoints(self, **kwargs):

        # print '\n\n\ngenerateAttachers_ikSpline: .......'

        bMiddleCtrl = True if self.iSpineJointCount > 2 else False
        bAttachMiddleToLine = kwargs.get('bAttachMiddleToLine', True)
        dAttachers = OrderedDict()

        dAttachers['ikBase'] = {'sTrs': 'tr', 'bMulti': True}
        if bMiddleCtrl:
            dAttachers['ikMiddle'] = {'sTrs': 'tr', 'bMulti': True, 'sLocals': ['local', 'base', 'top'] if bAttachMiddleToLine else []}
        dAttachers['ikTop'] = {'sTrs': 'tr', 'bMulti': True, 'sLocals': ['base'] if bAttachMiddleToLine else []}
        return dAttachers


    def feature_ikThreeJoints(self, bOrientToNearestStraightMatrixBase=False, bOrientToNearestStraightMatrixMiddle=False,
                         bOrientToNearestStraightMatrixTop=False, bAttachMiddleToLine=True):

        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        sJoints = self._duplicateBlueprintJoints('ik')

        if len(sJoints) not in [2,3]:
            raise Exception('%s: feature ikThreeJoints needs to have a joint length of 2 or 3' % self.sLimbName)

        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        dAttacherBuildData = {}


        cBase = self._createCtrl5(sName='baseIk', sMatch=list(self.dBlueprints.values())[0], sAttrs=['t', 'r', 's'],
                                 fSize=4.0 * self.fCtrlSize, fScaleShape=(1, 0.3, 1),
                                 iColorIndex=self.iColorIndex,
                                 bPivot=True, bSuper=True)
        cBase.adjustAxisOrientation([0, -90, -90])
        sBaseSlider = cBase.appendOffsetGroup('slider')
        dAttacherBuildData['ikBase'] = (utils.getDagPath(cBase.sPasser), cBase)

        sBaseR = cBase.appendOffsetGroup('baserotation')
        if self.sSide == 'r':
            cmds.setAttr('%s.s' % sBaseSlider, -1, -1, -1)

        if bOrientToNearestStraightMatrixBase:
            cBase.orientToNearestStraightMatrix()

        cChest = self._createCtrl5(sName='topIk', sMatch=sJoints[-1], iColorIndex=self.iColorIndex,
                                  sAttrs=['t', 'r'], fSize=4.0,
                                  fScaleShape=(1*self.fCtrlSize, 0.3*self.fCtrlSize, 1*self.fCtrlSize), bSuper=True, bPivot=True)
        cChest.adjustAxisOrientation([0, -90, -90])
        sChestSlider = cChest.appendOffsetGroup('slider')
        if self.sSide == 'r':
            cmds.setAttr('%s.s' % sChestSlider, -1, -1, -1)
        if bOrientToNearestStraightMatrixTop:
            cChest.orientToNearestStraightMatrix()

        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, cBase.sPasser)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, cChest.sPasser)

        cmds.pointConstraint(cBase.sOut, sJoints[0])
        constraints.matrixParentConstraint(cChest.sOut, sJoints[-1], mo=True)
        # creating middle controls
        #
        if self.iSpineJointCount == 3:
            cMiddle = self._createCtrl5(sName='midIk', sMatch=sJoints[1], iColorIndex=self.iColorIndex,
                                      sAttrs=['t'], fSize=4.0, sShape='squareY',
                                      fScaleShape=(1*self.fCtrlSize, 0.3*self.fCtrlSize, 1*self.fCtrlSize), bSuper=True, bPivot=True)
            cMiddle.adjustAxisOrientation([0, -90, -90])

            if bOrientToNearestStraightMatrixMiddle:
                cMiddle.orientToNearestStraightMatrix()
            cmds.controller(cMiddle.sCtrl, cBase.sCtrl, parent=True)
            cmds.controller(cChest.sCtrl, cMiddle.sCtrl, parent=True)
            cCtrls = [cBase, cMiddle, cChest]
            cmds.pointConstraint(cMiddle.sOut, sJoints[1])
            sMidPoleVector = self._createTransform('midPolevector')
            fDistance = xforms.distanceBetween(sJoints[0], sJoints[-1])
            fPosA = nodes.createPointByMatrixNode([0,fDistance*0.5, 0], '%s.worldMatrix' % cBase.sOut)
            fPosB = nodes.createPointByMatrixNode([0,fDistance*0.5, 0], '%s.worldMatrix' % cChest.sOut)
            nodes.createBlendNode(0.5, fPosA, fPosB, bVector=True, sTarget='%s.t' % sMidPoleVector)
            # cmds.aimConstraint(cMiddle.sOut, sJoints[0], wut='objectrotation', wuo=cBase.sOut)
            constraints.aimConstraintFromTransforms(sJoints[0], cMiddle.sOut, cBase.sOut, bOrientUp=True, sParent=self.sCurrentFeatureGrp)
            # cmds.aimConstraint(cChest.sOut, sJoints[1], wut='object', wuo=sMidPoleVector)
            constraints.aimConstraintFromTransforms(sJoints[1], cChest.sOut, sMidPoleVector, sParent=self.sCurrentFeatureGrp)
            dAttacherBuildData['ikMiddle'] = (utils.getDagPath(cMiddle.sPasser), cMiddle)
            cmds.scaleConstraint(self.sCurrentFeatureGrp, cMiddle.sPasser)

            if bAttachMiddleToLine:
                sMiddleAimGrp = self._createTransform('middleGrp')
                sMiddleAimScaledGrp = self._createTransform('middleScaleGrp', sParent=sMiddleAimGrp)
                sGlobalScale = '%s.outputScaleX' % nodes.createDecomposeMatrix('%s.worldMatrix' % cBase.sPasser).split('.')[0]
                nodes.createDistanceNode(nodes.getWorldPoint(cChest.sOut), nodes.getWorldPoint(cBase.sOut),
                                         sDivide=sGlobalScale,
                                         fNormalized=cmds.getAttr('%s.tx' % sJoints[1]),
                                         sTarget='%s.tx' % sMiddleAimScaledGrp)
                cmds.scaleConstraint(self.sCurrentFeatureGrp, sMiddleAimGrp)

                cmds.pointConstraint(cBase.sOut, sMiddleAimGrp)
                self.dLocalAttacherOutputs['ikMiddle'] = ['local.%s' % sMiddleAimScaledGrp, 'base.%s' % cBase.sOut, 'top.%s' % cChest.sOut]

            cmds.aimConstraint(cChest.sOut, sMiddleAimGrp, wut='objectrotation', wuo=cChest.sOut)
            # constraints.aimConstraintFromTransforms(sMiddleAimGrp, cChest.sOut, cChest.sOut, sParent=self.sCurrentFeatureGrp)
        else:
            cmds.controller(cChest.sCtrl, cBase.sCtrl, parent=True)
            cCtrls = [cBase, cChest]
            # cmds.aimConstraint(cChest.sOut, sJoints[0], wut='objectrotation', wuo=cChest.sOut)
            sAimConstraint = constraints.aimConstraintEmpty(sJoints[0], sParent=self.sCurrentFeatureGrp)
            nodes.createPointByMatrixNode(nodes.getWorldPoint(cChest.sCtrl), '%s.parentInverseMatrix' % sJoints[0], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            nodes.createMultMatrixNode(['%s.worldMatrix' % cChest.sOut, '%s.parentInverseMatrix' % sJoints[0]], sTarget='%s.worldUpMatrix' % sAimConstraint)


        dAttacherBuildData['root'] = (utils.getDagPath(cBase.sPasser), cBase)
        dAttacherBuildData['ikBase'] = (utils.getDagPath(sBaseR), cBase)
        dAttacherBuildData['ikTop'] = (utils.getDagPath(cChest.sPasser), cChest)
        if bAttachMiddleToLine:
            self.dLocalAttacherOutputs['ikTop'] = ['base.%s' % cBase.sOut]

        # scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)


        sOuts = sJoints

        # root output
        sRootOut = self._createTransform('root_fk', sParent=self.sCurrentFeatureGrp, sMatch=sOuts[0])
        constraints.matrixParentConstraint(cCtrls[0].sOut, sRootOut, mo=True, skipScale=[])
        sOuts.insert(0, sRootOut)

        self.cDynamicBakeCtrls += cCtrls
        return sOuts, cCtrls, dAttacherBuildData




    def generateAttachers_ikPoleVector(self, **kwargs):

        dAttachers = OrderedDict()
        dAttachers['ikPoleBase'] = {'sTrs': 'tr', 'bMulti': True}
        dAttachers['ikPoleTop'] = {'sTrs': 'tr', 'bMulti': True}
        dAttachers['ikPolePole'] = {'sTrs': 'tr', 'bMulti': True}
        return dAttachers


    def feature_ikPoleVector(self, bOrientToNearestStraightMatrixBase=False, bOrientToNearestStraightMatrixTop=False):

        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        sJoints = self._duplicateBlueprintJoints('ikPole')
        cmds.makeIdentity(sJoints[1], r=True, apply=True)

        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        dAttacherBuildData = {}


        cBase = self._createCtrl5(sName='ikRoot', sMatch=list(self.dBlueprints.values())[0], sAttrs=['t', 'r', 's'],
                                 fSize=4.0 * self.fCtrlSize, fScaleShape=(1, 0.3, 1),
                                 iColorIndex=self.iColorIndex,
                                 bPivot=True, bSuper=True)
        cBase.adjustAxisOrientation([0, -90, -90])
        sBaseSlider = cBase.appendOffsetGroup('slider')
        dAttacherBuildData['ikPoleBase'] = (utils.getDagPath(cBase.sPasser), cBase)


        if self.sSide == 'r':
            cmds.setAttr('%s.s' % sBaseSlider, -1, -1, -1)

        if bOrientToNearestStraightMatrixBase:
            cBase.orientToNearestStraightMatrix()

        cTop = self._createCtrl5(sName='ikTop', sMatch=sJoints[-1], iColorIndex=self.iColorIndex,
                                  sAttrs=['t', 'r'], fSize=4.0,
                                  fScaleShape=(1*self.fCtrlSize, 0.3*self.fCtrlSize, 1*self.fCtrlSize), bSuper=True, bPivot=True)
        cTop.adjustAxisOrientation([0, -90, -90])


        sChestSlider = cTop.appendOffsetGroup('slider')
        if self.sSide == 'r':
            cmds.setAttr('%s.s' % sChestSlider, -1, -1, -1)
        if bOrientToNearestStraightMatrixTop:
            cTop.orientToNearestStraightMatrix()


        cmds.pointConstraint(cBase.sOut, sJoints[0])

        print('self.dBlueprints.keys: ', list(self.dBlueprints.keys()))
        fPolePos = xforms.fPoleVectorPos(self.dBlueprints['spine_000'], self.dBlueprints['spine_001'], self.dBlueprints['spine_end'])
        cPole = self._createCtrl5(sName='midIk', sMatch=sJoints[1], fMatchPos=fPolePos, iColorIndex=self.iColorIndex,
                                  sAttrs=['t'], fSize=4.0, sShape='squareY',
                                  fScaleShape=(1*self.fCtrlSize, 0.3*self.fCtrlSize, 1*self.fCtrlSize), bSuper=True, bPivot=True)
        cPole.adjustAxisOrientation([0, -90, -90])

        sIk = xforms.createIk(sJoints[0], sJoints[-1], sPole=cPole.sOut, sParent=self.sCurrentFeatureGrp)
        cmds.pointConstraint(cTop.sOut, sIk)
        cmds.controller(cPole.sCtrl, cBase.sCtrl, parent=True)
        cmds.controller(cTop.sCtrl, cPole.sCtrl, parent=True)

        dAttacherBuildData['root'] = (utils.getDagPath(cBase.sPasser), cBase)
        constraints.matrixParentConstraint(cBase.sPasser, cPole.sPasser, mo=True)
        constraints.matrixParentConstraint(cBase.sPasser, cTop.sPasser, mo=True)
        dAttacherBuildData['ikPoleBase'] = (utils.getDagPath(cBase.appendOffsetGroup('attach')), cBase)
        dAttacherBuildData['ikPolePole'] = (utils.getDagPath(cPole.appendOffsetGroup('attach')), cPole)
        dAttacherBuildData['ikPoleTop'] = (utils.getDagPath(cTop.appendOffsetGroup('attach')), cTop)

        # scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)


        sOuts = sJoints

        # root output
        sRootOut = self._createTransform('root_fk', sParent=self.sCurrentFeatureGrp, sMatch=sOuts[0])
        constraints.matrixParentConstraint(cBase.sOut, sRootOut, mo=True, skipScale=[])
        sOuts.insert(0, sRootOut)

        return sJoints, [cBase, cPole, cTop], dAttacherBuildData



    def generateAttachers_simple(self, **kwargs):
        dData = {'sTrs': 'tr', 'bMulti': True}
        return {'ctrl_%02d' % i: dData for i in range(self.iSpineJointCount)}


    def feature_simple(self, bTranslation=True, bScale=False, bPostRefJoints=False):
        if self.bBlueprintsCurve:
            self._createBpJointsFromCurves()

        dAttacherBuildData = {}
        sJoints = self._duplicateBlueprintJoints('simple')

        cCtrls = []

        sPrev = None
        sAttrs = ['r']

        if bTranslation:
            sAttrs.append('t')
        if bScale:
            sAttrs.append('s')

        sCtrlParent = self._createTransform('ctrlParent', sParent=self.sCtrlsGlobal)
        for j, sJoint in enumerate(sJoints):
            cC = self._createCtrl5(sName=utils.getLetter(j), sMatch=sJoint, sAttrs=sAttrs, sShape='squareY',
                                  iColorIndex=self.iColorIndex,
                                  sParent=sCtrlParent)
            cC.adjustAxisOrientation([0, -90, -90])

            dAttacherBuildData['ctrl_%02d' % j] = (utils.getDagPath(cC.sPasser), cC)
            constraints.matrixParentConstraint(cC.sOut, sJoint)
            if bPostRefJoints:
                sRef = xforms.createTransform('%s_ref' % sJoint, sParent=cC.sSlider, sMatchXform=sJoint)
                utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, sRef)
            if j > 0:
                self.dLocalAttacherOutputs['ik_%02d' % j] = ['local.%s' % sPrev]

            cCtrls.append(cC)

            if j == 0:
                dAttacherBuildData['root'] = (utils.getDagPath(sCtrlParent), cCtrls[0])
            else:
                constraints.matrixParentConstraint(cCtrls[0].sPasser, cCtrls[j].sPasser, mo=True, skipScale=['x','y','z'])

            sMessageAttr = utils.addAttr(cC.sCtrl, ln='jointMessage', at='message')
            cmds.connectAttr('%s.message' % sJoint, sMessageAttr)



        sOuts = sJoints

        # global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, sCtrlParent)

        # for matching we assume that there are as many cCtrls as sJoints
        sMatchScript = ''
        # aCtrls = xforms.getPositionArray([cC.sCtrl for cC in cCtrls])

        for c, cC in enumerate(cCtrls):
            sMatchScript += match.generateMatchingConstrainCommand(c, sOuts, cC.sCtrl,
                                                                   iConstraintType=match.Type.parentConstraint,
                                                                   bOffsetR=True, bOffsetT=True)
        match.addAttr(self.sCurrentFeatureGrp, sMatchScript)

        # root output
        sRootOut = self._createTransform('root_fk', sParent=self.sCurrentFeatureGrp, sMatch=sOuts[0])
        constraints.matrixParentConstraint(cCtrls[0].sOut, sRootOut, mo=True, skipScale=[])
        sOuts.insert(0, sRootOut)

        return sOuts, cCtrls, dAttacherBuildData




    def buildBlueprintRig(self, lParent=None):

        baseLimb._LBaseLimb.buildBlueprintRig(self)

        if self.bBlueprintsCurve:

            sBpJoints = cmds.ls('bp_%s_spine' % self.sLimbName)
            if sBpJoints:
                raise Exception('You have set blueprintsCurve for %s, but there are joints (%s), please delete those joints' % (
                self.sLimbName, ', '.join(sBpJoints)))

            sBpRigCurve = cmds.duplicate(self.sBlueprintCurves[0], n='%s_RIG' % self.sBlueprintCurves[0])[0]
            sBpUpRigCurve = cmds.duplicate(self.sBlueprintCurves[1], n='%s_RIG' % self.sBlueprintCurves[1])[0]

            for sC in [sBpRigCurve, sBpUpRigCurve]:
                cmds.setAttr('%s.t' % sC, lock=True)
                cmds.setAttr('%s.r' % sC, lock=True)
                cmds.setAttr('%s.s' % sC, lock=True)

            sConnectedBpCurve = cmds.duplicate(self.sBlueprintCurves[0], n='connected:%s' % self.sBlueprintCurves[0])[0]
            sConnectedBpUpCurve = cmds.duplicate(self.sBlueprintCurves[1], n='connected:%s' % self.sBlueprintCurves[1])[0]
            curves.fixShapeName(sConnectedBpCurve)
            curves.fixShapeName(sConnectedBpUpCurve)
            cmds.setAttr('%s.v' % sConnectedBpCurve, False)
            cmds.setAttr('%s.v' % sConnectedBpUpCurve, False)
            self.sConnectedBlueprintCurves = [sConnectedBpCurve, sConnectedBpUpCurve]
            self.sRigBlueprintCurves = [sBpRigCurve, sBpUpRigCurve]

            for c, sC in enumerate([sBpRigCurve, sBpUpRigCurve]):
                cmds.blendShape(sC, self.sConnectedBlueprintCurves[c], w=[0, 1],
                                n='%s_defaultBs' % self.sConnectedBlueprintCurves[c].split(':')[-1])

            cmds.parent(sConnectedBpCurve, sConnectedBpUpCurve, 'connected:%s' % self.sBpSkelGrp)
            cmds.parent(sBpRigCurve, sBpUpRigCurve, self.sBpTopGrp)
            self.cBpAll = []
            self.cBpRoots = []

        else:
            cBpHips = blueprints.createGroupCtrl(self.dBlueprints['spine_000'], sSide=self.sSide,
                                                 xCtrl='%sGrpRoot' % self.sName,
                                                 sParent=self.sBpTopGrp, fCtrlSize=5.0)
            cBpEnd = blueprints.createGroupCtrl(self.dBlueprints['spine_end'], sSide=self.sSide,
                                                xCtrl='%sGrpspine_end' % self.sName,
                                                sParent=self.sBpTopGrp, fCtrlSize=5.0)

            cSpineCtrls = blueprints.createChainCtrls(list(self.dBlueprints.values()), sSide=self.sSide,
                                                      xRoot='%sRoot' % self.sName, xAim='%sEnd' % self.sName,
                                                      xPole='%sPole' % self.sName,
                                                      xElbows=['%sSpine0' % self.sName, '%sSpine1' % self.sName,
                                                               '%sSpine2' % self.sName,
                                                               '%sSpine3' % self.sName], sParent=self.sBpTopGrp, bLockTz=False)
            self.cBpAll = cSpineCtrls


            constraints.matrixParentConstraint(cBpHips.sOut, cSpineCtrls[0].sPasser, mo=True, skipScale=['x', 'y', 'z'])
            constraints.matrixParentConstraint(cBpEnd.sOut, cSpineCtrls[-1].sPasser, mo=True, skipScale=['x', 'y', 'z'])

            self.cBpRoots = [cBpHips, cBpEnd]

            self.dBpOutputs['root'] = cBpHips
            self.dBpOutputs['spine_end'] = cBpEnd

            cmds.controller(cSpineCtrls[0].sCtrl, cBpHips.sCtrl, parent=True)
            # cmds.controller(cSpineCtrls[-1].sCtrl, cBpEnd.sCtrl, parent=True)


            self.cBpSymmetry = [cBpHips, cBpEnd] + cSpineCtrls
            self.cLastBp = cBpEnd


    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren={}):
        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)


    @classmethod
    def rightClickCommand_createCurve(cls, ddData):
        sLimbName = '%s_%s' % (ddData['dArgsFILE']['sSide'], ddData['dArgsFILE']['sName'])
        curves.createSpineCurves(sLimbName, sParent='_blueprints')


    @classmethod
    def rightClickCommand_transferToSquashJointsSelected(cls, ddData):
        sSelBefore = cmds.ls(sl=True)
        sLimbName = '%s_%s' % (ddData['dArgsFILE']['sSide'], ddData['dArgsFILE']['sName'])
        weights.moveSkinClusterWeights(xJoints={'jnt_%sSpine_???*' % sLimbName:'Spine,SpineSquash'})
        cmds.select(sSelBefore)

'''
sBlendAttributes_m_spine_feature_ikSpline_spineBaseIk_ctrl = functions.blendAttributesFunction(eAttrParent=spineBaseIk_ctrl.eControl, sAttrNames=['space_cog', 'space_global'], xWeights=[1.0, 0.0])
sBlendAttributes_m_spine_feature_ikSpline_spineChestIk_ctrl = functions.blendAttributesFunction(eAttrParent=spineChestIk_ctrl.eControl, sAttrNames=['space_base', 'space_global', 'space_cog'], xWeights=[0.0, 0.0, 1.0])
sBlendAttributes_m_spine_feature_ikSpline_spineMidIk_A_ctrl = functions.blendAttributesFunction(eAttrParent=spineMidIk_A_ctrl.eControl, sAttrNames=['space_local', 'space_base', 'space_top'], xWeights=[1.0, 0, 0])
sBlendAttributes_m_spine_feature_ikSpline_spineMidIk_B_ctrl = functions.blendAttributesFunction(eAttrParent=spineMidIk_B_ctrl.eControl, sAttrNames=['space_local', 'space_base', 'space_top'], xWeights=[1.0, 0, 0])


'''