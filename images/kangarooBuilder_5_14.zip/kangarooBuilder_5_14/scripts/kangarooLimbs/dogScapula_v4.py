###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.utilFunctions as utils
import kangarooTabTools.segments as segments
import kangarooLimbs.baseLimb as baseLimb



class LDogScapula(baseLimb._LBaseLimb):

    def __init__(self, sName='scapula', sSide='l', #bMirror=False,
                bForceParentSkeletonToRoot=False,
                fBlueprintsCreationTranslationOffset = (0.0, 0.0, 1.0),
                fBlueprintsCreationRotationOffset = (0.0, 0.0, 0.0), iSegmentsPriority=50):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset,
                                     bRemoveEndSkinJoint=False, iSegmentsPriority=iSegmentsPriority)
        self.dOutputs['end'] = None
        self.tArm = None
        self.sDefaultFeatures = ['feature_fk']


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':True},
                'scale': {'sTrs':'s', 'bMulti':False}}

    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(0.2,0,1.5, 0,0,1), (5.2,0,1.5, 0,0,1)]], [['start', 'end']])
        return sNewJoints


    def feature_fk(self, fHorizLinearFront=0.5, fHorizLinearBack=1.0):
        dAttacherBuildData = {}
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]
        sJoint = xforms.createJoint('%s_fk' % sBlueprints[1], sMatch=sBlueprints[1], sParent=self.sCurrentFeatureGrp)
        xforms.matchRadius(sJoint, sBlueprints[1], 2)
        self.sFkPasser = self._createTransform(sName='fk', sMatch=self.dBlueprints['start'], bLocator=True)
        sFkAimer = self._createTransform(sName='aimer', sParent=self.sFkPasser, bLocator=True)
        cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % self.sFkPasser)
        sFkAimerChildAtCtrl = self._createTransform('aimerChild', sParent=sFkAimer, sMatch=sBlueprints[1])
        sPushOutByCtrlTx = self._createTransform('pushOut', sParent=sFkAimerChildAtCtrl)

        fSize = cmds.getAttr('%s.radius' % sBlueprints[1]) * 10.0
        self.cIk = self._createCtrl5(sName='ik', sMatch=self.dBlueprints['end'], sAttrs=['rx', 'ty', 'tz'], sShape='cube',
                               fSize=fSize, bChild=True, fTranslateShape=(0, fSize*0.5, 0))
        self.cIk.adjustAxisOrientation([-90,0,0])
        self.sAutoConstrainer = self.cIk.appendOffsetGroup('auto')
        sTxGroup = self.cIk.appendOffsetGroup('tx')
        sSlideUpDownAttr = utils.addAttr(self.cIk.sCtrl, ln='slideUpDown', k=True)
        sSlideUpDownGrp = xforms.insertParent(self.cIk.sOut, sName=self._createNodeName('upDown', 'grp'), bMatchParentTransform=True)
        cmds.connectAttr(sSlideUpDownAttr, '%s.ty' % sSlideUpDownGrp)

        sCtrlAnimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sSlideUpDownGrp, '%s.worldInverseMatrix' % cmds.listRelatives(self.cIk.sCtrl, p=True)[0]])
        sCtrlAnimDecomp = nodes.createDecomposeMatrix(sCtrlAnimMatrix)
        
        sTxAttr = utils.addAttr(self.cIk.sCtrl, ln='pushOut', k=True)
        sRotzAttr = utils.addAttr(self.cIk.sCtrl, ln='rotZ', k=True)
        cmds.connectAttr(sTxAttr, '%s.tx' % sTxGroup)
        xforms.matrixParentConstraint(self.sFkPasser, self.cIk.sPasser, mo=True)
        
        sHorizLinearFront = utils.addAttr(self.cIk.sPasser, ln='horizLinearFront', k=True, min=0, max=1, dv=fHorizLinearFront)
        sHorizLinearBack = utils.addAttr(self.cIk.sPasser, ln='horizLinearBack', k=True, min=0, max=1, dv=fHorizLinearBack)
        sHorizLinear = nodes.createConditionNode('%sZ' % sCtrlAnimDecomp, '>', 0, sHorizLinearFront, sHorizLinearBack)
        
        dAttacherBuildData['root'] = (utils.getDagPath(self.sFkPasser), self.cIk)

        sIkSibling = self._createTransform('ikSibling', sMatch=self.cIk.sCtrl, sParent=cmds.listRelatives(self.cIk.sCtrl, p=True)[0])
        cmds.connectAttr('%sY' % sCtrlAnimDecomp, '%s.ty' % sIkSibling)
        nodes.createBlendNode(sHorizLinear, 0, '%sZ' % sCtrlAnimDecomp, sTarget='%s.tz' % sIkSibling)
        cmds.aimConstraint(sIkSibling, sFkAimer, aim=[self.fSideMultipl,0,0], wut='objectrotation', wuo=self.cIk.sOut)
        cmds.aimConstraint(self.sFkPasser, sFkAimerChildAtCtrl, wut='objectrotation', wuo=self.cIk.sOut, aim=[-1,0,0], u=[0,1,0], wu=[0,0,-1])
        
        cmds.connectAttr(sTxAttr, '%s.tx' % sPushOutByCtrlTx)
        if self.sSide == 'r':
            nodes.createMultiplyNode(sRotzAttr, -1.0, sTarget='%s.rz' % sPushOutByCtrlTx)
        else:
            cmds.connectAttr(sRotzAttr, '%s.rz' % sPushOutByCtrlTx)

        # linear motion
        sFrontBack = '%sZ' % sCtrlAnimDecomp
        # if self.sSide == 'r':
        #     sFrontBack = nodes.createMultiplyNode(sFrontBack, -self.fSideMultipl)
        nodes.createBlendNode(sHorizLinear, sFrontBack, 0, sTarget='%s.tz' % sPushOutByCtrlTx)

        xforms.matrixParentConstraint(sPushOutByCtrlTx, sJoint, mo=True)
        #global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.sFkPasser)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cIk.sPasser)

        return [sJoint], [self.cIk], dAttacherBuildData


    def unreal_feature_fk(self):
        if self.sLimbName == 'm_global':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal

            sAutoDriverLimb = self.tArm.sLimbName


            sCommands = []
            sCommands.append('controllers.setNewColumn()')

            sPivot = utilsUnreal.createUnrealNull('eStrPivot_%s' % self.sLimbName, list(self.dBlueprints.values())[0], sWriteCommands=sCommands)
            cStrCtrl = utilsUnreal.createUnrealCtrl(self.cIk, sWriteCommands=sCommands)

            utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_fk', sWriteCommands=sCommands)

            # sHandCtrlName = None
            # if self.tArm:
            #     sHandCtrlName = self.tArm.cPrint.sCtrl

            sJoint = self.getOutputFullNames()[0]
            sFunctionNodeName = '%s_feature' % self.sLimbName


            sCommands.append("%s = functions.createScapulaFunction('%s', %s, '%s', '%s', %s, '%s')" % (sFunctionNodeName, self.sSide, cStrCtrl, sJoint, cmds.listRelatives(sJoint, p=True)[0], sPivot, sAutoDriverLimb))

            utilsUnreal.initiateAttacherDictCommand('feature_fk', sWriteCommands=sCommands)
            utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_fk', sFunctionNodeName, sWriteCommands=sCommands)

            return sCommands, [], []


    # TODO: make same as the dog and horse part, and then create just one function
    def childrenConnect_LArmLeg(self, _lChildren):
        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm
        if hasattr(tArm, 'bAutoClavicle') and tArm.bAutoClavicle:
            if len(tArm.sClavAimTransformPerFeature) > 1:
                sArmOutMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % sT for sT in tArm.sClavAimTransformPerFeature],
                                                            ['%s.weight' % sF for sF in tArm.sFeatureGrps])
            else:
                sArmOutMatrix = '%s.worldMatrix' % tArm.sClavAimTransformPerFeature[0]

            sAutoHorizAttr = utils.addAttr(self.cIk.sCtrl, ln='autoHoriz', min=0.0, max=1.0, k=True)
            sAutoVertAttr = utils.addAttr(self.cIk.sCtrl, ln='autoVert', min=0.0, max=1.0, k=True)
            sAutoOutput = nodes.createDecomposeMatrix(sArmOutMatrix)
            sLocalAutoOutput = nodes.createPointByMatrixNode(sAutoOutput, '%s.worldInverseMatrix' % cmds.listRelatives(self.sAutoConstrainer, p=True)[0])
            fDefaultLocalAutoOutput = cmds.getAttr(sLocalAutoOutput)[0]
            sOffsetAutoValues = nodes.createVectorAdditionNode([sLocalAutoOutput, fDefaultLocalAutoOutput], sOperation='minus')
            nodes.createBlendNode(sAutoHorizAttr, '%sz' % sOffsetAutoValues, 0, sTarget='%s.tz' % self.sAutoConstrainer)
            nodes.createBlendNode(sAutoVertAttr, '%sy' % sOffsetAutoValues, 0, sTarget='%s.ty' % self.sAutoConstrainer)

            # the replacement for attacher "root_clav"
            for mDag in tArm.mAttachToClavicleTransformsOnAuto:
                xforms.matrixParentConstraint(self.dOutputs['end'], mDag.partialPathName(), mo=True, skipScale=['x','y','z'])



    def childrenConnect_LDogArmLeg(self, _lChildren):
        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm
        if hasattr(tArm, 'bAutoClavicle') and tArm.bAutoClavicle:
            if len(tArm.sClavAimTransformPerFeature) > 1:
                sArmOutMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % sT for sT in tArm.sClavAimTransformPerFeature],
                                                            ['%s.weight' % sF for sF in tArm.sFeatureGrps])
            else:
                sArmOutMatrix = '%s.worldMatrix' % tArm.sClavAimTransformPerFeature[0]

            sAutoHorizAttr = utils.addAttr(self.cIk.sCtrl, ln='autoHoriz', min=0.0, max=1.0, k=True)
            sAutoVertAttr = utils.addAttr(self.cIk.sCtrl, ln='autoVert', min=0.0, max=1.0, k=True)
            sAutoOutput = nodes.createDecomposeMatrix(sArmOutMatrix)
            sLocalAutoOutput = nodes.createPointByMatrixNode(sAutoOutput, '%s.worldInverseMatrix' % cmds.listRelatives(self.sAutoConstrainer, p=True)[0])
            fDefaultLocalAutoOutput = cmds.getAttr(sLocalAutoOutput)[0]
            sOffsetAutoValues = nodes.createVectorAdditionNode([sLocalAutoOutput, fDefaultLocalAutoOutput], sOperation='minus')
            nodes.createBlendNode(sAutoHorizAttr, '%sz' % sOffsetAutoValues, 0, sTarget='%s.tz' % self.sAutoConstrainer)
            nodes.createBlendNode(sAutoVertAttr, '%sy' % sOffsetAutoValues, 0, sTarget='%s.ty' % self.sAutoConstrainer)

            # the replacement for attacher "root_clav"
            for mDag in tArm.mAttachToClavicleTransformsOnAuto:
                xforms.matrixParentConstraint(self.dOutputs['end'], mDag.partialPathName(), mo=True, skipScale=['x','y','z'])
            tArm.sUnrealAttachRootToClavicle = "library.getElementKey('%s', 'Control')" % self.cIk.sCtrl


    def childrenConnect_LHorseArmLeg(self, _lChildren): # this is an exact copy of the LDogArmLeg version
        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm
        if hasattr(tArm, 'bAutoClavicle') and tArm.bAutoClavicle:
            print ('tArm.sClavAimTransformPerFeature: ', tArm.sClavAimTransformPerFeature)
            if len(tArm.sClavAimTransformPerFeature) > 1:
                sArmOutMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % sT for sT in tArm.sClavAimTransformPerFeature],
                                                            ['%s.weight' % sF for sF in tArm.sFeatureGrps])
            else:
                sArmOutMatrix = '%s.worldMatrix' % tArm.sClavAimTransformPerFeature[0]

            sAutoHorizAttr = utils.addAttr(self.cIk.sCtrl, ln='autoHoriz', min=0.0, max=1.0, k=True)
            sAutoVertAttr = utils.addAttr(self.cIk.sCtrl, ln='autoVert', min=0.0, max=1.0, k=True)
            sAutoOutput = nodes.createDecomposeMatrix(sArmOutMatrix)
            sLocalAutoOutput = nodes.createPointByMatrixNode(sAutoOutput, '%s.worldInverseMatrix' % cmds.listRelatives(self.sAutoConstrainer, p=True)[0])
            fDefaultLocalAutoOutput = cmds.getAttr(sLocalAutoOutput)[0]
            sOffsetAutoValues = nodes.createVectorAdditionNode([sLocalAutoOutput, fDefaultLocalAutoOutput], sOperation='minus')
            nodes.createBlendNode(sAutoHorizAttr, '%sz' % sOffsetAutoValues, 0, sTarget='%s.tz' % self.sAutoConstrainer)
            nodes.createBlendNode(sAutoVertAttr, '%sy' % sOffsetAutoValues, 0, sTarget='%s.ty' % self.sAutoConstrainer)

            # the replacement for attacher "root_clav"
            for mDag in tArm.mAttachToClavicleTransformsOnAuto:
                xforms.matrixParentConstraint(self.dOutputs['end'], mDag.partialPathName(), mo=True, skipScale=['x','y','z'])



    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)
        
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]
        
        cClavCtrls = blueprints.createChainCtrls([sBlueprints[0], sBlueprints[1]], sSide=self.sSide, xRoot='clavicle', xAim='%sclavicleEnd' % self.sName,
                                                 xPole='%sPoleClavicle' % self.sName, sParent=self.sBpTopGrp)

        self.cBpArmAttach = cClavCtrls[-1]

        self.cBpAll = cClavCtrls
        self.cBpRoots = [cClavCtrls[0], cClavCtrls[-1]]



    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):

        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)

        # xAutoConnectData =  xData['connect_arm']
        if lChildren:
            tArm = lChildren[0]
            cArmRoot = tArm.cBpRoots[0]
            cArmRoot.convertToSimpleTransforms()
            cmds.parentConstraint(self.cBpArmAttach.sOut, cArmRoot.sPasser, mo=True)



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)
        # segments.updateTagAttr(self.dOutputs['end'] , {'bDisable':True})
        # segments.updateTagAttr(self.dOutputs['main'] , {'sSearchReplace':'clavicleMain;clavicleEnd'})



    def generateOutputs_poseJoint(self, **kwargs):
        return {}, []



    def detail_poseJoint(self, bAddPoseJoint=False):
        dAttacherBuildData = {}

        if bAddPoseJoint:
            sParent = self._createTransform('poseParent', sMatch=self.dBlueprints['start'], sParent=self.sDetailsGrp)
            sPoseJoints = xforms.duplicateJoinChain(list(self.dOutputs.values()), sPostfix='pose', sParent=sParent)
            cmds.aimConstraint(self.cIk.sOut, sPoseJoints[0], wut='objectrotation', aim=[self.fSideMultipl,0,0], wuo=self.cIk.sOut)
            dAttacherBuildData['root'] = (utils.getDagPath(sParent), None)

        return [], dAttacherBuildData









