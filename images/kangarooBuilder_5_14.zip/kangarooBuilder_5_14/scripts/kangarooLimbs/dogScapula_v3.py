###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.utilFunctions as utils
import kangarooTabTools.segments as segments
import kangarooLimbs.baseLimb as baseLimb



class LDogScapula(baseLimb._LBaseLimb):

    def __init__(self, sName='scapula', sSide='l', #bMirror=False,
                bForceParentSkeletonToRoot=False,
                fBlueprintsCreationTranslationOffset = (0.0, 0.0, 1.0),
                fBlueprintsCreationRotationOffset = (0.0, 0.0, 0.0), iSegmentsPriority=50):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,
                                     fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset,
                                     bRemoveEndSkinJoint=False, iSegmentsPriority=iSegmentsPriority)
        self.dOutputs['end'] = None
        self.tArm = None
        self.sDefaultFeatures = ['feature_fk']


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':True},
                'scale': {'sTrs':'s', 'bMulti':False}}

    def createOrSetBlueprints(self, lParent=None):
        sNewJoints = self._fillBlueprints([[(0.2,0,1.5, 0,0,1), (5.2,0,1.5, 0,0,1)]], [['start', 'end']])
        return sNewJoints


    def feature_fk(self):
        dAttacherBuildData = {}
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]
        sJoint = xforms.createJoint('%s_fk' % sBlueprints[1], sMatch=sBlueprints[1], sParent=self.sCurrentFeatureGrp)
        xforms.matchRadius(sJoint, sBlueprints[1], 2)
        self.cFk = self._createCtrl3(sName='', sMatch=self.dBlueprints['start'], bIsNoCtrl=True)
        sAimer = self._createTransform(sName='aimer', sParent=self.cFk.sOut, bLocator=True)
        cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sAimer)
        sAimerChild = self._createTransform('aimerChild', sParent=sAimer, sMatch=sBlueprints[1])
        dAttacherBuildData['root'] = (utils.getDagPath(self.cFk.sPasser), self.cFk)

        self.cIk = self._createCtrl3(sName='ik', fMatchPos=self.dBlueprints['end'], sAttrs=['rx', 't'], sShape='locator',
                               sParent=self.cFk.sOut, iSlider=3, fSize=cmds.getAttr('%s.radius' % sBlueprints[1]) * 10.0)

        cmds.aimConstraint(self.cIk.sOut, sAimer, aim=[self.fSideMultipl,0,0], wut='objectrotation', wuo=self.cIk.sOut)

        cmds.orientConstraint(self.cIk.sOut, sAimerChild)

        xforms.matrixParentConstraint(sAimerChild, sJoint, mo=True)
        #global scale
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sCurrentFeatureGrp), None)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cFk.sPasser)
        cmds.scaleConstraint(self.sCurrentFeatureGrp, self.cIk.sPasser)

        return [sJoint], [self.cFk], dAttacherBuildData


    def unreal_feature_fk(self):
        if self.sLimbName == 'm_global':
            return [], '_', '_'
        else:
            import kangarooTools.utilsUnreal as utilsUnreal

            sCommands = []
            sCommands.append("controllers.openCommentBox()")

            sIkCtrl, sCommand = utilsUnreal.createUnrealCtrl(self.cIk)
            sCommands.append(sCommand)
            sJoint = self.getOutputFullNames()[0]

            sCommands.append(utilsUnreal.ENTRYKEY(self.sLimbName))
            sCommands.append("nodes.createAimConstraintExecuteNode([%s.eControl], library.getElementKey('%s', 'Bone'), bMaintainOffset=True, fAimVector=[%d,0,0], fUpVector=[0,1,0])" % (sIkCtrl, sJoint, self.fSideMultipl))
            sCommands.append("controllers.closeCommentBox('%s (SingleTransform)', fColor=library.dColors['%s'])" % (self.sLimbName, self.sSide))

            sCommands.append(['ATTACHERTRANSFORMELEMENTS', (self.cFk.sPasser, '%s.ePasser' % sIkCtrl)])

            return sCommands, [], []



    def childrenConnect_LArmLeg(self, _lChildren):
    
        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm

        # TODO: needs to get cleaned up. why is it bAutoScapula and not bAuto? should work for human arm and also horseArm
        if hasattr(tArm, 'bAutoScapula') and tArm.bAutoScapula:
            sAim = self._createTransform(sName='aimer')
            sAimA = self._createTransform(sName='aimerDef', sParent=self.cFk.sPasser, sMatch=self.dBlueprints['end'])
            sAimB = self._createTransform(sName='aimerElbow', sMatch=self.dBlueprints['end']) # this one gets both connections
            cmds.delete(cmds.pointConstraint(tArm.dOutputs['_autoClavicle'], sAimA))
            cmds.pointConstraint(tArm.dOutputs['_autoClavicle'], sAimB)

            xforms.constraintBlend(sAim, sAimA, sAimB, self.cFk.sOut, '%s.auto' % self.cFk.sCtrl, cmds.pointConstraint, fDefault=0.0)
            cmds.select(self.cFk.sCtrl)

            sPoleAc = self._createTransform(sName='poleAc', sParent=self.cFk.sPasser, fLocalPos=[0,self.fSideMultipl,0])
            self.cFk.appendOffsetGroups(1)
            cmds.aimConstraint(sAim, self.cFk.sOffsets[-1], aim=[0,self.fSideMultipl,0], wu=[self.fSideMultipl,0,0], wut='object', wuo=sPoleAc, mo=True)




    def childrenConnect_LDogArmLeg(self, _lChildren):

        tArm = _lChildren[0]
        tArm.tClavicle = self
        self.tArm = tArm
        if tArm.bAutoScapula:
            sAim = self._createTransform(sName='aimer')
            sAimA = self._createTransform(sName='aimerDef', sParent=self.cFk.sPasser, sMatch=self.dBlueprints['end'])
            sAimB = self._createTransform(sName='aimerElbow', sMatch=self.dBlueprints['end']) # this one gets both connections
            cmds.delete(cmds.pointConstraint(tArm.dOutputs['_autoClavicle'], sAimA))
            cmds.pointConstraint(tArm.dOutputs['_autoClavicle'], sAimB)

            xforms.constraintBlend(sAim, sAimA, sAimB, self.cFk.sOut, '%s.auto' % self.cIk.sCtrl, cmds.pointConstraint, fDefault=0.0)
            cmds.select(self.cFk.sCtrl)

            sPoleAc = self._createTransform(sName='poleAc', sParent=self.cFk.sPasser, fLocalPos=[0,self.fSideMultipl,0])
            self.cFk.appendOffsetGroup('auto')
            cmds.aimConstraint(sAim, self.cFk.sOffsets[-1], aim=[0,self.fSideMultipl,0], wu=[self.fSideMultipl,0,0], wut='object', wuo=sPoleAc, mo=True)




    def buildBlueprintRig(self, lParent=None):
        baseLimb._LBaseLimb.buildBlueprintRig(self)
        
        sBlueprints = [self.dBlueprints[sN] for sN in ['start', 'end']]
        
        cClavCtrls = blueprints.createChainCtrls([sBlueprints[0], sBlueprints[1]], sSide=self.sSide, xRoot='clavicle', xAim='%sclavicleEnd' % self.sName,
                                                 xPole='%sPoleClavicle' % self.sName, sParent=self.sBpTopGrp)

        self.cBpArmAttach = cClavCtrls[-1]

        self.cBpAll = cClavCtrls
        self.cBpRoots = [cClavCtrls[0], cClavCtrls[-1]]



    def postSetupBlueprintRig(self, xData={}, dLimbsDict={}, lChildren=[]):

        baseLimb._LBaseLimb.postSetupBlueprintRig(self, xData=xData, dLimbsDict=dLimbsDict, lChildren=lChildren)

        # xAutoConnectData =  xData['connect_arm']
        if lChildren:
            tArm = lChildren[0]
            cArmRoot = tArm.cBpRoots[0]
            cArmRoot.convertToSimpleTransforms()
            cmds.parentConstraint(self.cBpArmAttach.sOut, cArmRoot.sPasser, mo=True)



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)
        # segments.updateTagAttr(self.dOutputs['end'] , {'bDisable':True})
        # segments.updateTagAttr(self.dOutputs['main'] , {'sSearchReplace':'clavicleMain;clavicleEnd'})



    def generateOutputs_poseJoint(self, **kwargs):
        return {}, []



    def detail_poseJoint(self, bAddPoseJoint=False):
        dAttacherBuildData = {}

        if bAddPoseJoint:
            sParent = self._createTransform('poseParent', sMatch=self.dBlueprints['start'], sParent=self.sDetailsGrp)
            sPoseJoints = xforms.duplicateJoinChain(list(self.dOutputs.values()), sPostfix='pose', sParent=sParent)
            cmds.aimConstraint(self.cIk.sOut, sPoseJoints[0], wut='objectrotation', aim=[self.fSideMultipl,0,0], wuo=self.cIk.sOut)
            dAttacherBuildData['root'] = (utils.getDagPath(sParent), None)

        return [], dAttacherBuildData









