###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np

import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTools.nodes as nodes
import kangarooTools.deformers as deformers
import kangarooTabTools.segments as segmentsTools
import kangarooTools.constraints as constraints
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils

from collections import OrderedDict


iCtrlCountTypes = [4,6,8]
iJointCountTypes = [None, 8, 10, 12, 14, 16, 18, 20, 22, 24]

kUpDistance = 10.0

class LBelt(baseLimb._LBaseLimb):
    iFixCurveMirrorBehavior = 1

    def __init__(self, sName='belt', sSide='m',
                fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0), fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0), bSegmentPlanes=False,
                bRemoveEndSkinJoint=False, bForceParentSkeletonToRoot=False, bMirrorOrient=True, iSegmentsPriority=-1, bIsBpBarent=False,
                iCtrlCounts=2, iCurveJoints=9, bPostRefJoints=False,
                _dComboboxItems={'iCurveJoints':[str(iT) for iT in iJointCountTypes], 'iCtrlCounts':[str(iT) for iT in iCtrlCountTypes]}):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide, fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset,
                                     bRemoveEndSkinJoint=bRemoveEndSkinJoint,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,bIsBpBarent=bIsBpBarent)

        # self.iCurveJoints = iCurveJoints
        if iCurveJoints == 0:
            self.iCurveJointCount = None
        else:
            self.iCurveJointCount = iJointCountTypes[iCurveJoints]

        self.iCtrlCount = iCtrlCountTypes[iCtrlCounts]

        self.bPostRefJoints = bPostRefJoints

        dSides = {'l':'LFT', 'm':'MDL', 'r':'RGT'}
        if self.iCurveJointCount == None: # iCurveJoints == 0
            sAllSides, iAllInds = self._getSidesInds(bJoints=True)
            sOutJoints = ['%s_%02d' % (dSides[sSide], iInd) for sSide,iInd in zip(sAllSides,iAllInds)]
        else: # we make joints independently from ctrls
            sOutJoints = [None] * self.iCurveJointCount

            if sSide == 'm':
                iFrontIndex = self.iCurveJointCount // 2
                sOutJoints[iFrontIndex] = 'MDL_00'
                for i, j in enumerate(range(iFrontIndex + 1, self.iCurveJointCount, 1)[::-1]):
                    iIndex = iFrontIndex - j
                    sOutJoints[iIndex] = 'LFT_%02d' % i
                for i, j in enumerate(range(1, iFrontIndex, 1)):
                    iIndex = iFrontIndex - j
                    sOutJoints[iIndex] = 'RGT_%02d' % i
                sOutJoints[0] = 'MDL_01'
            else:
                sOutJoints = ['MDL_%02d' % j for j in range(self.iCurveJointCount)]

        for i in range(len(sOutJoints)):
            self.dOutputs[sOutJoints[i]] = None


        self.bSegmentPlanes = bSegmentPlanes
        self.bMirrorOrient = bMirrorOrient
        self.iSegmentsPriority = iSegmentsPriority

        self.sDefaultFeatures = ['feature_main']

        self.bDoControlRigFunction = True



    def getDefaultParentOutput(self):
        return list(self.dOutputs.keys())[0]


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':False},
                'scale': {'sTrs':'s', 'bMulti':False}}


    def generateAttachers_main(self, **kwargs):

        sAllSides, iAllInds = self._getSidesInds()
        dAttachers = {}

        if self.sSide in ['l','r']:
            for s in range(len(sAllSides)):
                sAllSides[s] = 'm'

        for i, sSide in enumerate(sAllSides):#, iAllInds):
            iInd = iAllInds[i]
            dAttachers['%s_%d' % (sSide,iInd)] = {'sTrs': 'tr', 'bMulti': True}
        return dAttachers


    def createOrSetBlueprints(self, lParent=None):
        self.dBlueprints = OrderedDict()
        self.sBlueprintCurves = ['bpCurve_%s' % self.sLimbName]

        if not cmds.objExists(self.sBpSkelGrp):
            cmds.createNode('transform', name=self.sBpSkelGrp)

        if not cmds.objExists(self.sBlueprintCurves[0]):
            cmds.circle(s=self.iCtrlCount, nr=[0,1,0], d=3, n=self.sBlueprintCurves[0])
            curves.fixShapeName(self.sBlueprintCurves[0])

            cmds.parent(self.sBlueprintCurves[0], self.sBpSkelGrp)
            if self.sSide == 'r':
                cmds.setAttr('%s.sx' % self.sBlueprintCurves[0], -1)
            cmds.setAttr('%s.r' % self.sBlueprintCurves[0], lock=True)
            cmds.setAttr('%s.t' % self.sBlueprintCurves[0], lock=True)
            cmds.setAttr('%s.s' % self.sBlueprintCurves[0], lock=True)


        self.fBlueprintsDiagonal = utils.getModelBoundingBoxDiagonal(self.sBlueprintCurves)

        return [self.sBlueprintCurves[0]]


    def _getSidesInds(self, bJoints=False):
        if bJoints:
            sAllSides = ['m'] * self.iCtrlCount  # 8
        else:
            sAllSides = [self.sSide] * self.iCtrlCount # 8
        iAllInds = list(range(self.iCtrlCount))
        if self.sSide == 'm':
            iMiddles = [self.iCtrlCount // 2 + 1, 1] # [5, 1]
            iLefts = list(range(self.iCtrlCount // 2 + 2, self.iCtrlCount, 1)) + [0] # [6, 7, 0]
            iRights = list(range(self.iCtrlCount // 2, 1, -1)) # [4, 3, 2]
            iAllInds = [None] * self.iCtrlCount
            for sSide, iInds in [('m', iMiddles), ('l', iLefts), ('r', iRights)]:
                for i, iInd in enumerate(iInds):
                    sAllSides[iInd] = sSide
                    iAllInds[iInd] = i
        return sAllSides, iAllInds


    def feature_main(self, bCircleCtrlShapes=False, bScale=False, iColorIndex=2):

        dAttacherBuildData = {}
        if self.bPostRefJoints and self.iCurveJointCount:
            raise Exception('if PostRefJoints is on, the CurveJointCount needs to be set to NONE')

        aPoints = np.array(cmds.xform('%s.cv[*]' % self.sBlueprintCurves[0], q=True, ws=True, t=True)).reshape(-1, 3)
        if len(aPoints) < self.iCtrlCount:
            raise Exception('%s: %s doesn\'t have enought cv counts' % (self.sLimbName, self.sBlueprintCurves[0]))

        aTangents = curves.getTangentsFromPoints(self.sBlueprintCurves[0], aPoints, bReturnNumpy=True)
        aMidPoint = np.mean(aPoints, axis=0)
        self.sRootTransform = self._createTransform('parent', fMatchPos=aMidPoint)
        sMidLoc = self._createTransform('midLoc', sParent=self.sRootTransform)
        dAttacherBuildData['root'] = (utils.getDagPath(self.sRootTransform), None)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.sRootTransform), None)

        # xforms.matrixParentConstraint('jnt_m_spineSpine_001', sMidLoc, mo=True)
        self.cCtrls = [None] * self.iCtrlCount
        sInfs = []
        iNameCounter = 0

        sOutJoints = []

        sAllSides, iAllInds = self._getSidesInds()
        print('sAllSides: ', sAllSides)
        self.sAttacherOffsets = []
        for i, sSide in enumerate(sAllSides):
            fSideMultipl = -1.0 if sSide == 'r' else 1.0
            iInd = iAllInds[i]
            sInf = cmds.createNode('joint', n=self._createNodeName('ctrl', 'JNT', iNameCounter))
            cmds.xform(sInf, t=aPoints[i])

            xforms.orientThreePoints(sInf, sMidLoc, aTangents[i], fAimVector=[0,0,-fSideMultipl], fUpVector=[1,0,0])

            sAttrs = ['t','r']
            if bScale:
                sAttrs += ['s'] if self.iCurveJointCount == None else ['sy','sz']

            cC = self._createCtrl4(sName='', sSide=sSide, iIndex=iInd, sShape='circleX' if bCircleCtrlShapes else 'squareX', sMatch=sInf,
                              fSize=self.fBlueprintsDiagonal*0.1, sAttrs=sAttrs, iColorIndex=iColorIndex)

            if bScale:
                nodes.createVectorMultiplyNode([1,1,1], '%s.s' % cC.sCtrl, sOperation='divide', sTarget='%s.s' % cC.sOut)


            xforms.parentJointNoTransform(sInf, cC.sOut)
            xforms.resetTransform(sInf, jo=True)

            cmds.connectAttr('%s.rigVis' % self.sMasterGlobal, '%s.v' % sInf)
            cC.sUp = cmds.createNode('transform', n=self._createNodeName('up', 'grp', iNameCounter), p=cC.sOut)
            cmds.setAttr('%s.ty' % cC.sUp, kUpDistance)
            self.cCtrls[i] = cC
            sInfs.append(sInf)
            xforms.matrixParentConstraint(self.sRootTransform, cC.sPasser, mo=True)

            sAttacherOffset = cC.appendOffsetGroup('attacher', bMatchParentTransform=True)
            sExtraOffset = cC.appendOffsetGroup('extra')

            sAttacherSide = sSide if self.sSide == 'm' else 'm'
            dAttacherBuildData['%s_%d' % (sAttacherSide,iInd)] = (utils.getDagPath(sAttacherOffset), cC)

            self.sAttacherOffsets.append(sAttacherOffset)

            if self.iCurveJointCount == None:
                sJ = cmds.createNode('joint', n=self._createNodeName('', 'jnt', i), p=self.sCurrentFeatureGrp)
                cmds.setAttr('%s.radius' % sJ, self.fBlueprintsDiagonal*0.025)
                xforms.matrixParentConstraint(cC.sOut, sJ)
                sOutJoints.append(sJ)
                sMessageAttr = utils.addAttr(cC.sCtrl, ln='jointMessage', at='message')
                cmds.connectAttr('%s.message' % sJ, sMessageAttr)
                sMaster = utils.getMasterName()
                if self.bPostRefJoints:
                    sRefJ = cmds.createNode('joint', n=self._createNodeName('ref', 'jnt', i), p=sExtraOffset)
                    cmds.xform(sRefJ, m=cmds.xform(sInf, q=True, m=True, ws=True), ws=True)
                    cmds.setAttr('%s.radius' % sRefJ, self.fBlueprintsDiagonal * 0.025)
                    if sMaster:
                        cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sRefJ)
                    else:
                        cmds.setAttr('%s.v' % sRefJ, False)
                    utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
                    utils.getZeroJoint(self.sModulesGlobal)
            iNameCounter += 1





        if self.iCurveJointCount != None:
            sBeltCurve = cmds.duplicate(self.sBlueprintCurves[0], n=self._createNodeName('beltCurve', sType='curve'))[0]
            cmds.parent(sBeltCurve, self.sCurrentFeatureGrp)
            cmds.skinCluster(sBeltCurve, sInfs, tsb=True)

            fCtrlParams = np.array(np.arange(self.iCtrlCount+1), dtype='float64')
            fJointPercs = np.arange(self.iCurveJointCount) / float(self.iCurveJointCount)
            fJointParams = curves.getParamsFromPercs(sBeltCurve, fJointPercs)

            iBeforeCtrl = 0


            sParentMatrices = []
            sInverseParentMatrices = []
            sCtrlMatrices = []
            sLocalRotationMatrices = []

            fFoundCtrlParams = curves.getParamsFromTransforms(sBeltCurve, [cC.sCtrl for cC in self.cCtrls])
            for c,cCtrl in enumerate(self.cCtrls):
                sCtrlPoint = curves.createPointInfoNode(sBeltCurve, fParam=fFoundCtrlParams[c])[1]
                sParentMatrix = nodes.createComposeMatrixNode(xTranslate=sCtrlPoint,
                                                              xRotate=nodes.createDecomposeMatrix('%s.worldMatrix' % cCtrl.sSlider, bReturnRotate=True))

                sAimVector = nodes.createPointByMatrixNode([1,0,0], '%s.matrix' % cCtrl.sCtrl)
                sNoTwist = cmds.duplicate(cCtrl.sCtrl, po=True, n='%s_noTwist' % cCtrl.sCtrl.split('_')[0])[0]
                cmds.connectAttr('%s.t' % cCtrl.sCtrl, '%s.t' % sNoTwist)
                sAimConstraint = constraints.aimConstraintEmpty(sNoTwist, sName=self._createNodeName('ctrl', 'aim', c))
                cmds.connectAttr(sAimVector, '%s.target[0].targetTranslate' % sAimConstraint)
                sCtrlMatrix = nodes.createComposeMatrixNode(xTranslate=sCtrlPoint,
                                                              xRotate=nodes.createDecomposeMatrix('%s.worldMatrix' % sNoTwist, bReturnRotate=True))
                sLocalCtrl = nodes.createMultMatrixNode([sCtrlMatrix,
                                                         nodes.createInverseMatrix(sParentMatrix)])

                sParentMatrices.append(sParentMatrix)
                sInverseParentMatrices.append(nodes.createInverseMatrix(sParentMatrix))
                sCtrlMatrices.append(sCtrlMatrix)
                sLocalRotationMatrices.append(nodes.getRotationMatrix(sLocalCtrl, bScale=False))

            xCtrlWeightings = [] # for unreal
            for j in range(self.iCurveJointCount):
                sParentG = self._createTransform('beltParent', iIndex=j, sParent=self.sCurrentFeatureGrp)
                sG = self._createTransform('belt', iIndex=j, sParent=sParentG)
                sJ = cmds.createNode('joint', n=self._createNodeName('', 'jnt', j), p=self.sCurrentFeatureGrp)
                utils.addAttr(sJ, ln='jointIndex', defaultValue=j, k=True)
                cmds.setAttr('%s.radius' % sJ, self.fBlueprintsDiagonal*0.025)
                xforms.matrixParentConstraint(sG, sJ)


                if iBeforeCtrl < len(fCtrlParams) and fJointParams[j] >= fCtrlParams[iBeforeCtrl]:
                    iBeforeCtrl += 1

                iBlendCtrls = [(iBeforeCtrl) % self.iCtrlCount, (iBeforeCtrl + 1) % self.iCtrlCount]
                fLocalJointPerc = fJointParams[j] - fCtrlParams[iBeforeCtrl - 1]
                fRange = fCtrlParams[iBeforeCtrl] - fCtrlParams[iBeforeCtrl - 1]
                fBlendWeight = fLocalJointPerc / fRange
                xCtrlWeightings.append([iBlendCtrls[0], iBlendCtrls[1], fBlendWeight])
                sInfoNode, sPointOnCurve = curves.createPointInfoNode(sBeltCurve, fParam=fJointParams[j])
                sCurvePoint = nodes.createPointByMatrixNode(sPointOnCurve, '%s.parentInverseMatrix' % sParentG)

                cCtrl0 = self.cCtrls[iBlendCtrls[0]]
                cCtrl1 = self.cCtrls[iBlendCtrls[1]]

                sBlendCtrl0 = nodes.createBlendMatrixNode([sLocalRotationMatrices[iBlendCtrls[0]], utils.fIdentityMatrix],
                                                          [1-fBlendWeight, fBlendWeight], bBugfixWeightInConnections=True)
                sBlendCtrl1 = nodes.createBlendMatrixNode([sLocalRotationMatrices[iBlendCtrls[1]], utils.fIdentityMatrix],
                                                          [fBlendWeight, 1-fBlendWeight], bBugfixWeightInConnections=True)

                sMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sCurvePoint),
                                                      sInverseParentMatrices[iBlendCtrls[0]],
                                                      sBlendCtrl0,
                                                      sParentMatrices[iBlendCtrls[0]],
                                                      sInverseParentMatrices[iBlendCtrls[1]],
                                                      sBlendCtrl1,
                                                      sParentMatrices[iBlendCtrls[1]]])

                sTempOrientLoc = cmds.spaceLocator()[0]
                cmds.setAttr('%s.t' % sTempOrientLoc, *cmds.getAttr(sCurvePoint)[0])
                xforms.orientThreePoints(sTempOrientLoc, sMidLoc, cmds.getAttr('%s.tangent' % sInfoNode)[0], fAimVector=[0, 0, 1],  fUpVector=[1, 0, 0])

                nodes.createDecomposeMatrix(sMatrix, sTargetPos = '%s.t' % sParentG)
                sAim = nodes.createVectorAdditionNode([sPointOnCurve, '%s.tangent' % sInfoNode])
                sOutJoints.append(sJ)

                sUp = self._createTransform('jointUp', iIndex=j, sParent=sTempOrientLoc, fLocalPos=[0,kUpDistance,0])
                cmds.parent(sUp, self.sCurrentFeatureGrp)
                cmds.delete(sTempOrientLoc)

                sAimLocal = nodes.createPointByMatrixNode(sAim, '%s.parentInverseMatrix' % sParentG)
                sUpLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % sUp, '%s.parentInverseMatrix' % sParentG])
                nodes.createSimpleAimConstraint2(sAimLocal, sParentG, xUpMatrix=sUpLocal, sParent=self.sCurrentFeatureGrp, sName=self._createNodeName('joint', 'aim', j))

                sScaleY = nodes.createRangeNode(fBlendWeight, 0, 1, '%s.sy' % cCtrl0.sCtrl, '%s.sy' % cCtrl1.sCtrl)
                sScaleZ = nodes.createRangeNode(fBlendWeight, 0, 1, '%s.sz' % cCtrl0.sCtrl, '%s.sz' % cCtrl1.sCtrl)
                nodes.createVectorMultiplyNode('%s.s' % self.cCtrls[0].sPasser, [1.0, sScaleY, sScaleZ], sTarget='%s.s' % sG)

                sBlendedUp = nodes.createBlendMatrixNode(['%s.worldMatrix' % cCtrl0.sUp, '%s.worldMatrix' % cCtrl1.sUp],
                                                        [1.0 - fBlendWeight, fBlendWeight])
                fBlendedInverse = nodes.createInverseMatrix(sBlendedUp, bJustValues=True)

                sOffsettedBlend = nodes.createMultMatrixNode([nodes.createMultMatrixNode(['%s.worldMatrix' % sUp, fBlendedInverse], bJustValues=True),
                                            sBlendedUp])
                nodes.createDecomposeMatrix(sOffsettedBlend, sTargetPos='%s.t' % sUp)

        for sJ in sOutJoints:
            cmds.addAttr(sJ, ln='_forceKeepForGames_', k=True)

        if not utils.isNone(self.iCurveJointCount):
            utils.addStringAttr(self.sCurrentFeatureGrp, 'xCtrlWeightings', xCtrlWeightings)

        return sOutJoints, self.cCtrls, dAttacherBuildData


    def unrealCheck_feature_main(self):
        if not self.bPostRefJoints:
            return True
        else:
            return False

    def unreal_feature_main(self):
        import kangarooTools.utilsUnreal as utilsUnreal

        sCommands = []
        sCommands.append('controllers.setNewColumn()')

        # sCommands.extend(utilsUnreal.createKey_createCustomAttacherTransforms(self.sLimbName))

        sCommands.append("eCtrlParent = hierarchy.createNull('%s_ctrlParent_belt')" % self.sLimbName)
        sCtrlVariables = []
        for cC in self.cCtrls:
            sCommands.append('controllers.setNewColumn()')
            sCtrlVar, sCommand = utilsUnreal.createUnrealCtrl(cC, sParentVar='eCtrlParent')#, fCtrlOrient=[0,0,-90])
            sCommands.append(sCommand)
            sCtrlVariables.append(sCtrlVar)



        if not utils.isNone(self.iCurveJointCount):
            sWeightingsAttr = '%s.xCtrlWeightings' % self.sCurrentFeatureGrp
            sCtrlWeightings = cmds.getAttr(sWeightingsAttr)
            if not cmds.objExists(sWeightingsAttr):
                raise Exception('Attribute "xCtrlWeightings" doesn\'t exist for %s ' % self.sLimbName)
        else:
            sCtrlWeightings = None

        sJoints = list(self.dOutputs.values())

        sCommands.extend(utilsUnreal.createKey_createBlendNodes(self.sLimbName, 'feature_main'))

        sFunctionNodeName = '%s_feature_main_node' % self.sLimbName
        # if utils.isNone(self.iCurveJointCount):
        sCommands.append("%s = functions.createBeltRigFunction(sSide='%s', cCtrls=[%s], \n\t\tsJoints=%s, \n\t\teCtrlParent=eCtrlParent, \n\t\txCtrlWeightings=%s )" %
                         (sFunctionNodeName, self.sSide, ', '.join(sCtrlVariables), sJoints, sCtrlWeightings))
        # else:
        #     sCommands.append("%s = functions.createBeltRigSoft(cCtrls=[%s], \n\t\tsJoints=%s, xCtrlWeightings=%s)" %
        #                      (sFunctionNodeName, ', '.join(sCtrlVariables), sJoints, sCtrlWeightings))
        sCommands.extend(utilsUnreal.initiateAttacherDictCommand('feature_main'))
        sCommands.extend(utilsUnreal.createKey_connectUserAttachers(self.sLimbName, 'feature_main', sFunctionNodeName))

        return sCommands, [], []


    def buildBlueprintRig(self, lParent=None):
        # utils.reload2(blueprints)
        baseLimb._LBaseLimb.buildBlueprintRig(self)


        sBpJoints = cmds.ls('bp_%s_spine' % self.sLimbName)
        if sBpJoints:
            raise Exception('You have set blueprintsCurve for %s, but there are joints (%s), please delete those joints' % (
            self.sLimbName, ', '.join(sBpJoints)))

        sBpRigCurve = cmds.duplicate(self.sBlueprintCurves[0], n='%s_RIG' % self.sBlueprintCurves[0])[0]

        for sC in [sBpRigCurve]:
            cmds.setAttr('%s.t' % sC, lock=True)
            cmds.setAttr('%s.r' % sC, lock=True)
            cmds.setAttr('%s.s' % sC, lock=True)

        sConnectedBpCurve = cmds.duplicate(self.sBlueprintCurves[0], n='connected:%s' % self.sBlueprintCurves[0])[0]
        curves.fixShapeName(sConnectedBpCurve)
        cmds.setAttr('%s.v' % sConnectedBpCurve, False)
        self.sConnectedBlueprintCurves = [sConnectedBpCurve]
        self.sRigBlueprintCurves = [sBpRigCurve]

        for c, sC in enumerate([sBpRigCurve]):
            cmds.blendShape(sC, self.sConnectedBlueprintCurves[c], w=[0, 1],
                            n='%s_defaultBs' % self.sConnectedBlueprintCurves[c].split(':')[-1])

        cmds.parent(sConnectedBpCurve, 'connected:%s' % self.sBpSkelGrp)
        cmds.parent(sBpRigCurve, self.sBpTopGrp)
        self.cBpAll = []
        self.cBpRoots = []



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        if not self.bSegmentPlanes:
            for sJ in list(self.dOutputs.values()):
                segmentsTools.updateTagAttr(sJ, {'bDisable':True})





