###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import numpy as np

import kangarooTools.xforms as xforms
import kangarooTools.blueprints as blueprints
import kangarooTools.nodes as nodes
import kangarooLimbs.baseLimb as baseLimb
import kangarooTools.utilFunctions as utils


class LWheel(baseLimb._LBaseLimb):
    def __init__(self, sName='wheel', sSide='m',
                fBlueprintsCreationTranslationOffset=(0.0, 0.0, 0.0), fBlueprintsCreationRotationOffset=(0.0, 0.0, 0.0),
                bRemoveEndSkinJoint=False, bForceParentSkeletonToRoot=False, bMirrorOrient=True, iSegmentsPriority=-1, bIsBpBarent=False):
        baseLimb._LBaseLimb.__init__(self, sName=sName, sSide=sSide, fBlueprintsCreationTranslationOffset=fBlueprintsCreationTranslationOffset,
                                     fBlueprintsCreationRotationOffset=fBlueprintsCreationRotationOffset,
                                     bRemoveEndSkinJoint=bRemoveEndSkinJoint,
                                     bForceParentSkeletonToRoot=bForceParentSkeletonToRoot,bIsBpBarent=bIsBpBarent)

        self.dOutputs['main'] = None
        self.dOutputs['end'] = None

        # self.bSegmentPlanes = bSegmentPlanes
        self.bMirrorOrient = bMirrorOrient
        self.iSegmentsPriority = iSegmentsPriority

        self.sDefaultFeatures = ['feature_default']



    def getDefaultParentOutput(self):
        return 'main'


    def generateAttachers_init(self):
        return {'root': {'sTrs':'tr', 'bMulti':False},
                'scale': {'sTrs':'s', 'bMulti':False}}


    def generateAttachers_fk(self, **kwargs):
        return {'main': {'sTrs':'tr', 'bMulti':True}}


    def createOrSetBlueprints(self, lParent=None):
        # sNewJoints = self._fillBlueprints([[(0,0,0, 0,0,-1, None, None, self.bMirrorOrient), (0,1,0, 0,0,-1, None, None, self.bMirrorOrient)]], [['main', 'end']])
        sNewJoints = self._fillBlueprints([[(0,1,0, 0,0,-1), (0,0,0, 0,0,-1)]], [['main', 'end']])
        self.sBlueprintJoints = [self.dBlueprints[sN] for sN in ['main', 'end']]
        return sNewJoints


    def feature_default(self, sCtrlShape='cylinder', fScaleCtrlShape=(1.0, 1.0, 1.0), iColorIndex=2,
                   bAddSuperCtrl=False, bAddPivotCtrl=False, bAddChildCtrl=False, iNegateRight=1,
                   bSpring=False, _dComboboxItems={'iNegateRight': ['no', 'xyz', 'x']}):


        dAttacherBuildData = {}

        fks = xforms.duplicateJoinChain(self.sBlueprintJoints, sPostfix='fk', sParent=self.sCurrentFeatureGrp)

        fRadius = cmds.getAttr('%s.tx' % self.sBlueprintJoints[1])
        self.cCtrl = self._createCtrl(sName='', fSize=fRadius*2, sLockHide=['v'], fRotateShape=[0,0,90], fScaleShape=[1, 0.25, 1],
                         sMatch=self.dBlueprints['main'], bNoBoundingBoxScale=True, iColorIndex=iColorIndex,
                         sShape='cylinder', bSuper=bAddSuperCtrl, bPivot=bAddPivotCtrl, bChild=bAddChildCtrl)
        self.cCtrl.adjustAxisOrientation([0,-90,90])

        sAutoRotate = self.cCtrl.appendOffsetGroup('auto')
        if iNegateRight:
            sSlider = self.cCtrl.appendOffsetGroup('slider', bAboveCtrl=False)
            if self.sSide == 'r':
                if iNegateRight == 1:
                    cmds.setAttr('%s.s' % sSlider, -1, -1, -1)
                    cmds.setAttr('%s.s' % self.cCtrl.sOut, -1, -1, -1)

                elif iNegateRight == 2:
                    cmds.setAttr('%s.sx' % sSlider, -1)
                    cmds.setAttr('%s.sx' % self.cCtrl.sOut, -1)

        sForwardDistance = utils.addAttr(self.cCtrl.sPasser, ln='forwDistance', k=True)
        sLastForwardDistance = utils.addAttr(self.cCtrl.sPasser, ln='lastForwDistance', k=True)
        sStartFrame = utils.addAttr(utils.getMasterName(), ln='startFrame', dv=1, k=True, bReturnIfExists=True)

        sRotMatrix = nodes.createComposeMatrixNode(xRotate='%s.r' % self.cCtrl.sPasser)
        sPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(sAutoRotate), nodes.createInverseMatrix(sRotMatrix))
        cmds.connectAttr('%sZ' % sPoint, sForwardDistance)

        sExpr = '''
        $curTime = time1.outTime;
        $forwardDistance = {2};
        if ($curTime == {0})
        {{
            {1}.rx = 0.0;
        }}
        else
        {{
            $distance = {2} - {3};
            {1}.rx = {1}.rx + $distance * 360 / ({4} * 3.14);
        }}
        {3} = $forwardDistance;
            '''.format(sStartFrame, sAutoRotate, sForwardDistance, sLastForwardDistance, fRadius*2)
        cmds.expression(s=sExpr, ae=True, n='wheelExpression')

        xforms.matrixParentConstraint(self.cCtrl.sOut, fks[0], skipScale=[])

        sAttacherOffset = self.cCtrl.appendOffsetGroups(1, 'mainAttacher')[0]
        dAttacherBuildData['root'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)
        dAttacherBuildData['main'] = (utils.getDagPath(sAttacherOffset), self.cCtrl)
        dAttacherBuildData['scale'] = (utils.getDagPath(self.cCtrl.sPasser), self.cCtrl)

        return fks, [self.cCtrl], dAttacherBuildData


    def buildBlueprintRig(self, lParent=None):
        # utils.reload2(blueprints)
        baseLimb._LBaseLimb.buildBlueprintRig(self)

        # if self.sLimbName == 'r_eye':
        #     print 'self.dMirrorOrients: ', self.dMirrorOrients
        #     print "self.dBlueprints['main']", self.dBlueprints['main']

        cCtrls = blueprints.createChainCtrls([self.dBlueprints['main'], self.dBlueprints['end']],
                                                sSide=self.sSide,
                                                dMirrorOrients=self.dMirrorOrients,
                                                xRoot='%sMain' % self.sName,
                                                xAim='%sMainEnd' % self.sName,
                                                xPole='%sPole' % self.sName,
                                                sParent=self.sBpTopGrp)

        self.cBpRoots = [cCtrls[0]]
        # del self.cBpRoots[-2]
        self.cBpAll = cCtrls


        self.dBpOutputs['main'] = cCtrls[0]
        self.dBpOutputs['end'] = cCtrls[1]

        self.cBpSymmetry = cCtrls
        self.cLastBp = cCtrls[1]



    def finalCleanup(self, dCreatedLimbs={}, lChildren=[]):
        baseLimb._LBaseLimb.finalCleanup(self)

        # if not self.bSegmentPlanes:
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'bDisable':True})
        # else:
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'iPriority':self.iSegmentsPriority})
        #     segmentsTools.updateTagAttr(self.dOutputs['main'], {'bIsRoot':self.bSegmentsRoot})



