###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.utilsQt as utilsQt

if cmds.about(v=True) >= '2025':
    from PySide6 import QtWidgets, QtGui, QtCore
else:
    from PySide2 import QtWidgets, QtGui, QtCore

import kangarooTools.utilsQt as utilsQt


import maya.api.OpenMaya as OpenMaya2
from collections import OrderedDict
import os
global mainWin
import numpy as np
import subprocess
mainWin = None

_ButtonHeight = int(utilsQt.getDpi() * 0.3)


# import itertools

import kangarooShapeEditor.kangarooShapeEditorTools as tools
import kangarooShapeEditor.kangarooShapeEditorLibrary as library # get rid of this??
import kangarooTools.utilFunctions as utils
import kangarooTools.patch as patch
from collections import defaultdict

try:
    import kangarooShapeEditor.kangarooShapeEditorMeta as meta
except:
    meta = None

import kangarooAnimation.KangarooMatchTools as KangarooMatchTools

import kangarooTabTools.blendShapes as blendShapes
import kangarooTools.deformers as deformers

library.reload2(library)
library.reload2(tools)

if not library.isNone(meta):
    library.reload2(meta)


kWindowTitle = 'Kangaroo Shape Editor'
kMainMeshAttr = 'sMainMesh'
kDisabledMeshesAttr = 'sDisabledMeshes'
kCurvesAttr = 'sScannerCurves'
# kIsEdgeFlowAttr = 'bMirrorIsEdgeFlow'
# kIsFacePoint = 'bMirrorIsFacePoint'
# kIsSideAttr = 'bMirrorIsSide'
kSplineLideCorrectiveSep = 'X'
kSplineLidCorrectivePrefix = 'splineLidCorrective'

# kWrap3dExe = 'C:/Program Files/R3DS/Wrap 2020.12.2/WrapCmd.exe'
kWrap3dExe = 'C:/Program Files/Faceform/Wrap 2023.11.4/WrapCmd.exe'
# sWrap3dTempFolder = os.path.join(os.path.dirname(__file__), 'wrap3d')



def showUI():
    sLoadedPlugins = cmds.pluginInfo(query=True, listPlugins=True)

    for sPlugin in ['kt_cmdUndo', 'kt_edgeFlowMirror', 'kt_findClosestPoints', 'poseInterpolator', 'matrixNodes', 'quatNodes']:
        if sPlugin not in sLoadedPlugins:
            try:
                cmds.loadPlugin(sPlugin)
            except:
                pass

    global mainWin
    if mainWin != None:
        mainWin.close()
    mainWin = BlendShapeTool()
    mainWin.show()




qFontBold = QtGui.QFont()
qFontBold.setBold(True)
qFontItalic = QtGui.QFont()
qFontItalic.setItalic(True)



_kMeshesRowHeight = utilsQt.getDpi() / 5




def getJawOpenCtrlRotationZ(sBlendShape, sJointNamespace, sCtrlNamespace):
    fJawOpenRotation, _ = tools.getJawOpenRotation(sBlendShape, sJointNamespace, sCtrlNamespace)
    return fJawOpenRotation[2]




def getExtraFaceShapesForAddTargets(sRigNamespace):
    sStandardShapes = list(getRigRelations(sRigNamespace, bStandardOnes=True, bExtraDefinedOnes=False).keys())
    sCustomShapes = list(getRigRelations(sRigNamespace, bStandardOnes=False, bExtraDefinedOnes=True).keys())
    # sCorrectives = []
    # if sRigNamespace:
    #     dFunctionDatas = utils.getCurrentFunctionDatas()
    #     dBlendShapesAndSliders = dFunctionDatas.get('blendShapesAndSliders', [{}])[0]
    #     if dBlendShapesAndSliders:
    #         dFileArgs = dBlendShapesAndSliders.get('dFileArgs', {})
    #         ddCorrectives = dFileArgs.get('ddCorrectives', {})
    #         sCorrectives = list(ddCorrectives.keys())
    #
    return sStandardShapes, sCustomShapes


def getAttrIfExists(sAttr):
    if cmds.objExists(sAttr):
        return cmds.getAttr(sAttr)

def getRigRelations(sRigNamespace, bStandardOnes=True, bExtraDefinedOnes=True):
    dRigRelations = OrderedDict()

    dFunctionDatas = utils.getCurrentFunctionDatas()

    if bStandardOnes:
        dBASEMouthCtrls = dFunctionDatas.get('BASEMouthCtrls', [{}])[0]
        dBASEMouthPoseCtrlValues = {}
        if dBASEMouthCtrls:
            dFileArgs = dBASEMouthCtrls.get('dFileArgs', {})
            dBASEMouthPoseCtrlValues = dFileArgs.get('dPoseCtrlValues', {})


        dBrowSplines = dFunctionDatas.get('browSplinesSurface', [{}])[0]
        dBrowSplineArgs = {}
        if dBrowSplines:
            dBrowSplineArgs = dBrowSplines.get('dFileArgs', {})


        dRigRelations['eyeWide'] = {'blink_l_ctrl.ty':0.5}
        dRigRelations['blink'] = {'blink_l_ctrl.ty':-1}
        dRigRelations['eyeUpperUp'] = {'lidTop_l_ctrl.ty':1.0}
        dRigRelations['eyeUpperDown'] = {'lidTop_l_ctrl.ty':-1.0}
        dRigRelations['eyeLowerUp'] = {'lidBot_l_ctrl.ty':1.0}
        dRigRelations['eyeLowerDown'] = {'lidBot_l_ctrl.ty':-1.0}
        dRigRelations['funnel'] = {'mouth_ctrl.tz':1.0}
        dRigRelations['lipPress'] = {'mouth_ctrl.tz':-1.0}
        dRigRelations['upperUp'] = {'mouthTop_ctrl.ty':1.0}
        dRigRelations['upperDown'] = {'mouthTop_ctrl.ty':-1.0}
        dRigRelations['lowerDown'] = {'mouthBot_ctrl.ty':-1.0}
        dRigRelations['lowerUp'] = {'mouthBot_ctrl.ty':1.0}
        dRigRelations['noseWrinkler'] = {'noseWrinkler_l_ctrl.ty':1.0}
        dRigRelations['noseDown'] = {'noseWrinkler_l_ctrl.ty':-1.0}
        dRigRelations['nostrilIn'] = {'nostril_l_ctrl.tx':-1.0}
        dRigRelations['nostrilOut'] = {'nostril_l_ctrl.tx':1.0}
        dRigRelations['cheekOut'] = {'puff_l_ctrl.ty':1.0}
        dRigRelations['cheekIn'] = {'puff_l_ctrl.ty':-1.0}
        dRigRelations['puffFront'] = {'puffFront_ctrl.ty':1.0}
        dRigRelations['cheekRaiser'] = {'cheekRaiser_l_ctrl.ty':1.0}
        dRigRelations['squint'] = {'squint_l_ctrl.ty':1.0}
        dRigRelations['lipStretch'] = {'lipStretch_l_ctrl.ty':1.0}
        dRigRelations['mentalis'] = {'mentalis_l_ctrl.ty':1.0}
        dRigRelations['chinRaiser'] = {'chinRaiser_l_ctrl.ty':1.0}
        dRigRelations['upperRollIn'] = {'mouthTop_ctrl.rx':dBASEMouthPoseCtrlValues.get('topRollIn', 45)}
        dRigRelations['upperRollOut'] = {'mouthTop_ctrl.rx':dBASEMouthPoseCtrlValues.get('topRollOut', -45)}
        dRigRelations['lowerRollIn'] = {'mouthBot_ctrl.rx':dBASEMouthPoseCtrlValues.get('botRollIn', -45)}
        dRigRelations['lowerRollOut'] = {'mouthBot_ctrl.rx':dBASEMouthPoseCtrlValues.get('botRollOut', 45)}
        dRigRelations['jawOpen'] = {'jaw_ctrl.rz':getJawOpenCtrlRotationZ}
        dRigRelations['jawOpenLips'] = {'jaw_ctrl.rz':getJawOpenCtrlRotationZ}
        dRigRelations['browSplinesInA'] = {'browSplinesA_l_ctrl.tx':dBrowSplineArgs.get('fPoseInA', -0.5)}
        dRigRelations['browSplinesInWrinklesA'] = {'browSplinesA_l_ctrl.tx':dBrowSplineArgs.get('fPoseInA', -0.5)}
        dRigRelations['browSplinesSplitCtrlsUp'] = {'browMain_l_ctrl.ty':dBrowSplineArgs.get('fPoseMainUp', 0.5)}
        dRigRelations['browSplinesSplitCtrlsDown'] = {'browMain_l_ctrl.ty':dBrowSplineArgs.get('fPoseMainDown', -0.5)}
        dRigRelations['browSplinesSplitJointsUp'] = {'browMain_l_ctrl.ty':dBrowSplineArgs.get('fPoseMainUp', 0.5)}
        dRigRelations['browSplinesSplitJointsDown'] = {'browMain_l_ctrl.ty':dBrowSplineArgs.get('fPoseMainDown', -0.5)}
        dRigRelations['browSplinesUpA'] = {'grp_l_browSplinesAPasser.singleMainUp':1.0}
        dRigRelations['browSplinesUpB'] = {'grp_l_browSplinesBPasser.singleMainUp':1.0}
        dRigRelations['browSplinesUpC'] = {'grp_l_browSplinesCPasser.singleMainUp':1.0}
        dRigRelations['browSplinesDownA'] = {'grp_l_browSplinesAPasser.singleMainDown':1.0}
        dRigRelations['browSplinesDownB'] = {'grp_l_browSplinesBPasser.singleMainDown':1.0}
        dRigRelations['browSplinesDownC'] = {'grp_l_browSplinesCPasser.singleMainDown':1.0}
        dRigRelations['browIn'] = {'innerEyebrow_l_ctrl.tx':-1.0}
        dRigRelations['browOut'] = {'innerEyebrow_l_ctrl.tx':1.0}
        dRigRelations['innerBrowUp'] = {'innerEyebrow_l_ctrl.ty':1.0}
        dRigRelations['innerBrowDown'] = {'innerEyebrow_l_ctrl.ty':-1.0}
        dRigRelations['outerBrowUp'] = {'outerEyebrow_l_ctrl.ty':1.0}
        dRigRelations['outerBrowDown'] = {'outerEyebrow_l_ctrl.ty':-1.0}


        # reason why in the following lines it's creating a list from dAllSculptPoseDriverValues items is because in older rigs those are floats. BUT: Not relevant anymore since dAllSculptPoseDriverValues changed??
        dRigRelations['cornerOut'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerOut', [1,0]))[0]}
        dRigRelations['cornerIn'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerIn', [-1,0]))[0]}
        dRigRelations['pucker'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerIn', [-1,0]))[0]}

        for sKey, fPuckerOnCornerIn in [('cornerIn', 0), ('pucker', 1)]:
            sPuckerOnCornerIn = '%slipsCorner_l_ctrl.puckerOnIn' % sRigNamespace
            if cmds.objExists(sPuckerOnCornerIn):
                dRigRelations[sKey]['lipsCorner_l_ctrl.puckerOnIn'] = fPuckerOnCornerIn


        dRigRelations['cornerUp'] = {'lipsCorner_l_ctrl.ty':utils.toList(dBASEMouthPoseCtrlValues.get('cornerUp', [0,1]))[-1]}
        dRigRelations['cornerDown'] = {'lipsCorner_l_ctrl.ty':utils.toList(dBASEMouthPoseCtrlValues.get('cornerDown', [0,-1]))[-1]}
        dRigRelations['cornerOutUp'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerOutUp', [1,1]))[0],
                                        'lipsCorner_l_ctrl.ty':utils.toList(dBASEMouthPoseCtrlValues.get('cornerOutUp', [1,1]))[-1]}
        dRigRelations['cornerOutDown'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerOutDown', [1,-1]))[0],
                                          'lipsCorner_l_ctrl.ty':utils.toList(dBASEMouthPoseCtrlValues.get('cornerOutDown', [1,-1]))[-1]}
        dRigRelations['cornerInUp'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerInUp', [-1,1]))[0],
                                        'lipsCorner_l_ctrl.ty':utils.toList(dBASEMouthPoseCtrlValues.get('cornerInUp', [-1,1]))[-1]}
        dRigRelations['cornerInDown'] = {'lipsCorner_l_ctrl.tx':utils.toList(dBASEMouthPoseCtrlValues.get('cornerInDown', [-1,-1]))[0],
                                          'lipsCorner_l_ctrl.ty':utils.toList(dBASEMouthPoseCtrlValues.get('cornerInDown', [-1,-1]))[-1]}
        dRigRelations['funnel'] = {'mouth_ctrl.tz':1.0}
        dRigRelations['lipPress'] = {'mouth_ctrl.tz':-1.0}
        dRigRelations['all corners'] = ['cornerOut', 'cornerIn', 'cornerDown', 'cornerUp']
        dRigRelations['mouthLeft'] = {'mouth_ctrl.tx':dBASEMouthPoseCtrlValues.get('mouthLeft', 1.0)}
        dRigRelations['mouthUp'] = {'mouth_ctrl.ty':dBASEMouthPoseCtrlValues.get('mouthUp', 1.0)}
        dRigRelations['mouthRight'] = {'mouth_ctrl.tx':dBASEMouthPoseCtrlValues.get('mouthRight', -1.0)}
        dRigRelations['mouthDown'] = {'mouth_ctrl.ty':dBASEMouthPoseCtrlValues.get('mouthDown', -1.0)}

        for sTarget, dPoses in dRigRelations.items():
            if isinstance(dPoses, dict):
                dMirrorPoses = {}
                for sAttr, fValue in dPoses.items():
                    sMirrorAttr = utils.getMirrorName(sAttr)
                    if sMirrorAttr != sAttr and sMirrorAttr not in dPoses:
                        dMirrorPoses[sMirrorAttr] = fValue
                dPoses.update(dMirrorPoses)
                dRigRelations[sTarget] = dPoses



        sBlinkPasser = '%sgrp_l_blinkPasser' % sRigNamespace
        if cmds.objExists(sBlinkPasser):
            iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % sBlinkPasser) * 100),
                        -int(cmds.getAttr('%s.blendCurveTop' % sBlinkPasser) * 100)]

            for sParts in ['bot', 'top', 'botTop']:
                sStringSplits = ['', '']
                for p, sPart in enumerate(['bot', 'top']):
                    if sPart.upper() in sParts.upper():
                        iValue = iBotTops[p]
                        sStringSplits[p] = '%03d' % iValue if iValue > 0 else 'n%03d' % -iValue
                sString = kSplineLideCorrectiveSep.join(sStringSplits)

                sNewTarget = '%s%s%s' % (kSplineLidCorrectivePrefix, kSplineLideCorrectiveSep, sString)
                dRigRelations[sNewTarget] = {}


    if bExtraDefinedOnes:
        dBlendShapesAndSliders = dFunctionDatas.get('blendShapesAndSliders', [{}])[0]
        if dBlendShapesAndSliders:
            dFileArgs = dBlendShapesAndSliders.get('dFileArgs', {})
            ddCorrectives = dFileArgs.get('ddCorrectives', {})
            for sTarget, dData in ddCorrectives.items():
                dRigRelations[sTarget] = dData['dPoses']

            ddExtraTargetSliders = dFileArgs.get('ddExtraTargetSliders', {})
            dPoseTypes = {}
            dPoseTypes['sTargetUp'] = ('ty',1)
            dPoseTypes['sTargetDown'] = ('ty',-1)
            dPoseTypes['sTargetIn'] = ('tx',-1)
            dPoseTypes['sTargetOut'] = ('tx',1)
            dPoseTypes['sTargetBack'] = ('tz',-1)
            dPoseTypes['sTargetForward'] = ('tz',1)
            for dSlider in ddExtraTargetSliders:
                dTargets = dSlider['dTargets']
                sName = dSlider['sName']
                if dSlider.get('bMirror', True):
                    sCtrls = ['%s_l_ctrl' % sName, '%s_r_ctrl' % sName]
                else:
                    sCtrls = ['%s_ctrl' % sName]

                for sType, sTarget in dTargets.items():
                    sTarget = sTarget.strip()
                    if sTarget:
                        if sType in dPoseTypes:
                            sA,fV = dPoseTypes[sType]
                            dRigRelations[sTarget] = {'%s.%s' % (sCtrl,sA):fV for sCtrl in sCtrls}


            ddTargetsAsAttributes = dFileArgs.get('ddTargetsAsAttributes', {})
            for dTarget in ddTargetsAsAttributes:
                sCtrlAttr = dTarget['sCtrlAttr']
                for sKey, fValue in [('sTarget',1.0), ('sTargetNeg',-1.0)]:
                    if sKey in dTarget:
                        dRigRelations[dTarget[sKey]] = {sCtrlAttr:fValue}
                        if utils.getSide(sCtrlAttr) != 'm':
                            sMirrorCtrlAttr = utils.getMirrorName(sCtrlAttr)
                            if cmds.objExists(sMirrorCtrlAttr):
                                dRigRelations[dTarget[sKey]] = {sMirrorCtrlAttr: fValue}



    return dRigRelations


class QModelTableWidget(QtWidgets.QTableWidget):

    def  __init__(self, parent=None):
        # super(QFuncTreeWidget, self).__init__(parent=parent)
        QtWidgets.QTableWidget.__init__(self, parent=None)

        # header.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)

    def resizeEvent(self, event):
        iWidth = self.width() - 60
        iLastColumn = min(iWidth*0.25, 40)
        iFirstColumn = iWidth - iLastColumn
        self.setColumnWidth(0, iFirstColumn)
        self.setColumnWidth(1, iLastColumn)
        QtWidgets.QTreeWidget.resizeEvent(self, event)
    #



class EnterInfo(QtWidgets.QDialog):

    def __init__(self, funcCallback, sDefault=None):
        super(EnterInfo, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qComments = QtWidgets.QTextEdit()
        self.qComments.setAcceptRichText(False)
        self.qComments.setReadOnly(False)
        layout.addWidget(self.qComments)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

        self.setMinimumWidth(800)
        self.setMinimumHeight(800)
        self.funcCallback = funcCallback
        if sDefault != None:
            self.qComments.append(str(sDefault))

    def okClicked(self):
        sComments = self.qComments.toPlainText()
        self.close()
        self.funcCallback(sComments)



class CreateNewBlendShapeDialog(QtWidgets.QDialog):

    def __init__(self, funcCallback, sMesh):
        super(CreateNewBlendShapeDialog, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        layout.addWidget(QtWidgets.QLabel('There is no blendShape, please choose from the following targets list'))
        self.qListCombo = QtWidgets.QComboBox()
        self.dTargetListFiles = getListFileDict()
        for sF in self.dTargetListFiles.keys():
            self.qListCombo.addItem(sF)
        layout.addWidget(self.qListCombo)

        qOkButton = QtWidgets.QPushButton('Create BlendShape')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

        self.funcCallback = funcCallback
        self.sCallbackMesh = sMesh


    def okClicked(self):
        self.close()
        self.funcCallback(self.sCallbackMesh, self.qListCombo.currentText())



class QBlendShape(object):
    def build(self, qLayout, fFuncUpdate, funcClear, qParent):
        self.qControlLayout = QtWidgets.QHBoxLayout()
        self.qLine = QtWidgets.QLineEdit('')
        self.qControlLayout.addWidget(QtWidgets.QLabel('BlendShape'))
        self.qControlLayout.addWidget(self.qLine)
        self.qLine.setEnabled(False)
        self.qParent = qParent

        self.iClearScriptJob = None

        qSetButton = QtWidgets.QPushButton('<<')
        qSetButton.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        qSetButton.clicked.connect(self.setClicked)
        self.qControlLayout.addWidget(qSetButton)

        def markingMenuSetButton(vPos):
            qMenu = QtWidgets.QMenu()
            qAction = qMenu.addAction('refresh', lambda: self.setClicked(bRefreshCurrent=True))
            qClearAction = qMenu.addAction('clear', self.clearBlendShape)

            if not self.getBlendShape():
                qAction.setEnabled(False)
                qClearAction.setEnabled(False)

            qMenu.exec_(qSetButton.mapToGlobal(vPos))
            return qMenu

        qSetButton.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        qSetButton.customContextMenuRequested.connect(markingMenuSetButton)

        qSelectButton = QtWidgets.QPushButton('Select')
        qSelectButton.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        qSelectButton.clicked.connect(self.selectClicked)
        self.qControlLayout.addWidget(qSelectButton)

        qPaintButton = QtWidgets.QPushButton('Paint')
        qPaintButton.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        qPaintButton.clicked.connect(self.paintClicked)
        self.qControlLayout.addWidget(qPaintButton)

        self.funcUpdates = [fFuncUpdate]
        self.funcClear = funcClear
        qLayout.addLayout(self.qControlLayout)


    def clearBlendShape(self):
        self.qLine.setText('')
        self.funcClear()



    def paintClicked(self):
        sBlendShape = self.getBlendShape()
        sGeo = cmds.blendShape(sBlendShape, q=True, g=True)[0]
        cmds.select(sGeo)
        mel.eval('toolPropertyWindow -inMainWindow true')
        mel.eval('source "artAttrBlendShapeCallback.mel"')

        mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.paintTargetWeights" )' % sBlendShape)
        mel.eval('artBlendShapeTargetIndex')
        cmds.refresh()
        # mel.eval('artBlendShapeSelectTarget artAttrCtx "%s"' % sTarget)  # errors on first time
        # mel.eval('artBlendShapeTargetIndex')
        # mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.paintTargetWeights" )' % sDeformer)


    def selectClicked(self):
        cmds.select(self.getBlendShape())


    def setClicked(self, bRefreshCurrent=False):
        if bRefreshCurrent:
            sBlendShape = self.getBlendShape()
        else:
            sBlendShape = None

            sSelectedBlendShapes = cmds.ls(sl=True, et='blendShape')
            if sSelectedBlendShapes:
                sBlendShape = sSelectedBlendShapes[0]
            else:
                sSelectedTransforms = cmds.ls(sl=True, et='transform')
                for sT in sSelectedTransforms:
                    for sN in cmds.listHistory(sT):
                        if cmds.objectType(sN) == 'blendShape':
                            sBlendShape = sN
                            break
                    if sBlendShape:
                        break

        if sBlendShape:
            self.setBlendShape(sBlendShape)

        else:
            self.qNewDialog = CreateNewBlendShapeDialog(self.createNewBlendShape, sSelectedTransforms[0])
            self.qNewDialog.show()


    def createNewBlendShape(self, sMesh, sFileName):
        print ('======================== createNewBlendShape')
        print ('sFileName: ', sFileName)
        sBlendShape = cmds.blendShape(sMesh)[0]
        print('sFileName: ', sFileName)
        utils.addStringAttr(sBlendShape, kCurrentListFileAttr, sFileName)
        self.setBlendShape(sBlendShape)


    def setBlendShape(self, sBlendShape):
        self.qLine.setText(sBlendShape)
        for func in self.funcUpdates:
            func(sBlendShape)

        if self.iClearScriptJob != None:
            if cmds.scriptJob(exists=self.iClearScriptJob):
                cmds.scriptJob(kill=self.iClearScriptJob)
            self.iClearScriptJob = None

        self.iClearScriptJob = cmds.scriptJob(attributeDeleted=['%s.envelope' % sBlendShape, self.clearBlendShape])


    def getBlendShape(self):
        return self.qLine.text()






kEnabledInfoAttr = 'sEnabledInfoAttr'

class QTargetCell(QtWidgets.QWidget):
    comboModeChanged = QtCore.Signal(str, str)

    def __init__(self, qParent, qTableWidget, sBlendShape, sTarget, iTargetIndex, iRowIndex, bCombo=False, iComboMainTargetRows=[], bNoSculpt=False, bPredefinedTurnOffOption=[True, True], sInfo='', sComboMode='S'):
        QtWidgets.QWidget.__init__(self)

        if bCombo:
            self.bTurnOffOption = True
        else:
            self.bTurnOffOption = bPredefinedTurnOffOption[0]


        self.iSelectOrder = None

        self.qTable = qTableWidget
        layout = QtWidgets.QHBoxLayout(self.qTable)
        layout.setContentsMargins(0, 0, 0, 0)
        self.bDontRunSetValueOnOthers = False

        self.sBlendShape = sBlendShape

        self.sTargetAttr = '%s.%s' % (self.sBlendShape, sTarget)
        self.sTarget = sTarget
        self.iTargetIndex = iTargetIndex
        self.iRowIndex = iRowIndex
        self.qParent = qParent
        self.bNoSculpt = bNoSculpt

        fValue = cmds.getAttr(self.sTargetAttr)


        self.bCombo = bCombo
        self.qTextValue = QtWidgets.QLineEdit('')
        self.qTextValue.setValidator(utilsQt.QFloatValidator())

        if not self.bCombo:
            self.qKeyButton = QtWidgets.QPushButton('K')
            self.qKeyButton.setMaximumWidth(50)
            self.qKeyButton.clicked.connect(self.keyButtonClicked)

        self.qTextValue.setMaximumWidth(60)
        self.qSlider = QNoWheelSlider(self.qTable)
        self.qSlider.setMaximumWidth(200)
        self.qSlider.setMinimum(0)
        self.qSlider.setMaximum(100)
        self.qTargetName = QEditLabel(sTarget,
                            bEditable=False if bCombo or sTarget in list(self.qParent.dPredefinedTargets.keys()) else True,
                            qTableWidget=self.qTable,
                            sBlendShape=self.sBlendShape)

        iTargetIndexList = blendShapes.getInbetweenTargetIndices(self.sBlendShape, iTargetIndex)
        for iIndex in iTargetIndexList:
            if iIndex < 6000:
                self.qSlider.fInbetweens.append(library.projectToRange(float(iIndex), 5000, 6000, 0, 1.0))

        self.qTargetName.userChangedText.connect(self.renameTarget)
        if bNoSculpt:
            self.qTargetName.setFont(qFontItalic)
        elif sTarget in list(self.qParent.dPredefinedTargets.keys()):
            self.qTargetName.setFont(qFontBold)


        if self.bCombo:
            self.iComboMainTargetRows = iComboMainTargetRows


        if self.sTarget in ['jawOpen', 'innerBlink'] or self.sTarget.startswith('eyelook'):
            self.bJointRotation = True
        else:
            self.bJointRotation = False

        if self.bJointRotation:
            self.qTransformButton = QtWidgets.QPushButton('*')
            self.qTransformButton.clicked.connect(self.editJointValues)

        self.checkAndUpdateFieldRotationValues()


        iCheckBoxSize = 25
        if self.bTurnOffOption:
            self.qEnabledCheckBox = QtWidgets.QCheckBox()
            self.qEnabledCheckBox.stateChanged.connect(self.clickedEnabledCheckBox)
            sAttr = '%s.%s' % (self.qParent.sBlendShape, kEnabledInfoAttr)
            dTargets = eval(cmds.getAttr(sAttr)) if cmds.objExists(sAttr) else {}
            self.qEnabledCheckBox.setChecked(dTargets.get(self.sTarget, True if bCombo else bPredefinedTurnOffOption[1]))
            self.qEnabledCheckBox.setMinimumWidth(iCheckBoxSize)
            self.qEnabledCheckBox.setMaximumWidth(iCheckBoxSize)

            if not self.bCombo:
                self.qEnabledCheckBox.stateChanged.connect(qParent.evaluateAllSliderRanges)
        else:
            self.qEnabledCheckBox = None


        if self.bTurnOffOption:
            layout.addWidget(self.qEnabledCheckBox)
            self.clickedEnabledCheckBox()
        else:
            layout.addSpacing(iCheckBoxSize + 10)

        self.sInfo = sInfo

        self.qEditButton = QtWidgets.QPushButton('EDIT')
        self.qEditButton.setMinimumWidth(80)
        self.qEditButton.setMaximumWidth(80)
        self.qEditButton.setMinimumHeight(_ButtonHeight)
        self.qEditButton.setMaximumHeight(_ButtonHeight)
        self.qEditButton.setCheckable(True)
        sRed = '#ea4963'
        self.qEditButton.setStyleSheet('QPushButton:checked{background-color: %s; border: none}' % sRed)
        self.qEditButton.clicked.connect(self.editButtonClicked)

        if bCombo:
            self.qComboButton = QtWidgets.QPushButton(sComboMode)
            self.qComboButton.setMinimumWidth(30)
            self.qComboButton.setMaximumWidth(30)
            self.qComboButton.setMinimumHeight(_ButtonHeight)
            self.qComboButton.setMaximumHeight(_ButtonHeight)
            self.qComboButton.clicked.connect(self.comboButtonClicked)

        if not self.bCombo:
            layout.addWidget(self.qKeyButton)
        layout.addWidget(self.qTextValue)
        layout.addWidget(self.qSlider)
        layout.addWidget(self.qTargetName)

        if self.sTarget in ['jawOpen', 'innerBlink'] or self.sTarget.startswith('eyelook'):
            self.qTransformButton.setMinimumWidth(40)
            self.qTransformButton.setMaximumWidth(40)
            layout.addWidget(self.qTransformButton)

        layout.addStretch()

        layout.addWidget(self.qEditButton)
        if bCombo:
            layout.addWidget(self.qComboButton)

        self.setLayout(layout)
        self.bSliderPressed = False

        self.bFiltered = True
        self.bIsolated = True

        if self.bCombo:
            getComboTargetConditionPlug(self.sTargetAttr)



        self.qTextValue.setText('%0.2f' % fValue)
        self.qSlider.setValue(int(fValue*100))

        self.qTextValue.textChanged.connect(self.textValueChanged)
        self.qSlider.valueChanged.connect(self.sliderValueChanged)
        self.qSlider.sliderReleased.connect(self.sliderReleased)
        self.qSlider.sliderPressed.connect(self.sliderPressed)

        self.iCellScriptJobs = []
        if self.bCombo:
            self.sComboFactorPlug = getComboTargetFactorPlug(self.sTargetAttr)
            self.iCellScriptJobs.append(cmds.scriptJob(attributeChange=[self.sComboFactorPlug, self.funcScriptJobComboFactor]))
        else:
            self.iCellScriptJobs.append(cmds.scriptJob(attributeChange=[self.sTargetAttr, self.funcScriptJob]))

        self.bScriptJobDisabled = False
        self.bScriptJobDisabledJustOnce = False
        self.fLastValueWithoutSliderPressed = fValue

        if self.bCombo:
            self.fLastMainValuesWithoutSliderPressed = fValue
        else:
            self.bDrivenByCombo = False

        self.iMoveRowsTogether = []

        if not self.bCombo:
            self.updateKeyframeColor()

        self.qTwoDimSlider = None


    def comboButtonClicked(self):
        qMenu = QtWidgets.QMenu()
        def _changeCombo(sComboMode):
            self.qComboButton.setText(sComboMode)

            sAttr = '%s.%s' % (self.qParent.sBlendShape, utils.kShapeEditorComboModeInfoAttr)
            if cmds.objExists(sAttr):
                dTargets = eval(cmds.getAttr(sAttr))
            else:
                dTargets = {}
            dTargets[self.sTarget] = sComboMode

            sSelectionBefore = cmds.ls(sl=True)
            utils.addStringAttr(self.qParent.sBlendShape, utils.kShapeEditorComboModeInfoAttr, str(dTargets), bLock=True)

            self.qParent.comboModeChanged(self.sTargetAttr, sComboMode) # this recreates the attributes

            self.sComboFactorPlug = getComboTargetFactorPlug(self.sTargetAttr)
            self.iCellScriptJobs.append(cmds.scriptJob(attributeChange=[self.sComboFactorPlug, self.funcScriptJobComboFactor]))
            self.funcScriptJobComboFactor()
            cmds.select(sSelectionBefore)

        qMenu.addAction('Multiply', lambda: _changeCombo('M'))
        qMenu.addAction('Smallest', lambda: _changeCombo('S'))

        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())



    def addInbetween(self, fInbetween):
        self.qSlider.fInbetweens.append(fInbetween)

    def removeInbetween(self, fInbetween):
        self.qSlider.fInbetweens.remove(fInbetween)


    def editButtonClicked(self):
        for qCell in self.qParent.qMainTable.qAllCells + self.qParent.qComboTable.qAllCells:
            if qCell != self:
                qCell.qEditButton.blockSignals(True)
                qCell.qEditButton.setChecked(False)
                qCell.qEditButton.blockSignals(False)

        if self.qEditButton.isChecked():
            self.bUpdateNextSculptChange = False
            cmds.setAttr(self.qParent.sSculptTargetAttr, self.iTargetIndex)

        else:
            self.bUpdateNextSculptChange = False
            cmds.setAttr(self.qParent.sSculptTargetAttr, -1)


    def resetEditButton(self):
        if self.qEditButton.isChecked():
            self.qEditButton.setChecked(False)
            self.editButtonClicked()

    def isEnabled(self):
        if not library.isNone(self.qEnabledCheckBox):
            return self.qEnabledCheckBox.isChecked()
        else:
            return True



    def clickedEnabledCheckBox(self, qState=None):
        bEnabled = True if self.qEnabledCheckBox.checkState() == QtCore.Qt.CheckState.Checked else False
        if self.bCombo:
            sPlug = getComboTargetConditionPlug(self.sTargetAttr)
            cmds.setAttr(sPlug, bEnabled)
        else:
            self.qSlider.setEnabled(bEnabled)
            self.qTextValue.setEnabled(bEnabled)
            self.qTextValue.setEnabled(bEnabled)
            self.qSlider.setEnabled(bEnabled)
            self.qKeyButton.setEnabled(bEnabled)
            self.qTextValue.setText('0.0')
            if self.bJointRotation:
                self.qTransformButton.setEnabled(bEnabled)
                # for a in range(len(self.qTransforms)):
                #     self.qTransforms[a].setEnabled(bEnabled)

        sAttr = '%s.%s' % (self.qParent.sBlendShape, kEnabledInfoAttr)
        if cmds.objExists(sAttr):
            dTargets = eval(cmds.getAttr(sAttr))
        else:
            dTargets = {}
        dTargets[self.sTarget] = bEnabled

        utils.addStringAttr(self.qParent.sBlendShape, kEnabledInfoAttr, str(dTargets), bLock=True)

        self.qParent.enabledUpdate(bMoveTwoDimSliders=False)




    def renameTarget(self, sText):
        sNewName = mel.eval('formValidObjectName "%s"' % sText).replace('_', '')
        sAliasAttrs = cmds.aliasAttr(self.sBlendShape, q=True)

        if sNewName in sAliasAttrs:
            sButtons = ['Yes', 'Abort']#, 'Delete %s and replace %s' % (self.sTarget, sNewName)]
            sReturnButton = cmds.confirmDialog(m='"%s" is already the list. Delete %s and Replace the existing "%s"?' %
                                                 (sNewName, self.sTarget, sNewName), button=sButtons)
            if sReturnButton == sButtons[0]: # yes, repace
                dTargets = library.getTargetsDictFromBlendShape(self.qParent.sBlendShape, bPerTargetNames=True)
                iCopyToTargetIndex = dTargets[sNewName]
                dMeshes = self.qParent.getMeshes(bSelected=False)

                # for iGeo in iGeoIndices:
                for sMesh,iMeshIndex in list(dMeshes.items()):
                    # get
                    sPointsTarget = cmds.getAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                        self.qParent.sBlendShape, iMeshIndex, self.iTargetIndex))
                    sComponentsTarget = cmds.getAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' % (
                        self.qParent.sBlendShape, iMeshIndex, self.iTargetIndex))

                    # set
                    cmds.setAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                        self.qParent.sBlendShape, iMeshIndex, iCopyToTargetIndex), len(sPointsTarget), *sPointsTarget, type='pointArray')
                    cmds.setAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' % (
                        self.qParent.sBlendShape, iMeshIndex, iCopyToTargetIndex), len(sComponentsTarget), *sComponentsTarget, type='componentList')

                    # delete old
                    cmds.setAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                        self.qParent.sBlendShape, iMeshIndex, self.iTargetIndex), 0, *[], type='pointArray')
                    cmds.setAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' % (
                        self.qParent.sBlendShape, iMeshIndex, self.iTargetIndex), 0, *[], type='componentList')

                    self.killCellScriptJobs()
                    cmds.aliasAttr(self.sTargetAttr, rm=True)

                    iRowIndex = self.iRowIndex
                    self.qTable.removeRow(iRowIndex)
                    del self.qTable.qAllCells[self.iRowIndex]
                    self.qParent.resetRowIndices(False)
            elif sReturnButton == sButtons[1]:
                self.qTargetName.setText(self.sTarget)
        else:
            cmds.aliasAttr(sNewName, '%s.%s' % (self.sBlendShape, 'w[%d]' % self.iTargetIndex))
            self.sTarget = sNewName
            self.sTargetAttr = '%s.%s' % (self.sBlendShape, self.sTarget)
            if sNewName != sText:
                self.qTargetName.setText(sNewName)




    def editJointValues(self):

        def _changeJointValueButtons(fNewValues):
            self.qTransformButton.fValues=fNewValues
            self.changedRotationValue()

        self.qPercentagesUI = JointValuesUI(self.qTransformButton.fValues, _changeJointValueButtons)
        self.qPercentagesUI.show()



    def changedRotationValue(self):

        fValue = self.qTransformButton.fValues

        if self.sTarget == 'jawOpen':
            sPlugs = tools.getAndRefreshJawOpenInputPlug(self.sBlendShape)
            cmds.setAttr(sPlugs[0], *fValue[0:3])
            cmds.setAttr(sPlugs[1], *fValue[3:6])

        elif self.sTarget.startswith('eyelook'):
            sPlugs = tools.getAndRefreshEyelookatInputPlug(self.sBlendShape, self.sTarget)
            cmds.setAttr(sPlugs[0], *fValue[0:3])
            # cmds.setAttr(sPlugs[1], *fValue[0:3])

        elif self.sTarget == 'innerBlink':
            sPlugs = tools.getAndRefreshInnerBlinkInputPlug(self.sBlendShape)
            cmds.setAttr(sPlugs[0], *fValue)
            cmds.setAttr(sPlugs[1], *fValue)



    def checkAndUpdateFieldRotationValues(self):
        if self.sTarget == 'jawOpen':
            sPlugs = tools.getAndRefreshJawOpenInputPlug(self.sBlendShape)
            fValues = cmds.getAttr(sPlugs[0])[0] # rotation
            fValues += cmds.getAttr(sPlugs[1])[0] # translation
            self.qTransformButton.fValues = fValues

        elif self.sTarget.startswith('eyelook'):
            sPlugs = tools.getAndRefreshEyelookatInputPlug(self.sBlendShape, self.sTarget)
            if sPlugs:
                fValuesLeft = cmds.getAttr(sPlugs[0])[0]
                self.qTransformButton.fValues = fValuesLeft

        elif self.sTarget == 'innerBlink':
            sPlugs = tools.getAndRefreshInnerBlinkInputPlug(self.sBlendShape)
            if sPlugs:
                fValuesLeft = cmds.getAttr(sPlugs[0])[0]
                self.qTransformButton.fValues = fValuesLeft



    def updateKeyframeColor(self):
        sRed = '#ea4963'
        sOrange = '#ffae00'

        fTimes = cmds.keyframe(self.sTargetAttr, q=True)
        if not fTimes:
            self.qKeyButton.setStyleSheet('')
        else:
            if cmds.currentTime(q=True) in fTimes:
                self.qKeyButton.setStyleSheet('background-color: %s' % sRed)
            else:
                self.qKeyButton.setStyleSheet('background-color: %s' % sOrange)




    def keyButtonClicked(self):
        cmds.setKeyframe(self.sTargetAttr)
        self.updateKeyframeColor()


    def deleteAnimation(self, bJustCurrentKey=False):
        if bJustCurrentKey:
            sBlendShape, sAttr = self.sTargetAttr.split('.')
            fTime = cmds.currentTime(q=True)
            cmds.cutKey(sBlendShape, time=(fTime-0.001, fTime+0.001), attribute=sAttr, option='keys')
        else:
            sConnections = [sN for sN in cmds.listConnections(self.sTargetAttr, s=True, d=False) or [] if cmds.objectType(sN).startswith('animCurve')]
            if sConnections:
                cmds.delete(sConnections)


        self.updateKeyframeColor()


    def funcScriptJob(self):
        fValue = cmds.getAttr(self.sTargetAttr)
        if not self.bScriptJobDisabled and not self.bScriptJobDisabledJustOnce and not self.qParent.bGlobalScriptJobDisabled:
            self.qTextValue.blockSignals(True)
            self.qSlider.blockSignals(True)

            self.qTextValue.setText('%0.2f' % fValue)

            self.qSlider.setValue(int(fValue*100))

            self.qTextValue.blockSignals(False)
            self.qSlider.blockSignals(False)
            if self.qTwoDimSlider and not self.qTwoDimSlider.bMouseDown:
                self.qTwoDimSlider.blockSignals(True)
                self.qTwoDimSlider.updateFunction()
                self.qTwoDimSlider.blockSignals(False)


            if not self.bDrivenByCombo:
                self.fLastValueWithoutSliderPressed = fValue

        if self.bScriptJobDisabledJustOnce:
            self.bScriptJobDisabledJustOnce = False

        self.updateKeyframeColor()



    def funcScriptJobComboFactor(self):
        fValue = cmds.getAttr(self.sComboFactorPlug)

        if not self.bScriptJobDisabled and not self.bScriptJobDisabledJustOnce and not self.qParent.bGlobalScriptJobDisabled:
            self.qTextValue.blockSignals(True)
            self.qSlider.blockSignals(True)

            self.qTextValue.setText('%0.2f' % fValue)
            self.qSlider.setValue(int(fValue*100))

            self.qTextValue.blockSignals(False)
            self.qSlider.blockSignals(False)

            self.fLastValueWithoutSliderPressed = fValue

        if self.bScriptJobDisabledJustOnce:
            self.bScriptJobDisabledJustOnce = False



    def killCellScriptJobs(self):
        for iScriptJob in self.iCellScriptJobs:
            cmds.scriptJob(kill=iScriptJob)



    def textValueChanged(self, sText):
        if self.bCombo:
            dMainTargetPercs = tools.getPercsFromComboName(self.sTarget)
            for iMainRow in self.iComboMainTargetRows:
                qMainCell = self.qParent.qMainTable.qAllCells[iMainRow]
                fValue = float(sText)
                iPerc = dMainTargetPercs[qMainCell.sTarget]
                fMainTargetValue = fValue * (iPerc * 0.01)
                qMainCell.qTextValue.setText(str(fMainTargetValue))
        else:
            try:
                fValue = float(sText)
            except:
                fValue = 0.0

            if not self.bDontRunSetValueOnOthers:
                cmds.undoInfo(openChunk=True)
            try:
                self.bScriptJobDisabledJustOnce = True
                self.qSlider.blockSignals(True)
                self.qSlider.setValue(int(fValue*100))
                self.qSlider.blockSignals(False)
                cmds.setAttr(self.sTargetAttr, fValue)

                if not self.bDontRunSetValueOnOthers:
                    iCurrentSelectedRows = self.qParent.getSelectedTargetRows(False)
                    if self.iRowIndex in iCurrentSelectedRows:
                        iOtherRows = iCurrentSelectedRows
                        iOtherRows.remove(self.iRowIndex)

                        for iOtherRow in iOtherRows:
                            qOtherCell = self.qParent.qMainTable.qAllCells[iOtherRow]
                            qOtherCell.bScriptJobDisabledJustOnce = True
                            qOtherCell.bDontRunSetValueOnOthers = True
                            qOtherCell.qTextValue.setText(sText)
                            qOtherCell.bDontRunSetValueOnOthers = False

                if self.qTwoDimSlider != None and not self.qTwoDimSlider.bMouseDown:
                    self.qTwoDimSlider.blockSignals(True)
                    self.qTwoDimSlider.updateFunction()
                    self.qTwoDimSlider.blockSignals(False)



            except:
                raise
            finally:
                if not self.bDontRunSetValueOnOthers:
                    cmds.undoInfo(closeChunk=True)

            if not self.bSliderPressed and not self.bDrivenByCombo:
                self.fLastValueWithoutSliderPressed = fValue



    def sliderValueChanged(self, iValue):

        if self.bCombo:
            fValue = float(iValue) * 0.01
            self.qTextValue.blockSignals(True)
            self.qTextValue.setText('%0.2f' % fValue)
            self.qTextValue.blockSignals(False)

            dMainTargetPercs = tools.getPercsFromComboName(self.sTarget)
            for iMainRow in self.iComboMainTargetRows:
                qMainCell = self.qParent.qMainTable.qAllCells[iMainRow]
                iPerc = dMainTargetPercs[qMainCell.sTarget]
                iMainTargetValue = int(iValue * (iPerc * 0.01))
                qMainCell.qSlider.setValue(iMainTargetValue)

                bSignalsBlocked = self.qTextValue.signalsBlocked()
                self.qSlider.blockSignals(True)
                self.qSlider.blockSignals(bSignalsBlocked)

            for iRow in self.iMoveRowsTogether:
                qMoveCell = self.qParent.qComboTable.qAllCells[iRow]
                qMoveCell.qSlider.setValue(iValue)



        else:
            fValue = float(iValue) * 0.01
            self.qTextValue.blockSignals(True)
            self.qTextValue.setText('%0.2f' % fValue)
            self.qTextValue.blockSignals(False)

            cmds.undoInfo(swf=False)
            cmds.setAttr(self.sTargetAttr, fValue)
            cmds.undoInfo(swf=True)

            for iOtherRow in self.iMoveRowsTogether:
                self.qParent.qMainTable.qAllCells[iOtherRow].qSlider.setValue(iValue)

            if self.qTwoDimSlider != None and not self.qTwoDimSlider.bMouseDown:
                self.qTwoDimSlider.blockSignals(True)
                self.qTwoDimSlider.updateFunction()
                self.qTwoDimSlider.blockSignals(False)



    def sliderReleased(self):
        self.bSliderPressed = False

        fValue = self.qSlider.value() * 0.01
        self.qTextValue.blockSignals(True)
        self.qTextValue.setText('%0.2f' % fValue)
        self.qTextValue.blockSignals(False)


        if self.bCombo:
            cmds.undoInfo(swf=False)
            for iMainRow in self.iComboMainTargetRows:
                qMainCell = self.qParent.qMainTable.qAllCells[iMainRow]
                cmds.setAttr(qMainCell.sTargetAttr, qMainCell.fLastValueWithoutSliderPressed)
            for iOtherRow in self.iMoveRowsTogether:
                qOtherCell = self.qParent.qComboTable.qAllCells[iOtherRow]
                for iMainRow in qOtherCell.iComboMainTargetRows:
                    qMainCell = qOtherCell.qParent.qMainTable.qAllCells[iMainRow]
                    cmds.setAttr(qMainCell.sTargetAttr, qMainCell.fLastValueWithoutSliderPressed)
            cmds.undoInfo(swf=True)

            cmds.undoInfo(openChunk=True)
            dMainTargetPercs = tools.getPercsFromComboName(self.sTarget)
            for iMainRow in self.iComboMainTargetRows:
                qMainCell = self.qParent.qMainTable.qAllCells[iMainRow]
                iPerc = dMainTargetPercs[qMainCell.sTarget]
                fMainTargetValue = fValue * (iPerc * 0.01)
                cmds.setAttr(qMainCell.sTargetAttr, fMainTargetValue)

            for iOtherRow in self.iMoveRowsTogether:
                qOtherCell = self.qParent.qComboTable.qAllCells[iOtherRow]
                for iMainRow in qOtherCell.iComboMainTargetRows:
                    qMainCell = qOtherCell.qParent.qMainTable.qAllCells[iMainRow]
                    cmds.setAttr(qMainCell.sTargetAttr, fValue)
            cmds.undoInfo(closeChunk=True)

            # self.fLastValueWithoutSliderPressed = fValue
            self.bScriptJobDisabled = False

            for iMainRow in self.iComboMainTargetRows:
                self.qParent.qMainTable.qAllCells[iMainRow].bDrivenByCombo = False
                for iOtherRow in self.iMoveRowsTogether:
                    qOtherCell = self.qParent.qComboTable.qAllCells[iOtherRow]
                    for iMainRow in qOtherCell.iComboMainTargetRows:
                        self.qParent.qMainTable.qAllCells[iMainRow].bDrivenByCombo = False

            self.iMoveRowsTogether = []
        else:
            cmds.undoInfo(swf=False)
            try:
                cmds.setAttr(self.sTargetAttr, self.fLastValueWithoutSliderPressed)
                for iOtherRow in self.iMoveRowsTogether:
                    cmds.setAttr(self.qParent.qMainTable.qAllCells[iOtherRow].sTargetAttr, self.qParent.qMainTable.qAllCells[iOtherRow].fLastValueWithoutSliderPressed)
            except:
                raise
            finally:
                cmds.undoInfo(swf=True)


            cmds.undoInfo(openChunk=True)
            try:
                cmds.setAttr(self.sTargetAttr, fValue)
                for iOtherRow in self.iMoveRowsTogether:
                    cmds.setAttr(self.qParent.qMainTable.qAllCells[iOtherRow].sTargetAttr, fValue)
            except:
                raise
            finally:
                cmds.undoInfo(closeChunk=True)

            if not self.bDrivenByCombo:
                self.fLastValueWithoutSliderPressed = fValue

            self.bScriptJobDisabled = False
            for iOtherRow in self.iMoveRowsTogether:
                self.qParent.qMainTable.qAllCells[iOtherRow].bScriptJobDisabled = False

            self.iMoveRowsTogether = []


    def sliderPressed(self):

        self.bSliderPressed = True
        self.bScriptJobDisabled = True

        if self.bCombo:
            for iMainRow in self.iComboMainTargetRows:
                self.qParent.qMainTable.qAllCells[iMainRow].bDrivenByCombo = True

            iCurrentSelectedRows = self.qParent.getSelectedTargetRows(True)
            if self.iRowIndex in iCurrentSelectedRows:
                self.iMoveRowsTogether = [iRow for iRow in iCurrentSelectedRows if self.qParent.qComboTable.qAllCells[iRow].isEnabled()]
                try:
                    self.iMoveRowsTogether.remove(self.iRowIndex)
                except: pass

                for iOtherRow in self.iMoveRowsTogether:
                    for iMainRow in self.qParent.qComboTable.qAllCells[iOtherRow].iComboMainTargetRows:
                        self.qParent.qMainTable.qAllCells[iMainRow].bDrivenByCombo = True
            else:
                self.iMoveRowsTogether = []



        else:
            iCurrentSelectedRows = self.qParent.getSelectedTargetRows(False)
            if self.iRowIndex in iCurrentSelectedRows:
                self.iMoveRowsTogether = [iRow for iRow in iCurrentSelectedRows if self.qParent.qMainTable.qAllCells[iRow].isEnabled()]
                self.iMoveRowsTogether.remove(self.iRowIndex)
                for iOtherRow in self.iMoveRowsTogether:
                    self.qParent.qMainTable.qAllCells[iOtherRow].bScriptJobDisabled = True
            else:
                self.iMoveRowsTogether = []


#
# kTempTargetName = '__TEMPTARGET__'
#
#
# def _assignTempShader(sMeshes):
#     kTempShaderName = '__tempTargetModelShader__'
#
#     if not cmds.objExists(kTempShaderName):
#         sShader = cmds.shadingNode('lambert', asShader=True, n=kTempShaderName)
#         cmds.setAttr('%s.color' % sShader, 0.6, 0.4, 0, type='double3')
#
#     cmds.select(sMeshes)
#     cmds.hyperShade(assign=kTempShaderName)
#


class QShapesTable(QtWidgets.QTableWidget):

    def keyPressEvent(self, event):
        key = event.key()

        if key == QtCore.Qt.Key_Tab:
            for qCell in self.qAllCells:
                if qCell.qTextValue.hasFocus():
                    qCell.keyPressEvent(event)
        else:
            super(QtWidgets.QTableWidget, self).keyPressEvent(event)




qSliderLineColor = QtGui.QColor('#454545')
qSliderSquareColor = QtGui.QColor('#bd3f35')
qSliderBackgroundColor = QtGui.QColor('#2b2b2b')


class QTwoDimSlider(QtWidgets.QLabel):
    valueChanged = QtCore.Signal(object)
    selectTargetRows = QtCore.Signal(object)
    isolateTargetRows = QtCore.Signal(object)
    targetMoved = QtCore.Signal(object)


    def __init__(self, qParent, iRangeX=[-100,100], iRangeY=[100,-100], sTargets=[]):
        # iBorderSize = 160
        super(QTwoDimSlider, self).__init__()
        self.qParent = qParent
        self.sTargets = sTargets
        self.setRange(iRangeX, iRangeY, iButtonSize=40)
        self.qMovingTargetCells = []

        def _emptyFunction():
            pass
        self.updateFunction = _emptyFunction




    def setRange(self, iRangeX, iRangeY, iButtonSize=40):
        iRangeX.sort()
        iRangeY.sort(reverse=True)

        self.iRangeX = iRangeX
        self.iRangeY = iRangeY
        self.qLocalMousePos = QtCore.QPoint(0,0)

        self.qButtonHalfSize = QtCore.QSize(iButtonSize/2, iButtonSize/2)
        self.qBorderSize = QtCore.QSize(max(abs(iRangeX[1] - iRangeX[0]) + self.qButtonHalfSize.width(), self.qButtonHalfSize.width()*2),
                                        max(abs(iRangeY[1] - iRangeY[0]) + self.qButtonHalfSize.height(), self.qButtonHalfSize.height()*2))
        self.qRangeSize = self.qBorderSize - self.qButtonHalfSize

        self._canvas = QtGui.QPixmap(self.qBorderSize.width(), self.qBorderSize.height())
        self.setPixmap(self._canvas)

        self.bMouseDown = False
        self.paint()
        self.update()

        self.qMouseStartPos = QtCore.QPoint(0,0)

        self.bShiftDirUp = None
        self.bSliderPressed = None


    def udpateTargets(self):
        dCells = {qC.sTarget: qC for qC in self.qParent.qMainTable.qAllCells}
        for sT in self.sTargets:
            if sT in dCells:
                dCells[sT].qTwoDimSlider = self




    def paint(self, *args, **kwargs):
        self._pixmap = self.pixmap() # creating reference, without it it would crash in 2025
        painter = QtGui.QPainter(self._pixmap)
        # painter.setPen(QtGui.QColor(168, 34, 3))
        painter.setBrush(QtGui.QBrush(qSliderBackgroundColor, QtCore.Qt.SolidPattern))
        painter.drawRect(0, 0, self.qBorderSize.width(), self.qBorderSize.height())

        iLineHalfWidth = 2
        painter.setBrush(QtGui.QBrush(qSliderLineColor, QtCore.Qt.SolidPattern))
        painter.setPen(qSliderLineColor)

        if self.iRangeX[1] - self.iRangeX[0] > 0:
            qTopPoint = QtCore.QPoint(library.projectToRange(0, self.iRangeX[0], self.iRangeX[1], 0.0, self.qBorderSize.width()), 0)
            painter.drawRect(qTopPoint.x()-iLineHalfWidth, qTopPoint.y(), iLineHalfWidth*2, self.qBorderSize.height())


        qLeftPoint = QtCore.QPoint(0, library.projectToRange(0, self.iRangeY[0], self.iRangeY[1], 0.0, self.qBorderSize.height()))
        painter.drawRect(qLeftPoint.x(), qLeftPoint.y()-iLineHalfWidth, self.qBorderSize.width(), iLineHalfWidth*2)


        # button
        painter.setBrush(QtGui.QBrush(qSliderSquareColor, QtCore.Qt.SolidPattern))
        painter.setPen(qSliderSquareColor)
        self.qDrawPoint = QtCore.QPoint(library.projectToRange(self.qLocalMousePos.x(), self.iRangeX[0], self.iRangeX[1], self.qButtonHalfSize.width(),
                                                               self.qBorderSize.width()-self.qButtonHalfSize.width()),
                                   library.projectToRange(self.qLocalMousePos.y(), self.iRangeY[0], self.iRangeY[1], self.qButtonHalfSize.height(),
                                                          self.qBorderSize.height()-self.qButtonHalfSize.height()))
        self.qDrawRect = QtCore.QRect(self.qDrawPoint.x() - self.qButtonHalfSize.width(),
                         self.qDrawPoint.y() - self.qButtonHalfSize.height(),
                        self.qButtonHalfSize.width() * 2,
                        self.qButtonHalfSize.height() * 2)
        painter.drawRect(self.qDrawRect)
        painter.end()
        self.setPixmap(self._pixmap)



    def mousePressEvent(self, event):

        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.bMouseDown = True
            qMousePos = QtCore.QPoint(event.x(), event.y())
            self.qMouseStartPos = QtCore.QPoint(qMousePos)

            qEmptySpaceSize = self.rect().size() - self.qBorderSize
            qMousePosCanvas = QtCore.QPoint(qMousePos.x(),
                                              qMousePos.y() - qEmptySpaceSize.height() / 2)

            if self.qDrawRect.contains(qMousePosCanvas):
                self.qMouseOffset = self.qDrawPoint - qMousePosCanvas
            else:
                self.qMouseOffset = QtCore.QPoint(0,0)

            qMousePosCanvas += self.qMouseOffset
            self.qLocalMousePos = QtCore.QPoint(library.projectToRange(qMousePosCanvas.x(), self.qButtonHalfSize.width(), self.qBorderSize.width()-self.qButtonHalfSize.width(), self.iRangeX[0], self.iRangeX[1]),
                                                library.projectToRange(qMousePosCanvas.y(), self.qButtonHalfSize.height(), self.qBorderSize.height()-self.qButtonHalfSize.height(), self.iRangeY[0], self.iRangeY[1]))

            if self.qLocalMousePos.x() < 0:
                self.iCtrlSnapRangeX = [self.iRangeX[0], 0]
            else:
                self.iCtrlSnapRangeX = [0, self.iRangeX[1]]
            if self.qLocalMousePos.y() < 0:
                self.iCtrlSnapRangeY = [self.iRangeY[1], 0]
            else:
                self.iCtrlSnapRangeY = [0, self.iRangeY[0]]

            self.paint()
            self.update()

            self.valueChanged.emit(self.qLocalMousePos)
            self.bShiftDirUp = None


            # undo stuff
            self.bSliderPressed = True
            dCells = {qCell.sTarget: qCell for qCell in self.qParent.qMainTable.qAllCells}
            self.qMovingTargetCells = [dCells[sT] for sT in self.sTargets if sT in dCells]
            for qCell in self.qMovingTargetCells:
                qCell.bScriptJobDisabled = True



        else: # right mouse click
            qMenu = QtWidgets.QMenu()
            qMenu.addAction('Reset', self.resetToOrigin)
            qMenu.addAction('Select Targets', lambda: self.selectTargetRows.emit(self.sTargets))
            qMenu.addAction('Isolate Targets', lambda: self.isolateTargetRows.emit(self.sTargets))

            qCursor = QtGui.QCursor()
            qMenu.exec_(qCursor.pos())

            # marking menu


    def setPoint(self, qPoint):
        self.qLocalMousePos = qPoint
        self.paint()
        self.update()


    def resetToOrigin(self):
        self.qLocalMousePos = QtCore.QPoint(0,0)
        self.paint()
        self.update()
        self.valueChanged.emit(QtCore.QPoint(0,0))


    def mouseReleaseEvent(self, *args, **kwargs):
        self.bMouseDown = False
        self.qButtonOffset = QtCore.QPoint(0,0)
        self.bShiftDirUp = None



        fValues = [qCell.qSlider.value() * 0.01 for qCell in self.qMovingTargetCells]
        # fLastValues = [qCell.fLastValueWithoutSliderPressed for qCell in self.qMovingTargetCells]


        # undo stuff
        cmds.undoInfo(swf=False)
        try:
            for qCell in self.qMovingTargetCells:
                cmds.setAttr(qCell.sTargetAttr, qCell.fLastValueWithoutSliderPressed)
        except:
            raise
        finally:
            cmds.undoInfo(swf=True)

        cmds.undoInfo(openChunk=True)
        try:
            for c,qCell in enumerate(self.qMovingTargetCells):
                cmds.setAttr(qCell.sTargetAttr, fValues[c])
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

        for c,qCell in enumerate(self.qMovingTargetCells):
            qCell.bScriptJobDisabled = False
            qCell.bScriptJobDisabledJustOnce = True
            qCell.fLastValueWithoutSliderPressed = fValues[c]



    def mouseMoveEvent(self, event):
        if self.bMouseDown:
            qMousePos = QtCore.QPoint(event.x(), event.y())

            modifiers = QtWidgets.QApplication.keyboardModifiers()

            if modifiers & QtCore.Qt.ShiftModifier:
                if self.bShiftDirUp == None:
                    qDiff = qMousePos - self.qMouseStartPos
                    if abs(qDiff.x()) > abs(qDiff.y()):
                        qMousePos.setY(self.qMouseStartPos.y())
                    else:
                        qMousePos.setX(self.qMouseStartPos.x())

                    if abs(qDiff.y()) > 10:
                        self.bShiftDirUp = True
                    elif abs(qDiff.x()) > 10:
                        self.bShiftDirUp = False

                if self.bShiftDirUp == True:
                    qMousePos.setX(self.qMouseStartPos.x())
                elif self.bShiftDirUp == False:
                    qMousePos.setY(self.qMouseStartPos.y())

            qEmptySpaceSize = self.rect().size() - self.qBorderSize
            qMousePosCanvas = QtCore.QPoint(qMousePos.x(),
                                              qMousePos.y() - qEmptySpaceSize.height() / 2)
            qMousePosCanvas += self.qMouseOffset
            self.qLocalMousePos = QtCore.QPoint(library.projectToRange(qMousePosCanvas.x(), self.qButtonHalfSize.width(), self.qBorderSize.width()-self.qButtonHalfSize.width(), self.iRangeX[0], self.iRangeX[1]),
                                                library.projectToRange(qMousePosCanvas.y(), self.qButtonHalfSize.height(), self.qBorderSize.height()-self.qButtonHalfSize.height(), self.iRangeY[0], self.iRangeY[1]))

            if modifiers & QtCore.Qt.ControlModifier:
                self.qLocalMousePos.setX(max(self.iCtrlSnapRangeX[0], min(self.qLocalMousePos.x(), self.iCtrlSnapRangeX[1])))
                self.qLocalMousePos.setY(max(self.iCtrlSnapRangeY[0], min(self.qLocalMousePos.y(), self.iCtrlSnapRangeY[1])))


            self.paint()
            self.update()
            self.valueChanged.emit(self.qLocalMousePos)

kCurrentListFileAttr = 'sListFile'
kCurrentListFileFullContentAttr = 'sListFileFullContent'

class QFilterWidget(QtWidgets.QWidget):
    filterChanged = QtCore.Signal(object)

    def __init__(self):
        super(QFilterWidget, self).__init__()

        qLayout = QtWidgets.QHBoxLayout()
        qLayout.setSpacing(0)
        self.setLayout(qLayout)
        self.qLineEdit = QtWidgets.QLineEdit()
        qLayout.addWidget(self.qLineEdit)
        self.qClearButton = QtWidgets.QPushButton('Clear')
        qLayout.addWidget(self.qClearButton)
        qLayout.setContentsMargins(0,0,0,0)

        # self.qClearButton.setStyleSheet('QPushButton {"border-width: 2px;", "padding: 1px;}')

        self.qLineEdit.textChanged.connect(self.filterGotChanged)
        self.qClearButton.clicked.connect(lambda: self.qLineEdit.setText(''))


    def clear(self):
        self.qLineEdit.setText('')


    def filterGotChanged(self):
        sFilter = self.qLineEdit.text()
        sFilters = [sF.strip() for sF in sFilter.split(' ')]
        sFilters = [sF for sF in sFilters if sF]
        self.filterChanged.emit(sFilters)

kUndoPlugin = 'kt_cmdUndo'

class BlendShapeTool(QtWidgets.QDialog):

    def __init__(self, parent=utilsQt.getMayaWindow()):
        super(BlendShapeTool, self).__init__(parent, QtCore.Qt.Tool)

        self.setWindowFlags(self.windowFlags() |
                               QtCore.Qt.WindowMinimizeButtonHint |
                               QtCore.Qt.WindowSystemMenuHint)

        if kUndoPlugin in cmds.pluginInfo(q=True, ls=True):
            try:
                cmds.loadPlugin(kUndoPlugin)
            except:
                pass
        else:
            sPluginPath = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir, 'plug-ins',
                                       cmds.about(os=True), cmds.about(v=True), '%s.py' % kUndoPlugin)
            sPluginPath = os.path.normpath(sPluginPath)
            if os.path.exists(sPluginPath):
                print ('loading plugin: %s' % sPluginPath)
                cmds.loadPlugin(sPluginPath)
            else:
                cmds.warning('Plugin "%s" not found' % sPluginPath)

        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.setWindowTitle(kWindowTitle)
        self.iSculptTargetScriptJob = None
        self.bUpdateNextSculptChange = True

        qTopRow = QtWidgets.QHBoxLayout()
        self.layout.addLayout(qTopRow)
        self.qBlendShape = QBlendShape()
        self.qBlendShape.build(qTopRow, self.refreshBlendShapes, self.clearAll, self)

        # qNewSculpts = QtWidgets.QPushButton('Fill Sel Sculpts')
        # qNewSculpts.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        # qNewSculpts.clicked.connect(self.fillSculptsClicked)
        # qTopRow.addWidget(qNewSculpts)

        # top button row
        qTopButtonRow = QtWidgets.QHBoxLayout()
        self.bGlobalScriptJobDisabled = False

        qMainLayout = QtWidgets.QVBoxLayout()
        qTabs = QtWidgets.QTabWidget()
        qTabs.addTab(makeWidgetFromLayout(qMainLayout), 'Shapes')
        self.layout.addWidget(qTabs)
        # self.layout.addLayout(qMainLayout)

        qResetButton = QtWidgets.QPushButton('Reset All')
        qTopButtonRow.addWidget(qResetButton)
        qResetButton.clicked.connect(self.resetAllShapes)
        qMainLayout.addLayout(qTopButtonRow)


        self.qFileLists = QtWidgets.QComboBox()
        qTopButtonRow.addWidget(self.qFileLists)
        self.updateFileLists()


        self.qFileLists.currentIndexChanged.connect(self.fileListsUserSwitched)


        # top/bot splitter
        qVertSplitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        qVertSplitter.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        qMainLayout.addWidget(qVertSplitter)
        aTopLayout = QtWidgets.QVBoxLayout()
        qBotLayout = QtWidgets.QHBoxLayout()
        qVertSplitter.addWidget(makeWidgetFromLayout(aTopLayout, parent=self))
        qVertSplitter.addWidget(makeWidgetFromLayout(qBotLayout, parent=self))
        qVertSplitter.setSizes([80, 20])


        # left/right splitter
        qHorizSplitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        qHorizSplitter.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        aTopLayout.addWidget(qHorizSplitter)
        qMainShapesLayout = QtWidgets.QVBoxLayout()
        qComboShapesLayout = QtWidgets.QVBoxLayout()
        qHorizSplitter.addWidget(makeWidgetFromLayout(qMainShapesLayout, parent=self))
        qHorizSplitter.addWidget(makeWidgetFromLayout(qComboShapesLayout, parent=self))
        qHorizSplitter.setSizes([50, 50])



        # main shapes
        qMainShapesLayout.setSpacing(0)
        self.qIsolateMain = QtWidgets.QPushButton('Isolate')
        self.qIsolateMain.setCheckable(True)
        qMainShapesLayout.addWidget(self.qIsolateMain)
        self.qIsolateMain.clicked.connect(self.isolateMainClicked)

        self.qMainFilterWidget = QFilterWidget()
        qMainShapesLayout.addWidget(self.qMainFilterWidget)
        self.qMainFilterWidget.filterChanged.connect(self.mainLayoutFilter)

        self.qMainTable = QShapesTable()
        self.qMainTable.setStyleSheet("QTableWidget { background-color : #434343; }")
        # self.qSlider.setStyleSheet("QSlider { background-color : grey; }")

        self.qMainTable.qAllCells = []
        qMainShapesLayout.addWidget(self.qMainTable)

        self.qMainTable.verticalHeader().hide()
        self.qMainTable.horizontalHeader().hide()
        self.qMainTable.horizontalHeader().setStretchLastSection(True)

        self.qMainTable.setRowCount(0)
        self.qMainTable.setColumnCount(1)

        self.qMainTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qMainTable.customContextMenuRequested.connect(self.markingMenuMain)
        self.qMainTable.itemSelectionChanged.connect(self.countMainSelection)
        self.qMainTable.cellPressed.connect(self.clickedMainTable)


        # combo shapes
        qComboShapesLayout.setSpacing(0)
        self.qIsolateCombo = QtWidgets.QPushButton('Isolate')
        self.qIsolateCombo.setCheckable(True)
        qComboShapesLayout.addWidget(self.qIsolateCombo)
        self.qIsolateCombo.clicked.connect(self.isolateComboClicked)

        self.qComboFilterWidget = QFilterWidget()
        qComboShapesLayout.addWidget(self.qComboFilterWidget)
        self.qComboFilterWidget.filterChanged.connect(self.comboLayoutFilter)

        self.qComboTable = QShapesTable()
        self.qComboTable.setStyleSheet("QTableWidget { background-color : #434343; }")
        # self.qSlider.setStyleSheet("QSlider { background-color : grey; }")

        self.qComboTable.qAllCells = []
        qComboShapesLayout.addWidget(self.qComboTable)
        self.qComboTable.verticalHeader().hide()
        self.qComboTable.horizontalHeader().hide()
        self.qComboTable.horizontalHeader().setStretchLastSection(True)

        self.qComboTable.setRowCount(0)
        self.qComboTable.setColumnCount(1)
        self.setMinimumWidth(1000)
        self.setMinimumHeight(1000)

        self.qComboTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qComboTable.customContextMenuRequested.connect(self.markingMenuCombo)
        self.qComboTable.itemSelectionChanged.connect(self.countMainSelection)
        self.qComboTable.cellPressed.connect(self.clickedComboTable)


        self.iSculptRowIndex = None
        self.iMoveRowsTogether = []
        self.iTweakBlockScriptJobs = []

        # slider images
        self.qAllTwoDimSliders = []
        sTwoDimSliderNames = []
        self.qCornerSlider = QTwoDimSlider(self, sTargets=['cornerIn', 'cornerOut', 'cornerUp', 'cornerDown', 'cornerOutUp', 'cornerOutDown', 'cornerInUp', 'cornerInDown'])
        self.qCornerSlider.valueChanged.connect(self.moveCornerTargets)
        # self.qCornerSlider.updateFunction = self.updateCornerSlider # this would give bad results, maybe could rewrite with proper barycentric algorithm? Might not be worth it
        self.qAllTwoDimSliders.append(self.qCornerSlider)
        sTwoDimSliderNames.append('Corner')


        self.qMouthSlider = QTwoDimSlider(self, sTargets=['mouthDown', 'mouthUp', 'mouthLeft', 'mouthRight'])
        self.qMouthSlider.valueChanged.connect(self.moveMouthTargets)
        self.qMouthSlider.updateFunction = self.updateMouthSlider
        self.qAllTwoDimSliders.append(self.qMouthSlider)
        sTwoDimSliderNames.append('Mouth')

        self.qJawSlider = QTwoDimSlider(self, iRangeX=[0,0], iRangeY=[-100,0], sTargets=['jawOpen'])
        self.qJawSlider.valueChanged.connect(self.moveJawTargets)
        self.qJawSlider.updateFunction = self.updateJawSlider
        self.qAllTwoDimSliders.append(self.qJawSlider)
        sTwoDimSliderNames.append('Jaw')

        self.qNostrilSlider = QTwoDimSlider(self, iRangeX=[0,0], sTargets=['nostrilIn', 'nostrilOut'])
        self.qNostrilSlider.valueChanged.connect(self.moveNostrilTargets)
        self.qNostrilSlider.updateFunction = self.updateNostrilSlider
        self.qAllTwoDimSliders.append(self.qNostrilSlider)
        sTwoDimSliderNames.append('Nostril')

        self.qUpperSlider = QTwoDimSlider(self, iRangeX=[0,0], sTargets=['upperUp', 'upperDown'])
        self.qUpperSlider.valueChanged.connect(self.moveUpperTargets)
        self.qUpperSlider.updateFunction = self.updateUpperSlider
        self.qAllTwoDimSliders.append(self.qUpperSlider)
        sTwoDimSliderNames.append('Upper')

        self.qLowerSlider = QTwoDimSlider(self, iRangeX=[0,0], sTargets=['lowerUp', 'lowerDown'])
        self.qLowerSlider.valueChanged.connect(self.moveLowerTargets)
        self.qLowerSlider.updateFunction = self.updateLowerSlider
        self.qAllTwoDimSliders.append(self.qLowerSlider)
        sTwoDimSliderNames.append('Lower')


        self.qBrowSlider = QTwoDimSlider(self, sTargets=['innerBrowDown', 'innerBrowUp', 'browIn', 'browOut'])
        self.qBrowSlider.valueChanged.connect(self.moveBrowTargets)
        self.qBrowSlider.updateFunction = self.updateBrowSlider
        self.qAllTwoDimSliders.append(self.qBrowSlider)
        sTwoDimSliderNames.append('InnerBrow')


        self.qOuterBrowSlider = QTwoDimSlider(self, iRangeX=[0,0], sTargets=['outerBrowDown', 'outerBrowUp'])
        self.qOuterBrowSlider.valueChanged.connect(self.moveOuterBrowTargets)
        self.qOuterBrowSlider.updateFunction = self.updateOuterBrowSlider
        self.qAllTwoDimSliders.append(self.qOuterBrowSlider)
        sTwoDimSliderNames.append('OuterBrow')

        self.evaluateAllSliderRanges()

        # self.qFunnelSlider = QOneDimSlider(iRangeX=[-100,100], iRangeY=[100,0])
        # self.qFunnelSlider.valueChanged.connect(self.moveFunnelTargets)


        qSlidersLayout = QtWidgets.QHBoxLayout()

        qLeftBottomLayout = QtWidgets.QVBoxLayout()
        qLeftBottomLayout.addLayout(qSlidersLayout)

        qBotLayout.addLayout(qLeftBottomLayout)

        qMetaLayout = QtWidgets.QHBoxLayout()
        qLeftBottomLayout.addLayout(qMetaLayout)


        qToolsGroupLayout = utilsQt.createGroupBoxLayout(qLeftBottomLayout, 'Tools', bHorizontalLayout=True)
        self.qMasterMesh = QSetObject()
        self.qMasterMesh.build(qToolsGroupLayout, 'Master', 'sMasterMesh', qBlendShape=self.qBlendShape)

        self.qInbetweensBox = QtWidgets.QComboBox()
        [self.qInbetweensBox.addItem(sLabel) for sLabel in ['Main Target And Inbetweens', 'Only Main Targets', 'Only Closest Inbetween']]
        qToolsGroupLayout.addWidget(self.qInbetweensBox)

        qToolsButton = QtWidgets.QPushButton('TOOLS')
        qToolsGroupLayout.addWidget(qToolsButton)
        qToggleVisButton = QtWidgets.QPushButton('Toggle Master Vis')

        def _toggleSnapMeshVis():
            sMesh = self.qMasterMesh.getObject()
            bVis = cmds.getAttr('%s.v' % sMesh)
            cmds.setAttr('%s.v' % sMesh, not bVis)
        qToggleVisButton.clicked.connect(_toggleSnapMeshVis)
        qToolsGroupLayout.addWidget(qToggleVisButton)

        def _toolsMenu():
            sMaster = self.qMasterMesh.getObject()
            sMode = self.qInbetweensBox.currentText()
            bMasterIsMesh = sMaster and sMaster.strip() and cmds.objExists(sMaster) and cmds.listRelatives(sMaster, typ='mesh', c=True)
            bMasterIsCurve = sMaster and sMaster.strip() and cmds.objExists(sMaster) and cmds.listRelatives(sMaster, typ='nurbsCurve', c=True)

            sSelectedTargets = [self.qMainTable.qAllCells[iRow].sTarget for iRow in self.getSelectedTargetRows(False)] + \
                               [self.qComboTable.qAllCells[iRow].sTarget for iRow in self.getSelectedTargetRows(True)]
            iAllSelectedTargetsCount = len(sSelectedTargets)
            if iAllSelectedTargetsCount == 0:
                cmds.confirmDialog(m='Select Targets to run Tools')
                return

            qToolsMenu = QtWidgets.QMenu()

            def _snap(sSelectedTargets=sSelectedTargets):
                tools.snapSelectedMeshes(self.qMasterMesh.getObject(), self.qBlendShape.getBlendShape(), sTargets=sSelectedTargets, iInbetweensMode=self.qInbetweensBox.currentIndex())

            def _warp(sSelectedTargets=sSelectedTargets, bRigid=False, bUvs=False):
                utils.reload2(tools)
                tools.warp(self.qMasterMesh.getObject(), self.qBlendShape.getBlendShape(), sTargets=sSelectedTargets, bRigid=bRigid, bUvs=bUvs, iInbetweensMode=self.qInbetweensBox.currentIndex())

            def _blendIds(sSelectedTargets=sSelectedTargets):
                utils.reload2(tools)
                tools.blendIds(self.qMasterMesh.getObject(), self.qBlendShape.getBlendShape(), sTargets=sSelectedTargets, iInbetweensMode=self.qInbetweensBox.currentIndex())

            def _blendIdsTurnOffDeformers(sSelectedTargets=sSelectedTargets):
                utils.reload2(tools)
                tools.blendIds(self.qMasterMesh.getObject(), self.qBlendShape.getBlendShape(), sTargets=sSelectedTargets, iInbetweensMode=self.qInbetweensBox.currentIndex(), bTurnOffOtherDeformers=True)

            def _smoothVertices(sSelectedTargets=sSelectedTargets):
                def __smoothVertices(iIterations):
                    tools.smoothVertices(self.qBlendShape.getBlendShape(), sTargets=sSelectedTargets, iInbetweensMode=self.qInbetweensBox.currentIndex(), iIterations=iIterations)

                self.qSmoothDialog = utilsQt.QGetFloatDialog(__smoothVertices, sDefault='4', sMessage='Enter Factor')
                self.qSmoothDialog.show()

            def _wire(sSelectedTargets=sSelectedTargets):
                tools.wireWarp([self.qMasterMesh.getObject()], self.qBlendShape.getBlendShape(), sTargets=sSelectedTargets, iInbetweensMode=self.qInbetweensBox.currentIndex())

            def _multiply(sSelectedTargets=sSelectedTargets, bAlongTargetY=False):
                # set bCheckForFaceCombos to False recently because it gave strange behavior on the jawOpen corner shapes
                if bAlongTargetY:
                    tools.multiplyTargets(self.sBlendShape, sSelectedTargets, fFactor=None, sAlongTransformY=self.qMasterMesh.getObject(), iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False)
                else:
                    tools.multiplyTargets(self.sBlendShape, sSelectedTargets, fFactor=None, iInbetweensMode=self.qInbetweensBox.currentIndex(), bCheckForFaceCombos=False)


            if bMasterIsMesh:
                qToolsMenu.addAction('Warp to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _warp)
                qToolsMenu.addAction('Warp Rigid to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), lambda: _warp(bRigid=True))
                qToolsMenu.addAction('Warp UVs to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), lambda: _warp(bUvs=True))
                qToolsMenu.addAction('Snap to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _snap)
                qToolsMenu.addAction('Blend IDs to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _blendIds)
                qToolsMenu.addAction('Blend IDs turn off deformers to "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), _blendIdsTurnOffDeformers)
            else:
                for sAction in ['Snap', 'Warp', 'Warp Rigid', 'Warp UVs', 'Blend IDs']:
                    qDisabledAction = qToolsMenu.addAction(sAction)
                    qDisabledAction.setEnabled(False)

            qToolsMenu.addAction('Multiply (%d Targets)' % iAllSelectedTargetsCount, _multiply)
            qToolsMenu.addAction('Multiply Along Y of "%s" (%d Targets)' % (sMaster , iAllSelectedTargetsCount), lambda: _multiply(bAlongTargetY=True))
            qToolsMenu.addAction('Smooth Vertices (%d Targets)' % iAllSelectedTargetsCount, _smoothVertices)


            if bMasterIsCurve:
                qToolsMenu.addAction('Warp Wire to "%s" (%d Targets)' % (sMaster, iAllSelectedTargetsCount), _wire)
            else:
                qDisabledAction = qToolsMenu.addAction('Warp Wire')
                qDisabledAction.setEnabled(False)

            qToolsMenu.exec_(QtGui.QCursor().pos())

        qToolsButton.clicked.connect(_toolsMenu)
        

        self.qRig = QSetObject()

        qRigLayout = utilsQt.createGroupBoxLayout(qLeftBottomLayout, 'Transfer from Referenced Rig', bHorizontalLayout=False)
        qRigFirstLine = QtWidgets.QHBoxLayout()
        qRigLayout.addLayout(qRigFirstLine)
        self.qRig.build(qRigFirstLine, '', 'sReferencedRig', qBlendShape=self.qBlendShape, bIsNamespace=True)
        def _blendshapesOffOn(bOffOn):
            try:
                cmds.undoInfo(openChunk=True)

                sNamespace = self.qRig.getObject()
                iCount = 0
                for sMesh in self.getMeshes():
                    sNamespacedMesh = '%s%s' % (sNamespace, sMesh.split('|')[-1])
                    sBlendShapes = deformers.listAllDeformers(sNamespacedMesh, sFilterTypes=['blendShape'], bSkipGeoTest=True)
                    iCount += len(sBlendShapes)
                    print ('checking sNamespacedMesh: %s -> %s ' % (sNamespacedMesh, sBlendShapes))
                    for sBs in sBlendShapes:
                        print ('turning %s to %s' % (sBs, bOffOn))
                        cmds.setAttr('%s.envelope' % sBs, bOffOn)
                utilsQt.showFadingText('turning %d blendShapes to %s' % (iCount, bOffOn))
            except Exception as e:
                cmds.confirmDialog(m=str(e))
                raise
            finally:
                cmds.undoInfo(closeChunk=True)

        qRigBlendShapesOn = QtWidgets.QPushButton('BS On')
        qRigBlendShapesOn.clicked.connect(lambda: _blendshapesOffOn(True))
        qRigFirstLine.addWidget(qRigBlendShapesOn)
        qRigBlendShapesOff = QtWidgets.QPushButton('BS Off')
        qRigBlendShapesOff.clicked.connect(lambda: _blendshapesOffOn(False))
        qRigFirstLine.addWidget(qRigBlendShapesOff)
        qUpdateFromRig = QtWidgets.QPushButton('Pose Rig + Match Mesh/Vertex Selection')
        qUpdateFromRig.clicked.connect(lambda: self.updateShapesFromRelations(bOnlySelectedIfSelection=True))
        qRigFirstLine.addWidget(qUpdateFromRig)
        qPoseRig = QtWidgets.QPushButton('Pose Rig')
        qPoseRig.clicked.connect(lambda: self.updateShapesFromRelations(bSkipMatchShapes=True))
        qRigFirstLine.addWidget(qPoseRig)


        
        qGetSkinSetupButton = QtWidgets.QPushButton('Get Skin Setup')
        qRigLayout.addWidget(qGetSkinSetupButton)
        qGetSkinSetupButton.clicked.connect(self.getJawFromReference)


        if not library.isNone(meta):
            self.qMeta = meta.QMeta()
            self.qMeta.build(qLeftBottomLayout, self.qBlendShape, self)
            self.qBlendShape.funcUpdates.append(self.qMeta.update)

        for sText, qSlider in zip(sTwoDimSliderNames, self.qAllTwoDimSliders):
            qVertLayout = QtWidgets.QVBoxLayout()
            qVertLayout.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignTop)

            qSlidersLayout.addLayout(qVertLayout, QtCore.Qt.AlignRight)
            qSlider.qLabel = QtWidgets.QLabel(sText)
            qVertLayout.addWidget(qSlider.qLabel)
            qVertLayout.addWidget(qSlider)
            qVertLayout.addStretch()
            qSlider.selectTargetRows.connect(self.selectMainTargets)
            qSlider.isolateTargetRows.connect(self.isolateMainTargets)


        # extra models
        self.qMeshesTable = QModelTableWidget()
        self.qMeshesTable.setEditTriggers(QtWidgets.QTableWidget.NoEditTriggers)

        qBotLayout.addWidget(self.qMeshesTable)
        self.qMeshesTable.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.qMeshesTable.setColumnCount(2)
        self.qMeshesTable.setRowCount(0)
        self.qMeshesTable.verticalHeader().hide()
        # self.qMeshesTable.horizontalHeader().hide()
        self.qMeshesTable.setHorizontalHeaderLabels(['meshes', 'mirror'])
        self.qMeshesTable.horizontalHeader().setStretchLastSection(True)
        self.qMeshesTable.itemSelectionChanged.connect(self.meshTableSelectionChanged)
        self.qMeshesTable.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.qMeshesTable.customContextMenuRequested.connect(self.markingMenuMeshes)
        self.qMeshesTable.setMaximumWidth(1000)
        # self.qMeshesTable.setColumnWidth(1, 10)
        # header = self.qMeshesTable.horizontalHeader()
        # header.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        # header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        # self.qMeshesTable.setColumnWidth(1, 10)

        # extra models right column
        qBotRightLayout = QtWidgets.QVBoxLayout()
        qBotLayout.addLayout(qBotRightLayout)


        # get rid of Sync Mesh Selection ????? If no one complains....
        self.qSyncSelection = QtWidgets.QCheckBox('Sync Mesh Selection')
        self.qSyncSelection.setChecked(False)
        self.qSyncSelection.stateChanged.connect(self.syncMeshCheckboxChanged)
        # qBotRightLayout.addWidget(self.qSyncSelection)



        self.iSelectionScriptJob = cmds.scriptJob(e=["SelectionChanged", self.mayaSelectionChanged])
        self.bDisableSelectMeshesScriptJobOnce = False
        qBotRightLayout.addStretch()

        self.iUndoScriptJob = cmds.scriptJob(event=['Undo', self.mayaUndoEvent])

        self.iTimeChangedScriptJob = cmds.scriptJob(timeChange=self.mayaTimeChanged)


        self.sSculptMeshes = []
        self.bSculptMode = False
        self.bDisableDeleteSculptTargetScriptJob = False

        self.sBlendShape = None
        # self.qMainTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)


        self.iSelectionCounter = 0

        qToolsLayout = QtWidgets.QVBoxLayout()
        qTabs.addTab(makeWidgetFromLayout(qToolsLayout), 'Extras')

        # corners
        qCornersFrame = QtWidgets.QGroupBox('Align Corners')
        qCornersLayout = QtWidgets.QVBoxLayout()
        qCornersFrame.setLayout(qCornersLayout)
        qToolsLayout.addWidget(qCornersFrame)

        self.qCornerVertex = QSetObject()
        self.qCornerVertex.build(qCornersLayout, 'Left Corner Vertex', 'leftCornerVertex', qBlendShape=self.qBlendShape, bIsIndex=True)
        self.qCornerVertex50 = QSetObject()
        self.qCornerVertex50.build(qCornersLayout, 'Left Corner Vertex 50 %', 'leftCornerVertex50', qBlendShape=self.qBlendShape, bIsIndex=True)

        self.qCornerMask = QSetObject()
        self.qCornerMask.build(qCornersLayout, 'Corner Mask Cluster', 'cornerMaskCluster', qBlendShape=self.qBlendShape)


        qAlignButton = QtWidgets.QPushButton('Align Corners')
        qCornersLayout.addWidget(qAlignButton)
        qAlignButton.clicked.connect(self.alignCorners)

        qNegateShapesFrame = QtWidgets.QGroupBox('Create Negative Shapes')
        qNegateShapesLayout = QtWidgets.QVBoxLayout()
        qNegateShapesFrame.setLayout(qNegateShapesLayout)
        qToolsLayout.addWidget(qNegateShapesFrame)
        qNegateShapesButton = QtWidgets.QPushButton('create negative shapes')
        qNegateShapesButton.clicked.connect(self.negateShapes)
        qNegateShapesLayout.addWidget(qNegateShapesButton)


        qMirrorTableFrame = QtWidgets.QGroupBox('Create Mirror Tables')
        qMirrorTableLayout = QtWidgets.QVBoxLayout()
        qMirrorTableFrame.setLayout(qMirrorTableLayout)
        qToolsLayout.addWidget(qMirrorTableFrame)
        qMirrorTableEdgeButton = QtWidgets.QPushButton('selected (edgeflow)')
        qMirrorTableEdgeButton.clicked.connect(self.setMirrorTableSelectedE)
        qMirrorTableLayout.addWidget(qMirrorTableEdgeButton)
        qMirrorTablePosButton = QtWidgets.QPushButton('selected (position)')
        qMirrorTablePosButton.clicked.connect(self.setMirrorTableSelectedV)
        qMirrorTableLayout.addWidget(qMirrorTablePosButton)


        qBakeTableFrame = QtWidgets.QGroupBox('Bake Shapes')
        qBakeTableLayout = QtWidgets.QVBoxLayout()
        qBakeTableFrame.setLayout(qBakeTableLayout)
        qToolsLayout.addWidget(qBakeTableFrame)
        qBakeButton = QtWidgets.QPushButton('Bake All Targets')
        qBakeButton.clicked.connect(self.bakeTargets)
        qBakeTableLayout.addWidget(qBakeButton)
        qFillButton = QtWidgets.QPushButton('Fill Selected Sculpts to Targets')
        qFillButton.clicked.connect(self.fillSculptsClicked)
        qBakeTableLayout.addWidget(qFillButton)
        qFillButtonSel = QtWidgets.QPushButton('Fill Selected Sculpts to Targets (only on vertex selection)')
        qFillButtonSel.clicked.connect(lambda:self.fillSculptsClicked(bCheckModelSelection=True))
        qBakeTableLayout.addWidget(qFillButtonSel)

        qExtrasTableFrame = QtWidgets.QGroupBox('Extras')
        qExtrasTableLayout = QtWidgets.QVBoxLayout()
        qExtrasTableFrame.setLayout(qExtrasTableLayout)
        qToolsLayout.addWidget(qExtrasTableFrame)
        qCreateCurveButton = QtWidgets.QPushButton('Curve from selected vertices')
        qCreateCurveButton.clicked.connect(tools.createCurveFromSelectedVerts)
        qExtrasTableLayout.addWidget(qCreateCurveButton)

        qJointsOnCurveLayout = QtWidgets.QHBoxLayout()
        qJointsOnCurveButton = QtWidgets.QPushButton('Create Joints on selected vertices')
        self.qJointsOnCurveCount = QtWidgets.QLineEdit('10')
        qJointsOnCurveButton.clicked.connect(lambda: tools.createJointsOnSelectedCurve(int(self.qJointsOnCurveCount.text())))
        qJointsOnCurveLayout.addWidget(qJointsOnCurveButton)
        qJointsOnCurveLayout.addWidget(self.qJointsOnCurveCount)
        qExtrasTableLayout.addLayout(qJointsOnCurveLayout)
        qFaceARTableFrame = QtWidgets.QGroupBox('FaceAR')
        qFaceARTableLayout = QtWidgets.QVBoxLayout()
        qFaceARTableFrame.setLayout(qFaceARTableLayout)
        qToolsLayout.addWidget(qFaceARTableFrame)
        qFaceARButton = QtWidgets.QPushButton('Get Animation From FaceAR CSV File')
        qFaceARButton.clicked.connect(self.importCSV)
        qFaceARTableLayout.addWidget(qFaceARButton)

        qToolsLayout.addStretch()

        qRussian3dScannerLayout = QtWidgets.QVBoxLayout()
        qTabs.addTab(makeWidgetFromLayout(qRussian3dScannerLayout), 'Model Change different topology')
        qWrapMeshLayout = QtWidgets.QHBoxLayout()
        qRussian3dScannerLayout.addLayout(qWrapMeshLayout)
        self.qScanFromCombo = QtWidgets.QComboBox()
        qWrapMeshLayout.addWidget(self.qScanFromCombo)
        qWrapMeshLayout.addWidget(QtWidgets.QLabel(' -> '))
        self.qScanToMesh = QtWidgets.QLineEdit()
        self.qScanToMesh.setEnabled(False)
        qWrapMeshLayout.addWidget(self.qScanToMesh)
        qScanToSetButton = QtWidgets.QPushButton('Set')
        qWrapMeshLayout.addWidget(qScanToSetButton)

        qScanTableLayout = QtWidgets.QHBoxLayout()
        qRussian3dScannerLayout.addLayout(qScanTableLayout)
        qScanButtonsLayout = QtWidgets.QVBoxLayout()
        qScanTableLayout.addLayout(qScanButtonsLayout)


        # can we get rid of qCurvesTable ???
        self.qCurvesTable = QtWidgets.QTableWidget()
        self.qCurvesTable.setColumnCount(1)
        self.qCurvesTable.verticalHeader().hide()
        self.qCurvesTable.horizontalHeader().hide()
        self.qCurvesTable.horizontalHeader().setStretchLastSection(True)
        self.qCurvesTable.setEnabled(False)
        self.qCurvesTable.setHidden(True)



        qScanTableLayout.addWidget(self.qCurvesTable)
        qRussian3dScannerLayout.addWidget(self.qCurvesTable)
        qRussian3dScannerLayout.addStretch()
        qScanToSetButton.clicked.connect(self.setScanMesh)

        for sButton, func in [('Add Line', self.createLine),
                              ('Replace Line', self.replaceLine),
                              ('Mirror Line', self.mirrorLine),
                              ('Create Retopos', self.createRetoposWrap3d)]:
            qButton = QtWidgets.QPushButton(sButton)
            qButton.clicked.connect(func)
            qScanButtonsLayout.addWidget(qButton)

        self.qRetopo = QSetObject()
        self.qRetopo.build(qScanButtonsLayout, 'retopo', 'retopoObject', qBlendShape=self.qBlendShape)
        self.qRetopoOpen = QSetObject()
        self.qRetopoOpen.build(qScanButtonsLayout, 'retopoOpen', 'retopoOpenObject', qBlendShape=self.qBlendShape)

        for sButton, func in [('Wrap with Retopos', self.warpWithRetopos)]:
            qButton = QtWidgets.QPushButton(sButton)
            qButton.clicked.connect(func)
            qScanButtonsLayout.addWidget(qButton)

    cmds.selectPref(tso=True)


    def updateFileLists(self):
        self.dTargetListFiles = getListFileDict()
        self.qFileLists.blockSignals(True)
        try:
            self.qFileLists.clear()

            for sF in self.dTargetListFiles.keys():
                self.qFileLists.addItem(sF)

            if hasattr(self, 'sBlendShape'):
                sLocalLists = set()
                for sF in cmds.listAttr(self.sBlendShape):
                    if sF.startswith(kCurrentListFileFullContentAttr):
                        sListName = utils.replaceStringStart(sF, '%s_' % kCurrentListFileFullContentAttr, '')
                        if sListName not in self.dTargetListFiles.keys():
                            sLocalLists.add(sListName)

                for sListName in sLocalLists:
                    self.qFileLists.addItem('LOCAL: %s' % sListName)
        except:
            raise
        finally:
            self.qFileLists.blockSignals(False)


    def importCSV(self):
        def _importCsv(sFilePath, sSide):
            library.reload2(tools)
            tools.importCSV(self.qBlendShape.getBlendShape(), sFilePath=sFilePath, sSide=sSide)
            
        self.qFaceArDialog = QGetFaceArOptionsDialog(_importCsv)
        self.qFaceArDialog.show()


    def clickedMainTable(self, iRow, iColumn):
        if not library.shiftOrCtrlPressed():
            self.qComboTable.clearSelection()


    def clickedComboTable(self, iRow, iColumn):
        if not library.shiftOrCtrlPressed():
            self.qMainTable.clearSelection()


    def keyPressEvent(self, event):
        if event.key() == 16777216: # escape
            self.setWindowState(QtCore.Qt.WindowMinimized)
        else:
            QtWidgets.QDialog.keyPressEvent(self, event)


    def getCurves(self):
        sTransforms = cmds.listRelatives('_scanCurves', c=True, typ='transform') or []
        sCurrentCurves = [sT for sT in sTransforms if cmds.objExists('%s.bScanCurve' % sT)]
        return sCurrentCurves


    def getScanVertices(self, bReturnTriangles=False):
        sFromMesh, sToMesh = self.getScanMeshes()

        sCurves = self.getCurves()
        iFromVerts = np.zeros(len(sCurves), dtype=int)
        iToVerts = np.zeros(len(sCurves), dtype=int)

        print('sCurves: ', sCurves)
        for c,sCurve in enumerate(sCurves):
            fFromPoint = cmds.xform('%s.cv[0]' % sCurve, q=True, ws=True, t=True)
            iFromVerts[c] = library.getClosestVertex(sFromMesh, fFromPoint)

            fToPoint = cmds.xform('%s.cv[1]' % sCurve, q=True, ws=True, t=True)
            iToVerts[c] = library.getClosestVertex(sToMesh, fToPoint)


        if bReturnTriangles:
            xxxTriangles = [], []
            print('iFromVerts: ', iFromVerts)
            for s, iVerts, sMesh in [(0, iFromVerts, sFromMesh),
                                     (1, iToVerts, sToMesh)]:
                fnMesh = OpenMaya2.MFnMesh(library.getDagPath(sMesh))
                iTriangles = list(fnMesh.getTriangles()[1])

                # for i, iFrom,  in iFromVerts:
                for iV in iVerts:
                    iTriangleIndex = iTriangles.index(iV) // 3
                    iRelPointIndex = iTriangles.index(iV) % 3
                    xTriangle = [iTriangleIndex, 0.0, 0.0]

                    if iRelPointIndex == 0:
                        xTriangle[1] = 1.0
                    elif iRelPointIndex == 1:
                        xTriangle[2] = 1.0
                    elif iRelPointIndex == 2:
                        pass
                    else:
                        raise Exception('wrong index for triangle point: %d' % iRelPointIndex)

                    xxxTriangles[s].append(xTriangle)
            print('xTriangles: ', xxxTriangles)
            return xxxTriangles
            # fnToMesh = OpenMaya2.MFnMesh(library.getDagPath(sToMesh))
            # iToTriangles = np.array(fnToMesh.getTriangles()[1], dtype=int)
        else:
            return iFromVerts, iToVerts


    def createRetoposWrap3d(self):
        try:
            sClosed, sOpen = self.computeWrap3d()
            self.qRetopo.setClicked(sObject=sClosed)
            self.qRetopoOpen.setClicked(sObject=sOpen)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise


    def warpWithRetopos(self):
        try:
            sClosed = self.qRetopo.getObject()
            sOpen = self.qRetopoOpen.getObject()

            sFromMesh, sToMesh = self.getScanMeshes()
            for sAttr in ['tx','ty','tz','rx','ry','rz']:
                cmds.setAttr('%s.%s' % (sToMesh, sAttr), 0.0)
            self.addMeshesToBlendShapeAndTable([sClosed])

            self._poseToJawOpenWrapPose()
            tools.warpToOpenMeshPose(sFromMesh, self.sBlendShape, None, sNewMesh=sClosed, sMeshOpenPose=sOpen)
            tools.modelChange(self.sBlendShape, sClosed, sToMesh, bAskIfScaleDeltas=False)
            cmds.setAttr('%s.v' % sOpen, False)
            tools.resetAllShapes(self.sBlendShape)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise



    def _poseToJawOpenWrapPose(self):
        sJawOpenTarget = '%s.jawOpen' % self.sBlendShape
        if cmds.objExists(sJawOpenTarget):
            cmds.setAttr(sJawOpenTarget, 0.5)
        sBlinkTarget = '%s.blink' % self.sBlendShape
        if cmds.objExists(sBlinkTarget):
            cmds.setAttr(sBlinkTarget, 0.5)


    def computeWrap3d(self):

        if not os.path.exists(kWrap3dExe):
            cmds.confirmDialog(m='%s not found' % kWrap3dExe)
            return

        sFromMesh, sToMesh = self.getScanMeshes()
        sOutMeshes = ['retopo', 'retopoOpen']
        if cmds.objExists(sOutMeshes[0]) and cmds.objExists(sOutMeshes[1]):
            return sOutMeshes

        sWrap3dTempFolder = os.path.join(cmds.internalVar(utd=True), 'kangarooShapeEditorWrap3d')
        print('sWrap3dTempFolder: ', sWrap3dTempFolder)
        if not os.path.exists(sWrap3dTempFolder):
            os.makedirs(sWrap3dTempFolder)

        sFromFile = os.path.join(sWrap3dTempFolder, 'from.obj').replace('\\', '/')
        sOpenFromFile = os.path.join(sWrap3dTempFolder, 'fromJawOpen.obj').replace('\\', '/')
        sOutFileName = os.path.join(sWrap3dTempFolder, 'out##.obj').replace('\\', '/')
        sToFile = os.path.join(sWrap3dTempFolder, 'to.obj').replace('\\', '/')
        sOutFileDefault = os.path.join(sWrap3dTempFolder, 'out00.obj').replace('\\', '/')
        sOutFileOpen = os.path.join(sWrap3dTempFolder, 'out01.obj').replace('\\', '/')
        tools.resetAllShapes(self.qBlendShape.getBlendShape())
        library.exportObj(sFromMesh, sFromFile)

        self._poseToJawOpenWrapPose()
        library.exportObj(sFromMesh, sOpenFromFile)

        sAttrs = ['tx','ty','tz','rx','ry','rz']
        fOldValues = []
        for a,sA in enumerate(sAttrs):
            fOldValues.append(cmds.getAttr('%s.%s' % (sToMesh, sA)))
            cmds.setAttr('%s.%s' % (sToMesh, sA), 0.0)

        library.exportObj(sToMesh, sToFile)
        [cmds.setAttr('%s.%s' % (sToMesh,sA), fOldValues[a]) for a,sA in enumerate(sAttrs)]

        sProjectFile = os.path.join(os.path.dirname(__file__), 'wrap3d.wrap')
        sOutProjectFile = os.path.join(sWrap3dTempFolder, 'wrap3dOut.wrap')
        dWrap3dContent = library.getJsonContent(sProjectFile)
        dWrap3dContent['nodes']['toObj']['params']['fileName']['value'] = sToFile
        dWrap3dContent['nodes']['SaveGeom']['params']['fileName']['value'] = sOutFileName

        xxxTriangles = self.getScanVertices(bReturnTriangles=True)
        dWrap3dContent['nodes']['SelectPointPairs']['params']['pointsLeft']['value'] = xxxTriangles[1]
        dWrap3dContent['nodes']['SelectPointPairs']['params']['pointsRight']['value'] = xxxTriangles[0]

        library.setJsonContent(sOutProjectFile, dWrap3dContent)
        sCommand = [kWrap3dExe, 'compute', sOutProjectFile.replace('\\','/'), '-s', '0', '-e', '1']
        print('sCommand: ', sCommand)
        Process = subprocess.Popen(sCommand, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subProcessResults = Process.communicate()
        print(subProcessResults[0])
        print(subProcessResults[1])
        print ()
        if 'ERROR' in str(subProcessResults[1]):
            cmds.confirmDialog(m='Error with Wrap3d, please check script Editor')
            raise Exception(subProcessResults[1])


        for i, sFile in enumerate([sOutFileDefault, sOutFileOpen]):
            sNewMesh = sOutMeshes[i]
            if cmds.objExists(sNewMesh):
                continue

            with open(sFile) as myFile:
                sOutObjLines = list(myFile)
            fPoints = []
            for sLine in sOutObjLines:
                if sLine.startswith('v '):
                    sSplits = sLine.split(' ')
                    fPoints.append([float(sSplits[1]), float(sSplits[2]), float(sSplits[3])])
                else:
                    if len(fPoints):
                        break

            sRetopo = cmds.duplicate(sToMesh, n=sNewMesh)[0]
            [cmds.setAttr('%s.%s' % (sRetopo,sA), 0) for sA in sAttrs]
            mPointArray = OpenMaya2.MPointArray(fPoints)
            OpenMaya2.MFnMesh(library.getDagPath(sRetopo)).setPoints(mPointArray)

        return sOutMeshes



    def setScanMesh(self):
        if not self.sBlendShape:
            raise Exception('No blendShape is set, set blendShape first')

        sSel = cmds.ls(sl=True, flatten=True)
        sObj = sSel[0]
        self.qScanToMesh.setText(sObj)
        utils.addStringAttr(self.sBlendShape, 'sScanToMesh', sObj)



    def createLine(self, sFromMeshVertex=None, sToMeshVertex=None):
        sFromMesh, sToMesh = self.getScanMeshes()
        sSel = cmds.ls(orderedSelection=True, flatten=True, l=True)


        if library.isNone(sFromMeshVertex):
            sStrFromMesh = '%s.vtx[' % sFromMesh
            sFromMeshVertex = [sO for sO in sSel if sStrFromMesh in sO][-1]

        if library.isNone(sToMeshVertex):
            sStrToMesh = '%s.vtx[' % sToMesh
            sToMeshVertex = [sO for sO in sSel if sStrToMesh in sO][-1]


        cmds.undoInfo(openChunk=True)
        try:
            sGrp = '_scanCurves'
            sConstrainGrp = '_scanCurvesData'
            if not cmds.objExists(sGrp):
                cmds.createNode('transform', n=sGrp)
            if not cmds.objExists(sConstrainGrp):
                cmds.createNode('transform', n=sConstrainGrp, p=sGrp)
            cmds.setAttr('%s.v' % sConstrainGrp, False)

            sCurve = cmds.curve(p=[[0,0,0], [0,0,0]], n=library.getUniqueName('scannerLine_0'), d=1)
            cmds.addAttr(sCurve, ln='bScanCurve', defaultValue=1)
            sClusterFrom = cmds.cluster('%s.cv[0]' % sCurve)[1]
            sClusterTo = cmds.cluster('%s.cv[1]' % sCurve)[1]

            cmds.parent(sCurve, sGrp)
            cmds.parent(sClusterFrom, sClusterTo, sConstrainGrp)

            sMessageAttr = library.addAttr(sCurve, ln='clusterFrom', at='message')
            cmds.connectAttr('%s.message' % sClusterFrom, sMessageAttr)
            sMessageAttr = library.addAttr(sCurve, ln='clusterTo', at='message')
            cmds.connectAttr('%s.message' % sClusterTo, sMessageAttr)

            library.createRivetTransform(sFromMeshVertex, sClusterFrom, sParent=sConstrainGrp)
            library.createRivetTransform(sToMeshVertex, sClusterTo, sParent=sConstrainGrp)

            sCurvesAttr = '%s.%s' % (self.sBlendShape, kCurvesAttr)
            sCurrentCurves = [] if not cmds.objExists(sCurvesAttr) else eval(cmds.getAttr(sCurvesAttr))
            sCurrentCurves.append(sCurve)
            utils.addStringAttr(self.sBlendShape, kCurvesAttr, str(sCurrentCurves))

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.select(sCurve)
            cmds.undoInfo(closeChunk=True)

        self.addNewCurve(sCurve)

        return sCurve


    def addNewCurve(self, sCurve):
        qCurve = QtWidgets.QTableWidgetItem(sCurve)
        iNewIndex = self.qCurvesTable.rowCount()
        self.qCurvesTable.setRowCount(iNewIndex + 1)
        self.qCurvesTable.setItem(iNewIndex, 0, qCurve)


    def replaceLine(self):
        sSelBefore = cmds.ls(sl=True)
        sFromMesh, sToMesh = self.getScanMeshes()
        sSel = cmds.ls(sl=True, flatten=True)
        sStrFromMesh = '%s.vtx[' % sFromMesh
        sStrToMesh = '%s.vtx[' % sToMesh
        for o,sO in enumerate(sSel):
            if not sO.startswith('|'):
                sSel[o] = '|%s' % sO

        sFromMeshVertices = [sO for sO in sSel if sStrFromMesh in sO]
        sToMeshVertices = [sO for sO in sSel if sStrToMesh in sO]
        sFromMeshVertex = None if not sFromMeshVertices else sFromMeshVertices[0]
        sToMeshVertex = None if not sToMeshVertices else sToMeshVertices[0]

        sCurve = [sO for sO in cmds.ls('scannerLine_*', sl=True, et='transform')][0]
        print('sCurve: ', sCurve)

        cmds.undoInfo(openChunk=True)
        try:
            sGrp = '_scanCurves'
            sConstrainGrp = '_scanCurvesData'
            if not cmds.objExists(sGrp):
                cmds.createNode('transform', n=sGrp)
            if not cmds.objExists(sConstrainGrp):
                cmds.createNode('transform', n=sConstrainGrp, p=sGrp)
            cmds.setAttr('%s.v' % sConstrainGrp, False)

            sClusterFrom = cmds.listConnections('%s.clusterFrom' % sCurve, s=True, d=False)[0]
            sClusterTo = cmds.listConnections('%s.clusterTo' % sCurve, s=True, d=False)[0]

            if sFromMeshVertex:
                # cmds.delete(sClusterFrom)
                library.createRivetTransform(sFromMeshVertex, sClusterFrom, sParent=sConstrainGrp)

            if sToMeshVertex:
                # cmds.delete(sClusterTo)
                library.createRivetTransform(sToMeshVertex, sClusterTo, sParent=sConstrainGrp)

        except:
            raise
        finally:
            cmds.select(sSelBefore)
            cmds.undoInfo(closeChunk=True)



    def mirrorLine(self):

        try:
            cmds.undoInfo(openChunk=True)

            sFromMesh, sToMesh = self.getScanMeshes()
            sToMapArrayAttr = '%s.iMapArray' % sToMesh
            sFromMapArrayAttr = '%s.iMapArray' % sFromMesh

            if not cmds.objExists(sToMapArrayAttr):
                raise Exception('Mirror Table doesn\'t exist on "%s". To create go to Extras -> Create Mirror Table' % sToMesh)
            if not cmds.objExists(sFromMapArrayAttr):
                raise Exception('Mirror Table doesn\'t exist on "%s". To create go to Extras -> Create Mirror Table' % sFromMesh)

            iToMapArray = eval(cmds.getAttr(sToMapArrayAttr))
            iFromMapArray = eval(cmds.getAttr(sFromMapArrayAttr))

            sCurves = cmds.ls('scannerLine*', sl=True)

            sMirroredCurves = []
            for sCurve in sCurves:
                fFromPoint = cmds.xform('%s.cv[0]' % sCurve, q=True, ws=True, t=True)
                iFromVert = library.getClosestVertex(sFromMesh, fFromPoint)

                fToPoint = cmds.xform('%s.cv[1]' % sCurve, q=True, ws=True, t=True)
                iToVert = library.getClosestVertex(sToMesh, fToPoint)

                iFromMirrorVert = iFromMapArray[iFromVert]
                iToMirrorVert = iToMapArray[iToVert]
                sCurve = self.createLine('%s.vtx[%d]' % (sFromMesh, iFromMirrorVert),
                                           '%s.vtx[%d]' % (sToMesh, iToMirrorVert))
                sMirroredCurves.append(sCurve)

            cmds.select(sMirroredCurves)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def getScanMeshes(self):
        sFrom = self.qScanFromCombo.currentText()
        sAllMeshes = library.getBlendShapeMeshTransforms(self.sBlendShape, bFullPath=True)
        sCheckFrom = '|%s' % sFrom
        for sM in sAllMeshes:
            if sM.endswith(sCheckFrom):
                sFrom = sM
        return sFrom, self.qScanToMesh.text()


    def countMainSelection(self):
        self.iSelectionCounter += 1
        
        iMainRowCount = self.qMainTable.rowCount()
        iSelectedRows = []
        for i,qSelectionModel in enumerate([self.qMainTable.selectionModel(), self.qComboTable.selectionModel()]):

            iNewSelectedRows = [qRow.row() for qRow in qSelectionModel.selectedRows()]
            if i == 1:
                iNewSelectedRows = [iRow + iMainRowCount for iRow in iNewSelectedRows]
            iSelectedRows += iNewSelectedRows

        iNonSelectedRows = set(range(self.qMainTable.rowCount() + self.qComboTable.rowCount())) - set(iSelectedRows)


        for iRow in iSelectedRows:
            if iRow < iMainRowCount:
                if self.qMainTable.qAllCells[iRow].iSelectOrder == None:
                    self.qMainTable.qAllCells[iRow].iSelectOrder = self.iSelectionCounter
            else:
                if self.qComboTable.qAllCells[iRow-iMainRowCount].iSelectOrder == None:
                    self.qComboTable.qAllCells[iRow-iMainRowCount].iSelectOrder = self.iSelectionCounter

        for iRow in iNonSelectedRows:
            if iRow < iMainRowCount:
                self.qMainTable.qAllCells[iRow].iSelectOrder = None
            else:
                self.qComboTable.qAllCells[iRow-iMainRowCount].iSelectOrder = None

        if not iSelectedRows:
            self.iSelectionCounter = 0



    def selectMainTargets(self, sTargets):
        iSelectMainRows = []
        for iRow,qCell in enumerate(self.qMainTable.qAllCells):
            if qCell.sTarget in sTargets:
                iSelectMainRows.append(iRow)

        qSelectionModel = self.qMainTable.selectionModel()
        qSelectionModel.clearSelection()

        prevSelBehavior = self.qMainTable.selectionMode()
        try:
            self.qMainTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
            for iMainRow in iSelectMainRows:
                self.qMainTable.selectRow(iMainRow)
        except:
            raise
        finally:
            self.qMainTable.setSelectionMode(prevSelBehavior)




    def isolateMainTargets(self, sTargets):

        iSelectMainRows = []
        for iRow,qCell in enumerate(self.qMainTable.qAllCells):
            if qCell.sTarget in sTargets:
                iSelectMainRows.append(iRow)

        self.qIsolateMain.blockSignals(True)
        self.qIsolateMain.setChecked(True)
        self.qIsolateMain.blockSignals(False)


        for iRow,qCell in enumerate(self.qMainTable.qAllCells):
            if qCell.sTarget in sTargets:
                qCell.bIsolated = True
            else:
                qCell.bIsolated = False

        self.updateHidden(False)


    def setMirrorTableSelectedE(self):
        sMeshes = cmds.ls(sl=True)
        tools.setMirrorTableMiddleMeshes(sMeshes)


    def setMirrorTableSelectedV(self):
        sMeshes = cmds.ls(sl=True)
        tools.setMirrorTableMiddleMeshes(sMeshes, sType='V')


    def setMirrorTableMiddleMeshes(self, qMeshes, sType='I'):
        self.resetAllShapes()
        utils.reload2(tools)
        sMeshes = []
        for qMesh in qMeshes:
            sMeshes.append(qMesh.text().split('.')[0])
        tools.setMirrorTableMiddleMeshes(sMeshes, sType)

        for sMesh, qMesh in zip(sMeshes, qMeshes):
            qMirror = QtWidgets.QTableWidgetItem(cmds.getAttr('%s.sMirrorFlag' % sMesh))
            qMirror.setTextAlignment(QtCore.Qt.AlignCenter)
            self.qMeshesTable.setItem(qMesh.row(), 1, qMirror)


    def setMirrorTableSideMeshes(self, qMeshes, sType='I'): #iType: I=ids, V=vertex, F=faces
        self.resetAllShapes()
        utils.reload2(tools)
        sMeshes = []
        for qMesh in qMeshes:
            sMeshes.append(qMesh.text().split('.')[0])
        tools.setMirrorTableSideMeshes(sMeshes, sType)

        for sMesh, qMesh in zip(sMeshes, qMeshes):
            qMirror = QtWidgets.QTableWidgetItem(cmds.getAttr('%s.sMirrorFlag' % sMesh))
            qMirror.setTextAlignment(QtCore.Qt.AlignCenter)
            self.qMeshesTable.setItem(qMesh.row(), 1, qMirror)


    def fileListsUserSwitched(self):
        sCurrentFile = self.qFileLists.currentText()
        utils.addStringAttr(self.sBlendShape, kCurrentListFileAttr, utils.replaceStringStart(sCurrentFile, 'LOCAL: ', ''), bLock=True)
        self.refreshBlendShapes()



    def mainLayoutFilter(self, sFilters):
        if not sFilters:
            for iRow, qCell in enumerate(self.qMainTable.qAllCells):
                qCell.bFiltered = True
        else:
            for iRow,qCell in enumerate(self.qMainTable.qAllCells):
                if library.filterTarget(qCell.sTarget, sFilters):
                    qCell.bFiltered = True
                else:
                    qCell.bFiltered = False

        self.updateHidden(False)


    def comboLayoutFilter(self, sFilters):
        if not sFilters:
            for iRow, qCell in enumerate(self.qComboTable.qAllCells):
                qCell.bFiltered = True
        else:
            for iRow,qCell in enumerate(self.qComboTable.qAllCells):
                if library.filterTarget(qCell.sTarget, sFilters):
                    qCell.bFiltered = True
                else:
                    qCell.bFiltered = False

        self.updateHidden(True)


    def isolateMainClicked(self):
        bChecked = self.qIsolateMain.isChecked()
        iAllRows = set(range(self.qMainTable.rowCount()))
        if bChecked:
            iIsolateRows = set(self.getSelectedTargetRows(False))
            iHideRows = iAllRows - iIsolateRows
            for iRow in iIsolateRows:
                self.qMainTable.qAllCells[iRow].bIsolated = True
            for iRow in iHideRows:
                self.qMainTable.qAllCells[iRow].bIsolated = False
        else:
            for iRow in iAllRows:
                self.qMainTable.qAllCells[iRow].bIsolated = True

        self.updateHidden(False)



    def updateHidden(self, bCombo):
        if bCombo:
            for qCell in self.qComboTable.qAllCells:
                if qCell.bFiltered and qCell.bIsolated:
                    self.qComboTable.setRowHidden(qCell.iRowIndex, False)
                else:
                    self.qComboTable.setRowHidden(qCell.iRowIndex, True)
        else:
            for qCell in self.qMainTable.qAllCells:
                if qCell.bFiltered and qCell.bIsolated:
                    self.qMainTable.setRowHidden(qCell.iRowIndex, False)
                else:
                    self.qMainTable.setRowHidden(qCell.iRowIndex, True)


    def isolateComboClicked(self):
        bChecked = self.qIsolateCombo.isChecked()
        iAllRows = set(range(self.qComboTable.rowCount()))
        if bChecked:
            iIsolateRows = set(self.getSelectedTargetRows(True))
            iHideRows = iAllRows - iIsolateRows
            for iRow in iIsolateRows:
                self.qComboTable.setRowHidden(iRow, False)
            for iRow in iHideRows:
                self.qComboTable.setRowHidden(iRow, True)
        else:
            for iRow in iAllRows:
                self.qComboTable.setRowHidden(iRow, False)


    def resetAllShapes(self):
        tools.resetAllShapes(self.qBlendShape.getBlendShape())



    def fillSculptsClicked(self, bCheckModelSelection=False):

        sSelection = cmds.ls(sl=True)
        sSculpts = []
        dModelSelection = defaultdict(list)
        for sObj in sSelection:
            if '.' not in sObj:
                sSculpts.append(sObj)
            else:
                sModel, sComp = sObj.split('.')
                dModelSelection[sModel].append(sObj)

        sMainMesh = cmds.getAttr('%s.%s' % (self.sBlendShape, kMainMeshAttr))

        sSculpts.sort(key=lambda x: x.split('__')[-1].count('_'))

        sAllCurrentTargets = list(library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True).keys())
        sNewlyAddedTargets = []
        sFilledSculpts = []

        qStatusWindow = utilsQt.QStatusWindow('Fill Targets')
        qStatusWindow.setCount(len(sSculpts))

        cmds.undoInfo(openChunk=True)
        try:
            for sSculpt in sSculpts:
                sSplits = sSculpt.split('__')
                qStatusWindow.increment()

                if library.isInteger(sSplits[-1]): # inbetween
                    fInbetween = int(sSplits[-1]) * 0.01
                    sSculptMain = '__'.join(sSplits[:-1])
                else:
                    fInbetween = 1.0
                    sSculptMain = sSculpt

                if '__' in sSculptMain:
                    sModel, sTarget = sSculptMain.split('__')
                else:
                    sModel = sMainMesh
                    sTarget = sSplits[0]

                if sTarget not in sAllCurrentTargets+sNewlyAddedTargets:
                    if '_' in sTarget:
                        self.addNewComboTargetToTable(sTarget)
                    else:
                        self.addNewMainTargetToTable(sTarget)
                    sNewlyAddedTargets.append(sTarget)

                if bCheckModelSelection:
                    if sModel in dModelSelection:
                        cmds.select(dModelSelection[sModel])
                    else:
                        continue

                tools.setTargetsToNewSculpt(sModel, sSculpt, self.sBlendShape, [sTarget], fInbetweens=[fInbetween], bOnlySelectedIfSelection=bCheckModelSelection, fFactor=1.0)
                sFilledSculpts.append(sSculpt)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise

        finally:
            qStatusWindow.end()
            cmds.undoInfo(closeChunk=True)

        if sNewlyAddedTargets:
            cmds.confirmDialog(m=str('Success!\nFilled %d Shapes, %d new BlendShape Targets created: %s' % (len(sFilledSculpts), len(sNewlyAddedTargets), ', '.join(sNewlyAddedTargets))))
        else:
            cmds.confirmDialog(m=str('Success!\nFilled %d Shapes, no new BlendShape Targets created' % (len(sFilledSculpts))))


    def updateShapesFromRelations(self, sMeshes=None, bOnlySelectedIfSelection=False, bSkipMatchShapes=False):

        sTargets = ([self.qMainTable.qAllCells[iRow].sTarget for iRow in self.getSelectedTargetRows(False)] +
                    [self.qComboTable.qAllCells[iRow].sTarget for iRow in self.getSelectedTargetRows(True)])

        if library.isNone(sMeshes):
            sMeshes = self.getMeshes(bFullPath=False)
        sRigNamespace = self.qRig.getObject()
        dAllTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True)

        try:
            cmds.undoInfo(openChunk=True)
            for sT in sTargets:

                for fInb in tools.getSubTargets(self.sBlendShape, dAllTargets[sT], 1.0, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens):
                    KangarooMatchTools.goToDefaultPose(sRigNamespace)
                    for sPasser in cmds.ls('%sgrp_?_browSplines?Passer' % sRigNamespace, et='transform'):
                        if cmds.objExists(sPasser):
                            cmds.setAttr('%s.singleMainDown' % sPasser, 0)
                            cmds.setAttr('%s.singleMainUp' % sPasser, 0)


                    for sMainT in sT.split('_'):
                        if sMainT.startswith(kSplineLidCorrectivePrefix):
                            sBotTopSplits = sMainT.split(kSplineLideCorrectiveSep)[-2:]
                            for p, sPart in enumerate(['bot', 'top']):
                                if sBotTopSplits[p]:
                                    if sBotTopSplits[p].startswith('n'):
                                        iValue = -int(sBotTopSplits[p][1:])
                                    else:
                                        iValue = int(sBotTopSplits[p])
                                    fValue = iValue * 0.01 * fInb
                                    if p == 0:
                                        if cmds.attributeQuery('stopAtBlinkLine', node='%slidBot_l_ctrl' % sRigNamespace, exists=True):
                                            cmds.setAttr('%slidBot_l_ctrl.stopAtBlinkLine' % sRigNamespace, 0.0)
                                            cmds.setAttr('%slidBot_r_ctrl.stopAtBlinkLine' % sRigNamespace, 0.0)
                                        cmds.setAttr('%slidBot_l_ctrl.ty' % sRigNamespace, fValue)
                                        cmds.setAttr('%slidBot_r_ctrl.ty' % sRigNamespace, fValue)
                                    else:
                                        if cmds.attributeQuery('stopAtBlinkLine', node='%slidTop_l_ctrl' % sRigNamespace, exists=True):
                                            cmds.setAttr('%slidTop_l_ctrl.stopAtBlinkLine' % sRigNamespace, 0.0)
                                            cmds.setAttr('%slidTop_r_ctrl.stopAtBlinkLine' % sRigNamespace, 0.0)
                                        cmds.setAttr('%slidTop_l_ctrl.ty' % sRigNamespace, fValue)
                                        cmds.setAttr('%slidTop_r_ctrl.ty' % sRigNamespace, fValue)

                        else:
                            for sAttr, xValue in list(getRigRelations(sRigNamespace)[sMainT].items()):
                                if callable(xValue):
                                    fValue = xValue(self.sBlendShape, '', sRigNamespace)
                                else:
                                    if isinstance(xValue, list):
                                        fValue = xValue[1]
                                    else:
                                        fValue = xValue

                                sFullAttr = '%s%s' % (sRigNamespace, sAttr)
                                if cmds.getAttr(sFullAttr, settable=True): # added this so it doesn't break when attribute is manually locked
                                    cmds.setAttr(sFullAttr, fValue * fInb)
                                else:
                                    if not sFullAttr.endswith('.puckerOnIn'):
                                        cmds.confirmDialog(m='skipping attribute "%s" because it\'s locked' % sFullAttr)

                    if not bSkipMatchShapes:
                        self.qMeshesTable.blockSignals(True)
                        sRigMeshes = ['%s%s' % (sRigNamespace, sMesh) for sMesh in sMeshes]
                        tools.setTargetsToNewSculpt(sMeshes, sRigMeshes, self.sBlendShape, [sT], fInbetweens=[fInb], bOnlySelectedIfSelection=bOnlySelectedIfSelection)

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            self.qMeshesTable.blockSignals(False)
            cmds.undoInfo(closeChunk=True)



    def bakeTargets(self):

        library.reload2(tools)

        sDisabledMeshesAttr = '%s.%s' % (self.sBlendShape, kDisabledMeshesAttr)
        if cmds.objExists(sDisabledMeshesAttr):
            sDisabledMeshes = eval(cmds.getAttr(sDisabledMeshesAttr))
        else:
            sDisabledMeshes = []

        tools.bakeTargets(self.sBlendShape, sMainMesh=self.getMainMesh(), sIgnoreMeshes=sDisabledMeshes) #, bJustDeltas=bJustDeltas)


    def getMainMesh(self):
        return cmds.getAttr('%s.%s' % (self.sBlendShape, kMainMeshAttr))


    def getJawFromReference(self):
        library.reload2(tools)
        tools.getJawFromReferenceRig(self.sBlendShape, self.qRig.getObject())
        self.qBlendShape.setClicked(bRefreshCurrent=True)



    def comboModeChanged(self, sTargetAttr, sComboMode):
        print ('sComboMode: ', sComboMode)
        getComboTargetConditionPlug(sTargetAttr, sComboMode=sComboMode, bForceRecreate=True)


    def enabledUpdate(self, bMoveTwoDimSliders=True):
        sAttr = '%s.%s' % (self.sBlendShape, kEnabledInfoAttr)
        if cmds.objExists(sAttr):
            dTargets = eval(cmds.getAttr(sAttr))
        else:
            dTargets = {}

        # bHiddenFunnel = False if dTargets.get('funnel', True) else True
        sExistingTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True)
        if bMoveTwoDimSliders:
            self.bCornerOutUpEnabled = dTargets.get('cornerOutUp', False) if 'cornerOutUp' in sExistingTargets else False
            self.bCornerOutDownEnabled = dTargets.get('cornerOutDown', False) if 'cornerOutDown' in sExistingTargets else False
            self.bCornerInUpEnabled = dTargets.get('cornerInUp', False) if 'cornerInUp' in sExistingTargets else False
            self.bCornerInDownEnabled = dTargets.get('cornerInDown', False) if 'cornerInDown' in sExistingTargets else False
            self.moveCornerTargets()
            self.moveNostrilTargets()
            # self.moveFunnelTargets()


    def moveBrowTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qBrowPoint'):
                return
            qPoint = self.qBrowPoint
        else:
            self.qBrowPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.y() > 0:
                dCells['innerBrowUp'].qSlider.setValue(qPoint.y())
                dCells['innerBrowDown'].qSlider.setValue(0)
            elif qPoint.y() < 0:
                dCells['innerBrowUp'].qSlider.setValue(0)
                dCells['innerBrowDown'].qSlider.setValue(-qPoint.y())
            else:
                dCells['innerBrowUp'].qSlider.setValue(0)
                dCells['innerBrowDown'].qSlider.setValue(0)


            if 'browOut' in dCells:
                if qPoint.x() > 0:
                    dCells['browOut'].qSlider.setValue(qPoint.x())
                elif qPoint.x() < 0:
                    dCells['browOut'].qSlider.setValue(0)
                else:
                    dCells['browOut'].qSlider.setValue(0)
            if 'browIn' in dCells:
                if qPoint.x() > 0:
                    dCells['browIn'].qSlider.setValue(0)
                elif qPoint.x() < 0:
                    dCells['browIn'].qSlider.setValue(-qPoint.x())
                else:
                    dCells['browIn'].qSlider.setValue(0)

        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def moveMouthTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qMouthPoint'):
                return
            qPoint = self.qMouthPoint
        else:
            self.qMouthPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.y() > 0:
                if 'mouthUp' in dCells: dCells['mouthUp'].qSlider.setValue(qPoint.y())
                if 'mouthDown' in dCells: dCells['mouthDown'].qSlider.setValue(0)
            elif qPoint.y() < 0:
                if 'mouthUp' in dCells: dCells['mouthUp'].qSlider.setValue(0)
                if 'mouthDown' in dCells: dCells['mouthDown'].qSlider.setValue(-qPoint.y())
            else:
                if 'mouthUp' in dCells: dCells['mouthUp'].qSlider.setValue(0)
                if 'mouthDown' in dCells: dCells['mouthDown'].qSlider.setValue(0)

            if 'mouthLeft' in dCells:
                if qPoint.x() > 0:
                    dCells['mouthLeft'].qSlider.setValue(qPoint.x())
                elif qPoint.x() < 0:
                    dCells['mouthLeft'].qSlider.setValue(0)
                else:
                    dCells['mouthLeft'].qSlider.setValue(0)
            if 'mouthRight' in dCells:
                if qPoint.x() > 0:
                    dCells['mouthRight'].qSlider.setValue(0)
                elif qPoint.x() < 0:
                    dCells['mouthRight'].qSlider.setValue(-qPoint.x())
                else:
                    dCells['mouthRight'].qSlider.setValue(0)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)




    def moveOuterBrowTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qOuterBrowPoint'):
                return
            qPoint = self.qOuterBrowPoint
        else:
            self.qOuterBrowPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.y() > 0:
                if 'outerBrowUp' in dCells: dCells['outerBrowUp'].qSlider.setValue(qPoint.y())
                if 'outerBrowDown' in dCells: dCells['outerBrowDown'].qSlider.setValue(0)
            elif qPoint.y() < 0:
                if 'outerBrowUp' in dCells: dCells['outerBrowUp'].qSlider.setValue(0)
                if 'outerBrowDown' in dCells: dCells['outerBrowDown'].qSlider.setValue(-qPoint.y())
            else:
                if 'outerBrowUp' in dCells: dCells['outerBrowUp'].qSlider.setValue(0)
                if 'outerBrowDown' in dCells: dCells['outerBrowDown'].qSlider.setValue(0)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def moveNostrilTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qNostrilPoint'):
                return
            qPoint = self.qNostrilPoint
        else:
            self.qNostrilPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.y() > 0:
                if 'nostrilOut' in dCells: dCells['nostrilOut'].qSlider.setValue(qPoint.y())
                if 'nostrilIn' in dCells: dCells['nostrilIn'].qSlider.setValue(0)
            elif qPoint.y() < 0:
                if 'nostrilOut' in dCells: dCells['nostrilOut'].qSlider.setValue(0)
                if 'nostrilIn' in dCells: dCells['nostrilIn'].qSlider.setValue(-qPoint.y())
            else:
                if 'nostrilOut' in dCells: dCells['nostrilOut'].qSlider.setValue(0)
                if 'nostrilIn' in dCells: dCells['nostrilIn'].qSlider.setValue(0)
        except:
                raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def moveJawTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qNostrilPoint'):
                return
            qPoint = self.qNostrilPoint
        else:
            self.qNostrilPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if 'jawOpen' in dCells:
                dCells['jawOpen'].qSlider.setValue(-qPoint.y())
        except:
                raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def moveUpperTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qUpperPoint'):
                return
            qPoint = self.qUpperPoint
        else:
            self.qUpperPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.y() > 0:
                if 'upperUp' in dCells: dCells['upperUp'].qSlider.setValue(qPoint.y())
                if 'upperDown' in dCells: dCells['upperDown'].qSlider.setValue(0)
            elif qPoint.y() < 0:
                if 'upperUp' in dCells: dCells['upperUp'].qSlider.setValue(0)
                if 'upperDown' in dCells: dCells['upperDown'].qSlider.setValue(-qPoint.y())
            else:
                if 'upperUp' in dCells: dCells['upperUp'].qSlider.setValue(0)
                if 'upperDown' in dCells: dCells['upperDown'].qSlider.setValue(0)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def moveLowerTargets(self, qPoint=None):
        if qPoint == None:
            if not hasattr(self, 'qLowerPoint'):
                return
            qPoint = self.qLowerPoint
        else:
            self.qLowerPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.y() > 0:
                if 'lowerUp' in dCells: dCells['lowerUp'].qSlider.setValue(qPoint.y())
                if 'lowerDown' in dCells: dCells['lowerDown'].qSlider.setValue(0)
            elif qPoint.y() < 0:
                if 'lowerUp' in dCells: dCells['lowerUp'].qSlider.setValue(0)
                if 'lowerDown' in dCells: dCells['lowerDown'].qSlider.setValue(-qPoint.y())
            else:
                if 'lowerUp' in dCells: dCells['lowerUp'].qSlider.setValue(0)
                if 'lowerDown' in dCells: dCells['lowerDown'].qSlider.setValue(0)
        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)



    def evaluateAllSliderRanges(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}

        def _isActive(sTarget):
            if sTarget in dCells:
                qCell = dCells[sTarget]
                return qCell.isEnabled()
            else:
                return False

        # inner brow
        iRangeX = [0,0]
        if _isActive('browIn'):
            iRangeX[0] = -100
        if _isActive('browOut'):
            iRangeX[1] = 100
        self.qBrowSlider.setRange(iRangeX, [-100,100])

        iRangeY = [0,0]
        if _isActive('outerBrowUp'):
            iRangeY[1] = 100
        if _isActive('outerBrowDown'):
            iRangeY[0] = -100
        self.qOuterBrowSlider.setRange([0,0], iRangeY)

        # nostril
        iRangeY = [0,0]
        if _isActive('nostrilIn'):
            iRangeY[0] = -100
        if _isActive('nostrilOut'):
            iRangeY[1] = 100
        self.qNostrilSlider.setRange([0,0], iRangeY)


        # upper
        iRangeY = [0,0]
        if _isActive('upperDown'):
            iRangeY[0] = -100
        if _isActive('upperUp'):
            iRangeY[1] = 100
        self.qUpperSlider.setRange([0,0], iRangeY)


        # lower
        iRangeY = [0,0]
        if _isActive('lowerDown'):
            iRangeY[0] = -100
        if _isActive('lowerUp'):
            iRangeY[1] = 100
        self.qLowerSlider.setRange([0,0], iRangeY)




        for qTwoDimSlider in self.qAllTwoDimSliders:
            qTwoDimSlider.udpateTargets()


    def updateNostrilSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iOut = 0 if 'nostrilOut' not in dCells else dCells['nostrilOut'].qSlider.value()
        iIn = 0 if 'nostrilIn' not in dCells else dCells['nostrilIn'].qSlider.value()

        qPoint = QtCore.QPoint(0,0)
        if iOut == 0 and iIn == 0:
            qPoint.setY(0)
        else:
            if iOut > iIn:
                qPoint.setY(iOut)
            else:
                qPoint.setY(-iIn)

        self.qNostrilSlider.setPoint(qPoint)


    def updateJawSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iJawOpen = 0 if 'jawOpen' not in dCells else dCells['jawOpen'].qSlider.value()

        qPoint = QtCore.QPoint(0,-iJawOpen)

        self.qJawSlider.setPoint(qPoint)


    def updateUpperSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iOut = 0 if 'upperUp' not in dCells else dCells['upperUp'].qSlider.value()
        iIn = 0 if 'upperDown' not in dCells else dCells['upperDown'].qSlider.value()

        qPoint = QtCore.QPoint(0,0)
        if iOut == 0 and iIn == 0:
            qPoint.setY(0)
        else:
            if iOut > iIn:
                qPoint.setY(iOut)
            else:
                qPoint.setY(-iIn)

        self.qUpperSlider.setPoint(qPoint)


    def updateLowerSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iOut = 0 if 'lowerUp' not in dCells else dCells['lowerUp'].qSlider.value()
        iIn = 0 if 'lowerDown' not in dCells else dCells['lowerDown'].qSlider.value()

        qPoint = QtCore.QPoint(0,0)
        if iOut == 0 and iIn == 0:
            qPoint.setY(0)
        else:
            if iOut > iIn:
                qPoint.setY(iOut)
            else:
                qPoint.setY(-iIn)

        self.qLowerSlider.setPoint(qPoint)


    def updateBrowSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iUp = 0 if 'innerBrowUp' not in dCells else dCells['innerBrowUp'].qSlider.value()
        iDown = 0 if 'innerBrowDown' not in dCells else dCells['innerBrowDown'].qSlider.value()
        iOut = 0 if 'browOut' not in dCells else dCells['browOut'].qSlider.value()
        iIn = 0 if 'browIn' not in dCells else dCells['browIn'].qSlider.value()
        qPoint = QtCore.QPoint(0,0)

        if iUp == 0 and iDown == 0:
            qPoint.setY(0)
        else:
            if iUp > iDown:
                qPoint.setY(iUp)
            else:
                qPoint.setY(-iDown)

        if iOut == 0 and iIn == 0:
            qPoint.setX(0)
        else:
            if iOut > iIn:
                qPoint.setX(iOut)
            else:
                qPoint.setX(-iIn)

        self.qBrowSlider.setPoint(qPoint)


    def updateMouthSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iUp = 0 if 'mouthUp' not in dCells else dCells['mouthUp'].qSlider.value()
        iDown = 0 if 'mouthDown' not in dCells else dCells['mouthDown'].qSlider.value()
        iLeft = 0 if 'mouthLeft' not in dCells else dCells['mouthLeft'].qSlider.value()
        iRight = 0 if 'mouthRight' not in dCells else dCells['mouthRight'].qSlider.value()
        qPoint = QtCore.QPoint(0,0)

        if iUp == 0 and iDown == 0:
            qPoint.setY(0)
        else:
            if iUp > iDown:
                qPoint.setY(iUp)
            else:
                qPoint.setY(-iDown)

        if iLeft == 0 and iRight == 0:
            qPoint.setX(0)
        else:
            if iLeft > iRight:
                qPoint.setX(iLeft)
            else:
                qPoint.setX(-iRight)

        self.qMouthSlider.setPoint(qPoint)


    def updateOuterBrowSlider(self):
        dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
        iUp = 0 if 'outerBrowUp' not in dCells else dCells['outerBrowUp'].qSlider.value()
        iDown = 0 if 'outerBrowDown' not in dCells else dCells['outerBrowDown'].qSlider.value()
        qPoint = QtCore.QPoint(0,0)

        if iUp == 0 and iDown == 0:
            qPoint.setY(0)
        else:
            if iUp > iDown:
                qPoint.setY(iUp)
            else:
                qPoint.setY(-iDown)

        self.qOuterBrowSlider.setPoint(qPoint)


    # this is giving bad results, maybe could rewrite with proper barycentric algorithm? Might not be worth it
    # def updateCornerSlider(self):
    #     dCells = {qCell.sTarget: qCell for iRow,qCell in enumerate(self.qMainTable.qAllCells)}
    #
    #     fCornerIn = dCells['cornerIn'].qSlider.value() * 0.01
    #     fCornerOut = dCells['cornerOut'].qSlider.value() * 0.01
    #     fCornerUp = dCells['cornerUp'].qSlider.value() * 0.01
    #     fCornerDown = dCells['cornerDown'].qSlider.value() * 0.01
    #     fCornerOutUp = dCells['cornerOutUp'].qSlider.value() * 0.01 if self.bCornerOutUpEnabled else None
    #     fCornerOutDown = dCells['cornerOutDown'].qSlider.value() * 0.01 if self.bCornerOutDownEnabled else None
    #     fCornerInUp = dCells['cornerInUp'].qSlider.value() * 0.01 if self.bCornerInUpEnabled else None
    #     fCornerInDown = dCells['cornerInDown'].qSlider.value() * 0.01 if self.bCornerInDownEnabled else None
    #     qPoint = QtCore.QPoint(0,0)
    #
    #     def _mult(qPoint, fFactor):
    #         return QtCore.QPoint(qPoint.x() * fFactor, qPoint.y() * fFactor)
    #
    #     if fCornerIn > fCornerOut: # left side
    #         print ('left..')
    #         if fCornerUp > fCornerDown:
    #             print ('top')
    #             if self.bCornerInUpEnabled:
    #                 if fCornerIn > fCornerUp:
    #                     qPoint = _mult(QtCore.QPoint(-100,0), fCornerIn) + _mult(QtCore.QPoint(-100,100), fCornerInUp)
    #                 else:
    #                     print ('b')
    #                     qPoint = _mult(QtCore.QPoint(0,100), fCornerUp) + _mult(QtCore.QPoint(-100,100), fCornerInUp)
    #             else:
    #                 qPoint = QtCore.QPoint(-fCornerIn, fCornerUp)
    #         else: # bottom
    #             print ('bot')
    #             if self.bCornerInDownEnabled:
    #                 print ('enabled')
    #                 if fCornerIn > fCornerDown:
    #                     qPoint = _mult(QtCore.QPoint(-100,0), fCornerIn) + _mult(QtCore.QPoint(-100,-100), fCornerInDown)
    #                 else:
    #                     qPoint = _mult(QtCore.QPoint(0,-100), fCornerDown) + _mult(QtCore.QPoint(-100,-100), fCornerInDown)
    #             else:
    #                 print ('not enabled')
    #                 qPoint = QtCore.QPoint(-fCornerIn*100, -fCornerDown*100)
    #
    #     else:
    #         print ('right..')
    #         if fCornerUp > fCornerDown:
    #             if self.bCornerOutUpEnabled:
    #                 if fCornerOut > fCornerUp:
    #                     qPoint = _mult(QtCore.QPoint(100,0), fCornerOut) + _mult(QtCore.QPoint(100,100), fCornerOutUp)
    #                 else:
    #                     qPoint = _mult(QtCore.QPoint(0,100), fCornerUp) + _mult(QtCore.QPoint(100,100), fCornerOutUp)
    #             else:
    #                 qPoint = QtCore.QPoint(fCornerOut, fCornerUp)
    #         else: # bottom
    #             if self.bCornerOutDownEnabled:
    #                 if fCornerOut > fCornerDown:
    #                     qPoint = _mult(QtCore.QPoint(100,0), fCornerOut) + _mult(QtCore.QPoint(100,-100), fCornerOutDown)
    #                 else:
    #                     qPoint = _mult(QtCore.QPoint(0,-100), fCornerDown) + _mult(QtCore.QPoint(100,-100), fCornerOutDown)
    #             else:
    #                 qPoint = QtCore.QPoint(fCornerOut, -fCornerDown)
    #
    #     print ('qPoint: ', qPoint)
    #     self.qCornerSlider.setPoint(qPoint)


    def moveCornerTargets(self, qPoint=None):

        if qPoint == None:
            if not hasattr(self, 'qCornerPoint'):
                return
            qPoint = self.qCornerPoint
        else:
            self.qCornerPoint = qPoint

        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        dCells = {qC.sTarget: qC for qC in self.qMainTable.qAllCells}

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.x() < 0:
                dCells['cornerOut'].qSlider.setValue(0)
                if self.bCornerOutUpEnabled:
                    dCells['cornerOutUp'].qSlider.setValue(0)
                if self.bCornerOutDownEnabled:
                    dCells['cornerOutDown'].qSlider.setValue(0)

                if qPoint.y() > 0:
                    if self.bCornerInUpEnabled:
                        fBarycentricUp =  library.qBarycentric(qPoint, QtCore.QPoint(0,0), QtCore.QPoint(0,100), QtCore.QPoint(-100,100))
                        fBarycentricIn =  library.qBarycentric(qPoint, QtCore.QPoint(0,0), QtCore.QPoint(-100,0), QtCore.QPoint(-100,100))
                        if fBarycentricUp[0] >= 0.0 and fBarycentricUp[1] >= 0.0 and fBarycentricUp[2] >= 0.0:
                            dCells['cornerUp'].qSlider.setValue(fBarycentricUp[1])
                            dCells['cornerIn'].qSlider.setValue(0)
                            dCells['cornerInUp'].qSlider.setValue(fBarycentricUp[2])
                        else:
                            dCells['cornerUp'].qSlider.setValue(0)
                            dCells['cornerIn'].qSlider.setValue(fBarycentricIn[1])
                            dCells['cornerInUp'].qSlider.setValue(fBarycentricIn[2])
                    else:
                        dCells['cornerUp'].qSlider.setValue(qPoint.y())
                        dCells['cornerIn'].qSlider.setValue(-qPoint.x())
                        # dCells['cornerInUp'].qSlider.setValue(0)

                    if self.bCornerInDownEnabled:
                        dCells['cornerInDown'].qSlider.setValue(0)
                    dCells['cornerDown'].qSlider.setValue(0)

                else: # down
                    if self.bCornerInDownEnabled:
                        fBarycentricUp = library.qBarycentric(qPoint, QtCore.QPoint(0, 0), QtCore.QPoint(0, -100), QtCore.QPoint(-100, -100))
                        fBarycentricIn = library.qBarycentric(qPoint, QtCore.QPoint(0, 0), QtCore.QPoint(-100, 0), QtCore.QPoint(-100, -100))
                        if fBarycentricUp[0] >= 0.0 and fBarycentricUp[1] >= 0.0 and fBarycentricUp[2] >= 0.0:
                            dCells['cornerDown'].qSlider.setValue(fBarycentricUp[1])
                            dCells['cornerIn'].qSlider.setValue(0)
                            dCells['cornerInDown'].qSlider.setValue(fBarycentricUp[2])
                        else:
                            dCells['cornerDown'].qSlider.setValue(0)
                            dCells['cornerIn'].qSlider.setValue(fBarycentricIn[1])
                            dCells['cornerInDown'].qSlider.setValue(fBarycentricIn[2])
                    else:
                        dCells['cornerDown'].qSlider.setValue(-qPoint.y())
                        dCells['cornerIn'].qSlider.setValue(-qPoint.x())

            else: # corner outs
                dCells['cornerIn'].qSlider.setValue(0)

                if qPoint.y() > 0:
                    if self.bCornerOutUpEnabled:
                        fBarycentricUp =  library.qBarycentric(qPoint, QtCore.QPoint(0,0), QtCore.QPoint(0,100), QtCore.QPoint(100,100))
                        fBarycentricOut =  library.qBarycentric(qPoint, QtCore.QPoint(0,0), QtCore.QPoint(100,0), QtCore.QPoint(100,100))
                        if fBarycentricUp[0] >= 0.0 and fBarycentricUp[1] >= 0.0 and fBarycentricUp[2] >= 0.0:
                            dCells['cornerUp'].qSlider.setValue(fBarycentricUp[1])
                            dCells['cornerOut'].qSlider.setValue(0)
                            dCells['cornerOutUp'].qSlider.setValue(fBarycentricUp[2])
                        else:
                            dCells['cornerUp'].qSlider.setValue(0)
                            dCells['cornerOut'].qSlider.setValue(fBarycentricOut[1])
                            dCells['cornerOutUp'].qSlider.setValue(fBarycentricOut[2])
                    else:
                        dCells['cornerUp'].qSlider.setValue(qPoint.y())
                        dCells['cornerOut'].qSlider.setValue(qPoint.x())
                        # dCells['cornerOutUp'].qSlider.setValue(0)

                    if self.bCornerOutDownEnabled:
                        dCells['cornerOutDown'].qSlider.setValue(0)
                    dCells['cornerDown'].qSlider.setValue(0)

                else: # down
                    if self.bCornerOutDownEnabled:
                        fBarycentricUp = library.qBarycentric(qPoint, QtCore.QPoint(0, 0), QtCore.QPoint(0, -100), QtCore.QPoint(100, -100))
                        fBarycentricOut = library.qBarycentric(qPoint, QtCore.QPoint(0, 0), QtCore.QPoint(100, 0), QtCore.QPoint(100, -100))
                        if fBarycentricUp[0] >= 0.0 and fBarycentricUp[1] >= 0.0 and fBarycentricUp[2] >= 0.0:
                            dCells['cornerDown'].qSlider.setValue(fBarycentricUp[1])
                            dCells['cornerOut'].qSlider.setValue(0)
                            dCells['cornerOutDown'].qSlider.setValue(fBarycentricUp[2])
                        else:
                            dCells['cornerDown'].qSlider.setValue(0)
                            dCells['cornerOut'].qSlider.setValue(fBarycentricOut[1])
                            dCells['cornerOutDown'].qSlider.setValue(fBarycentricOut[2])
                    else:
                        dCells['cornerDown'].qSlider.setValue(-qPoint.y())
                        dCells['cornerOut'].qSlider.setValue(qPoint.x())
                        # dCells['cornerOutDown'].qSlider.setValue(0)

                    if self.bCornerOutUpEnabled:
                        dCells['cornerOutUp'].qSlider.setValue(0)
                    dCells['cornerUp'].qSlider.setValue(0)

        except Exception as e:
            cmds.warning('not able to move mouth slider')
            cmds.warning(e)
        finally:
            cmds.undoInfo(closeChunk=True)


    def moveFunnelTargets(self, qPoint=None):
        if not self.sBlendShape or not cmds.objExists(self.sBlendShape):
            return

        if qPoint == None:
            if not hasattr(self, 'qFunnelPoint'):
                return
            qPoint = self.qFunnelPoint
        else:
            self.qFunnelPoint = qPoint

        cmds.undoInfo(openChunk=True)
        try:
            if qPoint.x() < 0:
                fBarycentricUp =  library.qBarycentric(qPoint, QtCore.QPoint(0,0), QtCore.QPoint(0,100), QtCore.QPoint(-100,100))
                fBarycentricOut =  library.qBarycentric(qPoint, QtCore.QPoint(0,0), QtCore.QPoint(-100,0), QtCore.QPoint(-100,100))

                if fBarycentricUp[0] >= 0.0 and fBarycentricUp[1] >= 0.0 and fBarycentricUp[2] >= 0.0:
                    cmds.setAttr('%s.upperUp' % self.sBlendShape, fBarycentricUp[1])
                    cmds.setAttr('%s.lowerDown' % self.sBlendShape, fBarycentricUp[1])
                    cmds.setAttr('%s.funnel' % self.sBlendShape, fBarycentricUp[2])
                    cmds.setAttr('%s.cornerIn' % self.sBlendShape, 0.0)
                else:
                    cmds.setAttr('%s.cornerIn' % self.sBlendShape, fBarycentricOut[1])
                    cmds.setAttr('%s.lowerDown' % self.sBlendShape, 0.0)
                    cmds.setAttr('%s.upperUp' % self.sBlendShape, 0.0)
                    cmds.setAttr('%s.funnel' % self.sBlendShape, fBarycentricOut[2])

                cmds.setAttr('%s.lowerRollIn' % self.sBlendShape, 0.0)
                cmds.setAttr('%s.upperRollIn' % self.sBlendShape, 0.0)
            else:
                cmds.setAttr('%s.lowerRollIn' % self.sBlendShape, qPoint.x() * 0.01)
                cmds.setAttr('%s.upperRollIn' % self.sBlendShape, qPoint.x() * 0.01)
                cmds.setAttr('%s.upperUp' % self.sBlendShape, qPoint.y() * 0.01)
                cmds.setAttr('%s.lowerDown' % self.sBlendShape, qPoint.y() * 0.01)
                cmds.setAttr('%s.funnel' % self.sBlendShape, 0.0)
                cmds.setAttr('%s.cornerIn' % self.sBlendShape, 0.0)


        except:
            raise
        finally:
            cmds.undoInfo(closeChunk=True)




    def mayaUndoEvent(self):
        if not self.bSculptMode:
            for sM in self.sSculptMeshes:
                if cmds.objExists(sM):
                    self.setSculptMode(True)
                    break


    def mayaTimeChanged(self):
        for qCell in self.qMainTable.qAllCells:
            qCell.updateKeyframeColor()



    def mayaSelectionChanged(self):

        if self.bDisableSelectMeshesScriptJobOnce:
            self.bDisableSelectMeshesScriptJobOnce = False
            return

        if self.qSyncSelection.isChecked():

            self.qMeshesTable.blockSignals(True)
            try:
                sSelection = set(cmds.ls(sl=True))
                iRowCount = self.qMeshesTable.rowCount()

                for iRow in range(iRowCount):
                    qItemColumn0 = self.qMeshesTable.item(iRow, 0)
                    qItemColumn1 = self.qMeshesTable.item(iRow, 1)
                    if qItemColumn0.text() in sSelection:
                        qItemColumn0.setSelected(True)
                        qItemColumn1.setSelected(True)
                    else:
                        qItemColumn0.setSelected(False)
                        qItemColumn1.setSelected(False)
            except:
                raise
            finally:
                self.qMeshesTable.blockSignals(False)


    def meshTableSelectionChanged(self):
        if self.qSyncSelection.isChecked():
            sSelect = [qI.text() for qI in self.getMeshes(bSelected=True, bReturnItems=True)]
            self.bDisableSelectMeshesScriptJobOnce = True
            cmds.select(sSelect)


    def syncMeshCheckboxChanged(self, qState):
        library.addAttr(self.sBlendShape, ln='bSyncMayaSelection', at='bool', defaultValue=True if qState else False, bReturnIfExists=True)
        if self.qSyncSelection.isChecked():
            self.meshTableSelectionChanged()



    def addMeshesToBlendShapeAndTable(self, sMeshes=None):
        if isinstance(sMeshes, type(None)):
            sMeshes = cmds.ls(sl=True, et='transform')

        for sMesh in sMeshes:
            if not utils.isOnOrigin(sMesh):
                if cmds.confirmDialog(m='"%s" is not on origin, this could give issues when building the rig.\nContinue?' % sMesh,
                                      button=['Abort', 'Continue']) == 'Abort':
                    return

        for sMesh in sMeshes:
            cmds.blendShape(self.sBlendShape, e=True, geometry=sMesh)

        iAllTArgetIndices = list(library.getTargetsDictFromBlendShape(self.sBlendShape).keys())
        dMeshIndices = library.getBlendShapeMeshTransforms(self.sBlendShape, bReturnIndexDict=True)

        for sMesh in sMeshes:
            iMeshIndex = dMeshIndices[sMesh]
            for iTargetIndex in iAllTArgetIndices:
                fZeroPoints = [(0.0, 0.0, 0.0, 1.0)]
                iInbetweenIndices = blendShapes.getInbetweenTargetIndices(self.sBlendShape, iTargetIndex) # instead of that we just used the number 6000
                for iInbetweenIndex in iInbetweenIndices:
                    cmds.setAttr(f'{self.sBlendShape}.inputTarget[{iMeshIndex}].inputTargetGroup[{iTargetIndex}].inputTargetItem[{iInbetweenIndex}].inputPointsTarget',
                                 len(fZeroPoints), *fZeroPoints, type='pointArray')
                    if cmds.listRelatives(sMesh, typ='nurbsCurve'):
                        sZeroPoints = ['cv[0]']
                    elif cmds.listRelatives(sMesh, typ='nurbsSurface'):
                        sZeroPoints = ['cv[0][0]']
                    else:
                        sZeroPoints = ['vtx[0]']
                    cmds.setAttr(f'{self.sBlendShape}.inputTarget[{iMeshIndex}].inputTargetGroup[{iTargetIndex}].inputTargetItem[{iInbetweenIndex}].inputComponentsTarget',
                                 len(sZeroPoints), *sZeroPoints, type='componentList')

        self.addMeshesToTable(sMeshes)



    def addMeshesToTable(self, sMeshes, bSelect=True, sMainMesh=None, sDisabledMeshes=[]):
        dGeometryIndices = getGeometryIndices(self.sBlendShape)

        self.qMeshesTable.blockSignals(True)
        try:
            for sMesh in sMeshes:
                qNewItem = QtWidgets.QTableWidgetItem(sMesh)
                qNewItem.setData(QtCore.Qt.UserRole, {'iGeometryIndex':dGeometryIndices[sMesh]})
                if sMesh == sMainMesh:
                    qNewItem.setFont(qFontBold)
                elif sMesh in sDisabledMeshes:
                    qNewItem.setFont(qFontItalic)
                iNewRowIndex = self.qMeshesTable.rowCount()
                self.qMeshesTable.setRowCount(iNewRowIndex + 1)
                self.qMeshesTable.setItem(iNewRowIndex, 0, qNewItem)
                self.qMeshesTable.verticalHeader().setMinimumSectionSize(_kMeshesRowHeight)
                self.qMeshesTable.setRowHeight(iNewRowIndex, _kMeshesRowHeight)
                
                sMirrorFlagAttr = '%s.sMirrorFlag' % sMesh
                if cmds.objExists(sMirrorFlagAttr):
                    qMirror = QtWidgets.QTableWidgetItem(cmds.getAttr(sMirrorFlagAttr))
                    qMirror.setTextAlignment(QtCore.Qt.AlignCenter)
                    self.qMeshesTable.setItem(iNewRowIndex, 1, qMirror)

        except:
            raise
        finally:
            self.qMeshesTable.blockSignals(False)


    def setSculptMode(self, bOn, sWindowTitleText = ''):
        if bOn:
            self.qApplyButton.setHidden(False)
            self.qCancelButton.setHidden(False)
            self.qMainTable.setEnabled(False)
            self.qComboTable.setEnabled(False)
            self.bDisableDeleteSculptTargetScriptJob = False
            self.bSculptMode = True
        else:
            self.qApplyButton.setHidden(True)
            self.qCancelButton.setHidden(True)
            self.qMainTable.setEnabled(True)
            self.qComboTable.setEnabled(True)
            self.bDisableDeleteSculptTargetScriptJob = True
            self.bSculptMode = False

        self.setWindowTitle('%s %s' % (kWindowTitle, sWindowTitleText))


    def resetDeltas(self, iRowIndices, bCombo, sMeshes=None):

        # iGeoIndices = cmds.blendShape(self.sBlendShape, q=True, geometryIndices=True)
        for iRowIndex in iRowIndices:
            if bCombo:
                iTargetIndex = self.qComboTable.qAllCells[iRowIndex].iTargetIndex
            else:
                iTargetIndex = self.qMainTable.qAllCells[iRowIndex].iTargetIndex

            print('self.sBlendShape: ', self.sBlendShape)
            print('sMeshes: ', sMeshes)
            library.resetTargetDeltasFull(self.sBlendShape, iTargetIndex, sMeshes=sMeshes)
            # for iGeo in iGeoIndices:


    def deleteTargets(self, iRowIndices, bCombo):

        self.resetDeltas(iRowIndices, bCombo)
        iRowIndices.sort(reverse=True)

        for iRowIndex in iRowIndices:
            if bCombo:
                sTargetAttr = self.qComboTable.qAllCells[iRowIndex].sTargetAttr
                self.qComboTable.qAllCells[iRowIndex].killCellScriptJobs()
                del self.qComboTable.qAllCells[iRowIndex]
                self.qComboTable.removeRow(iRowIndex)
            else:
                sTargetAttr = self.qMainTable.qAllCells[iRowIndex].sTargetAttr
                self.qMainTable.qAllCells[iRowIndex].killCellScriptJobs()
                del self.qMainTable.qAllCells[iRowIndex]
                self.qMainTable.removeRow(iRowIndex)

            sConnections = cmds.listConnections(sTargetAttr, s=True, d=False, p=True)
            if sConnections:
                cmds.disconnectAttr(sConnections[0], sTargetAttr)
            cmds.aliasAttr(sTargetAttr, rm=True)

        self.resetRowIndices(bCombo)


    def resetRowIndices(self, bCombo):
        if bCombo:
            for t,qCell in enumerate(self.qComboTable.qAllCells):
                qCell.iRowIndex = t
        else:
            for t,qCell in enumerate(self.qMainTable.qAllCells):
                qCell.iRowIndex = t


    def getSelectedTargetRows(self, bCombo, bIncludeHidden=False):
        if bCombo:
            qSelectionModel = self.qComboTable.selectionModel()
        else:
            qSelectionModel = self.qMainTable.selectionModel()

        iRows = []
        for qBlendShapeIndex in qSelectionModel.selectedRows():
            iR = qBlendShapeIndex.row()
            if bIncludeHidden:
                iRows.append(iR)
            else:
                if bCombo:
                    if not self.qComboTable.isRowHidden(iR):
                        iRows.append(iR)
                else:
                    if not self.qMainTable.isRowHidden(iR):
                        iRows.append(iR)
        return iRows





    def addNewMainTargetToTable(self, sTarget, bSelect=False):
        if '_' in sTarget:
            cmds.confirmDialog('there cannot be "_" in the name')
            return

        iTargetIndex = library.getFirstAvailableTargetIndexFromBlendShape(self.sBlendShape)
        sWeightAttr = '%s.w[%d]' % (self.sBlendShape,iTargetIndex)
        print ('sWeightAttr: ', sWeightAttr)
        print ('sTarget: ', sTarget)
        cmds.aliasAttr(sTarget, sWeightAttr)
        library.resetTargetDeltasFull(self.sBlendShape, iTargetIndex)
        return self.addExistingMainTargetToTable(sTarget, iTargetIndex, bSelect=bSelect)



    def addExistingMainTargetToTable(self, sTarget, iTargetIndex, bSelect=False):
        iRow = self.qMainTable.rowCount()

        bPredefinedTurnOffOption = [True, True]
        if sTarget in self.dPredefinedTargets:
            bPredefinedTurnOffOption = [self.dPredefinedTargets[sTarget]['bEnableBox'], self.dPredefinedTargets[sTarget]['bEnableBoxDefault']]
            sInfo = self.dPredefinedTargets[sTarget]['sInfo']
        else:
            sInfo = ''

        qCell = QTargetCell(self, self.qMainTable, self.sBlendShape, sTarget, iTargetIndex, iRow,
                            bNoSculpt=True if sTarget=='mouthCloseAuto' else False,
                            bPredefinedTurnOffOption=bPredefinedTurnOffOption,
                            sInfo=sInfo)
        self.qMainTable.setRowCount(iRow+1)
        self.qMainTable.setCellWidget(iRow, 0, qCell)
        self.qMainTable.qAllCells.append(qCell)
        self.qMainTable.setRowHeight(iRow, _ButtonHeight)
        if bSelect:
            self.qMainTable.selectRow(iRow)
        return qCell



    def addNewComboTargetToTable(self, sTarget):
        try:
            sMainTargets = sTarget.split('_')
            if '_'.join(sorted(sMainTargets)) != sTarget:# actually shouldn't be needed because it should always be sorted
                raise Exception('Wrong name for "%s", it needs to be ordered alphabetically' % sTarget)

            dTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True)
            if sTarget in dTargets:
                cmds.confirmDialog(m='there is already a combo shape for %s.' % sMainTargets)
                return

            iTargetIndex = library.getFirstAvailableTargetIndexFromBlendShape(self.sBlendShape)
            cmds.aliasAttr(sTarget, '%s.w[%d]' % (self.sBlendShape,iTargetIndex))
            library.resetTargetDeltasFull(self.sBlendShape, iTargetIndex)

            getComboTargetConditionPlug('%s.%s' % (self.sBlendShape, sTarget))

            qNewCell = self.addExistingComboTargetToTable(sTarget, iTargetIndex)
            self.qComboTable.selectRow(qNewCell.iRow)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise

        return qNewCell




    def addExistingComboTargetToTable(self, sTarget, iTargetIndex):
        sMainTargets = [library.getTargetPercNumber(sMainT)[0] for sMainT in sTarget.split('_')]
        sAllMainTargets = [self.qMainTable.qAllCells[iRow].sTarget for iRow in range(self.qMainTable.rowCount())]
        iMainTargets = [sAllMainTargets.index(sMainT) for sMainT in sMainTargets]

        iRow = self.qComboTable.rowCount()
        print ('sTarget: ', sTarget)
        sComboMode = getCurrentMode(self.sBlendShape, sTarget)

        qCell = QTargetCell(self, self.qMainTable, self.sBlendShape, sTarget, iTargetIndex, iRow, bCombo=True, iComboMainTargetRows=iMainTargets, sComboMode=sComboMode)
        self.qComboTable.setRowCount(iRow+1)
        self.qComboTable.setCellWidget(iRow, 0, qCell)
        self.qComboTable.qAllCells.append(qCell)
        self.qComboTable.setRowHeight(iRow, _ButtonHeight)
        qCell.iRow = iRow
        return qCell



    def deleteAnimation(self, iTargetRows, bJustCurrentKey=False):
        for iTargetRow in iTargetRows:
            self.qMainTable.qAllCells[iTargetRow].deleteAnimation(bJustCurrentKey=bJustCurrentKey)


    def copyDelta(self, qFrom, qTos):
        dMeshes = self.getMeshes(bSelected=False)
        # for iGeo in iGeoIndices:
        for sMesh, iMeshIndex in list(dMeshes.items()):
            # get
            sPointsTarget = cmds.getAttr(
                '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                    self.sBlendShape, iMeshIndex, qFrom.iTargetIndex))

            sComponentsTarget = cmds.getAttr(
                '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' % (
                    self.sBlendShape, iMeshIndex, qFrom.iTargetIndex))

            # set
            if isinstance(sPointsTarget, type(None)):
                sPointsTarget = []
                sComponentsTarget = []

            for qTo in qTos:
                cmds.setAttr(
                    '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                        self.sBlendShape, iMeshIndex, qTo.iTargetIndex), len(sPointsTarget), *sPointsTarget,
                    type='pointArray')
                cmds.setAttr(
                    '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' % (
                        self.sBlendShape, iMeshIndex, qTo.iTargetIndex), len(sComponentsTarget), *sComponentsTarget,
                    type='componentList')


    def copyWeights(self, qFrom, qTos, bInvert=False):
        dMeshes = self.getMeshes(bSelected=False)

        for sMesh, iMeshIndex in list(dMeshes.items()):
            iVertexCount = cmds.polyEvaluate(sMesh, vertex=True)

            if not isinstance(qFrom, (list,tuple)):
                fWeights = cmds.getAttr('%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (self.sBlendShape, iMeshIndex, qFrom.iTargetIndex, iVertexCount-1))
            else:
                aaWeights = []
                for qF in qFrom:
                    fW = cmds.getAttr('%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (self.sBlendShape, iMeshIndex, qF.iTargetIndex, iVertexCount - 1))
                    aaWeights.append(np.array(fW, dtype='float64'))
                fWeights = list(np.sum(aaWeights, axis=0))

            if bInvert:
                fWeights = list(1.0 - np.array(fWeights, dtype='float64'))

            for qTo in library.toList(qTos):
                cmds.setAttr('%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (self.sBlendShape, iMeshIndex, qTo.iTargetIndex, iVertexCount-1), *fWeights)




    def reverseDelta(self, qTargets):
        dMeshes = self.getMeshes(bSelected=False)

        for qT in qTargets:
            # for iGeo in iGeoIndices:
            for sMesh, iMeshIndex in list(dMeshes.items()):
                # get
                sPointsTarget = cmds.getAttr(
                    '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                        self.sBlendShape, iMeshIndex, qT.iTargetIndex))

                if sPointsTarget:
                    for p,fPoint4 in enumerate(sPointsTarget):
                        sPointsTarget[p] = (-fPoint4[0], -fPoint4[1], -fPoint4[2], fPoint4[3])

                    # set
                    cmds.setAttr(
                        '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' % (
                            self.sBlendShape, iMeshIndex, qT.iTargetIndex), len(sPointsTarget), *sPointsTarget,
                        type='pointArray')


    def bakeWeights(self, qTargets):

        dMeshes = self.getMeshes(bSelected=False)
        print('dMeshes: ', dMeshes)

        try:
            cmds.undoInfo(openChunk=True)
            for qT in qTargets:
                aaWeights = []

                for sMesh, iMeshIndex in list(dMeshes.items()):
                    iVertexCount = cmds.polyEvaluate(sMesh, v=True)
                    sWeightsAttr = '%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (self.sBlendShape, iMeshIndex, qT.iTargetIndex, iVertexCount-1)
                    aaWeights.append(np.array(cmds.getAttr(sWeightsAttr), dtype='float64'))
                    cmds.setAttr(sWeightsAttr, *([1.0] * iVertexCount))

                cmds.select(list(dMeshes.keys()))
                tools.multiplyTargets(self.sBlendShape, [qT.sTarget], aaWeights)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def invertWeights(self, qTargets):

        dMeshes = self.getMeshes(bSelected=False)

        try:
            cmds.undoInfo(openChunk=True)
            for qT in qTargets:
                for sMesh, iMeshIndex in list(dMeshes.items()):
                    iVertexCount = cmds.polyEvaluate(sMesh, v=True)
                    sWeightsAttr = '%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (self.sBlendShape, iMeshIndex, qT.iTargetIndex, iVertexCount-1)
                    aWeights = np.array(cmds.getAttr(sWeightsAttr), dtype='float64')
                    aInvertedWeights = 1.0 - aWeights
                    cmds.setAttr(sWeightsAttr, *(list(aInvertedWeights)))

        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)

    def setShapeToCurrent(self, qTargets, bCombo=True, bResetWeights=False):
        dMeshes = self.getMeshes(bSelected=False)

        dDeformerEnvelopes = {}
        dPoints = {}
        for sMesh, iMeshIndex in list(dMeshes.items()):
            dPoints[sMesh] = patch.patchFromName(sMesh).getPoints()
            sDeformers = deformers.listAllDeformers(sMesh)
            for sDef in sDeformers:
                if cmds.objectType(sDef) == 'blendShape':
                    continue
                sEnvelopeAttr = '%s.envelope' % sDef
                dDeformerEnvelopes[sEnvelopeAttr] = cmds.getAttr(sEnvelopeAttr)
                cmds.setAttr(sEnvelopeAttr, 0.0)

        cmds.undoInfo(openChunk=True)
        try:
            for qT in qTargets:
                tools.resetAllShapes(self.qBlendShape.getBlendShape())
                if bCombo:
                    sMainTargets = qT.sTarget.split('_')
                    for sMainT in sMainTargets:
                        cmds.setAttr('%s.%s' % (self.sBlendShape, sMainT), 1.0)
                        qT.qEnabledCheckBox.setChecked(True)
                else:
                    cmds.setAttr(qT.sTargetAttr, 1.0)

                if bResetWeights:
                    iVertexCount = cmds.polyEvaluate(sMesh, vertex=True)
                    sWeightsAttr = '%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (self.sBlendShape, iMeshIndex, qT.iTargetIndex, iVertexCount - 1)
                    cmds.setAttr(sWeightsAttr, *([1] * iVertexCount))

                cmds.sculptTarget(self.sBlendShape, e=True, t=qT.iTargetIndex)
                iPrevSculptTargetIndex = cmds.getAttr(self.sSculptTargetAttr)

                for sMesh, iMeshIndex in list(dMeshes.items()):
                    pMesh = patch.patchFromName(sMesh)
                    pMesh.setPoints(dPoints[sMesh])

            cmds.sculptTarget(self.sBlendShape, e=True, t=iPrevSculptTargetIndex)
            # cmds.setAttr(self.sSculptTargetAttr, -1)


        except:
            raise
        finally:
            for sAttr, fValue in dDeformerEnvelopes.items():
                cmds.setAttr(sAttr, fValue)
            cmds.undoInfo(closeChunk=True)




    def paintWeights(self, qTarget):

        # cmds.select(sMesh)
        mel.eval('toolPropertyWindow -inMainWindow true')
        mel.eval('source "artAttrBlendShapeCallback.mel"')
        # blendShape1.inputTarget[0].inputTargetGroup[pSphere2].targetWeights
        mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.paintTargetWeights" )' % self.sBlendShape)
        mel.eval('artBlendShapeTargetIndex')
        mel.eval('artBlendShapeSelectTarget artAttrCtx "%s"' % qTarget.sTarget)  # errors on first time
        mel.eval('artBlendShapeTargetIndex')
        mel.eval('artSetToolAndSelectAttr( "artAttrCtx", "blendShape.%s.paintTargetWeights" )' % self.sBlendShape)
        cmds.refresh(force=True)

        iIndex = mel.eval('artBlendShapeTargetIndex')
        if iIndex[0] != 0:
            cmds.confirmDialog(title='Confirm',
                               message='please select "paint" again to ensure you are painting '
                                       'the correct target.\n(this should only happen the first time after you opened Maya)',
                               button=['ok'])


    def _addWeightsActionsToMenu(self, qMenu):

        qSelectedTargets = [self.qMainTable.qAllCells[iRow] for iRow in self.getSelectedTargetRows(False)] + \
                            [self.qComboTable.qAllCells[iRow] for iRow in self.getSelectedTargetRows(True)]

        if len(qSelectedTargets) >= 2:
            iSelectionOrders = [qT.iSelectOrder for qT in qSelectedTargets]
            print('iSelectionOrders: ', iSelectionOrders)
            iFirstSelected = np.argmin(iSelectionOrders)
            qFrom = qSelectedTargets[iFirstSelected]
            qTos = [qSelectedTargets[iInd] for iInd in range(len(qSelectedTargets)) if iInd != iFirstSelected]
            sTos = library.listToString([qT.sTarget for qT in qTos], iMaxCount=2)
            qMenu.addAction('Copy delta of "%s" to "%s"' % (qFrom.sTarget, sTos), lambda: self.copyDelta(qFrom, qTos))
            qMenu.addAction('Copy weights of "%s" to "%s"' % (qFrom.sTarget, sTos), lambda: self.copyWeights(qFrom, qTos, bInvert=False))
            qMenu.addAction('Copy inverted weights of "%s" to "%s"' % (qFrom.sTarget, sTos), lambda: self.copyWeights(qFrom, qTos, bInvert=True))

            iLastSelected = np.argmax(iSelectionOrders)
            qFromsSum = [qSelectedTargets[iInd] for iInd in range(len(qSelectedTargets)) if iInd != iLastSelected]
            sFromsSum = library.listToString([qT.sTarget for qT in qFromsSum], iMaxCount=2)
            qMenu.addAction('Copy weights SUM from "%s" to "%s"' % (sFromsSum, qSelectedTargets[iLastSelected].sTarget),
                            lambda: self.copyWeights(qFromsSum, qSelectedTargets[iLastSelected], bInvert=False))


    def markingMenuMain(self, vPos):
        library.reload2(tools)

        qMenu = QNoEnterMenu()

        iSelectedTargetRows = self.getSelectedTargetRows(False)
        qSelectedTargets = [self.qMainTable.qAllCells[iRow] for iRow in iSelectedTargetRows]
        sSelectedTargets = [self.qMainTable.qAllCells[iRow].sTarget for iRow in iSelectedTargetRows]

        self._addWeightsActionsToMenu(qMenu)


        qMenu.addAction('Make delta from Current for %s' % library.listToString([qT.sTarget for qT in qSelectedTargets], iMaxCount=2), lambda: self.setShapeToCurrent(qSelectedTargets))
        # qMenu.addAction('Negate Delta of %s' % library.listToString([qT.sTarget for qT in qSelectedTargets], iMaxCount=2), lambda: self.reverseDelta(qSelectedTargets))



        if len(iSelectedTargetRows) >= 1:
            qMenu.addAction('Paint weights for %s' % qSelectedTargets[0].sTarget, lambda: self.paintWeights(qSelectedTargets[0]))
            # qMenu.addAction('Reset all deltas of %s (Selection)' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: tools.resetTargetDeltas(self.sBlendShape, sSelectedTargets))

            iPossibleDeleteTargets = []
            sPossibleDeleteTargets = []
            for iT,sT in zip(iSelectedTargetRows, sSelectedTargets):
                if sT not in list(self.dPredefinedTargets.keys()):
                    iPossibleDeleteTargets.append(iT)
                    sPossibleDeleteTargets.append(sT)
            if iPossibleDeleteTargets:
                qMenu.addAction('Delete "%s"' % library.listToString(sPossibleDeleteTargets, iMaxCount=2), lambda: self.deleteTargets(iPossibleDeleteTargets, False))

            qMenu.addAction('Invert Weights for %s' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: self.invertWeights(qSelectedTargets))
            qMenu.addAction('Bake Weights for %s' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: self.bakeWeights(qSelectedTargets))


        qMenu.addSeparator()
        qMenu.addAction('Bake %d selected Main Targets' % len(sSelectedTargets), lambda: tools.bakeTargets(self.sBlendShape, sMainMesh=self.getMainMesh(), sFilterTargets=sSelectedTargets))
        qMenu.addSeparator()

        def _addNewComboTargetToTable():
            sSelectedTargets.sort()
            self.addNewComboTargetToTable('_'.join(sSelectedTargets))
        qComboAction = qMenu.addAction('Create Combo Shape with %d shapes' % len(iSelectedTargetRows), _addNewComboTargetToTable)
        if len(iSelectedTargetRows) <= 1:
            qComboAction.setEnabled(False)


        def _isolateComboTargets(bExcludeNonSelected=False):
            iSelectComboRows = []
            sSelectedTargetsSet = set(sSelectedTargets)
            for qCell in self.qComboTable.qAllCells:
                sPercs = set(tools.getPercsFromComboName(qCell.sTarget).keys())
                sIntersection = sSelectedTargetsSet.intersection(sPercs)
                if sIntersection:
                    if bExcludeNonSelected:
                        if not len(sPercs - sSelectedTargetsSet):
                            iSelectComboRows.append(qCell.iRow)
                    else:
                        iSelectComboRows.append(qCell.iRow)

            iSelectComboRows = list(set(iSelectComboRows))

            self.qIsolateCombo.blockSignals(True)
            self.qIsolateCombo.setChecked(True)
            self.qIsolateCombo.blockSignals(False)

            for qCell in self.qComboTable.qAllCells:
                qCell.bIsolated = False

            for iRow in iSelectComboRows:
                qCell = self.qComboTable.qAllCells[iRow]
                qCell.bIsolated = True

            self.updateHidden(True)
        qMenu.addAction('Isolate Combo shapes', _isolateComboTargets)
        qNonSelected = qMenu.addAction('Isolate Combo shapes (exclude combos with non-selected)', lambda:_isolateComboTargets(bExcludeNonSelected=True))
        if len(sSelectedTargets) <= 1:
            qNonSelected.setEnabled(False)

        qMenu.addSeparator()



        # add new:
        qMenuAddNew = QtWidgets.QMenu('Add Target')
        qMenu.addMenu(qMenuAddNew)
        sTargets = list(library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True).keys())
        sTargets = [sT for sT in sTargets if '_' not in sT]

        ssAddTargets = getExtraFaceShapesForAddTargets(self.qRig.getObject())
        for tt, sAddTargets in enumerate(ssAddTargets):
            for sT in sAddTargets:
                if tt == 0 and sT in sTargets:
                    continue
                def _add(_sT=sT):
                    self.addNewMainTargetToTable(_sT, bSelect=True)

                sLabel = sT
                if sT.startswith(kSplineLidCorrectivePrefix):
                    sSplits = sT.split(kSplineLideCorrectiveSep)
                    if sSplits[-2] and sSplits[-1]:
                        sPart = 'botTop split'
                    elif sSplits[-2]:
                        sPart = 'bot'
                    elif sSplits[-1]:
                        sPart = 'top'
                    sLabel = '%s (auto generated name for %s from rig lid positions)' % (sT, sPart)

                qAction = qMenuAddNew.addAction(sLabel, _add)
                if tt == 1 and sT in sTargets:
                    qAction.setEnabled(False)
            qMenuAddNew.addSeparator()


        # add new custom:
        qAddNew = QtWidgets.QWidgetAction(self)
        qAddNewLayout = QtWidgets.QHBoxLayout()
        qAddNewLayout.addWidget(QtWidgets.QLabel('Add Custom:'))
        qNameLine = QtWidgets.QLineEdit()
        qAddNewLayout.addWidget(qNameLine)
        qAddNew.setDefaultWidget(makeWidgetFromLayout(qAddNewLayout))

        def _updateNewName():
            self._sNewName = qNameLine.text()

        qNameLine.textChanged.connect(_updateNewName)

        def _addNewMainTargetToTable(_qMenu=qMenu):
            if self._sNewName:
                sTarget = self._sNewName
                self.addNewMainTargetToTable(sTarget, bSelect=True)
                self._sNewName = ''
                _qMenu.close()

        qNameLine.editingFinished.connect(_addNewMainTargetToTable)

        qMenu.addAction(qAddNew)

        qMenu.addAction('Delete Key "%s"' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: self.deleteAnimation(iSelectedTargetRows, bJustCurrentKey=True))
        qMenu.addAction('Delete Animation "%s"' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: self.deleteAnimation(iSelectedTargetRows, bJustCurrentKey=False))

        if len(iSelectedTargetRows) >= 1:
            qMenu.addAction('Disable if Unchanged', lambda: self.disableIfUnchanged(iSelectedTargetRows, bCombo=False))


        if not library.isNone(meta):
            qMenu.addAction('Bake from Metahuman "%s"' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: self.bakeFromMetahuman(iSelectedTargetRows))


        def _selectCheckedTargets():
            iSelectMainRows = []
            for iRow,qTarget in enumerate(self.qMainTable.qAllCells):
                if not qTarget.bTurnOffOption or qTarget.qEnabledCheckBox.isChecked():
                    iSelectMainRows.append(iRow)

            prevSelBehavior = self.qMainTable.selectionMode()
            self.qMainTable.clearSelection()
            try:
                self.qMainTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
                for iMainRow in iSelectMainRows:
                    self.qMainTable.selectRow(iMainRow)
            except:
                raise
            finally:
                self.qMainTable.setSelectionMode(prevSelBehavior)
        qMenu.addAction('Select Checked Targets', _selectCheckedTargets)

        qMenu.addSeparator()
        qMenu.addAction('Reset deltas (FULL, no Vert Selection Support)', lambda: self.resetDeltas(iSelectedTargetRows, False))

        qMenu.addSeparator()
        def _addInbetween():
            for qTarget in qSelectedTargets:
                fInbetween = tools.addInbetween(self.sBlendShape, self.getMeshes(), qTarget.sTarget)[0]
                qTarget.addInbetween(fInbetween)
        qMenu.addAction('Add Inbetween', _addInbetween)


        def _interpolateInbetweens(bClosest):
            for qTarget in qSelectedTargets:
                tools.interpolateInbetweens(self.sBlendShape, qTarget.sTarget, bClosestInbetween=bClosest)

        def _deleteInbetweens(bClosest):
            for qTarget in qSelectedTargets:
                fInbetweens = tools.deleteInbetweens(self.sBlendShape, qTarget.sTarget, bClosestInbetween=bClosest)
                [qTarget.removeInbetween(fInbetween) for fInbetween in fInbetweens]


        qMenu.addAction('Interpolate All Inbetweens (Selected Geo)', lambda:_interpolateInbetweens(False))
        qMenu.addAction('Interpolate Closest Inbetween (Selected Geo)', lambda:_interpolateInbetweens(True))
        qMenu.addAction('Delete All Inbetweens', lambda:_deleteInbetweens(False))
        qMenu.addAction('Delete Closest Inbetween', lambda:_deleteInbetweens(True))

        qMenu.addSeparator()


        qInfo = qMenu.addAction('Info', None)
        qInfo.setEnabled(False)
        if len(qSelectedTargets):
            if qSelectedTargets[0].sInfo:
                qInfo.triggered.connect(lambda: cmds.confirmDialog(m=qSelectedTargets[0].sInfo))
                qInfo.setEnabled(True)

        qMenu.exec_(self.qMainTable.mapToGlobal(vPos))
        return qMenu



    def bakeFromMetahuman(self, iTargetRows=None, bCombo=False, bWarp=True):
        if library.isNone(iTargetRows):
            if bCombo:
                iTargetRows = range(len(self.qComboTable.qAllCells))
            else:
                iTargetRows = range(len(self.qMainTable.qAllCells))
        sNamespace = self.qMeta.getNamespace()
        sMesh = self.qMeta.getMesh()

        if bCombo:
            sTargets = [self.qComboTable.qAllCells[iRow].sTarget for iRow in iTargetRows]
        else:
            sTargets = [self.qMainTable.qAllCells[iRow].sTarget for iRow in iTargetRows]

        meta.bakeFromMeta(self.qBlendShape.getBlendShape(),
                          sNamespace,
                          sMesh,
                          sTargets, bWarp)




    def markingMenuCombo(self, vPos):
        qMenu = QNoEnterMenu()

        iSelectedTargetRows = self.getSelectedTargetRows(True)
        # sSelectedTargets = [self.qComboTable.qAllCells[iRow].sTarget for iRow in iSelectedTargetRows]

        qSelectedTargets = [self.qComboTable.qAllCells[iRow] for iRow in iSelectedTargetRows]
        sSelectedTargets = [self.qComboTable.qAllCells[iRow].sTarget for iRow in iSelectedTargetRows]

        self._addWeightsActionsToMenu(qMenu)

        qMenu.addAction('Paint weights for %s' % qSelectedTargets[0].sTarget, lambda: self.paintWeights(qSelectedTargets[0]))


        # qStripAxixMenu = qMenu.addMenu('strip axis for "%s"' % library.listToString(sSelectedTargets, iMaxCount=2))
        # qStripAxixMenu.addAction('X', lambda: tools.stripAxis(self.sBlendShape, sSelectedTargets, 0))
        # qStripAxixMenu.addAction('Y', lambda: tools.stripAxis(self.sBlendShape, sSelectedTargets, 1))
        # qStripAxixMenu.addAction('Z', lambda: tools.stripAxis(self.sBlendShape, sSelectedTargets, 2))

        sSelectedTargetNames = [qT.sTarget for qT in qSelectedTargets]
        qMenu.addAction('Bake Weights for %s' % library.listToString([qT.sTarget for qT in qSelectedTargets], iMaxCount=2), lambda: self.bakeWeights(qSelectedTargets, bCombo=True))
        qMenu.addAction('Make delta from Current for %s' % library.listToString(sSelectedTargetNames, iMaxCount=2), lambda: self.setShapeToCurrent(qSelectedTargets, bCombo=True))
        qMenu.addAction('Make delta from Current for %s (weight reset)' % library.listToString(sSelectedTargetNames, iMaxCount=2), lambda: self.setShapeToCurrent(qSelectedTargets, bCombo=True, bResetWeights=True))

        iSelectedComboTargetRows = self.getSelectedTargetRows(True)
        if len(iSelectedComboTargetRows) >= 1:
            qMenu.addSeparator()
            qMenu.addAction('Reset deltas for %s' % library.listToString(sSelectedTargetNames, iMaxCount=2), lambda: self.resetDeltas(iSelectedComboTargetRows, True))
            qMenu.addSeparator()
            iPossibleDeleteTargets = []
            sPossibleDeleteTargets = []
            for iT,sT in zip(iSelectedTargetRows, sSelectedTargets):
                if sT not in list(self.dPredefinedTargets.keys()):
                    iPossibleDeleteTargets.append(iT)
                    sPossibleDeleteTargets.append(sT)
            if iPossibleDeleteTargets:
                qMenu.addAction('Delete "%s"' % library.listToString(sPossibleDeleteTargets, iMaxCount=2), lambda: self.deleteTargets(iPossibleDeleteTargets, True))

            # qMenu.addAction('Update from Rig for "%s" (All)' % library.listToString(sSelectedTargets, iMaxCount=2),
            #                 lambda: self.updateShapesFromRelations(sSelectedTargets, bOnlySelectedIfSelection=False))
            # qMenu.addAction('Update from Rig for "%s" (Scene Selection)' % library.listToString(sSelectedTargets, iMaxCount=2),
            #                 lambda: self.updateShapesFromRelations(sSelectedTargets, bOnlySelectedIfSelection=True))



        def _selectComboMainTargets():
            iSelectMainRows = []
            for iRow in iSelectedComboTargetRows:
                iSelectMainRows += self.qComboTable.qAllCells[iRow].iComboMainTargetRows
            iSelectMainRows = list(set(iSelectMainRows))
            qSelectionModel = self.qMainTable.selectionModel()
            qSelectionModel.clearSelection()

            prevSelBehavior = self.qMainTable.selectionMode()
            try:
                self.qMainTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
                for iMainRow in iSelectMainRows:
                    self.qMainTable.selectRow(iMainRow)
            except:
                raise
            finally:
                self.qMainTable.setSelectionMode(prevSelBehavior)


        def _isolateComboMainTargets():
            iSelectMainRows = []
            for iRow in iSelectedComboTargetRows:
                iSelectMainRows += self.qComboTable.qAllCells[iRow].iComboMainTargetRows
            iSelectMainRows = list(set(iSelectMainRows))
            print('iSelectMainRows: ', iSelectMainRows)

            self.qIsolateMain.blockSignals(True)
            self.qIsolateMain.setChecked(True)
            self.qIsolateMain.blockSignals(False)

            for qCell in self.qMainTable.qAllCells:
                qCell.bIsolated = False

            for iRow in iSelectMainRows:
                qCell = self.qMainTable.qAllCells[iRow]
                qCell.bIsolated = True

            self.updateHidden(False)

        qMenu.addSeparator()
        qMenu.addAction('Select Main Targets', _selectComboMainTargets)
        qMenu.addAction('Isolate Main Targets', _isolateComboMainTargets)
        qMenu.addSeparator()

        qWithCountMenu = qMenu.addMenu('Select Combos with count..')
        sAllComboTargets = [self.qComboTable.qAllCells[iRow].sTarget for iRow in range(len(self.qComboTable.qAllCells))]
        for iCount in range(2,7):
            sCountCombos = [sCombo for sCombo in sAllComboTargets if sCombo.count('_')+1 == iCount]
            def _comboCountSelect(sCountCombos=sCountCombos):
                iSelectRows = [sAllComboTargets.index(sCombo) for sCombo in sCountCombos]
                prevSelBehavior = self.qComboTable.selectionMode()
                try:
                    self.qComboTable.setSelectionMode(QtWidgets.QAbstractItemView.MultiSelection)
                    self.qComboTable.clearSelection()
                    for iComboRow in iSelectRows:
                        self.qComboTable.selectRow(iComboRow)
                except:
                    raise
                finally:
                    self.qComboTable.setSelectionMode(prevSelBehavior)
            qWithCountAction = qWithCountMenu.addAction('%d' % iCount, _comboCountSelect)
            if not sCountCombos:
                qWithCountAction.setEnabled(False)



        if len(iSelectedComboTargetRows) == 1:
            qMenu.addAction('Set Percentages', lambda: self.setPercentages(iSelectedTargetRows[0]))

        if len(iSelectedComboTargetRows) >= 1:
            qMenu.addAction('Disable if Unchanged', lambda: self.disableIfUnchanged(iSelectedTargetRows, bCombo=True))
            qMenu.addAction('Bake %d selected Combo Targets' % len(sSelectedTargets), lambda: tools.bakeTargets(self.sBlendShape, sMainMesh=self.getMainMesh(), sFilterTargets=sSelectedTargets))

        if not library.isNone(meta):
            qMenu.addAction('Bake from Metahuman "%s"' % library.listToString(sSelectedTargets, iMaxCount=2), lambda: self.bakeFromMetahuman(iSelectedTargetRows, bCombo=True))



        qMenu.addSeparator()
        def _addInbetween():
            for qTarget in qSelectedTargets:
                fInbetween = tools.addInbetween(self.sBlendShape, self.getMeshes(), qTarget.sTarget)[0]
                qTarget.addInbetween(fInbetween)
        qMenu.addAction('Add Inbetween', _addInbetween)


        def _interpolateInbetweens(bClosest):
            for qTarget in qSelectedTargets:
                tools.interpolateInbetweens(self.sBlendShape, qTarget.sTarget, bClosestInbetween=bClosest, bIsCombo=True)

        def _deleteInbetweens(bClosest):
            for qTarget in qSelectedTargets:
                fInbetweens = tools.deleteInbetweens(self.sBlendShape, qTarget.sTarget, bClosestInbetween=bClosest)
                [qTarget.removeInbetween(fInbetween) for fInbetween in fInbetweens]


        qMenu.addAction('Interpolate All Inbetweens (Selected Geo)', lambda:_interpolateInbetweens(False))
        qMenu.addAction('Interpolate Closest Inbetween (Selected Geo)', lambda:_interpolateInbetweens(True))
        qMenu.addAction('Delete All Inbetweens', lambda:_deleteInbetweens(False))
        qMenu.addAction('Delete Closest Inbetween', lambda:_deleteInbetweens(True))



        qMenu.exec_(self.qComboTable.mapToGlobal(vPos))
        return qMenu


    def disableIfUnchanged(self, iTargetRows, bCombo=False):

        library.reload2(tools)
        qTable = self.qComboTable if bCombo else self.qMainTable

        for i,iRow in enumerate(iTargetRows):
            qCell = qTable.qAllCells[iRow]
            sTarget = qCell.sTarget
            if not library.isNone(qCell.qEnabledCheckBox):
                bMoving = tools.checkIfNotEmpty(self.qBlendShape.getBlendShape(), sTarget, fThreshhold=0.005)
                qCell.qEnabledCheckBox.setChecked(bMoving)


    def setPercentages(self, iComboTargetRow):
        qTarget = self.qComboTable.qAllCells[iComboTargetRow]
        iTargetIndex = qTarget.iTargetIndex
        sTarget = qTarget.sTarget
        sMainTargets = list(tools.getPercsFromComboName(sTarget).keys())
        def _changeMainTargetPercentages(dPercs):
            sTargetsFull = [('%s%02d' % (sT,dPercs[sT]) if dPercs[sT] < 100 else sT) for sT in sMainTargets]
            sNewName = '_'.join(sTargetsFull)
            cmds.aliasAttr(sNewName, '%s.w[%d]' % (self.sBlendShape, iTargetIndex))
            qTarget.sTarget = sNewName
            qTarget.qTargetName.setText(sNewName)
            getComboTargetConditionPlug('%s.%s' % (self.sBlendShape, sNewName), bForceRecreate=True)

        self.qPercentagesUI = PercentagesUI(sTarget, _changeMainTargetPercentages)
        self.qPercentagesUI.show()



    def getMeshes(self, bSelected=True, bReturnItems=False, bFullPath=True):

        if bSelected:
            qItems = [qI for qI in self.qMeshesTable.selectedItems() if qI.column() == 0]
        if not bSelected or not qItems:
            iRowCount = self.qMeshesTable.rowCount()
            qItems = [self.qMeshesTable.item(iRow, 0) for iRow in range(iRowCount)]

        if bReturnItems:
            return qItems
        else:
            sBlendShapeMeshes = library.getBlendShapeMeshTransforms(self.sBlendShape, bFullPath=True)

            dMeshes = {}
            for qI in qItems:
                sMesh = qI.text()

                if bFullPath:
                    for sM in sBlendShapeMeshes:
                        if sM.endswith(sMesh):
                            sMesh = sM
                            break

                iIndex = qI.data(QtCore.Qt.UserRole)['iGeometryIndex']
                dMeshes[sMesh] = iIndex

            return dMeshes


    def markingMenuMeshes(self, vPos):
        qMenu = QtWidgets.QMenu()

        iSelectedMainTargetRows = self.getSelectedTargetRows(False)
        iSelectedComboTargetRows = self.getSelectedTargetRows(True)
        qSelectedMeshes = self.getMeshes(bSelected=True, bReturnItems=True)
        sSelectedMeshes = [qM.text() for qM in qSelectedMeshes]
        qAllMeshes = self.getMeshes(bSelected=False, bReturnItems=True)
        sSelectedMeshes = [qM.text() for qM in qSelectedMeshes]
        iTargetCount = len(iSelectedMainTargetRows) + len(iSelectedComboTargetRows)


        qMirror = qMenu.addMenu('Mirror')
        qSetMirrorTable = qMenu.addMenu('Set Mirror Table')
        if qSelectedMeshes:
            qMenu.addAction('Select in Scene', lambda: cmds.select([qS.text() for qS in qSelectedMeshes]))

            def _setMirrorTableE():
                self.setMirrorTableMiddleMeshes(qSelectedMeshes, 'E')
            def _setMirrorTableV():
                self.setMirrorTableMiddleMeshes(qSelectedMeshes, 'V')
            def _setMirrorTableF():
                self.setMirrorTableMiddleMeshes(qSelectedMeshes, 'F')
            qSetMirrorTable.addAction('middle mesh, edgeflow', _setMirrorTableE)
            qSetMirrorTable.addAction('middle mesh, vertex positions', _setMirrorTableV)
            qSetMirrorTable.addAction('middle mesh, face points', _setMirrorTableF)

            def _setMirrorTableSideMeshesI():
                self.setMirrorTableSideMeshes(qSelectedMeshes, sType='I')
            def _setMirrorTableSideMeshesV():
                self.setMirrorTableSideMeshes(qSelectedMeshes, sType='V')
            def _setMirrorTableSideMeshesF():
                self.setMirrorTableSideMeshes(qSelectedMeshes, sType='F')
            qSetMirrorTable.addAction('side meshes, ids', _setMirrorTableSideMeshesI)
            qSetMirrorTable.addAction('side meshes, vertex positions', _setMirrorTableSideMeshesV)
            qSetMirrorTable.addAction('side meshes, face points', _setMirrorTableSideMeshesF)

        sTargets = [self.qMainTable.qAllCells[iRow].sTarget for iRow in iSelectedMainTargetRows] + \
                   [self.qComboTable.qAllCells[iRow].sTarget for iRow in iSelectedComboTargetRows]


        # mirror
        def _mirrorToSelectedTargets(iDirection, _qSelectedMeshes=qSelectedMeshes):
            print ('iDirection: ', iDirection)
            sMeshes = [qM.text() for qM in _qSelectedMeshes]

            self.bGlobalScriptJobDisabled = True
            print ('sMeshes: ', sMeshes)
            try:
                self.qMeshesTable.blockSignals(True)
                library.reload2(tools)
                tools.mirrorTargets(self.sBlendShape, sTargets, sMeshes, iDirection)
            except:
                raise
            finally:
                self.qMeshesTable.blockSignals(False)
                self.bGlobalScriptJobDisabled = False

        def _mirrorCurrentTarget(iDirection, _qSelectedMeshes=qSelectedMeshes):
            iSculptTarget = cmds.getAttr(self.sSculptTargetAttr)
            # if iSculptTarget != -1:
            #     cmds.confirmDialog(m=f'For Mirroring, all EDIT buttons must be turned off ({iSculptTarget})')
            #     return

            sMeshes = [qM.text() for qM in _qSelectedMeshes]

            self.bGlobalScriptJobDisabled = True
            # print ('sMeshes: ', sMeshes)
            try:
                self.qMeshesTable.blockSignals(True)
                library.reload2(tools)
                tools.mirrorTargets(self.sBlendShape, None, sMeshes, iDirection)
            except:
                raise
            finally:
                self.qMeshesTable.blockSignals(False)
                self.bGlobalScriptJobDisabled = False


        # mirror weights
        def _mirrorToSelectedTargetsWeights(iDirection, _qSelectedMeshes=qSelectedMeshes, bBase=False):
            sMeshes = [qM.text() for qM in _qSelectedMeshes]
            self.bGlobalScriptJobDisabled = True
            try:
                self.qMeshesTable.blockSignals(True)
                library.reload2(tools)
                tools.mirrorWeights(self.sBlendShape, None if bBase else sTargets, sMeshes, iDirection)
            except:
                raise
            finally:
                self.qMeshesTable.blockSignals(False)
                self.bGlobalScriptJobDisabled = False


        sSceneSelectedMeshes = [sT for sT in cmds.ls(sl=True, et='transform') if cmds.listRelatives(sT, typ='mesh', c=True)]
        sSceneSelectedCurves = [sT for sT in cmds.ls(sl=True, et='transform') if cmds.listRelatives(sT, typ='nurbsCurve', c=True)]

        # if len(sSceneSelectedMeshes) == 1:
        #     qMenu.addAction('Change selected Targets to new Sculpt "%s" (%d Targets)' % (sSceneSelectedMeshes[0], iTargetCount), lambda: _setSelectedTargetsTo(sSceneSelectedMeshes[0]))


        qMirror.addSeparator()
        qTargetActions = []


        if cmds.getAttr(self.sSculptTargetAttr) == -1:
            qTargetActions.append(qMirror.addAction('Mirror %d selected targets (left->right)' % len(sTargets), lambda: _mirrorToSelectedTargets(0)))
            qTargetActions.append(qMirror.addAction('Mirror %d selected targets (right->left)' % len(sTargets), lambda: _mirrorToSelectedTargets(1)))
            qTargetActions.append(qMirror.addAction('Mirror %d selected targets (flip)' % len(sTargets), lambda: _mirrorToSelectedTargets(2)))
        else: # EDIT button clicked
            qMirror.addAction('Mirror currently Edited target (left->right)', lambda: _mirrorCurrentTarget(0))
            qMirror.addAction('Mirror currently Edited target (right->left)', lambda: _mirrorCurrentTarget(1))
            qMirror.addAction('Mirror currently Edited target (flip)', lambda: _mirrorCurrentTarget(2))

        # qMirror.addSeparator()
        # qTargetActions.append(qMirror.addAction('Mirror Weights %d selected targets (left->right)' % len(sTargets), lambda: _mirrorToSelectedTargetsWeights(0)))
        # qTargetActions.append(qMirror.addAction('Mirror Weights %d selected targets (right->left)' % len(sTargets), lambda: _mirrorToSelectedTargetsWeights(1)))
        # qTargetActions.append(qMirror.addAction('Mirror Weights %d selected targets (flip)' % len(sTargets), lambda: _mirrorToSelectedTargetsWeights(2)))
        # qMirror.addSeparator()
        # qMirror.addAction('Mirror Base Weights (left->right)', lambda: _mirrorToSelectedTargetsWeights(0, bBase=True))
        # qMirror.addAction('Mirror Base Weights (right->left)', lambda: _mirrorToSelectedTargetsWeights(1, bBase=True))
        # qMirror.addAction('Mirror Base Weights (flip)', lambda: _mirrorToSelectedTargetsWeights(2, bBase=True))
        #
        qMenu.addSeparator()


        if not iSelectedMainTargetRows and not iSelectedComboTargetRows:
            [qA.setEnabled(False) for qA in qTargetActions]


        if len(qSelectedMeshes) == 1:
            def _setMainMesh(qMesh=qSelectedMeshes[0]):
                utils.addStringAttr(self.sBlendShape, kMainMeshAttr, qMesh.text(), bLock=True)
                for qM in qAllMeshes:
                    qM.setFont(QtGui.QFont())
                qMesh.setFont(qFontBold)

            qMenu.addAction('set "%s" as new Main Mesh' % qSelectedMeshes[0].text(), _setMainMesh)



        def _sDisableMeshes():
            library.addToListStringAttr(self.sBlendShape, kDisabledMeshesAttr, sSelectedMeshes)
            for qM in qSelectedMeshes:
                qM.setFont(qFontItalic)
        qMenu.addAction('disable %s' % library.listToString(sSelectedMeshes, iMaxCount=3), _sDisableMeshes)
        def _sEnableMeshes():
            library.removeFromListStringAttr(self.sBlendShape, kDisabledMeshesAttr, sSelectedMeshes)
            for qM in qSelectedMeshes:
                qM.setFont(QtGui.QFont())
        qMenu.addAction('enable %s' % library.listToString(sSelectedMeshes, iMaxCount=3), _sEnableMeshes())


        # reset deltas
        def _resetDeltas():
            self.resetDeltas(iSelectedMainTargetRows, False, sMeshes=sSelectedMeshes)
            self.resetDeltas(iSelectedComboTargetRows, True, sMeshes=sSelectedMeshes)

        qResetDeltaSelectedTargets = qMenu.addAction('Reset deltas of %d Targets' % iTargetCount, _resetDeltas)
        if not len(iSelectedMainTargetRows) and not (iSelectedComboTargetRows):
            qResetDeltaSelectedTargets.setEnabled(False)

        # disconnect
        def _disconnect():
            dMeshes = self.getMeshes()
            cmds.blendShape(self.sBlendShape, e=True, geometry=list(dMeshes.keys()), remove=True)
            print ('calling refreshMeshes from _disconnect')
            self.refreshMeshes()

        if len(qSelectedMeshes) >= 1:
            qMenu.addAction('Remove from BlendShape', _disconnect)




        def _modelChange():
            library.reload2(tools)
            tools.modelChange(self.sBlendShape, sSelectedMeshes[0], sSceneSelectedMeshes[0])

        if sSceneSelectedMeshes:
            qMenu.addAction('Model Change from "%s" to "%s" to all targets' % (sSceneSelectedMeshes[0], sSelectedMeshes[0]), _modelChange)


        qNewMeshes = qMenu.addAction('Add new Meshes (scene selection)', self.addMeshesToBlendShapeAndTable)
        if not cmds.ls(sl=True):
            qNewMeshes.setEnabled(False)


        qMenu.exec_(self.qMeshesTable.mapToGlobal(vPos))
        return qMenu


    def sculptTargetChange(self):
        iTarget = int(cmds.getAttr(self.sSculptTargetAttr))
        if iTarget == -1:
            cmds.sculptTarget(self.sBlendShape, e=True, t=-1)

        else:

            dTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=False)
            sTarget = dTargets[iTarget]

            cmds.undoInfo(swf=False)

            fInbetweens = blendShapes.getInbetweenFloats(self.sBlendShape, iTarget)
            if not fInbetweens:
                cmds.sculptTarget(self.sBlendShape, e=True, t=iTarget)
                fInbetweenWeight = 1.0
            else:
                fCurrentWeight = cmds.getAttr('%s.%s' % (self.sBlendShape, sTarget))
                fInbetweens.append(1.0)
                aDiffs = abs(np.array(fInbetweens, dtype='float64') - fCurrentWeight)
                iInbetween = np.argmin(aDiffs)
                print ('fInbetweens[iInbetween]: ', fInbetweens[iInbetween])
                cmds.sculptTarget(self.sBlendShape, e=True, t=iTarget, inbetweenWeight=fInbetweens[iInbetween])
                fInbetweenWeight = fInbetweens[iInbetween]

            cmds.undoInfo(swf=True)

        if self.bUpdateNextSculptChange:
            for qCell in self.qMainTable.qAllCells + self.qComboTable.qAllCells:
                if qCell != self:
                    qCell.qEditButton.blockSignals(True)
                    if qCell.iTargetIndex == iTarget:
                        qCell.qEditButton.setChecked(True)
                        if fInbetweenWeight == 1.0:
                            qCell.qEditButton.setText('EDIT')
                        else:
                            qCell.qEditButton.setText('E %0.3f' % fInbetweenWeight)
                    else:
                        qCell.qEditButton.setChecked(False)
                        qCell.qEditButton.setText('EDIT')
                    qCell.qEditButton.blockSignals(False)

        self.bUpdateNextSculptChange = True


    def clearAll(self):
        self.clearTableScriptJobs(False)
        self.qMainTable.clear()
        self.clearTableScriptJobs(True)
        self.qComboTable.clear()
        self.qMeshesTable.clear()


    def refreshBlendShapes(self, sBlendShape=None):
        print ('refresh BlendShape')
        sSelBefore = cmds.ls(sl=True)
        if sBlendShape != None:
            self.sBlendShape = sBlendShape

        try:
            self.updateFileLists()
            cmds.sculptTarget(self.sBlendShape, e=True, t=-1)
            self.sSculptTargetAttr = library.addAttr(self.sBlendShape, ln='iSculptTarget', defaultValue=-1, bReturnIfExists=True)

            if self.iSculptTargetScriptJob != None:
                cmds.scriptJob(kill = self.iSculptTargetScriptJob)

            self.iSculptTargetScriptJob = cmds.scriptJob(attributeChange=[self.sSculptTargetAttr, self.sculptTargetChange])

            dMayaCombinationShapes = tools.getMayaCombinationShape(self.sBlendShape)
            if dMayaCombinationShapes:
                if cmds.confirmDialog(m='There are some combo shapes created with Maya Shape Editor. Convert them?\n%s' % library.listToString(list(dMayaCombinationShapes.keys()), iMaxCount=5),
                                   button=['yes', 'no']) == 'yes':
                    dTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True)

                    for sComboTarget, sMainTargets in list(dMayaCombinationShapes.items()):
                        iTargetIndex = dTargets[sComboTarget]
                        sMainTargets.sort()
                        sNewComboTargetName = '_'.join(sMainTargets)
                        if cmds.objExists('%s.%s' % (self.sBlendShape, sNewComboTargetName)):
                            raise Exception('Combo Target %s already exists in the blendShape' % sNewComboTargetName)
                        cmds.aliasAttr(sNewComboTargetName, '%s.%s' % (self.sBlendShape, 'w[%d]' % iTargetIndex))

            self.qIsolateMain.setChecked(False)
            self.qIsolateCombo.setChecked(False)
            self.qMainFilterWidget.clear()
            self.qComboFilterWidget.clear()

            self.dTargetListFiles = getListFileDict()
            sTargetListFiles = list(self.dTargetListFiles.keys())
            sCurrentListFile = library.getStringAttr(self.sBlendShape, kCurrentListFileAttr, sTargetListFiles[0], bCreateIfNotExists=True)

            self.qFileLists.blockSignals(True)

            try:
                sListsFromComboBox = [self.qFileLists.itemText(i) for i in range(self.qFileLists.count())]

                if sCurrentListFile in sListsFromComboBox:
                    print ('%s -> %s' % (sCurrentListFile, sListsFromComboBox))
                    self.qFileLists.setCurrentIndex(sListsFromComboBox.index(sCurrentListFile))
                    self.dPredefinedTargets = getPredefinedListFromFile(self.dTargetListFiles[sCurrentListFile])
                    utils.addStringAttr(self.sBlendShape, '%s_%s' % (kCurrentListFileFullContentAttr, sCurrentListFile), str(self.dPredefinedTargets), bLock=True)
                else:
                    sLocalCurrentListFile = 'LOCAL: %s' % sCurrentListFile
                    print ('%s -> %s' % (sLocalCurrentListFile, sListsFromComboBox))
                    self.qFileLists.setCurrentIndex(sListsFromComboBox.index(sLocalCurrentListFile))
                    sCurrentListFullContentAttr = '%s.%s_%s' % (self.sBlendShape, kCurrentListFileFullContentAttr, sCurrentListFile)
                    self.dPredefinedTargets = eval(cmds.getAttr(sCurrentListFullContentAttr))

            except:
                raise
            finally:
                self.qFileLists.blockSignals(False)


            sDeleteInputTargets = cmds.listConnections('%s.inputTarget' % self.sBlendShape, s=True, d=True, t='mesh')
            if sDeleteInputTargets:
                if cmds.confirmDialog(m='There are meshes connected as Targets. For the tool to work, those need to be deleted. Delete them?', button=['yes', 'no']) == 'yes':
                    cmds.delete(sDeleteInputTargets)
                else:
                    raise Exception('User no want delete target. So the tool no work')

            sWrongCombos = []
            dTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True)
            sTargetsSet = set(dTargets.keys()).union(set(self.dPredefinedTargets.keys()))
            for sTarget in list(dTargets.keys()):
                if '_' in sTarget:
                    sMainTargets = [library.getTargetPercNumber(sMainT)[0] for sMainT in sTarget.split('_')]
                    sMissingMainTargets = set(sMainTargets) - sTargetsSet
                    if sMissingMainTargets:
                        sWrongCombos.append(sTarget)

            if sWrongCombos:
                if cmds.confirmDialog(m='Some combos have wrong names: %s \nFix them?' % library.listToString(sWrongCombos, iMaxCount=10), button=['yes', 'no']) == 'yes':
                    for sTarget in sWrongCombos:
                        sTargetName = library.getUniqueBlendShapeTargetName(self.sBlendShape, sTarget.replace('_', ''))
                        cmds.aliasAttr(sTargetName, '%s.w[%d]' % (self.sBlendShape, dTargets[sTarget]))
                else:
                    self.qBlendShape.clearBlendShape()
                    raise Exception('User no want fix names. So the tool no work')



            self.clearAll()

            dExistingTargets = library.getTargetsDictFromBlendShape(self.sBlendShape, bPerTargetNames=True)
            sExistingTargets = list(dExistingTargets.keys())

            sExistingMainTargets = [sT for sT in sExistingTargets if '_' not in sT]
            sExistingComboTargets = [sT for sT in sExistingTargets if '_' in sT]

            sPredefinedMainTargets = [sT for sT in list(self.dPredefinedTargets.keys()) if '_' not in sT]
            sPredefinedComboTargets = [sT for sT in list(self.dPredefinedTargets.keys()) if '_' in sT]


            # main targets
            sExtraMainTargets = set(sExistingMainTargets) - set(sPredefinedMainTargets)
            sOrderedMainTargets = sPredefinedMainTargets + sorted(sExtraMainTargets)
            for iRow, sTarget in enumerate(sOrderedMainTargets):
                if sTarget in sExistingTargets:
                    self.addExistingMainTargetToTable(sTarget, dExistingTargets[sTarget])
                else:
                    self.addNewMainTargetToTable(sTarget)

            # combo targets
            sExtraComboTargets = set(sExistingComboTargets) - set(sPredefinedComboTargets)
            sOrderedComboTargets = sPredefinedComboTargets + sorted(sExtraComboTargets)
            for iRow, sTarget in enumerate(sOrderedComboTargets):
                if sTarget in sExistingTargets:
                    self.addExistingComboTargetToTable(sTarget, dExistingTargets[sTarget])
                else:
                    self.addNewComboTargetToTable(sTarget)

            print('calling refreshMeshes from refreshBlendShapes')
            self.refreshMeshes()


            #enabledAttr update
            sEnabledInfoAttr = '%s.%s' % (self.sBlendShape, kEnabledInfoAttr)
            if cmds.objExists(sEnabledInfoAttr):
                dEnabled = eval(cmds.getAttr(sEnabledInfoAttr))
                for qCell in self.qMainTable.qAllCells:
                    if not qCell.bTurnOffOption and qCell.sTarget in dEnabled:
                        dEnabled[qCell.sTarget] = True
                cmds.setAttr(sEnabledInfoAttr, lock=False)
                cmds.setAttr(sEnabledInfoAttr, str(dEnabled), type='string')
                cmds.setAttr(sEnabledInfoAttr, lock=True)

            self.enabledUpdate()

            cmds.select(sSelBefore)

            self.evaluateAllSliderRanges()


            dSkinClusterMeshes = {}
            for sM in self.getMeshes(bSelected=False):
                sSkinClusters = library.listAllDeformers(sM, sFilterTypes=['skinCluster'])
                if sSkinClusters:
                    dSkinClusterMeshes[sM] = sSkinClusters[0]

            # scan stuff
            self.qCurvesTable.clear()

            sScanToMeshAttr = '%s.sScanToMesh' % self.sBlendShape
            if cmds.objExists(sScanToMeshAttr):
                sScanToMesh = cmds.getAttr(sScanToMeshAttr)
                self.qScanToMesh.setText(sScanToMesh)
            else:
                self.qScanToMesh.setText('')

            if cmds.objExists('_scanCurves'):
                sTransforms = cmds.listRelatives('_scanCurves', c=True, typ='transform') or []
                sCurrentCurves = [sT for sT in sTransforms if cmds.objExists('%s.bScanCurve' % sT)]
                for sCurve in sCurrentCurves:
                    self.addNewCurve(sCurve)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise



    def refreshMeshes(self):
        print ('refreshMeshes....')
        self.qMeshesTable.blockSignals(True)
        try:
            sMeshesFull = library.getBlendShapeMeshTransforms(self.sBlendShape, bFullPath=True)
            sMeshes = [sM.split('|')[-1] for sM in sMeshesFull]
            # sMeshes = [cmds.listRelatives(sS, p=True)[0] for sS in cmds.blendShape(self.sBlendShape, q=True, g=True)]
            [utils.addStringAttr(sFullM, 'sMeshName', sM, bLock=True) for sM,sFullM in zip(sMeshes, sMeshesFull)]

            sMainMeshAttr = '%s.%s' % (self.sBlendShape, kMainMeshAttr)
            if cmds.objExists(sMainMeshAttr):
                sMainMesh = cmds.getAttr(sMainMeshAttr)
                if sMainMesh not in sMeshes:
                    sMainMesh = sMeshes[0]
            else:
                sMainMesh = sMeshes[0]

            utils.addStringAttr(self.sBlendShape, kMainMeshAttr, sMainMesh, bLock=True)


            sDisabledMeshesAttr = '%s.%s' % (self.sBlendShape, kDisabledMeshesAttr)
            if cmds.objExists(sDisabledMeshesAttr):
                sDisabledMeshes = eval(cmds.getAttr(sDisabledMeshesAttr))
            else:
                sDisabledMeshes = []


            # dGeometryIndices = getGeometryIndices(self.sBlendShape)
            self.qMeshesTable.clear()
            self.qMeshesTable.setHorizontalHeaderLabels(['meshes', 'mirror'])
            self.qMeshesTable.setRowCount(0)
            self.addMeshesToTable(sMeshes, sDisabledMeshes=sDisabledMeshes, sMainMesh=sMainMesh)

            self.qScanFromCombo.clear()
            for sM in sMeshes:
                self.qScanFromCombo.addItem(sM)


            # block tweak nodes (for when user accidently moves verts without Edit button clicked:
            self.killBlockTweakScriptJobs()
            self.bTweakScriptJobsActive = True
            sBlockTweakNodes = []
            for sM in sMeshes:
                sTweakNodes = [sN for sN in cmds.listHistory(sM) if cmds.objectType(sN) == 'tweak']
                if not sTweakNodes:
                    cmds.deformer(sM, type='tweak')
                    sTweakNodes = [sN for sN in cmds.listHistory(sM) if cmds.objectType(sN) == 'tweak']

                sBlockTweakNodes += sTweakNodes

            for sTweak in set(sBlockTweakNodes):
                def _block(_sTweak=sTweak):
                    if self.bTweakScriptJobsActive:
                        cmds.warning('resetting tweak node %s...' % _sTweak)
                        self.bTweakScriptJobsActive = False
                        ffChanges = cmds.getAttr('%s.vlist[0].vertex[*]' % _sTweak)
                        iCount = len(ffChanges)
                        cmds.setAttr('%s.vlist[0].vertex[*]' % _sTweak, *([0] * iCount * 3))
                    else:
                        self.bTweakScriptJobsActive = True

                iScriptJob = cmds.scriptJob(attributeChange=['%s.vlist[0].vertex' % sTweak, _block])
                self.iTweakBlockScriptJobs.append(iScriptJob)

        except:
            raise
        finally:
            self.qMeshesTable.blockSignals(False)



    def killBlockTweakScriptJobs(self):
        for iScriptJob in self.iTweakBlockScriptJobs:
            cmds.scriptJob(kill=iScriptJob)
        self.iTweakBlockScriptJobs = []



    def clearTableScriptJobs(self, bCombo):
        if bCombo:
            for qCell in self.qComboTable.qAllCells:
                qCell.killCellScriptJobs()
            self.qComboTable.setRowCount(0)
            del self.qComboTable.qAllCells[:]
        else:
            for qCell in self.qMainTable.qAllCells:
                qCell.killCellScriptJobs()
            self.qMainTable.setRowCount(0)
            del self.qMainTable.qAllCells[:]


    def closeEvent(self, event):
        print('close....')
        self.clearTableScriptJobs(False)
        self.clearTableScriptJobs(True)
        self.killBlockTweakScriptJobs()
        cmds.scriptJob(kill=self.iSelectionScriptJob)
        cmds.scriptJob(kill=self.iUndoScriptJob)
        cmds.scriptJob(kill=self.iTimeChangedScriptJob)
        if self.iSculptTargetScriptJob != None:
            cmds.scriptJob(kill=self.iSculptTargetScriptJob)
        QtWidgets.QDialog.closeEvent(self, event)


    def negateShapes(self):
        library.reload2(tools)
        dRelations = {}
        dRelations['upperDown'] = 'upperUp'
        dRelations['lowerUp'] = 'lowerDown'
        dRelations['browOut'] = 'browIn'
        dRelations['outerBrowDown'] = 'outerBrowUp'
        tools.negateShapes(self.qBlendShape.getBlendShape(), dRelations)


    def alignCorners(self):
        library.reload2(tools)

        iCornerPoint = int(self.qCornerVertex.getObject())
        iCornerPoint50 = int(self.qCornerVertex50.getObject())

        xxData =  [([None, 'cornerUp', 'cornerDown'], 0,  tools.adjustCornerMapsOptions.firstChangesOthers, iCornerPoint),
                   ([None, 'cornerIn', 'cornerOut'], 1, tools.adjustCornerMapsOptions.firstChangesOthers, iCornerPoint50),
                   (['cornerOut', 'cornerOut_cornerUp', 'cornerOut_cornerDown'], 0, tools.adjustCornerMapsOptions.highest, iCornerPoint),
                   (['cornerUp_cornerIn', 'cornerUp', 'cornerOut_cornerUp'], 1, tools.adjustCornerMapsOptions.highest, iCornerPoint),
                   (['cornerDown_cornerIn', 'cornerDown', 'cornerOut_cornerDown'], 1, tools.adjustCornerMapsOptions.highest, iCornerPoint)]

        sMesh = cmds.getAttr('%s.%s' % (self.sBlendShape, kMainMeshAttr))
        sWeightsCluster = self.qCornerMask.getObject()
        aMask = np.array(cmds.getAttr('%s.weightList[0].weights[0:%d]' % (sWeightsCluster, cmds.polyEvaluate(sMesh, vertex=True)-1)), dtype='float64')
        tools.alignTargets(self.sBlendShape, sMesh, xxData, aMask)


class QEditLabel(QtWidgets.QWidget):
    userChangedText = QtCore.Signal(object)
    def __init__(self, sText, bEditable, qTableWidget, sBlendShape):
        self.qTableWidget = qTableWidget
        QtWidgets.QWidget.__init__(self)
        qLayout = QtWidgets.QHBoxLayout()
        self.setLayout(qLayout)

        if bEditable:
            self.qLabel = QDoubleClickLabel(sText)
            self.qLine = QFocusCheckLineEdit()
            self.qLine.setHidden(True)
            qLayout.addWidget(self.qLine)
            self.qLabel.clickedTwice.connect(self.showLineEdit)
            self.qLine.finishedSettingText.connect(self.showLabel)
            self.qTableWidget.itemSelectionChanged.connect(self.showLabel)
            self.sBlendShape = sBlendShape
        else:
            self.qLabel = QtWidgets.QLabel(sText)
            self.qLine = None

        qLayout.addWidget(self.qLabel)


    def setFont(self, qFont):
        self.qLabel.setFont(qFont)


    def showLineEdit(self):
        self.qLabel.setHidden(True)
        self.qLine.setText(self.qLabel.text())
        self.qLine.setHidden(False)
        self.qLine.setSelection(0, len(self.qLine.text()))
        self.qLine.setFocus()


    def showLabel(self):
        if not self.qLine.isHidden():
            self.qLine.setHidden(True)
            sText = self.qLine.text()
            self.qLabel.setHidden(False)
            if sText != self.qLabel.text():
                self.qLabel.setText(sText)
                self.userChangedText.emit(sText)



    def setText(self, sText):
        if self.qLine != None:
            self.qLine.setText(sText)
        self.qLabel.setText(sText)




class QDoubleClickLabel(QtWidgets.QLabel):
    clickedTwice = QtCore.Signal()
    def mouseDoubleClickEvent(self, *args, **kwargs):
        self.clickedTwice.emit()


class QFocusCheckLineEdit(QtWidgets.QLineEdit):
    finishedSettingText = QtCore.Signal()
    def focusOutEvent(self, *args, **kwargs):
        self.finishedSettingText.emit()
    def keyPressEvent(self, event):
        key = event.key()
        if key == QtCore.Qt.Key_Enter or key == 16777220:
            self.finishedSettingText.emit()
        else:
            QtWidgets.QLineEdit.keyPressEvent(self, event)


class QNoEnterMenu(QtWidgets.QMenu):
    def keyPressEvent(self, event):
        key = event.key()

        if key == QtCore.Qt.Key_Enter:
            pass
        else:
            pass
            # super(QtWidgets.QTableWidget, self).keyPressEvent(event)



class QNoWheelSlider(QtWidgets.QSlider):
    def __init__(self, parent=None):
        QtWidgets.QSlider.__init__(self, QtCore.Qt.Horizontal, parent=parent)
        self.parent = parent
        self.fInbetweens = [] # [0.25, 0.5, 0.75]

    def wheelEvent(self, *args, **kwargs):
        return self.parent.wheelEvent(*args, **kwargs)

    def paintEvent(self, event):
        QtWidgets.QSlider.paintEvent(self, event)

        # self.fInbetweens = [0.25, 0.5, 0.75]
        if not self.fInbetweens:
            return
        qOpt = QtWidgets.QStyleOptionSlider()
        self.initStyleOption(qOpt)
        iSliderLength = self.style().pixelMetric(QtWidgets.QStyle.PM_SliderLength, qOpt, self)
        qPainter = QtGui.QPainter(self)
        qPainter.translate(qOpt.rect.x() + iSliderLength / 2, 0)
        fHeight = self.height()
        fWidth = self.width()
        qPainter.setPen(qSliderSquareColor)

        for fInb in sorted(self.fInbetweens):
            if fInb in [0.0, 1.0]:
                continue
            x = (fWidth-10) * fInb
            qPainter.drawLine(x, -fHeight, x, fHeight)



def makeWidgetFromLayout(qLayout, parent=None):
    qW = QtWidgets.QFrame(parent)
    qW.setLayout(qLayout)
    return qW


def getGeometryIndices(sBlendShape):
    iIndices = cmds.blendShape(sBlendShape, q=True, geometryIndices=True)
    sGeometries = cmds.blendShape(sBlendShape, q=True, geometry=True)
    sTransforms = [cmds.listRelatives(sG, p=True)[0] for sG in sGeometries]
    return dict(list(zip(sTransforms, iIndices)))



def getComboTargetConditionPlug(sTargetAttr, bForceRecreate=False, sComboMode=None):
    if not bForceRecreate:
        sConditionNodes = cmds.listConnections(sTargetAttr, s=True, d=False, t='condition')
    else:
        sConditionNodes = []

    if sConditionNodes:
        return '%s.secondTerm' % sConditionNodes[0]
    else:
        sBlendShape, sTarget = sTargetAttr.split('.')
        sMainTargetAttrs = sTarget.split('_')
        print('sTarget: ', sTarget)

        iPercs = []
        for t, sMainT in enumerate(sMainTargetAttrs):
            sT, iPerc = library.getTargetPercNumber(sMainT)
            sMainTargetAttrs[t] = sT
            iPercs.append(iPerc)


        if sComboMode == None:
            sComboMode = getCurrentMode(sBlendShape, sTarget)

        if sComboMode == 'M':
            sFactor = library.createMultiplyArrayNode(['%s.%s' % (sBlendShape,sT) for sT in sMainTargetAttrs], sTarget='%s.%s' % (sBlendShape, sTarget), bForce=True)
        elif sComboMode == 'S':
            sFactor = library.createMinimumNode(['%s.%s' % (sBlendShape,sT) for sT in sMainTargetAttrs],
                                                iPercs=iPercs, sTarget='%s.%s' % (sBlendShape, sTarget), bForce=True)
        else:
            raise Exception('Don\'t know what mode "%s" is' % (sComboMode))

        sCondition = library.createConditionNode(True, '==', True, sFactor, False,
                                                 sTarget='%s.%s' % (sBlendShape, sTarget), bForce=True,
                                                 sName='%s_turnOffPlug' % sTarget)
        return '%s.secondTerm' % sCondition.split('.')[0]


def getComboTargetFactorPlug(sTargetAttr):
    sConditionPlug = getComboTargetConditionPlug(sTargetAttr)
    sFactorPlug = cmds.listConnections('%s.colorIfTrueR' % sConditionPlug.split('.')[0], s=True, d=False, p=True)[0]
    return sFactorPlug


def getCurrentMode(sBlendShape, sTarget):
    dModes = eval(utils.getAttrIfExists('%s.%s' % (sBlendShape, utils.kShapeEditorComboModeInfoAttr), '{}'))

    if sTarget in dModes:
        return dModes[sTarget]
    else:
        sMainTargets = list(tools.getPercsFromComboName(sTarget).keys())
        return utils.decideCombineMode(sMainTargets, bReturnString=True)




def getToolDir():
    sFile = __file__
    sDir = os.path.dirname(sFile)
    return sDir


def getListFileDict():
    sDirs = [os.path.dirname(__file__)]
    sTargetListPath = os.environ.get('KANGAROO_TARGETLIST_PATH', None)
    if not library.isNone(sTargetListPath):
        sDirs.extend([sPath.strip() for sPath in sTargetListPath.split(';')])

    dFiles = {}
    for sDir in sDirs:
        sDir = sDir.strip()
        if sDir:
            for sF in os.listdir(sDir):
                sF = sF.strip()
                if sF and sF.endswith('.targetlist'):
                    sName = os.path.basename(sF).split('.')[0]
                    dFiles[sName] = os.path.join(sDir, sF)

    return dFiles


def getPredefinedListFromFile(sFile):
    with open(sFile) as f:
        sFileLines = f.readlines()
    sFileLines = [x.strip() for x in sFileLines]

    dTargets = OrderedDict()

    for sLine in sFileLines:
        sSplits = sLine.split(' ')
        if not len(sSplits) or not sSplits[0].strip():
            continue
        if len(sSplits) == 1:
            sSplits = [sSplits[0], 'true', 'true']
        elif len(sSplits) == 2:
            sSplits = [sSplits[0], sSplits[1], 'true']

        sTarget = sSplits[0]
        bEnabledBox = True if sSplits[1].upper() == 'TRUE' else False
        bEnabledDefault = True if sSplits[2].upper() == 'TRUE' else False
        sInfo = '\n'.join(sLine.split('"')[1::2])

        dTargets[sTarget] = {'bEnableBox':bEnabledBox, 'bEnableBoxDefault':bEnabledDefault, 'sInfo':sInfo}
    return dTargets






class PercentagesUI(QtWidgets.QDialog):

    def __init__(self, sComboTarget, funcCallBack, parent=library.getMayaWindow()):
        super(PercentagesUI, self).__init__(parent, QtCore.Qt.Tool)
        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        sMainTargets = sComboTarget.split('_')

        self.qTable = QtWidgets.QTableWidget()

        self.layout.addWidget(self.qTable)
        self.qTable.setColumnCount(1)
        self.qTable.setRowCount(len(sMainTargets))
        self.qTable.horizontalHeader().setStretchLastSection(True)
        self.qTable.setHorizontalHeaderLabels(['%'])
        self.funcCallBack = funcCallBack

        sMainTargetsIsolated = []
        for a, sAttr in enumerate(sMainTargets):
            sTarget, iNumber = library.getTargetPercNumber(sAttr)
            sMainTargetsIsolated.append(sTarget)
            qItem = QtWidgets.QTableWidgetItem()
            qItem.setText(str(iNumber))
            self.qTable.setItem(0,a, qItem)

        self.qTable.setVerticalHeaderLabels(sMainTargetsIsolated)
        self.qTable.itemChanged.connect(lambda: self.saveButton.setEnabled(True))

        self.saveButton = QtWidgets.QPushButton('Save')
        self.layout.addWidget(self.saveButton)
        self.saveButton.clicked.connect(self.save)
        self.saveButton.setEnabled(False)


    def save(self):

        dPercs = {}
        for iRow in range(self.qTable.rowCount()):
            sMainT = self.qTable.verticalHeaderItem(iRow).text()
            sPerc = self.qTable.item(iRow,0).text()
            dPercs[sMainT] = eval(sPerc)

        self.funcCallBack(dPercs)
        self.close()



class JointValuesUI(QtWidgets.QDialog):

    def __init__(self, fValues, funcCallBack, parent=library.getMayaWindow()):
        super(JointValuesUI, self).__init__(parent, QtCore.Qt.Tool)
        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qTable = QtWidgets.QTableWidget()

        self.layout.addWidget(self.qTable)
        self.qTable.setColumnCount(1)
        self.qTable.setRowCount(len(fValues))
        self.qTable.horizontalHeader().setStretchLastSection(True)
        self.qTable.setHorizontalHeaderLabels(['value'])
        self.funcCallBack = funcCallBack

        for a, fV in enumerate(fValues):
            qItem = QtWidgets.QTableWidgetItem()
            qItem.setText(str(fV))
            self.qTable.setItem(0,a, qItem)

        self.qTable.setVerticalHeaderLabels(['rx','ry','rz','tx','ty','tz'][:len(fValues)])
        self.qTable.itemChanged.connect(lambda: self.saveButton.setEnabled(True))

        self.saveButton = QtWidgets.QPushButton('Save')
        self.layout.addWidget(self.saveButton)
        self.saveButton.clicked.connect(self.save)
        self.saveButton.setEnabled(False)


    def save(self):

        fValues = []
        for iRow in range(self.qTable.rowCount()):
            sValue = self.qTable.item(iRow,0).text()
            fValues.append(eval(sValue))

        self.funcCallBack(fValues)
        self.close()




class QSetObject(object):
    def build(self, qLayout, sLabel, sAttr, qBlendShape=None, bIsIndex=False, bIsNamespace=False):

        self.qTopLayout = QtWidgets.QVBoxLayout()
        self.qNamespaceLayout = QtWidgets.QHBoxLayout()
        self.qTopLayout.addLayout(self.qNamespaceLayout)
        self.qLine = QtWidgets.QLineEdit('')
        self.qNamespaceLayout.addWidget(QtWidgets.QLabel(sLabel))
        self.qNamespaceLayout.addWidget(self.qLine)
        self.qLine.setEnabled(False)

        self.qBlendShape = qBlendShape

        self.iClearScriptJob = None

        self.sAttr = sAttr
        self.bIsIndex = bIsIndex
        self.bIsNamespace = bIsNamespace
        qSetButton = QtWidgets.QPushButton('<<')
        qSetButton.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        qSetButton.clicked.connect(self.setClicked)
        self.qNamespaceLayout.addWidget(qSetButton)

        qLayout.addLayout(self.qTopLayout)
        self.qBlendShape.funcUpdates.append(self.update)



    def update(self, sBlendShape=None):
        if sBlendShape == None:
            sBlendShape = self.qBlendShape.getBlendShape()
        if cmds.attributeQuery(self.sAttr, node=sBlendShape, exists=True):
            sValue = cmds.getAttr('%s.%s' % (sBlendShape, self.sAttr))
            self.qLine.setText(sValue)


    def setClicked(self, sObject=None):

        if library.isNone(sObject) or isinstance(sObject, bool):
            sObject = cmds.ls(sl=True)[0]

        sBlendShape = self.qBlendShape.getBlendShape()

        if self.bIsIndex:
            sNumber = sObject.split('[')[-1].split(']')[0]
            utils.addStringAttr(sBlendShape, self.sAttr, sNumber)
            self.qLine.setText(sNumber)
        elif self.bIsNamespace:
            if ':' not in sObject:
                return
            sNamespace = '%s:' % sObject.split(':')[0]
            utils.addStringAttr(sBlendShape, self.sAttr, sNamespace)
            self.qLine.setText(sNamespace)
        else:
            utils.addStringAttr(sBlendShape, self.sAttr, sObject)
            self.qLine.setText(sObject)


    def getObject(self):
        sText = self.qLine.text()
        if self.bIsIndex:
            return int(sText)
        else:
            return sText






class QGetFaceArOptionsDialog(QtWidgets.QDialog):

    def __init__(self, funcCallback, parent=None):
        super(QGetFaceArOptionsDialog, self).__init__(parent=parent)#, QtCore.Qt.WindowStaysOnTopHint)

        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.qMessage = QtWidgets.QLabel('File')
        self.qComments = QtWidgets.QLineEdit()
        self.qComments.setText(r"C:\Users\Thomas Bittner\Downloads\KAZUE_v12_notes\Kazue_Blendshape_Test.csv")
        self.qSideMappingCombo = QtWidgets.QComboBox()
        self.qSideMappingCombo.addItem('Assign Left Shapes from CSV File to Full if they don\'t exist (skipping Right side shapes)')
        self.qSideMappingCombo.addItem('Assign Right Shapes from CSV File to Full if they don\'t exist (skipping Left side shapes)')

        layout.addWidget(self.qMessage)
        layout.addWidget(self.qComments)
        layout.addWidget(self.qSideMappingCombo)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

        self.funcCallback = funcCallback


    def okClicked(self):
        sComments = self.qComments.text()
        iMapIndex = self.qSideMappingCombo.currentIndex()
        self.close()
        self.funcCallback(sComments, ['l','r'][iMapIndex])
