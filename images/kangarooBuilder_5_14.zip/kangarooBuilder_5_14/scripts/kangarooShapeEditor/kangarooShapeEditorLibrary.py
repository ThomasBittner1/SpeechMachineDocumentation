###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import re
import math
import json
import numpy as np
import sys
import importlib
from collections import Counter

import maya.api.OpenMaya as OpenMaya2
import maya.OpenMaya as OpenMaya
import kangarooTools.patch as patch
import maya.OpenMayaUI as mui

if cmds.about(v=True) >= '2025':
    from PySide6 import QtWidgets, QtGui, QtCore
    from shiboken6 import wrapInstance
else:
    from PySide2 import QtWidgets, QtGui, QtCore
    from shiboken2 import wrapInstance

kPythonVersion = None
def getPythonVersion():
    global kPythonVersion
    if kPythonVersion == None:
        kPythonVersion = int(sys.version[0])
    return kPythonVersion


def reload2(modModule):
    if getPythonVersion() == 2:
        return reload(modModule)
    else:
        return importlib.reload(modModule)

def isInteger(sString):
    try:
        int(sString)
        return True
    except:
        return False


def isStringOrUnicode(xValue):
    if getPythonVersion() == 2:
        return isinstance(xValue, (str, unicode))
    else:
        return isinstance(xValue, str)


class uiColors():
    blue = '#3f51b5'
    green = '#52af50'
    lightGreen = '#8bc34a'
    red = '#ea4963'
    orange = '#ffae00'
    orangeDark = '#af7800'
    yellow = '#ffeb3b'
    white = '#ffffff'
    default = '#d9d9d9'
    disabled = '#363636'
    blue = '#39a9f4'



class InbetweenModes():
    MainTargetAndInbetweens = 0
    OnlyMainTarget = 1
    OnlyClosestInbetween = 2


def getMayaWindow():
    ptr = mui.MQtUtil.mainWindow()
    return wrapInstance(int(ptr), QtWidgets.QWidget)






def getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=False):
    sAliases = cmds.aliasAttr(sBlendShape, q=True)
    if not sAliases:
        return {}
    sTargets = sAliases[::2]
    iIds = [intFromComponent(sComponent) for sComponent in sAliases[1::2]]
    if bPerTargetNames:
        return dict(list(zip(sTargets, iIds)))
    else:
        return dict(list(zip(iIds, sTargets)))



def getSide(sName):
    if 'LFT' in sName: return 'l'
    if 'RGT' in sName: return 'r'

    if sName[0:2].isupper():
        if sName[0] == 'L': return 'l'
        if sName[0] == 'R': return 'r'
    if sName.startswith('l_'): return 'l'
    if sName.startswith('r_'): return 'r'
    if '_l_' in sName: return 'l'
    if '_r_' in sName: return 'r'
    if '_L_' in sName: return 'l'
    if '_R_' in sName: return 'r'
    if sName.endswith('Left'): return 'l'
    if sName.endswith('Right'): return 'r'
    if sName.endswith('_L'): return 'l'
    if sName.endswith('_R'): return 'r'
    if sName.endswith('_Lt'): return 'l'
    if sName.endswith('_Rt'): return 'r'
    if '_L.' in sName: return 'l'
    if '_R.' in sName: return 'r'
    if sName.startswith('Left'): return 'l'
    if sName.startswith('Right'): return 'r'
    return 'm'



def getMirrorName(sName):
    sUnderscoreSplits = sName.split('__')
    if len(sUnderscoreSplits) == 5:
        sUnderscoreSplits[1] = getMirrorName(sUnderscoreSplits[1])
        return '__'.join(sUnderscoreSplits)

    if 'LFT' in sName: return sName.replace('LFT','RGT')
    if 'RGT' in sName: return sName.replace('RGT', 'LFT')


    if sName[0:2].isupper():
        if sName[0] == 'L': return 'R%s' % sName[1:]
        if sName[0] == 'R': return 'L%s' % sName[1:]
    if sName.startswith('l_'): return 'r_%s' % sName[2:]
    if sName.startswith('L_'): return 'R_%s' % sName[2:]
    if sName.startswith('r_'): return 'l_%s' % sName[2:]
    if sName.startswith('R_'): return 'L_%s' % sName[2:]
    if '_l_' in sName: return sName.replace('_l_','_r_')
    if '_r_' in sName: return sName.replace('_r_','_l_')
    if '_L_' in sName: return sName.replace('_L_','_R_')
    if '_R_' in sName: return sName.replace('_R_','_L_')
    if sName.endswith('Left'): return '%sRight' % sName[:-len('Left')]
    if sName.endswith('Right'): return '%sLeft' % sName[:-len('Right')]
    if sName.endswith('_Lt'): return '%s_Rt' % sName[:-len('_Rt')]
    if sName.endswith('_Rt'): return '%s_Lt' % sName[:-len('_Lt')]
    if sName.startswith('Left'): return 'Right%s' % sName[len('Left'):]
    if sName.startswith('Right'): return 'Left%s' % sName[len('Right'):]

    if '_L.' in sName: return sName.replace('_L.', '_R.')
    if '_R.' in sName: return sName.replace('_R.', '_L.')
    if sName.endswith('_L'): return '%s_R' % sName[:-2]
    if sName.endswith('_R'): return '%s_L' % sName[:-2]

    if sName.endswith('_l'): return '%s_r' % sName[:-2]
    if sName.endswith('_r'): return '%s_l' % sName[:-2]

    return sName



def getFirstAvailableTargetIndexFromBlendShape(sBlendShape):
    dTargets = getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    iIndices = list(dTargets.values())
    iIndices.sort()
    iFirstIndex = len(iIndices)
    for i,iIndex in enumerate(iIndices):
        if i != iIndex:
            iFirstIndex = i
            resetTargetDeltasFull(sBlendShape, iFirstIndex)
            return iFirstIndex
    resetTargetDeltasFull(sBlendShape, iFirstIndex)
    return iFirstIndex


def resetTargetDeltasFull(sBlendShape, iTargetIndex, sMeshes=None):
    dMeshes = getBlendShapeMeshTransforms(sBlendShape, bReturnIndexDict=True)

    cmds.undoInfo(openChunk=True)
    try:
        if isNone(sMeshes):# == None:
            sMeshes = list(dMeshes.keys())

        for sM in sMeshes:
            try:
                iMeshIndex = dMeshes[sM]
            except:
                print('problems getting %s from %s' % (sM, dMeshes))
                raise

            fZeroPoints = [(0.0, 0.0, 0.0, 1.0)]
            cmds.setAttr('%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputPointsTarget' %
                         (sBlendShape, iMeshIndex, iTargetIndex),
                         len(fZeroPoints), *fZeroPoints, type='pointArray')
            sZeroPoints = ['vtx[0]']
            cmds.setAttr('%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputComponentsTarget' %
                         (sBlendShape, iMeshIndex, iTargetIndex),
                         len(sZeroPoints), *sZeroPoints, type='componentList')
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def getBlendShapeMeshTransforms(sBlendShape, bReturnIndexDict=False, bFullPath=False):
    sGeometries = cmds.blendShape(sBlendShape, q=True, geometry=True)
    sMeshes = [cmds.listRelatives(sS, p=True, f=bFullPath)[0] for sS in sGeometries]
    if bReturnIndexDict:
        iIndices = cmds.blendShape(sBlendShape, q=True, geometryIndices=True)
        dMeshes = {sM:iI for sM,iI in zip(sMeshes,iIndices)}
        return dMeshes
    else:
        return sMeshes



def intFromComponent(sComp):
    sId = sComp.split('[')[-1].split(']')[0]
    iId = int(sId)
    return iId



def duplicateGeoClean(sMesh, sName=None, bSetToOrigMesh=False, bParentToOrigin=False):
    sDupl = cmds.duplicate(sMesh, rr=True, renameChildren=True)[0]
    if sName and cmds.objExists(sName):
        raise Exception('%s already exists!' % sName)
    if bParentToOrigin:
        if cmds.listRelatives(sDupl, p=True, f=True):
            cmds.parent(sDupl, w=True)

    sAllShapes = cmds.listRelatives(sDupl, s=True, f=True)
    sNoIntermShapes = cmds.listRelatives(sDupl, s=True, ni=True, f=True)
    sShapes = set(sAllShapes) - set(sNoIntermShapes)
    if sShapes:
        cmds.delete(list(sShapes))
    if sName:
        sDupl = cmds.rename(sDupl, sName)

    if bSetToOrigMesh:
        sAllShapes = cmds.listRelatives(sMesh, s=True)
        sNoIntermShapes = cmds.listRelatives(sMesh, s=True, ni=True)
        sShapes = set(sAllShapes) - set(sNoIntermShapes)

        if sShapes:
            sOrig = sShapes.pop()
        else:
            sOrig = sAllShapes[0]

        cmds.connectAttr('%s.outMesh' % sOrig, '%s.inMesh' % sDupl)

    return sDupl



# todo: rewrite it to be cleaner?
def getOrigShape(sTransform, sBlendShapeCheck=None):
    sAllShapes = cmds.listRelatives(sTransform, s=True, f=True) or []
    sNoIntermShapes = cmds.listRelatives(sTransform, s=True, ni=True, f=True) or []
    sShapes = list(set(sAllShapes) - set(sNoIntermShapes))
    print ('sBlendShapeCheck: ', sBlendShapeCheck)
    if sShapes:
        if len(sShapes) > 1 and sBlendShapeCheck == None:
            print ('more than one orig shapes: ', sShapes)
            raise Exception('There are more than one Orig shapes on %s' % sTransform)
        elif sBlendShapeCheck != None:
            for sShape in sShapes:
                if sBlendShapeCheck in (cmds.listConnections(sShape, d=True, s=False) or []):
                    return sShape
            raise Exception('issue finding orig shape')
        else:
            return sShapes[0]
    else:
        return sAllShapes[0]



def createVectorMultiplyNode(xInputA, xInputB, bVectorByScalar=False, sTarget=None, sOperation='multiply', sName='noname'):
    sNode = cmds.createNode('multiplyDivide', name='MULT_%s' % sName)

    _connectOrSetVector(xInputA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])

    if bVectorByScalar:
        _connectOrSet(xInputB, '%s.input2X' % sNode)
        _connectOrSet(xInputB, '%s.input2Y' % sNode)
        _connectOrSet(xInputB, '%s.input2Z' % sNode)
    else:
        _connectOrSetVector(xInputB, '%s.input2' % sNode, ['input2X', 'input2Y', 'input2Z'])

    if sOperation != 'multiply':
        iOperation = ['noOperation', 'multiply', 'divide', 'square'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)
    sOutput = '%s.output' % sNode
    #
    # if bOutputIsSum:
    #     sOutput = createAdditionNode(['%sX' % sOutput, '%sY' % sOutput, '%sZ' % sOutput], sName=sName)
    #
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput


def createWrap(sChildren, sParent, bExclusiveBind=True):
    sChildren = toList(sChildren)

    sSelBefore = cmds.ls(sl=True)
    cmds.select(sChildren, sParent)

    sWrapsBefore = set(cmds.ls(et='wrap'))
    cmds.CreateWrap()
    sWrapsAfter = set(cmds.ls(et='wrap'))

    sUnorderedWraps = list(sWrapsAfter - sWrapsBefore)
    for sWrap in sUnorderedWraps:
        cmds.setAttr('%s.exclusiveBind' % sWrap, bExclusiveBind)

    sBase = cmds.listConnections('%s.basePoints' % sUnorderedWraps[0])[0]

    cmds.select(sSelBefore)
    return sUnorderedWraps, sBase



def addBlendShapeTarget(sGeometry, sTarget, sAliasAttr, bTopologyCheck=False):

    sBlendShapes = listAllDeformers(sGeometry, sFilterTypes=['blendShape'])
    sBs = sBlendShapes[0]
    sGeo = cmds.deformer(sBs, q=True, g=True)[0]

    iNewIndex = getFirstAvailableTargetIndexFromBlendShape(sBs)
    print('iNewIndex...', iNewIndex)

    sUniqueAliasAttr = getUniqueBlendShapeTargetName(sBs, sAliasAttr) # we rely on this being the exact name of target that cmds.blendShape will create
    cmds.blendShape(sBs, e=True, t=[sGeo, iNewIndex, sTarget, 1.0], topologyCheck=bTopologyCheck)

    if sTarget != sAliasAttr:
        try:
            cmds.aliasAttr(sUniqueAliasAttr, '%s.w[%d]' % (sBs, iNewIndex))
        except Exception as e:
            raise Exception('BLENDSHAPE: %s - %s, error making unique alias attr ("%s")' % (sBs, e, sUniqueAliasAttr))
    return iNewIndex, sUniqueAliasAttr


def addAttr(*args, **kwargs):

    try:
        bReturnIfExists = kwargs['bReturnIfExists']
        del kwargs['bReturnIfExists']
    except:
        bReturnIfExists = False

    try:
        bCb = kwargs['cb']
        del kwargs['cb']
    except:
        bCb = False

    try:
        sAddSidePostFix = kwargs['sAddSidePostFix']
        del kwargs['sAddSidePostFix']
    except:
        sAddSidePostFix = None
    if sAddSidePostFix != None:
        sLn = kwargs['ln']
        if sAddSidePostFix.startswith('l'):
            sLn = '%sLeft' % sLn
        elif sAddSidePostFix.startswith('r'):
            sLn = '%sRight' % sLn
        elif sAddSidePostFix.startswith('m'):
            sLn = '%sMiddle' % sLn
        else:
            raise Exception('don\'t recognize what side "%s" is' % sAddSidePostFix)
        kwargs['ln'] = sLn

    sAttr = '%s.%s' % (args[0], kwargs['ln'])
    if cmds.objExists(sAttr):
        if bReturnIfExists:
            return sAttr
        else:
            raise Exception('attribute %s already exists!' % sAttr)

    try:
        fMultipl = kwargs['fMultipl']
        del kwargs['fMultipl']
    except:
        fMultipl = None


    cmds.addAttr(*args, **kwargs)

    if kwargs.get('at', 'double').endswith('3'):
        kChildrenArgs = dict(kwargs)
        sAttrName = kwargs['ln']
        kChildrenArgs['at'] = kwargs['at'][:-1]
        kChildrenArgs['p'] = sAttrName
        for i in range(3):
            kChildrenArgs['ln'] = '%s%s' % (sAttrName, ['X','Y','Z'][i])
            cmds.addAttr(*args, **kChildrenArgs)

    if bCb:
        cmds.setAttr(sAttr, cb=True)

    if fMultipl:
        sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True)
        cmds.connectAttr(sAttr, '%s.input1X' % sMultipl)
        cmds.setAttr('%s.input2X' % sMultipl, fMultipl)
        return '%s.%s' % (sMultipl, 'outputX')
    else:
        return sAttr


def shiftOrCtrlPressed():
    qModifiers = QtWidgets.QApplication.keyboardModifiers()
    if ((qModifiers & QtCore.Qt.ControlModifier) or (qModifiers & QtCore.Qt.ShiftModifier)):
        return True
    else:
        return False


def addStringAttr(sGrp, sAttr, sText, bLock=False):
    sAttr = addAttr(sGrp, ln=sAttr, dt='string', k=False, bReturnIfExists=True)
    bLockedBefore = cmds.getAttr(sAttr, lock=True)
    cmds.setAttr(sAttr, q=True, lock=False)
    cmds.setAttr(sAttr, sText, type='string')
    if bLockedBefore or bLock: cmds.setAttr(sAttr, lock=True)
    return sAttr


def getStringAttr(sGrp, sAttr, sDefault, bCreateIfNotExists=False):
    sFullAttr = '%s.%s' % (sGrp, sAttr)
    if cmds.objExists(sFullAttr):
        return cmds.getAttr(sFullAttr)
    else:
        if bCreateIfNotExists:
            addStringAttr(sGrp, sAttr, sDefault, bLock=True)
        return sDefault


def addToListStringAttr(sGrp, sAttr, sAdd=[]):
    sCurrent = eval(getStringAttr(sGrp, sAttr, '[]'))
    addStringAttr(sGrp, sAttr, sCurrent+sAdd)


def removeFromListStringAttr(sGrp, sAttr, sRemove=[]):
    sCurrent = eval(getStringAttr(sGrp, sAttr, '[]'))
    sNewList = [sStr for sStr in sCurrent if sStr not in sRemove]
    addStringAttr(sGrp, sAttr, sNewList)


def listAllDeformers(sGeometry, sFilterTypes=[], sIgnoreTypes=['tweak'], bDoCloth=False):
    sHistory = cmds.listHistory(sGeometry)

    sDeformers = [sN for sN in sHistory if 'geometryFilter' in cmds.nodeType(sN, i=True)]
    if sFilterTypes:
        sDeformers = [sD for sD in sDeformers if cmds.objectType(sD) in sFilterTypes]
    if sIgnoreTypes:
        sDeformers = [sD for sD in sDeformers if cmds.objectType(sD) not in sIgnoreTypes]

    sGeometryDeformers = []
    for sDeformer in sDeformers:
        sGeos = cmds.deformer(sDeformer, q=True, g=True)
        if isNone(sGeos):
            raise Exception('"%s" doesn\'t list any geometries' % sDeformer)
        for sGeo in sGeos:
            if geoEqual(sGeo, sGeometry):
                sGeometryDeformers.append(sDeformer)

    return sGeometryDeformers



def flattenedList(ssList):
    def _flattenREC(xObj, xResultList):
        if isinstance(xObj, (list,tuple,np.ndarray)):
            for sO in xObj:
                _flattenREC(sO, xResultList)
        else:
            xResultList.append(xObj)
    sReturnList = []
    _flattenREC(ssList, sReturnList)
    return sReturnList


def getUniqueBlendShapeTargetName(sBlendShape, sTarget):

    if not cmds.objExists('%s.%s' % (sBlendShape, sTarget)):
        return sTarget

    sTarget, iNumber = getNumberAtEnd(sTarget)
    while True:
        iNumber += 1
        sNewTarget = '%s%d' % (sTarget, iNumber)
        if not cmds.objExists('%s.%s' % (sBlendShape, sNewTarget)):
            return sNewTarget



def getNumberAtEnd(sName, iDefault=0):
    m = re.search(r'\d+$', sName)
    if m:
        sNumber = m.group()
        return sName[:-len(sNumber)], int(sNumber)
    else:
        return sName, iDefault


def getTargetPercNumber(sName, iDefault=100):
    if sName.startswith('splineLidCorrective'):
        return sName, iDefault
    else:
        m = re.search(r'\d+$', sName)
        if m:
            sNumber = m.group()
            return sName[:-len(sNumber)], int(sNumber)
        else:
            return sName, iDefault



def numberToString(fNumber, iDecimals=3):
    if isinstance(fNumber, float):
        fValue = round(fNumber, iDecimals)
    else:
        fValue = fNumber
    return str(fValue)




def toList(item):
    if isinstance(item, (list,tuple)):
        return item
    elif isinstance(item, dict):
        return list(item.keys())
    else:
        return [item]




def getDuplicates(xList):
    xDuplicates = [item for item, count in list(Counter(xList).items()) if count > 1]
    return xDuplicates


def listToString(sList, sSeparator=', ', iMaxCount=None):
    if iMaxCount and len(sList) > iMaxCount:
        iMore = len(sList) - iMaxCount
        return '%s, and %d more' % (sSeparator.join(sList[:iMaxCount]), iMore)
    else:
        return sSeparator.join(sList)



def geoEqual(sA, sB):
    if sA == sB:
        return True

    bATransform = True if cmds.objectType(sA) == 'transform' else False
    bBTransform = True if cmds.objectType(sB) == 'transform' else False

    if bATransform and bBTransform:
        return False
    if bATransform and sB in cmds.listRelatives(sA, s=True) or []:
        return True
    if bBTransform and sA in cmds.listRelatives(sB, s=True) or []:
        return True
    if not bATransform and not bBTransform:
        sParentsA = cmds.listRelatives(sA, p=True)
        sParentsB = cmds.listRelatives(sB, p=True)
        if not sParentsA or not sParentsB:
            return False
        if sParentsA[0] == sParentsB[0]:
            return True

    return False





def createAdditionNode(xInputs, sTarget=None, sName='noname', sOperation='plus'):

    if not isinstance(xInputs, (list,tuple)):
        raise Exception('input needs to be a list')

    sNode = cmds.createNode('plusMinusAverage', name='plusMinusAverage_%s' % sName)
    for i, xInput in enumerate(xInputs):
        _connectOrSet(xInput, '%s.input1D[%d]' % (sNode,i))

    if sOperation != 'plus':
        iOperation = ['noOperation','plus', 'minus', 'average'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)

    sOutput = '%s.output1D' % sNode
    if sTarget:
        if isinstance(sTarget, (list, tuple)):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT)
        else:
            cmds.connectAttr(sOutput, sTarget)

        # _connectOrSet(sOutput, sTarget)
    return sOutput





def _connectOrSet(xValue, sAttr, bForce=False):
    if isinstance(xValue, (list, tuple, np.ndarray)) and len(xValue) == 16:
        sHoldMatrix = cmds.createNode('holdMatrix')
        cmds.setAttr('%s.inMatrix' % sHoldMatrix, xValue, type='matrix')
        cmds.connectAttr('%s.outMatrix' % sHoldMatrix, sAttr)
    else:
        try:
            fValue = float(xValue)
        except:
            fValue = None

        if fValue != None:
            cmds.setAttr(sAttr, fValue)
        else:
            cmds.connectAttr(xValue, sAttr, f=bForce)



def _connectOrSetVector(xValue, sAttr, sSeparateItems=[], bForce=False):
    if sSeparateItems and isinstance(xValue, (list, tuple, np.ndarray)):
        sNode = sAttr.split('.')[0]
        _connectOrSet(xValue[0], '%s.%s' % (sNode, sSeparateItems[0]), bForce=bForce)
        _connectOrSet(xValue[1], '%s.%s' % (sNode, sSeparateItems[1]), bForce=bForce)
        _connectOrSet(xValue[2], '%s.%s' % (sNode, sSeparateItems[2]), bForce=bForce)
    elif sSeparateItems and isinstance(xValue, OpenMaya2.MVector):
        sNode = sAttr.split('.')[0]
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[0]), xValue[0])
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[1]), xValue[1])
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[2]), xValue[2])
    else:
        try:
            cmds.setAttr(sAttr, *xValue) # it's a list of values
        except:
            cmds.connectAttr(xValue, sAttr, force=bForce) # it's a compound attribute to connect



def _connectTargetIfNotNone(sTarget, sOutput, bForce=False):
    if sTarget:
        if isinstance(sTarget, list):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT)
        else:
            print('sTarget: ', sTarget, cmds.objExists(sTarget))

            cmds.connectAttr(sOutput, sTarget, force=bForce)


def createExtremeNode(xInputs, iPercs=[], bMinimum=True, sName='noname', sTarget=None, bForce=False):
    if not len(iPercs):
        iPercs = [100] * len(xInputs)

    if len(xInputs) == 1:
        sOutput = xInputs[0]
    else:
        xPrev = xInputs[0]
        if iPercs[0] < 100:
            xPrev = createMultiplyNode(xPrev, iPercs[0] * 0.01, sOperation='divide')
            xPrev = createClampNode(xPrev, 0, 1)

        for i in range(1, len(xInputs), 1):
            xInput = xInputs[i]
            if iPercs[i] < 100:
                xInput = createMultiplyNode(xInput, iPercs[i] * 0.01, sOperation='divide')
                xInput = createClampNode(xInput, 0, 1)
            xPrev = createConditionNode(xPrev, '<' if bMinimum else '>', xInput, xPrev, xInput, sName='%sMinimum' % sName)
        sOutput = xPrev

    _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)

    return sOutput


def createMinimumNode(xInputs, iPercs=[], sName='noname', sTarget=None, bForce=False):
    return createExtremeNode(xInputs, iPercs=iPercs, bMinimum=True, sName=sName, sTarget=sTarget, bForce=bForce)



def createClampNode(xInputA, xMin, xMax, bVector=False, sTarget=None, sName='noname', sFullName=None):
    if not sFullName:
        sFullName = 'clamp_%s' % sName

    sNode = cmds.createNode('clamp', name=sFullName)

    if not bVector:
        _connectOrSet(xInputA, '%s.inputR' % sNode)
        _connectOrSet(xMin, '%s.minR' % sNode)
        _connectOrSet(xMax, '%s.maxR' % sNode)
        sOutput = '%s.outputR' % sNode
    else:
        _connectOrSetVector(xInputA, '%s.input' % sNode, sSeparateItems=['inputR', 'inputG', 'inputB'])
        _connectOrSetVector(xMin, '%s.min' % sNode, sSeparateItems=['minR', 'minG', 'minB'])
        _connectOrSetVector(xMax, '%s.max' % sNode, sSeparateItems=['maxR', 'maxG', 'maxB'])
        sOutput = '%s.output' % sNode

    _connectTargetIfNotNone(sTarget, sOutput)
    return sOutput



def createConditionNode(xFirstTerm, sOperator, xSecondTerm, xOutputTrue, xOutputFalse, sName='noname', sFullName=None,
                        bVector=False, sTarget=None, bForce=False):
    if sFullName == None:
        sFullName = 'condition_%s' % sName

    try:
        iOperation = ['==', '!=', '>', '>=', '<', '<='].index(sOperator)
    except:
        raise Exception('don\'t know what operator %s is' % sOperator)

    sNode = cmds.createNode('condition', name=sFullName)
    _connectOrSet(xFirstTerm, '%s.firstTerm' % sNode)
    _connectOrSet(xSecondTerm, '%s.secondTerm' % sNode)
    cmds.setAttr('%s.operation' % sNode, iOperation)

    if bVector:
        _connectOrSetVector(xOutputTrue, '%s.colorIfTrue' % sNode)
        _connectOrSetVector(xOutputFalse, '%s.colorIfFalse' % sNode)
        sOutput = '%s.outColor' % sNode
        if sTarget:
            _connectOrSetVector(sOutput, sTarget, bForce=bForce)
        return sOutput
    else:
        _connectOrSet(xOutputTrue, '%s.colorIfTrueR' % sNode)
        _connectOrSet(xOutputFalse, '%s.colorIfFalseR' % sNode)
        sOutput = '%s.outColorR' % sNode
        if sTarget:
            _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)
        return sOutput


def findOneArrayInAnother(aMain, aFind, iMissingIndex=-1, bSkipMissing=False):
    if not len(aMain):
        aIndexed = np.empty(len(aFind), dtype=int)
        aIndexed.fill(iMissingIndex)
        return aIndexed
    aMain = np.array(aMain)
    aSort = np.argsort(aMain)
    aMainSorted = aMain[aSort]
    aSearchSorted = np.searchsorted(aMainSorted, aFind)
    aIndexed = np.append(aSort,-1)[aSearchSorted]
    for i, iInd in enumerate(aIndexed):
        if iInd != iMissingIndex and aMain[iInd] != aFind[i]:
            aIndexed[i] = iMissingIndex

    if bSkipMissing:
        aIndexed = aIndexed[aIndexed != iMissingIndex]

    return aIndexed



def getIdsToIndicesMapper(aIds):
    aAllIdsMapper = np.zeros(np.max(aIds)+1, dtype=int)
    aAllIdsMapper[aIds] = np.arange(len(aIds))
    return aAllIdsMapper



def getIslands(sMesh):
    iNeighbors = getNeighbors(sMesh)

    aIds = np.arange(cmds.polyEvaluate(sMesh, vertex=True))
    aIdsMapper = getIdsToIndicesMapper(aIds)

    iIslands = [list(iNeighbors[i]) for i in range(len(aIds))]
    for i, aId in enumerate(aIds):
        if not iIslands[i]:
            continue
        k = 0
        while k < len(iIslands[i]):
            currentId = iIslands[i][k]
            currentIdMapped = aIdsMapper[currentId]
            if currentIdMapped != -1 and iIslands[currentIdMapped] and currentId != aIds[aIdsMapper[aId]]:
                iIslands[i] += iIslands[currentIdMapped]
                iIslands[currentIdMapped] = None
            k += 1

    iIslands = [list(set(iI)) for iI in iIslands if iI]
    [iI.sort() for iI in iIslands]
    iIslands += [[aIds[i]] for i, iI in enumerate(iNeighbors) if not iI]  # single verts
    return [np.array(iI, dtype=int) for iI in iIslands]






def numpify2dList(xList, bReturnSizes=False, iEmptyValue=-1, iMaxCount=None, dtype=int):
    '''
    if iEmptyValue is set to None, the missing ones are filled with the last item
    '''
    aSizes = np.array([len(xL) for xL in xList], dtype=int)

    iBiggest = np.max(aSizes)
    if iMaxCount and iBiggest > iMaxCount:
        aSizes = np.clip(aSizes, 0, iMaxCount)
        iBiggest = iMaxCount

    aReturn = np.empty((len(xList),iBiggest), dtype=dtype)
    aReturn.fill(iEmptyValue if iEmptyValue != None else -5)

    for l,xL in enumerate(xList):
        aReturn[l,:aSizes[l]] = xL[0:min(iBiggest,len(xL))]
        if iEmptyValue == None and aSizes[l] < iBiggest:
            aReturn[l,aSizes[l]:] = aReturn[l,aSizes[l]-1]

    if bReturnSizes:
        return aReturn, aSizes
    else:
        return aReturn




def getClosestInfoFromPoints(sMesh, aPoints):
    # bReturnFaces = True, bReturnNormals = True

    mMesh = getDagPath(sMesh)
    fnMesh = OpenMaya2.MFnMesh(mMesh)

    xReturn = []
    for aPoint in aPoints:
        mClosestPoint, mClosestNormal, iClosestFace = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(aPoint))
        # itMesh.setIndex(iClosestFace)
        # iVerts = np.array(itMesh.getVertices(), dtype=int)
        # aLocalPoints = aMeshPoints[iVerts] - aPoint
        # aDistances = np.linalg.norm(aLocalPoints, axis=-1)
        # iClosest = np.argmin(aDistances)
        xReturn.append([np.array(mClosestPoint, dtype='float64')[0:3], iClosestFace])

    return xReturn



def getDependNode(sName):
    selList = OpenMaya2.MSelectionList()
    selList.add(sName)
    return selList.getDependNode(0)


def getDependNodeOldApi(sName):
    selList = OpenMaya.MSelectionList()
    selList.add(sName)
    tmp = OpenMaya.MObject()
    selList.getDependNode(0, tmp)
    return tmp



def getDagPath(sName):
    selList = OpenMaya2.MSelectionList()
    try:
        selList.add(sName)
    except Exception as e:
        raise Exception('unable to create dagPath with "%s" - %s' % (sName, e))
    return selList.getDagPath(0)


def getNeighbors(sMesh):
    mMeshDagPath = getDagPath(sMesh)
    mVertexIter = OpenMaya2.MItMeshVertex(mMeshDagPath)
    xNeighbors = []
    iMaxNeighborCount = -1
    iTotalVertexCount = cmds.polyEvaluate(sMesh, vertex=True)

    for iId in range(iTotalVertexCount):
        mVertexIter.setIndex(int(iId))
        aConnectedVertices = np.array(mVertexIter.getConnectedVertices(), dtype=int)

        iUsedNeighbors = list(aConnectedVertices)
        xNeighbors.append(iUsedNeighbors)
        if len(iUsedNeighbors) > iMaxNeighborCount:
            iMaxNeighborCount = len(iUsedNeighbors)

    return xNeighbors


def getAllVertexFaces(mMesh, aIds=None):
    iter = OpenMaya2.MItMeshVertex(mMesh)
    if isNone(aIds):# == None:
        aIds = np.arange(iter.count())
    iReturns = []
    for i, id in enumerate(aIds):
        iter.setIndex(int(id))
        iReturns.append(list(iter.getConnectedFaces()))
    return iReturns



def getAllFaceVertices(mMesh):
    it = OpenMaya2.MItMeshPolygon(mMesh)
    iFaceEdges = []
    while not it.isDone():
        edges = it.getVertices()
        iFaceEdges.append(edges)
        it.next(None)
    return iFaceEdges


def getAllVertexEdges(mMesh):
    it = OpenMaya2.MItMeshVertex(mMesh)
    iEdges = []
    while not it.isDone():
        edges = it.getConnectedEdges()
        iEdges.append(edges)
        it.next()
    return iEdges



#
# def getEdgeIntersections(sMesh, sIntersector):
#     print 'sMesh: ', sMesh
#     mMesh = getDagPath(sMesh)
#     fnMesh = OpenMaya2.MFnMesh(mMesh)
#     mIntersector = getDagPath(sIntersector)
#
#     accelParams = fnMesh.autoUniformGridParams()
#     mIntersectionPoints = []
#     iIntersectionEdges = []
#
#     if cmds.listRelatives(sIntersector, c=True, typ='mesh'):
#         fnMeshIntersector = OpenMaya2.MFnMesh(getDagPath(mIntersector))
#         aPointsIntersector = np.array(cmds.xform('%s.vtx[*]' % sIntersector, q=True, ws=True, t=True)).reshape(-1,3)
#         aEdges = np.zeros((fnMeshIntersector.numEdges, 2), dtype=int)
#         for edge in range(fnMeshIntersector.numEdges):
#             aEdges[edge] = fnMeshIntersector.getEdgeVertices(edge)
#     elif cmds.listRelatives(sIntersector, c=True, typ='nurbsCurve'):
#         aPointsIntersector = np.array(cmds.xform('%s.cv[*]' % sIntersector, q=True, ws=True, t=True)).reshape(-1,3)
#         iVertexCount = len(aPointsIntersector)
#         aEdges = np.zeros((iVertexCount - 1, 2), dtype=int)
#         aEdges[:, 0] = np.arange(iVertexCount - 1)
#         aEdges[:, 1] = np.arange(iVertexCount - 1) + 1
#     else:
#         raise Exception, 'don\'t know what %s is' % sIntersector
#
#     aEdgeDirections = aPointsIntersector[aEdges[:, 1]] - aPointsIntersector[aEdges[:, 0]]
#     aEdgeLengths = np.linalg.norm(aEdgeDirections, axis=-1)
#     aEdgeDirections /= aEdgeLengths[:, np.newaxis]
#     for edge in range(aEdges.size / 2):
#         dir = OpenMaya2.MFloatVector(aEdgeDirections[edge])
#         pos = OpenMaya2.MFloatPoint(aPointsIntersector[aEdges[edge, 0]])
#         mPoint, _, iFace, _, _, _ = fnMesh.closestIntersection(pos, dir, OpenMaya2.MSpace.kWorld,
#                                                                aEdgeLengths[edge], False, accelParams=accelParams)
#         if iFace != -1:
#             mIntersectionPoints.append(mPoint)
#             iIntersectionEdges.append(edge)
#
#     return mIntersectionPoints, iIntersectionEdges




def getBarycentricCoords(aClosests, aSourcePositions, aFaceVertexCounts, iSizeLimit=4):
    aCoords = np.zeros(aClosests.shape[0] * iSizeLimit, dtype='float64').reshape(-1, iSizeLimit)
    # quads
    #
    aQuadVerts = np.where(aFaceVertexCounts == 4)[0]
    if aQuadVerts.size:
        aSourcePositionsQuad = aSourcePositions[aQuadVerts]

        aEdgeLengths = np.zeros(aSourcePositionsQuad.shape[0] * 4, dtype='float64').reshape(-1, 4)
        aEdgeDiffs = np.zeros_like(aSourcePositionsQuad)
        aEdgeNorms = np.zeros_like(aSourcePositionsQuad)
        for i in range(4):
            aEdgeDiffs[:, i] = aSourcePositionsQuad[:, (i + 1) % 4] - aSourcePositionsQuad[:, i]
            aEdgeLengths[:, i] = np.sqrt(np.sum(np.square(aEdgeDiffs[:, i]), axis=-1))
            aEdgeNorms[:, i] = aEdgeDiffs[:, i] / aEdgeLengths[:, i][:, np.newaxis]
        # get the middle points that we need for barycentric coordinates on quads, using closest points on line calculations
        #
        aLengthsToLines = np.zeros(aClosests[aQuadVerts].shape[0] * 4).reshape(-1, 4)
        for i in range(4):
            aDiff = aClosests[aQuadVerts] - aSourcePositionsQuad[:, i]
            aDot = np.sum((aEdgeNorms[:, i] * aDiff), axis=-1)
            ts = aDot / aEdgeLengths[:, i]
            ts = ts[:, np.newaxis]
            aVec = aSourcePositionsQuad[:, i] * (1 - ts) + aSourcePositionsQuad[:, (i + 1) % 4] * (ts)
            aLengthsToLines[:, i] = np.sqrt(np.sum(np.square(aClosests[aQuadVerts] - aVec), axis=1))

        aHeightPercs = (aLengthsToLines[:, 0] / (aLengthsToLines[:, 2] + aLengthsToLines[:, 0]))[:, np.newaxis]
        aHeightPercs = np.nan_to_num(aHeightPercs)

        aWidthPerc = (aLengthsToLines[:, 3] / (aLengthsToLines[:, 3] + aLengthsToLines[:, 1]))[:, np.newaxis]
        aWidthPerc = np.nan_to_num(aWidthPerc)
        aMids = np.zeros(aClosests[aQuadVerts].shape[0] * 4 * 3, dtype='float64').reshape(-1, 4, 3)
        aMids[:, 0] = aSourcePositionsQuad[:, 1] * aWidthPerc + aSourcePositionsQuad[:, 0] * (1 - aWidthPerc)
        aMids[:, 2] = aSourcePositionsQuad[:, 2] * aWidthPerc + aSourcePositionsQuad[:, 3] * (1 - aWidthPerc)
        aMids[:, 1] = aSourcePositionsQuad[:, 2] * aHeightPercs + aSourcePositionsQuad[:, 1] * (1 - aHeightPercs)
        aMids[:, 3] = aSourcePositionsQuad[:, 3] * aHeightPercs + aSourcePositionsQuad[:, 0] * (1 - aHeightPercs)

        # now calculate the areas using those middle points
        #
        def getQuadAreas(As, Bs, Cs, Ds):
            a = np.sqrt(np.sum(np.square(Bs - As), axis=1))
            b = np.sqrt(np.sum(np.square(Cs - Bs), axis=1))
            c = np.sqrt(np.sum(np.square(As - Cs), axis=1))
            s = (a + b + c) * 0.5
            # print 's*(s-a)*(s-b)*(s-c): ', s*(s-a)*(s-b)*(s-c)
            aAreas = np.sqrt(s * (s - a) * (s - b) * (s - c))
            a = np.sqrt(np.sum(np.square(Ds - As), axis=1))
            b = np.sqrt(np.sum(np.square(Cs - Ds), axis=1))
            s = (a + b + c) * 0.5
            aAreas += np.sqrt(s * (s - a) * (s - b) * (s - c))
            return aAreas

        aAreas = np.ones(aClosests[aQuadVerts].shape[0] * 4, dtype='float64').reshape(-1, 4)
        aAreas[:, 0] = getQuadAreas(aSourcePositionsQuad[:, 2], aMids[:, 1], aClosests[aQuadVerts], aMids[:, 2])
        aAreas[:, 1] = getQuadAreas(aSourcePositionsQuad[:, 3], aMids[:, 3], aClosests[aQuadVerts], aMids[:, 2])
        aAreas[:, 2] = getQuadAreas(aSourcePositionsQuad[:, 0], aMids[:, 0], aClosests[aQuadVerts], aMids[:, 3])
        aAreas[:, 3] = getQuadAreas(aSourcePositionsQuad[:, 1], aMids[:, 0], aClosests[aQuadVerts], aMids[:, 1])

        aAreas = np.nan_to_num(aAreas)
        # and finally the coordinates using the areas
        #
        aTotalAreas = np.sum(aAreas, axis=-1)
        aCoords[aQuadVerts] = aAreas / aTotalAreas[:, np.newaxis]
        aZeroAreas = np.where(aTotalAreas == 0)[0]
        aCoords[aZeroAreas] = np.array([0.25, 0.25, 0.25, 0.25])

    # triangles..
    #
    aTriangledVerts = np.where(aFaceVertexCounts == 3)[0]
    if aTriangledVerts.size:
        def getTriangleAreas(As, Bs, Cs):
            a = np.sqrt(np.sum(np.square(Bs - As), axis=1))
            b = np.sqrt(np.sum(np.square(Cs - Bs), axis=1))
            c = np.sqrt(np.sum(np.square(As - Cs), axis=1))
            s = (a + b + c) * 0.5
            aAreaSquared = s * (s - a) * (s - b) * (s - c)
            aAreaSquared = np.where(aAreaSquared < 0.0000000001, 0.0000000001, aAreaSquared)
            aAreas = np.sqrt(aAreaSquared)
            return aAreas

        aAreas = np.ones(aTriangledVerts.size * 3, dtype='float64').reshape(-1, 3)
        aAreas[:, 0] = getTriangleAreas(aClosests[aTriangledVerts], aSourcePositions[aTriangledVerts, 1],
                                        aSourcePositions[aTriangledVerts, 2])
        aAreas[:, 1] = getTriangleAreas(aClosests[aTriangledVerts], aSourcePositions[aTriangledVerts, 0],
                                        aSourcePositions[aTriangledVerts, 2])
        aAreas[:, 2] = getTriangleAreas(aClosests[aTriangledVerts], aSourcePositions[aTriangledVerts, 0],
                                        aSourcePositions[aTriangledVerts, 1])
        aTotalAreas = np.sum(aAreas, axis=-1)
        aCoords[aTriangledVerts, 0:3] = aAreas / aTotalAreas[:, np.newaxis]

    # lines..
    #
    aLineVerts = np.where(aFaceVertexCounts == 2)[0]
    if aLineVerts.size:
        aVerts = aSourcePositions[aLineVerts, 0:2]
        aRepeated = np.repeat(aClosests[aLineVerts].reshape(-1, 1, 3), 2, axis=1)
        aDiff = aVerts - aRepeated
        aLengths = np.sqrt(np.sum(np.square(aDiff), axis=-1))
        aLengths /= np.sum(aLengths, axis=-1)[:, np.newaxis]
        aCoords[aLineVerts, 0:2] = 1 - aLengths

    # points..
    #
    aPointVerts = np.where(aFaceVertexCounts == 1)[0]
    if aPointVerts.size:
        aCoords[aPointVerts, 0] = 1

    return aCoords



def createMultiplyNode(xInputA, xInputB, sTarget=None, sOperation='multiply', sName='noname', sFullName=None):
    if sFullName == None:
        sFullName = 'MULT_%s' % sName

    sNode = cmds.createNode('multiplyDivide', name=sFullName)

    _connectOrSet(xInputA, '%s.input1X' % sNode)
    _connectOrSet(xInputB, '%s.input2X' % sNode)

    if sOperation != 'multiply':
        iOperation = ['noOperation', 'multiply', 'divide', 'square'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)
    sOutput = '%s.outputX' % sNode
    if sTarget:
        _connectOrSet(sOutput, sTarget)
    return sOutput




def createMultiplyArrayNode(xInputs, sTarget=None, bVector=False, sOperation='multiply', sName='noname', bForce=False):

    sPrev = xInputs[0]
    sNode = None
    for i, xInput in enumerate(xInputs[1:]):
        sNode = cmds.createNode('multiplyDivide', name='MULT_%s' % sName)
        if bVector:
            _connectOrSet(sPrev, '%s.input1' % sNode)
            _connectOrSet(xInput, '%s.input2' % sNode)
        else:
            _connectOrSet(sPrev, '%s.input1X' % sNode)
            _connectOrSet(xInput, '%s.input2X' % sNode)

        if sOperation != 'multiply':
            iOperation = ['noOperation', 'multiply', 'divide', 'square'].index(sOperation)
            cmds.setAttr('%s.operation' % sNode, iOperation)
        if bVector:
            sPrev = '%s.output' % sNode
        else:
            sPrev = '%s.outputX' % sNode

    sOutput = sPrev
    if sTarget:
        if bVector:
            _connectOrSetVector(sOutput, sTarget, bForce=bForce)
        else:
            _connectOrSet(sOutput, sTarget, bForce=bForce)

    return sOutput




def createRangeNode(xValue, xInMin, xInMax, xOutMin, xOutMax, sName='noname', sTarget=None, bOutRangeIsVector=False, bInfinity=False, bForce=False):

    try: fInMin = cmds.getAttr(xInMin)
    except: fInMin = float(xInMin)
    try: fInMax = cmds.getAttr(xInMax)
    except: fInMax = float(xInMax)

    if fInMin > fInMax:
        xInMin, xInMax = xInMax, xInMin
        xOutMin, xOutMax = xOutMax, xOutMin

    if not bInfinity:
        sNode = cmds.createNode('setRange', name='range_%s' % sName)

        if bOutRangeIsVector:
            for sA in ['X','Y','Z']:
                _connectOrSet(xValue, '%s.value%s' % (sNode,sA))
                _connectOrSet(xInMin, '%s.oldMin%s' % (sNode,sA))
                _connectOrSet(xInMax, '%s.oldMax%s' % (sNode,sA))
            _connectOrSetVector(xOutMin, '%s.min' % sNode)
            _connectOrSetVector(xOutMax, '%s.max' % sNode)
            sOutput = '%s.outValue' % sNode
        else:
            _connectOrSet(xValue, '%s.valueX' % sNode)
            _connectOrSet(xInMin, '%s.oldMinX' % sNode)
            _connectOrSet(xInMax, '%s.oldMaxX' % sNode)
            _connectOrSet(xOutMin, '%s.minX' % sNode)
            _connectOrSet(xOutMax, '%s.maxX' % sNode)
            sOutput = '%s.outValueX' % sNode
    else:
        if bOutRangeIsVector:
            raise Exception('bOutRangeIsVector with bInfinity is not supported yet')
        sName = '%sRange' % sName
        sT = fromEquation('(%s-%s) / (%s-%s)' % (xValue, xInMin, xInMax, xInMin), sName=sName)
        sOutput = fromEquation('%s*%s + %s*(1.0-%s)' % (xOutMax, sT, xOutMin, sT), sName=sName)

    _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)
    return sOutput


def filterTarget(sTarget, sFilters):
    for sF in sFilters:
        if sF.upper() in sTarget.upper():
            return True
    return False


def fromEquation(sEquation, sTarget=None, sName='noName', sFullName=None, bDoUnitConversionNodes=False):
    if sFullName == None:
        sMultiplName = 'multiplyDivide_%s_000' % sName
        sPlusName = 'plusMinusAverage_%s_000' % sName
        sConvName = 'conversion_%s_000' % sName
    else:
        sMultiplName = sFullName
        sPlusName = sFullName
        sConvName = sFullName

    # print 'sEquation: ', sEquation
    def createNodes(sEqu):
        sSplits = re.split('\/-|\*-|\*|\/|\+|\-|\^', sEqu)
        # print sEqu, '->', sSplits

        # first clean up minus signs, if the first one is '', then it should be a minus
        #
        if sSplits[0] == '':
            if sEqu[0] == '-':
                try:
                    float(sSplits[1])
                    sSplits[1] = '-%s' % sSplits[1]
                    del sSplits[0]
                except:
                    sSplits[0] = '-1'
                    sEqu = '-1*%s' % sEqu[1:]

        # still on minus signs, if  iPos is -, then it's a combination with * or /
        #
        iPos = 0
        i = 0
        while i < len(sSplits):
            if iPos != 0 and sEqu[iPos] == '-':
                try:
                    float(sSplits[i])
                    sSplits[i] = '-%s' % sSplits[i]
                except:
                    sSplits.insert(i, '-1')
                    sEqu = '%s%s%s' % (sEqu[:iPos + 1], '1*', sEqu[iPos + 1:])

            iPos += len(sSplits[i])
            iPos += 1
            i += 1

        # now go through all the splits, and either multiply or add them
        #
        i = 0
        iPos = -1
        sOperator = '.'
        sPrevAttr = None
        sAdditions = []
        sAdditionOperators = []
        while i < len(sSplits):
            sAttr = sSplits[i]

            if sOperator == '.':
                sPrevAttr = sAttr
            else:
                fConversionFactor = None
                if sOperator in '+-':
                    sAdditions.append(sPrevAttr if sPrevAttr != None else sSplits[i - 1])
                    sAdditionOperators.append(sOperator)
                    sOperator = '.'
                    sPrevAttr = None
                    continue
                elif sOperator == '*':
                    if bDoUnitConversionNodes:
                        try:
                            fConversionFactor = float(sAttr)
                        except:
                            pass
                        if fConversionFactor != None:
                            sConv = cmds.createNode('unitConversion', name=sConvName)
                            _connectOrSet(sPrevAttr, '%s.input' % sConv)
                            cmds.setAttr('%s.conversionFactor' % sConv,
                                         fConversionFactor)  # can only be set and not connected
                            sPrevAttr = '%s.output' % sConv

                if fConversionFactor == None and sOperator in '*/^':
                    sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True, name=sMultiplName)
                    _connectOrSet(sPrevAttr, '%s.input1X' % sMultipl)
                    _connectOrSet(sAttr, '%s.input2X' % sMultipl)
                    if sOperator == '/':
                        cmds.setAttr('%s.operation' % sMultipl, 2)
                    elif sOperator == '^':
                        cmds.setAttr('%s.operation' % sMultipl, 3)
                    sPrevAttr = '%s.outputX' % sMultipl

            iPos += len(sSplits[i]) + 1
            if iPos < len(sEqu):
                sOperator = sEqu[iPos]
                i += 1
            else:
                sAdditions.append(sAttr if sPrevAttr == None else sPrevAttr)
                break

        # we collected additions and additionsOperators before, now let's add them together
        #
        if len(sAdditions) == 1:
            return sAdditions[0]
        else:
            sPlusMinus = cmds.createNode('plusMinusAverage', name=sPlusName)
            # first check if we need to make minus or plus
            bMinus, bPlus = False, False
            for sOp in sAdditionOperators:
                if sOp == '+':
                    bPlus = True
                elif sOp == '-':
                    bMinus = True
            if bMinus:
                if not bPlus:
                    cmds.setAttr('%s.operation' % sPlusMinus, 2)
                elif bPlus:  # if we have mixed minus and plus, we'll have to multiply the minus ones by -1
                    for i in range(len(sAdditionOperators)):
                        if sAdditionOperators[i] == '-':
                            try:
                                sAdditions[i + 1] = -float(sAdditions[i + 1])
                            except:
                                sAdditions[i + 1] = createNodes('-1*%s' % sAdditions[i + 1])
            # finally connect the parts to the plus node
            for i, sAddition in enumerate(sAdditions):
                _connectOrSet(sAddition, '%s.input1D[%d]' % (sPlusMinus, i))
            sOutput = '%s.output1D' % sPlusMinus
            return sOutput

    def traverseParenthesis(sEqu, sSplits):
        sEquNew = ''
        i = 0
        iPos = 0
        while True:
            if sSplits[i]:
                sEquNew += sSplits[i]
            iPos += len(sSplits[i])
            if iPos >= len(sEqu):
                break
            iP = sEqu[iPos]
            iPos += 1
            i += 1
            if iP == '(':
                sNewOutput, i2, iPos2 = traverseParenthesis(sEqu[iPos:], sSplits[i:])
                i += i2
                iPos += iPos2
                sEquNew += sNewOutput
            elif iP == ')':
                sOutput = createNodes(sEquNew)
                return sOutput, i, iPos

        sLastPart = createNodes(sEquNew)
        return sLastPart

    sEquationStripped = sEquation.replace(' ', '')
    sEquationStripped = sEquationStripped.replace('+-', '-').replace('--', '+').replace('*+', '*')

    # print 'sEquationStripped: ', sEquationStripped

    sSplits = re.split('\(|\)', sEquationStripped)
    sRet = traverseParenthesis(sEquationStripped, sSplits)

    if sTarget:
        if isinstance(sTarget, (list, tuple)):
            for sT in sTarget:
                cmds.connectAttr(sRet, sT)
        else:
            cmds.connectAttr(sRet, sTarget)

    return sRet



def _turnOffDeformerAndSave(sDeformer, dSaveDict={}):
    if sDeformer in dSaveDict:
        return

    sEnvelope = '%s.envelope' % sDeformer
    sConns = cmds.listConnections(sEnvelope, s=True, d=False, p=True)
    if sConns:
        dSaveDict[sDeformer] = sConns[0]
        cmds.disconnectAttr(sConns[0], sEnvelope)
    else:
        dSaveDict[sDeformer] = cmds.getAttr(sEnvelope)

    cmds.setAttr(sEnvelope, 0)



def invertComboShape(sSculpt, sSkin, sComboBlendShape, sInvertName=''):
    if not cmds.objExists(sSculpt):
        raise Exception('sculpt shape %s doesn\'t exist' % sSculpt)

    if not sInvertName:
        if sSculpt.endswith('_posed'):
            replaceStringEnd(sSculpt, '_posed', '_inverted')

    pSculpt = patch.patchFromName(sSculpt)
    pSkin = patch.patchFromName(sSkin)

    if pSculpt.getTotalCount() != pSkin.getTotalCount():
        cmds.warning('%s and %s don\'t have the same vertex count (%d -> %d)' % (
        sSculpt, sSkin, pSculpt.getTotalCount(), pSkin.getTotalCount()))

    aSculptPoints = pSculpt.getPoints()

    cmds.setAttr('%s.envelope' % sComboBlendShape, False)
    aDefaultPoints = pSkin.getPoints()
    cmds.setAttr('%s.envelope' % sComboBlendShape, True)
    aBlendShapePoints = pSkin.getPoints()

    aNewPoints = aDefaultPoints + (aSculptPoints - aBlendShapePoints)

    sDupl = cmds.duplicate(sSkin, name=sInvertName)[0]
    patch.patchFromName(sDupl).setPoints(aNewPoints)
    try:
        cmds.parent(sDupl, w=True)
    except:
        pass

    freezeGeo(sDupl)
    return sDupl






def freezeGeo(sMeshTransform):
    cmds.delete(sMeshTransform, ch=True)
    sAllShapes = cmds.listRelatives(sMeshTransform, s=True, f=True) or []
    sNoIntermShapes = cmds.listRelatives(sMeshTransform, s=True, ni=True, f=True) or []
    sShapes = set(sAllShapes) - set(sNoIntermShapes)
    if sShapes:
        cmds.delete(list(sShapes))



def preDeformationBlendshapeHack(sTargets, sMesh, **kwargs):

    sAllDeformers = listAllDeformers(sMesh)

    if sTargets:
        sBlendShapes = cmds.blendShape(sTargets, sMesh, **kwargs)
    else:
        sBlendShapes = cmds.blendShape(sMesh, **kwargs)
    if sAllDeformers:
        cmds.reorderDeformers(sAllDeformers[-1], sBlendShapes[0], sMesh)

    return sBlendShapes




def replaceStringStart(sText, sSearch, sReplace):
    if sText.startswith(sSearch):
        return '%s%s' % (sReplace, sText[len(sSearch):])
    else:
        return sText

def replaceStringEnd(sText, sSearch, sReplace):
    if sText.endswith(sSearch):
        return '%s%s' % (sText[:-len(sSearch)], sReplace)
    else:
        return sText








def isNone(xVariable):
    return isinstance(xVariable, type(None))


def projectToRange(fValue, fInMin, fInMax, fOutMin, fOutMax):
    if fInMin > fInMax:
        fInMin, fInMax = fInMax, fInMin
        fOutMin, fOutMax = fOutMax, fOutMin

    if fValue <= fInMin:
        return fOutMin
    elif fValue >= fInMax:
        return fOutMax
    else:
        fT = (fValue-fInMin) / float(fInMax-fInMin)
        return fOutMax * fT + fOutMin * (1.0-fT)


def qBarycentric(qPoint, qA, qB, qC):
    ab = qB - qA
    ac = qC - qA
    ap = qPoint - qA

    nac = QtCore.QPointF(qA.y() - qC.y(), qC.x() - qA.x())
    nab = QtCore.QPointF(qA.y() - qB.y(), qB.x() - qA.x())

    bary_beta = QtCore.QPointF.dotProduct(ap, nac) / QtCore.QPointF.dotProduct(ab, nac)
    bary_gamma = QtCore.QPointF.dotProduct(ap, nab) / QtCore.QPointF.dotProduct(ac, nab)

    if abs(bary_beta) < 0.0001:
        bary_beta = 0.0
    if abs(bary_gamma) < 0.0001:
        bary_gamma = 0.0
    bary_alpha = 1.000 - bary_beta - bary_gamma

    if abs(bary_alpha) < 0.0001:
        bary_alpha = 0.0
    return int(bary_alpha*100.0), int(bary_beta*100.0), int(bary_gamma*100.0)



def getSelectedPatches(bAlwaysReturnFullGeometry=False):
    try:
        mRichSelection = OpenMaya2.MGlobal.getRichSelection()
    except:
        return []
    mSelection = mRichSelection.getSelection()
    selection = []
    mComponentPatches = []

    # mesh verts:
    #
    for kType, PatchClass in [(OpenMaya2.MFn.kMeshVertComponent, patch.MeshPatch),
                              (OpenMaya2.MFn.kCurveCVComponent, patch.CurvePatch)]:

        iter = OpenMaya2.MItSelectionList(mSelection, kType)
        while not iter.isDone():
            mDagPath, component = iter.getComponent()
            fnComp = OpenMaya2.MFnSingleIndexedComponent(component)
            mDagPath.pop()

            if bAlwaysReturnFullGeometry:
                aIds = None
            else:
                aIds = np.array([fnComp.element(i) for i in range(fnComp.elementCount)], dtype=int)

            if fnComp.hasWeights:
                aSofts = np.array([fnComp.weight(i).influence for i in range(fnComp.elementCount)], dtype='float64')
            else:
                aSofts = None

            mShape = mDagPath.extendToShape()
            selection.append(PatchClass(mShape, aIds, aSofts))
            mComponentPatches.append(mShape)
            iter.next()

    # nurbs surface cvs:
    #
    iter = OpenMaya2.MItSelectionList(mSelection, OpenMaya2.MFn.kSurfaceCVComponent)
    while not iter.isDone():
        mDagPath, component = iter.getComponent()
        fnComp = OpenMaya2.MFnDoubleIndexedComponent(component)
        mDagPath.pop()

        aCvs = np.array(fnComp.getElements(), dtype=int)
        if fnComp.hasWeights:
            aSofts = np.array([fnComp.weight(i).influence for i in range(fnComp.elementCount)], dtype='float64')
        else:
            aSofts = None

        selection.append(patch.SurfacePatch(mDagPath.extendToShape(), aCvs=aCvs, aSofts=aSofts))

        iter.next()

    # Whole Geometries
    #
    xTypes = [('mesh', patch.MeshPatch), ('nurbsCurve', patch.CurvePatch), ('nurbsSurface', patch.SurfacePatch)]
    for sType, PatchClass in xTypes:
        for sShape in cmds.ls(sl=True, et=sType):
            selection.append(PatchClass(getDagPath(sShape), None, None))
    for sTransform in cmds.ls(sl=True, et='transform'):
        for sType, PatchClass in xTypes:
            sShapes = cmds.listRelatives(sTransform, typ=sType)
            if sShapes:
                selection.append(PatchClass(getDagPath(sShapes[0]), None, None))


    return selection



def createMayaStringFromList(iIdList, bIdListIsAlreadySorted=False):
    if not bIdListIsAlreadySorted:
        iIdList.sort()

    iArrayLength = len(iIdList)
    iNextFace = -1
    i = 0
    iIslandStarts = []
    while i < iArrayLength:
        iIslandStarts.append(int(i))
        for k in range(i,iArrayLength,1):
            if iIdList[k] == iNextFace or iNextFace == -1:
                iNextFace = iIdList[k] + 1
                i += 1
            else:
                break
        iNextFace = -1

    iIslandStarts.append(iArrayLength)
    sStrings = []
    for i in range(len(iIslandStarts)-1):
        iCurrent = iIdList[iIslandStarts[i]]
        iNext = iIdList[iIslandStarts[i+1]-1]
        if iCurrent != iNext:
            sStrings.append('%d:%d' % (iCurrent, iNext))
        else:
            sStrings.append('%d' % (iCurrent))

    return sStrings


def mayaCompStringsToList(sComps, bReturnNumpy=False):
    sComps = toList(sComps)
    xList = []
    for sC in sComps:
        sInds = sC.split('[')[-1]
        if sInds.endswith(']'):
            sInds = sInds[:-1]
        if ':' in sInds:
            sSplit = sInds.split(':')
            xList += range(int(sSplit[0]), int(sSplit[1])+1, 1)
        else:
            xList.append(int(sInds))
    xList.sort()
    if bReturnNumpy:
        return np.array(xList, dtype=int)
    else:
        return xList



def getUniqueName(sName, bRemoveIllegalCharacters=True):

    if bRemoveIllegalCharacters:
        sName = sName.replace("'", "")

    if not cmds.objExists(sName):
        return sName

    sName, iNumber = getNumberAtEnd(sName)
    while True:
        iNumber += 1
        sNewName = '%s%d' % (sName, iNumber)
        if not cmds.objExists(sNewName):
            return sNewName



def createRivetTransform(sVertex, sTarget, sParent=None):

    sEdge = cmds.ls(cmds.polyListComponentConversion(sVertex, toEdge=True), flatten=True)[0]
    sCurve = cmds.duplicateCurve(sEdge, n=getUniqueName('curveOnMesh_0'))[0]
    if sParent:
        cmds.parent(sCurve, sParent)

    sOutputTranslation = getVertexTranslationOnCurve(sCurve, sVertex, bEnd=False)
    _connectTargetIfNotNone('%s.t' % sTarget, sOutputTranslation, bForce=True)

    sMessageAttr = addAttr(sTarget, ln='curve', at='message', bReturnIfExists=True)
    sConns = cmds.listConnections(sMessageAttr)
    if sConns:
        cmds.delete(sConns)
    cmds.connectAttr('%s.message' % sCurve, sMessageAttr)



def getDistance(fPosA, fPosB):
    fLocal = [(a-b)*(a-b) for a,b in zip(fPosA,fPosB)]
    fDistance = math.sqrt(fLocal[0] + fLocal[1] + fLocal[2])
    return fDistance




def getVertexTranslationOnCurve(sCurve, sVertex, bEnd=False):
    ffPositions = [cmds.xform('%s.cv[0]' % sCurve, q=True, ws=True, t=True),
                   cmds.xform('%s.cv[1]' % sCurve, q=True, ws=True, t=True)]

    fPos = cmds.xform(sVertex, q=True, ws=True, t=True)
    fDistance0 = getDistance(fPos, ffPositions[0])
    fDistance1 = getDistance(fPos, ffPositions[1])
    if fDistance1 < fDistance0:
        fParam = 1.0
    else:
        fParam = 0.0
    if bEnd:
        fParam = 1.0 - fParam

    return createPointInfoNode(sCurve, fParam=fParam, bFakePercentage=True)[1]



def createPointInfoNode(sCurve, fParam=0.0, sTargetPos=None, sName='noname', bFakePercentage=False):
    sNode = cmds.createNode('pointOnCurveInfo', n='pointOnCurveInfo_%s' % sName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.inputCurve' % sNode)
    _connectOrSet(fParam, '%s.parameter' % sNode)
    if bFakePercentage:
        cmds.setAttr('%s.turnOnPercentage' % sNode, True)
    if sTargetPos:
        cmds.connectAttr('%s.position' % sNode, sTargetPos)

    return sNode, '%s.position' % sNode






# def getDeformerMovedFromAllVerts(sMesh):
#
#     iVertCount = cmds.polyEvaluate(sMesh, vertex=True)
#     sTweaks = [sN for sN in cmds.listHistory(sMesh) if cmds.objectType(sN) == 'tweak']
#     cmds.delete(sTweaks)
#     sNewTweak = cmds.deformer(sMesh, type='tweak', foc=True)[0]
#     sTweakAttr = '%s.vlist[0].vertex' % sNewTweak
#
#
#     aIds = np.arange(iVertCount)
#     aaaMoveResults = np.zeros((3, aIds.size, 3), dtype='float64')
#     aMoveValues = np.zeros(len(aIds)*3, dtype='float64')
#     aIdsX = np.arange(iVertCount) * 3
#
#     for a in [0, 1, 2]:
#         aMoveValues[:] = 0.0
#         aMoveValues[aIdsX+a] = 1.0
#         cmds.setAttr('%s[0:%d]' % (sTweakAttr, iVertCount - 1), *list(aMoveValues))
#         aaaMoveResults[a] = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True)).reshape(-1,3)
#
#     sTweaks = [sN for sN in cmds.listHistory(sMesh) if cmds.objectType(sN) == 'tweak']
#     cmds.delete(sTweaks)
#
#     return aaaMoveResults



def exportObj(sMesh, sFile):
    sDupl = cmds.duplicate(sMesh, n='%s_obj' % sMesh, renameChildren=True)[0]
    cmds.select(sDupl)
    cmds.file(sFile, pr=1, typ='OBJexport', es=1, force=True, constructionHistory=False)
    cmds.delete(sDupl)




def getJsonContent(sFile):
    print('loading json file %s...' % sFile)
    with open(sFile) as file:
        xContent = json.load(file)
    return xContent


def setJsonContent(sFile, dContent):
    with open(sFile, 'w') as outfile:
        json.dump(dContent, outfile, indent=2)



def getClosestVertex(sMesh, fPoint):
    mMesh = getDagPath(sMesh)
    mPoint = OpenMaya2.MPoint(fPoint)
    meshFn = OpenMaya2.MFnMesh(mMesh)
    mClosestPoint, iFace = meshFn.getClosestPoint(mPoint, space=OpenMaya2.MSpace.kWorld)
    meshIter = OpenMaya2.MItMeshPolygon(mMesh)
    meshIter.setIndex(iFace)
    iFaceVerts = meshIter.getVertices()
    aaPoints = np.array([cmds.xform('%s.vtx[%d]' % (sMesh,iVert), q=True, ws=True, t=True) for iVert in iFaceVerts], dtype='float64')
    aClosestPoint = np.array(mClosestPoint, dtype='float64')[0:3]
    aaDiffs = aaPoints - aClosestPoint
    aLengths = np.linalg.norm(aaDiffs, axis=-1)
    iIndex = np.argmin(aLengths)
    return iFaceVerts[iIndex]



# not tested yet
def disconnectAttr(sAttr):
    sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
    if sConns:
        cmds.disconnectAttr(sConns[0], sAttr)



def boundingBoxDiagLength(aPoints):
    a = np.array([[np.min(aPoints[:, 0]), np.min(aPoints[:, 1]), np.min(aPoints[:, 2])],
                  [np.max(aPoints[:, 0]), np.max(aPoints[:, 1]), np.max(aPoints[:, 2])]],
                 dtype='float64')
    return np.linalg.norm(a[1] - a[0])



def bSpline4(fFourValues, iCount=5, aValues=None, bReachLengthMinusOne=False):

    if isinstance(aValues,np.ndarray):
        a = aValues
    elif isinstance(aValues, (list,tuple)):
        a = np.array(aValues, dtype='float64')
    else:
        if bReachLengthMinusOne:
            a = np.linspace(0.0, float(iCount-1)/iCount, iCount)
        else:
            a = np.linspace(0.0, 1.0, iCount)
    aResult =   fFourValues[0] * np.power(1-a, 3) + \
                fFourValues[1] * 3 * a * np.power(1-a,2) + \
                fFourValues[2] * 3 * np.power(a,2) * (1-a) + \
                fFourValues[3] * np.power(a, 3)
    return aResult


def parentToWorld(sObj):
    if not isNone(cmds.listRelatives(sObj, p=True)):
        cmds.parent(sObj, w=True)


def undoPluginLoaded():
    return True if cmds.pluginInfo('kt_cmdUndo.py', query=True, command=True) else False



def getMainSkinCluster(sGeo, _report=None):

    sSkinClusters = listAllDeformers(sGeo, sFilterTypes=['skinCluster'])

    if sSkinClusters:
        iCounts = [len(sS.split('__')) for sS in sSkinClusters]
        iInd = np.argmin(iCounts)
        return sSkinClusters[iInd]
    else:
        return None
