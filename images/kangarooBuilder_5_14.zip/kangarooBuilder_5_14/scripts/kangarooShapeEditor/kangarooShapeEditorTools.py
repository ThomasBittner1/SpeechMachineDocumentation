###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMayaAnim as OpenMayaAnim2
import maya.api.OpenMaya as OpenMaya2
from collections import OrderedDict, defaultdict
import kangarooTools.utilsQt as utilsQt

import numpy as np
import os
import csv
import kangarooTools.patch as patch
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.geometry as geometry
# try:
#     import pymel.core as pm
# except:
#     cmds.warning('cannot import pymel')


import kangarooShapeEditor.kangarooShapeEditorLibrary as library # get rid of this??


def wireWarp(sCurves, sBlendShape, sTargets, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens, bCheckForFaceCombos=True, dRigPoseAttrs=None):

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

    sTargets.sort(key=lambda x: x.count('_'))
    dTargetWeights = {sT:cmds.getAttr('%s.%s' % (sBlendShape, sT)) for sT in sTargets}

    dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), dRigPoseAttrs=dRigPoseAttrs, bSkipComboTargets=bCheckForFaceCombos)

    cmds.undoInfo(openChunk=True)
    sSelBefore = cmds.ls(sl=True)
    try:
        qStatusWindow = utilsQt.QStatusWindow('Wire Warping')
        qStatusWindow.setCount(len(sTargets))

        pSelection = patch.getSelectedPatches()
        sMeshes = [pObj.getTransformName() for pObj in pSelection]

        sMeshesDupls = [library.duplicateGeoClean(sM) for sM in sMeshes]

        if len(sCurves) > 1:
            iiCurveIndices = []
            for sMesh in sMeshes:
                aPoints = patch.patchFromName(sMesh).getPoints()
                aaDistances = np.zeros((len(aPoints), len(sCurves)), dtype='float64')
                for c,sCurve in enumerate(sCurves):
                    fnCurve = OpenMaya2.MFnNurbsCurve(library.getDagPath(sCurve))
                    for v,aP in enumerate(aPoints):
                        mClosestP = fnCurve.closestPoint(OpenMaya2.MPoint(aP))[0]
                        aClosestP = np.array(mClosestP, dtype='float64')[:3]
                        aDiff = aClosestP-aP
                        aaDistances[v,c] = np.linalg.norm(aDiff)

                iiCurveIndices.append(np.argmin(aaDistances, axis=1))

        sBaseWires = []
        sWireNodes = []
        for m,sDupl in enumerate(sMeshesDupls):
            for c,sCurve in enumerate(sCurves):
                sWireResult = cmds.wire(sDupl, w=sCurve, li=1.0, dds=[0,10000], n='wire_%s' % sCurve)
                sWireNodes.append(sWireResult[0])
                print ('sWireResult: ', sWireResult)
                sBaseWires += cmds.listConnections('%s.baseWire' % sWireResult[0], s=True, d=False)
                cmds.setAttr('%s.rotation' % sWireResult[0], 0.0)

                if len(sCurves) > 1:
                    aWeights = np.zeros(len(iiCurveIndices[m]), dtype='float64')
                    aWeights[iiCurveIndices[m] == c] = 1.0
                    cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sWireResult[0], cmds.polyEvaluate(sDupl, vertex=True)-1), *list(aWeights))


            for sT in sTargets:
                qStatusWindow.increment()

                xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)

                for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):

                    [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]
                    for m,pMesh in enumerate(pSelection):
                        sTemp = cmds.duplicate(sMeshesDupls[m], n='temp')[0]

                        aWarpedPoints = patch.patchFromName(sTemp).getAllPoints()
                        aCurrentPoints = pMesh.getAllPoints()
                        aNewPoints = np.copy(aCurrentPoints)
                        if library.isNone(pMesh.aSofts):
                            aNewPoints[pMesh.aIds] = aWarpedPoints[pMesh.aIds]
                        else:
                            aSofts = pMesh.aSofts[:,np.newaxis]
                            aNewPoints[pMesh.aIds] = aWarpedPoints[pMesh.aIds] * aSofts + aCurrentPoints[pMesh.aIds] * (1.0-aSofts)

                        cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)
                        patch.patchFromName(pMesh.getTransformName()).setPoints(aNewPoints)
                        cmds.sculptTarget(sBlendShape, e=True, t=-1)

                        cmds.delete(sTemp)
                [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]

        nodes.deleteConnectionsAndItself3(utils.flattenedList([sWireNodes, sBaseWires, sMeshesDupls]))
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        for sAttr, xValue in list(dWeightsBefore.items()):
            library._connectOrSet(xValue, sAttr)
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)
        qStatusWindow.end()

# cmds.transferAttributes('a', 'b', transferPositions=1, sampleSpace=3) # 'b' will be changed
def warp(sMaster, sBlendShape, sTargets, bRigid=True, bUvs=True, sMeshPoses=None, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens, bCheckForFaceCombos=True, dRigPoseAttrs=None):

    bWrapInDefaultPose = isinstance(sMeshPoses, type(None))

    if not sTargets:
        raise Exception('no targets selected')

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

    sTargets.sort(key=lambda x: x.count('_'))
    dTargetWeights = {sT:cmds.getAttr('%s.%s' % (sBlendShape, sT)) for sT in sTargets}

    sSelBefore = cmds.ls(sl=True)
    dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), dRigPoseAttrs=dRigPoseAttrs, bSkipComboTargets=bCheckForFaceCombos)

    pSelection = patch.getSelectedPatches()
    sMeshes = [pObj.getTransformName() for pObj in pSelection]

    cmds.undoInfo(openChunk=True)
    try:
        qStatusWindow = utilsQt.QStatusWindow('Rigid Warping' if bRigid else 'Warping')
        qStatusWindow.setCount(len(sTargets))
        sMeshesDupls = [library.duplicateGeoClean(sM) for sM in sMeshes]

        if bUvs:
            aaDifferencesInDefault = []
            for m, pMesh in enumerate(pSelection):
                sTempDefault = cmds.duplicate(sMeshesDupls[m], n='defaulttemp___')[0]
                aDefaultPoints = patch.patchFromName(sMeshesDupls[m]).getPoints()
                cmds.transferAttributes(sMaster, sTempDefault, transferPositions=1, sampleSpace=3)
                aTransferredPoints = patch.patchFromName(sTempDefault).getPoints()
                cmds.delete(sTempDefault)
                aaDifferencesInDefault.append(aTransferredPoints-aDefaultPoints)

        if bRigid or bUvs:
            for sT in sTargets:
                qStatusWindow.increment()
                sDefaultModel = cmds.duplicate(sMaster, n='temp')[0]
                xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)
                for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):

                    [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]
                    cmds.refresh()

                    for m,pMesh in enumerate(pSelection):
                        sTemp = cmds.duplicate(sMeshesDupls[m], n='temp___')[0]

                        if bRigid:
                            geometry.warpRigidIslands(sTemp, sDefaultModel, sMaster)
                            aWarpedPoints = patch.patchFromName(sTemp).getAllPoints()
                        elif bUvs:
                            cmds.transferAttributes(sMaster, sTemp, transferPositions=1, sampleSpace=3) # gives unwanted offsets
                            aWarpedPoints = patch.patchFromName(sTemp).getAllPoints()
                            aWarpedPoints -= aaDifferencesInDefault[m]

                        cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)
                        aCurrentPoints = pMesh.getAllPoints()
                        aNewPoints = np.copy(aCurrentPoints)
                        if library.isNone(pMesh.aSofts):
                            aNewPoints[pMesh.aIds] = aWarpedPoints[pMesh.aIds]
                        else:
                            aSofts = pMesh.aSofts[:,np.newaxis]
                            aNewPoints[pMesh.aIds] = aWarpedPoints[pMesh.aIds] * aSofts + aCurrentPoints[pMesh.aIds] * (1.0-aSofts)

                        patch.patchFromName(pMesh.getTransformName()).setPoints(aNewPoints)
                        cmds.sculptTarget(sBlendShape, e=True, t=-1)

                        cmds.delete(sTemp)
                cmds.delete(sDefaultModel)

                [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]

        else:
            if bWrapInDefaultPose:
                sUnorderedWraps, sBase = library.createWrap(sMeshesDupls, sMaster)
            else:
                for sAttr,xValue in list(dWeightsBefore.items()):
                    fValue = cmds.getAttr(xValue) if library.isStringOrUnicode(xValue) else xValue
                    cmds.setAttr(sAttr, fValue)
                sTempBlendShapes = []
                for sMesh, sPoseMesh in zip(sMeshesDupls, sMeshPoses):
                    sTempBlendShapes.append(cmds.blendShape(sPoseMesh, sMesh, w=[0,1])[0])
                sUnorderedWraps, sBase = library.createWrap(sMeshesDupls, sMaster)

                aPoints = patch.patchFromName(sMaster).getAllPoints()
                patch.patchFromName(sBase).setPoints(aPoints)

                for sAttr,xValue in list(dWeightsBefore.items()):
                    cmds.setAttr(sAttr, 0)

            for sT in sTargets:
                qStatusWindow.increment()
                xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)

                for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):
                    [cmds.setAttr(sAttr,fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]

                    for m,pMesh in enumerate(pSelection):
                        sTemp = cmds.duplicate(sMeshesDupls[m], n='temp')[0]
                        aWarpedPoints = patch.patchFromName(sTemp).getAllPoints()
                        aCurrentPoints = pMesh.getAllPoints()
                        aNewPoints = np.copy(aCurrentPoints)
                        if library.isNone(pMesh.aSofts):
                            aNewPoints[pMesh.aIds] = aWarpedPoints[pMesh.aIds]
                        else:
                            aSofts = pMesh.aSofts[:,np.newaxis]
                            aNewPoints[pMesh.aIds] = aWarpedPoints[pMesh.aIds] * aSofts + aCurrentPoints[pMesh.aIds] * (1.0-aSofts)

                        cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)
                        patch.patchFromName(pMesh.getTransformName()).setPoints(aNewPoints)
                        cmds.sculptTarget(sBlendShape, e=True, t=-1)
                        cmds.delete(sTemp)
                [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]

            cmds.delete(sUnorderedWraps, sBase)
        cmds.delete(sMeshesDupls)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.select(sSelBefore)
        reconnectTargets(dWeightsBefore)
        cmds.undoInfo(closeChunk=True)
        qStatusWindow.end()


def blendIds(sMaster, sBlendShape, sTargets, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens, bCheckForFaceCombos=True, bTurnOffOtherDeformers=False, dRigPoseAttrs=None):

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())

    sTargets.sort(key=lambda x: x.count('_'))
    dTargetWeights = {sT:cmds.getAttr('%s.%s' % (sBlendShape, sT)) for sT in sTargets}

    pSelection = patch.getSelectedPatches()
    pMaster = patch.patchFromName(sMaster)

    dOtherDeformers = {}
    if bTurnOffOtherDeformers:
        for m, pMesh in enumerate(pSelection):
            sOtherDeformers = library.listAllDeformers(pMesh.getTransformName(), sIgnoreTypes=['tweak', 'skinCluster'])
            dOtherDeformers[pMesh.getTransformName()] = [sD for sD in sOtherDeformers if sD != sBlendShape]



    cmds.undoInfo(openChunk=True)
    try:
        sSelBefore = cmds.ls(sl=True)
        dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), bSkipComboTargets=bCheckForFaceCombos)

        qStatusWindow = utilsQt.QStatusWindow('Blend Ids')
        qStatusWindow.setCount(len(sTargets))

        for sT in sTargets:
            qStatusWindow.increment()
            xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)
            for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):
                cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)
                [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]
                aMasterPoints = pMaster.getPoints()
                for m,pMesh in enumerate(pSelection):
                    aNewPoints = pMesh.getAllPoints()
                    if library.isNone(pMesh.aSofts):
                        aNewPoints[pMesh.aIds] = aMasterPoints[pMesh.aIds]
                    else:
                        aSofts = pMesh.aSofts[:, np.newaxis]
                        aNewPoints[pMesh.aIds] = aMasterPoints[pMesh.aIds] * aSofts + aNewPoints[pMesh.aIds] * (1.0 - aSofts)

                    if bTurnOffOtherDeformers:
                        dDeformersBefore = {}
                        for sD in dOtherDeformers[pMesh.getTransformName()]:
                            dDeformersBefore[sD] = cmds.getAttr('%s.envelope' % sD)
                            cmds.setAttr('%s.envelope' % sD, 0.0)

                    patch.patchFromName(pMesh.getTransformName()).setPoints(aNewPoints)

                    if bTurnOffOtherDeformers:
                        [cmds.setAttr('%s.envelope' % sD, fEnvelope) for sD, fEnvelope in dDeformersBefore.items()]
            [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.sculptTarget(sBlendShape, e=True, t=-1)
        reconnectTargets(dWeightsBefore)
        cmds.select(sSelBefore)
        qStatusWindow.end()
        cmds.undoInfo(closeChunk=True)


def smoothVertices(sBlendShape, sTargets, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens, iIterations=1, bCheckForFaceCombos=True, dRigPoseAttrs=None):

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())

    sTargets.sort(key=lambda x: x.count('_'))
    dTargetWeights = {sT:cmds.getAttr('%s.%s' % (sBlendShape, sT)) for sT in sTargets}

    pSelection = patch.getSelectedPatches()
    cmds.undoInfo(openChunk=True)
    try:
        dWeightsBefore = disconnectAndResetTargets(sBlendShape, dAllTargets.keys())
        qStatusWindow = utilsQt.QStatusWindow('Smooth')
        qStatusWindow.setCount(len(sTargets))
        for sT in sTargets:
            qStatusWindow.increment()
            xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)
            for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):
                [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]

                for m,pMesh in enumerate(pSelection):
                    cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)
                    geometry.smoothVertices(pMesh, iIterations=int(iIterations))

            [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]


    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.sculptTarget(sBlendShape, e=True, t=-1)
        reconnectTargets(dWeightsBefore)
        cmds.undoInfo(closeChunk=True)
        qStatusWindow.end()

def resetTargetDeltas(sBlendShape, sTargets, bCheckForFaceCombos=True, dRigPoseAttrs=None):

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())

    sTargets.sort(key=lambda x: x.count('_'))

    sSelBefore = cmds.ls(sl=True)
    dWeightsBefore = {}
    for sT in list(dAllTargets.keys()):
        if '_' not in sT:
            sAttr = '%s.%s' % (sBlendShape, sT)
            sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
            if sConns:
                dWeightsBefore[sAttr] = sConns[0]
                cmds.disconnectAttr(sConns[0], sAttr)
            else:
                dWeightsBefore[sAttr] = cmds.getAttr(sAttr)
            cmds.setAttr(sAttr, 0.0)


    aaBasePoints = []

    pSelection = patch.getSelectedPatches()
    sMeshes = [pObj.getTransformName() for pObj in pSelection]

    for m, sMesh in enumerate(sMeshes):
        pPatch = patch.patchFromName(sMesh)
        aaBasePoints.append(pPatch.getPoints())


    cmds.undoInfo(openChunk=True)
    try:
        sMeshesDupls = [library.duplicateGeoClean(sM) for sM in sMeshes]

        for sT in sTargets:
            xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)

            [cmds.setAttr(sAttr, fPerc) for sAttr,fPerc in xSetTargetAttrs]

            for m,pMesh in enumerate(pSelection):

                aCurrentPoints = pMesh.getAllPoints()
                aNewPoints = np.copy(aCurrentPoints)

                if library.isNone(pMesh.aSofts):
                    aNewPoints[pMesh.aIds] = aaBasePoints[m][pMesh.aIds]
                else:
                    aSofts = pMesh.aSofts[:, np.newaxis]
                    aNewPoints[pMesh.aIds] = aaBasePoints[m][pMesh.aIds] * aSofts + aCurrentPoints[pMesh.aIds] * (1.0 - aSofts)

                cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT])
                patch.patchFromName(pMesh.getTransformName()).setPoints(aNewPoints)
                cmds.sculptTarget(sBlendShape, e=True, t=-1)
            [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]

        cmds.delete(sMeshesDupls)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.select(sSelBefore)
        for sTargetAttr, xValue in list(dWeightsBefore.items()):
            library._connectOrSet(xValue, sTargetAttr)
        cmds.undoInfo(closeChunk=True)


def getSubTargets(sBlendShape, iTargetIndex, fCurrentTargetWeight, iInbetweensMode):
    # print ('fCurrentTargetWeight: ',fCurrentTargetWeight)
    if iInbetweensMode == library.InbetweenModes.MainTargetAndInbetweens:
        fSubTargets = blendShapes.getInbetweenFloats(sBlendShape, iTargetIndex) + [1.0]
    elif iInbetweensMode == library.InbetweenModes.OnlyMainTarget:
        fSubTargets = [1.0]
    elif iInbetweensMode == library.InbetweenModes.OnlyClosestInbetween:
        fAllInbetweens = blendShapes.getInbetweenFloats(sBlendShape, iTargetIndex)
        # print ('fAllInbetweens: ', fAllInbetweens)
        iInbetweenIndex = np.argmin(abs(np.array(fAllInbetweens, dtype='float64') - fCurrentTargetWeight))
        fSubTargets = [fAllInbetweens[iInbetweenIndex]]
    return fSubTargets

def snapSelectedMeshes(sMaster, sBlendShape, sTargets, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens, bCheckForFaceCombos=True, dRigPoseAttrs=None):

    print ('sTargets: ', sTargets)
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())

    sTargets.sort(key=lambda x: x.count('_'))
    dTargetWeights = {sT:cmds.getAttr('%s.%s' % (sBlendShape, sT)) for sT in sTargets}

    sSelBefore = cmds.ls(sl=True)
    dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), dRigPoseAttrs=dRigPoseAttrs, bSkipComboTargets=bCheckForFaceCombos)

    pSelection = patch.getSelectedPatches()
    sBlendShapeMeshes = getMeshesFromBlendShape(sBlendShape)
    sSkip = []

    cmds.undoInfo(openChunk=True)
    try:
        for sT in sTargets:
            xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos, dAdditionalSetAttrs=dRigPoseAttrs)
            for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):
                [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]
                for pMesh in pSelection:
                    if pMesh.getTransformName() not in sBlendShapeMeshes:
                        sSkip.append(pMesh.getTransformName())
                        continue
                    aCurrentPoints = pMesh.getAllPoints()
                    aClosestPoints = np.array(cmds.kt_findClosestPoints(fromMesh=pMesh.getName(), toMesh=sMaster), dtype='float64').reshape(-1, 3)

                    aNewPoints = np.copy(aCurrentPoints)
                    if library.isNone(pMesh.aSofts):
                        aNewPoints[pMesh.aIds] = aClosestPoints[pMesh.aIds]
                    else:
                        aSofts = pMesh.aSofts[:,np.newaxis]
                        aNewPoints[pMesh.aIds] = aClosestPoints[pMesh.aIds] * aSofts + aCurrentPoints[pMesh.aIds] * (1.0-aSofts)

                    cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)
                    pMesh.setPoints(aNewPoints)
                    # cmds.sculptTarget(sBlendShape, e=True, t=-1)
            [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xSetTargetAttrs]


    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.sculptTarget(sBlendShape, e=True, t=-1)
        cmds.select(sSelBefore)
        reconnectTargets(dWeightsBefore)
        if sSkip:
            cmds.confirmDialog(m='skipped because not in blendshape: %s' % library.listToString(sSkip))

        cmds.undoInfo(closeChunk=True)



def resetAllShapes(sBlendShape):
    try:
        cmds.undoInfo(openChunk=True)
        cmds.setAttr('%s.envelope' % sBlendShape, 1.0)
        dTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        for sT in list(dTargets.keys()):
            try:
                cmds.setAttr('%s.%s' % (sBlendShape, sT), 0.0)
            except:
                pass
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def setTargetsToNewSculpt(sMeshes, sSculpts, sBlendShape, sTargets, fInbetweens=None, bJustDeltas=False, bOnlySelectedIfSelection=False, fFactor=None):

    if utils.isNone(fFactor):
        fFactor = utilsQt.getFloatValueFromDialog('Enter Match Factor', 1.0, sConfigKey='_shapeEditorTargetsToNewSculptFactor')


    if bJustDeltas:
        raise Exception('just deltas is not supported at this time')

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())

    if utils.isNone(fInbetweens):
        fInbetweens = [1.0] * len(sTargets)

    xTargets = list(zip(sTargets, fInbetweens))

    xTargets.sort(key=lambda x: x[0].count('_'))


    sSelBefore = cmds.ls(sl=True)


    sMeshes = library.toList(sMeshes)
    sSculpts = library.toList(sSculpts)

    cmds.undoInfo(openChunk=True)
    try:
        dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()))

        dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        ddComboShapes = defaultdict(list)
        for sTarget in list(dAllTargets.keys()):
            if '_' in sTarget:
                sComboMainTargets = list(getPercsFromComboName(sTarget).keys())
                ddComboShapes[len(sComboMainTargets)].append((sTarget, sComboMainTargets))

        for sTarget, fInbetween in xTargets:
            xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sTarget)

            [cmds.setAttr(sAttr, fInbetween * fPerc) for sAttr, fPerc in xSetTargetAttrs]

            if fInbetween < 1.0 and fInbetween not in blendShapes.getInbetweenFloats(sBlendShape, dAllTargets[sTarget]):
                addInbetween(sBlendShape, sMeshes, [sTarget], fInbetween=fInbetween)

            cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sTarget], inbetweenWeight=fInbetween)

            if bOnlySelectedIfSelection:
                pSelection = patch.getSelectedPatches()
            for sMesh, sSculpt in zip(sMeshes, sSculpts):
                if bOnlySelectedIfSelection:
                    for pPatch in pSelection:
                        if pPatch.getTransformName().split(':')[-1] == sMesh:
                            if library.isNone(pPatch.aSofts):
                                aMultiply = fFactor
                            else:
                                aMultiply = (pPatch.aSofts * fFactor)[:, np.newaxis]

                            aSculptPoints = np.array(cmds.xform('%s.vtx[*]' % sSculpt, q=True, ws=True, t=True), dtype='float64').reshape(-1,3)
                            aSetPoints = np.array(cmds.xform('%s.vtx[*]' % sMesh, q=True, ws=True, t=True), dtype='float64').reshape(-1,3)

                            aSetPoints[pPatch.aIds] = aSculptPoints[pPatch.aIds] * aMultiply + aSetPoints[pPatch.aIds] * (1.0-aMultiply)
                            patch.patchFromName(sMesh).setPoints(aSetPoints, bWorld=False)
                            break
                else:
                    aSetPoints = patch.patchFromName(sSculpt).getAllPoints(bWorld=False)
                    patch.patchFromName(sMesh).setPoints(aSetPoints, bWorld=False)
            [cmds.setAttr(sAttr, 0.0) for sAttr, fPerc in xSetTargetAttrs]

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.sculptTarget(sBlendShape, e=True, t=-1)
        cmds.select(sSelBefore)
        reconnectTargets(dWeightsBefore)
        cmds.undoInfo(closeChunk=True)


def warpToOpenMeshPose(sMaster, sBlendShape, sTargets, sNewMesh, sMeshOpenPose):
    print('warp..: ', sMaster, sBlendShape, sTargets, sNewMesh)

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())

    sSelBefore = cmds.ls(sl=True)
    dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()))

    cmds.undoInfo(openChunk=True)
    try:
        dMeshIndices = library.getBlendShapeMeshTransforms(sBlendShape, bReturnIndexDict=True)
        iMeshIndex = dMeshIndices[sNewMesh]

        sMeshDupl = library.duplicateGeoClean(sNewMesh)

        for sAttr,xValue in list(dWeightsBefore.items()):
            fValue = cmds.getAttr(xValue) if library.isStringOrUnicode(xValue) else xValue
            cmds.setAttr(sAttr, fValue)
        sTempBlendShape = cmds.blendShape(sMeshOpenPose, sMeshDupl, w=[0,1])[0]
        sUnorderedWraps, sBase = library.createWrap(sMeshDupl, sMaster)

        aPoints = patch.patchFromName(sMaster).getAllPoints()
        patch.patchFromName(sBase).setPoints(aPoints)


        for sAttr,xValue in list(dWeightsBefore.items()):
            cmds.setAttr(sAttr, 0)

        aBadDiff = patch.patchFromName(sMeshDupl).getAllPoints() - patch.patchFromName(sNewMesh).getAllPoints()

        for sT in sTargets:
            sTargetAttr = '%s.%s' % (sBlendShape,sT)
            cmds.setAttr(sTargetAttr, 1.0)

            sTemp = cmds.duplicate(sMeshDupl, n='temp')[0]
            pTemp = patch.patchFromName(sTemp)
            pTemp.setPoints(pTemp.getAllPoints() - aBadDiff)

            cmds.connectAttr('%s.worldMesh[0]' % sTemp,
                             '%s.inputTarget[%d].inputTargetGroup[%d].inputTargetItem[6000].inputGeomTarget' % (sBlendShape, iMeshIndex, dAllTargets[sT]),
                             force=True)
            cmds.delete(sTemp)
            cmds.setAttr(sTargetAttr, 0.0)

        cmds.delete(sUnorderedWraps, sBase)
        cmds.delete(sMeshDupl)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        reconnectTargets(dWeightsBefore)
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)




def modelChange(sBlendShape, sOldModel, sNewModel, bAskIfScaleDeltas=True):
    print('sModel change... ', sBlendShape, sOldModel, sNewModel)
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    sAllTargets = list(dAllTargets.keys())
    sSelBefore = cmds.ls(sl=True)
    cmds.undoInfo(openChunk=True)

    try:
        qStatusWindow = utilsQt.QStatusWindow('Model Change')
        qStatusWindow.setCount(len(dAllTargets))

        dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), bSkipComboTargets=False)

        pOldModel = patch.patchFromName(sOldModel)
        aOldPoints = pOldModel.getPoints()
        aNewPoints = patch.patchFromName(sNewModel).getPoints()

        iSmallerCount = min(len(aOldPoints), len(aNewPoints))

        fFactor = library.boundingBoxDiagLength(aNewPoints[:iSmallerCount]) / library.boundingBoxDiagLength(aOldPoints[:iSmallerCount])
        if bAskIfScaleDeltas:
            if abs(fFactor-1.0) > 0.001:
                if cmds.confirmDialog(m='Different model size! The new model is %0.3f as big as the old one. Scale the deltas?' % fFactor,
                                    button=['yes', 'no']) == 'no':
                    fFactor = 1.0


        aaaPoints = [[] for _ in range(len(dAllTargets))]
        iiAllInbetweens = []

        # make sure to turn off skinCluster, otherwise we'll get a double transformation
        #
        dEnvelopesBefore = {}
        for sDeformer in library.listAllDeformers(sOldModel, sIgnoreTypes=['blendShape']):
            sEnvelopeAttr = '%s.envelope' % sDeformer
            dEnvelopesBefore[sEnvelopeAttr] = cmds.getAttr(sEnvelopeAttr)
            cmds.setAttr(sEnvelopeAttr, 0.0)


        for t,sT in enumerate(sAllTargets):
            sTargetAttr = '%s.%s' % (sBlendShape, sT)
            iInbetweens = blendShapes.getInbetweenTargetIndices(sBlendShape, dAllTargets[sT])
            iiAllInbetweens.append(iInbetweens)
            for iInb in iInbetweens:
                fTargetValue = utils.projectToRange(float(iInb), 5000, 6000, 0, 1.0)
                cmds.setAttr(sTargetAttr, fTargetValue)
                aaaPoints[t].append(aNewPoints[:iSmallerCount] + (pOldModel.getPoints()[:iSmallerCount] - aOldPoints[:iSmallerCount]) * fFactor)
                cmds.setAttr(sTargetAttr, 0.0)
            qStatusWindow.increment()


        for sEnvelopeAttr, fValue in dEnvelopesBefore.items():
            cmds.setAttr(sEnvelopeAttr, fValue)

        sOldOrigShape = library.getOrigShape(sOldModel, sBlendShapeCheck=sBlendShape)
        fnOldOrigShape = OpenMaya2.MFnMesh(library.getDagPath(sOldOrigShape))
        fnOldOrigShape.setPoints(OpenMaya2.MPointArray(aNewPoints[:iSmallerCount]))

        dMeshIndices = library.getBlendShapeMeshTransforms(sBlendShape, bReturnIndexDict=True)
        iMeshIndex = dMeshIndices[sOldModel]
        for t,sT in enumerate(sAllTargets):
            iInbetweens = iiAllInbetweens[t]
            for i,iInb in enumerate(iInbetweens):
                sTemp = cmds.duplicate(sOldModel)[0]
                aaPoints = aaaPoints[t]
                patch.patchFromName(sTemp).setPoints(aaPoints[i], aIds=np.arange(iSmallerCount))
                cmds.connectAttr('%s.worldMesh[0]' % sTemp,
                                 f'{sBlendShape}.inputTarget[{iMeshIndex}].inputTargetGroup[{dAllTargets[sT]}].inputTargetItem[{iInb}].inputGeomTarget')
                cmds.delete(sTemp)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.select(sSelBefore)
        reconnectTargets(dWeightsBefore)
        qStatusWindow.end()
        cmds.undoInfo(closeChunk=True)



def getJawFromReferenceRig(sBlendShape, sRigNamespace):
    sJaw = 'jnt_m_jawMain'

    try:
        bRecreateJointSetup = True
        if cmds.objExists(sJaw):
            sAnswer = cmds.confirmDialog(m='Recreate Joint Setup? \nThis is recommended on first time.', button=['yes','no','abort'])
            if sAnswer == 'no':
                bRecreateJointSetup = False
            elif sAnswer == 'abort':
                return

        dTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
        bMaintainJawOpen = False
        if 'jawOpen' in dTargets:
            sAnswer = cmds.confirmDialog(m='Maintain current JawOpen target?', button=['yes','no','abort'])
            if sAnswer == 'yes':
                bMaintainJawOpen = True
            if sAnswer == 'abort':
                return


        if bMaintainJawOpen:
            sMeshes = library.getBlendShapeMeshTransforms(sBlendShape)
            resetAllShapes(sBlendShape)
            cmds.setAttr('%s.jawOpen' % sBlendShape, 1)
            sDuplMeshes = [cmds.duplicate(sM, n='jawFixDupl_%s' % sM)[0] for sM in sMeshes]
            cmds.setAttr('%s.jawOpen' % sBlendShape, 0)

        if bRecreateJointSetup:
            sJointsGrp = 'joints'
            if not cmds.objExists(sJointsGrp):
                sJointsGrp = cmds.createNode('transform', n=sJointsGrp)

            sJoints = [sJaw, 'jnt_m_jawEnd', 'jnt_m_headMain', 'jnt_l_eyeMain', 'jnt_l_eyeEnd', 'jnt_r_eyeMain', 'jnt_r_eyeEnd', 'jnt_l_innerEyeLid', 'jnt_r_innerEyeLid']
            for sJ in sJoints:
                if cmds.objExists(sJ):
                    cmds.delete(sJ)
                cmds.createNode('joint', n=sJ)

                sRigJ = '%s%s' % (sRigNamespace, sJ)
                if cmds.objExists(sRigJ):
                    xforms.matchRadius(sJ, sRigJ)

            sJawParent = 'grp_m_jawParent'
            if cmds.objExists(sJawParent):
                cmds.delete(sJawParent)

            for sJ in sJoints:
                sReferenceJ = '%s%s' % (sRigNamespace, sJ)
                if cmds.objExists(sReferenceJ):
                    sReferenceParent = cmds.listRelatives(sReferenceJ, p=True)[0]
                    sParent = sReferenceParent.split(':')[-1]
                    if cmds.objExists(sParent):
                        sCurrentParents = cmds.listRelatives(sJ, p=True)
                        if not sCurrentParents or sCurrentParents[0] != sParent:
                            cmds.parent(sJ, sParent)
                    else:
                        try:
                            cmds.parent(sJ, sJointsGrp)
                        except: pass
            sJoints = cmds.ls(sJoints, l=True)
            sJoints.sort(key=lambda a:len(a), reverse=False)
            sJoints = [sJ.split('|')[-1] for sJ in sJoints]


            for sJ in sJoints:
                sReferenceJ = '%s%s' % (sRigNamespace, sJ)
                if cmds.objExists(sReferenceJ):
                    cmds.delete(cmds.parentConstraint(sReferenceJ, sJ))
                    cmds.makeIdentity(sJ, apply=True, r=True)
                    cmds.select(sJ)


            sJawJoint = 'jnt_m_jawMain'
            sHeadJoint = 'jnt_m_headMain'


            sJawParent = cmds.createNode('transform', n='grp_m_jawParent', p=sJointsGrp)
            cmds.delete(cmds.parentConstraint(sJaw, sJawParent))
            cmds.parent(sJaw, sJawParent)
            cmds.setAttr('%s.jo' % sJaw, 0,0,0)
            # if setupJaw() was run..
            for sA, fDefault in [('fOpenRotation', (0,0,-15)), ('fOpenTranslation', (0,-1,0))]:
                library.addStringAttr(sJawJoint, sA, getAttrIfExists('%s%s.%s' % (sRigNamespace, sJawJoint, sA), str(fDefault)))

            sJawRangeNodeR = kJawRangeNodeR % ('', sBlendShape)
            sJawRangeNodeT = kJawRangeNodeT % ('', sBlendShape)
            for sAttr, sJointA, sRange in [('fOpenRotation', 'r', sJawRangeNodeR),
                                           ('fOpenTranslation', 't', sJawRangeNodeT)]:
                if cmds.objExists(sRange):
                    sStringAttr = '%sjnt_m_jawMain.%s' % (sRigNamespace,sAttr)
                    if cmds.objExists(sStringAttr):
                        fValue = eval(cmds.getAttr(sStringAttr))
                        cmds.setAttr('%s.max' % sRange, *fValue)

        dMove = {'jnt_m_jawMain':['jnt_m_jawMain', 'jnt_m_botTeeth', 'jnt_m_teethBot', 'jnt_m_mouthPivotFrontJaw'],
                 'jnt_l_eyeMain':['jnt_l_eyeMain'], 'jnt_r_eyeMain':['jnt_r_eyeMain'], 'jnt_l_innerEyeLid':['jnt_l_innerEyeLid'], 'jnt_r_innerEyeLid':['jnt_r_innerEyeLid']}
        dMove['jnt_m_jawMain'].extend([sJ.split(':')[-1] for sJ in cmds.ls('%sjnt_?_botMouthSpline*_???' % sRigNamespace, et='joint')])
        dMove['jnt_m_jawMain'].extend([sJ.split(':')[-1] for sJ in cmds.ls('%sjnt_m_tongueSpine*' % sRigNamespace, et='joint')])

        sFromSkinClusters = cmds.ls('%s*' % sRigNamespace, et='skinCluster')
        sFromSkinClusters = [sS for sS in sFromSkinClusters if len(sS.split(':')[-1].split('__')) <= 2]

        for sFromSkinCluster in sFromSkinClusters:
            sGeometry = cmds.skinCluster(sFromSkinCluster, q=True, g=True)[0]
            if not sGeometry:
                cmds.warning('no geometry found for skinCluster "%s"' % sGeometry)
                continue
            if sGeometry.count(':') > 1: # to make sure it's not an unreal mesh, cuz that might overwrite stuff
                continue

            sReferencedMesh = cmds.listRelatives(sGeometry, p=True)[0]
            sM = sReferencedMesh.split(':')[-1]
            if not cmds.objExists(sM):
                continue

            mSkinCluster = library.getDependNode(sFromSkinCluster)
            fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(mSkinCluster)
            sInfluences = [dp.fullPathName().split('|')[-1] for dp in fnSkinCluster.influenceObjects()]

            iLen = cmds.polyEvaluate(sM, vertex=True)
            iRefLen = cmds.polyEvaluate(sReferencedMesh, vertex=True)
            iSmallerLen = min(iLen, iRefLen)
            aSetRange2d = np.arange(iSmallerLen)[:np.newaxis]
            pRefMesh = patch.patchFromName(sReferencedMesh)
            mComponents = pRefMesh.getIndexedComponents()
            fnRefSkinCluster = OpenMayaAnim2.MFnSkinCluster(mSkinCluster)
            mWeights, iInfCount = fnRefSkinCluster.getWeights(library.getDagPath(sReferencedMesh), mComponents)
            aWeights2d = np.array(list(mWeights), dtype='float64').reshape(-1, iInfCount)

            sMoveToJoints = list(dMove.keys())
            aFinalWeights2d = np.zeros((iLen, len(sMoveToJoints)+1), dtype='float64')
            aFinalWeights2d[:,0] = 1.0


            for sToJoint in sMoveToJoints:
                sFromJoints = dMove[sToJoint]

                for sFromJoint in sFromJoints:

                    sRefJawJoint = '%s%s' % (sRigNamespace, sFromJoint)
                    if sRefJawJoint in sInfluences:
                        iFromIndex = sInfluences.index(sRefJawJoint)
                        iToIndex = 1 + sMoveToJoints.index(sToJoint)

                        aFinalWeights2d[aSetRange2d,iToIndex] += aWeights2d[aSetRange2d,iFromIndex]
                        aFinalWeights2d[aSetRange2d,0] -= aWeights2d[aSetRange2d,iFromIndex]

            if library.listAllDeformers(sM, sFilterTypes=['skinCluster']):
                cmds.skinCluster(sM, e=True, ub=True)
            sNewSkinCluster = cmds.skinCluster(sM, ['jnt_m_headMain'] + sMoveToJoints, tsb=True, n='autoTransferredSkinCluster')[0]
            pM = patch.patchFromName(sM)
            fnSkinCluster = OpenMayaAnim2.MFnSkinCluster(library.getDependNode(sNewSkinCluster))

            mInfluences = OpenMaya2.MIntArray(range(1+len(sMoveToJoints)))
            fnSkinCluster.setWeights(pM.mDagPath,
                                     pM.getIndexedComponents(),
                                     mInfluences,
                                     OpenMaya2.MDoubleArray(list(aFinalWeights2d.flatten())))

        if 'jawOpen' in dTargets:
            if bRecreateJointSetup:
                getAndRefreshJawOpenInputPlug(sBlendShape)
    
            if bMaintainJawOpen:
                cmds.setAttr('%s.jawOpen' % sBlendShape, 1)
                cmds.sculptTarget(sBlendShape, e=True, t=dTargets['jawOpen'])
                for sM,sDuplM in zip(sMeshes, sDuplMeshes):
                    aPoints = patch.patchFromName(sDuplM).getAllPoints()
                    patch.patchFromName(sM).setPoints(aPoints)
                cmds.sculptTarget(sBlendShape, e=True, t=-1)
                cmds.setAttr('%s.jawOpen' % sBlendShape, 0)
                cmds.delete(sDuplMeshes)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise



def getMeshesFromBlendShape(sBlendShape):
    sShapes = cmds.blendShape(sBlendShape, q=True, g=True)
    sMeshes = [cmds.listRelatives(sS, p=True)[0] for sS in sShapes]
    return sMeshes




def disconnectAndResetTargets(sBlendShape, sTargets, bSkipComboTargets=True, dRigPoseAttrs=None, bIncludeOutgoingTargets=False):
    dWeightsBefore = {}
    for sT in list(sTargets):
        if bSkipComboTargets and '_' in sT:
            continue
        sAttr = '%s.%s' % (sBlendShape, sT)
        sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
        if sConns:
            dWeightsBefore[sAttr] = sConns[0]
            cmds.disconnectAttr(sConns[0], sAttr)
        else:
            dWeightsBefore[sAttr] = cmds.getAttr(sAttr)
        cmds.setAttr(sAttr, 0.0)

        if not utils.isNone(dRigPoseAttrs):
            for sAttr in dRigPoseAttrs.get(sT, {}).keys():
                if cmds.getAttr(sAttr, settable=True):
                    dWeightsBefore[sAttr] = cmds.getAttr(sAttr)
                    cmds.setAttr(sAttr, 0.0)

    return dWeightsBefore


def disconnectOutConnectionsFromTargets(sBlendShape, sTargets):
    '''
    this is mainly to disconnect the joints from the jawOpen
    '''
    dOutConnectionsBefore = defaultdict(list)
    for sT in list(sTargets):
        sTargetAttr = '%s.%s' % (sBlendShape, sT)
        print ('\n\nsTargetAttr: ', sTargetAttr)

        sPlugs = cmds.listConnections(sTargetAttr, d=True, s=False, p=True) or []
        for sPlug in sPlugs:
            if sPlug.startswith('%s.' % sBlendShape):
                continue
            dOutConnectionsBefore[sTargetAttr].append(sPlug)
            cmds.disconnectAttr(sTargetAttr, sPlug)
    return dOutConnectionsBefore


def reconnectTargets(dWeightsBefore):
    for sTargetAttr, xValue in list(dWeightsBefore.items()):
        library._connectOrSet(xValue, sTargetAttr)


def getSetTargetAttrs(sBlendShape, sTarget, bIncludeIfCombo=False, bCheckForFaceCombos=True, dAdditionalSetAttrs=None):
    if '_' in sTarget and bCheckForFaceCombos:
        dPercs = getPercsFromComboName(sTarget)
        xSetTargetAttrs = [('%s.%s' % (sBlendShape, sMainT), iPerc*0.01) for sMainT,iPerc in dPercs.items()]
        if bIncludeIfCombo:
            xSetTargetAttrs.append(('%s.%s' % (sBlendShape, sTarget), 1.0))
    else:
        xSetTargetAttrs = [('%s.%s' % (sBlendShape, sTarget), 1.0)]

    if not utils.isNone(dAdditionalSetAttrs):
        xSetTargetAttrs += dAdditionalSetAttrs[sTarget].items()

    return xSetTargetAttrs


def resetTargetIfEmpty(sBlendShape, iTargetIndex, sMesh, iMeshIndex):
    fZeroPoints = [(0.0, 0.0, 0.0, 1.0)]
    iInbetweenIndices = blendShapes.getInbetweenTargetIndices(sBlendShape, iTargetIndex)  # instead of that we just used the number 6000
    for iInbetweenIndex in iInbetweenIndices:

        sPointsAttr = f'{sBlendShape}.inputTarget[{iMeshIndex}].inputTargetGroup[{iTargetIndex}].inputTargetItem[{iInbetweenIndex}].inputPointsTarget'
        fCurrentPoints = cmds.getAttr(sPointsAttr)
        if not fCurrentPoints:
            cmds.setAttr(sPointsAttr, len(fZeroPoints), *fZeroPoints, type='pointArray')
            if cmds.listRelatives(sMesh, typ='nurbsCurve'):
                sZeroPoints = ['cv[0]']
            elif cmds.listRelatives(sMesh, typ='nurbsSurface'):
                sZeroPoints = ['cv[0][0]']
            else:
                sZeroPoints = ['vtx[0]']
            cmds.setAttr(
                f'{sBlendShape}.inputTarget[{iMeshIndex}].inputTargetGroup[{iTargetIndex}].inputTargetItem[{iInbetweenIndex}].inputComponentsTarget',
                len(sZeroPoints), *sZeroPoints, type='componentList')


def multiplyTargets(sBlendShape, sTargets, fFactor, sAlongTransformY=None, iInbetweensMode=library.InbetweenModes.MainTargetAndInbetweens, dRigPoseAttrs=None,
                    bCheckForFaceCombos=True):

    if utils.isNone(fFactor):
        fFactor = utilsQt.getFloatValueFromDialog('Enter Factor', 2.0, sConfigKey='_shapeEditorMultiplyFactor')

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if library.isNone(sTargets):
        sTargets = list(dAllTargets.keys())

    sTargets.sort(key=lambda x: x.count('_'))
    dTargetWeights = {sT:cmds.getAttr('%s.%s' % (sBlendShape, sT)) for sT in sTargets}

    sSelBefore = cmds.ls(sl=True)

    cmds.undoInfo(openChunk=True)
    try:
        pSelection = patch.getSelectedPatches()

        dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), dRigPoseAttrs=dRigPoseAttrs, bSkipComboTargets=bCheckForFaceCombos)
        dOutConnectionsBefore = disconnectOutConnectionsFromTargets(sBlendShape, list(dAllTargets.keys()))

        aaaDefaultPoints = [pMesh.getAllPoints() for pMesh in pSelection]
        qStatusWindow = utilsQt.QStatusWindow('Multiply')
        qStatusWindow.setCount(len(sTargets))

        dMeshIndices = library.getBlendShapeMeshTransforms(sBlendShape, bReturnIndexDict=True)

        for sT in sTargets:
            qStatusWindow.increment()

            # dAdditionalSetupAttrs would be the rig poses, but we turned it off, so it's all calculated in blendShape space:
            xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos) #, dAdditionalSetAttrs=dRigPoseAttrs)

            for fInbetween in getSubTargets(sBlendShape, dAllTargets[sT], dTargetWeights[sT], iInbetweensMode=iInbetweensMode):
                [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]

                cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)

                for m,pMesh in enumerate(pSelection):
                    sMesh = pMesh.getTransformName()
                    if sMesh not in dMeshIndices:
                        print ('skipping "%s"...' % sMesh)
                        continue

                    resetTargetIfEmpty(sBlendShape, dAllTargets[sT], sMesh, dMeshIndices[sMesh])

                    fMeshFactor = fFactor[m] if isinstance(fFactor, list) else fFactor
                    if isinstance(fMeshFactor, np.ndarray):
                        fMeshFactor = fMeshFactor[:,np.newaxis]
                    aaPoints = patch.patchFromName(pMesh.getTransformName()).getPoints()
                    aaDiff = aaPoints - aaaDefaultPoints[m]

                    if sAlongTransformY:
                        aAlongMatrix = utils.getNumpyMatrixFromTransform(sAlongTransformY)[0:3,0:3]
                        aDiffsLocal = np.dot(aaDiff, np.linalg.inv(aAlongMatrix))
                        aDiffsLocal[:,1] *= fMeshFactor
                        aaDiff = np.dot(aDiffsLocal, aAlongMatrix)
                    else:
                        aaDiff *= fMeshFactor
                    aMultipliedPoints = aaaDefaultPoints[m] + aaDiff

                    aNewPoints = np.copy(aaPoints)
                    if library.isNone(pMesh.aSofts):
                        aNewPoints[pMesh.aIds] = aMultipliedPoints[pMesh.aIds]
                    else:
                        aSofts = pMesh.aSofts[:, np.newaxis]
                        aNewPoints[pMesh.aIds] = aMultipliedPoints[pMesh.aIds] * aSofts + aaPoints[pMesh.aIds] * (1.0 - aSofts)

                    patch.patchFromName(pMesh.getTransformName()).setPoints(aNewPoints)

                [cmds.setAttr(sAttr, 0.0) for sAttr, fPerc in xSetTargetAttrs]

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.sculptTarget(sBlendShape, e=True, t=-1)
        reconnectTargets(dWeightsBefore)
        for sTargetAttr, sOutConnections in dOutConnectionsBefore.items():
            for sPlug in sOutConnections:
                cmds.connectAttr(sTargetAttr, sPlug)
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)
        qStatusWindow.end()




def bakeTargets(sBlendShape, sMainMesh=None, bJustDeltas=False, sIgnoreMeshes=[], sAddSuffix='', sFilterTargets=None, bCreateTransformForInactiveMainTargets=False):

    dTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)


    dPrevious = {}

    dEnableInfoAttr = eval(library.getStringAttr(sBlendShape, 'sEnabledInfoAttr', '{}'))
    for sTarget in list(dTargets.keys()):
        sAttr = '%s.%s' % (sBlendShape, sTarget)
        sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
        if sConns:
            dPrevious[sAttr] = sConns[0]
            cmds.disconnectAttr(sConns[0], sAttr)
            cmds.setAttr(sAttr, 0)
        else:
            dPrevious[sAttr] = cmds.getAttr(sAttr)
            cmds.setAttr(sAttr, 0)

    try:
        cmds.undoInfo(openChunk=True)
        sIgnoreMeshes = set(sIgnoreMeshes)
        sMeshes = library.getBlendShapeMeshTransforms(sBlendShape, bFullPath=True)
        sMeshes = [sM for sM in sMeshes if sM.split('|')[-1] not in sIgnoreMeshes]
        pMeshes = [patch.patchFromName(sM) for sM in sMeshes]
        aaDefaultPoints = [pM.getPoints() for pM in pMeshes]

        sReturn = []

        if bJustDeltas:
            ssSkinClusters = [library.listAllDeformers(sM, sFilterTypes=['skinCluster']) for sM in sMeshes]
            sSkinClusters = library.flattenedList(ssSkinClusters)
            for sSC in sSkinClusters:
                cmds.setAttr('%s.envelope' % sSC, 0)

        if not bJustDeltas:
            ddComboShapes = defaultdict(list)
            for sTarget in list(dTargets.keys()):
                if '_' in sTarget:
                    sComboMainTargets = list(getPercsFromComboName(sTarget).keys())
                    ddComboShapes[len(sComboMainTargets)].append((sTarget, sComboMainTargets))

        sDoTargets = sFilterTargets if not library.isNone(sFilterTargets) else list(dTargets.keys())

        sMainTargetsInCombos = set()
        for sTarget in sDoTargets:
            if '_' in sTarget and dEnableInfoAttr.get(sTarget, True) == True:
                for sMainT in sTarget.split('_'):
                    sMainTargetsInCombos.add(sMainT)

        for sTarget in sDoTargets:
            if cmds.objExists(sTarget):
                cmds.warning('Skipping "%s", it already exists' % sTarget)
                continue

            if dEnableInfoAttr.get(sTarget, True) == False:
                if bCreateTransformForInactiveMainTargets:
                    if sTarget in sMainTargetsInCombos:
                        cmds.createNode('transform', n=sTarget)
                continue
            iTargetIndexList = blendShapes.getInbetweenTargetIndices(sBlendShape, dTargets[sTarget])
            for m,sFullM in enumerate(sMeshes):
                sM = sFullM.split('|')[-1]
                for iIndex in iTargetIndexList:
                    fOveralPerc = library.projectToRange(float(iIndex), 5000, 6000, 0, 1.0)

                    iOveralPerc = int(fOveralPerc * 100.0)
                    sTargetName = sTarget
                    sTargetSplits = sTargetName.split('_')
                    sTargetName = '_'.join(['%s%s' % (sT,sAddSuffix) for sT in sTargetSplits])
                    if iOveralPerc != 100:
                        sTargetName = '%s__%03d' % (sTargetName, iOveralPerc)
                    if sM != sMainMesh:
                        sTargetName = '%s__%s' % (sM.split(':')[-1], sTargetName)


                    cmds.setAttr('%s.%s' % (sBlendShape, sTarget), fOveralPerc)

                    if not bJustDeltas:
                        sSetAttrs = []
                        if '_' in sTarget: #combo
                            # turn on all their main targets
                            dComboMainTargets = getPercsFromComboName(sTarget)
                            for sMainT, iPerc in list(dComboMainTargets.items()):
                                sAttr = '%s.%s' % (sBlendShape, sMainT)
                                cmds.setAttr(sAttr, fOveralPerc * iPerc * 0.01)
                                sSetAttrs.append(sAttr)

                            # turn on the lower combos
                            for k in range(2, len(dComboMainTargets),1): # to run on all smaller combo shapes
                                for sComboT, sMainTs in ddComboShapes[k]:
                                    if len(set(sMainTs) - set(dComboMainTargets.keys())) == 0:
                                        sAttr = '%s.%s' % (sBlendShape, sComboT)
                                        cmds.setAttr(sAttr, fOveralPerc * iPerc * 0.01)
                                        sSetAttrs.append(sAttr)


                    bSkip = False
                    if sM != sMainMesh:
                        aDiff = pMeshes[m].getPoints() - aaDefaultPoints[m]
                        aLengths = np.linalg.norm(aDiff, axis=-1)
                        if not len(np.where(aLengths > 0.001)[0]):
                            bSkip = True

                    if not bSkip:
                        if cmds.objExists(sTargetName):
                            raise Exception('object already exists with this name: "%s"' % sTargetName)
                        sReturn.append(library.duplicateGeoClean(sFullM, sName=sTargetName, bParentToOrigin=True))

                    cmds.setAttr('%s.%s' % (sBlendShape, sTarget), 0.0)
                    if not bJustDeltas:
                        if '_' in sTarget: #combo
                            for sAttr in sSetAttrs:
                                cmds.setAttr(sAttr, 0.0)

        if bJustDeltas:
            for sSC in sSkinClusters:
                cmds.setAttr('%s.envelope' % sSC, 1)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        for sAttr, xValue in list(dPrevious.items()):
            if library.isStringOrUnicode(xValue):
                cmds.connectAttr(xValue, sAttr)
            else:
                cmds.setAttr(sAttr, xValue)
        cmds.undoInfo(closeChunk=True)


    cmds.select(sReturn)
    return sReturn



def getPercsFromComboName(sComboTarget):
    dPercs = OrderedDict()
    for sString in sComboTarget.split('_'):
        sT,iPerc = library.getTargetPercNumber(sString)
        dPercs[sT] = iPerc
    return dPercs



def checkIfNotEmpty(sBlendShape, sTarget, fThreshhold=0.001):

    sMeshes = getMeshesFromBlendShape(sBlendShape)
    pMeshes = [patch.patchFromName(sM) for sM in sMeshes]

    sAttr = '%s.%s' % (sBlendShape,sTarget)
    sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
    if sConns:
        sWeightBefore = sConns[0]
        cmds.disconnectAttr(sConns[0], sAttr)
    else:
        sWeightBefore = cmds.getAttr(sAttr)
    cmds.setAttr(sAttr, 0.0)

    aaDefaultPoints = [pM.getPoints() for pM in pMeshes]
    cmds.setAttr(sAttr, 1.0)
    aaPoints = [pM.getPoints() for pM in pMeshes]

    library._connectOrSet(sWeightBefore, sAttr)
    for m,sM in enumerate(sMeshes):
        aDiff = aaPoints[m] - aaDefaultPoints[m]
        aMags = np.linalg.norm(aDiff, axis=-1)
        if len(np.where(aMags >= fThreshhold)[0]):
            return True

    return False



def createCurveFromSelectedVerts(sName='noname', sParent=None, fDirection=None, iDegree=1, bWrap=True):
    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    try:
        cmds.undoInfo(openChunk=True)
        aPoints = getSelectedOrderedPoints(bReturnPoints=True)

        if fDirection != None:
            aDirection = np.array(fDirection)
            aCurveDirection = aPoints[-1] - aPoints[0]
            if np.sum(aDirection*aCurveDirection) < 0.0:
                aPoints = aPoints[::-1]

        sCurve = cmds.curve(p=aPoints, d=iDegree if len(aPoints) > 2 else 1, n=sName)
        if sParent:
            cmds.parent(sCurve, sParent)

        if bWrap:
            print('wrapping to %s' % sMesh)
            library.createWrap(sCurve, sMesh)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)

    return sCurve

def createJointsOnSelectedCurve(iCount):
    sCurve = cmds.ls(sl=True)[0].split('.')[0]

    aParams = curves.getParamsFromPercs(sCurve, np.arange(iCount) / (iCount-1))
    sJoints = []
    for j in range(iCount):
        sJ = cmds.createNode('joint', n='jnt_%s_%03d' % (sCurve, j))
        sInfoNode, sInfoPosition = curves.createPointInfoNode(sCurve, aParams[j], sTargetPos='%s.t' % sJ)
        sJoints.append(sJ)

    for j,sJ in enumerate(sJoints):
        if j < len(sJoints)-1:
            cmds.delete(cmds.aimConstraint(sJoints[j+1], sJ))
        else:
            cmds.delete(cmds.orientConstraint(sJoints[j-1], sJ))

    cmds.select(sJoints)

def getSelectedOrderedPoints(bReturnPoints=False, bForceOneLine=True):
    pSelection = library.getSelectedPatches()
    if not pSelection:
        raise Exception('need to select vertices')

    pMesh = pSelection[0]
    iNbsArray = pMesh.getNeighbors(bExcludeNeighborsNotInIds=True)
    aIdsMapper = library.getIdsToIndicesMapper(pMesh.aIds)

    iNbsMapped = []
    for iNbs in iNbsArray:
        iNbsMapped.append([aIdsMapper[n] for n in iNbs])

    print('iNbsMapped before: ', iNbsMapped)
    # return

    iLeft = [0]
    iRight = [0]
    bLeftReachedEnd = False
    bRightReachedEnd = False

    xQueues = []
    for _ in range(pMesh.aIds.size): # just security, will likely cancel after first
        print('run')
        for i in range(pMesh.aIds.size): # maybe should go longer to make sure?
            if i == 0:
                iPair = iNbsMapped[iLeft[0]]
                if len(iPair) > 2:
                    raise Exception('need to select a line, can\'t have any forks or stars')
                iLeft.append(iPair[0])
                if len(iPair) == 1:
                    bRightReachedEnd = True
                elif len(iPair) == 2:
                    iRight.append(iPair[1])
                iNbsMapped[iLeft[0]] = None

            else:
                bDidSomething = False
                if not bLeftReachedEnd: # and len(iLeft) > i - 1: # if before we didn't assign anything, then this would fail
                    iPreviousInd = iLeft[-1]
                    iNextPair = iNbsMapped[iPreviousInd]
                    if iNextPair != None:
                        if len(iNextPair) == 1:
                            bLeftReachedEnd = True
                            bDidSomething = True
                        elif len(iNextPair) == 2:
                            iNextIndex = iNextPair[0] if iNbsMapped[iNextPair[1]] == None else iNextPair[1]
                            if iNextIndex != iLeft[-2]:
                                iLeft.append(iNextIndex)
                                bDidSomething = True
                        else:
                            raise Exception('need to select a line, can\'t have any forks or stars')
                        iNbsMapped[iPreviousInd] = None
                if not bRightReachedEnd and len(iRight) > i - 1:
                    iPreviousInd = iRight[-1]
                    iNextPair = iNbsMapped[iPreviousInd]
                    if iNextPair != None:
                        if len(iNextPair) == 1:
                            bRightReachedEnd = True
                            bDidSomething = True
                        elif len(iNextPair) == 2:
                            iNextIndex = iNextPair[0] if iNbsMapped[iNextPair[1]] == None else iNextPair[1]
                            if iNextIndex != iRight[-2]:
                                iRight.append(iNextIndex)
                                bDidSomething = True
                        else:
                            raise Exception('need to select a line, can\'t have any forks or stars')
                        iNbsMapped[iPreviousInd] = None

                if not bDidSomething:
                    break


        print('iNbsMapped after: ', iNbsMapped)

        bClosed = False
        iShrinkRight = 0
        for i in range(len(iRight)-1):
            if iRight[-(1+i)] in iLeft:
                iShrinkRight += 1
            else:
                break
        if iShrinkRight > 0:
            bClosed = True
            iRight = iRight[:-iShrinkRight]

        iLeft.reverse()
        iBoth = iLeft[:-1] + iRight
        xQueues.append(iBoth)

        bNothingLeft = True
        for i in range(len(iNbsMapped)):
            if iNbsMapped[i] != None:
                iLeft = [i]
                iRight = [i]
                bLeftReachedEnd = False
                bRightReachedEnd = False
                bNothingLeft = False
        if bNothingLeft:
            break
    print('xQueues: ,', xQueues)
    if len(xQueues) != 1:
        if bForceOneLine:
            raise Exception('more than one queues is not supported for getSelectedOrderedPoints(), use getTracktedSelectedOrderedPoints() instead')
        else:
            aPoints = pMesh.getPoints()
            print('aPoints: ', aPoints)
            xReturn = []
            for q,iPath in enumerate(xQueues):
                aPath = np.array(iPath, dtype=int)
                if bReturnPoints:
                    print('aPoints[aPath]: ', aPoints[aPath])
                    xReturn.append(aPoints[aPath])
                else:
                    xReturn.append(pMesh.aIds[aPath])
            return xReturn

    else:
        aPath = np.array(xQueues[0], dtype=int)

        if bReturnPoints:
            aPoints = pMesh.getPoints()
            return aPoints[aPath]
        else:
            return pMesh.aIds[aPath]


def getAttrIfExists(sAttr, xDefault, bStringEval=False):
    if cmds.objExists(sAttr):
        xValue = cmds.getAttr(sAttr)
        if bStringEval:
            xValue = eval(xValue)
        return xValue
    else:
        return xDefault


kJawRangeNodeR = '%sjawConnect__jawOpenRange__%s'
kJawRangeNodeT = '%sjawConnect__jawOpenRangeT__%s'
kInnerBlinkRangeNodes = ['%sinnerBlinkConnect__l_innerBlinkRange__%s', '%sinnerBlinkConnect__r_innerBlinkRange__%s']

def fixJawOldJoints():
    sJawParent = 'grp_m_jawParent'
    sJaw = 'jnt_m_jawMain'
    if cmds.objExists(sJaw) and not cmds.objExists(sJawParent):
        cmds.createNode('transform', n=sJawParent)

        sParent = cmds.listRelatives(sJaw, p=True)
        if sParent:
            cmds.parent(sJawParent, sParent[0])
        cmds.delete(cmds.pointConstraint(sJaw, sJawParent))
        cmds.parent(sJaw, sJawParent)



def getAndRefreshJawOpenInputPlug(sBlendShape, sExternNamespace=''): # sNamespace is only used when calling the function on an importet stuff

    sJawRangeNodeR = kJawRangeNodeR % (sExternNamespace, sBlendShape)
    sJawRangeNodeT = kJawRangeNodeT % (sExternNamespace, sBlendShape)

    fixJawOldJoints()

    sOutputs = []
    sJawJoint = '%sjnt_m_jawMain' % sExternNamespace

    fRotationDefault = getAttrIfExists('%sjnt_m_jawMain.fOpenRotation' % sExternNamespace, (0,0,-31), bStringEval=True)
    fTranslationDefault = getAttrIfExists('%sjnt_m_jawMain.fOpenTranslation' % sExternNamespace, (0,0,0), bStringEval=True)

    for sRange, sJointAttr, fDefault in [(sJawRangeNodeR, 'r', fRotationDefault),
                                         (sJawRangeNodeT, 't', fTranslationDefault)]:
        if not cmds.objExists(sRange):
            cmds.createNode('setRange', n=sRange)
            cmds.setAttr('%s.max' % sRange, *fDefault)

        for sA in ['X', 'Y', 'Z']:
            cmds.connectAttr('%s.jawOpen' % sBlendShape, '%s.value%s' % (sRange, sA), force=True)
            cmds.setAttr('%s.oldMin%s' % (sRange, sA), 0)
            cmds.setAttr('%s.oldMax%s' % (sRange, sA), 1)
        cmds.setAttr('%s.min' % sRange, 0, 0, 0)

        if not cmds.objExists(sJawJoint):
            cmds.createNode('joint', n=sJawJoint)
            cmds.setAttr('%s.jo' % sJawJoint, 0, 270, 0)

        cmds.connectAttr('%s.outValue' % sRange, '%s.%s' % (sJawJoint, sJointAttr), force=True)

        sOutputs.append('%s.max' % sRange)

    return sOutputs





kLookTargets = {'eyelookUp': [0,0,20],
                'eyelookDown': [0,0,-20],
                'eyelookLeft': [0,20,0],
                'eyelookRight': [0,-20,0],
                'eyelookIn': [0,-20,0],
                'eyelookOut': [0,20,0]}
def getAndRefreshEyelookatInputPlug(sBlendShape, sLookTarget):
    if sLookTarget not in kLookTargets:
        return None
    else:
        iLookatIndex = list(kLookTargets.keys()).index(sLookTarget)

        sRangeNodes = ['l_eyelookConnect__%sRange__%s' % (sLookTarget, sBlendShape),
                       'r_eyelookConnect__%sRange__%s' % (sLookTarget, sBlendShape)]

        for s,sSide in enumerate(['l','r']):
            sAdditionNode = '%s_eyelookConnect__additions_%s' % (sSide, sBlendShape)
            
            fValues = kLookTargets[sLookTarget]
            if sSide == 'l' and cmds.objExists(sRangeNodes[s]):
                fValues = cmds.getAttr('%s.max' % sRangeNodes[s])[0]
                cmds.delete(sRangeNodes[s])
            elif sSide == 'r':
                fValues = cmds.getAttr('%s.max' % sRangeNodes[0])[0]

            cmds.createNode('setRange', n=sRangeNodes[s])
            if sSide == 'r' and sLookTarget in ['eyelookLeft', 'eyelookRight']:
                nodes.createVectorMultiplyNode('%s.max' % sRangeNodes[0], [1,-1,1], sTarget='%s.max' % sRangeNodes[1], bForce=True) # on right side lookLeft/lookRight take the sRangeNode from left
            else:
                cmds.setAttr('%s.max' % sRangeNodes[s], *fValues)


            if not cmds.objExists(sAdditionNode):
                cmds.createNode('plusMinusAverage', n=sAdditionNode)

            for sA in ['X','Y','Z']:
                cmds.connectAttr('%s.%s' % (sBlendShape, sLookTarget), '%s.value%s' % (sRangeNodes[s],sA), force=True)
                cmds.setAttr('%s.oldMin%s' % (sRangeNodes[s],sA), 0)
                cmds.setAttr('%s.oldMax%s' % (sRangeNodes[s],sA), 1)
            cmds.setAttr('%s.min' % sRangeNodes[s], 0, 0, 0)
            sJoint = 'jnt_%s_eyeMain' % sSide
            if not cmds.objExists(sJoint):
                cmds.createNode('joint', n=sJoint)
            cmds.connectAttr('%s.outValue' % sRangeNodes[s], '%s.input3D[%d]' % (sAdditionNode, iLookatIndex), force=True)
            cmds.connectAttr('%s.output3D' % sAdditionNode, '%s.r' % sJoint, force=True)

        return ['%s.max' % sRangeNodes[0], '%s.max' % sRangeNodes[1]]



def getAndRefreshInnerBlinkInputPlug(sBlendShape, sExternNamespace=''): # sNamespace is only used when calling the function on an importet stuff
    sOutputs = []
    
    for s,sSide in enumerate(['l','r']):
        sRange = kInnerBlinkRangeNodes[s] % (sExternNamespace, sBlendShape)
        
        sJoint = '%sjnt_%s_innerEyeLid' % (sExternNamespace, sSide)
        
        fRotationDefault = [0,105,0]
        
        if not cmds.objExists(sRange):
            cmds.createNode('setRange', n=sRange)
            cmds.setAttr('%s.max' % sRange, *fRotationDefault)
        
        for sA in ['X', 'Y', 'Z']:
            cmds.connectAttr('%s.innerBlink' % sBlendShape, '%s.value%s' % (sRange, sA), force=True)
            cmds.setAttr('%s.oldMin%s' % (sRange, sA), 0)
            cmds.setAttr('%s.oldMax%s' % (sRange, sA), 1)
        cmds.setAttr('%s.min' % sRange, 0, 0, 0)
        
        if not cmds.objExists(sJoint):
            cmds.createNode('joint', n=sJoint)
        cmds.connectAttr('%s.outValue' % sRange, '%s.r' % sJoint, force=True)
        
        sOutputs.append('%s.max' % sRange)
        
    return sOutputs


def getEyelookPoses(sBlendShape):
    sNamespace = '%s:' % sBlendShape.split(':')[0] if ':' in sBlendShape else ''
    dLookPoses = {}
    for sTarget in kLookTargets:
        sRangeNode = '%sl_eyelookConnect__%sRange__%s' % (sNamespace, sTarget, sBlendShape.split(':')[-1])
        if cmds.objExists(sRangeNode):
            dLookPoses[sTarget] = cmds.getAttr('%s.max' % sRangeNode)[0]
    return dLookPoses


def detectMiddleEdge(sMesh, bReturnString=False):
    sShape = library.getOrigShape(sMesh)
    # sShape = pPatch.getOrigShape()
    print('sShape: ', sShape)
    aPos = np.array(cmds.xform('%s.vtx[*]' % sShape, q=True, ws=False, t=True))

    dagPath = library.getDagPath(sShape)
    fnMesh = OpenMaya2.MFnMesh(dagPath)
    iEdgeVerts = []
    for i in range(fnMesh.numEdges):
        iVerts = fnMesh.getEdgeVertices(i)
        iEdgeVerts.append(iVerts[0])
        iEdgeVerts.append(iVerts[1])
    aVertIds = np.array(iEdgeVerts, dtype=int)

    aX = np.abs(aPos[0::3])
    aEdgesX = aX[aVertIds].reshape(fnMesh.numEdges, 2)
    aSums = aEdgesX.sum(axis=1)
    iIndex = np.argmin(aSums)

    print('aSums: ', aSums)

    return '%s.e[%d]' % (sMesh, iIndex) if bReturnString else iIndex




def analizeTopology(edge):

    sMesh, sEdge = edge.split('.')
    firstEdge = int(sEdge.split('[')[-1].split(']')[0])
    mMesh = library.getDagPath(sMesh)

    fnMesh = OpenMaya2.MFnMesh(library.getDagPath(sMesh))
    pointCount = fnMesh.numVertices
    edgeCount = fnMesh.numEdges
    polyCount = fnMesh.numPolygons

    baseObjectName = sMesh


    mapArray = []
    sideArray = []
    checkedV = [-1] * pointCount
    sideV = [-1] * pointCount
    checkedP = [-1] * polyCount
    checkedE = [-1] * edgeCount

    polyIter = OpenMaya2.MItMeshPolygon(mMesh)
    edgeIter = OpenMaya2.MItMeshEdge(mMesh)

    l_edgeQueue = [firstEdge]
    r_edgeQueue = [firstEdge]


    l_faceEdges = []
    r_faceEdges = []

    qStatusWindow = utilsQt.QStatusWindow('Finding Opposite Vertices')
    qStatusWindow.setCount(edgeCount / 2)
    timeA = 0
    timeB = 0
    timeC = 0
    timeD = 0
    timeE = 0

    import time


    numPolys = fnMesh.numPolygons
    connectedEdgesPerFaces = [None] * numPolys

    for i in range(numPolys):
        polyIter.setIndex(i)
        edges = polyIter.getEdges()
        connectedEdgesPerFaces[i] = list(edges)

    while True:

        t = time.time()

        if len(l_edgeQueue) == 0:
            qStatusWindow.end()
            break

        qStatusWindow.increment()
        l_currentE = l_edgeQueue[0]
        r_currentE = r_edgeQueue[0]

        l_edgeQueue = l_edgeQueue[1:]
        r_edgeQueue = r_edgeQueue[1:]

        checkedE[l_currentE] = r_currentE
        checkedE[r_currentE] = l_currentE

        timeA += time.time() - t
        t = time.time()

        if l_currentE == r_currentE and l_currentE != firstEdge:
            continue

        # get the left face
        edgeIter.setIndex(l_currentE)
        l_faceList = edgeIter.getConnectedFaces()
        if len(l_faceList) == 1:
            l_currentP = l_faceList[0]
        elif checkedP[l_faceList[0]] == -1 and checkedP[l_faceList[1]] != -1:
            l_currentP = l_faceList[0]
        elif checkedP[l_faceList[1]] == -1 and checkedP[l_faceList[0]] != -1:
            l_currentP = l_faceList[1]
        elif checkedP[l_faceList[0]] == -1 and checkedP[l_faceList[1]] == -1:
            l_currentP = l_faceList[0]
            checkedP[l_currentP] = -2

        # get the right face
        edgeIter.setIndex(r_currentE)
        r_faceList = edgeIter.getConnectedFaces()
        if len(r_faceList) == 1:
            r_currentP = r_faceList[0]
        elif checkedP[r_faceList[0]] == -1 and checkedP[r_faceList[1]] != -1:
            r_currentP = r_faceList[0]
        elif checkedP[r_faceList[1]] == -1 and checkedP[r_faceList[0]] != -1:
            r_currentP = r_faceList[1]
        elif checkedP[r_faceList[1]] == -1 and checkedP[r_faceList[0]] == -1:
            raise Exception('not able to make symmetry with this mesh')
        elif checkedP[r_faceList[1]] != -1 and checkedP[r_faceList[0]] != -1:
            continue

        checkedP[r_currentP] = l_currentP
        checkedP[l_currentP] = r_currentP

        l_edgeVertices0, l_edgeVertices1 = fnMesh.getEdgeVertices(l_currentE)
        r_edgeVertices0, r_edgeVertices1 = fnMesh.getEdgeVertices(r_currentE)

        timeB += time.time() - t
        t = time.time()

        if l_currentE == firstEdge:
            checkedV[l_edgeVertices0] = r_edgeVertices0
            checkedV[l_edgeVertices1] = r_edgeVertices1
            checkedV[r_edgeVertices0] = l_edgeVertices0
            checkedV[r_edgeVertices1] = l_edgeVertices1
        else:
            if checkedV[l_edgeVertices0] == -1 and checkedV[r_edgeVertices0] == -1:
                checkedV[l_edgeVertices0] = r_edgeVertices0
                checkedV[r_edgeVertices0] = l_edgeVertices0
            if checkedV[l_edgeVertices1] == -1 and checkedV[r_edgeVertices1] == -1:
                checkedV[l_edgeVertices1] = r_edgeVertices1
                checkedV[r_edgeVertices1] = l_edgeVertices1
            if checkedV[l_edgeVertices0] == -1 and checkedV[r_edgeVertices1] == -1:
                checkedV[l_edgeVertices0] = r_edgeVertices1
                checkedV[r_edgeVertices1] = l_edgeVertices0
            if checkedV[l_edgeVertices1] == -1 and checkedV[r_edgeVertices0] == -1:
                checkedV[l_edgeVertices1] = r_edgeVertices0
                checkedV[r_edgeVertices0] = l_edgeVertices1

        sideV[l_edgeVertices0] = 2
        sideV[l_edgeVertices1] = 2
        sideV[r_edgeVertices0] = 1
        sideV[r_edgeVertices1] = 1

        timeC += time.time() - t
        t = time.time()

        r_faceEdgesCount = 0
        for edge in connectedEdgesPerFaces[r_currentP]:
            if len(r_faceEdges) > r_faceEdgesCount:
                r_faceEdges[r_faceEdgesCount] = edge
            else:
                r_faceEdges.append(edge)
            r_faceEdgesCount += 1

        l_faceEdgesCount = 0
        for edge in connectedEdgesPerFaces[l_currentP]:
            if len(l_faceEdges) > l_faceEdgesCount:
                l_faceEdges[l_faceEdgesCount] = edge
            else:
                l_faceEdges.append(edge)
            l_faceEdgesCount += 1


        timeD += time.time() - t
        t = time.time()

        for i in range(l_faceEdgesCount):

            if checkedE[l_faceEdges[i]] == -1:

                edgeIter.setIndex(l_currentE)

                if edgeIter.connectedToEdge(l_faceEdges[i]) and l_currentE != l_faceEdges[i]:

                    l_ifCheckedVertice0, l_ifCheckedVertice1 = fnMesh.getEdgeVertices(l_faceEdges[i])
                    if l_ifCheckedVertice0 == l_edgeVertices0 or l_ifCheckedVertice0 == l_edgeVertices1:
                        l_checkedVertex = l_ifCheckedVertice0
                        l_nonCheckedVertex = l_ifCheckedVertice1
                    elif l_ifCheckedVertice1 == l_edgeVertices0 or l_ifCheckedVertice1 == l_edgeVertices1:
                        l_checkedVertex = l_ifCheckedVertice1
                        l_nonCheckedVertex = l_ifCheckedVertice0
                    else:
                        continue

                    for k in range(r_faceEdgesCount):
                        edgeIter.setIndex(r_currentE)
                        if edgeIter.connectedToEdge(r_faceEdges[k]) and r_currentE != r_faceEdges[k]:
                            r_faceEdgeVertice0, r_faceEdgeVertice1 = fnMesh.getEdgeVertices(r_faceEdges[k])

                            if r_faceEdgeVertice0 == checkedV[l_checkedVertex]:
                                checkedV[l_nonCheckedVertex] = r_faceEdgeVertice1
                                checkedV[r_faceEdgeVertice1] = l_nonCheckedVertex
                                sideV[l_nonCheckedVertex] = 2
                                sideV[r_faceEdgeVertice1] = 1
                                l_edgeQueue.append(l_faceEdges[i])
                                r_edgeQueue.append(r_faceEdges[k])

                            if r_faceEdgeVertice1 == checkedV[l_checkedVertex]:
                                checkedV[l_nonCheckedVertex] = r_faceEdgeVertice0
                                checkedV[r_faceEdgeVertice0] = l_nonCheckedVertex
                                sideV[l_nonCheckedVertex] = 2
                                sideV[r_faceEdgeVertice0] = 1
                                l_edgeQueue.append(l_faceEdges[i])
                                r_edgeQueue.append(r_faceEdges[k])

        timeE += time.time() - t
        t = time.time()

    # print 'timeA:', timeA, 'timeB:', timeB, 'timeC:', timeC, 'timeD:', timeD, 'timeE:', timeE,

    xAverage2 = 0
    xAverage1 = 0
    # checkPosPoint = OpenMaya2.MPoint()
    for i in range(pointCount):
        if checkedV[i] != i and checkedV[i] != -1:
            checkPosPoint = fnMesh.getPoint(checkedV[i])
            if sideV[i] == 2:
                xAverage2 += checkPosPoint.x
            if sideV[i] == 1:
                xAverage1 += checkPosPoint.x

    switchSide = xAverage2 < xAverage1

    for i in range(pointCount):
        mapArray.append(checkedV[i])
        if checkedV[i] != i:
            if not switchSide:
                sideArray.append(sideV[i])
            else:
                if sideV[i] == 2:
                    sideArray.append(1)
                else:
                    sideArray.append(2)
        else:
            sideArray.append(0)

    for i in range(len(mapArray)):
        if mapArray[i] == -1:
            mapArray[i] = i

    return np.array(mapArray, dtype=int), np.array(sideArray, dtype=int), baseObjectName





class MirrorDirection(object):
    leftToRight = 0
    rightToLeft = 1
    flip = 2



def setMirrorTableMiddleMeshes(sMeshes, sType='I'):
    try:
        for sMesh in sMeshes:
            if sType == 'F':
                pMesh = patch.patchFromName(sMesh)
                aFaceVertices, aCoords, aSide = pMesh.getMirrorTablePointsOnFaces()

                utils.addStringAttr(sMesh, 'iFaceVertices', str([list(x) for x in aFaceVertices]), bLock=True)
                utils.addStringAttr(sMesh, 'fCoords', str([list(x) for x in aCoords]), bLock=True)
                utils.addStringAttr(sMesh, 'iSideArray', str(list(aSide)), bLock=True)

            elif sType in ['E', 'V']:
                if sType == 'E':
                    sEdges = cmds.ls(sl=True, flatten=True)
                    if len(sEdges) != 1:  # or '.e[' not in sEdges[0]:
                        cmds.confirmDialog(m='you need to select a middle edge or mesh')
                        return
                    sEdge = sEdges[0]
                    if '.e[' not in sEdge:
                        sEdge = detectMiddleEdge(sEdge, bReturnString=True)

                    aMapArray, aSideArray, _ = analizeTopology(sEdge)

                    utils.addStringAttr(sMesh, 'iMapArray', list(aMapArray), bLock=True)
                    utils.addStringAttr(sMesh, 'iSideArray', list(aSideArray), bLock=True)
                elif sType == 'V':
                    fClosestArray = cmds.kt_findClosestPoints(fromMesh=sMesh, toMesh=sMesh, vertex=True,
                                                              mirror=True)
                    aTable = np.array(fClosestArray, dtype='int')

                    pMesh = patch.patchFromName(sMesh)
                    aBasePoints = pMesh.getAllPoints()
                    aSide = np.where(aBasePoints[:, 0] > 0.0, 1, 2)
                    aSide[aTable == np.arange(len(aTable))] = 0
                    utils.addStringAttr(sMesh, 'iMapArray', list(aTable), bLock=True)
                    utils.addStringAttr(sMesh, 'iSideArray', list(aSide), bLock=True)

            utils.addStringAttr(sMesh, 'sMirrorFlag', sType, bLock=True)

            # sSideMirrorMeshAttr = '%s.sOppositeMesh' % sMesh
            # if cmds.objExists(sSideMirrorMeshAttr):
            #     cmds.deleteAttr(sSideMirrorMeshAttr)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise



def setMirrorTableSideMeshes(sMeshes, sType='I'): #iType: I=ids, V=vertex, F=faces
    try:
        for sMesh in sMeshes:
            sOppositeMesh = library.getMirrorName(sMesh)
            if sOppositeMesh == sMesh:
                raise Exception('"%s" doesn\'t seem to be a side mesh. Try changing the name.' % sOppositeMesh)
            elif not cmds.objExists(sOppositeMesh):
                raise Exception('Mirror mesh for "%s" not found ("%s").' % (sMesh, sOppositeMesh))

            utils.addStringAttr(sMesh, 'sOppositeMesh', sOppositeMesh, bLock=True)
            utils.addStringAttr(sMesh, 'sMirrorFlag', 'S%s' % sType, bLock=True)
            if sType in ['I', 'V']:
                if sType == 'I':
                    aTable = np.arange(cmds.polyEvaluate(sMesh, vertex=True))
                elif sType == 'V':
                    fClosestArray = cmds.kt_findClosestPoints(fromMesh=sMesh, toMesh=sOppositeMesh, vertex=True, mirror=True)
                    aTable = np.array(fClosestArray, dtype='int')
                utils.addStringAttr(sMesh, 'iMapArray', list(aTable), bLock=True)

            elif sType == 'F':
                pMesh = patch.patchFromName(sMesh)
                aFaceVertices, aCoords, aSide = pMesh.getMirrorTablePointsOnFaces(patch.patchFromName(sOppositeMesh))
                utils.addStringAttr(sMesh, 'iFaceVertices', str([list(x) for x in aFaceVertices]), bLock=True)
                utils.addStringAttr(sMesh, 'fCoords', str([list(x) for x in aCoords]), bLock=True)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise






def mirrorTargets(sBlendShape, sTargets, sMeshes, iDirection, sFromTargets=None, bCheckForFaceCombos=True, dRigPoseAttrs={}):

    if sBlendShape == None:
        if len(sMeshes) > 1:
            raise Exception('When sBlendShape is None, you can have only one sMesh, currently %d are specified' % len(sMeshes))
        sBlendShape = 'blendShape__%s' % sMeshes[0]
        bChooseBlendShapeFromMeshName = True
    else:
        bChooseBlendShapeFromMeshName = False

    bPassedTargets = not library.isNone(sTargets)
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

    sFromBlendShape = sBlendShape
    print ('sFromBlendShape: ', sFromBlendShape)
    # dFromAllTargets = dict(dAllTargets)

    if bPassedTargets:
        if isinstance(sTargets, type(None)):
            sTargets = list(dAllTargets.keys())
        sTargets.sort(key=lambda x: x.count('_'))

        if utils.isNone(sFromTargets):
            sFromTargets = list(sTargets)
        else:
            if len(sFromTargets) != len(sTargets):
                raise Exception('If you pass sFromTargets, those need to be the same length as sTargets')

    else:
        sTargets = [None]
        sFromTargets = [None]


    cmds.undoInfo(openChunk=True)
    try:
        sSelBefore = cmds.ls(sl=True)

        # first gather tagged infos from mesh(es)
        #
        sMirrorMeshes = []
        pMirrorMeshes = {}
        aaTables = {}
        aaSides = {}
        dFromMeshes = {}
        aaFaceVertices = {}
        aaCords = {}
        dMirrorFlags = {}
        print ('sMeshes: ', sMeshes)
        for sM in sMeshes:
            sMirrorFlagAttr = '%s.sMirrorFlag' % sM
            if cmds.objExists(sMirrorFlagAttr):
                dMirrorFlags[sM] = cmds.getAttr(sMirrorFlagAttr)
            else:
                cmds.warning('Mirror Table not set for "%s"' % sM)
                continue
            print ('dMirrorFlags[sM]: ', dMirrorFlags[sM])
            if dMirrorFlags[sM].startswith('S'):
                sFromMeshAttr = '%s.sOppositeMesh' % sM
                sFromM = cmds.getAttr(sFromMeshAttr)
                if not cmds.objExists(sFromM):
                    raise Exception('opposite mesh (%s) doesn\'t exist anymore' % sFromM)
                
                sMirrorMeshes.extend([sM, sFromM])
                pMesh = patch.patchFromName(sM, bConsiderSelection=True)
                pFromMesh = patch.patchFromName(sFromM, bConsiderSelection=True)
                pMirrorMeshes[sM] = pMesh
                pMirrorMeshes[sFromM] = pFromMesh
                dFromMeshes[sM] = sFromM
                dFromMeshes[sFromM] = sM
                if bChooseBlendShapeFromMeshName:
                    sFromBlendShape = 'blendShape__%s' % sFromM
                dFromAllTargets = library.getTargetsDictFromBlendShape(sFromBlendShape, bPerTargetNames=True)

                if dMirrorFlags[sM][1] == 'F':
                    aaFaceVertices[sM] = np.array(eval(cmds.getAttr('%s.iFaceVertices' % sM)), dtype=int)
                    aaCords[sM] = np.array(eval(cmds.getAttr('%s.fCoords' % sM)), dtype='float64')
                elif dMirrorFlags[sM][1] in ['I', 'V']:
                    aaTables[sM] = np.array(eval(cmds.getAttr( '%s.iMapArray' % sM)), dtype=int)
                else:
                    raise Exception('Unknown mirror flag')

            else:
                sSideArrayAttr = '%s.iSideArray' % sM
                aaSides[sM] = np.array(eval(cmds.getAttr(sSideArrayAttr)), dtype=int)
                pMesh = patch.patchFromName(sM, bConsiderSelection=True)
                pMirrorMeshes[sM] = pMesh
                sMirrorMeshes.append(sM)

                if dMirrorFlags[sM] == 'F':
                    aaFaceVertices[sM] = np.array(eval(cmds.getAttr('%s.iFaceVertices' % sM)), dtype=int)
                    aaCords[sM] = np.array(eval(cmds.getAttr('%s.fCoords' % sM)), dtype='float64')
                elif dMirrorFlags[sM] in ['E', 'V']:
                    aaTables[sM] = np.array(eval(cmds.getAttr( '%s.iMapArray' % sM)), dtype=int)
                else:
                    raise Exception('Unknown mirror flag (%s)' % dMirrorFlags[sM])


        if bPassedTargets:
            dWeightsBefore = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), bSkipComboTargets=bCheckForFaceCombos, dRigPoseAttrs=dRigPoseAttrs)
            if sFromBlendShape != sBlendShape:
                dWeightsBefore.update(disconnectAndResetTargets(sFromBlendShape, list(dFromAllTargets.keys()), bSkipComboTargets=bCheckForFaceCombos))


        # cmds.setAttr('%s.envelope' % sBlendShape, 1.0) # do we need this???

        aaBasePoints = {}
        if bPassedTargets:
            qStatusWindow = utilsQt.QStatusWindow('Mirror')
            qStatusWindow.setCount(len(sTargets))


        if not sMirrorMeshes:
            cmds.confirmDialog(m='None of the meshes have table attributes')
            return


        for sT, sFromT in zip(sTargets, sFromTargets): # in shapeEditor sT and sFromT are always the same
            if bPassedTargets:
                xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sT, bCheckForFaceCombos=bCheckForFaceCombos)
                print ('sFromBlendShape 1: ', sFromBlendShape)
                xFromSetTargetAttrs = getSetTargetAttrs(sFromBlendShape, sFromT, bCheckForFaceCombos=bCheckForFaceCombos)
                fSubTargets = blendShapes.getInbetweenFloats(sBlendShape, dAllTargets[sT]) + [1.0]
            else:
                fSubTargets = [None]

            if bPassedTargets:
                qStatusWindow.increment()

            for fInbetween in fSubTargets:

                # pose the rig (if there is a rig)
                if bPassedTargets:
                    for _sT in [sT, sFromT]:
                        for sA, fV in dRigPoseAttrs.get(_sT, {}).items():
                            if cmds.getAttr(sA, settable=True):
                                cmds.setAttr(sA, fV * fInbetween)
                else:
                    dWeightsBeforeNotPassedTargets = disconnectAndResetTargets(sBlendShape, list(dAllTargets.keys()), bSkipComboTargets=bCheckForFaceCombos, dRigPoseAttrs=dRigPoseAttrs)

                # get the base points. It's only stored in global array because of side meshes
                # print ('sMirrorMeshes: ', sMirrorMeshes)
                for m, sM in enumerate(sMirrorMeshes):
                    aaBasePoints[sM] = pMirrorMeshes[sM].getAllPoints()

                if not bPassedTargets:
                    reconnectTargets(dWeightsBeforeNotPassedTargets)

                # finally do the mirror
                for m, sM in enumerate(sMirrorMeshes):
                    pMesh = pMirrorMeshes[sM]
                    sMirrorFlag = dMirrorFlags.get(sM, None)
                    if sMirrorFlag == None:
                        continue

                    if bPassedTargets:
                        [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xFromSetTargetAttrs]


                    if sMirrorFlag.startswith('S'):
                        sFromM = dFromMeshes[sM]
                        aTarget = pMirrorMeshes[sFromM].getAllPoints()
                    else:
                        aTarget = pMesh.getAllPoints()

                    if bPassedTargets:
                        [cmds.setAttr(sAttr, 0.0) for sAttr,fPerc in xFromSetTargetAttrs]
                        [cmds.setAttr(sAttr, fInbetween*fPerc) for sAttr,fPerc in xSetTargetAttrs]

                        cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT], inbetweenWeight=fInbetween)


                    if sMirrorFlag.startswith('S'):
                        if iDirection == MirrorDirection.leftToRight:
                            if library.getSide(sM) == 'l':
                                continue
                        elif iDirection == MirrorDirection.rightToLeft:
                            if library.getSide(sM) == 'r':
                                continue
                        sFromM = dFromMeshes[sM]

                        aDefault = pMesh.getAllPoints()

                        if sMirrorFlag[1] == 'F':
                            aFaceVertices = aaFaceVertices[sM]
                            aCoords = aaCords[sM]
                            aDiffsPlusZero = np.concatenate([aTarget - aaBasePoints[sFromM], [[0, 0, 0]]])
                            aMultiplied = aDiffsPlusZero[aFaceVertices] * aCoords[ ..., np.newaxis]
                            aSum = np.sum(aMultiplied, axis=1)
                            aSum[:, 0] *= -1.0
                            aMirrored = aaBasePoints[sM] + aSum
                        elif sMirrorFlag[1] in ['I', 'V']:
                            # print ('aTarget: ', aTarget[0])
                            # print ('aaBasePoints: ', aaBasePoints[sFromM][0])
                            # print ('aaBasePoints: ', aaBasePoints[sM][0])
                            aDiffs = aTarget - aaBasePoints[sFromM]
                            aDiffs[:,0] *= -1.0
                            # print ('aDiffs: ', aDiffs[0])
                            aDiffsMapped = aDiffs[aaTables[sM]]
                            # print ('aDiffsMapped: ', aDiffsMapped[0])
                            aMirrored = aaBasePoints[sM] + aDiffsMapped
                        else:
                            raise Exception('Invalid Mirror Flag (%s)' % sMirrorFlag)

                        if not isinstance(pMesh.aSofts, type(None)):
                            aSoftAll = np.zeros(pMesh.getTotalCount())
                            aSoftAll[pMesh.aIds] = np.array(pMesh.aSofts, dtype='float64')
                            aSoft2d = aSoftAll[:, np.newaxis]
                            aMirrored = np.multiply(aMirrored, aSoft2d) + np.multiply(aaBasePoints[sM], 1 - aSoft2d)


                    else:

                        # aDefault = np.copy(aTarget)
                        aDefault = pMesh.getAllPoints() # fixed recently!!

                        if iDirection == MirrorDirection.flip:
                            aChangeIds = pMesh.aIds
                        else:
                            aChangeIds = np.array(np.where(aaSides[sM] == (2 if iDirection == MirrorDirection.leftToRight else 1))[0], dtype=int)
                            aChangeIds = np.intersect1d(aChangeIds, pMesh.aIds)

                        aMirrored = np.copy(aDefault)

                        if sMirrorFlag == 'F':
                            aFaceVertices = aaFaceVertices[sM][aChangeIds]
                            aCoords = aaCords[sM][aChangeIds]
                            aDiffsPlusZero = np.concatenate([aTarget - aaBasePoints[sM], [[0, 0, 0]]])
                            aMultiplied = aDiffsPlusZero[aFaceVertices] * aCoords[ ..., np.newaxis]
                            aSum = np.sum(aMultiplied, axis=1)
                            aSum[:, 0] *= -1.0
                            aMirrored[aChangeIds] = aaBasePoints[sM][aChangeIds] + aSum

                        elif sMirrorFlag in ['V', 'E']: # vertex position and edgeflow have same mirror process
                            aDiff = aTarget - aaBasePoints[sM]
                            aDiff[:, 0] *= -1
                            aDiffSelected = aDiff[aaTables[sM]]

                            aMirrored[aChangeIds] = aaBasePoints[sM][aChangeIds] + aDiffSelected[aChangeIds]
                            if iDirection != MirrorDirection.flip:
                                aMiddleIds = np.intersect1d(pMesh.aIds, np.array(np.where(aaSides[sM] == 0)[0], dtype=int))
                                aMirrored[aMiddleIds, 0] = aaBasePoints[sM][aMiddleIds, 0]

                        if not isinstance(pMesh.aSofts, type(None)):
                            aSoftAll = np.ones(pMesh.getTotalCount())
                            aSoftAll[pMesh.aIds] = np.array(pMesh.aSofts, dtype='float64')
                            aSoft2d = aSoftAll[:, np.newaxis]
                            aMirrored[aChangeIds] = np.multiply(aMirrored[aChangeIds], aSoft2d[aChangeIds]) + np.multiply(aDefault[aChangeIds], 1 - aSoft2d[aChangeIds])

                    # print ('aMirrored: ', aMirrored[1082], aMirrored[449])
                    # print ('aaBasePoints[sM]: ', aaBasePoints[sM][1082], aaBasePoints[sM][449])

                    aVects = (aMirrored - aDefault)
                    aSums = np.sum(np.square(aVects), axis=1)
                    aDifferentIds = np.array(np.where(aSums > 0.0000000001)[0], dtype=int)
                    pMesh.setPoints(aMirrored[aDifferentIds], aIds=aDifferentIds)

            if bPassedTargets:
                [cmds.setAttr(sAttr, 0.0) for sAttr, fPerc in xSetTargetAttrs]


    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.select(sSelBefore)
        if bPassedTargets:
            cmds.sculptTarget(sBlendShape, e=True, t=-1)
            reconnectTargets(dWeightsBefore)
            qStatusWindow.end()
        cmds.undoInfo(closeChunk=True)



def mirrorWeights(sBlendShape, sTargets, sMeshes, iDirection):

    sTargets = library.toList(sTargets)

    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    if isinstance(sTargets, type(None)):
        sTargets = list(dAllTargets.keys())


    cmds.undoInfo(openChunk=True)
    try:
        dMeshIndices = library.getBlendShapeMeshTransforms(sBlendShape, bReturnIndexDict=True)

        sMirrorMeshes = []
        pMirrorMeshes = []
        aaTables = []
        aaSides = []
        for sM in sMeshes:
            sMapArrayAttr = '%s.iMapArray' % sM
            sSideArrayAttr = '%s.iSideArray' % sM
            if cmds.objExists(sMapArrayAttr):
                sMirrorMeshes.append(sM)
                iMapArray = eval(cmds.getAttr(sMapArrayAttr))
                iSideArray = eval(cmds.getAttr(sSideArrayAttr))
                aaTables.append(np.array(iMapArray, dtype=int))
                aaSides.append(np.array(iSideArray, dtype=int))
                pMesh = patch.patchFromName(sM, bConsiderSelection=True)
                pMirrorMeshes.append(pMesh)

        if not sMirrorMeshes:
            cmds.confirmDialog(m='None of the meshes have table attributes')
            return


        for sT in sTargets:

            for m,sMesh in enumerate(sMirrorMeshes):
                iMeshIndex = dMeshIndices[sMesh]
                iVertexCount = cmds.polyEvaluate(sMesh, vertex=True)
                if sT == None:
                    sWeightsAttr = '%s.inputTarget[%d].baseWeights[0:%d]' % (sBlendShape, iMeshIndex, iVertexCount - 1)
                else:
                    sWeightsAttr = '%s.inputTarget[%d].inputTargetGroup[%s].targetWeights[0:%d]' % (sBlendShape, iMeshIndex, dAllTargets[sT], iVertexCount - 1)

                aWeights = np.array(cmds.getAttr(sWeightsAttr), dtype='float64')
                aMirroredWeights = np.copy(aWeights)
                if iDirection == 0:
                    aToIds = np.where(aaSides[m] == 2)[0]
                elif iDirection == 1:
                    aToIds = np.where(aaSides[m] == 1)[0]
                elif iDirection == 2:
                    aToIds = np.arange(iVertexCount)
                else:
                    raise Exception('unknown direction', iDirection)
                aMirroredWeights[aToIds] = aWeights[aaTables[m][aToIds]]

                cmds.setAttr(sWeightsAttr, *list(aMirroredWeights))


    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)





def getMayaCombinationShape(sBlendShape):
    sCombinationConns = cmds.listConnections(sBlendShape, t='combinationShape', s=True, d=False, p=True, c=True) or []
    dInbetweens = {}
    for t in range(0, len(sCombinationConns), 2):
        sTargetAttr = sCombinationConns[t]
        sTarget = sTargetAttr.split('.')[-1]
        sComb = sCombinationConns[t + 1].split('.')[0]

        sMainTargetAttrs = cmds.listConnections(sComb, s=True, d=False, p=True)
        sMainTargets = [sAttr.split('.')[-1] for sAttr in sMainTargetAttrs]

        dInbetweens[sTarget] = sMainTargets

    return dInbetweens





class adjustCornerMapsOptions():
    firstChangesOthers = 0
    highest = 1
    lowest = 2
    average = 3


def alignTargets(sBlendShape, sMesh, xxData, aMask, bMirror=True, iMode=adjustCornerMapsOptions.firstChangesOthers):
    iCornerPoint50 = 21166
    aaSplitWeights = geometry.getSplitWeights(sMesh)
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    cmds.undoInfo(openChunk=True)
    try:
        dWeightsBefore = {}
        for sT in list(dAllTargets.keys()):
            sAttr = '%s.%s' % (sBlendShape, sT)
            sConns = cmds.listConnections(sAttr, s=True, d=False, p=True)
            if sConns:
                dWeightsBefore[sAttr] = sConns[0]
                cmds.disconnectAttr(sConns[0], sAttr)
            else:
                dWeightsBefore[sAttr] = cmds.getAttr(sAttr)
            cmds.setAttr(sAttr, 0.0)


        pMesh = patch.patchFromName(sMesh)

        dPoints = {}
        ssExistingTargets = []
        iModes = []
        ddSetTargetAttrs = {}

        for iPart, xData in enumerate(xxData):
            sTargets, iAxis, iMode, iCornerPoint = xData
            sExistingTargets = [sT for sT in sTargets if sT == None or cmds.objExists('%s.%s' % (sBlendShape, sT))]
            ssExistingTargets.append(sExistingTargets)
            iModes.append(iMode)

            for t,sT in enumerate(sExistingTargets):
                dSetAttrs = {}
                if sT != None:
                    dSetAttrs['%s.%s' % (sBlendShape, sT)] =  1.0
                    if '_' in sT:
                        dComboMainTargets = getPercsFromComboName(sT)
                        for sMainT, iPerc in dComboMainTargets.items():
                            dSetAttrs['%s.%s' % (sBlendShape, sMainT)] = iPerc * 0.01

                [cmds.setAttr(sA,fV) for sA,fV in dSetAttrs.items()]
                dPoints[sT] = pMesh.getPoints()
                [cmds.setAttr(sA,0) for sA,fV in dSetAttrs.items()]
                ddSetTargetAttrs[sT] = dSetAttrs

        sMapArrayAttr = '%s.iMapArray' % sMesh
        if not cmds.objExists(sMapArrayAttr):
            raise Exception('mirror attributes missing for %s' % sMesh)
        iMapArray = eval(cmds.getAttr(sMapArrayAttr))
        aMapArray = np.array(iMapArray, dtype=int)


        for iPart, xData in enumerate(xxData):
            _, iAxis, iMode, iCornerPoint = xData

            iIgnores = []
            aFromCornerPoints = []
            for s,sSide in enumerate(['l','r'] if bMirror else ['m']):
                if s == 1:
                    iSideCornerPoint = iMapArray[iCornerPoint]
                else:
                    iSideCornerPoint = iCornerPoint

                aAllCornerPoints = np.array([dPoints[sT][iSideCornerPoint] for sT in ssExistingTargets[iPart]], dtype='float64')

                if iMode == adjustCornerMapsOptions.firstChangesOthers:
                    aFromCornerPoint = aAllCornerPoints[0]
                    iIgnore = 0
                elif iMode == adjustCornerMapsOptions.highest:
                    if iAxis == 0 and sSide == 'r':
                        iIgnore = np.argmin(aAllCornerPoints[:,iAxis])
                        aFromCornerPoint = aAllCornerPoints[iIgnore]
                    else:
                        iIgnore = np.argmax(aAllCornerPoints[:,iAxis])
                        aFromCornerPoint = aAllCornerPoints[iIgnore]
                elif iMode == adjustCornerMapsOptions.lowest:
                    if iAxis == 0 and sSide == 'r':
                        iIgnore = np.argmax(aAllCornerPoints[:,iAxis])
                        aFromCornerPoint = aAllCornerPoints[iIgnore]
                    else:
                        iIgnore = np.argmin(aAllCornerPoints[:,iAxis])
                        aFromCornerPoint = aAllCornerPoints[iIgnore]
                elif iMode == adjustCornerMapsOptions.average:
                    iIgnore = -1
                    aFromCornerPoint = np.average(aAllCornerPoints, axis=0)

                iIgnores.append(iIgnore)
                aFromCornerPoints.append(aFromCornerPoint)


            for t,sT in enumerate(ssExistingTargets[iPart]):
                if iIgnores[0] == t:
                    continue
                if sT == None:
                    raise Exception('Cannot adjust neutral pose. ')

                aPoints = np.copy(dPoints[sT])

                for s,sSide in enumerate(['l', 'r']):
                    if s == 1:
                        iSideCornerPoint = iMapArray[iCornerPoint]
                    else:
                        iSideCornerPoint = iCornerPoint

                    aSideMask = aMask * aaSplitWeights[s]

                    aSideCornerPoint = aPoints[iSideCornerPoint]
                    aOffset = aFromCornerPoints[s] - aSideCornerPoint
                    aChangeOffset = np.zeros(3, dtype='float64')
                    aChangeOffset[iAxis] = aOffset[iAxis]
                    aPointOffsets = aSideMask[:,np.newaxis] * aChangeOffset
                    aPoints += aPointOffsets
                dPoints[sT] = aPoints


        sAllExistingTargets = []
        for sTargets in ssExistingTargets:
            sAllExistingTargets += sTargets
        sAllExistingTargets = [sT for sT in list(set(sAllExistingTargets)) if sT]
        sOrderedTargets = sorted(sAllExistingTargets, key=lambda x: x.count('_'))
        for sT in sOrderedTargets:
            [cmds.setAttr(sAttr, fV) for sAttr, fV in ddSetTargetAttrs[sT].items()]
            cmds.sculptTarget(sBlendShape, e=True, t=dAllTargets[sT])
            patch.patchFromName(sMesh).setPoints(dPoints[sT], bWorld=False)
            cmds.sculptTarget(sBlendShape, e=True, t=-1)
            [cmds.setAttr(sAttr, 0.0) for sAttr,fV in ddSetTargetAttrs[sT].items()]

        for sTargetAttr, xValue in list(dWeightsBefore.items()):
            library._connectOrSet(xValue, sTargetAttr)

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def negateShapes(sBlendShape, dRelations):

    try:
        cmds.undoInfo(openChunk=True)
        resetAllShapes(sBlendShape)
        sMeshes = getMeshesFromBlendShape(sBlendShape)
        pMeshes = [patch.patchFromName(sM) for sM in sMeshes]
        aaDefaultPoints = [pM.getPoints() for pM in pMeshes]

        dTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

        cmds.sculptTarget(sBlendShape, e=True, t=-1)

        for sChangeT,sOrigT in dRelations.items():
            cmds.setAttr('%s.%s' % (sBlendShape,sOrigT), 1.0)
            aaOrigPoints = []
            for m,pM in enumerate(pMeshes):
                aaOrigPoints.append(pM.getPoints())
            cmds.setAttr('%s.%s' % (sBlendShape,sOrigT), 0.0)

            cmds.setAttr('%s.%s' % (sBlendShape,sChangeT), 1.0)
            cmds.sculptTarget(sBlendShape, e=True, t=dTargets[sChangeT])
            for m,mP in enumerate(pMeshes):
                aPoints = aaDefaultPoints[m] + (aaOrigPoints[m]-aaDefaultPoints[m]) * -1.0
                pM.setPoints(aPoints)
            cmds.setAttr('%s.%s' % (sBlendShape, sChangeT), 0.0)
        cmds.sculptTarget(sBlendShape, e=True, t=-1)


    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def getJawOpenRotation(sBlendShape, sJointNamespace, sCtrlNamespace, sSuffix=''):
    sShapeJaw = '%sjnt_m_jawMain' % (sJointNamespace)
    sJawCtrl = '%sjaw%s_ctrl' % (sCtrlNamespace, sSuffix)
    sJawOpenOverrideAttrRotZ = '%sjnt_m_jawMain.jawOpenPoseOverrideRotZ' % sCtrlNamespace
    if cmds.objExists(sJawOpenOverrideAttrRotZ):
        return [0,0,cmds.getAttr(sJawOpenOverrideAttrRotZ)], [0,0,0]

    elif cmds.objExists(sJawCtrl) and cmds.objExists(sShapeJaw) and cmds.objExists('%s.jawOpen' % sBlendShape):
        # TODO: clean up this function - this is probably (!) the only block it needs.
        #  Maybe add temp errors, and see over time if thoes situations happen
        cmds.setAttr('%s.jawOpen' % sBlendShape, 0.0)
        sJawConstraint = cmds.parentConstraint(sShapeJaw, sJawCtrl, mo=True)
        cmds.setAttr('%s.jawOpen' % sBlendShape, 1.0)

        fJawOpenRotation = cmds.getAttr('%s.r' % sJawCtrl)[0]
        fJawOpenTranslation = cmds.getAttr('%s.t' % sJawCtrl)[0]
        cmds.setAttr('%s.jawOpen' % sBlendShape, 0.0)
        cmds.delete(sJawConstraint)
        return fJawOpenRotation, fJawOpenTranslation
    else:
        return [0,0,0], [0,0,0]




def importBlendShapeFile(sFile='', sBlendShape='', bRemoveReferenceWhenDone=True, sSuffix='', bApplyInnerBlinkValues=False, bCreateTransformForInactiveMainTargets=False, report=None):

    # import kangarooTools.nodes as nodes
    import kangarooTools.assets as assets
    import kangarooTools.utilFunctions as utils


    sNamespace = 'shapes:'
    if isinstance(sBlendShape, list):
        sBlendShape = sBlendShape[0]
    if not sBlendShape.startswith(sNamespace):
        sBlendShape = '%s%s' % (sNamespace, sBlendShape)

    if ':' in sFile:
        sFullPath = sFile
    else:
        sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)

    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)
    if report:
        report.report.addLogText('importing "%s"...' % sFullPath)
    utils.importMayaFiles(sFullPath, sNamespace=sNamespace[:-1], bReference=True)

    sImportedBlendShapes = [sB for sB in cmds.ls(et='blendShape') if sB.startswith(sNamespace)]
    if len(sImportedBlendShapes) == 0:
        raise Exception('There is no blendShape imported (shapes:*)')
    elif len(sImportedBlendShapes) == 1:
        sBakeBlendShape = sImportedBlendShapes[0]
    elif len(sImportedBlendShapes) > 1:
        if sBlendShape in sImportedBlendShapes:
            sBakeBlendShape = sBlendShape
        else:
            raise Exception('There is more than one blendShapes imported (%s), but "%s" doesn\'t match any of them.'
                            'To fix, either delete all extra blendShapes in the blendShape file or specify the important one in '
                            'the argument "sBlendShape"' % \
                             (library.listToString(sImportedBlendShapes, ', ', 5), sBlendShape))

    sModel = cmds.getAttr('%s.sMainMesh' % sBakeBlendShape)
    sMeshes = getMeshesFromBlendShape(sBakeBlendShape)
    if sModel not in [sM.split(':')[-1] for sM in sMeshes]:
        sModel = sMeshes[0].split(':')[-1]
    report.report.addLogText('Baking blendShape "%s"...' % sBakeBlendShape)

    sTargets = bakeTargets(sBakeBlendShape, sMainMesh='%s%s' % (sNamespace, sModel), bJustDeltas=False, sAddSuffix=sSuffix, bCreateTransformForInactiveMainTargets=bCreateTransformForInactiveMainTargets)
    [cmds.setAttr('%s.v' % sT, False) for sT in sTargets]

    utils.data.store('sBakedBlendshapeTargets%s' % sSuffix, sTargets)
    utils.data.store('sBakedBlendshapeMainMesh%s' % sSuffix, sModel)

    fJawOpenRotation, fJawOpenTranslation = getJawOpenRotation(sBakeBlendShape, sNamespace, '', sSuffix=sSuffix)
    utils.data.store('sBakedBlendShapeJawOpenRotation%s' % sSuffix, fJawOpenRotation)
    utils.data.store('sBakedBlendShapeJawOpenTranslation%s' % sSuffix, fJawOpenTranslation)

    dEyelookPoses = getEyelookPoses(sBakeBlendShape)
    utils.data.store('dEyelookPoses%s' % sSuffix, dEyelookPoses)

    dBakedBlendShapeComboModes = eval(utils.getAttrIfExists('%s.%s' % (sBakeBlendShape, utils.kShapeEditorComboModeInfoAttr), '{}'))
    utils.data.store('dBakedBlendShapeComboModes%s' % sSuffix, dBakedBlendShapeComboModes)


    if bApplyInnerBlinkValues:
        for s,sSide in enumerate(['l','r']):
            sRigAttr = 'grp_%s_blinkPasser.innerBlinkRotate' % sSide
            sRangeNode = kInnerBlinkRangeNodes[s] % (sNamespace, sBakeBlendShape.split(':')[-1])
            sShapeFileAttr = '%s.max' % sRangeNode
            if cmds.objExists(sRigAttr) and cmds.objExists(sShapeFileAttr):
                cmds.setAttr(sRigAttr, *cmds.getAttr(sShapeFileAttr)[0])


    if bRemoveReferenceWhenDone:
        cmds.file(sFile, removeReference=True)
        sJawCtrl = 'jaw%s_ctrl' % sSuffix
        if cmds.objExists(sJawCtrl):
            cmds.setAttr('%s.r' % sJawCtrl, 0, 0, 0)
            cmds.setAttr('%s.t' % sJawCtrl, 0, 0, 0)

    # utils.data.store('sImportedHeadSuffixes', sValidSuffixes)


def addInbetween(sBlendShape, sMeshes, sTargets, fInbetween=None):
    sSelectionBefore = cmds.ls(sl=True)
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    fInbetweens = []
    cmds.undoInfo(openChunk=True)
    try:
        for sTarget in library.toList(sTargets):
            if not utils.isNone(fInbetween):
                fCurrentInbetween = fInbetween
            else:
                fCurrentInbetween = round(cmds.getAttr('%s.%s' % (sBlendShape, sTarget)), 3)

            fInbetweens.append(fCurrentInbetween)
            for sMesh in sMeshes:
                sTempDupl = cmds.duplicate(sMesh)[0]
                cmds.blendShape(sBlendShape, e=True, t=[sMesh, dAllTargets[sTarget], sTempDupl, fCurrentInbetween])
                cmds.delete(sTempDupl)
    except:
        raise
    finally:
        cmds.select(sSelectionBefore)
        cmds.undoInfo(closeChunk=True)

    return fInbetweens


def interpolateInbetweens(sBlendShape, sTarget, bClosestInbetween=False, bIsCombo=False):
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)

    pSelection = patch.getSelectedPatches()
    sBlendShapeMeshes = getMeshesFromBlendShape(sBlendShape)
    sSkip = []

    for pMesh in pSelection:
        if pMesh.getTransformName() not in sBlendShapeMeshes:
            sSkip.append(pMesh.getTransformName())

    if not pSelection:
        cmds.confirmDialog(m='No Meshes selected')
        return

    cmds.undoInfo(openChunk=True)
    try:
        sTargetAttr = '%s.%s' % (sBlendShape, sTarget)
        # xSetTargetAttrs = getSetTargetAttrs(sBlendShape, sTarget, bIncludeIfCombo=True)
        xSetTargetAttrs = [('%s.%s' % (sBlendShape, sTarget), 1.0)]
        fTargetWeight = cmds.getAttr(sTargetAttr)
        resetAllShapes(sBlendShape)
        dWeightsBefore = disconnectAndResetTargets(sBlendShape, dAllTargets.keys())

        iTarget = dAllTargets[sTarget]


        for pMesh in pSelection:
            sMesh = pMesh.getTransformName()
            pFullMesh = patch.patchFromName(sMesh)
            if sMesh not in sBlendShapeMeshes:
                sSkip.append(sMesh)
                continue
            fAllInbetweens = blendShapes.getInbetweenFloats(sBlendShape, iTarget)
            if bClosestInbetween:
                iInbetweenIndex = np.argmin(abs(np.array(fAllInbetweens, dtype='float64') - fTargetWeight))
                fRange = [fAllInbetweens[iInbetweenIndex - 1] if iInbetweenIndex > 0 else 0.0,
                          fAllInbetweens[iInbetweenIndex + 1] if iInbetweenIndex < len(fAllInbetweens) - 1 else 1.0]
                xDoInbetweens = [(fAllInbetweens[iInbetweenIndex], fRange)]
            else:
                xDoInbetweens = [(fInb, (0.0, 1.0)) for fInb in fAllInbetweens]

            for fInb, fRange in xDoInbetweens:
                [cmds.setAttr(sAttr, fRange[0]*fPerc) for sAttr,fPerc in xSetTargetAttrs]
                aFromPoints = pMesh.getAllPoints()
                [cmds.setAttr(sAttr, fRange[1]*fPerc) for sAttr,fPerc in xSetTargetAttrs]
                aToPoints = pMesh.getAllPoints()
                [cmds.setAttr(sAttr, fInb) for sAttr,fPerc in xSetTargetAttrs]
                aSetPoints = pMesh.getAllPoints()
                fT = library.projectToRange(fInb, fRange[0], fRange[1], 0.0, 1.0)
                aInterpolatedPoints = aToPoints * fT + aFromPoints * (1.0-fT)
                if library.isNone(pMesh.aSofts):
                    aSetPoints[pMesh.aIds] = aInterpolatedPoints[pMesh.aIds]
                else:
                    aSofts = pMesh.aSofts[:,np.newaxis]
                    aSetPoints[pMesh.aIds] = aInterpolatedPoints[pMesh.aIds] * aSofts + aInterpolatedPoints[pMesh.aIds] * (1.0-aSofts)

                cmds.sculptTarget(sBlendShape, e=True, t=iTarget, inbetweenWeight=fInb)
                pFullMesh.setPoints(aSetPoints)

                cmds.sculptTarget(sBlendShape, e=True, t=-1)
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        reconnectTargets(dWeightsBefore)
        cmds.undoInfo(closeChunk=True)



def deleteInbetweens(sBlendShape, sTarget, bClosestInbetween=False):
    dAllTargets = library.getTargetsDictFromBlendShape(sBlendShape, bPerTargetNames=True)
    iTarget = dAllTargets[sTarget]

    cmds.undoInfo(openChunk=True)
    try:
        iAllInbetweens = blendShapes.getInbetweenTargetIndices(sBlendShape, iTarget)
        if 5000 in iAllInbetweens:
            iAllInbetweens.remove(5000)
        if 6000 in iAllInbetweens:
            iAllInbetweens.remove(6000)

        fTargetWeight = cmds.getAttr('%s.%s' % (sBlendShape, sTarget))
        iTargetWeight = int(utils.projectToRange(fTargetWeight, 0.0, 1.0, 5000, 6000))

        if bClosestInbetween:
            iInbetweenIndex = np.argmin(abs(np.array(iAllInbetweens, dtype=int) - iTargetWeight))
            iDoInbetweens = [iAllInbetweens[iInbetweenIndex]]
        else:
            iDoInbetweens = iAllInbetweens


        print ('iDoInbetweens: ',iDoInbetweens)
        fRemoves = []
        for iInb in iDoInbetweens:
            mel.eval(f'blendShapeDeleteInBetweenTarget {sBlendShape} {iTarget} {iInb}')
            fRemoves.append(utils.projectToRange(iInb, 5000, 6000, 0.0, 1.0))

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)

    return fRemoves




def _stringTimeToFloat(sTime):
    fSplits = [float(sS) for sS in sTime.split(':')]
    return fSplits[-1] + fSplits[-2]*60.0 + fSplits[-3]*60*60 + fSplits[-4]*60*60*60


def importCSV(sBlendShape, sSide='l', sFilePath=r"C:\Users\Thomas Bittner\Downloads\KAZUE_v12_notes\Kazue_Blendshape_Test.csv"):
    import kangarooTools.utilFunctions as utils
    import kangarooTools.nodes as nodes

    dData = readFaceArCsvFile(sFilePath)


    # ANIMATION
    if sSide == 'l':
        sIgnoreSuffix = 'Right'
        sSideSuffix = 'Left'
    elif sSide == 'r':
        sIgnoreSuffix = 'Left'
        sSideSuffix = 'Right'

    fMayaDelta = 1.0
    fBiggestKey = 0
    for sAttr, fValues in list(dData.items()):
        # sLocAttr = utils.addAttr(sLoc, ln=sAttr, minValue=0.0, maxValue=1.0, k=True)
        if sAttr.endswith(sIgnoreSuffix):
            continue

        sAttr = utils.getFirstLetterLowerCase(sAttr)
        sLocAttr = '%s.%s' % (sBlendShape, sAttr)
        if not cmds.objExists(sLocAttr):
            sLocAttr = utils.replaceStringEnd(sLocAttr, sSideSuffix, '')

        if not cmds.objExists(sLocAttr):
            print ('skipping %s because %s doesn\'t exist' % (sAttr, sLocAttr))
            continue

        for f,fV in enumerate(fValues):
            cmds.setKeyframe(sLocAttr, t=f*fMayaDelta, v=fV)
            fBiggestKey = max(fBiggestKey, f*fMayaDelta)

    cmds.playbackOptions(e=True, minTime=0, maxTime=fBiggestKey)
    cmds.select(sBlendShape)


def readFaceArCsvFile(sFile):

    xxData = []
    sKeys = []

    with open(sFile) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for r,row in enumerate(csv_reader):
            # print 'row: ', row
            if line_count == 0:
                sKeys = list(row)
                xxData = [[] for i in range(len(sKeys))]
            else:
                for i, item in enumerate(row):
                    xxData[i].append(item)
            line_count += 1

    dData = OrderedDict()
    for k,sK in enumerate(sKeys):
        if k >= 2:
            dData[sK] = [float(fV) for fV in xxData[k]]

    return dData



# This is extremely slow to unlock. Maybe revisit in future
def lockVerts(xMeshes, bLock=True):
    try:
        print ('lock.. ', bLock)
        cmds.undoInfo(openChunk=True)
        for xMesh in utils.toList(xMeshes):
            sMesh = xMesh if isinstance(xMesh, str) else xMesh.getTransformName()
            if bLock:
                cmds.setAttr(f'{sMesh}.vtx[*]', lock=True)
            else:
                # mel.eval('CBunlockAttr')
                cmds.setAttr(f'{sMesh}.vtx[*]', lock=False)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



