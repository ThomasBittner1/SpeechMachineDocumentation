###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMayaUI as mui

if cmds.about(v=True) >= '2025':
    from PySide6 import QtWidgets, QtGui, QtCore
    from shiboken6 import wrapInstance

else:
    from PySide2 import QtWidgets, QtGui, QtCore
    from shiboken2 import wrapInstance

from collections import defaultdict
import json
import os
from functools import reduce
import time

global mainWin
mainWin = None

import kangarooAnimation.KangarooMatchTools as KangarooMatchTools
import kangarooAnimation.library as library

library.reload2(KangarooMatchTools)
library.reload2(library)

sDefaultCharacter = 'FullCharacter'
def getCharacter(sNamespace):
    sInfoTransform = '%sAnimPickerData' % sNamespace
    if cmds.objExists(sInfoTransform):
        return cmds.getAttr('%s.character' % sInfoTransform)
    else:
        return sDefaultCharacter


def getCharacterFiles(sNamespace):
    sCharacter = getCharacter(sNamespace)
    try:
        import kangarooTools.settings as settings
        import kangarooTools.assets as assets
        bKangarooImported = True
    except:
        print ('kangaroo tools missing, skipping settings')
        bKangarooImported = False
    sDirs = []


    sServerPathsString = os.environ['KANGAROO_PICKER_PATH'] if 'KANGAROO_PICKER_PATH' in os.environ else None
    if not library.isNone(sServerPathsString):
        sDirs.extend([sPath.strip() for sPath in sServerPathsString.split(';')])

    if bKangarooImported:
        sAdditionalPickerFilesPath = settings.getSettingsFileEntry('sAdditionalPickerFilesPath')
        if sAdditionalPickerFilesPath:
            sDirs.append(sAdditionalPickerFilesPath.replace('\\','/'))

    sToolPath = os.path.dirname(__file__).replace('\\','/')
    sDirs.append(sToolPath)

    sDirs = [sDir.split('@')[-1] for sDir in sDirs] # just to not have errors when paths are copied from module paths
    print ('found directories:\n%s' % ', '.join(sDirs))
    ssElementFiles = []
    for sDir in sDirs:
        if not (isinstance(sDir, type(None))) and sDir:
            for sContent in os.listdir(sDir):
                if sContent.endswith('.elements') and (sContent.startswith('%s.' % sCharacter) or sContent.startswith('%s_' % sCharacter)):
                    sName = sContent.split('.')[0]

                    sImageFile = os.path.join(sDir, '%s.jpg' % sName)
                    if os.path.exists(sImageFile):
                        sElementFile = os.path.join(sDir, sContent)
                        ssElementFiles.append([sImageFile, sElementFile])

    print ('found %d element files' % len(ssElementFiles))
    for sImageFile, sElementFile in ssElementFiles:
        print (sElementFile)

    return ssElementFiles


    raise Exception('%s.elements file not found, check script editor for more information' % sCharacter)




bCtrlsPost = True

kVersion = '4.5'

bShowEditBox = False
kCopyPastePrefix = 'KangarooPickerCopied:'

def showUI(bInShowEditBox):
    global bShowEditBox
    bShowEditBox = bInShowEditBox

    global mainWin
    if mainWin != None:
        mainWin.close()
    mainWin = RigAnimTool()
    mainWin.show()


def getMayaWindow():
    ptr = mui.MQtUtil.mainWindow()
    return wrapInstance(int(ptr), QtWidgets.QWidget)


def mayaSelectionChanged():
    if mainWin:
        mainWin.mayaSelectionChanged()


class CollisionType:
    sphere = 0
    halfsphere = 4
    polygon = 1
    cross = 2
    box = 3

eType = 0
eSide = 1
ePos = 2
eSize = 3
eSavedObjects = 4
eSceneObjects = 5
eCollider = 6
eMouseOverIt = 7

eBoolSelected = 8
eDrawData = 9
eEditSelected = 10
eCommands = 11
eMayaColor = 12
eMayaShape = 13 # not used yet

iNonesCount = 9 # needs to be incremented as we add e.. properties

rStartPos = 0
rEndPos = 1
rRect = 2
rCtrlKeys = 3
rCornerPoints = 4
rElementsPrevSelected = 5
rPrevSelection = 6


def fBlendedColor(fMayaColor, sSide, fPerc):
    if isinstance(fMayaColor, type(None)):
        if sSide == 'l':
            iColor = [0, 0, 255]
        if sSide == 'm':
            iColor = [255, 255, 0]
        if sSide == 'r':
            iColor = [255, 0, 0]
    else:
        iColor = [fMayaColor[0], fMayaColor[1], fMayaColor[2]]

    iBlendColor = [255 * fPerc + iColor[0] * (1.0 - fPerc),
                   255 * fPerc + iColor[1] * (1.0 - fPerc),
                   255 * fPerc + iColor[2] * (1.0 - fPerc)]

    return QtGui.QColor(*iBlendColor)


class PickerImage(QtWidgets.QWidget):
    def __init__(self, qParent, sImageFile, dFileData):

        super(PickerImage, self).__init__()
        self.setGeometry(30, 30, 500, 300)
        self.setMouseTracking(True)
        self.bLeftMouseDown = False

        self.pixmap = QtGui.QPixmap(sImageFile)
        self.xElements = dFileData.get('xElements', [])

        self.fSymmetryPos = dFileData.get('fSymmetryPos', 0.5)
        self.qSymmetryRect = None
        self.bMovingSymmetry = False

        self.qParent = qParent

        self.qPrevMousePos = None

        self.iMovingElements = set()
        self.iScalingElements = set()
        self.iWideningElements = set()
        self.fWideningPivot = None
        self.qShrinkingLastPos = None

        self.iPressedKeys = set()

        self.xSelectRect = None  # [None, None, None, False, None, []] # [startPos, endPos, rect, bShiftKey, qCornerPoints, elementsPrevSelected]

        self.resetPanZoom()

        self.iSelectedElements = set()

        self.iTextEditModeElement = None

        self.xxxUndoStack = []
        self.iUndoStackPos = 0

        self.bOptionKeyDown = False


    def setData(self, dElementsFile, sImageFile):
        self.pixmap = QtGui.QPixmap(sImageFile)
        self.xElements = dElementsFile.get('xElements', [])

        self.sAllMayaObjects = set()
        for e,xE in enumerate(self.xElements):
            self.sAllMayaObjects.update(xE[eSavedObjects])
            for i in range(iNonesCount):
                xE.append(None)


        self.fSymmetryPos = dElementsFile.get('fSymmetryPos', 0.5)
        if self.fSymmetryPos > 0.99:
            self.fSymmetryPos = 0.5
        self.updateExistInfo()
        self.update()


    def isDirty(self):
        return '*' in self.qParent.qSaveButton.text()


    def appendToEditUndoStack(self, bDirtySaveButton=False, iDebugInt=None):
        self.xxxUndoStack = self.xxxUndoStack[:self.iUndoStackPos]

        xDeepCopy = []
        for xE in self.xElements:
            xDeepCopy.append(list(xE))
        self.xxxUndoStack.append([xDeepCopy, self.isDirty()])
        self.iUndoStackPos = len(self.xxxUndoStack)

        if bDirtySaveButton:
            self.qParent.dirtySaveButton(iDebugInt=iDebugInt)


    def runUndoEdit(self):
        if self.iUndoStackPos > 0:
            self.iUndoStackPos -= 1
            self.xElements, bIsDirty = self.xxxUndoStack[self.iUndoStackPos]
            self.resetShapes()
            self.update()
            if not bIsDirty:
                self.qParent.dirtySaveButton(False)


    def resizeEvent(self, event):
        self.resetShapes()
        super(PickerImage, self).resizeEvent(event)


    def updateFromObjects(self):
        sCharacter = getCharacter(self.qParent.getNamespace())
        iTabCount = 0
        for sImageFile, sElementsFile in getCharacterFiles(sCharacter):
            dElements = library.getJsonContent(sElementsFile)
            self.setData(dElements, sImageFile)
            iTabCount += 1


    def resetShapes(self):
        for xE in self.xElements:
            xE[eDrawData] = None
        self.update()

    def editClicked(self):
        pass

    def updateExistInfo(self):
        sNamespace = self.qParent.getNamespace()
        sCurrentSelection = set(cmds.ls(sl=True))
        for e, xE in enumerate(self.xElements):
            sObjects = []
            sCommands = []
            fMayaColor = None
            for sSavedObject in xE[eSavedObjects]:
                if sSavedObject:
                    sSavedObject = sSavedObject.strip()
                    if sSavedObject.startswith('$'):
                        sCommands.append(sSavedObject[1:])
                    else:
                        sLsString = '%s%s' % (sNamespace, sSavedObject)
                        sObjects += [sT for sT in (cmds.ls(sLsString, et='transform') + cmds.ls(sLsString, et='joint'))
                                     if cmds.attributeQuery('bIsCtrl', node=sT, exists=True) or cmds.attributeQuery('ctrlType', node=sT, exists=True)]
            for o,sO in enumerate(sObjects):
                if o == 0:
                    fMayaColor = [0,0,0]
                sShapes = cmds.listRelatives(sO, s=True, typ='nurbsCurve')
                sColorO = sShapes[0] if sShapes else sO
                fColor = cmds.getAttr('%s.overrideColorRGB' % sColorO)[0]
                
                fMayaColor[0] += fColor[0]
                fMayaColor[1] += fColor[1]
                fMayaColor[2] += fColor[2]
            if len(sObjects) > 1:
                fMayaColor[0] /= len(sObjects)
                fMayaColor[1] /= len(sObjects)
                fMayaColor[2] /= len(sObjects)
            if len(sObjects) > 0:
                fMayaColor[0] *= 255
                fMayaColor[1] *= 255
                fMayaColor[2] *= 255

            xE[eSceneObjects] = [sO[sO.rfind(':')+1:] for sO in sObjects]  # array of existing objects
            xE[eCommands] = sCommands
            xE[eBoolSelected] = [(sO in sCurrentSelection) for sO in xE[eSceneObjects]]

            xE[eMayaColor] = fMayaColor
            xE[eMayaShape] = [1,0,0]
            self.sAllMayaObjects.update(xE[eSceneObjects])

    def resetPanZoom(self):
        self.xPan = [QtCore.QPoint(0, 0), None]  # [currentRectPos, lastMousePos]
        self.xZoom = [1.0, None, None]  # [currentRectScale, lastMousePos, origMousePos]

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        qCanvasRect = self.rect()

        fZoom = self.xZoom[0]
        fDenomZoom = 1.0 / fZoom
        fWindowScaled = float(qCanvasRect.width()) / 1280

        qZoomedRect = QtCore.QRect(qCanvasRect.x() + self.xPan[0].x(), qCanvasRect.y() + self.xPan[0].y(),
                                   qCanvasRect.width() * fZoom, qCanvasRect.height() * fZoom)
        fZoomedOffsetX = qZoomedRect.x()
        fZoomedOffsetY = qZoomedRect.y()
        painter.drawPixmap(qZoomedRect, self.pixmap)

        if self.xSelectRect != None and self.xSelectRect[rStartPos] and self.xSelectRect[rEndPos]:
            qDrawRect = QtCore.QRect(QtCore.QPoint(qZoomedRect.width() * self.xSelectRect[rStartPos][0] * fDenomZoom,
                                                   qZoomedRect.height() * self.xSelectRect[rStartPos][1] * fDenomZoom),
                                     QtCore.QPoint(qZoomedRect.width() * self.xSelectRect[rEndPos][0] * fDenomZoom,
                                                   qZoomedRect.height() * self.xSelectRect[rEndPos][1] * fDenomZoom))

            fLeft, fRight = self.xSelectRect[rRect].left(), self.xSelectRect[rRect].right()
            fBot, fTop = self.xSelectRect[rRect].bottom(), self.xSelectRect[rRect].top()
            self.xSelectRect[rCornerPoints] = [QtCore.QPoint(fLeft, fTop), QtCore.QPoint(fRight, fTop),
                                               QtCore.QPoint(fRight, fBot), QtCore.QPoint(fLeft, fBot),
                                               QtCore.QPoint(fLeft, fTop)]
            self.xSelectRect[rRect] = qDrawRect
            painter.drawRect(qDrawRect)

            painter.setBrush(QtGui.QBrush(QtGui.QColor(255, 255, 255, 25), QtCore.Qt.SolidPattern))
            painter.drawRect(qDrawRect)
        for e, xE in enumerate(self.xElements):

            if not self.qParent.qEditModeBox.isChecked():
                if not xE[eSceneObjects] and not xE[eCommands]:
                    continue

            sType = xE[eType]

            if not self.qParent.qEditModeBox.isChecked():
                if len(xE[eSceneObjects]):
                    fPerc = _perc(xE[eBoolSelected])
                else:
                    fPerc = 1.0
            else:
                fPerc = 1.0 if xE[eEditSelected] else 0.0

            if sType == 'sphere':
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]
                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))
                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fFactor * fZoom * fWindowScaled
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                             fSize, fSize)
                else:
                    qDrawRect = xE[eDrawData]

                xE[eCollider] = [qDrawRect, (CollisionType.sphere, qDrawRect.center(), (fSize * 0.5) * (fSize * 0.5))]
                painter.drawEllipse(qDrawRect.x(), qDrawRect.y(), qDrawRect.width(), qDrawRect.height())

            if sType == 'halfsphere':
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]
                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))
                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fFactor * fZoom * fWindowScaled
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                             fSize, fSize)
                else:
                    qDrawRect = xE[eDrawData]

                painter.drawChord(qDrawRect.x(), qDrawRect.y(), qDrawRect.width(), qDrawRect.height(), 0, 180*16)

                qSecondCollisionRect = QtCore.QRect(qDrawRect)
                qSecondCollisionRect.setHeight(qSecondCollisionRect.height() * 0.5)

                xE[eCollider] = [qSecondCollisionRect,
                                 (CollisionType.halfsphere, qDrawRect.center(), (fSize * 0.5) * (fSize * 0.5), qSecondCollisionRect)]

            elif sType == 'circle':
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]
                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))
                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fDrawSize = fSize * fFactor * fZoom * fWindowScaled
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fDrawSize * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fDrawSize * 0.5,
                                             fDrawSize, fDrawSize)
                else:
                    qDrawRect = xE[eDrawData]

                iHalfThickness = 4
                fScaledHalfThickness = iHalfThickness * fZoom * fWindowScaled
                qColliderRect = QtCore.QRect(qDrawRect.x() - fScaledHalfThickness,
                                             qDrawRect.y() - fScaledHalfThickness,
                                             qDrawRect.width() + fScaledHalfThickness,
                                             qDrawRect.height() + fScaledHalfThickness)
                fColliderSize = (fSize+iHalfThickness*2) * fFactor * fZoom * fWindowScaled
                xE[eCollider] = [qColliderRect, (CollisionType.sphere, qDrawRect.center(), (fColliderSize * 0.5) * (fColliderSize * 0.5))]

                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, fScaledHalfThickness*2, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(QtCore.Qt.white, QtCore.Qt.NoBrush))

                painter.drawEllipse(qDrawRect.x(), qDrawRect.y(), qDrawRect.width(), qDrawRect.height())

            elif sType == 'arrow':
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]

                qColor = fBlendedColor(fMayaColor, sSide, fPerc)

                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fZoom * fFactor * fWindowScaled
                    qDrawPoints = [QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0],
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] + fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] + fSize * 0.25,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] + fSize * 0.25,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] + fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0],
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.5),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.25,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.25),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.25,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.25),
                                   ]

                    qPolygon = QtGui.QPolygon(qDrawPoints)
                    qButtonRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                               fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                               fSize, fSize)
                    xE[eDrawData] = qButtonRect, qPolygon, qDrawPoints
                else:
                    qButtonRect, qPolygon, qDrawPoints = xE[eDrawData]

                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))

                painter.drawPolygon(qPolygon)
                xE[eCollider] = [qButtonRect, (CollisionType.polygon, qDrawPoints, qPolygon)]

            elif sType == 'triangle':
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]

                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fZoom * fFactor * fWindowScaled
                    qDrawPoints = [QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.5),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0],
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] + fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.5),
                                   QtCore.QPoint(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                                 fZoomedOffsetY + qZoomedRect.height() * fPos[1] + fSize * 0.5)]

                    qPolygon = QtGui.QPolygon(qDrawPoints)
                    qButtonRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                               fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                               fSize, fSize)
                    xE[eDrawData] = qButtonRect, qPolygon, qDrawPoints
                else:
                    qButtonRect, qPolygon, qDrawPoints = xE[eDrawData]

                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))
                painter.drawPolygon(qPolygon)
                xE[eCollider] = [qButtonRect, (CollisionType.polygon, qDrawPoints, qPolygon)]

            elif sType == 'box':
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]

                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))

                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fFactor * fZoom * fWindowScaled
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                             fSize, fSize)
                    xE[eDrawData] = qDrawRect
                else:
                    qDrawRect = xE[eDrawData]

                xE[eCollider] = [qDrawRect, None]
                painter.drawRect(qDrawRect)

            elif sType.startswith('text'):
                sText = sType.split('_')[-1]
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]

                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fFactor * fZoom * fWindowScaled

                    qDefaultFont = QtGui.QFont('Arial', 100)
                    qFontMetrics = QtGui.QFontMetrics(qDefaultFont)

                    iFontWidth = qFontMetrics.horizontalAdvance(sText)
                    iFontHeight = qFontMetrics.height()
                    fWidthRatio = float(iFontWidth) / iFontHeight
                    qFont = QtGui.QFont('Arial', 100 * fSize / iFontHeight)
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * fWidthRatio * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                             fSize * fWidthRatio, fSize)
                    xE[eDrawData] = qDrawRect, qFont
                else:
                    qDrawRect, qFont = xE[eDrawData]

                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))

                painter.setFont(qFont)
                xE[eCollider] = [qDrawRect, None]
                painter.drawText(qDrawRect, QtCore.Qt.AlignCenter, sText)

                # border
                bDrawSolidBorder = None
                if self.qParent.qEditModeBox.isChecked():
                    if xE[eEditSelected]:
                        bDrawSolidBorder = True
                else:
                    if _any(xE[eBoolSelected]):
                        bDrawSolidBorder = _all(xE[eBoolSelected])

                if bDrawSolidBorder != None:
                    painter.setPen(QtGui.QPen(qColor, 2 * fZoom * fWindowScaled,
                                              QtCore.Qt.SolidLine if bDrawSolidBorder else QtCore.Qt.DashLine))
                    painter.setBrush(QtGui.QBrush(QtCore.Qt.white, QtCore.Qt.NoBrush))
                    painter.drawRect(qDrawRect)

            elif sType.startswith('button'):
                sText = sType.split('_')[-1]
                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]

                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fFactor * fZoom * fWindowScaled

                    qDefaultFont = QtGui.QFont('Arial', 100)
                    qFontMetrics = QtGui.QFontMetrics(qDefaultFont)

                    iFontWidth = qFontMetrics.horizontalAdvance(sText)
                    iFontHeight = qFontMetrics.height()
                    fWidthRatio = float(iFontWidth) / iFontHeight
                    qFont = QtGui.QFont('Arial', 100 * fSize / iFontHeight)
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * fWidthRatio * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                             fSize * fWidthRatio, fSize)
                    xE[eDrawData] = qDrawRect, qFont
                else:
                    qDrawRect, qFont = xE[eDrawData]

                xE[eCollider] = [qDrawRect, None]

                # border
                painter.setPen(QtGui.QPen(QtCore.Qt.lightGray, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(QtCore.Qt.lightGray, QtCore.Qt.SolidPattern))
                painter.drawRect(qDrawRect)

                qColor = fBlendedColor(fMayaColor, sSide, 0.0)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))

                painter.setFont(qFont)
                painter.drawText(qDrawRect, QtCore.Qt.AlignCenter, sText)



            elif sType == 'cross':

                sSide, fPos, fSize, bStatus, fMayaColor = xE[eSide], xE[ePos], xE[eSize], xE[eMouseOverIt], xE[eMayaColor]

                qColor = fBlendedColor(fMayaColor, sSide, fPerc)
                painter.setPen(QtGui.QPen(qColor, 1, QtCore.Qt.SolidLine))
                painter.setBrush(QtGui.QBrush(qColor, QtCore.Qt.SolidPattern))

                if xE[eDrawData] == None:
                    fFactor = 1.2 if bStatus == True else 1.0
                    fSize *= fFactor * fZoom * fWindowScaled
                    qDrawRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                             fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                             fSize, fSize)
                    qRectA = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.5,
                                          fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.15,
                                          fSize, fSize * 0.3)
                    qRectB = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * fPos[0] - fSize * 0.15,
                                          fZoomedOffsetY + qZoomedRect.height() * fPos[1] - fSize * 0.5,
                                          fSize * 0.3, fSize)
                    xE[eDrawData] = qDrawRect, qRectA, qRectB
                else:
                    qDrawRect, qRectA, qRectB = xE[eDrawData]

                painter.drawRect(qRectA)
                painter.drawRect(qRectB)
                xE[eCollider] = [qDrawRect, (CollisionType.cross, qRectA, qRectB)]

        fSymmetryLineWidth = 6
        if self.qParent.qEditModeBox.isChecked():
            painter.setPen(QtGui.QPen(QtCore.Qt.green, 1, QtCore.Qt.SolidLine))
            painter.setBrush(QtGui.QBrush(QtCore.Qt.green, QtCore.Qt.SolidPattern))

            self.qSymmetryRect = QtCore.QRect(fZoomedOffsetX + qZoomedRect.width() * self.fSymmetryPos - fSymmetryLineWidth * 0.5, 0,
                                              fSymmetryLineWidth, qCanvasRect.height())

            painter.drawRect(self.qSymmetryRect)

        painter.end()

    def switchMode(self, bEditMode):
        if bEditMode:
            # self.resetPanZoom()
            for xE in self.xElements:
                xE[eEditSelected] = False
        else:
            self.mayaSelectionChanged(cmds.ls(sl=True))

        self.update()

    def getPosFromMouse(self, mouseEvent):
        return mouseEvent.x() / float(self.width()), mouseEvent.y() / float(self.height())

    def keyPressEvent(self, event):
        self.iPressedKeys.add(event.key())
        if QtWidgets.QApplication.keyboardModifiers() == QtCore.Qt.ControlModifier:
            if event.key() == 90:
                if self.qParent.qEditModeBox.isChecked():
                    self.runUndoEdit()
                else:
                    cmds.undo()

        # iUp = 16777235
        # iDown = 16777237

    def keyReleaseEvent(self, event):
        try:
            self.iPressedKeys.remove(event.key())
        except:
            pass

    def mouseMoveEvent(self, event):
        qMousePos = QtCore.QPoint(event.x(), event.y())
        if self.xPan[1]:
            qMoved = qMousePos - self.xPan[1]
            self.xPan[0] += qMoved
            self.xPan[1] = qMousePos
            self.update()

            for xE in self.xElements:
                xE[eDrawData] = None

        if self.xZoom[1]:
            qMoved = qMousePos - self.xZoom[1]

            fPrevZoom = self.xZoom[0]
            self.xZoom[0] *= (1.0 + (qMoved.x() * 0.005))
            self.xZoom[0] = max(0.1, self.xZoom[0])

            fZoomed = self.xZoom[0] / fPrevZoom
            qOffsetFromRect = self.xZoom[2] - self.xPan[0]
            qOffsetFromRect = QtCore.QPointF(qOffsetFromRect.x(), qOffsetFromRect.y())

            self.xPan[0] = self.xZoom[2] - (qOffsetFromRect * fZoomed).toPoint()

            self.xZoom[1] = qMousePos
            self.update()
            for xE in self.xElements:
                xE[eDrawData] = None

        if self.xSelectRect != None:
            qRect = self.rect()
            self.xSelectRect[rEndPos] = self.getPosFromMouse(event)
            self.xSelectRect[rRect] = QtCore.QRect(QtCore.QPoint(qRect.width() * self.xSelectRect[rStartPos][0],
                                                                 qRect.height() * self.xSelectRect[rStartPos][1]),
                                                   QtCore.QPoint(qRect.width() * self.xSelectRect[rEndPos][0],
                                                                 qRect.height() * self.xSelectRect[rEndPos][1]))

            bShift, bControl = self.xSelectRect[rCtrlKeys]
            if not self.qParent.qEditModeBox.isChecked():
                bbElementsPrevSelected = self.xSelectRect[rElementsPrevSelected]
                for e, xE in enumerate(self.xElements):
                    _setAll(xE[eBoolSelected], False)

                iChangedEs = [False] * len(self.xElements)
                for e, xE in enumerate(self.xElements):
                    if not self.qParent.qEditModeBox.isChecked() and not xE[eSceneObjects]:
                        continue

                    bIntersects = self.rectInCollider(xE[eCollider])
                    if not bShift and not bControl:
                        if bIntersects:
                            _setAll(xE[eBoolSelected], bIntersects)
                            iChangedEs[e] = True

                    elif bShift == True and bControl == False:  # shift
                        if bIntersects:
                            if _any(bbElementsPrevSelected[e]):
                                _setAll(xE[eBoolSelected], False)
                            else:
                                _setAll(xE[eBoolSelected], True)
                            iChangedEs[e] = True
                        else:
                            _setAllArray(xE[eBoolSelected], bbElementsPrevSelected[e])

                    elif bShift == False and bControl == True:
                        if bIntersects:
                            if _any(bbElementsPrevSelected[e]):
                                _setAll(xE[eBoolSelected], False)
                                iChangedEs[e] = True
                        else:
                            _setAllArray(xE[eBoolSelected], bbElementsPrevSelected[e])

                    elif bShift == True and bControl == True:
                        if bIntersects:
                            _setAll(xE[eBoolSelected], True)
                            iChangedEs[e] = True
                        else:
                            _setAllArray(xE[eBoolSelected], bbElementsPrevSelected[e])

                for e, xE in enumerate(self.xElements):
                    if iChangedEs[e]:
                        for e2, xE2 in enumerate(self.xElements):
                            if e2 == e:
                                continue
                            for o, sO in enumerate(xE[eSceneObjects]):
                                for o2, sO2 in enumerate(xE2[eSceneObjects]):
                                    if sO == sO2:
                                        xE2[eBoolSelected][o2] = xE[eBoolSelected][o]

                sSelectObjects = []
                for e, xE in enumerate(self.xElements):
                    for o, bO in enumerate(xE[eBoolSelected]):
                        if bO:
                            sSelectObjects.append(xE[eSceneObjects][o])

                self.qParent.selectObjects(sSelectObjects, bDisableUndo=True)

            else:  # edit mode
                bElementsPrevSelected = self.xSelectRect[rElementsPrevSelected]
                for e, xE in enumerate(self.xElements):
                    xE[eEditSelected] = False

                iChangedEs = [False] * len(self.xElements)
                for e, xE in enumerate(self.xElements):
                    if not self.qParent.qEditModeBox.isChecked() and not xE[eSceneObjects]:
                        continue

                    bIntersects = self.rectInCollider(xE[eCollider])
                    if not bShift and not bControl:  # no button
                        if bIntersects:
                            xE[eEditSelected] = bIntersects
                            iChangedEs[e] = True

                    elif bShift == True and bControl == False:  # shift

                        if bIntersects:
                            if bElementsPrevSelected[e]:
                                xE[eEditSelected] = False
                            else:
                                xE[eEditSelected] = True
                            iChangedEs[e] = True
                        else:
                            xE[eEditSelected] = bElementsPrevSelected[e]
                    elif bShift == False and bControl == True:  # control
                        if bIntersects:
                            if bElementsPrevSelected[e]:
                                xE[eEditSelected] = False
                                iChangedEs[e] = True
                        else:
                            xE[eEditSelected] = bElementsPrevSelected[e]

                    elif bShift == True and bControl == True:  # shift + control
                        if bIntersects:
                            xE[eEditSelected] = True
                            iChangedEs[e] = True
                        else:
                            xE[eEditSelected] = bElementsPrevSelected[e]

                self.editorSelectionChanged()

            self.update()

        if self.qParent.qEditModeBox.isChecked():
            if self.qPrevMousePos == None:
                self.qPrevMousePos = qMousePos
            else:
                qMoved = qMousePos - self.qPrevMousePos
                self.qPrevMousePos = qMousePos

                if self.bMovingSymmetry:
                    fOldPos = self.fSymmetryPos
                    self.fSymmetryPos = fOldPos + qMoved.x() / float(self.width())

                if self.iMovingElements:
                    for e in self.iMovingElements:
                        fOldPos = self.xElements[e][ePos]
                        self.xElements[e][ePos] = fOldPos[0] + qMoved.x() / float(self.width()) / self.xZoom[0], \
                                                  fOldPos[1] + qMoved.y() / float(self.height()) / self.xZoom[0]
                        self.xElements[e][eDrawData] = None

                else:
                    if self.iScalingElements:
                        for e in self.iScalingElements:
                            fOldSize = self.xElements[e][eSize]
                            self.xElements[e][eSize] = max(5, fOldSize + qMoved.x() * 0.5)
                            self.xElements[e][eDrawData] = None

                    if self.iWideningElements:
                        qMouseOffset = qMousePos - self.qShrinkingLastPos
                        for e in self.iWideningElements:
                            fOffset = [self.xElements[e][ePos][0] - self.fWideningPivot[0],
                                       self.xElements[e][ePos][1] - self.fWideningPivot[1]]
                            fNewPos = [self.fWideningPivot[0] + fOffset[0] * (1.0 + qMouseOffset.x() * 0.01),
                                       self.fWideningPivot[1] + fOffset[1] * (1.0 + qMouseOffset.y() * 0.01)]
                            self.xElements[e][ePos] = [fNewPos[0], fNewPos[1]]
                            self.xElements[e][eDrawData] = None
                        self.qShrinkingLastPos = qMousePos
                self.update()

    def deselectAllElements(self):
        if self.qParent.qEditModeBox.isChecked:
            for e, xE in enumerate(self.xElements):
                self.xElements[e][eEditSelected] = False
        else:
            for e, xE in enumerate(self.xElements):
                _setAll(self.xElements[e][eBoolSelected], False)
        self.iSelectedElements.clear()

    def fillUndoQueue(self):
        if cmds.undoInfo(st=True, q=True):
            sPrevSelection = self.xSelectRect[rPrevSelection]
            sCurSelection = cmds.ls(sl=True)

            cmds.undoInfo(swf=False)

            try:
                self.qParent.bDisableNextScriptJob = True
                cmds.select(sPrevSelection)
                cmds.undoInfo(swf=True)
                self.qParent.bDisableNextScriptJob = True
                cmds.select(sCurSelection)
            except:
                raise
            finally:
                cmds.undoInfo(swf=True)

    def rectInCollider(self, xCollider):
        bIntersects = self.xSelectRect[rRect].intersects(xCollider[0])
        if bIntersects and xCollider[1] != None:
            xCollisionData = xCollider[1]
            if xCollisionData[0] == CollisionType.cross:
                bIntersects = xCollisionData[1].intersects(self.xSelectRect[rRect]) or xCollisionData[2].intersects(self.xSelectRect[rRect])
            elif xCollisionData[0] == CollisionType.sphere:
                xs = sorted([self.xSelectRect[rRect].left(), self.xSelectRect[rRect].right()])
                ys = sorted([self.xSelectRect[rRect].bottom(), self.xSelectRect[rRect].top()])
                x = max(xs[0], min(xCollisionData[1].x(), xs[1]))
                y = max(ys[0], min(xCollisionData[1].y(), ys[1]))
                qDiff = QtCore.QPoint(x, y) - xCollisionData[1]
                bIntersects = pow(qDiff.x(), 2) + pow(qDiff.y(), 2) <= xCollisionData[2]
            elif xCollisionData[0] == CollisionType.halfsphere:
                xs = sorted([self.xSelectRect[rRect].left(), self.xSelectRect[rRect].right()])
                ys = sorted([self.xSelectRect[rRect].bottom(), self.xSelectRect[rRect].top()])
                x = max(xs[0], min(xCollisionData[1].x(), xs[1]))
                y = max(ys[0], min(xCollisionData[1].y(), ys[1]))
                qDiff = QtCore.QPoint(x, y) - xCollisionData[1]
                bIntersects = pow(qDiff.x(), 2) + pow(qDiff.y(), 2) <= xCollisionData[2]
            elif xCollisionData[0] == CollisionType.polygon:
                qCollisionPoints = xCollisionData[1]
                bIntersects = False
                if self.xSelectRect[rCornerPoints]:
                    # check if polygon is completely inside rectangle (only need to check first one)
                    if self.xSelectRect[rRect].contains(qCollisionPoints[0]):
                        bIntersects = True
                    # now check each line if it intersects
                    if not bIntersects:
                        for r in range(4):
                            for p in range(len(qCollisionPoints) - 1):
                                if lineIntersection(qCollisionPoints[p + 0], qCollisionPoints[p + 1],
                                                    self.xSelectRect[rCornerPoints][r + 0],
                                                    self.xSelectRect[rCornerPoints][r + 1]):
                                    bIntersects = True
                                    break
        return bIntersects

    def pointInCollider(self, qPoint, xCollider):
        if xCollider == None:
            return False
        bContains = xCollider[0].contains(qPoint)
        if bContains and xCollider[1] != None:
            xCollisionData = xCollider[1]
            if xCollisionData[0] == CollisionType.sphere:
                qDiff = qPoint - xCollisionData[1]
                bContains = pow(qDiff.x(), 2) + pow(qDiff.y(), 2) <= xCollisionData[2]
            elif xCollisionData[0] == CollisionType.halfsphere:
                qDiff = qPoint - xCollisionData[1]
                bContains = pow(qDiff.x(), 2) + pow(qDiff.y(), 2) <= xCollisionData[2] and qPoint.y() < xCollisionData[1].y()
            elif xCollisionData[0] == CollisionType.polygon:
                bContains = xCollisionData[2].containsPoint(qPoint, QtCore.Qt.OddEvenFill)
            elif xCollisionData[0] == CollisionType.cross:
                bContains = xCollisionData[1].contains(qPoint) or xCollisionData[2].contains(qPoint)
        return bContains


    def duplicateElement(self, xE):
        xDuplE = [None] * len(xE)
        xDuplE[eType] = xE[eType]
        xDuplE[eSide] = xE[eSide]
        xDuplE[ePos] = list(xE[ePos])
        xDuplE[eSize] = xE[eSize]
        xDuplE[eMouseOverIt] = None
        xDuplE[eSavedObjects] = list(xE[eSavedObjects])
        xDuplE[eBoolSelected] = list(xE[eBoolSelected])
        xDuplE[eEditSelected] = xE[eEditSelected]
        xDuplE[eDrawData] = None
        return xDuplE


    def mousePressEvent(self, event):
        modifiers = QtWidgets.QApplication.keyboardModifiers()
        bShiftKey = modifiers == QtCore.Qt.ShiftModifier
        bControlKey = modifiers == QtCore.Qt.ControlModifier

        if modifiers == QtCore.Qt.AltModifier:
            self.bOptionKeyDown = True

        bCanZoom = (self.qParent.qEditModeBox.isChecked() and self.bOptionKeyDown) \
                   or not self.qParent.qEditModeBox.isChecked()


        if modifiers & QtCore.Qt.ShiftModifier and modifiers & QtCore.Qt.ControlModifier:
            bShiftKey, bControlKey = True, True

        qMousePos = QtCore.QPoint(event.x(), event.y())

        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.bLeftMouseDown = True

            if self.qParent.qEditModeBox.isChecked():
                self.appendToEditUndoStack()

                self.setTextEditMode(False)

                if self.qParent.qCreateButton.isChecked():  # adding a new element

                    sNewType = self.qParent.qElementsCombo.currentText()

                    if sNewType == 'text':
                        sNewType = 'text_text'
                    elif sNewType == 'button':
                        sNewType = 'button_button'

                    sNewSide = self.qParent.qSidesCombo.currentText()
                    sSel = cmds.ls(sl=True)

                    xNewE = [None] * (5+iNonesCount)#12
                    xNewE[eType] = sNewType
                    xNewE[eSide] = sNewSide[0]
                    xNewE[ePos] = self.getPosFromMouse(event)
                    xNewE[eSize] = 50
                    xNewE[eSavedObjects] = [sO.split(':')[-1] for sO in sSel]
                    xNewE[eEditSelected] = True

                    self.xElements.append(xNewE)
                    self.iMovingElements = set()
                    self.iMovingElements.add(len(self.xElements) - 1)

                    for sObj in sSel:
                        self.sAllMayaObjects.add(sObj)
                    self.updateExistInfo()
                    self.update()
                    self.qParent.dirtySaveButton(iDebugInt=17)

                elif self.qParent.qDuplicateButton.isChecked():
                    for e, xE in enumerate(self.xElements):
                        if self.pointInCollider(qMousePos, xE[eCollider]):  # xE[eCollider][0].contains(qMousePos):
                            xNewE = self.duplicateElement(self.xElements[e])
                            sNamespacedObjects = cmds.ls(sl=True)
                            xNewE[eSavedObjects] = [sO.split(':')[-1] for sO in sNamespacedObjects]
                            xNewE[eSavedObjects] += [sO for sO in xE[eSavedObjects] if sO.strip().startswith('$')]
                            xNewE[eEditSelected] = True
                            xNewE[eBoolSelected] = [True] * len(sNamespacedObjects)
                            self.xElements.append(xNewE)
                            self.iMovingElements = set()
                            self.iMovingElements.add(len(self.xElements) - 1)
                            self.updateExistInfo()
                            self.update()
                            self.qParent.dirtySaveButton(iDebugInt=18)
                            break

                else:  # move or select rectangle
                    bOverSomething = False
                    if self.qSymmetryRect != None and self.qSymmetryRect.contains(qMousePos):
                        self.bMovingSymmetry = True
                        bOverSomething = True

                    elif bControlKey or bShiftKey:
                        if bControlKey:
                            self.iScalingElements.clear()
                            for e, xE in enumerate(self.xElements):
                                if xE[eCollider][0].contains(qMousePos):
                                    if not bShiftKey:
                                        if xE[eEditSelected] == False:  # == False: # it is not selected yet
                                            self.deselectAllElements()
                                    self.iSelectedElements.add(e)
                                    self.xElements[e][eEditSelected] = True
                                    self.iScalingElements.add(e)
                                    self.iScalingElements = self.iScalingElements.union(self.iSelectedElements)
                                    bOverSomething = True
                                    break

                        if bShiftKey:
                            self.iWideningElements.clear()
                            for e, xE in enumerate(self.xElements):
                                if xE[eCollider][0].contains(qMousePos):
                                    if not bShiftKey:
                                        if xE[eEditSelected] == False:
                                            self.deselectAllElements()
                                    self.iSelectedElements.add(e)
                                    self.xElements[e][eEditSelected] = True
                                    self.iWideningElements.add(e)
                                    self.iWideningElements = self.iWideningElements.union(self.iSelectedElements)

                                    self.fWideningPivot = [0, 0]
                                    for e in self.iWideningElements:
                                        self.fWideningPivot[0] += self.xElements[e][ePos][0]
                                        self.fWideningPivot[1] += self.xElements[e][ePos][1]
                                    self.fWideningPivot[0] /= float(len(self.iWideningElements))
                                    self.fWideningPivot[1] /= float(len(self.iWideningElements))

                                    self.qShrinkingLastPos = qMousePos
                                    bOverSomething = True
                                    break

                    else:  # no key pressed, edit mode
                        self.iMovingElements = set()
                        for e, xE in enumerate(self.xElements):
                            if xE[eCollider][0].contains(qMousePos):
                                if not bShiftKey:  # QtCore.Qt.Key_Shift not in self.iPressedKeys: # no shift button
                                    # if not _any(xE[eBoolSelected]): # == False: # it is not selected yet
                                    if xE[eEditSelected] == False:
                                        self.deselectAllElements()
                                self.iSelectedElements.add(e)
                                xE[eEditSelected] = True
                                # _setAll(xE[eBoolSelected], True) # = True
                                self.iMovingElements.add(e)
                                self.iMovingElements = self.iMovingElements.union(self.iSelectedElements)

                                bOverSomething = True
                                break
                    if not bOverSomething:
                        bElementsInitiallySelected = [xE[eEditSelected] for xE in self.xElements]
                        self.xSelectRect = [None] * 7
                        self.xSelectRect[rStartPos] = self.getPosFromMouse(event)
                        self.xSelectRect[rCtrlKeys] = [bShiftKey, bControlKey]
                        self.xSelectRect[rElementsPrevSelected] = bElementsInitiallySelected
                        self.xSelectRect[rPrevSelection] = cmds.ls(sl=True)

            else:  # normal mode
                bSomethingHappened = False
                bOverSomething = False
                for e, xE in enumerate(self.xElements):
                    if not xE[eSceneObjects] and not xE[eCommands]:
                        continue
                    bContains = self.pointInCollider(qMousePos, xE[eCollider])
                    bStatus = True if bContains else None
                    if xE[eMouseOverIt] != bStatus:
                        xE[eMouseOverIt] = bStatus
                        xE[eDrawData] = None
                        bSomethingHappened = True
                    if bStatus == True:
                        bOverSomething = True
                if bSomethingHappened:
                    self.update()
                if not bOverSomething:
                    bbElementsInitiallySelected = [list(xE[eBoolSelected]) for xE in self.xElements]
                    self.xSelectRect = [None] * 7
                    self.xSelectRect[rStartPos] = self.getPosFromMouse(event)
                    self.xSelectRect[rCtrlKeys] = [bShiftKey, bControlKey]
                    self.xSelectRect[rElementsPrevSelected] = bbElementsInitiallySelected
                    self.xSelectRect[rPrevSelection] = cmds.ls(sl=True)

        elif event.button() == QtCore.Qt.MouseButton.MidButton:  # duplicating
            if bCanZoom:
                self.xPan[1] = qMousePos


        elif event.button() == QtCore.Qt.MouseButton.RightButton:
            if self.qParent.qEditModeBox.isChecked():
                qMousePos = QtCore.QPoint(event.x(), event.y())

                if not self.bOptionKeyDown:
                    iElementCollided = None
                    for e, xE in enumerate(self.xElements):
                        if self.pointInCollider(qMousePos, xE[eCollider]):
                            iElementCollided = e
                            break

                    if not isinstance(iElementCollided, type(None)):
                        e = iElementCollided
                        qMenu = QtWidgets.QMenu()

                        def deleteButton(e=e):
                            self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=1)
                            iRemoveElements = set([e]).union(self.iSelectedElements)

                            xSorted = sorted(list(set(iRemoveElements)), reverse=True)
                            for e in xSorted:
                                del self.xElements[e]
                            self.iSelectedElements.clear()
                            self.update()

                        def mirrorButton(e=e):
                            self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=2)
                            iMirrorElements = set([e]).union(self.iSelectedElements)
                            for e in iMirrorElements:
                                self.mirrorElement(e)
                            self.updateExistInfo()
                            self.update()

                        def copy(e=e):
                            iCopyElements = set([e]).union(self.iSelectedElements)
                            xClipboard = [list(self.xElements[e])[:5] for e in iCopyElements]

                            import kangarooTools.clipboard
                            kangarooTools.clipboard.put(str('%s%s' % (kCopyPastePrefix, xClipboard)))

                            print ('xClipboard: ', xClipboard)


                        def alignVertical(e=e):
                            self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=3)
                            iElements = set([e]).union(self.iSelectedElements)
                            iHeight = reduce(lambda a, b: a + b, [self.xElements[e][ePos][1] for e in iElements]) / len(iElements)
                            for e in iElements:
                                iPos = self.xElements[e][ePos]
                                self.xElements[e][ePos] = (iPos[0], iHeight)
                            self.resetShapes()
                            self.update()

                        def alignHorizontal(e=e):
                            self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=4)
                            iElements = set([e]).union(self.iSelectedElements)
                            iWidth = reduce(lambda a, b: a + b, [self.xElements[e][ePos][0] for e in iElements]) / len(iElements)
                            for e in iElements:
                                iPos = self.xElements[e][ePos]
                                self.xElements[e][ePos] = (iWidth, iPos[1])
                            self.resetShapes()
                            self.update()

                        def setFromSelection(e=e, bAdd=False):
                            self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=51)
                            sNamespaceMayaObjects = cmds.ls(sl=True, et='transform')+cmds.ls(sl=True, et='joint')

                            sObjects = sorted([sO.split(':')[-1] for sO in sNamespaceMayaObjects])
                            if bAdd:
                                self.xElements[e][eSavedObjects] += sObjects
                            else:
                                self.xElements[e][eSavedObjects] = sObjects

                            self.xElements[e][eSceneObjects] = self.xElements[e][eSavedObjects]
                            self.updateExistInfo()

                        def setFromUI(e=e):
                            def _updateInfo(sData):
                                self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=6)
                                sSplitData = [sD.strip() for sD in sData.split('\n')]
                                print(sSplitData)
                                self.xElements[e][eSavedObjects] = sSplitData

                                sNamespacesMayaObjects = []
                                sNamespace = self.qParent.getNamespace()
                                sCommands = []
                                for sLsString in sSplitData:
                                    if sLsString.startswith('$'):
                                        sCommands.append(sLsString)
                                    else:
                                        sLsString = sLsString.strip()
                                        if len(sLsString):
                                            sNamespacesMayaObjects += cmds.ls('%s%s' % (sNamespace, sLsString), et='transform')
                                            sNamespacesMayaObjects += cmds.ls('%s%s' % (sNamespace, sLsString), et='joint')

                                sNonNamespacedMayaObjects = [sObj.split(':')[-1] for sObj in sNamespacesMayaObjects]
                                self.xElements[e][eSceneObjects] = sNonNamespacedMayaObjects
                                self.xElements[e][eCommands] = sCommands

                                self.updateExistInfo()

                            self.enterInfo = EnterInfo(_updateInfo, '\n'.join(xE[eSavedObjects]))
                            self.enterInfo.show()

                        def setSideColor(e=e, sSide='m'):
                            self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=6)
                            iElements = set([e]).union(self.iSelectedElements)
                            for e in iElements:
                                self.xElements[e][eSide] = sSide
                            self.resetShapes()
                            self.update()

                        qInfoAction = qMenu.addAction(str(xE[eSavedObjects]), lambda: None)
                        qInfoAction.setEnabled(False)

                        qMenu.addAction('Set Objects (from selection)', setFromSelection)
                        qMenu.addAction('Add Objects (from selection)', lambda: setFromSelection(bAdd=True) )
                        qMenu.addAction('Set Objects (adjust list)', setFromUI)
                        qMenu.addAction('Mirror', mirrorButton)
                        qMenu.addAction('Align Horizontally', alignHorizontal)
                        qMenu.addAction('Align Vertically', alignVertical)
                        qMenu.addAction('Copy', copy)
                        qMenu.addAction('Delete', deleteButton)

                        qSideMenus = qMenu.addMenu('Set Side')
                        qSideMenus.addAction('Left', lambda: setSideColor(sSide='l'))
                        qSideMenus.addAction('Middle', lambda: setSideColor(sSide='m'))
                        qSideMenus.addAction('Right', lambda: setSideColor(sSide='r'))

                        qShapesMenu = qMenu.addMenu('Set Shape')
                        for sShape in ['sphere', 'box', 'circle', 'halfsphere', 'arrow', 'cross', 'text_text', 'button_button']:

                            def setShape(e=e, sShape=sShape):
                                self.appendToEditUndoStack(bDirtySaveButton=True, iDebugInt=7)
                                iElements = set([e]).union(self.iSelectedElements)
                                for e in iElements:
                                    self.xElements[e][eType] = sShape
                                self.resetShapes()
                                self.update()

                            qShapesMenu.addAction(sShape.split('_')[0], setShape)

                        qCursor = QtGui.QCursor()
                        qMenu.exec_(qCursor.pos())

                    else: # no collided element is found (iElementCollided is None)
                        qMenu = QtWidgets.QMenu()

                        import kangarooTools.clipboard
                        sClipboard = kangarooTools.clipboard.get()

                        def paste(sClipboard=sClipboard):
                            sClipboard = sClipboard[len(kCopyPastePrefix):]
                            xElements = eval(sClipboard)

                            fMousePos = self.getPosFromMouse(event)
                            fPositionSum = [0, 0]
                            for xE in xElements:
                                fPositionSum[0] += xE[ePos][0]
                                fPositionSum[1] += xE[ePos][1]
                            fPositionSum[0] /= len(xElements)
                            fPositionSum[1] /= len(xElements)
                            for xE in xElements:
                                xE[ePos] = (xE[ePos][0] + fMousePos[0] - fPositionSum[0],
                                            xE[ePos][1] + fMousePos[1] - fPositionSum[1])

                            self.xElements.extend(xElements)

                            self.sAllMayaObjects = set()
                            for e, xE in enumerate(xElements):
                                self.sAllMayaObjects.update(xE[eSavedObjects])
                                for i in range(iNonesCount):
                                    xE.append(None)

                            self.updateExistInfo()
                            self.update()

                            self.qParent.dirtySaveButton(iDebugInt=10)

                        qPaste = qMenu.addAction('Paste', paste)
                        if not sClipboard.startswith(kCopyPastePrefix):
                            qPaste.setEnabled(False)

                        qCursor = QtGui.QCursor()
                        qMenu.exec_(qCursor.pos())

            if bCanZoom:
                self.xZoom[1] = qMousePos
                self.xZoom[2] = qMousePos


    def mirrorElement(self, e):
        xE = self.xElements[e]
        xMirrorE = self.duplicateElement(xE)
        if xE[eSide] == 'l':
            xMirrorE[1] = 'r'
            fPos = xMirrorE[ePos]
            fPos[0] = self.fSymmetryPos + (self.fSymmetryPos - fPos[0])
            xMirrorE[ePos] = fPos

            for o, sO in enumerate(xE[eSavedObjects]):
                if sO.strip().startswith('$'):
                    xMirrorE[eSavedObjects][o] = sO.replace("'l'", "'r'")
                else:
                    sMirrorO = library.getMirrorName(sO)
                    xMirrorE[eSavedObjects][o] = sMirrorO
                    self.sAllMayaObjects.add(sMirrorO)
                    self.qParent.dirtySaveButton(iDebugInt=11)

            self.xElements.append(xMirrorE)
            self.qParent.dirtySaveButton(iDebugInt=12)


        elif xE[eSide] == 'r':
            xMirrorE[1] = 'l'
            fPos = xMirrorE[ePos]
            fPos[0] = self.fSymmetryPos + (self.fSymmetryPos - fPos[0])
            xMirrorE[ePos] = fPos

            for o, sO in enumerate(xE[eSavedObjects]):
                if sO.strip().startswith('$'):
                    xMirrorE[eSavedObjects][o] = sO.replace("'r'", "'l'")
                else:
                    sMirrorO = library.getMirrorName(sO)
                    xMirrorE[eSavedObjects][o] = sMirrorO
                    self.sAllMayaObjects.add(sMirrorO)

            self.xElements.append(xMirrorE)
            self.qParent.dirtySaveButton(iDebugInt=13)


    def mouseReleaseEvent(self, event):
        modifiers = QtWidgets.QApplication.keyboardModifiers()
        bShiftKey = modifiers == QtCore.Qt.ShiftModifier
        bControlKey = modifiers == QtCore.Qt.ControlModifier
        if modifiers & QtCore.Qt.ShiftModifier and modifiers & QtCore.Qt.ControlModifier:
            bShiftKey, bControlKey = True, True

        if modifiers == QtCore.Qt.AltModifier:
            self.bOptionKeyDown = False

        self.qParent.bDisableNextScriptJob = False

        self.bLeftMouseDown = False
        if self.iMovingElements:
            self.qParent.dirtySaveButton(iDebugInt=14)

        self.iMovingElements.clear()

        if self.iScalingElements or self.iWideningElements:
            bReleasedFromScalingOrWidening = True
            self.iScalingElements.clear()
            self.iWideningElements.clear()
            self.qParent.dirtySaveButton(iDebugInt=15)
        else:
            bReleasedFromScalingOrWidening = False

        self.bMovingSymmetry = False
        if self.xPan[1] or self.xZoom[1]:
            self.xPan[1] = None
            self.xZoom[1] = None
            return

        if self.xSelectRect != None:  # [rStartPos]:
            if self.xSelectRect[rEndPos]:
                self.iSelectedElements.clear()
                if self.qParent.qEditModeBox.isChecked():
                    for e, xE in enumerate(self.xElements):
                        if xE[eEditSelected] == True:
                            self.iSelectedElements.add(e)
                else:  # normal mode
                    for e, xE in enumerate(self.xElements):
                        if _any(xE[eBoolSelected]):
                            self.iSelectedElements.add(e)

                self.fillUndoQueue()
                self.xSelectRect = None
                self.update()

                return
            else:  # didn't start drawing rect yet
                self.xSelectRect = None
                self.deselectAllElements()
                self.update()
                cmds.select(clear=True)

        qMousePos = QtCore.QPoint(event.x(), event.y())

        if not self.qParent.qEditModeBox.isChecked():
            bbPrev = []
            if bShiftKey and not bControlKey:
                for xE in self.xElements:
                    bbPrev.append(list(xE[eBoolSelected]))
            if not bShiftKey and not bControlKey:
                for xE in self.xElements:
                    _setAll(xE[eBoolSelected], False)

            for e, xE in enumerate(self.xElements):
                if not xE[eSceneObjects] and not xE[eCommands]:
                    continue
                bContains = self.pointInCollider(qMousePos, xE[eCollider])
                bStatus = False if bContains else None
                if xE[eMouseOverIt] != bStatus:
                    xE[eMouseOverIt] = bStatus
                    xE[eDrawData] = None
                if bContains:
                    if xE[eCommands]:
                        for sCommand in xE[eCommands]:
                            exec(sCommand.replace('[NAMESPACE]', self.qParent.getNamespace()))
                    if xE[eSceneObjects]:
                        if not bShiftKey and not bControlKey:
                            _setAll(xE[eBoolSelected], True)
                            for e2, xE2 in enumerate(self.xElements):
                                if e != e2:
                                    for o2, sO2 in enumerate(xE2[eSceneObjects]):
                                        if sO2 in xE[eSceneObjects]:
                                            xE2[eBoolSelected][o2] = True
                            self.qParent.selectObjects(xE[eSceneObjects])

                        elif bShiftKey and not bControlKey:
                            if _any(bbPrev[e]):
                                bOffOn = False
                                self.qParent.selectObjects(xE[eSceneObjects], bDeselect=True)
                            else:
                                bOffOn = True
                                self.qParent.selectObjects(xE[eSceneObjects], bAdd=True)
                            _setAll(xE[eBoolSelected], bOffOn)
                            for e2, xE2 in enumerate(self.xElements):
                                if e != e2:
                                    for o2, sO2 in enumerate(xE2[eSceneObjects]):
                                        if sO2 in xE[eSceneObjects]:
                                            xE2[eBoolSelected][o2] = bOffOn

                        elif bControlKey and not bShiftKey:
                            self.qParent.selectObjects(xE[eSceneObjects], bDeselect=True)
                            _setAll(xE[eBoolSelected], False)
                            for e2, xE2 in enumerate(self.xElements):
                                if e != e2:
                                    for o2, sO2 in enumerate(xE2[eSceneObjects]):
                                        if sO2 in xE[eSceneObjects]:
                                            xE2[eBoolSelected][o2] = False

                        elif bShiftKey and bControlKey:
                            self.qParent.selectObjects(xE[eSceneObjects], bAdd=True)
                            _setAll(xE[eBoolSelected], True)
                            for e2, xE2 in enumerate(self.xElements):
                                if e != e2:
                                    for o2, sO2 in enumerate(xE2[eSceneObjects]):
                                        if sO2 in xE[eSceneObjects]:
                                            xE2[eBoolSelected][o2] = True


        else:  # edit box
            # bSomethingGotChanged = False
            if not bReleasedFromScalingOrWidening:
                for e, xE in enumerate(self.xElements):
                    bContains = self.pointInCollider(qMousePos, xE[eCollider])
                    bStatus = False if bContains else None
                    if xE[eMouseOverIt] != bStatus:
                        xE[eMouseOverIt] = bStatus
                        xE[eDrawData] = None
                    if bContains:
                        bShiftKey = QtWidgets.QApplication.keyboardModifiers() == QtCore.Qt.ShiftModifier
                        if not bShiftKey and not bControlKey:
                            xE[eEditSelected] = True
                        elif bShiftKey and not bControlKey:
                            if xE[eEditSelected] == True:
                                xE[eEditSelected] = False
                            else:
                                xE[eEditSelected] = True
                        elif bControlKey and not bShiftKey:
                            xE[eEditSelected] = False
                        elif bShiftKey and bControlKey:
                            xE[eEditSelected] = True
                        # bSomethingGotChanged = True
                self.editorSelectionChanged()
        self.update()

    def textTextChanged(self, sText):
        if self.iTextEditModeElement != None and len(sText):
            sCurrentType = self.xElements[self.iTextEditModeElement][eType]
            self.xElements[self.iTextEditModeElement][eType] = '%s_%s' % (sCurrentType.split('_')[0], sText)
            self.xElements[self.iTextEditModeElement][eDrawData] = None
            self.update()
            # self.qParent.dirtySaveButton(iDebugInt=16)

    def setTextEditMode(self, bOffOn, e=None):
        if bOffOn:
            self.iTextEditModeElement = e
            self.qParent.qTextText.setEnabled(True)
            self.qParent.qTextText.setText(self.xElements[e][eType].split('_')[-1])
        else:
            self.iTextEditModeElement = None
            self.qParent.qTextText.setEnabled(False)
            self.qParent.qTextText.setText('')

    def editorSelectionChanged(self):
        iSelectedElements = []
        for e, xE in enumerate(self.xElements):
            if xE[eEditSelected]:
                iSelectedElements.append(e)

        if len(iSelectedElements) == 1 and '_' in self.xElements[iSelectedElements[0]][eType]:
            self.setTextEditMode(True, iSelectedElements[0])
        else:
            self.setTextEditMode(False)

    def mayaSelectionChanged(self, sObjs):
        if self.qParent.qEditModeBox.checkState() == QtCore.Qt.CheckState.Checked: # changed later, but not tested yet
            return
        sIntersectedObjs = set(sObjs).intersection(self.sAllMayaObjects)
        self.deselectAllElements()
        for e, xE in enumerate(self.xElements):
            for o, xEObject in enumerate(xE[eSceneObjects]):
                if xEObject in sIntersectedObjs:
                    xE[eBoolSelected][o] = True
                else:
                    xE[eBoolSelected][o] = False

        self.update()


class ValueType:
    code = 0


class EnterInfo(QtWidgets.QDialog):

    def __init__(self, funcCallback, sDefault=None):
        super(EnterInfo, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)
        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)

        self.qComments = QtWidgets.QTextEdit()
        self.qComments.setAcceptRichText(False)
        self.qComments.setReadOnly(False)
        layout.addWidget(self.qComments)

        qOkButton = QtWidgets.QPushButton('OK')
        qOkButton.clicked.connect(self.okClicked)
        layout.addWidget(qOkButton)

        self.setMinimumWidth(800)
        self.setMinimumHeight(800)
        self.funcCallback = funcCallback
        if sDefault != None:
            self.qComments.append(str(sDefault))

    def okClicked(self):
        sComments = self.qComments.toPlainText()
        self.close()
        self.funcCallback(sComments)



class RigAnimTool(QtWidgets.QDialog):

    def __init__(self, parent=getMayaWindow()):
        super(RigAnimTool, self).__init__(parent, QtCore.Qt.Tool)

        self.layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        self.setWindowTitle('Kangaroo Ctrl Picker %s' % kVersion)
        self.setWindowFlags(self.windowFlags() |
                               QtCore.Qt.WindowMinimizeButtonHint |
                               QtCore.Qt.WindowSystemMenuHint)

        self.iSelectionScriptJob = None
        self.qNamespace = QNamespace()
        self.qNamespace.setFromSelectedClicked.connect(self.updatePickers)
        self.layout.addWidget(self.qNamespace)

        self.iSelectionScriptJob = cmds.scriptJob(e=["SelectionChanged", mayaSelectionChanged])

        qTopRowLayout = QtWidgets.QHBoxLayout()
        self.layout.addLayout(qTopRowLayout)
        for func, sLabel, bPassNamespace in [(KangarooMatchTools.spaceSwitchMenu, 'Space Switch', False),
                                             (KangarooMatchTools.humanLimbsSwitchMenu, 'Fk/Ik Switch', False),
                                             (KangarooMatchTools.goToDefaultPose, 'Go to Default Pose (Full Character)', True),
                                             (KangarooMatchTools.goToDefaultPoseSelection, 'Go to Default Pose (Selected Ctrls)', False),
                                             (KangarooMatchTools.simMenu, 'Sim', True)]:
            def _buttonFunction(_func=func, _bPassNamespace=bPassNamespace):
                library.reload2(KangarooMatchTools)
                if _bPassNamespace:
                    sNamespace = self.getNamespace()
                    _func(sNamespace)
                else:
                    _func()
            qButton = QtWidgets.QPushButton(sLabel)
            qButton.clicked.connect(_buttonFunction)
            qTopRowLayout.addWidget(qButton)

        self.qFaceLayout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom)
        self.layout.addLayout(self.qFaceLayout)

        qEditLayout = QtWidgets.QHBoxLayout()
        self.qFaceLayout.addLayout(qEditLayout)
        self.qEditModeBox = QtWidgets.QCheckBox('Edit Mode')
        self.qEditModeBox.stateChanged.connect(self.editClicked)
        qEditLayout.addWidget(self.qEditModeBox)

        self.qDuplicateButton = QtWidgets.QPushButton('Duplicate')
        self.qDuplicateButton.setCheckable(True)
        self.qDuplicateButton.clicked.connect(self.clickedDuplicate)
        qEditLayout.addWidget(self.qDuplicateButton)

        self.qCreateButton = QtWidgets.QPushButton('Create')
        self.qCreateButton.setCheckable(True)
        self.qCreateButton.clicked.connect(self.clickedCreate)
        qEditLayout.addWidget(self.qCreateButton)

        self.qElementsCombo = QtWidgets.QComboBox()
        for sElement in ['sphere', 'box', 'circle', 'halfsphere', 'arrow', 'cross', 'text', 'button']:
            self.qElementsCombo.addItem(sElement)
        qEditLayout.addWidget(self.qElementsCombo)
        self.qSidesCombo = QtWidgets.QComboBox()
        for sSide in ['left', 'middle', 'right']:
            self.qSidesCombo.addItem(sSide)
        qEditLayout.addWidget(self.qSidesCombo)
        self.qElementsCombo.setHidden(True)

        self.qTextText = QtWidgets.QLineEdit()
        qEditLayout.addWidget(self.qTextText)
        self.qTextText.setEnabled(False)
        self.qTextText.textChanged.connect(self.textTextChanged)

        self.qWidgetAllTabs = QtWidgets.QTabWidget()
        self.qFaceLayout.addWidget(self.qWidgetAllTabs)

        self.qSaveButton = QtWidgets.QPushButton('Save')
        self.qSaveButton.clicked.connect(self.saveElements)
        qEditLayout.addWidget(self.qSaveButton)

        self.qMatchButtonLayout = None

        self.qMatchGroups = []
        # self.setGeometry(100, 100, qImageSize.width(), qImageSize.height())# (geometry().x(), geometry().y(), 200, 400);
        self.setMinimumWidth(500)
        self.setMinimumHeight(500)


        self.bDisableNextScriptJob = False

        if not bShowEditBox:
            self.qEditModeBox.setHidden(True)

        self.xPreviousSelectedObjects = None

        # mirror tab
        #
        qMirrorTab = QtWidgets.QWidget()
        self.qWidgetAllTabs.addTab(qMirrorTab, 'Mirror')
        qMirrorLayout = QtWidgets.QVBoxLayout(qMirrorTab)
        self.qMirrorAnimationCheckBox = QtWidgets.QCheckBox('mirror full animation')
        self.qMirrorAnimationCheckBox.setChecked(False)
        for sButton, bAll, bFlip, iMirror in [('adjust selected', False, False, None),
                                             ('adjust selected and other side', False, True, None),
                                             ('All in current namespace', True, None, 0),
                                             ('All Left in current namespace', True, None, 1),
                                             ('All Right current namespace', True, None, 2)]:
            qButton = QtWidgets.QPushButton(sButton)
            qMirrorLayout.addWidget(qButton)
            def _func(_bAll=bAll, _bFlip=bFlip, _iMirror=iMirror):
                library.reload2(KangarooMatchTools)
                library.reload2(library)
                bAnimation = self.qMirrorAnimationCheckBox.isChecked()
                if _bAll:
                    sNamespace = self.getNamespace()
                    KangarooMatchTools.mirrorPoseAll(sNamespace, bAnimation, _iMirror)  # there is no flip
                else:
                    KangarooMatchTools.mirrorPoseSelected(_bFlip, bAnimation) # there is no namespace

            qButton.clicked.connect(_func)

        qMirrorLayout.addWidget(self.qMirrorAnimationCheckBox)
        qMirrorLayout.addStretch()


        # rokoko tab
        #
        qMocapTab = QtWidgets.QWidget()
        self.qWidgetAllTabs.addTab(qMocapTab, 'Motion Capture')
        qMocapLayout = QtWidgets.QVBoxLayout(qMocapTab)

        qBodyGroupBox = QtWidgets.QGroupBox('Body')
        qMocapLayout.addWidget(qBodyGroupBox)
        qBodyLayout = QtWidgets.QVBoxLayout()
        qBodyGroupBox.setLayout(qBodyLayout)

        for sButton, fFunc in [('Connect Body to humanIk ', self.humanIkConnect),
                               ('Disconnect from humanIk ', self.humanIkDisConnect),
                               ('Characterize Selected Mocap and Connect to HumanIK Skeleton', self.characterizeSelectedMocap),
                               ('Bake humanIk Skeleton', self.rokokoBodyBakeHumanIk),
                               ('Bake Body', self.rokokoBodyBake)]:
            qButton = QtWidgets.QPushButton(sButton)
            qBodyLayout.addWidget(qButton)
            qButton.clicked.connect(fFunc)


        qFaceGroupBox = QtWidgets.QGroupBox('Face')
        qMocapLayout.addWidget(qFaceGroupBox)
        qFaceLayout = QtWidgets.QVBoxLayout()
        qFaceGroupBox.setLayout(qFaceLayout)
        for sButton, fFunc in [('Connect Face (select only imported Rokoko/FaceAR Face)', self.rokokoFaceConnect),
                               ('Connect Face (choose CSV File)', self.faceArCsvFile),
                               ('Import Default BlendShape Mesh and Connect Face', self.importBlendshapeMeshAndConnect),
                               ('Bake Face', self.rokokoFaceBake)]:
            qButton = QtWidgets.QPushButton(sButton)
            qFaceLayout.addWidget(qButton)
            qButton.clicked.connect(fFunc)
            
        qMocapLayout.addStretch()


        # motion tab
        #
        qPathTab = QtWidgets.QWidget()
        self.qWidgetAllTabs.addTab(qPathTab, 'Motion Path')
        qPathLayout = QtWidgets.QVBoxLayout(qPathTab)

        self.qPath = QSetObject('Path (Curve)')
        qPathLayout.addWidget(self.qPath)

        # self.qPathSecondaryCheckBox = QtWidgets.QCheckBox('constrain secondary ctrls')
        for sButton, fFunc in [('Attach Character', self.attachCtrlsToPath),
                               # ('Switch selected Ctrls to FREE', lambda: self.switchPathSpace(bToPath=False)),
                               # ('Switch selected Ctrls to PATH ', lambda: self.switchPathSpace(bToPath=True)),
                               ('Select Main Ctrl', self.selectPathMainCtrl),
                               ('Select Ctrls', self.selectPathCtrls)]:
            qButton = QtWidgets.QPushButton(sButton)
            qPathLayout.addWidget(qButton)
            qButton.clicked.connect(fFunc)
        qPathLayout.addStretch()

        self.pickerImages = []
        self.pickerElementFiles = []
        self.updatePickers('', bSetToFirstPickerTab=False)

        self.editClicked(False)

        self.qNamespace.setClicked(bDialogIfNoValidSelection=False)


    def textTextChanged(self, sText):
        for pickerImage in self.pickerImages:
            pickerImage.textTextChanged(sText)


    def updatePickers(self, sNamespace, bSetToFirstPickerTab=True):
        self.pickerImages.clear()
        self.pickerElementFiles.clear()

        for iTabIndex in range(3, self.qWidgetAllTabs.count(), 1)[::-1]:
            self.qWidgetAllTabs.removeTab(iTabIndex)

        for sImageFile, sElementsFile in getCharacterFiles(sNamespace):
            dElements = library.getJsonContent(sElementsFile)
            sName = os.path.basename(sImageFile).split('.')[0]
            sSuffix = sName.split('_')[-1] if '_' in sName else ''

            qPickerTab = QtWidgets.QWidget()

            self.qWidgetAllTabs.addTab(qPickerTab, 'Picker %s' % sSuffix.title())
            qPickerLayout = QtWidgets.QHBoxLayout(qPickerTab)

            pickerImage = PickerImage(self, sImageFile, dElements)
            pickerImage.setData(dElements, sImageFile)

            qPickerLayout.addWidget(pickerImage)
            self.pickerImages.append(pickerImage)
            self.pickerElementFiles.append(sElementsFile)

        if bSetToFirstPickerTab:
            self.qWidgetAllTabs.setCurrentIndex(3)

    def selectPathCtrls(self):
        sNamespace = self.getNamespace()
        sMaster = library.getMasterName(sNamespace)
        sCtrls = eval(cmds.getAttr('%s.sMotionPathCtrls' % sMaster))
        print ('sCtrls: ', sCtrls)
        sFullCtrls = []
        for sCtrl in sCtrls:
            sFullCtrl = '%s%s' % (sNamespace, sCtrl)
            sAttachTransform = '%s%s' % (sNamespace, cmds.getAttr('%s.sAttachTransform' % sFullCtrl))
            sFullCtrls.append(sAttachTransform)
        cmds.select(sFullCtrls)


    def selectPathMainCtrl(self):
        sNamespace = self.getNamespace()
        sMaster = library.getMasterName(sNamespace)
        sMainCtrl = cmds.getAttr('%s.sMotionPathMainCtrl' % sMaster)
        sFullCtrl = '%s%s' % (sNamespace, sMainCtrl)
        cmds.select(sFullCtrl)


    def attachCtrlsToPath(self):


        sCurve = self.qPath.getObject()


        if not cmds.objExists(sCurve):
            cmds.confirmDialog(m='please set curve first')
            return
        sSelBefore = cmds.ls(sl=True)
        sNamespace = self.getNamespace()
        sMaster = library.getMasterName(sNamespace)
        sMotionPathAttrCtrlAttr = '%s.sMotionPathAttrCtrl' % sMaster
        if not cmds.objExists(sMotionPathAttrCtrlAttr):
            cmds.confirmDialog(m='character is not setup-ed for motion path')
            return

        sAttrCtrl = cmds.getAttr(sMotionPathAttrCtrlAttr)
        sCtrls = eval(cmds.getAttr('%s.sMotionPathCtrls' % sMaster))
        sMainCtrls = eval(cmds.getAttr('%s.sMotionPathMainCtrls' % sMaster))

        cmds.undoInfo(openChunk=True)
        try:
            sGroup = cmds.createNode('transform', n='grp_motionPath_%s' % sCurve)

            sButtons = ['only main', 'main + secondarys']
            sButtonResult = cmds.confirmDialog(m='only the main ctrls (%s), or also secondary ctrls (%s)' % (str(sMainCtrls), list(set(sCtrls)-set(sMainCtrls))), button=sButtons)
            if sButtonResult == sButtons[0]:
                sDoCtrls = sMainCtrls
            elif sButtonResult == sButtons[1]:
                sDoCtrls = list(set(sMainCtrls+sCtrls))
            else:
                raise Exception('unknown button result (%s)' % sButtonResult)

            sPathLength = library.createCurveLengthNode(sCurve)
            sDistanceAttr = library.addAttr('%s%s' % (sNamespace, sAttrCtrl), ln='pathDistance', k=True, bReturnIfExists=True)
            sTwistAttr = library.addAttr('%s%s' % (sNamespace, sAttrCtrl), ln='pathTwist', k=True, bReturnIfExists=True)

            print ('sDoCtrls: ', sDoCtrls)
            fAllOffsets = [cmds.getAttr('%s%s.fMotionPathOffset' % (sNamespace,sCtrl)) for sCtrl in sDoCtrls]
            print ('fAllOffsets: ', fAllOffsets)
            fMinOffset = fAllOffsets[0] if len(fAllOffsets) == 1 else min(*fAllOffsets)
            fMaxOffset = fAllOffsets[0] if len(fAllOffsets) == 1 else max(*fAllOffsets)
            sLocs = []
            for c, sCtrl in enumerate(sDoCtrls):
                sFullCtrl = '%s%s' % (sNamespace, sCtrl)
                ffConstraintOffset = eval(cmds.getAttr('%s.ffMotionPathConstraintOffset' % sFullCtrl))

                sLocator = library.createLocator('%s__%s_LOC' % (sCurve,sCtrl), fSize=fMaxOffset*0.1)
                sLocs.append(sLocator)
                fOffset = cmds.getAttr('%s.fMotionPathOffset' % sFullCtrl) - fMinOffset

                sMotionPath = library.createMotionPath(sCurve, fU=0.0, bLengthPerc=True)[0]
                cmds.setAttr('%s.frontAxis' % sMotionPath, 2)
                cmds.setAttr('%s.upAxis' % sMotionPath, 1)
                cmds.setAttr('%s.inverseFront' % sMotionPath, False)
                cmds.setAttr('%s.inverseUp' % sMotionPath, False)

                sPathMatrix = library.createComposeMatrixNode(xTranslate='%s.allCoordinates' % sMotionPath,
                                                              xRotate='%s.r' % sMotionPath)
                sPathLocal = library.createMultMatrixNode([library.createComposeMatrixNode(ffConstraintOffset[0], ffConstraintOffset[1]),
                                                            sPathMatrix,
                                                           '%s.parentInverseMatrix' % sLocator])
                library.createDecomposeMatrix(sPathLocal, sTargetPos='%s.t' % sLocator, sTargetRot='%s.r' % sLocator)
                sDistancePlusOffset = library.createAdditionNode([sDistanceAttr, fOffset])
                library.createMultiplyNode(sDistancePlusOffset, sPathLength, sOperation='divide', sTarget='%s.uValue' % sMotionPath)

                cmds.connectAttr(sTwistAttr, '%s.frontTwist' % sMotionPath)

            for c, sCtrl in enumerate(sDoCtrls):
                sLocator = sLocs[c]
                sWorldLocator = library.createLocator('%s__%s_LOCWORLD' % (sCurve,sCtrl), fSize=fMaxOffset*0.2, sParent=sGroup)

                sFullCtrl = '%s%s' % (sNamespace, sCtrl)
                sParentCtrlAttr = '%s.sMotionPathParentCtrl' % sFullCtrl

                sAttachTransform = '%s%s' % (sNamespace, cmds.getAttr('%s.sMotionPathAttachTransform' % sFullCtrl))
                if cmds.objExists(sParentCtrlAttr):
                    sParentCtrl = cmds.getAttr(sParentCtrlAttr)
                    sPreviusLocator = '%s__%s_LOC' % (sCurve,sParentCtrl)
                    cmds.parent(sLocator, sPreviusLocator)

                    sFullParentCtrl = '%s%s' % (sNamespace, sParentCtrl)
                    sPreviousOut = '%s%s' % (sNamespace, cmds.getAttr('%s.sMotionPathOutTransform' % sFullParentCtrl))
                    sNewMatrix = library.createMultMatrixNode(['%s.matrix' % sLocator,
                                                               '%s.worldMatrix' % sPreviousOut])
                    library.createDecomposeMatrix(sNewMatrix, sTargetPos='%s.t' % sWorldLocator, sTargetRot='%s.r' % sWorldLocator, bConnectRotateOrder=True)

                    sAttachParent = cmds.listRelatives(sAttachTransform, p=True)[0]
                    library.constraintBlend(sAttachTransform, sAttachParent, sWorldLocator, sFullCtrl, 'pathBlend', fDefault=1.0)
                else:
                    cmds.parent(sLocator, sGroup)
                    cmds.parentConstraint(sLocator, sAttachTransform)


            cmds.setAttr('%s.v' % sGroup, False)
            cmds.select(sSelBefore)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        finally:
            cmds.undoInfo(closeChunk=True)


    def openRokokoUI(self):
        sLoadedPlugins = cmds.pluginInfo(query=True, listPlugins=True)
        sPlugin = 'rokoko-studio-live-maya-2020'
        if sPlugin not in sLoadedPlugins:
            cmds.loadPlugin(sPlugin)

        mel.eval('showRSLM')

    def humanIkConnect(self):
        print('humanIk connect')
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.humanIkConnect(self.getNamespace())
        
    def humanIkDisConnect(self):
        print('humanIk connect')
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.humanIkDisConnect(self.getNamespace())

    def characterizeSelectedMocap(self):
        print('humanIk connect')
        library.reload2(KangarooMatchTools)
        sButtons = ['yes', 'no, it\'s already in T Pose', 'cancel']
        sReturn = cmds.confirmDialog(m='Set rotations to zero?', button=sButtons)
        if sReturn == sButtons[2]:
            return
        else:
            bResetRotations = sReturn == sButtons[0]
            KangarooMatchTools.characterizeSelectedMocap(self.getNamespace(), bResetRotations=bResetRotations)

    def rokokoFaceConnect(self):
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.attachToRokokoFace(self.getNamespace())

    def importBlendshapeMeshAndConnect(self):
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.importBlendshapeMeshAndConnect(self.getNamespace())


    def faceArCsvFile(self):
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.faceArCsvFile(self.getNamespace())

    def rokokoBodyBake(self):
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.bakeRokokoBody(self.getNamespace())

    def rokokoBodyBakeHumanIk(self):
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.rokokoBodyBakeHumanIk(self.getNamespace())

    def rokokoFaceBake(self):
        library.reload2(KangarooMatchTools)
        KangarooMatchTools.bakeRokokoFace(self.getNamespace())


    def clickedCreate(self):
        print ('clickedCreate')
        self.qDuplicateButton.setChecked(False)
        self.updateEditWidgets()

    def clickedDuplicate(self):
        print ('clickedDuplicate')
        self.qCreateButton.setChecked(False)
        self.updateEditWidgets()

    def mayaSelectionChanged(self):
        if not self.bDisableNextScriptJob:
            sNamespace = self.qNamespace.getNamespace()
            sSel = [sO[len(sNamespace):] for sO in cmds.ls(sl=True) if sO.startswith(sNamespace)]
            for pickerImage in self.pickerImages:
                pickerImage.mayaSelectionChanged(sSel)

        self.bDisableNextScriptJob = False

    def closeEvent(self, event):
        print('killing script job with number: ', self.iSelectionScriptJob)
        cmds.scriptJob(kill=self.iSelectionScriptJob)

    def getNamespace(self):
        return self.qNamespace.getNamespace()

    def selectObjects(self, sObjects, bAdd=False, bDeselect=False, bDisableUndo=False):
        bDisableBefore = self.bDisableNextScriptJob
        self.bDisableNextScriptJob = True
        if bDisableUndo:
            bPrevUndoState = cmds.undoInfo(st=True, q=True)
            cmds.undoInfo(swf=False)
        try:
            sNamespace = self.qNamespace.getNamespace()
            sObjects = set(['%s%s' % (sNamespace, sO) for sO in sObjects])
            xNewSelectedObjects = [bDeselect, sObjects]
            if not bDisableUndo or self.xPreviousSelectedObjects == None or self.xPreviousSelectedObjects != xNewSelectedObjects:
                if bDeselect:
                    cmds.select(list(sObjects), deselect=bDeselect)
                else:
                    cmds.select(list(sObjects), add=bAdd)
                self.xPreviousSelectedObjects = list(xNewSelectedObjects)

        except:
            self.bDisableNextScriptJob = bDisableBefore
            raise
        finally:
            if bDisableUndo:
                cmds.undoInfo(swf=bPrevUndoState)


    def saveElements(self):
        for pickerImage, sElementsFile in zip(self.pickerImages, self.pickerElementFiles):
            xElements = [list(xE) for xE in pickerImage.xElements]
            for xE in xElements:
                del xE[5:]

            dSaveData = {'fSymmetryPos': pickerImage.fSymmetryPos,
                         'xElements': xElements}

            print('saving to file %s' % sElementsFile)
            with open(sElementsFile, 'w') as outfile:
                json.dump(dSaveData, outfile, indent=2)

        self.dirtySaveButton(False)


    def editClicked(self, bState):
        print ('editClicked..')
        self.qCreateButton.setChecked(False)
        self.qDuplicateButton.setChecked(False)
        self.updateEditWidgets(bState)


    def dirtySaveButton(self, bDirty=True, iDebugInt=None):
        self.qSaveButton.setText('Save *' if bDirty else 'Save')
        # print ('iDebugInt: ', iDebugInt)

    def updateEditWidgets(self, bState=True):
        self.qCreateButton.setHidden(not bState)
        self.qDuplicateButton.setHidden(not bState)

        self.qElementsCombo.setHidden(not bState)
        self.qSidesCombo.setHidden(not bState)
        self.qTextText.setHidden(not bState)

        bCreateState = self.qCreateButton.isChecked() if bState else False
        self.qElementsCombo.setEnabled(bCreateState)
        self.qSidesCombo.setEnabled(bCreateState)

        self.qSaveButton.setHidden(not bState)
        [pickerImage.switchMode(bState) for pickerImage in self.pickerImages]
        [pickerImage.editClicked() for pickerImage in self.pickerImages]


    def keyPressEvent(self, event):
        if event.key() == 16777216:  # escape
            self.setWindowState(QtCore.Qt.WindowMinimized)
        else:
            [pickerImage.keyPressEvent(event) for pickerImage in self.pickerImages]


    def keyReleaseEvent(self, event):
        [pickerImage.keyReleaseEvent(event) for pickerImage in self.pickerImages]



class QNamespace(QtWidgets.QWidget):
    setFromSelectedClicked = QtCore.Signal(str)

    def __init__(self):
        QtWidgets.QWidget.__init__(self)
        qLayout = QtWidgets.QHBoxLayout()
        qLayout.setContentsMargins(0,0,0,0)
        self.setLayout(qLayout)

        self.qLine = QtWidgets.QLineEdit('')
        qLayout.addWidget(QtWidgets.QLabel('Namespace'))
        qLayout.addWidget(self.qLine)
        self.qLine.setEnabled(False)

        self.qSetFromSelected = QtWidgets.QPushButton('Set from Selected')
        self.qSetFromSelected.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        self.qSetFromSelected.clicked.connect(self.setClicked)
        qLayout.addWidget(self.qSetFromSelected)
        qLayout.addLayout(qLayout)

        self.qSetFromList = QtWidgets.QPushButton('Set from List')
        self.qSetFromList.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        self.qSetFromList.clicked.connect(self.setClickedList)
        qLayout.addWidget(self.qSetFromList)
        qLayout.addLayout(qLayout)

        self.sCurrentNamespace = None


    def _setFromNamespace(self, sNamespace):
        self.qLine.setText(sNamespace)
        self.setFromSelectedClicked.emit(sNamespace)
        self.sCurrentNamespace = sNamespace

    def setClickedList(self):
        sPickerDatas = cmds.ls('*:AnimPickerData', et='transform')
        sNamespaces = sorted(['%s:' % sT.split(':')[0] for sT in sPickerDatas])
        qMenu = QtWidgets.QMenu()
        if sNamespaces:
            for sNamespace in sNamespaces:
                def _add(sNamespace=sNamespace):
                    self._setFromNamespace(sNamespace)
                qAction = qMenu.addAction(sNamespace[:-1], _add)
                if sNamespace == self.sCurrentNamespace:
                    qAction.setEnabled(False)
        else:
            qAction = qMenu.addAction('no characters found')
            qAction.setEnabled(False)

        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())


    def setClicked(self, bDialogIfNoValidSelection=True):
        fBefore = time.time()
        sSel = cmds.ls(sl=True)
        if not sSel or ':' not in sSel[0]:
            if cmds.objExists('master'):
                self.qLine.setText('')
            else:
                if bDialogIfNoValidSelection:
                    cmds.confirmDialog(title='Please Select object with Namespace',
                                       message='Please Select object with Namespace',
                                       button=['ok'])
                return
        else:
            sNamespace = '%s:' % ':'.join(sSel[0].split(':')[:-1])
            self._setFromNamespace(sNamespace)

        print ('updating the UI took %0.3f seconds' % (time.time()-fBefore))

    def getNamespace(self):
        return self.qLine.text()


def lineIntersection(a1, a2, b1, b2):
    b = a2 - a1
    d = b2 - b1
    fDotPerp = float(b.x() * d.y() - b.y() * d.x())

    if fDotPerp == 0:  # parallel
        return False

    c = b1 - a1
    t = (c.x() * d.y() - c.y() * d.x()) / fDotPerp
    if t < 0 or t > 1:
        return False

    u = (c.x() * b.y() - c.y() * b.x()) / fDotPerp
    if u < 0 or u > 1:
        return False

    # intersectionPoint = a1 + t * b

    return True


def _setAllArray(xArray, xValues):
    for i in range(len(xArray)):
        xArray[i] = xValues[i]


def _setAllArrayReverse(xArray, xValues):
    for i in range(len(xArray)):
        xArray[i] = not xValues[i]


def _setAll(xArray, xValue):
    for i in range(len(xArray)):
        xArray[i] = xValue


def _any(xArray):
    for i in range(len(xArray)):
        if xArray[i]:
            return True
    return False


def _all(xArray):
    for i in range(len(xArray)):
        if not xArray[i]:
            return False
    return True


def _perc(xArray):
    fSum = 0.0
    for xV in xArray:
        if xV: fSum += 1.0
    return fSum / len(xArray)




class QSetObject(QtWidgets.QWidget):
    def __init__(self, sLabel):
        QtWidgets.QWidget.__init__(self)

        qLayout = QtWidgets.QHBoxLayout()
        self.qLine = QtWidgets.QLineEdit('')
        qLayout.addWidget(QtWidgets.QLabel(sLabel))
        qLayout.addWidget(self.qLine)
        self.qLine.setEnabled(False)

        qSetButton = QtWidgets.QPushButton('<<')
        qSetButton.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        qSetButton.clicked.connect(self.setClicked)
        qLayout.addWidget(qSetButton)

        self.setLayout(qLayout)


    def setClicked(self):

        sObject = cmds.ls(sl=True)[0]
        self.qLine.setText(sObject)


    def getObject(self):
        sText = self.qLine.text()
        return sText


