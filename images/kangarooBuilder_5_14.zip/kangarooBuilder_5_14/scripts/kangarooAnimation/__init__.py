###############################################################################################
#
# Kangaroo builder has been created by Thomas Bittner from 2019 to 2024, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. Please use the contact page on kangaroobuilder.com for that.
#
# For only using the tool within your company, a license is required if you are using the
# skinCluster tools. You are free to use all other code as long it's within your company.
#
# To distribute any or all of the code, a license is required. Please use the contact page on 
# kangaroobuilder.com for that.
# 
# In any case the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################
