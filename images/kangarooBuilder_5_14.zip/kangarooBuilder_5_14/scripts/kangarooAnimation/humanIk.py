###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
from collections import OrderedDict
import os
import kangarooAnimation.library as library



def createHumanIkSkeleton(sCharacter, bCharacterize=False):
    library.reload2(library)
    sRoot = 'humanIk:Reference'
    # report.report.addLogText('sRoot: %s, sCharacter: %s, sGenerator: %s: ' % (sRoot, sCharacter, sGenerator))
    importSkeleton()
    sMaster = library.getMasterName()
    library.addOffOnAttr(sMaster, 'humanIkVis', bDefaultValue=False, sTarget='%s.v' % sRoot, bReturnIfExists=True)
    cmds.parent(sRoot, sMaster)
    # general height
    fHikHeight = cmds.xform('humanIk:Head', q=True, t=True, ws=True)[1]
    fKangarooHeight = cmds.xform('jnt_m_headMain', q=True, t=True, ws=True)[1]
    fScaleFactor = fKangarooHeight / fHikHeight

    sAllJoints = cmds.listRelatives(sRoot, ad=True, typ='joint')
    for sJoint in sAllJoints:
        fTranslation = cmds.getAttr('%s.t' % sJoint)[0]
        cmds.setAttr('%s.t' % sJoint, fTranslation[0] * fScaleFactor, fTranslation[1] * fScaleFactor,
                     fTranslation[2] * fScaleFactor)
        library.matchRadius(sJoint, sJoint, fScaleFactor)

    # spine
    sSpineCtrls = ['spineBase_ctrl'] + sorted(cmds.ls('spineSplineFk_?_ctrl'))

    sShoulders = ['humanIk:LeftShoulder', 'humanIk:RightShoulder']
    sNeck = ['humanIk:Neck']

    sSpineJoints = ['humanIk:Hips'] + cmds.ls('humanIk:Spine*')
    iSpineCount = len(sSpineCtrls)
    if len(sSpineJoints) > iSpineCount:
        cmds.parent(sShoulders + sNeck, w=True)
        cmds.delete(sSpineJoints[iSpineCount])
        sSpineJoints = sSpineJoints[0:iSpineCount]
        cmds.parent(sShoulders + sNeck, sSpineJoints[-1])

    for i, sCtrl, sHik in zip(range(len(sSpineCtrls)), sSpineCtrls, sSpineJoints):
        matchJointToCtrl(sCtrl, sHik, bPosition=True, xRotation=[(1, 0, 0), (0, 1, 0)],
                         bCreateConstraintAttributes=False if i == 0 else True)

    createConstraintAttributes('cog_ctrl', sSpineJoints[0])


    if cmds.objExists('neckA_ctrl'):
        matchJointToCtrl('neckA_ctrl', 'humanIk:Neck', bPosition=True, xRotation=[(1, 0, 0), (0, 1, 0)],
                         bCreateConstraintAttributes=True)
    else:
        matchJointToCtrl('neckBaseIk_ctrl', 'humanIk:Neck', bPosition=True, xRotation=[(1, 0, 0), (0, 1, 0)],
                         bCreateConstraintAttributes=True)
    matchJointToCtrl('head_ctrl', 'humanIk:Head', bPosition=True, xRotation=[(1, 0, 0), (0, 1, 0)],
                     bCreateConstraintAttributes=True)

    matchJointToCtrl('ctrl_l_clavicleOut', 'humanIk:LeftShoulder', bPosition=True, xRotation=[(1, 0, 0), (0, 0, 1)])
    createConstraintAttributes('clavicle_l_ctrl', 'humanIk:LeftShoulder')
    
    
    if False: #cmds.objExists('clavicle_l_ctrl.auto'):
        matchJointToCtrl('armUpperChild_l_ctrl', 'humanIk:LeftArm', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armElbowChild_l_ctrl', 'humanIk:LeftForeArm', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armWristChild_l_ctrl', 'humanIk:LeftHand', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)], bCreateConstraintAttributes=True)
    else:
        matchJointToCtrl('armUpper_l_ctrl', 'humanIk:LeftArm', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armElbow_l_ctrl', 'humanIk:LeftForeArm', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armWrist_l_ctrl', 'humanIk:LeftHand', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)], bCreateConstraintAttributes=True)

    matchJointToCtrl('ctrl_r_clavicleOut', 'humanIk:RightShoulder', bPosition=True, xRotation=[(0, 1, 0), (1, 0, 0)])
    createConstraintAttributes('clavicle_r_ctrl', 'humanIk:RightShoulder')

    if False: #cmds.objExists('clavicle_r_ctrl.auto'):
        matchJointToCtrl('armUpperChild_r_ctrl', 'humanIk:RightArm', bPosition=True, xRotation=[(0, 1, 0), (-1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armElbowChild_r_ctrl', 'humanIk:RightForeArm', bPosition=True, xRotation=[(0, 1, 0), (-1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armWristChild_r_ctrl', 'humanIk:RightHand', bPosition=True, xRotation=[(0, 1, 0), (-1, 0, 0)], bCreateConstraintAttributes=True)
    else:
        matchJointToCtrl('armUpper_r_ctrl', 'humanIk:RightArm', bPosition=True, xRotation=[(0, 1, 0), (-1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armElbow_r_ctrl', 'humanIk:RightForeArm', bPosition=True, xRotation=[(0, 1, 0), (-1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('armWrist_r_ctrl', 'humanIk:RightHand', bPosition=True, xRotation=[(0, 1, 0), (-1, 0, 0)], bCreateConstraintAttributes=True)

    cmds.setAttr('humanIk:LeftHandThumb2.t', 1, 0, 0)
    matchJointToCtrl('thumbMeta_l_ctrl', 'humanIk:LeftHandThumb1', bPosition=True, xRotation=[(0, 0, -1), (1, 0, 0)],
                     bCreateConstraintAttributes=True)
    matchJointToCtrl('thumbBase_l_ctrl', 'humanIk:LeftHandThumb2', bPosition=True, xRotation=[(0, 0, -1), (1, 0, 0)],
                     bCreateConstraintAttributes=True)
    matchJointToCtrl('thumbMid_l_ctrl', 'humanIk:LeftHandThumb3', bPosition=True, xRotation=[(0, 0, -1), (1, 0, 0)],
                     bCreateConstraintAttributes=True)
    cmds.setAttr('humanIk:RightHandThumb2.t', -1, 0, 0)
    matchJointToCtrl('thumbMeta_r_ctrl', 'humanIk:RightHandThumb1', bPosition=True, xRotation=[(0, 0, -1), (-1, 0, 0)],
                     bCreateConstraintAttributes=True)
    matchJointToCtrl('thumbBase_r_ctrl', 'humanIk:RightHandThumb2', bPosition=True, xRotation=[(0, 0, -1), (-1, 0, 0)],
                     bCreateConstraintAttributes=True)
    matchJointToCtrl('thumbMid_r_ctrl', 'humanIk:RightHandThumb3', bPosition=True, xRotation=[(0, 0, -1), (-1, 0, 0)],
                     bCreateConstraintAttributes=True)

    for sFinger in ['index', 'middle', 'ring', 'pinky']:
        matchJointToCtrl('%sBase_l_ctrl' % sFinger, 'humanIk:LeftHand%s1' % library.getFirstLetterUpperCase(sFinger),
                         bPosition=True, xRotation=[(0, 0, -1), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('%sMid_l_ctrl' % sFinger, 'humanIk:LeftHand%s2' % library.getFirstLetterUpperCase(sFinger),
                         bPosition=True, xRotation=[(0, 0, -1), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('%sTip_l_ctrl' % sFinger, 'humanIk:LeftHand%s3' % library.getFirstLetterUpperCase(sFinger),
                         bPosition=True, xRotation=[(0, 0, -1), (1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('%sBase_r_ctrl' % sFinger, 'humanIk:RightHand%s1' % library.getFirstLetterUpperCase(sFinger),
                         bPosition=True, xRotation=[(0, 0, -1), (-1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('%sMid_r_ctrl' % sFinger, 'humanIk:RightHand%s2' % library.getFirstLetterUpperCase(sFinger),
                         bPosition=True, xRotation=[(0, 0, -1), (-1, 0, 0)], bCreateConstraintAttributes=True)
        matchJointToCtrl('%sTip_r_ctrl' % sFinger, 'humanIk:RightHand%s3' % library.getFirstLetterUpperCase(sFinger),
                         bPosition=True, xRotation=[(0, 0, -1), (-1, 0, 0)], bCreateConstraintAttributes=True)

    matchJointToCtrl('jnt_l_leg_upperTwist_000', 'humanIk:LeftUpLeg', bPosition=True, xRotation=[(0, -1, 0), (0, 0, -1)])
    matchJointToCtrl('jnt_l_leg_lowerTwist_000', 'humanIk:LeftLeg', bPosition=True, xRotation=[(0, -1, 0), (0, 0, -1)])
    # matchJointToCtrl('legHeel_l_ctrl', 'humanIk:LeftFoot', bPosition=True)
    matchJointToCtrl('jnt_l_legWrist', 'humanIk:LeftFoot', bPosition=True, xRotation=[(0, -1, 0), (0, 0, -1)])
    matchJointToCtrl('jnt_l_legFingers', 'humanIk:LeftToeBase', bPosition=True) #, xRotation=[(0, -1, 0), (0, 0, -1)])

    matchJointToCtrl('jnt_r_leg_upperTwist_000', 'humanIk:RightUpLeg', bPosition=True, xRotation=[(0, 1, 0), (0, 0, 1)])
    matchJointToCtrl('jnt_r_leg_lowerTwist_000', 'humanIk:RightLeg', bPosition=True, xRotation=[(0, 1, 0), (0, 0, 1)])
    # matchJointToCtrl('legHeel_r_ctrl', 'humanIk:RightFoot', bPosition=True)
    matchJointToCtrl('jnt_r_legWrist', 'humanIk:RightFoot', bPosition=True, xRotation=[(0, 1, 0), (0, 0, 1)])
    matchJointToCtrl('jnt_r_legFingers', 'humanIk:RightToeBase', bPosition=True) #, xRotation=[(0, 1, 0), (0, 0, 1)])

    createConstraintAttributes('legIk_l_ctrl', 'humanIk:LeftToeBase')
    createConstraintAttributes('legIk_r_ctrl', 'humanIk:RightToeBase')
    createConstraintAttributes('armIk_l_ctrl', 'humanIk:LeftHand')
    createConstraintAttributes('armIk_r_ctrl', 'humanIk:RightHand')

    for s,sSide in enumerate(['l','r']):
        sAnkleRev = 'grp_%s_legAnkleRevOffsetAttr' % sSide
        if cmds.objExists(sAnkleRev):
            sConstraintOffset = library.insertParent(sAnkleRev, 'grp_%s_tempConstraintOffset' % sSide)
            createConstraintAttributes(sConstraintOffset, 'humanIk:%sFoot' % library.sSidesFirstUpper[s], sSkipTranslate=['x','y','z'],
                                       dExtra={'sRotatePlugs':['legIk_%s_ctrl.ballRoll' % sSide, 'legIk_%s_ctrl.ballSide' % sSide, 'legIk_%s_ctrl.ballTwist' % sSide]})
        else:
            createConstraintAttributes('legAnkleRev_%s_ctrl' % sSide, 'humanIk:%sFoot' % library.sSides4[s])


    for sJoint in sAllJoints:
        if cmds.objExists(sJoint):
            cmds.makeIdentity(sJoint, r=True)

    if bCharacterize:
        sCharacterDefinition = hikCreateDefinition(sCharacter)
        library.addStringAttr(sMaster, 'sHumanIkCharacerNode', sCharacterDefinition, bLock=True)
        assignAllStandardBones(sCharacter, 'humanIk:')
        # mel.eval('hikToggleLockDefinition()')
#



def matchJointToCtrl(sCtrl, sHik, bPosition, xRotation=False, bCreateConstraintAttributes=False):
    if not cmds.objExists(sHik):
        return

    if not cmds.objExists(sCtrl):
        cmds.delete(sHik)
        return
    else:
        if bPosition:
            cmds.delete(cmds.pointConstraint(sCtrl, sHik))
        if xRotation:
            fAim, fUp = xRotation
            sTempAim = library.createLocator('tempAim', sParent=sCtrl, xPos=[1,0,0])
            sTempUp = library.createLocator('tempUp', sParent=sCtrl, xPos=[0,1,0])
            cmds.delete(cmds.aimConstraint(sTempAim, sHik, wut='object', wuo=sTempUp, aim=fAim, u=fUp))
            cmds.delete(sTempAim, sTempUp)
            cmds.makeIdentity(sHik, r=True, apply=True)

        if bCreateConstraintAttributes:
            createConstraintAttributes(sCtrl, sHik)


def createConstraintAttributes(sCtrl, sHik, sSkipTranslate=[], sSkipRotate=[], dExtra={}):
    dData = {}
    dData['sCtrl'] = sCtrl

    if not sSkipTranslate:
        sSkipTranslate = list(sSkipTranslate)
        for sA in ['tx','ty', 'tz']:
            if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True):
                sSkipTranslate.append(sA[-1])

    if not sSkipRotate:
        sSkipRotate = list(sSkipRotate)
        for sA in ['rx','ry', 'rz']:
            if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True):
                sSkipRotate.append(sA[-1])
    
    # if sCtrl == '':
	# 	print ('sSkipTranslate: ', sSkipTranslate)

    sConstraint = cmds.parentConstraint(sHik, sCtrl, mo=True, skipTranslate=sSkipTranslate, skipRotate=sSkipRotate)[0]
    dData['fOffsetTranslate'] = cmds.getAttr('%s.target[0].targetOffsetTranslate' % sConstraint)[0]
    dData['fOffsetRotate'] = cmds.getAttr('%s.target[0].targetOffsetRotate' % sConstraint)[0]
    dData['sSkipTranslate'] = sSkipTranslate
    dData['sSkipRotate'] = sSkipRotate


    dData.update(dExtra)

    cmds.delete(sConstraint)
    library.addToListStringAttr(sHik, 'xCtrls', sAdd=[dData], bLock=True)



def initiate():
    plugins_list = ["mayaHIK", "mayaCharacterization", "OneClick"]
    for plugin in plugins_list:
        if not cmds.pluginInfo(plugin, q=True, loaded=True):
            cmds.loadPlugin(plugin)
    mel.eval('hikToggleWidget()')


def importSkeleton(sCharacterName=None):
    sFile = os.path.join(os.path.dirname(__file__), os.pardir, 'mayaImport', 'humanIk.ma')
    library.importMayaFiles(sFile, sNamespace='humanIk')[0]

    # if sCharacterName:
    #     sRoot = cmds.rename(sRoot, library.replaceStringStart(sRoot, sCharacter, sCharacterName))
    #
    #     sAllNodes = sorted(cmds.listRelatives(sRoot, c=True, ad=True, f=True), key=lambda a:len(a), reverse=True)
    #     for sNode in sAllNodes:
    #         cmds.rename(sNode, library.replaceStringStart(sNode.split('|')[-1], sCharacter, sCharacterName))
    #     sCharacter = cmds.rename(sCharacter, sCharacterName)





def hikCreateSkeleton(sCharacter):
    '''
    This is MEL function from maya installation folder converted to Python, and added sCharacter input and return of generator node
    Actually useless because couldn't find way to continue scripting right after creation
    '''
    mel.eval('hikSyncSkeletonGeneratorFromUI()')

    mel.eval('hikCreateCharacter( "%s" )' % sCharacter)
    sCurrentName = mel.eval('hikGetCurrentCharacter()')

    if sCurrentName:

        sSkeletonGeneratorNode = cmds.createNode('HIKSkeletonGeneratorNode')
        cmds.setAttr ('%s.isHistoricallyInteresting' % sSkeletonGeneratorNode, 0)
        sOutPlug = '%s.CharacterNode' % sSkeletonGeneratorNode;
        sInPlug = '%s.SkeletonGenerator' % sCurrentName
        cmds.connectAttr(sOutPlug, sInPlug)

        mel.eval('hikReadDefaultCharPoseFileOntoSkeletonGeneratorNode("%s")' % sSkeletonGeneratorNode)
        mel.eval('hikSetSkeletonGeneratorDefaults("%s")' % sSkeletonGeneratorNode)

        cmds.select(sCurrentName)

        mel.eval('hikSetCurrentSource(hikNoneString())')    # set the current source to "None"
        # If we have no characters yet, select the newly
        # created character. This will refresh both the
        # character and source lists...
        mel.eval('hikUpdateCurrentCharacterFromScene()')

        # Update the definition information if the plug-in is loaded
        mel.eval('hikUpdateDefinitionUI()')

        # Select and refresh the skeleton generator tab
        mel.eval('hikSelectSkeletonTab()')

        return sSkeletonGeneratorNode, '%s_Reference' % sCharacter



# this sets up bone/ctrl mappings on kangaroo bipeds. But it's not great because it can't do finger bones and foot ballRolls
def humanIkTags(sCharacter):
    hikCreateDefinition(sCharacter)
    assignAllBones(sCharacter)
    ctrlMapping(sCharacter)



def hikCreateDefinition(sCharacter):

    sCharacterName = mel.eval('hikCreateCharacter( "%s" )' % sCharacter)
    mel.eval('hikUpdateCharacterList()')    # update the character list
    mel.eval('hikSelectDefinitionTab()')    # select and update appropriate tab
    mel.eval('hikUpdateCharacterListCallback()')
    
    return sCharacterName

def assignAllBones(sCharacter):
    dBoneIndexMapper = {}

    # spine
    for iInd, sBone in zip([8, 23, 24, 25, 26, 27, 28, 29, 30, 31], cmds.ls('jnt_m_spineSpine_???', et='joint')):
        dBoneIndexMapper[sBone] = iInd

    # neck
    for iInd, sBone in zip([20, 32, 33, 34, 35, 36, 37, 38, 39, 40], cmds.ls('jnt_m_neckSpine_???', et='joint')):
        dBoneIndexMapper[sBone] = iInd

    dBoneIndexMapper['jnt_m_hips'] = 1
    dBoneIndexMapper['jnt_m_headMain'] = 15

    dBoneIndexMapper['jnt_l_clavicleMain'] = 18
    dBoneIndexMapper['jnt_l_arm_upperTwist_000'] = 9
    dBoneIndexMapper['jnt_l_arm_lowerTwist_000'] = 10
    dBoneIndexMapper['jnt_l_armWrist'] = 11

    dBoneIndexMapper['jnt_r_clavicleMain'] = 19
    dBoneIndexMapper['jnt_r_arm_upperTwist_000'] = 12
    dBoneIndexMapper['jnt_r_arm_lowerTwist_000'] = 13
    dBoneIndexMapper['jnt_r_armWrist'] = 14

    dBoneIndexMapper['jnt_l_leg_upperTwist_000'] = 2
    dBoneIndexMapper['jnt_l_leg_lowerTwist_000'] = 3
    dBoneIndexMapper['jnt_l_legWrist'] = 4
    dBoneIndexMapper['jnt_l_legFingers'] = 16

    dBoneIndexMapper['jnt_r_leg_upperTwist_000'] = 5
    dBoneIndexMapper['jnt_r_leg_lowerTwist_000'] = 6
    dBoneIndexMapper['jnt_r_legWrist'] = 7
    dBoneIndexMapper['jnt_r_legFingers'] = 17

    sFingerBones = ['Base', 'Mid', 'Tip']
    sThumbBones = ['Meta', 'Base', 'Mid']

    for iInd, sBone in zip([50, 51, 52], ['jnt_l_thumb%s' % sB for sB in sThumbBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([54, 55, 56], ['jnt_l_index%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([58, 59, 60], ['jnt_l_middle%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([62, 63, 64], ['jnt_l_ring%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([66, 67, 68], ['jnt_l_pinky%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd

    for iInd, sBone in zip([74, 75, 76], ['jnt_r_thumb%s' % sB for sB in sThumbBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([78, 79, 80], ['jnt_r_index%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([82, 83, 84], ['jnt_r_middle%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([86, 87, 88], ['jnt_r_ring%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([90, 91, 92], ['jnt_r_pinky%s' % sB for sB in sFingerBones]):
        dBoneIndexMapper[sBone] = iInd



    sExistingBones = cmds.ls('skeleton', dag=True, et='joint')
    sIntersectedBones = set(sExistingBones).intersection(set(dBoneIndexMapper.keys()))

    for sBone in sorted(sIntersectedBones):
        mel.eval('setCharacterObject("%s", "%s", %d, 0)' % (sBone, sCharacter, dBoneIndexMapper[sBone]))


def assignAllStandardBones(sCharacter, sNamespace):
    dBoneIndexMapper = {}

    sSpineJoints = ['%sHips' % sNamespace] + cmds.ls('%sSpine*' % sNamespace, et='joint')

    # spine
    for iInd, sBone in zip([8, 23, 24, 25, 26, 27, 28, 29, 30, 31], sSpineJoints[1:]):
        dBoneIndexMapper[sBone] = iInd

    # neck
    for iInd, sBone in zip([20, 32, 33, 34, 35, 36, 37, 38, 39, 40], ['%sNeck' % sNamespace]):
        dBoneIndexMapper[sBone] = iInd

    dBoneIndexMapper[sSpineJoints[0]] = 1
    dBoneIndexMapper['%sHead' % sNamespace] = 15

    dBoneIndexMapper['%sLeftShoulder' % sNamespace] = 18
    dBoneIndexMapper['%sLeftArm' % sNamespace] = 9
    dBoneIndexMapper['%sLeftForeArm' % sNamespace] = 10
    dBoneIndexMapper['%sLeftHand' % sNamespace] = 11

    dBoneIndexMapper['%sRightShoulder' % sNamespace] = 19
    dBoneIndexMapper['%sRightArm' % sNamespace] = 12
    dBoneIndexMapper['%sRightForeArm' % sNamespace] = 13
    dBoneIndexMapper['%sRightHand' % sNamespace] = 14

    dBoneIndexMapper['%sLeftUpLeg' % sNamespace] = 2
    dBoneIndexMapper['%sLeftLeg' % sNamespace] = 3
    dBoneIndexMapper['%sLeftFoot' % sNamespace] = 4
    dBoneIndexMapper['%sLeftToeBase' % sNamespace] = 16

    dBoneIndexMapper['%sRightUpLeg' % sNamespace] = 5
    dBoneIndexMapper['%sRightLeg' % sNamespace] = 6
    dBoneIndexMapper['%sRightFoot' % sNamespace] = 7
    dBoneIndexMapper['%sRightToeBase' % sNamespace] = 17


    for iInd, sBone in zip([50, 51, 52], cmds.ls('%sLeftHandThumb*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([54, 55, 56], cmds.ls('%sLeftHandIndex*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([58, 59, 60], cmds.ls('%sLeftHandMiddle*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([62, 63, 64], cmds.ls('%sLeftHandRing*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([66, 67, 68], cmds.ls('%sLeftHandPinky*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd

    for iInd, sBone in zip([74, 75, 76], cmds.ls('%sRightHandThumb*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([78, 79, 80], cmds.ls('%sRightHandIndex*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([82, 83, 84], cmds.ls('%sRightHandMiddle*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([86, 87, 88], cmds.ls('%sRightHandRing*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd
    for iInd, sBone in zip([90, 91, 92], cmds.ls('%sRightHandPinky*' % sNamespace, et='joint')):
        dBoneIndexMapper[sBone] = iInd

    sReference = '%sReference' % sNamespace
    if cmds.objExists(sReference):
        mel.eval('setCharacterObject("%s", "%s", %d, 0)' % (sReference, sCharacter, 0))
        
    sExistingBones = cmds.ls('%s*' % sNamespace, et='joint')
    sIntersectedBones = set(sExistingBones).intersection(set(dBoneIndexMapper.keys()))
    print ('sIntersectedBones:', sIntersectedBones)
    for sBone in sorted(sIntersectedBones):
        mel.eval('setCharacterObject("%s", "%s", %d, 0)' % (sBone, sCharacter, dBoneIndexMapper[sBone]))

    mel.eval('hikToggleLockDefinition();')
    
    

def ctrlMapping(sCharacter):
    mel.eval('hikCreateCustomRig("%s")' % sCharacter)
    dCtrlIndexMapper = OrderedDict()

    dCtrlIndexMapper['cog_ctrl'] = 1

    sSpineCtrls = cmds.ls('spineSplineFk_?_ctrl')
    for iInd, sCtrl in zip([8, 23, 24, 25, 26], ['spineBase_ctrl'] + sSpineCtrls[:-1]):
        dCtrlIndexMapper[sCtrl] = iInd


    dCtrlIndexMapper[sSpineCtrls[-1]] = 1000

    dCtrlIndexMapper['clavicle_l_ctrl'] = 18
    dCtrlIndexMapper['armUpper_l_ctrl'] = 9
    dCtrlIndexMapper['armElbow_l_ctrl'] = 10
    dCtrlIndexMapper['armWrist_l_ctrl'] = 11

    dCtrlIndexMapper['clavicle_r_ctrl'] = 19
    dCtrlIndexMapper['armUpper_r_ctrl'] = 12
    dCtrlIndexMapper['armElbow_r_ctrl'] = 13
    dCtrlIndexMapper['armWrist_r_ctrl'] = 14

    dCtrlIndexMapper['legIk_l_ctrl'] = 4
    dCtrlIndexMapper['legIk_r_ctrl'] = 7

    dCtrlIndexMapper['neckTopIk_ctrl'] = 15
    dCtrlIndexMapper['neckBaseIk_ctrl'] = 20


    # chest 1000
    sExistingCtrls = cmds.ls('*_ctrl')
    sIntersectedCtrls = set(sExistingCtrls).intersection(set(dCtrlIndexMapper.keys()))

    # dOrder = {sK:i for sK,i in zip(dCtrlIndexMapper.keys(), range(len(dCtrlIndexMapper)))}
    for sBone in sorted(sIntersectedCtrls): #, key=lambda a:dOrder[a]):
        cmds.select(sBone)
        mel.eval('hikCustomRigAssignEffector %d' % dCtrlIndexMapper[sBone])


