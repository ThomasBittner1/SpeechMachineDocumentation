###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as OpenMaya2
import math
import re
import csv
from collections import OrderedDict
import json
import os
import sys
import importlib

kPythonVersion = None
def getPythonVersion():
    global kPythonVersion
    if kPythonVersion == None:
        kPythonVersion = int(sys.version[0])
    return kPythonVersion


def isStringOrUnicode(xValue):
    if getPythonVersion() == 2:
        return isinstance(xValue, (str, unicode))
    else:
        return isinstance(xValue, str)


def reload2(modModule):
    if getPythonVersion() == 2:
        return reload(modModule)
    else:
        return importlib.reload(modModule)


def sourceEnvs():
    sToolRootFolder = os.path.join(__file__, os.pardir, os.pardir, os.pardir, 'pathsEnv.mel')
    sPathsEnvFile = os.path.normpath(sToolRootFolder).replace('\\', '/')
    mel.eval(f'source "{sPathsEnvFile}"')


def isNone(xInput):
    return isinstance(xInput, type(None))


sSides4 = ['Left', 'Right']
sSides3 = ['LFT', 'RGT']
sSidesFirstUpper = ['Left', 'Right']
sSides1 = ['l','r']


def getSide(sFullName):
    sName = sFullName.split(':')[-1]

    if 'LFT' in sName: return 'l'
    if 'RGT' in sName: return 'r'

    if sName[0:2].isupper():
        if sName[0] == 'L': return 'l'
        if sName[0] == 'R': return 'r'
    if sName.startswith('l_'): return 'l'
    if sName.startswith('r_'): return 'r'
    if '_l_' in sName: return 'l'
    if '_r_' in sName: return 'r'
    if '_L_' in sName: return 'l'
    if '_R_' in sName: return 'r'
    if sName.endswith('Left'): return 'l'
    if sName.endswith('Right'): return 'r'
    if sName.endswith('_L'): return 'l'
    if sName.endswith('_R'): return 'r'
    if sName.endswith('_Lt'): return 'l'
    if sName.endswith('_Rt'): return 'r'
    if '_L.' in sName: return 'l'
    if '_R.' in sName: return 'r'
    if sName.startswith('Left'): return 'l'
    if sName.startswith('Right'): return 'r'
    return 'm'



def isNumber(xValue):
    if getPythonVersion() == 2:
        return isinstance(xValue, (int, long, float))
    else:
        return isinstance(xValue, (int, float))



def getMirrorName(sFullName):

    def _getMirrorNameNoNamespace(sName):
        sUnderscoreSplits = sName.split('__')
        if len(sUnderscoreSplits) == 5:
            sUnderscoreSplits[1] = getMirrorName(sUnderscoreSplits[1])
            return '__'.join(sUnderscoreSplits)

        if 'LFT' in sName: return sName.replace('LFT', 'RGT')
        if 'RGT' in sName: return sName.replace('RGT', 'LFT')

        if sName[0:2].isupper():
            if sName[0] == 'L': return 'R%s' % sName[1:]
            if sName[0] == 'R': return 'L%s' % sName[1:]
        if sName.startswith('l_'): return 'r_%s' % sName[2:]
        if sName.startswith('L_'): return 'R_%s' % sName[2:]
        if sName.startswith('r_'): return 'l_%s' % sName[2:]
        if sName.startswith('R_'): return 'L_%s' % sName[2:]
        if '_l_' in sName: return sName.replace('_l_', '_r_')
        if '_r_' in sName: return sName.replace('_r_', '_l_')
        if sName.endswith('Left'): return '%sRight' % sName[:-len('Left')]
        if sName.endswith('Right'): return '%sLeft' % sName[:-len('Right')]
        if sName.startswith('Left'): return 'Right%s' % sName[len('Left'):]
        if sName.startswith('Right'): return 'Left%s' % sName[len('Right'):]
        return sName

    sSplits = sFullName.split(':')
    sSplits[-1] = _getMirrorNameNoNamespace(sSplits[-1])
    return ':'.join(sSplits)


def getFirstLetterUpperCase(sText):
    if not sText:
        return ''
    elif len(sText) == 1:
        return sText.upper()
    else:
        return '%s%s' % (sText[0].upper(), sText[1:])


def intersectionSets(xSets):
    outSet = xSets[0]
    for xS in xSets[1:]:
        outSet = outSet.intersection(xS)
    return outSet



def matchRadius(sJoint, sFromJoint, fMultipl=1.0):
    cmds.setAttr('%s.radius' % sJoint, cmds.getAttr('%s.radius' % sFromJoint) * fMultipl)



def createLocator(sName, fSize=1.0, sParent=None, sMatch=None, xPos=None):
    sName = getUniqueName(sName)

    sLoc = cmds.spaceLocator(n=sName)[0]
    cmds.setAttr('%s.localScale' % cmds.listRelatives(sLoc, s=True)[0], fSize, fSize, fSize)

    if sParent:
        cmds.parent(sLoc, sParent)
        if sMatch:
            cmds.delete(cmds.parentConstraint(sMatch,sLoc))
        else:
            cmds.setAttr('%s.t' % sLoc, 0,0,0)
            cmds.setAttr('%s.r' % sLoc, 0,0,0)
            cmds.setAttr('%s.s' % sLoc, 1,1,1)
    elif sMatch:
        cmds.delete(cmds.parentConstraint(sMatch,sLoc))

    if isinstance(xPos, OpenMaya2.MVector) or not isNone(xPos):# != None:
        _connectOrSetVector(xPos, '%s.t' % sLoc, ['tx','ty','tz'])

    return sLoc



def intersectionLists(xLists):
    return list(intersectionSets([set(xL) for xL in xLists]))


def flattenedList(ssList):
    def _flattenREC(xObj, xResultList):
        if isinstance(xObj, (list,tuple)):
            for sO in xObj:
                _flattenREC(sO, xResultList)
        else:
            xResultList.append(xObj)
    sReturnList = []
    _flattenREC(ssList, sReturnList)
    return sReturnList


def getBiggestIndex(fList):
    iBiggest = 0
    fBiggest = abs(fList[0])
    for i in range(1, len(fList), 1):
        if abs(fList[i]) > fBiggest:
            fBiggest = abs(fList[i])
            iBiggest = i
    return iBiggest, 1.0 if fList[iBiggest] > 0 else -1.0


def addAttr(*args, **kwargs):

    try:
        bReturnIfExists = kwargs['bReturnIfExists']
        del kwargs['bReturnIfExists']
    except:
        bReturnIfExists = False

    try:
        bCb = kwargs['cb']
        del kwargs['cb']
    except:
        bCb = False

    try:
        sAddSidePostFix = kwargs['sAddSidePostFix']
        del kwargs['sAddSidePostFix']
    except:
        sAddSidePostFix = None
    if sAddSidePostFix != None:
        sLn = kwargs['ln']
        if sAddSidePostFix.startswith('l'):
            sLn = '%sLeft' % sLn
        elif sAddSidePostFix.startswith('r'):
            sLn = '%sRight' % sLn
        elif sAddSidePostFix.startswith('m'):
            sLn = '%sMiddle' % sLn
        else:
            raise Exception('don\'t recognize what side "%s" is' % sAddSidePostFix)
        kwargs['ln'] = sLn

    sAttr = '%s.%s' % (args[0], kwargs['ln'])
    if cmds.objExists(sAttr):
        if bReturnIfExists:
            return sAttr
        else:
            raise Exception('attribute %s already exists!' % sAttr)

    try:
        fMultipl = kwargs['fMultipl']
        del kwargs['fMultipl']
    except:
        fMultipl = None


    cmds.addAttr(*args, **kwargs)

    if kwargs.get('at', 'double').endswith('3'):
        kChildrenArgs = dict(kwargs)
        sAttrName = kwargs['ln']
        kChildrenArgs['at'] = kwargs['at'][:-1]
        kChildrenArgs['p'] = sAttrName
        for i in range(3):
            kChildrenArgs['ln'] = '%s%s' % (sAttrName, ['X','Y','Z'][i])
            cmds.addAttr(*args, **kChildrenArgs)

    if bCb:
        cmds.setAttr(sAttr, cb=True)

    if fMultipl:
        sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True)
        cmds.connectAttr(sAttr, '%s.input1X' % sMultipl)
        cmds.setAttr('%s.input2X' % sMultipl, fMultipl)
        return '%s.%s' % (sMultipl, 'outputX')
    else:
        return sAttr



def addStringAttr(sGrp, sAttr, sText, bLock=False):
    sAttr = addAttr(sGrp, ln=sAttr, dt='string', k=False, bReturnIfExists=True)
    bLockedBefore = cmds.getAttr(sAttr, lock=True)
    cmds.setAttr(sAttr, q=True, lock=False)
    cmds.setAttr(sAttr, sText, type='string')
    if bLockedBefore or bLock: cmds.setAttr(sAttr, lock=True)
    return sAttr



def getStringAttr(sGrp, sAttr, sDefault, bCreateIfNotExists=False):
    sFullAttr = '%s.%s' % (sGrp, sAttr)
    if cmds.objExists(sFullAttr):
        return cmds.getAttr(sFullAttr)
    else:
        if bCreateIfNotExists:
            addStringAttr(sGrp, sAttr, sDefault, bLock=True)
        return sDefault


def addToListStringAttr(sGrp, sAttr, sAdd=[], bLock=False):
    sCurrent = eval(getStringAttr(sGrp, sAttr, '[]'))
    addStringAttr(sGrp, sAttr, sCurrent+sAdd, bLock=bLock)



def addOffOnAttr(sNode, sAttr, bDefaultValue=True, bLock=False, bReturnNonIfExists=False, bReturnIfExists=False, sTarget=[], bNoAnim=False, bForce=False):
    if bReturnNonIfExists and cmds.objExists('%s.%s' % (sNode,sAttr)):
        return None
    elif bReturnIfExists and cmds.objExists('%s.%s' % (sNode,sAttr)):
        sAttr = '%s.%s' % (sNode,sAttr)
    else:
        sAttr = addAttr(sNode, ln=sAttr, at='enum', en='Off:On', defaultValue=bDefaultValue, k=False if bNoAnim else True, cb=True)
        if bLock:
            cmds.setAttr(sAttr, lock=True)

    for sT in toList(sTarget):
        try:
            cmds.connectAttr(sAttr, sT, force=bForce)
        except:
            raise Exception('Cannot connect %s -> %s' % (sAttr, sT))
    return sAttr



def getDistanceBetween(sTransformA, sTransformB):
    fA = cmds.xform(sTransformA, q=True, ws=True, t=True)
    fB = cmds.xform(sTransformB, q=True, ws=True, t=True)
    fDiff = [fA[0] - fB[0], fA[1]-fB[1], fA[2]-fB[2]]
    return listVectorLength(fDiff)


def listVectorLength(fVector):
    return math.sqrt(fVector[0]*fVector[0] + fVector[1]*fVector[1] + fVector[2]*fVector[2])


def getMasterName(sNamespace=''):
    for sMaster in ['%smaster' % sNamespace, '%sRig_Grp' % sNamespace]:
        if cmds.objExists(sMaster):
            return sMaster

    sSkeletonGrp = '%sskeleton' % sNamespace
    if cmds.objExists(sSkeletonGrp):
        return cmds.listRelatives(sSkeletonGrp, p=True)[0]



def getAnimAttrsFromNode(sCtrl):
    sAttrs = cmds.listAttr(sCtrl, keyable=False, channelBox=True, scalar=True, visible=True, leaf=True) or []
    sAttrs += cmds.listAttr(sCtrl, keyable=True, scalar=True, visible=True, leaf=True) or []

    dAttrs = {}
    for sAttr in sAttrs:
        sFullAttr = '%s.%s' % (sCtrl, sAttr)
        try:
            fValue = cmds.getAttr(sFullAttr)
            cmds.setAttr(sFullAttr, fValue) # shouldn't change anything, but will error (get ignored) when it's not setable
            dAttrs[sAttr] = fValue
        except:
            pass

    return dAttrs


# def _getMirrorName(sCtrl):
#     if 'LFT' in sCtrl:
#         return sCtrl.replace('LFT', 'RGT')
#     elif 'RGT' in sCtrl:
#         return sCtrl.replace('RGT', 'LFT')
#     elif '_l_' in sCtrl:
#         return sCtrl.replace('_l_', '_r_')
#     elif '_r_' in sCtrl:
#         return sCtrl.replace('_r_', '_l_')
#     else:
#         return sCtrl




# def _getSide(sCtrl):
#     if 'LFT' in sCtrl:
#         return 'l'
#     if 'RGT' in sCtrl:
#         return 'r'
#     return 'm'

def getFfMpegExe():
    sFfmpeg = os.path.join(os.path.dirname(__file__), os.pardir, 'kangarooAnimation/ffmpeg.exe').replace('\\', '/')
    if os.path.exists(sFfmpeg):
        return os.path.normpath(sFfmpeg)

    sFfmpeg = os.path.join(os.path.dirname(__file__), os.pardir, 'kangarooAnimation/ffmpeg/bin/ffmpeg.exe').replace('\\', '/')
    if os.path.exists(sFfmpeg):
        return os.path.normpath(sFfmpeg)

    raise Exception('ffmpeg.exe not found, please check https://kangaroobuilder.com/animationTools/#mp4-playblast for how to install.')


def createReverseNode(xInput, sTarget=None, sName='noname', sFullName=None):
    if sFullName == None:
        sFullName = 'reverse_%s' % sName
    sNode = cmds.createNode('reverse', name=sFullName)
    cmds.connectAttr(xInput, '%s.inputX' % sNode)
    sOutput = '%s.outputX' % sNode
    if sTarget:
        for sT in toList(sTarget):
            _connectTarget(sOutput, sT)
    return sOutput


def createBlendNode(xBlend, xFirst, xSecond, bVector=False, sName='noname', sFullName=None, sTarget=None):
    if sFullName == None:
        sFullName = 'BLEND_%s' % sName

    sNode = cmds.createNode('blendColors', name=sFullName)
    _connectOrSet(xBlend, '%s.blender' % sNode)

    if bVector:
        _connectOrSetVector(xFirst, '%s.color1' % sNode, ['color1R', 'color1G', 'color1B'])
        _connectOrSetVector(xSecond, '%s.color2' % sNode, ['color2R', 'color2G', 'color2B'])

        sOutput = '%s.output' % sNode
        if sTarget:
            cmds.connectAttr(sOutput, sTarget)
    else: # this is not tested yet!
        _connectOrSet(xFirst, '%s.color1R' % sNode)
        _connectOrSet(xSecond, '%s.color2R' % sNode)
        sOutput = '%s.outputR' % sNode
        _connectTargetIfNotNone(sTarget, sOutput)
        # if sTarget:
        #     cmds.connectAttr(sOutput, sTarget)
    return sOutput




def _connectTarget(sOutput, sTarget):
    if sTarget == None:
        return
    sTargets = toList(sTarget)
    for Ts in sTargets:
        cmds.connectAttr(sOutput, Ts)




def createVectorAdditionNode(xInputs, sTarget=None, sName='noname', sOperation='plus'):
    if not isinstance(xInputs, (list,tuple)):
        raise Exception('input needs to be a list')

    sNode = cmds.createNode('plusMinusAverage', name='plusMinusAverageVector_%s' % sName)
    for i, xInput in enumerate(xInputs):
        if isinstance(xInput, (list,tuple)):
            _connectOrSet(xInput[0], '%s.input3D[%d].input3Dx' % (sNode, i))
            _connectOrSet(xInput[1], '%s.input3D[%d].input3Dy' % (sNode, i))
            _connectOrSet(xInput[2], '%s.input3D[%d].input3Dz' % (sNode, i))
        else:
            _connectOrSetVector(xInput, '%s.input3D[%d]' % (sNode,i), sSeparateItems=['input3Dx[%d]' % i, 'input3Dy[%d]' % i, 'input3Dz[%d]' % i])

    if sOperation != 'plus':
        iOperation = ['noOperation','plus', 'minus', 'average'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)

    sOutput = '%s.output3D' % sNode
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput



def createAdditionNode(xInputs, sTarget=None, sName='noname', sOperation='plus'):

    if not isinstance(xInputs, (list,tuple)):
        raise Exception('input needs to be a list')

    sNode = cmds.createNode('plusMinusAverage', name='plusMinusAverage_%s' % sName)
    for i, xInput in enumerate(xInputs):
        _connectOrSet(xInput, '%s.input1D[%d]' % (sNode,i))

    if sOperation != 'plus':
        iOperation = ['noOperation','plus', 'minus', 'average'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)

    sOutput = '%s.output1D' % sNode
    if sTarget:
        if isinstance(sTarget, (list, tuple)):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT)
        else:
            cmds.connectAttr(sOutput, sTarget)

        # _connectOrSet(sOutput, sTarget)
    return sOutput


def createAngleNode(xInputA, xInputB, sTarget=None, sName='noname'):
    sNode = cmds.createNode('angleBetween', name='angleBetween_%s' % sName)
    _connectOrSetVector(xInputA, '%s.vector1' % sNode, sSeparateItems=['vector1X', 'vector1Y', 'vector1Z'])
    _connectOrSetVector(xInputB, '%s.vector2' % sNode, sSeparateItems=['vector2X', 'vector2Y', 'vector2Z'])
    sOutput = '%s.angle' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sOutput



def createDecomposeMatrix(xInputMatrix, sTargetPos=None, sTargetRot=None, sTargetScale=None, bConnectRotateOrder=False, sName='noname', sFullName=None, bReturnRotate=False, bJustValues=False):
    if not sFullName:
        sFullName = 'decomposeMatrix_%s' % sName

    sNode = cmds.createNode('decomposeMatrix', name=sFullName)
    _connectOrSetMatrix(xInputMatrix, '%s.inputMatrix' % sNode)
    sOutputPos = '%s.outputTranslate' % sNode
    sOutputRot = '%s.outputRotate' % sNode
    sOutputScale = '%s.outputScale' % sNode
    if sTargetPos:
        cmds.connectAttr(sOutputPos, sTargetPos)
    if sTargetRot:
        cmds.connectAttr(sOutputRot, sTargetRot)
        if bConnectRotateOrder:
            cmds.setAttr('%s.inputRotateOrder' % sNode, cmds.getAttr('%s.rotateOrder' % sTargetRot.split('.')[0]))

    if sTargetScale:
        cmds.connectAttr(sOutputScale, sTargetScale)

    sOutput = sOutputRot if bReturnRotate else sOutputPos

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)
        cmds.delete(sNode)
        return fOutput
    else:
        return sOutput


def createDistanceNode(xInputA, xInputB, sTarget=None, sName='noname', fNormalized=None, sDivide=None):
    sNode = cmds.createNode('distanceBetween', name='distanceBetween_%s' % sName)

    if not isinstance(xInputA, (list, tuple)) and '.' not in xInputA:
        xInputA = createDecomposeMatrix('%s.worldMatrix' % xInputA, sName=sName)
    if not isinstance(xInputB, (list, tuple)) and '.' not in xInputB:
        xInputB = createDecomposeMatrix('%s.worldMatrix' % xInputB, sName=sName)

    _connectOrSetVector(xInputA, '%s.point1' % sNode, sSeparateItems=['point1X ', 'point1Y ', 'point1Z'])
    _connectOrSetVector(xInputB, '%s.point2' % sNode, sSeparateItems=['point2X ', 'point2Y ', 'point2Z'])
    sOutput = '%s.distance' % sNode

    if sDivide != None:
        sOutput = createMultiplyNode(sOutput, sDivide, sOperation='divide', sName='%sDivide' % sName)

    if fNormalized != None:
        sOutput = createMultiplyNode(sOutput, fNormalized / cmds.getAttr(sOutput), sName='%sNormalize' % sName)

    if sTarget:
        [cmds.connectAttr(sOutput, sT) for sT in toList(sTarget)]

    return sOutput



def toList(item):
    if isinstance(item, (list,tuple)):
        return item
    elif isinstance(item, dict):
        return list(item.keys())
    else:
        return [item]


def listToString(sList, sSeparator=', ', iMaxCount=None):
    if iMaxCount and len(sList) > iMaxCount:
        iMore = len(sList) - iMaxCount
        return '%s, and %d more' % (sSeparator.join(sList[:iMaxCount]), iMore)
    else:
        return sSeparator.join(sList)


def createMultiplyNode(xInputA, xInputB, sTarget=None, sOperation='multiply', sName='noname', sFullName=None):
    if sFullName == None:
        sFullName = 'MULT_%s' % sName

    sNode = cmds.createNode('multiplyDivide', name=sFullName)

    _connectOrSet(xInputA, '%s.input1X' % sNode)
    _connectOrSet(xInputB, '%s.input2X' % sNode)

    if sOperation != 'multiply':
        iOperation = ['noOperation', 'multiply', 'divide', 'square'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)
    sOutput = '%s.outputX' % sNode
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput


def translateSideName(sFullCtrl, bErrorIfNotExist=True):
    sNamespace = getNamespace(sFullCtrl)
    if cmds.objExists(sFullCtrl):
        return sFullCtrl
    else:
        sCtrl = sFullCtrl.split(':')[-1]

        if 'LFT' in sCtrl:
            sOtherCtrl = sCtrl.replace('LFT', '_l')
            if cmds.objExists('%s%s' % (sNamespace,sOtherCtrl)):
                return '%s%s' % (sNamespace, sOtherCtrl)
            else:
                if bErrorIfNotExist:
                    raise Exception('Controls "%s" and "%s%s" don\'t exist' % (sFullCtrl, sNamespace, sOtherCtrl))
                else:
                    return None
        elif 'RGT' in sCtrl:
            sOtherCtrl = sCtrl.replace('RGT', '_r')
            if cmds.objExists('%s%s' % (sNamespace,sOtherCtrl)):
                return '%s%s' % (sNamespace, sOtherCtrl)
            else:
                if bErrorIfNotExist:
                    raise Exception('Controls "%s" and "%s%s" don\'t exist' % (sFullCtrl, sNamespace, sOtherCtrl))
                else:
                    return None
        elif '_l_' in sCtrl:
            sOtherCtrl = sCtrl.replace('_l_', 'LFT_')
            if cmds.objExists('%s%s' % (sNamespace,sOtherCtrl)):
                return '%s%s' % (sNamespace, sOtherCtrl)
            else:
                if bErrorIfNotExist:
                    raise Exception('Controls "%s" and "%s%s" don\'t exist' % (sFullCtrl, sNamespace, sOtherCtrl))
                else:
                    return None
        elif '_r_' in sCtrl:
            sOtherCtrl = sCtrl.replace('_r_', 'RGT_')
            if cmds.objExists('%s%s' % (sNamespace,sOtherCtrl)):
                return '%s%s' % (sNamespace, sOtherCtrl)
            else:
                if bErrorIfNotExist:
                    raise Exception('Controls "%s" and "%s%s" don\'t exist' % (sFullCtrl, sNamespace, sOtherCtrl))
                else:
                    return None
        else:
            if bErrorIfNotExist:
                raise Exception('Control "%s" doesn\'t exist' % sCtrl)
            else:
                return None


def createVectorMultiplyNode(xInputA, xInputB, bVectorByScalar=False, sTarget=None, sOperation='multiply', sName='noname'):
    sNode = cmds.createNode('multiplyDivide', name='MULT_%s' % sName)

    _connectOrSetVector(xInputA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])

    if bVectorByScalar:
        _connectOrSet(xInputB, '%s.input2X' % sNode)
        _connectOrSet(xInputB, '%s.input2Y' % sNode)
        _connectOrSet(xInputB, '%s.input2Z' % sNode)
    else:
        _connectOrSetVector(xInputB, '%s.input2' % sNode, ['input2X', 'input2Y', 'input2Z'])

    if sOperation != 'multiply':
        iOperation = ['noOperation', 'multiply', 'divide', 'square'].index(sOperation)
        cmds.setAttr('%s.operation' % sNode, iOperation)
    sOutput = '%s.output' % sNode
    #
    # if bOutputIsSum:
    #     sOutput = createAdditionNode(['%sX' % sOutput, '%sY' % sOutput, '%sZ' % sOutput], sName=sName)
    #
    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput


def _connectOrSetVector(xValue, sAttr, sSeparateItems=[], bForce=False):
    if sSeparateItems and isinstance(xValue, (list, tuple)):
        sNode = sAttr.split('.')[0]
        _connectOrSet(xValue[0], '%s.%s' % (sNode, sSeparateItems[0]), bForce=bForce)
        _connectOrSet(xValue[1], '%s.%s' % (sNode, sSeparateItems[1]), bForce=bForce)
        _connectOrSet(xValue[2], '%s.%s' % (sNode, sSeparateItems[2]), bForce=bForce)
    elif sSeparateItems and isinstance(xValue, OpenMaya2.MVector):
        sNode = sAttr.split('.')[0]
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[0]), xValue[0])
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[1]), xValue[1])
        cmds.setAttr('%s.%s' % (sNode, sSeparateItems[2]), xValue[2])
    else:
        try:
            cmds.setAttr(sAttr, *xValue) # it's a list of values
        except:
            cmds.connectAttr(xValue, sAttr, force=bForce) # it's a compound attribute to connect



def _connectOrSet(xValue, sAttr, bForce=False):
    if isinstance(xValue, (list, tuple)) and len(xValue) == 16:
        sHoldMatrix = cmds.createNode('holdMatrix')
        cmds.setAttr('%s.inMatrix' % sHoldMatrix, xValue, type='matrix')
        cmds.connectAttr('%s.outMatrix' % sHoldMatrix, sAttr)
    else:
        try:
            fValue = float(xValue)
        except:
            fValue = None

        if fValue != None:
            cmds.setAttr(sAttr, fValue)
        else:
            cmds.connectAttr(xValue, sAttr, f=bForce)



def _connectOrSetMatrix(xValue, sAttr, bForce=False):
    try:
        cmds.setAttr(sAttr, *xValue, type='matrix')
    except:
        cmds.connectAttr(xValue, sAttr, force=bForce)



def createMultMatrixNode(xInputMatrices, sTarget=None, sName='noname', sFullName=None, bJustValues=False):
    if not isinstance(xInputMatrices, (list, tuple)):
        raise Exception('He needs a LIST of matrices')

    if sFullName == None:
        sFullName = 'multiplyMatrix_%s' % sName

    sNode = cmds.createNode('multMatrix', name=sFullName)

    for i, xMatrix in enumerate(xInputMatrices):
        _connectOrSetMatrix(xMatrix, '%s.matrixIn[%d]' % (sNode, i))

    sOutput = '%s.matrixSum' % sNode

    if bJustValues:
        fOutput = cmds.getAttr(sOutput)
        cmds.delete(sNode)
        return fOutput

    if sTarget:
        _connectOrSetMatrix(sOutput, sTarget)
    return sOutput





def createChoiceNode(xSelector, xInputs, sTarget=None, sName='noname', sFullName=None, bForce=False):
    if sFullName == None:
        sFullName = 'CHOICE_%s' % sName

    sNode = cmds.createNode('choice', name=sFullName)
    _connectOrSet(xSelector, '%s.selector' % sNode)
    for i, xInput in enumerate(xInputs):
        _connectOrSet(xInput, '%s.input[%d]' % (sNode,i))
    sOutput = '%s.output' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget, f=bForce)
    return sOutput


def createComposeMatrixNode(xTranslate=None, xRotate=None, xQuat=None, xScale=None, sTarget=None, bForce=False, sName='noname'):
    sNode = cmds.createNode('composeMatrix', name='composeMatrix_%s' % sName)
    if xTranslate:
        _connectOrSetVector(xTranslate, '%s.inputTranslate' % sNode, ['inputTranslateX', 'inputTranslateY', 'inputTranslateZ'])
    if xRotate:
        _connectOrSetVector(xRotate, '%s.inputRotate' % sNode, ['inputRotateX', 'inputRotateY', 'inputRotateZ'])
    if xQuat:
        _connectOrSetVector(xQuat, '%s.inputQuat' % sNode)
    if xScale:
        _connectOrSetVector(xScale, '%s.inputScale' % sNode, ['inputScaleX', 'inputScaleY', 'inputScaleZ'])

    sOutput = '%s.outputMatrix' % sNode
    if sTarget:
        _connectOrSetMatrix(sOutput, sTarget, bForce=bForce)
    return sOutput



def createInverseMatrix(xInputMatrix, sTarget=None, sName='noname', sFullName=None):

    if isinstance(xInputMatrix, (str,unicode)) and xInputMatrix.endswith('.worldMatrix'):
        return '%s.worldInverseMatrix' % xInputMatrix.split('.')[0]

    if not sFullName:
        sFullName = 'inverseMatrix_%s' % sName
    sNode = cmds.createNode('inverseMatrix', name=sFullName)
    _connectOrSetMatrix(xInputMatrix, '%s.inputMatrix' % sNode)
    sOutput = '%s.outputMatrix' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sOutput




def createDotProductNode(xVectorA, xVectorB, sTarget=None, sName='noname'):
    sNode = cmds.createNode('vectorProduct', name='dotProduct_%s' % sName)
    _connectOrSetVector(xVectorA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])
    _connectOrSetVector(xVectorB, '%s.input2' % sNode, ['input2X', 'input2Y', 'input2Z'])
    cmds.setAttr('%s.operation' % sNode, 1)

    sOutput = '%s.outputX' % sNode
    if sTarget:
        _connectOrSet(sOutput, sTarget)
    return sOutput


def createNormalizedVector(xInputA, bSafe=False, bReturnDistance=False, sTarget=None, sName='noname'):
    sNode = cmds.createNode('multiplyDivide', name='normalize_%s' % sName)

    _connectOrSetVector(xInputA, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])
    sActualDistance = createDistanceNode(xInputA,[0,0,0], sName='normalize_%s' % sName)
    if bSafe:
        sDistance = createConditionNode(sActualDistance, '<', 0.001, 1.0, sActualDistance, sName='normalize_%s' % sName)
    else:
        sDistance = sActualDistance

    cmds.connectAttr(sDistance, '%s.input2X' % sNode)
    cmds.connectAttr(sDistance, '%s.input2Y' % sNode)
    cmds.connectAttr(sDistance, '%s.input2Z' % sNode)
    cmds.setAttr('%s.operation' % sNode, 2) # divide

    sOutput = '%s.output' % sNode

    if sTarget:
        _connectOrSetVector(sOutput, sTarget)

    if bReturnDistance:
        return sOutput, sActualDistance
    else:
        return sOutput



def createConditionNode(xFirstTerm, sOperator, xSecondTerm, xOutputTrue, xOutputFalse, sName='noname', sFullName=None,
                        bVector=False, sTarget=None, bForce=False):
    if sFullName == None:
        sFullName = 'condition_%s' % sName

    try:
        iOperation = ['==', '!=', '>', '>=', '<', '<='].index(sOperator)
    except:
        raise Exception('don\'t know what operator %s is' % sOperator)

    sNode = cmds.createNode('condition', name=sFullName)
    _connectOrSet(xFirstTerm, '%s.firstTerm' % sNode)
    _connectOrSet(xSecondTerm, '%s.secondTerm' % sNode)
    cmds.setAttr('%s.operation' % sNode, iOperation)

    if bVector:
        _connectOrSetVector(xOutputTrue, '%s.colorIfTrue' % sNode)
        _connectOrSetVector(xOutputFalse, '%s.colorIfFalse' % sNode)
        sOutput = '%s.outColor' % sNode
        if sTarget:
            _connectOrSetVector(sOutput, sTarget, bForce=bForce)
        return sOutput
    else:
        _connectOrSet(xOutputTrue, '%s.colorIfTrueR' % sNode)
        _connectOrSet(xOutputFalse, '%s.colorIfFalseR' % sNode)
        sOutput = '%s.outColorR' % sNode
        if sTarget:
            _connectTargetIfNotNone(sTarget, sOutput, bForce=bForce)
        return sOutput


def _connectTargetIfNotNone(sTarget, sOutput, bForce=False):
    if sTarget:
        if isinstance(sTarget, list):
            for sT in sTarget:
                cmds.connectAttr(sOutput, sT)
        else:
            cmds.connectAttr(sOutput, sTarget, force=bForce)



def getWorldPoint(sTransform):
    sLocators = cmds.listRelatives(sTransform, typ='locator')
    if sLocators:
        return '%s.worldPosition' % sLocators[0]
    else:
        return createDecomposeMatrix('%s.worldMatrix' % sTransform)



def createPointByMatrixNode(xVector, xMatrix, sTarget=None, sName='noname', sFullName=None, bJustValues=False):
    if sFullName == None:
        sFullName = 'vectorMatrixProduct_%s' % sName
    sNode = cmds.createNode('vectorProduct', name=sFullName)
    _connectOrSetVector(xVector, '%s.input1' % sNode, ['input1X', 'input1Y', 'input1Z'])
    _connectOrSetMatrix(xMatrix, '%s.matrix' % sNode)
    cmds.setAttr('%s.operation' % sNode, 4)

    sOutput = '%s.output' % sNode

    if bJustValues:
        fOut = cmds.getAttr(sOutput)[0]
        cmds.delete(sNode)
        return fOut

    if sTarget:
        _connectOrSetVector(sOutput, sTarget)
    return sOutput




def createAngleNode(xInputA, xInputB, sTarget=None, sName='noname'):
    sNode = cmds.createNode('angleBetween', name='angleBetween_%s' % sName)
    _connectOrSetVector(xInputA, '%s.vector1' % sNode, sSeparateItems=['vector1X', 'vector1Y', 'vector1Z'])
    _connectOrSetVector(xInputB, '%s.vector2' % sNode, sSeparateItems=['vector2X', 'vector2Y', 'vector2Z'])
    sOutput = '%s.angle' % sNode
    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sOutput




def createRangeNode(xValue, xInMin, xInMax, xOutMin, xOutMax, sName='noname', sTarget=None, bOutRangeIsVector=False, bInfinity=False):

    try: fInMin = cmds.getAttr(xInMin)
    except: fInMin = float(xInMin)
    try: fInMax = cmds.getAttr(xInMax)
    except: fInMax = float(xInMax)

    if fInMin > fInMax:
        xInMin, xInMax = xInMax, xInMin
        xOutMin, xOutMax = xOutMax, xOutMin

    if not bInfinity:
        sNode = cmds.createNode('setRange', name='range_%s' % sName)

        if bOutRangeIsVector:
            for sA in ['X','Y','Z']:
                _connectOrSet(xValue, '%s.value%s' % (sNode,sA))
                _connectOrSet(xInMin, '%s.oldMin%s' % (sNode,sA))
                _connectOrSet(xInMax, '%s.oldMax%s' % (sNode,sA))
            _connectOrSetVector(xOutMin, '%s.min' % sNode)
            _connectOrSetVector(xOutMax, '%s.max' % sNode)
            sOutput = '%s.outValue' % sNode
        else:
            _connectOrSet(xValue, '%s.valueX' % sNode)
            _connectOrSet(xInMin, '%s.oldMinX' % sNode)
            _connectOrSet(xInMax, '%s.oldMaxX' % sNode)
            _connectOrSet(xOutMin, '%s.minX' % sNode)
            _connectOrSet(xOutMax, '%s.maxX' % sNode)
            sOutput = '%s.outValueX' % sNode
    else:
        if bOutRangeIsVector:
            raise Exception('bOutRangeIsVector with bInfinity is not supported yet')
        sName = '%sRange' % sName
        sT = fromEquation('(%s-%s) / (%s-%s)' % (xValue, xInMin, xInMax, xInMin), sName=sName)
        sOutput = fromEquation('%s*%s + %s*(1.0-%s)' % (xOutMax, sT, xOutMin, sT), sName=sName)

    _connectTargetIfNotNone(sTarget, sOutput)
    return sOutput



def fromEquation(sEquation, sTarget=None, sName='noName', sFullName=None, bDoUnitConversionNodes=False):
    if sFullName == None:
        sMultiplName = 'multiplyDivide_%s_000' % sName
        sPlusName = 'plusMinusAverage_%s_000' % sName
        sConvName = 'conversion_%s_000' % sName
    else:
        sMultiplName = sFullName
        sPlusName = sFullName
        sConvName = sFullName

    # print 'sEquation: ', sEquation
    def createNodes(sEqu):
        sSplits = re.split('\/-|\*-|\*|\/|\+|\-|\^', sEqu)
        # print sEqu, '->', sSplits

        # first clean up minus signs, if the first one is '', then it should be a minus
        #
        if sSplits[0] == '':
            if sEqu[0] == '-':
                try:
                    float(sSplits[1])
                    sSplits[1] = '-%s' % sSplits[1]
                    del sSplits[0]
                except:
                    sSplits[0] = '-1'
                    sEqu = '-1*%s' % sEqu[1:]

        # still on minus signs, if  iPos is -, then it's a combination with * or /
        #
        iPos = 0
        i = 0
        while i < len(sSplits):
            if iPos != 0 and sEqu[iPos] == '-':
                try:
                    float(sSplits[i])
                    sSplits[i] = '-%s' % sSplits[i]
                except:
                    sSplits.insert(i, '-1')
                    sEqu = '%s%s%s' % (sEqu[:iPos + 1], '1*', sEqu[iPos + 1:])

            iPos += len(sSplits[i])
            iPos += 1
            i += 1

        # now go through all the splits, and either multiply or add them
        #
        i = 0
        iPos = -1
        sOperator = '.'
        sPrevAttr = None
        sAdditions = []
        sAdditionOperators = []
        while i < len(sSplits):
            sAttr = sSplits[i]

            if sOperator == '.':
                sPrevAttr = sAttr
            else:
                fConversionFactor = None
                if sOperator in '+-':
                    sAdditions.append(sPrevAttr if sPrevAttr != None else sSplits[i - 1])
                    sAdditionOperators.append(sOperator)
                    sOperator = '.'
                    sPrevAttr = None
                    continue
                elif sOperator == '*':
                    if bDoUnitConversionNodes:
                        try:
                            fConversionFactor = float(sAttr)
                        except:
                            pass
                        if fConversionFactor != None:
                            sConv = cmds.createNode('unitConversion', name=sConvName)
                            _connectOrSet(sPrevAttr, '%s.input' % sConv)
                            cmds.setAttr('%s.conversionFactor' % sConv,
                                         fConversionFactor)  # can only be set and not connected
                            sPrevAttr = '%s.output' % sConv

                if fConversionFactor == None and sOperator in '*/^':
                    sMultipl = cmds.shadingNode('multiplyDivide', asUtility=True, name=sMultiplName)
                    _connectOrSet(sPrevAttr, '%s.input1X' % sMultipl)
                    _connectOrSet(sAttr, '%s.input2X' % sMultipl)
                    if sOperator == '/':
                        cmds.setAttr('%s.operation' % sMultipl, 2)
                    elif sOperator == '^':
                        cmds.setAttr('%s.operation' % sMultipl, 3)
                    sPrevAttr = '%s.outputX' % sMultipl

            iPos += len(sSplits[i]) + 1
            if iPos < len(sEqu):
                sOperator = sEqu[iPos]
                i += 1
            else:
                sAdditions.append(sAttr if sPrevAttr == None else sPrevAttr)
                break

        # we collected additions and additionsOperators before, now let's add them together
        #
        if len(sAdditions) == 1:
            return sAdditions[0]
        else:
            sPlusMinus = cmds.createNode('plusMinusAverage', name=sPlusName)
            # first check if we need to make minus or plus
            bMinus, bPlus = False, False
            for sOp in sAdditionOperators:
                if sOp == '+':
                    bPlus = True
                elif sOp == '-':
                    bMinus = True
            if bMinus:
                if not bPlus:
                    cmds.setAttr('%s.operation' % sPlusMinus, 2)
                elif bPlus:  # if we have mixed minus and plus, we'll have to multiply the minus ones by -1
                    for i in range(len(sAdditionOperators)):
                        if sAdditionOperators[i] == '-':
                            try:
                                sAdditions[i + 1] = -float(sAdditions[i + 1])
                            except:
                                sAdditions[i + 1] = createNodes('-1*%s' % sAdditions[i + 1])
            # finally connect the parts to the plus node
            for i, sAddition in enumerate(sAdditions):
                _connectOrSet(sAddition, '%s.input1D[%d]' % (sPlusMinus, i))
            sOutput = '%s.output1D' % sPlusMinus
            return sOutput

    def traverseParenthesis(sEqu, sSplits):
        sEquNew = ''
        i = 0
        iPos = 0
        while True:
            if sSplits[i]:
                sEquNew += sSplits[i]
            iPos += len(sSplits[i])
            if iPos >= len(sEqu):
                break
            iP = sEqu[iPos]
            iPos += 1
            i += 1
            if iP == '(':
                sNewOutput, i2, iPos2 = traverseParenthesis(sEqu[iPos:], sSplits[i:])
                i += i2
                iPos += iPos2
                sEquNew += sNewOutput
            elif iP == ')':
                sOutput = createNodes(sEquNew)
                return sOutput, i, iPos

        sLastPart = createNodes(sEquNew)
        return sLastPart

    sEquationStripped = sEquation.replace(' ', '')
    sEquationStripped = sEquationStripped.replace('+-', '-').replace('--', '+').replace('*+', '*')

    # print 'sEquationStripped: ', sEquationStripped

    sSplits = re.split('\(|\)', sEquationStripped)
    sRet = traverseParenthesis(sEquationStripped, sSplits)

    if sTarget:
        if isinstance(sTarget, (list, tuple)):
            for sT in sTarget:
                cmds.connectAttr(sRet, sT)
        else:
            cmds.connectAttr(sRet, sTarget)

    return sRet

def _stringTimeToFloat(sTime):
    fSplits = [float(sS) for sS in sTime.split(':')]
    return fSplits[-1] + fSplits[-2]*60.0 + fSplits[-3]*60*60 + fSplits[-4]*60*60*60



def readCsvFile(sFile):

    xxData = []
    sKeys = []

    with open(sFile) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for r,row in enumerate(csv_reader):
            # print 'row: ', row
            if line_count == 0:
                sKeys = list(row)
                xxData = [[] for i in range(len(sKeys))]
            else:
                for i, item in enumerate(row):
                    xxData[i].append(item)
            line_count += 1

    dData = OrderedDict()
    for k,sK in enumerate(sKeys):
        if k >= 2:
            dData[sK] = [float(fV) for fV in xxData[k]]

    return dData



def getFrameRate():
    sQueried = cmds.currentUnit(q=True, t=True)
    dFrameRates = {'game': 15, 'film': 24, 'pal': 25, 'ntsc': 30, 'show': 48, 'palf': 50, 'ntscf': 60}

    if sQueried in dFrameRates:
        fFramesPerSecond = float(dFrameRates[sQueried])
    elif sQueried.endswith('fps'):
        sFramesPerSecond = sQueried[:-3]
        fFramesPerSecond = float(sFramesPerSecond)
    else:
        raise Exception('unrecognized frame rate: %s' % sQueried)

    fFrameLength = 1.0 / fFramesPerSecond
    return fFramesPerSecond, fFrameLength


def getJsonContent(sFile):
    with open(sFile) as file:
        xContent = json.load(file)
    return xContent


def setJsonContent(sFile, dContent):
    with open(sFile, 'w') as outfile:
        json.dump(dContent, outfile, indent=2)



def getNamespace(sObj):
    sSplits = sObj.split('.')[0].split(':')
    if len(sSplits) <= 1:
        return ''
    else:
        return '%s:' % ':'.join(sSplits[:-1])



def deleteAnimation(sAttr):
    sConnections = [sN for sN in cmds.listConnections(sAttr, s=True, d=False) or [] if
                    cmds.objectType(sN).startswith('animCurve')]
    if sConnections:
        cmds.delete(sConnections)



def createMotionPath(sCurve, fU=0, bLengthPerc=False, sName='noname', sTargetTransform=None, sTarget=None, sFullName=None):
    if sFullName == None:
        sFullName = 'motionPath_%s' % sName
    sMotionPath = cmds.createNode('motionPath', n=sFullName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.geometryPath' % sMotionPath)
    cmds.setAttr('%s.frontAxis' % sMotionPath, 0)
    cmds.setAttr('%s.upAxis' % sMotionPath, 2)
    _connectOrSet(fU, '%s.uValue' % sMotionPath)
    if bLengthPerc:
        cmds.setAttr('%s.fractionMode' % sMotionPath, True)

    sOutput = '%s.allCoordinates' % sMotionPath

    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    if sTargetTransform:
        cmds.connectAttr(sOutput, '%s.t' % sTargetTransform)
        cmds.connectAttr('%s.r' % sMotionPath, '%s.r' % sTargetTransform)

    return sMotionPath, sOutput



def getNumberAtEnd(sName, iDefault=0):
    m = re.search(r'\d+$', sName)
    if m:
        sNumber = m.group()
        return sName[:-len(sNumber)], int(sNumber)
    else:
        return sName, iDefault



def getUniqueName(sName, bRemoveIllegalCharacters=True):

    if bRemoveIllegalCharacters:
        sName = sName.replace("'", "")

    if not cmds.objExists(sName):
        return sName

    sName, iNumber = getNumberAtEnd(sName)
    while True:
        iNumber += 1
        sNewName = '%s%d' % (sName, iNumber)
        if not cmds.objExists(sNewName):
            return sNewName



def insertParent(sNode, sName, bMatchParentTransform=False, sType='transform'):
    sName = getUniqueName(sName)

    sOldParent = cmds.listRelatives(sNode, p=True)
    sParent = cmds.createNode(sType, name=sName)
    if sOldParent:
        cmds.parent(sParent, sOldParent[0])
    # else:
    if bMatchParentTransform and sOldParent:
        fValuesBefore = []
        for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
            fValuesBefore.append(cmds.getAttr('%s.%s' % (sNode,sA)))
        fMatrix = cmds.xform(sOldParent, q=True, ws=True, m=True)
        cmds.xform(sParent, m=fMatrix, ws=True)
    else:
        fMatrix = cmds.xform(sNode, q=True, ws=True, m=True)
        cmds.xform(sParent, m=fMatrix, ws=True)

    cmds.parent(sNode, sParent)

    # if it's getting matched to the parent, the node shouldn't have any different values than before.
    # but because of some maya bug, sometimes it has different values
    if bMatchParentTransform and sOldParent:
        for sA, fV in zip(['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz'], fValuesBefore):
            try:
                cmds.setAttr('%s.%s' % (sNode,sA), fV)
            except:
                pass
    return sParent




def createCurveLengthNode(sCurve, sTarget=None, sName='noname'):
    sInfoNode = cmds.createNode('curveInfo', name=sName)
    cmds.connectAttr('%s.worldSpace[0]' % sCurve, '%s.inputCurve' % sInfoNode)
    sOutput = '%s.arcLength' % sInfoNode

    if sTarget:
        cmds.connectAttr(sOutput, sTarget)
    return sOutput



def constraintBlend(sTransform, sTargetA, sTargetB, sCtrl, sAttr, func=cmds.parentConstraint, fDefault=0.0, bMaintainOffset=False, kwargs={}):
    '''
    if blend value is 0, it's targetA. If it's 1, it's targetB
    '''

    if '.' in sAttr:
        sBlendAttr = sAttr
    else:
        sBlendAttr = '%s.%s' % (sCtrl, sAttr)

    if isinstance(sTransform, (list,tuple)):
        raise Exception('sTransform needs to be simple string, not list: %s' % sTransform)


    if isinstance(sTargetA, (list,tuple)):
        raise Exception('targetA needs to be simple string, not list: %s' % sTargetA)

    if isinstance(sTargetB, (list,tuple)):
        raise Exception('targetB needs to be simple string, not list: %s' % sTargetB)


    if not cmds.objExists(sBlendAttr):
        sC, sA = sBlendAttr.split('.')
        addAttr(sC, ln=sA, at='double', defaultValue=fDefault, minValue=0.0, maxValue=1.0, k=True)

    sReverse = createReverseNode(sBlendAttr, sName='blendConstraint_%s' % sCtrl)

    sConstr = func(sTargetA, sTargetB, sTransform, mo=bMaintainOffset, **kwargs)[0]
    if func in [cmds.parentConstraint, cmds.orientConstraint]:
        cmds.setAttr('%s.interpType' % sConstr, 2)

    cmds.connectAttr(sBlendAttr, '%s.%sW1' % (sConstr, sTargetB.split(':')[-1]))
    cmds.connectAttr(sReverse, '%s.%sW0' % (sConstr, sTargetA.split(':')[-1]))

    return sBlendAttr




def distanceBetweenObjects(sA, sB):
    fA = cmds.xform(sA, q=True, ws=True, t=True)
    fB = cmds.xform(sB, q=True, ws=True, t=True)

    fDiff = [fA[0] - fB[0], fA[1] - fB[1], fA[2] - fB[2]]
    sSum = fDiff[0] * fDiff[0] + fDiff[1] * fDiff[1] + fDiff[2] * fDiff[2]
    return math.sqrt(sSum)



def getTimeSliderRange():
    playback_slider = mel.eval('$tmpVar=$gPlayBackSlider')
    
    if cmds.timeControl(playback_slider, q=True, rangeVisible=True):
        return cmds.timeControl(playback_slider, q=True, rangeArray=True)
    else: # if nothing selected, we return the normal range
        return cmds.playbackOptions(q=True,minTime=True), cmds.playbackOptions(q=True,maxTime=True) + 1
    



def importMayaFiles(sFiles, sNamespace=None, bReference=False, _report=None, bReturnAllNodes=False):
    import kangarooTools.xforms as xforms

    sBefore = cmds.ls(dag=True)

    for sFile in toList(sFiles):
        if _report:
            _report.addLogText('importing file: %s' % sFile)
            _report.incrementProgress()

        if not os.path.isfile(sFile):
            cmds.warning('skipping file, because it doesn\'t exist: %s' % sFile)
            if _report: _report.addLogText('skipping, doesn\'t exist')
            continue

        if sFile.endswith('.mb'):
            sType = 'mayaBinary'
        elif sFile.endswith('.ma'):
            sType = 'mayaAscii'
        elif sFile.endswith('obj') or sFile.endswith('OBJ'):
            sType = 'OBJ'
        elif sFile.endswith('fbx') or sFile.endswith('FBX'):
            sType = 'FBX'
        elif sFile.endswith('abc'):
            sType = 'Alembic'
        else:
            raise Exception('unknown file ending: %s' % sFile)
        print('\n\n\nTYPE: ', sType)

        try:
            if sType == 'FBX':
                print('sFile: ', sFile)
                sPreviousBlendShapes = cmds.ls(et='blendShape')
                mel.eval('FBXImport -f "%s"' % sFile.replace('\\', '/'))
                sBlendShapes = set(cmds.ls(et='blendShape')) - set(sPreviousBlendShapes)
                for sBs in sBlendShapes:
                    sConns = cmds.listConnections('%s.inputTarget' % sBs, s=True, d=False)
                    if sConns: cmds.delete(sConns)
            else:
                if bReference:
                    if sNamespace:
                        cmds.file(sFile, r=True, type=sType, namespace=sNamespace, ignoreVersion=True, prompt=False)
                    else:
                        cmds.file(sFile, r=True, type=sType, ignoreVersion=True, prompt=False)
                else:
                    if sNamespace:
                        cmds.file(sFile, i=True, type=sType, namespace=sNamespace, ignoreVersion=True, prompt=False)
                    else:
                        cmds.file(sFile, i=True, type=sType, ignoreVersion=True, prompt=False)
        except Exception as e:
            cmds.warning('errors happened when importing: %s' % e)
    sAfter = cmds.ls(dag=True)
    sNewNodes = list(set(sAfter) - set(sBefore))

    if bReturnAllNodes:
        return sNewNodes
    else:
        return xforms.getRoots(sNewNodes)
