###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import maya.cmds as cmds
import maya.mel as mel
if cmds.about(v=True) >= '2025':
    from PySide6 import QtWidgets, QtGui, QtCore
else:
    from PySide2 import QtWidgets, QtGui, QtCore

from collections import OrderedDict, defaultdict
import subprocess
import os
import math
global mainWin
mainWin = None
import kangarooAnimation.library as library
import kangarooAnimation.humanIk as humanIk

class ValueType:
    code = 0


sAppleFaceBlendShapes = ['browDownLeft',  'browDownRight', 'browInnerUp', 'browOuterUpLeft', 'browOuterUpRight',
                         'cheekPuff', 'cheekSquintLeft', 'cheekSquintRight', 'eyeBlinkLeft', 'eyeBlinkRight',
                         'eyeLookDownLeft', 'eyeLookDownRight', 'eyeLookInLeft', 'eyeLookInRight', 'eyeLookOutLeft',
                         'eyeLookOutRight', 'eyeLookUpLeft', 'eyeLookUpRight', 'eyeSquintLeft', 'eyeSquintRight',
                         'eyeWideLeft', 'eyeWideRight', 'jawForward', 'jawLeft', 'jawOpen', 'jawRight', 'mouthClose',
                         'mouthDimpleLeft', 'mouthDimpleRight', 'mouthFrownLeft', 'mouthFrownRight', 'mouthFunnel',
                         'mouthLeft', 'mouthLowerDownLeft', 'mouthLowerDownRight', 'mouthPressLeft', 'mouthPressRight',
                         'mouthPucker', 'mouthRight', 'mouthRollLower', 'mouthRollUpper', 'mouthShrugLower',
                         'mouthShrugUpper', 'mouthSmileLeft', 'mouthSmileRight', 'mouthStretchLeft', 'mouthStretchRight',
                         'mouthUpperUpLeft', 'mouthUpperUpRight', 'noseSneerLeft', 'noseSneerRight']

# # we should be able to get rid of this
# def _translateGrpName(sName):
#     if cmds.objExists(sName):
#         return sName
#     else:
#         sSplits = sName.split(':')
#         if sSplits[-1].startswith('grp_'):
#             sSplits[-1] = '%s_Grp' % sSplits[-1][4:]
#             return ':'.join(sSplits)



# class Type():
#     pointConstraint = 0
#     orientConstraint = 1
#     parentConstraint = 2

# fMatchSetKey = None
# bMatchRecord = False
# ffMatchKeys = []
# iMatchKeysIndex = 0
# iMatchKeysT = 0


def _getShortsFromFeatureGrps(sFeatureGrps):
    sAllShorts = []
    for sG in sFeatureGrps:
        sSplitG = sG.split('_')
        sAllShorts.append(sSplitG[-2] if sSplitG[-1] == 'Grp' else sSplitG[-1])
    return sAllShorts


def getCurrentFeature(sNamespace, sSide, sLimb='arm'):
    sModuleGrp = '%sgrp_%s_%sModule' % (sNamespace, sSide, sLimb)
    # sModuleGrp = _translateGrpName(sModuleGrp)
    if not cmds.objExists(sModuleGrp):
        print('skipping switching %s, it doesn\'t exist' % sModuleGrp)
        return
    sFeatureGrps = [sG for sG in cmds.listRelatives(sModuleGrp, c=True, typ='transform') if cmds.attributeQuery('__featureSwitches__', node=sG, exists=True)]


    dSwitchAttrList = [eval(cmds.getAttr('%s.__featureSwitches__' % sGrp).replace('NAMESPACE', sNamespace)) for sGrp in sFeatureGrps]
    # sAllShorts = [sG.split('_')[-1] for sG in sFeatureGrps]
    sAllShorts = _getShortsFromFeatureGrps(sFeatureGrps)

    fDiffs = [0.0] * len(sAllShorts)
    for f, sF in enumerate(sAllShorts):
        dSwitchAttr = dSwitchAttrList[f]
        for sAttr, fValue in dSwitchAttr.items():
            fCurrentValue = cmds.getAttr(sAttr)
            fDiffs[f] += abs(fCurrentValue - fValue)

    sFromFeatureGrp = None
    sFromFeatureShort = None
    fSmallestDiff = -1.0
    for f,fDiff in enumerate(fDiffs):
        if sFromFeatureGrp == None or fDiff < fSmallestDiff:
            sFromFeatureGrp = sFeatureGrps[f]
            sFromFeatureShort = sAllShorts[f]
            fSmallestDiff = fDiff

    return sFromFeatureShort, sFromFeatureGrp




def doSwitchLimb(sNamespaces, sSides, sLimbs='arm', fSwitchValue=None, bAnim=False, bBaked=False):
    sNamespaces = library.toList(sNamespaces)
    sSides = library.toList(sSides)
    sLimbs = library.toList(sLimbs)
    
    iLimbsRange = list(range(len(sLimbs)))

    sSelBefore = cmds.ls(sl=True)
    sModuleGrps = ['%sgrp_%s_%sModule' % (sNamespace, sSide, sLimb) for sNamespace, sSide, sLimb in zip(sNamespaces, sSides, sLimbs)]
    
    sClassTypes = [cmds.getAttr('%s.sClassType' % sModuleG) for sModuleG in sModuleGrps]
    
    sFromFeatureShorts = []
    sFromFeatureGrps = []
    for x in iLimbsRange:
        _sFromFeatureShort, _sFromFeatureGrp = getCurrentFeature(sNamespaces[x], sSides[x], sLimbs[x])
        sFromFeatureShorts.append(_sFromFeatureShort)
        sFromFeatureGrps.append(_sFromFeatureGrp)

    # get the controls to detect keys
    ssCtrls = [cmds.getAttr('%s.__ctrls__' % sFromFeatureGrps[x]).split(',') for x in iLimbsRange]
    ssFullCtrls = [['%s%s' % (sNamespaces[x], sC) for sC in ssCtrls[x]] for x in iLimbsRange]


    ddOutputs = [eval(cmds.getAttr('%s.%s' % (sModuleG, '__outputs__'))) for sModuleG in sModuleGrps]

    
    sSwitchAttrs = [chooseExisting('%s%sGlobal_%s_ctrl.fk2ik' % (sNamespaces[x], sLimbs[x], sSides[x])) for x in iLimbsRange]
    
    if fSwitchValue != None:
        fSwitchValues = [fSwitchValue] * len(sLimbs)
    else:
        fSwitchValues = [round(1-cmds.getAttr(sSwitchAttrs[x])) for x in iLimbsRange]
    
    if bAnim:
        fMinTime, fMaxTime = library.getTimeSliderRange()
        if bBaked:
            fAllTimes = range(int(fMinTime), int(fMaxTime)+1, 1)
            ffLimbTimes = [fAllTimes] * len(sLimbs)
            dLimbsOnTimes = {fT:iLimbsRange for fT in fAllTimes}
        else:
            fAllTimes = []
            ffLimbTimes = []
            dLimbsOnTimes = defaultdict(list)
            for x in iLimbsRange:
                fTimes = []
                for sCtrl in ssFullCtrls[x]:
                    fTimes += [fT for fT in (cmds.keyframe(sCtrl, q=True) or []) if fT >= fMinTime and fT <= fMaxTime]
                fTimes = sorted(list(set(fTimes)))
                fAllTimes += fTimes
                ffLimbTimes.append(fTimes)
                for fT in fTimes:
                    dLimbsOnTimes[fT].append(x)
            fAllTimes = sorted(list(set(fAllTimes)))
            
            
    # bUndoBefore = cmds.undoInfo(q=True, st=True)
    cmds.undoInfo(openChunk=True)
    if bAnim:
        cmds.ogs(pause=True)
    try:
        ssTransformsToBake = [['%s%s' % (sNamespaces[x], sJ) for sJ in list(ddOutputs[x].values())] for x in iLimbsRange]
        ssNamesForBaking = [list(ddOutputs[x].keys()) for x in iLimbsRange]
        for x in iLimbsRange:
            if sClassTypes[x] in ['LArmLeg', 'LDogArmLeg', 'LHorseArmLeg', 'LBirdLeg'] and fSwitchValues[x] == 1.0:  # to ik
                sIkCtrl = chooseExisting('%s%sIk_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                sOffsetTo = '%s%s' % (sNamespaces[x], cmds.getAttr('%s.sOffsetTo' % sIkCtrl))
                ssTransformsToBake[x].extend([sIkCtrl, sOffsetTo])
                ssNamesForBaking[x].extend(['ikCtrl', 'ikCtrlOffset'])

        sExtraTransforms = []
        ssTempTransforms = [createSimpleTransforms(sNamespaces[x], ssTransformsToBake[x], ssNamesForBaking[x], bKeepConstraints=bAnim) for x in iLimbsRange]
        fffTransformValues = [[] for _ in iLimbsRange]
        if bAnim:
            for t,fT in enumerate(fAllTimes):
                cmds.currentTime(fT)
                for x in dLimbsOnTimes[fT]:
                    fffTransformValues[x].append([(cmds.getAttr('%s.t' % sT)[0], cmds.getAttr('%s.r' % sT)[0], cmds.getAttr('%s.s' % sT)[0]) for sT in ssTempTransforms[x]])
            for x in iLimbsRange:
                for tt,sT in enumerate(ssTempTransforms[x]):
                    sParentConstraints = cmds.listConnections(sT, s=True, d=False, t='parentConstraint')
                    sScaleConstraints = cmds.listConnections(sT, s=True, d=False, t='scaleConstraint')
                    cmds.delete(sParentConstraints + sScaleConstraints)
                    for t,fT in enumerate(ffLimbTimes[x]):
                        cmds.setKeyframe('%s.tx' % sT, t=fT, v=fffTransformValues[x][t][tt][0][0])
                        cmds.setKeyframe('%s.ty' % sT, t=fT, v=fffTransformValues[x][t][tt][0][1])
                        cmds.setKeyframe('%s.tz' % sT, t=fT, v=fffTransformValues[x][t][tt][0][2])
                        cmds.setKeyframe('%s.rx' % sT, t=fT, v=fffTransformValues[x][t][tt][1][0])
                        cmds.setKeyframe('%s.ry' % sT, t=fT, v=fffTransformValues[x][t][tt][1][1])
                        cmds.setKeyframe('%s.rz' % sT, t=fT, v=fffTransformValues[x][t][tt][1][2])
                        cmds.setKeyframe('%s.sx' % sT, t=fT, v=fffTransformValues[x][t][tt][2][0])
                        cmds.setKeyframe('%s.sy' % sT, t=fT, v=fffTransformValues[x][t][tt][2][1])
                        cmds.setKeyframe('%s.sz' % sT, t=fT, v=fffTransformValues[x][t][tt][2][2])

        # first switch to mode
        [cmds.setAttr(sSwitchAttrs[x], fSwitchValues[x]) for x in iLimbsRange]

        xxResults = [[] for _ in iLimbsRange]
        for x in iLimbsRange:
            if sClassTypes[x] in ['LArmLeg', 'LDogArmLeg', 'LHorseArmLeg', 'LBirdLeg']:
                if fSwitchValues[x] == 0.0: # to fk
                    sUpperPasser = '%sgrp_%s_%sUpperPasser' % (sNamespaces[x], sSides[x], sLimbs[x])
                    sUpperCtrl = chooseExisting('%s%sUpper_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    sLowerCtrl = chooseExisting('%s%sElbow_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]), '%s%sKnee_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    sUpperChildCtrl = chooseExisting('%s%sUpperChild_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    sLowerChildCtrl = chooseExisting('%s%sElbowChild_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]), '%s%sKneeChild_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    sWristCtrl = chooseExisting('%s%sWrist_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]), '%s%sAnkle_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    cmds.setAttr('%s.ro' % sUpperChildCtrl, cmds.getAttr('%s.ro' % sUpperCtrl))
                    cmds.setAttr('%s.ro' % sLowerChildCtrl, cmds.getAttr('%s.ro' % sLowerCtrl))
                    xxResults[x].extend([_matchAttr('%s.%s' % (sUpperCtrl, sA), 0.0, bAnim) for sA in ['rx','ry','rz']])
                    xxResults[x].extend([_matchAttr('%s.%s' % (sLowerCtrl, sA), 0.0, bAnim) for sA in ['tx','ty','tz', 'rx','ry','rz']])

                    if sClassTypes[x] == 'LArmLeg':
                        sPoleVector = cmds.spaceLocator()[0]
                        sExtraTransforms.append(sPoleVector)
                        xxResults[x].append(_matchPoleVector(ssTempTransforms[x][0], ssTempTransforms[x][1], ssTempTransforms[x][2], sPoleVector, bAnim))
                        if bAnim:
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][0], sUpperChildCtrl, bAnim, sTransformAttrs=['tx','ty','tz']))
                            xxResults[x].append(_matchAimConstraint(ssTempTransforms[x][1], sPoleVector, sUpperChildCtrl, bAnim))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][1], sLowerChildCtrl, bAnim, sTransformAttrs=['tx','ty','tz']))
                            xxResults[x].append(_matchAimConstraint(ssTempTransforms[x][2], sPoleVector, sLowerChildCtrl, bAnim))
                        else:
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][0], sUpperCtrl, bAnim, sTransformAttrs=['tx','ty','tz']))
                            xxResults[x].append(_matchAimConstraint(ssTempTransforms[x][1], sPoleVector, sUpperCtrl, bAnim))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][1], sLowerCtrl, bAnim, sTransformAttrs=['tx','ty','tz']))
                            xxResults[x].append(_matchAimConstraint(ssTempTransforms[x][2], sPoleVector, sLowerCtrl, bAnim))

                    else:
                        if bAnim:
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][0], sUpperChildCtrl, bAnim))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][1], sLowerChildCtrl, bAnim))
                        else:
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][0], sUpperCtrl, bAnim))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][1], sLowerCtrl, bAnim))
                    
                    xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sWristCtrl, bAnim))
                    
                    if sClassTypes[x] in ['LArmLeg', 'LDogArmLeg', 'LHorseArmLeg']:
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][0], ssTempTransforms[x][1], sUpperCtrl, 'scaleY', sUpperPasser, bAnim))
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][1], ssTempTransforms[x][2], sLowerCtrl, 'scaleY', sUpperPasser, bAnim))
                        cmds.select(sUpperCtrl, sLowerCtrl)

                    if sClassTypes[x] in ['LArmLeg', 'LDogArmLeg', 'LBirdLeg']:
                        sFingerCtrl = chooseExisting('%s%sFingersFK_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]), '%s%sToesFK_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]),
                                                     '%s%sFingers_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]), '%s%sToes_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                        if sFingerCtrl:
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][3], sFingerCtrl, bAnim))
                    
                    if sClassTypes[x] in ['LDogArmLeg', 'LBirdLeg']:
                        sFingerMidCtrl = chooseExisting('%s%sFingersMid_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]), '%s%sToesMid_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                        xxResults[x].append(_matchSetSum(['%s.rz' % ssTempTransforms[x][4], cmds.getAttr('%s.fFingerMidDefaultAngle' % sFingerMidCtrl)],
                                                     '%s.rx' % sFingerMidCtrl, bAnim, sOperation='minus', bNegate=True))
    
                    if sClassTypes[x] == 'LHorseArmLeg':
                        for sLetter, iTransformIndex in zip(['A','B','C'], [3,4,5]):
                            sHorseFingerCtrl = chooseExisting('%s%sFingerFk%s_%s_ctrl' % (sNamespaces[x], sLimbs[x], sLetter, sSides[x]), '%s%sToeFk%s_%s_ctrl' % (sNamespaces[x], sLimbs[x], sLetter, sSides[x]))
                            
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][iTransformIndex], sHorseFingerCtrl, bAnim))

                    if sClassTypes[x] == 'LBirdLeg':
                        sBirdAnkleTweaker =  '%s%sAnkleTweaker_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x])
                        sBirdPoleTweaker =  '%s%sPoleTweaker_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x])
                        if cmds.objExists(sBirdAnkleTweaker):
                            cmds.setAttr('%s.r' % sBirdAnkleTweaker, 0,0,0)
                            cmds.setAttr('%s.t' % sBirdPoleTweaker, 0,0,0)


                elif fSwitchValues[x] == 1.0: # to ik
                    sIkPasser = '%sgrp_%s_%sIkPasser' % (sNamespaces[x], sSides[x], sLimbs[x])
                    sIkCtrl = chooseExisting('%s%sIk_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    sPoleCtrl = chooseExisting('%s%sPole_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                    sOffsetTo = '%s%s' % (sNamespaces[x], cmds.getAttr('%s.sOffsetTo' % sIkCtrl))

                    if sClassTypes[x] == 'LArmLeg':
                        xxResults[x].append(_matchConstraintSpecial(ssTempTransforms[x][3], ssTempTransforms[x][-2], ssTempTransforms[x][-1], sIkCtrl, sOffsetTo, bAnim))
                        xxResults[x].append(_matchAttr('%s.softIk' % sIkCtrl, 0.001, bAnim))
                        xxResults[x].append(_matchAttr('%s.toeBend' % sIkCtrl, 0.0, bAnim))
                        xxResults[x].append(_matchAttr('%s.fingerBend' % sIkCtrl, 0.0, bAnim))


                        for sA in ['rx', 'ry', 'rz']:
                            xxResults[x].append(_matchAttr('%s%sToesExtra_%s_ctrl.%s' % (sNamespaces[x], sLimbs[x], sSides[x], sA), 0.0, bAnim))
                            xxResults[x].append(_matchAttr('%s%sFingersExtra_%s_ctrl.%s' % (sNamespaces[x], sLimbs[x], sSides[x], sA), 0.0, bAnim))


                        xxResults[x].append(_matchAttr('%s.fingerBend' % sIkCtrl, 0.0, bAnim))

                        if cmds.attributeQuery('ballRoll', node=sIkCtrl, exists=True):
                            sDummyAnkle = '%s%s' % (sNamespaces[x], cmds.getAttr('%s.dummyAnkle' % sIkCtrl))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sDummyAnkle, bAnim, sTransformAttrs=['rx','ry','rz'],
                                                             sTransferAttrs=['%s.ball%s' % (sIkCtrl, sA) for sA in ['Roll', 'Twist', 'Side']]))
                        else:
                            sBallCtrl = chooseExisting('%s%sAnkleRev_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                            if sBallCtrl:
                                xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sBallCtrl, bAnim, sTransformAttrs=['rx','ry','rz']))

                        xxResults[x].append(_matchPoleVector(ssTempTransforms[x][0], ssTempTransforms[x][1], ssTempTransforms[x][2], sPoleCtrl, bAnim))
            
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][0], ssTempTransforms[x][1], sIkCtrl, 'upperScale', sIkPasser, bAnim))
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][1], ssTempTransforms[x][2], sIkCtrl, 'lowerScale', sIkPasser, bAnim))
                        
                    elif sClassTypes[x] == 'LDogArmLeg':
                        fDefaultAngle = cmds.getAttr('%s.fFingerMidDefaultAngle' % sIkCtrl)
                        xxResults[x].append(_matchAttr('%s.softIk' % sIkCtrl, 0.001, bAnim))
                        xxResults[x].append(_matchConstraintSpecial(ssTempTransforms[x][4], ssTempTransforms[x][-2], ssTempTransforms[x][-1], sIkCtrl, sOffsetTo, bAnim, sAttrSuffix='B'))
    
                        xxResults[x].append(_matchConstraintSpecialCondition(ssTempTransforms[x][3], ssTempTransforms[x][4], ['%s.rz' % ssTempTransforms[x][4], '>', fDefaultAngle],
                                                                         ssTempTransforms[x][-2], ssTempTransforms[x][-1], sIkCtrl, sOffsetTo, bAnim))
    
                        xxResults[x].append(_setValueOnCondition(['%s.rz' % ssTempTransforms[x][4], '>', fDefaultAngle], '%s.toeCurl' % sIkCtrl,
                                                                 [-fDefaultAngle, '%s.rz' % ssTempTransforms[x][4]], 0, False, bAnim))
                        xxResults[x].append(_setValueOnCondition(['%s.rz' % ssTempTransforms[x][4], '<=', fDefaultAngle], '%s.midFingerRoll' % sIkCtrl,
                                                                 [-fDefaultAngle, '%s.rz' % ssTempTransforms[x][4], '%s.footRoll' % sIkCtrl], 0, True, bAnim,
                                                                 xOnTrueAddOptions=[None, None, AddOptions.addPositive]))

                        if cmds.attributeQuery('ankleRoll', node=sIkCtrl, exists=True):
                            sDummyAnkle = '%s%s' % (sNamespaces[x], cmds.getAttr('%s.dummyAnkle' % sIkCtrl))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sDummyAnkle, bAnim, sTransformAttrs=['rx','ry','rz'],
                                                             sTransferAttrs=['%s.ankle%s' % (sIkCtrl, sA) for sA in ['Roll', 'Twist', 'Side']]))
                        else:
                            sAnkleCtrl = chooseExisting('%s%sAnkleRev_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                            if library.isNone(sAnkleCtrl):
                                sAnkleCtrl = chooseExisting('%s%sWristRev_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sAnkleCtrl, bAnim, sTransformAttrs=['rx','ry','rz']))

                        sOppositePoleAttr = '%s.bOppositePole' % sIkCtrl
                        bOppositePole = eval(sOppositePoleAttr) if cmds.objExists(sOppositePoleAttr) else False
                        xxResults[x].append(_matchPoleVector(ssTempTransforms[x][0], ssTempTransforms[x][1], ssTempTransforms[x][2], sPoleCtrl, bAnim,
                                                         bBackIsPositive=eval(cmds.getAttr('%s.bBackIsPositive' % sIkCtrl)),
                                                         bOpposite=bOppositePole))
    
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][0], ssTempTransforms[x][1], sIkCtrl, 'upperScale', sIkPasser, bAnim))
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][1], ssTempTransforms[x][2], sIkCtrl, 'lowerScale', sIkPasser, bAnim))
    
                    elif sClassTypes[x] == 'LBirdLeg':
                        sUpperIkCtrl = chooseExisting('%s%sUpperIk_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
    
                        fDefaultAngle = cmds.getAttr('%s.fFingerMidDefaultAngle' % sIkCtrl)
                        xxResults[x].append(_matchAttr('%s.softIk' % sIkCtrl, 0.001, bAnim))
                        # xxResults[x].append(_matchConstraintSpecial(ssTempTransforms[x][4], ssTempTransforms[x][-2], ssTempTransforms[x][-1], sIkCtrl, sOffsetTo, bAnim, sAttrSuffix='B'))
                        xxResults[x].append(_matchConstraintSpecialCondition(ssTempTransforms[x][3], ssTempTransforms[x][4], ['%s.rz' % ssTempTransforms[x][4], '>', fDefaultAngle],
                                                                         ssTempTransforms[x][-2], ssTempTransforms[x][-1], sIkCtrl, sOffsetTo, bAnim))
                        xxResults[x].append(_setValueOnCondition(['%s.rz' % ssTempTransforms[x][4], '>', fDefaultAngle], '%s.toeCurl' % sIkCtrl, [-fDefaultAngle, '%s.rz' % ssTempTransforms[x][4]], 0, False, bAnim))
                        xxResults[x].append(_setValueOnCondition(['%s.rz' % ssTempTransforms[x][4], '<=', fDefaultAngle], '%s.midFingerRoll' % sIkCtrl, [-fDefaultAngle, '%s.rz' % ssTempTransforms[x][4]], 0, True, bAnim))
    
                        xxResults[x].append(_matchPoleVector(ssTempTransforms[x][1], ssTempTransforms[x][2], ssTempTransforms[x][3], sPoleCtrl, bAnim,
                                                         bBackIsPositive=eval(cmds.getAttr('%s.bBackIsPositive' % sIkCtrl))))
    
                        xxResults[x].append(_matchConstraint(ssTempTransforms[x][0], sUpperIkCtrl, bAnim, sTransformAttrs=['rx','ry','rz']))
    
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][1], ssTempTransforms[x][2], sIkCtrl, 'upperScale', sIkPasser, bAnim))
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][2], ssTempTransforms[x][3], sIkCtrl, 'lowerScale', sIkPasser, bAnim))
                        
                    elif sClassTypes[x] == 'LHorseArmLeg':
                        sFkWrist = 'armWristIk_l_ctrl'
                        xxResults[x].append(_matchAttr('%s.softIk' % sIkCtrl, 0.001, bAnim))
                        xxResults[x].append(_matchAttr('%s.rx' % sFkWrist, 0.0, bAnim))
                        xxResults[x].append(_matchAttr('%s.ry' % sFkWrist, 0.0, bAnim))
                        xxResults[x].append(_matchAttr('%s.rz' % sFkWrist, 0.0, bAnim))
                        xxResults[x].append(_matchConstraintSpecial(ssTempTransforms[x][3], ssTempTransforms[x][-2], ssTempTransforms[x][-1], sIkCtrl, sOffsetTo, bAnim, sTransformAttrs=['tx','ty','tz', 'rx','ry','rz']))

                        if cmds.attributeQuery('ankleRoll', node=sIkCtrl, exists=True):
                            sDummyAnkle = '%s%s' % (sNamespaces[x], cmds.getAttr('%s.dummyAnkle' % sIkCtrl))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sDummyAnkle, bAnim, sTransformAttrs=['rx','ry','rz'],
                                                             sTransferAttrs=['%s.ankle%s' % (sIkCtrl, sA) for sA in ['Roll', 'Twist', 'Side']]))
                        else:
                            sAnkleCtrl = chooseExisting('%s%sAnkleRev_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                            if library.isNone(sAnkleCtrl):
                                sAnkleCtrl = chooseExisting('%s%sWristRev_%s_ctrl' % (sNamespaces[x], sLimbs[x], sSides[x]))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][2], sAnkleCtrl, bAnim, sTransformAttrs=['rx','ry','rz']))

                        xxResults[x].append(_matchPoleVector(ssTempTransforms[x][0], ssTempTransforms[x][1], ssTempTransforms[x][2], sPoleCtrl, bAnim,
                                                         bBackIsPositive=eval(cmds.getAttr('%s.bBackIsPositive' % sIkCtrl))))
    
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][0], ssTempTransforms[x][1], sIkCtrl, 'upperScale', sIkPasser, bAnim))
                        xxResults[x].append(_matchDistance(ssTempTransforms[x][1], ssTempTransforms[x][2], sIkCtrl, 'lowerScale', sIkPasser, bAnim))
    
                        for sLetter, iTransformIndex in zip(['A', 'B', 'C'], [3, 4, 5]):
                            sHorseFingerCtrl = chooseExisting('%s%sFinger%s_%s_ctrl' % (sNamespaces[x], sLimbs[x], sLetter, sSides[x]), '%s%sToe%s_%s_ctrl' % (sNamespaces[x], sLimbs[x], sLetter, sSides[x]))
                            xxResults[x].append(_matchConstraint(ssTempTransforms[x][iTransformIndex], sHorseFingerCtrl, bAnim))

        # stop here on debug (and comment the lines after finally):
        # xxxxxx
        if bAnim:
            ssBakeAttrs = [library.flattenedList([xR[1] for xR in xResults]) for xResults in xxResults]
            sDeleteNodes = library.flattenedList([[xR[0] for xR in xResults] for xResults in xxResults])
            sPrevConnections = library.flattenedList([[xR[2] for xR in xResults] for xResults in xxResults])

            fffValues = [[] for _ in iLimbsRange]
            for fT in fAllTimes:
                cmds.currentTime(fT)
                for x in dLimbsOnTimes[fT]:
                    fffValues[x].append([cmds.getAttr(sA) for sA in ssBakeAttrs[x]])

            cmds.delete(sDeleteNodes)

            for c in range(0,len(sPrevConnections),2):
                cmds.connectAttr(sPrevConnections[c+1], sPrevConnections[c])
                
            for x in iLimbsRange:
                for t,fT in enumerate(ffLimbTimes[x]):
                    for a,sA in enumerate(ssBakeAttrs[x]):
                        if 'Child' in sA:
                            cmds.setKeyframe(sA, t=fT, v=1.0 if 'SCALE' in sA.upper() else 0.0)
                            cmds.setKeyframe(sA.replace('Child', ''), t=fT, v=fffValues[x][t][a])
                        else:
                            cmds.setKeyframe(sA, t=fT, v=fffValues[x][t][a])


    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        if bAnim:
            cmds.ogs(pause=True)
        cmds.delete(library.flattenedList(ssTempTransforms))
        if sExtraTransforms:
            cmds.delete(sExtraTransforms)
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)



def chooseExisting(*sCtrls):
    for sCtrl in sCtrls:
        if cmds.objExists(sCtrl):
            return sCtrl
        if '_l_' in sCtrl:
            sOldNamedCtrl = sCtrl.replace('_l_', 'LFT_')
            if cmds.objExists(sOldNamedCtrl):
                return sOldNamedCtrl
        if '_r_' in sCtrl:
            sOldNamedCtrl = sCtrl.replace('_r_', 'RGT_')
            if cmds.objExists(sOldNamedCtrl):
                return sOldNamedCtrl
    return None







def _matchPoleVector(sPointA, sPointB, sPointC, sCtrl, bAnim, bBackIsPositive=False, bOpposite=False):
    if bAnim:
        sPrevConnections = []
        for sA in ['t','tx','ty','tz']:
            sConns = cmds.listConnections('%s.%s' % (sCtrl, sA), s=True, d=False, p=True, c=True)
            if sConns:
                sPrevConnections.append(sConns)
        for sConns in sPrevConnections:
            cmds.disconnectAttr(sConns[1], sConns[0])
    
        sPoleVectorNodes = poleVectorMath(sPointA, sPointB, sPointC, sCtrl, bAnim, bBackIsPositive=bBackIsPositive, bOpposite=bOpposite)
        
        return [sPoleVectorNodes,
                ['%s.%s' % (sCtrl, sA) for sA in ['tx','ty','tz']],
                sPrevConnections]
    else:
        poleVectorMath(sPointA, sPointB, sPointC, sCtrl, bAnim)



def poleVectorMath(sUpperObj, sLowerObj, sWristObj, sCtrl, bAnim, bBackIsPositive=False, bOpposite=False, bMocap=False):
    # import kangarooTools.nodes as nodes
    
    sNodesAttrsForDeletion = []
    sUpper = library.createDecomposeMatrix('%s.worldMatrix' % sUpperObj)
    sElbow = library.createDecomposeMatrix('%s.worldMatrix' % sLowerObj)
    sWrist = library.createDecomposeMatrix('%s.worldMatrix' % sWristObj)
    sUpperDistance = library.createDistanceNode(sUpper, sElbow)
    sDirection = library.createVectorAdditionNode([sWrist, sUpper], sOperation='minus', sName='direction')
    sDistance = library.createDistanceNode(sWrist, sUpper, sName='distance')
    sDirection = library.createVectorMultiplyNode(sDirection, sDistance, sOperation='divide',
                                                bVectorByScalar=True, sName='divideByDistance')
    sT = library.createDotProductNode(sDirection,
                                    library.createVectorAdditionNode([sElbow, sUpper], sOperation='minus'),
                                    sName='ttt')
    sPointOnLine = library.createVectorAdditionNode(
        [sUpper, library.createVectorMultiplyNode(sDirection, sT, bVectorByScalar=True)], sName='pointOnLine')
    sMoveOutLine = library.createVectorAdditionNode([sElbow, sPointOnLine], sOperation='minus',
                                                  sName='moveOutLine')
    sMoveOutLineNormalized = library.createNormalizedVector(sMoveOutLine, sName='normalizedMoveOutLine')

    if not bOpposite:
        sThreePointOut = library.createVectorAdditionNode([sPointOnLine, sMoveOutLine,
                                                   library.createVectorMultiplyNode(sMoveOutLineNormalized,
                                                                                  sUpperDistance,
                                                                                  bVectorByScalar=True)])
    else:
        sMoveOutLineNormalized = library.createVectorMultiplyNode(sMoveOutLineNormalized, -1.0, bVectorByScalar=True)
        sThreePointOut = library.createVectorAdditionNode([sPointOnLine,
                                                   library.createVectorMultiplyNode(sMoveOutLineNormalized,
                                                                                  sUpperDistance,
                                                                                  bVectorByScalar=True)], sName='threePointOut')
    
    sMoveForward = library.createConditionNode('%s.tx' % sLowerObj, '>', 0, 1.0, -1.0)

    sNodesAttrsForDeletion.extend([sDirection, sDistance, sT, sPointOnLine, sMoveOutLine, sThreePointOut, sMoveForward, sMoveOutLineNormalized])
    
    
    if bMocap: # since input skeleton has different axes...
        sMovedOut = -1.0
        sUpperDistanceMovedBack = library.createMultiplyNode(sUpperDistance, sMovedOut)
        sUpperDistanceMovedForward = library.createMultiplyNode(sUpperDistance, sMoveForward)
        sStretchedOut = library.createPointByMatrixNode([sUpperDistanceMovedForward, 0, sUpperDistanceMovedBack], '%s.worldMatrix' % sUpperObj)
    else:
        bPositive = bBackIsPositive
        if bOpposite: bPositive = not bPositive
        sMovedOut = library.createConditionNode('%s.tx' % sLowerObj, '>', 0, 1.0 if bPositive else -1.0, -1.0 if bPositive else 1.0)
        sUpperDistanceMovedBack = library.createMultiplyNode(sUpperDistance, sMovedOut)
        sUpperDistanceMovedForward = library.createMultiplyNode(sUpperDistance, sMoveForward)
        sStretchedOut = library.createPointByMatrixNode([sUpperDistanceMovedForward, sUpperDistanceMovedBack, 0], '%s.worldMatrix' % sUpperObj)
    
    sLocalA = library.createVectorAdditionNode([sUpper, sElbow], sOperation='minus')
    sLocalB = library.createVectorAdditionNode([sWrist, sElbow], sOperation='minus')
    sAngle = library.createAngleNode(sLocalA, sLocalB)
    
    sNodesAttrsForDeletion.extend([sLocalA, sLocalB, sAngle])

    sMinAngle = 155
    sMaxAngle = 175

    if bAnim and bMocap:
        sMinAngle = library.addAttr(sCtrl, ln='angled2straightMin', dv=150, k=True, bReturnIfExists=True)
        sMaxAngle = library.addAttr(sCtrl, ln='angled2straightMax', dv=170, k=True, bReturnIfExists=True)
        sCurrentAngle = library.addAttr(sCtrl, ln='currentAngle', k=False, cb=True, bReturnIfExists=True)
        sCurrentMode = library.addAttr(sCtrl, ln='currentMode', k=False, cb=True, bReturnIfExists=True)
        cmds.connectAttr(sAngle, sCurrentAngle)
        
    sBlendedOut = library.createRangeNode(sAngle, sMinAngle, sMaxAngle, sThreePointOut, sStretchedOut, bOutRangeIsVector=True)
    
    if bAnim and bMocap:
        sNodesAttrsForDeletion.append(library.createRangeNode(sAngle, sMinAngle, sMaxAngle, 0, 1, sTarget=sCurrentMode))
    
    sParents = cmds.listRelatives(sCtrl, p=True) or []
    sLocal = library.createPointByMatrixNode(sBlendedOut, '%s.worldInverseMatrix' % sParents[0]) if sParents else sBlendedOut
    if bAnim:
        cmds.connectAttr(sLocal, '%s.t' % sCtrl)
        sNodesAttrsForDeletion.extend([sBlendedOut, sLocal])
        return [sAttr.split('.')[0] for sAttr in sNodesAttrsForDeletion]
    else:
        cmds.setAttr('%s.t' % sCtrl, *cmds.getAttr(sLocal)[0])
        cmds.delete(sNodesAttrsForDeletion)


# def _matchLiveConstraint(sLocator, sCtrl, sNamespace):
#     import kangarooTools.nodes as nodes
#     sLiveOffset = cmds.getAttr('%s.liveOffset' % sCtrl)
#     sFullLiveOffset = '%s%s' % (sNamespace, sLiveOffset)
#
#     sCtrlParent = cmds.listRelatives(sCtrl, p=True)[0]
#     sOutputMatrix = library.createMultMatrixNode(['%s.worldMatrix' % sCtrlParent,
#                                                   '%s.worldInverseMatrix' % sFullLiveOffset,
#                                                   '%s.worldMatrix' % sLocator,
#                                                   '%s.worldInverseMatrix' % sCtrlParent])
#     sDecompose = library.createDecomposeMatrix(sOutputMatrix, sTargetPos='%s.t' % sCtrl, sTargetRot='%s.r' % sCtrl, bConnectRotateOrder=True)
#     return [sOutputMatrix.split('.')[0], sDecompose.split('.')[0]], ['%s.%s' % (sCtrl,sA) for sA in ['tx','ty','tz','rx','ry','rz']]



def _matchAttr(sAttr, fValue, bAnim):
    
    if bAnim:
        if not cmds.objExists(sAttr) or not cmds.getAttr(sAttr, settable=True):
            return [], [], []
        else:
            sPrevConnections = cmds.listConnections(sAttr, s=True, d=False, p=True, c=True) or []
            if sPrevConnections:
                cmds.disconnectAttr(sPrevConnections[1], sPrevConnections[0])
                
            cmds.setAttr(sAttr, fValue)
            
            return [], [sAttr], [sPrevConnections]
    else:
        if cmds.objExists(sAttr) and cmds.getAttr(sAttr, settable=True):
            if cmds.getAttr(sAttr, settable=True):
                cmds.setAttr(sAttr, fValue)
            

def _matchDistance(sLocator0, sLocator1, sCtrl, sA, sGlobalScaleCtrl, bAnim):
    # import kangarooTools.nodes as nodes
    if bAnim:
        sPrevConnections = cmds.listConnections('%s.%s' % (sCtrl,sA), s=True, d=False, p=True, c=True) or []
        if sPrevConnections:
            cmds.disconnectAttr(sPrevConnections[1], sPrevConnections[0])
    
    fMultipl = cmds.getAttr('%s.distanceMultipl_%s' % (sCtrl,sA))
    sAttr = '%s.%s' % (sCtrl, sA)
    sDistance = library.createDistanceNode(sLocator0, sLocator1)

    sGlobalScale = '%s.outputScaleX' % library.createDecomposeMatrix('%s.worldMatrix' % sGlobalScaleCtrl).split('.')[0]
    sDistanceDivided = library.createMultiplyNode(sDistance, sGlobalScale, sOperation='divide')
    sMultipl = library.createMultiplyNode(sDistanceDivided, fMultipl)
    sDeleteAttrs = [sDistance.split('.')[0], sMultipl.split('.')[0], sGlobalScale.split('.')[0], sDistanceDivided.split('.')[0]]
    if bAnim:
        cmds.connectAttr(sMultipl, sAttr)
        return sDeleteAttrs, [sAttr], [sPrevConnections]
    else:
        cmds.setAttr(sAttr, cmds.getAttr(sMultipl))
        cmds.delete(sDeleteAttrs)



class AddOptions():
    normal = 0
    addNegative = 1
    addPositive = 2
    addAllNegated = 3
    addNegativeNegated = 4
    addPositiveNegated = 5


def _setValueOnCondition(xCondition, sTargetAttr, xOnTrue, xOnFalse, bNegate, bAnim, xOnTrueAddOptions=[], xOnFalseAddOptions=[]):
    # import kangarooTools.nodes as nodes
    if bAnim:
        sPrevConnections = cmds.listConnections(sTargetAttr, s=True, d=False, p=True, c=True) or []
        if sPrevConnections:
            cmds.disconnectAttr(sPrevConnections[1], sPrevConnections[0])

    sTrueFalseOuts = [None, None]
    for i, xOut, xAddOptions in [(0, xOnTrue, xOnTrueAddOptions), (1, xOnFalse, xOnFalseAddOptions)]:
        if isinstance(xOut, (list,tuple)):
            for x,kOption in enumerate(xAddOptions):
                if kOption == AddOptions.addNegative:
                    xOut[x] = library.createConditionNode(xOut[x], '<', 0.0, xOut[x], 0.0)
                elif kOption == AddOptions.addPositive:
                    xOut[x] = library.createConditionNode(xOut[x], '>', 0.0, xOut[x], 0.0)
                if kOption == AddOptions.addAllNegated:
                    xOut[x] = library.createMultiplyNode(xOut[x], -1.0)
                elif kOption == AddOptions.addNegativeNegated:
                    xOut[x] = library.createConditionNode(xOut[x], '<', 0.0, library.createMultiplyNode(xOut[x], -1.0), 0.0)
                elif kOption == AddOptions.addPositiveNegated:
                    xOut[x] = library.createConditionNode(xOut[x], '>', 0.0, library.createMultiplyNode(xOut[x], -1.0), 0.0)
            sTrueFalseOuts[i] = library.createAdditionNode(xOut)
        else:
            sTrueFalseOuts[i] = xOut

    sCondition = library.createConditionNode(xCondition[0], xCondition[1], xCondition[2], sTrueFalseOuts[0], sTrueFalseOuts[1])
    
    sDeleteAttrs = [sCondition.split('.')[0]]
    
    if bNegate:
        sOutAttr = library.createMultiplyNode(sCondition, -1)
        sDeleteAttrs.append(sOutAttr.split('.')[0])
    else:
        sOutAttr = sCondition
    
    if bAnim:
        cmds.connectAttr(sOutAttr, sTargetAttr)
        return sDeleteAttrs, [sTargetAttr], [sPrevConnections]
    else:
        cmds.setAttr(sTargetAttr, cmds.getAttr(sOutAttr))
        cmds.delete(sDeleteAttrs)


def _matchSetSum(xElements, sTargetAttr, bAnim, sOperation='plus', bNegate=False):
    # import kangarooTools.nodes as nodes
    if bAnim:
        sPrevConnections = cmds.listConnections(sTargetAttr, s=True, d=False, p=True, c=True) or []
        if sPrevConnections:
            cmds.disconnectAttr(sPrevConnections[1], sPrevConnections[0])
    
    sSum = library.createAdditionNode(xElements, sOperation=sOperation)
    sDeleteAttrs = [sSum.split('.')[0]]
    
    if bNegate:
        sSum = library.createMultiplyNode(sSum, -1)
        sDeleteAttrs.append(sSum.split('.')[0])
    
    
    if bAnim:
        cmds.connectAttr(sSum, sTargetAttr)
        return sDeleteAttrs, [sTargetAttr], [sPrevConnections]
    else:
        cmds.setAttr(sTargetAttr, cmds.getAttr(sSum))
        cmds.delete(sDeleteAttrs)



def _matchConstraintSpecial(sLocator, sPrevIkLocator, sPrevIkOffsetToLocator, sCtrl, sOffsetTo, bAnim, sTransformAttrs=['tx', 'ty', 'tz', 'rx', 'ry', 'rz'], sAttrSuffix=''):
    sTempOffsetTo = cmds.spaceLocator(n='tempOffsetTo')[0]
    sConstraint = cmds.parentConstraint(sLocator, sTempOffsetTo)[0]
    sScaleConstraint = cmds.scaleConstraint(sLocator, sTempOffsetTo)[0]
    ffOffsets = eval(cmds.getAttr('%s.parentConstraintOffset%s' % (sOffsetTo, sAttrSuffix)))
    cmds.setAttr('%s.target[0].targetOffsetTranslate' % sConstraint, *ffOffsets[0])
    cmds.setAttr('%s.target[0].targetOffsetRotate' % sConstraint, *ffOffsets[1])

    sCtrlParent = cmds.listRelatives(sCtrl, p=True)[0]
    sCtrlCopyConstraint = cmds.createNode('transform')
    sCtrlCopy = cmds.createNode('joint', p=sCtrlParent)
    cmds.setAttr('%s.ro' % sCtrlCopy, cmds.getAttr('%s.ro' % sCtrl))
    cmds.xform(sCtrlCopy, m=cmds.xform(sCtrl, q=True, m=True, ws=True), ws=True)
    if cmds.objectType(sCtrl) == 'joint':
        cmds.setAttr('%s.jo' % sCtrlCopy, *cmds.getAttr('%s.jo' % sCtrl)[0])

    sDynamicOffset = library.createMultMatrixNode(['%s.worldMatrix' % sPrevIkLocator,
                                                 '%s.worldInverseMatrix' % sPrevIkOffsetToLocator,
                                                 '%s.worldMatrix' % sTempOffsetTo])
    
    sDecompose = library.createDecomposeMatrix(sDynamicOffset, sTargetPos='%s.t' % sCtrlCopyConstraint, sTargetRot='%s.r' % sCtrlCopyConstraint, sTargetScale='%s.s' % sCtrlCopyConstraint, bConnectRotateOrder=True)
    cmds.xform(sCtrlCopy, m=cmds.xform(sCtrlCopyConstraint, q=True, m=True, ws=True), ws=True)
    cmds.parentConstraint(sCtrlCopyConstraint, sCtrlCopy, mo=True)
    
    sDeleteNodes = [sAttr.split('.')[0] for sAttr in [sCtrlCopyConstraint, sCtrlCopy, sConstraint, sScaleConstraint, sDynamicOffset, sDecompose, sTempOffsetTo]]

    sSkipTranslate = [sA[-1] for sA in ['tx', 'ty', 'tz'] if
                      not cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True) or sA not in sTransformAttrs]
    sSkipRotate = [sA[-1] for sA in ['rx', 'ry', 'rz'] if
                   not cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True) or sA not in sTransformAttrs]

    sConnectedAttrs = ['%s.%s' % (sCtrl, sA) for sA in sTransformAttrs if
                       cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True)]

    if not bAnim:
        for sAttr in sConnectedAttrs:
            sAttrCopy = '%s.%s' % (sCtrlCopy, sAttr.split('.')[-1])
            cmds.setAttr(sAttr, cmds.getAttr(sAttrCopy))
        cmds.delete(sDeleteNodes)

    else:
        cmds.parentConstraint(sCtrlCopy, sCtrl, skipRotate=sSkipRotate, skipTranslate=sSkipTranslate)
        return sDeleteNodes, sConnectedAttrs, []
    
    
def _matchConstraintSpecialCondition(sLocatorA, sLocatorB, xCondition, sPrevIkLocator, sPrevIkOffsetToLocator, sCtrl, sOffsetTo, bAnim, sTransformAttrs=['tx', 'ty', 'tz', 'rx', 'ry', 'rz']):
    # import kangarooTools.nodes as nodes


    sTempOffsetToA = cmds.spaceLocator(n='tempOffsetToA')[0]
    sConstraintA = cmds.parentConstraint(sLocatorA, sTempOffsetToA)[0]
    sScaleConstraintA = cmds.scaleConstraint(sLocatorA, sTempOffsetToA)[0]
    ffOffsetsA = eval(cmds.getAttr('%s.parentConstraintOffsetA' % sOffsetTo))
    cmds.setAttr('%s.target[0].targetOffsetTranslate' % sConstraintA, *ffOffsetsA[0])
    cmds.setAttr('%s.target[0].targetOffsetRotate' % sConstraintA, *ffOffsetsA[1])


    sTempOffsetToB = cmds.spaceLocator(n='tempOffsetToB')[0]
    sConstraintB = cmds.parentConstraint(sLocatorB, sTempOffsetToB)[0]
    sScaleConstraintB = cmds.scaleConstraint(sLocatorB, sTempOffsetToB)[0]
    ffOffsetsB = eval(cmds.getAttr('%s.parentConstraintOffsetB' % sOffsetTo))
    cmds.setAttr('%s.target[0].targetOffsetTranslate' % sConstraintB, *ffOffsetsB[0])
    cmds.setAttr('%s.target[0].targetOffsetRotate' % sConstraintB, *ffOffsetsB[1])

    sCtrlParent = cmds.listRelatives(sCtrl, p=True)[0]
    sCtrlCopyConstraint = cmds.createNode('transform')
    sCtrlCopy = cmds.createNode('joint', p=sCtrlParent)
    cmds.setAttr('%s.ro' % sCtrlCopy, cmds.getAttr('%s.ro' % sCtrl))
    if cmds.objectType(sCtrl) == 'joint':
        cmds.setAttr('%s.jo' % sCtrlCopy, *cmds.getAttr('%s.jo' % sCtrl)[0])

    sConditionNode = library.createConditionNode(xCondition[0], xCondition[1], xCondition[2], 0, 1)
    sOffsetSelect = library.createChoiceNode(sConditionNode, ['%s.worldMatrix' % sTempOffsetToA, '%s.worldMatrix' % sTempOffsetToB])

    sDynamicOffset = library.createMultMatrixNode(['%s.worldMatrix' % sPrevIkLocator,
                                                 '%s.worldInverseMatrix' % sPrevIkOffsetToLocator,
                                                 sOffsetSelect])
    
    sDecompose = library.createDecomposeMatrix(sDynamicOffset, sTargetPos='%s.t' % sCtrlCopyConstraint, sTargetRot='%s.r' % sCtrlCopyConstraint, sTargetScale='%s.s' % sCtrlCopyConstraint, bConnectRotateOrder=True)
    cmds.xform(sCtrlCopy, m=cmds.xform(sCtrlCopyConstraint, q=True, m=True, ws=True), ws=True)
    cmds.parentConstraint(sCtrlCopyConstraint, sCtrlCopy, mo=True)
    
    sDeleteNodes = [sAttr.split('.')[0] for sAttr in [sCtrlCopyConstraint, sCtrlCopy, sConstraintA, sConstraintB, sScaleConstraintA, sScaleConstraintB, sDynamicOffset, sDecompose, sTempOffsetToA, sTempOffsetToB, sConditionNode, sOffsetSelect]]

    sSkipTranslate = [sA[-1] for sA in ['tx', 'ty', 'tz'] if
                      not cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True) or sA not in sTransformAttrs]
    sSkipRotate = [sA[-1] for sA in ['rx', 'ry', 'rz'] if
                   not cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True) or sA not in sTransformAttrs]

    sConnectedAttrs = ['%s.%s' % (sCtrl, sA) for sA in sTransformAttrs if
                       cmds.getAttr('%s.%s' % (sCtrl, sA), settable=True)]

    if not bAnim:
        for sAttr in sConnectedAttrs:
            sAttrCopy = '%s.%s' % (sCtrlCopy, sAttr.split('.')[-1])
            cmds.setAttr(sAttr, cmds.getAttr(sAttrCopy))
        cmds.delete(sDeleteNodes)

    else:
        cmds.parentConstraint(sCtrlCopy, sCtrl, skipRotate=sSkipRotate, skipTranslate=sSkipTranslate)
        return sDeleteNodes, sConnectedAttrs, []


def _matchAimConstraint(sTarget, sPole, sCtrl, bAnim):
    if not bAnim:
        sCtrlCopy = cmds.createNode('joint', p=cmds.listRelatives(sCtrl, p=True)[0])
        cmds.setAttr('%s.ro' % sCtrlCopy, cmds.getAttr('%s.ro' % sCtrl))
        cmds.xform(sCtrlCopy, m=cmds.xform(sCtrl, q=True, m=True, ws=True), ws=True)
        if cmds.objectType(sCtrl) == 'joint':
            cmds.setAttr('%s.jo' % sCtrlCopy, *cmds.getAttr('%s.jo' % sCtrl)[0])

    if bAnim:
        sPrevConnections = []
        for sA in ['r', 'rx', 'ry', 'rz']:
            sConns = cmds.listConnections('%s.%s' % (sCtrl, sA), s=True, d=False, p=True, c=True)
            if sConns:
                sPrevConnections.append(sConns)
        for sConns in sPrevConnections:
            cmds.disconnectAttr(sConns[1], sConns[0])

    sConstraint = cmds.aimConstraint(sTarget, sCtrl if bAnim else sCtrlCopy, wut='object', wuo=sPole, aim=[0, 1, 0], u=[0, 0, 1])[0]

    if bAnim:
        return [sConstraint], ['%s.%s' % (sCtrl,sA) for sA in ['rx','ry','rz']], sPrevConnections
    else:
        cmds.setAttr('%s.r' % sCtrl, *cmds.getAttr('%s.r' % sCtrlCopy)[0])
        cmds.delete(sCtrlCopy)
        
        

def _matchConstraint(sLocator, sCtrl, bAnim, sTransformAttrs=['tx', 'ty', 'tz', 'rx', 'ry', 'rz'], sTransferAttrs=None):

    if not bAnim:
        sCtrlCopy = cmds.createNode('joint', p=cmds.listRelatives(sCtrl, p=True)[0])
        cmds.setAttr('%s.ro' % sCtrlCopy, cmds.getAttr('%s.ro' % sCtrl))
        cmds.xform(sCtrlCopy, m=cmds.xform(sCtrl, q=True, m=True, ws=True), ws=True)
        if cmds.objectType(sCtrl) == 'joint':
            cmds.setAttr('%s.jo' % sCtrlCopy, *cmds.getAttr('%s.jo' % sCtrl)[0])

    sSkipTranslate = [sA[-1] for sA in ['tx','ty','tz'] if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True) or sA not in sTransformAttrs]
    sSkipRotate = [sA[-1] for sA in ['rx','ry','rz'] if not cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True) or sA not in sTransformAttrs]
    
    sConnectedAttrs = ['%s.%s' % (sCtrl,sA) for sA in sTransformAttrs if cmds.getAttr('%s.%s' % (sCtrl,sA), settable=True)]
    
    sConstraint = cmds.parentConstraint(sLocator, sCtrl if bAnim else sCtrlCopy, skipTranslate=sSkipTranslate, skipRotate=sSkipRotate)[0]

    ffOffsets = eval(cmds.getAttr('%s.parentConstraintOffset' % sCtrl))
    cmds.setAttr('%s.target[0].targetOffsetTranslate' % sConstraint, *ffOffsets[0])
    cmds.setAttr('%s.target[0].targetOffsetRotate' % sConstraint, *ffOffsets[1])

    if bAnim:
        # cmds.select(sConstraint, sCtrl)
        
        sPrevConnections = []
    
        if sTransferAttrs:
            for sAttr in sTransferAttrs:
                sConns = cmds.listConnections(sAttr, s=True, d=False, p=True, c=True)
                if sConns:
                    sPrevConnections.append(sConns)
            for sConns in sPrevConnections:
                cmds.disconnectAttr(sConns[1], sConns[0])
        
            cmds.disconnectAttr('%s.constraintRotateX' % sConstraint, '%s.rx' % sCtrl)
            cmds.disconnectAttr('%s.constraintRotateY' % sConstraint, '%s.ry' % sCtrl)
            cmds.disconnectAttr('%s.constraintRotateZ' % sConstraint, '%s.rz' % sCtrl)
            cmds.connectAttr('%s.constraintRotateX' % sConstraint, sTransferAttrs[0])
            cmds.connectAttr('%s.constraintRotateY' % sConstraint, sTransferAttrs[1])
            cmds.connectAttr('%s.constraintRotateZ' % sConstraint, sTransferAttrs[2])
            sConnectedAttrs = sTransferAttrs
    
        return [sConstraint], sConnectedAttrs, sPrevConnections
    else:
        if sTransferAttrs:
            for a,sAttr in enumerate(sConnectedAttrs):
                sAttrCopy = '%s.%s' % (sCtrlCopy, sAttr.split('.')[-1])
                cmds.setAttr(sTransferAttrs[a], cmds.getAttr(sAttrCopy))
        else:
            for sAttr in sConnectedAttrs:
                sAttrCopy = '%s.%s' % (sCtrlCopy, sAttr.split('.')[-1])
                cmds.setAttr(sAttr, cmds.getAttr(sAttrCopy))
        cmds.delete(sCtrlCopy)
    
    
    
def humanLimbsSwitchMenu():
    sLimbs = []
    for sNode in cmds.ls(sl=True):
        sAttr = '%s.sLimbCtrl' % sNode
        if cmds.objExists(sAttr):
            sLimbs.append('%s%s' % (library.getNamespace(sNode), cmds.getAttr(sAttr)))
    sLimbs = sorted(list(set(sLimbs)))

    if sLimbs:
        qMenu = QtWidgets.QMenu()

        if len(sLimbs):
            sNamespaces = [library.getNamespace(sLimb) for sLimb in sLimbs]
            ssSplits = [sLimb.split(':')[-1].split('_') for sLimb in sLimbs]
            sSides = [ssSplits[x][0] for x in range(len(ssSplits))]
            sNames = [ssSplits[x][1] for x in range(len(ssSplits))]
            
            sLimbList = library.listToString([sL.split(':')[-1] for sL in sorted(sLimbs)])
            
            qLimbMenu = qMenu.addMenu('to FK (%d %s: %s)' % (len(sLimbs), 'limb' if len(sLimbs) == 1 else 'limbs', sLimbList))
            qLimbMenu.addAction('Pose', lambda: doSwitchLimb(sNamespaces, sSides, sNames, fSwitchValue=0.0))
            qLimbMenu.addAction('Anim', lambda: doSwitchLimb(sNamespaces, sSides, sNames, fSwitchValue=0.0, bAnim=True))
            qLimbMenu.addAction('Anim Baked', lambda: doSwitchLimb(sNamespaces, sSides, sNames, fSwitchValue=0.0, bAnim=True, bBaked=True))

            qLimbMenu = qMenu.addMenu('to IK (%d %s: %s)' % (len(sLimbs), 'limb' if len(sLimbs) == 1 else 'limbs', sLimbList))
            qLimbMenu.addAction('Pose', lambda: doSwitchLimb(sNamespaces, sSides, sNames, fSwitchValue=1.0))
            qLimbMenu.addAction('Anim', lambda: doSwitchLimb(sNamespaces, sSides, sNames, fSwitchValue=1.0, bAnim=True))
            qLimbMenu.addAction('Anim Baked', lambda: doSwitchLimb(sNamespaces, sSides, sNames, fSwitchValue=1.0, bAnim=True, bBaked=True))

        qCursor = QtGui.QCursor()
        qMenu.exec_(qCursor.pos())
        return qMenu
    else:
        cmds.confirmDialog(m='Select controls of limbs you want to switch')


def switchLimb(sNamespace, sSide, sLimb='arm'):
    qMenu = QtWidgets.QMenu()
    qMenu.addAction('Pose', lambda: doSwitchLimb(sNamespace, sSide, sLimb))
    qMenu.addAction('Anim', lambda: doSwitchLimb(sNamespace, sSide, sLimb, bAnim=True))
    qMenu.addAction('Anim Baked', lambda: doSwitchLimb(sNamespace, sSide, sLimb, bAnim=True, bBaked=True))
    qCursor = QtGui.QCursor()
    qMenu.exec_(qCursor.pos())
    return qMenu




def createSimpleTransforms(sNamespace, sJoints, sNames=None, sSuffix='', bKeepConstraints=False):
    sTempTransforms = []
    if sNames == None:
        sNames = [sJ.split(':')[-1] for sJ in sJoints]

    # sFullJoints = ['%s%s' % (sNamespace,sJ) for sJ in sJoints]
    dJoints = {}
    for sFullJ,sN in zip(sJoints,sNames):
        sName = library.getUniqueName('tempDupl_%s%s' % (sN,sSuffix))
        sLoc = cmds.spaceLocator(name=sName)[0]
        cmds.xform(sLoc, m=cmds.xform(sFullJ, m=True, q=True, ws=True), ws=True)
        sParentConstraint = cmds.parentConstraint(sFullJ, sLoc, mo=True)
        if not bKeepConstraints: cmds.delete(sParentConstraint)
        sScaleConstraint = cmds.scaleConstraint(sFullJ, sLoc, mo=True)
        if not bKeepConstraints: cmds.delete(sScaleConstraint)

        sTempTransforms.append(sLoc)
        dJoints[sFullJ] = sLoc

    for sFullJ,sLoc in dJoints.items():
        sParent = cmds.listRelatives(sFullJ, p=True)[0]
        if sParent in dJoints:
            cmds.parent(sLoc, dJoints[sParent])
    return sTempTransforms



def switchAutoScapula():
    sSel = cmds.ls(sl=True)
    sScapula = sSel[0]
    sAttr = '%s.autoVert' % sScapula
    if not cmds.objExists(sAttr):
        cmds.confirmDialog(m='Select Ctrl with autoVert attribute')
        return
    else:
        fValue = cmds.getAttr(sAttr)
        fNewValue = 1.0 - fValue
        
        cmds.undoInfo(openChunk=True)
        try:
            sTempObj = cmds.spaceLocator()[0]
            cmds.delete(cmds.pointConstraint(sScapula, sTempObj))
            
            cmds.setAttr(sAttr, fNewValue)
            cmds.delete(cmds.pointConstraint(sTempObj, sScapula, skip=['x']))
        except:
            raise
        finally:
            cmds.delete(sTempObj)
            cmds.undoInfo(closeChunk=True)
            cmds.select(sSel)
            
            

def spaceSwitchMenu():

    def _invalidSelection():
        cmds.confirmDialog(title='Please Select Control with Space Switch Attribute',
                           message='Please Select Control with Space Switch Attribute',
                           button=['ok'])


    sSelectedCtrls = cmds.ls('*:*_ctrl', '*_ctrl', sl=True, et='transform') + cmds.ls('*:*_ctrl', '*_ctrl', sl=True, et='joint')
    if not sSelectedCtrls:
        _invalidSelection()
        return

    sNamespaces = []
    sInfoAttrs = []
    sCtrls = []
    for sCtrl in sSelectedCtrls:
        sInfoAttr = '%s.__switchInfo__' % sCtrl
        if cmds.objExists(sInfoAttr):
            sNamespace = ':'.join(sCtrl.split(':')[:-1])
            if sNamespace:
                sNamespace = '%s:' % sNamespace
            sNamespaces.append(sNamespace)
            sInfoAttrs.append(sInfoAttr)
            sCtrls.append(sCtrl)

    if not len(sInfoAttrs):
        _invalidSelection()
        return

    qMenu = QtWidgets.QMenu()
    ddSpaces = OrderedDict()

    for sInfoAttr in sInfoAttrs:
        xSpaces = eval(cmds.getAttr(sInfoAttr))
        for xSp in xSpaces:
            sInfo = xSp[1]
            if isinstance(sInfo, (list,tuple)):
                sSpaceName = sInfo[1].split('_')[-1]
            else:
                sSpaceName = sInfo.split('_')[-1]

            if sSpaceName not in ddSpaces:
                ddSpaces[sSpaceName] = [xSp]
            else:
                ddSpaces[sSpaceName].append(xSp)

    for sType in ['pose', 'anim']:
        qTypeMenu = qMenu.addMenu(sType)

        for sSpaceName, xxSpaces in list(ddSpaces.items()):
            ssOutputNames = [xSp[2] for xSp in xxSpaces]
            sCommonOutputNames = library.intersectionLists(ssOutputNames)
            qSpace = qTypeMenu if len(ddSpaces) == 1 else qTypeMenu.addMenu(sSpaceName)
            for o,sO in enumerate(sCommonOutputNames):
                def _switchTo(_xxSpaces=xxSpaces, _sO=sO, bAnim=True if sType=='anim' else False):
                    cmds.undoInfo(openChunk=True)
                    try:
                        sSelBefore = cmds.ls(sl=True)
                        if bAnim:
                            fTimeBefore = cmds.currentTime(q=True)
                            # fMinTime = cmds.playbackOptions(q=True, minTime=True)
                            # fMaxTime = cmds.playbackOptions(q=True, maxTime=True) + 1
                            fMinTime, fMaxTime = library.getTimeSliderRange()

                            for xSp in _xxSpaces:
                                bBlend = xSp[0]
                                sSwitchAttr = xSp[1]
                                sOutputNames = xSp[2]
                                sTrs = xSp[3]
                                if isinstance(sSwitchAttr, (list, tuple)):
                                    sCtrl = sSwitchAttr[1].split('.')[0]
                                    for sA in sSwitchAttr:
                                        if library.isStringOrUnicode(sA):
                                            library.deleteAnimation('%s%s' % (sNamespace, sA))
                                else:
                                    sCtrl = sSwitchAttr.split('.')[0]
                                    library.deleteAnimation('%s%s' % (sNamespace, sSwitchAttr))


                                fAllTimes = [fT for fT in (cmds.keyframe('%s%s' % (sNamespace, sCtrl), q=True) or []) if
                                             fT >= fMinTime and fT <= fMaxTime]
                                fAllTimes = sorted(list(set(fAllTimes)))

                                # sTempLocs = []
                                sTempLoc = cmds.spaceLocator(n='matchTempLocBlend')[0]
                                sParentConstraintTempLoc = cmds.parentConstraint('%s%s' % (sNamespace, sCtrl), sTempLoc)[0]
                                
                                ffKeys = []
                                for t,fT in enumerate(fAllTimes):
                                    cmds.currentTime(fT)
                                    ffKeys.append((cmds.getAttr('%s.t' % sTempLoc)[0], cmds.getAttr('%s.r' % sTempLoc)[0]))
                                    # sTempLocs.append(sTempLoc)
                                
                                for t,fT in enumerate(fAllTimes):
                                    cmds.setKeyframe('%s.tx' % sTempLoc, t=fAllTimes[t], v=ffKeys[t][0][0])
                                    cmds.setKeyframe('%s.ty' % sTempLoc, t=fAllTimes[t], v=ffKeys[t][0][1])
                                    cmds.setKeyframe('%s.tz' % sTempLoc, t=fAllTimes[t], v=ffKeys[t][0][2])
                                    cmds.setKeyframe('%s.rx' % sTempLoc, t=fAllTimes[t], v=ffKeys[t][1][0])
                                    cmds.setKeyframe('%s.ry' % sTempLoc, t=fAllTimes[t], v=ffKeys[t][1][1])
                                    cmds.setKeyframe('%s.rz' % sTempLoc, t=fAllTimes[t], v=ffKeys[t][1][2])
                                cmds.delete(sParentConstraintTempLoc)
                                
                                iSwitchTo = sOutputNames.index(_sO)
                                
                                sFullCtrl = '%s%s' % (sNamespace, sCtrl)
                                cmds.currentTime(fAllTimes[0])
                                
                                if bBlend:
                                    for a,sA in enumerate(sSwitchAttr):
                                        if a == 0: continue
                                        cmds.setAttr('%s%s' % (sNamespace,sA), 1 if a == iSwitchTo else 0)
                                else:
                                    cmds.setAttr('%s%s' % (sNamespace,sSwitchAttr), iSwitchTo)
                            
                                
                                sTempParent = cmds.createNode('transform')
                                sTempCtrl = cmds.createNode('joint')
                                
                                if cmds.objectType(sFullCtrl) == 'joint':
                                    cmds.setAttr('%s.jo' % sTempCtrl, *cmds.getAttr('%s.jo' % sFullCtrl)[0])
                                cmds.setAttr('%s.ro' % sTempCtrl, cmds.getAttr('%s.ro' % sFullCtrl))
                                
                                cmds.parent(sTempCtrl, sTempParent)
                                cmds.xform(sTempParent, m=cmds.xform(cmds.listRelatives(sFullCtrl, p=True)[0], m=True, q=True, ws=True), ws=True)
                                cmds.parentConstraint(cmds.listRelatives(sFullCtrl, p=True)[0], sTempParent, mo=True)
                                cmds.parentConstraint(sTempLoc, sTempCtrl)#, skipTranslate=sSkipTranslate, skipRotate=sSkipRotate)[0]
                                
                                
                                sRecordAttrs = ['%s.%s' % (sTempCtrl,sA) for sA in ['tx', 'ty', 'tz', 'rx','ry','rz'] if cmds.getAttr('%s.%s' % (sFullCtrl,sA), settable=True)]
                                sBakeAttrs = ['%s.%s' % (sFullCtrl,sA) for sA in ['tx', 'ty', 'tz', 'rx','ry','rz'] if cmds.getAttr('%s.%s' % (sFullCtrl,sA), settable=True)]
                                ffNewKeys = []
                                for t,fT in enumerate(fAllTimes):
                                    cmds.currentTime(fT)
                                    ffNewKeys.append([cmds.getAttr(sAttr) for sAttr in sRecordAttrs])
                                
                                for t,fT in enumerate(fAllTimes):
                                    for a,sAttr in enumerate(sBakeAttrs):
                                        cmds.setKeyframe(sAttr, t=fAllTimes[t], v=ffNewKeys[t][a])

                                cmds.delete(sTempLoc, sTempParent)
                            cmds.currentTime(fTimeBefore)
                        else:
                            sTempLoc = cmds.spaceLocator(n='matchTempLocBlend')[0]
                            print ('_xxSpaces: ', _xxSpaces)
                            for xSp in _xxSpaces:
                                bBlend = xSp[0]
                                sSwitchAttr = xSp[1]
                                if isinstance(sSwitchAttr, (list, tuple)):
                                    sCtrl = sSwitchAttr[1].split('.')[0]
                                else:
                                    sCtrl = sSwitchAttr.split('.')[0]

                                sOutputNames = xSp[2]
                                sTrs = xSp[3]
                                cmds.delete(cmds.parentConstraint('%s%s' % (sNamespace, sCtrl), sTempLoc))

                                iSwitchTo = sOutputNames.index(_sO)
                                if bBlend:
                                    for a, sA in enumerate(sSwitchAttr):
                                        if a == 0: continue
                                        cmds.setAttr('%s%s' % (sNamespace, sA), 1 if a == iSwitchTo else 0)
                                else:
                                    cmds.setAttr('%s%s' % (sNamespace, sSwitchAttr), iSwitchTo)

                                moveCtrlToLoc('%s%s' % (sNamespace, sCtrl), sTempLoc, sTrs)

                            cmds.delete(sTempLoc)

                        cmds.select(sSelBefore)
                    except:
                        raise
                    finally:
                        cmds.undoInfo(closeChunk=True)

                qSpace.addAction(sO, _switchTo)

    qCursor = QtGui.QCursor()
    qMenu.exec_(qCursor.pos())
    return qMenu




def moveCtrlToLoc(sCtrl, sLoc, sTrs, bKey=False):
    sDuplParent = cmds.createNode('transform')
    sDupl = cmds.createNode('joint', p=sDuplParent)
    cmds.setAttr('%s.ro' % sDupl, cmds.getAttr('%s.ro' % sCtrl))
    cmds.xform(sDuplParent, m=cmds.xform(cmds.listRelatives(sCtrl, p=True)[0], q=True, m=True, ws=True), ws=True)
    if cmds.objectType(sCtrl) == 'joint':
        for sA in ['jox', 'joy', 'joz']:
            cmds.setAttr('%s.%s' % (sDupl, sA), cmds.getAttr('%s.%s' % (sCtrl, sA)))
    else:
        cmds.setAttr('%s.jo' % sDupl, 0, 0, 0)

    cmds.delete(cmds.parentConstraint(sLoc, sDupl))

    if sTrs in ['tr', 't']:
        for sA in ['tx','ty','tz']:
            sAttr = '%s.%s' % (sCtrl,sA)
            if cmds.getAttr(sAttr, settable=True):
                fV = cmds.getAttr('%s.%s' % (sDupl,sA))
                cmds.setAttr(sAttr, fV)
                if bKey:
                    cmds.setKeyframe(sAttr, v=fV)
    if sTrs in ['tr', 'r']:
        for sA in ['rx','ry','rz']:
            sAttr = '%s.%s' % (sCtrl,sA)
            if cmds.getAttr(sAttr, settable=True):
                fV = cmds.getAttr('%s.%s' % (sDupl,sA))
                cmds.setAttr(sAttr, fV)
                if bKey:
                    cmds.setKeyframe(sAttr, v=fV)


    cmds.delete(sDuplParent)



def circleDetailCtrls(sNamespace):
    cmds.undoInfo(openChunk=True)
    try:
        sDetails = cmds.ls('%s???LipDetailVtx*_ctrl' % sNamespace, et='transform')
        for sD in sDetails:
            sAttr = '%s.__circlePos__' % sD
            if cmds.objExists(sAttr):
                fPos = cmds.getAttr(cmds.getAttr(sAttr))[0]
                cmds.move(fPos[0], fPos[1], fPos[2], sD, a=True, ws=True)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def resetDetailCtrls(sNamespace):
    sDetails = cmds.ls('%s???LipDetailVtx*_ctrl' % sNamespace, et='transform')
    for sD in sDetails:
        cmds.setAttr('%s.t' % sD, 0, 0, 0)
    print(sDetails)



def selectAllCtrls(sNamespace):
    sCtrls = [sN for sN in cmds.ls('*%s*_ctrl' % sNamespace, '*%s*:*_ctrl' % sNamespace, et='transform') if cmds.attributeQuery('bIsCtrl', node=sN, exists=True)
                                                                                                    or cmds.attributeQuery('ctrlType', node=sN, exists=True)]
    sCtrls += [sN for sN in cmds.ls('*%s*_ctrl' % sNamespace,'*%s*:*_ctrl' % sNamespace, et='joint')  if cmds.attributeQuery('bIsCtrl', node=sN, exists=True)
                                                                                                    or cmds.attributeQuery('ctrlType', node=sN, exists=True)]
    # sCtrls += list(set([sS.split('|')[-1] for sS in cmds.ls('%s__*_Features__' % sNamespace)]))

    cmds.select(sCtrls)




def simMenu(sNamespace):

    qMenu = QtWidgets.QMenu()

    qMenu.addAction('Bake Spring Simulations', bakeSpringsSelectedCtrls)
    qMenu.addAction('Bake Chain Simulations', lambda:bakeDynamicsSelectedCtrls(sNamespace))

    qHairMenu = qMenu.addMenu('Cache nHair')

    def _selectHair():
        sHairSystems = cmds.ls('%s*' % sNamespace, et='hairSystem')
        print('sHairSystems: ', sHairSystems)
        if sHairSystems:
            sTransforms = [cmds.listRelatives(sH, p=True)[0] for sH in sHairSystems]
            cmds.select(sTransforms)
        else:
            cmds.confirmDialog(m='No hair system found in %s namespace')

    def _cacheInfo():
        cmds.confirmDialog(m='Having the hair nodes selected, go to FX menu, nCache -> Create New Cache -> nObject. You can delete and recreate cache in same menu.')

    qHairMenu.addAction('Select hair nodes for caching', _selectHair)
    qHairMenu.addAction('Tell me how to cache...', _cacheInfo)

    qCursor = QtGui.QCursor()
    qMenu.exec_(qCursor.pos())
    return qMenu



def bakeDynamicsSelectedCtrls(sNamespace=''):
    sCtrls = [sT for sT in cmds.ls('%s*' % sNamespace, sl=True, et='transform') if cmds.objExists('%s.sDynamicJoint' % sT)]

    if not sCtrls:
        cmds.confirmDialog(m='Select Controls from Dynamic Setups')
        return


    sCtrls.sort()
    sBakeLocs = []
    sConstraints = []

    try:
        cmds.undoInfo(openChunk=True)
        # bake the simulation to locators
        sSwitches = set()
        for sC in sCtrls:
            sLoc = cmds.spaceLocator()[0]
            sJoint = '%s%s' % (sNamespace, cmds.getAttr('%s.sDynamicJoint' % sC))
            cmds.xform(sLoc, m=cmds.xform(sJoint, q=True, m=True, ws=True), ws=True)
            sConstraints.append(cmds.parentConstraint(sJoint, sLoc, mo=True)[0])
            sConstraints.append(cmds.scaleConstraint(sJoint, sLoc, mo=True)[0])
            sBakeLocs.append(sLoc)
            sAttr = '%s.sDynamicSwitch' % sC
            if cmds.objExists(sAttr):
                sSwitches.add(cmds.getAttr(sAttr))
        # iRange = (int(cmds.playbackOptions(q=True, minTime=True)),
        #           int(cmds.playbackOptions(q=True, maxTime=True)))
        iRange = library.getTimeSliderRange()
        
        cmds.bakeResults(sBakeLocs, t=iRange, simulation=True)
        cmds.delete(sConstraints)

        if False: # create curve for debugging purposes
            import kangarooTools.xforms as xforms
            aPoints = library.getPositionArray(sBakeLocs)
            sCurve = cmds.curve(p=aPoints, d=1)
            sDebugJoints = []
            for p,aP in enumerate(aPoints):
                sDebugJoint = library.createJoint('joint%03d' % p, xPos=aP)
                cmds.parentConstraint(sBakeLocs[p], sDebugJoint)
                sDebugJoints.append(sDebugJoint)
            cmds.skinCluster(sDebugJoints, sCurve, tsb=True)


        # turn of sim
        for sAttr in sSwitches:
            cmds.setAttr(sAttr, False)
        sChainSim = '%s.chainSimulationOnOff' % (library.getMasterName(sNamespace))
        if cmds.objExists(sChainSim):
            cmds.setAttr(sChainSim, False)

        # move from baked locators to the controls
        ssFreeAttrs = []
        sTempTransforms = []
        sTempParents = []
        for c,sC in enumerate(sCtrls):
            sParentConstrainer = cmds.listRelatives(sC, p=True)[0]

            ssFreeAttrs.append([sA for sA in ['tx','ty','tz','rx','ry','rz'] if cmds.getAttr('%s.%s' % (sC,sA), settable=True)])
            sTempParent = cmds.createNode('transform', n='%s_tempParent' % sParentConstrainer)
            sTempTransform = cmds.createNode('joint', p=sTempParent, n='%s_tempTransform' % sC)

            cmds.xform(sTempParent, m=cmds.xform(sParentConstrainer, q=True, m=True, ws=True), ws=True)
            cmds.parentConstraint(sParentConstrainer, sTempParent, mo=True)
            cmds.scaleConstraint(sParentConstrainer, sTempParent, mo=True)

            cmds.setAttr('%s.ro' % sTempTransform, cmds.getAttr('%s.ro' % sC))
            sConstraint = cmds.parentConstraint(sBakeLocs[c], sTempTransform)[0]
            sAttr = '%s.fDynamicOffsetTranslate' % sC
            fDynamicOffsetTranslate = eval(cmds.getAttr(sAttr)) if cmds.objExists(sAttr) else [0,0,0]
            sAttr = '%s.fDynamicOffsetRotate' % sC
            fDynamicOffsetRotate = eval(cmds.getAttr(sAttr)) if cmds.objExists(sAttr) else [0,0,0]

            cmds.setAttr('%s.target[0].targetOffsetTranslate' % sConstraint, *fDynamicOffsetTranslate)
            cmds.setAttr('%s.target[0].targetOffsetRotate' % sConstraint, *fDynamicOffsetRotate)
            sTempTransforms.append(sTempTransform)
            sTempParents.append(sTempParent)

        for iFrame in range(math.floor(iRange[0]), math.ceil(iRange[1]), 1):
            cmds.currentTime(iFrame)
            for c,sC in enumerate(sCtrls):
                for sA in ssFreeAttrs[c]:
                    cmds.setAttr('%s.%s' % (sC,sA), cmds.getAttr('%s.%s' % (sTempTransforms[c],sA)))
                    cmds.setKeyframe('%s.%s' % (sC,sA), v=cmds.getAttr('%s.%s' % (sTempTransforms[c],sA)))

        cmds.delete(sBakeLocs, sTempParents)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def bakeSpringsSelectedCtrls():
    sCtrls = [sC for sC in cmds.ls(sl=True, et='transform')+cmds.ls(sl=True, et='joint') if cmds.objExists('%s.sSpringGrp' % sC)]
    if not sCtrls:
        cmds.confirmDialog(m='Select Controls from Spring Setups')
        return

    sCtrls.sort()

    try:
        cmds.undoInfo(openChunk=True)

        sSpringGrps = []
        for sC in sCtrls:
            sSpringGrps.append('%s%s' % (library.getNamespace(sC), cmds.getAttr('%s.sSpringGrp' % sC)))

        iRange = library.getTimeSliderRange()
        iAllFrames = list(range(math.floor(iRange[0]), math.ceil(iRange[1]), 1))


        ffRotations = [[] for _ in range(len(iAllFrames))]
        for iFrame in iAllFrames:
            cmds.currentTime(iFrame)
            for i,sGrp in enumerate(sSpringGrps):
                ffRotations[iFrame].append(cmds.getAttr('%s.r' % sGrp)[0])

        for c,sC in enumerate(sCtrls):
            for a,sA in enumerate(['rx', 'ry','rz']):
                sAttr = '%s.%s' % (sC, sA)
                for iFrame in iAllFrames:
                    cmds.setKeyframe(sAttr, t=iFrame, v=ffRotations[iFrame][c][a])

        sDoneBlendAttrs = set()
        for sC in sCtrls:
            sBlendAttr = '%s%s' % (library.getNamespace(sC), cmds.getAttr('%s.sSpringStrengthAttr' % sC))
            if sBlendAttr not in sDoneBlendAttrs:
                cmds.setAttr(sBlendAttr, 0.0)
                sDoneBlendAttrs.add(sBlendAttr)


    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)




def mirrorPoseSelected(bFlip=True, bAnimation=False):
    print('mirrorPoseSelected', bFlip, bAnimation)
    sSelectedCtrls = cmds.ls('*_ctrl', et='transform', sl=True) + cmds.ls('*_ctrl', et='joint', sl=True)
    sSelectedCtrls += cmds.ls('*:*_ctrl', et='transform', sl=True) + cmds.ls('*:*_ctrl', et='joint', sl=True)
    print('sSelectedCtrls: ', sSelectedCtrls)
    mirrorPose(sSelectedCtrls, bFlip=bFlip, bAnimation=bAnimation)


def mirrorPoseAll(sNamespace='', bAnimation=False, iMirror=0):

    sSearchString = '%s*_ctrl' % sNamespace
    sFeatureSearchString = '%s__*_Features__' % sNamespace
    if iMirror == 1:
        sSearchString = '%s*_l_ctrl' % sNamespace
        sFeatureSearchString = '%s__l_Features__' % sNamespace
    elif iMirror == 2:
        sSearchString = '%s*_r_ctrl' % sNamespace
        sFeatureSearchString = '%s__r_Features__' % sNamespace

    sCtrls = [sN for sN in cmds.ls(sSearchString, et='transform')  if cmds.attributeQuery('bIsCtrl', node=sN, exists=True)
                                                                                                        or cmds.attributeQuery('ctrlType', node=sN, exists=True)]
    sCtrls += [sN for sN in cmds.ls(sSearchString, et='joint')  if cmds.attributeQuery('bIsCtrl', node=sN, exists=True)
                                                                                                        or cmds.attributeQuery('ctrlType', node=sN, exists=True)]
    cmds.select(sCtrls)
    sCtrls += list(set([sS.split('|')[-1] for sS in cmds.ls(sFeatureSearchString)]))

    sAdditionalCtrls = []
    for sC in sCtrls:
        sSuper = sC.replace('_ctrl', 'Super_ctrl')
        if cmds.objExists(sSuper):
            sAdditionalCtrls.append(sSuper)
        sPivot = sC.replace('_ctrl', 'Pivot_ctrl')
        if cmds.objExists(sPivot):
            sAdditionalCtrls.append(sPivot)
        sChild = sC.replace('_ctrl', 'Child_ctrl')
        if cmds.objExists(sChild):
            sAdditionalCtrls.append(sChild)

    sCtrls += sAdditionalCtrls

    mirrorPose(sCtrls, bFlip=True if iMirror == 0 else False, bAnimation=bAnimation)


def mirrorPose(sInputCtrls=[], bFlip=True, bAnimation=False):
    sSelBefore = cmds.ls(sl=True)

    ddState = {}
    sCtrls = []
    sBothCtrls = []
    for sSelectedCtrl in sInputCtrls:
        sCtrls.append(sSelectedCtrl)
        sBothCtrls.append(sSelectedCtrl)

        sMirrorCtrl = library.getMirrorName(sSelectedCtrl)
        if cmds.objExists(sMirrorCtrl):
            sBothCtrls.append(sMirrorCtrl)
            if bFlip:
                sCtrls.append(sMirrorCtrl)

    sCtrls = list(set(sCtrls))
    sBothCtrls = list(set(sBothCtrls))
    for sCtrl in sBothCtrls:
        sAttrs = library.getAnimAttrsFromNode(sCtrl)
        dState = {}

        for sA in sAttrs:
            sCtrlAttr = '%s.%s' % (sCtrl, sA)
            fValue = cmds.getAttr(sCtrlAttr)
            xAnim = None
            if bAnimation:
                fTimes = cmds.keyframe(sCtrlAttr, q=True)
                if fTimes:
                    fValues = cmds.keyframe(sCtrlAttr, q=True, vc=True)
                    xAnim = dict(list(zip(fTimes, fValues)))

            dState[sA] = [fValue, xAnim]

        ddState[sCtrl] = dState


    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sDataAttr = '%s.dMirrorData' % sCtrl
            if cmds.objExists(sDataAttr):
                dData = eval(cmds.getAttr(sDataAttr))
            else:
                dData = {}

            sDefaultNegate = ['translateX', 'rotateY', 'rotateZ'] if library.getSide(sCtrl) == 'm' else []
            sNegate = dData.get('sNegate', sDefaultNegate)
            sMirrorCtrl = library.getMirrorName(sCtrl)

            if not cmds.objExists(sMirrorCtrl):
                continue

            dState = ddState[sMirrorCtrl] # could be same or mirror one
            for sA,xV in list(dState.items()):
                fValue, xAnim = xV

                fMultipl = -1.0 if sA in sNegate else 1.0
                sAttr = '%s.%s' % (sCtrl,sA)
                if xAnim: # if animation, we'll delete the animation first
                    sConnections = cmds.listConnections(sAttr, s=True, d=False) or []
                    for sC in sConnections:
                        if cmds.objExists(sC): cmds.delete(sC)

                if not cmds.objExists(sAttr):
                    print ('attribute %s doesn\'t exist' % sAttr)
                elif cmds.getAttr(sAttr, lock=True):
                    print('attribute %s is locked' % sAttr)
                    continue
                else:
                    sConnections = cmds.listConnections(sAttr, s=True, d=False)
                    if not sConnections or cmds.objectType(sConnections[0]).startswith('animCurve'):
                        if xAnim:
                            for fT, fV in list(xAnim.items()):
                                cmds.setKeyframe(sAttr, t=fT, v=fV*fMultipl)
                        try:
                            cmds.setAttr(sAttr, fValue*fMultipl)
                        except Exception as e: cmds.warning('not able to set %s. %s' % (sAttr, e))

    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)




def _getUniqueName(sName, bRemoveIllegalCharacters=True):

    if bRemoveIllegalCharacters:
        sName = sName.replace("'", "")

    if not cmds.objExists(sName):
        return sName

    sNewName = sName
    while True:
        sNewName = '%s_' % sNewName
        if not cmds.objExists(sNewName):
            return sNewName


def goToDefaultPoseSelected(bDeleteAnim=False, bKeepPoseOnDeleteAnim=False, bSkipFk2IkAttrs=False, bSkipDisplayAttrs=True):
    sSel = cmds.ls(sl=True)
    if not sSel:
        sNamespace = ''
    else:
        sNamespace = library.getNamespace(sSel[0])

    goToDefaultPose(sNamespace, bDeleteAnim=bDeleteAnim, bKeepPoseOnDeleteAnim=bKeepPoseOnDeleteAnim, bSkipFk2IkAttrs=bSkipFk2IkAttrs, bSkipDisplayAttrs=bSkipDisplayAttrs)

    
def goToDefaultPose(sNamespace, bDeleteAnim=False, bKeepPoseOnDeleteAnim=False, bSkipFk2IkAttrs=False, bSkipDisplayAttrs=True):
    sCtrls = [sC for sC in cmds.ls('%sctrl_*' % sNamespace, '%s*_ctrl' % sNamespace, et='transform')]# if cmds.objExists('%s.bIsCtrl' % sC)]
    sCtrls += [sC for sC in cmds.ls('%sctrl_*' % sNamespace, '%s*_ctrl' % sNamespace, et='joint')]# if cmds.objExists('%s.bIsCtrl' % sC)]
    sCtrls = [sC for sC in sCtrls if cmds.attributeQuery('ctrlType', node=sC, exists=True) or
              cmds.attributeQuery('bIsCtrl', node=sC, exists=True) or
              cmds.attributeQuery('bIsPivot', node=sC, exists=True) or
              cmds.attributeQuery('bIsSuper', node=sC, exists=True) or
              cmds.attributeQuery('bIsChild', node=sC, exists=True)]

    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            if bSkipDisplayAttrs and sCtrl.split(':')[-1] == 'display_ctrl':
                continue
            sFullAttr = '%s.dDefaultAttrs' % sCtrl

            if not cmds.objExists(sFullAttr):
                sFullAttr = sFullAttr.replace('Super', '').replace('Child', '')

            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    if sA == 'fk2ik' and bSkipFk2IkAttrs:
                        continue
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    if bDeleteAnim:
                        if cmds.objExists(sFullAttr):
                            cmds.getAttr(sFullAttr)
                            sAnimConnections = [sNode for sNode in (cmds.listConnections(sFullAttr, s=True, d=False) or []) if cmds.objectType(sNode).startswith('animCurve')]
                            if sAnimConnections:
                                cmds.delete(sAnimConnections)
                            cmds.setAttr(sFullAttr)
                    try:
                        if not bKeepPoseOnDeleteAnim:
                            cmds.setAttr(sFullAttr, fV)
                    except: pass
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def goToDefaultPoseSelection():
    sCtrls = [sCtrl for sCtrl in cmds.ls('*_ctrl', '*:*_ctrl', sl=True)]
    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)




def _getRokokoJoints(sPrefix, sStringOptions, bMirror, bReturnNonIfNotExist=False):
    print('_getRokokoJoints: ', sPrefix, sStringOptions, bMirror)
    if bMirror:
        sReturn = [None, None]
        for s,sSide in enumerate(['l','r']):
            for sOption in sStringOptions:
                sJoint = '%s%s%s' % (sPrefix, library.sSides4[s], sOption)
                if cmds.objExists(sJoint):
                    sReturn[s] = sJoint

        if not bReturnNonIfNotExist:
            for s,sSide in enumerate(['l','r']):
                if sReturn[s] == None:
                    sJoint = '%s%s%s' % (sPrefix, library.sSides4[s], sStringOptions[-1])
                    raise Exception('%s not found' % sJoint)
        return sReturn

    else:
        sReturn = None
        for sOption in sStringOptions:
            sJoint = '%s%s' % (sPrefix, sOption)
            if cmds.objExists(sJoint):
                sReturn = sJoint
        if not bReturnNonIfNotExist:
            if sReturn == None:
                sJoint = '%s%s' % (sPrefix, sStringOptions[-1])
                raise Exception('%s not found' % sJoint)
        return sReturn


def characterizeSelectedMocap(sCharNamespace='', bResetRotations=False):
    # define mocap
    sMocapNamespace = library.getNamespace(cmds.ls(sl=True)[0])
    if bResetRotations:
        sMocapJoints = cmds.ls('%s*' % sMocapNamespace, et='joint')
        for sJ in sMocapJoints:
            cmds.setAttr('%s.r' % sJ, 0, 0, 0)
    
    sMocapCharacter = 'mocapCharacter_definition'
    if sMocapCharacter in cmds.ls(et='HIKCharacterNode'):
        cmds.delete(sMocapCharacter)
    sMocapCharacter = humanIk.hikCreateDefinition(sMocapCharacter)
    
    humanIk.assignAllStandardBones(sMocapCharacter, sMocapNamespace)

    
    # connect them
    sMaster = library.getMasterName(sCharNamespace)
    sCharacterDefinition = '%s%s' % (sCharNamespace, cmds.getAttr('%s.sHumanIkCharacerNode' % sMaster))
    if sCharacterDefinition:
        # Set Character
        mel.eval('optionMenuGrp -e -v "%s" hikCharacterList;' % sCharacterDefinition)
        mel.eval('hikUpdateCurrentCharacterFromUI();')
        mel.eval('hikOnSwitchContextualTabs; hikUpdateContextualUI;hikResizeTabLayout;')
        
        # Set Source
        mel.eval('optionMenuGrp -e -v " %s" hikSourceList;' % sMocapCharacter)
        mel.eval('hikUpdateCurrentSourceFromUI(); hikUpdateContextualUI();')




def humanIkDisConnect(sCharNamespace=''):
    sGrp = '%sretarget' % sCharNamespace
    if not cmds.objExists(sGrp):
        cmds.confirmDialog(m='"%s" not found. Did you connect the body?' % sGrp)
    sDeleteNodes = eval(cmds.getAttr('%s.deleteNodes' % sGrp))
    print ('sDeleteNodes: ', sDeleteNodes)
    cmds.delete([sN for sN in sDeleteNodes if cmds.objExists(sN)])
    

bChildConstraints = False

def humanIkConnect(sCharNamespace=''):
    library.reload2(humanIk)
    cmds.undoInfo(openChunk=True)
    
    humanIk.initiate()
    try:
        for s,sSide in enumerate(['l','r']):
            sClavicleAuto = '%sclavicle_%s_ctrl.auto' % (sCharNamespace, sSide)
            if cmds.objExists(sClavicleAuto):
                cmds.setAttr(sClavicleAuto, 0)

        sReference = '%s:humanIk:Reference' % sCharNamespace
        sJoints = cmds.listRelatives(sReference, c=True, ad=True, typ='joint')
        print ('sJoints: ', sJoints)
        sBakeAttrs = []
        sDeleteNodes = []
        for sFullJoint in sJoints:
            # sFullJoint = '%s%s' % (sCharNamespace, sJoint)
            sAttr = '%s.xCtrls' % (sFullJoint)
            if cmds.objExists(sAttr):
                dDatas = eval(cmds.getAttr(sAttr)) # {'sCtrl': 'spineSplineFk_A_ctrl', 'xOffset': [[(-0.0, 0.0, 0.0)], [(0.0, 0.0, 0.0)]], 'sSkipTranslate': [], 'sSkipRotate': []}
                for dData in dDatas:
                    sFullCtrl = '%s%s' % (sCharNamespace, dData['sCtrl'])
                    sConstraint = cmds.parentConstraint(sFullJoint, sFullCtrl, skipTranslate=dData['sSkipTranslate'], skipRotate=dData['sSkipRotate'])[0]
                    sDeleteNodes.append(sConstraint)
                    for sAxis in ['x','y','z']:
                        if sAxis not in dData['sSkipTranslate']:
                            sBakeAttrs.append('%s.translate%s' % (sFullCtrl, sAxis.upper()))
                    if 'sRotatePlugs' not in dData:
                        for sAxis in ['x', 'y', 'z']:
                            if sAxis not in dData['sSkipRotate']:
                                sBakeAttrs.append('%s.rotate%s' % (sFullCtrl, sAxis.upper()))
    
                    cmds.setAttr('%s.target[0].targetOffsetTranslate' % sConstraint, *dData['fOffsetTranslate'])
                    cmds.setAttr('%s.target[0].targetOffsetRotate' % sConstraint, *dData['fOffsetRotate'])
    
                    if 'sRotatePlugs' in dData:
                        sRotatePlugs = dData['sRotatePlugs']
                        cmds.disconnectAttr('%s.constraintRotateX' % sConstraint, '%s.rx' % sFullCtrl)
                        cmds.disconnectAttr('%s.constraintRotateY' % sConstraint, '%s.ry' % sFullCtrl)
                        cmds.disconnectAttr('%s.constraintRotateZ' % sConstraint, '%s.rz' % sFullCtrl)
                        cmds.connectAttr('%s.constraintRotateX' % sConstraint, '%s%s' % (sCharNamespace, sRotatePlugs[0]))
                        cmds.connectAttr('%s.constraintRotateY' % sConstraint, '%s%s' % (sCharNamespace, sRotatePlugs[1]))
                        cmds.connectAttr('%s.constraintRotateZ' % sConstraint, '%s%s' % (sCharNamespace, sRotatePlugs[2]))
                        for a,sAxis in enumerate(['x', 'y', 'z']):
                            if sAxis not in dData['sSkipRotate']:
                                sBakeAttrs.append('%s%s' % (sCharNamespace, sRotatePlugs[a]))

        # poleVectors:
        sNodes = poleVectorMath('%shumanIk:LeftArm' % sCharNamespace,
                       '%shumanIk:LeftForeArm' % sCharNamespace,
                       '%shumanIk:LeftHand' % sCharNamespace,
                       '%sarmPole_l_ctrl' % sCharNamespace, bAnim=True, bMocap=True)
        sBakeAttrs.extend(['%sarmPole_l_ctrl.%s' % (sCharNamespace,sA) for sA in ['tx','ty','tz']])
        sDeleteNodes.extend(sNodes)

        sNodes = poleVectorMath('%shumanIk:RightArm' % sCharNamespace,
                       '%shumanIk:RightForeArm' % sCharNamespace,
                       '%shumanIk:RightHand' % sCharNamespace,
                       '%sarmPole_r_ctrl' % sCharNamespace, bAnim=True, bMocap=True)
        sBakeAttrs.extend(['%sarmPole_r_ctrl.%s' % (sCharNamespace,sA) for sA in ['tx','ty','tz']])
        sDeleteNodes.extend(sNodes)

        
        sGrp = cmds.createNode('transform', n='%sretarget' % sCharNamespace)
        library.addStringAttr(sGrp, 'bakeAttrs', str(sBakeAttrs), bLock=True)
        library.addStringAttr(sGrp, 'deleteNodes', str(sDeleteNodes), bLock=True)

    
        
        
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


# DEPRICATED. we just keep it here for backup
def attachToRokokoBody(sCharNamespace=''):
    print('in function...')

    sSel = cmds.ls(sl=True)
    if len(sSel) > 1:
        cmds.confirmDialog(m='Select only one node of the mocap rig. \nAnd make sure it has that namespace!')
        return

    sRokokoNamespace = library.getNamespace(sSel[0])
    sObj = sSel[0].split(':')[-1]
    if '_' in sObj:
        sRokokoNamespace = '%s%s_' % (sRokokoNamespace, sObj.split('_')[0])

    sAllMocapJoints = cmds.ls('%s*' % sRokokoNamespace, et='joint')
    print ('sAllMocapJoints: ', sAllMocapJoints)
    for sJ in sAllMocapJoints:
        cmds.setAttr('%s.r' % sJ, 0,0,0)
    print ('finished setting Joints to 0')
    sRokToes = _getRokokoJoints(sRokokoNamespace, ['Toe', 'ToeBase'], True)
    sRokHip = _getRokokoJoints(sRokokoNamespace, ['Hips'], False)

    cmds.setAttr('%s.tx' % sRokHip, 0.0)
    sDefaultToeY = cmds.xform(sRokToes[0], q=True, ws=True, t=True)[1]
    cmds.move(0,-sDefaultToeY,0, sRokHip, r=True, ws=True)


    sMaster = library.getMasterName(sCharNamespace)
    sMocapAttr = '%s.mocapArmT' % sMaster
    if not cmds.objExists(sMocapAttr):
        cmds.confirmDialog(m='This character is not setup for mocap.')
        return
    dPoseTags = eval(cmds.getAttr(sMocapAttr))

    sOldNodes = [sN for sN in cmds.ls() if cmds.objExists('%s.motionCaptureRetarget' % sN) and cmds.getAttr('%s.motionCaptureRetarget' % sN) == sCharNamespace]
    cmds.delete(sOldNodes)
    goToDefaultPose(sCharNamespace)

    sNodesBefore = cmds.ls()
    cmds.undoInfo(openChunk=True)
    try:
        sBakeAttrs = []
        sGrp = cmds.createNode('transform', n='%sretarget' % sCharNamespace)

        sRokShins = _getRokokoJoints(sRokokoNamespace, ['Shin', 'Leg'], True)
        sRokFeet = _getRokokoJoints(sRokokoNamespace, ['Foot'], True)
        sRokToes = _getRokokoJoints(sRokokoNamespace, ['Toe', 'ToeBase'], True)


        fRokokoLegLength = library.listVectorLength(cmds.getAttr('%s.t' % sRokShins[0])[0]) + library.listVectorLength(cmds.getAttr('%s.t' % sRokFeet[0])[0])
        fCharLegLength = library.getDistanceBetween('%sjnt_l_legWrist' % sCharNamespace, '%sjnt_l_leg_lowerTwist_000' % sCharNamespace) + \
                         library.getDistanceBetween('%sjnt_l_leg_lowerTwist_000' % sCharNamespace, '%sjnt_l_leg_upperTwist_000' % sCharNamespace)

        fCharRatio = fCharLegLength / fRokokoLegLength

        # feet
        for s,sSide in enumerate(['l','r']):
            # sRokTip = '%s%sToeTip' % (sRokokoNamespace, library.sSides4[s])
            # sRokToe = '%s%sToe' % (sRokokoNamespace, library.sSides4[s])
            sRokTip = sRokToes[s]
            sRokToe = sRokToes[s]
            sRokFoot = sRokFeet[s] #'%s%sFoot' % (sRokokoNamespace, library.sSides4[s])
            sFootIk = library.translateSideName('%slegIk%s_ctrl' % (sCharNamespace, library.sSides3[s]))

            sScaledTip = library.createVectorMultiplyNode(library.createDecomposeMatrix('%s.worldMatrix' % sRokTip), fCharRatio, bVectorByScalar=True)
            sLocTip = cmds.spaceLocator(n='loc_%s_tip' % sSide)[0]
            sLocHeel = cmds.spaceLocator(n='loc_%s_heel' % sSide)[0]
            cmds.parent(sLocTip, sLocHeel, sGrp)
            cmds.connectAttr(sScaledTip, '%s.t' % sLocTip)
            cmds.orientConstraint(sRokTip, sLocTip)

            fHeelInTipOffset = library.createMultMatrixNode(['%s.worldMatrix' % sFootIk, '%s.worldInverseMatrix' % sLocTip], bJustValues=True)
            fHeelInTip = library.createMultMatrixNode([fHeelInTipOffset, '%s.worldMatrix' % sLocTip])

            library.createDecomposeMatrix(fHeelInTip, sTargetPos='%s.t' % sLocHeel, sTargetRot='%s.r' % sLocHeel)
            cmds.parentConstraint(sLocHeel, sFootIk, mo=True)

            # twistDetector(sRokFoot, sRokTip)

            fHeelInToePointDefault = library.createPointByMatrixNode(library.getWorldPoint(sRokFoot), '%s.worldInverseMatrix' % sRokToe, bJustValues=True)
            fLength = library.listVectorLength(fHeelInToePointDefault)
            fHeelInToePointDefaultNorm = [fHeelInToePointDefault[0] / fLength, fHeelInToePointDefault[1] / fLength, fHeelInToePointDefault[2] / fLength]
            sHeelInToe = library.createPointByMatrixNode(library.getWorldPoint(sRokFoot), '%s.worldInverseMatrix' % sRokToe)
            sHeelInToeNorm = library.createVectorMultiplyNode(sHeelInToe, library.createDistanceNode(sRokFoot, sRokToe), bVectorByScalar=True)
            sAngle = library.createAngleNode(sHeelInToeNorm, fHeelInToePointDefaultNorm)
            cmds.connectAttr(sAngle, '%s.ballRoll' % sFootIk, force=True)
            for sAttr in ['tx','ty','tz','rx','ry','rz', 'ballRoll']:
                sBakeAttrs.append('%s.%s' % (sFootIk, sAttr))

        # hip
        sRokHip = _getRokokoJoints(sRokokoNamespace, ['Hips'], False)
        sLocHip = cmds.spaceLocator(n='loc_m_hip')[0]
        cmds.parent(sLocHip, sGrp)
        sCogCtrl = '%scog_ctrl' % sCharNamespace
        library.createVectorMultiplyNode(library.createDecomposeMatrix('%s.worldMatrix' % sRokHip), fCharRatio, bVectorByScalar=True, sTarget='%s.t' % sLocHip)
        cmds.parentConstraint(sRokHip, sLocHip, mo=True, skipTranslate=['x','y','z'])
        cmds.parentConstraint(sLocHip, sCogCtrl, mo=True)
        for sAttr in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']:
            sBakeAttrs.append('%s.%s' % (sCogCtrl, sAttr))

        # torso
        for sRokJointOptions, sCtrl in [(['Spine', 'Spine1'], 'spineSplineFk_A_ctrl'), (['Spine2'], 'spineSplineFk_B_ctrl'), (['Spine4', 'Spine1'], 'spineSplineFk_C_ctrl')]:
            sRokJoint = _getRokokoJoints(sRokokoNamespace, sRokJointOptions, False, bReturnNonIfNotExist=True)
            sCtrl = '%s%s' % (sCharNamespace, sCtrl)
            if sRokJoint != None and cmds.objExists(sCtrl):
                cmds.orientConstraint(sRokJoint, sCtrl, mo=True)
                for sAttr in ['rx','ry','rz']:
                    sBakeAttrs.append('%s.%s' % (sCtrl, sAttr))


        # clavicle
        sRokClavs = _getRokokoJoints(sRokokoNamespace, ['Shoulder'], True)
        for s,sSide in enumerate(['l','r']):
            sClavCtrl = library.translateSideName('%sclavicle%s_ctrl' % (sCharNamespace, library.sSides3[s]))
            cmds.orientConstraint(sRokClavs[s], sClavCtrl, mo=True)
            for sAttr in ['rx', 'ry', 'rz']:
                sBakeAttrs.append('%s.%s' % (sClavCtrl, sAttr))

        # arms
        # fHandOffsets = [[90,180,0],[-90,180,0]]

        sRokUpperArms = _getRokokoJoints(sRokokoNamespace, ['Arm'], True)
        sRokElbows = _getRokokoJoints(sRokokoNamespace, ['ForeArm'], True)
        sRokHands = _getRokokoJoints(sRokokoNamespace, ['Hand'], True)
        for s,sSide in enumerate(['l','r']):
            sIkCtrl = library.translateSideName('%sarmIk%s_ctrl' % (sCharNamespace, library.sSides3[s]))

            for sAttr in ['tx','ty','tz', 'rx', 'ry', 'rz']:
                sBakeAttrs.append('%s.%s' % (sIkCtrl, sAttr))


            cmds.setAttr('%s.softIk' % sIkCtrl, 0.001)
            sPoleCtrl = library.translateSideName('%sarmPoleSuper%s_ctrl' % (sCharNamespace, library.sSides3[s]))
            cmds.setAttr(library.translateSideName('%sarmPole%s_ctrl.superVIS' % (sCharNamespace, library.sSides3[s])), True)

            for sAttr in ['tx','ty','tz']:
                sBakeAttrs.append('%s.%s' % (sPoleCtrl, sAttr))

            cmds.setAttr(library.translateSideName('%sarmGlobal%s_ctrl.fk2ik' % (sCharNamespace, library.sSides3[s])), 1)
            sLocUpper = cmds.spaceLocator(n='loc_%s_upperArm' % sSide)[0]
            cmds.delete(cmds.pointConstraint('%sjnt_%s_arm_upperTwist_000' % (sCharNamespace,sSide), sLocUpper))
            cmds.parentConstraint('%sjnt_m_spineSpine_end' % sCharNamespace, sLocUpper, skipRotate=['x','y','z'], mo=True)
            cmds.orientConstraint(sRokUpperArms[s], sLocUpper)
            sLocLower = cmds.spaceLocator(n='loc_%s_elbow' % sSide)[0]
            cmds.parent(sLocLower, sLocUpper)

            fCharUpperLength = library.getDistanceBetween('%sjnt_%s_arm_lowerTwist_000' % (sCharNamespace,sSide),
                                         '%sjnt_%s_arm_upperTwist_000' % (sCharNamespace, sSide))
            fRokElbowLocal = cmds.getAttr('%s.t' % sRokElbows[s])[0]
            iAxis, iSignFactor = library.getBiggestIndex(fRokElbowLocal)
            fLocLowerTranslation = [0,0,0]
            fLocLowerTranslation[iAxis] = fCharUpperLength * iSignFactor


            cmds.setAttr('%s.t' % sLocLower, *fLocLowerTranslation)
            cmds.orientConstraint(sRokElbows[s], sLocLower)

            sLocWrist = cmds.spaceLocator(n='loc_%s_wrist' % sSide)[0]
            cmds.parent(sLocWrist, sLocLower)
            fCharLowerLength = library.getDistanceBetween('%sjnt_%s_arm_lowerTwist_000' % (sCharNamespace,sSide),
                                         '%sjnt_%s_armWrist' % (sCharNamespace, sSide))
            iAxis, iSignFactor = library.getBiggestIndex(cmds.getAttr('%s.t' % sRokHands[s])[0])
            fLocHandTranslation = [0,0,0]
            fLocHandTranslation[iAxis] = fCharLowerLength * iSignFactor
            cmds.setAttr('%s.t' % sLocWrist, *fLocHandTranslation)

            cmds.pointConstraint(sLocWrist, sIkCtrl)
            # cmds.pointConstraint(sLocLower, sPoleCtrl)

            sGrpMiddle = cmds.createNode('transform', n='grp_%s_elbowMiddle' % sSide)
            library.createVectorMultiplyNode(library.createVectorAdditionNode([library.getWorldPoint(sLocUpper), library.getWorldPoint(sLocWrist)]), 0.5, bVectorByScalar=True, sTarget='%s.t' % sGrpMiddle)
            sAimElbow = cmds.createNode('transform', n='grp_%s_aimMiddle' % sSide, p=sGrpMiddle)
            sOrientWrist = cmds.createNode('transform', n='grp_%s_orientWrist' % sSide, p=sGrpMiddle)
            cmds.orientConstraint(sRokHands[s], sOrientWrist, mo=True)
            cmds.aimConstraint(sLocLower, sAimElbow)
            # sBlend = cmds.createNode(n='grp_%s_blendMiddle', p=sGrpMiddle)
            sLocPole = cmds.spaceLocator(n='loc_%s_poleA' % sSide)[0]
            cmds.parent(sLocPole, sAimElbow)
            sLocPoleB = cmds.spaceLocator(n='loc_%s_poleB' % sSide)[0]
            cmds.parent(sLocPoleB, sOrientWrist)

            cmds.setAttr('%s.t' % sLocPole, fCharUpperLength+fCharLowerLength,0,0)

            cmds.setAttr('%s.t' % sLocPoleB, 0,0,-(fCharUpperLength+fCharLowerLength))
            sPoleConstraint = cmds.pointConstraint(sLocPole, sLocPoleB, sPoleCtrl)[0]

            # get elbow angle
            sUpperPoint = library.createVectorAdditionNode([library.getWorldPoint(sLocUpper), library.getWorldPoint(sLocLower)], sOperation='minus')
            sLowerPoint = library.createVectorAdditionNode([library.getWorldPoint(sLocWrist), library.getWorldPoint(sLocLower)], sOperation='minus')
            cmds.addAttr(sGrp, ln='%s_elbowAngle' % sSide, k=True)
            sAngle = '%s.%s_elbowAngle' % (sGrp, sSide)
            library.createAdditionNode([180, library.createAngleNode(sUpperPoint, sLowerPoint)], sOperation='minus', sTarget=sAngle)
            sPoleStrengthA = library.createRangeNode(sAngle, 0,35, 0, 1)
            cmds.connectAttr(sPoleStrengthA, '%s.%sW0' % (sPoleConstraint,sLocPole))
            library.createReverseNode(sPoleStrengthA, sTarget='%s.%sW1' % (sPoleConstraint,sLocPoleB))

            # hand
            sLeftArmIk = library.translateSideName('%sarmIkLFT_ctrl' % sCharNamespace).split(':')[-1]
            cmds.setAttr('%s.t' % sIkCtrl, *(dPoseTags['%s.t' % sLeftArmIk]))
            cmds.setAttr('%s.r' % sIkCtrl, *(dPoseTags['%s.r' % sLeftArmIk]))
            cmds.orientConstraint(sRokHands[s], sIkCtrl, mo=True)
            # cmds.setAttr('%s.offset' % sOrientConstraint, fHandOffsets[s][0], fHandOffsets[s][1], fHandOffsets[s][2])

            cmds.parent(sLocUpper, sGrpMiddle, sGrp)


        print('\n\n\n')
        # fingers
        # Character1_LeftHandIndex2
        for sRokFingerOptions,sCharFinger in [(['Finger1','HandThumb',],'thumb'), (['Finger2','HandIndex'], 'index'), (['Finger3','HandMiddle'],'middle'),
                                              (['Finger4','HandRing'], 'ring'), (['Finger5','HandPinky'],'pinky')]:
            for sRokNameOptions, sCharBone in [(['Proximal','1'], 'Base'), (['Medial','2'], 'Mid'), (['Distal','3'], 'Tip')]:
                print('sRokFingerOptions: ', sRokFingerOptions)
                sOptions = ['%s%s' % (sRokFingerOptions[0], sRokNameOptions[0]), '%s%s' % (sRokFingerOptions[1], sRokNameOptions[1])]
                sRokJoints = _getRokokoJoints(sRokokoNamespace, sOptions, True, bReturnNonIfNotExist=True)
                for s,sSide in enumerate(['l','r']):
                    if sRokJoints[s] == None:
                        continue
                    # sRokJoint = '%s%sFinger%s%s' % (sRokokoNamespace, library.sSides4[s], sRokIndex, sRokName)
                    sCharCtrl = library.translateSideName('%s%s%s%s_ctrl' % (sCharNamespace, sCharFinger, sCharBone, library.sSides3[s]), bErrorIfNotExist=False)
                    if sCharCtrl == None:
                        continue
                    sKey = '%s.r' % sCharCtrl.split(':')[-1]
                    if sSide == 'r':
                        sKey = sKey.replace('RGT','LFT')
                    if sKey in dPoseTags:
                        cmds.setAttr('%s.r' % sCharCtrl, *(dPoseTags[sKey]))

                    print('finger ssRokJoints[s]: ', sRokJoints[s], sCharCtrl)
                    if cmds.objExists(sRokJoints[s]) and cmds.objExists(sCharCtrl):
                        try:
                            cmds.orientConstraint(sRokJoints[s], sCharCtrl, mo=True)
                            for sAttr in ['rx', 'ry', 'rz']:
                                sBakeAttrs.append('%s.%s' % (sCharCtrl, sAttr))

                        except:
                            pass

        # head
        sNeckBaseCtrls = ['%sneckBaseIk_ctrl' % sCharNamespace, '%sneckA_ctrl' % sCharNamespace]
        for sNeckIk in sNeckBaseCtrls:
            if cmds.objExists(sNeckIk):
                cmds.orientConstraint('%sNeck' % sRokokoNamespace, sNeckIk, mo=True)
                for sAttr in ['rx', 'ry', 'rz']:
                    sBakeAttrs.append('%s.%s' % (sNeckIk, sAttr))
                break
        for sNeckTopIk in ['%sneckTopIk_ctrl' % sCharNamespace, '%shead_ctrl' % sCharNamespace]:
            if cmds.objExists(sNeckTopIk):
                cmds.orientConstraint('%sHead' % sRokokoNamespace, sNeckTopIk, mo=True)
                for sAttr in ['rx', 'ry', 'rz']:
                    sBakeAttrs.append('%s.%s' % (sNeckTopIk, sAttr))
                break

        library.addStringAttr(sGrp, 'bakeAttrs', str(sBakeAttrs), bLock=True)
    except:
        cmds.confirmDialog(title='Error',
                            message='some errors happened, please check script editor')
        raise
    finally:
        cmds.undoInfo(closeChunk=True)
        sNodesAfter = cmds.ls()
        sNewNodes = set(sNodesAfter) - set(sNodesBefore)
        for sNode in sNewNodes:
            library.addStringAttr(sNode, 'motionCaptureRetarget', sCharNamespace, bLock=True)



def rokokoBodyBakeHumanIk(sCharNamespace):
    sJoints = cmds.ls('%shumanIk:Reference' % sCharNamespace, dag=True, et='joint')
    
    sBakeAttrs = []
    for sJ in sJoints:
        sBakeAttrs.append('%s.t' % sJ)
        sBakeAttrs.append('%s.r' % sJ)
        sBakeAttrs.append('%s.s' % sJ)

    iRange = library.getTimeSliderRange()
    cmds.bakeResults(sBakeAttrs, t=iRange, simulation=True)


def bakeRokokoBody(sCharNamespace):
    sGrp = '%sretarget' % sCharNamespace
    cmds.undoInfo(openChunk=True)
    try:
        cmds.ogs(pause=1)
        
        sBakeAttrs = eval(cmds.getAttr('%s.bakeAttrs' % sGrp))
        # iRange = (int(cmds.playbackOptions(q=True, minTime=True)),
        #           int(cmds.playbackOptions(q=True, maxTime=True)))
        iRange = library.getTimeSliderRange()

        cmds.bakeResults(sBakeAttrs, t=iRange, simulation=True)


        sOldNodes = [sN for sN in cmds.ls() if cmds.objExists('%s.motionCaptureRetarget' % sN) and cmds.getAttr('%s.motionCaptureRetarget' % sN) == sCharNamespace]
        cmds.delete(sOldNodes)
    
        # if bChildConstraints: # we could remove this since it's always False
        #     # move anim from child to main ctrls:
        #     for s, sSide in enumerate(['l', 'r']):
        #         for sName in ['Upper', 'Elbow', 'Wrist']:
        #             sChildCtrl = '%sarm%sChild_%s_ctrl' % (sCharNamespace, sName, sSide)
        #             sCtrl = '%sarm%s_%s_ctrl' % (sCharNamespace, sName, sSide)
        #             sAttrs = ['rx', 'ry', 'rz'] if sName == 'Upper' else ['tx','ty','tz', 'rx', 'ry', 'rz']
        #             for sA in sAttrs:
        #                 sChildAttr = '%s.%s' % (sChildCtrl, sA)
        #                 sAttr = '%s.%s' % (sCtrl, sA)
        #                 sConns = cmds.listConnections(sChildAttr, s=True, d=False, p=True)
        #                 cmds.disconnectAttr(sConns[0], sChildAttr)
        #                 cmds.connectAttr(sConns[0], sAttr)
        #                 cmds.setAttr(sChildAttr, 0)
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    finally:
        cmds.undoInfo(closeChunk=True)
        cmds.ogs(pause=1)


def bakeRokokoFace(sCharNamespace):
    sGrp = '%sretargetFace' % sCharNamespace
    sBakeAttrs = eval(cmds.getAttr('%s.bakeAttrs' % sGrp))
    # iRange = (int(cmds.playbackOptions(q=True, minTime=True)),
    #           int(cmds.playbackOptions(q=True, maxTime=True)))
    iRange = library.getTimeSliderRange()
    
    cmds.bakeResults(sBakeAttrs, t=iRange, simulation=True)
    sOldNodes = [sN for sN in cmds.ls() if cmds.objExists('%s.motionCaptureRetargetFace' % sN) and cmds.getAttr('%s.motionCaptureRetargetFace' % sN) == sCharNamespace]
    cmds.delete(sOldNodes)



def createDummyBlendShape():
    sSphere = cmds.polySphere(n='dummyFace', ch=False)[0]
    sBlendShape = cmds.blendShape(sSphere)[0]
    sDummyTarget = cmds.polySphere(r=2)[0]
    for t,sTarget in enumerate(sAppleFaceBlendShapes):
        cmds.blendShape(sBlendShape, e=True, t=[sSphere, t, sDummyTarget, 1.0])
        cmds.aliasAttr('%s%s' % (sTarget[0].upper(), sTarget[1:]), '%s.w[%d]' % (sBlendShape, t))
    cmds.delete(sDummyTarget)
    cmds.select(sSphere)


def faceArCsvFile(sCharNamespace=''):
    sFilePath = QtWidgets.QFileDialog.getOpenFileName(None, "open file", None, '*.csv')[0]
    bAlwaysRedoImages = True
    bDefaultBlend = 1.0

    
    dData = library.readCsvFile(sFilePath)
    fFramesPerSecond, fFrameLength = library.getFrameRate()
    sDir = os.path.dirname(sFilePath)
    sFilePath = sFilePath.replace('\\\\', '\\')
    cmds.undoInfo(openChunk=True)
    try:
        sLoc = cmds.spaceLocator(n='appleFaceBlendshapes')[0]
        sGrp = cmds.createNode('transform', n='__appleFaceBlendshapeAnims__', p=sLoc)
    
        # GET JSON INFO
        sJsonFilePath = os.path.join(sDir, 'take.json')
        dJsonData = library.getJsonContent(sJsonFilePath)
    
        fLength = (library._stringTimeToFloat(dJsonData['endTimecode']) - library._stringTimeToFloat(dJsonData['startTimecode'])) / 60.0
        iInputFrameCount = len(dData[list(dData.keys())[0]])
        fInputFrameLength = fLength / iInputFrameCount
        fMayaDelta = fInputFrameLength * fFramesPerSecond
        cmds.playbackOptions(e=True, minTime=0.0, maxTime=iInputFrameCount*fMayaDelta)
    
    
        # ANIMATION
        sBlend = library.addAttr(sLoc, ln='blend', minValue=0.0, maxValue=1.0, defaultValue=bDefaultBlend, k=True)
        for sAttr, fValues in list(dData.items()):
            sLocAttr = library.addAttr(sLoc, ln=sAttr, minValue=0.0, maxValue=1.0, k=True)
            sGrpAttr = library.addAttr(sGrp, ln=sAttr, minValue=0.0, maxValue=1.0, k=True)
            for f,fV in enumerate(fValues):
                cmds.setKeyframe('%s.%s' % (sGrp, sAttr), t=f*fMayaDelta, v=fV)
            library.createBlendNode(sBlend, sGrpAttr, 0.0, sTarget=sLocAttr)
    
        attachToRokokoFace(sCharNamespace, sFaceArNode=sLoc)
    
    
        # MOVIE
        sFile = os.path.basename(sFilePath)
        sMovFile = os.path.join(sDir, '%s.mov' % sFile.split('.')[0])
        for sEnding in ['_cal.mov', '_neutral.mov', '_raw.mov']:
            sMovFile = sMovFile.replace(sEnding, '.mov')

        if not os.path.exists(sMovFile):
            raise Exception('movie file doesn\'t exist: %s' % sMovFile)
    
        sImageFilesDir = os.path.join(sDir, 'imageFiles')
        bDoImages = False
        if not os.path.exists(sImageFilesDir):
            os.makedirs(sImageFilesDir)
            bDoImages = True
        else:
            if bAlwaysRedoImages:
                bDoImages = True
                sContents = os.listdir(sImageFilesDir)
                for sC in sContents:
                    sPathC = os.path.join(sImageFilesDir, sC)
                    if os.path.isfile(sPathC):
                        os.remove(sPathC)
    
        if bDoImages:
            sOutFiles = os.path.join(sImageFilesDir, 'image%d.jpg')
            sFfmpegExe = library.getFfMpegExe()
            if not os.path.exists(sFfmpegExe):
                cmds.warning('%s not found, not creating images')
            sCommand = [sFfmpegExe, '-i', sMovFile, '-vf', 'fps=%0.3f' % fFramesPerSecond, sOutFiles]
            mpegProcess = subprocess.Popen(
                sCommand, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            sMpegProcessResult = mpegProcess.communicate()
            print(sMpegProcessResult[0])
            print(sMpegProcessResult[1])
    
        sImagePlane, sImagePlaneShape = cmds.imagePlane(w=float(1080)/1440, h=1)
        cmds.setAttr('%s.imageName' % sImagePlaneShape, os.path.join(sImageFilesDir, 'image1.jpg'), type='string')
        cmds.setAttr('%s.useFrameExtension' % sImagePlaneShape, True)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def importBlendshapeMeshAndConnect(sCharNamespace=''):
    sDir = os.path.dirname(__file__)

    sBlendshapeFile = os.path.join(sDir, 'headWithBlendShapes.ma')
    sRootName = 'RokokoFaceRoot'
    sOld = '%s%s' % (sCharNamespace, sRootName)
    
    if cmds.objExists(sOld):
        cmds.delete(sOld)
    
    sNodes = library.importMayaFiles(sBlendshapeFile, sNamespace=sCharNamespace[:-1] if sCharNamespace else None, bReturnAllNodes=True)
    for sN in sNodes:
        sNewName = '%s%s' % (sCharNamespace, sN.split(':')[-1])
        if sN != sNewName:
            cmds.rename(sN, sNewName)
    
    sFaceMesh = '%sface' % sCharNamespace
    cmds.select(sFaceMesh)

    attachToRokokoFace(sCharNamespace)



def attachToRokokoFace(sCharNamespace='', sFaceArNode=None):
    sMaster = library.getMasterName(sCharNamespace)
    dCharacterFacialMocapTags = eval(library.getStringAttr(sMaster, 'dCharacterFacialMocapTags', '{}'))
    dCharacterFacialMocapTagsDefaults = eval(library.getStringAttr(sMaster, 'dCharacterFacialMocapTagsDefaults', '{}'))

    sMetahumanFace = '%smetaHuman:headRig_grp' % sCharNamespace

    sSel = cmds.ls(sl=True)
    if sFaceArNode == None:
        for sObj in sSel:
            if sFaceArNode != None:
                break
            if cmds.objectType(sObj) == 'blendShape':
                sFaceArNode = sObj
            for sN in cmds.listHistory(sObj):
                if cmds.objectType(sN) == 'blendShape':
                    sFaceArNode = sN
    if sFaceArNode == None:
        cmds.confirmDialog(m='please select mesh with faceAR blendShape')
        return

    dConnections = {}

    print('now....')

    dDefaultValues = {}


    if cmds.objExists(sMetahumanFace):
        print('in it..')
        dConnections['BrowDownLeft'] = {'metaHuman:CTRL_L_brow_down.ty': 1.0}
        dConnections['BrowInnerUp'] = {'metaHuman:CTRL_L_brow_raiseIn.ty': 1.0, 'metaHuman:CTRL_R_brow_raiseIn.ty': 1.0}
        dConnections['BrowOuterUpLeft'] = {'metaHuman:CTRL_L_brow_raiseOut.ty': 1.0}
        dConnections['CheekPuff'] = {'metaHuman:CTRL_L_mouth_suckBlow.ty': 1.0, 'metaHuman:CTRL_R_mouth_suckBlow.ty': 1.0}
        dConnections['CheekSquintLeft'] = {'metaHuman:CTRL_L_eye_cheekRaise.ty': 1.0}
        dConnections['EyeBlinkLeft'] = {'metaHuman:CTRL_L_eye_blink.ty': -1.0}
        dConnections['EyeLookDownLeft'] = {'metaHuman:CTRL_L_eye.ty': -1.0}
        dConnections['EyeLookUpLeft'] = {'metaHuman:CTRL_L_eye.ty': 1.0}
        dConnections['EyeLookInLeft'] = {'metaHuman:CTRL_L_eye.tx': -1.0}
        dConnections['EyeLookInRight'] = {'metaHuman:CTRL_R_eye.tx': -1.0}
        dConnections['EyeLookOutLeft'] = {'metaHuman:CTRL_L_eye.tx': 1.0}
        dConnections['EyeLookOutRight'] = {'metaHuman:CTRL_R_eye.tx': -1.0}
        dConnections['EyeWideLeft'] = {'metaHuman:CTRL_L_eye_blink.ty': -1}

        dConnections['JawForward'] = {'metaHuman:CTRL_C_jaw_fwdBack.tz': -1.0}
        dConnections['JawLeft'] = {'metaHuman:CTRL_C_jaw.tx': -1.0}
        dConnections['JawRight'] = {'metaHuman:CTRL_C_jaw.tx': 1.0}
        dConnections['JawOpen'] = {'metaHuman:CTRL_C_jaw.ty': 1}

        # dConnections['mouthClose'] = {'Jaw_ctrl.mouthClose': 1}

        dConnections['MouthDimpleLeft'] = {'metaHuman:CTRL_L_mouth_dimple.ty': 1}
        dConnections['MouthFrownLeft'] = {'metaHuman:CTRL_L_mouth_cornerDepress.ty': -1}

        dConnections['MouthFunnel'] = {'metaHuman:CTRL_L_mouth_funnelD.ty': 1, 'metaHuman:CTRL_R_mouth_funnelD.ty': 1,
                                       'metaHuman:CTRL_L_mouth_funnelU.ty': 1, 'metaHuman:CTRL_R_mouth_funnelU.ty': 1}

        dConnections['MouthPucker'] = {'metaHuman:CTRL_L_mouth_purseD.ty': 1, 'metaHuman:CTRL_R_mouth_purseD.ty': 1,
                                       'metaHuman:CTRL_L_mouth_purseU.ty': 1, 'metaHuman:CTRL_R_mouth_purseU.ty': 1}

        dConnections['MouthLeft'] = {'metaHuman:CTRL_C_mouth.tx': 1.0}
        dConnections['MouthRight'] = {'metaHuman:CTRL_C_mouth.tx': -1.0}

        # dConnections['MouthRollLower'] = {'mouthBot_ctrl.tz': -1.0}
        # dConnections['MouthRollUpper'] = {'mouthTop_ctrl.tz': -1.0}

        dConnections['MouthSmileLeft'] = {'metaHuman:CTRL_L_mouth_cornerPull.ty': 1.0}

        dConnections['MouthUpperUpLeft'] = {'metaHuman:CTRL_L_mouth_upperLipRaise.ty': 1.0}
        dConnections['MouthLowerDownLeft'] = {'metaHuman:CTRL_L_mouth_lowerLipDepress.ty': 1.0}
    else:
        dConnections['HeadYaw'] = {'head_ctrl.ry': [-90,90]}
        dConnections['HeadPitch'] = {'head_ctrl.rx': [-90,90]}
        dConnections['HeadRoll'] = {'head_ctrl.rz': [-90,90]}
    
        dConnections['BrowDownLeft'] = {'innerEyebrow_l_ctrl.ty':-1.0}
        dConnections['BrowInnerUp'] = {'innerEyebrow_l_ctrl.ty':1.0, 'innerEyebrow_r_ctrl.ty':1.0}
        dConnections['BrowOuterUpLeft'] = {'outerEyebrow_l_ctrl.ty':1.0}
        dConnections['CheekPuff'] = {'puff_l_ctrl.ty':1.0, 'puff_r_ctrl.ty':1.0}
        dConnections['CheekSquintLeft'] = {'cheekRaiser_l_ctrl.ty':1.0}
        dConnections['EyeBlinkLeft'] = {'blink_l_ctrl.ty':-1.0}
        dConnections['EyeLookDownLeft'] = {'eyesLookAt_l_ctrl.ty':-15.0}
        dConnections['EyeLookUpLeft'] = {'eyesLookAt_l_ctrl.ty':15.0}
        dConnections['EyeLookInLeft'] = {'eyesLookAt_l_ctrl.tx':-15.0}
        dConnections['EyeLookOutLeft'] = {'eyesLookAt_l_ctrl.tx':15.0}
        dConnections['EyeWideLeft'] = {'blink_l_ctrl.ty':0.5}

        fJawMatrix = cmds.xform('%sjaw_ctrl' % sCharNamespace, q=True, ws=True, m=True)
        if fJawMatrix[2*4 + 0] < -0.9: # x value axis of z axis, orienting along z axis
            dConnections['JawForward'] = {'jaw_ctrl.tx':1.0}
            dConnections['JawLeft'] = {'jaw_ctrl.tz':-1.0}
            dConnections['JawRight'] = {'jaw_ctrl.tz':1.0}
            dConnections['JawOpen'] = {'jaw_ctrl.rz':-15}
        else:   # fJawMatrix[0*4 + 0] > 0.9: # orienting along x axis
            dConnections['JawForward'] = {'jaw_ctrl.ty':1.0}
            dConnections['JawLeft'] = {'jaw_ctrl.tx':1.0}
            dConnections['JawRight'] = {'jaw_ctrl.tx':-1.0}
            dConnections['JawOpen'] = {'jaw_ctrl.rx':15}

        # dConnections['JawOpen'] = {'jaw_ctrl.rx':15}
        dConnections['MouthClose'] = {'jaw_ctrl.mouthClose':1}

        dConnections['MouthDimpleLeft'] = {'lipsCorner_l_ctrl.tx':1}
        dConnections['MouthFrownLeft'] = {'lipsCorner_l_ctrl.ty':-1}

        dConnections['MouthFunnel'] = {'mouth_ctrl.tz':1}
        dConnections['MouthPucker'] = {'lipsCorner_l_ctrl.tx':-1, 'lipsCorner_r_ctrl.tx':-1}

        dConnections['MouthLeft'] = {'mouth_ctrl.tx':1.0}
        dConnections['MouthRight'] = {'mouth_ctrl.tx':-1.0}

        dConnections['MouthRollLower'] = {'mouthBot_ctrl.tz':-1.0}
        dConnections['MouthRollUpper'] = {'mouthTop_ctrl.tz':-1.0}


        dConnections['MouthSmileLeft'] = {'lipsCorner_l_ctrl.ty':0.5}

        dConnections['MouthUpperUpLeft'] = {'lipsTop_l_ctrl.ty':1.0}

        dConnections['MouthLowerDownLeft'] = {'lipsBot_l_ctrl.ty':-1.0}


    dConnectionsMirrored = {}
    for sTarget, dPose in list(dConnections.items()):
        dConnectionsMirrored[sTarget] = dict(dPose)
        if sTarget.endswith('Left'):
            sTargetRight = '%sRight' % sTarget[:-len('Left')]
            if sTargetRight not in dConnections:
                dPoseRight = {}
                for sCtrl,fValue in list(dPose.items()):
                    sMirrorCtrl = sCtrl.replace('_l_','_r_').replace('_L_', '_R_')
                    dPoseRight[sMirrorCtrl] = fValue
                dConnectionsMirrored[sTargetRight] = dPoseRight

    dConnectionsMirrored.update(dCharacterFacialMocapTags)
    dDefaultValues.update(dCharacterFacialMocapTagsDefaults)

    cmds.undoInfo(openChunk=True)

    try:

        sOldNodes = [sN for sN in cmds.ls() if cmds.objExists('%s.motionCaptureRetargetFace' % sN) and cmds.getAttr(
            '%s.motionCaptureRetargetFace' % sN) == sCharNamespace]
        cmds.delete(sOldNodes)

        sBakeAttrs = []


        sNodesBefore = cmds.ls()

        sGrp = cmds.createNode('transform', n='%sretargetFace' % sCharNamespace)

        dProducts = defaultdict(list)
        for sT,dP in list(dConnectionsMirrored.items()):
            for sA,fV in list(dP.items()):
                fDefaultValue = dDefaultValues.get(sA, 0)
                sPossibleTargets = ['%s.%s' % (sFaceArNode, sT), '%s.%s%s' % (sFaceArNode, sT[0].lower(), sT[1:])]
                
                print ('sPossibleTargets[0]: ', sPossibleTargets[0], sPossibleTargets[1])
                if cmds.objExists(sPossibleTargets[0]):
                    sFoundTarget = sPossibleTargets[0]
                elif cmds.objExists(sPossibleTargets[1]):
                    sFoundTarget = sPossibleTargets[1]
                else: # this could be the head rotations that don't exist as blendShapes
                    continue
                    
                if isinstance(fV, (list, tuple)):
                    dProducts[sA].append(library.createRangeNode(sFoundTarget, 0, 1, 0, fV[0] - fDefaultValue))
                    dProducts[sA].append(library.createRangeNode(sFoundTarget, 0, -1, 0, fV[1] - fDefaultValue))
                else:
                    dProducts[sA].append(library.createRangeNode(sFoundTarget, 0, 1, 0, fV - fDefaultValue))


        print('dProducts: ', dProducts)
        for sA,sProducts in list(dProducts.items()):
            sCtrlAttr = '%s%s' % (sCharNamespace,sA)
            if cmds.objExists(sCtrlAttr):
                fDefaultValue = dDefaultValues.get(sA, 0)
                if fDefaultValue:
                    sProducts.append(fDefaultValue)
                sAdditionNode = library.createAdditionNode(sProducts, sTarget=sCtrlAttr)
                sBakeAttrs.append(sCtrlAttr)

        library.addStringAttr(sGrp, 'bakeAttrs', str(sBakeAttrs), bLock=True)

        sEyeLookatSpaceAttr = '%seyesLookAt_ctrl.space' % sCharNamespace
        if cmds.objExists(sEyeLookatSpaceAttr):
            cmds.setAttr(sEyeLookatSpaceAttr, 0)

    except:
        cmds.confirmDialog(title='Error',
                           message='some errors happened, please check script editor')
        raise
    finally:
        cmds.undoInfo(closeChunk=True)
        sNodesAfter = cmds.ls()
        sNewNodes = set(sNodesAfter) - set(sNodesBefore)
        for sNode in sNewNodes:
            library.addStringAttr(sNode, 'motionCaptureRetargetFace', sCharNamespace, bLock=True)




'''
import kangarooAnimation.KangarooMatchTools as matchTools
import importlib
importlib.reload(matchTools)
matchTools.switchLimb('', 'l', 'arm')
'''


