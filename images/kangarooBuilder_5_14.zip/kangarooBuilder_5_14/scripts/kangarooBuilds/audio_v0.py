###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from collections import OrderedDict, defaultdict
import numpy as np
import kangarooTools.patch as patch

import kangarooTabTools.builder as builderTools

import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.geometry as geometry

# import kangarooTabTools.poser as poser

iColorIndexCtrls = 0
bPolyCtrls = False
kBuilderColor = utils.uiColors.yellow  # '#39a9f4'

kFaceDataNode = '__faceData__'




def fillPose(sPosesKey, sCtrls, _uiArgs=None, _report=None):
    dAvailableAttrs = getAvailablePhoneticAttrs()

    dPose = {}
    for sCtrl, sAttrs in list(dAvailableAttrs.items()):
        dNewPose = {}
        print('sCtrl: ', sCtrl, sAttrs)
        for sA in sAttrs:

            fValue = cmds.getAttr('%s.%s' % (sCtrl,sA))
            cC = ctrls.ctrlFromName(sCtrl)
            sPhonetics = cC.getOffsetByName('phonetics', bReturnNoneIfNotExists=True)
            if sPhonetics:
                if sA.startswith('scale'):
                    fValue *= cmds.getAttr('%s.%s' % (sPhonetics,sA))
                else:
                    fValue += cmds.getAttr('%s.%s' % (sPhonetics,sA))

            if (sA.startswith('scale') and abs(fValue-1.0) > 0.0001) or \
            (not sA.startswith('scale') and abs(fValue) > 0.0001):
                print('sCtrl: ', sCtrl)
                print('sA: ', sA)
                dNewPose[sA] = round(fValue, 5)
        if dNewPose:
            dPose[sCtrl] = dNewPose

    _uiArgs[sPosesKey].setText(str(dPose))

    _report.addLogText(str(dPose))


def getAvailablePhoneticAttrs():
    dAttrs = {}
    dAttrs['ctrl_l_lipsCorner'] = ['translateY', 'tangentBot', 'tangentTop', 'rotateZ']
    dAttrs['ctrl_l_lipsCorner'] = ['translateY', 'tangentBot', 'tangentTop', 'rotateZ']
    dAttrs['ctrl_m_mouth'] = ['rollTopRight', 'rollTopLeft', 'rollBotRight', 'rollBotLeft', 'translateZ']
    sMiddleCtrlAttrs = ['translateX', 'translateY', 'translateZ', 'rotateX', 'rotateY', 'rotateZ', 'scaleY', 'scaleZ']
    dAttrs['ctrl_l_lipsTop'] = sMiddleCtrlAttrs
    dAttrs['ctrl_r_lipsTop'] = sMiddleCtrlAttrs
    dAttrs['ctrl_l_lipsBot'] = sMiddleCtrlAttrs
    dAttrs['ctrl_m_lipsBot'] = sMiddleCtrlAttrs
    dAttrs['ctrl_m_lipsTop'] = sMiddleCtrlAttrs
    dAttrs['ctrl_r_lipsBot'] = sMiddleCtrlAttrs
    dAttrs['ctrl_l_puff'] = ['translateZ']

    sDetails = cmds.ls('ctrl_?_???LipDetailVtx_???', et='transform')
    for sD in sDetails:
        dAttrs[sD] = ['translateX', 'translateY', 'translateZ', 'rotateX', 'rotateY', 'rotateZ']

    return dAttrs


def posePhoneticsToDefault():
    for sCtrl, sAttrs in list(getAvailablePhoneticAttrs().items()):
        for sA in sAttrs:
            if sA.startswith('scale'):
                cmds.setAttr('%s.%s' % (sCtrl, sA), 1.0)
            else:
                cmds.setAttr('%s.%s' % (sCtrl, sA), 0.0)


def posePhoneticPose(dDict):
    posePhoneticsToDefault()

    for sCtrl, dPoses in list(dDict.items()):
        for sA,fF in list(dPoses.items()):
            sFullA = '%s.%s' % (sCtrl,sA)
            cmds.setAttr(sFullA, fF)


def poseFf(dFf):
    posePhoneticPose(dFf)


def poseRr(dRr):
    posePhoneticPose(dRr)


def poseBp(dBp):
    posePhoneticPose(dBp)


def poseForward(dForward):
    posePhoneticPose(dForward)


def fillFf(_uiArgs=None, _report=None):
    fillPose('dFf', getAvailablePhoneticAttrs(), _uiArgs=_uiArgs, _report=_report)
fillFf.dSideButtons = {'pose to':poseFf}


def fillRr(_uiArgs=None, _report=None):
    fillPose('dRr', getAvailablePhoneticAttrs(), _uiArgs=_uiArgs, _report=_report)
fillRr.dSideButtons = {'pose to':poseRr}


def fillBp(_uiArgs=None, _report=None):
    fillPose('dBp', getAvailablePhoneticAttrs(), _uiArgs=_uiArgs, _report=_report)
fillBp.dSideButtons = {'pose to':poseBp}


def fillForward(_uiArgs=None, _report=None):
    fillPose('dForward', getAvailablePhoneticAttrs(), _uiArgs=_uiArgs, _report=_report)
fillForward.dSideButtons = {'pose to':poseForward}



def poseToF(bJawClosedOnF):
    try:
        cmds.undoInfo(openChunk=True)
        dDict = utils.createDictFromDecodedAudioLipsString(cmds.getAttr('grp_m_audioPasser.__dict__'))
        if bJawClosedOnF:
            cmds.setAttr('ctrl_m_jaw.rotateX', 0.0)
        else:
            cmds.setAttr('ctrl_m_jaw.rotateX', dDict['fJawMaxOpen'][0] * 0.125 * 2.0)

        iInd = 0 if bJawClosedOnF else 1
        cmds.setAttr('ctrl_m_mouthTop.translateY', dDict['fFffTopY'][iInd])
        cmds.setAttr('ctrl_m_mouthBot.translateY', dDict['fFffBotY'][iInd])
        cmds.setAttr('ctrl_m_mouthBot.translateZ', dDict['fFffBotZ'][iInd])
        cmds.setAttr('ctrl_m_audio.ff', 1.0)
        cmds.setAttr('ctrl_m_audio.enabled', 1.0)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def poseToDefault():
    try:
        cmds.undoInfo(openChunk=True)

        cmds.setAttr('ctrl_m_jaw.rotateX', 0.0)
        cmds.setAttr('ctrl_m_mouthTop.translateY', 0.0)
        cmds.setAttr('ctrl_m_mouthBot.translateY', 0.0)
        cmds.setAttr('ctrl_m_mouthBot.translateZ', 0.0)

        posePhoneticsToDefault()
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def mirrorPhoneticCtrls():

    sCtrls = list(getAvailablePhoneticAttrs().keys())
    sMirrorCtrls = []

    for sCtrl in sCtrls:
        if utils.getSide(sCtrl) == 'l':
            sMirrorCtrls.append(sCtrl)
    ctrls.mirrorAnimation(_sCtrls=sMirrorCtrls)




def removePhoneticCtrlPoses(_report=None):

    sPrevNodes = [sN for sN in cmds.ls('PHONETICPOSES_*') if cmds.objExists('%s.PHONETICPOSESATTR' % sN)]
    if sPrevNodes:
        if _report: _report.addLogText('deleteing %d old nodes' % len(sPrevNodes))
        cmds.delete(sPrevNodes)

    for sCtrl, sAttrs in list(getAvailablePhoneticAttrs().items()):
        sOffset = ctrls.ctrlFromName(sCtrl).getOffsetByName('phonetic')
        for sA in sAttrs:
            sOffsetAttr = '%s.%s' % (sOffset,sA)
            print('sOffsetAttr: ', sOffsetAttr)

            nodes.deleteConnection(sOffsetAttr)
            if sA.startswith('scale'):
                cmds.setAttr(sOffsetAttr, 1.0)
            else:
                cmds.setAttr(sOffsetAttr, 0.0)


removePhoneticCtrlPoses.dSideButtons = {'?':['Removes the current poses. This is also being called at the beginning of he ctrlPhoneticPoses() function']}


dButtons = OrderedDict()
dButtons['pose main ctrls to F open'] = lambda:poseToF(False)
dButtons['pose main ctrls to F open'].xHelp = ['This is to help creating the ff poses. It takes the values from the data inside the rig that '\
                 'was generated in createAudioCtrls()']
dButtons['pose main ctrls to F close'] = lambda:poseToF(True)
dButtons['pose main ctrls to F close'].xHelp = ['Same as button above, but in jaw close pose']

dButtons['pose all back to default'] = poseToDefault
dButtons['mirror ctrl values'] = mirrorPhoneticCtrls
dButtons['fill dFf values'] = fillFf
dButtons['fill dRr values'] = fillRr
dButtons['fill dBp values'] = fillBp
dButtons['fill dForward values'] = fillForward
dButtons['remove phonetic poses'] = removePhoneticCtrlPoses



@builderTools.addToBuild(iOrder=95.5, dButtons=dButtons)
def ctrlPhoneticPoses(dFf={}, dRr={}, dBp={}, dForward={}, _report=None):

    cAudio = ctrls.ctrlFromName('ctrl_m_audio')

    # nodes.addSeparatorAttr('ctrl_m_mouth', 'phonemes')
    dProducts = defaultdict(list)
    for sDriverAttr, dKeys in [('ff',dFf), ('rr',dRr), ('bp',dBp), ('forward',dForward)]:

        sCtrlAnim = '%s.%s' % (cAudio.sPasser, sDriverAttr)
        for sCtrl, dAttrValues in list(dKeys.items()): # {u'ctrl_l_lipsBot': {u'scaleY': 0.7}, u'ctrl_l_lipsTop': {u'scaleY': 0.7, u'translateY': -0.10118}, u'ctrl_r_lipsTop': {u'scaleY': 0.7, u'translateY': -0.10118}, u'ctrl_m_mouth': {u'rollBotLeft': 0.5, u'rollBotRight': 0.5, u'rollTopRight': 0.5, u'rollTopLeft': 0.5}, u'ctrl_m_lipsTop': {u'scaleY': 0.7, u'translateY': -0.10118}, u'ctrl_m_lipsBot': {u'scaleY': 0.7}}
            for sA,fV in list(dAttrValues.items()):
                sDrivenAttr = '%s.%s' % (sCtrl,sA)
                print('sDrivenAttr:' , sDrivenAttr)
                prod = (sCtrlAnim, fV)
                dProducts[sDrivenAttr].append(prod)

    removePhoneticCtrlPoses(_report=_report)

    sNodesBefore = set(cmds.ls(l=True))


    for sDrivenAttr, xProducts in list(dProducts.items()):
        sCtrl, sAttr = sDrivenAttr.split('.')
        sName = 'phoneme_%s' % sDrivenAttr.replace('.','_')
        cCtrl = ctrls.ctrlFromName(sCtrl)
        sOffset = cCtrl.getOffsetByName('phonetic', bReturnNoneIfNotExists=True)
        if not sOffset:
            raise 'no phonetic offset: %s' % sDrivenAttr
        bDoUnitConversionNodes = not sAttr.startswith('rotate')

        sTargetAttr = '%s.%s' % (sOffset, sAttr)
        if sAttr in ['scaleX', 'scaleY', 'scaleZ']:
            sBlends = [nodes.createBlendNode(xP[0], xP[1], 1.0) for xP in xProducts]
            nodes.createMultiplyArrayNode([sDrivenAttr] + sBlends, sTarget=sTargetAttr, sName='%s_addPhonetic' % sName)
        else:
            nodes.createInfiniteDotProduct(xProducts, sTarget=sTargetAttr, sName=sName, bDoUnitConversionNodes=bDoUnitConversionNodes)


    sNewNodes = list(set(cmds.ls(l=True)) - sNodesBefore)
    for sN in sNewNodes:
        sN = cmds.rename(sN, 'PHONETICPOSES_%s' % sN)
        cmds.addAttr(sN, ln='PHONETICPOSESATTR', at='bool')
        print(sN)



def setAsAudioCtrl(sCtrl):
    cmds.addAttr(sCtrl, ln='bIsAudioCtrl', at='bool', defaultValue=True, k=False)



# sString = 'fTopCloseY?-0.180/fBotCloseZ?-0.050/fBotCloseY?1.100/fTopCloseZ?-0.150/fFffBotY?-0.000?0.270/fFffBotZ?-0.250?-0.250/fFffTopY?0.100?0.200/fTongueBaseT?0.000?0.000?0.000/fBotTeethT?0.000?0.000?0.000/fTopTeethT?0.000?0.000?0.000'



def updateAudioDict(fJawMaxOpen, fBotCloseY, fBotCloseZ, fBotCloseRot, fTopCloseY, fTopCloseZ, fTopCloseRot, fBotTeethT, fTopTeethT, fTongueBaseT,
                    fJawFffMaxOpen, fFffBotY, fFffBotZ, fFffTopY, fCornerRange):

    xDict = {'fBotCloseY':fBotCloseY, 'fBotCloseZ':fBotCloseZ, 'fBotCloseRot':fBotCloseRot, 'fTopCloseRot':fTopCloseRot, 'fTopCloseY':fTopCloseY, 'fTopCloseZ':fTopCloseZ,
             'fBotTeethT':fBotTeethT, 'fTopTeethT':fTopTeethT, 'fJawFffMaxOpen':fJawFffMaxOpen, 'fFffBotY':fFffBotY, 'fFffBotZ':fFffBotZ, 'fFffTopY':fFffTopY,
             'fTongueBaseT':fTongueBaseT, 'fJawMaxOpen':fJawMaxOpen, 'fCornerRange':fCornerRange}
    print('xDict: ', xDict)

    sDicts = []
    for sK,fV in list(xDict.items()):
        sV = ['%0.3f' % fV for fV in utils.toList(fV)]
        sDicts.append('%s?%s' % (sK, '?'.join(sV)))

    cAudio = ctrls.ctrlFromName('ctrl_m_audio')
    sDictString = '/'.join(sDicts)
    sDictAttr = utils.addStringAttr(cAudio.sPasser, '__dict__', utils.encodeAudioLipsString(sDictString))
    cmds.setAttr(sDictAttr, lock=True)


def printEncodedDict(_report=None):
    xDict = utils.createDictFromDecodedAudioLipsString(cmds.getAttr('grp_m_audioPasser.__dict__'))
    if _report:
        _report.addLogText(str(xDict))
    print(xDict)



def _setItemFromAttr(qArg, iIndex, sAttr):
    ffValues = utils.evalValueFromString(qArg.text())
    ffValues[iIndex] = round(cmds.getAttr(sAttr), 3)
    qArg.setText(str(ffValues))


kMouthBotTop = ['ctrl_m_mouthBot', 'ctrl_m_mouthTop']

def updateCloseValues(fJawMaxOpen, _uiArgs=None, _report=None):
    kMouthBotTop = ['ctrl_m_mouthBot', 'ctrl_m_mouthTop']
    cmds.setAttr('%s.tx' % kMouthBotTop[0], 0.0)
    cmds.setAttr('%s.tx' % kMouthBotTop[1], 0.0)
    cmds.setAttr('ctrl_m_jaw.rx', fJawMaxOpen)
    _uiArgs['fBotCloseZ'].setText(utils.getStringFloatValue('%s.tz' % kMouthBotTop[0]))
    _uiArgs['fBotCloseY'].setText(utils.getStringFloatValue('%s.ty' % kMouthBotTop[0]))
    _uiArgs['fTopCloseY'].setText(utils.getStringFloatValue('%s.ty' % kMouthBotTop[1]))
    _uiArgs['fBotCloseRot'].setText(utils.getStringFloatValue('%s.rx' % kMouthBotTop[0]))
    _uiArgs['fTopCloseRot'].setText(utils.getStringFloatValue('%s.rx' % kMouthBotTop[1]))
def goToCloseValues(fJawMaxOpen, fBotCloseY, fBotCloseZ, fBotCloseRot, fTopCloseY, fTopCloseZ, fTopCloseRot):
    print('go to close values', fBotCloseY, fBotCloseZ, fTopCloseY, fTopCloseZ)
    kMouthBotTop = ['ctrl_m_mouthBot', 'ctrl_m_mouthTop']
    cmds.setAttr('%s.tx' % kMouthBotTop[0], 0.0)
    cmds.setAttr('%s.ty' % kMouthBotTop[0], fBotCloseY)
    cmds.setAttr('%s.tz' % kMouthBotTop[0], fBotCloseZ)
    cmds.setAttr('%s.tx' % kMouthBotTop[1], 0.0)
    cmds.setAttr('%s.ty' % kMouthBotTop[1], fTopCloseY)
    cmds.setAttr('%s.tz' % kMouthBotTop[1], fTopCloseZ)
    cmds.setAttr('%s.rx' % kMouthBotTop[0], fBotCloseRot)
    cmds.setAttr('%s.rx' % kMouthBotTop[1], fTopCloseRot)
    cmds.setAttr('ctrl_m_jaw.rx', fJawMaxOpen)
updateCloseValues.dSideButtons = {'pose to':goToCloseValues}


def updateFffValuesClosed(_uiArgs=None, _report=None):
    kMouthBotTop = ['ctrl_m_mouthBot', 'ctrl_m_mouthTop']
    cmds.setAttr('%s.tx' % kMouthBotTop[0], 0.0)
    cmds.setAttr('%s.tx' % kMouthBotTop[1], 0.0)
    cmds.setAttr('%s.tz' % kMouthBotTop[1], 0.0)
    cmds.setAttr('ctrl_m_jaw.rx', 0.0)
    _setItemFromAttr(_uiArgs['fFffBotY'], 0, '%s.ty' % kMouthBotTop[0])
    _setItemFromAttr(_uiArgs['fFffBotZ'], 0, '%s.tz' % kMouthBotTop[0])
    _setItemFromAttr(_uiArgs['fFffTopY'], 0, '%s.ty' % kMouthBotTop[1])

def goToFffClosedValues(fFffBotY, fFffBotZ, fFffTopY):
    print('go to fff closed values', fFffBotY, fFffBotZ, fFffTopY)
    cmds.setAttr('%s.tx' % kMouthBotTop[0], 0.0)
    cmds.setAttr('%s.ty' % kMouthBotTop[0], fFffBotY[0])
    cmds.setAttr('%s.tz' % kMouthBotTop[0], fFffBotZ[0])
    cmds.setAttr('%s.tx' % kMouthBotTop[1], 0.0)
    cmds.setAttr('%s.ty' % kMouthBotTop[1], fFffTopY[0])
    cmds.setAttr('%s.tz' % kMouthBotTop[1], 0)
    cmds.setAttr('ctrl_m_jaw.rx', 0.0)
updateFffValuesClosed.dSideButtons = {'pose to':goToFffClosedValues}


def updateFffValuesOpen(fJawFffMaxOpen, _uiArgs=None, _report=None):
    kMouthBotTop = ['ctrl_m_mouthBot', 'ctrl_m_mouthTop']
    cmds.setAttr('%s.tx' % kMouthBotTop[0], 0.0)
    cmds.setAttr('%s.tx' % kMouthBotTop[1], 0.0)
    cmds.setAttr('%s.tz' % kMouthBotTop[1], 0.0)
    cmds.setAttr('ctrl_m_jaw.rx', fJawFffMaxOpen)
    _setItemFromAttr(_uiArgs['fFffBotY'], 1, '%s.ty' % kMouthBotTop[0])
    _setItemFromAttr(_uiArgs['fFffBotZ'], 1, '%s.tz' % kMouthBotTop[0])
    _setItemFromAttr(_uiArgs['fFffTopY'], 1, '%s.ty' % kMouthBotTop[1])

def goToFffOpenValues(fJawFffMaxOpen, fFffBotY, fFffBotZ, fFffTopY):
    cmds.setAttr('%s.tx' % kMouthBotTop[0], 0.0)
    cmds.setAttr('%s.ty' % kMouthBotTop[0], fFffBotY[1])
    cmds.setAttr('%s.tz' % kMouthBotTop[0], fFffBotZ[1])
    cmds.setAttr('%s.tx' % kMouthBotTop[1], 0.0)
    cmds.setAttr('%s.ty' % kMouthBotTop[1], fFffTopY[1])
    cmds.setAttr('%s.tz' % kMouthBotTop[1], 0)
    cmds.setAttr('ctrl_m_jaw.rx', fJawFffMaxOpen)
updateFffValuesOpen.dSideButtons = {'pose to':goToFffOpenValues}


def setMouthCtrlsToDefault():
    for p in [0,1]:
        cmds.setAttr('%s.tx' % kMouthBotTop[p], 0.0)
        cmds.setAttr('%s.ty' % kMouthBotTop[p], 0.0)
        cmds.setAttr('%s.tz' % kMouthBotTop[p], 0.0)
    cmds.setAttr('ctrl_m_jaw.rx', 0.0)


dButtons = OrderedDict()
dButtons['update dict'] = updateAudioDict
dButtons['print dict'] = printEncodedDict
dButtons['Fill Close Values on jaw.rx=fJawMaxOpen from Scene'] = updateCloseValues
dButtons['Fill F values on jaw.rx=0 from Scene'] = updateFffValuesClosed
dButtons['Fill F values on jaw.rx=fJawMaxOpen*0.25 from Scene'] = updateFffValuesOpen
dButtons['go to default'] = setMouthCtrlsToDefault


def _getCombinedAttr(cC, sAttr):
    if sAttr.startswith('translate') or sAttr.startswith('rotate') or sAttr.startswith('scale'):
        sCombinedAttr = '%s.%sCombined%s' % (cC.sPasser, sAttr[:-1], sAttr[-1])
        if cmds.objExists(sCombinedAttr):
            return sCombinedAttr
    else:
        return None



@builderTools.addToBuild(iOrder=95, dButtons=dButtons)
def createAudioCtrls(fJawMaxOpen=16.0, fBotCloseY=0.36, fBotCloseZ=0.0, fBotCloseRot=0.0, fTopCloseY=-0.2, fTopCloseZ=-0.26, fTopCloseRot=0.0, fBotTeethT=[0,0,0], fTopTeethT=[0,0,0], fTongueBaseT=[0,0,0],
                     fJawFffMaxOpen=4.0, fFffBotY=[0.1,0.65], fFffBotZ=[-0.2, 0.0], fFffTopY=[0.1, 0.2], fCornerRange=[-0.8, 0.8]):

    '''
    The dict holds the values from the bottom parameters, and it goes into the rig for the lip Sync Tool \
    to  use for creating the animation.

    Most important one to set first is fJawOpen. This is the rx value of ctrl_m_jaw when jaw is open \
    the most. Basically the limit.
    fBotCloseY, fBotCloseZ and fBotCloseRot are values for the ctrl_m_mouthBot to close the mouth when \
    jaw is on its max open.
    fTopCloseY, fTopCloseZ, fTopCloseRot are the same for the ctrl_m_mouthTop control.

    The F shape needs more attention:
    fJawFffMaxOpen is the widest the jaw can be open on F
    fFffBotY, fFffBotZ and fFffTopY are lists with 2 items. The first item is the value of the ctrl_m_mouthBot or ctrl_m_mouthTop \
    when Jaw is at 0, and the second items are the values when Jaw is at fJawFffMaxOpen.

    fBotTeethT, fTopTeethT and fTongueBaseT are simple translation values where controls will be moved to \
    when lip Sync Animation is created.


    '''

    sMouthCtrl = 'ctrl_m_mouth'
    fSliderScale = utils.data.get('mouthSliderScale', sNode=kFaceDataNode)

    cAudio = ctrls.create(sName='audio', sSide='m', sParent='faceCtrls', sShape='A', fSize=fSliderScale*0.5)
    aPos = np.average(np.array(cmds.xform('%s.cv[*]' % sMouthCtrl, q=True, ws=True, t=True)).reshape(-1,3), axis=0)
    cmds.setAttr('%s.t' % cAudio.sPasser, aPos[0], aPos[1], aPos[2])
    cmds.parentConstraint(sMouthCtrl, cAudio.sPasser, mo=True)
    sBlend = utils.addAttr(cAudio.sCtrl, ln='enabled', at='enum', en='Off:On', defaultValue=0, k=True)
    sCtrlVis = utils.addAttr(cAudio.sCtrl, ln='ctrlVis', at='enum', en='Off:On', defaultValue=0, k=True)
    # sBlend = utils.addAttr(cAudio.sCtrl, ln='blend', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
    setAsAudioCtrl(cAudio.sCtrl)

    # add character specific values
    updateAudioDict(fJawMaxOpen, fBotCloseY, fBotCloseZ, fBotCloseRot, fTopCloseY, fTopCloseZ, fTopCloseRot, fBotTeethT, fTopTeethT, fTongueBaseT,
                    fJawFffMaxOpen, fFffBotY, fFffBotZ, fFffTopY, fCornerRange)

    sRevBlend = nodes.createReverseNode(sBlend)
    sRevBlendNeg = nodes.fromEquation('%s * -1' % sRevBlend)


    # phonetic attrs that will get connected in character scripts
    for sA in ['rr', 'ff', 'bp', 'forward']:
        sAttr = utils.addAttr(cAudio.sCtrl, ln=sA, minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
        sOutAttr = utils.addAttr(cAudio.sPasser, ln=sA, minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
        nodes.fromEquation('%s * %s' % (sAttr, sBlend), sTarget=sOutAttr)





    dCtrls = {
        'ctrl_m_jaw': ['rotateX'],
        'ctrl_l_lipsCorner':['translateX', 'translateY', 'translateZ', 'seal', 'roundWhenWiden', 'smileDampRoundWhenWiden'],
        'ctrl_r_lipsCorner':['translateX', 'translateY', 'translateZ', 'seal', 'roundWhenWiden', 'smileDampRoundWhenWiden'],
        'ctrl_l_lipsTop':['translateX', 'translateY', 'translateZ'],
        'ctrl_r_lipsTop':['translateX', 'translateY', 'translateZ'],
        'ctrl_l_lipsTopA':['translateX', 'translateY', 'translateZ'],
        'ctrl_r_lipsTopA':['translateX', 'translateY', 'translateZ'],
        'ctrl_l_lipsTopB':['translateX', 'translateY', 'translateZ'],
        'ctrl_r_lipsTopB':['translateX', 'translateY', 'translateZ'],
        'ctrl_m_lipsTop':['translateX', 'translateY', 'translateZ'],
        'ctrl_l_lipsBot':['translateX', 'translateY', 'translateZ'],
        'ctrl_r_lipsBot':['translateX', 'translateY', 'translateZ'],
        'ctrl_l_lipsBotA':['translateX', 'translateY', 'translateZ'],
        'ctrl_r_lipsBotA':['translateX', 'translateY', 'translateZ'],
        'ctrl_l_lipsBotB':['translateX', 'translateY', 'translateZ'],
        'ctrl_r_lipsBotB':['translateX', 'translateY', 'translateZ'],
        'ctrl_m_lipsBot':['translateX', 'translateY', 'translateZ'],
        'ctrl_m_mouthBot': ['translateY', 'translateZ', 'rotateX'],
        'ctrl_m_mouthTop':['translateY', 'rotateX'],
        'ctrl_m_botFaceSquashStretch':['translateY'],
        'ctrl_m_tongueTip':['ss', 'th', 'up'],
        'ctrl_m_tongueMid':['up']
    }

    cCorners = []
    cForceCloseMouthCtrl = []

    # duplicate ctrls
    for sC in sorted(dCtrls.keys()):
        if not cmds.objExists(sC):
            continue
        sAttrs = dCtrls[sC]
        cC = ctrls.ctrlFromName(sC)
        if sC.endswith('_lipsCorner'):
            cCorners.append(cC)
        elif sC.startswith('ctrl_m_mouth') or '_lipsBot' in sC or '_lipsTop' in sC:
            cForceCloseMouthCtrl.append(cC)
        elif sC == 'ctrl_m_jaw':
            cJaw = cC
        print('sC: ', sC)
        cC.sAudioCtrl = cmds.duplicate(cC.sCtrl, n='ctrl_%s_%sAudio' % (cC.sSide, cC.sName))[0]
        cmds.setAttr('%s.overrideEnabled' % cC.sAudioCtrl, True)
        cmds.setAttr('%s.overrideRGBColors' % cC.sAudioCtrl, True)
        cmds.setAttr('%s.overrideColorRGB' % cC.sAudioCtrl, *[fV/255.0 for fV in [200,200,200]])

        setAsAudioCtrl(cC.sAudioCtrl)
        cmds.setAttr('%s.v' % cC.sAudioCtrl, lock=False)
        cmds.connectAttr(sCtrlVis, '%s.v' % cC.sAudioCtrl)
        cmds.delete(cmds.listRelatives(cC.sAudioCtrl, c=True, f=True, typ='transform'))
        cmds.parent(cC.sAudioCtrl, cC.sCtrl)
        cmds.parent(cC.sOut, cC.sAudioCtrl)

        pAudioShape = patch.patchFromName(cmds.listRelatives(cC.sAudioCtrl, s=True)[0])
        aShapePoints = pAudioShape.getAllPoints()
        aShapeMiddle = np.mean(aShapePoints, axis=0)
        pAudioShape.setPoints(aShapeMiddle + (aShapePoints-aShapeMiddle)*0.6)

        sSwitchRev = xforms.insertParent(cC.sOut, 'switchRev_%s_%sAudio' % (cC.sSide, cC.sName))
        cC.sBeforeRevRot = xforms.insertParent(cC.sAudioCtrl, 'revCloseRot_%s_%sAudio' % (cC.sSide, cC.sName))
        nodes.createChoiceNode('%s.ro' % cC.sCtrl, xforms.iSwapRotateOrders, sTarget='%s.ro' % cC.sBeforeRevRot)
        cC.sBeforeRev = xforms.insertParent(cC.sAudioCtrl, 'revClose_%s_%sAudio' % (cC.sSide, cC.sName))
        sAudioSum = nodes.createVectorAdditionNode(['%s.t' % cC.sAudioCtrl, '%s.t' % cC.sBeforeRev])
        nodes.createVectorMultiplyNode(sAudioSum, sRevBlendNeg, bVectorByScalar=True, sTarget='%s.t' % sSwitchRev)

        if sC == 'ctrl_m_jaw':
            sSwitchRevRot = xforms.insertParent(sSwitchRev, 'switchRevRot_%s_%sAudio' % (cC.sSide, cC.sName), bMatchParentTransform=True)
            nodes.createVectorMultiplyNode('%s.r' % cC.sAudioCtrl, sRevBlendNeg, bVectorByScalar=True, sTarget='%s.r' % sSwitchRevRot)
            nodes.createChoiceNode('%s.ro' % cC.sAudioCtrl, xforms.iSwapRotateOrders, sTarget='%s.ro' % sSwitchRevRot)

        sCurrentAttrs = cmds.listAttr(cC.sAudioCtrl, keyable=True, scalar=True, visible=True, leaf=True) or []
        sRemoveAttrs = list(set(sCurrentAttrs) - set(sAttrs))
        for sA in sRemoveAttrs:
            cmds.setAttr('%s.%s' % (cC.sAudioCtrl,sA), k=False)

        # create addition nodes
        # sLockAttrs = set(['translateCombinedX', 'translateCombinedY', 'translateCombinedZ',
        #                   'rotateCombinedX', 'rotateCombinedY', 'rotateCombinedZ',
        #                   'scaleCombinedX', 'scaleCombinedY', 'scaleCombinedZ']) - set(sAttrs)
        # for sA in list(sLockAttrs):
        #     cmds.setAttr('%s.%s' % (cC.sAudioCtrl, sA), lock=True)

        for sA in sAttrs:
            sAudioAttr = '%s.%s' % (cC.sAudioCtrl, sA)
            sAttr = '%s.%s' % (cC.sCtrl, sA)
            # sCopyAttr = utils.addAttr(cC.sPasser, ln='%s_sum' % sA, k=True)

            if not cmds.objExists(sAttr):
                sAttr = '%s.%s' % (cC.sPasser, sA)
                if not cmds.objExists(sAttr):
                    raise Exception('attribute %s of ctrl %s not found' % (sA, sC))

                nodes.moveCustomAttributes(cC.sPasser, cC.sAudioCtrl, sAttrs=[sA], bDeleteOldAttr=False, bReconnectDest=False)

            sConns = cmds.listConnections(sAttr, s=False, d=True, p=True) or []

            sCombinedAttr = _getCombinedAttr(cC,sA)
            if sCombinedAttr:
                sCombinedConns = cmds.listConnections(sCombinedAttr, s=False, d=True, p=True) or []


            print('sAttr: ', sAttr, sConns)

            fMax = cmds.addAttr(sAttr, q=True, maxValue=True)
            fMin = cmds.addAttr(sAttr, q=True, minValue=True)
            sAudioMultipl = nodes.fromEquation('%s * %s' % (sAudioAttr, sBlend))
            if sA.startswith('translate'):
                sAttr2 = '%s.%s' % (cC.sBeforeRev, sA)
                sAddition = nodes.createAdditionNode([sAttr, sAttr2, sAudioMultipl])
            else:
                sAddition = nodes.createAdditionNode([sAttr, sAudioMultipl])

            # cmds.connectAttr(sAddition, sCopyAttr)

            if fMin == None and fMax == None:
                sClamp = sAddition
            elif fMin == None:
                sClamp = nodes.createClampNode(sAddition, -1000, fMax)
            elif fMax == None:
                sClamp = nodes.createClampNode(sAddition, fMin, 1000)
            else:
                sClamp = nodes.createClampNode(sAddition, fMin, fMax)

            for sC in sConns:
                cmds.disconnectAttr(sAttr, sC)
                cmds.connectAttr(sClamp, sC)
            if sCombinedAttr:
                for sC in sCombinedConns:
                    cmds.disconnectAttr(sCombinedAttr, sC)
                    cmds.connectAttr(sClamp, sC)

    # # flatten when narrow
    # for s,sSide in enumerate(['l','r']):
    #     cC = cCorners[s]
    #     sFlattenAttr = utils.addAttr(cC.sAudioCtrl, ln='flattenWhenNarrow', minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True)
    #     sAudioInEnd = nodes.createAdditionNode([-0.4], sOperation='minus', sName='%s_audioEnd' % sSide)
    #     sClampedInX = nodes.createClampNode('%s.tx' % cC.sAudioCtrl, sAudioInEnd, 100000)
    #     sFlattenedY = nodes.createRangeNode(sClampedInX, sAudioInEnd, 0.0, '%s.ty' % cC.sCtrl, 0, bInfinity=True, sName='%s_flattenCorner' % sSide)
    #     nodes.fromEquation('%s * %s * -1' % (sFlattenedY, sFlattenAttr), sTarget='%s.ty' % cC.sBeforeRev, sName='%s_flattenCorner' % sSide)


    # force close
    sForceLipsAttr = utils.addAttr(cAudio.sCtrl, ln='forceAllClose', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
    sForceLipsMultipl = nodes.fromEquation('%s * %s' % (sForceLipsAttr, sBlend))

    sForceJawAttr = utils.addAttr(cAudio.sCtrl, ln='forceJawClose', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
    sForceJawMultipl = nodes.fromEquation('%s * %s' % (sForceJawAttr, sBlend))


    sRevFlattenLipsNeg = nodes.fromEquation('%s * -1.0' % (sForceLipsMultipl))
    sRevFlattenJawNeg = nodes.fromEquation('%s * -1.0' % (sForceJawMultipl))
    sRevFlattenSum = nodes.createConditionNode(sRevFlattenLipsNeg, '<', sRevFlattenJawNeg, sRevFlattenLipsNeg, sRevFlattenJawNeg)
    for cC in cForceCloseMouthCtrl:
        nodes.createVectorMultiplyNode('%s.t' % cC.sCtrl, sRevFlattenLipsNeg, bVectorByScalar=True, sTarget='%s.t' % cC.sBeforeRev)
        nodes.createVectorMultiplyNode('%s.r' % cC.sCtrl, sRevFlattenLipsNeg, bVectorByScalar=True, sTarget='%s.r' % cC.sBeforeRevRot)
    nodes.createVectorMultiplyNode('%s.t' % cJaw.sCtrl, sRevFlattenSum, bVectorByScalar=True, sTarget='%s.t' % cJaw.sBeforeRev)
    nodes.createVectorMultiplyNode('%s.r' % cJaw.sCtrl, sRevFlattenSum, bVectorByScalar=True, sTarget='%s.r' % cJaw.sBeforeRevRot)

    # nodes.fromEquation('%s.rx * %s' % (cJaw.sCtrl, sRevFlattenLipsNeg), sTarget='%s.rx' % cJaw.sBeforeRev)


    # move against outside to preserve narrowing
    for s,sSide in enumerate(['l','r']):
        cC = cCorners[s]
        sMoveAgainstOnNarrowMax = utils.addAttr(cC.sPasser, ln='moveAgainstOnNarrowMax', minValue=-0.8, maxValue=0, defaultValue=-0.4, k=True)
        sMoveAgainstOnNarrowStrength = utils.addAttr(cC.sPasser, ln='moveAgainstOnNarrow', minValue=0.0, maxValue=1.0, defaultValue=1.0, k=True)
        sMoveAgainst = nodes.fromEquation('%s * %s.tx * -1' % (sMoveAgainstOnNarrowStrength, cC.sCtrl))
        nodes.createConditionNode('%s.tx' % cC.sCtrl, '>', 0, sMoveAgainst, 0, sTarget='%s.tx' % cC.sBeforeRev)
        # nodes.setDrivenKey('%s.tx' % cC.sAudioCtrl, [0,-0.4], sMoveAgainstOnNarrowStrength, [0,1])
        nodes.createRangeNode('%s.tx' % cC.sAudioCtrl, 0, sMoveAgainstOnNarrowMax, 0, 1, sTarget=sMoveAgainstOnNarrowStrength)



    sDebugAttrA = utils.addAttr('grp_m_audioPasser', ln='debugAttrA', k=True, bReturnIfExists=True)
    sDebugAttrB = utils.addAttr('grp_m_audioPasser', ln='debugAttrB', k=True, bReturnIfExists=True)
    sDebugAttrC = utils.addAttr('grp_m_audioPasser', ln='debugAttrC', k=True, bReturnIfExists=True)
    sDebugAttrD = utils.addAttr('grp_m_audioPasser', ln='debugAttrD', k=True, bReturnIfExists=True)




def poseToF(bJawClosedOnF):
    utils.addAttr('grp_m_audioPasser', ln='debugAttrC', k=True, bReturnIfExists=True)
    dDict = utils.createDictFromDecodedAudioLipsString(cmds.getAttr('grp_m_audioPasser.__dict__'))
    cmds.setAttr('grp_m_audioPasser.debugAttrC', 1.0)
    if bJawClosedOnF:
        cmds.setAttr('ctrl_m_jaw.rotateX', 0.0)
    else:
        cmds.setAttr('ctrl_m_jaw.rotateX', dDict['fJawMaxOpen'][0] * 0.125 * 2.0)

    iInd = 0 if bJawClosedOnF else 1
    cmds.setAttr('ctrl_m_mouthTop.translateY', dDict['fFffTopY'][iInd])
    cmds.setAttr('ctrl_m_mouthBot.translateY', dDict['fFffBotY'][iInd])
    cmds.setAttr('ctrl_m_mouthBot.translateZ', dDict['fFffBotZ'][iInd])
    cmds.setAttr('ctrl_m_audio.ff', 1.0)
    cmds.setAttr('ctrl_m_audio.enabled', 1.0)


def poseAwayFromF():
    utils.addAttr('grp_m_audioPasser', ln='debugAttrC', k=True, bReturnIfExists=True)
    cmds.setAttr('grp_m_audioPasser.debugAttrC', 0.0)
    cmds.setAttr('ctrl_m_jaw.rotateX', 0.0)
    cmds.setAttr('ctrl_m_mouthTop.translateY', 0.0)
    cmds.setAttr('ctrl_m_mouthBot.translateY', 0.0)
    cmds.setAttr('ctrl_m_mouthBot.translateZ', 0.0)
    cmds.setAttr('ctrl_m_audio.ff', 0.0)
    cmds.setAttr('ctrl_m_audio.enabled', 0.0)






@builderTools.addToBuild(iOrder=95.8, dButtons={'pose to F':poseToF, 'back to default':poseAwayFromF})
def createAudioCorrectives(sCorrectiveFs=[], bJawClosedOnF=False, _report=None):
    sDebugAttrA = utils.addAttr('grp_m_audioPasser', ln='debugAttrA', k=True, bReturnIfExists=True)
    sDebugAttrB = utils.addAttr('grp_m_audioPasser', ln='debugAttrB', k=True, bReturnIfExists=True)
    sDebugAttrC = utils.addAttr('grp_m_audioPasser', ln='debugAttrC', k=True, bReturnIfExists=True)
    sDebugAttrD = utils.addAttr('grp_m_audioPasser', ln='debugAttrD', k=True, bReturnIfExists=True)

    dDict = utils.createDictFromDecodedAudioLipsString(cmds.getAttr('grp_m_audioPasser.__dict__'))
    # TARGET__body_geo__correctiveF__100__posed
    for sC in sCorrectiveFs:
        if not cmds.objExists(sC):
            if _report != None:
                _report.addLogText('skipping: %s' % sC)
                cmds.warning('skipping: %s' % sC)
                continue

        sModel, sMeshKey, iWeight, sType = interpolator.extractMeshName(sC)
        if sType != 'inverted':
            # cmds.setAttr('ctrl_m_jaw.rotateX', dDict['fJawMaxOpen'][0] * 0.125)
            # cmds.setAttr('ctrl_m_mouthTop.translateY', dDict['fFffTopY'][1])
            # cmds.setAttr('ctrl_m_mouthBot.translateY', dDict['fFffBotY'][1])
            # cmds.setAttr('ctrl_m_mouthBot.translateZ', dDict['fFffBotZ'][1])
            # cmds.setAttr('ctrl_m_audio.enabled', 1.0)
            # cmds.setAttr('ctrl_m_audio.ff', 1.0)
            poseToF(bJawClosedOnF)
            print('bJawClosedOnF: ', bJawClosedOnF)
            sInverted = geometry.invertShapeDeformers(sC, sModel, sInvertName=interpolator.makeMeshName(sModel, sMeshKey, iWeight, 'inverted'), sComboBlendShape=True)
            poseAwayFromF()
            # cmds.setAttr('ctrl_m_jaw.rotateX', 0)
            # cmds.setAttr('ctrl_m_mouthTop.translateY', 0)
            # cmds.setAttr('ctrl_m_mouthBot.translateY', 0)
            # cmds.setAttr('ctrl_m_mouthBot.translateZ', 0)
            # cmds.setAttr('ctrl_m_audio.enabled', 0.0)
            # cmds.setAttr('ctrl_m_audio.ff', 0)

        else:
            sInverted = sC
        sTarget = deformers.addBlendShapeTargets(sModel, [sInverted])[0]
        nodes.createMultiplyArrayNode(['grp_m_audioPasser.debugAttrC', 'ctrl_m_audio.enabled'], sTarget=sTarget)
        # nodes.createRangeNode('%s.ff' % cAudio.sPasser, 0, 0.3, 0, 1, sTarget=sTarget)

