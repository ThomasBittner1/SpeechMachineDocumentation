###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np
import pickle
import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.constraints as constraints
import kangarooTools.utilsUnreal as utilsUnreal

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.blendShapesPro as blendShapesPro

from collections import defaultdict

kBuilderColor = '#a9ff00'

kAddBackwardsCtrlInitiations = '#Add Backwards Ctrl Initiations..'
# get rid of this?
sDoBackwardsLimbs=['m_placement', 'm_cog', 'm_spine', 'm_hips',  'l_clavicle', 'l_arm', 'l_leg', 'l_thumb', 'l_index', 'l_middle', 'l_ring', 'l_pinky',
                                                                 'r_clavicle', 'r_arm', 'r_leg', 'r_thumb', 'r_index', 'r_middle', 'r_ring', 'r_pinky', 'm_neck', 'm_head']


@builderTools.addToBuild(iOrder=-3)
def unrealPythonStartFile(sAvoidForwardLimbs=[], sAvoidBackwardsLimbs=[]): #, dUnrealAvoidLimbs={'forward':[], 'backwards':[]}):
    utils.data.store('bBuildUnrealPuppet', True)
    # utils.data.store('bMannequin', bMannequin)
    utils.data.store('sUnrealAvoidForwardLimbs', sAvoidForwardLimbs)
    utils.data.store('sUnrealAvoidBackwardsLimbs', sAvoidBackwardsLimbs)
    # utils.data.store('sDoBackwardsLimbs', sDoBackwardsLimbs)


    sSetSolverString = "controllers.__iCurrentSolver__ = %d"

    sUnrealCodeLines = []
    sUnrealCodeLines.append(sSetSolverString % 0)
    sUnrealCodeLines.append("nodes.startFunction('FORWARD', bSequencer=True)")
    utils.data.store('pythonStartedFunction', True)


    utils.data.store(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True)


    sUnrealBackwardsCodeLines = []
    sUnrealBackwardsCodeLines.append('\n\n')
    sUnrealBackwardsCodeLines.append(sSetSolverString % 1)
    sUnrealBackwardsCodeLines.append(kAddBackwardsCtrlInitiations)
    sUnrealBackwardsCodeLines.append('\n\n')
    sUnrealBackwardsCodeLines.append("try: nodes.createBackwardsEvent()")
    sUnrealBackwardsCodeLines.append("except: print ('backwardsEvent seems to already exist')")
    sUnrealBackwardsCodeLines.append("nodes.startFunction('BACKWARDS', bSequencer=True)")


    utils.data.store(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True, sKey=utilsUnreal.kUnrealBackwardsCodeLines)







@builderTools.addToBuild(iOrder=133.9)
def pythonEndFile():
    sUnrealCommands = []
    sUnrealBackwardsCommands = []

    sUnrealCommands.append("nodes.endCurrentFunction()")
    sUnrealBackwardsCommands.append("nodes.endCurrentFunction()")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()

    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)




@builderTools.addToBuild(iOrder=106.5, bDisableByDefault=True)
def pythonFingerPoses():
    sUnrealDriverLimbs = utils.data.get('unrealFingerDriverLimbs')
    print ('sUnrealDriverLimbs: ', sUnrealDriverLimbs)

    sCreatedCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    sFilePath = utilsUnreal.createOutFilePath()
    with open(sFilePath, 'rt') as sText:
        sAllLines = list(sText)
        print ('sUnrealDriverLimbs: ', sUnrealDriverLimbs)
        for sLimbName in sUnrealDriverLimbs:
            dUnrealProducts = utils.data.get('%s_dFingerPosesUnrealProducts' % sLimbName)
            print ('dUnrealProducts: ', dUnrealProducts)

            sCommands = ['\n\n# FINGER POSES %s' % sLimbName.upper()]
            sCommands.append("unrealUI.logMessage('Finger Poses %s...')" % sLimbName)
            sCommands.append("unrealUI.incrementProgress()")

            utilsUnreal.setNewColumn(sWriteCommands=sCommands)

            sCommands.append('dFingerPosesDrivers = {}')
            dRanges = {}
            sCreatedPoseKeys = set()
            # {'indexBase_l_ctrl.r': [('armGlobal_l_ctrl.curl', [102.07447, 0.0, 0.0]), ('armGlobal_l_ctrl.curl negative', [-13.90678, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', [95.58889, 0.0, 0.0]), ('armGlob
            for sCtrlAttr, xPoses in dUnrealProducts.items():
                for sKey, fVector in xPoses:
                    if sKey in sCreatedPoseKeys:
                        continue
                    sSplits = sKey.split('.')
                    sDriverCtrl = sSplits[0]
                    sDriverA = sSplits[1].split(' ')[0]
                    sDriverAttr = '%s.%s' % (sDriverCtrl,sDriverA)
                    if sDriverCtrl not in sCreatedCtrls:
                        cDriverCtrl = ctrls7.ctrlFromName(sDriverCtrl)
                        utilsUnreal.createUnrealCtrl(cDriverCtrl, sWriteCommands=sCommands)
                        sCreatedCtrls.add(cDriverCtrl.sCtrl)
                    if sDriverAttr not in dRanges:
                        fRange = [cmds.addAttr(sDriverAttr, q=True, min=True), cmds.addAttr(sDriverAttr, q=True, max=True)]
                        sCommands.append("hierarchy.createFloatControl('%s', eParent=%s.eControl, fRange=[%0.3f, %0.3f])" % (sDriverA, sDriverCtrl, fRange[0], fRange[1]))
                        dRanges[sDriverAttr] = fRange

                    if sKey.endswith('negative'):
                        sCommands.append("dFingerPosesDrivers['%s'] = functions.mapFloatControl('%s', '%s', %d)" % (sKey, sDriverCtrl, sDriverA, dRanges[sDriverAttr][0]))
                    else:
                        sCommands.append("dFingerPosesDrivers['%s'] = functions.mapFloatControl('%s', '%s', %d)" % (sKey, sDriverCtrl, sDriverA, dRanges[sDriverAttr][1]))
                    sCreatedPoseKeys.add(sKey)

            dUnrealFingerFunctions = utils.data.get('dUnrealFingerFunctions')
            sUsedUnrealFingerFunctions = list(set(dUnrealFingerFunctions.values()))

            ddLimbsPasserRotations = {sUnrealFunc:defaultdict(dict) for sUnrealFunc in sUsedUnrealFingerFunctions}
            ddLimbsPasserTranslations = {sUnrealFunc:defaultdict(dict) for sUnrealFunc in sUsedUnrealFingerFunctions}
            # sBones = ['meta', 'base', 'mid', 'tip']
            sAllFingerLimbs = set()
            for sCtrlAttr, xPoses in dUnrealProducts.items():
                sCtrl,sA = sCtrlAttr.split('.')
                sFingerLimbName = cmds.getAttr('%s.sLimbCtrl' % sCtrl)
                sUnrealFunc = dUnrealFingerFunctions[sFingerLimbName]
                sPasser = utils.replaceStringStart(ctrls7.ctrlFromName(sCtrl).sPasser, 'grp_', '')
                if sA == 'r':
                    ddLimbsPasserRotations[sUnrealFunc][sFingerLimbName][sPasser] = xPoses
                elif sA == 't':
                    ddLimbsPasserTranslations[sUnrealFunc][sFingerLimbName][sPasser] = xPoses
                sAllFingerLimbs.add(sFingerLimbName)

            dRotationsMaxPasserCounts = {}
            dTranslationsMaxPasserCounts = {}
            for sUnrealFunc in sUsedUnrealFingerFunctions:
                dRotationsMaxPasserCounts[sUnrealFunc] = max([len(x) for x in ddLimbsPasserRotations[sUnrealFunc].values()]) if len(ddLimbsPasserRotations[sUnrealFunc].values()) else 0
                dTranslationsMaxPasserCounts[sUnrealFunc] = max([len(x) for x in ddLimbsPasserTranslations[sUnrealFunc].values()]) if len(ddLimbsPasserTranslations[sUnrealFunc].values()) else 0


            for sFingerLimb in sAllFingerLimbs:
                sUnrealFunc = dUnrealFingerFunctions[sFingerLimb]
                # .r
                sWritePassersRotation = [None] * dRotationsMaxPasserCounts[sUnrealFunc]
                xWristPosesRotation = [None] * dRotationsMaxPasserCounts[sUnrealFunc]
                for p,sPasser in enumerate(ddLimbsPasserRotations[sUnrealFunc][sFingerLimb].keys()):
                    sWritePassersRotation[p] = sPasser
                    xWristPosesRotation[p] = ddLimbsPasserRotations[sUnrealFunc][sFingerLimb][sPasser]

                # .t
                sWritePassersTranslation = [None] * dTranslationsMaxPasserCounts[sUnrealFunc]
                xWristPosesTranslation = [None] * dTranslationsMaxPasserCounts[sUnrealFunc]
                for p,sPasser in enumerate(ddLimbsPasserTranslations[sUnrealFunc][sFingerLimb].keys()):
                    sWritePassersTranslation[p] = sPasser
                    xWristPosesTranslation[p] = ddLimbsPasserTranslations[sUnrealFunc][sFingerLimb][sPasser]
                for l,sLine in enumerate(sAllLines):
                    if sLine.strip().startswith(('functions.createFingerFunction', 'functions.createDogToeFunction')):
                        sLineSplits = sLine.split('#')
                        if sLineSplits[-1].strip() == sFingerLimb:
                            iBracketsPos = sLineSplits[0].rfind(')')
                            sLineSplits[0] = sLineSplits[0][:iBracketsPos] + \
                                            ', dFingerPosesDrivers=dFingerPosesDrivers, sPosePassersRotation=%s, xPasserPosesRotation=%s, sPosePassersTranslation=%s, xPasserPosesTranslation=%s' % \
                                             (sWritePassersRotation, xWristPosesRotation, sWritePassersTranslation, xWristPosesTranslation) + \
                                            sLineSplits[0][iBracketsPos:]
                            sAllLines[l] = '#'.join(sLineSplits)
                            break

            iInsertToLine = None
            for i,sLine in enumerate(sAllLines):
                if sLine.strip() == '# PIECE.END: %s' % sLimbName:
                    iInsertToLine = i
            if utils.isNone(iInsertToLine):
                raise Exception('Piece End of "%s" not found in file' % sLimbName)
            sAllLines = sAllLines[:iInsertToLine] + ['%s\n' % sCommand for sCommand in sCommands] + sAllLines[iInsertToLine:]

    utils.createTextFile(sFilePath, sAllLines)




kAddBackwardsCtrlInitiations = '#Add Backwards Ctrl Initiations..'
@builderTools.addToBuild(iOrder=120)
def initiateCtrlsInBackwards(bReloadLimbs=False, sExtraAvoidLimbs=[]):
    sCommands = ['\n\n#Initiate created ctrls']

    sCreatedCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    for sCtrl in sCreatedCtrls:
        sCommands.append("%s = hierarchy.Ctrl().initFromExisting('%s')" % (sCtrl, sCtrl))

    sFilePath = utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)
    if utils.isTextInFile(sFilePath, kAddBackwardsCtrlInitiations):
        utils.searchReplaceFile(sFilePath, kAddBackwardsCtrlInitiations, '\n'.join(sCommands))
    else:
        raise Exception ('no place found to add the code lines')




@builderTools.addToBuild(iOrder=130.1)
def pythonMuscleJoints():
    dUnrealJoints = utils.data.get('dUnrealJoints')
    sCommands =['# Muscle Joints']
    sCommands.extend(utilsUnreal.generateMuscleJointsCode(dUnrealJointsMapper=dUnrealJoints, bPieceLines=True))
    # anim rig file
    sFilePath = utilsUnreal.createOutFilePath()
    if utils.isTextInFile(sFilePath, sCommands[0]):
        utils.searchReplaceFile(sFilePath, sCommands[0], '\n'.join(sCommands))
    else:
        utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile()




@builderTools.addToBuild(iOrder=130.15)
def unrealPythonBlendJoints():
    sBlendJoints = [sJ for sJ in cmds.ls('game:*Blend', et='joint') if cmds.attributeQuery('unrealBlendJoint', node=sJ, exists=True)]
    for sFullJ in sBlendJoints:
        if cmds.getAttr('%s.unrealBlendJoint' % sFullJ) == True:
            sJ = sFullJ.split(':')[-1]
            sBlendFrom = cmds.getAttr('%s.blendFrom' % sFullJ)
            sBlendTo = cmds.getAttr('%s.blendTo' % sFullJ)
            fWeight = cmds.getAttr('%s.blendWeight' % sFullJ)
            sCommands = ['\n\n# Blend Joints']

            sCommands.append(f'# PIECE.START: {sJ}')
            sCommands.append('# PIECE.TYPE: blendJoint')

            sCommands.append(f"# PIECE.INPUTS: ['{sBlendFrom}', '{sBlendTo}']")
            sCommands.append(f"# PIECE.OUTPUTS: ['{sJ}']")

            sCommands.append(f"functions.blendJoints([('{sJ}', '{sBlendFrom}', '{sBlendTo}', {fWeight})])")
            sCommands.append(f'# PIECE.END: {sJ}')


            utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
            utilsUnreal.dumpUnrealCodeLinesToFile()





@builderTools.addToBuild(iOrder=130.17)
def unrealPythonInterpolators():
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sUnrealCommands = []
    sUnrealCommands.append(f'# PIECE.START: Interpolators')

    sUnrealCommands.append("nodes.startFunction('kangaroo_interpolators', bSequencer=False)")

    sUnrealCommands.append('\n\n#UplegUp Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('uplegType', node=sT, exists=True)]
    sMayaHip = 'jnt_m_hips'
    sHip = dUnrealJoints.get(sMayaHip, sMayaHip)

    ssLines = []
    ssInterpolators = []
    def _convertSpaceValue(iCurrentAxis, fValues):
        aMayaHipMatrix = utils.getNumpyMatrixFromTransform(sMayaHip)
        aHipMatrix = utils.getNumpyMatrixFromTransform('game:%s' % sHip)
        fPoints4 = [[0,0,0,1], [0,0,0,1]]
        for v,fV in enumerate(fValues):
            fPoints4[v][iCurrentAxis] = fV

        aGlobalPoints4 = np.dot(np.array(fPoints4, dtype='float64'), aMayaHipMatrix)
        aUnrealLocalPoints = np.dot(aGlobalPoints4, np.linalg.inv(aHipMatrix))
        aDiffs = np.abs(aUnrealLocalPoints[1] - aUnrealLocalPoints[0])
        iUnrealAxis = np.argmax(aDiffs)
        aUnrealValues = aUnrealLocalPoints[:,iUnrealAxis]
        if iUnrealAxis == 1:
            aUnrealValues *= -1.0
        return iUnrealAxis, list(aUnrealValues)


    for sInterp in sInterpolators:
        sSide = utils.getSide(sInterp)

        sMayaKnee = 'jnt_%s_leg_lowerTwist_000' % sSide
        sKnee = dUnrealJoints.get(sMayaKnee, sMayaKnee)

        sDrivenKeys = eval(cmds.getAttr('%s.drivenKeys' % sInterp))
        ffLocalPoints = []
        ffValues = []
        # sPoseTargets = []

        iCurrentAxes = [1,0,2]
        iUnrealAxes = []
        for a,sNode in enumerate(sDrivenKeys):
            fValues = cmds.keyframe(sNode, q=True, valueChange=True)
            ffValues.append(fValues)
            fTimes = cmds.keyframe(sNode, q=True, floatChange=True)
            iUnrealAxis, fUnrealTimes = _convertSpaceValue(iCurrentAxes[a], fTimes)
            ffLocalPoints.append(fUnrealTimes)
            iUnrealAxes.append(iUnrealAxis)

        ssLines.append([f"{sInterp}_up = functions.uplegUpInterpolator(bIsRight={sSide=='r'}) # (interpolator)"])
        ssInterpolators.append([f"{sInterp}_up"])


    # sUnrealCommands.append('\n\n#Angle Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('angleType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoints = eval(cmds.getAttr('%s.sJoints' % sInterp))
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        iCurveTypes = eval(cmds.getAttr('%s.iCurveTypes' % sInterp))
        ffAngleRanges = eval(cmds.getAttr('%s.ffAngleRanges' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        sPoseTargets = []
        sReturns = []
        ffPassRanges = []
        iPassCurveTypes = []
        for p,sPose in enumerate(sPoseNames):
            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue
            ffPassRanges.append(ffAngleRanges[p])
            # sPoseTargets.append(list(set(sTargets))) # it only takes one target currently
            sReturns.append('%s_%s' % (sInterp, sPose))
            iPassCurveTypes.append(iCurveTypes[p])
        if sReturns:
            sUnrealJoints = [dUnrealJoints.get(sJ, sJ) for sJ in sJoints]
            ssLines.append([f"{', '.join(sReturns)} = functions.angleInterpolator({str(sUnrealJoints)}, {str(ffPassRanges)}, iCurveTypes={iPassCurveTypes}) # {sInterp} (interpolator)"])
            ssInterpolators.append(sReturns)

    # sUnrealCommands.append('\n\n#Signed Angle Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('signedAngleType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoints = eval(cmds.getAttr('%s.sJoints' % sInterp))
        sTwist, sParent = sJoints

        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        iCurveTypes = eval(cmds.getAttr('%s.iCurveTypes' % sInterp))
        ffAngleRanges = eval(cmds.getAttr('%s.ffAngleValues' % sInterp))
        iForwardAxis = eval(cmds.getAttr('%s.iForwardAxis' % sInterp))
        iUpAxis = eval(cmds.getAttr('%s.iUpAxis' % sInterp))
        iAngleAxis = eval(cmds.getAttr('%s.iAngleAxis' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        # sPoseTargets = []
        sReturns = []
        ffPassRanges = []
        iPassCurveTypes = []
        for p,sPose in enumerate(sPoseNames):
            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue
            ffPassRanges.append(ffAngleRanges[p])
            sReturns.append('%s_%s' % (sInterp, sPose))
            iPassCurveTypes.append(iCurveTypes[p])
        if sReturns:
            iUnrealForwardAxis = xforms.getClosestAxis('game:%s' % dUnrealJoints.get(sTwist, sTwist), sTwist, iForwardAxis, bSigned=True)
            print ('iUnrealForwardAxis first: ', iUnrealForwardAxis)
            iUnrealUpAxis = xforms.getClosestAxis('game:%s' % dUnrealJoints.get(sTwist, sTwist), sTwist, iUpAxis, bSigned=True)
            if iUnrealForwardAxis == 1:
                iUnrealForwardAxis = 4
            elif iUnrealForwardAxis == 4:
                iUnrealForwardAxis = 1
            if iUnrealUpAxis == 1:
                iUnrealUpAxis = 4
            elif iUnrealUpAxis == 4:
                iUnrealUpAxis = 1

            fForwardVector = [0, 0, 0]
            fForwardVector[iUnrealForwardAxis % 3] = 1 if iUnrealForwardAxis < 3 else -1
            fUpVector = [0, 0, 0]
            fUpVector[iUnrealUpAxis % 3] = 1 if iUnrealUpAxis < 3 else -1
            ssLines.append([f"{', '.join(sReturns)} = functions.signedAngleInterpolator('{dUnrealJoints.get(sTwist, sTwist)}', '{dUnrealJoints.get(sParent, sParent)}', {str(ffPassRanges)}, "
                                   f"iCurveTypes={iPassCurveTypes}, iAngleAxis={iAngleAxis}, fForwardVector={fForwardVector}, fUpVector={fUpVector}) # {sInterp} (interpolator)"])
            ssInterpolators.append(sReturns)


    # sUnrealCommands.append('\n\n#Cone Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('coneType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoint = cmds.getAttr('%s.sJoint' % sInterp)
        sUnrealJoint = dUnrealJoints.get(sJoint, sJoint)
        sParent = cmds.getAttr('%s.sJointParent' % sInterp)
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        aPoint4 = np.array([1,0,0,1], dtype='float64')
        ffUnrealConePoints = []
        ffRanges = []
        sPoseTargets = []
        sReturns = []
        fJointLength = np.round(cmds.getAttr('%s.tx' % cmds.listRelatives(sJoint, c=True)[0]), 3)

        aJointMatrix = utils.getNumpyMatrixFromTransform(sJoint)
        aUnrealJointMatrix = utils.getNumpyMatrixFromTransform('game:%s' % sUnrealJoint)
        iCurveTypes = []
        for sPose in sPoseNames:
            sCone = '%s_%s_cone' % (sInterp, sPose)
            if not cmds.objExists(sCone):
                raise Exception('Cone "%s" doesn\'t exist' % sCone)

            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue

            iCurveTypes.append(cmds.getAttr('%s.curveType' % sCone))

            aConeMatrix = utils.getNumpyMatrixFromTransform(sCone, bWorld=False)
            aConeMatrix[0] *= fJointLength / np.linalg.norm(aConeMatrix[0])
            aConeMatrix[1] *= fJointLength / np.linalg.norm(aConeMatrix[1])
            aConeMatrix[2] *= fJointLength / np.linalg.norm(aConeMatrix[2])

            aConePoint = np.dot(aPoint4, aConeMatrix)
            aWorldPoint = np.dot(aConePoint, aJointMatrix)
            aUnrealPoint = np.dot(aWorldPoint, np.linalg.inv(aUnrealJointMatrix))

            sReturns.append('%s_%s' % (sInterp, sPose))
            ffUnrealConePoints.append((aUnrealPoint[0], -aUnrealPoint[1], aUnrealPoint[2]))
            ffRanges.append((cmds.getAttr('%s.innerAngle' % sCone), cmds.getAttr('%s.outerAngle' % sCone)))

        if sReturns:
            sUnrealParent = dUnrealJoints.get(sParent, sParent)
            ssLines.append([f"{', '.join(sReturns)} = functions.coneInterpolator('{sUnrealJoint}', '{sUnrealParent}', {True if utils.getSide(sUnrealJoint)=='r' else False}, {str(ffUnrealConePoints)}, {str(ffRanges)}, {str(iCurveTypes)}) # {sInterp} (interpolator)"])
            ssInterpolators.append(sReturns)

    # utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


    sTargetPlugs = utils.data.get(utilsUnreal.kBodyBlendShapeTargetList, xDefault=[])
    sCompletedsCurveNames = set()
    for sPlug in sTargetPlugs:

        sTargetCommands = []
        if utils.isNone(sPlug):
            continue
        sCurveName = sPlug.split('.')[-1]
        if sCurveName in sCompletedsCurveNames:
            continue
        sCompletedsCurveNames.add(sCurveName)

        sConns = cmds.listConnections(sPlug, s=True, d=False, p=True)
        if not sConns:
            continue
        sNode, sA = sConns[0].split('.')
        sFactorsAttr = '%s.sFactors_%s' % (sNode, sA)

        # if cmds.objExists(sFactorsAttr):
        sFactors = eval(cmds.getAttr(sFactorsAttr)) # this should always exist.
        # else:
        #     sFactors = [sConns[0]]

        sFactorNames = [sF.replace('.', '_') for sF in sFactors]

        if len(sFactors) > 1:
            sFinalAttr = '%s_output' % sNode
            sTargetCommands.append(f"{sFinalAttr} = nodes.createExtremeNode({utilsUnreal.listNice(sFactorNames)}, bMinimum=True)")
        else:
            sFinalAttr = sFactorNames[0]


        sTargetCommands.append(f"nodes.setCurveValueExecuteNode('{sCurveName}', {sFinalAttr})")
        iFoundInterpolators = [-1] * len(sFactorNames)
        for f,sFactorName in enumerate(sFactorNames):
            for i,sInterpolators in enumerate(ssInterpolators):
                if sFactorName in sInterpolators:
                    iFoundInterpolators[f] = i

        if -1 in iFoundInterpolators:
            iIndex = iFoundInterpolators.index(-1)
            raise Exception('no interpolator found for %s (%s) - ' % (sPlug, sFactorNames, sFactorNames[iIndex]))

        iLatestInterpolator = max(iFoundInterpolators)
        ssLines[iLatestInterpolator].extend(sTargetCommands)


    for i,sLines in enumerate(ssLines):
        sUnrealCommands.append('\n')
        sUnrealCommands.append(f'# interpolators: {ssInterpolators[i]}')
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCommands)
        sUnrealCommands.extend(sLines)

    sUnrealCommands.append("nodes.endCurrentFunction()")
    sUnrealCommands.append('# PIECE.INPUTS: %s' % str(list(sCompletedsCurveNames)))
    sUnrealCommands.append(f'# PIECE.END: Interpolators')

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()



@builderTools.addToBuild(iOrder=134)
def pythonUiify():
    for sFilePath in [utilsUnreal.createOutFilePath(), utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]:
        report.report.addLogText('Uiifying "%s"...' % sFilePath)
        bIndent = False
        with open(sFilePath) as sText:
            sAllLines = list(sText)

            # count pieces and add increment lines
            iPieceCounter = 0
            i = -1
            while i < len(sAllLines)-1:
                i += 1
                if 'unrealUI.incrementProgress()' in sAllLines[i]:
                    iPieceCounter += 1

            # add the try, and open UI function
            i = -1
            while i < len(sAllLines)-1:
                i += 1

                if sAllLines[i].startswith('eOrigin = '):
                    sInsertLines = []
                    sInsertLines.append("def run():\n")
                    sInsertLines.append("    unrealUI.logMessage('============ %s ============', bLogTimeWhenDone=False)\n" % assets.assetManager.getCurrentAsset())
                    sInsertLines.append("    fStartTime = time.time()\n")
                    sInsertLines.append("    try:\n")
                    sAllLines = sAllLines[0:i] + sInsertLines + sAllLines[i:]
                    i += len(sInsertLines)
                    bIndent = True

                if bIndent:
                    sAllLines[i] = "        %s" % sAllLines[i]

            # ending
            sAllLines.append("    except:\n")
            sAllLines.append("        sError = traceback.format_exc()\n")
            sAllLines.append("        unrealUI.logMessage(sError)\n")
            sAllLines.append("        raise\n")
            sAllLines.append("\n")
            sAllLines.append("    unrealUI.logMessage('\\nDone! It took %s' % (library.secondsNice(time.time()-fStartTime)))\n")
            sAllLines.append("\n")
            sAllLines.append("unrealUI.openWindow(run, %d)\n" % iPieceCounter)

        utils.createTextFile(sFilePath, sAllLines)


@builderTools.addToBuild(iOrder=130.3, bDisableByDefault=True)
def pythonBrowSplines():
    sUnrealCodeLines = ['\n\n# BROWS SPLINES\n']
    sUnrealCodeLines.append("unrealUI.logMessage('Brows Splines...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")

    aaaWeights = utils.data.get('browsSplineBsplineWeights')
    dDefaultSettingValuesBrows = utils.data.get('dDefaultSettingValuesBrows')

    sAllSculptPosesAttr = '%s.dAllSculptPoseDriverValues' % utils.getMasterName()
    if cmds.objExists(sAllSculptPosesAttr):
        dAllSculptPoseDriverValues = eval(cmds.getAttr(sAllSculptPosesAttr))
    else:
        dAllSculptPoseDriverValues = {}


    ssCtrls = [None, None]
    for s,sSide in enumerate(['l','r']):
        sUnrealCodeLines.append('\n\n## %s' % utils.sSides[s].upper())
        cMainCtrl = ctrls7.ctrlFromName('browMain_%s_ctrl' % sSide)
        utilsUnreal.createUnrealCtrl(cMainCtrl, sWriteCommands=sUnrealCodeLines)
        ssCtrls[s] = ['browSplinesA_%s_ctrl' % sSide, 'browSplinesB_%s_ctrl' % sSide, 'browSplinesC_%s_ctrl' % sSide]
        sAllTangentCtrls = []
        for sCtrl in ssCtrls[s]:
            cCtrl = ctrls7.ctrlFromName(sCtrl)
            utilsUnreal.createUnrealCtrl(cCtrl, bOut=True, sWriteCommands=sUnrealCodeLines) # sParentVar='%s.eControl' % cMainCtrl.sCtrl
            sTangentCtrls = eval(cmds.getAttr('%s.sTangentCtrls' % sCtrl))
            for sTangentCtrl in sTangentCtrls:
                utilsUnreal.createUnrealCtrl(ctrls7.ctrlFromName(sTangentCtrl), sParentVar='%s.eOut' % sCtrl, bExtraSliderScale=True, sWriteCommands=sUnrealCodeLines)
                sAllTangentCtrls.append(sTangentCtrl)
            sCurve = 'curve_%s_brows' % sSide
            pCurve = patch.patchFromName(sCurve)
            _, sInfluences, aaWeights = pCurve.getSkinCluster()
            aCurvePoints = pCurve.getPoints()
            sCtrlInfluences = [cmds.getAttr('%s.sCtrl' % sI) for sI in sInfluences]
            fPoints = []

            iInfluencesA = []
            iInfluencesB = []
            fInfluenceWeightsA = []
            for i in range(len(aaWeights)):
                fPoints.append(utilsUnreal.flipVectorToUnreal(list(aCurvePoints[i])))
                aInds = np.argsort(aaWeights[i])[::-1]
                fInfluenceWeightsA.append(aaWeights[i][aInds[0]])
                iInfluencesA.append(aInds[0])
                iInfluencesB.append(aInds[1])

        dPreSiblingValues = {}
        dPreSiblingDriverValues = {}
        dPostSiblingValues = defaultdict(dict)
        dPostSiblingDriverValues = defaultdict(dict)
        dTangentPreSiblingValues = defaultdict(dict)
        dTangentPreSiblingDriverValues = defaultdict(dict)
        print ('dDefaultSettingValuesBrows: ', dDefaultSettingValuesBrows)
        for sAttr,fValue in dDefaultSettingValuesBrows.items():
            sSibling, sA = sAttr.split('.')
            if utils.getSide(sAttr) == sSide:
                if 'preSibling' in sAttr:
                    if sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'translateX', 'translateY', 'translateZ', 'rotateX', 'rotateY', 'rotateZ'] and abs(fValue) > 0.01:
                        sCtrl = utils.getStringAttr(sSibling, 'sCtrl', None)
                        iControlIndex = ['browSplinesA_%s_ctrl' % sSide, 'browSplinesB_%s_ctrl' % sSide, 'browSplinesC_%s_ctrl' % sSide].index(sCtrl)
                        dUnrealA = {'tx':'TranslateX', 'ty':'TranslateZ', 'tz':'TranslateY'}
                        sUnrealAttr = '%d.%s' % (iControlIndex, dUnrealA[sA])
                        dPreSiblingValues[sUnrealAttr] = fValue
                        dPreSiblingDriverValues[iControlIndex] = cmds.getAttr('%s.driverCtrlValue' % sSibling)
                elif 'preTangentSibling' in sAttr:
                    if sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'translateX', 'translateY', 'translateZ', 'rotateX', 'rotateY', 'rotateZ'] and abs(fValue) > 0.01:
                        sNameChain = utils.camelToChain(sSibling).split('_')
                        sDirection = sNameChain[-1]
                        sCtrl = utils.getStringAttr(sSibling, 'sCtrl', None)
                        iControlIndex = ['browTangentAOut_%s_ctrl' % sSide, 'browTangentBIn_%s_ctrl' % sSide, 'browTangentBOut_%s_ctrl' % sSide, 'browTangentCIn_%s_ctrl' % sSide].index(sCtrl)
                        dUnrealA = {'rx':'RotateX', 'ry':'RotateY', 'rz':'RotateY'}
                        sUnrealAttr = '%d.%s' % (iControlIndex, dUnrealA[sA])
                        dTangentPreSiblingValues[sDirection][sUnrealAttr] = -fValue
                        dTangentPreSiblingDriverValues[sDirection][iControlIndex] = cmds.getAttr('%s.driverCtrlValue' % sSibling)
                elif 'postSibling' in sAttr:
                    print ('sA: ', sA)
                    if sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'translateX', 'translateY', 'translateZ', 'rotateX', 'rotateY', 'rotateZ'] and  abs(fValue) > 0.01:
                        sNameChain = utils.camelToChain(sSibling).split('_')
                        sDirection = sNameChain[-1]
                        sCtrl = utils.getStringAttr(sSibling, 'sCtrl', None)
                        iControlIndex = ['browSplinesA_%s_ctrl' % sSide, 'browSplinesB_%s_ctrl' % sSide, 'browSplinesC_%s_ctrl' % sSide].index(sCtrl)
                        dUnrealA = {'rx':'RotateX', 'ry':'RotateY', 'rz':'RotateY'}
                        sUnrealAttr = '%d.%s' % (iControlIndex, dUnrealA[sA])
                        dPostSiblingValues[sDirection][sUnrealAttr] = -fValue
                        dPostSiblingDriverValues[sDirection][iControlIndex] = cmds.getAttr('%s.driverCtrlValue' % sSibling)




        sJoints = sorted(cmds.ls('jnt_%s_brows_???' % sSide, et='joint'))
        fVerticalDefaults = [cmds.getAttr('%s.defaultY' % sJ) for sJ in sJoints]
        fVerticalDowns = [cmds.getAttr('%s.verticalDownPose' % sJ) for sJ in sJoints]
        fVerticalUps = [cmds.getAttr('%s.verticalUpPose' % sJ) for sJ in sJoints]
        sUnrealCodeLines.append(f"sBrows_{sSide} = functions.browSplines(cMainCtrl={cMainCtrl.sCtrl}, cCtrls={utilsUnreal.listNice(ssCtrls[s])}, "
                                f"cTangentCtrls={utilsUnreal.listNice(sAllTangentCtrls)}, fPoints={str(fPoints)}, sSplineInfluences={sCtrlInfluences}, iSplineInfluencesA={str(iInfluencesA)}, iSplineInfluencesB={str(iInfluencesB)}, fSplineInfluenceWeightsA={str(fInfluenceWeightsA)}, "
                                f"\n\t\t\t\tsJoints={str(sJoints)}, fJointWeights0={list(aaaWeights[s][0])}, fJointWeights1={list(aaaWeights[s][1])}, sSide='{sSide}', "
                                f"\n\t\t\t\tdPreSiblingValues={str(dict(dPreSiblingValues))}, dPreSiblingDriverValues={str(dPreSiblingDriverValues)}, "
                                f"\n\t\t\t\tdTangentPreSiblingValuesAllDirections={str(dict(dTangentPreSiblingValues))}, dTangentPreSiblingDriverValuesAllDirections={str(dict(dTangentPreSiblingDriverValues))},"
                                f"\n\t\t\t\tdPostSiblingValuesAllDirections={str(dict(dPostSiblingValues))}, dPostSiblingDriverValuesAllDirections={str(dict(dPostSiblingDriverValues))},"
                                f"\n\t\t\t\tfVerticalDefaults={str(fVerticalDefaults)}, fVerticalDowns={str(fVerticalDowns)}, fVerticalUps={str(fVerticalUps)})")

        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)
        sUnrealCodeLines.append(f"{sSide}_BrowTotalTranslate0 = hierarchy.newVariable('{sSide}_BrowTotalTranslate0', sType='FVector', bLocal=False)")
        sUnrealCodeLines.append(f"nodes.createSetVariableExecuteNode({sSide}_BrowTotalTranslate0, '%s.ControlTotalTranslate0' % sBrows_{sSide})")

    cMiddle = ctrls7.ctrlFromName('browMiddle_ctrl')
    sMiddleDefaultJoint = 'jnt_m_browMiddleDefault'
    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)
    utilsUnreal.createUnrealCtrl(cMiddle, sWriteCommands=sUnrealCodeLines)
    sUnrealCodeLines.append(f"sMiddleBrow = functions.browsMiddle(cMiddle={cMiddle.sCtrl}, sBone='jnt_m_browMiddle', sBoneDefault='jnt_m_browMiddleDefault', sBrowsNodeLeft=sBrows_l, sBrowsNodeRight=sBrows_r, "
                            f"\n\t\t\t\tcBrowsControlLeft={ssCtrls[0][0]}, cBrowsControlRight={ssCtrls[1][0]}, "
                            f"\n\t\t\t\tfFollow={cmds.getAttr('%s.follow' % cMiddle.sCtrl)}, fAutoPush={cmds.getAttr('%s.autoPush' % cMiddle.sCtrl)}, fAutoScale={cmds.getAttr('%s.autoScale' % cMiddle.sCtrl)}, "
                            f"\n\t\t\t\tfVerticalDefault={cmds.getAttr('%s.defaultY' % sMiddleDefaultJoint)}, fVerticalDown={cmds.getAttr('%s.verticalDownPose' % sMiddleDefaultJoint)}, fVerticalUp={cmds.getAttr('%s.verticalUpPose' % sMiddleDefaultJoint)})")
    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)


    sUnrealCodeLines.append(f"functions.browsToVariables(sBrows_l, sBrows_r, sMiddleBrow, {len(sJoints)*2 + 1})")
    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=131.02, bDisableByDefault=True)
def pythonLidSplines():

    utils.reload2(utilsUnreal)
    sUnrealCodeLines = ['\n\n# LID SPLINES \n']
    sUnrealCodeLines.append("unrealUI.logMessage('Lid Splines...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")

    sEyeTransformCtrls = [utilsUnreal.ctrlInitFromExisting('eyeTransform_l_ctrl', sUnrealCodeLines), utilsUnreal.ctrlInitFromExisting('eyeTransform_r_ctrl', sUnrealCodeLines)]
    # aEyeTransformJointMatrices = [utils.getNumpyMatrixFromTransform('jnt_l_eyeTransform'), utils.getNumpyMatrixFromTransform('jnt_r_eyeTransform')]
    # aInvEyeTransformJointMatrices = [np.linalg.inv(aEyeTransformJointMatrices[0]), np.linalg.inv(aEyeTransformJointMatrices[1])]
    # aaaMaxPoints = [[], []]
    for s,sSide in enumerate(['l', 'r']):

        ccCtrls = [None, None]
        sUnrealCodeLines.append('\n\n## %s' % utils.sSides[s].upper())
        cCornerCtrls = [ctrls7.ctrlFromName('eyeSplineCornerIn_%s_ctrl' % sSide), ctrls7.ctrlFromName('eyeSplineCornerOut_%s_ctrl' % sSide)]
        cCornerCtrls[0].cTangents = []
        cCornerCtrls[1].cTangents = []
        utilsUnreal.createUnrealCtrl(cCornerCtrls[0], bOut=True, sParentVar='%s.eControl' % sEyeTransformCtrls[s], sWriteCommands=sUnrealCodeLines)
        utilsUnreal.createUnrealCtrl(cCornerCtrls[1], bOut=True, sParentVar='%s.eControl' % sEyeTransformCtrls[s], sWriteCommands=sUnrealCodeLines)

        # ssMaxNulls = [], []
        xxCtrlWeights = [], []
        for p,sPart in enumerate(['bot','top']):
            cCtrls = [ctrls7.ctrlFromName(sC) for sC in cmds.ls('eyeSpline%s?_%s_ctrl' % (sPart.title(), sSide), et='transform')]
            for cCtrl in cCtrls:
                utilsUnreal.createUnrealCtrl(cCtrl, bOut=True, sParentVar='%s.eControl' % sEyeTransformCtrls[s], sWriteCommands=sUnrealCodeLines)
            ccCtrls[p] = cCtrls

            cTangentIn = ctrls7.ctrlFromName('eyeSplineCornerInTangent%s_%s_ctrl' % (sPart.title(), sSide))
            cTangentOut = ctrls7.ctrlFromName('eyeSplineCornerOutTangent%s_%s_ctrl' % (sPart.title(), sSide))
            utilsUnreal.createUnrealCtrl(cTangentIn, sParentVar='%s.eControl' % cCornerCtrls[0].sCtrl, sShapeName='Square_Thick', sWriteCommands=sUnrealCodeLines)
            utilsUnreal.createUnrealCtrl(cTangentOut, sParentVar='%s.eControl' % cCornerCtrls[1].sCtrl, sShapeName='Square_Thick', sWriteCommands=sUnrealCodeLines)
            cCornerCtrls[0].cTangents.append(cTangentIn)
            cCornerCtrls[1].cTangents.append(cTangentOut)

            aMaxPointsBot = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineMaxBlendingBot' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aMaxPointsTop = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineMaxBlendingTop' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aMaxPointsBot[:,1] *= -1.0 # Negating Y to translate to Unreal
            aMaxPointsTop[:,1] *= -1.0 # Negating Y to translate to Unreal
            aPointsBot = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineBlendingBot' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aPointsTop = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineBlendingTop' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aPointsBot[:,1] *= -1.0 # Negating Y to translate to Unreal
            aPointsTop[:,1] *= -1.0 # Negating Y to translate to Unreal


            sCombinedCurve = 'curve_%s_%sCombined' % (sSide, sPart)
            _, sCtrlInfluences, aaCtrlWeights = patch.patchFromName(sCombinedCurve).getSkinCluster(sChooseSkinCluster='skinCluster__%s__CTRLS' % sCombinedCurve)
            for i in range(len(aaCtrlWeights)): # per vertex
                aBiggest = np.argsort(aaCtrlWeights[i])[::-1]
                xxCtrlWeights[p].append([(cmds.getAttr('%s.sCtrl' % sCtrlInfluences[aBiggest[0]]), cmds.getAttr('%s.sCtrl' % sCtrlInfluences[aBiggest[1]])),
                                         (aaCtrlWeights[i,aBiggest[0]], aaCtrlWeights[i,aBiggest[1]])])

        cBlink = ctrls7.ctrlFromName('blink_%s_ctrl' % sSide)
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)



        sUnrealCodeLines.append(f"LidSplines_{sSide} = functions.lidSplines(cMainCtrl={sEyeTransformCtrls[s]}, cBotCtrls={utilsUnreal.listNice(ccCtrls[0])}, cTopCtrls={utilsUnreal.listNice(ccCtrls[1])},"
                                f"\n\t\t\t\tcCornerCtrls={utilsUnreal.listNice(cCornerCtrls)}, cTangentInCtrls={utilsUnreal.listNice(cCornerCtrls[0].cTangents)}, cTangentOutCtrls={utilsUnreal.listNice(cCornerCtrls[1].cTangents)},"
                                f"\n\t\t\t\tffBotMaxPoints={utilsUnreal.listNice(aMaxPointsBot)},"
                                f"\n\t\t\t\tffTopMaxPoints={utilsUnreal.listNice(aMaxPointsTop)},"#
                                f"\n\t\t\t\tffBotPoints={utilsUnreal.listNice(aPointsBot[1:-1])},"
                                f"\n\t\t\t\tffTopPoints={utilsUnreal.listNice(aPointsTop)},"#
                                f"\n\t\t\t\tsBotBones={str(cmds.ls('jnt_%s_botSkinLidSpline_???' % sSide, et='joint'))},"#
                                f"\n\t\t\t\tsTopBones={str(cmds.ls('jnt_%s_topSkinLidSpline_???' % sSide, et='joint'))},"#
                                f"\n\t\t\t\txCtrlWeightsBot={str(xxCtrlWeights[0][1:-1])},"#
                                f"\n\t\t\t\txCtrlWeightsTop={str(xxCtrlWeights[1])},"#
                                f"\n\t\t\t\tcBlink={cBlink.sCtrl}, fDefaultBlinkLine={cmds.getAttr('%s.blinkLine' % cBlink.sCtrl)}, sTransformBone='jnt_{sSide}_eyeTransform', fBlinkOverShoot={cmds.getAttr('%s.overShootOnBlinkFactor' % cBlink.sPasser)}, fLivePole={cmds.getAttr('%s.livePole' % cBlink.sPasser)})")#
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)
        sUnrealCodeLines.append(f"{sSide}_blendCurveBot = hierarchy.newVariable('{sSide}_blendCurveBot', 'double', bLocal=False)")
        sUnrealCodeLines.append(f"nodes.createSetVariableExecuteNode({sSide}_blendCurveBot, '%s.BlendCurveBot' % LidSplines_{sSide})")
        sUnrealCodeLines.append(f"{sSide}_blendCurveTop = hierarchy.newVariable('{sSide}_blendCurveTop', 'double', bLocal=False)")
        sUnrealCodeLines.append(f"nodes.createSetVariableExecuteNode({sSide}_blendCurveTop, '%s.BlendCurveTop' % LidSplines_{sSide})")

    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=131.03, bDisableByDefault=True)
def pythonLips():

    sUnrealCodeLines = ['\n\n# LIPS \n']
    sUnrealCodeLines.append("unrealUI.logMessage('Lips ...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")


    ccRows = [[ctrls7.ctrlFromName(sC) for sC in nodes.data.get('lipsBotRow')],
              [ctrls7.ctrlFromName(sC) for sC in nodes.data.get('lipsTopRow')]]
    dJawAttaches = {cC.sCtrl:cmds.getAttr('%s.jawAttach' % cC.sCtrl) for cC in utils.flattenedList(ccRows)}

    dFollowCornerPathOuts, dFollowCornerPathIns, dFollowCornerZs, dAimToNeighbors = {}, {}, {}, {}
    for cC in utils.flattenedList(ccRows):
        for sA, dD in [('followCornerPathOut', dFollowCornerPathOuts), ('followCornerPathIn', dFollowCornerPathIns), ('followCornerY', dFollowCornerZs), ('aimToNeighbors', dAimToNeighbors)]:
            sAttr = '%s.%s' % (cC.sPasser, sA)
            if cmds.objExists(sAttr):
                dD[cC.sCtrl] = cmds.getAttr(sAttr)

    cStrRows = [[utilsUnreal.createUnrealCtrl(cC, bOffsets=True, sSkipOffsets=['extramove'], sTrsValuesOnOffsets=['pivot'],
                                                    bMatchPasser=True, bOut=True, bExtraSliderScale=True, sWriteCommands=sUnrealCodeLines) for cC in ccRows[0]],
                [utilsUnreal.createUnrealCtrl(cC, bOffsets=True, sSkipOffsets=['extramove'], sTrsValuesOnOffsets=['pivot'],
                                                    bMatchPasser=True, bOut=True, bExtraSliderScale=True, sWriteCommands=sUnrealCodeLines) for cC in ccRows[1][1:-1]]]

    # cStrBotTop = [utilsUnreal.createUnrealCtrl(ctrls7.ctrlFromName('mouthBot_ctrl'), bOffsets=True, bMatchPasser=True, sWriteCommands=sUnrealCodeLines),
    #               utilsUnreal.createUnrealCtrl(ctrls7.ctrlFromName('mouthTop_ctrl'), bOffsets=True, bMatchPasser=True, sWriteCommands=sUnrealCodeLines)]

    cStrCornerTangents = []
    for sCtrl in ['cornerTangentBot_l_ctrl',  'cornerTangentBot_r_ctrl', 'cornerTangentTop_l_ctrl', 'cornerTangentTop_r_ctrl']:
        cC = ctrls7.ctrlFromName(sCtrl)
        cStrCornerTangents.append(utilsUnreal.createUnrealCtrl(cC, bOffsets=True, bMatchPasser=True, bExtraSliderScale=True, sWriteCommands=sUnrealCodeLines))


    sStrMouthPivot = utilsUnreal.createUnrealNull('loc_m_mouthPivot', 'loc_m_mouthPivot', sWriteCommands=sUnrealCodeLines)

    ccStrLips = [cStrRows[0][1:-1], cStrRows[1]]
    fVerticalTranslates = [cmds.getAttr('grp_m_mouthPasser.verticalTranslateStrength%s' % sA) for sA in ['X','Y','Z']]
    fHorizontalTranslates = [cmds.getAttr('grp_m_mouthPasser.horizontalTranslateStrength%s' % sA) for sA in ['X','Y','Z']]
    fMouthTranslateMultiplier = utils.data.get('fMouthTranslateMultiplier')

    fHorizontalTranslates = [fHorizontalTranslates[1] * fMouthTranslateMultiplier,
                             -fHorizontalTranslates[0] * fMouthTranslateMultiplier,
                             -fHorizontalTranslates[2] * fMouthTranslateMultiplier]
    fVerticalTranslates = [fVerticalTranslates[1] * fMouthTranslateMultiplier,
                             -fVerticalTranslates[0] * fMouthTranslateMultiplier,
                             -fVerticalTranslates[2] * fMouthTranslateMultiplier]
    fVerticalRotate = -cmds.getAttr('grp_m_mouthPasser.verticalRotateStrength')
    fHorizonalRotate = -cmds.getAttr('grp_m_mouthPasser.horizontalRotateStrength')

    ffCurvePoints = []
    for sCurve in ['curve_l_mouthStaticSlide', 'curve_r_mouthStaticSlide', 'curve_l_mouthStaticSlideUp', 'curve_r_mouthStaticSlideUp', 'curve_l_cornerSlideCurve', 'curve_r_cornerSlideCurve']:
        aPoints = patch.patchFromName(sCurve).getPoints()
        fPoints = [utilsUnreal.flipVectorToUnreal(aP) for aP in aPoints]
        ffCurvePoints.append(fPoints)

    dPercParamsStaticCurve = utils.data.get('dPercParamsStaticCurve')
    dDistancesToCorner = utils.data.get('dDistancesToCorner')



    sUnrealCodeLines.append(f"sLipsNode, eBotInfluences, eTopInfluences = functions.lips(cCorners=[{cStrRows[0][0]}, {cStrRows[0][-1]}], ccLips=[{utilsUnreal.listNice(ccStrLips[0])}, {utilsUnreal.listNice(ccStrLips[1])}],"
                            f"\n\t\t\t\tcCornerTangents={utilsUnreal.listNice(cStrCornerTangents)}, "
                            f"\n\t\t\t\tdJawAttaches={dJawAttaches}, dFollowCornerZs={dFollowCornerZs}, dFollowCornerPathIns={dFollowCornerPathIns}, dFollowCornerPathOuts={dFollowCornerPathOuts}, dAimToNeighbors={dAimToNeighbors},"
                            f"\n\t\t\t\tdPercParamsStaticCurve={dPercParamsStaticCurve}, dDistancesToCorner={dDistancesToCorner},"
                            f"\n\t\t\t\tcBotTops=[mouthBot_ctrl, mouthTop_ctrl],"
                            f"\n\t\t\t\tsMouthPivot={sStrMouthPivot}, fVerticalTranslates={fVerticalTranslates}, fHorizontalTranslates={fHorizontalTranslates}, fVerticalRotate={fVerticalRotate}, fHorizontalRotate={fHorizonalRotate},"
                            f"\n\t\t\t\tffTwoStaticSlideCurvePoints=[{ffCurvePoints[0]}, {ffCurvePoints[1]}],"
                            f"\n\t\t\t\tffTwoStaticSlideCurvePointsUp=[{ffCurvePoints[2]}, {ffCurvePoints[3]}],"
                            f"\n\t\t\t\tffTwoCornerSlideCurves=[{ffCurvePoints[4]}, {ffCurvePoints[5]}],"
                            f"\n\t\t\t\tflipCornerSlideParamsLeft={utilsUnreal.listNice(utils.data.get('l_lipCornerSlideParamsUnreal'))}, flipCornerSlideParamsRight={utilsUnreal.listNice(utils.data.get('r_lipCornerSlideParamsUnreal'))},"
                            f")")
    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)



    ffCurvePoints = []
    iiInfluencesA = [], []
    iiInfluencesB = [], []
    iiInfluencesC = [], []
    ffInfluenceWeightsA = [], []
    ffInfluenceWeightsB = [], []
    ffInfluenceWeightsC = [], []

    for c,sCurve in enumerate(['curve_m_botMouth', 'curve_m_topMouth']):
        aPoints = patch.patchFromName(sCurve).getPoints()
        fPoints = [utilsUnreal.flipVectorToUnreal(aP) for aP in aPoints]
        ffCurvePoints.append(fPoints)
        _, sInfluences, aaWeights = patch.patchFromName(sCurve).getSkinCluster()

        for i in range(len(aaWeights)):
            aInds = np.argsort(aaWeights[i])[::-1]
            ffInfluenceWeightsA[c].append(aaWeights[i][aInds[0]])
            ffInfluenceWeightsB[c].append(aaWeights[i][aInds[1]])
            ffInfluenceWeightsC[c].append(aaWeights[i][aInds[2]])
            iiInfluencesA[c].append(aInds[0])
            iiInfluencesB[c].append(aInds[1])
            iiInfluencesC[c].append(aInds[2])



    sUnrealCodeLines.append(f"LipsSplines = functions.lipsSplines(cCorners=[{cStrRows[0][0]}, {cStrRows[0][-1]}], ccLips=[{utilsUnreal.listNice(ccStrLips[0])}, {utilsUnreal.listNice(ccStrLips[1])}], "
                            f"\n\t\t\t\tffBotCurvePoints={ffCurvePoints[0]}, "
                            f"\n\t\t\t\tffTopCurvePoints={ffCurvePoints[1]},"
                            f"\n\t\t\t\tdJawAttaches={dJawAttaches},"
                            f"\n\t\t\t\tfLipsEndFollowMouthT={cmds.getAttr('grp_m_mouthPasser.lipsEndFollowMouthT')},"
                            f"\n\t\t\t\tfLipsEndFollowMouthR={cmds.getAttr('grp_m_mouthPasser.lipsEndFollowMouthR')},"
                            f"\n\t\t\t\tsLipsSmallJointsBot={utils.data.get('sLipsSmallJointsBot')},"
                            f"\n\t\t\t\tsLipsSmallJointsTop={utils.data.get('sLipsSmallJointsTop')},"
                            f"\n\t\t\t\tsLipsBigJointsBot={utils.data.get('sLipsBigJointsBot')},"
                            f"\n\t\t\t\tsLipsBigJointsTop={utils.data.get('sLipsBigJointsTop')},"
                            f"\n\t\t\t\teBotInfluences=eBotInfluences, eTopInfluences=eTopInfluences,"
                            f"\n\t\t\t\tiBotInfluencesA={iiInfluencesA[0]}, ffBotInfluenceWeightsA={ffInfluenceWeightsA[0]},"
                            f"\n\t\t\t\tiBotInfluencesB={iiInfluencesB[0]}, ffBotInfluenceWeightsB={ffInfluenceWeightsB[0]},"
                            f"\n\t\t\t\tiBotInfluencesC={iiInfluencesC[0]}, ffBotInfluenceWeightsC={ffInfluenceWeightsC[0]},"
                            f"\n\t\t\t\tiTopInfluencesA={iiInfluencesA[1]}, ffTopInfluenceWeightsA={ffInfluenceWeightsA[1]},"
                            f"\n\t\t\t\tiTopInfluencesB={iiInfluencesB[1]}, ffTopInfluenceWeightsB={ffInfluenceWeightsB[1]},"
                            f"\n\t\t\t\tiTopInfluencesC={iiInfluencesC[1]}, ffTopInfluenceWeightsC={ffInfluenceWeightsC[1]},"
                            f"\n\t\t\t\tfLipsParamsBot={utils.data.get('fLipsParamsNormalizedBot')}, fLipsParamsTop={utils.data.get('fLipsParamsNormalizedTop')},"
                            f"\n\t\t\t\txMouthCtrlWeightingsBot={utils.data.get('xMouthCtrlWeightingsBot')},"
                            f"\n\t\t\t\txMouthCtrlWeightingsTop={utils.data.get('xMouthCtrlWeightingsTop')},"
                            ")")


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()



@builderTools.addToBuild(iOrder=130.2)
def pythonSortLimbs():
    for sFilePath in [utilsUnreal.createOutFilePath(), utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]:
        with open(sFilePath) as sText:
            sAllLines = list(sText)
            dAllPieces = []
            i = -1
            while True:
                i += 1
                if i >= len(sAllLines):
                    break
                if '# PIECE.START' in sAllLines[i]:
                    print ('piece start: ', sAllLines[i])
                    sName = sAllLines[i].split(':')[-1].strip()
                    dNewPiece = {'sName':sName, 'sInputs':[], 'sOutputs':[], 'sType':None, 'sReplacedLines':False}
                    for k in range(i+1, len(sAllLines), 1):
                        if sAllLines[k].startswith('# PIECE.INPUTS'):
                            sInputs = eval(sAllLines[k].split(':')[-1])
                            dNewPiece['sInputs'].extend(sInputs)
                        if sAllLines[k].startswith('# PIECE.TYPE'):
                            dNewPiece['sType'] = sAllLines[k].split(':')[-1].strip()
                        elif sAllLines[k].startswith('# PIECE.OUTPUTS'):
                            sString = sAllLines[k].split(':')[-1]
                            sInputs = eval(sString)
                            dNewPiece['sOutputs'].extend(sInputs)
                        elif sAllLines[k].startswith('# PIECE.END'):
                            dNewPiece['iLineRange'] = [i,k+1]
                            dAllPieces.append(dNewPiece)
                            i = k
                            break


        for i,dPiece in enumerate(dAllPieces):
            dPiece['sInputs'] = set(dPiece['sInputs'])
            dPiece['sOutputs'] = set(dPiece['sOutputs'])
            dAllPieces[i] = dPiece

        iOrder = list(range(len(dAllPieces)))
        for iCount in range(len(dAllPieces)): # until we don't have anymore
            bDidSomething = False
            for i in range(len(iOrder)):
                iInd = iOrder[i]
                for k in range(len(iOrder)-1, i, -1):
                    if dAllPieces[iInd]['sInputs'].intersection(dAllPieces[iOrder[k]]['sOutputs']):
                        report.report.addLogText('moving %s to after %s' % (dAllPieces[iInd]['sName'], dAllPieces[iOrder[k]]['sName']))
                        iOrder.pop(i)
                        iOrder.insert(k, iInd)
                        bDidSomething = True
                        break
            if not bDidSomething:
                break
        report.report.addLogText('sorted %d times' % iCount)

        sAllLinesCopy = list(sAllLines)
        for dPiece in dAllPieces[::-1]:
            print ('removing lines from %s' % dPiece['sName'])
            iRange = dPiece['iLineRange']
            del sAllLines[iRange[0]:iRange[1]]


        dOrderedPieces = [dAllPieces[i] for i in iOrder]

        def _getGroups(sType):
            iiGroups = []
            i = -1
            while i < len(dOrderedPieces) - 1:
                i += 1
                if dOrderedPieces[i]['sType'] == sType:
                    iiGroups.append([i, None])
                    while i < len(dOrderedPieces):
                        i += 1
                        if i >= len(dOrderedPieces) or dOrderedPieces[i]['sType'] != sType:
                            iiGroups[-1][1] = i
                            break
            return iiGroups

        # combine muscles into functions
        iiMuscleGroups = _getGroups('muscleJoint')
        for i,iMuscleGroup in enumerate(iiMuscleGroups[::-1]):
            sFunctionName = 'Muscles %s' % utils.getLetter(len(iiMuscleGroups)-i-1)
            dGroupedPiece = {}
            dGroupedPiece['sType'] = 'Muscle Group'
            sReplacedLines = ['\n', '\n']
            sReplacedLines.append("unrealUI.logMessage('%s...')\n" % sFunctionName)
            sReplacedLines.append("unrealUI.incrementProgress()\n")

            sReplacedLines.append('controllers.setNewColumn()\n')
            sReplacedLines.append("nodes.startFunction('%s') # muscle group function" % sFunctionName)
            for dPiece in dOrderedPieces[iMuscleGroup[0]:iMuscleGroup[1]]:
                iRange = dPiece['iLineRange']
                sReplacedLines.extend(['\n'] + sAllLinesCopy[iRange[0]:iRange[1]] + ['\n'])
            sReplacedLines.append("nodes.endCurrentFunction() # muscle group function")

            dGroupedPiece['sReplacedLines'] = sReplacedLines
            del dOrderedPieces[iMuscleGroup[0]:iMuscleGroup[1]]
            dOrderedPieces.insert(iMuscleGroup[0], dGroupedPiece)


        # combine blendJoints into functions
        iiBlendGroups = _getGroups('blendJoint')
        for iBlendGroup in iiBlendGroups[::-1]:
            dGroupedPiece = {}
            dGroupedPiece['sType'] = 'Blend Group'
            sReplacedLines = ['\n', '\n']
            sReplacedLines.append("unrealUI.logMessage('Blend Joints...')\n")
            sReplacedLines.append("unrealUI.incrementProgress()\n")

            sAttributeStrings = []
            for dPiece in dOrderedPieces[iBlendGroup[0]:iBlendGroup[1]]:
                iRange = dPiece['iLineRange']
                for sLine in sAllLinesCopy[iRange[0]:iRange[1]]:
                    print('sLine: ', sLine)
                    if sLine.strip().startswith('functions.blendJoints(['): # functions.blendJoints([('jnt_l_arm_lowerTwist_000Blend', 'upperarm_twist_03_l', 'lowerarm_l')])
                        iStartIndex = sLine.rfind('(')
                        iEndIndex = sLine.find(')')
                        sAttributeStrings.append(sLine[iStartIndex:iEndIndex+1])
                        break
            sReplacedLines.append('functions.blendJoints([%s]) # combined' % ', '.join(sAttributeStrings))
            dGroupedPiece['sReplacedLines'] = sReplacedLines
            del dOrderedPieces[iBlendGroup[0]:iBlendGroup[1]]
            dOrderedPieces.insert(iBlendGroup[0], dGroupedPiece)


        # with dOrderPieces create sNewLinesChain that we can later put into the File
        sNewLinesChain = []
        for dPiece in dOrderedPieces:
            sReplacedLines = dPiece['sReplacedLines']
            if sReplacedLines:
                sNewLinesChain.extend(sReplacedLines)
            else:
                iRange = dPiece['iLineRange']
                sNewLinesChain.extend(['\n'] + sAllLinesCopy[iRange[0]:iRange[1]] + ['\n'])


        # put sNewLinesChain into the File
        iStartLine = dAllPieces[0]['iLineRange'][0]
        sAllLines = sAllLines[:iStartLine] + sNewLinesChain + sAllLines[iStartLine:]
        utils.createTextFile(sFilePath, sAllLines)



@builderTools.addToBuild(iOrder=131, dButtons={}, bDisableByDefault=False)
def pythonUnrealSliderCtrls(sSkipCtrls=[]):
    utilsUnreal.generateSliderCtrlsCode(sSkipCtrls=sSkipCtrls)



@builderTools.addToBuild(iOrder=131.1, dButtons={}, bDisableByDefault=False)
def pythonUnrealSimpleLidSetup():
    sUnrealCodeLines = ['\n\n# Lid Setup\n\n']
    sUnrealCodeLines.append("unrealUI.logMessage('Lid Setup...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")
    sUnrealCodeLines.append("sAllEyePosesFunction = nodes.startFunction('allEyePoses', bMutable=True, bSequencer=True)")

    for s, sSide in enumerate(['l', 'r']):
        utilsUnreal.newSequencerPlug(sWriteCommands=sUnrealCodeLines)

        sUnrealCodeLines.append("controllers.openCommentBox('Joint Poses %s_eye')" % sSide)

        ssUnrealTranslations = [], []
        ssUnrealRotations = [], []
        ssUnrealScales = [], []

        for p, sPart in enumerate(['bot', 'top']):
            sSiblingBlinkMain = 'grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingWideMain = 'grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraDown = 'grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraUp = 'grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sList = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp]
            for sT in sList:
                ssUnrealTranslations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.t' % sT)[0], bBoneSpace=True))
                ssUnrealRotations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.r' % sT)[0], bEuler=True, bBoneSpace=True))
                ssUnrealScales[p].append(cmds.getAttr('%s.s' % sT)[0])

        sUnrealCodeLines.append(f"functions.lidSetup([{ssUnrealTranslations[0]}, {ssUnrealRotations[0]}, {ssUnrealScales[0]}], "
                                f"\n\t\t\t[{ssUnrealTranslations[1]}, {ssUnrealRotations[1]}, {ssUnrealScales[1]}], sSide='{sSide}', sLookVertVarName='lookVert_{'%s_eye' % sSide}', sLookHorizVarName='lookHoriz_{'%s_eye' % sSide}')")

        sUnrealCodeLines.append("controllers.closeCommentBox('Joint Poses %s_eye')" % sSide)

    sUnrealCodeLines.append("nodes.endCurrentFunction(bAddToExecute=True)")

    report.report.addLogText('\n'.join(sUnrealCodeLines), bPrint=True)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()




@builderTools.addToBuild(iOrder=131.2, dButtons={}, bDisableByDefault=False)
def pythonParallelAttachSliders(iMaxTargetsAttach=16, iMaxJointAttach=8):

    sUnrealCommands = ['\n\n#Transform SliderCtrl Passers\n']
    sUnrealCommands.append("unrealUI.logMessage('Transform SliderCtrl Passers...')")
    sUnrealCommands.append("unrealUI.incrementProgress()")

    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("nodes.startFunction('kangaroo_transformSliderPassers', bSequencer=False)")

    sAllSliderCtrls = utils.data.get(utilsUnreal.kCreatedUnrealSliderCtrls, xDefault=[])
    sAllSliderCtrls = list(set(sAllSliderCtrls))
    ssJoints = [[] for _ in range(len(sAllSliderCtrls))]
    ffWeights = [[] for _ in range(len(sAllSliderCtrls))]

    ddProducts = defaultdict(list)
    dSimpleConstraints = defaultdict(list)

    for c,sCtrl in enumerate(sAllSliderCtrls):
        print ('===================== sCtrl: ', sCtrl)
        cCtrl = ctrls7.ctrlFromName(sCtrl)
        bSuccessfull = False
        bCheckBlendShapes = False
        for sNode in cmds.listConnections(cCtrl.sPasser, s=True) or []:
            if sNode.startswith('decomposeMatrix_PC_') and sNode.endswith('__'):
                sLoc = sNode.split('decomposeMatrix_PC_')[-1][:-2]
                if not cmds.objExists(sLoc):
                    raise Exception('Locator doesn\'t exist: "%s"' % sLoc)


                if cmds.objectType(sLoc) == 'joint':
                    dSimpleConstraints[sLoc].append(sCtrl)
                else:
                    sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
                    sBlendAllInfluencesNodes = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)
                    if sBlendAllInfluencesNodes:
                        sBlendAllInfluencesNode = sBlendAllInfluencesNodes[0]
                        if cmds.objectType(sBlendAllInfluencesNode) == 'wtAddMatrix':
                            for j in range(10): # per joint
                                sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sBlendAllInfluencesNode, j), s=True, d=False)
                                if j == 0:
                                    sFirstMatrixConn = sMatrixConns[0]
                                if not sMatrixConns:
                                    break
                                sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                                fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sBlendAllInfluencesNode, j))
                                ssJoints[c].append(sJoint)
                                ffWeights[c].append(fWeight)
                                bSuccessfull = True
                                bCheckBlendShapes = True
                        elif cmds.objectType(sBlendAllInfluencesNode) == 'multMatrix':
                            sJoint = cmds.listConnections('%s.matrixIn[2]' % sBlendAllInfluencesNode, s=True, d=False)[0]
                            sFirstMatrixConn = sBlendAllInfluencesNode
                            ssJoints[c] = [sJoint, sJoint]
                            ffWeights[c] = [1.0, 0.0]
                            bSuccessfull = True
                            bCheckBlendShapes = True
                break

        if not bSuccessfull:
            dSimpleConstraints['jnt_m_headMain'].append(sCtrl)

        if bSuccessfull and bCheckBlendShapes:
            sPointToMatrix = cmds.listConnections('%s.matrixIn[0]' % sFirstMatrixConn, s=True, d=False)[0]
            if cmds.objectType(sPointToMatrix) == 'multMatrix':
                sPointToMatrix = cmds.listConnections('%s.matrixIn[0]' % sPointToMatrix, s=True, d=False)[0]
            sAdditionNode = cmds.listConnections('%s.inputTranslate' % sPointToMatrix, s=True, d=False)[0]

            for b in range(1, 100000, 1):
                sMults = cmds.listConnections('%s.input3D[%d]' % (sAdditionNode, b), s=True, d=False)
                if not sMults:
                    break
                sRangeOrConditionNode = cmds.listConnections('%s.input2X' % sMults[0], s=True, d=False)[0]
                sTargetAttr = '%s.sTarget' % sRangeOrConditionNode
                if cmds.objExists(sTargetAttr):
                    fValues = cmds.getAttr('%s.input1' % sMults[0])[0]
                    ddProducts[sCtrl].append((cmds.getAttr(sTargetAttr), utilsUnreal.flipVectorToUnreal(fValues)))



    print ('dSimpleConstraints: ', list(dSimpleConstraints.keys()))
    for sJoint, sCtrls in dSimpleConstraints.items():
        sUnrealCommands.append(f"controllers.openCommentBox('Simples ones Constraint to {sJoint}')")
        sUnrealCommands.append("ePassers = nodes.createHierarchyTransformArrayNode([%s])" % ', '.join(["%s.ePasser" % sCtrl for sCtrl in sCtrls]))
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCommands)
        sUnrealCommands.append("sForEach = nodes.createForEachExecuteNode(ePassers)")
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCommands)
        sUnrealCommands.append(f"nodes.createParentConstraintExecuteNode([(library.getElementKey('{sJoint}', 'Bone'), 1)], '%s.Element' % sForEach, bMaintainOffset=True)" )
        sUnrealCommands.append("controllers.goToParentExecute()")
        sUnrealCommands.append(f"controllers.closeCommentBox('Simples ones Constraint to {sJoint}')")

    # create the commands

    for c,sCtrl in enumerate(sAllSliderCtrls):
        if not ssJoints[c]:
            continue

        sProducts = ddProducts.get(sCtrl, [])
        sProducts = sorted(sProducts, key=lambda a:np.linalg.norm(a[1]), reverse=True)
        sBlendShapesArguments = [a for a in sProducts[:min(iMaxTargetsAttach, len(sProducts))] if np.linalg.norm(a[1]) >= 0.005]

        # fStartPos = utilsUnreal.flipVectorToUnreal(cmds.xform(sCtrl, q=True, ws=True, t=True))
        sUnrealCommands.append('\n')
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCommands)

        iJointCount = min(iMaxJointAttach, len(ssJoints[c]))
        sJoints = ssJoints[c][0:iJointCount]
        fWeights = ffWeights[c][0:iJointCount]
        # xConstraintParents = ', '.join(["(ELEM('%s', 'Bone'), %0.6f)" % (sJ, fW) for sJ, fW in ])
        sUnrealCommands.append(f"functions.parallelAttach({sCtrl}.ePasser, xBlendShapePairs={sBlendShapesArguments}, xConstraintParents={list(zip(sJoints, fWeights))})")
        # sLines.append(f"functions.parallelAttach({sTransform}, xBlendShapePairs={sBlendShapesArguments}, xConstraintParents=[{xConstraintParents}])")

    sUnrealCommands.append("nodes.endCurrentFunction(bAddToExecute=True)")


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()




@builderTools.addToBuild(iOrder=130.11)
def pythonCustomAttachers(iMaxTargetsAttach=4):
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sTransforms = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.sPuppetParentAttachment' % sT) and ':' not in sT]

    ssJoints = [[] for _ in range(len(sTransforms))]
    ffWeights = [[] for _ in range(len(sTransforms))]

    ddProducts = defaultdict(list)
    dSimpleConstraints = defaultdict(list)

    for c,sTransform in enumerate(sTransforms):
        print ('===================== sTransform: ', sTransform)
        bSuccessfull = False
        bCheckBlendShapes = False
        for sNode in cmds.listConnections(sTransform, s=True) or []:
            if sNode.startswith('decomposeMatrix_PC_') and sNode.endswith('__'):
                sLoc = sNode.split('decomposeMatrix_PC_')[-1][:-2]
                if not cmds.objExists(sLoc):
                    raise Exception('Locator doesn\'t exist: "%s"' % sLoc)

                if cmds.objectType(sLoc) == 'joint':
                    dSimpleConstraints[sLoc].append(sTransform)
                else:
                    sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
                    sBlendAllInfluencesNodes = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)
                    if sBlendAllInfluencesNodes:
                        sBlendAllInfluencesNode = sBlendAllInfluencesNodes[0]
                        if cmds.objectType(sBlendAllInfluencesNode) == 'wtAddMatrix':
                            for j in range(10): # per joint
                                sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sBlendAllInfluencesNode, j), s=True, d=False)
                                if j == 0:
                                    sFirstMatrixConn = sMatrixConns[0]
                                if not sMatrixConns:
                                    break
                                sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                                fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sBlendAllInfluencesNode, j))
                                ssJoints[c].append(sJoint)
                                ffWeights[c].append(fWeight)
                                bSuccessfull = True
                                bCheckBlendShapes = True
                        elif cmds.objectType(sBlendAllInfluencesNode) == 'multMatrix':
                            sJoint = cmds.listConnections('%s.matrixIn[2]' % sBlendAllInfluencesNode, s=True, d=False)[0]
                            sFirstMatrixConn = sBlendAllInfluencesNode
                            ssJoints[c] = [sJoint, sJoint]
                            ffWeights[c] = [1.0, 0.0]
                            bSuccessfull = True
                            bCheckBlendShapes = True

                break

        if not bSuccessfull:
            dSimpleConstraints['jnt_m_headMain'].append(sTransform)

        if bSuccessfull and bCheckBlendShapes:
            print ('%s.matrixIn[0]' % sFirstMatrixConn)

            sPointToMatrixList = cmds.listConnections('%s.matrixIn[0]' % sFirstMatrixConn, s=True, d=False)
            if not sPointToMatrixList:
                continue
            sPointToMatrix = sPointToMatrixList[0]
            sAdditionNode = cmds.listConnections('%s.inputTranslate' % sPointToMatrix, s=True, d=False)[0]

            for b in range(1, 100000, 1):
                sMults = cmds.listConnections('%s.input3D[%d]' % (sAdditionNode, b), s=True, d=False)
                if not sMults:
                    break
                sRangeOrConditionNode = cmds.listConnections('%s.input2X' % sMults[0], s=True, d=False)[0]
                sTargetAttr = '%s.sTarget' % sRangeOrConditionNode
                if cmds.objExists(sTargetAttr):
                    fValues = cmds.getAttr('%s.input1' % sMults[0])[0]
                    ddProducts[sTransform].append((cmds.getAttr(sTargetAttr), utilsUnreal.flipVectorToUnreal(fValues)))


    # create the commands
    sFiles = [utilsUnreal.createOutFilePath(),
              utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]

    for f,sFile in enumerate(sFiles):
        with open(sFile, 'r') as file:
            sFileData = file.read()

        for sTransform, sJoints, fWeights in zip(sTransforms, ssJoints, ffWeights):
            print ('creating line for transform: ', sTransform)
            sEntryLine = '# CUSTOMATTACHER %s' % sTransform
            sLines = [sEntryLine]
            if f == 0:
                utilsUnreal.createUnrealNull(sTransform, sTransform, sWriteCommands=sLines)
            else:
                sLines.append(f"{sTransform} = library.getElementKey('{sTransform}', 'Null')")
            sUnrealJoints = [dUnrealJoints.get(sJ,sJ) for sJ in sJoints]

            sProducts = ddProducts.get(sTransform, [])
            sProducts = sorted(sProducts, key=lambda a:np.linalg.norm(a[1]), reverse=True)
            sBlendShapesArguments = [a for a in sProducts[:min(iMaxTargetsAttach, len(sProducts))] if np.linalg.norm(a[1]) >= 0.005]

            # fStartPos = utilsUnreal.flipVectorToUnreal(cmds.xform(sTransform, q=True, ws=True, t=True))
            utilsUnreal.setNewColumn(sWriteCommands=sLines)
            # xConstraintParents = ', '.join(["(ELEM('%s', 'Bone'), %0.3f)" % (sJ, fW) for sJ,fW in zip(sJoints,fWeights)])
            sLines.append(f"functions.parallelAttach({sTransform}, xBlendShapePairs={sBlendShapesArguments}, xConstraintParents={list(zip(sJoints, fWeights))})")
            sLines.append('# PIECE.INPUTS: %s' % str(sUnrealJoints))
            sLines.append('# PIECE.INPUTS: %s' % str([xPair[0] for xPair in sBlendShapesArguments]))
            sFileData = sFileData.replace(sEntryLine, '\n'.join(sLines))

        with open(sFile, 'w') as file:
            file.write(sFileData)






@builderTools.addToBuild(iOrder=132)
def pythonShapeCtrls():
    utils.reload2(utilsUnreal)
    sUnrealAvoidForwardLimbs = utils.data.get('sUnrealAvoidForwardLimbs')
    utilsUnreal.generateControlShapeCode(sSkipLimbs=sUnrealAvoidForwardLimbs)



dMetahumanLimbs = {}
dMetahumanLimbs['m_placement'] = ['game:root']
dMetahumanLimbs['m_neck'] = ['game:neck_01', 'game:neck_02']
dMetahumanLimbs['m_spine'] = ['game:spine_01', 'game:spine_02', 'game:spine_03', 'game:spine_04', 'game:spine_05']
dMetahumanLimbs['m_head'] = ['game:head']
dMetahumanLimbs['l_arm'] = ['game:upperarm_l', 'game:lowerarm_l', 'game:hand_l', 'game:upperarm_twist_01_l', 'game:upperarm_twist_02_l', 'game:upperarm_twist_03_l', 'game:lowerarm_twist_01_l', 'game:lowerarm_twist_02_l', 'game:lowerarm_twist_03_l']
dMetahumanLimbs['r_arm'] = ['game:upperarm_r', 'game:lowerarm_r', 'game:hand_r', 'game:upperarm_twist_01_r', 'game:upperarm_twist_02_r', 'game:upperarm_twist_03_r', 'game:lowerarm_twist_01_r', 'game:lowerarm_twist_02_r', 'game:lowerarm_twist_03_r']
dMetahumanLimbs['l_leg'] = ['game:thigh_l', 'game:calf_l', 'game:foot_l', 'game:ball_l', 'game:thigh_twist_01_l', 'game:thigh_twist_02_l', 'game:thigh_twist_03_l', 'game:calf_twist_01_l', 'game:calf_twist_02_l', 'game:calf_twist_03_l']
dMetahumanLimbs['r_leg'] = ['game:thigh_r', 'game:calf_r', 'game:foot_r', 'game:ball_r', 'game:thigh_twist_01_r', 'game:thigh_twist_02_r', 'game:thigh_twist_03_r', 'game:calf_twist_01_r', 'game:calf_twist_02_r', 'game:calf_twist_03_r']



@builderTools.addToBuild(iOrder=132.5)
def pythonReplacePuppetJoints():
    dAllUsedOutputs = utils.data.get('dAllUsedOutputs')
    print ('dAllUsedOutputs: ', dAllUsedOutputs)
    dUnrealJoints = utils.data.get('dUnrealJoints')

    bMetahumanJoints = utils.data.get('bMetahumanJoints')

    sAllJointsInGameSkeleton = cmds.listRelatives('GAMESKELETON', typ='joint', ad=True)

    for sFile in [utilsUnreal.createOutFilePath(),
                  utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]:

        with open(sFile, 'r') as file:
            filedata = file.read()

        for sMayaJoint, sUnrealJoint in dUnrealJoints.items():
            if sMayaJoint != sUnrealJoint:
                filedata = filedata.replace("'%s'" % sMayaJoint, "'%s'" % sUnrealJoint)


        for sMayaJoint, sLimbName in dAllUsedOutputs.items():
            if 'game:%s' % sMayaJoint not in sAllJointsInGameSkeleton:
                if sMayaJoint not in dUnrealJoints: # if it would be in there, it'd be taken care of already
                    if bMetahumanJoints and sLimbName in dMetahumanLimbs:
                        iClosest = xforms.findClosestJoints(xforms.getPositionArray([sMayaJoint]), dMetahumanLimbs[sLimbName])[0]
                        sMetahumanJoint = dMetahumanLimbs[sLimbName][iClosest].split(':')[-1]
                        filedata = filedata.replace("'%s'" % sMayaJoint, "'%s'" % sMetahumanJoint)
                    else: # could be something like m_cog that doesn't have a joint
                        sLimbNameAttr = '%s.sLimbJoint' % sMayaJoint
                        if cmds.objExists(sLimbNameAttr):
                            sModuleGrp = 'grp_%sModule' % cmds.getAttr(sLimbNameAttr)
                            sCtrls = eval(cmds.getAttr('%s.__ctrls__' % sModuleGrp))
                            iClosest = xforms.findClosestPoints(xforms.getPositionArray([sMayaJoint]), xforms.getPositionArray(sCtrls))[0]
                            filedata = filedata.replace("library.getElementKey('%s', 'Bone')" % sMayaJoint, "%s.eControl" % sCtrls[iClosest])


        with open(sFile, 'w') as file:
            file.write(filedata)



@builderTools.addToBuild(iOrder=131.15, dButtons={}, bDisableByDefault=False)
def pythonConnectBlendShapes():

    dDriverReplacements = {'grp_l_eyesLookAtPasser.lookVert': 'vLookVert_l_eye',
                           'grp_r_eyesLookAtPasser.lookVert': 'vLookVert_r_eye',
                           'grp_l_eyesLookAtPasser.lookHoriz': 'vLookHoriz_l_eye',
                           'grp_r_eyesLookAtPasser.lookHoriz': 'vLookHoriz_r_eye',
                           'grp_l_blinkPasser.blendCurveBot': 'l_blendCurveBot',  # "vBlendCurveBot_l = nodes.createGetVariableNode('l_blendCurveBot')"),
                           'grp_r_blinkPasser.blendCurveBot': 'r_blendCurveBot',
                           'grp_l_blinkPasser.blendCurveTop': 'l_blendCurveTop',
                           'grp_r_blinkPasser.blendCurveTop': 'r_blendCurveTop',
                           'grp_l_browSplinesAPasser.totalTranslateX': 'l_BrowTotalTranslate0.X',
                           'grp_r_browSplinesAPasser.totalTranslateX': 'r_BrowTotalTranslate0.X'}

    sCreatedUnrealCtrls = utils.data.get(utilsUnreal.kCreatedUnrealCtrls)
    sTargetAttrs = utils.data.get(utilsUnreal.kBlendShapeTargetList, xDefault=[])
    dInbetweens = utils.data.get(utilsUnreal.kBlendShapeTargetInbetweensList, xDefault={})
    sUnrealCommands = []
    sUnrealCommands.append('\n\n# BlendShape Target Weights (Curve) Connections\n\n')

    sUnrealCommands.append("unrealUI.logMessage('Connect Blendshapes...')")
    sUnrealCommands.append("unrealUI.incrementProgress()")

    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("nodes.startFunction('kangaroo_blendShapeTargets', bSequencer=True)")
    sUnrealCommands.append("controllers.setNewColumn()")
    iLinePointAfterStartFunction = len(sUnrealCommands)
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("controllers.openCommentBox('BlendShape Connections')")

    sCreatedVariables = set()
    sCompletedCurves = set()
    sTweakerCtrls = []
    sTweakerCurvePrefixes = []

    bZipper = False

    for sAttribute in sTargetAttrs:
        print ('%s...' % sAttribute)
        if sAttribute == None:
            continue
        sCurveName = sAttribute.split('.')[-1]
        if sCurveName in sCompletedCurves:
            continue
        else:
            sCompletedCurves.add(sCurveName)

        xxDrivers = []
        sCombinedDriver = cmds.listConnections(sAttribute, s=True, d=False, p=True, skipConversionNodes=True)[0]
        sCombinedDriverNode = sCombinedDriver.split('.')[0]
        sCombinedDriverOverrideAttr = '%s.sCombinedDriverOverride' % sCombinedDriverNode
        if cmds.objExists(sCombinedDriverOverrideAttr):
            sCombinedDriver = cmds.getAttr(sCombinedDriverOverrideAttr)

        if '_ctrl.' in sCombinedDriver and cmds.attributeQuery('isTweaker', node=sCombinedDriverNode, exists=True):
            sTweakerCtrls.append(sCombinedDriverNode)
            sCurveNamePrefix = sCurveName[:-1]
            sTweakerCurvePrefixes.append(sCurveNamePrefix)
            sCompletedCurves.add('%sX' % sCurveNamePrefix)
            sCompletedCurves.add('%sY' % sCurveNamePrefix)
            sCompletedCurves.add('%sZ' % sCurveNamePrefix)
        else: # no tweaker ctrl
            if cmds.objectType(sCombinedDriverNode) == 'condition' :
                sFactors = eval(cmds.getAttr('%s.sFactors_outColorR' % sCombinedDriverNode)) # ['range_blink_l_ctrl_ty1.outValueX', 'range_blink_l_ctrl_upCurveBlink1.outValueX']
                iCombineMode = 1
            elif cmds.objectType(sCombinedDriverNode) == 'multiplyDivide':
                sFactors = eval(cmds.getAttr('%s.sFactors_outputX' % sCombinedDriverNode)) # ['range_blink_l_ctrl_ty1.outValueX', 'range_blink_l_ctrl_upCurveBlink1.outValueX']
                iCombineMode = 2
            else:
                sFactors = [sCombinedDriver]
                iCombineMode = 0

            bAllRangesAreThere = True
            sUnrealCommands.append('\n\n# BlendShape Weight sAttribute: %s' % sAttribute)
            sPreCommands = []
            for sFactor in sFactors:
                sNode, sAttr = sFactor.split('.')
                sNodeType = cmds.objectType(sNode)
                if sNode.startswith('zipperOut_'):
                    xxDrivers.append(["'%s'" % sNode, None, "'ZIPPER'"])
                    iSpan = re.search('(^|_)z[0-9]*_', sCurveName).span()
                    if iSpan[0] == 0:
                        sMatchPattern = '_'.join(['z[0-9]*', sCurveName[iSpan[1]:]])
                    else:
                        sMatchPattern = '_'.join([sCurveName[:iSpan[0]], 'z[0-9]*', sCurveName[iSpan[1]:]])
                    for _sTargetAttr in sTargetAttrs:
                        _sCurveName = _sTargetAttr.split('.')[-1]
                        if re.match(sMatchPattern, _sCurveName):
                            sCompletedCurves.add(_sCurveName)
                    bZipper = True
                elif  ('_brows_' in sNode or sNode=='jnt_m_browMiddleDefault') and sAttr in ['movedDown', 'movedUp']:
                    xxDrivers.append(["'%s'" % sAttr, None, "'BROWS'"])
                    iSpan = re.search('(^|_)b[0-9]*_', sCurveName).span()
                    if iSpan[0] == 0:
                        sMatchPattern = '_'.join(['b[0-9]*', sCurveName[iSpan[1]:]])
                    else:
                        sMatchPattern = '_'.join([sCurveName[:iSpan[0]], 'b[0-9]*', sCurveName[iSpan[1]:]])
                    for _sTargetAttr in sTargetAttrs:
                        _sCurveName = _sTargetAttr.split('.')[-1]
                        if re.match(sMatchPattern, _sCurveName): # r_b39_blinkCorr_browSplinesMainDown_INVA
                            sCompletedCurves.add(_sCurveName)
                    bBrowSplines = True
                elif sNodeType == 'setRange' or sNodeType.startswith('animCurve'):
                    sDriver = cmds.listConnections('%s.%s' % (sNode, 'valueX' if sNodeType=='setRange' else 'input'), s=True, d=False, p=True, skipConversionNodes=True)[0] # l_b00_blinkCorr_browSplinesMainDown_INVA
                    sDriverNode, sDriverAttr = sDriver.split('.')
                    fRangesFromNode = nodes.getRangeFromRangeNode(sNode)
                    if sDriverAttr.startswith('rotate'):
                        fRangesFromNode = [(-fV if i < len(fRangesFromNode) // 2 else fV) for i, fV in enumerate(fRangesFromNode)]  # negating is happening when working on the jaw. Not sure if that applies to all?

                    if sDriver in dDriverReplacements:
                        sReplacement = dDriverReplacements[sDriver].split('.')
                        sVariableName = sReplacement[0]
                        if sVariableName not in sCreatedVariables:
                            sPreCommands.append(f"{sVariableName}_value = nodes.createGetVariableNode({sVariableName})")
                            sCreatedVariables.add(sVariableName)
                        sPlug = '%s_value' % sVariableName
                        if len(sReplacement) > 1:
                            sPlug = f"'%s.{sReplacement[1]}' % {sPlug}" # '%s.X' % l_BrowTotalTranslate0_value
                        xxDrivers.append([sPlug, fRangesFromNode, "'VALUE'"])
                    elif sDriverNode.endswith('_ctrl'):
                        if sDriverNode not in sCreatedUnrealCtrls:
                            continue
                        if sDriverAttr.startswith('translate'):
                            if sDriverAttr == 'translateX':
                                iAxis = 0
                            elif sDriverAttr == 'translateY':
                                iAxis = 2
                            elif sDriverAttr == 'translateZ':
                                iAxis = 1
                            else:
                                raise Exception('not sure what attr "%s" is' % sDriverAttr)
                            xxDrivers.append(["'%s.%d'" % (sDriverNode, iAxis), fRangesFromNode, "'CTRLTRANSFORM'"]) # ['%s.Translation.Z' % lipsCornerLFT_ctrl_getTranslation

                        elif sDriverAttr.startswith('rotate'):
                            if sDriverAttr == 'rotateX':
                                iAxis = 3
                            elif sDriverAttr == 'rotateY':
                                iAxis = 5
                            elif sDriverAttr == 'rotateZ':
                                iAxis = 4
                            else:
                                raise Exception('not sure what attr "%s" is' % sDriverAttr)
                            xxDrivers.append(["'%s.%d'" % (sDriverNode, iAxis), fRangesFromNode, "'CTRLTRANSFORM'"])

                        else: # custom attributes, like upCurve blink
                            xxDrivers.append(["'%s.%s'" % (sDriverNode, sDriverAttr), fRangesFromNode, "'CTRLCHANNEL'"]) # ['%s.Translation.Z' % lipsCornerLFT_ctrl_getTranslation

                else:
                    raise Exception('not sure what to do with node "%s" ("%s")' % (sNode, sAttribute))

            if bAllRangesAreThere and len(xxDrivers):
                sUnrealCommands.append("controllers.setNewColumn()")
                sDriverStrings = ["[%s, %s, %s]" % (xD[0], str(xD[1]), xD[2]) for xD in xxDrivers]

                fInbetweens = sorted(list(set(dInbetweens.get(sCurveName, []))))
                sInbetweens = ['%s__%03d' % (sCurveName, int(fPerc*100.0)) for fPerc in fInbetweens]

                sUnrealCommands.extend(sPreCommands)
                sUnrealCommands.append(f"functions.curveDriver('{sCurveName}', {utilsUnreal.listNice(sDriverStrings)}, fInbetweens={fInbetweens}, sInbetweenCurveNames={sInbetweens}, iCombineMode={iCombineMode})")

    sUnrealCommands.append("controllers.closeCommentBox('BlendShape Connections')")

    if bZipper:
        dZipper = utils.data.get('dZipper')
        sZipperUnrealCommands = ['\n\n#Zipper\n']
        sZipperUnrealCommands.append(f"functions.createZipperVariables({dZipper['iSampleCount']}, [lipsCorner_l_ctrl.eControl, lipsCorner_r_ctrl.eControl])")
        print ('sUnrealCommands: ', type(sUnrealCommands))
        print ('sZipperUnrealCommands: ', type(sZipperUnrealCommands))
        sUnrealCommands = sUnrealCommands[:iLinePointAfterStartFunction] + sZipperUnrealCommands + sUnrealCommands[iLinePointAfterStartFunction:]
    report.report.addLogText('\n'.join(sUnrealCommands), bPrint=True)


    if sTweakerCtrls:
        sUnrealCommands.append('\n')
        utilsUnreal.newSequencerPlug(sWriteCommands=sUnrealCommands)
        sUnrealCommands.append(f"functions.tweakerControls(sCtrls={sTweakerCtrls}, \n\t\t\tsCurveNamePrefixes={sTweakerCurvePrefixes})")

    sUnrealCommands.append("nodes.endCurrentFunction(bAddToExecute=True)")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=131.11, dButtons={}, bDisableByDefault=True)
def unrealConnectControlsToAppleCurves(fLookUpDownInOutTranslate=[15, -15, -15, 15]):
    sUnrealMocapBackwardsCodeLines = []
    sUnrealMocapBackwardsCodeLines.append('\n\n# BlendShape Target Weights (Curve) Connections (Apple) \n\n')

    fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation')
    fJawOpenTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation')

    dDict = {}
    dDict['blink_l_ctrl.translateZ'] = [(-1, 'eyeBlinkLeft'), (0.5, 'eyeWideLeft')]
    dDict['blink_r_ctrl.translateZ'] = [(-1, 'eyeBlinkRight'), (0.5, 'eyeWideRight')]
    dDict['innerEyebrow_l_ctrl.translateZ'] = [(-1, 'browDownLeft'), (1, 'browInnerUp')]
    dDict['innerEyebrow_r_ctrl.translateZ'] = [(-1, 'browDownRight'), (1, 'browInnerUp')]
    dDict['outerEyebrow_l_ctrl.translateZ'] = [(1, 'browOuterUpLeft')]
    dDict['outerEyebrow_r_ctrl.translateZ'] = [(1, 'browOuterUpRight')]
    dDict['cheekRaiser_l_ctrl.translateZ'] = [(1, 'cheekSquintLeft')]
    dDict['cheekRaiser_r_ctrl.translateZ'] = [(1, 'cheekSquintRight')]
    dDict['puff_l_ctrl.translateZ'] = [(1, 'cheekPuff')]
    dDict['puff_r_ctrl.translateZ'] = [(1, 'cheekPuff')]
    dDict['jaw_ctrl.rotateY'] = [(-fJawOpenRotation[2], 'jawOpen')]
    dDict['jaw_ctrl.translateY'] = [(-3.0, 'jawLeft')]
    dDict['jaw_ctrl.translateY'] = [(3.0, 'jawRight')]
    dDict['jaw_ctrl.translateX'] = [(3.0, 'jawForward')]
    dDict['mouth_ctrl.translateY'] = [(1.0, 'mouthFunnel')]

    dDict['mouthBot_ctrl.translateY'] = [(-1.0, 'mouthRollLower'), (1.0, 'mouthShrugLower')]
    dDict['mouthTop_ctrl.translateY'] = [(-1.0, 'mouthRollUpper'), (1.0, 'mouthShrugUpper')]

    dDict['lipsBot_l_ctrl.translateZ'] = [(-1.0, 'mouthLowerDownLeft')]
    dDict['lipsBot_r_ctrl.translateZ'] = [(-1.0, 'mouthLowerDownRight')]
    dDict['lipsTop_l_ctrl.translateZ'] = [(1.0, 'mouthUpperUpLeft')]
    dDict['lipsTop_r_ctrl.translateZ'] = [(1.0, 'mouthUpperUpRight')]

    dDict['noseWrinkler_l_ctrl.translateZ'] = [(1.0, 'noseSneerLeft')]
    dDict['noseWrinkler_r_ctrl.translateZ'] = [(1.0, 'noseSneerRight')]
    dDict['lipsCorner_l_ctrl.translateX'] = [(1.0, 'mouthDimpleLeft')]
    dDict['lipsCorner_r_ctrl.translateX'] = [(1.0, 'mouthDimpleRight')]
    dDict['lipsCorner_l_ctrl.translateX'] = [(-1.0, 'mouthPucker')]
    dDict['lipsCorner_r_ctrl.translateX'] = [(-1.0, 'mouthPucker')]
    dDict['lipsCorner_l_ctrl.translateZ'] = [(1.0, 'mouthSmileLeft'), (-1.0, 'mouthFrownLeft')]
    dDict['lipsCorner_r_ctrl.translateZ'] = [(1.0, 'mouthSmileRight'), (-1.0, 'mouthFrownRight')]
    dDict['lipSretch_l_ctrl.translateZ'] = [(1.0, 'mouthStretchLeft')]
    dDict['lipSretch_r_ctrl.translateZ'] = [(1.0, 'mouthStretchRight')]

    fUp, fDown, fIn, fOut = fLookUpDownInOutTranslate
    dDict['eyesLookAt_l_ctrl.translateZ'] = [(fUp, 'eyeLookUpLeft'), (fDown, 'eyeLookDownLeft')]
    dDict['eyesLookAt_l_ctrl.translateX'] = [(fIn, 'eyeLookInLeft'), (fOut, 'eyeLookOutLeft')]
    dDict['eyesLookAt_r_ctrl.translateZ'] = [(fUp, 'eyeLookUpRight'), (fDown, 'eyeLookDownRight')]
    dDict['eyesLookAt_r_ctrl.translateX'] = [(fIn, 'eyeLookInRight'), (fOut, 'eyeLookOutRight')]

    dDictExisting = {sControlValue: xPoses for sControlValue, xPoses in dDict.items() if cmds.objExists(sControlValue)}
    sUnrealMocapBackwardsCodeLines.append("functions.moveCtrlsByAppleCurves(%s)" % str(dDictExisting))

    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealMocapBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)

    # utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealMocapBackwardsCodeLines)
    # utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)

    # drive apple curves in Maya
    sCurveNames = []
    for _, xPoses in dDictExisting.items():
        sCurveNames.extend([y for x, y in xPoses])
    sTargets = unreal.addEmptyUnrealTargets(sCurveNames)
    print('sTargets: ', sTargets)
    dTargets = {sTarget.split('.')[-1]: sTarget for sTarget in sTargets}

    sConnected = set()
    for sUnrealCtrlAttr, xPoses in dDictExisting.items():
        if sUnrealCtrlAttr.endswith('Y'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Y', 'Z')
        elif sUnrealCtrlAttr.endswith('Z'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Z', 'Y')
        elif sUnrealCtrlAttr.endswith('X'):
            sMayaCtrlAttr = sUnrealCtrlAttr
        else:
            raise Exception('attribute %s not supported' % sUnrealCtrlAttr)

        for fPose, sCurve in xPoses:
            if sCurve not in sConnected:
                nodes.createRangeNode(sMayaCtrlAttr, 0, fPose, 0, 1, sTarget=dTargets[sCurve],
                                      sName='appleCurve_%s' % sMayaCtrlAttr)
                sConnected.add(sCurve)






@builderTools.addToBuild(iOrder=131.05, dButtons={}, bDisableByDefault=True)
def pythonTweakerCtrls():
    sUnrealCommands = ['\n\n#Creating Tweaker Ctrls\n']

    # sCtrls = ['eyelidMidBotLFT_ctrl']
    sCtrls = utils.data.get('sAllTweakerCtrlsForUnreal')
    sCreatedCtrls = []
    for sCtrl in sCtrls:
        cCtrl = ctrls7.ctrlFromName(sCtrl)
        fColor = cmds.getAttr('%s.overrideColorRGB' % cCtrl.sShape)[0]
        fSliderScale = cmds.getAttr('%s.sx' % cCtrl.sSlider)
        utilsUnreal.createUnrealCtrl(cCtrl, sShapeName='Box_Solid', fSize=0.018 / fSliderScale, fOverwriteColor=fColor, sWriteCommands=sUnrealCommands)
        sCreatedCtrls.append(sCtrl)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utils.data.addToList(utilsUnreal.kCreatedUnrealSliderCtrls, sCreatedCtrls)
    utils.data.addToList(utilsUnreal.kCreatedUnrealCtrls, sCreatedCtrls)
    utilsUnreal.dumpUnrealCodeLinesToFile()

