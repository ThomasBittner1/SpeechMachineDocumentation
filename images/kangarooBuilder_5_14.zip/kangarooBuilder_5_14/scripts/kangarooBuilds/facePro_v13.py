###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



'''

changes from _v3:
eye_r_ctrl keeps the orientation now. in V3 it was flipped to make it parallel. However now the new
function ParallelEyes is taking care of it

'''


from collections import OrderedDict, defaultdict
import numpy as np
import os
import kangarooTools.patch as patch
import kangarooTools.report as report
import time
import pickle
import math

# QtWidgets, QtGui, QtCore = utils.importQtModules()


import kangarooShapeEditor.kangarooShapeEditorTools as kangarooShapeEditorTools

import kangarooTabTools.builder as builderTools
import kangarooTabTools.unreal as unreal

import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.barycentric as barycentric
import kangarooTools.topology as topology
import kangarooTools.curves as curves
import kangarooTools.surfaces as surfaces
import kangarooTools.nodes as nodes
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.constraints as constraints
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.weights as weights
import kangarooTabTools.ctrls8 as ctrls8
import kangarooTabTools.geometry as geometry
import kangarooTools.utilsUnreal as utilsUnreal
import kangarooTools.defaultAttributes as defaultAttributes

QtWidgets, QtGui, QtCore = utils.importQtModules()

iColorIndexCtrls = 0
kBuilderColor = utils.uiColors.orange
kEyelidBuilderColor = utils.uiColors.orangeDark


sHeadCtrl = None
def headCtrl():
    global sHeadCtrl
    if sHeadCtrl == None:
        sHeadCtrl = utils.translateCtrlName('ctrl_m_head')
    return sHeadCtrl

sJawCtrl = None
def jawCtrl():
    global sJawCtrl
    if sJawCtrl == None:
        sJawCtrl = utils.translateCtrlName('ctrl_m_jaw')
    return sJawCtrl


bParentJointsToGroups = True
def jointOrGroup(sJointName):
    sReturn = sJointName
    if bParentJointsToGroups:
        sReturn = f'JOINTGROUP_{sJointName}'
        if not cmds.objExists(sReturn):
            cmds.createNode('transform', n=sReturn, p='skeleton')
            constraints.matrixParentConstraint(sJointName, sReturn)
    return sReturn


def exportBps(sFileName, sGroup):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    print('exporting "%s" to "%s" ' % (sGroup, sFile))
    report.report.addLogText('exporting "%s" to "%s" ' % (sGroup, sFile))
    utils.createFolderIfNotExists(sFile)

    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #


def createTransformFromSelectedPoints(sName, sParent, bLockToMiddle=False, sSkinningSphere=None, bNoTransform=False):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.spaceLocator(n=sName)[0]
    print('aMean: ', aMean)
    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))

    if bLockToMiddle:
        for sL in ['%s.%s' % (sLoc, sAttr) for sAttr in ['tx', 'ry', 'rz']]:
            cmds.setAttr(sL, 0.0)
            cmds.setAttr(sL, lock=True)

    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        print('bNoTransform:', bNoTransform)
        if bNoTransform:
            cmds.parent(sSkinningSphere, sParent)
            cmds.delete(sLoc)
    return sLoc




def createMatrixCtrlromSelectedPoints(sName, sParent, sSkinningSphere=None, fRotate=(0,0,0)):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls8.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    fnMesh = OpenMaya2.MFnMesh(pSel.mDagPath)
    _, mNormal, _ = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(list(aMean)), space=OpenMaya2.MSpace.kWorld)

    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    xforms.orientThreePoints(sLoc, (mNormal.x, mNormal.y, mNormal.z), (0, 0, -1), fAimVector=(0, 0, 1),
                             fUpVector=(1, 0, 0))

    cmds.rotate(fRotate[0], fRotate[1], fRotate[2], sLoc, r=True, os=True)
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))
    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        cmds.parent(sSkinningSphere, sParent)


def createMatrixCtrlFromTransform(sName, sParent, sTransform=None):
    if sTransform == None:
        sTransform = cmds.ls(sl=True)[0]

    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls8.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    cmds.delete(cmds.parentConstraint(sTransform, sLoc))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))



def mirrorGroup(sGrp, bDeleteNewChildren=False):
    sMirrorName = utils.getMirrorName(sGrp)
    if not cmds.objExists(sMirrorName):
        if not cmds.objExists(sGrp):
            return None
        sMirrorGrp = cmds.duplicate(sGrp, n=sMirrorName)[0]
        if bDeleteNewChildren:
            cmds.delete(cmds.listRelatives(sMirrorGrp, c=True, f=True))

        sTemp = cmds.createNode('transform')
        sOldParent = cmds.listRelatives(sMirrorGrp, p=True)
        cmds.parent(sMirrorGrp, sTemp)
        cmds.setAttr('%s.sx' % sTemp, -1)
        if sOldParent:
            cmds.parent(sMirrorGrp, sOldParent)
        else:
            cmds.parent(sMirrorGrp, w=True)
        # cmds.setAttr('%s.tx' % sMirrorGrp, -cmds.getAttr('%s.tx' % sMirrorGrp))

        cmds.delete(sTemp)
        return sMirrorGrp
    return sMirrorName


def createBpCurve(sName, sParent, fDirection=(1, 0, 0), bTrackedOrder=False):  # , bInToOut=None, bBotToTop=None):
    if cmds.objExists(sName):
        cmds.delete(sName)
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sCurve = curves.createCurveFromSelectedVerts(sName=sName, fDirection=fDirection,
                                                 bTrackedSelectionOrder=bTrackedOrder)
    utils.addStringAttr(sCurve, 'sMesh', sMesh)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.select(sCurve)


def createBothBpCurves(sName, sParent, fDirection=(1, 0, 0)):
    # if cmds.objExists(sName): cmds.delete(sName)
    # utils.reload2(curves)
    sCurve, sLocA, sLocB = curves.createCurveWithSeparationLocs(sName, fDirection=fDirection)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.parent(sLocA, sLocB, sCurve)
    cmds.select(sCurve)


def createBpUpVectorCurve(sName, sMainCurve):
    sMesh = cmds.getAttr('%s.sMesh' % sMainCurve)
    if not cmds.objExists(sMainCurve):
        raise Exception('"%s" doesn\'t exist - make sure you run the previous steps' % sMainCurve)
    if not cmds.objExists(sMesh):
        raise Exception('"%s" doesn\'t exist anymore' % sMesh)

    fClosest = cmds.kt_findClosestPoints(fromMesh=sMainCurve, toMesh=sMesh, returnNormals=True)
    aClosest = np.array(fClosest, dtype='float64').reshape(-1, 6)
    aNormals = aClosest[:, 3:6]
    aNormals /= np.linalg.norm(aNormals, axis=1).reshape(-1, 1)
    fLength = curves.getLength(sMainCurve)

    if cmds.objExists(sName):
        cmds.delete(sName)
    sNewCurve = cmds.duplicate(sMainCurve, n=sName)[0]
    pNewCurve = patch.patchFromName(sNewCurve)
    aPushedOutPoints = pNewCurve.getPoints() + aNormals * (fLength * 0.1)
    pNewCurve.setPoints(aPushedOutPoints)


def _getFaceCtrlGrp():
    sName = 'faceCtrls'
    if not cmds.objExists(sName):
        sSelBefore = cmds.ls(sl=True)
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.ctrlVis' % sMaster, '%s.v' % sName)
        cmds.select(sSelBefore)

    return sName


def getFaceGrp():
    sName = 'faceRig'
    if not cmds.objExists(sName):
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sName)
    return sName


def getParentJointOrigin(sParentJoint):
    sName = '%sOrigin' % sParentJoint
    if not cmds.objExists(sName):
        xforms.createJoint(sName, sParent=getFaceGrp(), sMatch=sParentJoint)
    return sName



# def recordJawPose(_uiArgs=None):
#     fRotation = cmds.getAttr('jaw_ctrl.r')[0]
#     fTranslation = cmds.getAttr('jaw_ctrl.t')[0]
#     _uiArgs['fRotation'].setText(str(fRotation))
#     _uiArgs['fTranslation'].setText(str(fTranslation))


#
# @builderTools.addToBuild(iOrder=10, dButtons={}, bDisableByDefault=True)
# def reloadModules():
#     utils.reload2(blendShapesPro)


@builderTools.addToBuild(iOrder=62.1, dButtons={}, bDisableByDefault=True)
def jawAutoTranslate(fOverwriteRotation=None, fOverwriteTranslation=None, sSuffix=''):
    '''
    in order for this to work, make sure in the blueprints the polevector is pointing down, and the
    fAdjustAxisOrientation is [0,0,0]
    Basically minus rotateZ is opening the jaw

    This should be taken from the blendShape
    '''

    #
    # if not utils.data.exists('sBakedBlendShapeJawOpenTranslation%s' % sSuffix):
    #     report.report.addLogText('no jawOpen setup from blendShape file')
    #     return False

    if utils.isNone(fOverwriteTranslation):
        fTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation%s' % sSuffix)
        report.report.addLogText('taking from blendShape file translation: %s' % str(fTranslation))
    else:
        fTranslation = fOverwriteTranslation

    if utils.isNone(fOverwriteRotation):
        fRotation = utils.data.get('sBakedBlendShapeJawOpenRotation%s' % sSuffix)
        report.report.addLogText('taking from blendShape file rotation: %s' % str(fRotation))
    else:
        fRotation = fOverwriteRotation

    fDriverValue = fRotation[2]


    sJawCtrl = 'jaw%s_ctrl' % sSuffix
    sJawJoint = 'jnt_m_jaw%sMain' % sSuffix

    cmds.setAttr('%s.r' % sJawCtrl, 0,0,0)
    cmds.setAttr('%s.t' % sJawCtrl, 0,0,0)

    cCtrl = ctrls8.ctrlFromName(sJawCtrl)
    sOffsetTranslation = cCtrl.appendOffsetGroup('poseTranslation')
    sOffsetRotation = cCtrl.appendOffsetGroup('poseRotation')

    sDriverValue = '%s.rz' % sJawCtrl
    sDriverValueClampedPre = nodes.createClampNode(sDriverValue, 0, 10000000)
    sDriverValueClampedPost = nodes.createClampNode(sDriverValue, -10000000, fDriverValue)
    sDriverValueClampedOffsetPost = nodes.createAdditionNode([sDriverValueClampedPost, fDriverValue], sOperation='minus')

    # sRotation = nodes.createVectorAdditionNode([fRotation, [0,0,sDriverValue]], sOperation='minus')

    sRangeRot = nodes.createRangeNode(sDriverValue, 0, fDriverValue, [0,0,0], fRotation,
                                      bOutRangeIsVector=True)

    sSubtract = nodes.createVectorAdditionNode([sRangeRot, [0,0,sDriverValue]],
                                               sOperation='minus')

    # to do: add overshoot and undershoot
    nodes.createVectorAdditionNode([[0,0,sDriverValueClampedPre], sSubtract, [0,0,sDriverValueClampedOffsetPost]], sTarget='%s.r' % sOffsetRotation)

    nodes.createRangeNode(sDriverValue, 0, fDriverValue, [0,0,0], fTranslation,
                          sTarget='%s.t' % sOffsetTranslation, bOutRangeIsVector=True)

    utils.addStringAttr(sJawJoint, 'fOpenRotation', str(fRotation))
    utils.addStringAttr(sJawJoint, 'fOpenTranslation', str(fTranslation))

    utils.data.store('fJawAutoTranslateDriverValue%s' % sSuffix, fDriverValue, sNode=utils.kFaceDataNode)

    sUnrealCommands = []
    sUnrealCommands.append('\n\n# auto jaw\n')
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox('Auto Jaw')")
    sUnrealCommands.append("eJawOffset = jaw_ctrl.addOffset('auto')")

    sUnrealCommands.append("fDriverValue = %0.3f" % fDriverValue)
    sUnrealCommands.append("sDriverValue = '%s.Pitch' % nodes.getControlRotator(jaw_ctrl.eControl, bLocal=True)")
    sUnrealCommands.append("sDriverValueClampedPre = nodes.createClampNode(sDriverValue, 0, 10000000)")
    sUnrealCommands.append("sDriverValueClampedPost = nodes.createClampNode(sDriverValue, -10000000, fDriverValue)")
    sUnrealCommands.append("sDriverValueClampedOffsetPost = nodes.createBasicCalculateNode([sDriverValueClampedPost, fDriverValue], sOperation='Subtract')")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("sRangeRot = nodes.createRemapNode(sDriverValue, 0, fDriverValue, [0,0,0], %s, bOutIsVector=True)" % utilsUnreal.flipVectorToUnreal(fRotation))
    sUnrealCommands.append("sSubtract = nodes.createBasicCalculateNode([sRangeRot, [0,sDriverValue,0]], sOperation='Subtract', iPinType=pins.PinType.vector)")
    sUnrealCommands.append("sOffsetRotationValue = nodes.createBasicCalculateNode([[0,sDriverValueClampedPre,0], sSubtract, [0,sDriverValueClampedOffsetPost,0]], sOperation='Add', iPinType=pins.PinType.vector)")
    sUnrealCommands.append("sOffsetTranslationValue = nodes.createRemapNode(sDriverValue, 0, fDriverValue, [0,0,0], %s, bOutIsVector=True)" % utilsUnreal.flipVectorToUnreal(fTranslation))
    sUnrealCommands.append("sQuat = nodes.createFromEulerNode(sOffsetRotationValue)")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("nodes.createSetTransformExecuteNode(eJawOffset, [sOffsetTranslationValue, sQuat, None], bLocal=True)")
    sUnrealCommands.append("controllers.closeCommentBox('Auto Jaw')")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()







def mainBrowOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_mainBrow', [0, 0.5, 1])
    sNames = ['A', 'B', 'C']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sMainBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls8.createSimpleCurve('matrixNames', sName='bpLoc_l_mainBrowOrientation%s' % sNames[i], sParent=sBrowsMainGrp)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)



def bindMainEyebrows():
    sBody = cmds.ls(sl=True)[0]
    sJoints = [sJ for sJ in cmds.ls('jnt_?_brows_*', et='joint') if not sJ.endswith('_ref') and 'Inf' not in sJ]
    sJoints += cmds.ls('jnt_?_*Eyebrow', et='joint')

    sSkinCluster = 'skinCluster__%s' % sBody
    if cmds.objExists(sSkinCluster):
        deformers.addInfluences(sSkinCluster, sJoints)
    else:
        deformers.skinMesh(sBody, sJoints)




sBrowsMainGrp = '_grp_m_browsBpMain'


dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_mainBrow', sBrowsMainGrp, fDirection=(1, 0, 0))
dButtons['Create Left Brow Curve'].dSideButtons = {'?':['eyebrowVerts.jpg']}
dButtons['Create Left Brow Orientation Locators'] = mainBrowOrientationLocators
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsBrows', 'dDefaultSettingValuesBrows')

dButtons['Add Influences to Selected'] = bindMainEyebrows

dButtons['- Export Brows Main BPs -'] = lambda: exportBps('faceBlueprintsBrowsMain.ma', sBrowsMainGrp)


@builderTools.addToBuild(iOrder=30, dButtons=dButtons, bDisableByDefault=True)
def browSplinesSurface(iCurveJoints=None, sVisAttrCtr='head_ctrl', sParentJoint='jnt_m_headMain', bMiddleCtrl=True, dDefaultSettingValuesBrows={},
                       fPoseMainUp=0.5, fPoseMainDown=-0.5, fPoseInA=-0.5, sSurfaceSlide=None, fVerticalSplineOffset=[], bLegacyBlueprintIsOnlyUpVector=False):

    if sSurfaceSlide:
        sSurfaceSlide = utils.toList(sSurfaceSlide)[0]
        sSurfaceSlide_eyeSocket = '%s_eyeSocket' % sSurfaceSlide
        cmds.setAttr('%s.v' % sSurfaceSlide)
        cmds.setAttr('%s.v' % sSurfaceSlide_eyeSocket)

        sSurfaceSlide = cmds.duplicate(sSurfaceSlide, n='%s_copy' % sSurfaceSlide)[0]
        sSurfaceSlide_eyeSocket = cmds.duplicate(sSurfaceSlide_eyeSocket, n='%s_copy' % sSurfaceSlide_eyeSocket)[0]
        cmds.parent(sSurfaceSlide, sSurfaceSlide_eyeSocket, 'modules')

        constraints.matrixParentConstraint(sParentJoint, sSurfaceSlide, mo=True)
        constraints.matrixParentConstraint(sParentJoint, sSurfaceSlide_eyeSocket, mo=True)
    else:
        raise Exception('sSurfaceSlide needs to be set with a surface')

    dExtraJointInfluences = defaultdict(list)
    sDefaultSettingAttrsBrows = []

    sCtrlVis = utils.addOffOnAttr(utils.toList(sVisAttrCtr)[0], 'browVisCtrls', bDefaultValue=True, bReturnIfExists=True)

    utils.data.store('iBrowCurveJoints', iCurveJoints, sNode=utils.kFaceDataNode)

    sBrowsOrigGrp = cmds.createNode('transform', name='grp_browsOrig', p=getFaceGrp())
    sBrowsGrp = cmds.createNode('transform', name='grp_browSplines', p=getFaceGrp())
    xforms.matrixParentConstraint('jnt_m_headMain', sBrowsGrp)

    # dAllSculptPoseDriverValues = eval(utils.getStringAttr(utils.getMasterName(), 'dAllSculptPoseDriverValues', '{}', bCreateIfNotExists=True))
    # dAllSculptPoseDriverValues['browSplinesSplitJointsUp'] = fPoseMainUp
    # dAllSculptPoseDriverValues['browSplinesSplitJointsDown'] = fPoseMainDown
    # dAllSculptPoseDriverValues['browSplinesInA'] = fPoseInA
    # utils.addStringAttr(utils.getMasterName(), 'dAllSculptPoseDriverValues', str(dAllSculptPoseDriverValues), bLock=True)


    sBpCurves = ['bpCurve_%s_mainBrow' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleBrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv)

    bJointsPerCvs = True if isinstance(iCurveJoints, type(None)) else False

    aaCurvePoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                    curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aaCtrlPoints = [[aaCurvePoints[0][0], aaCurvePoints[0][3], aaCurvePoints[0][6]],
                    [aaCurvePoints[1][0], aaCurvePoints[1][3], aaCurvePoints[1][6]]]

    sCurves = [cmds.curve(p=aaCurvePoints[0], n='curve_l_brows'), cmds.curve(p=aaCurvePoints[1], n='curve_r_brows')]


    if bJointsPerCvs:
        aaPoints = [np.array(cmds.xform('%s.cv[*]' % sBpCurves[0], q=True, ws=True, t=True)).reshape(-1,3),
                    np.array(cmds.xform('%s.cv[*]' % sBpCurves[1], q=True, ws=True, t=True)).reshape(-1,3)]
        ffParams = [curves.getParamsFromPoints(sCurves[0], aaPoints[0]),
                    curves.getParamsFromPoints(sCurves[1], aaPoints[1])]
    else:
        ffParams = [curves.getParamsFromPercs(sCurves[0], np.linspace(0.0, 1.0, iCurveJoints)),
                    curves.getParamsFromPercs(sCurves[1], np.linspace(0.0, 1.0, iCurveJoints))]
        aaPoints = [curves.getPointsFromParams(sCurves[0], ffParams[0], bReturnNumpy=True),
                    curves.getPointsFromParams(sCurves[1], ffParams[1], bReturnNumpy=True)]


    aaPercs = [curves.getPercsFromParams(sCurves[0], ffParams[0]),
               curves.getPercsFromParams(sCurves[1], ffParams[1])]
    aaaTangentPoints = [[aaCtrlPoints[0][0],
                       aaCtrlPoints[0][0] * 0.05 + aaCtrlPoints[0][1] * 0.95,
                       aaCtrlPoints[0][1] * 0.95 + aaCtrlPoints[0][2] * 0.05,
                       aaCtrlPoints[0][2]],
                      [aaCtrlPoints[1][0],
                       aaCtrlPoints[1][0] * 0.05 + aaCtrlPoints[1][1] * 0.95,
                       aaCtrlPoints[1][1] * 0.95 + aaCtrlPoints[1][2] * 0.05,
                       aaCtrlPoints[1][2]]]
    aaTangentCtrlPercs = [curves.getPercsFromPoints(sCurves[0], aaaTangentPoints[0]),
                          curves.getPercsFromPoints(sCurves[1], aaaTangentPoints[1])]
    xJointsToTangentsWeightings =  [xforms.getCtrlWeightings(aaPercs[0], aaTangentCtrlPercs[0]),
                                    xforms.getCtrlWeightings(aaPercs[1], aaTangentCtrlPercs[1])]



    print ('xJointsToTangentsWeightings: ', xJointsToTangentsWeightings)

    aaaWeights3 = [utils.bSpline3([1,0,0], len(aaPoints[0])),
                   utils.bSpline3([0,1,0], len(aaPoints[0])),
                   utils.bSpline3([0,0,1], len(aaPoints[0]))], \
                  [utils.bSpline3([1,0,0], len(aaPoints[1])),
                   utils.bSpline3([0,1,0], len(aaPoints[1])),
                   utils.bSpline3([0,0,1], len(aaPoints[1]))]

    utils.data.store('browsSplineBsplineWeights', aaaWeights3)
    utils.data.store('dDefaultSettingValuesBrows', dDefaultSettingValuesBrows)

    # collect orients
    ssBpOrients = []
    for s,sSide in enumerate(['l','r']):
        sBpOrients = []
        for sName in ['A', 'B', 'C']:
            sBpOrient = 'bpLoc_%s_mainBrowOrientation%s' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_mainBrowOrientation%s' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    xforms.mirrorCurveTransforms(sLeftBpOrient)
            sBpOrients.append(sBpOrient)
        ssBpOrients.append(sBpOrients)

    # make up curves
    aaCurveUpPoints = []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1

        aaPushForwardWeights =  [utils.bSpline3([1, 0, 0], 7),
                                  utils.bSpline3([0, 1, 0], 7),
                                  utils.bSpline3([0, 0, 1], 7)]

        aForwardPoints =    utils.getNumpyMatrixFromTransform(ssBpOrients[s][0])[2,0:3] * aaPushForwardWeights[0][:,np.newaxis] + \
                            utils.getNumpyMatrixFromTransform(ssBpOrients[s][1])[2,0:3] * aaPushForwardWeights[1][:,np.newaxis] + \
                            utils.getNumpyMatrixFromTransform(ssBpOrients[s][2])[2,0:3] * aaPushForwardWeights[2][:,np.newaxis]
        aCurveUpPoints = aaCurvePoints[s] + aForwardPoints * fSliderScale * fSideMultipl
        aaCurveUpPoints.append(aCurveUpPoints)


    sUpCurves = [cmds.curve(p=aaCurveUpPoints[0], n='curve_l_browsUp'), cmds.curve(p=aaCurveUpPoints[1], n='curve_r_browsUp')]


    for sCrv in (sCurves + sUpCurves ):
        cmds.parent(sCrv, sBrowsOrigGrp)

    sInvParentRotationMatrix = nodes.getRotationMatrix2('%s.worldInverseMatrix' % sParentJoint)
    ccCtrls = [], []
    cBrowTransforms = []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1

        aUps = np.zeros((2, 3, 3), dtype='float64')

        for c, sName in enumerate(['A', 'B', 'C']):
            sAttrs = ['tx','ty', 'tz', 'r', 'sy']
            if c == 1:
                sAttrs.append('sx')
            cC = ctrls8.create(sName='browSplines%s' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(), fMatchPos=aaCtrlPoints[s][c],
                               sMatch=None if bLegacyBlueprintIsOnlyUpVector else 'bpLoc_%s_mainBrowOrientation%s' % (sSide, sName),
                               sShape='cube', fSliderScale=fSliderScale, sAttrs=sAttrs, fSize=0.25)
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            ccCtrls[s].append(cC)
            sPoseOffset = cC.appendOffsetGroup('pose')

            sBpOrients[s] = 'bpLoc_%s_mainBrowOrientation%s' % (sSide, sName)

            aMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sBpOrients[s]), dtype='float64').reshape(4, 4)
            aUps[s, c] = aMatrix[1][:3] * fSideMultipl
            cC.sUnscaledCtrl = xforms.insertParent(cC.sOut, 'grp_%s_browUnscaled%s' % (sSide, sName), bMatchParentTransform=True)
            nodes.createVectorMultiplyNode([1,1,1], '%s.s' % cC.sCtrl, sOperation='divide', sTarget='%s.s' % cC.sUnscaledCtrl)
            cC.sExtraMove, cC.sSecondPasser = cC.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'], bAddSecondPasser=True)

            cC.sJumpedOut = cmds.duplicate(cC.sOut, n='%sJumped' % cC.sOut, po=True)[0]
            constraints.matrixParentConstraint(cC.sOut, cC.sJumpedOut, sJumpOverTransforms=[cC.sExtraMove, cC.sSecondPasser])
            cC.sRotationMatrix = nodes.createMultMatrixNode([nodes.getRotationMatrix2('%s.worldMatrix' % cC.sJumpedOut, sName='Brows_rotation_%s_%s' % (sSide, sName)),
                                                             sInvParentRotationMatrix])
            cC.sRotatedUp = nodes.createPointByMatrixNode([fSideMultipl,0,0], cC.sRotationMatrix)

            # driver attributes for poses
            sTotalTranslate = utils.addAttr(cC.sPasser, ln='totalTranslate', at='double3', k=True)
            sSignedSecondPasser = nodes.createVectorMultiplyNode('%s.t' % cC.sSecondPasser, fSliderScale * fSideMultipl, sOperation='divide', bVectorByScalar=True)
            nodes.createVectorAdditionNode(['%s.t' % cC.sCtrl, '%s.t' % sPoseOffset, sSignedSecondPasser], sTarget=sTotalTranslate)


        if bLegacyBlueprintIsOnlyUpVector:
            xforms.orientThreePoints(ccCtrls[s][0].sPasser, aUps[s, 0], ccCtrls[s][1].sOut, fAimVector=[0, fSideMultipl, 0], fUpVector=[fSideMultipl, 0, 0])
            xforms.orientThreePoints(ccCtrls[s][2].sPasser, aUps[s, 2], ccCtrls[s][1].sOut, fAimVector=[0, fSideMultipl, 0], fUpVector=[-fSideMultipl, 0, 0])
            sUpMiddle = ((aaCtrlPoints[s][0] - aaCtrlPoints[s][1]) - (aaCtrlPoints[s][2] - aaCtrlPoints[s][1])) * 0.5
            xforms.orientThreePoints(ccCtrls[s][1].sPasser, aUps[s, 1], sUpMiddle, fAimVector=[0, fSideMultipl, 0], fUpVector=[-fSideMultipl, 0, 0])


        sAttrs = ['tx','ty', 'tz', 'r']
        cBrowTransform = ctrls8.create(sName='browMain', sSide=sSide, sParent=_getFaceCtrlGrp(), fSliderScale=fSliderScale,
                          sMatch=ccCtrls[s][1].sCtrl, sShape='locator', iColorIndex=0, sAttrs=sAttrs, fSize=1.0)
        constraints.matrixParentConstraint(sParentJoint, cBrowTransform.sPasser, mo=True)

        cBrowTransforms.append(cBrowTransform)
        cBrowTransform.sExtraMove = cBrowTransform.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])

        for c,cC in enumerate(ccCtrls[s]):
            constraints.matrixParentConstraint(sParentJoint, cC.sPasser, mo=True)
            constraints.matrixParentConstraint(cBrowTransform.sOut, cC.sSecondPasser, sJumpOverTransforms=[cBrowTransform.sExtraMove, cBrowTransform.sPasser], mo=True)
            sPoseOffset = cC.getOffsetByName('pose')

            ssPoseProducts = [], []
            ssSecondPasserProducts = [], []
            for sDir, fPoseValue in [('Down', fPoseMainDown), ('Up', fPoseMainUp)]:

                sSingleMainDownAttr = utils.addAttr(cC.sPasser, ln=f'singleMain{sDir}', min=0, max=1, dv=0, k=True)
                sMainBrowTransformDown = nodes.createRangeNode('%s.ty' % cBrowTransform.sCtrl, 0, fPoseValue, 0, 1)

                sCombinedDown = nodes.createAdditionNode([sMainBrowTransformDown, sSingleMainDownAttr])
                sPoseLoc = xforms.createLocator(f"_poseLoc__{cC.sCtrl.replace('_ctrl', '')}__main{sDir}", sParent=cmds.listRelatives(sPoseOffset, p=True))
                for a,sA in enumerate('tr'):
                    ssPoseProducts[a].append(nodes.createBlendNode(sCombinedDown, '%s.%s' % (sPoseLoc,sA), [0,0,0], bVector=True))
                nodes.createBlendNode(sCombinedDown, 1, 0, sTarget='%s.v' % sPoseLoc)
                utils.connectPosesLocVis(sPoseLoc)

                sDefaultSettingAttrsBrows.append('%s.t' % sPoseLoc)
                sDefaultSettingAttrsBrows.append('%s.r' % sPoseLoc)
                cmds.controller(cC.sCtrl, cBrowTransform.sCtrl, parent=True)
                utils.addStringAttr(sPoseLoc, 'sCtrl', cC.sCtrl)
                utils.addAttr(sPoseLoc, ln='driverCtrlValue', dv=fPoseValue)

                # singleMainDown setup
                cmds.setAttr('%s.ty' % cBrowTransform.sCtrl, fPoseValue)
                ffValues = [cmds.getAttr('%s.%s' % (cC.sSecondPasser,sA))[0] for sA in 'trs']
                cmds.setAttr('%s.ty' % cBrowTransform.sCtrl, 0.0)
                for a,sA in enumerate('tr'):
                    ssSecondPasserProducts[a].append(nodes.createBlendNode(sSingleMainDownAttr, ffValues[a], [0,0,0], bVector=True))

            for a,sA in enumerate('tr'):
                nodes.createVectorAdditionNode(ssPoseProducts[a], sTarget='%s.%s' % (sPoseOffset,sA))
                sMainConnection = cmds.listConnections('%s.%s' % (cC.sSecondPasser, sA), s=True, d=False, p=True)[0]
                nodes.createVectorAdditionNode([sMainConnection] + ssSecondPasserProducts[a], sTarget='%s.%s' % (cC.sSecondPasser, sA), bForce=True)


    sMoveSpeedPosAttrs = []
    sMoveSpeedNegAttrs = []
    for v in range(len(fVerticalSplineOffset)):
        sMoveSpeedPosAttrs.append(utils.addAttr(cBrowTransforms[0].sPasser, ln='offsetSplineFollowSpeedUp_%s' % utils.getLetter(v), min=0.0, max=3.0, dv=0.5, k=True, bReturnIfExists=True))
        sMoveSpeedNegAttrs.append(utils.addAttr(cBrowTransforms[0].sPasser, ln='offsetSplineFollowSpeedDown_%s' % utils.getLetter(v), min=0.0, max=3.0, dv=0.5, k=True, bReturnIfExists=True))
    sDefaultSettingAttrsBrows.extend(sMoveSpeedPosAttrs+sMoveSpeedNegAttrs)

    if bMiddleCtrl:
        sMiddleBp = 'bpJnt_m_browMiddle'
        if not cmds.objExists(sMiddleBp):
            cmds.createNode('joint', n=sMiddleBp, p=sBrowsMainGrp)
            cmds.delete(cmds.pointConstraint(ccCtrls[0][0].sCtrl, ccCtrls[1][0].sCtrl, sMiddleBp))
        cBrowMiddle = ctrls8.create(sName='browMiddle', sSide='m', sParent=_getFaceCtrlGrp(), fSliderScale=fSliderScale,
                              sMatch=sMiddleBp, sShape='cube', iColorIndex=1, sAttrs=['t','r','s'], fSize=0.25)
        cBrowMiddle.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
        sMoveWithSidesGrp = cBrowMiddle.appendOffsetGroup('movewithsides')
        sPushGrp = cBrowMiddle.appendOffsetGroup('push')
        sMiddle = xforms.createJoint('jnt_m_browMiddle', sMatch=sMiddleBp, sParent=jointOrGroup(sParentJoint), fSize=fSliderScale * 0.4)
        sMiddleCrease = xforms.createJoint('jnt_m_browMiddleCrease', sMatch=sMiddleBp, sParent=sMiddle, fSize=fSliderScale * 0.4)
        sMiddleDefault = xforms.createJoint('jnt_m_browMiddleDefault', sMatch=sMiddleBp, sParent=jointOrGroup(sParentJoint), fSize=fSliderScale * 0.3)
        dExtraJointInfluences[sMiddleDefault].append(sMiddle)

        sFollowAttr = utils.addAttr(cBrowMiddle.sCtrl, ln='follow', min=0, max=1, dv=1.0, k=True)
        sPushAttr = utils.addAttr(cBrowMiddle.sPasser, ln='autoPush', dv=0.1, k=True)
        sScaleAttr = utils.addAttr(cBrowMiddle.sPasser, ln='autoScale', min=0, dv=0.6, max=1.0, k=True)
        sCreaseMoveBackAttr = utils.addAttr(cBrowMiddle.sPasser, ln='autoCreaseTranslateBack', dv=0.5, k=True)
        sCreaseScaleInAttr = utils.addAttr(cBrowMiddle.sPasser, ln='autoCreaseScaleIn', min=0, dv=0.6, max=2.0, k=True)
        sDefaultSettingAttrsBrows.extend([sFollowAttr, sPushAttr, sScaleAttr, sCreaseMoveBackAttr, sCreaseScaleInAttr])

        sSideTranslation = nodes.createVectorAdditionNode(['%s.totalTranslate' % ccCtrls[0][0].sPasser, '%s.totalTranslate' % ccCtrls[1][0].sPasser])
        sSideTranslation = nodes.createVectorMultiplyNode(sSideTranslation, 0.5, bVectorByScalar=True)
        sMoveOffset = nodes.createVectorMultiplyNode(sSideTranslation, sFollowAttr, bVectorByScalar=True)
        cmds.connectAttr('%sY' % sMoveOffset, '%s.ty' % sMoveWithSidesGrp)
        cmds.connectAttr('%sZ' % sMoveOffset, '%s.tz' % sMoveWithSidesGrp)

        sFactor = nodes.createDistanceNode(nodes.getWorldPoint(ccCtrls[0][0].sJumpedOut), nodes.getWorldPoint(ccCtrls[1][0].sJumpedOut),
                                           fNormalized=1.0, sDivide=nodes.scaleFromXform(sParentJoint), sName='browsMiddleDistance')
        nodes.createRangeNode(sFactor, 1.0, 0.1, 0.0, sPushAttr, sTarget='%s.tz' % sPushGrp)
        nodes.createRangeNode(sFactor, 1.0, 0.1, 1.0, sScaleAttr, sTarget='%s.sx' % sPushGrp)
        nodes.createRangeNode(sFactor, 1.0, 0.1, 0.0, nodes.createMultiplyNode(sCreaseMoveBackAttr, -1.0), sTarget='%s.tx' % sMiddleCrease)
        nodes.createRangeNode(sFactor, 1.0, 0.1, 1.0, sCreaseScaleInAttr, sTarget='%s.sz' % sMiddleCrease)

        cmds.scaleConstraint(sMiddle, sMiddleDefault)

        constraints.matrixParentConstraint(sParentJoint, cBrowMiddle.sPasser, mo=True)

        if not sSurfaceSlide: # Middle
            constraints.matrixParentConstraint(cBrowMiddle.sCtrl, sMiddle, sJumpOverTransforms=[cBrowMiddle.sExtraMove, cBrowMiddle.sPasser])
            constraints.matrixParentConstraint(sMoveWithSidesGrp, sMiddleDefault, sJumpOverTransforms=[cBrowMiddle.sExtraMove, cBrowMiddle.sPasser])
        elif sSurfaceSlide: # Middle
            cBrowMiddle.sJumpedOut = cmds.duplicate(cBrowMiddle.sOut, n='%sJumped' % cBrowMiddle.sOut, po=True)[0]
            constraints.matrixParentConstraint(cBrowMiddle.sOut, cBrowMiddle.sJumpedOut, sJumpOverTransforms=[cBrowMiddle.sExtraMove, cBrowMiddle.sPasser])

            fnSurface = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sSurfaceSlide))
            sLocalMiddleCtrl = nodes.createPointByMatrixNode(nodes.getWorldPoint(cBrowMiddle.sJumpedOut), '%s.worldInverseMatrix' % cBrowMiddle.sPasser)

            sLocalAutoMoveGrp = nodes.createPointByMatrixNode(nodes.getWorldPoint(sMoveWithSidesGrp), '%s.worldInverseMatrix' % cBrowMiddle.sExtraMove)
            sTwoMiddleUvResults3 = [], []
            sDefaultUv3 = []
            for iAxis, iUv, fExtremes in [(0, 0, [fPoseInA, -fPoseInA]), (1, 1, [fPoseMainDown, fPoseMainUp])]:
                sAxis = 'xyz'[iAxis]
                mDefaultUv = fnSurface.closestPoint(OpenMaya2.MPoint(cmds.xform(cBrowMiddle.sCtrl, q=True, ws=True, t=True)), space=OpenMaya2.MSpace.kWorld)
                fDefaultLocatorPos = cmds.getAttr(sLocalMiddleCtrl)[0]

                if iAxis == 1:
                    cmds.setAttr('%s.ty' % cBrowTransforms[0].sCtrl, fExtremes[0])
                    cmds.setAttr('%s.ty' % cBrowTransforms[1].sCtrl, fExtremes[0])
                else:
                    cmds.setAttr('%s.tx' % cBrowMiddle.sCtrl, fExtremes[0])

                mUv0 = fnSurface.closestPoint(OpenMaya2.MPoint(cmds.xform(cBrowMiddle.sCtrl, q=True, ws=True, t=True)), space=OpenMaya2.MSpace.kWorld)
                fLocatorPos0 = cmds.getAttr(sLocalMiddleCtrl)[0]

                if iAxis == 1:
                    cmds.setAttr('%s.ty' % cBrowTransforms[0].sCtrl, fExtremes[1])
                    cmds.setAttr('%s.ty' % cBrowTransforms[1].sCtrl, fExtremes[1])
                else:
                    cmds.setAttr('%s.tx' % cBrowMiddle.sCtrl, fExtremes[1])

                mUv1 = fnSurface.closestPoint(OpenMaya2.MPoint(cmds.xform(cBrowMiddle.sCtrl, q=True, ws=True, t=True)), space=OpenMaya2.MSpace.kWorld)
                fLocatorPos1 = cmds.getAttr(sLocalMiddleCtrl)[0]

                cmds.setAttr('%s.ty' % cBrowTransforms[0].sCtrl, 0)
                cmds.setAttr('%s.ty' % cBrowTransforms[1].sCtrl, 0)
                cmds.setAttr('%s.tx' % cBrowMiddle.sCtrl, 0)

                sDefaultUv3.append(mDefaultUv[iUv+1])

                for d, sDriver in enumerate(['%s%s' % (sLocalMiddleCtrl, sAxis.upper()), '%s%s' % (sLocalAutoMoveGrp, sAxis.upper())]):
                    sTwoMiddleUvResults3[d].append(nodes.setDrivenKey(sDriver, [fLocatorPos0[iAxis], fDefaultLocatorPos[iAxis], fLocatorPos1[iAxis]],
                                               sDrivenAttrPath=None,
                                               fDrivenVals=[mUv0[iUv+1], mDefaultUv[iUv+1], mUv1[iUv+1]],
                                               bPreEndless=True, bPostEndless=True))

            sDefaultUv3.append(0)
            sTwoMiddleUvResults3[0].append(0)
            sTwoMiddleUvResults3[1].append(0)


            for sJoint, sUvResult3 in [(sMiddle, sTwoMiddleUvResults3[0]), (sMiddleDefault, sTwoMiddleUvResults3[1])]:
                sClamped = nodes.createClampNode(sUvResult3, [0.0001, 0.0001, 0.0001], [0.9999, 0.9999, 0.9999], bVector=True)
                sSurfaceInfo, _ = surfaces.createPointInfoNode(sSurfaceSlide, fParamU='%sR' % sClamped, fParamV='%sG' % sClamped)
                sLocalDriverMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sMoveWithSidesGrp,
                                                                 '%s.worldInverseMatrix' % cBrowMiddle.sExtraMove,
                                                                 '%s.worldMatrix' % cBrowMiddle.sPasser,
                                                                 '%s.worldInverseMatrix' % sParentJoint])
                sAimConstraint = cmds.createNode('aimConstraint', p=sBrowsOrigGrp)
                nodes.createPointByMatrixNode([0,1,0], nodes.getRotationMatrix2(sLocalDriverMatrix), sTarget='%s.worldUpVector' % sAimConstraint)
                nodes.createPointByMatrixNode('%s.normal' % sSurfaceInfo, sInvParentRotationMatrix, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                sJointTranslation = nodes.createPointByMatrixNode('%s.position' % sSurfaceInfo, '%s.worldInverseMatrix' % sParentJoint)
                if sJoint == sMiddleDefault:
                    cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sJoint)
                    cmds.connectAttr(sJointTranslation, '%s.t' % sJoint)
                else:
                    sSurfacedMatrixInHead = nodes.createComposeMatrixNode(xTranslate=sJointTranslation, xRotate='%s.constraintRotate' % sAimConstraint)
                    sWorldSurfaceMatrix = nodes.createMultMatrixNode([sSurfacedMatrixInHead, '%s.worldMatrix' % sParentJoint])

                    fAnimParentInSurfaceMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cBrowMiddle.sJumpedOut,
                                                                                nodes.createInverseMatrix(sWorldSurfaceMatrix, bJustValues=True)], bJustValues=True)
                    fSurfaceMatrixInAnimParent = nodes.createMultMatrixNode([sWorldSurfaceMatrix,
                                                                            '%s.worldInverseMatrix' % cBrowMiddle.sJumpedOut], bJustValues=True)

                    sTranslateSumZ = nodes.createAdditionNode(['%s.tz' % cBrowMiddle.sCtrl, '%s.tz' % sPushGrp])
                    sTranslateSumZ = nodes.createMultiplyNode(sTranslateSumZ, '%s.sx' % cBrowMiddle.sSlider)
                    sScaleSum = nodes.createVectorMultiplyNode('%s.s' % cBrowMiddle.sCtrl, '%s.s' % sPushGrp)
                    sAnimatedMatrix = nodes.createMultMatrixNode([fSurfaceMatrixInAnimParent,
                                                                  nodes.createComposeMatrixNode([0, 0, sTranslateSumZ], '%s.r' % cBrowMiddle.sCtrl, xScale=sScaleSum),
                                                                  fAnimParentInSurfaceMatrix,
                                                                  sSurfacedMatrixInHead])

                    nodes.createDecomposeMatrix(sAnimatedMatrix, sTargetPos='%s.t' % sMiddle, sTargetRot='%s.r' % sMiddle, sTargetScale='%s.s' % sMiddle)

                sOffsetJoints = []
                for v, fOffsetV in enumerate(fVerticalSplineOffset):
                    sOffsetJ = cmds.duplicate(sJoint, n='%s%s' % (sJoint ,utils.getLetter(v)), po=True)[0]
                    xforms.matchRadius(sOffsetJ, sJoint, 0.5)


                    # can we remove this attribute?? temporarily set the k flag to False, but should probably remove in future
                    sOffsetAttr = utils.addAttr(cBrowTransforms[s].sCtrl, ln='offsetSpline%s' % utils.getLetter(v), dv=fOffsetV, k=False, bReturnIfExists=True)


                    sExtraDefault = nodes.createVectorAdditionNode([sDefaultUv3, [0,sOffsetAttr,0]])

                    sDeltaFromMain = nodes.createVectorAdditionNode([sUvResult3, sDefaultUv3], sOperation='minus')
                    sMoveSpeed = nodes.createConditionNode('%sy' % sDeltaFromMain, '>', 0.0, sMoveSpeedPosAttrs[v], sMoveSpeedNegAttrs[v])

                    sDeltaFromMain = nodes.createVectorMultiplyNode(sDeltaFromMain, sMoveSpeed, bVectorByScalar=True)
                    sAddition = nodes.createVectorAdditionNode([sExtraDefault, sDeltaFromMain])
                    sClamped = nodes.createClampNode(sAddition, [0.0001, 0.0001, 0.0001], [0.9999, 0.9999, 0.9999], bVector=True)
                    sOffsetSurfaceInfo, _ = surfaces.createPointInfoNode(sSurfaceSlide if fOffsetV > 0.0 else sSurfaceSlide_eyeSocket, fParamU='%sR' % sClamped, fParamV='%sG' % sClamped)
                    nodes.createPointByMatrixNode('%s.position' % sOffsetSurfaceInfo, '%s.parentInverseMatrix' % sOffsetJ, sTarget='%s.t' % sOffsetJ)

                    sAim = cmds.createNode('aimConstraint', p=sBrowsOrigGrp)
                    sTarget = '%s.normal' % sOffsetSurfaceInfo
                    nodes.createPointByMatrixNode(sTarget, sInvParentRotationMatrix, sTarget='%s.target[0].targetTranslate' % sAim)
                    nodes.createPointByMatrixNode('%s.tangentU' % sOffsetSurfaceInfo, sInvParentRotationMatrix, sTarget='%s.worldUpVector' % sAim)
                    cmds.connectAttr('%s.constraintRotate' % sAim, '%s.r' % sOffsetJ)
                    dExtraJointInfluences[sMiddleDefault].append(sOffsetJ)




    # ctrl aiming setup
    ssJoints = [], []
    ssMoveOutEach = [[0, 0, 0], [0, 0, 0]]

    ccTangents = [], []
    ssFourRotationMatrices = [], []
    ssFourRotationMatricesWithBend = [], []
    ssPointOnCurves = [], []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1

        sLocalCtrlMatrix1 = nodes.createMultMatrixNode(['%s.worldMatrix' % ccCtrls[s][1].sCtrl, '%s.worldInverseMatrix' % ccCtrls[s][1].sExtraMove])
        sLocalCtrlInverseNoScaleMatrix1 = nodes.createInverseMatrix(nodes.createMultMatrixNode(['%s.worldMatrix' % ccCtrls[s][1].sUnscaledCtrl, '%s.worldInverseMatrix' % ccCtrls[s][1].sExtraMove]))

        for c, sLetter in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            cC.sAimer = xforms.createTransform('loc_%s_browAimer%s' % (sSide, sLetter), sParent=cC.sUnscaledCtrl)
            sAimTargetMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                        '%s.worldInverseMatrix' % cC.sExtraMove,
                                                        '%s.worldMatrix' % cC.sSecondPasser])
            cC.sAimTarget = nodes.createDecomposeMatrix(sAimTargetMatrix)
            sRelativeMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut, '%s.worldInverseMatrix' % cC.sExtraMove])
            cC.sTwist = '%sX' % nodes.createDecomposeMatrix(sRelativeMatrix, bReturnRotate=True)
            cmds.setAttr('%s.inputRotateOrder' % cC.sTwist.split('.')[0], 1) # to have x last

            cC.sInfs = []
            cC.cTangents = []
            sMoveOuts = []

            sSecondPasserRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % cC.sSecondPasser)

            for d,sDir in enumerate(['in', 'out']):
                if (c==0 and d==0) or (c==2 and d==1):
                    continue
                sInf = xforms.createJoint('jnt_%s_browInf%s%s' % (sSide, sLetter, utils.getFirstLetterUpperCase(sDir)), sParent=cC.sSecondPasser, fSize=0.5) #, xPos=[[-0.01, 0.01][d],0,0])
                cTangent = ctrls8.create('browTangent%s%s' % (sLetter, utils.getFirstLetterUpperCase(sDir)), sSide=sSide, sMatch=sInf, sShape='revL_y',
                                    sParent=cC.sAimer, sAttrs=['t','r','s'], fSize=fSliderScale*0.4, iColorIndex=1, iSlider=6)
                fScale = cmds.getAttr('%s.s' % cTangent.sPasser)[0]
                cmds.setAttr('%s.s' % cTangent.sPasser, abs(fScale[0]), abs(fScale[1]), abs(fScale[2]))

                cmds.controller(cTangent.sCtrl, cC.sCtrl, parent=True)
                utils.addStringAttr(sInf, 'sCtrl', cTangent.sCtrl)
                if d == 0:
                    cmds.setAttr('%s.sx' % cTangent.sSlider, -1)
                    cmds.setAttr('%s.sx' % cTangent.sOut, -fSideMultipl)
                sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cTangent.sOut, '%s.worldInverseMatrix' % cC.sExtraMove])
                sDecomp = nodes.createDecomposeMatrix(sMatrix)

                sTangentRotationMatrix = nodes.createComposeMatrixNode(xRotate='%s.outputRotate' % sDecomp.split('.')[0]) #nodes.getRotationMatrix2(sMatrix)

                sAimVector = nodes.createPointByMatrixNode([fSideMultipl,0,0], sTangentRotationMatrix)

                sAimMatrix = nodes.createAimMatrixNode(nodes.createComposeMatrixNode(['%sX' % sDecomp, '%sY' % sDecomp, 0]),
                                                       sTargetPos=['%sX' % sAimVector, '%sY' % sAimVector, 0], bAlignAim=True, aim=[fSideMultipl, 0, 0], up=[0,fSideMultipl,0])
                if c == 1:
                    sAimMatrixScaled = nodes.createMultMatrixNode([sAimMatrix, sLocalCtrlInverseNoScaleMatrix1, sLocalCtrlMatrix1])
                else:
                    sAimMatrixScaled = sAimMatrix

                cmds.connectAttr(sAimMatrixScaled, '%s.offsetParentMatrix' % sInf)

                cTangent.sTwistAngle = utils.addAttr(cTangent.sCtrl, ln='twist', k=False, cb=True,
                                                     sConnect=xforms.getLocalAngle(sTangentRotationMatrix, iForwardAxis=1, iUpAxis=2, bForwardNeg=sSide=='r'))

                cTangent.sBendAngle = utils.addAttr(cTangent.sCtrl, ln='bend', k=False, cb=True,
                                                    sConnect=xforms.getLocalAngle(sTangentRotationMatrix, iForwardAxis=0, iUpAxis=2, bForwardNeg=sSide=='r' and d==1))

                utils.addOffOnAttr(cC.sCtrl, 'tangentCtrlVis', bReturnIfExists=True, sTarget='%s.v' % cTangent.sPasser)

                cTangent.sPose = cTangent.appendOffsetGroup('pose')

                cC.cTangents.append(cTangent)
                ccTangents[s].append(cTangent)
                utils.addToListStringAttr(cC.sCtrl, 'sTangentCtrls', [cTangent.sCtrl])

                sMoveOuts.append('%sZ' % sDecomp)

                ssFourRotationMatricesWithBend[s].append(nodes.createMultMatrixNode([sTangentRotationMatrix,
                                                                                    sSecondPasserRotationMatrix]))
                ssFourRotationMatrices[s].append(nodes.createMultMatrixNode([sAimMatrix,
                                                                            sSecondPasserRotationMatrix]))

                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf)

                cC.sInfs.append(sInf)




            ssMoveOutEach[s][c] = sMoveOuts[0] if len(sMoveOuts) == 1 else nodes.createAdditionNode(sMoveOuts)
            if s == 1:
                ssMoveOutEach[s][c] = nodes.createMultiplyNode(ssMoveOutEach[s][c], -1.0)


        for c, sAimTargets, fAim in [(0, [ccCtrls[s][1].sAimTarget], [fSideMultipl,0,0]),
                                     (1, [ccCtrls[s][0].sAimTarget, ccCtrls[s][2].sAimTarget], [-fSideMultipl,0,0]),
                                     (2, [ccCtrls[s][1].sAimTarget], [-fSideMultipl,0,0])]:

            sAimer = ccCtrls[s][c].sAimer
            sAimConstraint = constraints.aimConstraintEmpty(sAimer, aim=fAim, bIgnoreConstraintRotateTranslateConnection=True)

            sCtrlNoRotate = nodes.createMultMatrixNode(['%s.worldMatrix' % ccCtrls[s][c].sCtrl,
                                                        '%s.worldInverseMatrix' % ccCtrls[s][c].sExtraMove])
            sAimerParent = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(nodes.createDecomposeMatrix(sCtrlNoRotate)),
                                                     '%s.worldMatrix' % ccCtrls[s][c].sSecondPasser])
            sParentInv = nodes.createInverseMatrix(sAimerParent)

            if len(sAimTargets) == 1:
                sAimPointTotal = nodes.createPointByMatrixNode(sAimTargets[0], sParentInv)

            elif len(sAimTargets) == 2:
                sAimPoint0 = nodes.createPointByMatrixNode(sAimTargets[0], sParentInv)
                sAimPoint1 = nodes.createPointByMatrixNode(sAimTargets[1], sParentInv)
                sAimPointTotal = nodes.createVectorAdditionNode([sAimPoint0, sAimPoint1], sOperation='minus')

            cmds.connectAttr(sAimPointTotal, '%s.target[0].targetTranslate' % sAimConstraint)


    # PoseLocs
    #
    for s,sSide in enumerate(['l','r']):

        if not sSurfaceSlide: # if we don't have sSurfaceSlide geo, we can get better
            for c, sName in enumerate(['A', 'B', 'C']):
                cC = ccCtrls[s][c]
                sDrivenGrp = cC.sOut
                sRangesR = []
                sRangesT = []
                for sDir,sDriverA,fDriverCtrlValue in [('up', 'Y', fPoseMainUp),
                                                        ('down', 'Y', fPoseMainDown),
                                                        ('in', 'X', fPoseInA)]:

                    sPoseLoc = xforms.createLocator(f"_poseLoc__{cC.sCtrl.replace('_ctrl', '')}__{sDir}", sParent=cmds.listRelatives(cC.sOut, p=True), fSize=fSliderScale*0.4)
                    sDefaultSettingAttrsBrows.append('%s.t' % sPoseLoc)
                    sDefaultSettingAttrsBrows.append('%s.r' % sPoseLoc)

                    sDriverAttr = '%s.totalTranslate%s' % (cC.sPasser, sDriverA)

                    sDriverValueMultipl = nodes.createMultiplyNode(fDriverCtrlValue, 100)
                    sRangesR.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                          [0,0,0],
                                                          nodes.createVectorMultiplyNode('%s.r' % sPoseLoc, 100, bVectorByScalar=True),
                                                          bOutRangeIsVector=True, sName='r_%s_%s' % (sDir, sDriverA)))
                    sRangesT.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                          [0,0,0],
                                                          nodes.createVectorMultiplyNode('%s.t' % sPoseLoc, 100, bVectorByScalar=True),
                                                          bOutRangeIsVector=True, sName='t_%s_%s' % (sDir, sDriverA)))
                    nodes.createRangeNode(sDriverAttr, 0, fDriverCtrlValue, 0, 1, sTarget='%s.v' % sPoseLoc)
                    utils.connectPosesLocVis(sPoseLoc)

                    sDefaultSettingAttrsBrows.append('%s.t' % sPoseLoc)
                    sDefaultSettingAttrsBrows.append('%s.r' % sPoseLoc)

                    utils.addAttr(sPoseLoc, ln='driverCtrlValue', dv=fDriverCtrlValue)

                    # sDefaultSettingAttrsBrows.append(sDriverValue)
                    utils.addStringAttr(sPoseLoc, 'sCtrl', cC.sCtrl)
                nodes.createVectorAdditionNode(sRangesR, sTarget='%s.r' % sDrivenGrp)
                nodes.createVectorAdditionNode(sRangesT, sTarget='%s.t' % sDrivenGrp)

        # pre tangent ctrls
        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            # for sDrivenGrp in [cTangent.sPose for cTangent in cC.cTangents]:
            for cTangent in cC.cTangents:
                sDrivenGrp = cTangent.sPose
                sRangesR = []
                sRangesT = []
                for sDir,sDriverA,fDriverCtrlValue in [#('up', 'Y', fPoseMainUp),
                                                      #('down', 'Y', fPoseMainDown),
                                                      ('in', 'X', fPoseInA)]:
                    sDriverValue = utils.addAttr(sPoseLoc, ln='driverCtrlValueTangents', k=True, dv=fDriverCtrlValue, bReturnIfExists=True)

                    sPoseLoc = xforms.createLocator(f"_poseLoc__{cTangent.sCtrl.replace('_ctrl', '')}__tangent{sDir.title()}", sParent=cmds.listRelatives(sDrivenGrp, p=True), fSize=fSliderScale*0.1)

                    sDriverAttr = '%s.totalTranslate%s' % (cC.sPasser, sDriverA)

                    sDriverValueMultipl = nodes.createMultiplyNode(sDriverValue, 100)
                    sRangesR.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                          [0,0,0],
                                                          nodes.createVectorMultiplyNode('%s.r' % sPoseLoc, 100, bVectorByScalar=True),
                                                          bOutRangeIsVector=True, sName='r_%s_%s' % (sDir, sDriverA)))
                    sRangesT.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                          [0,0,0],
                                                          nodes.createVectorMultiplyNode('%s.t' % sPoseLoc, 100, bVectorByScalar=True),
                                                          bOutRangeIsVector=True, sName='t_%s_%s' % (sDir, sDriverA)))
                    nodes.createRangeNode(sDriverAttr, 0, sDriverValue, 0, 1, sTarget='%s.v' % sPoseLoc)
                    utils.connectPosesLocVis(sPoseLoc)

                    sDefaultSettingAttrsBrows.append('%s.r' % sPoseLoc)
                    sDefaultSettingAttrsBrows.append('%s.t' % sPoseLoc)
                    sDefaultSettingAttrsBrows.append(sDriverValue)
                    utils.addStringAttr(sPoseLoc, 'sCtrl', cTangent.sCtrl)
                    utils.addAttr(sPoseLoc, ln='driverCtrlValue', dv=fDriverCtrlValue)

                nodes.createVectorAdditionNode(sRangesR, sTarget='%s.r' % sDrivenGrp)
                nodes.createVectorAdditionNode(sRangesT, sTarget='%s.t' % sDrivenGrp)


        weights.skinCurveBSpline4(patch.patchFromName(sCurves[s]), utils.flattenedList([cC.sInfs for cC in ccCtrls[s]]))
        weights.skinCurveBSpline4(patch.patchFromName(sUpCurves[s]), utils.flattenedList([cC.sInfs for cC in ccCtrls[s]]))


        sUpGroups = []

        for j, fP in enumerate(ffParams[s]):
            sJ = 'jnt_%s_brows_%03d' % (sSide, j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, jointOrGroup(sParentJoint))
                xforms.resetJoint(sJ)
                cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.25)
            else:
                sJ = xforms.createJoint(sJ, fSize=fSliderScale * 0.25, sParent=jointOrGroup(sParentJoint))

            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)

            sUp = xforms.createTransform(sName='grp_%s_browsUp_%03d' % (sSide, j))
            cmds.parent(sUp, sBrowsOrigGrp)

            ssJoints[s].append(sJ)
            sUpGroups.append(sUp)

            # scale
            sMultipls = [nodes.createVectorMultiplyNode('%s.s' % ccCtrls[s][c].sCtrl, aaaWeights3[s][c][j], bVectorByScalar=True) for c in [0,1,2]]
            sScaleAddition = nodes.createVectorAdditionNode(sMultipls)
            cmds.connectAttr('%sy' % sScaleAddition, '%s.sy' % sJ)
            # cmds.connectAttr('%sz' % sScaleAddition, '%s.sx' % sJ)

            _, sPosOnCurve = curves.createPointInfoNode(sCurves[s], fParam=fP)
            ssPointOnCurves[s].append(sPosOnCurve)


        sLocators = []
        sLocalLocators = []
        sSurfaceNodes = []
        sPushedOutPoints = []
        for j, fP in enumerate(ffParams[s]):
            sSurfaceN = surfaces.createPointInfoNode(sSurfaceSlide)[0]
            sMoveOutSum = nodes.createDotProductNode(ssMoveOutEach[s], [aaaWeights3[s][0][j], aaaWeights3[s][1][j], aaaWeights3[s][2][j]])
            sPosition = nodes.createVectorAdditionNode(['%s.position' % sSurfaceN, nodes.createVectorMultiplyNode( '%s.normalizedNormal' % sSurfaceN, sMoveOutSum,  bVectorByScalar=True)])
            sSurfaceNodes.append(sSurfaceN)
            sPushedOutPoints.append(sPosition)


        iMiddleIndex = int(len(ffParams[s]) / 2)
        for iMatrix, iPointIndex in enumerate([0, iMiddleIndex, iMiddleIndex, len(ffParams[s])-1]):
            ssFourRotationMatricesWithBend[s][iMatrix] = nodes.createComposeMatrixNode(sPushedOutPoints[iPointIndex], nodes.createDecomposeMatrix(ssFourRotationMatricesWithBend[s][iMatrix], bReturnRotate=True))
            ssFourRotationMatrices[s][iMatrix] = nodes.createInverseMatrix(nodes.createComposeMatrixNode(sPushedOutPoints[iPointIndex], nodes.createDecomposeMatrix(ssFourRotationMatrices[s][iMatrix], bReturnRotate=True)))

        for j, fP in enumerate(ffParams[s]):
            sJ = ssJoints[s][j]
            sLoc = xforms.createLocator('loc_%s_brows_%03d' % (sSide, j), fSize=fSliderScale * 0.25, sParent=sBrowsOrigGrp)
            sLocators.append(sLoc)
            cmds.connectAttr(ssPointOnCurves[s][j],'%s.t' % sLoc)
            sLocalLocators.append(nodes.createPointByMatrixNode(nodes.getWorldPoint(sLoc), '%s.worldInverseMatrix' % cBrowTransforms[s].sPasser))

            iInf0, iInf1, fBlend = xJointsToTangentsWeightings[s][j]
            sPositionMatrices = [nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sPushedOutPoints[j]),
                                                            ssFourRotationMatrices[s][iInf],
                                                            ssFourRotationMatricesWithBend[s][iInf],
                                                            '%s.worldInverseMatrix' % sParentJoint]) for iInf in [iInf0, iInf1]]
            sBlendPositionMatrix = nodes.createBlendMatrixNode(sPositionMatrices, [nodes.createReverseNode(fBlend), fBlend])

            nodes.createDecomposeMatrix(sBlendPositionMatrix, '%s.t' % sJ)



        if sSurfaceSlide:
            # utils.parentTo(sSurfaceSlide_copy, sBrowsGrp)
            fnSurface = OpenMaya2.MFnNurbsSurface(utils.getDagPath(sSurfaceSlide))

            sOrientToCurveAttrs = [utils.addAttr(ccCtrls[s][0].sPasser, ln='upVectorFromCurveTangent', min=0, max=1, dv=0.0, k=True),
                                   utils.addAttr(ccCtrls[s][1].sPasser, ln='upVectorFromCurveTangent', min=0, max=1, dv=1.0, k=True),
                                   utils.addAttr(ccCtrls[s][2].sPasser, ln='upVectorFromCurveTangent', min=0, max=1, dv=1.0, k=True)]
            sDefaultSettingAttrsBrows.extend(sOrientToCurveAttrs)


            for j, sJ in enumerate(ssJoints[s]):
                sUvResult3 = []
                sDefaultUv3 = []
                for iAxis, iUv, fExtremes in [(0, 0, [fPoseInA, -fPoseInA]), (1, 1, [fPoseMainDown, fPoseMainUp])]:

                    sAxis = 'xyz'[iAxis]
                    mDefaultUv = fnSurface.closestPoint(OpenMaya2.MPoint(cmds.xform(sLocators[j], q=True, ws=True, t=True)), space=OpenMaya2.MSpace.kWorld)
                    fDefaultLocatorPos = cmds.getAttr(sLocalLocators[j])[0]

                    cmds.setAttr('%s.t%s' % (cBrowTransforms[s].sCtrl, sAxis), fExtremes[0])
                    mUv0 = fnSurface.closestPoint(OpenMaya2.MPoint(cmds.xform(sLocators[j], q=True, ws=True, t=True)), space=OpenMaya2.MSpace.kWorld)
                    fLocatorPos0 = cmds.getAttr(sLocalLocators[j])[0]
                    cmds.setAttr('%s.t%s' % (cBrowTransforms[s].sCtrl, sAxis), fExtremes[1])
                    mUv1 = fnSurface.closestPoint(OpenMaya2.MPoint(cmds.xform(sLocators[j], q=True, ws=True, t=True)), space=OpenMaya2.MSpace.kWorld)
                    fLocatorPos1 = cmds.getAttr(sLocalLocators[j])[0]

                    cmds.setAttr('%s.t%s' % (cBrowTransforms[s].sCtrl, sAxis), 0)

                    sDriver = '%s%s' % (sLocalLocators[j], sAxis.upper())
                    sUvResult3.append(nodes.setDrivenKey(sDriver, [fLocatorPos0[iAxis], fDefaultLocatorPos[iAxis], fLocatorPos1[iAxis]],
                                                       sDrivenAttrPath=None,
                                                       fDrivenVals=[mUv0[iUv+1], mDefaultUv[iUv+1], mUv1[iUv+1]],
                                                       bPreEndless=True, bPostEndless=True))
                    sDefaultUv3.append(mDefaultUv[iUv+1])


                sUvResult3.append(0)
                sDefaultUv3.append(0)
                sClamped = nodes.createClampNode(sUvResult3, [0.01, 0.01, 0.01], [0.99, 0.99, 0.99], bVector=True)
                cmds.connectAttr('%sR' % sClamped, '%s.parameterU' % sSurfaceNodes[j])
                cmds.connectAttr('%sG' % sClamped, '%s.parameterV' % sSurfaceNodes[j])

                sOffsetSurfaceNodes = []
                sOffsetJoints = []
                for v,fOffsetV in enumerate(fVerticalSplineOffset):
                    sNameSplits = sJ.split('_')
                    sNameSplits[-2] = '%s%s' % (sNameSplits[2], utils.getLetter(v))
                    sOffsetJ = cmds.duplicate(sJ, n='_'.join(sNameSplits))[0]
                    sOffsetJoints.append(sOffsetJ)
                    xforms.matchRadius(sOffsetJ, sJ, 0.5)

                    sOffsetAttr = utils.addAttr(cBrowTransforms[s].sCtrl, ln='offsetSpline%s' % utils.getLetter(v), dv=fOffsetV, k=False, bReturnIfExists=True)
                    # sMoveSpeedAttr = utils.addAttr(cBrowTransforms[0].sPasser, ln='offsetSplineFollowSpeed_%s' % utils.getLetter(v), min=0.0, max=1.0, dv=0.5, k=True, bReturnIfExists=True)

                    sExtraDefault = nodes.createVectorAdditionNode([sDefaultUv3, [0,sOffsetAttr,0]])

                    sDeltaFromMain = nodes.createVectorAdditionNode([sUvResult3, sDefaultUv3], sOperation='minus')
                    sMoveSpeed = nodes.createConditionNode('%sy' % sDeltaFromMain, '>', 0.0, sMoveSpeedPosAttrs[v], sMoveSpeedNegAttrs[v])
                    sMoveSpeedAverage = nodes.createAdditionNode([sMoveSpeedPosAttrs[v], sMoveSpeedNegAttrs[v]], sOperation='average')

                    sDeltaFromMain = nodes.createVectorMultiplyNode(sDeltaFromMain, [sMoveSpeedAverage, sMoveSpeed, 0])
                    sAddition = nodes.createVectorAdditionNode([sExtraDefault, sDeltaFromMain])
                    sClamped = nodes.createClampNode(sAddition, [0.01, 0.01, 0.01], [0.99, 0.99, 0.99], bVector=True)
                    sOffsetSurfaceInfo, _ = surfaces.createPointInfoNode(sSurfaceSlide if fOffsetV > 0.0 else sSurfaceSlide_eyeSocket, fParamU='%sR' % sClamped, fParamV='%sG' % sClamped)
                    nodes.createPointByMatrixNode('%s.position' % sOffsetSurfaceInfo, '%s.parentInverseMatrix' % sOffsetJ, sTarget='%s.t' % sOffsetJ)
                    sOffsetSurfaceNodes.append(sOffsetSurfaceInfo)
                    dExtraJointInfluences[sJ].append(sOffsetJ)



                sCurveUpVector = nodes.createPointByMatrixNode('%s.normalizedTangent' % ssPointOnCurves[s][j].split('.')[0], sInvParentRotationMatrix) #, sTarget='%s.worldUpVector' % sAim)
                sCtrlUpVector = nodes.createVectorAdditionNode([nodes.createVectorMultiplyNode(ccCtrls[s][0].sRotatedUp, aaaWeights3[s][0][j], bVectorByScalar=True),
                                                                nodes.createVectorMultiplyNode(ccCtrls[s][1].sRotatedUp, aaaWeights3[s][1][j], bVectorByScalar=True),
                                                                nodes.createVectorMultiplyNode(ccCtrls[s][2].sRotatedUp, aaaWeights3[s][2][j],  bVectorByScalar=True)])
                sCtrlUpVector = nodes.createNormalizedVector(sCtrlUpVector)
                fDiff = nodes.createVectorAdditionNode([sCurveUpVector, sCtrlUpVector], sOperation='minus', bJustValues=True)
                sCtrlUpVectorOffsetted = nodes.createVectorAdditionNode([fDiff, sCtrlUpVector])
                sOrientToCurveStrength = nodes.createDotProductNode(sOrientToCurveAttrs, [aaaWeights3[s][0][j], aaaWeights3[s][1][j], aaaWeights3[s][2][j]])
                sBlendUpVector = nodes.createBlendNode(sOrientToCurveStrength, sCurveUpVector, sCtrlUpVectorOffsetted, bVector=True)

                for vv in range(1 + len(fVerticalSplineOffset)):
                    sAim = cmds.createNode('aimConstraint', p=sBrowsOrigGrp)
                    sTarget = '%s.normal' % (sSurfaceNodes[j] if vv==0 else sOffsetSurfaceNodes[vv-1])
                    nodes.createPointByMatrixNode(sTarget, sInvParentRotationMatrix, sTarget='%s.target[0].targetTranslate' % sAim)
                    if vv == 0:
                        cmds.setAttr('%s.upVector' % sAim, 0,0,1)
                        cmds.connectAttr(sBlendUpVector, '%s.worldUpVector' % sAim)
                    else:
                        nodes.createPointByMatrixNode('%s.tangentU' %sOffsetSurfaceNodes[vv-1], sInvParentRotationMatrix, sTarget='%s.worldUpVector' % sAim)
                    cmds.connectAttr('%s.constraintRotate' % sAim, '%s.jo' % (sJ if vv==0 else sOffsetJoints[vv-1])) # could do jo instead of r, too

                iCtrl0, iCtrl1, fBlend = xJointsToTangentsWeightings[s][j]
                nodes.createBlendNode(fBlend, ccTangents[s][iCtrl1].sTwistAngle, ccTangents[s][iCtrl0].sTwistAngle, sTarget='%s.rz' % sJ)



    cSideCtrls = utils.flattenedList(ccCtrls)
    for cC in cSideCtrls + cBrowTransforms + utils.flattenedList([cC.cTangents for cC in cSideCtrls]):
        cC.setDefaultAttrDict()
    if bMiddleCtrl:
        cBrowMiddle.setDefaultAttrDict()

    for sMeasureJoint, sAdditionalJoints in dExtraJointInfluences.items():
        utils.addStringAttr(sMeasureJoint, 'sAdditionalSkinJoints', str(sAdditionalJoints))

    # measure attributes for blendShape Targets
    sMeasureJoints = ssJoints[0] + ssJoints[1]
    if bMiddleCtrl:
        sMeasureJoints.append(sMiddleDefault)

    sBrowSplinesCtrlInfluences =  [cC.sOut for cC in ccCtrls[0] + ccCtrls[1]]

    dInverseSliderInPasserMatrices = {}
    for sSide, sCtrl in [('m', 'browMiddle_ctrl'), ('l','browMain_l_ctrl'), ('r','browMain_r_ctrl')]:
        cParentCtrl = ctrls8.ctrlFromName(sCtrl)
        sMatrix = nodes.createMultMatrixNode(['%s.matrix' % cParentCtrl.sSlider,
                                             '%s.worldMatrix' % cParentCtrl.sPasser])
        dInverseSliderInPasserMatrices[sSide] = nodes.createInverseMatrix(sMatrix)

    for sJ in sMeasureJoints:
        sLocalJointMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sJ, dInverseSliderInPasserMatrices[utils.getSide(sJ)]])
        sDecomp = nodes.createDecomposeMatrix(sLocalJointMatrix)
        sVerticalAttr = utils.addAttr(sJ, ln='verticalMove', k=True)
        cmds.connectAttr('%sY' % sDecomp, sVerticalAttr)
        sDefaultAttr = utils.addAttr(sJ, ln='defaultY', dv=cmds.getAttr(sVerticalAttr), k=True)
        cmds.setAttr(sDefaultAttr, lock=True)

    for cC in ccCtrls[0] + ccCtrls[1]:
        sLocalJointMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                        '%s.worldInverseMatrix' % cC.sExtraMove,
                                                        '%s.worldMatrix' % cC.sSecondPasser,
                                                        dInverseSliderInPasserMatrices[utils.getSide(cC.sSide)]])
        sDecomp = nodes.createDecomposeMatrix(sLocalJointMatrix)
        sVerticalAttr = utils.addAttr(cC.sOut, ln='verticalMove', k=True)
        cmds.connectAttr('%sY' % sDecomp, sVerticalAttr)
        sDefaultAttr = utils.addAttr(cC.sOut, ln='defaultY', dv=cmds.getAttr(sVerticalAttr), k=True)
        cmds.setAttr(sDefaultAttr, lock=True)


    # UP
    cmds.setAttr('%s.ty' % cBrowTransforms[0].sCtrl, fPoseMainUp)
    cmds.setAttr('%s.ty' % cBrowTransforms[1].sCtrl, fPoseMainUp)
    for sJ in sMeasureJoints + sBrowSplinesCtrlInfluences:
        sUpAttr = nodes.addAttr(sJ, ln='movedUp', min=0, max=1, k=True)
        fVerticalUpPose = cmds.getAttr('%s.verticalMove' % sJ)
        nodes.createRangeNode('%s.verticalMove' % sJ, cmds.getAttr('%s.defaultY' % sJ), fVerticalUpPose, 0, 1, sTarget=sUpAttr)
        utils.addAttr(sJ, ln='verticalUpPose', dv=fVerticalUpPose, k=True)


    # DOWN
    cmds.setAttr('%s.ty' % cBrowTransforms[0].sCtrl, fPoseMainDown)
    cmds.setAttr('%s.ty' % cBrowTransforms[1].sCtrl, fPoseMainDown)
    for sJ in sMeasureJoints + sBrowSplinesCtrlInfluences:
        sDownAttr = nodes.addAttr(sJ, ln='movedDown', min=0, max=1, k=True)
        fVerticalDownPose = cmds.getAttr('%s.verticalMove' % sJ)
        nodes.createRangeNode('%s.verticalMove' % sJ, cmds.getAttr('%s.defaultY' % sJ), fVerticalDownPose, 0, 1, sTarget=sDownAttr)
        utils.addAttr(sJ, ln='verticalDownPose', dv=fVerticalDownPose, k=True)

    cmds.setAttr('%s.ty' % cBrowTransforms[0].sCtrl, 0)
    cmds.setAttr('%s.ty' % cBrowTransforms[1].sCtrl, 0)

    utils.data.store('browSplinesMeasureJoints', sMeasureJoints)


    utils.data.store('sDefaultSettingAttrsBrows', sDefaultSettingAttrsBrows)
    for sA,fV in dDefaultSettingValuesBrows.items():
        if cmds.objExists(sA):
            if isinstance(fV, (list,tuple)):
                cmds.setAttr(sA, *fV)
            else:
                cmds.setAttr(sA, fV)
        else:
            report.report.addLogText('skipping "%s", doesn\'t exist..' % sA)

    sBrowSplinesCtrlInfluences.append(sMiddleDefault)
    utils.data.store('sBrowSplinesCtrlInfluences', sBrowSplinesCtrlInfluences)


def bindTweakers(sStringMatch='jnt_?_tweakerLids*'):
    sBodyMeshes = cmds.ls(sl=True)
    sBody = sBodyMeshes[0]
    sJoints = [sJ for sJ in cmds.ls(sStringMatch, et='joint') if not sJ.endswith('_ref') and 'Inf' not in sJ]
    sSkinCluster = 'skinCluster__%s__TWEAKERS' % sBody
    if not cmds.objExists(sSkinCluster):
        deformers.skinMesh(sBody, sName='skinCluster__%s__TWEAKERS' % sBody,
                           sInfluences=['jnt_m_faceZero'] + sJoints,
                           bAlwaysAddDefaultWeights=True)
    else:
        print('adding influences: ', sJoints)
        deformers.addInfluences(sSkinCluster, sJoints)


kTweakerLidsBpGroupName = '_grp_m_eyesBpTWEAKER'


dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_tweakerLids', kTweakerLidsBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['create Right Curve and Locators'] = lambda: createBothBpCurves('bpCurve_r_tweakerLids', kTweakerLidsBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['create Right Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerLids*')
dButtons['- Export Eyelid Tweaker BPs -'] = lambda: exportBps('faceBlueprintsTweakerLids.ma', kTweakerLidsBpGroupName)



# to do: check that disabled live rotation setup
@builderTools.addToBuild(iOrder=85.0, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_lids(sAttachMesh=[], fMidPercs=[0.25, 0.5, 0.75], sNames=['inner', 'mid', 'outer'], sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    if len(fMidPercs) != len(sNames):
        raise Exception('fMidPercs and sNames need to have same count (%d -> %d)' % (len(fMidPercs), len(sNames)))

    for sCrv in ['bpCurve_l_tweakerLids', 'bpCurve_r_tweakerLids']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_tweakerLids', 'locB_l_tweakerLids', 'locA_r_tweakerLids', 'locB_r_tweakerLids']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_l_tweakerLids', 'locA_l_tweakerLids', 'locB_l_tweakerLids', 'bpCurve_l_botLid',
                                            'bpCurve_l_topLid'))
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_r_tweakerLids', 'locA_r_tweakerLids', 'locB_r_tweakerLids', 'bpCurve_r_botLid',
                                            'bpCurve_r_topLid'))

    fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccLidCtrls = [[], []]
    sCornerNames = ['cornerIn', 'cornerOut']
    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    sssCtrlJoints = [[], []], [[], []]
    for s, sSide in enumerate(['l', 'r']):

        # bottom tops
        for p,sPart in enumerate(['bot','top']):
            fCtrlParams = curves.getParamsFromPercs(ssCurves[s][p], fMidPercs)
            aTangents = curves.getTangentsFromParams(ssCurves[s][p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(ssCurves[s][p], fCtrlParams)
            for c, fP, sN in zip(range(len(fCtrlParams)), fCtrlParams, sNames):
                sName = 'eyelid%s%s' % (utils.getFirstLetterUpperCase(sN), utils.getFirstLetterUpperCase(sPart))

                cC = ctrls8.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, fSliderScale=fSliderScale,
                                  sAttrs=['t','r','s'], fSize=0.1, sShape='cube', fMatchPos=aCtrlPoints[c])
                cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

                xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangents[c], fAimVector=[0,0,-1], fUpVector=[1,0,0] )
                cC.sSurfaceInfoNode = None

                cccBotTopCtrls[s][p].append(cC)
                ccLidCtrls[s].append(cC)

        # corners
        fCtrlParams = curves.getParamsFromPercs(ssCurves[s][0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(ssCurves[s][0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, sCornerNames):
            sName = 'eyelid%s' % (utils.getFirstLetterUpperCase(sN))

            cC = ctrls8.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, sMatch='jnt_%s_eyeMain' % sSide,
                              sAttrs=['t','r'], fSize=0.1, sShape='cube', fMatchPos=aCtrlPoints[c], fSliderScale=fSliderScale)

            if c == 0:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -1], fUpVector=[1, 0, 0])
            cC.sSurfaceInfoNode = None

            ccCornerCtrls[s].append(cC)
            ccLidCtrls[s].append(cC)

        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, ctrls8.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s]).sCtrl, parent=True)


        sEyePoint = nodes.getWorldPoint(sEyeJoints[s])
        for c,cC in enumerate(ccLidCtrls[s]):
            cC.sJ = 'jnt_%s_tweakerLids_%s' % (sSide, cC.sName)
            sssCtrlJoints[s][p].append(cC.sJ)
            if cmds.objExists(cC.sJ):
                xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
                xforms.resetTransform(cC.sJ, jo=True)
            else:
                cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

            utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

            cmds.setAttr('%s.radius' % cC.sJ, 0.1)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJ)


            sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
            sDecomposeMatrix = nodes.createDecomposeMatrix('%s.worldMatrix' % sCtrlParent, bReturnRotate=True)
            sNoRotMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(cC.sCtrl),
                                                         xRotate=sDecomposeMatrix,
                                                         xScale='%s.outputScale' % sDecomposeMatrix.split('.')[0])
            sInverseNoRotMatrix = nodes.createInverseMatrix(sNoRotMatrix)

            sAimTargetLocal = nodes.createPointByMatrixNode(sEyePoint, sInverseNoRotMatrix)
            nodes.createSimpleAimConstraint2(sAimTargetLocal, cC.sOut, bRotateUp=False, xAimVector=[0, 0, -1], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
            sLocalCtrlPlane = ['%s.tx' % cC.sCtrl, '%s.ty' % cC.sCtrl, 0]
            sDistanceInsidePlane = nodes.createDistanceNode([0,0,0], sLocalCtrlPlane)
            sCtrlPlane = nodes.createPointByMatrixNode(sLocalCtrlPlane, '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0])
            sDiff = nodes.createVectorAdditionNode([sCtrlPlane, sEyePoint], sOperation='minus')
            sDistance = nodes.createDistanceNode([0,0,0], sDiff)
            sNormDiff = nodes.createVectorMultiplyNode(sDiff, sDistance, sOperation='divide', bVectorByScalar=True)

            sAutoPushAttr = utils.addAttr(cC.sCtrl, ln='autoPushOut', k=True, dv=2)
            sAutoPush = nodes.createMultiplyNode(sDistanceInsidePlane, sAutoPushAttr)
            sPushOutDistance = nodes.createAdditionNode([cmds.getAttr(sDistance), '%s.tz' % cC.sCtrl, sAutoPush])
            sScaledDiff = nodes.createVectorMultiplyNode(sNormDiff, sPushOutDistance, bVectorByScalar=True)
            sWorldPos = nodes.createVectorAdditionNode([sEyePoint, sScaledDiff])

            sCtrlPlaneMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalCtrlPlane),
                                                           '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0]])
            sInvCtrlPlaneMatrix = nodes.createInverseMatrix(sCtrlPlaneMatrix)
            nodes.createPointByMatrixNode(sWorldPos, sInvCtrlPlaneMatrix, sTarget='%s.t' % cC.sOut)



    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr(utils.flattenedList(sssCtrlJoints))

    for cC in ccLidCtrls[0]+ccLidCtrls[1]:
        sAttachDeformers = [sD for sD in ctrls8.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls8.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers,
                                                 bRotate=False if 'CORNER' in cC.sCtrl.upper() else True)

    utils.data.addToList('sAllTweakerCtrlsForUnreal', [cC.sCtrl for cC in ccLidCtrls[0]+ccLidCtrls[1]])






kMouthPostBpGroupName = '_grp_m_mouthBpsTweakers'


dButtons = OrderedDict()
dButtons['Create Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_tweakerLips', kMouthPostBpGroupName, fDirection=(-1, 0, 0))
dButtons['Attach Joints to Selected'] = lambda: bindTweakers('jnt_?_tweakerLips*')
# dButtons['Add Bind Corner Rot (do the normal bind first and then open mouth and select mesh)'] = bindCornerRotPostLips
dButtons['- Export Lips Tweaker BPs -'] = lambda: exportBps('faceBlueprintsMouthTweakers.ma', kMouthPostBpGroupName)



@builderTools.addToBuild(iOrder=85.2, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_lips(fHalfPercs=[0.0, 0.25, 0.5], bFlipInnerBpCurves=False, sUpAxisGuideTransform='mouth_ctrl', iUpAxis=1):

    # if sAttachMesh:
    #     sAttachMesh = utils.toList(sAttachMesh)[0]
    # else:
    #     raise Exception('no attachmesh given')

    sUpAxisGuideTransform = utils.toList(sUpAxisGuideTransform)[0]
    sPostCtrls = cmds.createNode('transform', n='grp_lipsTweakerCtrls', p='ctrls')
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    sBpCurves = ['bpCurve_m_%sTweakerLips' % sPart for sPart in ['bot', 'top']]
    if bFlipInnerBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs('bpCurve_m_tweakerLips', 'locA_m_tweakerLips', 'locB_m_tweakerLips', sBpCurves[1], sBpCurves[0])
    else:
        curves.separateCurveUsingSeparationLocs('bpCurve_m_tweakerLips', 'locA_m_tweakerLips', 'locB_m_tweakerLips', sBpCurves[0], sBpCurves[1])

    aHalfPercs = np.array(fHalfPercs, dtype='float64')
    aCtrlPercs = np.concatenate([aHalfPercs, 1.0-aHalfPercs[::-1][1:]])
    iCtrlCount = len(aCtrlPercs)
    report.report.addLogText('Params: %s' % list(aCtrlPercs))
    aSides, aInds = utils.convertMiddleSequenceToSides(iCtrlCount)

    aaPoints = []

    for p,sPart in enumerate(['bot','top']):
        aPoints = curves.getPointsFromPercs(sBpCurves[p], aCtrlPercs, bReturnNumpy=True)
        if True:
            pBpCurve = patch.patchFromName(sBpCurves[p])
            aBpPoints = pBpCurve.getPoints()
            iPoints = xforms.findClosestPoints(aPoints, aBpPoints)
            aPoints = aBpPoints[iPoints]

        aaPoints.append(aPoints)

    fCurveEndsDistance = barycentric.distanceBetween('%s.cv[0]' % sBpCurves[0], '%s.cv[%d]' % (sBpCurves[0], len(cmds.ls('%s.cv[*]' % sBpCurves[0], flatten=True))-1)) * 0.5
    fSliderScale = fCurveEndsDistance * 0.25

    dCommonFlags = {'sShape': 'cube', 'fSize': 1, 'sAttrs':['t','r','s'],
                    'sParent': sPostCtrls, 'iColorIndex': 2, 'fSliderScale':fSliderScale}

    cCorners = [ctrls8.create(sName='tweakerLipsCorner', sSide='l', fMatchPos=aaPoints[0][0], **dCommonFlags),
                ctrls8.create(sName='tweakerLipsCorner', sSide='r', fMatchPos=aaPoints[0][-1], **dCommonFlags)]

    ccCtrls = [], []

    for p,sPart in enumerate(['bot','top']):
        for i in range(iCtrlCount):
            if i in [0,iCtrlCount-1]:
                continue
            cC = ctrls8.create(sName='tweakerLips%s' % utils.getFirstLetterUpperCase(sPart), iIndex=aInds[i], sSide=aSides[i],
                               fMatchPos=aaPoints[p][i], **dCommonFlags)
            ccCtrls[p].append(cC)


    if not cmds.objExists(sUpAxisGuideTransform):
        raise Exception('"%s" doesn\'t exist, set a different sUpAxisGuideTransform value' % sUpAxisGuideTransform)

    aLocalUp = utils.getNumpyMatrixFromTransform(sUpAxisGuideTransform)[iUpAxis,0:3]


    # orient the controls
    for i in range(iCtrlCount):

        fSideMultipl = -1.0 if aSides[i] == 'r' else 1.0
        if i in [0, iCtrlCount-1]:
            if i == 0:
                aLocalAim = (aaPoints[0][1]+aaPoints[1][1]) * 0.5 - aaPoints[0][0]
                xforms.orientThreePoints(cCorners[0].sPasser, aLocalAim, aLocalUp, fAimVector=[-1,0,0], fUpVector=[0,1,0])
            else:
                aLocalAim = (aaPoints[0][-2]+aaPoints[1][-2]) * 0.5 - aaPoints[0][-1]
                xforms.orientThreePoints(cCorners[1].sPasser, aLocalAim, aLocalUp, fAimVector=[1,0,0], fUpVector=[0,-1,0])
        else:
            c = i - 1
            for p,sPart in enumerate(['bot','top']):
                aLocalAim = ((aaPoints[p][i-1]-aaPoints[p][i]) - (aaPoints[p][i+1]-aaPoints[p][i]))
                xforms.orientThreePoints(ccCtrls[p][c].sPasser, aLocalAim, aLocalUp, fAimVector=[1, 0, 0], fUpVector=[0, fSideMultipl, 0])


    cAllLipCtrls = cCorners + ccCtrls[0] + ccCtrls[1]
    for c,cC in enumerate(cAllLipCtrls):
        cC.sJ = 'jnt_%s_tweakerLips_%s' % (cC.sSide, cC.sName.replace('tweaker',''))
        if cC.iIndex != None:
            cC.sJ = '%s_%03d' % (cC.sJ, cC.iIndex)

        if cmds.objExists(cC.sJ):
            xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
            xforms.resetTransform(cC.sJ, jo=True)
        else:
            cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

        cmds.setAttr('%s.v' % cC.sJ, False)
        cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

        utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr([cC.sJ for cC in cAllLipCtrls])

    for cC in cAllLipCtrls:
        sAttachDeformers = [sD for sD in ctrls8.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls8.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers,
                                                 bRotate=False if 'CORNER' in cC.sCtrl.upper() else True)

    utils.data.addToList('sAllTweakerCtrlsForUnreal', [cC.sCtrl for cC in cAllLipCtrls])





kTweakerSocketsBpGroupName = '_grp_m_tweakerSocketsBp'


dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_tweakerSockets', kTweakerSocketsBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['create Right Curve and Locators'] = lambda: createBothBpCurves('bpCurve_r_tweakerSockets', kTweakerSocketsBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['create Right Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerSocket*')
dButtons['Select Influences'] = lambda:cmds.select(cmds.ls('jnt_?_tweakerSocket*', et='joint'))
# dButtons['Add Tangent Influences to Selected'] = bindEyelidCornerRotPostLips
dButtons['- Export Tweaker Sockets BPs -'] = lambda: exportBps('faceBlueprintsTweakerSockets.ma', kTweakerSocketsBpGroupName)



# to do: check that disabled live rotation setup
@builderTools.addToBuild(iOrder=85.1, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_sockets(sAttachMesh=[], fMidPercs=[0.25, 0.5, 0.75], sNames=['inner', 'mid', 'outer'], sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    if len(fMidPercs) != len(sNames):
        raise Exception('fMidPercs and sNames need to have same count (%d -> %d)' % (len(fMidPercs), len(sNames)))

    for sCrv in ['bpCurve_l_tweakerSockets', 'bpCurve_r_tweakerSockets']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_tweakerSockets', 'locB_l_tweakerSockets', 'locA_r_tweakerSockets', 'locB_r_tweakerSockets']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_l_tweakerSockets', 'locA_l_tweakerSockets', 'locB_l_tweakerSockets', 'bpCurve_l_botLid',
                                            'bpCurve_l_topLid'))
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_r_tweakerSockets', 'locA_r_tweakerSockets', 'locB_r_tweakerSockets', 'bpCurve_r_botLid',
                                            'bpCurve_r_topLid'))

    fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccSocketsCtrls = [[], []]
    sCornerNames = ['cornerIn', 'cornerOut']
    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    sssCtrlJoints = [[], []], [[], []]
    for s, sSide in enumerate(['l', 'r']):

        aEyeJointMatrix = utils.getNumpyMatrixFromTransform(sEyeJoints[s])
        for p,sPart in enumerate(['bot','top']):
            fCtrlParams = curves.getParamsFromPercs(ssCurves[s][p], fMidPercs)
            aTangents = curves.getTangentsFromParams(ssCurves[s][p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(ssCurves[s][p], fCtrlParams)
            for c, fP, sN in zip(range(len(fCtrlParams)), fCtrlParams, sNames):
                sName = 'tweakerSocket%s%s' % (utils.getFirstLetterUpperCase(sN), utils.getFirstLetterUpperCase(sPart))

                cC = ctrls8.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, fSliderScale=fSliderScale,
                                  sAttrs=['t','r','s'], fSize=0.1, sShape='sphere', fMatchPos=aCtrlPoints[c])
                cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

                xforms.orientThreePoints(cC.sPasser, aEyeJointMatrix[1,0:3], aTangents[c], fAimVector=[0,1,0], fUpVector=[1,0,0] )
                cC.sSurfaceInfoNode = None

                cccBotTopCtrls[s][p].append(cC)
                ccSocketsCtrls[s].append(cC)

        # corners
        fCtrlParams = curves.getParamsFromPercs(ssCurves[s][0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(ssCurves[s][0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, sCornerNames):
            sName = 'tweakerSocket%s' % (utils.getFirstLetterUpperCase(sN))

            cC = ctrls8.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, sMatch='jnt_%s_eyeMain' % sSide,
                              sAttrs=['t','r'], fSize=0.1, sShape='sphere', fMatchPos=aCtrlPoints[c], fSliderScale=1.0)

            if c == 0:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            cmds.delete(cmds.orientConstraint(sEyeJoints[s], cC.sPasser))
            # xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -1], fUpVector=[1, 0, 0])
            cC.sSurfaceInfoNode = None

            ccCornerCtrls[s].append(cC)
            ccSocketsCtrls[s].append(cC)

        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, ctrls8.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s]).sCtrl, parent=True)


        sEyePoint = nodes.getWorldPoint(sEyeJoints[s])
        for c,cC in enumerate(ccSocketsCtrls[s]):
            cC.sJ = 'jnt_%s_%s' % (sSide, cC.sName)
            sssCtrlJoints[s][p].append(cC.sJ)
            if cmds.objExists(cC.sJ):
                xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
                xforms.resetTransform(cC.sJ, jo=True)
            else:
                cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

            utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

            cmds.setAttr('%s.radius' % cC.sJ, fSliderScale * 0.005)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJ)


            sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
            sDecomposeMatrix = nodes.createDecomposeMatrix('%s.worldMatrix' % sCtrlParent, bReturnRotate=True)
            sNoRotMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(cC.sCtrl),
                                                         xRotate=sDecomposeMatrix,
                                                         xScale='%s.outputScale' % sDecomposeMatrix.split('.')[0])
            sInverseNoRotMatrix = nodes.createInverseMatrix(sNoRotMatrix)

            sAimTargetLocal = nodes.createPointByMatrixNode(sEyePoint, sInverseNoRotMatrix)
            nodes.createSimpleAimConstraint2(sAimTargetLocal, cC.sOut, bRotateUp=False, xAimVector=[0, 0, -1], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
            sLocalCtrlPlane = ['%s.tx' % cC.sCtrl, '%s.ty' % cC.sCtrl, 0]
            sDistanceInsidePlane = nodes.createDistanceNode([0,0,0], sLocalCtrlPlane)
            sCtrlPlane = nodes.createPointByMatrixNode(sLocalCtrlPlane, '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0])
            sDiff = nodes.createVectorAdditionNode([sCtrlPlane, sEyePoint], sOperation='minus')
            sDistance = nodes.createDistanceNode([0,0,0], sDiff)
            sNormDiff = nodes.createVectorMultiplyNode(sDiff, sDistance, sOperation='divide', bVectorByScalar=True)

            sAutoPushAttr = utils.addAttr(cC.sCtrl, ln='autoPushOut', k=True, dv=2)
            sAutoPush = nodes.createMultiplyNode(sDistanceInsidePlane, sAutoPushAttr)
            sPushOutDistance = nodes.createAdditionNode([cmds.getAttr(sDistance), '%s.tz' % cC.sCtrl, sAutoPush])
            sScaledDiff = nodes.createVectorMultiplyNode(sNormDiff, sPushOutDistance, bVectorByScalar=True)
            sWorldPos = nodes.createVectorAdditionNode([sEyePoint, sScaledDiff])

            sCtrlPlaneMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalCtrlPlane),
                                                           '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0]])
            sInvCtrlPlaneMatrix = nodes.createInverseMatrix(sCtrlPlaneMatrix)
            nodes.createPointByMatrixNode(sWorldPos, sInvCtrlPlaneMatrix, sTarget='%s.t' % cC.sOut)


    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr(utils.flattenedList(sssCtrlJoints))

    for cC in ccSocketsCtrls[0]+ccSocketsCtrls[1]:
        sAttachDeformers = [sD for sD in ctrls8.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls8.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers,
                                                 bRotate=False if 'CORNER' in cC.sCtrl.upper() else True)

    utils.data.addToList('sAllTweakerCtrlsForUnreal', [cC.sCtrl for cC in ccSocketsCtrls[0]+ccSocketsCtrls[1]])



kTweakerBrowsSplinesBpGroupName = '_grp_m_tweakerBrowsSplinesBpMain'

def tweakerBrowOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_tweakerBrowsSplines', [0, 0.5, 1])
    sNames = ['A', 'B', 'C']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sMainBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls8.createSimpleCurve('matrixNames', sName='bpLoc_l_tweakerBrowsSplinesOrientation%s' % sNames[i], sParent=kTweakerBrowsSplinesBpGroupName)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)



kTweakerBrowsSimpleBpGroupName = '_grp_m_tweakerBrowsSimpleBpMain'

def tweakerBrowOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_tweakerBrowsSimple', [0, 0.5, 1])
    sNames = ['A', 'B', 'C']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sMainBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls8.createSimpleCurve('matrixNames', sName='bpLoc_l_tweakerBrowsSimpleOrientation%s' % sNames[i], sParent=kTweakerBrowsSimpleBpGroupName)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)


dSelectSiblingsMenu = {}
dSelectSiblingsMenu['all'] = lambda: cmds.select(cmds.ls('grp_l_tweakerBrowsSimple*_*Sibling*', et='transform'))


dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_tweakerBrowsSimple', kTweakerBrowsSimpleBpGroupName, fDirection=(1, 0, 0))
dButtons['Create Left Brow Orientation Locators'] = tweakerBrowOrientationLocators
dButtons['=== SELECT LEFT SIBLINGS ==='] = dSelectSiblingsMenu
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsTweakerBrowsSimple', 'dDefaultSettingValuesTweakerBrowsSimple')

dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerBrowsSimple*')

dButtons['- Export Tweaker brows Simple BPs -'] = lambda: exportBps('faceBlueprintsTweakerBrowsSimple.ma', kTweakerBrowsSimpleBpGroupName)


@builderTools.addToBuild(iOrder=85.4, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_browsSimple(sAttachMesh='', sVisAttrCtr='head_ctrl', sParentJoint='jnt_m_headMain', dDefaultSettingValuesBrows={}):
    sDefaultSettingAttrsBrows = []
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    sCtrlVis = utils.addOffOnAttr(utils.toList(sVisAttrCtr)[0], 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)


    sBpCurves = ['bpCurve_%s_tweakerBrowsSimple' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleBrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv)

    aaCurvePoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                     curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aaCtrlPoints = [[aaCurvePoints[0][0], aaCurvePoints[0][3], aaCurvePoints[0][6]],
                    [aaCurvePoints[1][0], aaCurvePoints[1][3], aaCurvePoints[1][6]]]

    # collect orients
    ssBpOrients = []
    for s, sSide in enumerate(['l', 'r']):
        sBpOrients = []
        for sName in ['A', 'B', 'C']:
            sBpOrient = 'bpLoc_%s_tweakerBrowsSimpleOrientation%s' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_tweakerBrowsSimpleOrientation%s' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    xforms.mirrorCurveTransforms(sLeftBpOrient)
            sBpOrients.append(sBpOrient)
        ssBpOrients.append(sBpOrients)

    # make up curves
    ccCtrls = [], []
    ssJoints = [], []
    for s, sSide in enumerate(['l', 'r']):

        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ctrls8.create(sName='tweakerBrow%s' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(),
                               fMatchPos=aaCtrlPoints[s][c], sShape='cube', fSliderScale=fSliderScale,
                               sAttrs=['t', 'r', 'sy', 'sz'], fSize=0.25)
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            ccCtrls[s].append(cC)

            sBpOrient = 'bpLoc_%s_tweakerBrowsSimpleOrientation%s' % (sSide, sName)
            if cmds.objExists(sBpOrient):
                cmds.delete(cmds.orientConstraint(sBpOrient, cC.sPasser))

            sJ = 'jnt_%s_tweakerBrowsSimple_%s' % (sSide, sName)
            if cmds.objExists(sJ):
                cmds.parent(sJ, cC.sOut)
                xforms.resetJoint(sJ)
                cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.25)
            else:
                sJ = xforms.createJoint(sJ, fSize=fSliderScale * 0.25, sParent=cC.sOut)

            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
            # constraints.matrixParentConstraint(cC.sOut, sJ)

            sRefJ = xforms.createJoint('jnt_%s_tweakerBrowsSimple_%s_ref' % (sSide, sName), fSize=fSliderScale * 0.33, sParent=cC.sPasser)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            xforms.matchXform(sJ, sRefJ)

            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJ)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sRefJ)


            ssJoints[s].append(sJ)

    deformers.connectJointReferencesFromAttr(utils.flattenedList(ssJoints))

    for cC in utils.flattenedList(ccCtrls):
        cC.setDefaultAttrDict()
        sAttachDeformers = [sD for sD in ctrls8.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls8.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers, bRotate=True)





def proceduralBind_zipper(iBindLipRows, fBindMultipls):
    _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='Zipper', sSkinClusterSuffix='ZIPPER')

dButtons = {}
dButtons['bind selected'] = proceduralBind_zipper



@builderTools.addToBuild(iOrder=84, dButtons=dButtons, bDisableByDefault=True)
def postZipper(sMesh=None, sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain', sLipPressMesh=None, sClosedMesh=None, iBindLipRows=[3,3], fBindMultipls=[1.0,1.0,1.0], fOvershoot=0.05):

    sMesh = utils.objFromArg(sMesh)

    if utils.data.get('bMouthJointType', sNode=utils.kFaceDataNode, xDefault=False) == True:
        report.report.addLogText('skipping because mouth rig has joint setup')
        return

    sZipperGrpOrigin = cmds.createNode('transform', n='grp_zipperOrigin') #, p=getFaceGrp())
    # fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode)
    sZipperGrpWorld = cmds.createNode('transform', n='grp_zipperWorld') #, p=getFaceGrp())
    constraints.matrixParentConstraint(sParentJoint, sZipperGrpWorld)


    # zipper
    cCornerCtrls = [ctrls8.ctrlFromName('lipsCorner_l_ctrl'), ctrls8.ctrlFromName('lipsCorner_r_ctrl')]
    sZipperLeft = utils.addAttr(cCornerCtrls[0].sCtrl, ln='zipper', at='double',  defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
    sZipperRight = utils.addAttr(cCornerCtrls[1].sCtrl, ln='zipper', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)

    sZipperFadeLengthLeft = utils.addAttr(cCornerCtrls[0].sCtrl, ln='zipperFade', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
    sZipperFadeLengthRight = utils.addAttr(cCornerCtrls[1].sCtrl, ln='zipperFade', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)

    sZipperLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sZipperLeft, sZipperFadeLengthLeft), sName='left_zipperByFade')
    sZipperRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sZipperRight, sZipperFadeLengthRight), sName='right_zipperByFade')

    sBpCurvesA = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]

    sZipperCurves = [cmds.duplicate(sBpCurvesA[0], n='crv_m_botZipper')[0], cmds.duplicate(sBpCurvesA[1], n='crv_m_topZipper')[0]]
    cmds.parent(sZipperCurves, sZipperGrpOrigin)

    pMesh = patch.patchFromName(sMesh)
    aMeshPoints = pMesh.getPoints()
    aClosedMeshPoints = aMeshPoints if not sClosedMesh else patch.patchFromName(sClosedMesh).getPoints()

    aHeadMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sParentJoint), dtype='float64').reshape(4,4)
    aHeadMatrixInverse = np.linalg.inv(aHeadMatrix)

    aClosedMeshPointsLocal = np.dot(utils.makePoint4Array(aClosedMeshPoints), aHeadMatrixInverse)[:,0:3]
    if sLipPressMesh:
        aLipPressMeshPoints = patch.patchFromName(sLipPressMesh).getPoints()
        aLipPressPointsLocal = np.dot(utils.makePoint4Array(aLipPressMeshPoints), aHeadMatrixInverse)[:,0:3]


    ssJoints = [], []
    ssRefJoints = [], []
    aaPoints = [None, None]
    for p,sPart in enumerate(['bot','top']):
        aAllPartPoints = np.array(cmds.xform('%s.cv[*]' % sZipperCurves[p], q=True, t=True, ws=True), dtype='float64').reshape(-1,3)
        if p == 0:
            aaPoints[p] = aAllPartPoints
        else:
            aaPoints[p] = aAllPartPoints[1:-1]

        aSides, aInds = utils.convertMiddleSequenceToSides(len(aaPoints[p]))
        for j,aPoint in enumerate(aaPoints[p]):
            sRefJ = cmds.createNode('joint', n='jnt_%s_%sRefZipper_%03d' % (aSides[j], sPart, aInds[j]), p=sZipperGrpWorld)
            sJ = 'jnt_%s_%sZipper_%03d' % (aSides[j], sPart, aInds[j])
            if not cmds.objExists(sJ):
                sJ = cmds.createNode('joint', n=sJ, p=sZipperGrpWorld)
            else:
                cmds.parent(sJ, sZipperGrpWorld)
            utils.matchJointRadius(sJ, 'jnt_m_headMain', 0.2)
            utils.matchJointRadius(sRefJ, 'jnt_m_headMain', 0.5)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            ssJoints[p].append(sJ)
            ssRefJoints[p].append(sRefJ)
            cmds.setAttr('%s.v' % sRefJ, False)

    aaClosestIds = [xforms.findClosestPoints(aaPoints[0], aMeshPoints),
                    xforms.findClosestPoints(aaPoints[1], aMeshPoints)]

    aClosestIds = np.concatenate([aaClosestIds[0], aaClosestIds[1]])
    cmds.select(ssJoints[0], ssJoints[1])

    sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh
    if cmds.objExists(sSkinCluster):
        cmds.setAttr('%s.envelope' % sSkinCluster, 0.0)

    sLocs = constraints.parallelTransformAsDeformers2(sMesh, aClosestIds, sParent=sZipperGrpOrigin,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint,
                                                     sDeformers=['blendShape__%s' % sMesh, 'skinCluster__%s' % sMesh])
    [cmds.setAttr('%s.localScale' % sL, 0.02, 0.02, 0.02) for sL in sLocs]

    ssLocs = sLocs[:len(aaPoints[0])], sLocs[len(aaPoints[0]):]
    for p,sPart in enumerate(['bot','top']):
        for j,sJ  in enumerate(ssJoints[p]):
            cmds.pointConstraint(ssLocs[p][j], ssRefJoints[p][j])
            cmds.delete(cmds.pointConstraint(ssLocs[p][j], ssJoints[p][j]))


    cmds.skinCluster(sZipperCurves[0], ssRefJoints[0], tsb=True)
    cmds.skinCluster(sZipperCurves[1], ssRefJoints[1], tsb=True)

    ffOppositeParams = []
    ffOppositeParams.append(curves.getParamsFromPoints(sZipperCurves[1], aaPoints[0]))
    ffOppositeParams.append(curves.getParamsFromPoints(sZipperCurves[0], aaPoints[1]))


    if sLipPressMesh:
        sLipPressAttr = utils.addAttr('mouth_ctrl', ln='lipPress', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True, bReturnIfExists=True)
    else:
        sLipPressAttr = 0.0

    sOverShoot = utils.addAttr('grp_m_mouthPasser', ln='zipperOverShoot', k=True, dv=fOvershoot)

    for p,sPart in enumerate(['bot','top']):
        aSides, aInds = utils.convertMiddleSequenceToSides(len(aaPoints[p]))

        fLeftPercs = utils.bSpline4([0,0,1,1], aValues=np.arange(len(ffOppositeParams[p])) / float(len(ffOppositeParams[p])-1))
        fRightPercs = 1.0 - fLeftPercs
        sPositionAdditions = []
        sAllLeftRightZippersClamped = []
        sBlendPlusOvershoot = nodes.createAdditionNode([0.5, sOverShoot])
        for j,sJ in enumerate(ssJoints[p]):
            cmds.setAttr('%s.jo' % sJ, 0,0,0)
            cmds.setAttr('%s.jo' % sRefJ, 0,0,0)

            deformers.connectRefsOnCurrentSkinClusters(sJ)
            sLeftRightZippers = cmds.createNode('plusMinusAverage', n='plus_%s_sumZippers_%03d' % (aSides[j], aInds[j]))

            sEndLeft = nodes.createAdditionNode([fLeftPercs[j], sZipperFadeLengthLeft],
                                          sName='%s_left_zipperFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeLeft = nodes.createRangeNode(sZipperLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0,
                                               sName='%s_left_zipper_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

            sEndRight = nodes.createAdditionNode([fRightPercs[j], sZipperFadeLengthRight], sName='%s_right_zipperFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeRight = nodes.createRangeNode(sZipperRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='%s_right_zipper_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

            sAllClose = nodes.createAdditionNode(['%s.output1D' % sLeftRightZippers, sLipPressAttr])
            sAllCloseClamped = nodes.createClampNode(sAllClose, 0, 1)

            _, sPosOnNode = curves.createPointInfoNode(sZipperCurves[0 if p == 1 else 1], fParam=ffOppositeParams[p][j], sName='%sZipper_%03d' % (sPart, j))
            sPosOnNodeLocal = nodes.createPointByMatrixNode(sPosOnNode, '%s.worldInverseMatrix' % sParentJoint)
            sPosOnNodeBlend = nodes.createBlendNode(sBlendPlusOvershoot, sPosOnNodeLocal, '%s.t' % ssRefJoints[p][j], bVector=True)

            sNewOffset = nodes.createVectorAdditionNode([sPosOnNodeBlend, '%s.t' % ssRefJoints[p][j]], sOperation='minus')

            sOffsetMultipls = []
            sOffsetMultipls.append(nodes.createVectorMultiplyNode(sNewOffset, sAllCloseClamped, bVectorByScalar=True))
            sAdd = nodes.createVectorAdditionNode(['%s.t' % ssRefJoints[p][j]] + sOffsetMultipls, '%s.t' % ssJoints[p][j])
            sPositionAdditions.append(sAdd.split('.')[0])
            sAllLeftRightZippersClamped.append(sAllCloseClamped)

        cCornerCtrl = ctrls8.ctrlFromName('lipsCorner_l_ctrl')
        cmds.setAttr('%s.zipper' % cCornerCtrl.sCtrl, 1.0)
        for j,sJ in enumerate(ssJoints[p]):
            aPos = np.array(cmds.getAttr('%s.t' % ssJoints[p][j])[0], dtype='float64')
            aOffset = aClosedMeshPointsLocal[aaClosestIds[p][j]] - aPos
            sMult = nodes.createVectorMultiplyNode(aOffset, sAllLeftRightZippersClamped[j], bVectorByScalar=True)
            cmds.connectAttr(sMult, '%s.input3D[2]' % sPositionAdditions[j])
        cmds.setAttr('%s.zipper' % cCornerCtrl.sCtrl, 0.0)

        if sLipPressMesh:
            cmds.setAttr(sLipPressAttr, 1.0)
            for j,sJ in enumerate(ssJoints[p]):
                aPos = np.array(cmds.getAttr('%s.t' % ssJoints[p][j])[0], dtype='float64')
                aOffset = aLipPressPointsLocal[aaClosestIds[p][j]] - aPos
                sDiff = nodes.createAdditionNode([sLipPressAttr, sAllLeftRightZippersClamped[j]], sOperation='minus')
                sDiff = nodes.createClampNode(sDiff, 0, 1)
                sMult = nodes.createVectorMultiplyNode(aOffset, sDiff, bVectorByScalar=True)
                cmds.connectAttr(sMult, '%s.input3D[3]' % sPositionAdditions[j])
            cmds.setAttr(sLipPressAttr, 0.0)


    createOrFixFaceZero()


    sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh

    # fix skinCluster if it's already there from loadDeformers
    if cmds.objExists(sSkinCluster):
        sJoints = cmds.ls('jnt_?_???Zipper_???', et='joint')
        if cmds.objExists(sSkinCluster):
            cmds.setAttr('%s.envelope' % sSkinCluster, True)

        for j, sJoint in enumerate(sJoints):
            sRefJoint = sJoint.replace('Zipper', 'RefZipper')
            if not cmds.objExists(sRefJoint):
                continue

            sMatrixConnections = cmds.listConnections('%s.worldMatrix' % sJoint, p=True, t='skinCluster', s=False,
                                                      d=True)
            if not sMatrixConnections:
                continue
            sMatrixConnections = [sC for sC in sMatrixConnections if sC.startswith(sSkinCluster)]
            if not sMatrixConnections:
                continue

            iIndex = utils.indexFromName(sMatrixConnections[0])
            cmds.connectAttr('%s.worldInverseMatrix' % sRefJoint, '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex),
                             f=True)


    if sLipPressMesh:
        # sModels = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)
        # sSecondaryModels = [] if len(sModels) <= 1 else sModels[1:]
        connectTargets(sMesh, sLipPressMesh, dPoses={sLipPressAttr: 1.0}, bMirror=False, iInvert=2)

    cmds.parent(sZipperGrpOrigin, sZipperGrpWorld, 'modules')





@builderTools.addToBuild(iOrder=84.5, bDisableByDefault=True)
def blendShapifyPostZipper(iSampleCount=8, fJawRotationZ=-15):

    sMirrorJointAxes = utils.data.get('sMirrorJointAxes', xDefault=[]) #, xDefault=[])

    sSuffixes = utils.data.get('sImportedHeadSuffixes')
    bReturn = None
    sBpCurvesA = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]
    utils.data.store('dZipper', {'iSampleCount': iSampleCount, 'sCurve': sBpCurvesA[0]})
    createOrGetBakedZipperSetup()


    addTargetData('zipper',
                  dPoses={},
                  dDrivers={},
                  bMirror=False,
                  bSplitBotTop=False,
                  iInvert=2,
                  fSplitRadius=1.0,
                  dSplitAlongCurve={},
                  bZipper=True,
                  iBrowSplinesSplit=0,
                  ffLidRanges=[],
                  bControlRigCommands=True)


    addTargetData('jawOpenZipper',
                  dPoses={'jaw_ctrl.rz':fJawRotationZ},
                  dDrivers={},
                  bMirror=False,
                  bSplitBotTop=False,
                  iInvert=0,
                  fSplitRadius=1.0,
                  dSplitAlongCurve={},
                  bZipper=True,
                  iBrowSplinesSplit=0,
                  ffLidRanges=[],
                  bControlRigCommands=True)


    bDeletePrevSetup = True
    def _getZipperComboName(sTargets):
        sTargets = utils.toList(sTargets)
        sAllTargets = sorted(sTargets)
        return '_'.join(sAllTargets + ['zipper'])


    # xMirrorAxis = sMirrorJointAxes[suf] if suf < len(sMirrorJointAxes) else None
    sSuffix = ''
    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sSecondaryModels = utils.data.get('sAllSecondaryModels%s' % sSuffix)

    dTargets = OrderedDict()
    dTargets[_getZipperComboName('jawOpenZipper')] = {'jaw_ctrl.rz':fJawRotationZ}
    dTargets[_getZipperComboName('lowerDown')] = {'lipsBotA_l_ctrl.ty':-1.0}
    dTargets[_getZipperComboName('upperUp')] = {'lipsTopA_l_ctrl.ty':1.0}
    dTargets[_getZipperComboName('lipStretch')] = {'lipStretch_l_ctrl.ty':1.0}
    dTargets[_getZipperComboName('funnel')] = {'mouth_ctrl.tz':1.0}
    dTargets[_getZipperComboName(['lowerDown', 'upperUp'])] = {'lipsBotA_l_ctrl.ty':-1.0, 'lipsTopA_l_ctrl.ty':1.0}
    for sTarget, dPoses in list(dTargets.items()):
        dTargets[sTarget] = _mirrorAttrsDict(dPoses)

    report.report.resetProgress(len(dTargets))

    for sComboT, dPose in list(dTargets.items()):
        report.report.addLogText('combo shape "%s"..' % sComboT, bRefresh=True, bIncrementProgress=True)
        if not cmds.objExists(sComboT):

            sMainTargets = sComboT.split('_')
            bSkip = False
            for sT in sMainTargets:
                if sT not in ['zipper', 'jawOpenZipper'] and not cmds.objExists(sT):
                    report.report.addLogText('missing main target: "%s"' % sT)
                    bSkip = True
                    # break
            if bSkip:
                continue

            dPrev = {}
            for sA,fV in list(dPose.items()):
                dPrev[sA] = cmds.getAttr(sA)
                cmds.setAttr(sA, fV)

            cmds.setAttr('lipsCorner_l%s_ctrl.zipper' % sSuffix, 1.0)
            cmds.duplicate(sModel, n=sComboT)
            cmds.setAttr('lipsCorner_l%s_ctrl.zipper' % sSuffix, 0.0)

            utils.parentToWorld(sComboT)
            cmds.setAttr('%s.v' % sComboT, False)
            for sA,fV in list(dPrev.items()):
                cmds.setAttr(sA,fV)

        bSuccess, sMessage = autoConnectComboTarget(sComboT, sModel, sSecondaryModels, bLegacyIgnoreEyeLookHoriz=False)

        report.report.addLogText(sMessage)
        if not bSuccess:
            bReturn = False

    if bDeletePrevSetup:
        for sMesh in [sModel] + sSecondaryModels:
            sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh
            if cmds.objExists(sSkinCluster):
                cmds.delete(sSkinCluster)

    cmds.setAttr('lipsCorner_l_ctrl.zipper', 0.0)

    if bDeletePrevSetup:
        for sAttr in ['lipsCorner_l_ctrl.zipper', 'lipsCorner_l_ctrl.zipperFade', 'lipsCorner_r_ctrl.zipper', 'lipsCorner_r_ctrl.zipperFade']:
            cmds.deleteAttr(sAttr)
        cmds.delete('grp_zipperOrigin', 'grp_zipperWorld')

        cmds.renameAttr('lipsCorner_l_ctrl.zipperB', 'zipper')
        cmds.renameAttr('lipsCorner_l_ctrl.zipperFadeB', 'zipperFade')
        cmds.renameAttr('lipsCorner_r_ctrl.zipperB', 'zipper')
        cmds.renameAttr('lipsCorner_r_ctrl.zipperFadeB', 'zipperFade')



    return bReturn


dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls8.exportSliderBps
@builderTools.addToBuild(iOrder=50.01, dButtons=dButtons, bDisableByDefault=True)
def eyeSpecular(ddMeshes={'eyesLookAt_l_ctrl':{'A':[], 'B':[]}}, bMirrorToRight=True, bFirstReversesOthers=False):
    for sCtrl, dData in list(ddMeshes.items()):
        sFirstHoriz = [None, None]
        sFirstVert = [None, None]
        sReverseOthersAttr = [None, None]

        for l, sLetter in enumerate(sorted(list(dData.keys()))):
            sMeshes = dData[sLetter]
            if not sMeshes:
                continue

            sInputCtrlSide = utils.getSide(sCtrl)
            if sInputCtrlSide == 'm':
                sSides = ['m']
                bMirrors = [False]
            elif sInputCtrlSide == 'l':
                if bMirrorToRight:
                    sSides = ['l','r']
                    bMirrors = [False, True]
                else:
                    sSides = ['l']
                    bMirrors = [False]
            elif sInputCtrlSide == 'r':
                sSides = ['r']
                bMirrors = [False]

            for s,sSide in enumerate(sSides):

                fSideMultipl = -1.0 if sSide == 'r' else 1.0

                if bMirrors[s]:
                    sMeshesSide = utils.mirrorList(list(sMeshes))
                    sCtrlSide = utils.getMirrorName(sCtrl)
                else:
                    sMeshesSide = list(sMeshes)
                    sCtrlSide = sCtrl

                sEyeJoint = cmds.getAttr('%s.sEyeJoint' % sCtrlSide)
                sTransformJoint = cmds.listRelatives(sEyeJoint, p=True)[0]

                sSpecParent = 'jnt_%s_specJointParent' % sSide
                if not cmds.objExists(sSpecParent):
                    sSpecParent = xforms.createJoint(sSpecParent, sParent=sTransformJoint)

                    sEyeFollow = utils.addAttr(sCtrlSide, ln='specFollow', minValue=0, maxValue=1, k=True)
                    sSpecTwist = utils.addAttr(sCtrlSide, ln='specTwist', k=True)
                    if sSide == 'r':
                        sSpecTwist = nodes.createMultiplyNode(sSpecTwist, -1)
                    # cmds.connectAttr(sSpecTwist, '%s.rx' % sSpecParent)
                    sBlendMatrix = nodes.createBlendMatrixNode([cmds.getAttr('%s.matrix' % sEyeJoint), '%s.matrix' % sEyeJoint],
                                                               [nodes.createReverseNode(sEyeFollow), sEyeFollow])
                    sParentMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xRotate=[sSpecTwist, 0,0]),
                                                                   sBlendMatrix])
                    nodes.createDecomposeMatrix(sParentMatrix, sTargetRot='%s.r' % sSpecParent)



                    if bFirstReversesOthers:
                        sReverseOthersAttr[s] = utils.addAttr(sCtrlSide, ln='firstReversesOthers', min=0, max=1, dv=1, k=True)

                aaPoints = [patch.patchFromName(sM).getPoints() for sM in sMeshesSide]
                aPoints = np.concatenate(aaPoints)
                aMeshCenter = np.mean(aPoints, axis=0)

                sBaseJoint = xforms.createJoint(sEyeJoint.replace('Main', 'Spec%s' % sLetter), sMatch=sEyeJoint, sParent=sSpecParent)
                sJoint = sEyeJoint.replace('Main', 'SpecEnd%s' % sLetter)
                if not cmds.objExists(sJoint):
                    xforms.createJoint(sJoint, xPos = aMeshCenter)
                else:
                    cmds.setAttr('%s.t' % sJoint, *list(aMeshCenter))

                cmds.delete(cmds.aimConstraint(sJoint, sBaseJoint, wut='objectrotation', wuo=sTransformJoint, aim=[fSideMultipl,0,0]))
                cmds.makeIdentity(sBaseJoint, r=True, apply=True)
                cmds.parent(sJoint, sBaseJoint)
                cmds.setAttr('%s.jo' % sJoint, 0,0,0)
                utils.matchJointRadius([sBaseJoint, sJoint], sEyeJoint, 0.75)
                deformers.resetJointReferences(sJoint)

                for sM in sMeshesSide:
                    if not deformers.listAllDeformers(sM, sFilterTypes=['skinCluster']):
                        cmds.skinCluster(sM, sJoint, tsb=True)

                sSpecVert = utils.addAttr(sCtrlSide, ln='specVert%s' % sLetter, k=True)
                if bFirstReversesOthers:
                    if l == 0:
                        sFirstVert[s] = sSpecVert
                    else:
                        sSpecVert = nodes.createAdditionNode([sSpecVert, nodes.createMultiplyNode(sFirstVert[s], sReverseOthersAttr[s])],
                                                             sOperation='minus', sName='addFirst')
                cmds.connectAttr(sSpecVert, '%s.rz' % sBaseJoint)

                sSpecHoriz = utils.addAttr(sCtrlSide, ln='specHoriz%s' % sLetter, k=True)
                if sSide == 'r':
                    sSpecHoriz = nodes.createMultiplyNode(sSpecHoriz, -1)
                if bFirstReversesOthers:
                    if l == 0:
                        sFirstHoriz[s] = sSpecHoriz
                    else:
                        sSpecHoriz = nodes.createAdditionNode([sSpecHoriz, nodes.createMultiplyNode(sFirstHoriz[s], sReverseOthersAttr[s])],
                                                              sOperation='minus', sName='addFirst')
                cmds.connectAttr(sSpecHoriz, '%s.ry' % sBaseJoint)

                sLiftAttr = utils.addAttr(sCtrlSide, ln='specLift%s' % sLetter, k=True)
                if sSide == 'r':
                    sLiftAttr = nodes.createMultiplyNode(sLiftAttr, -1)
                nodes.createAdditionNode([cmds.getAttr('%s.tx' % sJoint), sLiftAttr], sTarget='%s.tx' % sJoint)

                sScaleAttr = utils.addAttr(sCtrlSide, ln='specScale%s' % sLetter, dv=1, k=True)
                cmds.connectAttr(sScaleAttr, '%s.sx' % sJoint)
                cmds.connectAttr(sScaleAttr, '%s.sy' % sJoint)
                cmds.connectAttr(sScaleAttr, '%s.sz' % sJoint)



def createOrFixFaceZero():
    sZero = 'jnt_m_faceZero'
    if not cmds.objExists(sZero):
        cmds.createNode('joint', n=sZero, p='modules')
    else:
        if not cmds.listRelatives(sZero, p=True):
            cmds.parent(sZero, 'modules')


dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls8.exportSliderBps
@builderTools.addToBuild(iOrder=24, dButtons=dButtons, bCanGetDuplicated=True)
def BASELidCtrls(sParentJoint='jnt_m_headMain', sLookUpStrengthes=[1,1], sLookDownStrengthes=[1,1], bPolyCtrls=False, fInnerBlink=None, sSuffix=''):
    '''
    This creates the ctrls "blink_l_ctrl", "lidBot_l_ctrl" and "lidTop_l_ctrl"
    
    fInnerBlink is for creatures that have a membrane blink, such as birds. If it's None, it won't create a joint, but if it's a float vector such as [0,100,0], it'll create a joint
    That float vector is the default of the blink rotation.,
    IMPORTANT: this float vector will likely get overwritten in the importBlendShapeFile() function!
    '''

    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if s == 1 else 1.0
        sEyeJoints = ['jnt_%s_eye%sMain' % (sSide, sSuffix), 'jnt_%s_eye%sIris' % (sSide, sSuffix)]
        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        # sParent = xforms.createTransform('grp_%s_eyeLid%sParent' % (sSide, sSuffix), sParent='modules',
        #                                  sMatch=sEyeJoints[0])
        # sOutwardsRotParent = cmds.createNode('transform', n='grp_%s_eyeLid%sOutwardsRotate' % (sSide, sSuffix),
        #                                      p=sParent)
        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1] - aJointPositions[0])

        if sSide == 'l':
            aBlinkPos = aJointPositions[1] + np.array([fRadius * fSideMultipl, 0, 0])

            cBlinks = ctrls8.createSliderCtrl('blink%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                              fBpPos=aBlinkPos, fRangeY=[-1, 0.5],
                                              sAttach=sParentJoint, fScale=fSliderScale, bPoly=bPolyCtrls,
                                              bExportMirrorBps=True)

            cBotLids = ctrls8.createSliderCtrl('lidBot%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                                 fRangeY=[-1, 1.0], sAttach=sParentJoint,
                                                 fScale=fSliderScale * 0.5,
                                                 fBpPos=aBlinkPos + np.array(
                                                     [fSliderScale * fSideMultipl, -1 * fSliderScale, 0]),
                                                 bPoly=bPolyCtrls, bExportMirrorBps=True)
            cTopLids = ctrls8.createSliderCtrl('lidTop%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                                 fRangeY=[-1, 1.0], sAttach=sParentJoint,
                                                 fScale=fSliderScale * 0.5,
                                                 fBpPos=aBlinkPos + np.array(
                                                     [fSliderScale * fSideMultipl, 1 * fSliderScale, 0]),
                                                 bPoly=bPolyCtrls, bExportMirrorBps=True)

            ccExtraBlinks = [cBotLids, cTopLids]

        
            for cC in cBlinks + cBotLids + cTopLids:
                cC.createExtraMoveTransformAndTag(['skinCluster__*face*__TWEAKER'])


        cAim = ctrls8.ctrlFromName('eyesLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)
        if not cAim:
            cAim = ctrls8.ctrlFromName('eyeLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)

        # drivers for shapes:
        for p,sPart in enumerate(['bot','top']):
            sBlendExtraDownShape = nodes.createRangeNode('%s.ty' % ccExtraBlinks[p][s].sCtrl, 0, -1.0, 0, 1)
            sBlendExtraUpShape = nodes.createRangeNode('%s.ty' % ccExtraBlinks[p][s].sCtrl, 0, 1.0, 0, 1)
            sBlendsFollowDownShape = nodes.createRangeNode('%s.lookVert' % cAim.sPasser, 0, -5.0, 0, 1)
            sBlendsFollowUpShape = nodes.createRangeNode('%s.lookVert' % cAim.sPasser, 0, 5, 0, 1)

            sBlendsFollowDownShape = nodes.createMultiplyNode(sBlendsFollowDownShape, sLookDownStrengthes[p])
            sBlendsFollowUpShape = nodes.createMultiplyNode(sBlendsFollowUpShape, sLookUpStrengthes[p])

            sShapeDriverDown = utils.addAttr(ccExtraBlinks[p][s].sPasser, ln='shapeDriverDown', k=True)
            sShapeDriverUp = utils.addAttr(ccExtraBlinks[p][s].sPasser, ln='shapeDriverUp', k=True)
            sAdditions = nodes.createVectorAdditionNode([[sBlendExtraDownShape, sBlendExtraUpShape, 0], [sBlendsFollowDownShape, sBlendsFollowUpShape, 0]])
            cmds.connectAttr('%sx' % sAdditions, sShapeDriverDown)
            cmds.connectAttr('%sy' % sAdditions, sShapeDriverUp)



        sBlinkLineAttr = utils.addAttr(cBlinks[s].sCtrl, ln='blinkLine', min=0.0, max=1.0, dv=0.5, k=True)
        sBotBlendAttr = utils.addAttr(cBlinks[s].sPasser, ln='blendCurveBot' , k=True)
        sTopBlendAttr = utils.addAttr(cBlinks[s].sPasser, ln='blendCurveTop', k=True)

        # bot
        sLookVert = nodes.createAdditionNode(['%s.shapeDriverUp' % ccExtraBlinks[0][s].sPasser, '%s.shapeDriverDown' % ccExtraBlinks[0][s].sPasser], sOperation='minus')
        nodes.createAdditionNode([nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1, sBlinkLineAttr]), sLookVert], sTarget=sBotBlendAttr)

        # top
        sLookVert = nodes.createAdditionNode(['%s.shapeDriverUp' % ccExtraBlinks[1][s].sPasser, '%s.shapeDriverDown' % ccExtraBlinks[1][s].sPasser], sOperation='minus')
        sMainBlink = nodes.createConditionNode('%s.ty' % cBlinks[s].sCtrl, '<', 0,
                                               nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1, nodes.createReverseNode(sBlinkLineAttr)]),
                                               nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1.75])) # -1.75 means that the main blink up will be 1.75 of the extra up shape
        nodes.createAdditionNode([sMainBlink, nodes.createMultiplyNode(sLookVert, -1)],  sTarget=sTopBlendAttr)

    if fInnerBlink != None:
        for s, sSide in enumerate(['l', 'r']):
            sEyeJoint = 'jnt_%s_eyeMain' % sSide
            cBlinks[s] = ctrls8.ctrlFromName('blink%s_ctrl' % utils.sSides3[s])
            sLidJoint = cmds.duplicate(sEyeJoint, n='jnt_%s_innerEyeLid' % sSide, po=True)[0]
            cmds.parent(sLidJoint, sEyeJoint)
            sCloseAttr = utils.addAttr(cBlinks[s].sCtrl, ln='innerBlink', min=0, max=1, k=True)
            
            sInnerBlinkRotate = utils.addAttr(cBlinks[s].sPasser, ln='innerBlinkRotate', at='double3', k=True)
            for sA,fV in zip(['X','Y','Z'], fInnerBlink):
                cmds.setAttr('%s%s' % (sInnerBlinkRotate,sA),fV)
                
            nodes.createRangeNode(sCloseAttr, 0, 1, [0,0,0], sInnerBlinkRotate, bOutRangeIsVector=True, sTarget='%s.r' % sLidJoint)


dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def fillBlinkValues(fExtraBlinkCtrlStrengthes, _uiArgs=None):
    sCtrl = 'blink_l_ctrl'
    sPasser = ctrls8.ctrlFromName(sCtrl).sPasser
    # sPasser = 'grp_l_blinkPasser'
    print('sPasser: ',sPasser)
    if not cmds.objExists(sPasser):
        if not cmds.objExists(sPasser):
            raise Exception('eye blink passer not found')

    _uiArgs['fBlinkValues'].setText(str([cmds.getAttr('%s.botBlink' % sPasser), cmds.getAttr('%s.topBlink' % sPasser)]))
    _uiArgs['fBlinkTwistValues'].setText(str([cmds.getAttr('%s.botBlinkTwist' % sPasser), cmds.getAttr('%s.topBlinkTwist' % sPasser)]))
    _uiArgs['fWideValues'].setText(str([cmds.getAttr('%s.botWide' % sPasser), cmds.getAttr('%s.topWide' % sPasser)]))
    _uiArgs['fFollowUps'].setText(str([cmds.getAttr('%s.followBotUp' % sPasser), cmds.getAttr('%s.followTopUp' % sPasser)]))
    _uiArgs['fFollowDowns'].setText(str([cmds.getAttr('%s.followBotDown' % sPasser), cmds.getAttr('%s.followTopDown' % sPasser)]))


    for i, sCtrl in enumerate(['lidBot_l_ctrl', 'lidTop_l_ctrl']):
        if cmds.objExists(sCtrl):
            cCtrl = ctrls8.ctrlFromName(sCtrl)
            sPasser = cCtrl.sPasser
            fExtraBlinkCtrlStrengthes[i] = round(cmds.getAttr('%s.fExtraBlinkCtrlStrength' % sPasser), 3)
        _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(fExtraBlinkCtrlStrengthes))

    # _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(cmds.getAttr('%s.fExtraBlinkCtrlStrengthes' % sPasser)))



kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill blink values'] = fillBlinkValues


def proceduralBind_lidSplineUndo(bSeparateSkinCluster):
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sAllJoints = cmds.ls('jnt_?_???SkinLidSpline*_???', et='joint')
    weights.moveSkinClusterWeights(sMesh, xJoints={sJ:'jnt_m_headMain' for sJ in sAllJoints})


def proceduralBind_lidSpline(iBindRows, bSeparateSkinCluster):
    utils.reload2(weights)
    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)
        sSelection = cmds.ls(sl=True)
        if bSeparateSkinCluster:
            sSkinCluster = 'skinCluster__%s__LIDSPLINE' % (sMesh)
            sSkinClusterTemp = 'TEMP__skinCluster__%s__LIDSPLINE' % (sMesh)
            if cmds.objExists(sSkinClusterTemp):
                cmds.delete(sSkinClusterTemp)
            deformers.skinMesh(sMesh, ['jnt_m_faceZero'], sName=sSkinClusterTemp, bAlwaysAddDefaultWeights=True)
        else:
            sSkinCluster = 'skinCluster__%s' % (sMesh)
            sSkinClusterTemp = 'skinCluster__%s' % (sMesh)


        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()

        # fJointWeightings = np.interp(np.arange(sJoints), iIndices, [1, 0.5, ]
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()

        utils.reload2(weights)
        sAllJoints = cmds.ls('jnt_l_???SkinLidSpline_???', et='joint')
        cmds.select(sSelection)
        weights.bindToClosestVertexAndExpand(None, sJoints=sAllJoints,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iBindRows[0], iExpandedFadeOutLoops=iBindRows[1],
                                             sChooseSkinCluster=sSkinClusterTemp)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)
        if bSeparateSkinCluster:

            if cmds.objExists(sSkinCluster):
                pTransferTo = pMesh
                for pSel in pSelection:
                    if pSel.getName() == pMesh.getName():
                        pTransferTo = pSel
                        break

                weights.transferSkinCluster([pTransferTo], sFrom=sSkinClusterTemp, sChooseSkinCluster=sSkinCluster, iMode=weights.TransferMode.vertexIndex)
                cmds.delete(sSkinClusterTemp)
            else:
                cmds.rename(sSkinClusterTemp, sSkinCluster)


            cmds.setAttr('%s.skinningMethod' % sSkinCluster, 1)

            deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)


kEyeSplinesPostBpGroupName = '_grp_m_eyeSplinesBp'
kEyeSplinesPostBpFileName = 'faceBlueprintsEyeSplines.ma'



#
# def _generateLidCorrective(sModel, sParts):
#     print ('sModel: ', sModel)
#     if sModel:
#         sModel = utils.toList(sModel)[0]
#     else:
#         raise Exception('no model given')
#
#     sSecondaryMeshes = [sM for sM in cmds.ls(sl=True) if sM != sModel]
#
#     cBlink = ctrls8.ctrlFromName('blink_l_ctrl')
#     iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % cBlink.sPasser) * 100),
#                 -int(cmds.getAttr('%s.blendCurveTop' % cBlink.sPasser) * 100)]
#     sNewMeshes = []
#
#     sStringSplits = ['','']
#     for p,sPart in enumerate(['bot','top']):
#         if sPart.upper() in sParts.upper():
#             iValue = iBotTops[p]
#             sStringSplits[p] = '%03d' % iValue if iValue > 0 else 'n%03d' % -iValue
#     sString = kSplineLideCorrectiveSep.join(sStringSplits)
#
#     for i, sM in enumerate([sModel] + sSecondaryMeshes):
#         sNewMesh = '%s%s%s' % (kSplineLidCorrectivePrefix, kSplineLideCorrectiveSep, sString)
#
#         if i > 0:
#             sNewMesh = '%s__%s' % (sM, sNewMesh)
#
#         if not cmds.objExists(sNewMesh):
#             cmds.duplicate(sM, n=sNewMesh)
#             print ('sNewMesh: ', sNewMesh)
#             utils.parentToWorld(sNewMesh)
#         sNewMeshes.append(sNewMesh)
#
#     cmds.select(sNewMeshes)


# def generateLidCorrectiveBot(sModel):
#     _generateLidCorrective(sModel, 'bot')
#
# def generateLidCorrectiveBotTop(sModel):
#     _generateLidCorrective(sModel, 'botTop')
#
# def generateLidCorrectiveTop(sModel):
#     _generateLidCorrective(sModel, 'top')


#EXCLUDE START LIDSPLINES




def generateNewSplineLidsPose():
    cBlink = ctrls8.ctrlFromName('blink_l_ctrl')
    iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % cBlink.sPasser) * 100),
                int(cmds.getAttr('%s.blendCurveTop' % cBlink.sPasser) * 100)]

    dSiblings = getSplineLidsPosesInfo()
    for p,sPart in enumerate(['bot','top']):
        dAttrValues = {}
        for sName in ['A', 'B', 'C']:
            sPoseGrp = f'grp_l_eyeSpline{sPart.title()}{sName}OffsetPose'
            dAttrValues[sName] = [cmds.getAttr('%s.t' % sPoseGrp)[0],
                                  cmds.getAttr('%s.r' % sPoseGrp)[0],
                                  cmds.getAttr('%s.s' % sPoseGrp)[0]]
        dSiblings[f'{sPart}.{iBotTops[p]}'] = dAttrValues

    createSplineLidsPosesSetup(dSiblings)



def createSplineLidsPosesSetup(dPoses, _bBlendLastToZero=False):

    dPoses['bot.000'] = {}
    dPoses['top.000'] = {}

    dTranslates = defaultdict(list)
    dRotates = defaultdict(list)
    dScales = defaultdict(list)


    for s,sSide in enumerate('lr'):
        for sKey, dP in dPoses.items():
            if '.' not in sKey: # probably blink pose
                continue

            sPart, sPos = sKey.split('.')
            iDriverValue = int(sPos)
            sCtrls = cmds.ls(f'eyeSpline{sPart.title()}?_{sSide}_ctrl', et='transform') + \
                      cmds.ls(f'eyeSplineCorner*Tangent{sPart.title()}_{sSide}_ctrl', et='transform') + \
                      cmds.ls(f'eyeSplineCorner*_{sSide}_ctrl', et='transform')

            for sCtrl in sCtrls:
                cCtrl = ctrls8.ctrlFromName(sCtrl)
                sPoseGrp = cCtrl.getOffsetByName('pose')
                sSign = 'p' if iDriverValue >= 0 else 'n'
                sPoseLoc = f"_poseLoc__{cCtrl.sCtrl.replace('_ctrl', '')}__{sPart}__{sSign}{abs(iDriverValue):03d}"
                if not cmds.objExists(sPoseLoc):
                    xforms.createLocator(sPoseLoc, sParent=cCtrl.sSlider, fSize=cCtrl.fSize)
                    utils.connectPosesLocVis(sPoseLoc)
                    xforms.matchXform(sPoseGrp, sPoseLoc)
                    fValues = dP.get(sCtrl, [(0,0,0), (0,0,0), (1,1,1)])
                    cmds.setAttr('%s.t' % sPoseLoc, *fValues[0])
                    cmds.setAttr('%s.r' % sPoseLoc, *fValues[1])
                    cmds.setAttr('%s.s' % sPoseLoc, *fValues[2])

                if iDriverValue == 0:
                    for sA in 'trs':
                        cmds.setAttr('%s.%s' % (sPoseLoc, sA), lock=True)

                utils.connectPosesLocVis(sPoseLoc)
                if 'tangent' not in sCtrl.lower():
                    dTranslates['%s.%s' % (sPoseGrp, sPart)].append(('%s.t' % sPoseLoc, iDriverValue))
                else:
                    cmds.setAttr('%s.t' % sPoseLoc, lock=True)
                dRotates['%s.%s' % (sPoseGrp, sPart)].append(('%s.r' % sPoseLoc, iDriverValue))
                dScales['%s.%s' % (sPoseGrp, sPart)].append((nodes.createVectorAdditionNode(['%s.s' % sPoseLoc, [-1,-1,-1]]), iDriverValue))


    ddBotTopOutputs = defaultdict(dict)
    for sOutA, dData in [('t', dTranslates),
                         ('r', dRotates),
                         ('s', dScales)]:

        for sPoseGrpAndPart, xValues in dData.items():
            sPoseGrp, sPart = sPoseGrpAndPart.split('.')
            p = 0 if sPart.lower() == 'bot' else 1
            if sOutA == 't' and 'tangent' in sPoseGrp.lower():
                continue

            xValues = sorted(xValues, key=lambda a:a[1])
            sSide = utils.getSide(sPoseGrp)
            sDriverAttr = 'grp_%s_blinkPasser.blendCurve%s' % (sSide, utils.getFirstLetterUpperCase(sPart))

            for i, xV in enumerate(xValues):
                sPoseLocAttr = xV[0]
                fDriverValue = xV[1] * 0.01
                if i == 0:
                    sPrevSiblingAttr = [0,0,0]
                    fPrevDriverValue = -1.0
                else:
                    sPrevSiblingAttr = xValues[i-1][0]
                    fPrevDriverValue = xValues[i-1][1] * 0.01

                sRange = nodes.createRangeNode(sDriverAttr, fPrevDriverValue, fDriverValue, sPrevSiblingAttr, sPoseLocAttr, bOutRangeIsVector=True)
                sOutput = nodes.createConditionNode(sDriverAttr, '<=', fDriverValue, sRange, [-55, -55, -55], bVector=True, sName='SplineLidsPose_%d' % xV[1])
                if i == 0:
                    ddBotTopOutputs['%s.%s' % (sPoseGrp, sOutA)][sPart.lower()] = sOutput
                else:
                    cmds.connectAttr(sOutput, '%s.colorIfFalse' % sPrevCondition)

                sPrevCondition = sOutput.split('.')[0]
                if sOutA == 'r': # checking for rotation only because every control has that, and the following block needs to get run for each control just once
                    sVisPrev = nodes.createRangeNode(sDriverAttr, fPrevDriverValue, fDriverValue, 0, 1)
                    if i < len(xValues)-1:
                        sVisNext = nodes.createRangeNode(sDriverAttr, fDriverValue, xValues[i+1][1] * 0.01, 1, 0)
                        sVisOutput = nodes.createConditionNode(sDriverAttr, '<', fDriverValue, sVisPrev, sVisNext)
                    else:
                        sVisOutput = sVisPrev

                    if xV[1] == 0:
                        cmds.setAttr('%s.v' % sPoseLocAttr.split('.')[0], False)
                    else:
                        cmds.connectAttr(sVisOutput, '%s.v' % sPoseLocAttr.split('.')[0], force=True)

            if _bBlendLastToZero:
                sLastRange = nodes.createRangeNode(sDriverAttr, fDriverValue, 1, sPoseLocAttr, [0,0,0], bOutRangeIsVector=True)
                cmds.connectAttr(sLastRange, '%s.colorIfFalse' % sPrevCondition)
            else:
                cmds.connectAttr(sPoseLocAttr, '%s.colorIfFalse' % sPrevCondition)


    for sPoseName, sDriverAttr, fDriverValue in [('blink', 'blink_l_ctrl.ty', -1.0)]:

        for s,sSide in enumerate('lr'):
            sDriverOutput = nodes.createRangeNode(utils.getMirrorName(sDriverAttr) if sSide == 'r' else sDriverAttr,
                                                  0, fDriverValue, 0, 1)

            sCtrls = cmds.ls(f'eyeSpline*_{sSide}_ctrl', et='transform') + \
                      cmds.ls(f'eyeSplineCorner*Tangent*_{sSide}_ctrl', et='transform') + \
                      cmds.ls(f'eyeSplineCorner*_{sSide}_ctrl', et='transform')
            for sCtrl in sCtrls:
                cCtrl = ctrls8.ctrlFromName(sCtrl)
                sPoseGrp = cCtrl.getOffsetByName('pose')
                sPoseLoc = f"_poseLoc__{cCtrl.sCtrl.replace('_ctrl', '')}__{sPoseName}"
                if not cmds.objExists(sPoseLoc):
                    xforms.createLocator(sPoseLoc, sParent=cCtrl.sSlider, fSize=cCtrl.fSize)
                    utils.connectPosesLocVis(sPoseLoc)
                    xforms.matchXform(sPoseGrp, sPoseLoc)
                    fValues = dPoses.get(sPoseName, {}).get(sCtrl, [(0,0,0), (0,0,0), (1,1,1)])
                    cmds.setAttr('%s.t' % sPoseLoc, *fValues[0])
                    cmds.setAttr('%s.r' % sPoseLoc, *fValues[1])
                    cmds.setAttr('%s.s' % sPoseLoc, *fValues[2])

                for sOutA in 'tr':
                    ddBotTopOutputs['%s.%s' % (sPoseGrp, sOutA)][sPoseName] = nodes.createVectorMultiplyNode('%s.%s' % (sPoseLoc, sOutA), sDriverOutput, bVectorByScalar=True)

                ddBotTopOutputs['%s.s' % (sPoseGrp)][sPoseName] = nodes.createVectorMultiplyNode(nodes.createVectorAdditionNode(['%s.s' % (sPoseLoc), [-1,-1,-1]]),
                                                                                                 sDriverAttr, bVectorByScalar=True)



    for sPoseAttr, dDict in ddBotTopOutputs.items():
        sOutputs = list(dDict.values())
        if sPoseAttr.endswith('.s'):
            nodes.createVectorAdditionNode([[1,1,1]] + sOutputs, sTarget=sPoseAttr, bForce=True)
        else:
            nodes.createVectorAdditionNode(sOutputs, sTarget=sPoseAttr, bForce=True)



def getSplineLidsPosesInfo():
    dPoses = defaultdict(dict)
    for p,sPart in enumerate(['bot','top']):
        sPoseLocs = cmds.ls(f'_poseLoc__eyeSpline*_l__{sPart.lower()}__????', et='transform')
        for sPoseLoc in sPoseLocs:
            sDriverValue = sPoseLoc.split('_')[-1]
            iDriverValue = int(sDriverValue[1:]) * (-1 if sDriverValue[0] == 'n' else 1)
            if iDriverValue != 0:

                sCtrlName = '%s_ctrl' % sPoseLoc.split('__')[1]
                dPoses['%s.%d' % (sPart, iDriverValue)][sCtrlName] = [cmds.getAttr('%s.t' % sPoseLoc)[0],
                                                                      cmds.getAttr('%s.r' % sPoseLoc)[0],
                                                                      cmds.getAttr('%s.s' % sPoseLoc)[0]]

                dPoses['%s.%d' % (sPart, iDriverValue)][utils.getMirrorName(sCtrlName)] = [cmds.getAttr('%s.t' % sPoseLoc)[0],
                                                                                           cmds.getAttr('%s.r' % sPoseLoc)[0],
                                                                                           cmds.getAttr('%s.s' % sPoseLoc)[0]]

        for sPoseName in ['blink']:
            sPoseLocs = cmds.ls(f'_poseLoc__eyeSpline*_l__{sPoseName}', et='transform')
            for sPoseLoc in sPoseLocs:

                sCtrlName = '%s_ctrl' % sPoseLoc.split('__')[1]
                dPoses[sPoseName][sCtrlName] = [cmds.getAttr('%s.t' % sPoseLoc)[0],
                                              cmds.getAttr('%s.r' % sPoseLoc)[0],
                                              cmds.getAttr('%s.s' % sPoseLoc)[0]]

                dPoses[sPoseName][utils.getMirrorName(sCtrlName)] = [cmds.getAttr('%s.t' % sPoseLoc)[0],
                                                                    cmds.getAttr('%s.r' % sPoseLoc)[0],
                                                                    cmds.getAttr('%s.s' % sPoseLoc)[0]]

    return dict(dPoses)



def fillSplineLidsPoses(_uiArgs=None):
    dPoses = getSplineLidsPosesInfo()
    _uiArgs['dPoses'].setText(str(dPoses))


#EXCLUDE START LIDSPLINES

dButtons = OrderedDict()

dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_lidSplines', kEyeSplinesPostBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {
    '?': [['Select vertices and click button.', 'eyelidVertices.jpg'],
          ['Locators indicate separation points between bottom and top eyelid. ' \
           'Adjust if needed', 'eyelidCurvesLocators.jpg']]}


dButtons['== BIND =='] = {'bind to joints on selected Mesh': proceduralBind_lidSpline, 'transfer back to jnt_m_headMain on selected Mesh':proceduralBind_lidSplineUndo}
dButtons['- Export Eye Splines BPs -'] = lambda: exportBps(kEyeSplinesPostBpFileName, kEyeSplinesPostBpGroupName)

dButtons['Generate PoseLoc at Current Lid Position'] = generateNewSplineLidsPose
dButtons['Fill PoseLocs '] = fillSplineLidsPoses

# dButtons['Generate Lid Corrective from selected'] = {'botTop':generateLidCorrectiveBotTop,
#                                                      'bot':generateLidCorrectiveBot,
#                                                      'top': generateLidCorrectiveTop}


# to do: ctrl orientations are not following latticed movement
@builderTools.addToBuild(iOrder=24.3, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def splineLidSetup(fMidPercs=[0.25, 0.5, 0.75], fLivePole=0.0, fDefaultBlinkLine=0.5,
                 sParentJoint='jnt_m_headMain', iBindRows=[2,3], fWidenFactors=[0.5,0.5], fDefaultOverShoot=1.025, bSeparateSkinCluster=False, bLidsCanPushOut=True, iSkipSplineJoints=0,
                 iExtraRowsBot=0, iExtraRowsTop=2, bZipper=True, fOvershootZipper=0.02, iCtrlSmoothIterations=8, _bSquashed=False, dPoses={}):
    '''
    fLivePole: if 1.0, the joints orientations are aligning to the curve
    
    Adjusting wide shapes: on running the function, he creates curve_?_*LidSplineWideTarget* curves inside the blueprint group. \
    Simply adjust those and export blueprints. If right side is not there, it'll get mirrored automatically
    '''

    # sModel = utils.objFromArg(sModel)

    sGrp = cmds.createNode('transform', n='grp_eyeSplines', p='modules')
    createOrFixFaceZero()

    for sCrv in ['bpCurve_l_lidSplines', 'bpCurve_r_lidSplines']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_lidSplines', 'locB_l_lidSplines', 'locA_r_lidSplines', 'locB_r_lidSplines']:
        xforms.mirrorIfNotExists(sLoc)

    ssCurves = []
    ssCurves.append(
        curves.separateCurveUsingSeparationLocs('bpCurve_l_lidSplines', 'locA_l_lidSplines', 'locB_l_lidSplines', 'bpCurve_l_botLidSpline',
                                                'bpCurve_l_topLidSpline'))
    ssCurves.append(
        curves.separateCurveUsingSeparationLocs('bpCurve_r_lidSplines', 'locA_r_lidSplines', 'locB_r_lidSplines', 'bpCurve_r_botLidSpline',
                                                'bpCurve_r_topLidSpline'))

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccEyeCtrls = [[], []]
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]

    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    sSuffix = ''
    sssAllJoints = [[], []], [[], []]
    for s, sSide in enumerate(['l', 'r']):

        sParent = xforms.createJoint('jnt_%s_eyeLidSplineParent' % sSide, sParent=jointOrGroup(sParentJoint), sMatch=ssEyeJoints[s][0], fSize=0.5  )
        utils.matchJointRadius(sParent, sEyeJoints[s], 1.15)

        cmds.setAttr('%s.segmentScaleCompensate' % sParent, False)

        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        aJointPositions = xforms.getPositionArray(ssEyeJoints[s])
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        cEyeTransform = ctrls8.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])
        cBlink = ctrls8.ctrlFromName('blink%s%s_ctrl' % (sSuffix, utils.sSides3[s]))
        sEyeTransformJoint = 'jnt_%s_eyeTransform' % sSide

        sBlinkLineAttr = '%s.blinkLine' % cBlink.sCtrl
        cmds.setAttr(sBlinkLineAttr, fDefaultBlinkLine)

        if bSeparateSkinCluster:
            sEyeTransformJointLive = cmds.duplicate(sEyeTransformJoint, n='jnt_%s_eyeTransformLive' % sSide, po=True)[0]
            cmds.parent(sEyeTransformJointLive, sEyeTransformJoint)
            fLocalEyeTransform = nodes.createMultMatrixNode( ['%s.worldMatrix' % sEyeTransformJointLive, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
            sEyeTransformInverseRef = nodes.createInverseMatrix(nodes.createMultMatrixNode([fLocalEyeTransform, '%s.worldMatrix' % sParentJoint]))
            utils.addStringAttr(sEyeTransformJointLive, deformers.kPostRefJointAttr, sEyeTransformInverseRef)

        sTransformJoint = 'jnt_%s_eyeTransform' % sSide
        sTransformJointRotMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sTransformJoint)
        sTransformJointRotInverseMatrix = nodes.createInverseMatrix(sTransformJointRotMatrix)

        # ffBlinkPoses = [('%s.ty' % cExtraBlinks[0].sCtrl, 1.0), ('%s.ty' % cExtraBlinks[1].sCtrl, -1.0)]
        sStartCurves = []
        if _bSquashed:
            ssLattices = utils.data.get('ssEyeLattices')
            for p,sPart in enumerate(['bot','top']):
                sTempDupl = cmds.duplicate(ssCurves[s][p], n='tempDuplCurve')[0]
                sTempLattice = deformers.applyLattice(ssLattices[s], ssCurves[s][p])
                cmds.setAttr('%s.outsideLattice' % sTempLattice, 1)
                sInvert = geometry.invertShapeDeformers(sTempDupl, ssCurves[s][p], sInvertName='curve_%s_%sInverted' % (sSide,sPart))
                sStartCurves.append(sInvert)
                deformers.disconnectLattice(sTempLattice)
                cmds.delete(sTempLattice)
                cmds.delete(sTempDupl)
            cmds.parent(sStartCurves, sGrp)
        else:
            sStartCurves = ssCurves[s]

        aaPoints = [patch.patchFromName(sStartCurves[0]).getPoints(),
                    patch.patchFromName(sStartCurves[1]).getPoints()]
        aNonSkippedIndices = [utils.getFilteredFromAvoidIndices(len(aaPoints[0]), iSkipSplineJoints, bForceKeepEnds=True),
                              utils.getFilteredFromAvoidIndices(len(aaPoints[1]), iSkipSplineJoints, bForceKeepEnds=True)]
        aaPoints = [aaPoints[0][aNonSkippedIndices[0]], aaPoints[1][aNonSkippedIndices[1]]]

        aaLocalPoints = [np.dot(utils.makePoint4Array(aaPoints[0]), np.linalg.inv(utils.getNumpyMatrixFromTransform(cEyeTransform.sOut)))[:,0:3],
                         np.dot(utils.makePoint4Array(aaPoints[1]), np.linalg.inv(utils.getNumpyMatrixFromTransform(cEyeTransform.sOut)))[:, 0:3]]
        iBiggerCvCount = max(len(aaPoints[0]), len(aaPoints[1]))

        sTransformGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransform' % sSide, p=sGrp)
        sOriginTransformGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransformOrigin' % sSide, p=sGrp)
        sCtrlGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesCtrls' % sSide, p='ctrls')
        constraints.matrixParentConstraint(sEyeTransformJoint, sTransformGrp)
        constraints.matrixParentConstraint(sEyeTransformJoint, sOriginTransformGrp) #, mo=True)
        constraints.matrixParentConstraint(cEyeTransform.sOut, sCtrlGrp)

        sTransformRefGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransformRef' % sSide, p=sGrp)
        cmds.xform(sTransformRefGrp, m=cmds.xform(sTransformGrp, q=True, m=True))

        sTempDuplCurves = [cmds.duplicate(sStartCurves[0], n='curve_%s_tempDuplBot' % sSide)[0],
                          cmds.duplicate(sStartCurves[1], n='curve_%s_tempDuplTop' % sSide)[0]]

        cmds.parent(sTempDuplCurves, sOriginTransformGrp)

        sMaxStaticCurves = [curves.rebuildWithCvCount(sTempDuplCurves[0], iCvCount=iBiggerCvCount, iDegree=2, sNewName='curve_%s_lidSplineBot_static' % sSide),
                            curves.rebuildWithCvCount(sTempDuplCurves[1], iCvCount=iBiggerCvCount, iDegree=2, sNewName='curve_%s_lidSplineTop_static' % sSide)]
        sMaxBlendingCurves = [cmds.duplicate(sMaxStaticCurves[0], n='curve_%s_lidSplineMaxBlendingBot' % sSide)[0],
                              cmds.duplicate(sMaxStaticCurves[1], n='curve_%s_lidSplineMaxBlendingTop' % sSide)[0]]
        aaMaxPoints = [patch.patchFromName(sMaxStaticCurves[0]).getPoints(),
                       patch.patchFromName(sMaxStaticCurves[1]).getPoints()]

        sBlendingCurves = [cmds.curve(p=aaPoints[0], d=1, n='curve_%s_lidSplineBlendingBot' % sSide),
                            cmds.curve(p=aaPoints[1], d=1, n='curve_%s_lidSplineBlendingTop' % sSide)]
        curves.fixShapeName(sBlendingCurves)
        cmds.parent(sBlendingCurves, sGrp)
        sCtrlBlendingCurves = [cmds.duplicate(sBlendingCurves[0], n='curve_%s_lidSplineBlendingCtrlsBot' % sSide)[0],
                                cmds.duplicate(sBlendingCurves[1], n='curve_%s_lidSplineBlendingCtrlsTop' % sSide)[0]]

        sBlink = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0,-1,0,1)

        ssWideTargetCurves = [None, None]
        for p,sPart in enumerate(['bot','top']):
            ssWideTargetCurves[p] = ['curve_%s_%sLidSplineWideTarget' % (sSide,sPart), 'curve_%s_%sLidSplineWideTargetOther' % (sSide,sPart)]
            for pp,sCurve in enumerate(ssWideTargetCurves[p]):
                if not cmds.objExists(sCurve):
                    sMirrorCurve = utils.getMirrorName(sCurve)
                    if cmds.objExists(sMirrorCurve):
                        aPoints = patch.patchFromName(sMirrorCurve).getPoints()
                        aPoints[:, 0] *= -1.0
                    else:
                        if pp == 0:
                            aPoints = aaMaxPoints[p] - (aaMaxPoints[1-p]-aaMaxPoints[p]) * fWidenFactors[p]
                        else:
                            aPoints = aaMaxPoints[1-p]
                    cmds.curve(p=aPoints, d=1, n=sCurve)

                utils.parentTo(sCurve, kEyeSplinesPostBpGroupName)

        sOverShootAttr = utils.addAttr(cBlink.sPasser, ln='overShootOnBlinkFactor', dv=fDefaultOverShoot, k=True)

        sBlendingTargetAttrs = ['%s.blendCurveBot' % cBlink.sPasser, '%s.blendCurveTop' % cBlink.sPasser]

        for p,sPart in enumerate(['bot','top']):

            sTargetAttrs = blendShapes.addTargets(sMaxBlendingCurves[p], [sMaxStaticCurves[1-p], ssWideTargetCurves[p][0]])
            sOtherTargetAttr = blendShapes.addTargets(sMaxBlendingCurves[1-p], [ssWideTargetCurves[p][1]])[0]

            nodes.createConditionNode(sBlendingTargetAttrs[p], '>=', 0, nodes.createMultiplyNode(sBlendingTargetAttrs[p], sOverShootAttr), 0, sTarget=sTargetAttrs[0])
            nodes.createConditionNode(sBlendingTargetAttrs[p], '<', 0, nodes.createMultiplyNode(sBlendingTargetAttrs[p], -1), 0, sTarget=[sTargetAttrs[1], sOtherTargetAttr])

        ffCtrlParams = [curves.getParamsFromPercs(sBlendingCurves[0], fMidPercs),
                        curves.getParamsFromPercs(sBlendingCurves[1], fMidPercs)]
        # ctrls - bottom tops
        fCtrlSize = len(ssCurves[0][p]) * 0.02

        iMiddleIndex = None if not len(ffCtrlParams[p]) % 2 else len(ffCtrlParams[p]) // 2
        for p, sPart in enumerate(['bot', 'top']):
            fCtrlParams = ffCtrlParams[p]
            # aTangents = curves.getTangentsFromParams(sBlendingCurves[p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(sBlendingCurves[p], fCtrlParams)
            for c, fP in enumerate(fCtrlParams):
                if _bSquashed:
                    cC = ctrls8.create(sName='eyeSplineAttach%s%s' % (sPart.title(), utils.getLetter(c)), sSide=sSide,
                                       sParent=sTransformGrp,
                                       fSliderScale=fSliderScale, bIsNoCtrl=True,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])
                    cC.cC = ctrls8.create(sName='eyeSpline%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide,
                                       sParent=sCtrlGrp, iColorIndex=2,
                                       fSliderScale=fSliderScale,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])

                    cC.cAnim = cC.cC
                    for sA in ['t','r','s']:
                        cmds.connectAttr('%s.%s' % (cC.cC.sCtrl,sA), '%s.%s' % (cC.sCtrl,sA))
                else:
                    cC = ctrls8.create(sName='eyeSpline%s%s' % (sPart.title(), utils.getLetter(c)), sSide=sSide,
                                       sParent=sCtrlGrp, iColorIndex=2,
                                       fSliderScale=fSliderScale,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])
                    cC.createExtraMoveTransformAndTag(ctrls8.kDefaultFaceAttachDeformers[2:])
                    cC.cAnim = cC

                bNotMiddle = c != len(fCtrlParams) // 2

                cC.appendOffsetGroup('pose')
                cC.sJoint = cmds.createNode('joint', n='jnt_%s_%sCtrl_%03d' % (sSide, sPart, c), p=cC.sPasser)
                utils.addStringAttr(cC.sJoint, 'sCtrl', cC.sCtrl)
                constraints.matrixParentConstraint(cC.sOut, cC.sJoint, sJumpOverTransforms=[cC.getOffsetByName('extramove'), cC.sPasser])

                utils.matchJointRadius(cC.sJoint, sEyeJoints[s], 0.5)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                utils.addStringAttr(cC.sJoint, deformers.kPostRefJointAttr, cC.sPasser)


                cccBotTopCtrls[s][p].append(cC)

                ccEyeCtrls[s].append(cC)


            sMiddleSliderMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cccBotTopCtrls[s][p][iMiddleIndex].sSlider,
                                                             '%s.worldInverseMatrix' % cccBotTopCtrls[s][p][iMiddleIndex].sExtraMove,
                                                             '%s.worldMatrix' % cccBotTopCtrls[s][p][iMiddleIndex].sPasser])
            sCtrlSliderMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cccBotTopCtrls[s][p][iMiddleIndex].sCtrl,
                                                             '%s.worldInverseMatrix' % cccBotTopCtrls[s][p][iMiddleIndex].sExtraMove,
                                                             '%s.worldMatrix' % cccBotTopCtrls[s][p][iMiddleIndex].sPasser])
            for c, fP in enumerate(fCtrlParams):
                if iMiddleIndex and c != iMiddleIndex:
                    sDriveByMiddleOffset = cccBotTopCtrls[s][p][c].appendOffsetGroup('drivebymiddle')
                    sDriveByMiddleParent = cmds.listRelatives(sDriveByMiddleOffset, p=True)[0]

                    sDriveByMiddleParentMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sDriveByMiddleParent,
                                                                             '%s.worldInverseMatrix' % cccBotTopCtrls[s][p][c].sExtraMove,
                                                                             '%s.worldMatrix' % cccBotTopCtrls[s][p][c].sPasser])

                    sDriveByMiddleMatrix = nodes.createMultMatrixNode([sDriveByMiddleParentMatrix,
                                                                       nodes.createInverseMatrix(sMiddleSliderMatrix),
                                                                       sCtrlSliderMatrix,
                                                                       nodes.createInverseMatrix(sDriveByMiddleParentMatrix)])

                    sParentToMiddleAttr = utils.addAttr(cccBotTopCtrls[s][p][c].sPasser, ln='parentToMiddle', min=0, max=1, dv=0.8, k=True)
                    sBlendMatrix = nodes.createBlendMatrixNode([sDriveByMiddleMatrix, utils.fIdentityMatrix], [sParentToMiddleAttr, nodes.createReverseNode(sParentToMiddleAttr)])
                    nodes.createDecomposeMatrix(sBlendMatrix,
                                                sTargetPos='%s.t' % sDriveByMiddleOffset,
                                                sTargetRot='%s.r' % sDriveByMiddleOffset)


        # ccEyeCtrls[s][1].convertToSimpleTransforms()
        # cmds.delete(ccEyeCtrls[s][1].sCtrl, 'sliderBp_l_blink')

        # ctrls - corners
        fCtrlParams = curves.getParamsFromPercs(sStartCurves[0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(sStartCurves[0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, ['cornerIn', 'cornerOut']):
            sName = 'eyeSpline%s' % (utils.getFirstLetterUpperCase(sN))

            if _bSquashed:
                cC = ctrls8.create(sName='%sAttach' % sName, sSide=sSide, sParent=sTransformGrp,
                                   sMatch='jnt_%s_eyeMain' % sSide, bIsNoCtrl=True,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize*0.33, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cC = ctrls8.create(sName=sName, sSide=sSide, sParent=sCtrlGrp, iColorIndex=2,
                                   sMatch='jnt_%s_eyeMain' % sSide,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize*0.33, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cAnim = cC.cC
                for sA in ['t', 'r', 's']:
                    cmds.connectAttr('%s.%s' % (cC.cC.sCtrl, sA), '%s.%s' % (cC.sCtrl, sA))
            else:
                cC = ctrls8.create(sName=sName, sSide=sSide, sParent=sCtrlGrp, iColorIndex=2,
                                   sMatch='jnt_%s_eyeMain' % sSide,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize*0.33, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.createExtraMoveTransformAndTag(ctrls8.kDefaultFaceAttachDeformers[2:])
                cC.cAnim = cC

            cC.appendOffsetGroup('pose')

            cC.sJumped = cmds.duplicate(cC.sOut, po=True, n='%sJumped' % cC.sOut)[0]
            constraints.matrixParentConstraint(cC.sOut, cC.sJumped, sJumpOverTransforms=[cC.sExtraMove, cC.sPasser])

            if c == 0: # inner
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aAverageTangent = (aPoints[0] + aPoints[1]) * 0.5 - aPoints[2]
                aBotTopTangents = [aPoints[0] - aPoints[2], aPoints[1] - aPoints[2]]
            else: # outer
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aAverageTangent = (aPoints[0] + aPoints[1]) * 0.5 - aPoints[2]
                aAverageTangent *= -1
                aBotTopTangents = [aPoints[0] - aPoints[2], aPoints[1] - aPoints[2]]

            xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aAverageTangent, fAimVector=[0, 0, -fSideMultipl], fUpVector=[fSideMultipl, 0, 0])
            if _bSquashed:
                cmds.delete(cmds.parentConstraint(cC.sPasser, cC.cC.sPasser))

            cC.sJoints = []
            cC.cTangents = []
            for p,sPart in enumerate(['bot','top']):
                cTangent = ctrls8.create('%sTangent%s' % (cC.sName, sPart.title()), sSide=sSide, sMatch=cC.sOut, sShape='revL_y',
                                        sParent=cC.sJumped, sAttrs=['rx','ry','rz', 'sx','sy','sz'], fSize=fSliderScale*0.4, iColorIndex=3)
                cTangent.appendOffsetGroup('pose')
                cTangent.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
                xforms.orientThreePoints(cTangent.sPasser, sEyeJoints[s], aBotTopTangents[p], fAimVector=[0, 0, -fSideMultipl], fUpVector=[fSideMultipl, 0, 0])

                sJoint = cmds.createNode('joint', n='jnt_%s_%sCtrlCorner_%d' % (sSide, sPart, c), p=cTangent.sPasser)
                constraints.matrixParentConstraint(cTangent.sOut, sJoint, sJumpOverTransforms=[cTangent.getOffsetByName('extramove'), cTangent.sPasser])

                utils.matchJointRadius(sJoint, sEyeJoints[s], 0.5)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJoint)

                sRefJoint = cmds.duplicate(sJoint, n='%sRef' % sJoint)[0]
                cmds.parent(sRefJoint, cC.sPasser)
                xforms.matchXform(sJoint, sRefJoint)
                utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, sRefJoint)
                cC.cTangents.append(cTangent)
                cC.sJoints.append(sJoint)
                utils.addStringAttr(sJoint, 'sCtrl', cTangent.sCtrl)


            ccCornerCtrls[s].append(cC)
            ccEyeCtrls[s].append(cC)


        # # aim setup
        # for p, sPart in enumerate(['bot', 'top']):
        #     cRowCtrls = [ccCornerCtrls[s][0].cTangents[p]] + cccBotTopCtrls[s][p] + [ccCornerCtrls[s][-1].cTangents[p]]
        #     for c,cRowCtrl in enumerate(cRowCtrls):
        #         sAutoAimAttr = utils.addAttr(cRowCtrl.sCtrl, ln='aim', min=0, max=1, dv=1, k=True)
        #         if c == 0:
        #             sOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cRowCtrls[1].sSlider, '%s.worldInverseMatrix' % cRowCtrl.sCtrl], bJustValues=True)
        #             sAimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cRowCtrls[1].sCtrl, '%s.worldInverseMatrix' % cRowCtrls[1].sSlider, sOffset])
        #             sAimTarget = nodes.createDecomposeMatrix(sAimMatrix)
        #         elif c == len(cRowCtrls) - 1:
        #             sOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cRowCtrls[-2].sSlider, '%s.worldInverseMatrix' % cRowCtrl.sCtrl], bJustValues=True)
        #             sAimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cRowCtrls[-2].sCtrl, '%s.worldInverseMatrix' % cRowCtrls[-2].sSlider, sOffset])
        #             sAimTarget = nodes.createDecomposeMatrix(sAimMatrix)
        #         else:
        #             sOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cRowCtrls[c-1].sSlider, '%s.worldInverseMatrix' % cRowCtrl.sCtrl], bJustValues=True)
        #             sAimMatrix = nodes.createMultMatrixNode(['%s.matrix' % cRowCtrls[c-1].sSlider, sOffset])
        #             sAimTargetA = nodes.createDecomposeMatrix(sAimMatrix)
        #
        #             sOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cRowCtrls[c+1].sSlider, '%s.worldInverseMatrix' % cRowCtrl.sCtrl], bJustValues=True)
        #             sAimMatrix = nodes.createMultMatrixNode(['%s.matrix' % cRowCtrls[c+1].sCtrl, sOffset])
        #             sAimTargetB = nodes.createDecomposeMatrix(sAimMatrix)
        #
        #             sAimTarget = nodes.createVectorAdditionNode([sAimTargetB, sAimTargetA], sOperation='minus')
        #
        #         sBlendedAimTarget = nodes.createBlendNode(sAutoAimAttr, sAimTarget, cmds.getAttr(sAimTarget)[0], bVector=True)
        #         fOutMatrixBefore = cmds.xform(cRowCtrl.sOut, q=True, m=True, ws=True)
        #         sAimConstraint = constraints.aimConstraintEmpty(cRowCtrl.sOut, aim=[1,0,0], up=[0,0,1])
        #         cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0,0,1)
        #         cmds.connectAttr(sBlendedAimTarget, '%s.target[0].targetTranslate' % sAimConstraint)
        #         constraints.computeAimOffset(sAimConstraint, fOutMatrixBefore)

        # push out sJoints, and deform sBlendingCurves/sCtrlBlendingCurves. To do: calculate in transformGrp's space, so the joint gets rotation (for the offset between joint and cvs)
        sScaleFromTransform = nodes.getScaleFromXform(sEyeTransformJoint)
        for p,sPart in enumerate(['bot','top']):
            fParams = curves.getParamsFromPoints(sMaxBlendingCurves[p], aaPoints[p])
            sJoints = []
            for j,fParam in enumerate(fParams):
                sInfoNode, sInfoPos = curves.createPointInfoNode(sMaxBlendingCurves[p], fParam=fParams[j], sName='eyeSpline_%s_%sPushOutSpline_%03d' % (sSide,sPart,j))
                sJ = cmds.createNode('joint', n='jnt_%s_%sPushOutSpline_%03d' % (sSide, sPart, j), p=sGrp)
                utils.matchJointRadius(sJ, sEyeJoints[s], 0.4)
                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)
                sLength = nodes.createDistanceNode(sLocalPoint, [0, 0, 0])
                sFactor = nodes.createMultiplyNode(cmds.getAttr(sLength), sLength, sOperation='divide', sName='eyeSpline_%s_%sFactor_%03d' % (sSide,sPart,j))
                sFactor = nodes.createConditionNode(sFactor, '>', 1.0, sFactor, 1.0, sName='eyeSpline_%s_%sFactor_%03d' % (sSide,sPart,j))
                sScaledLocalPoint = nodes.createVectorMultiplyNode(sLocalPoint, sFactor, bVectorByScalar=True)
                sWorldPoint = nodes.createPointByMatrixNode(sScaledLocalPoint, '%s.worldMatrix' % cEyeTransform.sOut)
                cmds.connectAttr(sWorldPoint, '%s.t' % sJ)
                cmds.connectAttr(sScaleFromTransform, '%s.s' % sJ)
                sJoints.append(sJ)

            cmds.skinCluster(sBlendingCurves[p], sJoints, n='skinCluster__%s' % sBlendingCurves[p], tsb=True)
            cmds.skinCluster(sCtrlBlendingCurves[p], sJoints, n='skinCluster__%s' % sBlendingCurves[p], tsb=True)

        # positions on sBlendingCurves
        ssCurvePositions = [], []
        ffParams = []
        ssSkinNodes = [], []
        for p,sPart in enumerate(['bot','top']):
            fParams = curves.getParamsFromPoints(sBlendingCurves[p], aaPoints[p])
            for j,fParam in enumerate(fParams):
                sNode, sPos = curves.createPointInfoNode(sBlendingCurves[p], fParam=fParams[j])
                ssCurvePositions[p].append(sPos)
                ssSkinNodes[p].append(sNode)
            ffParams.append(fParams)

        sLivePoleAttr = utils.addAttr(cBlink.sPasser, ln='livePole', min=0, max=1, dv=fLivePole, k=True)

        if bZipper:
            sZipperLeft = utils.addAttr(cBlink.sCtrl, ln='zipperLeft', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
            sZipperFadeLengthLeft = utils.addAttr(cBlink.sCtrl, ln='zipperFadeLeft', defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
            sZipperRight = utils.addAttr(cBlink.sCtrl, ln='zipperRight', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
            sZipperFadeLengthRight = utils.addAttr(cBlink.sCtrl, ln='zipperFadeRight', defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
            sZipperLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sZipperLeft, sZipperFadeLengthLeft), sName='left_zipperByFade')
            sZipperRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sZipperRight, sZipperFadeLengthRight), sName='right_zipperByFade')
            sZipperOvershoot = utils.addAttr(cBlink.sPasser, ln='zipperOvershoot', defaultValue=fOvershootZipper, k=True)
            sZipperMiddleValue = nodes.createAdditionNode([0.5, sZipperOvershoot])

        sCombinedCurves = []
        ssPointsOnCurves = [], []
        ssLocalPointsOnCurves = [], []
        ssEvenTangents = [], []
        for p,sPart in enumerate(['bot','top']):
            sEvenJoints = []

            # create even joints and attach them
            for j,fParam in enumerate(ffParams[p]):
                sJ = cmds.createNode('joint', n='jnt_%s_%sEvenLidSpline_%03d' % (sSide, sPart, j), p=sTransformGrp)
                utils.matchJointRadius(sJ, sEyeJoints[s], 0.36)
                sEvenJoints.append(sJ)
                sInfoPos = ssCurvePositions[p][j]
                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)
                sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0], bConnectJointOrient=False)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)

                jUp = j+1 if j == 0 else j-1
                sWorldTangent = nodes.createVectorAdditionNode([ssCurvePositions[p][jUp], ssCurvePositions[p][j]], sOperation='minus')
                sTangent = nodes.createPointByMatrixNode(sWorldTangent, sTransformJointRotInverseMatrix)
                sTangent = nodes.createBlendNode(sLivePoleAttr, sTangent, cmds.getAttr(sTangent)[0], bVector=True)
                ssEvenTangents[s].append(sTangent)
                cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                cmds.connectAttr(sLocalPoint, '%s.t' % sJ)


            # attach ctrls
            cCtrlCurveNodes = []
            for c,cC in enumerate(cccBotTopCtrls[s][p]):
                sNode, sInfoPos = curves.createPointInfoNode(sBlendingCurves[p], fParam=ffCtrlParams[p][c])
                nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut, sTarget='%s.t' % cC.sPasser)
                cCtrlCurveNodes.append(sNode)
                sAimConstraint = constraints.aimConstraintEmpty(cC.sPasser, aim=[0, 0, -fSideMultipl], up=[fSideMultipl, 0, 0])
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sTransformJointRotInverseMatrix)
                cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)

                if _bSquashed:
                    sInfoNodeSquashed, sInfoPos = curves.createPointInfoNode(sCtrlBlendingCurves[p])#, fParam=ffCtrlParams[p][c])
                    cmds.connectAttr('%s.parameter' % sNode, '%s.parameter' % sInfoNodeSquashed)
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  sTarget='%s.t' % cC.cC.sPasser)
                    sAimConstraint = constraints.aimConstraintEmpty(cC.cC.sPasser, aim=[0, 0, -1], up=[1, 0, 0])
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNodeSquashed, sTransformJointRotInverseMatrix)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)

            # attach corner ctrls
            if p == 0:
                for c,cC in enumerate(ccCornerCtrls[s]):
                    sOffset = xforms.createTransform('grp_%s_eyeLidCtrlConstraint_%d' % (sSide,c), sMatch=cC.sPasser, sParent=sTransformGrp)
                    sInfoNodeSquashed, sInfoPos = curves.createPointInfoNode(sCtrlBlendingCurves[p],
                                                                             fParam=0 if c == 0 else curves.getParamLength(sCtrlBlendingCurves[p]))
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  sTarget='%s.t' % sOffset)
                    sAimConstraint = constraints.aimConstraintEmpty(sOffset, aim=[0, 0, -1], up=[1, 0, 0])
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNodeSquashed, sTransformJointRotInverseMatrix)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                    if _bSquashed:
                        constraints.matrixParentConstraint(sOffset, cC.cC.sPasser, mo=True)



            sCombinedCurve = cmds.duplicate(sBlendingCurves[p], n='curve_%s_%sCombined' % (sSide, sPart))[0]
            cmds.skinCluster(sCombinedCurve, sEvenJoints, n='skinCluster__%s' % sCombinedCurve, tsb=True)
            sCombinedCurves.append(sCombinedCurve)

            # create and attach skin joints
            for j, fParam in enumerate(ffParams[p]):
                _, sInfoPos = curves.createPointInfoNode(sCombinedCurves[p], fParam=ffParams[p][j], sName=f'pointOnCurve_{sPart}_{j:03d}')
                ssPointsOnCurves[p].append(sInfoPos)
                ssLocalPointsOnCurves[p].append(nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut))

        # Spline Joints
        sSkinJoints = []
        for p, sPart in enumerate(['bot', 'top']):
            cmds.setAttr('%s.ty' % cBlink.sCtrl, -1.0)
            aPercsToOther = curves.getPercsFromPoints(sCombinedCurves[1 - p], [cmds.getAttr(sPos)[0] for sPos in ssPointsOnCurves[p]], bReturnNumpy=True)
            aPercsAtOther = curves.getPercsFromPoints(sCombinedCurves[1 - p], [cmds.getAttr(sPos)[0] for sPos in ssPointsOnCurves[1-p]], bReturnNumpy=True)
            xOtherJointWeightings = xforms.getCtrlWeightings(aPercsToOther, aPercsAtOther)
            cmds.setAttr('%s.ty' % cBlink.sCtrl, 0.0)


            fLeftPercs = utils.bSpline4([0, 0, 1, 1], aValues=aPercsToOther)
            fRightPercs = 1.0 - fLeftPercs

            for j, fParam in enumerate(ffParams[p]):
                if p == 0 and j in [0, len(ffParams[p]) - 1]:
                    continue
                sRowJoints = []
                iExtraRows = [iExtraRowsBot, iExtraRowsTop][p]
                for row in range(iExtraRows + 1):
                    sRowPrefix = '' if row == 0 else utils.getLetter(row - 1)
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSkinLidSpline%s_%03d' % (sSide, sPart, sRowPrefix, j), p=sTransformJoint)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.8 if row == 0 else 0.4)
                    sSkinJoints.append(sJ)

                    cmds.setAttr('%s.useObjectColor' % sJ, True)
                    cmds.setAttr('%s.objectColor' % sJ, (j + row) % 8)

                    sRowJoints.append(sJ)
                    sssAllJoints[s][p].append(sJ)
                    if row == 0:
                        # on main row we take ssLocalPointsOnCurves and apply zipper
                        if bZipper:
                            cmds.setAttr('%s.ty' % cBlink.sCtrl, -1.0)
                            sLeftRightZippers = cmds.createNode('plusMinusAverage', n='plus_sumZippers_%03d' % j)

                            sEndLeft = nodes.createAdditionNode([fLeftPercs[j], sZipperFadeLengthLeft], sName='left_zipperFadeLength_%03d' % j)
                            sRangeLeft = nodes.createRangeNode(sZipperLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0, sName='left_zipper_%03d' % j)
                            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

                            sEndRight = nodes.createAdditionNode([fRightPercs[j], sZipperFadeLengthRight], sName='right_zipperFadeLength_%03d' % j)
                            sRangeRight = nodes.createRangeNode(sZipperRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='right_zipper_%03d' % j)
                            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

                            sClamp = nodes.createClampNode('%s.output1D' % sLeftRightZippers, 0, 1, sName='lidZipper_%s_%03d' % (sPart,j))
                            sJointBlendStrength = nodes.createMultiplyNode(sClamp, sZipperMiddleValue, sName='lidZipper_%s_%03d' % (sPart,j))

                            iJoint0, iJoint1, fBlend = xOtherJointWeightings[j]
                            sOtherPos = nodes.createBlendNode(fBlend, ssLocalPointsOnCurves[1-p][iJoint1],
                                                                      ssLocalPointsOnCurves[1-p][iJoint0], bVector=True, sName='lidZipperOppositePoint_%s_%03d_' % (sPart,j))
                            sZipperPos = nodes.createBlendNode(sJointBlendStrength, sOtherPos, ssLocalPointsOnCurves[p][j], bVector=True, sName='lidZipperFinal_%s_%03d_' % (sPart,j))
                            cmds.setAttr('%s.ty' % cBlink.sCtrl, 0.0)
                        else:
                            sZipperPos = ssLocalPointsOnCurves[p][j]

                        sLocalPoint = sZipperPos
                        sLocalPointMain = sLocalPoint
                    else:
                        fBlend = 1.0 - row / (iExtraRows + 1)
                        sBlendAttr = utils.addAttr(sJ, ln='blend', min=0, max=1, k=True, dv=fBlend)
                        sLocalPoint = nodes.createBlendNode(sBlendAttr, sLocalPointMain, cmds.getAttr(sLocalPointMain)[0], bVector=True)

                    # push out again
                    sLength = nodes.createDistanceNode(sLocalPoint, [0, 0, 0])
                    sFactor = nodes.createMultiplyNode(cmds.getAttr(sLength), sLength, sOperation='divide')

                    if bLidsCanPushOut:
                        sFactor = nodes.createConditionNode(sFactor, '>', 1.0, sFactor, 1.0)

                    sLocalPoint = nodes.createVectorMultiplyNode(sLocalPoint, sFactor, bVectorByScalar=True)

                    aLocalOffset = aaLocalPoints[p][j] - np.array(cmds.getAttr(sLocalPoint)[0], dtype='float64')
                    sLocalPoint = nodes.createVectorAdditionNode([sLocalPoint, aLocalOffset])

                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0], bConnectJointOrient=False)
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)


                    print ('p: ', p)
                    print ('j: ', j)
                    print ('len:' , len(ssEvenTangents[s]))
                    cmds.connectAttr(ssEvenTangents[s][j], '%s.worldUpVector' % sAimConstraint)

                    cmds.connectAttr(sLocalPoint, '%s.t' % sJ)

                if iExtraRows > 0:
                    print ('sRowJoints: ', sRowJoints)
                    utils.addStringAttr(sRowJoints[0], 'sRowJoints', str(sRowJoints[1:]), bLock=True)


             # reference matrix:
            if bSeparateSkinCluster:
                for sJ in sSkinJoints:
                    fLocalMatrix = nodes.createMultMatrixNode(
                        ['%s.worldMatrix' % sJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                    sRefMatrix = nodes.createMultMatrixNode([fLocalMatrix, '%s.worldMatrix' % sParentJoint])
                    sRevInvMatrix = nodes.createInverseMatrix(sRefMatrix)
                    utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRevInvMatrix)



        sCtrlSkinClusters = [] #bot/top
        for p,sPart in enumerate(['bot','top']):
            sCtrlJoints = [ccCornerCtrls[s][0].sJoints[p]] + [cC.sJoint for cC in cccBotTopCtrls[s][p]] + [ccCornerCtrls[s][1].sJoints[p]]
            pCombinedCurve = patch.patchFromName(sCombinedCurves[p])
            sCtrlSkinCluster = deformers.skinMesh(sCombinedCurves[p], sCtrlJoints,
                                                  bAlwaysCreateManually=True, bAlwaysAddDefaultWeights=True,
                                                  sName='skinCluster__%s__CTRLS' % (sCombinedCurves[p]), _bSkipDeformerAdjustLogging=True)
            weights.skinCurveBSpline4(pCombinedCurve, sCtrlJoints,
                                      sChooseSkinCluster=sCtrlSkinCluster, bStrongEnds=False, #bStrongEnds used to be True but then some ctrls where not bound at all on low res curves
                                      iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)

            pCombinedCurveSmooth = patch.patchFromName(pCombinedCurve.getTransformName())
            pCombinedCurveSmooth.aIds = pCombinedCurveSmooth.aIds[1:-1]
            weights.smoothSkinWeights(pCombinedCurveSmooth, iIterations=iCtrlSmoothIterations, sChooseSkinCluster=sCtrlSkinCluster, _bSkipDeformerAdjustLogging=True)
            # weights.reduceInfluences(pCombinedCurve, iMaxInfluences=2, sChooseSkinCluster=sCtrlSkinCluster, _bSkipDeformerAdjustLogging=True)

            sCtrlSkinClusters.append(sCtrlSkinCluster)
        
        # bottom lid follow top controls on blink
        cmds.setAttr('%s.ty' % cBlink.sCtrl, -1)
        sTopToBotSkinCluster = weights.transferSkinCluster(patch.patchFromName(sCombinedCurves[0]), sFrom=sCtrlSkinClusters[1],
                                                           bAutoCreateNewSkinCluster='%s_otherside' % sSide, _bSkipDeformerAdjustLogging=True)[0]
        cmds.setAttr('%s.ty' % cBlink.sCtrl, 0)
        sBotFollowTopCtrlsAttr = utils.addAttr(cBlink.sCtrl, ln='botFollowTopCtrlsOnBlink', min=0, max=1, dv=0, k=True)
        nodes.createMultiplyNode(sBotFollowTopCtrlsAttr, sBlink, sTarget='%s.envelope' % sTopToBotSkinCluster)

        # pick walk
        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, cEyeTransform.sCtrl, parent=True)

    createSplineLidsPosesSetup(dPoses)

    deformers.setCurrentReferencePose(utils.flattenedList(sssAllJoints))


#EXCLUDE END LIDSPLINES


kSplineLidCorrectivePrefix = 'splineLidCorrective'
kSplineLideCorrectiveSep = 'X'

@builderTools.addToBuild(iOrder=63.5, dButtons=dButtons, bDisableByDefault=True)
def applySplineLidCorrectives(sModel=None):
    if sModel:
        sModel = utils.toList(sModel)[0]
    else:
        raise Exception('no model given')

    sCorrectives = cmds.ls('%s*' % kSplineLidCorrectivePrefix, et='transform')

    xxCorrs = [[], []]
    for sCorr in sCorrectives:
        report.report.addLogText('"%s"...' % sCorr)

        sBotTopSplits = sCorr.split(kSplineLideCorrectiveSep)[-2:]
        for p,sPart in enumerate(['bot','top']):
            if sBotTopSplits[p]:
                print ('sBotTopSplits[p]: ', sBotTopSplits[p])
                if sBotTopSplits[p].startswith('n'):
                    iValue = -int(sBotTopSplits[p][1:])
                else:
                    iValue = int(sBotTopSplits[p])
                fValue = iValue * 0.01
                bBoth = True if sBotTopSplits[1-p] else False
                xxCorrs[p].append((sCorr, fValue, bBoth))



    for p,sPart in enumerate(['bot','top']):
        print ('\n\n\n PART: ', sPart)
        xCorrsSorted = sorted(xxCorrs[p], key=lambda x:x[1])

        for x,xCorr in enumerate(xCorrsSorted):
            sCorr, fValue, bBoth = xCorr
            if p == 1 and bBoth:
                continue
            fBothValues = [None, None]
            fBothValues[p] = fValue
            if p == 0 and bBoth:
                for xOppCorr in xxCorrs[1]:
                    sOppCorr, fOppValue, _ = xOppCorr
                    if sCorr == sOppCorr:
                        fBothValues[1] = fOppValue

            ffLidRanges = [[], []]

            for pp,fV in enumerate(fBothValues):
                if fV == None:
                    continue
                fRange = [None, fV, None]
                if fV > 0.9999:
                    fFloorValue = 0.0
                else:
                    fFloorValue = math.floor(fV)
                fCeilValue = math.ceil(fV)


                if x > 0:
                    fRange[0] = xCorrsSorted[x-1][1]
                    if fV > 0.0 and fRange[0] < 0.0:
                        fRange[0] = 0.0
                else:
                    fRange[0] = fFloorValue
                if fRange[0] == fRange[1]:
                    fRange[0] = None
                print ('x: ', x, 'xCorrsSorted: ', xCorrsSorted)
                if x < len(xCorrsSorted)-1:
                    fRange[2] = xCorrsSorted[x+1][1]

                    if fV < 0.0 and fRange[2] > 0.0:
                        fRange[2] = 0.0
                else:
                    if fRange[1] == -1:
                        fRange[2] = 0
                    else:
                        fRange[2] = fCeilValue
                if fRange[2] == fRange[1]:
                    fRange[2] = None


                if fRange[0] == None and fRange[2] == None:
                    continue
                    # raise Exception('Something wrong with the algorithm.. both ends are None')

                ffLidRanges[pp] = fRange

            
            report.report.addLogText('==== sCorr: %s, ffLidRanges, %s' % (sCorr, ffLidRanges))

            sSecondaryModels = [sO.split('__')[0] for sO in cmds.ls('*__%s' % sCorr)]
            connectTargets(sModel, sCorr, ffLidRanges=ffLidRanges, iInvert=2, sSecondaryModels=sSecondaryModels, bControlRigCommands=True)
            # if bMakeNotExportWeights:
            #     deformers.makeBlendShapesNoExport([sModel]+sSecondaryModels)


@builderTools.addToBuild(iOrder=51, dButtons={}, bDisableByDefault=True)
def eyeLatticeCtrls(sLeftMeshes=[], sRightMeshes=[], sSkinMeshes=[], fScale=[1.0, 1.0, 1.0], fTranslate=[0,0,0], fEye_l_ctrl_defaultR=[0,0,0]):
    '''
    To place/scale the controls/lattice, set the fScale and fTranslate values. To find those values, just translate/scale the lattice boxes around and record their values
    '''
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]

    if not sLeftMeshes and not sRightMeshes:
        raise Exception('need to specify meshes (sLeftMeshes, sRightMeshes, sSkinMeshes)')

    ssEyeMeshes = [sLeftMeshes, sRightMeshes]

    sGrp = cmds.createNode('transform', n='grp_eyeLatticeSetup', p='modules')


    for s,sSide in enumerate(['l','r']):
        fEyeLength = abs(cmds.getAttr('%s.tx' % ssEyeJoints[s][1]))
        sEyeCtrl = ctrls8.ctrlFromName('eye%s_ctrl' % utils.sSides3[s]).sCtrl
        cEyeTransform = ctrls8.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])

        sTempMatchTransform = cmds.createNode('transform')
        cmds.delete(cmds.orientConstraint(cEyeTransform.sCtrl, sTempMatchTransform))

        # if not bLegacyOrient:
        sConstrDelete = cmds.parentConstraint(sEyeCtrl, sTempMatchTransform, mo=True)

        cmds.setAttr('%s.r' % sEyeCtrl, *fEye_l_ctrl_defaultR)

        # if not bLegacyOrient:
        cmds.delete(sConstrDelete)


        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        for m, sMesh in enumerate(ssEyeMeshes[s]+sSkinMeshes):
            # sName = 'lattice_%s_eyeball' % sSide
            sLatDeformer = 'lattice__%s__%s_EYE' % (sMesh, sSide)
            if m == 0:
                if cmds.objExists(sLatDeformer):
                    sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                    sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                else:
                    sLatDeformer, sLat, sLatBase = cmds.lattice(sMesh, n=sLatDeformer)

                cmds.setAttr('%s.sDivisions' % sLat, 2)
                cmds.setAttr('%s.tDivisions' % sLat, 3)
                cmds.setAttr('%s.uDivisions' % sLat, 2)
                cmds.setAttr('%s.localInfluenceS' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceT' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceU' % sLatDeformer, 2)

                sParent = cmds.createNode('transform', n='grp_%s_eyeLattice' % sSide, p=sGrp)
                sScaleParent = cmds.createNode('transform', n='grp_%s_eyeLatticeScale' % sSide, p=sParent)
                cmds.parent(sLat, sLatBase, sScaleParent)
                cmds.setAttr('%s.s' % sLat, fScale[0], fScale[1], fScale[2])
                cmds.setAttr('%s.s' % sLatBase, fScale[0], fScale[1], fScale[2])
                cmds.setAttr('%s.t' % sLat, fTranslate[0], fTranslate[1], fTranslate[2])
                cmds.setAttr('%s.t' % sLatBase, fTranslate[0], fTranslate[1], fTranslate[2])

            else:
                # sLatDeformer, _sLat, _sLatBase = cmds.lattice(sMesh)#, divisions=(2, 3, 2), ldv=(2, 2, 2))
                if cmds.objExists(sLatDeformer):
                    _sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                    _sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                else:
                    sLatDeformer, _sLat, _sLatBase = cmds.lattice(sMesh, n=sLatDeformer)
                cmds.setAttr('%s.localInfluenceS' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceT' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceU' % sLatDeformer, 2)
                cmds.connectAttr('%sShape.latticeOutput' % sLat, '%s.deformedLatticePoints' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLat, '%s.deformedLatticeMatrix' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLatBase, '%s.baseLatticeMatrix' % sLatDeformer, f=True)
                cmds.delete(_sLat, _sLatBase)

            cmds.setAttr('%s.outsideLattice' % sLatDeformer, 1)

            # if it's a mesh per side, we more likely won't need to paint weights
            if sMesh not in sSkinMeshes:
                if sMesh not in ssEyeMeshes[1-s]:
                    deformers.makeNotExport(sLatDeformer)

        cmds.delete(cmds.parentConstraint(ssEyeJoints[s][0], sParent))
        cmds.setAttr('%s.sx' % sParent, fSideMultipl)
        cmds.setAttr('%s.sy' % sParent, fSideMultipl)
        constraints.matrixParentConstraint(cEyeTransform.sOut, sParent, mo=True)
        fParentScale = fEyeLength * 2.0
        cmds.setAttr('%s.s' % sScaleParent, fParentScale, fParentScale, fParentScale*fSideMultipl)

        sJoints = []
        sOrigin = xforms.createTransform('grp_%s_latticeOrigin' % sSide, sMatch=cEyeTransform.sPasser, sParent=sGrp)

        xLatticePointData = [['bot', ('pt[0:1][0][0]', 'pt[0:1][0][1]'), ('pt[1][0][0:1]',)],
                            ['top', ('pt[0:1][2][0]', 'pt[0:1][2][1]'), ('pt[1][2][0:1]',)],
                            ['in', ('pt[0:1][1][1]',), ('pt[1][1][1]',)],
                            ['out', ('pt[0:1][1][0]',), ('pt[1][1][0]',)]]
        dJoints = {}
        dCtrls = {}
        for sName, sPoints, sCtrlPoints in xLatticePointData:
            aCtrlPos = np.average(np.array(cmds.xform(['%s.%s' % (sLat,sP) for sP in sCtrlPoints], q=True, ws=True, t=True)).reshape(-1,3), axis=0)
            cmds.setAttr('%s.t' % sTempMatchTransform, *list(aCtrlPos))
            cC = ctrls8.create(sName='%sEyeLattice' % sName, sSide=sSide, sParent=_getFaceCtrlGrp(), sMatch=sTempMatchTransform,
                              sAttrs=['t','r','sx'] if sName in ['bot','top'] else ['t','r'],
                              fRotateShape=(0, 0, 0) if sName in ['bot','top'] else (0,0,-90),
                              iColorIndex=1, fSliderScale=fEyeLength,
                              sShape='triangle', fSize=0.5)
            cC.createExtraMoveTransformAndTag(['skinCluster__*face*__TWEAKER', 'skinCluster__*face*__BEND'])
            if sName == 'bot':
                cmds.setAttr('%s.sy' % cC.sSlider, cmds.getAttr('%s.sy' % cC.sSlider) * -1.0)
                cmds.setAttr('%s.sy' % cC.sOut, cmds.getAttr('%s.sy' % cC.sOut) / -1.0)
            if sName == 'out':
                cmds.setAttr('%s.sx' % cC.sSlider, cmds.getAttr('%s.sx' % cC.sSlider) * -1.0)
                cmds.setAttr('%s.sx' % cC.sOut, cmds.getAttr('%s.sx' % cC.sOut) / -1.0)
            
            constraints.matrixParentConstraint(cEyeTransform.sCtrl, cC.sPasser, mo=True, skipTranslate=['x','y','z'] if sName in ['in', 'out'] else [])
            sJ = cmds.createNode('joint', n='jnt_%s_%sEyelattice' % (sSide,sName), p=sOrigin)
            cmds.setAttr('%s.radius' % sJ, fEyeLength*0.1)
            # cmds.setAttr('%s.v' % sJ, False)


            sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut,
                                                  '%s.worldInverseMatrix' % cC.getOffsetByName('extramove'),
                                                  '%s.worldMatrix' % cC.sPasser,
                                                  '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  ])
            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ)
            # nodes.transformInLocalSpace(cC.sOut, cEyeTransform.sOut, sJ)

            sJoints.append(sJ)
            dJoints[sName] = sJ
            dCtrls[sName] = cC

            if sName in ['in', 'out']:
                sPoints = []
                for sPart in ['bot','top']:
                    cPart = dCtrls[sPart]
                    sPoint = xforms.createTransform('grp_%s_%sConstr%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)), sParent=cPart.sOut, sMatch=cC.sOut)
                    cmds.setAttr('%s.ty' % sPoint, 0.0)
                    cmds.parent(sPoint, cPart.sPasser)
                    constraints.matrixParentConstraint(cPart.sOut, sPoint, mo=True, sJumpOverTransforms=[cPart.getOffsetByName('extramove'), cPart.sPasser])
                    sPoints.append(sPoint)

                cmds.pointConstraint(sPoints[0], sPoints[1], cC.sPasser)

        sSkinCluster = cmds.skinCluster(sLat, sJoints, tsb=True, maximumInfluences=1)[0]
        for sName, sPoints, sCtrlPoints in xLatticePointData:
            cmds.skinPercent(sSkinCluster, ['%s.%s' % (sLat,sP) for sP in sPoints], transformValue=[dJoints[sName], 1])

        cmds.delete(sTempMatchTransform)
        cmds.setAttr('%s.r' % sEyeCtrl, 0,0,0)





dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def recordSiblings(_bLeftAndRight=False, _uiArgs=None):

    dPoses = {}
    sSiblings = [sT for sT in cmds.listRelatives('jnt_l_eyeLidParent', c=True) if sT.startswith('grp_l_sibling') or sT.startswith('l_sibling')]

    if _bLeftAndRight:
        sSiblings += [sT for sT in cmds.listRelatives('jnt_r_eyeLidParent', c=True) if sT.startswith('grp_r_sibling') or sT.startswith('r_sibling')]

    print('sSiblings: ',sSiblings)
    for sT in sSiblings:
        sPrintT = sT
        if sPrintT.endswith('_Grp'):
            sPrintT = 'grp_%s' % sPrintT[:-4]
        for sA in ['t','r','s']:
            sAttr = '%s.%s' % (sT,sA)
            sPrintAttr = '%s.%s' % (sPrintT,sA)
            dPoses[sPrintAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dSiblingPoses'].setText(str(dPoses))


def recordSiblingsLeft(_uiArgs=None):
    recordSiblings(False, _uiArgs)
def recordSiblingsLeftAndRight(_uiArgs=None):
    recordSiblings(True, _uiArgs)

def selectSiblings(_uiArgs=None):
    sSiblings = [sT for sT in cmds.listRelatives('jnt_l_eyeLidParent', c=True) if sT.startswith('grp_l_sibling') or sT.startswith('l_sibling')]
    cmds.select(sSiblings)


kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill sibling poses (just left)'] = recordSiblingsLeft
dButtons['fill sibling poses (left and right)'] = recordSiblingsLeftAndRight
dButtons['select left sibling transforms'] = selectSiblings



def _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bLattice, fScaleTheScale):
    utils.data.store('bLatticeEyes', bLattice)
    # utils.data.store('bScaleSquash', bScaleSquash)

    ssLattices = [None, None], [None, None]
    if not bLattice:
        fEyeballSquashValues = cmds.getAttr('%s.s' % ssMeshes[0][0])[0]
        fEyeballSquashValues = [abs(fEyeballSquashValues[0]), abs(fEyeballSquashValues[1]), abs(fEyeballSquashValues[2])]
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]
    sNurbsSpheres = []
    for s,sSide in enumerate(['l','r']):
        sSphere = cmds.sphere(n='nurbs_%s_eyeRigSphere' % sSide, r=cmds.getAttr('%s.tx' % ssEyeJoints[s][1]))[0]
        cmds.delete(cmds.parentConstraint(ssEyeJoints[s][0], sSphere))
        ssMeshes[s].append(sSphere)
        sNurbsSpheres.append(sSphere)
        sSkinCluster = cmds.skinCluster(sSphere, ssEyeJoints[s][0], tsb=True)
        deformers.makeNotExport(sSkinCluster)

    cmds.parent(sNurbsSpheres, 'modules')
    if bLattice:
        sLatticeDeformers = []
        for s,sSide in enumerate(['l','r']):
            for sM in ssMeshes[s]:
                sDefs = deformers.listAllDeformers(sM, sFilterTypes=['ffd'], bSkipGeoTest=True)
                sLatticeDeformers += sDefs
                for sD in sDefs:
                    sLatticeConn = cmds.listConnections(sD, t='lattice', s=True, d=False)
                    if sLatticeConn:
                        ssLattices[s][0] = sLatticeConn[0]
                    sBaseLatticeConn = cmds.listConnections(sD, t='baseLattice', s=True, d=False)
                    if sBaseLatticeConn:
                        ssLattices[s][1] = sBaseLatticeConn[0]

                    sConns = cmds.listConnections(sD, t='lattice', s=True, d=False, c=True, p=True) or []
                    sConns += cmds.listConnections(sD, t='baseLattice', s=True, d=False, c=True, p=True) or []
                    print('sConns: ', sConns)
                    for i in range(0, len(sConns), 2):
                        cmds.disconnectAttr(sConns[i+1], sConns[i])

        if sLatticeDeformers:
            cmds.delete(sLatticeDeformers)


    utils.data.store('ssEyeLattices', ssLattices)
    utils.data.store('ssEyeMeshes', ssMeshes)
    sSuffix = ''
    for s, sSide in enumerate(['l', 'r']):

        cEyeCtrl = ctrls8.ctrlFromName('eye%s_ctrl' % utils.sSides3[s])
        cEyeTransform = ctrls8.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])


        if not bLattice:
            for sM in ssMeshes[s]:
                fValues = cmds.getAttr('%s.s' % sM)[0]
                fSquashToOne = fValues[0]/fEyeballSquashValues[0], fValues[1]/fEyeballSquashValues[1], fValues[2]/fEyeballSquashValues[2]
                if sM not in sNurbsSpheres:
                    cmds.setAttr('%s.s' % sM, *fSquashToOne)

        if bLattice:
            sLatticeGrp = cmds.createNode('transform', n='grp_%s_latticeGrp' % sSide, p='modules')
            constraints.matrixParentConstraint(cEyeTransform.sOut, sLatticeGrp)
            print ('ssLattices: ', ssLattices)
            cmds.parent(ssLattices[s], sLatticeGrp)
            cmds.select(sLatticeGrp)

        else: # used to be bSquashedEyeballs
            sEyeballSquashAttrs = [utils.addAttr(cEyeTransform.sPasser, ln='squashX', defaultValue=fEyeballSquashValues[2], k=True),
                                  utils.addAttr(cEyeTransform.sPasser, ln='squashY', defaultValue=fEyeballSquashValues[1], k=True),
                                  utils.addAttr(cEyeTransform.sPasser, ln='squashZ', defaultValue=fEyeballSquashValues[0], k=True)]
            sEyeballSquashSwitch = utils.addAttr(cEyeTransform.sPasser, ln='squashSwitch', defaultValue=0.0, k=True, min=0, max=1)
            sEyeballSquashScaleTheScale = utils.addAttr(cEyeTransform.sPasser, ln='squashExtra', defaultValue=fScaleTheScale, k=True)
            sDiff = nodes.createVectorAdditionNode([sEyeballSquashAttrs, [1,1,1]], sOperation='minus')
            sMultipl = nodes.createVectorMultiplyNode(sDiff, sEyeballSquashScaleTheScale, bVectorByScalar=True)
            sEyeballSquashAdded = nodes.createVectorAdditionNode([sMultipl, [1,1,1]])
            
            sEyeballSquash = nodes.createBlendNode(sEyeballSquashSwitch, sEyeballSquashAdded, [1,1,1], bVector=True)
            sSquashGrp = xforms.insertParent(ssEyeJoints[s][0], sName='grp_%s_eyeSquash' % sSide)
            nodes.deleteConnection('%s.s' % ssEyeJoints[s][0])
            nodes.deleteConnection('%s.r' % ssEyeJoints[s][0])


            cmds.connectAttr(sEyeballSquash, '%s.s' % sSquashGrp)
            sEyeInPasser = cmds.createNode('transform', n='grp_%s_eyeInPasser' % sSide, p='grp_%s_eyeTransformPasser' % sSide)
            constraints.matrixParentConstraint(cEyeCtrl.sOut, sEyeInPasser)
            cmds.connectAttr('%s.r' % sEyeInPasser, '%s.r' % ssEyeJoints[s][0])



@builderTools.addToBuild(iOrder=24.2, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def simpleLidSetup(sParentJoint='jnt_m_headMain', dSiblingPoses={}, sLeftMeshes=[], sRightMeshes=[], bModelHasLattice=False, fScaleTheScale=1.0):
    '''
    for the behavior of the joints towards the controls, adjust the sibling groups. They are in the same
    parents as the eyelid joints (select button "select blink joints" to find them)

    Adjust the left side, and he'll mirror the right side for you
    '''

    ssMeshes = [sLeftMeshes, sRightMeshes]

    if ssMeshes[0] or ssMeshes[1]:
        _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bModelHasLattice, fScaleTheScale)
    sEyeLimbNames = ['l_eye', 'r_eye']
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]
    sEyeTransformJoints = ['jnt_l_eyeTransform', 'jnt_r_eyeTransform']
    sSuffix = ''
    for s,sSide in enumerate(['l','r']):
        fMainRadius = cmds.getAttr('%s.radius' % ssEyeJoints[s][0])
        sParent = xforms.createJoint('jnt_%s_eyeLidParent' % sSide, sParent=sParentJoint, sMatch=sEyeTransformJoints[s], fSize=fMainRadius*1.5)
        cmds.setAttr('%s.segmentScaleCompensate' % sParent, False)
        constraints.matrixParentConstraint(sEyeTransformJoints[s], sParent)

        # aJointPositions = xforms.getPositionArray(ssEyeJoints[s])

        cBlink = ctrls8.ctrlFromName('blink%s%s_ctrl' % (sSuffix, utils.sSides3[s]))
        cExtraBlinks = [ctrls8.ctrlFromName('lidBot%s%s_ctrl' % (sSuffix, utils.sSides3[s])),
                        ctrls8.ctrlFromName('lidTop%s%s_ctrl' % (sSuffix, utils.sSides3[s]))]
        cAim = ctrls8.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s], bReturnNoneIfNotExists=True)
        if not cAim:
            cAim = ctrls8.ctrlFromName('eyeLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)


        # cmds.setAttr('%s.s' % cBlink.sSlider, fSideMultipl,  fSideMultipl, fSideMultipl)
        cmds.controller(cBlink.sCtrl, headCtrl(), parent=True)

        sBlinkJoints = [xforms.createJoint('jnt_%s_eyeBlinkBot' % sSide, sMatch=ssEyeJoints[s][0], sParent=sParent, fSize=fMainRadius*2.0),
                        xforms.createJoint('jnt_%s_eyeBlinkTop' % sSide, sMatch=ssEyeJoints[s][0], sParent=sParent, fSize=fMainRadius*2.0)]


        sEyeOpen = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0,-1, 1, 0)


        sLookVert = '%s.lookVert' % cAim.sPasser
        sSwitchedLookY = nodes.createMultiplyArrayNode([sLookVert, 0.5, sEyeOpen])

        for p,sPart in enumerate(['bot','top']):
            sSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingWideMain = cmds.createNode('transform', n='grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingExtraDown = cmds.createNode('transform', n='grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingExtraUp = cmds.createNode('transform', n='grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)

            # sSiblingFollowDown = cmds.createNode('transform', n='grp_%s_siblingFollowDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            # sSiblingFollowUp = cmds.createNode('transform', n='grp_%s_siblingFollowUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)

            # default attributes..
            if p == 0:
                cmds.setAttr('%s.rz' % sSiblingBlinkMain, 30)
                cmds.setAttr('%s.rz' % sSiblingWideMain, -5)
            else:
                cmds.setAttr('%s.rz' % sSiblingBlinkMain, -30)
                cmds.setAttr('%s.rz' % sSiblingWideMain, 10)
            cmds.setAttr('%s.rz' % sSiblingExtraDown, -30)
            cmds.setAttr('%s.rz' % sSiblingExtraUp, 30)
            # cmds.setAttr('%s.rz' % sSiblingFollowDown, -30)
            # cmds.setAttr('%s.rz' % sSiblingFollowUp, 30)

            for sA in ['t','r','s']:
                fDefault = [1,1,1] if sA == 's' else [0,0,0]
                sBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sSiblingBlinkMain, sA), bOutRangeIsVector=True)
                sBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sSiblingWideMain, sA), bOutRangeIsVector=True)
                sBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                sBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)

                sBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                sBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)

                if sA in ['t','r']:
                    nodes.createVectorAdditionNode([sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp], sTarget='%s.%s' % (sBlinkJoints[p], sA))
                else:
                    nodes.createMultiplyArrayNode([sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp], bVector=True, sTarget='%s.%s' % (sBlinkJoints[p], sA))


    for sAttr, fValues in list(dSiblingPoses.items()):
        cmds.setAttr(sAttr, *fValues)
        if utils.getSide(sAttr) == 'l':
            sAttrRight = utils.getMirrorName(sAttr)
            if sAttrRight not in dSiblingPoses:
                if sAttr.endswith('.t'):
                    cmds.setAttr(sAttrRight, -fValues[0], -fValues[1], -fValues[2])
                else:
                    cmds.setAttr(sAttrRight, *fValues)




@builderTools.addToBuild(iOrder=50.1, dButtons={})
def activateEyeSQUASHED():
    if cmds.objExists('grp_l_eyeTransformPasser.squashSwitch'):
        cmds.setAttr('grp_l_eyeTransformPasser.squashSwitch', 1.0)
    if cmds.objExists('grp_r_eyeTransformPasser.squashSwitch'):
        cmds.setAttr('grp_r_eyeTransformPasser.squashSwitch', 1.0)


    if utils.data.get('bLatticeEyes') == True:
        ssLattices = utils.data.get('ssEyeLattices')
        ssEyeMeshes = utils.data.get('ssEyeMeshes')
        for s,sSide in enumerate(['l','t']):
            for sM in ssEyeMeshes[s]:
                sLattice, sBaseLattice = ssLattices[s]
                sLatDeformer, _sLat, _sLatBase = cmds.lattice(sM, divisions=(2, 3, 2), ldv=(2, 2, 2))
                cmds.connectAttr('%sShape.latticeOutput' % sLattice, '%s.deformedLatticePoints' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLattice, '%s.deformedLatticeMatrix' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sBaseLattice, '%s.baseLatticeMatrix' % sLatDeformer, f=True)
                cmds.setAttr('%s.outsideLattice' % sLatDeformer, 1)
                cmds.delete(_sLat, _sLatBase)
                deformers.makeNotExport(sLatDeformer)

dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls8.exportSliderBps



@builderTools.addToBuild(iOrder=89, dButtons=dButtons)
def parallelAttachTransforms(sDefaultAttachMesh=[], sScaleJoint='jnt_m_headMain', bReorderDeformers=True, bIgnoreBrowSplits=True):
    sSelBefore = cmds.ls(sl=True)
    if sDefaultAttachMesh:
        sDefaultAttachMesh = utils.toList(sDefaultAttachMesh)[0]
    else:
        sDefaultAttachMesh = None
    utils.reload2(ctrls8)
    ctrls8.parallelAttachTransforms(sDefaultAttachMesh, sScaleJoint, bReorderDeformers=bReorderDeformers, bIgnoreBrowSplits=bIgnoreBrowSplits)
    cmds.select(sSelBefore)


# dButtons = {}
kLashesBpGrp = '_grp_m_lashesBps'
kLashesBpFileName = 'faceBlueprintsLashes.ma'


def recordLashesSiblings(_uiArgs=None):
    sSiblings = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.lashesSibling' % sT) and '_l_' in sT]
    dPoses = {}
    for sT in sSiblings:
        for sA in ['t','r','s']:
            sAttr = '%s.%s' % (sT,sA)
            dPoses[sAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dSiblingPoses'].setText(str(dPoses))


def recordLashesSiblingsRef(_uiArgs=None):
    sSiblings = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.lashesSiblingRef' % sT) and '_l_' in sT]
    dPoses = {}
    for sT in sSiblings:
        for sA in ['t','r']:
            sAttr = '%s.%s' % (sT,sA)
            dPoses[sAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dRefSiblingPoses'].setText(str(dPoses))



def bindLashes():
    sSelBefore = cmds.ls(sl=True)
    sJoints = [sJ for sJ in cmds.ls('jnt_?_lashesBot_*', et='joint') if not sJ.endswith('_ref')]
    sJoints += [sJ for sJ in cmds.ls('jnt_?_lashesTop_*', et='joint') if not sJ.endswith('_ref')]
    sMeshes = cmds.ls(sl=True)
    for sMesh in sMeshes:
        sSkinCluster = 'skinCluster__%s' % sMesh

        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sName=sSkinCluster,
                               sInfluences=sJoints,
                               bAlwaysAddDefaultWeights=True)
            deformers.reorderDeformer(sSkinCluster, ['skinCluster__%s__POST' % sMesh], sMesh)

        else:
            deformers.addInfluences(sSkinCluster, sJoints)


    if sSelBefore:
        cmds.select(sSelBefore)


def generateNewLashesPose():
    cBlink = ctrls8.ctrlFromName('blink_l_ctrl')
    iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % cBlink.sPasser) * 100),
                int(cmds.getAttr('%s.blendCurveTop' % cBlink.sPasser) * 100)]

    dSiblings = getLashesPosesInfo()
    for p,sPart in enumerate(['bot','top']):
        dAttrValues = {}
        for sName in ['inner', 'mid', 'outer']:
            sPoseGrp = f'grp_l_{sName}Lashes{sPart.title()}OffsetPose'
            dAttrValues[sName] = [cmds.getAttr('%s.t' % sPoseGrp)[0],
                                  cmds.getAttr('%s.r' % sPoseGrp)[0],
                                  cmds.getAttr('%s.s' % sPoseGrp)[0]]
        dSiblings[f'{sPart}.{iBotTops[p]}'] = dAttrValues

    createLashesPosesSetup(dSiblings)



def createLashesPosesSetup(dPoses, _bBlendLastToZero=False):

    dPoses['bot.000'] = {}
    dPoses['top.000'] = {}

    sNames = ['inner', 'mid', 'outer']
    dTranslates = defaultdict(list)
    dRotates = defaultdict(list)
    dScales = defaultdict(list)

    for s,sSide in enumerate(['l','r']):
        for sKey, dPoseData in dPoses.items():
            sPart, sPos = sKey.split('.')
            iDriverValue = int(sPos)
            for sName in sNames:
                cCtrl = ctrls8.ctrlFromName('%sLashes%s_%s_ctrl' % (sName, utils.getFirstLetterUpperCase(sPart), sSide))
                sPoseGrp = cCtrl.getOffsetByName('pose')
                sSign = 'p' if iDriverValue >= 0 else 'n'
                sPoseLoc =  f"_poseLoc__{cCtrl.sCtrl.replace('_ctrl', '')}__{sSign}{abs(iDriverValue):03d}"
                if not cmds.objExists(sPoseLoc):
                    xforms.createLocator(sPoseLoc, sParent=cCtrl.sSlider, fSize=cCtrl.fSize)
                    xforms.matchXform(sPoseGrp, sPoseLoc)
                    fValues = dPoseData.get(sName, [(0,0,0), (0,0,0), (1,1,1)])
                    cmds.setAttr('%s.t' % sPoseLoc, *fValues[0])
                    cmds.setAttr('%s.r' % sPoseLoc, *fValues[1])
                    cmds.setAttr('%s.s' % sPoseLoc, *fValues[2])
                utils.connectPosesLocVis(sPoseLoc)
                dTranslates['%s.%s' % (sPoseGrp, sPart)].append(('%s.t' % sPoseLoc, iDriverValue))
                dRotates['%s.%s' % (sPoseGrp, sPart)].append(('%s.r' % sPoseLoc, iDriverValue))
                dScales['%s.%s' % (sPoseGrp, sPart)].append((nodes.createVectorAdditionNode(['%s.s' % sPoseLoc, [-1,-1,-1]]), iDriverValue))

            if iDriverValue == 0:
                for sA in 'trs':
                    cmds.setAttr('%s.%s' % (sPoseLoc, sA), lock=True)


    for sOutA, dData in [('t', dTranslates),
                         ('r', dRotates),
                         ('s', dScales)]:

        for sPoseGrpAndPart, xValues in dData.items():
            sPoseGrp, sPart = sPoseGrpAndPart.split('.')
            xValues = sorted(xValues, key=lambda a:a[1])
            sSide = utils.getSide(sPoseGrp)
            sDriverAttr = 'grp_%s_blinkPasser.blendCurve%s' % (sSide, utils.getFirstLetterUpperCase(sPart))

            for i, xV in enumerate(xValues):
                sPoseLocAttr = xV[0]
                fDriverValue = xV[1] * 0.01
                if i == 0:
                    sPrevSiblingAttr = [0,0,0]
                    fPrevDriverValue = -1.0
                else:
                    sPrevSiblingAttr = xValues[i-1][0]
                    fPrevDriverValue = xValues[i-1][1] * 0.01

                sRange = nodes.createRangeNode(sDriverAttr, fPrevDriverValue, fDriverValue, sPrevSiblingAttr, sPoseLocAttr, bOutRangeIsVector=True)
                sOutput = nodes.createConditionNode(sDriverAttr, '<=', fDriverValue, sRange, [-55, -55, -55], bVector=True, sName='lashesPose_%d' % xV[1])
                if i == 0:
                    if sOutA == 's':
                        nodes.createVectorAdditionNode([sOutput, [1,1,1]], sTarget='%s.%s' % (sPoseGrp, sOutA), bForce=True)
                    else:
                        cmds.connectAttr(sOutput, '%s.%s' % (sPoseGrp, sOutA), force=True)
                else:
                    cmds.connectAttr(sOutput, '%s.colorIfFalse' % sPrevCondition)

                sPrevCondition = sOutput.split('.')[0]
                if sOutA == 't':
                    sVisPrev = nodes.createRangeNode(sDriverAttr, fPrevDriverValue, fDriverValue, 0, 1)
                    if i < len(xValues)-1:
                        sVisNext = nodes.createRangeNode(sDriverAttr, fDriverValue, xValues[i+1][1] * 0.01, 1, 0)
                        sVisOutput = nodes.createConditionNode(sDriverAttr, '<', fDriverValue, sVisPrev, sVisNext)
                    else:
                        sVisOutput = sVisPrev

                    if xV[1] == 0:
                        cmds.setAttr('%s.v' % sPoseLocAttr.split('.')[0], False)
                    else:
                        cmds.connectAttr(sVisOutput, '%s.v' % sPoseLocAttr.split('.')[0], force=True)

            if _bBlendLastToZero:
                sLastRange = nodes.createRangeNode(sDriverAttr, fDriverValue, 1, sPoseLocAttr, [0,0,0], bOutRangeIsVector=True)
                cmds.connectAttr(sLastRange, '%s.colorIfFalse' % sPrevCondition)
            else:
                cmds.connectAttr(sPoseLocAttr, '%s.colorIfFalse' % sPrevCondition)


def getLashesPosesInfo():
    dPoses = defaultdict(dict)
    for p,sPart in enumerate(['bot','top']):
        for sName in ['inner', 'mid', 'outer']:
            sPoses = cmds.ls(f'_poseLoc__{sName}Lashes{sPart.title()}_l__????', et='transform')  # grp_l_mid_lashSibling_top_040
            for sPoseLoc in sPoses:
                sDriverValue = sPoseLoc.split('_')[-1]
                iDriverValue = int(sDriverValue[1:]) * (-1 if sDriverValue[0] == 'n' else 1)
                if iDriverValue != 0:
                    dPoses['%s.%d' % (sPart, iDriverValue)][sName] = [cmds.getAttr('%s.t' % sPoseLoc)[0], cmds.getAttr('%s.r' % sPoseLoc)[0], cmds.getAttr('%s.s' % sPoseLoc)[0]]

    return dict(dPoses)



def fillLashesPoses(_uiArgs=None):
    dPoses = getLashesPosesInfo()
    _uiArgs['dPoses'].setText(str(dPoses))


#EXCLUDE START LIDSPLINES

dButtons = OrderedDict()
dButtons['Create Top Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesTop', kLashesBpGrp)
dButtons['Create Bot Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesBot', kLashesBpGrp)
dButtons['Create Top End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesTopEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Create Bot End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesBotEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Fill PoseLocs'] = fillLashesPoses
dButtons['Generate PoseLoc at Current Lid Position'] = generateNewLashesPose
dButtons['BIND Eyelashes (selected)'] = bindLashes
dButtons['- Export Lashes BPs -'] = lambda: exportBps(kLashesBpFileName, kLashesBpGrp)





@builderTools.addToBuild(iOrder=55, dButtons=dButtons, bDisableByDefault=True)
def lashesSetup_splineLids(sAttachMesh=[], sParentJoint='jnt_m_headMain', bDoBot=True, bDoTop=True, dPoses={}, iJointStep=1, bCtrlVisDefault=False):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sGrp = cmds.createNode('transform', n='grp_lashes', p='modules')

    ssBpCurves = [['bpCurve_l_lashesBot', 'bpCurve_l_lashesTop'], ['bpCurve_r_lashesBot', 'bpCurve_r_lashesTop']]
    ssBpCurvesEnd = [['bpCurve_l_lashesBotEnd', 'bpCurve_l_lashesTopEnd'], ['bpCurve_r_lashesBotEnd', 'bpCurve_r_lashesTopEnd']]

    aaPoints = [], []
    aaClosestIds = [], []
    bDoes = [bDoBot, bDoTop]
    for s,sSide in enumerate(['l', 'r']):

        for p, sBpCurve in enumerate(ssBpCurves[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)
        for p, sBpCurve in enumerate(ssBpCurvesEnd[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)

        for p,sPart in enumerate(['bot','top']):
            if bDoes[p]:
                aPoints = patch.patchFromName(ssBpCurves[s][p]).getAllPoints()
                aIndices = np.arange(len(aPoints), step=iJointStep)
                aIndices[-1] = len(aPoints)-1
                aPoints = aPoints[aIndices]
                aaPoints[s].append(aPoints)
                aaClosestIds[s].append(xforms.getClosestIdsFromPoints(sAttachMesh, aPoints))
            else:
                aaPoints[s].append([])
                aaClosestIds[s].append([])

    aAllClosestIds = np.array(utils.flattenedList(aaClosestIds))

    sAllLocs = constraints.parallelTransformAsDeformers2(sAttachMesh, aAllClosestIds, sParent=sGrp,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint, #bConnectEnvelopes=False,
                                                     sDeformers=['skinCluster__%s' % sAttachMesh])#, 'skinCluster__%s__BEND' % sAttachMesh])
    aAllLocs = np.array(sAllLocs)


    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'lashesCtrlVis', bDefaultValue=bCtrlVisDefault)
    sssJoints = [[[], []], [[], []]]
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        fEyeJointRadius = cmds.getAttr('jnt_%s_eyeMain.radius' % sSide)
        for p, sPart in enumerate(['bot', 'top']):
            if bDoes[p]:
                sCurveEnd = cmds.duplicate(ssBpCurvesEnd[s][p], n=utils.replaceStringStart(ssBpCurvesEnd[s][p], 'bpCurve_', 'curve_'))[0]
                curves.fixShapeName(sCurveEnd)

                cmds.parent(sCurveEnd, sGrp)

                aClosestIds = aaClosestIds[s][p]
                aInds = utils.findOneArrayInAnother(aAllClosestIds, aClosestIds)
                sLocs = aAllLocs[aInds]
                aPoints = aaPoints[s][p]
                aPercs = curves.getPercsFromPoints(ssBpCurves[s][p], aPoints)
                aParams = curves.getParamsFromPercs(sCurveEnd, aPercs)
                aEndPoints = curves.getPointsFromParams(sCurveEnd, aParams, bReturnNumpy=True)
                for j,sL in enumerate(sLocs):
                    sJ = 'jnt_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j)
                    if cmds.objExists(sJ):
                        cmds.parent(sJ, jointOrGroup(sParentJoint))
                        cmds.setAttr('%s.v' % sJ, True)
                        xforms.resetJoint(sJ)
                    else:
                        cmds.createNode('joint', n=sJ, p=jointOrGroup(sParentJoint))
                    cmds.move(aPoints[j,0], aPoints[j,1], aPoints[j,2], sJ, a=True, ws=True)
                    sssJoints[s][p].append(sJ)
                    sJEnd = cmds.createNode('joint', n='jnt_%s_lashes%sEnd_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p=sJ)
                    cmds.setAttr('%s.radius' % sJ, fEyeJointRadius*0.15)
                    cmds.setAttr('%s.radius' % sJEnd, fEyeJointRadius*0.15)

                    fLength = np.linalg.norm(aEndPoints[j]-aPoints[j])

                    cmds.setAttr('%s.tx' % sJEnd, fLength*fSideMultipl)

                    constraints.matrixParentConstraint(sL, sJ, skipRotate=['x','y','z'], mo=True)


                for j, sJ in enumerate(sssJoints[s][p]):
                    _, sAimPos = curves.createPointInfoNode(sCurveEnd, fParam=aParams[j])

                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[fSideMultipl, 0, 0])
                    nodes.createPointByMatrixNode(sAimPos, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                    jUp = j+1 if j == 0 else j-1
                    sConnectionJ = cmds.listConnections('%s.t' % sssJoints[s][p][j], s=True, d=False, p=True)[0]
                    sConnectionUpJ = cmds.listConnections('%s.t' % sssJoints[s][p][jUp], s=True, d=False, p=True)[0]
                    nodes.createVectorAdditionNode([sConnectionUpJ, sConnectionJ], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)




                aCtrlPercs = np.array([0, 0.5, 1], dtype='float64')
                fCtrlPoints = curves.getPointsFromPercs(sCurveEnd, aCtrlPercs)
                aLocInds = np.array(aCtrlPercs*(len(sLocs)-1), dtype=int)
                sInfluences = []
                for c,sName in enumerate(['inner', 'mid', 'outer']):

                    cC = ctrls8.create('%sLashes%s' % (sName, utils.getFirstLetterUpperCase(sPart)), sSide, sParent='ctrls', sAttrs=['t','r'],
                                      sMatch='jnt_%s_eyeMain' % sSide, fMatchPos=fCtrlPoints[c], iColorIndex=2, sShape='sphere')
                    cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)
                    cC.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[3:]])
                    constraints.matrixParentConstraint(sLocs[aLocInds[c]], cC.sPasser, mo=True)

                    constraints.matrixParentConstraint(cC.sCtrl, cC.sOut, sJumpOverTransforms=[cC.sExtraMove, cC.sPasser], skipScale=['x','y','z'])
                    cC.sJoint = cmds.createNode('joint', p=cC.sOut, n='jnt_%s_%sLashes%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)))
                    cmds.setAttr('%s.radius' % cC.sJoint, fEyeJointRadius * 0.35)

                    cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                    sInfluences.append(cC.sJoint)

                    cC.appendOffsetGroup('pose')


                cmds.skinCluster(sCurveEnd, sInfluences, tsb=True)


    createLashesPosesSetup(dPoses)



    deformers.resetJointReferences(utils.flattenedList(sssJoints))


#EXCLUDE END LIDSPLINES









def selectSiblings():
    cmds.select(cmds.ls('*LashSibling*', et='transform'))


dButtons = OrderedDict()
dButtons['Create Top Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesTop', kLashesBpGrp)
dButtons['Create Bot Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesBot', kLashesBpGrp)
dButtons['Create Top End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesTopEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Create Bot End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesBotEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Select Siblings'] = selectSiblings
dButtons['Fill Siblings'] = recordLashesSiblings
# dButtons['Fill Siblings Ref'] = recordLashesSiblingsRef # not sure what that was about..
dButtons['BIND Eyelashes (selected)'] = bindLashes
dButtons['- Export Lashes BPs -'] = lambda: exportBps(kLashesBpFileName, kLashesBpGrp)



# TODO: change poses to work with poseLocs, same as lashesSetup_splineLids()
# ref stuff might not work anymore!  we'll have to create a separate function for that.
@builderTools.addToBuild(iOrder=65, dButtons=dButtons, bDisableByDefault=True)
def lashesSetup_blendShapeLids(sAttachMesh=[], sParentJoint='jnt_m_headMain', bDoBot=True, bDoTop=True, dSiblingPoses={}, dRefSiblingPoses={}, iJointStep=1, bCtrlVisDefault=False):
    '''
    NOT WORKING YET! NEEDS TO BE CLEANED UP
    '''

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sGrp = cmds.createNode('transform', n='grp_lashes', p='modules')

    ssBpCurves = [['bpCurve_l_lashesBot', 'bpCurve_l_lashesTop'], ['bpCurve_r_lashesBot', 'bpCurve_r_lashesTop']]
    ssBpCurvesEnd = [['bpCurve_l_lashesBotEnd', 'bpCurve_l_lashesTopEnd'], ['bpCurve_r_lashesBotEnd', 'bpCurve_r_lashesTopEnd']]

    aaPoints = [], []
    aaClosestIds = [], []
    bDoes = [bDoBot, bDoTop]
    for s,sSide in enumerate(['l', 'r']):

        for p, sBpCurve in enumerate(ssBpCurves[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)
        for p, sBpCurve in enumerate(ssBpCurvesEnd[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)

        for p,sPart in enumerate(['bot','top']):
            if bDoes[p]:
                aPoints = patch.patchFromName(ssBpCurves[s][p]).getAllPoints()
                aIndices = np.arange(len(aPoints), step=iJointStep)
                aIndices[-1] = len(aPoints)-1
                aPoints = aPoints[aIndices]
                aaPoints[s].append(aPoints)
                aaClosestIds[s].append(xforms.getClosestIdsFromPoints(sAttachMesh, aPoints))
            else:
                aaPoints[s].append([])
                aaClosestIds[s].append([])

    aAllClosestIds = np.array(utils.flattenedList(aaClosestIds))

    sAllLocs = constraints.parallelTransformAsDeformers2(sAttachMesh, aAllClosestIds, sParent=sGrp,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint, #bConnectEnvelopes=False,
                                                     sDeformers=['skinCluster__%s' % sAttachMesh])#, 'skinCluster__%s__BEND' % sAttachMesh])
    aAllLocs = np.array(sAllLocs)


    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'lashesCtrlVis', bDefaultValue=bCtrlVisDefault)
    sssJoints = [[[], []], [[], []]]
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        cBlink = ctrls8.ctrlFromName('blink%s_ctrl' % utils.sSides3[s])
        cExtraBlinks = [ctrls8.ctrlFromName('lidBot%s_ctrl' % utils.sSides3[s]), ctrls8.ctrlFromName('lidTop%s_ctrl' % utils.sSides3[s])]
        cLookAt = ctrls8.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s])
        sSwitchedLookY = nodes.createMultiplyNode('%s.lidFollow' % cLookAt.sCtrl, 'grp_%s_eyesLookAtPasser.lookVert' % sSide)

        fEyeJointRadius = cmds.getAttr('jnt_%s_eyeMain.radius' % sSide)
        for p, sPart in enumerate(['bot', 'top']):
            if bDoes[p]:
                sCurveEnd = cmds.duplicate(ssBpCurvesEnd[s][p], n=utils.replaceStringStart(ssBpCurvesEnd[s][p], 'bpCurve_', 'curve_'))[0]
                curves.fixShapeName(sCurveEnd)

                cmds.parent(sCurveEnd, sGrp)

                aClosestIds = aaClosestIds[s][p]
                aInds = utils.findOneArrayInAnother(aAllClosestIds, aClosestIds)
                sLocs = aAllLocs[aInds]
                aPoints = aaPoints[s][p]
                aPercs = curves.getPercsFromPoints(ssBpCurves[s][p], aPoints)
                aParams = curves.getParamsFromPercs(sCurveEnd, aPercs)
                aEndPoints = curves.getPointsFromParams(sCurveEnd, aParams, bReturnNumpy=True)
                for j,sL in enumerate(sLocs):
                    sJ = 'jnt_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j)
                    if cmds.objExists(sJ):
                        cmds.parent(sJ, sParentJoint)
                        cmds.setAttr('%s.v' % sJ, True)
                        xforms.resetJoint(sJ)
                    else:
                        cmds.createNode('joint', n=sJ, p=sParentJoint)
                    cmds.move(aPoints[j,0], aPoints[j,1], aPoints[j,2], sJ, a=True, ws=True)
                    sssJoints[s][p].append(sJ)
                    sJEnd = cmds.createNode('joint', n='jnt_%s_lashes%sEnd_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p=sJ)
                    cmds.setAttr('%s.radius' % sJ, fEyeJointRadius*0.15)
                    cmds.setAttr('%s.radius' % sJEnd, fEyeJointRadius*0.15)

                    fLength = np.linalg.norm(aEndPoints[j]-aPoints[j])

                    cmds.setAttr('%s.tx' % sJEnd, fLength*fSideMultipl)

                    constraints.matrixParentConstraint(sL, sJ, skipRotate=['x','y','z'], mo=True)


                for j, sJ in enumerate(sssJoints[s][p]):
                    _, sAimPos = curves.createPointInfoNode(sCurveEnd, fParam=aParams[j])

                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[fSideMultipl, 0, 0])
                    nodes.createPointByMatrixNode(sAimPos, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                    jUp = j+1 if j == 0 else j-1
                    sConnectionJ = cmds.listConnections('%s.t' % sssJoints[s][p][j], s=True, d=False, p=True)[0]
                    sConnectionUpJ = cmds.listConnections('%s.t' % sssJoints[s][p][jUp], s=True, d=False, p=True)[0]
                    nodes.createVectorAdditionNode([sConnectionUpJ, sConnectionJ], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)




                aCtrlPercs = np.array([0, 0.5, 1], dtype='float64')
                fCtrlPoints = curves.getPointsFromPercs(sCurveEnd, aCtrlPercs)
                aLocInds = np.array(aCtrlPercs*(len(sLocs)-1), dtype=int)
                sInfluences = []
                for c,sName in enumerate(['inner', 'mid', 'outer']):

                    cC = ctrls8.create('%sLashes%s' % (sName, utils.getFirstLetterUpperCase(sPart)), sSide, sParent='ctrls', sAttrs=['t','r'],
                                      sMatch='jnt_%s_eyeMain' % sSide, fMatchPos=fCtrlPoints[c], iColorIndex=2, sShape='sphere')
                    cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)
                    cC.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[3:]])
                    constraints.matrixParentConstraint(sLocs[aLocInds[c]], cC.sPasser, mo=True)

                    constraints.matrixParentConstraint(cC.sCtrl, cC.sOut, sJumpOverTransforms=[cC.sExtraMove, cC.sPasser], skipScale=['x','y','z'])
                    cC.sJoint = cmds.createNode('joint', p=cC.sOut, n='jnt_%s_%sLashes%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)))
                    cmds.setAttr('%s.radius' % cC.sJoint, fEyeJointRadius * 0.35)

                    cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                    sInfluences.append(cC.sJoint)

                    sPoseOffset = cC.appendOffsetGroup('pose')

                    sSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingBlink%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingWideMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingWide%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingExtraDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraDown%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingExtraUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraUp%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingFollowDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowDown%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingFollowUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowUp%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblings = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp, sSiblingFollowDown, sSiblingFollowUp]
                    [cmds.addAttr(sT, ln='lashesSibling') for sT in sSiblings]
                    for sA in ['t', 'r', 's']:
                        fDefault = [1,1,1] if sA == 's' else [0,0,0]
                        sBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sSiblingBlinkMain, sA), bOutRangeIsVector=True)
                        sBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sSiblingWideMain, sA), bOutRangeIsVector=True)
                        sBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                        sBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)
                        sBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sSiblingFollowDown, sA), bOutRangeIsVector=True)
                        sBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sSiblingFollowUp, sA), bOutRangeIsVector=True)
                        sAllSiblings = [sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp]
                        if sA in ['t','r']:
                            nodes.createVectorAdditionNode(sAllSiblings, sTarget='%s.%s' % (sPoseOffset, sA))
                        else:
                            nodes.createMultiplyArrayNode(sAllSiblings, bVector=True, sTarget='%s.%s' % (cC.sOut, sA))

                    # if sSide == 'r':
                    #     cmds.setAttr('%s.s' % sSliderOffset, 1, -1, 1)
                cmds.skinCluster(sCurveEnd, sInfluences, tsb=True)

        for sAttr, fValues in list(dSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if cmds.objExists(sAttrSide):
                cmds.setAttr(sAttrSide, *fValues)

        for sAttr, fValues in list(dRefSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if cmds.objExists(sAttrSide):
                cmds.setAttr(sAttrSide, *fValues)

    deformers.resetJointReferences(utils.flattenedList(sssJoints))



def openShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)
    cmds.file(sFullPath, open=True, force=True)

def fingShapeEditorFileInExplorer(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)
    utils.openExplorer(sFullPath)


def saveAsShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    cmds.file(rename=sFullPath)
    cmds.file(force=True, type='mayaAscii', save=True)


def referenceShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)

    utils.importMayaFiles(sFullPath, sNamespace='shapes', bReference=True)



dButtons = OrderedDict()
dButtons['Open File'] = openShapeEditorFile
dButtons['Find in Explorer'] = fingShapeEditorFileInExplorer
dButtons['Save File'] = saveAsShapeEditorFile
dButtons['Reference File'] = referenceShapeEditorFile
dButtons['- Export *Slider* BPs -'] = ctrls8.exportSliderBps


@builderTools.addToBuild(iOrder=62, dButtons=dButtons, bCanGetDuplicated=True)
def importBlendShapeFile(sFile='blendShapes.ma', sBlendShape='', bRemoveReferenceWhenDone=True, sSuffix='', bApplyInnerBlinkValues=True):
    utils.reload2(kangarooShapeEditorTools)
    kangarooShapeEditorTools.importBlendShapeFile(sFile=sFile, sBlendShape=sBlendShape, bRemoveReferenceWhenDone=bRemoveReferenceWhenDone, sSuffix=sSuffix, report=report,
                                                  bApplyInnerBlinkValues=bApplyInnerBlinkValues, bCreateTransformForInactiveMainTargets=True)



def selectMapMeshesFromMesh():
    sSel = cmds.ls(sl=True)
    sSelect = []
    for sMesh in sSel:
        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            report.report.addLogText('%s Map not exists: ' % sMapMesh)
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)
        sSelect.append(sMapMesh)
    cmds.select(sSelect)


@builderTools.addToBuild(iOrder=61, dButtons={'Create Or Select Map Meshes from Selection':selectMapMeshesFromMesh}, bDisableByDefault=True)
def importMapMeshes(sDefaultMeshes=[]):
    '''
    map meshes per mesh is meshname__MAPS
    on those the clusters are named MAP__meshName__myName
    and those are exported as meshname__myName.map
    '''
    for sMesh in sDefaultMeshes:
        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)


    sMapFolder = assets.assetManager.getCurrentVersionPath(sSubPath='maps')
    if not os.path.exists(sMapFolder):
        return
    sMapFiles = os.listdir(sMapFolder)
    for sFile in sMapFiles:
        sSplits = sFile.split('.')[0].split('__')
        if len(sSplits) != 2:
            report.report.addLogText('%s does not have the right name standard. Skipping..' % sFile)
            continue

        report.report.addLogText('importing map: %s' % sFile)
        sMesh, sMapName = sSplits

        with open(os.path.join(sMapFolder, sFile), 'rb') as handle:
            fWeights = pickle.load(handle)

        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)
        sCluster = 'MAP__%s__%s' % (sMesh, sMapName)
        if not cmds.objExists(sCluster):
            _, sTempHandle = cmds.cluster(sMapMesh, n=sCluster)
            nodes.deleteConnectionsAndItself2(cmds.ls(sTempHandle, dag=True))
        cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, len(fWeights)-1), *fWeights)



kMouthBpGroupName = '_grp_m_mouthBps'
kMouthBpFileName = 'faceBlueprintsMouth.ma'


dButtons = OrderedDict()
dCurveHelpA = {'?':['Select the most inner vertex loop, and then place the locators as needed,'\
                                                        '\nto indicate splitting point between bottom and top.'
                                                        '\nThe curve will be broken up at a random point, but that\'s ok. Ideally the '\
                                                        '\nbottom and top part of the curves will be a close together as possible,'\
                                                        '\nbut that\'s depending on the model.'
                                                        '\nIMPORTANT: if at the front the top lip part is lower then the bottom lip part, '\
                                                        '\nyou need to set bFlipInnerBpCurves to True', 'mouthInnerCurves.JPG']}

dCurveHelpB = {'?':['Select the row for the outer curve. This is mainly for the control positions', 'mouthOuterCurves.JPG']}

dButtons['Create Inner Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsInner', kMouthBpGroupName, fDirection=(-1, 0, 0))
dButtons['Create Inner Curves and Locators'].dSideButtons = dCurveHelpA
dButtons['Create Outer Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsOuter', kMouthBpGroupName, fDirection=(-1, 0, 0))
dButtons['Create Outer Curves and Locators'].dSideButtons = dCurveHelpB



def _attachAndSelectJoints(sJointsString):
    sJoints = cmds.ls(sJointsString, et='joint')
    for sObj in cmds.ls(sl=True):
        sSkinCluster = deformers.convertChooseSkinCluster(None, sObj)
        deformers.addInfluences(sSkinCluster, sJoints)
    cmds.select(sJoints)




def createMouthSlidingPlane():
    sPlane = cmds.nurbsPlane(name='bpNurbs_l_cornerSlidePlane', w=2.0, u=3, v=3)[0]
    cmds.parent(sPlane, xforms.createOrReturnTopGroup(kMouthBpGroupName))

dButtons['Create Corner Sliding Planes'] = createMouthSlidingPlane
createMouthSlidingPlane.dSideButtons = {'?':['This should be roughtly the shape of the teeth. '\
                                 '\nIt\'s to have the corner controls move in a not so linear way.', 'slidingPlane.jpg']}
createMouthSlidingPlane.dSideButtons = {'?':['This should be roughtly the shape of the teeth. '\
                                 '\nIt\'s to have the corner controls move in a not so linear way.', 'slidingPlane.jpg']}

dButtons['Create Mouth Pivot'] = lambda: createMatrixCtrlFromTransform('bp_m_mouthPivot', kMouthBpGroupName, sTransform='jnt_m_headMain')




dSetPosesMenu = OrderedDict()


def getMouthPoseCtrls(bIncludeJaw=False):
    print ('bIncludeJaw: ', bIncludeJaw)
    ccPoseCtrls = []
    for p, sPart in enumerate(['bot', 'top']):
        sPartUpper = utils.getFirstLetterUpperCase(sPart)
        sPartCtrls = cmds.ls('lips%s_?_ctrl' % sPartUpper) + cmds.ls('lips%s_ctrl' % sPartUpper) + cmds.ls('detail%s???_?_ctrl' % sPartUpper) + \
                     ['mouth%s_ctrl' % sPartUpper,
                      'cornerTangent%s_l_ctrl' % sPartUpper,
                      'cornerTangent%s_r_ctrl' % sPartUpper,
                      'lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']
        if bIncludeJaw:
            sPartCtrls.append('jaw_ctrl')
        ccPoseCtrls.append([ctrls8.ctrlFromName(sC) for sC in sPartCtrls])
    return ccPoseCtrls



def disableAllLipPush():
    for sCtrl in cmds.ls('lipsTop*ctrl', et='transform'):
        sAttr = '%s.lipPush' % sCtrl
        if cmds.objExists(sAttr):
            cmds.setAttr(sAttr, 0)





# m_mouthPasser_Grp -> grp_m_mouthPasser
def translateAttrToStandard(sAttr):
    sSplits = sAttr.split('.')
    sObj = sSplits[0]
    if not cmds.objExists(sObj):
        sSplitsB = sObj.split('_')
        if len(sSplitsB) >= 3:
            sSplitsB = [sSplitsB[-1].lower()] + sSplitsB[0:-1]
        sObj = '_'.join(sSplitsB)
        sSplits[0] = sObj
        sNewAttr = '.'.join(sSplits)
        if cmds.objExists(sNewAttr):
            return sNewAttr
    return sAttr





def createStaticSlideCurves():
    sSelect = []
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    for sCurve in sCurves:
        if not cmds.objExists(sCurve):
            cmds.confirmDialog(m='For creating this blueprint, you need to run the function first')
        else:
            sNewCurve = utils.replaceStringStart(sCurve, 'curve_', 'bpCurve_')
            sSelect.append(sNewCurve)
            if cmds.objExists(sNewCurve):
                if cmds.confirmDialog(m='Curve "%s" already exists. Recreate?' % sNewCurve, button=['yes', 'no']) == 'no':
                    continue
                else:
                    cmds.delete(sNewCurve)
            cmds.duplicate(sCurve, n=sNewCurve)
            cmds.parent(sNewCurve, kMouthBpGroupName)
        cmds.rebuildCurve(sCurve, kr=0, d=3, ch=False)

    if sSelect:
        cmds.select(sSelect)


def selectStaticSlideCurveBps():
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    sSel = []
    for sCurve in sCurves:
        sNewCurve = utils.replaceStringStart(sCurve, 'curve_', 'bpCurve_')
        if cmds.objExists(sNewCurve):
            sSel.append(sNewCurve)
    if sSel:
        cmds.select(sSel)

def selectRiggedOnes():
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    cmds.select(sCurves)


dButtons['=== Static Blueprint Curves (Optional) ==='] = {'Create Blueprints': createStaticSlideCurves, 'Select Blueprints':selectStaticSlideCurveBps, 'Select Rigged':selectRiggedOnes}


dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu()

dSquashStretchMenu = {}
def bakeSquashStretchShapes(ddSquashStretchSettings, _uiArgs=None):

    sModel = cmds.ls(sl=True)[0]

    sNew = []
    for sKey, sValueKey in [('sShrinkTarget', 'fShrinkCornerValue'),
                            ('sExpandTarget', 'fExpandCornerValue')]:
        sTarget = ddSquashStretchSettings[sKey]
        if cmds.objExists(sTarget):
            cmds.delete(sTarget)
        fValue = ddSquashStretchSettings[sValueKey]
        cmds.setAttr('lipsCorner_l_ctrl.tx', fValue)
        cmds.setAttr('lipsCorner_r_ctrl.tx', fValue)

        cmds.duplicate(sModel, n=sTarget)
        utils.parentToWorld(sTarget)
        sNew.append(sTarget)

    cmds.setAttr('lipsCorner_l_ctrl.tx', 0)
    cmds.setAttr('lipsCorner_r_ctrl.tx', 0)
    cmds.select(sNew)
dSquashStretchMenu['Bake Shapes'] = bakeSquashStretchShapes


dButtons['=== SQUASH STRETCH ==='] = dSquashStretchMenu


dButtons['- Export Mouth BPs -'] = lambda: exportBps(kMouthBpFileName, kMouthBpGroupName)
dButtons['- Export *Slider* BPs -'] = ctrls8.exportSliderBps


# curve_m_botMouth gets rotation on pucker!!!!



kMouthSplineCurves = ['curve_m_botMouth', 'curve_m_topMouth']
kMouthJawOpenCorrectiveCurves = ['jawOpenBotMouth', 'jawOpenTopMouth']
def selectMouthSplineCurves():
    cmds.select(kMouthSplineCurves)

def selectMouthSplineCorrectiveCurves():
    cmds.select(kMouthJawOpenCorrectiveCurves)


def generateCorrectiveCurves():
    sReturn = []
    for c,sCurve in enumerate(kMouthSplineCurves):
        sCorrCurve = kMouthJawOpenCorrectiveCurves[c]
        if cmds.objExists(sCorrCurve):
            cmds.delete(sCorrCurve)
        cmds.duplicate(sCurve, n=sCorrCurve)[0]
        cmds.parent(sCorrCurve, kMouthBpGroupName)
        sReturn.append(sCorrCurve)
    cmds.select(sReturn)


def mirrorCorrectiveCurves():
    for sCorr in kMouthJawOpenCorrectiveCurves:
        pCurve = patch.patchFromName(sCorr)
        aCvs = pCurve.getPoints()
        aMirrorCvs = np.copy(aCvs[::-1])
        aMirrorCvs[:,0] *= -1.0
        iMirrorIds = np.arange(len(aCvs)//2 + 1, len(aCvs), 1)
        aCvs[iMirrorIds] = aMirrorCvs[iMirrorIds]
        aCvs[len(aCvs)//2, 0] = 0.0
        pCurve.setPoints(aCvs)

# probably not needed anymore since curves are smoother
dButtons['=== SPLINE CURVE CORRECTIVES ==='] = {'select rigged curves':selectMouthSplineCurves,
                                                'select correctives':selectMouthSplineCorrectiveCurves,
                                                'generate correctives':generateCorrectiveCurves,
                                                'mirror correctives curves':mirrorCorrectiveCurves}


def changePoseLocatorsToOldPoses(ddPoses):
    for sKey in ['cornerIn', 'funnel', 'lipPress', 'topRollIn']:
        pass
        dPose = ddPoses[sKey]['dPose']
        for sCtrl, dAttrs in dPose.items():
            print ('sCtrl: ', sCtrl)
            sSide = utils.getSide(sCtrl)

            sTryLocs = [f"_poseLoc__{sCtrl.replace('_ctrl','')}__{sKey}", f"_poseLoc__{sCtrl.replace('_ctrl','')}__{sSide}_{sKey}"]
            for sLoc in sTryLocs:
                if cmds.objExists(sLoc):
                    print ('found %s' % sLoc)
                    for sA, fValue in dAttrs.items():
                        if cmds.attributeQuery(sA, node=sLoc, exists=True):
                            cmds.setAttr('%s.%s' % (sLoc, sA), fValue)


dButtons['change Pose Locators to Old Poses'] = changePoseLocatorsToOldPoses


def moveInOut(bOut=True):
    sNewLocs = []
    for sLoc in cmds.ls(sl=True):
        sDetailStart = '_poseLoc__detail'
        if sLoc.startswith(sDetailStart):
            sSplits = sLoc.split('__')
            sCtrl = sSplits[1]

            sCtrlName, sCtrlSide = sCtrl.split('_')
            sPart = sCtrlName[len('detail'):len('detail')+3].lower()
            sNumber = sCtrlName[len('detail')+3:]
            # _poseLoc__detailTop004_l__l_in
            iNumber = int(sNumber)

            iNextNumber = iNumber+1 if bOut else iNumber-1
            sSplits[1] = f'detail{sPart.title()}{iNextNumber:03d}_{sCtrlSide}'
            sNewLoc = '__'.join(sSplits)
            print ('new Loc: ', sNewLoc)
            if cmds.objExists(sNewLoc):
                sNewLocs.append(sNewLoc)
            else:
                sNewLocs.append(sLoc)
    cmds.select(sNewLocs)

def toggleBotTop():
    sNewLocs = []
    for sLoc in cmds.ls(sl=True):
        sDetailStart = '_poseLoc__detail'
        if sLoc.startswith(sDetailStart):
            sSplits = sLoc.split('__')
            sCtrl = sSplits[1]

            sCtrlName, sCtrlSide = sCtrl.split('_')
            sPart = sCtrlName[len('detail'):len('detail')+3].lower()
            sNumber = sCtrlName[len('detail')+3:]
            iNumber = int(sNumber)

            sSplits[1] = f"detail{'Top' if sPart=='bot' else 'Bot'}{sNumber}_{sCtrlSide}"
            sNewLoc = '__'.join(sSplits)
            print ('new Loc: ', sNewLoc)
            if cmds.objExists(sNewLoc):
                sNewLocs.append(sNewLoc)
            else:
                sNewLocs.append(sLoc)
    cmds.select(sNewLocs)


def toggleMiddleLeft():
    sNewLocs = []
    for sLoc in cmds.ls(sl=True):
        sDetailStart = '_poseLoc__detail'
        if sLoc.startswith(sDetailStart):
            sSplits = sLoc.split('__')
            sCtrl = sSplits[1]

            if '_' in sCtrl: #side to middle
                sCtrlName, sSide = sCtrl.split('_')
                sSplits[1] = f"{sCtrlName[:len('detail')+3]}000"
                sSplits[-1] = f"{sSplits[-1]}_?"
            else: #middle to left
                sSplits[1] = f"{sCtrl[:len('detail')+3]}000_l"
                sSplits[-1] = sSplits[-1].split('_')[0]

            sNewCtrl = '__'.join(sSplits)
            print ('sNewCtrl:j ', sNewCtrl)
            if cmds.objExists(sNewCtrl):
                sNewLocs.append(sNewCtrl)
            else:
                sNewLocs.append(sLoc)
            # _poseLoc__detailTop000__l_in
            # _poseLoc__detailTop002_l__l_in
    cmds.select(sNewLocs)


def moveCornerInPucker(bToPucker):
    ssLocs = [cmds.ls('_poseLoc__*__cornerIn*', et='transform')]
    print ('ssLocs: ', ssLocs)
    ssLocs.append([sLoc.replace('cornerIn', 'pucker') for sLoc in ssLocs[0]])

    if bToPucker:
        iFrom, iTo = 0, 1
    else:
        iFrom, iTo = 1, 0

    print ('iFrom: ', iFrom)
    print ('iTo: ', iTo)
    for sFrom, sTo in zip(ssLocs[iFrom], ssLocs[iTo]):
        for sA in 'trs':
            fValue = cmds.getAttr('%s.%s' % (sFrom, sA))[0]
            cmds.setAttr('%s.%s' % (sTo, sA), *fValue)



dButtons['-- PoseLoc Tools --'] = {'Select Detail - out':lambda:moveInOut(bOut=True), 'Select Detail - in':lambda:moveInOut(bOut=False),
                                     'Selecte Detail - toggle bot/top': toggleBotTop,
                                     'Select Detail toggle middle/left': toggleMiddleLeft,
                                     'CornerIn -> Pucker': lambda:moveCornerInPucker(True),
                                     'Pucker -> CornerIn': lambda:moveCornerInPucker(False),
                                        }

dPoseCtrlValuesDefault = {}
dPoseCtrlValuesDefault['cornerUp'] = [0,1]
dPoseCtrlValuesDefault['cornerOutUp'] = [1,1]
dPoseCtrlValuesDefault['cornerOut'] = [1,0]
dPoseCtrlValuesDefault['cornerOutDown'] = [1,-1]
dPoseCtrlValuesDefault['cornerDown'] = [0,-1]
dPoseCtrlValuesDefault['cornerIn'] = [-1,0]
dPoseCtrlValuesDefault['cornerInUp'] = [-1,1]
dPoseCtrlValuesDefault['cornerInDown'] = [-1,-1]
dPoseCtrlValuesDefault['pucker'] = [-1,0]
dPoseCtrlValuesDefault['jawOpen'] = -35.0
dPoseCtrlValuesDefault['jawOpenOnMouthClose'] = -20.0
dPoseCtrlValuesDefault['botRollIn'] = -45.0
dPoseCtrlValuesDefault['topRollIn'] = 45.0
dPoseCtrlValuesDefault['botRollOut'] = 45.0
dPoseCtrlValuesDefault['topRollOut'] = -45.0
dPoseCtrlValuesDefault['mouthLeft'] = 1.0
dPoseCtrlValuesDefault['mouthRight'] = -1.0
dPoseCtrlValuesDefault['mouthDown'] = -1.0
dPoseCtrlValuesDefault['mouthUp'] = 1.0

@builderTools.addToBuild(iOrder=62.2, dButtons=dButtons)
def BASEMouthCtrls(sAttachMesh=[], bSPLINES=False, bFEATURES=False, bCorners=True, bBorders=True, bLimitOnNonSplineMode=True, bFrontBoxCtrls=True, bFlipInnerMouthBpCurves=False,
                        fLeftLipParamPercs=[0.33],
                        xMirrorAxis=None, sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain',
                        dDefaultSettingValues={},
                        ddSquashStretchSettings={'bScaleJoints':True, 'fShrinkCornerValue':-1, 'fExpandCornerValue':1.0, 'sShrinkTarget':'mouthSquash', 'sExpandTarget':'mouthStretch'},
                        iSkipSplineJoints=0, bConvertSurfaceSlideToCurve=False, dPoseCtrlValues=dPoseCtrlValuesDefault, bZipper=False,
                         sSuffix=''):
    '''
    1. Create the inner and outer curves (check the locators)
    2. MOST IMPORTANT: set bFlipInnerMouthCurves accordingly!!
    3. for bSplines, create the Corner Sliding Planes

    :param fLeftLipParamPercs
    Changes lip control position or add more controls. By default it's None, which is similar to [0.33].
    To add a middle control: [0.33, 0.5]
    To have 2 extra controls: [0.15, 0.3, 0.5]

    :param fLeftPuckerStrenth:
    Changes behavior of lipCorner_l_ctrl going forward (inside)
    Example: [0.15, 0.3, 0.5]
    
    if lipsCorner_l_ctrl moving negative causes joints to behave unstable, create the Puckerslide Blueprint
    '''
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    bPolyCtrls=False

    dMergedPoseCtrlValues = dict(dPoseCtrlValuesDefault)
    dMergedPoseCtrlValues.update(dPoseCtrlValues)

    # utils.updateDictStringAttr(utils.getMasterName(), 'dAllSculptPoseDriverValues', dMergedPoseCtrlValues)

    if dMergedPoseCtrlValues['cornerOutUp'][0] != dMergedPoseCtrlValues['cornerOut'][0]:
        raise Exception(f'cornerPose "outUp" needs to have the same X value as "out" (%0.3f, %0.3f)' % (dMergedPoseCtrlValues['cornerOutUp'][0], dMergedPoseCtrlValues['cornerOut'][0]))
    if dMergedPoseCtrlValues['cornerOutDown'][0] != dMergedPoseCtrlValues['cornerOut'][0]:
        raise Exception(f'cornerPose "outDown" needs to have the same X value as "out" (%0.3f, %0.3f)' % (dMergedPoseCtrlValues['cornerOutDown'][0], dMergedPoseCtrlValues['cornerOut'][0]))
    if dMergedPoseCtrlValues['cornerInUp'][0] != dMergedPoseCtrlValues['cornerIn'][0]:
        raise Exception(f'cornerPose "InUp" needs to have the same X value as "In" (%0.3f, %0.3f)' % (dMergedPoseCtrlValues['cornerInUp'][0], dMergedPoseCtrlValues['cornerIn'][0]))
    if dMergedPoseCtrlValues['cornerInDown'][0] != dMergedPoseCtrlValues['cornerIn'][0]:
        raise Exception(f'cornerPose "InDown" needs to have the same X value as "In" (%0.3f, %0.3f)' % (dMergedPoseCtrlValues['cornerInDown'][0], dMergedPoseCtrlValues['cornerIn'][0]))


    sDefaultSettingAttrs = []
    utils.data.store('bMouthSplines%s' % sSuffix, bSPLINES)

    # xMirrorAxis = sMirrorJointAxes[suf] if suf < len(sMirrorJointAxes) else None
    fLipCtrlScale = 1.0
    sInputCurveInner = 'bpCurve_m_lipsInner%s' % sSuffix
    sInputCurveOuter = 'bpCurve_m_lipsOuter%s' % sSuffix

    sBpCurvesA = ['bpCurve_m_%sLipInner%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]
    sBpCurvesB = ['bpCurve_m_%sLipOuter%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]

    utils.data.store('sBpCurvesA%s' % sSuffix, sBpCurvesA)
    utils.data.store('sBpCurvesB%s' % sSuffix, sBpCurvesB)

    # aHeadMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')
    if cmds.objExists('bp_m_mouthPivot'):
        aMouthSlideMatrix = utils.getNumpyMatrixFromTransform('bp_m_mouthPivot')
    else:
        aMouthSlideMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')

    aMouthRotationSlideMatrix = aMouthSlideMatrix[0:3,0:3]
        

    if bFlipInnerMouthBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs(sInputCurveInner, 'locA_m_lipsInner%s' % sSuffix,
                                                'locB_m_lipsInner%s' % sSuffix, sBpCurvesA[1], sBpCurvesA[0])
    else:
        curves.separateCurveUsingSeparationLocs(sInputCurveInner, 'locA_m_lipsInner%s' % sSuffix,
                                                'locB_m_lipsInner%s' % sSuffix, sBpCurvesA[0], sBpCurvesA[1])

    curves.separateCurveUsingSeparationLocs(sInputCurveOuter, 'locA_m_lipsOuter%s' % sSuffix,
                                            'locB_m_lipsOuter%s' % sSuffix, sBpCurvesB[0], sBpCurvesB[1])

    utils.data.store('bLipCurves%s' % sSuffix, True)
    fMouthCurveEndsDistance = barycentric.distanceBetween('%s.cv[0]' % sBpCurvesA[0], '%s.cv[%d]' % (sBpCurvesA[0], len(cmds.ls('%s.cv[*]' % sBpCurvesA[0], flatten=True))-1))
    utils.data.store('fMouthCurveEndsDistance%s' % sSuffix, fMouthCurveEndsDistance)
    fMouthSliderScale = fMouthCurveEndsDistance * 0.25

    aBotMiddle = curves.getPointsFromPercs(sBpCurvesA[0], [0.5], bReturnNumpy=True)[0]
    aTopMiddle = curves.getPointsFromPercs(sBpCurvesA[1], [0.5], bReturnNumpy=True)[0]
    aMouthCtrlFront = (aTopMiddle + aBotMiddle) * 0.5 + np.array([0,0,fMouthSliderScale*0.5], dtype='float64')

    sMouthTransformOrigin = cmds.createNode('transform', n='sMouthTransformOrigin', p=getFaceGrp())

    cmds.setAttr('%s.t' % sMouthTransformOrigin, *list(aMouthCtrlFront))
    sMouthGrpJoints = cmds.createNode('transform', n='grp_m_mouthJoints',
                                      p=sMouthTransformOrigin)  # an origin group, because below are nodes getting curveInfo datas
    cmds.move(0, 0, 0, sMouthGrpJoints, ws=True, a=True)

    iMidInd = 1
    aCtrlPercs = np.array([0.0, 0.5, 1.0], dtype='float64')

    # else:
    #     iMidInd = 3
    #     aCtrlPercs = np.array([0.0, 0.1667, 0.3334, 0.5, 0.6667, 0.833334, 1.0], dtype='float64')

    sCtrlBpCurves = sBpCurvesA if bSPLINES else sBpCurvesB


    ffCtrlPoints = []
    ffCtrlPoints.append(curves.getPointsFromPercs(sCtrlBpCurves[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPoints.append(curves.getPointsFromPercs(sCtrlBpCurves[1], aCtrlPercs, bReturnNumpy=True))

    ffCtrlPointsB = []
    # not finding bpCurve_m_botLipOuter
    ffCtrlPointsB.append(curves.getPointsFromPercs(sBpCurvesB[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPointsB.append(curves.getPointsFromPercs(sBpCurvesB[1], aCtrlPercs, bReturnNumpy=True))

    aMouthCtrlsOffset = np.array([0,0,0]) if bSPLINES else np.array([0, 0, fMouthCurveEndsDistance * 0.1], dtype='float64')

    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sTargets = set(utils.data.get('sBakedBlendshapeTargets%s' % sSuffix, xDefault=[]))

    aCornerTangent = curves.getTangentsFromPercs(sBpCurvesA[0], [0.1], bReturnNumpy=True)[0]

    if bCorners:
        cCorners = ctrls8.createSliderCtrl('lipsCorner%s' % sSuffix, 'l', fBpPos=ffCtrlPoints[0][0] + aMouthCtrlsOffset,
                                           fRangeX=[-1.0, 1.0], fRangeY=[-1.0, 1.0], fRangeZ=[-1,1] if bSPLINES else [0,0],
                                           sShape='cube', sAttach=None if bSPLINES else sModel, bBorder=bBorders,
                                           bPoly=bPolyCtrls, fScale=fMouthSliderScale,
                                           xMirrorAxis=xMirrorAxis, sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                            dAlignVectors = {'sAim': aMouthRotationSlideMatrix[0],
                                                             'sUp': -aCornerTangent,
                                                             'fAimVector': [0, 1, 0], 'fUpVector': [1, 0, 0]})

        if bSPLINES:

            for cC in cCorners:
                cC.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[2:]])
                cC.sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                                '%s.worldInverseMatrix' % cC.sExtraMove,
                                                                '%s.worldMatrix' % cC.sPasser])
                cC.sJumpedPos = nodes.createDecomposeMatrix(cC.sJumpedMatrix)

        cCorners[0].fPerc = 0
        cCorners[1].fPerc = 1


        if bSPLINES:
            for s,sSide in enumerate(['l','r']):
                cmds.xform('sliderBp_%s_lipsCorner' % sSide, t=ffCtrlPoints[0][0 if s == 0 else -1], ws=True)

    else:
        if bSPLINES:
            raise Exception('bCorners needs to be On if bSPLINES is on')
        cCorners = []

    # bot top ctrls
    if bFrontBoxCtrls:
        cBot = ctrls8.createSliderCtrl('mouthBot%s' % sSuffix, 'm', sShape='cube', fBpPos=ffCtrlPoints[0][iMidInd] + aMouthCtrlsOffset,
                                bBorder=False, fScaleShape=[1, 0.1, 0.1], fRangeX=[-1, 1], fRangeY=[-1, 1], fRangeZ=[-1, 1],
                                sAttach=None if bSPLINES else sModel,
                                sAddAttrs=['rx', 'ry', 'rz'] if bSPLINES else [])[0]
        cmds.setAttr('%s.s' % cBot.sSlider, fMouthSliderScale, fMouthSliderScale, fMouthSliderScale)
        cTop = ctrls8.createSliderCtrl('mouthTop%s' % sSuffix, 'm', sShape='cube', fBpPos=ffCtrlPoints[1][iMidInd] + aMouthCtrlsOffset,
                                bBorder=False, fScaleShape=[1, 0.1, 0.1], fRangeX=[-1, 1], fRangeY=[-1, 1], fRangeZ=[-1, 1],
                                sAttach=None if bSPLINES else sModel,
                                sAddAttrs=['rx', 'ry', 'rz'] if bSPLINES else [])[0]
        cmds.setAttr('%s.s' % cTop.sSlider, fMouthSliderScale, fMouthSliderScale, fMouthSliderScale)
        cBot.fPerc = 0.5
        cTop.fPerc = 0.5
        cBotTops = [cBot, cTop]

    else:
        cBotTops = []

    sLowerDown = 'lowerDown%s' % sSuffix
    sLowerUp = 'lowerUp%s' % sSuffix
    sUpperDown = 'upperDown%s' % sSuffix
    sUpperUp = 'upperUp%s' % sSuffix

    if bSPLINES:
        fLowerRangeY = [-1,1]
        fLowerRangeX = [-1,1]
        fLowerRangeZ = [-1,1]
        fUpperRangeY = [-1,1]
        fUpperRangeX = [-1,1]
        fUpperRangeZ = [-1,1]
    else:
        if sLowerDown in sTargets or sLowerUp in sTargets:
            fLowerRangeY = [-1.0 if sLowerDown in sTargets else 0.0, 1.0 if sLowerUp in sTargets else 0.0]
        else:
            fLowerRangeY = [-1,0] # just to have a default
        fLowerRangeX = [0,0]
        fLowerRangeZ = [0,0]
        if sUpperDown in sTargets or sUpperUp in sTargets:
            fUpperRangeY = [-1.0 if sUpperDown in sTargets else 0.0, 1.0 if sUpperUp in sTargets else 0.0]
        else:
            fUpperRangeY = [0,1] # just to have a default
        fUpperRangeX = [0,0]
        fUpperRangeZ = [0,0]


    if fLeftLipParamPercs != None:
        fLeftLipParamPercs.sort()
        if fLeftLipParamPercs[-1] > 0.5:
            raise Exception('fLeftLipParamPercs values can only go from 0 to 0.5')

        aParams = np.array(fLeftLipParamPercs) * curves.getParamLength(sCtrlBpCurves[0]) # we have to do params, because it will be calculated faster for each mesh point later
        aPercs = curves.getPercsFromParams(sCtrlBpCurves[0], aParams)
        aLeftLowerPoints = curves.getPointsFromPercs(sCtrlBpCurves[0], aPercs, bReturnNumpy=True)
        aLeftLowerTangents = curves.getTangentsFromPercs(sCtrlBpCurves[0], aPercs, bReturnNumpy=True)

        cBotLips = [None] * (len(fLeftLipParamPercs) * 2)
        if fLeftLipParamPercs[-1] == 0.5:
            cBotLips = cBotLips[:-1]


        for i, aPoint in enumerate(aLeftLowerPoints):
            sS = 'm' if fLeftLipParamPercs[i] == 0.5 else 'l'
            if fLeftLipParamPercs[i] == 0.5:
                sI = ''
            elif len(fLeftLipParamPercs) <= 2:
                sI = ''
            else:
                sI = '%d' % i

            sAddAttrs = []
            if bSPLINES:
                sAddAttrs = ['rx', 'ry', 'rz', 'sx', 'sy', 'sz']
            elif bFEATURES:
                sAddAttrs = ['tx','ty','tz','rx']

            # if sS == 'm':
            #     aPoint[0] = 0.0
            sCtrlName = 'lipsBot%s%s' % (sI, sSuffix) if len(aLeftLowerPoints[aLeftLowerPoints<0.5]) == 1 or sS == 'm' else 'lipsBot%s%s%s' % (sI, utils.getLetter(i), sSuffix)
            _cCtrls = ctrls8.createSliderCtrl(sCtrlName, sSide=sS, fBpPos=aPoint + aMouthCtrlsOffset, bRedoTranslation=True,
                                              sAttach=None if bSPLINES else sModel, fRangeY=[-1,1] if bFEATURES else fLowerRangeY, fRangeX=[-1,1] if bFEATURES else fLowerRangeX, fRangeZ=[-1,1] if bFEATURES else fLowerRangeZ, bPoly=bPolyCtrls,
                                              fScale=fMouthSliderScale,
                                              dAlignVectors={'sAim':-aMouthRotationSlideMatrix[2] if sS == 'm' else -aLeftLowerTangents[i],
                                                             'sUp':aMouthRotationSlideMatrix[0],
                                                             'fAimVector':[1,0,0], 'fUpVector':[0,1,0]},
                                              xMirrorAxis=xMirrorAxis, bBorder=bBorders, sAddAttrs=sAddAttrs)
            _cCtrls[0].fPerc = fLeftLipParamPercs[i]
            if sS == 'l':
                _cCtrls[1].fPerc = 1.0 - fLeftLipParamPercs[i]
            cBotLips[i] = _cCtrls[0]
            if sS == 'l':
                cBotLips[-(i + 1)] = _cCtrls[1]

        if fLeftLipParamPercs[-1] == 0.5:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-2::-1]]
        else:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-1::-1]]
        dSplitAlongCurve = {'ssAttrs': [['%s.ty' % cC.sCtrl for cC in cBotLips]],
                            'ffValues': [[-1.0] * len(cBotLips)],
                            'fParams': fPassParams,
                            'sCurve': sBpCurvesA[0]}
        utils.data.store('dLipSplitAlongCurve%s' % sSuffix, dSplitAlongCurve)


        # top
        aLeftUpperPoints = curves.getPointsFromPercs(sCtrlBpCurves[1], aPercs, bReturnNumpy=True)
        aLeftUpperTangents = curves.getTangentsFromPercs(sCtrlBpCurves[1], aPercs, bReturnNumpy=True)

        cTopLips = [None] * (len(fLeftLipParamPercs)*2)
        if fLeftLipParamPercs[-1] == 0.5:
            del cTopLips[-1]

        for i, aPoint in enumerate(aLeftUpperPoints):
            sS = 'm' if fLeftLipParamPercs[i] == 0.5 else 'l'
            if fLeftLipParamPercs[i] == 0.5:
                sI = ''
            elif len(fLeftLipParamPercs) <= 2:
                sI = ''
            else:
                sI = '%d' % i

            if bSPLINES:
                sAddAttrs = ['rx', 'ry', 'rz', 'sx', 'sy', 'sz']
            elif bFEATURES:
                sAddAttrs = ['tx','ty','tz','rx']
            # if sS == 'm':
            #     aPoint[0] = 0.0
            sCtrlName = 'lipsTop%s%s' % (sI, sSuffix) if len(aLeftLowerPoints[aLeftLowerPoints<0.5]) == 1 or sS == 'm' else 'lipsTop%s%s%s' % (sI, utils.getLetter(i), sSuffix)
            _cCtrls = ctrls8.createSliderCtrl(sCtrlName, sSide=sS, fBpPos=aPoint+aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel, bRedoTranslation=True,
                                              fRangeX=[-1,1] if bFEATURES else fUpperRangeX, fRangeY=[-1,1] if bFEATURES else fUpperRangeY, fRangeZ=[-1,1] if bFEATURES else fUpperRangeZ, bPoly=bPolyCtrls,
                                              fScale=fMouthSliderScale,
                                              dAlignVectors={'sAim':-aMouthRotationSlideMatrix[2] if sS == 'm' else -aLeftUpperTangents[i],
                                                             'sUp':aMouthRotationSlideMatrix[0],
                                                             'fAimVector':[1,0,0], 'fUpVector':[0,1,0]},
                                              xMirrorAxis=xMirrorAxis,
                                              sAddAttrs=sAddAttrs,
                                              bBorder=bBorders)
            # cmds.transformLimits(_cCtrls[0].sCtrl, sy=(0.1,5), esy=(True, True))
            # cmds.transformLimits(_cCtrls[0].sCtrl, sz=(0.1,5), esz=(True, True))
            # cmds.transformLimits(_cCtrls[1].sCtrl, sy=(0.1,5), esy=(True, True))
            # cmds.transformLimits(_cCtrls[1].sCtrl, sz=(0.1,5), esz=(True, True))

            _cCtrls[0].fPerc = fLeftLipParamPercs[i]
            if sS == 'l':
                _cCtrls[1].fPerc = 1.0 - fLeftLipParamPercs[i]
            cTopLips[i] = _cCtrls[0]
            if sS == 'l':
                cTopLips[-(i+1)] = _cCtrls[1]

        if fLeftLipParamPercs[-1] == 0.5:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-2::-1]]
        else:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-1::-1]]

        dSplitAlongCurve = {'ssAttrs':[['%s.ty' % cC.sCtrl for cC in cTopLips]],
                         'ffValues':[[1.0] * len(cTopLips)],
                         'fParams':fPassParams,
                         'sCurve':sBpCurvesA[1]}
        utils.data.store('dUpperSplitAlongCurve%s' % sSuffix, dSplitAlongCurve)

    else: # we should be able to get rid of this
        # lower simple left/right
        aLeftLowerPoint = curves.getPointsFromPercs(sCtrlBpCurves[0], [0.33], bReturnNumpy=True)[0]
        aLeftLowerTangent = curves.getTangentsFromPercs(sCtrlBpCurves[0], [0.33], bReturnNumpy=True)[0]

        cBotLips = ctrls8.createSliderCtrl('lipsBot%s' % sSuffix, sSide='l',
                                           fBpPos=aLeftLowerPoint + aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel,
                                           fRangeX=fLowerRangeX, fRangeY=fLowerRangeY, fRangeZ=fLowerRangeZ, bPoly=bPolyCtrls,
                                           fScale=fMouthSliderScale, sAlignOnModel=[sModel, sLowerUp, sLowerDown],
                                           xMirrorAxis=xMirrorAxis,
                                           sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                           bBorder=bBorders,
                                           dAlignVectors={'sAim': -aLeftLowerTangent, 'sUp': aMouthRotationSlideMatrix[0], 'fAimVector': [1, 0, 0], 'fUpVector': [0, 1, 0]},
                                           )
        cBotLips[0].fPerc = 0.333
        cBotLips[1].fPerc = 0.667
        utils.data.store('sLipBotCtrls', [cBotLips[0].sCtrl, cBotLips[1].sCtrl])


        # upper simple left/right
        aLeftUpperPoint = curves.getPointsFromPercs(sCtrlBpCurves[1], [0.333], bReturnNumpy=True)[0]
        aLeftUpperTangent = curves.getTangentsFromPercs(sCtrlBpCurves[1], [0.33], bReturnNumpy=True)[0]

        cTopLips = ctrls8.createSliderCtrl('lipsTop%s' % sSuffix, sSide='l', fBpPos=aLeftUpperPoint+aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel,
                                            fRangeX=fUpperRangeX, fRangeY=fUpperRangeY, fRangeZ=fUpperRangeZ, bPoly=bPolyCtrls,
                                            fScale=fMouthSliderScale, sAlignOnModel=[sModel, sLowerUp, sLowerDown], xMirrorAxis=xMirrorAxis,
                                            sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                            dAlignVectors={'sAim': -aLeftUpperTangent, 'sUp': aMouthRotationSlideMatrix[0], 'fAimVector': [1, 0, 0], 'fUpVector': [0, 1, 0]},
                                           bBorder=bBorders)
        cTopLips[0].fPerc = 0.333
        cTopLips[1].fPerc = 0.667
        utils.data.store('sLipTopCtrls', [cTopLips[0].sCtrl, cTopLips[1].sCtrl])


    ccLipCtrls = [cBotLips, cTopLips]

    for cCtrl in cBotLips + cTopLips:
        cCtrl.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[2:]])

    # if bSPLINES:
    #     for cCtrl in cBotLips+cTopLips:
    #         ctrls8.createExtraMoveTransformAndTag(cCtrl, [sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[2:]])

    sOrientGuide = xforms.createTransform('lipsOrientGuide', sMatch='jnt_m_headMain')
    if cmds.objExists('bp_m_mouthPivot'):
        cmds.delete(cmds.orientConstraint('bp_m_mouthPivot', sOrientGuide))
    cmds.rotate(90, 90, 0, sOrientGuide, os=True, r=True)
    
    
    # cMouthTransform
    cMouth = ctrls8.createSliderCtrl('mouth%s' % sSuffix, 'm', sShape='locator', sMatch=sOrientGuide, fBpPos=aMouthCtrlFront,
                                  bBorder=False, fScaleShape=[1,1,1], fRangeX=[-1,1], fRangeY=[-1,1], fRangeZ=[-1,1], bSuper=bSPLINES,
                                  sAttach=sParentJoint if bSPLINES else sModel, fScale=fMouthSliderScale, sAddAttrs=['t', 'r', 's'] if bSPLINES else [])[0]
    fOutScale =  cmds.xform(cMouth.sOut, q=True, s=True, ws=True)
    cmds.setAttr('%s.s' % cMouth.sOut, 1.0 / fOutScale[0], 1.0 / fOutScale[1], 1.0 / fOutScale[2])

    if False:
        cmds.connectAttr('%s.sx' % cMouth.sCtrl, '%s.sy' % cMouth.sCtrl)
        cmds.connectAttr('%s.sx' % cMouth.sCtrl, '%s.sz' % cMouth.sCtrl)
        cmds.setAttr('%s.sz' % cMouth.sCtrl, lock=True) #, keyable=False, channelBox=False)
        cmds.setAttr('%s.sy' % cMouth.sCtrl, lock=True) #, keyable=False, channelBox=False)

    if bSPLINES:
        cMouth.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[2:]])
        iIdsAlongCurve = cmds.kt_findClosestPoints(fromMesh=sInputCurveInner, toMesh=sAttachMesh, vertex=True)
        iIdsAlongCurve = [int(iId) for iId in iIdsAlongCurve]
        utils.addStringAttr(cMouth.sPasser, 'iIdsAlongCurve', iIdsAlongCurve, bLock=True)

    cMouth.fPerc = 0.5
    cAllCtrls = ccLipCtrls[0] + ccLipCtrls[1] + cCorners + cBotTops + [cMouth]
    if bCorners:
        ccRows = [[cCorners[0]] + ccLipCtrls[0] + [cCorners[1]],
                  [cCorners[0]] + ccLipCtrls[1] + [cCorners[1]]]
    else:
        ccRows = ccLipCtrls
    utils.data.store('lipsBotRow', [cC.sCtrl for cC in ccRows[0]])
    utils.data.store('lipsTopRow', [cC.sCtrl for cC in ccRows[1]])
    if bSPLINES:
        for cC in ccRows[0] + ccRows[1][1:-1]:
            utils.addAttr(cC.sCtrl, ln='bSkipUnrealCreation', at='bool', dv=True)

    for cC in ccLipCtrls[0][::-1] + ccLipCtrls[1][::-1] + cCorners[::-1]:
        cmds.controller(cC.sCtrl, cMouth.sCtrl, parent=True)


    if bSPLINES or not bLimitOnNonSplineMode:
        for cC in cAllCtrls:
            cmds.transformLimits(cC.sCtrl, etx=[False, False], ety=[False, False], etz=[False, False])
            ctrls8.disconnectFromSliderBp(cC)

        # need to set cMouth back because it's used for funnel and lipPress
        cmds.transformLimits(cMouth.sCtrl, etz=[True, True])


    bMouthSplinesExecuted = False

    # EXCLUDE START MOUTHSPLINES

    if bSPLINES:
        bMouthSplinesExecuted = True
        sGrp = cmds.createNode('transform', n='grp_mouthSplines', p='modules')

        sParentGrp = cmds.createNode('transform', n='grp_mouthSplinesParentJoint', p=sGrp)
        constraints.matrixParentConstraint(sParentJoint, sParentGrp)


        dDriverPerCtrlsForLipPush = defaultdict(dict)
        dPoseOffsetAdditions = {}
        dPoseOffsets = {}
        def addPoseLocToPoseOffset(sCtrl, sPoseKey, sDriverOutput):
            sPoseOffset = dPoseOffsets[sCtrl]
            sPoseLoc = xforms.createLocator(f"_poseLoc__{sCtrl.replace('_ctrl', '')}__{sPoseKey}", sParent=cmds.listRelatives(sPoseOffset, p=True))
            utils.connectPosesLocVis(sPoseLoc)
            sTranslationAdditionNode, sRotationAdditionNode, sScaleAdditionNode, iAdditionSize = dPoseOffsetAdditions[sCtrl]

            sTranslationPoseMultipl = nodes.createVectorMultiplyNode('%s.t' % sPoseLoc, sDriverOutput, bVectorByScalar=True)
            cmds.connectAttr(sTranslationPoseMultipl, '%s.input3D[%d]' % (sTranslationAdditionNode, iAdditionSize))
            sRotationPoseMultipl = nodes.createVectorMultiplyNode('%s.r' % sPoseLoc, sDriverOutput, bVectorByScalar=True)
            cmds.connectAttr(sRotationPoseMultipl, '%s.input3D[%d]' % (sRotationAdditionNode, iAdditionSize))
            sScalePoseMultipl = nodes.createVectorMultiplyNode(nodes.createVectorAdditionNode(['%s.s' % sPoseLoc, [1,1,1]], sOperation='minus'), sDriverOutput, bVectorByScalar=True)
            cmds.connectAttr(sScalePoseMultipl, '%s.input3D[%d]' % (sScaleAdditionNode, iAdditionSize+1))

            iAdditionSize += 1
            dPoseOffsetAdditions[sCtrl][-1] = iAdditionSize
            sDefaultSettingAttrs.append('%s.t' % sPoseLoc)
            sDefaultSettingAttrs.append('%s.r' % sPoseLoc)
            sDefaultSettingAttrs.append('%s.s' % sPoseLoc)
            cmds.connectAttr(sDriverOutput, '%s.v' % sPoseLoc)
            dDriverPerCtrlsForLipPush[sCtrl][sPoseKey] = sDriverOutput

        def addPoseOffsets(cAddPosingCtrls):
            for cC in utils.flattenedList(cAddPosingCtrls):
                sPoseOffset = cC.appendOffsetGroup('poses')
                sTranslationAdditionOutput = nodes.createVectorAdditionNode([], sTarget='%s.t' % sPoseOffset)
                sRotationAdditionOutput = nodes.createVectorAdditionNode([], sTarget='%s.r' % sPoseOffset)
                sScaleAdditionOutput = nodes.createVectorAdditionNode([[1,1,1]], sTarget='%s.s' % sPoseOffset)
                dPoseOffsetAdditions[cC.sCtrl] = [sTranslationAdditionOutput.split('.')[0], sRotationAdditionOutput.split('.')[0], sScaleAdditionOutput.split('.')[0], 0]
                dPoseOffsets[cC.sCtrl] = sPoseOffset


        addPoseOffsets(ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners)# + cCornerTangents



        for cC in cBotTops:
            cC.sPivot = cC.appendOffsetGroup('pivot', sAboveOtherOffset='poses')
            nodes.createVectorMultiplyNode('%s.t' % cC.sPivot, -1.0, bVectorByScalar=True, sTarget='%s.t' % cC.sOut)
            cC.createExtraMoveTransformAndTag(ctrls8.kDefaultFaceAttachDeformers[2:])
            sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut,
                                                        '%s.worldInverseMatrix' % cC.sExtraMove])
            cC.sJumped = cmds.duplicate(cC.sExtraMove, po=True, n=utils.replaceStringEnd(cC.sCtrl, '_ctrl', '_jumped'))[0]
            nodes.createDecomposeMatrix(sJumpedMatrix, sTargetPos='%s.t' % cC.sJumped, sTargetRot='%s.r' % cC.sJumped, sTargetScale='%s.s' % cC.sJumped)
            cC.sJumpedMatrix = '%s.worldMatrix' % cC.sJumped
            # cC.sJumpedInverseMatrix = '%s.worldInverseMatrix' % cC.sJumped

            sRemoveTwistGrp = xforms.insertParent(cC.sOut, '%s.NoTwist' % cC.sOut, bMatchParentTransform=True)
            sAimConstraint = constraints.aimConstraintEmpty(sRemoveTwistGrp)
            nodes.createVectorAdditionNode([[1,0,0]], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            sParentMatrixInLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cmds.listRelatives(cC.getOffsetByName('poses'), p=True)[0],
                                                              '%s.worldInverseMatrix' % cC.sCtrl])
            nodes.createPointByMatrixNode([0,1,0], nodes.getRotationMatrix2(sParentMatrixInLocal), sTarget='%s.worldUpVector' % sAimConstraint)
            cC.sTwistAttr = xforms.getSignedAngle3(cC.sCtrl, sRemoveTwistGrp, 0, bDebugAttr=True)


        for p,sPart in enumerate(['bot','top']):
            for cC in ccRows[p][1:-1]:
                cC.sPivot = cC.appendOffsetGroup('pivot', sAboveOtherOffset='poses')

        fCurveLengthes = [curves.getLength(sBpCurvesA[0]), curves.getLength(sBpCurvesA[1])]



        # slide pivots
        sSlideBp = 'bp_m_mouthPivot'
        sMouthPivot = xforms.createLocator('loc_m_mouthPivot', sParent=sParentGrp, sMatch=sSlideBp, fSize=fCurveLengthes[0]*0.035)
        xforms.insertParent(sMouthPivot, 'grp_m_mouthPivotParent')

        fPivotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sMouthPivot, '%s.worldInverseMatrix' % cMouth.sSuper], bJustValues=True)
        nodes.createMultMatrixNode([fPivotOffset,
                                    '%s.worldMatrix' % cMouth.sSuper,
                                    '%s.worldInverseMatrix' % cMouth.sExtraMove,
                                    '%s.worldMatrix' % cMouth.sPasser,
                                    '%s.worldInverseMatrix' % cmds.listRelatives(sMouthPivot, p=True)[0]],
                                   sTarget='%s.offsetParentMatrix' % sMouthPivot)
        cmds.setAttr('%s.superVIS' % cMouth.sCtrl, True)


        sMouthPivotFront = 'jnt_m_mouthPivotFrontHead'
        if cmds.objExists(sMouthPivotFront):
            cmds.parent(sMouthPivotFront, sParentJoint)
            cmds.delete(cmds.parentConstraint(cMouth.sCtrl, sMouthPivotFront))
        else:
            xforms.createJoint(sMouthPivotFront, sParent=sParentJoint, sMatch=cMouth.sCtrl)
        cmds.setAttr('%s.segmentScaleCompensate' % sMouthPivotFront, False)

        sMouthPivotFrontRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sMouthPivotFront)
        sMouthPivotFrontInvRotationMatrix = nodes.createInverseMatrix(sMouthPivotFrontRotationMatrix)

        sGrpMouthPivotFront = xforms.createTransform('grp_m_mouthPivotFront', sParent=sParentGrp, sMatch=cMouth.sCtrl)#, fSize=fCurveLengthes[0]*0.05) # it was a joint before... why?
        sAnimMatrix = nodes.createComposeMatrixNode(xRotate='%s.r' % cMouth.sCtrl, xScale='%s.s' % cMouth.sCtrl)
        fMouthPivotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sMouthPivotFront, '%s.worldInverseMatrix' % sMouthPivot], bJustValues=True)
        sFrontMatrix = nodes.createMultMatrixNode([sAnimMatrix,
                                                   fMouthPivotOffset,
                                                   '%s.worldMatrix' % sMouthPivot,
                                                   '%s.worldInverseMatrix' % sParentJoint])
        nodes.createDecomposeMatrix(sFrontMatrix, sTargetPos='%s.t' % sMouthPivotFront, sTargetRot='%s.r' % sMouthPivotFront, sTargetScale='%s.s' % sMouthPivotFront)
        nodes.createDecomposeMatrix(sFrontMatrix, sTargetPos='%s.t' % sGrpMouthPivotFront, sTargetRot='%s.r' % sGrpMouthPivotFront, sTargetScale='%s.s' % sGrpMouthPivotFront)


        sLipsCtrlsParent = cmds.createNode('transform', n='lipsCtrlParent', p='faceCtrls')
        constraints.matrixParentConstraint(sMouthPivotFront, sLipsCtrlsParent)
        cmds.parent([cC.sPasser for cC in utils.flattenedList(ccRows)], sLipsCtrlsParent)
        cmds.parent(cBotTops[0].sPasser, cBotTops[1].sPasser, sLipsCtrlsParent)



        sJawMouthPivot = 'jnt_m_mouthPivotFrontJaw'
        if cmds.objExists(sJawMouthPivot):
            cmds.parent(sJawMouthPivot, sParentJoint)
            xforms.resetTransform(sJawMouthPivot, jo=True)
            cmds.delete(cmds.parentConstraint(sJawJoint, sJawMouthPivot))
        else:
            xforms.createJoint(sJawMouthPivot, sParent=sParentJoint, sMatch=sJawJoint)

        cmds.setAttr('%s.segmentScaleCompensate' % sMouthPivotFront, False)
        utils.matchJointRadius([sMouthPivotFront, sJawMouthPivot], 'jnt_m_headMain', 0.1)

        sJawSliderFrontMatrix = nodes.createMultMatrixNode([sAnimMatrix,
                                                        nodes.createMultMatrixNode(['%s.worldMatrix' % cMouth.sCtrl, '%s.worldInverseMatrix' % sJawJoint], bJustValues=True),
                                                       '%s.worldMatrix' % sJawJoint,
                                                       '%s.worldInverseMatrix' % sParentJoint,
                                                       nodes.createMultMatrixNode(['%s.worldMatrix' % sParentJoint, '%s.worldInverseMatrix' % sMouthPivot], bJustValues=True),
                                                       '%s.worldMatrix' % sMouthPivot,
                                                       '%s.worldInverseMatrix' % sParentJoint], sName='jawSliderMatrix')
        nodes.createDecomposeMatrix(sJawSliderFrontMatrix, sTargetPos='%s.t' % sJawMouthPivot, sTargetRot='%s.r' % sJawMouthPivot)#, sTargetScale='%s.s' % sJawMouthPivot)
        cmds.connectAttr('%s.s' % sMouthPivotFront, '%s.s' % sJawMouthPivot)

        sJawSliderRotateMatrix = nodes.getRotationMatrix2(nodes.createMultMatrixNode(['%s.worldMatrix' % sJawMouthPivot, '%s.worldInverseMatrix' % sMouthPivotFront]),
                                                          bScale=False, sName='rotJawSliderMatrix')
        deformers.resetJointReferences([sMouthPivotFront, sJawMouthPivot])


        sHorizontalStrengthRotate = utils.addAttr(cMouth.sPasser, ln='horizontalRotateStrength', dv=10, k=True)
        sHorizontalStrengthRotateTwist = utils.addAttr(cMouth.sPasser, ln='horizontalRotateTwistStrength', dv=0, k=False)
        sHorizontalStrengthRotateVert = utils.addAttr(cMouth.sPasser, ln='horizontalRotateVertStrength', dv=0, k=False)
        sHorizontalStrengthTranslateAttr = [utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthX', k=True),
                                            utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthY', k=True),
                                            utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthZ', k=True)]
        sDefaultSettingAttrs.extend([sHorizontalStrengthRotate, sHorizontalStrengthRotateTwist, sHorizontalStrengthRotateVert])
        sDefaultSettingAttrs.extend(sHorizontalStrengthTranslateAttr)

        sVerticalStrengthRotate = utils.addAttr(cMouth.sPasser, ln='verticalRotateStrength', dv=5, k=True)
        sVerticalStrengthRotateTwist = utils.addAttr(cMouth.sPasser, ln='verticalRotateTwistStrength', dv=0, k=True)
        sVerticalStrengthRotateHoriz = utils.addAttr(cMouth.sPasser, ln='verticalRotateHorizStrength', dv=0, k=True)
        sVerticalStrengthTranslateAttr = [utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthX', k=True),
                                          utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthY', k=True),
                                          utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthZ', k=True)]
        sDefaultSettingAttrs.extend([sVerticalStrengthRotate, sVerticalStrengthRotateTwist, sVerticalStrengthRotateHoriz])
        sDefaultSettingAttrs.extend(sVerticalStrengthTranslateAttr)

        sMouthX = '%s.tx' % cMouth.sCtrl
        sMouthY = '%s.ty' % cMouth.sCtrl
        sMouthAbsX = nodes.createAbsoluteNode(sMouthX)
        sMouthAbsY = nodes.createAbsoluteNode(sMouthY)


        fMouthTranslateMultiplier = fCurveLengthes[0]*0.035
        utils.data.store('fMouthTranslateMultiplier', fMouthTranslateMultiplier)
        sVerticalStrengthTranslateAttr = nodes.createVectorMultiplyNode(sVerticalStrengthTranslateAttr, [-1, 1, -1])
        sVerticalStrengthTranslateAttr = ['%sY' % sVerticalStrengthTranslateAttr, '%sZ' % sVerticalStrengthTranslateAttr, '%sX' % sVerticalStrengthTranslateAttr]
        sVerticalStrengthTranslate = nodes.createVectorMultiplyNode(sVerticalStrengthTranslateAttr, fMouthTranslateMultiplier, bVectorByScalar=True)
        sVertResult = nodes.createVectorMultiplyNode(sVerticalStrengthTranslate, [sMouthY, sMouthAbsY, sMouthAbsY])

        sHorizontalStrengthTranslateAttr = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslateAttr, [-1, 1, -1])
        sHorizontalStrengthTranslateAttr = ['%sY' % sHorizontalStrengthTranslateAttr, '%sZ' % sHorizontalStrengthTranslateAttr, '%sX' % sHorizontalStrengthTranslateAttr]
        sHorizontalStrengthTranslate = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslateAttr, fMouthTranslateMultiplier, bVectorByScalar=True)
        sHorizResult = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslate, [sMouthAbsX, sMouthAbsX, sMouthX])
        nodes.createVectorAdditionNode([sVertResult, sHorizResult], sTarget='%s.t' % sMouthPivot)



        sHorizontalRotateResults = [nodes.createMultiplyNode(sHorizontalStrengthRotate, '%s.tx' % cMouth.sCtrl),
                                    nodes.createMultiplyNode(sHorizontalStrengthRotateTwist, '%s.tx' % cMouth.sCtrl),
                                    nodes.createMultiplyNode(sHorizontalStrengthRotateVert, nodes.createAbsoluteNode('%s.tx' % cMouth.sCtrl))]
        sVerticalRotateResults =  [nodes.createMultiplyNode(sVerticalStrengthRotateHoriz, nodes.createAbsoluteNode('%s.ty' % cMouth.sCtrl)),
                                   nodes.createMultiplyNode(sVerticalStrengthRotateTwist, '%s.ty' % cMouth.sCtrl),
                                   nodes.createMultiplyNode(sVerticalStrengthRotate, '%s.ty' % cMouth.sCtrl)]

        nodes.createVectorAdditionNode([sHorizontalRotateResults, sVerticalRotateResults], sTarget='%s.r' % sMouthPivot)

        sFrontPivotRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sMouthPivotFront)
        sFrontPivotRotationInverseMatrix = nodes.createInverseMatrix(sFrontPivotRotationMatrix)
        constraints.matrixParentConstraint(sJawMouthPivot, cBotTops[0].sPasser, mo=True)
        constraints.matrixParentConstraint(sMouthPivotFront, cBotTops[1].sPasser, mo=True)

        # static sliding curve
        aaPoints = [patch.patchFromName(sBpCurvesA[0]).getPoints(), patch.patchFromName(sBpCurvesA[1]).getPoints()]
        for p in range(2):
            aNonSkippedIndices = utils.getFilteredFromAvoidIndices(len(aaPoints[p]), iSkipSplineJoints)
            aaPoints[p] = aaPoints[p][aNonSkippedIndices]

        aaPercs = [curves.getPercsFromPoints(sBpCurvesA[0], aaPoints[0]), curves.getPercsFromPoints(sBpCurvesA[1], aaPoints[1])]
        aaOuterPoints = [curves.getPointsFromPercs(sBpCurvesB[0], aaPercs[0], bReturnNumpy=True), curves.getPointsFromPercs(sBpCurvesB[1], aaPercs[1], bReturnNumpy=True)]

        aMouthPivotFront = utils.getNumpyMatrixFromTransform(sMouthPivotFront)
        aInvMouthPivotFront = np.linalg.inv(aMouthPivotFront)
        aaLocalPoints = [np.dot(utils.makePoint4Array(aaPoints[0]), aInvMouthPivotFront)[:, 0:3],
                         np.dot(utils.makePoint4Array(aaPoints[1]), aInvMouthPivotFront)[:, 0:3]]
        aaLocalOuterPoints = [np.dot(utils.makePoint4Array(aaOuterPoints[0]), aInvMouthPivotFront)[:, 0:3],
                             np.dot(utils.makePoint4Array(aaOuterPoints[1]), aInvMouthPivotFront)[:, 0:3]]
        # iMaxCurve = np.argmax([len(aaPoints[0]), len(aaPoints[1])])


        # only creating one sliding curve - using same for the top one
        sStaticSlideCurves = ['curve_l_mouthStaticSlide', 'curve_r_mouthStaticSlide']
        sStaticSlideUpCurves = ['curve_l_mouthStaticSlideUp', 'curve_r_mouthStaticSlideUp']
        sStaticSlideCurvesBp = [utils.replaceStringStart(sStaticSlideCurves[0], 'curve_', 'bpCurve_'), utils.replaceStringStart(sStaticSlideCurves[1], 'curve_', 'bpCurve_')]
        sStaticSlideUpCurvesBp = [utils.replaceStringStart(sStaticSlideUpCurves[0], 'curve_', 'bpCurve_'), utils.replaceStringStart(sStaticSlideUpCurves[1], 'curve_', 'bpCurve_')]

        aSlidePoints = np.copy(aaPoints[0])
        if True: # averaging in X of slide pivot
            aSlidePoints4 = utils.makePoint4Array(aSlidePoints)
            aSlidePointsLocal4 = np.dot(aSlidePoints4, np.linalg.inv(aMouthSlideMatrix))
            aSlidePointsLocal4[:,0] = np.average(aSlidePointsLocal4[:,0])
            aSlidePoints = np.dot(aSlidePointsLocal4, aMouthSlideMatrix)[:,0:3]
        aSlideUpPoints = aSlidePoints + aMouthSlideMatrix[0,0:3] * fCurveLengthes[0] * 0.05

        for s,sSide in enumerate(['l','r']):
            if cmds.objExists(sStaticSlideCurvesBp[s]):
                cmds.duplicate(sStaticSlideCurvesBp[s], n=sStaticSlideCurves[s])
            else:
                if cmds.objExists(sStaticSlideCurvesBp[1-s]):
                    sMirrored = geometry.meshMirrorNoBase([patch.patchFromName(sStaticSlideCurvesBp[1-s])], bWorld=True)[0]
                    cmds.rename(sMirrored, sStaticSlideCurves[s])
                else:
                    cmds.curve(p=aSlidePoints if s==0 else aSlidePoints[::-1], d=2, n=sStaticSlideCurves[s])
            if cmds.objExists(sStaticSlideUpCurvesBp[s]):
                cmds.duplicate(sStaticSlideUpCurvesBp[s], n=sStaticSlideUpCurves[s])
            else:
                if cmds.objExists(sStaticSlideUpCurvesBp[1-s]):
                    sMirrored = geometry.meshMirrorNoBase([patch.patchFromName(sStaticSlideUpCurvesBp[1-s])])[0]
                    cmds.rename(sMirrored, sStaticSlideUpCurves[s])
                else:
                   cmds.curve(p=aSlideUpPoints if s==0 else aSlideUpPoints[::-1], d=2, n=sStaticSlideUpCurves[s])

            cmds.rebuildCurve(sStaticSlideCurves[s], kr=0, d=3, ch=False)
            cmds.rebuildCurve(sStaticSlideUpCurves[s], kr=0, d=3, ch=False)

            cmds.skinCluster(sStaticSlideCurves[s], sMouthPivotFront, tsb=True)
            cmds.skinCluster(sStaticSlideUpCurves[s], sMouthPivotFront, tsb=True)

        cmds.parent(sStaticSlideCurves, sStaticSlideUpCurves, sGrp)



        sCornerSlidePlanes = []
        sCornerSlidePlanesOrig = []
        for s,sSide in enumerate(['l','r']):
            sBpSurface = 'bpNurbs_%s_cornerSlidePlane' % sSide
            if not cmds.objExists(sBpSurface):
                sMirrorSurface = utils.getMirrorName(sBpSurface)
                if not cmds.objExists(sMirrorSurface):
                    raise Exception('Corner Slide plane missing')
                cmds.duplicate(sMirrorSurface, n=sBpSurface)
                sTemp = cmds.createNode('transform', n='tempDelete')
                cmds.parent(sBpSurface, sTemp)
                cmds.setAttr('%s.sx' % sTemp, -1)
                cmds.parent(sBpSurface, kMouthBpGroupName)
                cmds.delete(sTemp)
            sSurface = cmds.duplicate(sBpSurface, n=utils.replaceStringStart(sBpSurface, 'bpN', 'n'))[0]
            cmds.parent(sSurface, sGrpMouthPivotFront)
            cmds.makeIdentity(sSurface, apply=True, t=True, r=True, s=True)
            cmds.setAttr('%s.rotatePivot' % sSurface, 0, 0, 0)
            cmds.setAttr('%s.scalePivot' % sSurface, 0, 0, 0)

            sSurfaceOrig = cmds.duplicate(sSurface, n='%s_orig' % sSurface)[0]
            for sA in ['t','r','s']:
                cmds.connectAttr('%s.%s' % (sSurface,sA), '%s.%s' % (sSurfaceOrig,sA))
            cmds.parent(sSurfaceOrig, sGrp)

            cmds.setAttr('%s.v' % sSurface, False)
            cmds.setAttr('%s.v' % sSurfaceOrig, False)
            sCornerSlidePlanesOrig.append(sSurfaceOrig)
            sCornerSlidePlanes.append(sSurface)


        # remove the twist from the lip ctrls
        #
        for p,sPart in enumerate(['bot','top']):
            for c,cC in enumerate(ccLipCtrls[p]):
                sAimConstraint = constraints.aimConstraintEmpty(cC.sOut, bIgnoreConstraintRotateTranslateConnection=True) #, aim=[1,0,0], up=[0,1,0])
                nodes.createVectorAdditionNode([[1,0,0]], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                # nodes.createVectorAdditionNode([[1,0,0], '%s.t' % cC.sOut], sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                sParentMatrixInLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cmds.listRelatives(cC.getOffsetByName('poses'), p=True)[0],
                                                                  '%s.worldInverseMatrix' % cC.sCtrl])
                nodes.createPointByMatrixNode([0,1,0], nodes.getRotationMatrix2(sParentMatrixInLocal), sTarget='%s.worldUpVector' % sAimConstraint)
                sTwistFromBoxes = cC.appendOffsetGroup('twist', sAboveOtherOffset='poses')

                cmds.connectAttr(cBotTops[p].sTwistAttr, '%s.rx' % sTwistFromBoxes)


        sAttrs = ['tx','ty','tz','rx','ry','rz']
        ssJawSpaces = [(sJawMouthPivot, sGrpMouthPivotFront), (cBotTops[0].sJumped, sGrpMouthPivotFront), (sJawMouthPivot, cBotTops[1].sJumped)]
        sCornerNotUp = nodes.createRangeNode('lipsCorner_l_ctrl.ty', 0, 1, 1, 0), nodes.createRangeNode('lipsCorner_r_ctrl.ty', 0, 1, 1, 0)
        for cc,cCtrls in enumerate((cCorners, ccLipCtrls[0], ccLipCtrls[1])):
            for c,cC in enumerate(cCtrls):
                cC.cOrig = ctrls8.create('%sOrig' % cC.sName, cC.sSide, cC.iIndex, sMatch=cC.sCtrl, sParent=sLipsCtrlsParent, bIsNoCtrl=True, sAttrs=sAttrs)

                constraints.matrixParentConstraint(cC.sPasser, cC.cOrig.sPasser)

                sJawAttachAttr = utils.addAttr(cC.sCtrl, ln='jawAttach', min=0, max=1, dv=0, k=True)
                if 'TOP' in cC.sCtrl.upper() or 'CORNER' in cC.sCtrl.upper():
                    sJawAttach = nodes.createMultiplyNode(sJawAttachAttr, sCornerNotUp[1 if cC.sSide == 'r' else 0])
                else:
                    sJawAttach = sJawAttachAttr
                fSecondToFirst = nodes.createMultMatrixNode(['%s.worldMatrix' % ssJawSpaces[cc][0], '%s.worldInverseMatrix' % ssJawSpaces[cc][1]], bJustValues=True)
                sDefaultSettingAttrs.append(sJawAttachAttr)
                utils.addToListStringAttr(cC.sCtrl, utils.kSkipKeyImportAttrs, ['jawAttach'])
                sSecondOffsetted = nodes.createMultMatrixNode([fSecondToFirst, '%s.worldMatrix' % ssJawSpaces[cc][1]])
                sBlendMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % ssJawSpaces[cc][0], sSecondOffsetted],
                                                            [sJawAttach, nodes.createReverseNode(sJawAttach)])

                fAttachOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser, '%s.worldInverseMatrix' % ssJawSpaces[cc][0]], bJustValues=True)
                sAttachMatrix = nodes.createMultMatrixNode([fAttachOffset, sBlendMatrix, '%s.worldInverseMatrix' % sLipsCtrlsParent])

                nodes.createDecomposeMatrix(sAttachMatrix, sTargetPos='%s.t' % cC.sPasser, sTargetRot='%s.r' % cC.sPasser)#, sTargetScale='%s.s' % cC.sPasser)

                if cc > 0: # not corners. because corners have a much more complicated setup further below
                    cmds.setAttr('%s.s' % cC.sOut, 1,1,1) # this is to make the right side's out positive. If it's negative, then the behavior is different
                    sRelMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut, '%s.worldInverseMatrix' % cC.sSlider])
                    nodes.createDecomposeMatrix(sRelMatrix, sTargetPos='%s.t' % cC.cOrig.sCtrl, sTargetRot='%s.r' % cC.cOrig.sCtrl)


        fCornerJawAttach = 0.35
        for p, fMidStrength in enumerate([1, 0]):
            iHalfSize = len(ccLipCtrls[p]) // 2
            if len(ccLipCtrls[p]) % 2:
                iHalfSize += 1
            for c in range(iHalfSize):
                fMidPerc = (c+1) / float(iHalfSize)
                fMidPercRev = (1-fMidPerc) ** 3
                fMidPerc = 1-fMidPercRev
                fJawAttach = fCornerJawAttach * (1.0-fMidPerc) + fMidStrength * (fMidPerc)
                cmds.setAttr('%s.jawAttach' % ccLipCtrls[p][c].sCtrl, fJawAttach)
                cmds.setAttr('%s.jawAttach' % ccLipCtrls[p][-(c+1)].sCtrl, fJawAttach)

        for cC in cCorners:
            cmds.setAttr('%s.jawAttach' % cC.sCtrl, fCornerJawAttach)


        sPuckerActivates = [nodes.createRangeNode(nodes.createAdditionNode(['%s.tx' % cCorners[0].sCtrl, '%s.tx' % cCorners[0].getOffsetByName('poses')]), 0, -1, 0, 1),
                            nodes.createRangeNode(nodes.createAdditionNode(['%s.tx' % cCorners[1].sCtrl, '%s.tx' % cCorners[1].getOffsetByName('poses')]), 0, -1, 0, 1)]

        # corner slide setup
        sCornerSlideLocs = []
        for s,cCorner in enumerate(cCorners):
            sNegTranslateZGroup = xforms.insertParent(cCorner.sOut, '%s_tz' % cCorner.sOut, bMatchParentTransform=True)
            nodes.createMultiplyNode('%s.tz' % cCorner.sCtrl, -1.0, sTarget='%s.tz' % sNegTranslateZGroup)
            sLocalCornerMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sNegTranslateZGroup, '%s.worldInverseMatrix' % cCorner.sSlider])
            cCorner.sAnimDecomp = nodes.createDecomposeMatrix(sLocalCornerMatrix, sName='_%s_cornerDecomp' % cCorner.sSide).split('.')[0]

            sLocalCornerMatrixWithZ = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.sCtrl, '%s.worldInverseMatrix' % cCorner.sSlider])
            cCorner.sAnimDecompWithZ = nodes.createDecomposeMatrix(sLocalCornerMatrixWithZ, sName='_%s_cornerDecompWithZ' % cCorner.sSide).split('.')[0]

            if bConvertSurfaceSlideToCurve: # this is to make sure it works in Unreal
                fTranslates = (0,0), (3,0), (-1,0)
                fCornerPoints = []
                for fT in fTranslates:
                    cmds.setAttr('%s.tx' % cCorner.sCtrl, fT[0])
                    cmds.setAttr('%s.ty' % cCorner.sCtrl, fT[1])
                    fCornerPoints.append(cmds.xform(cCorner.sCtrl, q=True, ws=True, t=True))
                cmds.setAttr('%s.tx' % cCorner.sCtrl, 0)
                cmds.setAttr('%s.ty' % cCorner.sCtrl, 0)

                fClosestUv = surfaces.getParamsFromPoints(sCornerSlidePlanes[s], [cmds.xform(cCorner.sCtrl, q=True, ws=True, t=True)])[0]
                sCornerSlideCurve = cmds.duplicateCurve('%s.v[%0.3f]' % (sCornerSlidePlanes[s], fClosestUv[1]), ch=False, n='curve_%s_cornerSlideCurve' % utils.sSides1[s])[0]
                cmds.parent(sCornerSlideCurve, sGrpMouthPivotFront)
                fUs = curves.getParamsFromPoints(sCornerSlideCurve, fCornerPoints, bReturnNumpy=True)
                utils.data.store('%s_lipCornerSlideParamsUnreal' % cCorner.sSide, list(fUs / curves.getParamLength(sCornerSlideCurve))) # dividing by params length probably not needed because it's normalized already
                sOut = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sAnimDecomp, 0, fTranslates[1][0], fUs[0], fUs[1], bInfinity=True)
                sIn = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sAnimDecomp, 0, fTranslates[2][0], fUs[0], fUs[2], bInfinity=True)
                sUpDownOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.sCtrl, '%s.worldInverseMatrix' % sGrpMouthPivotFront], bJustValues=True)
                sUpDownRotationMatrix = nodes.getRotationMatrix2(sUpDownOffset, bJustValues=True)
                sUpDownRotated = nodes.createPointByMatrixNode([0, '%s.outputTranslateY' % cCorner.sAnimDecomp, 0], sUpDownRotationMatrix)
                sSlideLoc = xforms.createLocator('loc_%s_mouthSlideLoc' % utils.sSides1[s], sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035) # is at werid location
                sCornerSlideLocs.append(sSlideLoc)
                sCurveNode, sSlidePos = curves.createPointInfoNode(sCornerSlideCurve, fUs[0]) #, sTargetPos='%s.t' % sSlideLoc)
                sSlidedOnCurve = nodes.createPointByMatrixNode(sSlidePos, '%s.worldInverseMatrix' % sGrpMouthPivotFront)
                nodes.createVectorAdditionNode([sSlidedOnCurve, sUpDownRotated], sTarget='%s.t' % sSlideLoc)

                sAimConstraint = constraints.aimConstraintEmpty(sSlideLoc)
                sAimTarget = nodes.createVectorAdditionNode([sSlidePos, '%s.tangent' % sCurveNode]) #, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                nodes.createPointByMatrixNode(sAimTarget, '%s.worldInverseMatrix' % sGrpMouthPivotFront, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                sUpVectorMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.sCtrl, '%s.worldInverseMatrix' % sGrpMouthPivotFront])
                cmds.connectAttr(sUpVectorMatrix, '%s.worldUpMatrix' % sAimConstraint)

                nodes.createConditionNode('%s.outputTranslateX' % cCorner.sAnimDecomp, '>', 0, sOut, sIn, sTarget='%s.parameter' % sCurveNode)

            else: # old way with surfaces does not work in Unreal
                fTranslates = (0,0), (0,2), (0,-2), (3,0), dPoseCtrlValues['cornerIn']
                fCornerPoints = []
                for fT in fTranslates:
                    cmds.setAttr('%s.tx' % cCorner.sCtrl, fT[0])
                    cmds.setAttr('%s.ty' % cCorner.sCtrl, fT[1])
                    fCornerPoints.append(cmds.xform(cCorner.sCtrl, q=True, ws=True, t=True))
                cmds.setAttr('%s.tx' % cCorner.sCtrl, 0)
                cmds.setAttr('%s.ty' % cCorner.sCtrl, 0)
                fUvs = surfaces.getParamsFromPoints(sCornerSlidePlanes[s], fCornerPoints)

                sUp = nodes.createRangeNode('%s.outputTranslateY' % cCorner.sAnimDecomp, 0, fTranslates[1][1], fUvs[0][1], fUvs[1][1], bInfinity=True)
                sDown = nodes.createRangeNode('%s.outputTranslateY' % cCorner.sAnimDecomp, 0, fTranslates[2][1], fUvs[0][1], fUvs[2][1], bInfinity=True)
                sOut = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sAnimDecomp, 0, fTranslates[3][0], fUvs[0][0], fUvs[3][0], bInfinity=True)
                sIn = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sAnimDecomp, 0, fTranslates[4][0], fUvs[0][0], fUvs[4][0], bInfinity=True)

                sSlideLoc = xforms.createLocator('loc_%s_mouthSlideLoc' % utils.sSides1[s], sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035) # is at werid location
                sCornerSlideLocs.append(sSlideLoc)
                sSurfaceNode, sSlidePos = surfaces.createPointInfoNode(sCornerSlidePlanesOrig[s], fUvs[0][0], fUvs[0][1], sTargetPos='%s.t' % sSlideLoc)

                sAimConstraint = constraints.aimConstraintEmpty(sSlideLoc)
                nodes.createVectorAdditionNode([sSlidePos, '%s.normal' % sSurfaceNode],
                                               sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                cmds.connectAttr('%s.tangentU' % sSurfaceNode, '%s.worldUpVector' % sAimConstraint)

                nodes.createConditionNode('%s.outputTranslateY' % cCorner.sAnimDecomp, '>', 0, sUp, sDown, sTarget='%s.parameterV' % sSurfaceNode)
                nodes.createConditionNode('%s.outputTranslateX' % cCorner.sAnimDecomp, '>', 0, sOut, sIn, sTarget='%s.parameterU' % sSurfaceNode)


            sAnimRotMatrix = nodes.createComposeMatrixNode(xRotate='%s.outputRotate' % cCorner.sAnimDecomp)

            sFirstOffset = cmds.listRelatives(cCorner.cOrig.sCtrl, p=True)[0]
            sWorldCtrlWithoutJaw = nodes.createMultMatrixNode([nodes.createMultMatrixNode(['%s.worldMatrix' % sFirstOffset, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True),
                                                               '%s.worldMatrix' % sMouthPivotFront])

            fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.cOrig.sCtrl, '%s.worldInverseMatrix' % sSlideLoc], bJustValues=True)

            sPuckerOffsetTzAttr = utils.addAttr(cCorners[s].sPasser, ln='PuckerOffsetTranslateZ', k=True)
            sDefaultSettingAttrs.append(sPuckerOffsetTzAttr)
            sPuckerOffsetMult = nodes.createMultiplyNode(sPuckerOffsetTzAttr, sPuckerActivates[s])

            sMatrix = nodes.createMultMatrixNode([sAnimRotMatrix,
                                                  nodes.createComposeMatrixNode([0,0,nodes.createAdditionNode(['%s.tz' % cCorner.sCtrl, sPuckerOffsetMult])]),
                                                  fOffset,
                                                  '%s.worldMatrix' % sSlideLoc,
                                                  nodes.createInverseMatrix(sWorldCtrlWithoutJaw)])

            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % cCorner.cOrig.sCtrl, sTargetRot='%s.r' % cCorner.cOrig.sCtrl)
            cmds.transformLimits(cCorner.sCtrl, etx=[True,False], tx=[dPoseCtrlValues['cornerIn'][0],1000])


            cCorner.sInOutTxSum = utils.addAttr(cCorner.sCtrl, ln='txSum', k=False)
            cmds.connectAttr('%s.tx' % cCorner.sCtrl, cCorner.sInOutTxSum) #temporary connect, will be overwritten later


        # create JustAnim transforms. JustAnim transforms are just the animation of corner and lips. the bot/top box ctrls are extracted in a clamped way
        # those are to calculate better tangent orienting or jawOpen pose
        for cC in ccRows[0]+ccRows[1]:
            cC.sJustAnims = [None, None]
        for p,sPart in enumerate(['bot','top']):

            # create sJustAnim transforms for lip ctrls
            for c,cC in enumerate(ccLipCtrls[p]):
                cC.sJustAnimParent = cmds.duplicate(cC.sSlider, n='%sJustAnimParent' % cC.sSlider, po=True)[0]
                xforms.lockTrs(cC.sJustAnimParent)
                cmds.parent(cC.sJustAnimParent, cC.sPasser)
                cC.sJustAnims[p] = cmds.createNode('transform', n='grp_%s_%sJustAnim' % (cC.sSide, cC.sName), p=cC.sJustAnimParent)
                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sJustAnimParent, '%s.worldInverseMatrix' % sGrpMouthPivotFront], bJustValues=True)
                sAnim = nodes.createComposeMatrixNode(nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.parentInverseMatrix' % cC.getOffsetByName('poses')))
                sJustAnimMatrix = nodes.createMultMatrixNode([sAnim, fOffset, '%s.worldMatrix' % sGrpMouthPivotFront, '%s.worldInverseMatrix' % cC.sJustAnimParent])
                nodes.createDecomposeMatrix(sJustAnimMatrix, sTargetPos='%s.t' % cC.sJustAnims[p], sTargetRot='%s.r' % cC.sJustAnims[p])

            # create sJustAnim transforms for corners
        for s,cC in enumerate(cCorners):
            cC.sJustAnimParent = cmds.duplicate(cC.sSlider, n='%sSliderAnim' % cC.sSlider, po=True)[0]
            xforms.lockTrs(cC.sJustAnimParent)
            cmds.parent(cC.sJustAnimParent, cC.sPasser)
            for p, sPart in enumerate(['bot', 'top']):

                cC.sJustAnims[p] = cmds.createNode('transform', n='grp_%s_%s%sJustAnim' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sJustAnimParent)

                sSliderJumped = nodes.createMultMatrixNode(['%s.matrix' % cC.sJustAnimParent, '%s.worldMatrix' % cC.sPasser])
                sSliderJumpedInverse = nodes.createInverseMatrix(sSliderJumped)

                fCornerFromBoxOffset = nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cBotTops[p].sJumped, bJustValues=True)
                sWorldCornerFromBox = nodes.createPointByMatrixNode(fCornerFromBoxOffset, '%s.worldMatrix' % cBotTops[p].sJumped)

                sTranslationPlusPoses = nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.parentInverseMatrix' % cC.getOffsetByName('poses'))
                sTranslateXY = ['%sX' % sTranslationPlusPoses, '%sY' % sTranslationPlusPoses, 0]

                sCornerFromBoxInCornerSpace = nodes.createPointByMatrixNode(sWorldCornerFromBox, sSliderJumpedInverse)

                fOffset = nodes.createMultMatrixNode([sSliderJumped, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)

                sMaxY = nodes.createConditionNode('%sY' % sTranslationPlusPoses, '<' if p==0 else '>', 0, '%sY' % sTranslationPlusPoses, 0)
                if p == 0:
                    sClampedY = nodes.createClampNode('%sY' % sCornerFromBoxInCornerSpace, sMaxY, 0)
                else:
                    sClampedY = nodes.createClampNode('%sY' % sCornerFromBoxInCornerSpace, 0, sMaxY)
                sClamped = [ '%sX' % sCornerFromBoxInCornerSpace, sClampedY, '%sZ' % sCornerFromBoxInCornerSpace]

                sDiff = nodes.createVectorAdditionNode([sTranslateXY, sClamped], sOperation='minus')

                sAnim = nodes.createComposeMatrixNode(sDiff)
                sJustAnimMatrix = nodes.createMultMatrixNode([sAnim, fOffset, '%s.worldMatrix' % sMouthPivotFront, '%s.worldInverseMatrix' % cC.sJustAnimParent])
                nodes.createDecomposeMatrix(sJustAnimMatrix, sTargetPos='%s.t' % cC.sJustAnims[p], sTargetRot='%s.r' % cC.sJustAnims[p])

        # generate values for static sliding curves
        fStaticCurveMidParams = [curves.getParamsFromPercs(sStaticSlideCurves[0], [0.5])[0], curves.getParamsFromPercs(sStaticSlideCurves[1], [0.5])[0]]

        dPercParamsStaticCurve = {}
        dDistancesToCorner = {}
        for s, sSide in enumerate(['l', 'r']):
            fCurveLength = curves.getLength(sStaticSlideCurves[s])
            fCurveParamLength = curves.getParamLength(sStaticSlideCurves[s])
            for p,sPart in enumerate(['bot','top']):
                cSideCtrls = [cC for cC in ccLipCtrls[p] if cC.sSide == sSide]
                aParams = curves.getParamsFromTransforms(sStaticSlideCurves[s], [cC.sCtrl for cC in cSideCtrls], bReturnNumpy=True)
                aPercs = curves.getPercsFromParams(sStaticSlideCurves[s], aParams, bReturnNumpy=True)
                for cC,fParam,fPerc in zip(cSideCtrls, aParams, aPercs):
                    cC.fParamStaticCurve = fParam
                    cC.fDistanceToCorner = fCurveLength * fPerc
                    dPercParamsStaticCurve[cC.sCtrl] = cC.fParamStaticCurve / fCurveParamLength
                    dDistancesToCorner[cC.sCtrl] = cC.fDistanceToCorner

                # not tested yet!
                for cC in ccLipCtrls[p]:
                    if cC.sSide == 'm':
                        cC.fParamStaticCurve = fStaticCurveMidParams[s]
                        cC.fDistanceToCorner = fCurveLength * 0.5

        utils.data.store('dPercParamsStaticCurve', dPercParamsStaticCurve)
        utils.data.store('dDistancesToCorner', dDistancesToCorner)


        for p,sPart in enumerate(['bot','top']):

            sEndTangents = [None, None]
            for c,cC in enumerate(ccLipCtrls[p]):
                if cC.sSide == 'm':
                    continue
                iSide = 1 if cC.sSide == 'r' else 0
                fSideMultipl = -1.0 if cC.sSide == 'r' else 1.0
                sMove = cC.appendOffsetGroup('movetocorner', sAboveOtherOffset='twist')
                sFollowY = utils.addAttr(cC.sPasser, ln='followCornerY', min=0, max=1, k=True)
                sFollowZ = utils.addAttr(cC.sPasser, ln='followCornerZ', min=0, max=1, k=True)
                sFollowPathOut = utils.addAttr(cC.sPasser, ln='followCornerPathOut', min=0, max=1, k=True)
                sFollowPathIn = utils.addAttr(cC.sPasser, ln='followCornerPathIn', min=0, max=1, k=True)

                sDefaultSettingAttrs.append(sFollowY)
                sDefaultSettingAttrs.append(sFollowZ)
                sDefaultSettingAttrs.append(sFollowPathOut)
                sDefaultSettingAttrs.append(sFollowPathIn)

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[iSide].sJustAnims[p], '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)
                sParentMatrix = nodes.createMultMatrixNode([fOffset, '%s.worldMatrix' % sMouthPivotFront])
                sParentInverseMatrix = nodes.createInverseMatrix(sParentMatrix)
                sLocalMovingMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[iSide].sJustAnims[p], sParentInverseMatrix])
                sCornerJustAnimTranslation = nodes.createDecomposeMatrix(sLocalMovingMatrix, sFullName='cornerTranslation')
                fDefaultValue = abs(cC.fPerc - 0.5)
                cmds.setAttr(sFollowY, fDefaultValue)
                cmds.setAttr(sFollowZ, min(fDefaultValue * 4, 1.0))
                cmds.setAttr(sFollowPathOut, fDefaultValue)
                cmds.setAttr(sFollowPathIn, fDefaultValue)

                fScaleFactorForUpDown = nodes.createMultiplyNode(1.0, '%s.sx' % cC.sPasser, sOperation='divide')
                sUpDown = nodes.createMultiplyNode('%sY' % sCornerJustAnimTranslation, fScaleFactorForUpDown)
                nodes.createMultiplyNode(sFollowY, sUpDown, sTarget='%s.ty' % sMove)

                sForwardBack = nodes.createMultiplyNode('%s.outputTranslateZ' % cCorners[iSide].sAnimDecompWithZ, fScaleFactorForUpDown)
                nodes.createMultiplyNode(sFollowZ, sForwardBack, sTarget='%s.tz' % sMove)

                sScaleFactorForPath = nodes.createMultiplyNode('%s.sx' % cCorners[iSide].sPasser, '%s.sx' % cC.sPasser, sOperation='divide', sName='scaledFactorForPath')
                sCornerJustAnimBackForward = nodes.createMultiplyNode('%sX' % sCornerJustAnimTranslation, sScaleFactorForPath, sName='scaledForPath')
                sFollowPath = nodes.createConditionNode(sCornerJustAnimBackForward, '>', 0, sFollowPathOut, sFollowPathIn, sName='inOrOut') # out is different to in

                cC.sSlidingGrpOut = cC.appendOffsetGroup('movetocornerpath', sAboveOtherOffset='twist')
                cC.sSlidingLocOut = xforms.createLocator('loc_%s_%sOutSlidingCopy_%03d' % (cC.sSide, cC.sName, 0 if utils.isNone(cC.iIndex) else cC.iIndex), sParent=sMouthPivotFront, fSize=fCurveLengthes[0]*0.035)
                sNode, sPos = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=cC.fParamStaticCurve)
                sUpNode, sUpPos = curves.createPointInfoNode(sStaticSlideUpCurves[iSide], fParam=cC.fParamStaticCurve)

                sDistanceToCornerBySpeed = nodes.createMultiplyNode(cC.fDistanceToCorner, sFollowPath, sOperation='divide', sName='distanceToCornerBySpeed')


                # for after it reached the end
                if sEndTangents[iSide] == None: # since we have bot/top we only need to calculate the End Tangent once
                    sCornerInfoNode, _ = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=0.0, sName='endTangent')
                    sNormTangent = nodes.createNormalizedVector('%s.tangent' % sCornerInfoNode, sName='endTangent')
                    sEndTangents[iSide] = nodes.createVectorMultiplyNode(sNormTangent, -100, bVectorByScalar=True, sName='endTangent')
                sEndTangentExtra = nodes.createRangeNode(sCornerJustAnimBackForward, sDistanceToCornerBySpeed, 100,
                                                            [0,0,0],
                                                                    nodes.createVectorMultiplyNode(sEndTangents[iSide], sFollowPath, bVectorByScalar=True),
                                                                    bOutRangeIsVector=True, sName='endTangent')

                sPosAddition = nodes.createVectorAdditionNode([sPos, sEndTangentExtra])
                nodes.createPointByMatrixNode(sPosAddition, '%s.worldInverseMatrix' % sMouthPivotFront, sTarget='%s.t' % cC.sSlidingLocOut)

                sAimConstraint = constraints.aimConstraintEmpty(cC.sSlidingLocOut, aim=[fSideMultipl,0,0])
                sTargetPos = nodes.createVectorAdditionNode([sPosAddition, '%s.tangent' % sNode])
                nodes.createPointByMatrixNode(sTargetPos, '%s.worldInverseMatrix' % sMouthPivotFront, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                sUpVector = nodes.createVectorAdditionNode([sUpPos, sPos], sOperation='minus')
                nodes.createPointByMatrixNode(sUpVector, sMouthPivotFrontInvRotationMatrix, sTarget='%s.worldUpVector' % sAimConstraint)


                sPositive = nodes.createRangeNode(sCornerJustAnimBackForward, 0, sDistanceToCornerBySpeed, cC.fParamStaticCurve, 0.0, sName='pos')
                sNegative = nodes.createRangeNode(sCornerJustAnimBackForward, 0, nodes.createMultiplyNode(sDistanceToCornerBySpeed,-1), cC.fParamStaticCurve, curves.getParamLength(sStaticSlideCurves[iSide]), sName='neg')
                nodes.createConditionNode(sCornerJustAnimBackForward, '>', 0, sPositive, sNegative, sTarget=['%s.parameter' % sNode, '%s.parameter' % sUpNode], sName='posOrNeg')

                sSlidingLocLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingLocOut, '%s.worldInverseMatrix' % sMouthPivotFront])
                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingGrpOut, '%s.worldInverseMatrix' % cC.sSlidingLocOut], bJustValues=True)

                fSlidingGrpToPivotFrontOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlider, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)

                sSlidingInLocal = nodes.createMultMatrixNode([fOffset,
                                                              # nodes.createComposeMatrixNode(xScale=[sMouthScale, sMouthScale, sMouthScale]),
                                                              sSlidingLocLocal,
                                                              nodes.createInverseMatrix(fSlidingGrpToPivotFrontOffset, bJustValues=True)])

                nodes.createDecomposeMatrix(sSlidingInLocal, sTargetPos='%s.t' % cC.sSlidingGrpOut, sTargetRot='%s.r' % cC.sSlidingGrpOut)


        for s,sSide in enumerate(['l','r']):
            nodes.createAdditionNode(['%s.tx' % cCorners[s].sCtrl, '%s.tx' % cCorners[s].getOffsetByName('poses')], sTarget=cCorners[s].sInOutTxSum, bForce=True)


        # can we remove that?????
        def addAttrInclPoseCtrls(cC, ln, defaultValue=0, minValue=0, maxValue=1, k=True):
            sPoseCtrlsString = utils.getStringAttr(cC.sCtrl, 'sPoseCtrls', '[]')
            sPoseCtrls = eval(sPoseCtrlsString)
            sAttrs = []

            for c,sC in enumerate([cC.sCtrl]+sPoseCtrls):
                sAttrs.append(utils.addAttr(sC, ln=ln,
                                            defaultValue=defaultValue if c == 0 else 0,
                                            k=k, minValue=minValue, maxValue=maxValue))
            sSumAttr = utils.addAttr(cC.sPasser, ln='%sSum' % ln, k=True)
            nodes.createAdditionNode(sAttrs, sTarget=sSumAttr)
            return sSumAttr


        # create additional attributes
        for s,sSide in enumerate(['l','r']):
            cCorners[s].sRoundAttr = addAttrInclPoseCtrls(cCorners[s], ln='pointyRound', minValue=0, maxValue=1, k=True)
            cCorners[s].sRoundExceedAttr = utils.addAttr(cCorners[s].sPasser, ln='pointyRoundExceed', k=True)
            cCorners[s].sRoundExceedAutoAttr = utils.addAttr(cCorners[s].sPasser, ln='pointyRoundExceedWhenOn', k=True)

            cCorners[s].sTangentScales = [utils.addAttr(cCorners[s].sPasser, ln='tangentScaleBot', k=True, dv=1),
                                          utils.addAttr(cCorners[s].sPasser, ln='tangentScaleTop', k=True, dv=1)]
            cCorners[s].sTangentScalesAuto = [utils.addAttr(cCorners[s].sPasser, ln='tangentScaleBotAuto', k=True, dv=1),
                                              utils.addAttr(cCorners[s].sPasser, ln='tangentScaleTopAuto', k=True, dv=1)]
            sScaleSumNode = nodes.createVectorAdditionNode([ [cCorners[s].sTangentScales[0], cCorners[s].sTangentScales[1], 0],
                                                             [cCorners[s].sTangentScalesAuto[0], cCorners[s].sTangentScalesAuto[1], 0],
                                                             [-1,-1,0]]) # -1 = -2 + 1
            cCorners[s].sScaleSums = ['%sx' % sScaleSumNode, '%sy' % sScaleSumNode]
            utils.data.store('sTangentScalesAuto_%s' % sSide, cCorners[s].sTangentScalesAuto)

            if bZipper:
                cCorners[s].sZipper = addAttrInclPoseCtrls(cCorners[s], ln='zipper', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
                cCorners[s].sZipperFadeLength = utils.addAttr(cCorners[s].sCtrl, ln='zipperFade', defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)



        # # setting the pivot attributes
        # #
        # for cC in ccRows[p][1:-1] + cBotTops:
        #     sPivotAttrs = ['%s.tx' % cC.sPivot, '%s.ty' % cC.sPivot, '%s.tz' % cC.sPivot]
        #     sDefaultSettingAttrs.extend(sPivotAttrs)
        #     cmds.setAttr('%s.t' % cC.sPivot, dDefaultSettingValues.get(sPivotAttrs[0], 0.0),
        #                                              dDefaultSettingValues.get(sPivotAttrs[1], 0.0),
        #                                              dDefaultSettingValues.get(sPivotAttrs[2], 0.0))

        sPuckerOnCornerIns = [None, None]
        sPuckerOnCornerInRevs = [None, None]
        for s,sSide in enumerate(['l','r']):
            sPuckerOnCornerIns[s] = utils.addAttr(cCorners[s].sCtrl, ln='puckerOnIn', min=0, max=1, dv=0.0, k=True)
            sPuckerOnCornerInRevs[s] = nodes.createReverseNode(sPuckerOnCornerIns[s])


        ssPartInfluences = [[], []]
        ccCornerTangents = [[], []]
        # create control influence joints
        for p,sPart in enumerate(['bot','top']):
            fCurveLengthes[p] = curves.getLength(sBpCurvesA[0])
            fPartMult = 1 if p == 0 else -1

            for c,cC in enumerate(ccRows[p]):
                s = ['l','r','m'].index(cC.sSide)
                sI = cmds.createNode('joint', n='inf_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), p=cC.cOrig.sOut)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sI)
                sAimToNeighborsAttr = utils.addAttr(cC.sPasser, ln='aimToNeighbors', min=0, max=1, dv=0.0 if cC.sSide == 'm' else 1.0, k=True, bReturnIfExists=True)
                sAimToNeighborsPuckerMultiplyAttr = utils.addAttr(cC.sPasser, ln='aimToNeighborsPuckerMultiply', min=0, max=1, dv=0.0, k=True, bReturnIfExists=True)
                sDefaultSettingAttrs.append(sAimToNeighborsAttr)
                sDefaultSettingAttrs.append(sAimToNeighborsPuckerMultiplyAttr)
                if s == 2:
                    sAimToNeighborPuckered = sAimToNeighborsAttr
                else:
                    sExtraPuckerFactor = nodes.createBlendNode(sPuckerActivates[s], sAimToNeighborsPuckerMultiplyAttr, 1.0)
                    sAimToNeighborPuckered = nodes.createMultiplyNode(sAimToNeighborsAttr, sExtraPuckerFactor)
                sNoRotCtrl = cmds.duplicate(cC.cOrig.sCtrl, n='grp_%s_%sMouthNoRot%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), po=True)[0]
                cmds.connectAttr('%s.t' % cC.cOrig.sCtrl, '%s.t' % sNoRotCtrl)
                if c in [0, len(ccRows[p])-1]: # corners
                    sParentI = xforms.insertParent(sI, 'parent_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)))
                    sTangentParent = '%sTangentParent' % utils.replaceStringStart(cC.sOut, 'ctrl_', 'grp_')
                    if not cmds.objExists(sTangentParent):
                        cmds.duplicate(cC.sOut, n=sTangentParent)[0]
                        cmds.parent(sTangentParent, cC.sCtrl)
                        xforms.matchLocalTransformAttributes(cC.sOut, sTangentParent)

                    cCornerTangent = ctrls8.create('cornerTangent%s' % utils.getFirstLetterUpperCase(sPart), sSide=cC.sSide, sMatch=sI, sShape='revL_z',
                                                 sParent=sTangentParent, sAttrs=['rx','ry','rz'], fSize=fCurveLengthes[0]*0.2, iColorIndex=2)

                    cCornerTangent.sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCornerTangent.sCtrl,
                                                                             '%s.worldInverseMatrix' % cC.sExtraMove,
                                                                             '%s.worldMatrix' % cC.sPasser])

                    ccCornerTangents[s].append(cCornerTangent)
                    sCtrlVis = utils.addOffOnAttr(cC.sCtrl, 'tangentCtrl%sVis' % utils.getFirstLetterUpperCase(sPart), bDefaultValue=True, bReturnIfExists=True)
                    sDefaultSettingAttrs.append(sCtrlVis)

                    cmds.connectAttr(sCtrlVis, '%s.v' % cCornerTangent.sPasser)
                    cmds.connectAttr('%s.r' % sParentI, '%s.r' % cCornerTangent.sPasser)
                    cmds.connectAttr('%s.ro' % sParentI, '%s.ro' % cCornerTangent.sPasser)
                    sTangentAnimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCornerTangent.sOut, '%s.worldInverseMatrix' % cCornerTangent.sPasser])
                    nodes.createDecomposeMatrix(sTangentAnimMatrix, sTargetPos='%s.t' % sI, sTargetRot='%s.r' % sI)

                    # fXformBefore = cmds.xform(sI, q=True, ws=True, m=True)
                    sAimConstraint = constraints.aimConstraintEmpty(sParentI)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0, 0, 1)

                    if c == 0:
                        sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][1].cOrig.sCtrl), '%s.worldInverseMatrix' % sNoRotCtrl) # sNoRotCtrl is CornerCtrl with just translation
                    else:
                        sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][-2].cOrig.sCtrl), '%s.worldInverseMatrix' % sNoRotCtrl)
                    fLength = np.linalg.norm(np.array(cmds.getAttr(sAimTarget)[0], dtype='float64'))

                    sRoundRotate = nodes.createAdditionNode([cC.sRoundExceedAttr,
                                                             nodes.createMultiplyNode(cC.sRoundExceedAutoAttr, cC.sRoundAttr)])

                    sSignedRoundRotate = sRoundRotate if p == 0 else nodes.createMultiplyNode(sRoundRotate, -1)

                    sExceededRoundAimTarget = nodes.createPointByMatrixNode([0, fLength*(-fPartMult), 0],
                                                                            nodes.createComposeMatrixNode(xRotate=[0,0,sSignedRoundRotate]))

                    nodes.createBlendNode(cC.sRoundAttr, sExceededRoundAimTarget, sAimTarget, bVector=True,
                                                       sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                    # constraints.computeAimOffset(sAimConstraint, fXformBefore)
                    cmds.connectAttr(cCorners[0 if c == 0 else 1].sScaleSums[p], '%s.sx' % sI)

                else: # not corners
                    # fXformBefore = cmds.xform(sI, q=True, ws=True, m=True)
                    sAimConstraint = constraints.aimConstraintEmpty(sI, bIgnoreConstraintRotateTranslateConnection=True)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0, 0, 1)

                    sAimTargetA = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][c-1].sJustAnims[p]), '%s.worldInverseMatrix' % cC.sJustAnims[p])
                    sAimTargetB = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][c+1].sJustAnims[p]), '%s.worldInverseMatrix' % cC.sJustAnims[p])
                    sAimTarget = nodes.createVectorAdditionNode([sAimTargetA, sAimTargetB], sOperation='minus')
                    nodes.createBlendNode(sAimToNeighborPuckered, sAimTarget, cmds.getAttr(sAimTarget)[0], bVector=True, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                    # constraints.computeAimOffset(sAimConstraint, fXformBefore)
                    
                    cmds.connectAttr('%s.sx' % cC.sCtrl, '%s.sx' % sI)
                ssPartInfluences[p].append(sI)



        addPoseOffsets(utils.flattenedList(ccCornerTangents))



        # utils.data.store('ddFaceCtrlDriverDatas', ddPoseDriverDatas)

        # connectFaceCtrlPoses(ddPoses)


        # END OF POSES


        # move ctrl shapes to outer curves
        if False:
            for p, cCtrls in enumerate([(ccLipCtrls[0] + [cBotTops[0]] + cCorners),
                                        (ccLipCtrls[1] + [cBotTops[1]])]): #excluded cBotTop ctrls
                aCurrentPositions = xforms.getPositionArray([cC.sCtrl for cC in cCtrls])
                if True: # find by closest
                    aMoveToPositions = curves.getPointsFromPoints(sBpCurvesB[p], aCurrentPositions, bReturnNumpy=True)
                else: # find by percentage
                    fCtrlPercs = [cC.fPerc for cC in cCtrls]
                    aMoveToPositions = curves.getPointsFromPercs(sBpCurvesB[p], fCtrlPercs, bReturnNumpy=True)
                aMoves = aMoveToPositions - aCurrentPositions
                for c,cC in enumerate(cCtrls):
                    pCtrl = patch.patchFromName(cC.sShape)
                    pCtrl.setPoints(pCtrl.getPoints() + aMoves[c])

        # slide ctrls

        cSlideCtrls = ccLipCtrls[0]+ccLipCtrls[1]

        fCurveLengths = [curves.getLength(sStaticSlideCurves[0]), curves.getLength(sStaticSlideCurves[1])]
        for s,cCorner in enumerate(cCorners):
            sPuckerFactor = utils.addAttr(cCorner.sPasser, ln='puckerFactor', k=True, min=0.1, max=10, dv=1.0)
            sDefaultSettingAttrs.append(sPuckerFactor)
            cCorner.sFullPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(cCorner.sCtrl), '%s.worldInverseMatrix' % cCorner.sSlider)
            sCornerX = nodes.createMultiplyNode('%sX' % cCorner.sFullPoint, '%s.sx' % cCorner.sPasser)
            sPuckerDistance = nodes.createConditionNode(sCornerX, '<', 0, sCornerX, 0.0)
            sPuckerDistance = nodes.createMultiplyNode(sPuckerDistance, sPuckerFactor)

            sMidPercAttr = utils.addAttr(cCorner.sPasser, ln='midPerc', k=True)
            sNegHalfCurveLength = nodes.createMultiplyArrayNode([-fCurveLengths[s] * 0.5, 1]) #sGlobalMouthScale])
            nodes.createMultiplyNode(sPuckerDistance, sNegHalfCurveLength, sOperation='divide', sTarget=sMidPercAttr)


        # for cCtrl in cBotLips+cTopLips:
        #     cCtrl.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[2:]])



        #
        # lipsEnd joints
        #
        sLipsEndJoints = []
        for s, sSide in enumerate(['l', 'r']):
            # lipsEnd joint
            sLipsEnd = 'jnt_%s_lipsEnd' % sSide
            if cmds.objExists(sLipsEnd):
                cmds.parent(sLipsEnd, sMouthPivotFront)
            else:
                cmds.createNode('joint', n=sLipsEnd, p=sMouthPivotFront)
            xforms.resetTransform(sLipsEnd, jo=True)
            cmds.setAttr('%s.radius' % sLipsEnd, fCurveLengthes[0] * 0.075)
            cmds.setAttr('%s.segmentScaleCompensate' % sLipsEnd, True)
            sLipsEndJoints.append(sLipsEnd)
            


        #
        # start doing the splines 
        #
        ssBigJointMatrices = [[], []]
        ssLocMatrices = [None, None]
        ssSmallJoints = [[], []]
        ssBigJoints = [[], []]

        for p,sPart in enumerate(['bot','top']):
            fCurveLengthes[p] = curves.getLength(sBpCurvesA[0])
            fPercs = [0] + curves.getPercsFromTransforms(sBpCurvesA[p], [cC.sCtrl for cC in ccLipCtrls[p]]) + [1]
            fPercs = utils.addTangents(fPercs, bRemoveMains=False)
            sCurve = curves.rebuildWithPercs(sBpCurvesA[p], fPercs, bCreateNew=True, sName='curve_m_%sMouth' % sPart, sParent=utils.getMasterName())
            sCurveVisAttr = utils.addOffOnAttr(cMouth.sCtrl, 'curveVis', bDefaultValue=False, sTarget='%s.v' % sCurve, bReturnIfExists=True)
            sDefaultSettingAttrs.append(sCurveVisAttr)
            curves.setLineWidth(sCurve, 10.0)
            # cmds.setAttr('%s.template' % sCurve, True)
            utils.data.store('sRoundExceedWhenOnAttrs', [cCorners[0].sRoundExceedAutoAttr, cCorners[1].sRoundExceedAutoAttr])
            cmds.skinCluster(sCurve, ssPartInfluences[p], tsb=True, mi=1)
            pCurve = patch.patchFromName(sCurve)
            weights.skinCurveBSpline4(pCurve, ssPartInfluences[p],
                                      bStrongEnds=True,
                                      iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)
            pCurve.aIds = pCurve.aIds[1:-1]
            weights.smoothSkinWeights([pCurve], iIterations=2, _bSkipDeformerAdjustLogging=True)

            iSplineJointCount = len(aaPoints[p])

            sSides, iIndices = utils.convertMiddleSequenceToSides(iSplineJointCount)
            sLocs = []
            fParams = curves.getParamsFromPoints(sCurve, aaPoints[p], bReturnNumpy=True)
            cmds.select(sCurve)
            aPercs = curves.getPercsFromParams(sCurve, fParams, bReturnNumpy=True)
            utils.data.store('fLipsParamsNormalized%s' % sPart.title(), list(fParams/curves.getParamLength(sCurve)))

            for j in range(iSplineJointCount):
                if p == 1 and j in [0, iSplineJointCount-1]:
                    ssSmallJoints[p].append(None)
                    continue

                sJ = 'jnt_%s_%sMouthSplineSmall_%03d' % (sSides[j], sPart, iIndices[j])
                if cmds.objExists(sJ):
                    cmds.parent(sJ, jointOrGroup(sMouthPivotFront))
                else:
                    cmds.createNode('joint', n=sJ, p=sMouthPivotFront)

                cmds.setAttr('%s.useObjectColor' % sJ, True)
                cmds.setAttr('%s.objectColor' % sJ, j%8)

                xforms.resetTransform(sJ, jo=True)
                cmds.setAttr('%s.radius' % sJ, fCurveLengthes[p]*0.025)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                utils.addAttr(sJ, ln='createdFromFaceRigFunction')
                sPercAttr = utils.addAttr(sJ, ln='perc', dv=aPercs[j], k=True)
                cmds.setAttr(sPercAttr, lock=True)
                ssSmallJoints[p].append(sJ)

            for j in range(iSplineJointCount):
                if p == 1 and j in [0, iSplineJointCount-1]:
                    ssBigJoints[p].append(None)
                    continue
                sJ = 'jnt_%s_%sMouthSplineBig_%03d' % (sSides[j], sPart, iIndices[j])
                if cmds.objExists(sJ):
                    cmds.parent(sJ, jointOrGroup(sMouthPivotFront))
                else:
                    cmds.createNode('joint', n=sJ, p=jointOrGroup(sMouthPivotFront))
                xforms.resetTransform(sJ, jo=True)
                cmds.setAttr('%s.radius' % sJ, fCurveLengthes[p]*0.05)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                utils.addAttr(sJ, ln='createdFromFaceRigFunction')
                utils.addStringAttr(sJ, 'skinParent', ssSmallJoints[p][j], bLock=True)
                cmds.setAttr('%s.useObjectColor' % sJ, True)
                cmds.setAttr('%s.objectColor' % sJ, j%8)

                ssBigJoints[p].append(sJ)
            utils.data.store('sLipsSmallJoints%s' % sPart.title(), ssSmallJoints[p])
            utils.data.store('sLipsBigJoints%s' % sPart.title(), ssBigJoints[p])

            fCtrlPercs = np.array([cC.fPerc for cC in ccRows[p]], dtype='float64')
            xCtrlWeightings = xforms.getCtrlWeightings(aPercs, fCtrlPercs)
            utils.data.store('xMouthCtrlWeightings%s' % sPart.title(), xCtrlWeightings)
            sTwistUps = []
            for c,cC in enumerate(ccRows[p]):

                cC.sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                            '%s.worldInverseMatrix' % cC.sExtraMove,
                                                            '%s.worldMatrix' % cC.sPasser])
                sJumpedLocalMatrix = nodes.createMultMatrixNode([cC.sJumpedMatrix,
                                                            '%s.worldInverseMatrix' % sMouthPivotFront])

                sRotMatrix = nodes.getRotationMatrix2(sJumpedLocalMatrix) # used to be cC.cOrig.sCtrl instead of sJumpedLocalMatrix, but we changed it after that aimConstraint thingy
                sTwistUps.append(nodes.createPointByMatrixNode([0, 0, 1], sRotMatrix))
                cC.sLiveTangentAttr = utils.addAttr(cC.sPasser, ln='liveTangent', min=0, max=1, k=True, dv=0.0, bReturnIfExists=True)
                sDefaultSettingAttrs.append(cC.sLiveTangentAttr)


            # aCurvePointsBeforePivot = patch.patchFromName(sCurve).getPoints()
            # utils.data.store('ffLipsCurvePointsBeforePivot%s' % sPart.title(), [list(aP) for aP in aCurvePointsBeforePivot])


            # # # SHALL WE MOVE THIS UP??
            # setting the pivot attributes
            #
            for cC in ccRows[p][1:-1] + cBotTops:
                sPivotAttr = '%s.t' % cC.sPivot
                sDefaultSettingAttrs.append(sPivotAttr)
                cmds.setAttr('%s.t' % cC.sPivot, *dDefaultSettingValues.get(sPivotAttr, [0,0,0]))

            pCurve = patch.patchFromName(sCurve)
            _, sInfluences, aaWeights = pCurve.getSkinCluster()
            cmds.delete(sCurve, ch=True)
            pCurve.setSkinClusterWeights(aaWeights, sInfluences, _bSkipDeformerAdjustLogging=True)

            # create locs
            #
            for j,fP in enumerate(fParams):
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]

                sLoc = xforms.createLocator('loc_%s_%sMouthSpline_%03d' % (sSides[j], sPart, iIndices[j]), sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035)
                sNode, sPos = curves.createPointInfoNode(sCurve, fP)
                nodes.createPointByMatrixNode(sPos, '%s.worldInverseMatrix' % sMouthPivotFront, sTarget='%s.t' % sLoc)

                sAimConstraint = constraints.aimConstraintEmpty(sLoc, aim=[0,1,0], up=[-1,0,0], bIgnoreConstraintRotateTranslateConnection=True) # aim will be set back to [0,0,1] below
                sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sFrontPivotRotationInverseMatrix)
                sLiveTangentBlend = nodes.createBlendNode(fBlend, ccRows[p][iCtrl1].sLiveTangentAttr, ccRows[p][iCtrl0].sLiveTangentAttr)
                nodes.createBlendNode(sLiveTangentBlend, sTangent, cmds.getAttr(sTangent)[0], bVector=True, sTarget='%s.worldUpVector' % sAimConstraint)
                fFinalXform = cmds.getAttr('%s.worldMatrix' % sLoc)

                sUpBlend = nodes.createBlendNode(fBlend, sTwistUps[iCtrl1], sTwistUps[iCtrl0], bVector=True)

                cmds.connectAttr(sUpBlend, '%s.target[0].targetTranslate' % sAimConstraint)
                # nodes.createVectorAdditionNode([sLocalPos, sUpBlend], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                constraints.computeAimOffset(sAimConstraint, fFinalXform)

                sLocs.append(sLoc)

            ssLocMatrices[p] = ['%s.matrix' % sL for sL in sLocs]


            # big joint matrices resetting the orientation to be like head/jaw
            #
            for j,sM in enumerate(ssLocMatrices[p]):
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                fOuterLocalPos = nodes.createPointByMatrixNode(aaLocalOuterPoints[p][j], nodes.createInverseMatrix(sM, bJustValues=True), bJustValues=True)
                sOuterPos = nodes.createPointByMatrixNode(fOuterLocalPos, sM)


                sJawAttachBlended = nodes.createBlendNode(fBlend, '%s.jawAttach' % ccRows[p][iCtrl1].sCtrl,
                                                                  '%s.jawAttach' % ccRows[p][iCtrl0].sCtrl, sName='jawAttach_%03d_' % j)
                sBlendedRotMatrix = nodes.createBlendMatrixNode([sJawSliderRotateMatrix, cmds.getAttr(sJawSliderRotateMatrix)],
                                                                [sJawAttachBlended, nodes.createReverseNode(sJawAttachBlended)], sName='jawAttach_%03d_' % j)

                sBlendedDecomp = nodes.createDecomposeMatrix(sBlendedRotMatrix).split('.')[0]
                sResetMatrix = nodes.createComposeMatrixNode(xTranslate = sOuterPos,
                                                             xRotate = '%s.outputRotate' % sBlendedDecomp,
                                                             xScale = '%s.outputScale' % sBlendedDecomp, sName='jawAttach_%03d_' % j)

                ssBigJointMatrices[p].append(sResetMatrix)


            # this is slide locs for the ends to keep the lipsEnd joints later stable. The following loop has similarities to the previous one
            if p == 0:
                for s,sSide in enumerate(['l','r']):
                    fP = fParams[0] if sSide == 'l' else fParams[-1]
                    sStableEnd = xforms.createLocator('loc_%s_stableEnd' % sSide, sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.05)
                    sNode, sPos = curves.createPointInfoNode(sCurve, fP)
                    sLocalPos = nodes.createPointByMatrixNode(sPos, '%s.worldInverseMatrix' % sMouthPivotFront)
    
                    aLocalPos = np.array(cmds.getAttr(sLocalPos)[0], dtype='float64')
                    fSmallOffset = aaLocalPoints[p][0 if sSide=='l' else -1] - aLocalPos
    
                    nodes.createVectorAdditionNode([sLocalPos, fSmallOffset], sTarget='%s.t' % sStableEnd)
    
                    sAimConstraint = constraints.aimConstraintEmpty(sStableEnd, aim=[0,0,1], up=[-1,0,0])
    
                    sUpBlend = sTwistUps[0 if sSide=='l' else -1]
                    nodes.createVectorAdditionNode([sLocalPos, sUpBlend], sTarget='%s.target[0].targetTranslate' % sAimConstraint, bJustValues=True)
    
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sFrontPivotRotationInverseMatrix)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, *cmds.getAttr(sTangent)[0])

                    # this is almost a copy of the previous block, where the joints get the slide
                    sSplinesPlusPucker = '%s.matrix' % sStableEnd

                    # blend with no mouthCtrl (inverse against it)
                    fLocalMouthPivot = nodes.createMultMatrixNode(['%s.worldMatrix' % sMouthPivotFront, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                    sStaticMouthPivotFront = nodes.createMultMatrixNode([fLocalMouthPivot, '%s.worldMatrix' % sParentJoint])
                    sSplinesPlusSidingLocalNoMouth = nodes.createMultMatrixNode([sSplinesPlusPucker, sStaticMouthPivotFront, '%s.worldInverseMatrix' % sMouthPivotFront])

                    sLipsEndFollowMouthT = utils.addAttr(cMouth.sPasser, ln='lipsEndFollowMouthT', min=0, max=1, dv=1.0, k=True, bReturnIfExists=True)
                    sLipsEndFollowMouthR = utils.addAttr(cMouth.sPasser, ln='lipsEndFollowMouthR', min=0, max=1, dv=0.0, k=True, bReturnIfExists=True)
                    sDefaultSettingAttrs.extend([sLipsEndFollowMouthT, sLipsEndFollowMouthR])

                    sMouthPivotFrontBlendedT = nodes.createBlendMatrixNode([sSplinesPlusPucker, sSplinesPlusSidingLocalNoMouth],
                                                                          [sLipsEndFollowMouthT, nodes.createReverseNode(sLipsEndFollowMouthT)])
                    sMouthPivotFrontBlendedR = nodes.createBlendMatrixNode([sSplinesPlusPucker, sSplinesPlusSidingLocalNoMouth],
                                                                          [sLipsEndFollowMouthR, nodes.createReverseNode(sLipsEndFollowMouthR)])

                    sMouthPivotRotationScale = nodes.createDecomposeMatrix(sMouthPivotFrontBlendedR).split('.')[0]
                    sMouthPivotTranslate = nodes.createDecomposeMatrix(sMouthPivotFrontBlendedT).split('.')[0]
                    sBlendedMatrix = nodes.createComposeMatrixNode(xTranslate='%s.outputTranslate' % sMouthPivotTranslate,
                                                                   xRotate='%s.outputRotate' % sMouthPivotRotationScale,
                                                                   xScale='%s.outputScale' % sMouthPivotTranslate,
                                                                   xShear='%s.outputShear' % sMouthPivotRotationScale)
                    # cmds.connectAttr(sBlendedMatrix, '%s.offsetParentMatrix' % sLipsEndJoints[s])
                    nodes.createDecomposeMatrix(sBlendedMatrix, sTargetPos='%s.t' % sLipsEndJoints[s], sTargetRot='%s.r' % sLipsEndJoints[s], sTargetScale='%s.s' % sLipsEndJoints[s], sTargetShear='%s.shear' % sLipsEndJoints[s])

                createPostRefAttrFromCurrentWorld(sLipsEndJoints)
                deformers.resetJointReferences(sLipsEndJoints)

        ssSmallJointMatrices = [list(ssLocMatrices[0]), list(ssLocMatrices[1])]


        # lip zipper
        #
        if bZipper:
            ssSmallDecomposeMatrices = [[nodes.createDecomposeMatrix(sM, sName='_bot_beforeLipZipper_%03d' % j) for j, sM in enumerate(ssSmallJointMatrices[0])],
                                        [nodes.createDecomposeMatrix(sM, sName='_top_beforeLipZipper_%03d' % j) for j, sM in enumerate(ssSmallJointMatrices[1])]]
            sZipperLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (cCorners[0].sZipper, cCorners[0].sZipperFadeLength), sName='left_zipperByFade')
            sZipperRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (cCorners[1].sZipper, cCorners[1].sZipperFadeLength), sName='right_zipperByFade')

            for p,sPart in enumerate(['bot','top']):
                fLeftPercs = utils.bSpline4([0, 0, 1, 1], aValues=np.arange(len(aaPoints[p])) / float(len(aaPoints[p]) - 1))
                fRightPercs = 1.0 - fLeftPercs
                aPercsToOther = curves.getPercsFromPoints(sBpCurvesA[1 - p], aaPoints[p], bReturnNumpy=True)
                aPercsAtOther = curves.getPercsFromPoints(sBpCurvesA[1 - p], aaPoints[1 - p], bReturnNumpy=True)

                # this might have to be tested more on lips with different upper and lower count!!
                xOtherJointWeightings = xforms.getCtrlWeightings(aPercsToOther, aPercsAtOther)

                for j in range(len(aaPoints[p])):
                    sLeftRightZippers = cmds.createNode('plusMinusAverage', n='plus_sumZippers_%03d' % j)

                    sEndLeft = nodes.createAdditionNode([fLeftPercs[j], cCorners[0].sZipperFadeLength], sName='left_zipperFadeLength_%03d' % j)
                    sRangeLeft = nodes.createRangeNode(sZipperLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0, sName='left_zipper_%03d' % j)
                    nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

                    sEndRight = nodes.createAdditionNode([fRightPercs[j], cCorners[1].sZipperFadeLength], sName='right_zipperFadeLength_%03d' % j)
                    sRangeRight = nodes.createRangeNode(sZipperRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='right_zipper_%03d' % j)
                    nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

                    sClamp = nodes.createClampNode('%s.output1D' % sLeftRightZippers, 0, 1, sName='lipZipper_%s_%03d' % (sPart,j))
                    sJointBlendStrength = nodes.createMultiplyNode(sClamp, 0.5, sName='lipZipper_%s_%03d' % (sPart,j))

                    # get other joint weightings
                    iJoint0, iJoint1, fBlend = xOtherJointWeightings[j]
                    sOtherPos = nodes.createBlendNode(fBlend, ssSmallDecomposeMatrices[1-p][iJoint1],
                                                              ssSmallDecomposeMatrices[1-p][iJoint0], bVector=True, sName='lipZipper_%s_%03d_' % (sPart,j))
                    fLocalPoint = cmds.getAttr(ssSmallDecomposeMatrices[p][j])[0]
                    fOffset = np.array(fLocalPoint, dtype='float64') - np.array(cmds.getAttr(sOtherPos)[0], dtype='float64') # fLocalPoint was aaLocalPoints[p][j], but that was bad because of the new ctrl pivots
                    sOffsettedOtherPos = nodes.createVectorAdditionNode([sOtherPos, list(fOffset)], sName='lipZipper_%s_%03d_' % (sPart,j))
                    sBlendPos = nodes.createBlendNode(sJointBlendStrength, sOffsettedOtherPos, ssSmallDecomposeMatrices[p][j], bVector=True, sName='lipZipper_%s_%03d_' % (sPart,j))
                    ssSmallJointMatrices[p][j] = nodes.createComposeMatrixNode(xTranslate=sBlendPos,
                                                          xRotate='%s.outputRotate' % ssSmallDecomposeMatrices[p][j].split('.')[0],
                                                          xScale='%s.outputScale' % ssSmallDecomposeMatrices[p][j].split('.')[0], sName='lipZipper_%s_%03d_' % (sPart,j))

        # detail ctrls
        #
        for p,sPart in enumerate(['bot','top']):
            cDetails = []

            sPoints = [nodes.createDecomposeMatrix(sM) for sM in ssSmallJointMatrices[p]]

            for j,sJ in enumerate(ssSmallJoints[p]):
                if p == 1 and j in [0, len(ssSmallJoints[p]) - 1]:
                    continue
                sSide = utils.getSide(sJ)
                fSideMultipl = -1.0 if sSide == 'r' else 1.0
                iIndex = int(sJ.split('_')[-1])
                cDetail = ctrls8.create('detail%s' % utils.getFirstLetterUpperCase(sPart), sSide, iIndex, sShape='locator', fSize=fCurveLengthes[0]*0.1,
                                        iColorIndex=1, sParent=sLipsCtrlsParent, sAttrs=['t','r','s'])
                # cDetail.appendOffsetGroup('poses')

                cmds.connectAttr(sPoints[j], '%s.t' % cDetail.sPasser)

                sAimConstraint = constraints.aimConstraintEmpty(cDetail.sPasser, up=[0,0,fSideMultipl])
                cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0,0,1)

                if j == 0:
                    cmds.connectAttr(sPoints[j+1], '%s.target[0].targetTranslate' % sAimConstraint)
                    cmds.setAttr('%s.aimVector' % sAimConstraint, -1,0,0)
                elif j == len(ssSmallJointMatrices[p])-1:
                    cmds.connectAttr(sPoints[j-1], '%s.target[0].targetTranslate' % sAimConstraint)
                    cmds.setAttr('%s.aimVector' % sAimConstraint, 1,0,0)
                    # cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0,0,-1)
                else:
                    sVectorA = nodes.createVectorAdditionNode([sPoints[j+1], sPoints[j]], sOperation='minus')
                    sVectorB = nodes.createVectorAdditionNode([sPoints[j], sPoints[j-1]], sOperation='minus')
                    nodes.createVectorAdditionNode([sPoints[j], sVectorA, sVectorB], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                    cmds.setAttr('%s.aimVector' % sAimConstraint, -1,0,0)

                cDetail.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls8.kDefaultFaceAttachDeformers[2:]])

                ssSmallJointMatrices[p][j] = nodes.createMultMatrixNode([ssSmallJointMatrices[p][j],
                                                                         '%s.inverseMatrix' % cDetail.sPasser,
                                                                         '%s.worldMatrix' % cDetail.sCtrl,
                                                                         '%s.worldInverseMatrix' % cDetail.sExtraMove,
                                                                         '%s.worldMatrix' % cDetail.sPasser,
                                                                         '%s.worldInverseMatrix' % sLipsCtrlsParent])

                utils.addOffOnAttr(cMouth.sCtrl, 'detailCtrlsVis', sTarget='%s.v' % cDetail.sPasser, bDefaultValue=False, bReturnIfExists=True)
                cDetail.setDefaultAttrDict()
                cDetails.append(cDetail)
            addPoseOffsets(cDetails)

            for j, cDetail in enumerate(cDetails if p == 1 else cDetails[::-1]):
                cmds.controller(cDetail.sCtrl, cMouth.sCtrl, parent=True)


        ## POSES

        ## jawOpen pose
        sJawDriverAttr = 'jaw_ctrl.rz'

        for cC in cBotTops:
            sMatrixSkipped = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                        '%s.worldInverseMatrix' % cC.getOffsetByName('extramove'),
                                                         '%s.worldMatrix' % cC.sPasser])
            cC.sCtrlHeight = '%sY' % nodes.createPointByMatrixNode(nodes.createDecomposeMatrix(sMatrixSkipped), '%s.worldInverseMatrix' % sMouthPivotFront)

        for cC in cCorners:
            cC.sCtrlHeight = '%sY' % nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sPasser), '%s.worldInverseMatrix' % sMouthPivotFront)


        # Poses - JawOpen
        #
        sJawAngle = xforms.getSignedAngle3('jnt_m_jawMain', 'jnt_m_headMain', iAngleAxis=2)
        fJawAnglePoses = [cmds.getAttr(sJawAngle), None]
        cmds.setAttr(sJawDriverAttr, dMergedPoseCtrlValues['jawOpen'])
        fJawAnglePoses[1] = cmds.getAttr(sJawAngle)
        cmds.setAttr(sJawDriverAttr, 0.0)
        sJawAloneDriver = nodes.createRangeNode(sJawAngle, fJawAnglePoses[0], fJawAnglePoses[1], 0, 1, sName='jawAloneDriver')

        utils.addAttr('jnt_m_jawMain', ln='jawOpenPoseOverrideRotZ', dv=dMergedPoseCtrlValues['jawOpen'], k=True)

        xBoxHeights = [[[None, None], [None, None], [None, None]],
                       [[None, None], [None, None], [None, None]]]
        sCornerAverageCtrlHeight = nodes.createBlendNode(0.5, cCorners[0].sCtrlHeight, cCorners[1].sCtrlHeight)
        for p,sPart in enumerate(['bot','top']):
            #left:
            xBoxHeights[p][0][0] = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, cCorners[0].sCtrlHeight], sOperation='minus')
            xBoxHeights[p][0][1] = cmds.getAttr(xBoxHeights[p][0][0])

            # right:
            xBoxHeights[p][1][0] = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, cCorners[1].sCtrlHeight], sOperation='minus')
            xBoxHeights[p][1][1] = cmds.getAttr(xBoxHeights[p][1][0])

            # middle:
            xBoxHeights[p][2][0] = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, sCornerAverageCtrlHeight], sOperation='minus')
            xBoxHeights[p][2][1] = cmds.getAttr(xBoxHeights[p][2][0])

        ssJawDriverOutputs = [{}, {}, {}]
        for p,sPart in enumerate(['bot','top']):
            cmds.setAttr(sJawDriverAttr, dMergedPoseCtrlValues['jawOpen'])
            fPosedBoxHeightLeft = cmds.getAttr(xBoxHeights[p][0][0])
            fPosedBoxHeightRight = cmds.getAttr(xBoxHeights[p][1][0])
            fPosedBoxHeightMiddle = cmds.getAttr(xBoxHeights[p][2][0])
            cmds.setAttr(sJawDriverAttr, 0)
            print ('ssJawDriverOutputs[p]: ', ssJawDriverOutputs[p])

            ssJawDriverOutputs[p]['l'] = nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][0][0], xBoxHeights[p][0][1], fPosedBoxHeightLeft, 0, 1), sJawAloneDriver], sName='jawOpen_l_%s_' % utils.getFirstLetterUpperCase(sPart))
            ssJawDriverOutputs[p]['r'] = nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][1][0], xBoxHeights[p][1][1], fPosedBoxHeightRight, 0, 1), sJawAloneDriver], sName='jawOpen_r_%s_' % utils.getFirstLetterUpperCase(sPart))
            ssJawDriverOutputs[p]['m'] = nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][2][0], xBoxHeights[p][1][1], fPosedBoxHeightMiddle, 0, 1), sJawAloneDriver], sName='jawOpen_m_%s_' % utils.getFirstLetterUpperCase(sPart))

        # both parts combined
        for sSide in 'lrm':
            ssJawDriverOutputs[2][sSide] = nodes.createBlendNode(0.5, ssJawDriverOutputs[0][sSide], ssJawDriverOutputs[1][sSide])

        # ddPoseDriverDatas['jawOpen']['sCtrlDriverAttrs'] = [sJawDriverAttr]
        for sCtrl, sPoseOffset in dPoseOffsets.items():
            if sCtrl in ['mouthBot_ctrl', 'mouthTop_ctrl', 'lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']:
                continue
            iPart = 2
            if 'Bot' in sCtrl:
                iPart = 0
            elif 'Top' in sCtrl:
                iPart = 1
            sDriverOutput = ssJawDriverOutputs[iPart][utils.getSide(sCtrl)]
            addPoseLocToPoseOffset(sCtrl, 'jawOpen', sDriverOutput)

        utils.addStringAttr('jnt_m_jawMain', 'jawOpen_driver_bot', ssJawDriverOutputs[0]['l'])
        utils.addStringAttr('jnt_m_jawMain', 'jawOpen_driver_top', ssJawDriverOutputs[1]['r'])


        # Poses - MouthClose
        #
        fJawOpenOnMouthClose = dMergedPoseCtrlValues['jawOpenOnMouthClose']
        sMouthCloseAttr = utils.addAttr('jaw_ctrl', ln='mouthClose', min=0, max=1, dv=0, k=True)
        sMouthCloseOutput = nodes.createMultiplyNode(nodes.createRangeNode('jaw_ctrl.rz', 0, fJawOpenOnMouthClose, 0, 1), sMouthCloseAttr)
        for sCtrl, sPoseOffset in dPoseOffsets.items():
            addPoseLocToPoseOffset(sCtrl, 'mouthClose', sMouthCloseOutput)


        # Poses - Corners
        #
        def clampCornerForInterpolate(sPoint, sTarget):
            sPointX = '%sX' % sPoint
            sOutClampMaxY = nodes.createRangeNode(sPointX, 0, dMergedPoseCtrlValues['cornerOut'][0], dMergedPoseCtrlValues['cornerUp'][1], dMergedPoseCtrlValues['cornerOutUp'][1])
            sOutClampMinY = nodes.createRangeNode(sPointX, 0, dMergedPoseCtrlValues['cornerOut'][0], dMergedPoseCtrlValues['cornerDown'][1], dMergedPoseCtrlValues['cornerOutDown'][1])
            sInClampMaxY = nodes.createRangeNode(sPointX, 0, dMergedPoseCtrlValues['cornerIn'][0], dMergedPoseCtrlValues['cornerUp'][1], dMergedPoseCtrlValues['cornerInUp'][1])
            sInClampMinY = nodes.createRangeNode(sPointX, 0, dMergedPoseCtrlValues['cornerIn'][0], dMergedPoseCtrlValues['cornerDown'][1], dMergedPoseCtrlValues['cornerInDown'][1])

            sClampMinY = nodes.createConditionNode(sPointX, '>', 0, sOutClampMinY, sInClampMinY)
            sClampMaxY = nodes.createConditionNode(sPointX, '>', 0, sOutClampMaxY, sInClampMaxY)
            sClamped = nodes.createClampNode(sPoint, [dMergedPoseCtrlValues['cornerIn'][0], sClampMinY, 0], [dMergedPoseCtrlValues['cornerOut'][0], sClampMaxY, 0], bVector=True)
            cmds.connectAttr(sClamped, sTarget)



        sSortedCornerPoses = sorted([sKey for sKey in dMergedPoseCtrlValues.keys() if sKey.startswith('corner')])
        for s, sSide in enumerate(['l', 'r']):

            sAloneInterpolatorTransform = cmds.createNode('transform', n=f'loc_{sSide}_cornerAnimAndPoses', p=cCorners[s].sSlider)
            sLocal = nodes.createPointByMatrixNode(nodes.getWorldPoint(cCorners[s].sCtrl), '%s.worldInverseMatrix' % cCorners[s].sSlider)
            clampCornerForInterpolate(sLocal, '%s.t' % sAloneInterpolatorTransform)
            sInterp = cmds.poseInterpolator(sAloneInterpolatorTransform, name=f'interp_{sSide}_corner')[0]
            cmds.setAttr(f'{sInterp}.enableRotation', False)
            cmds.setAttr(f'{sInterp}.enableTranslation', True)
            cmds.parent(sInterp, 'modules')
            cmds.poseInterpolator(sInterp, e=True, addPose='default')
            dPoseCtrlValuesAloneOutputs = {}
            for i, sCornerPose in enumerate(sSortedCornerPoses):
                fPose = dMergedPoseCtrlValues[sCornerPose]
                cmds.setAttr('%s.t' % cCorners[s].sCtrl, fPose[0], fPose[1], 0.0)
                cmds.poseInterpolator(sInterp, e=True, addPose=sCornerPose)
                dPoseCtrlValuesAloneOutputs[sCornerPose] = f'{sInterp}.output[{i + 1}]'

                sLogAttr = utils.addAttr(cCorners[s].sCtrl, ln=utils.getFirstLetterLowerCase(sCornerPose.replace('corner', '')), k=False, cb=False)
                cmds.connectAttr(dPoseCtrlValuesAloneOutputs[sCornerPose], sLogAttr)
            cmds.setAttr('%s.t' % cCorners[s].sCtrl, 0, 0, 0)

            dCornerPoseDriverOutputs = {sCornerPose:[None, None, None] for sCornerPose in sSortedCornerPoses+['pucker']}

            for p, sPart in enumerate(['bot', 'top']):

                sOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[s].sCtrl, nodes.createInverseMatrix(cBotTops[p].sJumpedMatrix, bJustValues=True)], bJustValues=True)
                sInv = nodes.createInverseMatrix(nodes.createMultMatrixNode([sOffset, cBotTops[p].sJumpedMatrix]))
                sCornerInBoxSpace = nodes.createPointByMatrixNode(cCorners[s].sJumpedPos, sInv)

                sInterpolatorTransform = cmds.createNode('transform', n=f'loc_{sSide}_{sPart.title()}_cornerInBoxSpace', p=cCorners[s].sPasser)
                sInterp = cmds.poseInterpolator(sInterpolatorTransform, name=f'interp_{sSide}_{sPart.title()}corner')[0]
                cmds.parent(sInterp, 'modules')

                clampCornerForInterpolate(sCornerInBoxSpace, '%s.t' % sInterpolatorTransform)
                cmds.setAttr(f'{sInterp}.enableRotation', False)
                cmds.setAttr(f'{sInterp}.enableTranslation', True)

                cmds.poseInterpolator(sInterp, e=True, addPose='default')
                for i, sCornerPose in enumerate(sSortedCornerPoses):
                    fPose = dMergedPoseCtrlValues[sCornerPose]
                    cmds.setAttr('%s.t' % cCorners[s].sCtrl, fPose[0], fPose[1], 0.0)
                    cmds.poseInterpolator(sInterp, e=True, addPose=sCornerPose)
                    sOutput = f'{sInterp}.output[{i+1}]'

                    sMinimumOutput = nodes.createMinimumNode([sOutput, dPoseCtrlValuesAloneOutputs[sCornerPose]], sName='%s_%s_%sMinimum' % (sSide, sPart, sCornerPose))
                    if sCornerPose == 'cornerIn':
                        dCornerPoseDriverOutputs[sCornerPose][p] = nodes.createMultiplyNode(sMinimumOutput, sPuckerOnCornerInRevs[s])
                        dCornerPoseDriverOutputs['pucker'][p] = nodes.createMultiplyNode(sMinimumOutput, sPuckerOnCornerIns[s])
                    else:
                        dCornerPoseDriverOutputs[sCornerPose][p] = sMinimumOutput

                    if True:
                        sShortenedPoseName = utils.getFirstLetterLowerCase(sCornerPose.replace('corner', ''))
                        sDebugAttr = utils.addAttr(cCorners[s].sCtrl, ln=f'pose{sPart.title()}_{sShortenedPoseName}', k=False, cb=False)
                        cmds.connectAttr(sOutput, sDebugAttr)

                cmds.setAttr('%s.t' % cCorners[s].sCtrl, 0,0,0)


            for sCornerPose in sSortedCornerPoses+['pucker']:
                dCornerPoseDriverOutputs[sCornerPose][2] = nodes.createBlendNode(0.5, dCornerPoseDriverOutputs[sCornerPose][0], dCornerPoseDriverOutputs[sCornerPose][1]) # bot/top combined
                for sCtrl, sPoseOffset in dPoseOffsets.items():
                    if sCtrl in ['mouthBot_ctrl', 'mouthTop_ctrl', 'lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']:
                        continue
                    sCtrlSide = utils.getSide(sCtrl)
                    if sCtrlSide != 'm' and sCtrlSide != sSide:
                        continue

                    sDriverOutput = dCornerPoseDriverOutputs[sCornerPose][iPart]
                    addPoseLocToPoseOffset(sCtrl, '%s_%s' % (sCornerPose, sSide) if sCtrlSide=='m' else sCornerPose, sDriverOutput)

        # Poses - Lip Rolls
        #
        # dSimplePoseOutputs = {}
        for p,sPart in enumerate(['bot','top']):
            sAngle = xforms.getSignedAngle3(cBotTops[p].sCtrl, cBotTops[p].sSlider, iUpAxis=2)
            sAngleAttr = utils.addAttr(cBotTops[p].sPasser, ln='rollAngle', k=True)
            nodes.createMultiplyNode(sAngle, -1, sTarget=sAngleAttr)

            for sPoseKeyType in ['RollIn', 'RollOut']:
                sPoseKey = f'{sPart}{sPoseKeyType}'
                fPoseValue = dMergedPoseCtrlValues[f'{sPart}{sPoseKeyType}']
                sDriverOutput = nodes.createRangeNode(sAngleAttr, 0, fPoseValue, 0, 1)
                for sCtrl, sPoseOffset in dPoseOffsets.items():
                    if sCtrl in ['mouthBot_ctrl', 'mouthTop_ctrl']:
                        continue
                    if ['Top', 'Bot'][p] in sCtrl:
                        continue
                    addPoseLocToPoseOffset(sCtrl, sPoseKey, sDriverOutput)

                # dSimplePoseOutputs[sPoseKey] = sDriverOutput

        ## create drivers of simple poses
        for sPoseKey, fPoseValue in [('funnel', 1.0), ('lipPress', -1.0)]:
            sDriverOutput = nodes.createRangeNode('mouth_ctrl.tz', 0, fPoseValue, 0, 1)
            for sCtrl, sPoseOffset in dPoseOffsets.items():
                if sCtrl == 'mouth_ctrl':
                    continue
                addPoseLocToPoseOffset(sCtrl, sPoseKey, sDriverOutput)

            # dSimplePoseOutputs[sPoseKey] = sDriverOutput





        for p, sPart in enumerate(['bot', 'top']):
            for j,sJ in enumerate(ssSmallJoints[p]):
                aDiff = nodes.createPointByMatrixNode(aaLocalPoints[p][j],
                                                      nodes.createInverseMatrix(ssSmallJointMatrices[p][j], bJustValues=True), bJustValues=True)
                ssSmallJointMatrices[p][j] = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(aDiff), ssSmallJointMatrices[p][j]])

            # squash/stretch
            #
            sSquashStretchMatrices = []
            sPoints = [nodes.createDecomposeMatrix(sM) for sM in ssSmallJointMatrices[p]]
            ssDistances = [], []
            for j in range(1, len(sPoints) // 2 + 1, 1):
                ssDistances[0].append(nodes.createDistanceNode(sPoints[j], sPoints[j - 1]))
            for j in range(len(sPoints) - 2, len(sPoints) // 2 - 1, -1):
                ssDistances[1].append(nodes.createDistanceNode(sPoints[j], sPoints[j + 1]))

            sSideDistanceSums = []
            aaSideScaleWeights = []
            for s, fWeights in enumerate([[1, 1, 0, 0], [0, 0, 1, 1]]):
                sSum = nodes.createAdditionNode(ssDistances[s], sFullName='sum_%s_mouthScale' % utils.sSides1[s])
                sSideDistanceSums.append(sSum)
                aaSideScaleWeights.append(utils.bSpline4(fWeights, aValues=aPercs))

            ddSquashStretchSettings['sDriverLeft'] = sSideDistanceSums[0]
            utils.data.store('ddSquashStretchSettings', ddSquashStretchSettings)

            if not ddSquashStretchSettings['bScaleJoints']:
                sSquashStretchMatrices = ssSmallJointMatrices[p]
            else:
                sSquashStrengthHeight = utils.addAttr(cMouth.sPasser, ln='squashStrengthHeight', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sSquashStrengthDepth = utils.addAttr(cMouth.sPasser, ln='squashStrengthDepth', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sStretchStrengthHeight = utils.addAttr(cMouth.sPasser, ln='stretchStrengthHeight', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sStretchStrengthDepth = utils.addAttr(cMouth.sPasser, ln='stretchStrengthDepth', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sDefaultSettingAttrs += [sSquashStrengthHeight, sStretchStrengthHeight, sSquashStrengthDepth, sStretchStrengthDepth]

                sCtrlScaleDiffs = []
                for c,cC in enumerate(ccRows[p]):
                    if c == 0:
                        cScale = ccRows[p][1]
                    elif c == len(ccRows[p])-1:
                        cScale = ccRows[p][len(ccRows[p])-2]
                    else:
                        cScale = cC
                    sScaleAttr = nodes.createVectorMultiplyNode('%s.scale' % cScale.sCtrl,
                                                                '%s.scale' % cScale.getOffsetByName('poses'))

                    sClamp = nodes.createClampNode([1.0, '%sY' % sScaleAttr, '%sZ' % sScaleAttr], [0.1, 0.1, 0.1], [10, 10, 10], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sScaleDiff = nodes.createVectorAdditionNode([sClamp, [1,1,1]], sOperation='minus', sName='%s_%s_squashStretch' % (sSide, sPart))
                    sCtrlScaleDiffs.append(sScaleDiff)

                sSideScaleAdditions = []
                for s, sSide in enumerate(['l', 'r']):
                    sLipsLengthFactor = nodes.createMultiplyNode(cmds.getAttr(sSideDistanceSums[s]), sSideDistanceSums[s], sOperation='divide', sName='l_%s_squashStretchFactor' % (sPart))

                    sStretchFactor = nodes.createConditionNode(sLipsLengthFactor, '<', 1.0, 1.0, 0.0)
                    sSquashFactor = nodes.createReverseNode(sStretchFactor)
                    sStrength = nodes.createVectorAdditionNode([nodes.createVectorMultiplyNode([0, sStretchStrengthHeight, sStretchStrengthDepth], sStretchFactor, bVectorByScalar=True),
                                                                nodes.createVectorMultiplyNode([0, sSquashStrengthHeight, sSquashStrengthDepth], sSquashFactor, bVectorByScalar=True)])
                    
                    sScaleAddition = nodes.createVectorAdditionNode([[sLipsLengthFactor, sLipsLengthFactor, sLipsLengthFactor], [-1, -1, -1]])
                    sSideScaleAdditions.append(nodes.createVectorMultiplyNode(sScaleAddition, sStrength))
                    
                for j, sJ in enumerate(ssSmallJoints[p]):

                    sAdditions = []
                    # left right scale from lengths
                    for s,sSide in enumerate(['l','r']):
                        sAdditions.append(nodes.createVectorMultiplyNode(sSideScaleAdditions[s], aaSideScaleWeights[s][j], bVectorByScalar=True, sName='%s_%s_squashStretch_%03d_' % (sSide,sPart,j)))

                    # ctrl scales
                    iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                    sAdditions.append(nodes.createBlendNode(fBlend, sCtrlScaleDiffs[iCtrl1], sCtrlScaleDiffs[iCtrl0], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart)))

                    sScale = nodes.createVectorAdditionNode([[1,1,1]] + sAdditions, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sScale = nodes.createClampNode(sScale, [0.1, 0.1, 0.1], [100.0, 100.0, 100.0], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sLocalScaleMatrix = nodes.createComposeMatrixNode(xScale=sScale, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sSquashStretchMatrices.append(nodes.createMultMatrixNode([sLocalScaleMatrix, ssSmallJointMatrices[p][j]], sName='%sSquashStretch_%03d' % (sPart,j)))
                    
            ssSmallJointMatrices[p] = sSquashStretchMatrices






        # finally set them
        for p,sPart in enumerate(['bot','top']):
            # finally connect the small joints
            for j,sJ in enumerate(ssSmallJoints[p]):
                if not utils.isNone(sJ):
                    xforms.resetTransform(sJ, jo=True)
                    nodes.createDecomposeMatrix(ssSmallJointMatrices[p][j], sTargetPos = '%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ, sName='finalDecomposeSmall_%s_%03d' % (sPart,j))
            utils.data.store('%sLipJointsSmall' % sPart, ssSmallJoints[p])


            # finally connect the big joints
            for j,sJ in enumerate(ssBigJoints[p]):
                if not utils.isNone(sJ):
                    nodes.createDecomposeMatrix(ssBigJointMatrices[p][j], sTargetPos = '%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ, sName='finalDecomposeBig_%s_%03d' % (sPart,j))




        # Default Settings (including Poses)
        for sA, fV in list(dDefaultSettingValues.items()):
            if cmds.objExists(sA):
                if isinstance(fV, (list,tuple)):
                    cmds.setAttr(sA, *fV)
                else:
                    cmds.setAttr(sA, fV)
            else:
                report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)




        # Lip Push - important that it runs after Default Settings, since that's posing the Pose Locators
        for cBot, cTop in zip(ccLipCtrls[0], ccLipCtrls[1]):
            sLipPushAttr = utils.addAttr(cTop.sCtrl, ln='lipPush', min=0, max=1, dv=0, k=True)
            sDecompBotCtrl = nodes.createDecomposeMatrix(cBot.sJumpedMatrix)
            fBotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cBot.sPasser, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)
            sPasserDefaultMatrix = nodes.createMultMatrixNode([fBotOffset, '%s.worldMatrix' % sMouthPivotFront])
            if cBot.sSide == 'r':
                sPasserDefaultMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xScale=[-1, -1, -1]), sPasserDefaultMatrix])

            sPasserDefaultRotation = nodes.createDecomposeMatrix(sPasserDefaultMatrix, bReturnRotate=True)
            sPlane = nodes.createComposeMatrixNode(xTranslate=sDecompBotCtrl, xRotate=sPasserDefaultRotation, xScale='%s.outputScale' % sPasserDefaultRotation.split('.')[0])
            sPlaneInv = nodes.createInverseMatrix(sPlane)
            sTopInPlane = nodes.createMultMatrixNode([cTop.sJumpedMatrix, sPlaneInv])

            sTopInPlaneY = '%sY' % nodes.createDecomposeMatrix(sTopInPlane)
            fDefaultTopInPlaneY = cmds.getAttr(sTopInPlaneY)

            sImpactingPoseKeys = ['cornerOut', 'cornerIn', 'cornerUp', 'cornerDown', 'cornerOutUp', 'cornerInUp', 'cornerOutDown', 'cornerInDown', 'botRollIn', 'topRollIn', 'lipPress', 'pucker']
            sDotNodes = []
            iNextImportantPoseIndex = 0
            for sPoseKey in sImpactingPoseKeys:
                if sPoseKey in dDriverPerCtrlsForLipPush[cTop.sCtrl]:

                    if sPoseKey.startswith('corner') or sPoseKey == 'pucker':
                        sPoseKeySide = utils.getSide(cTop.sCtrl)
                        if sPoseKeySide == 'm':
                            continue
                        iPoseKeySide = 'lr'.index(sPoseKeySide)
                        cmds.setAttr('%s.t' % cCorners[iPoseKeySide].sCtrl, dMergedPoseCtrlValues[sPoseKey][0], dMergedPoseCtrlValues[sPoseKey][1], 0.0)
                        if sPoseKey in ['cornerIn', 'pucker']:
                            fPuckerBefore = cmds.getAttr(sPuckerOnCornerIns[0])
                            cmds.setAttr(sPuckerOnCornerIns[0], 1.0 if sPoseKey == 'pucker' else 0.0)
                            cmds.setAttr(sPuckerOnCornerIns[1], 1.0 if sPoseKey == 'pucker' else 0.0)
                    elif 'Roll' in sPoseKey:
                        iPoseKeyPart = 0 if sPoseKey[0:3] == 'bot' else 1
                        cmds.setAttr('%s.rx' % cBotTops[iPoseKeyPart].sCtrl, dMergedPoseCtrlValues[sPoseKey])
                    elif sPoseKey in ['lipPress', 'funnel']:
                        cmds.setAttr('mouth_ctrl.tz', -1 if sPoseKey == 'lipPress' else 1.0)
                    elif sPoseKey == 'mouthClose':
                        cmds.setAttr('jaw_ctrl.rz', dMergedPoseCtrlValues['jawOpenOnMouthClose'])
                        cmds.setAttr('jaw_ctrl.mouthClose', 1.0)
                    fValue = cmds.getAttr(sTopInPlaneY) - fDefaultTopInPlaneY

                    if sPoseKey.startswith('corner') or sPoseKey == 'pucker':
                        cmds.setAttr('%s.t' % cCorners[iPoseKeySide].sCtrl, 0,0,0)
                        if sPoseKey in ['cornerIn', 'pucker']:
                            cmds.setAttr(sPuckerOnCornerIns[0], fPuckerBefore)
                            cmds.setAttr(sPuckerOnCornerIns[1], fPuckerBefore)
                    elif 'Roll' in sPoseKey:
                        cmds.setAttr('%s.rx' % cBotTops[iPoseKeyPart].sCtrl, 0)
                    elif sPoseKey in ['lipPress', 'funnel']:
                        cmds.setAttr('mouth_ctrl.tz', 0.0)
                    elif sPoseKey == 'mouthClose':
                        cmds.setAttr('jaw_ctrl.rz', 0.0)
                        cmds.setAttr('jaw_ctrl.mouthClose', 0.0)

                    if abs(fValue) > 0.0001:
                        iModulo = iNextImportantPoseIndex % 3
                        if iModulo == 0:
                            sDotNodes.append(nodes.createDotProductNode([0,0,0], [0,0,0]).split('.')[0])
                        sPoseOutput = dDriverPerCtrlsForLipPush[cTop.sCtrl][sPoseKey]
                        cmds.connectAttr(sPoseOutput,  '%s.input1%s' % (sDotNodes[-1], ['X','Y','Z'][iModulo]))
                        cmds.setAttr('%s.input2%s' % (sDotNodes[-1], ['X','Y','Z'][iModulo]), fValue)
                        iNextImportantPoseIndex += 1

            sDefaultTopInPlaneInclPoses = nodes.createAdditionNode([fDefaultTopInPlaneY] + ['%s.outputX' % sNode for sNode in sDotNodes])
            sDiff = nodes.createAdditionNode([sTopInPlaneY, sDefaultTopInPlaneInclPoses], sOperation='minus')
            sPushValue = nodes.createConditionNode(sDiff, '<', 0, nodes.createMultiplyNode(sDiff, -1), 0)
            sTranslateY = nodes.createBlendNode(sLipPushAttr, sPushValue, 0)
            sCtrlAndPose = nodes.createMultMatrixNode(['%s.worldMatrix' % cTop.sCtrl, '%s.parentInverseMatrix' % dPoseOffsets[cTop.sCtrl]])
            sParentScaleY = '%s.outputScaleY' % nodes.createDecomposeMatrix(sCtrlAndPose).split('.')[0]
            nodes.createMultiplyNode(sTranslateY, sParentScaleY, sOperation='divide', sTarget='%s.ty' % cTop.sOut)
            cmds.setAttr(sLipPushAttr, 1.0)


        for sJoint in utils.flattenedList(ssBigJoints) + utils.flattenedList(ssSmallJoints):
            if not utils.isNone(sJoint):
                utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, cmds.getAttr('%s.worldInverseMatrix' % sJoint))
                deformers.resetJointReferences(sJoint)


        for cCtrl in utils.flattenedList(ccRows + ccCornerTangents + cBotTops + [cMouth]):
            cCtrl.setDefaultAttrDict()


    # EXCLUDE END MOUTHSPLINES


    for sCurve in sBpCurvesA+sBpCurvesB:
        cmds.setAttr('%s.v' % sCurve, False)
    
    cmds.setAttr('%s.v' % kMouthBpGroupName, False)
    utils.data.store('sDefaultSettingAttrs', sDefaultSettingAttrs)




def roundCornerRom(fJawRotates, fCornerRange):
    cmds.setKeyframe('lipsCorner_l_ctrl.pointyRound', t=1, v=0.0)
    cmds.setKeyframe('lipsCorner_r_ctrl.pointyRound', t=1, v=0.0)
    fCurrentTime = 5.0
    cmds.setKeyframe('lipsCorner_l_ctrl.pointyRound', t=fCurrentTime, v=1.0)
    cmds.setKeyframe('lipsCorner_r_ctrl.pointyRound', t=fCurrentTime, v=1.0)
    sJawAttr = '%s.rz' % jawCtrl()
    sCornerAttrs = ['lipsCorner_l_ctrl.translateX', 'lipsCorner_r_ctrl.translateX']
    fCurrentTime = 5.0
    for fJawRotate in ([0.0] + fJawRotates):
        cmds.setKeyframe(sJawAttr, t=fCurrentTime, v=fJawRotate)
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=0)
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=0)
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=fCornerRange[0])
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=fCornerRange[0])
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=fCornerRange[1])
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=fCornerRange[1])
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=0)
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=0)
        fCurrentTime += 5.0

    cmds.playbackOptions(e=True, minTime=0, maxTime=fCurrentTime)

            


@builderTools.addToBuild(iOrder=65, bDisableByDefault=True, dButtons={'create rom':roundCornerRom})
def calibratePointyRound(fCornerRange=[-1,1.5], fJointIndexFromLeft=1.0, fJawRotates=[-8, -15, -25], fTangentScales=[1,1.5,2.0], fPostMultipl=1.0):
    '''
    If "fJointIndexFromLeft" is 0.0, then he's taking the 2nd joint from the very left or right to \
    analize the roundness during the calibrating. If it's one, then it's the 1st Sjoint. If there \
    are issues calibrating, this is the first value you should experiment with.

    To find the values for fTangentScales: break the connections to inf_l_lipsCornerMouthInfluenceBot and inf_l_lipsCornerMouthInfluenceTop,
    and try scaling it while mouth is open

    fPostMultipl happens after the calibration
    '''

    if utils.data.get('bMouthSplines', xDefault=False) == False:
        report.report.addLogText('skipping because mouth is not setup with bSPLINES')
        return False


    kPointyRoundPrefix = 'pointyRoundCalibrate__'

    sOldNodes = cmds.ls('%s*' % kPointyRoundPrefix)
    if sOldNodes:
        cmds.delete(sOldNodes)

    # sCornerCtrls = ['lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']
    cCornerCtrls = [ctrls8.ctrlFromName('lipsCorner_l_ctrl'),
                    ctrls8.ctrlFromName('lipsCorner_r_ctrl')]


    sCalibrateNodeOutputs = []
    try:
        ssLipJoints = [None, None]
        for p,sPart in enumerate(['bot','top']):
            ssLipJoints[p] = utils.data.get('%sLipJointsSmall' % sPart)

        iJointIndexFromLeftFloor = int(math.floor(fJointIndexFromLeft))
        if (fJointIndexFromLeft - iJointIndexFromLeftFloor) < 0.0001:
            iJointIndexFromLeftCeil = iJointIndexFromLeftFloor + 1
        else:
            iJointIndexFromLeftCeil = int(math.ceil(fJointIndexFromLeft))
        fJointT = fJointIndexFromLeft - iJointIndexFromLeftFloor


        sPointBotFloor = nodes.getWorldPoint(ssLipJoints[0][iJointIndexFromLeftFloor])
        sPointBotCeil = nodes.getWorldPoint(ssLipJoints[0][iJointIndexFromLeftCeil])

        sPointTopFloor = nodes.getWorldPoint(ssLipJoints[1][iJointIndexFromLeftFloor])
        sPointTopCeil = nodes.getWorldPoint(ssLipJoints[1][iJointIndexFromLeftCeil])


        sOpenDriver = nodes.createDistanceNode(nodes.getWorldPoint('mouthBot_ctrl'), nodes.getWorldPoint('mouthTop_ctrl'))

        sJawAttr = '%s.rz' % jawCtrl()

        fClosedValue = cmds.getAttr(sOpenDriver)
        fOpenValues = []
        for r, fRot in enumerate(fJawRotates):
            cmds.setAttr(sJawAttr, fRot)
            fOpenValues.append(cmds.getAttr(sOpenDriver))
        cmds.setAttr(sJawAttr, 0.0)

        sExceedWhenOnAttrs = utils.data.get('sRoundExceedWhenOnAttrs')
        sPointyRoundAttrs = ['%s.pointyRound' % cCornerCtrls[0].sCtrl, '%s.pointyRound' % cCornerCtrls[1].sCtrl]
        sPointyRoundAttrSums = ['%s.pointyRoundSum' % cCornerCtrls[0].sPasser, '%s.pointyRoundSum' % cCornerCtrls[1].sPasser]

        for s, sSide in enumerate(['l', 'r']):
            sTangentScalesAuto = utils.data.get('sTangentScalesAuto_%s' % sSide)
            # sJoints = ['inf_%s_lipsCornerMouthInfluenceBot' % sSide, 'inf_%s_lipsCornerMouthInfluenceTop' % sSide]
            sDrivenKeys0 = nodes.setDrivenKey(sOpenDriver, [fClosedValue] + fOpenValues, None, [1] + fTangentScales)
            sDrivenKeys1 = nodes.setDrivenKey(sOpenDriver, [fClosedValue] + fOpenValues, None, [1] + fTangentScales)

            nodes.createBlendNode(sPointyRoundAttrSums[s], sDrivenKeys0, 1.0, sTarget=sTangentScalesAuto[0], bForce=True)
            nodes.createBlendNode(sPointyRoundAttrSums[s], sDrivenKeys1, 1.0, sTarget=sTangentScalesAuto[1], bForce=True)


        sTempCalibrateParentMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(ssLipJoints[0][0]),
                                                                   xRotate=nodes.createDecomposeMatrix('ctrl_l_lipsCornerOrigOut.worldMatrix', bReturnRotate=True))

        sTempCalibrateParentInverseMatrix = nodes.createInverseMatrix(sTempCalibrateParentMatrix)
        sTempCalibratePointBot = nodes.createPointByMatrixNode(nodes.createBlendNode(fJointT, sPointBotCeil, sPointBotFloor, bVector=True),
                                                               sTempCalibrateParentInverseMatrix)
        sTempCalibratePointTop = nodes.createPointByMatrixNode(nodes.createBlendNode(fJointT, sPointTopCeil, sPointTopFloor, bVector=True),
                                                               sTempCalibrateParentInverseMatrix)

        sTempCalibratePointNormalizedBot = nodes.createNormalizedVector(['%sX' % sTempCalibratePointBot, '%sY' % sTempCalibratePointBot, 0])
        sTempCalibratePointNormalizedTop = nodes.createNormalizedVector(['%sX' % sTempCalibratePointTop, '%sY' % sTempCalibratePointTop, 0])

        sTempDot = nodes.createDotProductNode(sTempCalibratePointNormalizedBot, sTempCalibratePointNormalizedTop)
        sTempAverageHoriz = nodes.createBlendNode(0.5, '%sX' % sTempCalibratePointNormalizedBot, '%sX' % sTempCalibratePointNormalizedTop)

        sParentLoc = cmds.spaceLocator(n='calibrateInfo')[0]
        sLoc0 = cmds.spaceLocator()[0]
        sLoc1 = cmds.spaceLocator()[0]
        sLoc2 = cmds.spaceLocator()[0]
        cmds.parent(sLoc0, sLoc1, sLoc2, sParentLoc)
        cmds.connectAttr(sTempCalibratePointNormalizedBot, '%s.t' % sLoc0)
        cmds.connectAttr(sTempCalibratePointNormalizedTop, '%s.t' % sLoc1)
        cmds.connectAttr(sTempAverageHoriz, '%s.tx' % sLoc2)
        cmds.connectAttr(sTempDot, '%s.ty' % sLoc2)
        def calibrate():
            fDirection = -1 if cmds.getAttr(sTempAverageHoriz) > 0 else 1
            iTestingCount = 18
            fValues = np.arange(iTestingCount) * 5 * fDirection
            fDots = [0] * iTestingCount
            for v, fValue in enumerate(fValues): #(18 = 90 / 5)
                cmds.setAttr(sExceedWhenOnAttrs[0], float(fValue))
                fDots[v] = cmds.getAttr(sTempDot)
            iSmallestDot = np.argmin(fDots)
            return fValues[iSmallestDot]


        # cmds.setAttr(sPointyRoundAttrs[0], 1.0 - cmds.getAttr(sPointyRoundAttrSums[0]))
        report.report.resetProgress(len(fJawRotates))
        ssDrivenKeys = [], []
        for fJawRotate in fJawRotates:
            print('\n\n\n ============ JAWROTATE: ', fJawRotate)

            cmds.setAttr(sJawAttr, fJawRotate)
            cmds.setAttr(sPointyRoundAttrs[0], 0.0)
            cmds.setAttr(sPointyRoundAttrs[0], 1.0 - cmds.getAttr(sPointyRoundAttrSums[0]))

            # fLipOutDriverValues = [-0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0, 1.5]
            iHorizCount = 8
            fLipOutDriverValues =  np.interp(np.arange(iHorizCount), [0, iHorizCount-1], fCornerRange)

            aValues = np.zeros(len(fLipOutDriverValues), dtype='float64')
            for v,fX in enumerate(fLipOutDriverValues):
                print('=================== calibrating.. ', fX, fJawRotate)
                cmds.setAttr('%s.tx' % cCornerCtrls[0].sCtrl, fX)
                aValues[v] = calibrate()
            aValues *= fPostMultipl

            for s, sSide in enumerate(['l','r']):
                sDks = nodes.setDrivenKey('%s.tx' % cCornerCtrls[s].sCtrl, fLipOutDriverValues, None, aValues)
                ssDrivenKeys[s].append(sDks)
                sCalibrateNodeOutputs.append(sDks)
            report.report.incrementProgress()

        cmds.setAttr(sPointyRoundAttrs[0], 0.0)
        cmds.setAttr(sJawAttr, 0.0)
        cmds.setAttr('%s.tx' % cCornerCtrls[0].sCtrl, 0.0)


        sCalibrateNodeOutputs.append(sOpenDriver)


        for s,sSide in enumerate(['l','r']):
            sPrevCond = 0.0
            for r in range(len(fJawRotates) - 1):
                iFrom = r
                iTo =  r+1
                sRange = nodes.createRangeNode(sOpenDriver, fOpenValues[iFrom], fOpenValues[iTo], ssDrivenKeys[s][iFrom], ssDrivenKeys[s][iTo],
                                               sName='%s_pointyRoundCondition_%03d' % (sSide,r))
                sNewCond = nodes.createConditionNode(sOpenDriver, '<', fOpenValues[iTo], sRange, 0,
                                                     sName='%s_pointyRoundCondition_%03d' % (sSide,r))

                if r == 0:
                    cmds.connectAttr(sNewCond, sExceedWhenOnAttrs[s])
                else:
                    sPrevCondNode = sPrevCond.split('.')[0]
                    cmds.connectAttr(sNewCond, '%s.colorIfFalseR' % sPrevCondNode)
                    if r == len(fJawRotates) - 2:
                        sNewCondNode = sNewCond.split('.')[0]
                        cmds.connectAttr(ssDrivenKeys[s][iTo], '%s.colorIfFalseR' % sNewCondNode)

                sPrevCond = sNewCond
                sCalibrateNodeOutputs += [sRange, sNewCond]

    except:
        raise
    finally:
        for o, sO in enumerate(sCalibrateNodeOutputs):
            sNode = sO.split('.')[0]
            sCalibrateNodeOutputs[o] = cmds.rename(sNode, '%s%s' % (kPointyRoundPrefix, sNode))



#EXCLUDE START CHEEKSETUP




sCheekGroupName = '_grp_m_cheekBps'
kCheekFileName = 'blueprintCheek.ma'
dButtons = OrderedDict()
dButtons['Create Left Cheek Curve (Tracked Order)'] = lambda: createBpCurve('bpCurve_l_cheek', sCheekGroupName,
                                                                            fDirection=(0, 1, 0), bTrackedOrder=True)
dButtons['Create Left Cheek Curve (Tracked Order)'].dSideButtons = {'?':['The vertices here don\'t have to be neighbor vertices, as long '\
                                                            '\nas you select them in the correct order', 'cheekTrackedOrder.jpg']}
dButtons['Create Left Cheek Curve'] = lambda: createBpCurve('bpCurve_l_cheek', sCheekGroupName,
                                                            fDirection=(0, 1, 0))

# def createCheekLocator():
#     xforms.createLocator('bpLoc_l_cheekCorner', xPos=cmds.xform(q=True, ws=True, t=True), sParent=sCheekGroupName)
dButtons['Create Left Cheek Corner Loc Selected CV'] = lambda: xforms.createLocator('bpLoc_l_cheekCorner', xPos=cmds.xform(q=True, ws=True, t=True), sParent=sCheekGroupName)

dButtons['Create Left Cheek Curve'].dSideButtons = {'?':['If the vertices all neighbors, you can use that '\
                                             'button instead of the one above']}
dButtons['Create Left Cheek PushOut Curve'] = lambda: createBpUpVectorCurve('bpCurve_l_cheekUp',
                                                                            'bpCurve_l_cheek')
dButtons['Create Left Cheek PushOut Curve'].dSideButtons = {'?':['no selection needed, he\'ll create the curve himself']}

dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsCheeks', 'dDefaultSettingValuesCheeks')


dButtons['Export BPs'] = lambda: exportBps(kCheekFileName, sCheekGroupName)


@builderTools.addToBuild(iOrder=62.4, dButtons=dButtons, bDisableByDefault=True)
def cheekSetup(sParentJoint='jnt_m_headMain', fBotCtrlPercs=[0.5], fTopCtrlPercs=[0.33, 0.66], iCheekCurveJointCount=8, dDefaultSettingValuesCheeks={}, iSharpenCornerPoint=1):
    sDefaultSettingAttrsCheeks = []

    sGroup = cmds.createNode('transform', n='grp_cheekSetup', p='modules')
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'cheekCtrlVis', False)

    sBpCurves = ['bpCurve_l_cheek', 'bpCurve_r_cheek']
    sBpUpCurves = ['bpCurve_l_cheekUp', 'bpCurve_r_cheekUp']

    fCornerPerc = curves.getPercsFromTransforms(sBpCurves[0], ['bpLoc_l_cheekCorner'])[0]

    fCtrlPercs = [0.0] + list(np.interp(fBotCtrlPercs, [0.0, 1.0], [0.0, fCornerPerc])) + [fCornerPerc] + list(np.interp(fTopCtrlPercs, [0.0, 1.0], [fCornerPerc, 1.0])) + [1.0]
    iCornerIndex = len(fBotCtrlPercs) + 1
    ccCtrls = [[], []]
    ssJoints = [], []
    # sGlobalScale = nodes.getScaleFromXform(sParentJoint)
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        curves.mirrorIfNotExists(sBpCurves[s], sErrorAddition='You need to create the curves using the button "Create Left Cheek Curve"')
        curves.mirrorIfNotExists(sBpUpCurves[s], sErrorAddition='Maybe you forgot to click the button "Create Left Cheek PushOut Curve"')

        fCurvePoints = curves.getPointsFromPercs(sBpCurves[s], fCtrlPercs)
        fCurvePointsSharp = fCurvePoints[:iCornerIndex] + [fCurvePoints[iCornerIndex]] * (1+iSharpenCornerPoint) + fCurvePoints[iCornerIndex+1:]
        fCurvePointsUp = curves.getPointsFromPercs(sBpUpCurves[s], fCtrlPercs)
        fCurvePointsUpSharp = fCurvePointsUp[:iCornerIndex] + [fCurvePointsUp[iCornerIndex]] * (1+iSharpenCornerPoint) + fCurvePointsUp[iCornerIndex+1:]

        sCurve = cmds.curve(p=fCurvePointsSharp, n='curve_%s_cheek' % sSide)
        sCurveUp = cmds.curve(p=fCurvePointsUpSharp, n='curve_%s_cheekUp' % sSide)
        cmds.parent(sCurve, sCurveUp, sGroup)

        aCtrlPoints = np.array(fCurvePoints, dtype='float64')
        aTangents = curves.getTangentsFromPercs(sCurve, fCtrlPercs)
        aCtrlPointsUp = np.array(fCurvePointsUp, dtype='float64')
        fCurveLength = curves.getLength(sCurve)
        fCtrlSize = fCurveLength * 0.1
        fSliderScale = fCurveLength * 0.1
        sTempLoc = cmds.spaceLocator()[0]

        sHeadRotation = nodes.getRotationMatrix2('jnt_m_headMain.worldMatrix')
        sHeadPole = nodes.createPointByMatrixNode([0,-1,0], sHeadRotation)
        sParentScale = nodes.scaleFromXform(sParentJoint)

        iMainCtrls = [0, iCornerIndex, len(fCtrlPercs)-1]
        sMainParents = ['jnt_m_jawMain', f'jnt_{sSide}_lipsEnd', 'jnt_m_headMain']
        sThreePoints = []
        ccCtrls[s] = [None] * len(fCtrlPercs)
        for c,cc in enumerate(iMainCtrls):
            cmds.setAttr('%s.t' % sTempLoc, *list(aCtrlPoints[cc]))
            xforms.orientThreePoints(sTempLoc, aCtrlPointsUp[cc]-aCtrlPoints[cc], aTangents[cc], fAimVector=[0,0,fSideMultipl], fUpVector=[0,fSideMultipl,0])
            cCtrl = ctrls8.create('cheekMain', sSide, cc, sShape='sphere', sAttrs=['t', 'r', 's'], fSize=fCtrlSize*1.5, fSliderScale=fSliderScale, sParent=_getFaceCtrlGrp(), sMatch=sTempLoc, iSlider=2, iColorIndex=1)
            cCtrl.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
            cmds.connectAttr(sCtrlVis, '%s.v' % cCtrl.sPasser)

            if c == 1:
                constraints.matrixParentConstraint(sMainParents[2], cCtrl.sPasser, mo=True)
                sMoveToAttrs = [utils.addAttr(cCtrl.sPasser, ln='moveToCorner%s' % sSuffix, k=True, min=0, max=1, dv=0.7) for sSuffix in ['Horiz', 'Vert', 'Depth']]
                sMoveOffset = cCtrl.appendOffsetGroup('movewithcorner')
                sCorner = sMainParents[1]
                fCtrlPos = cmds.xform(cCtrl.sCtrl, q=True, ws=True, t=True)

                fStraightMatrix = list(utils.fIdentityMatrix)
                fStraightMatrix[12:15] = fCtrlPos

                fCtrlInCorner = nodes.createPointByMatrixNode(fCtrlPos, '%s.worldInverseMatrix' % sCorner, bJustValues=True)
                sFullMoveCtrl = nodes.createPointByMatrixNode(fCtrlInCorner, '%s.worldMatrix' % sCorner)

                fStraightMatrixInSlider = nodes.createMultMatrixNode([fStraightMatrix, '%s.worldInverseMatrix' % cCtrl.sSlider], bJustValues=True)
                sSliderStraightened = nodes.createMultMatrixNode([fStraightMatrixInSlider, '%s.worldMatrix' % cCtrl.sSlider,
                                                                  '%s.worldInverseMatrix' % cCtrl.sExtraMove, '%s.worldMatrix' % cCtrl.sPasser])
                sSliderStraightenedInv = nodes.createInverseMatrix(sSliderStraightened)

                sFullMoveCtrlInStraight = nodes.createPointByMatrixNode(sFullMoveCtrl, sSliderStraightenedInv)

                sFullMoveCtrlStrenghted = nodes.createVectorMultiplyNode(sMoveToAttrs, sFullMoveCtrlInStraight)
                sDefaultSettingAttrsCheeks.extend(sMoveToAttrs)

                fSliderInPasser = nodes.createMultMatrixNode(['%s.worldMatrix' % cCtrl.sSlider, '%s.worldInverseMatrix' % cCtrl.sPasser], bJustValues=True)
                sSliderInPasser = nodes.createMultMatrixNode([fSliderInPasser, '%s.worldMatrix' % cCtrl.sPasser])
                sMoveCtrlWorld = nodes.createPointByMatrixNode(sFullMoveCtrlStrenghted, sSliderStraightened)
                nodes.createPointByMatrixNode(sMoveCtrlWorld, nodes.createInverseMatrix(sSliderInPasser), sTarget='%s.t' % sMoveOffset)
            else:
                constraints.matrixParentConstraint(sMainParents[c], cCtrl.sPasser, mo=True)

            cCtrl.sJumpedOut = cmds.duplicate(cCtrl.sOut, n='%sJumped' % cCtrl.sOut, po=True)[0]
            constraints.matrixParentConstraint(cCtrl.sOut, cCtrl.sJumpedOut, sJumpOverTransforms=[cCtrl.sExtraMove, cCtrl.sPasser])

            sThreePoints.append(nodes.getWorldPoint(cCtrl.sJumpedOut))
            ccCtrls[s][cc] = cCtrl


        sLines = []
        for i, sStartPoint, sEndPoint in [(0, sThreePoints[0], sThreePoints[1]),
                                          (1, sThreePoints[1], sThreePoints[2])]:
            sLoc = xforms.createLocator(f'grp_{sSide}_cheekLine_{i}', xPos=sStartPoint, sParent=sGroup)
            sAimConstraint = constraints.aimConstraintEmpty(sLoc)
            cmds.connectAttr(sEndPoint, '%s.target[0].targetTranslate' % sAimConstraint)
            cmds.connectAttr(sHeadPole, '%s.worldUpVector' % sAimConstraint)
            nodes.createDistanceNode(sStartPoint, sEndPoint, fNormalized=1.0, sTarget='%s.sx' % sLoc)
            cmds.connectAttr(sParentScale, '%s.sy' % sLoc)
            cmds.connectAttr(sParentScale, '%s.sz' % sLoc)
            sLines.append(sLoc)

        iSecondaryControls = sorted(list(set(range(len(fCtrlPercs))).difference(set(iMainCtrls))))
        for c, cc in enumerate(iSecondaryControls):
            cmds.setAttr('%s.t' % sTempLoc, *list(aCtrlPoints[cc]))
            xforms.orientThreePoints(sTempLoc, aCtrlPointsUp[cc]-aCtrlPoints[cc], aTangents[cc], fAimVector=[0,0,fSideMultipl], fUpVector=[0,fSideMultipl,0])
            cCtrl = ctrls8.create('cheek', sSide, cc, sShape='sphere', sAttrs=['t', 'r', 's'], fSize=fCtrlSize, fSliderScale=fSliderScale, sParent=_getFaceCtrlGrp(), sMatch=sTempLoc, iSlider=2, iColorIndex=1)
            cCtrl.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
            cmds.connectAttr(sCtrlVis, '%s.v' % cCtrl.sPasser)
            sLine = sLines[0 if cc < iCornerIndex else 1]
            constraints.matrixParentConstraint(sLine, cCtrl.sPasser, skipScale=['x','y','z'], mo=True)
            cmds.scaleConstraint(sParentJoint, cCtrl.sPasser)
            ccCtrls[s][cc] = cCtrl

            cCtrl.sJumpedOut = cmds.duplicate(cCtrl.sOut, n='%sJumped' % cCtrl.sOut, po=True)[0]
            constraints.matrixParentConstraint(cCtrl.sOut, cCtrl.sJumpedOut, sJumpOverTransforms=[cCtrl.sExtraMove, cCtrl.sPasser])

            sMoveToLineOffset = cCtrl.appendOffsetGroup('movetoline')
            sMoveToLineCenterAttr = utils.addAttr(cCtrl.sCtrl, ln='moveToLineCenter', min=0, max=10, dv=1.5, k=True)
            sDefaultSettingAttrsCheeks.append(sMoveToLineCenterAttr)

            sJumpedSlider = nodes.createMultMatrixNode(['%s.matrix' % cCtrl.sSlider,
                                                        '%s.worldMatrix' % cCtrl.sPasser])

            sSliderInLine = nodes.createMultMatrixNode([sJumpedSlider,
                                                        '%s.worldInverseMatrix' % sLine])
            sSliderInLinePoint = nodes.createDecomposeMatrix(sSliderInLine)

            sCurrentFactorAttr = utils.addAttr(cCtrl.sCtrl, ln='currentStretchFactor', k=False, cb=True)
            cmds.connectAttr('%s.scaleX' % sLine, sCurrentFactorAttr)
            sLineStretchDivided = nodes.createMultiplyNode('%s.scaleX' % sLine, sParentScale, sOperation='divide')
            sLocalPosition = nodes.createRangeNode(sLineStretchDivided, 1.0, sMoveToLineCenterAttr, sSliderInLinePoint, ['%sX' % sSliderInLinePoint, 0,0], bOutRangeIsVector=True)

            sMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalPosition),
                                                  '%s.worldMatrix' % sLine,
                                                   nodes.createInverseMatrix(sJumpedSlider)])
            nodes.createDecomposeMatrix(sMatrix, '%s.t' % sMoveToLineOffset)



        sInfluences = []
        for cc, cCtrl in enumerate(ccCtrls[s]):
            sInf = cmds.createNode('joint', n='inf_%s_cheek_%03d' % (sSide, cc), p=cCtrl.sJumpedOut)
            cmds.setAttr('%s.radius' % sInf, fCtrlSize*0.5)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf)
            sInfluences.append(sInf)



        cmds.skinCluster(sCurve, sInfluences, tsb=True)
        cmds.skinCluster(sCurveUp, sInfluences, tsb=True)
        cmds.delete(sTempLoc)



        # poses
        for cCtrl in ccCtrls[s]:
            sPoseOffset = cCtrl.appendOffsetGroup('poses')
            sTranslations = []
            sRotations = []
            sScales = []
            for sDriverCtrl in [f'lipsCorner_{sSide}_ctrl']:
                for sDriverA in ['out', 'up', 'down', 'outDown', 'outUp', 'in']:
                    sDriverAttr = f'{sDriverCtrl}.{sDriverA}'
                    sLoc = xforms.createLocator(f"_{cCtrl.sCtrl.replace('_ctrl', '')}__{sDriverCtrl.replace('_ctrl', '')}_{sDriverA}", sParent=cmds.listRelatives(sPoseOffset, p=True)[0])
                    utils.connectPosesLocVis(sLoc)
                    cmds.connectAttr(sDriverAttr, '%s.v' % sLoc)

                    sTranslations.append(nodes.createVectorMultiplyNode('%s.t' % sLoc, sDriverAttr, bVectorByScalar=True))
                    sRotations.append(nodes.createVectorMultiplyNode('%s.r' % sLoc, sDriverAttr, bVectorByScalar=True))
                    sScales.append(nodes.createVectorMultiplyNode(nodes.createVectorAdditionNode(['%s.s' % sLoc, [1,1,1]], sOperation='minus'), sDriverAttr, bVectorByScalar=True))
                    sDefaultSettingAttrsCheeks.append('%s.t' % sLoc)
                    sDefaultSettingAttrsCheeks.append('%s.r' % sLoc)
                    sDefaultSettingAttrsCheeks.append('%s.s' % sLoc)

            nodes.createVectorAdditionNode(sTranslations, sTarget='%s.t' % sPoseOffset)
            nodes.createVectorAdditionNode(sRotations, sTarget='%s.r' % sPoseOffset)
            nodes.createVectorAdditionNode([[1,1,1]] + sScales, sTarget='%s.s' % sPoseOffset)




        # joints
        aJointPercs = np.arange(iCheekCurveJointCount) / (iCheekCurveJointCount-1)
        fJointParams = curves.getParamsFromPercs(sCurve, aJointPercs)
        sParentRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sParentJoint)
        sParentRotationMatrixInv = nodes.createInverseMatrix(sParentRotationMatrix)


        xJointWeightings = xforms.getCtrlWeightings(aJointPercs, fCtrlPercs)
        sCtrlPoles = [nodes.createPointByMatrixNode([0,0,1], nodes.getRotationMatrix('%s.worldMatrix' % cC.sJumpedOut)) for cC in ccCtrls[s]]

        sScaleAnimPlusPoses = [nodes.createVectorAdditionNode(['%s.s' % cC.getOffsetByName('poses'), '%s.s' % cC.sCtrl]) for cC in ccCtrls[s]]
        sAimStrenghtAttrs = [utils.addAttr(cC.sPasser, ln='aim', min=0.0, max=1.0, dv=1.0, k=True) for cC in ccCtrls[s]]
        sDefaultSettingAttrsCheeks.extend(sAimStrenghtAttrs)

        for j,fParam in enumerate(fJointParams):
            sInfoNode, sPoint = curves.createPointInfoNode(sCurve, fParam)
            sJ = 'jnt_%s_cheek_%03d' % (sSide,j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, jointOrGroup(sParentJoint))
            else:
                cmds.createNode('joint', n=sJ, p=jointOrGroup(sParentJoint))
            cmds.setAttr('%s.jo' % sJ, 0,0,0)
            cmds.setAttr('%s.radius' % sJ, fCtrlSize*0.3)
            nodes.createPointByMatrixNode(sPoint, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0,1,0], up=[0,0,1], bIgnoreConstraintRotateTranslateConnection=True)
            nodes.createPointByMatrixNode('%s.tangent' % sInfoNode, sParentRotationMatrixInv, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            # sTangentPlusPos = nodes.createVectorAdditionNode(['%s.position' % sInfoNode, '%s.tangent' % sInfoNode])
            # nodes.createPointByMatrixNode(sTangentPlusPos, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            iCtrl0, iCtrl1, fBlend = xJointWeightings[j]
            sPole = nodes.createBlendNode(fBlend, sCtrlPoles[iCtrl1], sCtrlPoles[iCtrl0], bVector=True)
            nodes.createPointByMatrixNode(sPole, sParentRotationMatrixInv, sTarget='%s.worldUpVector' % sAimConstraint)
            ssJoints[s].append(sJ)
            nodes.createBlendNode(fBlend, sScaleAnimPlusPoses[iCtrl1], sScaleAnimPlusPoses[iCtrl0], bVector=True, sTarget='%s.s' % sJ)

            sAimBlend = nodes.createBlendNode(fBlend, sAimStrenghtAttrs[iCtrl1], sAimStrenghtAttrs[iCtrl0])
            sAimOutput = cmds.listConnections('%s.r' % sJ, s=True, d=False, p=True)[0]
            sAimMatrix = nodes.createComposeMatrixNode(xRotate=sAimOutput)

            sNoAimBlendMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % ccCtrls[s][iCtrl0].sJumpedOut, '%s.worldMatrix' % ccCtrls[s][iCtrl1].sJumpedOut], [1.0-fBlend, fBlend])
            sNoAimOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sJ, nodes.createInverseMatrix(sNoAimBlendMatrix, bJustValues=True)], bJustValues=True)
            sNoAimMatrix = nodes.createMultMatrixNode([sNoAimOffset, sNoAimBlendMatrix, '%s.parentInverseMatrix' % sJ])

            sAimBlendedMatrix = nodes.createBlendMatrixNode([sNoAimMatrix, sAimMatrix], [nodes.createReverseNode(sAimBlend), sAimBlend])
            nodes.createDecomposeMatrix(sAimBlendedMatrix, sTargetRot='%s.r' % sJ, bForce=True)

    createPostRefAttrFromCurrentWorld(ssJoints[0] + ssJoints[1])
    utils.data.store('sDefaultSettingAttrsCheeks', sDefaultSettingAttrsCheeks)
    deformers.resetJointReferences(ssJoints[0] + ssJoints[1])

    for sA, fV in list(dDefaultSettingValuesCheeks.items()):
        if cmds.objExists(sA):
            if isinstance(fV, (list,tuple)):
                cmds.setAttr(sA, *fV)
            else:
                cmds.setAttr(sA, fV)
        else:
            report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)





sNlfGroupName = '_grp_m_nlfBps'
kNlfFileName = 'blueprintNlf.ma'
dButtons = OrderedDict()
dButtons['Create Left Nlf Curve (Tracked Order)'] = lambda: createBpCurve('bpCurve_l_nlf', sNlfGroupName,
                                                                            fDirection=(0, 1, 0), bTrackedOrder=True)
dButtons['Create Left Nlf Curve (Tracked Order)'].dSideButtons = {'?':['The vertices here don\'t have to be neighbor vertices, as long '\
                                                            '\nas you select them in the correct order', 'nlfTrackedOrder.jpg']}
dButtons['Create Left Nlf Curve'] = lambda: createBpCurve('bpCurve_l_nlf', sNlfGroupName,
                                                            fDirection=(0, 1, 0))

# def createNlfLocator():
#     xforms.createLocator('bpLoc_l_nlfCorner', xPos=cmds.xform(q=True, ws=True, t=True), sParent=sNlfGroupName)
dButtons['Create Left Nlf Corner Loc Selected CV'] = lambda: xforms.createLocator('bpLoc_l_nlfCorner', xPos=cmds.xform(q=True, ws=True, t=True), sParent=sNlfGroupName)

dButtons['Create Left Nlf Curve'].dSideButtons = {'?':['If the vertices all neighbors, you can use that '\
                                             'button instead of the one above']}
dButtons['Create Left Nlf PushOut Curve'] = lambda: createBpUpVectorCurve('bpCurve_l_nlfUp',
                                                                            'bpCurve_l_nlf')
dButtons['Create Left Nlf PushOut Curve'].dSideButtons = {'?':['no selection needed, he\'ll create the curve himself']}

dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsNlfs', 'dDefaultSettingValuesNlfs')


dButtons['Export BPs'] = lambda: exportBps(kNlfFileName, sNlfGroupName)


@builderTools.addToBuild(iOrder=62.3, dButtons=dButtons, bDisableByDefault=True)
def nlfSetup(sParentJoint='jnt_m_headMain', fBotCtrlPercs=[0.5], fTopCtrlPercs=[0.33, 0.66], iNlfCurveJointCount=8, dDefaultSettingValuesNlfs={}, iSharpenCornerPoint=1):
    sDefaultSettingAttrsNlfs = []

    sGroup = cmds.createNode('transform', n='grp_nlfSetup', p='modules')
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'nlfCtrlVis', False)
    sBpCurves = ['bpCurve_l_nlf', 'bpCurve_r_nlf']
    sBpUpCurves = ['bpCurve_l_nlfUp', 'bpCurve_r_nlfUp']

    fCornerPerc = curves.getPercsFromTransforms(sBpCurves[0], ['bpLoc_l_nlfCorner'])[0]

    fCtrlPercs = [0.0] + list(np.interp(fBotCtrlPercs, [0.0, 1.0], [0.0, fCornerPerc])) + [fCornerPerc] + list(np.interp(fTopCtrlPercs, [0.0, 1.0], [fCornerPerc, 1.0])) + [1.0]
    iCornerIndex = len(fBotCtrlPercs) + 1
    ccCtrls = [[], []]
    ssJoints = [], []
    # sGlobalScale = nodes.getScaleFromXform(sParentJoint)
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        curves.mirrorIfNotExists(sBpCurves[s], sErrorAddition='You need to create the curves using the button "Create Left NLF Curve"')
        curves.mirrorIfNotExists(sBpUpCurves[s], sErrorAddition='Maybe you forgot to click the button "Create Left NLF PushOut Curve"')

        fCurvePoints = curves.getPointsFromPercs(sBpCurves[s], fCtrlPercs)
        fCurvePointsSharp = fCurvePoints[:iCornerIndex] + [fCurvePoints[iCornerIndex]] * (1+iSharpenCornerPoint) + fCurvePoints[iCornerIndex+1:]
        fCurvePointsUp = curves.getPointsFromPercs(sBpUpCurves[s], fCtrlPercs)
        fCurvePointsUpSharp = fCurvePointsUp[:iCornerIndex] + [fCurvePointsUp[iCornerIndex]] * (1+iSharpenCornerPoint) + fCurvePointsUp[iCornerIndex+1:]

        sCurve = cmds.curve(p=fCurvePointsSharp, n='curve_%s_nlf' % sSide)
        sCurveUp = cmds.curve(p=fCurvePointsUpSharp, n='curve_%s_nlfUp' % sSide)
        cmds.parent(sCurve, sCurveUp, sGroup)

        aCtrlPoints = np.array(fCurvePoints, dtype='float64')
        aTangents = curves.getTangentsFromPercs(sCurve, fCtrlPercs)
        aCtrlPointsUp = np.array(fCurvePointsUp, dtype='float64')
        fCurveLength = curves.getLength(sCurve)
        fCtrlSize = fCurveLength * 0.1
        fSliderScale = fCurveLength * 0.1
        sTempLoc = cmds.spaceLocator()[0]

        sHeadRotation = nodes.getRotationMatrix2('jnt_m_headMain.worldMatrix')
        sHeadPole = nodes.createPointByMatrixNode([0,-1,0], sHeadRotation)
        sParentScale = nodes.scaleFromXform(sParentJoint)

        iMainCtrls = [0, iCornerIndex, len(fCtrlPercs)-1]
        sMainParents = ['jnt_m_jawMain', f'jnt_{sSide}_lipsEnd', 'jnt_m_headMain']
        sThreePoints = []
        ccCtrls[s] = [None] * len(fCtrlPercs)
        for c,cc in enumerate(iMainCtrls):
            cmds.setAttr('%s.t' % sTempLoc, *list(aCtrlPoints[cc]))
            xforms.orientThreePoints(sTempLoc, aCtrlPointsUp[cc]-aCtrlPoints[cc], aTangents[cc], fAimVector=[0,0,fSideMultipl], fUpVector=[0,fSideMultipl,0])
            cCtrl = ctrls8.create('nlfMain', sSide, cc, sShape='sphere', sAttrs=['t', 'r', 's'], fSize=fCtrlSize*1.5, fSliderScale=fSliderScale, sParent=_getFaceCtrlGrp(), sMatch=sTempLoc, iSlider=2, iColorIndex=1)
            cmds.connectAttr(sCtrlVis, '%s.v' % cCtrl.sPasser)

            cCtrl.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
            constraints.matrixParentConstraint(sMainParents[c], cCtrl.sPasser, mo=True)

            cCtrl.sJumpedOut = cmds.duplicate(cCtrl.sOut, n='%sJumped' % cCtrl.sOut, po=True)[0]
            constraints.matrixParentConstraint(cCtrl.sOut, cCtrl.sJumpedOut, sJumpOverTransforms=[cCtrl.sExtraMove, cCtrl.sPasser])

            sThreePoints.append(nodes.getWorldPoint(cCtrl.sJumpedOut))
            ccCtrls[s][cc] = cCtrl


        sLines = []
        for i, sStartPoint, sEndPoint in [(0, sThreePoints[0], sThreePoints[1]),
                                          (1, sThreePoints[1], sThreePoints[2])]:
            sLoc = xforms.createLocator(f'grp_{sSide}_nlfLine_{i}', xPos=sStartPoint, sParent=sGroup)
            sAimConstraint = constraints.aimConstraintEmpty(sLoc)
            cmds.connectAttr(sEndPoint, '%s.target[0].targetTranslate' % sAimConstraint)
            cmds.connectAttr(sHeadPole, '%s.worldUpVector' % sAimConstraint)
            nodes.createDistanceNode(sStartPoint, sEndPoint, fNormalized=1.0, sTarget='%s.sx' % sLoc)
            cmds.connectAttr(sParentScale, '%s.sy' % sLoc)
            cmds.connectAttr(sParentScale, '%s.sz' % sLoc)

            sLines.append(sLoc)

        iSecondaryControls = sorted(list(set(range(len(fCtrlPercs))).difference(set(iMainCtrls))))
        for c, cc in enumerate(iSecondaryControls):
            cmds.setAttr('%s.t' % sTempLoc, *list(aCtrlPoints[cc]))
            xforms.orientThreePoints(sTempLoc, aCtrlPointsUp[cc]-aCtrlPoints[cc], aTangents[cc], fAimVector=[0,0,fSideMultipl], fUpVector=[0,fSideMultipl,0])
            cCtrl = ctrls8.create('nlf', sSide, cc, sShape='sphere', sAttrs=['t', 'r', 's'], fSize=fCtrlSize, fSliderScale=fSliderScale, sParent=_getFaceCtrlGrp(), sMatch=sTempLoc, iSlider=2, iColorIndex=1)
            cCtrl.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
            cmds.connectAttr(sCtrlVis, '%s.v' % cCtrl.sPasser)
            sLine = sLines[0 if cc < iCornerIndex else 1]
            constraints.matrixParentConstraint(sLine, cCtrl.sPasser, skipScale=['x','y','z'], mo=True)
            cmds.scaleConstraint(sParentJoint, cCtrl.sPasser)
            ccCtrls[s][cc] = cCtrl

            cCtrl.sJumpedOut = cmds.duplicate(cCtrl.sOut, n='%sJumped' % cCtrl.sOut, po=True)[0]
            constraints.matrixParentConstraint(cCtrl.sOut, cCtrl.sJumpedOut, sJumpOverTransforms=[cCtrl.sExtraMove, cCtrl.sPasser])

            sMoveToLineOffset = cCtrl.appendOffsetGroup('movetoline')
            sMoveToLineCenterAttr = utils.addAttr(cCtrl.sCtrl, ln='moveToLineCenter', min=0, max=10, dv=1.5, k=True)
            sDefaultSettingAttrsNlfs.append(sMoveToLineCenterAttr)

            sJumpedSlider = nodes.createMultMatrixNode(['%s.matrix' % cCtrl.sSlider,
                                                        '%s.worldMatrix' % cCtrl.sPasser])

            sSliderInLine = nodes.createMultMatrixNode([sJumpedSlider,
                                                        '%s.worldInverseMatrix' % sLine])
            sSliderInLinePoint = nodes.createDecomposeMatrix(sSliderInLine)

            sCurrentFactorAttr = utils.addAttr(cCtrl.sCtrl, ln='currentStretchFactor', k=False, cb=True)
            cmds.connectAttr('%s.scaleX' % sLine, sCurrentFactorAttr)
            sLineStretchDivided = nodes.createMultiplyNode('%s.scaleX' % sLine, sParentScale, sOperation='divide')
            sLocalPosition = nodes.createRangeNode(sLineStretchDivided, 1.0, sMoveToLineCenterAttr, sSliderInLinePoint, ['%sX' % sSliderInLinePoint, 0,0], bOutRangeIsVector=True)

            sMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalPosition),
                                                  '%s.worldMatrix' % sLine,
                                                   nodes.createInverseMatrix(sJumpedSlider)])
            nodes.createDecomposeMatrix(sMatrix, '%s.t' % sMoveToLineOffset)
            


        sInfluences = []
        for cc, cCtrl in enumerate(ccCtrls[s]):
            sInf = cmds.createNode('joint', n='inf_%s_nlf_%03d' % (sSide, cc), p=cCtrl.sJumpedOut)
            cmds.setAttr('%s.radius' % sInf, fCtrlSize*0.5)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf)
            sInfluences.append(sInf)



        cmds.skinCluster(sCurve, sInfluences, tsb=True)
        cmds.skinCluster(sCurveUp, sInfluences, tsb=True)
        cmds.delete(sTempLoc)



        # poses
        for cCtrl in ccCtrls[s]:
            sPoseOffset = cCtrl.appendOffsetGroup('poses')
            sTranslations = []
            sRotations = []
            sScales = []
            for sDriverCtrl in [f'lipsCorner_{sSide}_ctrl']:
                for sDriverA in ['out', 'up', 'down', 'outDown', 'outUp', 'in']:
                    sDriverAttr = f'{sDriverCtrl}.{sDriverA}'
                    sLoc = xforms.createLocator(f"_{cCtrl.sCtrl.replace('_ctrl', '')}__{sDriverCtrl.replace('_ctrl', '')}_{sDriverA}", sParent=cmds.listRelatives(sPoseOffset, p=True)[0])
                    utils.connectPosesLocVis(sLoc)
                    cmds.connectAttr(sDriverAttr, '%s.v' % sLoc)

                    sTranslations.append(nodes.createVectorMultiplyNode('%s.t' % sLoc, sDriverAttr, bVectorByScalar=True))
                    sRotations.append(nodes.createVectorMultiplyNode('%s.r' % sLoc, sDriverAttr, bVectorByScalar=True))
                    sScales.append(nodes.createVectorMultiplyNode(nodes.createVectorAdditionNode(['%s.s' % sLoc, [1,1,1]], sOperation='minus'), sDriverAttr, bVectorByScalar=True))
                    sDefaultSettingAttrsNlfs.append('%s.t' % sLoc)
                    sDefaultSettingAttrsNlfs.append('%s.r' % sLoc)
                    sDefaultSettingAttrsNlfs.append('%s.s' % sLoc)

            nodes.createVectorAdditionNode(sTranslations, sTarget='%s.t' % sPoseOffset)
            nodes.createVectorAdditionNode(sRotations, sTarget='%s.r' % sPoseOffset)
            nodes.createVectorAdditionNode([[1,1,1]] + sScales, sTarget='%s.s' % sPoseOffset)




        # joints
        aJointPercs = np.arange(iNlfCurveJointCount) / (iNlfCurveJointCount-1)
        fJointParams = curves.getParamsFromPercs(sCurve, aJointPercs)
        sParentRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sParentJoint)
        sParentRotationMatrixInv = nodes.createInverseMatrix(sParentRotationMatrix)


        xJointWeightings = xforms.getCtrlWeightings(aJointPercs, fCtrlPercs)
        sCtrlPoles = [nodes.createPointByMatrixNode([0,0,1], nodes.getRotationMatrix('%s.worldMatrix' % cC.sJumpedOut)) for cC in ccCtrls[s]]

        sScaleAnimPlusPoses = [nodes.createVectorAdditionNode(['%s.s' % cC.getOffsetByName('poses'), '%s.s' % cC.sCtrl]) for cC in ccCtrls[s]]
        sAimStrenghtAttrs = [utils.addAttr(cC.sPasser, ln='aim', min=0.0, max=1.0, dv=1.0, k=True) for cC in ccCtrls[s]]
        sDefaultSettingAttrsNlfs.extend(sAimStrenghtAttrs)

        for j,fParam in enumerate(fJointParams):
            sInfoNode, sPoint = curves.createPointInfoNode(sCurve, fParam)
            sJ = 'jnt_%s_nlf_%03d' % (sSide,j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, jointOrGroup(sParentJoint))
            else:
                cmds.createNode('joint', n=sJ, p=jointOrGroup(sParentJoint))
            cmds.setAttr('%s.jo' % sJ, 0,0,0)
            cmds.setAttr('%s.radius' % sJ, fCtrlSize*0.3)
            nodes.createPointByMatrixNode(sPoint, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            # sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0,1,0], up=[0,0,1])
            # sTangentPlusPos = nodes.createVectorAdditionNode(['%s.position' % sInfoNode, '%s.tangent' % sInfoNode])
            # nodes.createPointByMatrixNode(sTangentPlusPos, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

            sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0,1,0], up=[0,0,1], bIgnoreConstraintRotateTranslateConnection=True)
            nodes.createPointByMatrixNode('%s.tangent' % sInfoNode, sParentRotationMatrixInv, sTarget='%s.target[0].targetTranslate' % sAimConstraint)



            iCtrl0, iCtrl1, fBlend = xJointWeightings[j]
            sPole = nodes.createBlendNode(fBlend, sCtrlPoles[iCtrl1], sCtrlPoles[iCtrl0], bVector=True)
            nodes.createPointByMatrixNode(sPole, sParentRotationMatrixInv, sTarget='%s.worldUpVector' % sAimConstraint)
            ssJoints[s].append(sJ)
            nodes.createBlendNode(fBlend, sScaleAnimPlusPoses[iCtrl1], sScaleAnimPlusPoses[iCtrl0], bVector=True, sTarget='%s.s' % sJ)

            sAimBlend = nodes.createBlendNode(fBlend, sAimStrenghtAttrs[iCtrl1], sAimStrenghtAttrs[iCtrl0])
            sAimOutput = cmds.listConnections('%s.r' % sJ, s=True, d=False, p=True)[0]
            sAimMatrix = nodes.createComposeMatrixNode(xRotate=sAimOutput)

            sNoAimBlendMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % ccCtrls[s][iCtrl0].sJumpedOut, '%s.worldMatrix' % ccCtrls[s][iCtrl1].sJumpedOut], [1.0-fBlend, fBlend])
            sNoAimOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sJ, nodes.createInverseMatrix(sNoAimBlendMatrix, bJustValues=True)], bJustValues=True)
            sNoAimMatrix = nodes.createMultMatrixNode([sNoAimOffset, sNoAimBlendMatrix, '%s.parentInverseMatrix' % sJ])

            sAimBlendedMatrix = nodes.createBlendMatrixNode([sNoAimMatrix, sAimMatrix], [nodes.createReverseNode(sAimBlend), sAimBlend])
            nodes.createDecomposeMatrix(sAimBlendedMatrix, sTargetRot='%s.r' % sJ, bForce=True)

    createPostRefAttrFromCurrentWorld(ssJoints[0] + ssJoints[1])
    utils.data.store('sDefaultSettingAttrsNlfs', sDefaultSettingAttrsNlfs)
    deformers.resetJointReferences(ssJoints[0] + ssJoints[1])

    for sA, fV in list(dDefaultSettingValuesNlfs.items()):
        if cmds.objExists(sA):
            if isinstance(fV, (list,tuple)):
                cmds.setAttr(sA, *fV)
            else:
                cmds.setAttr(sA, fV)
        else:
            report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)





#EXCLUDE END CHEEKSETUP

def poseToCorectives(ddCorrectives):
    qMenu = QtWidgets.QMenu()

    for sTarget, dData in ddCorrectives.items():
        bMirror = dData['bMirror']
        dPoses = dData['dPoses']

        def _goTo(dPoses=dPoses, bMirror=bMirror):
            for sAttr, fValue in dPoses.items():
                print ('setting sAttr.. ', sAttr, fValue)
                if isinstance(fValue, (list,tuple)):
                    cmds.setAttr(sAttr, *fValue)
                else:
                    cmds.setAttr(sAttr, fValue)

                if bMirror:
                    sMirrorAttr = utils.getMirrorName(sAttr)
                    print ('checking.. sMirrorAttr: ', sMirrorAttr)
                    if sMirrorAttr != sAttr and cmds.objExists(sMirrorAttr):
                        print ('setting sMirrorAttr... ', sMirrorAttr, fValue)
                        if isinstance(fValue, (list, tuple)):
                            cmds.setAttr(sMirrorAttr, *fValue)
                        else:
                            cmds.setAttr(sMirrorAttr, fValue)

        qMenu.addAction(sTarget, _goTo)

    qCursor = QtGui.QCursor()
    qMenu.exec_(qCursor.pos())


dButtons = OrderedDict()
dButtons['select MAP meshes'] = lambda: cmds.select(cmds.ls('*__MAPS', et='transform'))
dButtons['Pose To Correctives'] = poseToCorectives

dButtons['- Export *Slider* BPs -'] = ctrls8.exportSliderBps
@builderTools.addToBuild(iOrder=63.6, dButtons=dButtons)
def blendShapesAndSliders(dSplitRadienFactors={'fOuterBrow':1.0, 'fMouthPucker':1.0, 'fMouthCorner':0.75, 'fUpperLips':0.5, 'fLowerLips':0.5, 'fBlink':1.0, 'fNostril':0.25}, iUpperLowerSmoothIterations=3,
                            sMirrorJointAxes=[], dSkip={'bSkipCornerShapes':False, 'bSkipMouthDirectionShapes':False, 'bSkipLipShapes':False, 'bSkipJawShapes':False, 'bSkipLidCloseShapes':False},
                            ddTargetsAsAttributes=[{'sCtrlAttr':'lipsCorner_l_ctrl.NEWATTR', 'sTarget':'', 'fSplitRadius':0.5}],
                            ddExtraTargetSliders=[{'sName':'newName', 'dTargets':{'sTargetUp':'', 'sTargetDown':'', 'sTargetIn':'', 'sTargetOut':''}, 'bMirror':True}],
                            ddCorrectives={'TARGETNAME': {'dPoses': {'lipsCorner_l_ctrl.tx': 1.0}, 'fSplitRadius': 0.5, 'bMirror':True, 'sDrivers':[]}},
                            sIgnoreTargets=[]):


    # _importMapMeshes()
    bMouthSplines = utils.data.get('bMouthSplines', xDefault=False)
    utils.addStringAttr(utils.getMasterName(), 'ddFaceCorrectives', str(ddCorrectives), bLock=True)

    dFunctionDatas = utils.getCurrentFunctionDatas()
    dBrowSplinesArgs = dFunctionDatas.get('browSplines', [{}])[0].get('dFileArgs', {})
    dMouthPoseCtrlValues = dFunctionDatas.get('BASEMouthCtrls', [{}])[0].get('dFileArgs', {}).get('dPoseCtrlValues', {})
    # TODO: should we get rid of dAllSculptPoseDriverValues and just check the Build file?? Just to be consistent with how the shape editor does it
    # sAllSculptPosesAttr = '%s.dAllSculptPoseDriverValues' % utils.getMasterName()
    # if cmds.objExists(sAllSculptPosesAttr):
    #     dAllSculptPoseDriverValues = eval(cmds.getAttr(sAllSculptPosesAttr))
    # else:
    #     dAllSculptPoseDriverValues = {}


    clearWeightsCache()

    fUpperLipsSplitRadiusFactor = dSplitRadienFactors['fUpperLips']
    fLowerLipsSplitRadiusFactor = dSplitRadienFactors['fUpperLips']
    fOuterBrowSplitRadiusFactor = dSplitRadienFactors['fOuterBrow']
    fMouthPuckerSplitRadiusFactor = dSplitRadienFactors['fMouthPucker']
    fMouthCornerSplitRadiusFactor = dSplitRadienFactors['fMouthCorner']
    fBlinkSplitRadiusFactor = dSplitRadienFactors['fBlink']
    fNostrilSplitRadiusFactor = dSplitRadienFactors['fNostril']


    # sSuffixes = utils.data.get('sImportedHeadSuffixes', xDefault=['']) #, xDefault=[])
    utils.data.store('sMirrorJointAxes', sMirrorJointAxes) #, xDefault=[])
    bReturn = None
    sSuffix = ''
    xMirrorAxis = None

    report.report.resetProgress(12)
    if cmds.objExists('jnt_l_eye%sMain' % sSuffix):
        fBlinkSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.1
        fNoseSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.2
        fBrowSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.5
    else:
        fBlinkSplitRadius, fNoseSplitRadius, fBrowSplitRadius = 1.0, 1.0, 1.0

    report.report.addLogText('splitting blueprints... ', bIncrementProgress=True)

    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sTargets = set(utils.data.get('sBakedBlendshapeTargets%s' % sSuffix, xDefault=[])) - set(sIgnoreTargets)


    sSecondaryModels = []
    for sT in sTargets:
        if '__' in sT:
            sSecondaryModels.append(sT.split('__')[0])
    sSecondaryModels = list(set(sSecondaryModels) - set(sTargets)) # without minus targets he would catch inbetweens as secondaryModels
    sSecondaryModels = [sM for sM in sSecondaryModels if cmds.objExists(sM)]

    sSecondaryModels += utils.data.get('sExtraSecondaryModels%s' % sSuffix, xDefault=[])

    utils.data.store('sAllSecondaryModels%s' % sSuffix, sSecondaryModels)

    sParentJoint = 'jnt_m_headMain'
    sJawJoint = 'jnt_m_jawMain'



    fMouthCurveEndsDistance = utils.data.get('fMouthCurveEndsDistance%s' % sSuffix, xDefault=1.0)
    fMouthSplitRadius = fMouthCurveEndsDistance * 0.5
    # fMouthSliderScale = fMouthCurveEndsDistance * 0.25

    bLipCurves = utils.data.get('bLipCurves%s' % sSuffix, xDefault=False)

    if bLipCurves:
        cCorners = [ctrls8.ctrlFromName('lipsCorner_l_ctrl', bReturnNoneIfNotExists=True), ctrls8.ctrlFromName('lipsCorner_r_ctrl', bReturnNoneIfNotExists=True)]

        if cCorners[0]:
            ddSquashStretchSettings = utils.data.get('ddSquashStretchSettings')
            if not utils.isNone(ddSquashStretchSettings):
                connectTargets(sModel, ddSquashStretchSettings['sShrinkTarget'],
                                           dPoses={'%s.tx' % cCorners[0].sCtrl: ddSquashStretchSettings['fShrinkCornerValue']},
                                           # dDrivers={ddSquashStretchSettings['sDriverLeft']:None},
                                           fSplitRadius=fMouthSplitRadius,
                                           sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bMirror=True)

                connectTargets(sModel, ddSquashStretchSettings['sExpandTarget'],
                                           dPoses={'%s.tx' % cCorners[0].sCtrl: ddSquashStretchSettings['fExpandCornerValue']},
                                           # dDrivers={ddSquashStretchSettings['sDriverLeft']:None},
                                           fSplitRadius=fMouthSplitRadius,
                                           sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bMirror=True)
        # ddSquashStretchSettings = {'bScaleJoints': True, 'fShrinkCornerValue': -1, 'fExpandCornerValue': 1.0,
        #                            'sShrinkTarget': 'mouthSquash', 'sExpandTarget': 'mouthStretch'},
        else:
            cCorners = None



        report.report.addLogText('upper/lower lips... ', bIncrementProgress=True)
        if not dSkip.get('bSkipLipShapes', False):
            sLowerDown = 'lowerDown%s' % sSuffix
            sLowerUp = 'lowerUp%s' % sSuffix
            sUpperDown = 'upperDown%s' % sSuffix
            sUpperUp = 'upperUp%s' % sSuffix
            cBot = ctrls8.ctrlFromName('mouthBot_ctrl')
            cTop = ctrls8.ctrlFromName('mouthTop_ctrl')
            cMouth = ctrls8.ctrlFromName('mouth_ctrl')

            if sLowerDown in sTargets or sLowerUp in sTargets:
                fBotVertRange = [-1.0 if sLowerDown in sTargets else 0.0, 1.0 if sLowerUp in sTargets else 0.0]
                connectTargets(sModel, sLowerUp, dPoses={'%s.ty' % cBot.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                connectTargets(sModel, sLowerDown, dPoses={'%s.ty' % cBot.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                ctrls8.setSliderRange(cBot, fRangeY=fBotVertRange, bAdjustBorders=True)

                dLowerSplitAlongCurve = utils.data.get('dLipSplitAlongCurve%s' % sSuffix)

                if not utils.isNone(dLowerSplitAlongCurve):
                    dLowerSplitAlongCurve['iSmoothIterations'] = iUpperLowerSmoothIterations
                    connectTargets(sModel, sLowerDown, dPoses={}, dSplitAlongCurve=dLowerSplitAlongCurve, bMirror=False,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    dLowerSplitAlongCurve['ffValues'] = [[1.0] * len(dLowerSplitAlongCurve['ffValues'][0])]
                    connectTargets(sModel, sLowerUp, dPoses={}, dSplitAlongCurve=dLowerSplitAlongCurve, bMirror=False,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                else: # simple left/right
                    sLipBotCtrls = utils.data.get('sLipBotCtrls')
                    connectTargets(sModel, sLowerDown, dPoses={'%s.ty' % sLipBotCtrls[0]: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    connectTargets(sModel, sLowerUp, dPoses={'%s.ty' % sLipBotCtrls[0]: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



            if sUpperUp in sTargets or sUpperDown in sTargets:
                fTopVertRange = [-1.0 if sUpperDown in sTargets else 0.0, 1.0 if sUpperUp in sTargets else 0.0]

                connectTargets(sModel, sUpperUp, dPoses={'%s.ty' % cTop.sCtrl: 1}, fSplitRadius=fMouthSplitRadius * fUpperLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                connectTargets(sModel, sUpperDown, dPoses={'%s.ty' % cTop.sCtrl: -1}, fSplitRadius=fMouthSplitRadius * fUpperLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                ctrls8.setSliderRange(cTop, fRangeY=fTopVertRange, bAdjustBorders=True)

                dUpperSplitAlongCurve = utils.data.get('dUpperSplitAlongCurve%s' % sSuffix)
                if not utils.isNone(dUpperSplitAlongCurve):
                    dUpperSplitAlongCurve['iSmoothIterations'] = iUpperLowerSmoothIterations
                    connectTargets(sModel, sUpperUp, dPoses={}, dSplitAlongCurve=dUpperSplitAlongCurve, bMirror=False, bControlRigCommands=True,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis)
                    dUpperSplitAlongCurve['ffValues'] = [[-1.0] * len(dUpperSplitAlongCurve['ffValues'][0])]
                    connectTargets(sModel, sUpperDown, dPoses={}, dSplitAlongCurve=dUpperSplitAlongCurve, bMirror=False, bControlRigCommands=True,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis)
                else: # simple left/right. MIGHT NEVER GET INTO THIS ANYMORE ?!
                    sLipTopCtrls = utils.data.get('sLipTopCtrls')

                    connectTargets(sModel, sUpperUp, dPoses={'%s.ty' % sLipTopCtrls[0]: 1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    connectTargets(sModel, sUpperDown, dPoses={'%s.ty' % sLipTopCtrls[0]: -1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        if not utils.isNone(cCorners):
            for sTarget in ['mouthRound']:
                sTargetSuffix = '%s%s' % (sTarget, sSuffix)
                if cmds.objExists(sTargetSuffix):
                    sAttrs = [utils.addAttr(cCorners[s].sCtrl, ln=sTarget, minValue=0.0, maxValue=1.0, k=True) for s in [0, 1]]
                    connectTargets(sModel, sTargetSuffix, dPoses={sAttrs[0]:1.0}, fSplitRadius=fMouthSplitRadius * fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels)

    report.report.addLogText('brows... ', bIncrementProgress=True)

    sBrowIn = 'browIn%s' % sSuffix
    sBrowOut = 'browOut%s' % sSuffix
    sInnerBrowDown = 'innerBrowDown%s' % sSuffix
    sInnerBrowUp = 'innerBrowUp%s' % sSuffix

    sInnerBrowShapes = [sInnerBrowUp, sInnerBrowDown, sBrowIn, sBrowOut]
    if sTargets.intersection(set(sInnerBrowShapes)):
        fRangeX = [-1,1]
        fRangeY = [-1,1]

        if not cmds.objExists(sBrowIn):
            fRangeX[0] = 0
        if not cmds.objExists(sBrowOut):
            fRangeX[1] = 0
        if not cmds.objExists(sInnerBrowDown):
            fRangeY[0] = 0
        if not cmds.objExists(sInnerBrowUp):
            fRangeY[1] = 0

        cInnerBrows = ctrls8.createSliderCtrl('innerEyebrow%s' % sSuffix, 'l', fRangeX=fRangeX, fRangeY=fRangeY, sAttach=sModel,
                                                    sAlignOnModel=[sModel]+sInnerBrowShapes, xMirrorAxis=xMirrorAxis)
        connectTargets(sModel, 'innerBrowUp%s' % sSuffix, dPoses={'%s.ty' % cInnerBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        connectTargets(sModel, 'innerBrowDown%s' % sSuffix, dPoses={'%s.ty' % cInnerBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,1], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        connectTargets(sModel, 'browIn%s' % sSuffix, dPoses={'%s.tx' % cInnerBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        connectTargets(sModel, 'browOut%s' % sSuffix, dPoses={'%s.tx' % cInnerBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sOuterBrowUp = 'outerBrowUp%s' % sSuffix
    sOuterBrowDown = 'outerBrowDown%s' % sSuffix
    if sOuterBrowUp in sTargets or sOuterBrowDown in sTargets:
        fRangeY = [-1,1]
        if not cmds.objExists(sOuterBrowDown):
            fRangeY[0] = 0
        if not cmds.objExists(sOuterBrowUp):
            fRangeY[1] = 0

        cOuterBrows = ctrls8.createSliderCtrl('outerEyebrow%s' % sSuffix, 'l', fRangeY=fRangeY, sAttach=sModel,
                                                    sAlignOnModel=[sModel, 'outerBrowUp', 'outerBrowDown'], xMirrorAxis=xMirrorAxis)
        connectTargets(sModel, sOuterBrowUp, dPoses={'%s.ty' % cOuterBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*fOuterBrowSplitRadiusFactor,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        connectTargets(sModel, sOuterBrowDown, dPoses={'%s.ty' % cOuterBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*fOuterBrowSplitRadiusFactor,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    # inner brow spline ctrls
    for sLetter in 'ABC':
        for sDir in ['Up', 'Down']:
            sTarget = f'browSplines{sDir}{sLetter}'
            if cmds.objExists(sTarget):
                sBrowCtrlPasser = ctrls8.ctrlFromName(f'browSplines{sLetter}_l_ctrl').sPasser
                sDriver = f'{sBrowCtrlPasser}.totalTranslateY'
                if not cmds.objExists(sDriver):
                    raise Exception('driver attribute doesn\'t exist ("%s")' % sDriver)
                connectTargets(sModel, sTarget, dPoses= {f'{sBrowCtrlPasser}.singleMain{sDir}':1.0},
                               dDrivers={sDriver:None}, fSplitRadius=fBrowSplitRadius * 0.5, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bControlRigCommands=True)

    if cmds.objExists('browSplinesInA'):
        cBrowCtrl = ctrls8.ctrlFromName('browSplinesA_l_ctrl')
        sDriver = '%s.totalTranslateX' % (cBrowCtrl.sPasser)
        if not cmds.objExists(sDriver):
            raise Exception('driver attribute doesn\'t exist ("%s")' % sDriver)
        connectTargets(sModel, 'browSplinesInA', dPoses= {'%s.tx' % cBrowCtrl.sCtrl: dBrowSplinesArgs.get('fPoseInA', -0.5)},
                       dDrivers={sDriver:None}, fSplitRadius=fBrowSplitRadius * 0.5, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bControlRigCommands=True)

    if cmds.objExists('browSplinesInWrinklesA'):
        sWrinkleAttrs = [utils.addAttr('browSplinesA_l_ctrl', ln='wrinkle', min=0, max=1, dv=1, k=True),
                         utils.addAttr('browSplinesA_r_ctrl', ln='wrinkle', min=0, max=1, dv=1, k=True) ]
        cBrowCtrl = ctrls8.ctrlFromName('browSplinesA_l_ctrl')
        sDriver = '%s.totalTranslateX' % (cBrowCtrl.sPasser)
        if not cmds.objExists(sDriver):
            raise Exception('driver attribute doesn\'t exist ("%s")' % sDriver)
        connectTargets(sModel, 'browSplinesInWrinklesA', dPoses= {'%s.tx' % cBrowCtrl.sCtrl: dBrowSplinesArgs.get('fPoseInA', -0.5)},
                       dDrivers={sDriver:None, sWrinkleAttrs[0]:[0.0, 1.0]}, fSplitRadius=fBrowSplitRadius * 0.1, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2)



    for sTarget, iDirection in [('browSplinesSplitJointsDown', utils.browSplinesSplitOptions.jointsDown),
                                ('browSplinesSplitJointsUp', utils.browSplinesSplitOptions.jointsUp),
                                ('browSplinesSplitCtrlsDown', utils.browSplinesSplitOptions.ctrlsDown),
                                ('browSplinesSplitCtrlsUp', utils.browSplinesSplitOptions.ctrlsUp)]:
        if cmds.objExists(sTarget):
            connectTargets(sModel, sTarget, iBrowSplinesSplit=iDirection, fSplitRadius=fBrowSplitRadius * 0.5, sSecondaryModels=sSecondaryModels,
                                          fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bControlRigCommands=True)

    report.report.addLogText('cheeks... ', bIncrementProgress=True)

    sCheekRaiser = 'cheekRaiser%s' % sSuffix
    sCheekUp = 'cheekUp%s' % sSuffix
    if not cmds.objExists(sCheekRaiser) and cmds.objExists(sCheekUp):
        sCheekRaiser = sCheekUp
    sCheekLower = 'cheekLower%s' % sSuffix

    if sCheekRaiser in sTargets or sCheekLower in sTargets:
        fRangeY = [-1, 1]
        if not cmds.objExists(sCheekLower):
            fRangeY[0] = 0
        if not cmds.objExists(sCheekRaiser):
            fRangeY[1] = 0

        cCheekRaiser = ctrls8.createSliderCtrl('cheekRaiser%s' % sSuffix, 'l', fRangeY=fRangeY, sAttach=sModel, sAlignOnModel=[sModel, 'cheekRaiser', 'cheekLower'],
                                                     xMirrorAxis=xMirrorAxis)
        connectTargets(sModel, sCheekRaiser, dPoses={'%s.ty' % cCheekRaiser[0].sCtrl: 1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        connectTargets(sModel, sCheekLower, dPoses={'%s.ty' % cCheekRaiser[0].sCtrl: -1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sSquint = 'squint%s' % sSuffix
    if sSquint in sTargets:
        cSquints = ctrls8.createSliderCtrl(sSquint, 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sSquint])
        connectTargets(sModel, sSquint, dPoses={'%s.ty' % cSquints[0].sCtrl:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)



    sCheekOut = 'cheekOut%s' % sSuffix
    if not cmds.objExists(sCheekOut):
        sCheekOut = 'puff%s' % sSuffix
    sCheekIn = 'cheekIn%s' % sSuffix

    if sCheekOut in sTargets or sCheekIn in sTargets:
        fPuffRange = [-1,1]
        if sCheekOut not in sTargets:
            fPuffRange[1] = 0.0
        if sCheekIn not in sTargets:
            fPuffRange[0] = 0.0

        cPuffs = ctrls8.createSliderCtrl('puff%s' % sSuffix, 'l', fRangeY=fPuffRange, sShape='doubleArrowSquareY', sAttach=sModel,
                                               sAlignOnModel=[sModel, sCheekOut, sCheekIn], xMirrorAxis=xMirrorAxis)
        if sCheekOut in sTargets:
            connectTargets(sModel, sCheekOut, dPoses={'%s.ty' % cPuffs[0].sCtrl:1.0}, fSplitRadius=fMouthSplitRadius,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        if sCheekIn in sTargets:
            connectTargets(sModel, sCheekIn, dPoses={'%s.ty' % cPuffs[0].sCtrl:-1.0}, fSplitRadius=fMouthSplitRadius,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    report.report.addLogText('nose... ', bIncrementProgress=True)


    sNoseWrinkler = 'noseWrinkler%s' % sSuffix
    sNoseDown = 'noseDown%s' % sSuffix
    if sNoseWrinkler in sTargets or sNoseDown in sTargets:
        fRange = [0,0]
        if sNoseWrinkler in sTargets:
            fRange[1] = 1.0
        if sNoseDown in sTargets:
            fRange[0] = -1.0

        cNoseWrinklers = ctrls8.createSliderCtrl('noseWrinkler%s' % sSuffix, 'l', fRangeY=fRange,
                                                       sShape='doubleArrowSquareY', sAttach=sModel, sAlignOnModel=[sModel, sNoseWrinkler], xMirrorAxis=xMirrorAxis)
        connectTargets(sModel, sNoseWrinkler, dPoses={'%s.ty' % cNoseWrinklers[0].sCtrl:1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        connectTargets(sModel, sNoseDown, dPoses={'%s.ty' % cNoseWrinklers[0].sCtrl:-1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sNostrilIn = 'nostrilIn%s' % sSuffix
    sNostrilOut = 'nostrilOut%s' % sSuffix
    if sNostrilIn in sTargets or sNostrilOut in sTargets:
        fNostrilRange = [-1,1]
        if sNostrilIn not in sTargets:
            fNostrilRange[0] = 0.0
        if sNostrilOut not in sTargets:
            fNostrilRange[1] = 0.0

        cNostrils = ctrls8.createSliderCtrl('nostril%s' % sSuffix, 'l', fRangeX=fNostrilRange,
                                                  sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, None, None, sNostrilIn, sNostrilOut], xMirrorAxis=xMirrorAxis)
        if sNostrilOut in sTargets:
            connectTargets(sModel, sNostrilOut, dPoses={'%s.tx' % cNostrils[0].sCtrl:1.0}, fSplitRadius=fNoseSplitRadius*fNostrilSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        if sNostrilIn in sTargets:
            connectTargets(sModel, sNostrilIn, dPoses={'%s.tx' % cNostrils[0].sCtrl:-1.0}, fSplitRadius=fNoseSplitRadius*fNostrilSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


    if not dSkip.get('bSkipJawShapes', False):
        report.report.addLogText('jaw... ', bIncrementProgress=True)

        if utils.data.exists('sBakedBlendShapeJawOpenRotation%s' % sSuffix):
            if bMouthSplines:
                sJawOpenOverrideAttrRotZ = cmds.getAttr('jnt_m_jawMain.jawOpenPoseOverrideRotZ')
                sDriverBot = cmds.getAttr('jnt_m_jawMain.jawOpen_driver_bot')
                sDriverTop = cmds.getAttr('jnt_m_jawMain.jawOpen_driver_top')
                connectTargets(sModel, 'jawOpenLips%s' % sSuffix, bSplitBotTop=True,
                                              dPoses={'jaw%s_ctrl.rz' % sSuffix: sJawOpenOverrideAttrRotZ},
                                              dDrivers={sDriverBot:None, sDriverTop:None},
                                              iInvert=2,
                                              sSecondaryModels=sSecondaryModels,
                                              bControlRigCommands=True)
                connectTargets(sModel, 'jawOpen%s' % sSuffix, bSplitBotTop=False,
                                              dPoses={'jaw%s_ctrl.rz' % sSuffix: sJawOpenOverrideAttrRotZ},
                                              # dDrivers={sDriverBot:None, sDriverTop:None},
                                              iInvert=2,
                                              sSecondaryModels=sSecondaryModels,
                                              bControlRigCommands=True)
            else:
                fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation%s' % sSuffix)
                connectTargets(sModel, 'jawOpen%s' % sSuffix,
                                           dPoses={'jaw%s_ctrl.r' % sSuffix: tuple(fJawOpenRotation)},
                                           dDrivers={'jaw%s_ctrl.rz' % sSuffix:fJawOpenRotation[2]},
                                           iInvert=2,
                                           sSecondaryModels=sSecondaryModels, bControlRigCommands=True)
        else:
            report.report.addLogText('skipping jaw because not set up in blendShape file')

    report.report.addLogText('eyelids... ', bIncrementProgress=True)


    if cmds.objExists('blink%s_l_ctrl' % sSuffix):
        cBlinkCtrls = [ctrls8.ctrlFromName('blink%s_l_ctrl' % sSuffix), ctrls8.ctrlFromName('blink%s_r_ctrl' % sSuffix)]
        sBlink = 'blink%s' % sSuffix
        sBlinkCurvedUp = 'blinkCurvedUp%s' % sSuffix
        sLeftLidTop = ctrls8.ctrlFromName('lidTop%s_l_ctrl' % sSuffix).sCtrl
        sLeftLidBot = ctrls8.ctrlFromName('lidBot%s_l_ctrl' % sSuffix).sCtrl

        if not dSkip.get('bSkipLidCloseShapes', False):
            if cmds.objExists('blinkCurvedUp'):
                utils.addAttr(cBlinkCtrls[0].sCtrl, ln='upCurveBlink', minValue=0.0, maxValue=1.0, k=True)
                utils.addAttr(cBlinkCtrls[1].sCtrl, ln='upCurveBlink', minValue=0.0, maxValue=1.0, k=True)
                connectTargets(sModel, sBlink, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:[0,-1.0], '%s.upCurveBlink' % cBlinkCtrls[0].sCtrl:[1,0]}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                            iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                connectTargets(sModel, sBlinkCurvedUp, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:[0,-1.0], '%s.upCurveBlink' % cBlinkCtrls[0].sCtrl:[0,1]}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                            iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            else:
                connectTargets(sModel, sBlink, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:-1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                            iInvert=2,  sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

            connectTargets(sModel, 'eyeUpperDown%s' % sSuffix, dPoses={'%s.ty' % sLeftLidTop: -1.0}, fSplitRadius=fBlinkSplitRadius * fBlinkSplitRadiusFactor,
                                       iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            connectTargets(sModel, 'eyeLowerUp%s' % sSuffix, dPoses={'%s.ty' % sLeftLidBot:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        connectTargets(sModel, 'eyeWide%s' % sSuffix, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:0.5}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                    iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        connectTargets(sModel, 'eyeUpperUp%s' % sSuffix, dPoses={'%s.ty' % sLeftLidTop:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                    iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        connectTargets(sModel, 'eyeLowerDown%s' % sSuffix, dPoses={'%s.ty' % sLeftLidBot:-1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                    iInvert=2, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



        dEyelookPoses = utils.data.get('dEyelookPoses', xDefault={})

        if dEyelookPoses:
            # sEyePoints = []
            # sPoseAdditions = []
            # for s,sSide in enumerate(['l','r']):
            #     sEyeRotAttr = 'jnt_%s_eyeMain.r' % sSide
            #     sPlug = cmds.listConnections(sEyeRotAttr, p=True, s=True, d=False)[0]
            #     cmds.disconnectAttr(sPlug, sEyeRotAttr)
            #     sAddition = nodes.createVectorAdditionNode([sPlug, [0,0,0]], sFullName='addition_%s_tempPoseEye' % sSide, sTarget=sEyeRotAttr)
            #     sPoseAdditions.append('%s.input3D[1]' % sAddition.split('.')[0])

            for sDirection, bVert in [('eyelookDown',True), ('eyelookUp',True), ('eyelookLeft',False), ('eyelookRight',False)]:
                fEyeRotPose = dEyelookPoses.get(sDirection, None)
                if not utils.isNone(fEyeRotPose):
                    cLeftLookAt = ctrls8.ctrlFromName('eyesLookAt_l_ctrl', bReturnNoneIfNotExists=True)
                    print ('cLeftLookAt: ', cLeftLookAt)
                    if not cLeftLookAt:
                        cLeftLookAt = ctrls8.ctrlFromName('eyeLookAt_l_ctrl')

                    sDriver = '%s.lookVert' % cLeftLookAt.sPasser if bVert else '%s.lookHoriz' % cLeftLookAt.sPasser

                    print ('cLeftLookAt: ', cLeftLookAt.sCtrl)
                    connectTargets(sModel, sDirection,
                                               dPoses = {'eye_l_ctrl.r': fEyeRotPose,
                                                         'eye_r_ctrl.r': (fEyeRotPose[0], -fEyeRotPose[1], fEyeRotPose[2])},
                                               dDrivers = {sDriver:None},
                                               fSplitRadius=fBlinkSplitRadius * fBlinkSplitRadiusFactor,
                                               iInvert=0, sSecondaryModels=sSecondaryModels,
                                               xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    sMouthClose = 'mouthClose%s' % sSuffix
    if bLipCurves:

        if not dSkip.get('bSkipMouthDirectionShapes', False):
            report.report.addLogText('mouth directions... ', bIncrementProgress=True)

            connectTargets(sModel, 'mouthLeft%s' % sSuffix, dPoses={'%s.tx' % cMouth.sCtrl:dMouthPoseCtrlValues.get('mouthLeft', 1.0)}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            if cmds.objExists('mouthLeft') and not cmds.objExists('mouthRight'):
                cmds.duplicate('mouthLeft', n='mouthRight')
                geometry.meshMirrorMiddle([patch.patchFromName('mouthRight')], iDirection=geometry.MirrorDirection.flip, bControlRigCommands=True)

            connectTargets(sModel, 'mouthRight%s' % sSuffix, dPoses={'%s.tx' % cMouth.sCtrl:dMouthPoseCtrlValues.get('mouthRight', -1.0)}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)

            connectTargets(sModel, 'mouthUp%s' % sSuffix, dPoses={'%s.ty' % cMouth.sCtrl:dMouthPoseCtrlValues.get('mouthUp', 1.0)}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)
            connectTargets(sModel, 'mouthDown%s' % sSuffix, dPoses={'%s.ty' % cMouth.sCtrl:dMouthPoseCtrlValues.get('mouthDown', -1.0)}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)

            if not bMouthSplines:
                connectTargets(sModel, 'mouthLeft%s' % sSuffix, dPoses={'%s.tx' % cBot.sCtrl:1.0, '%s.tx' % cTop.sCtrl:1.0}, bSplitBotTop=True, iInvert=2 if bMouthSplines else 0,
                                            bMirror=False, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)
                connectTargets(sModel, 'mouthRight%s' % sSuffix, dPoses={'%s.tx' % cBot.sCtrl:-1.0, '%s.tx' % cTop.sCtrl:-1.0}, bSplitBotTop=True, iInvert=2 if bMouthSplines else 0,
                                            bMirror=False, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)


        report.report.addLogText('lip corners... ', bIncrementProgress=True)

        if not utils.isNone(cCorners) and not dSkip.get('bSkipCornerShapes', False):
            for sCornerTarget in ['cornerUp', 'cornerOut', 'cornerDown', 'cornerOutUp', 'cornerOutDown', 'cornerIn', 'pucker', 'cornerInUp', 'cornerInDown']:
                sCornerTargetSuffixed = '%s%s' % (sCornerTarget, sSuffix)
                # dAllSculptPoseDriverValues = eval(utils.getStringAttr(utils.getMasterName(), 'dAllSculptPoseDriverValues', '{}', bCreateIfNotExists=True))
                fDefaultPoseValues = dPoseCtrlValuesDefault[sCornerTarget]
                fPoseValues = dMouthPoseCtrlValues.get(sCornerTarget, fDefaultPoseValues)

                dCornerPose = {}
                for a,sAxis in enumerate('XY'):
                    if fPoseValues[a] != 0.0:
                        dCornerPose[f'{cCorners[0].sCtrl}.translate{sAxis}'] = fPoseValues[a]
                if sCornerTarget in ['cornerIn', 'pucker']:
                    sPuckerOnCornerIn = 'lipsCorner_l_ctrl.puckerOnIn'
                    if cmds.objExists(sPuckerOnCornerIn):
                        dCornerPose[sPuckerOnCornerIn] = 1.0 if sCornerTarget == 'pucker' else [1.0, 0.0]
                if cmds.objExists(sCornerTargetSuffixed):
                    connectTargets(sModel, sCornerTargetSuffixed, dPoses=dCornerPose, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                                sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True,
                                                iInvert=2 if bMouthSplines else 0)


        if not dSkip.get('bSkipLipShapes', False):
            fTopRollRange = [0,0]
            report.report.addLogText('lip rolls... ', bIncrementProgress=True)
            if 'upperRollOut' in sTargets or 'upperRollIn' in sTargets:
                fTopRollRange = [-1.0 if 'upperRollIn' in sTargets else 0.0, 1.0 if 'upperRollOut' in sTargets else 0.0]
                connectTargets(sModel, 'upperRollOut%s' % sSuffix, dPoses={'%s.tz' % cTop.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                connectTargets(sModel, 'upperRollIn%s' % sSuffix, dPoses={'%s.tz' % cTop.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            if not bMouthSplines:
                ctrls8.setSliderRange(cTop, fRangeZ=fTopRollRange, bAdjustBorders=True)


            fBotRollRange = [0, 0]
            if 'lowerRollOut' in sTargets or 'lowerRollIn' in sTargets:
                fBotRollRange = [-1.0 if 'lowerRollIn' in sTargets else 0.0, 1.0 if 'lowerRollOut' in sTargets else 0.0]
                connectTargets(sModel, 'lowerRollOut%s' % sSuffix, dPoses={'%s.tz' % cBot.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                connectTargets(sModel, 'lowerRollIn%s' % sSuffix, dPoses={'%s.tz' % cBot.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

            if not bMouthSplines:
                ctrls8.setSliderRange(cBot, fRangeZ=fBotRollRange, bAdjustBorders=True)


            report.report.addLogText('lipPress/funnel/fff... ', bIncrementProgress=True)

        # connectTargets(sModel, 'forward%s' % sSuffix, dPoses={'mouthBot_ctrl.tz':1, 'mouthTop_ctrl.tz':1}, fSplitRadius=8.0, bSplitBotTop=True,
        #                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10])

        if not dSkip.get('bSkipLipShapes', False):
            bMouthSplines = utils.data.get('bMouthSplines%s' % sSuffix)
            
            if 'funnel' in sTargets:
                connectTargets(sModel, 'funnel%s' % sSuffix, dPoses={'mouth_ctrl.tz':1}, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True,
                                              iInvert=2 if bMouthSplines else 0)

            if 'lipPress' in sTargets:
                connectTargets(sModel, 'lipPress%s' % sSuffix, dPoses={'mouth_ctrl.tz':-1}, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True,
                                              iInvert=2 if bMouthSplines else 0)


    report.report.addLogText('Extra Targets... ', bIncrementProgress=True)
    for dTargetData in ddTargetsAsAttributes:
        sTarget = dTargetData.get('sTarget', None)
        if not sTarget:
            continue

        sTargetSuffix = '%s%s' % (sTarget, sSuffix)

        sCtrlAttr = dTargetData['sCtrlAttr']
        sCtrl, sA = sCtrlAttr.split('.')
        sCtrlSuffix = '%s%s' % (sCtrl, sSuffix)
        fSplitRadius = dTargetData.get('fSplitRadius', 0.2)
        if utils.getSide(sCtrl) == 'l':
            sAttrs = [utils.addAttr(sCtrlSuffix, ln=sTarget, min=0, max=1, dv=0, k=True),
                      utils.addAttr(utils.getMirrorName(sCtrlSuffix), ln=sTarget, min=0, max=1, dv=0, k=True)]
            bMirror = True
        else:
            sAttrs = [utils.addAttr(sCtrlSuffix, ln=sTarget, min=0, max=1, dv=0, k=True)]
            bMirror = False

        connectTargets(sModel, sTargetSuffix, dPoses={sAttrs[0]:1.0},
                                    fSplitRadius=fSplitRadius,
                                    sSecondaryModels=sSecondaryModels,
                                    bMirror=bMirror)


    report.report.addLogText('Extra Target Sliders')
    ddExtraTargetSliders = list(ddExtraTargetSliders)
    ddExtraTargetSliders.append({'sName':'mentalis', 'dTargets':{'sTargetUp':'mentalis'}, 'bMirror': False})
    ddExtraTargetSliders.append({'sName':'puffFront', 'dTargets':{'sTargetUp':'puffFront'}, 'bMirror': False})
    ddExtraTargetSliders.append({'sName':'lipStretch', 'dTargets':{'sTargetUp':'lipStretch'}, 'bMirror': True})
    ddExtraTargetSliders.append({'sName':'neckStretch', 'dTargets':{'sTargetUp':'neckStretch'}, 'bMirror': True})

    print ('\n\n\n\n\n EXTRATARGET SLIDERS')
    for dSlider in ddExtraTargetSliders:
        print ('===============  dSlider: ', dSlider)
        sExtraTargets = [None] * 4
        dTargets = dSlider['dTargets']
        bControlRigCommands = dSlider.get('bDoControlRig', True)
        bBorder = dSlider.get('bBorder', True)
        bOneOfThemExists = False
        for k, sKey in enumerate(['sTargetUp', 'sTargetDown', 'sTargetOut', 'sTargetIn']):
            sValue = dTargets.get(sKey, '')
            if sValue and cmds.objExists(sValue):
                sExtraTargets[k] = sValue
                bOneOfThemExists = True

        if bOneOfThemExists:
            fRangeY = [0,0]
            fRangeX = [0,0]
            if sExtraTargets[0] or sExtraTargets[1]:
                fRangeY = [-1 if sExtraTargets[1] else 0,
                          1 if sExtraTargets[0] else 0]
            if sExtraTargets[2] or sExtraTargets[3]:
                fRangeX = [-1 if sExtraTargets[3] else 0,
                          1 if sExtraTargets[2] else 0]



            bMirror = dSlider.get('bMirror', True)
            cSliders = ctrls8.createSliderCtrl('%s%s' % (dSlider['sName'], sSuffix), 'l' if bMirror else 'm', fRangeX=fRangeX, fRangeY=fRangeY, sAttach=sModel,
                                                sShape=dSlider.get('sShape', 'sphere'), sAlignOnModel=[sModel]+sExtraTargets, xMirrorAxis=xMirrorAxis, bBorder=bBorder)

            if sExtraTargets[0]: # up
                connectTargets(sModel, sExtraTargets[0], dPoses={'%s.ty' % cSliders[0].sCtrl: 1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)
            if sExtraTargets[1]: # down
                connectTargets(sModel, sExtraTargets[1], dPoses={'%s.ty' % cSliders[0].sCtrl: -1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)
            if sExtraTargets[2]: # in
                connectTargets(sModel, sExtraTargets[2], dPoses={'%s.tx' % cSliders[0].sCtrl: 1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)
            if sExtraTargets[3]: # out
                connectTargets(sModel, sExtraTargets[3], dPoses={'%s.tx' % cSliders[0].sCtrl: -1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)


    for sTarget, dData in list(ddCorrectives.items()):
        # if not cmds.objExists(sTarget):
        #     continue
        dDrivers = {}
        if dData.get('sDrivers', []):
            dDrivers = {sD:None for sD in dData['sDrivers']}

        bAttributesExist = True
        for sAttr in dData['dPoses'].keys():
            if not cmds.objExists(sAttr):
                bAttributesExist = False
                report.report.addLogText('Skipping "%s" because "%s" doesnt exist' % (sTarget, sAttr))
        if bAttributesExist:
            connectTargets(sModel, '%s%s' % (sTarget, sSuffix),
                                        dPoses=dData['dPoses'],
                                        fSplitRadius=dData.get('fSplitRadius', 0.2),
                                        sSecondaryModels=sSecondaryModels,
                                        bMirror=dData.get('bMirror', True),
                                        dDrivers = dDrivers,
                                        iInvert=2, bControlRigCommands=True)


    # # this is so the shape editor picks it up
    # updateCorrectivesDict(ddCorrectives)



    report.report.addLogText('mouth close... ', bIncrementProgress=True)

    if bLipCurves:
        sMouthCloseAttr = utils.addAttr('jaw_ctrl', ln=sMouthClose, minValue=0.0, maxValue=1.0, k=True, bReturnIfExists=True)
        addTargetData(sMouthClose,
                      dPoses={sMouthCloseAttr: 1.0},
                      dDrivers={sMouthCloseAttr: [0,1]},
                      bMirror=False,
                      bSplitBotTop=False,
                      iInvert=2,
                      fSplitRadius=1.0,
                      dSplitAlongCurve={},
                      bZipper={},
                      iBrowSplinesSplit=utils.browSplinesSplitOptions.none,
                      ffLidRanges=[],
                      bControlRigCommands=[])


    # combo shapes
    sComboTargets = [sT for sT in sTargets if '_' in sT and '__' not in sT]
    sComboTargets.sort(key=lambda sT:len(sT.split('_')))

    report.report.addLogText('All the combos......', bIncrementProgress=True, bRefresh=True)
    report.report.resetProgress(len(sComboTargets))

    for sComboT in sComboTargets:
        bSuccess, sMessage = autoConnectComboTarget(sComboT, sModel, sSecondaryModels, xMirrorAxis=xMirrorAxis, bLegacyIgnoreEyeLookHoriz=False)
        report.report.addLogText(sMessage, bRefresh=True, bIncrementProgress=True)
        if not bSuccess:
            bReturn = False
    print ('sComboTargets: ', sComboTargets)
    return bReturn






def _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='LipsDetail', sSkinClusterSuffix='DETAIL'):

    iBindLipRows = iBindLipRows
    fBotMultipl, fCornerMultipl, fTopMultipl = fBindMultipls



    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        sSkinCluster = 'skinCluster__%s__%s' % (sMesh, sSkinClusterSuffix)
        sSkinClusterTemp = 'TEMP__skinCluster__%s__%s' % (sMesh, sSkinClusterSuffix)


        if cmds.objExists(sSkinClusterTemp):
            cmds.delete(sSkinClusterTemp)
        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()


        deformers.skinMesh(sMesh, ['jnt_m_faceZero'], sName=sSkinClusterTemp, bAlwaysAddDefaultWeights=True)

        weights.smoothSkinWeights([pMesh], iIterations=2, sChooseSkinCluster=sSkinClusterTemp)
        report.report.incrementProgress(bRefresh=True)
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)


        report.report.addLogText('\nskinning lips..', bRefresh=True)
        fTimeBefore = time.time()


        sAllJoints = []
        fAllValues = []


        bIgnoreMostOut = False # probably useless...
        if bIgnoreMostOut:
            iStart = 1
            iEnd = -1
        else:
            iStart = 0
            iEnd = None

        # left top
        sJoints = ['jnt_m_top%s_000' % sSuffix] + sorted(cmds.ls('jnt_l_top%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fTopMultipl, fTopMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # left bot
        sJoints = sorted(cmds.ls('jnt_l_bot%s_???' % sSuffix, et='joint'), reverse=True) + ['jnt_m_bot%s_000' % sSuffix]
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fBotMultipl, fBotMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        # right bot
        sJoints = sorted(cmds.ls('jnt_r_bot%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fBotMultipl, fBotMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # right top
        sJoints = sorted(cmds.ls('jnt_r_top%s_???' % sSuffix, et='joint'), reverse=True)
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fTopMultipl, fTopMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        print('sAlLJoins: ', sAllJoints)
        print('fAllValues: ', fAllValues)

        fJointWeightings = np.array(fAllValues, dtype='float64')
        print('fJointWeightings: ', fJointWeightings)


        # fJointWeightings = np.interp(np.arange(sJoints), iIndices, [1, 0.5, ]
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()
        weights.bindToClosestVertexAndExpand([pMesh], sJoints=sAllJoints, _fJointWeightings=fJointWeightings,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iBindLipRows[0], iExpandedFadeOutLoops=iBindLipRows[1],
                                             sChooseSkinCluster=sSkinClusterTemp)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)


        if cmds.objExists(sSkinCluster):
            pTransferTo = pMesh
            for pSel in pSelection:
                if pSel.getName() == pMesh.getName():
                    pTransferTo = pSel
                    break

            weights.transferSkinCluster([pTransferTo], sFrom=sSkinClusterTemp, sChooseSkinCluster=sSkinCluster, iMode=weights.TransferMode.vertexIndex)
            cmds.delete(sSkinClusterTemp)
        else:
            cmds.rename(sSkinClusterTemp, sSkinCluster)

        deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)



def proceduralBind_details(iBindLipRows, fBindMultipls):
    _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='LipsDetail', sSkinClusterSuffix='DETAIL')


dButtons = {}
dButtons['bind selected'] = proceduralBind_details


@builderTools.addToBuild(iOrder=95, dButtons=dButtons, bDisableByDefault=True)
def DETAILS_mouth(sAttachMesh=[], iBindLipRows=[3,3], fBindMultipls=[1.0,1.0,1.0]):
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')
    pMesh = patch.patchFromName(sAttachMesh)
    sBpCurves = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]
    iiVerts = [topology.getIdsAlongCurve(pMesh, sBpCurves[0])[0],
               topology.getIdsAlongCurve(pMesh, sBpCurves[1])[0]]
    iiVerts[1] = iiVerts[1][1:-1]
    fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode) or cmds.getAttr('jnt_m_jawEnd.tx') * 0.2

    sGroup = cmds.createNode('transform', n='grp_details', p='modules')
    ssJoints = [[], []]
    ssRefJoints = [[], []]
    for p,sPart in enumerate(['bot','top']):
        sSides, iInds = utils.convertMiddleSequenceToSides(len(iiVerts[p]))
        for i, iVert in enumerate(iiVerts[p]):
            sJ = 'jnt_%s_%sLipsDetail_%03d' % (sSides[i], sPart, iInds[i])
            if not cmds.objExists(sJ):
                xforms.createJoint(sJ, fSize=fSliderScale*0.1)
            sRefJ = xforms.createJoint('jnt_%s_%sLipsDetail_%03d_ref' % (sSides[i], sPart, iInds[i]), fSize=fSliderScale*0.1)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            ssJoints[p].append(sJ)
            ssRefJoints[p].append(sRefJ)

            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJ)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sRefJ)


    sSkinClusters = [sS for sS in deformers.listAllDeformers(sAttachMesh, sFilterTypes=['skinCluster']) if 'DETAIL' not in sS]
    sLocs = constraints.parallelTransformAsDeformers2(sAttachMesh, iiVerts[0]+iiVerts[1], sDeformers=sSkinClusters, sParent=sGroup, fTargetMinimumDistance=0.01)
    ssLocs = [sLocs[0:len(iiVerts[0])], sLocs[len(iiVerts[0]):]]
    sCtrlsGrp = cmds.createNode('grp_detailCtrls', p='ctrls')
    sVisAttr = utils.addOffOnAttr('head_ctrl', 'lipsDetailCtrlsVis', False, sTarget='%s.v' % sCtrlsGrp)
    ccCtrls = [], []
    for p,sPart in enumerate(['bot','top']):

        sSides, iInds = utils.convertMiddleSequenceToSides(len(iiVerts[p]))
        for i, iVert in enumerate(iiVerts[p]):
            cC = ctrls8.create('%sDetail' % sPart, sSide=sSides[i], iIndex=iInds[i], sParent=sCtrlsGrp, sShape='circleZ', iColorIndex=3, fMatchPos=ssLocs[p][i],
                               fSliderScale=fSliderScale, sAttrs=['t','r','s'])
            cmds.connectAttr(sVisAttr, '%s.v' % cC.sPasser)
            aHeadMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')

            iUp = i-1 if sSides[i] == 'r' else i+1
            fSideMultipl = -1.0 if sSides[i] == 'r' else 1.0
            xforms.orientThreePoints(cC.sPasser, aHeadMatrix[0,0:3], ssLocs[p][iUp], fAimVector=[0,fSideMultipl,0], fUpVector=[fSideMultipl,0,0])
            cmds.parent(ssJoints[p][i], cC.sOut)
            cmds.parent(ssRefJoints[p][i], cC.sPasser)
            xforms.resetTransform(ssJoints[p][i])
            xforms.resetTransform(ssRefJoints[p][i])

            # sSlider = cC.appendOffsetGroup('slider')
            # fSideMultipl = -1.0 if sSides[i] == 'r' else 1.0
            # cmds.setAttr('%s.s' % sSlider, fSideMultipl * fSliderScale*0.2, fSliderScale*0.2, fSliderScale*0.2)
            # cmds.setAttr('%s.s' % cC.sOut, fSideMultipl * 1.0/(fSliderScale*0.2), 1/(fSliderScale*0.2), 1/(fSliderScale*0.2))

            constraints.matrixParentConstraint(ssLocs[p][i], cC.sPasser, mo=True)
            ccCtrls[p].append(cC)


    for cC in ccCtrls[0] + ccCtrls[1][::-1]:
        cmds.controller(cC.sCtrl, 'mouth_ctrl' if cmds.objExists('mouth_ctrl') else 'head_ctrl', parent=True)

    # utils.reload2(deformers)
    deformers.connectRefsOnCurrentSkinClusters(ssJoints[0]+ssJoints[1])

    cmds.select(ssJoints[0]+ssJoints[1])




# ***************************
# **** Bend Controls  *******
# ***************************

kBendBpGroupName = '_grp_m_faceBendBps'
kBendBpFileName = 'faceBlueprintsFaceBend.ma'


def placeBendBpCircles():
    xforms.createOrReturnTopGroup(kBendBpGroupName)
    cmds.delete(cmds.parentConstraint('jnt_m_headMain', kBendBpGroupName))
    sCircles = []
    fScale = xforms.distanceBetween('jnt_m_jawEnd', 'jnt_m_headEnd') * 0.5
    for sName, sMatch, fS in [('bp_m_bendBot', 'jnt_m_jawEnd', 0.5),
                              ('bp_m_bendMid', 'bp_l_eye_main', 1.0),
                              ('bp_m_bendTop', 'jnt_m_headEnd', 0.75)]:
        sCircle = cmds.circle(name=sName)[0]
        cmds.parent(sCircle, kBendBpGroupName)
        # cmds.setAttr('%s.rz' % sCircle, 90)
        cmds.rotate(90, 0, 0, '%s.cv[*]' % sCircle)
        cmds.setAttr('%s.s' % sCircle, fScale * fS, fScale * fS, fScale * fS)
        sCircles.append(sCircle)
        cmds.delete(cmds.pointConstraint(sMatch, sCircle))

    cmds.setAttr('%s.ty' % sCircles[1], 0)
    cmds.setAttr('%s.tz' % sCircles[1], 0)

    cmds.select(sCircles)




daBodyWeights2d = {}
daBodyInfluences = {}

def bendSetupConnectInfluencesToSelection():
    sMeshes = cmds.ls(sl=True)


    for sMesh in sMeshes:

        sBendInfluences = ['jnt_m_faceZero', 'jnt_m_faceBendMiddle'] + \
                          cmds.ls('jnt_m_botFaceBendSquash_???', et='joint') + cmds.ls('jnt_m_topFaceBendSquash_???', et='joint')

        sSkinCluster = 'skinCluster__%s__BEND' % sMesh
        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sBendInfluences, sName=sSkinCluster, bAlwaysAddDefaultWeights=True, bAlwaysCreateManually=True)
        else:
            deformers.addInfluences(sSkinCluster, sBendInfluences)

    cmds.select(sMeshes)


def bendSetupBindSelectedToMiddle():
    sMeshes = cmds.ls(sl=True)

    for sMesh in sMeshes:

        sBendInfluences = ['jnt_m_faceZero', 'jnt_m_faceBendMiddle']

        sSkinCluster = 'skinCluster__%s__BEND' % sMesh
        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sBendInfluences, sName=sSkinCluster, bAlwaysAddDefaultWeights=True, bAlwaysCreateManually=True)
        else:
            deformers.addInfluences(sSkinCluster, sBendInfluences)
        pBody = patch.patchFromName(sMesh)

        pBody.setSkinClusterWeights(np.ones(pBody.getTotalCount(), dtype='float64')[:,np.newaxis], sInfluences=['jnt_m_faceBendMiddle'], sChooseSkinCluster=sSkinCluster)

    cmds.select(sMeshes)






def bendRomAnim():
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=1, v=1.0)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=10, v=1.25)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=20, v=0.8)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=30, v=1.0)

    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=30, v=0.0)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=40, v=0.25)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=50, v=-0.25)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=60, v=0.0)

    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=60, v=0.0)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=70, v=0.25)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=80, v=-0.25)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=90, v=0.0)


    cmds.playbackOptions(e=True, minTime=0, maxTime=100)

placeBendBpCircles.dSideButtons = {'?':[['No selection needed. After clicking the button, it should look like '\
                             '\nthe picture below. If it doesn\'t, check the joints "jnt_m_jawEnd", "jnt_m_headMain" and "jnt_m_headEnd"'],
                            'bendCircles.jpg']}


dButtons = OrderedDict()
dButtons['create BPs'] = placeBendBpCircles
dButtons['connect influences (selected meshes)'] = bendSetupConnectInfluencesToSelection
dButtons['bind to Middle (selected meshes)'] = bendSetupBindSelectedToMiddle
dButtons['SELECT'] = {'main joint':lambda:cmds.select('jnt_m_faceBendMiddle'),
                      'bot & top joints':lambda:cmds.select('jnt_m_???FaceBendSquash_???'),
                      'bot joints':lambda:cmds.select('jnt_m_botFaceBendSquash_???'),
                      'top joints':lambda:cmds.select('jnt_m_topFaceBendSquash_???')}
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsBend', 'dDefaultSettingValuesBend')
dButtons['create rom anim'] = bendRomAnim
dButtons['- Export Bend BPs -'] = lambda: exportBps(kBendBpFileName, kBendBpGroupName)


@builderTools.addToBuild(iOrder=62.5, dButtons=dButtons, bDisableByDefault=True)
def createBendSetup(sParentJoint='jnt_m_headMain', bBotTopChains=True, iBotTopJointCounts=[6, 6], fDefaultPivot=[0,0,0], fPivotDefaultTranslation=[0,0,0], dDefaultSettingValuesBend={}):
    '''
    This creates the controls "ctrl_m_botFaceSquashStretch", "ctrl_m_midFaceSquashStretch" and "ctrl_m_topFaceSquashStretch"
    '''

    sDefaultSettingAttrsBend = []

    fSliderScale = cmds.getAttr('jnt_m_jawEnd.tx') * 0.5
    # fJointRadius = xforms.getAverageJointRadius()
    fCtrlSize = fSliderScale * 4
    sBendGrp = cmds.createNode('transform', name='grp_m_faceBend', p=getFaceGrp())
    aParentJointMatrix = utils.getNumpyMatrixFromTransform(sParentJoint)
    constraints.matrixParentConstraint(sParentJoint, sBendGrp, skipScale=[])
    sBps = ['bp_m_bend%s' % sN for sN in ['Bot', 'Mid', 'Top']]
    cCtrls = []

    cMiddleCtrl = ctrls8.create(sName='faceSquashStretch', sSide='m', sParent=_getFaceCtrlGrp(), fRotateShape=(0, 90, 0),
                      sAttrs=['t','r','s'], fSliderScale=fSliderScale,
                      sMatch=sBps[1], sShape='circleY', fSize=fCtrlSize / fSliderScale, bPivot=True)
    cmds.controller(cMiddleCtrl.sCtrl, headCtrl(), parent=True)

    constraints.matrixParentConstraint(sParentJoint, cMiddleCtrl.sPasser, mo=True, skipScale=[])

    sMiddleJ = 'jnt_m_faceBendMiddle'
    if not cmds.objExists(sMiddleJ):
        cmds.createNode('joint', n=sMiddleJ)
    cmds.setAttr('%s.radius' % sMiddleJ, fSliderScale * 0.5)
    xforms.parentJointNoTransform(sMiddleJ, cMiddleCtrl.sOut)
    xforms.resetTransform(sMiddleJ, jo=True)# if not bLegacyJointOrientIssue else False)
    sLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sMiddleJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
    sRefMatrix = nodes.createMultMatrixNode([sLocalMatrix, '%s.worldMatrix' % sParentJoint])
    sInvRefMatrix = nodes.createInverseMatrix(sRefMatrix)
    utils.addStringAttr(sMiddleJ, deformers.kPostRefJointAttr, sInvRefMatrix)
    deformers.connectJointReferencesFromAttr(sMiddleJ)
    cmds.setAttr('%s.t' % cMiddleCtrl.sPivot, *fDefaultPivot)
    cmds.connectAttr('master.skeletonVis', '%s.v' % sMiddleJ)

    sSquashStretch = utils.addAttr(cMiddleCtrl.sCtrl, ln='squashStretch', k=True)
    sScaleOut = xforms.insertParent(cMiddleCtrl.sOut, '%s_scale' % cMiddleCtrl.sOut, bMatchParentTransform=True)
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sy' % sScaleOut, [0, 1, 10])
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sx' % sScaleOut, [10, 1, 0])
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sz' % sScaleOut, [10, 1, 0])

    if bBotTopChains:
        cC = ctrls8.create(sName='faceSquashStretchBot', sSide='m', sParent=_getFaceCtrlGrp(),
                          sAttrs=['t', 'r', 's'], fRotateShape=(90, 0, 90), fSliderScale=fSliderScale,
                          sMatch=[sBps[0], sBps[1]], sShape='circleY', fSize=fCtrlSize / fSliderScale)
        cCtrls.append(cC)
        cC = ctrls8.create(sName='faceSquashStretchTop', sSide='m', sParent=_getFaceCtrlGrp(),
                           sAttrs=['t', 'r', 's'], fRotateShape=(90, 0, 90), fSliderScale=fSliderScale,
                          sMatch=[sBps[2], sBps[1]], sShape='circleY', fSize=fCtrlSize / fSliderScale)
        cCtrls.append(cC)

        for cC in cCtrls:
            constraints.matrixParentConstraint(sMiddleJ, cC.sPasser, mo=True, skipScale=[])
            cmds.controller(cC.sCtrl, cMiddleCtrl.sCtrl, parent=True)

        aPoints = xforms.getPositionArray(sBps)

        aAllCurvePoints = np.array([aPoints[0],
                                    aPoints[0] * 0.33 + aPoints[1] * 0.66,
                                    aPoints[1],
                                    aPoints[1] * 0.66 + aPoints[2] * 0.33,
                                    aPoints[2]], dtype='float64')
        aTopTangent = aAllCurvePoints[3] - aAllCurvePoints[2]
        aBotTangent = aAllCurvePoints[1] - aAllCurvePoints[2]
        fTopTangentLength = np.linalg.norm(aTopTangent)
        fBotTangentLength = np.linalg.norm(aBotTangent)
        aTopTangent /= fTopTangentLength
        aBotTangent /= fBotTangentLength
        aTopSmoothed = (aTopTangent - aBotTangent) * 0.5
        aBotSmoothed = -aTopSmoothed
        aTopSmoothed *= fTopTangentLength
        aBotSmoothed *= fBotTangentLength
        aAllCurvePoints[1] = aAllCurvePoints[2] + aBotSmoothed.reshape(1, 3)
        aAllCurvePoints[3] = aAllCurvePoints[2] + aTopSmoothed.reshape(1, 3)
        cmds.curve(p=aAllCurvePoints)

        aaRanges = [np.arange(2, -1, -1), np.arange(2, 5, 1)]
        ssJoints = [], []
        ssSquashJoints = [], []

        for p, sPart in enumerate(['bot', 'top']):
            fPartMultipl = -1.0 if sPart == 'top' else 1.0
            cCtrl = cCtrls[p]
            sCurve = cmds.curve(n='curve_m_%sFaceBend_Temp' % sPart, p=aAllCurvePoints[aaRanges[p]], d=2)
            fEyeHeightPerc = 0.0
            curves.rebuildWithPercs(sCurve, fPercs=[0,
                                                    fEyeHeightPerc,  # *0.9,
                                                    fEyeHeightPerc + (1.0 - fEyeHeightPerc) * 0.5,
                                                    1.0])

            aPoints = curves.getPointsFromPercs(sCurve, np.linspace(0, 1, iBotTopJointCounts[p]), bReturnNumpy=True)

            # first create skinParent joints for easier binding
            aPoints4 = utils.makePoint4Array(aPoints)
            aPointsLocal4 = np.dot(aPoints4, np.linalg.inv(aParentJointMatrix))
            aPointsLocalAverage = np.average(aPointsLocal4, axis=0)
            aPointsLocal4[:, 1] = aPointsLocalAverage[1]
            aPointsLocal4[:, 2] = aPointsLocalAverage[2]
            aParentSkinPoints = np.dot(aPointsLocal4, aParentJointMatrix)[:, 0:3]
            sSkinParentJoints = xforms.createJointChain(aParentSkinPoints,
                                                        ['jnt_m_%sFaceBendSkinParent_%03d' % (sPart, j) for j in
                                                         range(len(aParentSkinPoints))],
                                                        sParent=sBendGrp, fRadius=fSliderScale * 0.35)

            sPrev = sMiddleJ
            for j in range(iBotTopJointCounts[p]):
                sJ = 'jnt_m_%sFaceBend_%03d' % (sPart, j)
                sSquashJ = 'jnt_m_%sFaceBendSquash_%03d' % (sPart, j)
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sPrev)
                    xforms.resetTransform(sJ, jo=True)
                else:
                    cmds.createNode('joint', n=sJ, p=sPrev)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.4)
                cmds.xform(sJ, t=aPoints[j], ws=True)


                if j < iBotTopJointCounts[p] - 1:
                    if cmds.objExists(sSquashJ):
                        cmds.parent(sSquashJ, sJ)
                        xforms.resetTransform(sSquashJ, jo=True)
                    else:
                        cmds.createNode('joint', n=sSquashJ, p=sJ)
                    cmds.setAttr('%s.radius' % sSquashJ, fSliderScale * 0.5)
                    cmds.setAttr('%s.segmentScaleCompensate' % sSquashJ, False)
                    utils.addStringAttr(sSquashJ, 'skinParent', sSkinParentJoints[j], bLock=True)
                    ssSquashJoints[p].append(sSquashJ)

                ssJoints[p].append(sJ)
                sPrev = sJ

            # ref:
            for sJ in ssJoints[p] + ssSquashJoints[p]:
                fLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                sRefMatrix = nodes.createMultMatrixNode([fLocalMatrix, '%s.worldMatrix' % sParentJoint], sName='%s_ref' % sJ)
                sInvRefMatrix = nodes.createInverseMatrix(sRefMatrix, sName='%s_invRef' % sJ)
                utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sInvRefMatrix)


            deformers.connectJointReferencesFromAttr(ssJoints[p])
            deformers.connectJointReferencesFromAttr(ssSquashJoints[p])

            sAutoSquashWidth = utils.addAttr(cCtrl.sPasser, ln='autoSquashWidth', min=0, max=10, dv=1.0, k=True)
            sAutoSquashDepth = utils.addAttr(cCtrl.sPasser, ln='autoSquashDepth', min=0, max=10, dv=0.2, k=True)
            sScaleAttrSquash = [sAutoSquashWidth, 1, sAutoSquashDepth]

            sAutoStretchWidth = utils.addAttr(cCtrl.sPasser, ln='autoStretchWidth', min=0, max=10, dv=1.0, k=True)
            sAutoStretchDepth = utils.addAttr(cCtrl.sPasser, ln='autoStretchDepth', min=0, max=10, dv=0.2, k=True)
            sScaleAttrStretch = [sAutoStretchWidth, 1, sAutoStretchDepth]
            sDefaultSettingAttrsBend.extend([sAutoSquashWidth, sAutoSquashDepth, sAutoStretchWidth, sAutoStretchDepth])
            aOutStretchStrength = np.arange(len(ssJoints[p])) / float(len(ssJoints[p])-1)
            aOutStretchStrengthStartQuick = 1.0 - np.power(1.0-aOutStretchStrength, 2)
            aOutStretchStrengthScale = (1+np.arange(len(ssJoints[p]))) / float(len(ssJoints[p]))

            sCtrlScaleDiff = nodes.createVectorAdditionNode(['%s.s' % cCtrl.sCtrl, [1,1,1]], sOperation='minus')
            for j, sJ in enumerate(ssJoints[p]):
                sCtrlTranslate = nodes.createVectorMultiplyNode('%s.t' % cCtrl.sCtrl, (aOutStretchStrengthStartQuick[j] * fSliderScale * (2.0 / iBotTopJointCounts[p])), bVectorByScalar=True)
                nodes.createVectorAdditionNode([cmds.getAttr('%s.t' % sJ)[0], sCtrlTranslate], sTarget='%s.t' % sJ, sName='squashAddToJoint')

                sCtrlRotate = nodes.createVectorMultiplyNode('%s.r' % cCtrl.sCtrl, (aOutStretchStrength[j] * 6.0 * (0.5 / iBotTopJointCounts[p])), bVectorByScalar=True) # recently changed fSliderScale to 6.0
                nodes.createVectorAdditionNode([cmds.getAttr('%s.r' % sJ)[0], sCtrlRotate], sTarget='%s.r' % sJ, sName='squashAddToJoint')

                if j < len(ssSquashJoints[p]):
                    sNextJ = ssJoints[p][j+1]
                    sSquashJ = ssSquashJoints[p][j]
                    sDistance = nodes.createDistanceNode([0,0,0], '%s.t' % sNextJ, fNormalized=1.0)
                    sDivided = nodes.createMultiplyNode(1, sDistance, sOperation='divide')
                    sAutoScaleDiff = nodes.createVectorAdditionNode([[sDivided, sDistance, sDivided], [1,1,1]], sOperation='minus')
                    sScaleAttr = nodes.createConditionNode(sDistance, '<', 1.0, sScaleAttrSquash, sScaleAttrStretch, bVector=True)
                    sAutoScaleDiff = nodes.createVectorMultiplyNode(sAutoScaleDiff, sScaleAttr)
                    sCtrlScale = nodes.createVectorMultiplyNode(sCtrlScaleDiff, aOutStretchStrength[j], bVectorByScalar=True)
                    sAutoScale = nodes.createVectorMultiplyNode(sAutoScaleDiff, aOutStretchStrengthScale[j], bVectorByScalar=True)
                    nodes.createVectorAdditionNode([[1,1,1], sCtrlScale, sAutoScale], sTarget='%s.s' % sSquashJ, sName='squashAddToJoint')


    utils.data.store('sDefaultSettingAttrsBend', sDefaultSettingAttrsBend)
    for sA,fV in dDefaultSettingValuesBend.items():
        # if cmds.objExists(sA):
        cmds.setAttr(sA, fV)
        # else:
        #     report.report.addLogText('skipping "%s", doesn\'t exist..' % sA)


    [cC.setDefaultAttrDict() for cC in cCtrls]

    cmds.setAttr('faceSquashStretchPivot_ctrl.t', *fPivotDefaultTranslation)
    createOrFixFaceZero()
    cmds.setAttr('_grp_m_faceBendBps.v', False)




def _replaceTargetsWithOthers(sTargetAttrs, sOtherGrp):
    sTargetShortAttrs = [sAttr.split('.')[-1] for sAttr in sTargetAttrs]

    sFoundTargets = []
    sSearchMeshes = utils.listMeshes(sOtherGrp)
    for sMesh in sSearchMeshes:
        sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]
            for sTarget in deformers.getBlendShapeTargets(sBlendShape):
                if sTarget in sTargetShortAttrs:
                    sFoundTargets.append('%s.%s' % (sBlendShape, sTarget))

    sTargetAttrs = sorted(sFoundTargets, key=lambda a: a.split('.')[-1].count('_'))
    return sTargetAttrs




def getPoseFromRangeNode(sRangeNode, bJustSign=False):
    sBeforeOverShootAttr = '%s.fBeforeOverShoot' % sRangeNode
    if cmds.objExists(sBeforeOverShootAttr):
        fBeforeOverShoot = eval(cmds.getAttr(sBeforeOverShootAttr))
        fPose = fBeforeOverShoot[1] if fBeforeOverShoot[0] == 0 else fBeforeOverShoot[0]
    else:
        fOldMinX, fOldMinMax = cmds.getAttr('%s.oldMinX' % sRangeNode), cmds.getAttr('%s.oldMaxX' % sRangeNode)
        fPose = fOldMinMax if fOldMinX == 0 else fOldMinX

    if bJustSign:
        return 1 if fPose > 0 else -1
    else:
        return fPose





def createPostRefAttrFromCurrentWorld(sJoints):
    for sJoint in utils.toList(sJoints):
        utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, str(utils.invertFlatMatrix(cmds.xform(sJoint, q=True, m=True, ws=True))))




@builderTools.addToBuild(iOrder=85.99, bDisableByDefault=True)
def blendShapifyTweakers(bScale=False):
    def _cCtrlFromJoint(sJoint):
        _sParent = sJoint
        for i in range(10):
            try:
                _sParent = cmds.listRelatives(_sParent, p=True)[0]
            except Exception as e:
                return None
                # raise Exception('Problem with %s, seems to be outside the hierarchy (%s)' % (sJoint, e))
            if _sParent.endswith('_ctrl'):
                return _sParent

    for sSkinCluster in cmds.ls('*__TWEAKERS', et='skinCluster'):
        iiEyebrowJoints = [], []
        sMesh = cmds.skinCluster(sSkinCluster, q=True, g=True)[0]
        sMesh = cmds.listRelatives(sMesh, p=True)[0]
        pMesh = patch.patchFromName(sMesh)
        aPoints = pMesh.getPoints()
        _, sInfluences, aWeights2d = pMesh.getSkinCluster(sChooseSkinCluster=sSkinCluster)
        for j,sJ in enumerate(sInfluences):
            print('sJ: ', sJ)
            if np.any(aWeights2d[:, j]):
                if 'tweakerLips' in sJ or 'tweakerBrowsSimple' in sJ or 'tweakerLids' in sJ:
                    sCtrl = _cCtrlFromJoint(sJ)
                    if utils.isNone(sCtrl):
                        continue
                    aMatrix = utils.getNumpyMatrixFromTransform(sCtrl)

                    for a in range(3):
                        sTarget = cmds.duplicate(sMesh, n='%sShape%s%s' % (sMesh, sJ.replace('_',''), ['X','Y','Z'][a]))[0]
                        aTargetPoints = np.array(aPoints)
                        aTargetPoints += aWeights2d[:,j,np.newaxis] * aMatrix[a,0:3]
                        patch.patchFromName(sTarget).setPoints(aTargetPoints)
                        # dPoses = {'%s.%s' % (sCtrl, ['tx','ty','tz'][a]):1.0}
                        sTargetAttr = blendShapes.addTargets(sMesh, sTarget)[0] #, dPoses=dPoses, bMirror=False, fOvershootRange=[10,10])
                        utils.data.addToList(utilsUnreal.kBlendShapeTargetList, [sTargetAttr])

                        cmds.connectAttr('%s.%s' % (sCtrl, ['tx','ty','tz'][a]), sTargetAttr)
                        nodes.addAttr(sCtrl, ln='isTweaker', at='bool', dv=True, k=False, bReturnIfExists=True)
                        cmds.delete(sTarget)

                    if bScale: # this is not tested yet with Unreal Control Rig!
                        for a in range(3):
                            sTarget = cmds.duplicate(sMesh, n='%sShape%sScale%s' % (sMesh, sJ.replace('_',''), ['X','Y','Z'][a]))[0]
                            aTargetPoints = np.array(aPoints)
                            aTargetPoints4 = utils.makePoint4Array(aTargetPoints)
                            aInvMatrix = np.linalg.inv(aMatrix)
                            aLocalTargetPoints4 = np.dot(aTargetPoints4, aInvMatrix)
                            aLocalTargetPoints4[:,a] = 0
                            aWorldTargetPoints4 = np.dot(aLocalTargetPoints4, aMatrix)
                            aWorldTargetPoints = aWorldTargetPoints4[:,0:3]
                            aTargetPoints = aTargetPoints * (1-aWeights2d[:,j,np.newaxis]) + aWorldTargetPoints * aWeights2d[:,j,np.newaxis]
                            patch.patchFromName(sTarget).setPoints(aTargetPoints)
                            dPoses = {'%s.%s' % (sCtrl, ['sx','sy','sz'][a]):[1, 0]}
                            connectTargets(sMesh, sTarget, dPoses=dPoses, bMirror=False, fOvershootRange=[10,10])
                            cmds.delete(sTarget)

                    for sA in ['rx','ry','rz','sx','sy','sz','v','ro']:
                        cmds.setAttr('%s.%s' % (sCtrl, sA), lock=True, keyable=False, channelBox=False)

                    if bScale:
                        for sA in ['sx', 'sy', 'sz']:
                            cmds.setAttr('%s.%s' % (sCtrl, sA), lock=False, channelBox=True)
                            cmds.setAttr('%s.%s' % (sCtrl, sA), keyable=True)

                if 'EyebrowTWEAKER' in sJ:
                    iSide = utils.getSideIndex(sJ)
                    iiEyebrowJoints[iSide].append(j)


        for s,sSide in enumerate(['l','r']):
            if iiEyebrowJoints[s]:

                aBrowTransformWeights = np.zeros(len(aWeights2d), dtype='float64')
                print ('aBrowTransformWeights: ', aBrowTransformWeights.shape)
                print ('aWeights2d: ', aWeights2d.shape)
                for iJ in iiEyebrowJoints[s]:
                    aBrowTransformWeights += aWeights2d[:,iJ]

                sCtrl = ['tweakerEyebrowParentLFT_ctrl', 'tweakerEyebrowParentRGT_ctrl'][s]
                aMatrix = utils.getNumpyMatrixFromTransform(sCtrl)
                for a in range(3):
                    sTarget = cmds.duplicate(sMesh, n='%sShape%s%s' % (sMesh, sJ.replace('_', ''), ['X', 'Y', 'Z'][a]))[0]
                    aTargetPoints = np.array(aPoints)
                    aTargetPoints += aBrowTransformWeights[:,np.newaxis] * aMatrix[a, 0:3]
                    patch.patchFromName(sTarget).setPoints(aTargetPoints)
                    dPoses = {'%s.%s' % (sCtrl, ['tx', 'ty', 'tz'][a]): 1.0}
                    sTargetAttr = blendShapes.addTargets(sMesh, [sTarget])[0]
                    cmds.connectAttr('%s.%s' % (sCtrl, ['tx', 'ty', 'tz'][a]), sTargetAttr)
                    utils.data.addToList(utilsUnreal.kBlendShapeTargetList, [sTargetAttr])

                    # connectTargets(sMesh, sTarget, dPoses=dPoses, bMirror=False, fOvershootRange=[10, 10])
                    cmds.delete(sTarget)

                for sA in ['rx', 'ry', 'rz', 'sx', 'sy', 'sz', 'v', 'ro']:
                    cmds.setAttr('%s.%s' % (sCtrl, sA), lock=True, keyable=False, channelBox=False)


        cmds.delete(sSkinCluster)



kIgnoreAttachTargetsAttr = 'ignoreAttachTargets'
def addIgnoreAttachTargets(sCtrl, sTargets):
    sAttr = '%s.%s' % (sCtrl, kIgnoreAttachTargetsAttr)
    try: # this could be a reference, in which case it wouldn't matter anyway
        sPrevTargets = [] if not cmds.objExists(sAttr) else eval(cmds.getAttr(sAttr))
        sPrevTargets += sTargets
        utils.addStringAttr(sCtrl, kIgnoreAttachTargetsAttr, str(sPrevTargets))
    except:
        pass



def _mirrorAttrsDict(dDict):
    for sAttr in list(dDict.keys()):
        if utils.getSide(sAttr) == 'l':
            sRightAttr = utils.getMirrorName(sAttr)
            if sRightAttr not in dDict:
                dDict[sRightAttr] = dDict[sAttr]
    return dDict


def _mirrorAttrsList(sList):
    sAdd = []
    for sAttr in sList:
        if utils.getSide(sAttr) == 'l':
            sRightAttr = utils.getMirrorName(sAttr)
            if sRightAttr not in sList:
                sAdd.append(sRightAttr)
    sList += sAdd
    return sList


def _separateAttrKeysIntoSides(dDict, bMirror=True):
    if bMirror:
        sLefts, sRights = [], []
        for sAttr in list(dDict.keys()):
            sSide = utils.getSide(sAttr)
            if sSide == 'l':
                sLefts.append(sAttr)
            elif sSide == 'r':
                sRights.append(sAttr)
            elif utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                sLefts.append(sAttr)
                sRights.append(sAttr)
    else:
        sLefts = list(dDict.keys())
        sRights = []

    return sLefts, sRights


def _separateAttrListIntoSides(sList, bMirror=True):
    if bMirror:
        sLefts, sRights = [], []
        for sAttr in sList:
            sSide = utils.getSide(sAttr)
            if sSide == 'l':
                sLefts.append(sAttr)
            elif sSide == 'r':
                sRights.append(sAttr)
            elif utils.getSide(sAttr) == 'm': #not '_r_' in sAttr and not '.r_' in sAttr and not sAttr.endswith('Right'):
                sLefts.append(sAttr)
                sRights.append(sAttr)
    else:
        sLefts = list(sList)
        sRights = []
    return sLefts, sRights



def getLidsBottomWeights(sModel):
    sMainModel = None
    if '__' in sModel:
        sMainModel = sModel.split('__')[0]
        if not cmds.objExists(sMainModel):
            sMainModel = None

    if sMainModel:
        pass
    else:
        aaWeights = geometry.getClosestToCurvesWeights(sModel, ['bpCurve_l_botLidSpline', 'bpCurve_l_topLidSpline', 'bpCurve_r_botLidSpline', 'bpCurve_r_topLidSpline'], iSmoothIterations=2)
    return aaWeights[:,0] + aaWeights[:,2]

# to do: we could simplify that function a lot. Has a lot of garbage from old stuff
def getMouthBottomWeights(sModel, iSkinClusterSmoothIterations=2):
    print('get mouthBottomWeights... sModel: ', sModel)
    sModel = utils.replaceStringEnd(sModel, '_noPreJoints', '')
    if cmds.objExists('MAP__%s__faceBottom' % sModel):
        return geometry.getMapValues('MAP__%s__faceBottom' % sModel)
    if cmds.objExists('MAP__faceBottom'):
        return geometry.getMapValues('MAP__faceBottom')
    if cmds.objExists('MAP__mouthBot'):
        return geometry.getMapValues('MAP__mouthBot')

    # pModel = patch.patchFromName(sModel)
    sSkinClusters = ['splitSkinCluster__%s' % sModel, 'skinCluster__%s' % sModel]

    if cmds.objExists(sSkinClusters[0]):
        sSkinCluster = sSkinClusters[0]
        ssLookForInfluences = [['jnt_m_jawMain'], ['jnt_m_headMain']]
    elif cmds.objExists(sSkinClusters[1]):
        sSkinCluster = sSkinClusters[1]
        ssLookForInfluences = [cmds.ls(['jnt_?_botMouthSplineBig_???', 'jnt_?_botMouthSplineSmall_???'], et='joint') + ['jnt_m_jawMain'],
                               cmds.ls(['jnt_?_topMouthSplineBig_???', 'jnt_?_topMouthSplineSmall_???'], et='joint') + ['jnt_m_headMain']]

    else:
        if cmds.confirmDialog(m='None of the 2 skinClusters exists: %s\nCreate an empty Map Mesh Cluster?' % ', '.join(sSkinClusters),
                           button=['yes', 'no']) == 'no':
            raise Exception('Can\'t find a way to split bottom/top for %s' % sModel)
        sSkinCluster = None


    if sSkinCluster:
        sMesh = deformers.getGeoFromDeformer(sSkinCluster)
        pModel = patch.patchFromName(sMesh)

        _, sInfluences, aWeights2d = pModel.getSkinCluster(sChooseSkinCluster=sSkinCluster)

        aWeightings2d = np.zeros((pModel.getTotalCount(), 3), dtype='float64')

        for p, sPart in enumerate(['bot', 'top']):
            sLipJoints = ssLookForInfluences[p]
            iLipInds = utils.findOneArrayInAnother(sInfluences, sLipJoints)
            aWeightings2d[:, p] = np.sum(aWeights2d[:, iLipInds], axis=1)

        aWeightings2d[:, 2] = 1.0 - np.sum([aWeightings2d[:, 0], aWeightings2d[:, 1]])
        aWeightings2d = pModel.smoothValues2d(aWeightings2d, iIterations=iSkinClusterSmoothIterations)

        aReturnWeights = aWeightings2d[:,0]
    else:
        aReturnWeights = np.zeros(cmds.polyEvaluate(sModel, vertex=True), dtype='float64')

    # generate cluster for saving next time
    sMapModel = '%s__MAPS' % sModel
    if not cmds.objExists(sMapModel):
        cmds.duplicate(sModel, n=sMapModel)
        utils.parentToWorld(sMapModel)
        cmds.setAttr('%s.v' % sMapModel, False)
    # sCluster = cmds.deformer(sMapModel, type='cluster', n='MAP__%s__faceBottom' % sModel)[0]
    sCluster, sTempHandle = cmds.cluster(sMapModel, n='MAP__%s__faceBottom' % sModel)
    nodes.deleteConnectionsAndItself2(cmds.ls(sTempHandle, dag=True))

    deformers.makeNotExport(sCluster)
    cmds.refresh()
    cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, len(aReturnWeights)-1), *list(aReturnWeights))

    return aReturnWeights



def _rangeOrDrivenKeys(sAttr, xRelation, fOvershootRange=None, bControlRigCommands=False):
    if '.' not in sAttr:
        raise Exception('%s is not an attribute' % sAttr)
    if isinstance(xRelation, type(None)):
        return sAttr
    elif isinstance(xRelation, list):
        if len(xRelation) == 2:
            if isinstance(xRelation[0], list):  # [(-1,0,1),(0,1,0)]
                sDrivenKey = nodes.setDrivenKey(sAttr, list(xRelation[0]), None, list(xRelation[1]), sInTanType='linear', sOutTanType='linear')
                if bControlRigCommands: utilsUnreal.tagFaceNode(sDrivenKey)
                return sDrivenKey
            else:  # [1,0]
                sRangeNode = nodes.createRangeNode(sAttr, xRelation[0], xRelation[1], 0, 1, sName=sAttr.replace('.', '_'), fOvershoot=fOvershootRange)
                if bControlRigCommands: utilsUnreal.tagFaceNode(sRangeNode)
                return sRangeNode
        elif len(xRelation) == 3:
            sDrivenKey = nodes.setDrivenKey(sAttr, list(xRelation), None, [0.0, 1.0, 0.0], sInTanType='linear', sOutTanType='linear')
            if bControlRigCommands: utilsUnreal.tagFaceNode(sDrivenKey)
            return sDrivenKey
        else:
            raise Exception('not supported yet: %s ' % xRelation)
    elif isinstance(xRelation, (float, int)):
        sRangeNode = nodes.createRangeNode(sAttr, 0, xRelation, 0, 1, sName=sAttr.replace('.', '_'), fOvershoot=fOvershootRange)
        if bControlRigCommands: utilsUnreal.tagFaceNode(sRangeNode)
        return sRangeNode
    else:
        raise Exception('not sure what %s is - returning None from _rangeOrDrivenKeys' % sAttr)


class CombineMode(object):
    product = 0
    minimum = 1


def _combineValues(iMode, xValues, sTarget=None, bControlRigCommands=False):
    if iMode == CombineMode.product:
        sMultiplyNode = nodes.createMultiplyArrayNode(xValues, sTarget=sTarget, bAddFactorsInfoAttr=True)
        if bControlRigCommands: utilsUnreal.tagFaceNode(sMultiplyNode)
        return sMultiplyNode
    elif iMode == CombineMode.minimum:
        sMinimumNode = nodes.createMinimumNode(xValues, sTarget=sTarget, bAddFactorsInfoAttr=True)
        if bControlRigCommands: utilsUnreal.tagFaceNode(sMinimumNode)
        return sMinimumNode
    else:
        raise Exception('Don\'t know what combine mode %d is' % iMode)




def createOrGetBakedZipperSetup():
    dZipper = utils.data.get('dZipper')
    iSampleCount = dZipper['iSampleCount']

    sZipperOutAttrs = ['zipperOut_%03d.outputR' % j for j in range(iSampleCount)]

    if not cmds.objExists(sZipperOutAttrs[0]):
        sCornerCtrls = ['lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']
        sZipperLeft = utils.addAttr(sCornerCtrls[0], ln='zipperB', at='double',  defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sZipperRight = utils.addAttr(sCornerCtrls[1], ln='zipperB', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
        sZipperFadeLengthLeft = utils.addAttr(sCornerCtrls[0], ln='zipperFadeB', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
        sZipperFadeLengthRight = utils.addAttr(sCornerCtrls[1], ln='zipperFadeB', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
        sZipperLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sZipperLeft, sZipperFadeLengthLeft), sName='left_zipperByFade')
        sZipperRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sZipperRight, sZipperFadeLengthRight), sName='right_zipperByFade')


        aSides, aInds = utils.convertMiddleSequenceToSides(iSampleCount)

        fLeftPercs = utils.bSpline4([0,0,1,1], aValues=np.arange(iSampleCount) / float(iSampleCount-1))
        fRightPercs = 1.0 - fLeftPercs

        for j in range(iSampleCount):
            sLeftRightZippers = cmds.createNode('plusMinusAverage', n='plus_%s_sumZippers_%03d' % (aSides[j], aInds[j]))

            sEndLeft = nodes.fromEquation('%f + %s' % (fLeftPercs[j], sZipperFadeLengthLeft),
                                          sName='%s_left_zipperFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeLeft = nodes.createRangeNode(sZipperLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0,
                                               sName='%s_left_zipper_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

            sEndRight = nodes.fromEquation('%f + %s' % (fRightPercs[j], sZipperFadeLengthRight), sName='%s_right_zipperFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeRight = nodes.createRangeNode(sZipperRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='%s_right_zipper_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightZippers, [0, 1], sInTanType='flat', sOutTanType='flat')

            sClamped = nodes.createClampNode('%s.output1D' % sLeftRightZippers, 0, 1, sFullName=sZipperOutAttrs[j].split('.')[0])
            sZipperOutAttrs.append(sClamped)

    return sZipperOutAttrs




dBottomWeightsMouth = {}
dBottomWeightsLids = {}
dSplitAlongCurveWeights = {}
dSplitBrowSplinesMainWeights = {}

dZipperWeights = {}
def clearWeightsCache():
    global dBottomWeightsMouth
    dBottomWeightsMouth.clear()

    global dBottomWeightsLids
    dBottomWeightsLids.clear()

    global dSplitAlongCurveWeights
    dSplitAlongCurveWeights.clear()

    global dSplitBrowSplinesMainWeights
    dSplitBrowSplinesMainWeights.clear()

    global dZipperWeights
    dZipperWeights.clear()



def getAllTargetDatas():
    return utils.data.get('ddAllTargetDatas', xDefault={})

def addTargetData(sTarget, dPoses, dDrivers, bMirror, bSplitBotTop, iInvert, fSplitRadius, dSplitAlongCurve, bZipper, iBrowSplinesSplit, ffLidRanges, bControlRigCommands):
    dTargetData = {}
    dTargetData['dPoses'] = dPoses
    dTargetData['dDrivers'] = dDrivers
    dTargetData['bMirror'] = bMirror
    dTargetData['bSplitBotTop'] = bSplitBotTop
    dTargetData['ffLidRanges'] = ffLidRanges
    dTargetData['iInvert'] = iInvert
    dTargetData['fSplitRadius'] = fSplitRadius
    dTargetData['dSplitAlongCurve'] = dict(dSplitAlongCurve)
    dTargetData['bZipper'] = bZipper
    dTargetData['iBrowSplinesSplit'] = iBrowSplinesSplit
    dTargetData['bControlRigCommands'] = bControlRigCommands

    ddAllTargetDatas = getAllTargetDatas()
    xCurrentList = ddAllTargetDatas.get(sTarget, [])
    xCurrentList.append(dTargetData)
    ddAllTargetDatas[sTarget] = xCurrentList

    utils.data.store('ddAllTargetDatas', ddAllTargetDatas)



def connectTargets(sModel, sTarget, dPoses={}, dDrivers={}, sPostMultDrivers=[], bMirror=True, iInvert=False, sAliasSuffix='',
                    fSplitRadius=0.2, bSplitBotTop=False, ffLidRanges=[], sBlendShape=None, bStopBeforeInvert=False,  bControlRigCommands=False, sSecondaryModels=[],
                   bReturnIfNotExist=False, fOvershootRange=None, iCombineMode=CombineMode.minimum, xMirrorAxis=None, dSplitAlongCurve={}, bZipper=False, iBrowSplinesSplit=utils.browSplinesSplitOptions.none):
    '''
    :param sModel:
    :param sTarget:
    :param dPoses: dictionary of attributes and values
            poses examples: dPoses={'clav_l':'forward'},
    :param dDrivers: dictionary of attributes and values/lists. If it's a list it needs to have 2 items, start and end \
                    value of attribute. If it's missing, then the poses dictionary will be taken for it.
    :param bMirror:
    :param iInvert:
    :param fSplitRadius:
    :param bSplitBotTop:
    :param sBlendShape:
    :return:
    '''

    # targetData = TargetData()
    # ddAllTargetDatas[sTarget] = targetData

    bNoTarget=False
    if sTarget != None and (not cmds.objExists(sTarget) or not cmds.listRelatives(sTarget, typ='mesh', c=True)):
        if bReturnIfNotExist:
            print('skipping target "%s", because it doesn\'t exist.' % sTarget)
            return
        else:
            bNoTarget=True

    dDrivers = dict(dDrivers)
    dPoses = dict(dPoses)
    sPostMultDrivers = list(sPostMultDrivers)

    if iBrowSplinesSplit:
        bMirror = True


    if bMirror: # TODO: take more generic function from utilFunctions ?
        _mirrorAttrsDict(dDrivers)
        _mirrorAttrsDict(dPoses)
        _mirrorAttrsList(sPostMultDrivers)


    if not dDrivers:
        dDrivers = dict(dPoses)
    elif not dPoses:
        dPoses = dict(dDrivers)

    if not bNoTarget:
        if sModel == unreal.kBlendShapeDummySphere or cmds.attributeQuery(unreal.kBlendShapeDummySphere, node=sTarget, exists=True):
            sModel = unreal.kBlendShapeDummySphere
            iInvert = False
            if not cmds.objExists(sTarget):
                unreal.addEmptyUnrealTargets(sTarget, bConnectToDummySphereAndDelete=False)

    dSavePoses = dict(dPoses)
    dSaveDrivers = dict(dDrivers)


    bSplitLidTargets = True if ffLidRanges and ffLidRanges[0] and ffLidRanges[1] else False
    iLidTargetsCount = 2 if bSplitLidTargets else 1
    ffLidFactors = []
    ssLidPoseAttrs = [['lidBot_l_ctrl.ty', 'lidTop_l_ctrl.ty'],
                    ['lidBot_r_ctrl.ty', 'lidTop_r_ctrl.ty']]
    ssLidDrivers = [['grp_l_blinkPasser.blendCurveBot', 'grp_l_blinkPasser.blendCurveTop'],
                   ['grp_r_blinkPasser.blendCurveBot', 'grp_r_blinkPasser.blendCurveTop']]

    if ffLidRanges:
        for p,sPart in enumerate(['bot','top']):
            if ffLidRanges[p]:
                fDriverValues = list(ffLidRanges[p])
                fDrivenValues = [0,1,0]

                if fDriverValues[0] == None:
                    fDriverValues = fDriverValues[1:]
                    fDrivenValues = fDrivenValues[1:]
                elif fDriverValues[-1] == None:
                    fDriverValues = fDriverValues[:-1]
                    fDrivenValues = fDrivenValues[:-1]

                if p == 1:
                    for i in range(len(fDriverValues)):
                        fDriverValues[i] *= -1

                sLeftRightDriven = [nodes.setDrivenKey(ssLidDrivers[s][p], fDriverValues, None, fDrivenValues) for s in [0,1]]
                ffLidFactors.append(sLeftRightDriven)


    dPosesForInvert = dict(dPoses)
    if dSplitAlongCurve:
        for sAttrs, fValues in zip(dSplitAlongCurve['ssAttrs'], dSplitAlongCurve['ffValues']):
            for sA,fV in zip(sAttrs, fValues):
                dPosesForInvert[sA] = fV
    if bZipper:
        dZipper = utils.data.get('dZipper')
        dPosesForInvert['lipsCorner_l_ctrl.zipperB'] = 1.0

    if ffLidRanges:
        for p,sPart in enumerate(['bot','top']):
            if ffLidRanges[p]:
                dPosesForInvert[ssLidPoseAttrs[0][p]] = ffLidRanges[p][1]
                dPosesForInvert[ssLidPoseAttrs[1][p]] = ffLidRanges[p][1]


    # make sure .r and .t endings are posed first
    sSortedPoseKeysForInvert = sorted(list(dPosesForInvert.keys()), key=lambda a:not a.endswith('.t') and not a.endswith('.r'))
    dDefaultAttrs = {}
    for sA in sSortedPoseKeysForInvert:
        if cmds.objExists(sA):
            fValue = cmds.getAttr(sA)
            if isinstance(fValue, (list,tuple)): # most likely rotation, in that case it'll look like [(0.0, 0.0, 90)]
                dDefaultAttrs[sA] = np.array(fValue[0], dtype='float64')
            else:
                dDefaultAttrs[sA] = fValue


    if sTarget == None:
        sTarget = cmds.duplicate(sModel)[0]
        if cmds.listRelatives(sTarget, p=True):
           cmds.parent(sTarget, w=True)

    print('\n\n\n ============================= sTarget: %s (%s) - secondary models: %s' % (sTarget, sModel, sSecondaryModels))

    # if not cmds.objExists(sTarget):
    #     raise Exception('Target %s doesn\'t exist.' % sTarget)

    if not bNoTarget:
        if sBlendShape == None:
            sBlendShape = 'blendShape__%s' % sModel.split(':')[-1]
            if not cmds.objExists(sBlendShape):
                deformers.preDeformationBlendshapeHack([], sModel, n=sBlendShape)
                if not cmds.objExists(sBlendShape):
                    raise Exception('wasn\'t able to create blendShape')

        if sSecondaryModels:
            sSecondaryModels = [sM for sM in list(set(sSecondaryModels)) if cmds.objExists(sM)]
        sSecondaryBlendShapes = []
        for sSecondaryModel in sSecondaryModels:
            sSecondaryBlendShape = 'blendShape__%s' % sSecondaryModel
            if not cmds.objExists(sSecondaryBlendShape):
                sSecondaryBlendShapes.append(sSecondaryBlendShape)
                deformers.preDeformationBlendshapeHack([], sSecondaryModel, n=sSecondaryBlendShape)
                if not cmds.objExists(sSecondaryBlendShape):
                    raise Exception('wasn\'t able to create blendShape')
            sSecondaryBlendShapes.append(sSecondaryBlendShape)


    sInbetweens = []
    iInbetweens = []
    if not bNoTarget:
        for sI in cmds.ls('%s__???' % sTarget, et='transform'):
            try: iNumber = int(sI.split('_')[-1])
            except: iNumber = None
            if iNumber:
                sInbetweens.append(sI)
                iInbetweens.append(iNumber)


    sTargets = [sTarget] + sInbetweens
    iInbetweens = [100] + iInbetweens
    aSorted = np.argsort(iInbetweens)

    sTargets = list(np.array(sTargets)[aSorted])
    iInbetweens = np.array(iInbetweens, dtype='float64')[aSorted]
    aPercs = iInbetweens * 0.01

    if iInvert == 2:
        sNewTargetName = '%s_INV' % sTargets[-1]
    elif iInvert == 1:
        sNewTargetName = '%s_CMB' % sTargets[-1]
    else:
        sNewTargetName = str(sTargets[-1])


    def _activatePose(fPerc):
        for sAttr in sSortedPoseKeysForInvert:
            fValue = dPosesForInvert[sAttr]
            if isinstance(fValue, tuple):
                if sAttr.endswith('.t') or sAttr.endswith('.translate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['tx','ty','tz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                elif sAttr.endswith('.r') or sAttr.endswith('.rotate'):
                    iErrorCounter = 0
                    for a,sA in enumerate(['rx','ry','rz']):
                        sAttr2 = '%s.%s' % (sAttr.split('.')[0], sA)
                        try:
                            cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))
                        except: iErrorCounter += 1
                    if iErrorCounter >= 3:
                        raise Exception('error with setting attribute %s' % sAttr)
                elif '.input3D' in sAttr:
                    for a,sA in enumerate(['x','y','z']):
                        sAttr2 = '%s.input3D%s' % (sAttr, sA)
                        cmds.setAttr(sAttr2, dPosesForInvert[sAttr][a] * fPerc + dDefaultAttrs[sAttr][a] * (1.0 - fPerc))

            elif isinstance(fValue, (list,np.ndarray)):
                cmds.setAttr(sAttr, dPosesForInvert[sAttr][-1] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc))
            else:
                cmds.setAttr(sAttr, dPosesForInvert[sAttr] * fPerc + dDefaultAttrs[sAttr] * (1.0-fPerc))

        if iBrowSplinesSplit:
            dFunctionDatas = utils.getCurrentFunctionDatas()
            dBrowSplinesArgs = dFunctionDatas['browSplinesSurface'][0].get('dFileArgs', {})
            if iBrowSplinesSplit in [utils.browSplinesSplitOptions.ctrlsDown, utils.browSplinesSplitOptions.jointsDown]:
                fBrowSplineDriverValue = dBrowSplinesArgs.get('fPoseMainDown', -0.5)
            elif iBrowSplinesSplit in [utils.browSplinesSplitOptions.ctrlsUp, utils.browSplinesSplitOptions.jointsUp]:
                fBrowSplineDriverValue = dBrowSplinesArgs.get('fPoseMainUp', 0.5)
            else:
                raise Exception('unknown iBrowSplinesSplit value (%d). Needs to be 0, 1 or 2' % iBrowSplinesSplit)
            cmds.setAttr('browMain_l_ctrl.ty', fBrowSplineDriverValue * fPerc)
            cmds.setAttr('browMain_r_ctrl.ty', fBrowSplineDriverValue * fPerc)

    sNoneDrivers = []
    for sAttr,xV in list(dDrivers.items()):
        if utils.isNone(xV):
            sNoneDrivers.append(sAttr)
            dDrivers[sAttr] = [None, None]


    if sNoneDrivers:
        for sAttr in sNoneDrivers:
            if sAttr in dPoses:
                xPosesRelation = dPoses[sAttr]
                dDrivers[sAttr] = xPosesRelation if isinstance(xPosesRelation, list) else [0, xPosesRelation]
            else:
                if cmds.objExists(sAttr): # had to do that for when mouth ctrls are not there
                    if '.' not in sAttr:
                        raise Exception('this is not an attribute: %s (sDriversGetAttr)' % sA)
                    try:
                        dDrivers[sAttr][0] = cmds.getAttr(sAttr)
                    except: raise Exception('error getting attribute value for %s' % sAttr)

                _activatePose(1.0)
                for sAttr in sNoneDrivers:
                    dDrivers[sAttr][1] = cmds.getAttr(sAttr)
                _activatePose(0.0)


    sLeftRights = [None, None]
    sLeftRights[0], sLeftRights[1] = _separateAttrKeysIntoSides(dDrivers, bMirror)

    sAllPostMultDriversLeftRights = [None, None]
    sAllPostMultDriversLeftRights[0], sAllPostMultDriversLeftRights[1] = _separateAttrListIntoSides(sPostMultDrivers, bMirror)

    # split dDrivers into left and right middles
    sReturnTargetAttrs = []


    for sAttr, xRelation in list(dDrivers.items()):
        dDrivers[sAttr] = _rangeOrDrivenKeys(sAttr, xRelation, fOvershootRange, bControlRigCommands=bControlRigCommands)

    if not bNoTarget and iInvert:

        for t,sT in enumerate(sTargets):

            sCurrentNewName = str(sNewTargetName)
            if t < len(sTargets)-1:
                sCurrentNewName = '%s__%03d' % (sCurrentNewName, iInbetweens[t])

            _activatePose(aPercs[t])

            if bStopBeforeInvert:
                cmds.select(sT, sModel)
                raise Exception('exception on purpose: stop before invertShapeDeformers (meshes are selected)')

            print ('inverting.. ', sT, sModel)

            if iInvert == 1:
                sInverted = geometry.calculateComboShape(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)
            else:
                sInverted = geometry.invertShapeDeformers(sT, sModel, sComboBlendShape=sBlendShape, sInvertName=sCurrentNewName)

            try:cmds.setAttr('%s.v' % sInverted, cmds.getAttr('%s.v' % sT))
            except: pass

            for b, sSecondaryModel in enumerate(sSecondaryModels):
                if cmds.objExists(sSecondaryModel):
                    sSecondaryT = '%s__%s' % (sSecondaryModel, sT)
                    if cmds.objExists(sSecondaryT):
                        sSecondaryInverted = geometry.invertShapeDeformers(sSecondaryT, sSecondaryModel, sComboBlendShape=sSecondaryBlendShapes[b], sInvertName='%s__%s' % (sSecondaryModel, sCurrentNewName))
                        try:cmds.setAttr('%s.v' % sSecondaryInverted, cmds.getAttr('%s.v' % sT))
                        except: pass

            try: cmds.parent(sInverted, '_invertedShapes_')
            except: pass

            sTargets[t] = sInverted

        _activatePose(0.0)


    if not sLeftRights[1] and not sAllPostMultDriversLeftRights[1] and not ffLidRanges:
        bMirror = False

    sSides = ['l','r'] if bMirror else ['m']
    sParts = ['bot','top'] if bSplitBotTop else ['bot']

    addTargetData(sTarget,
                  dPoses=dSavePoses,
                  dDrivers=dSaveDrivers,
                  bMirror=True if len(sLeftRights[0]) or len(sAllPostMultDriversLeftRights[0]) else False,
                  bSplitBotTop=bSplitBotTop,
                  iInvert=iInvert,
                  fSplitRadius=fSplitRadius,
                  dSplitAlongCurve=dict(dSplitAlongCurve),
                  bZipper=bZipper,
                  iBrowSplinesSplit=iBrowSplinesSplit,
                  ffLidRanges=ffLidRanges,
                  bControlRigCommands=bControlRigCommands)
    print ('added stuff..')
    if bNoTarget:
        return



    if bSplitBotTop:
        global dBottomWeightsMouth
        for sM in [sModel] + sSecondaryModels:
            if sM not in dBottomWeightsMouth:
                dBottomWeightsMouth[sM] = getMouthBottomWeights(sM)

    if bSplitLidTargets:
        global dBottomWeightsLids
        aModelWeights = getLidsBottomWeights(sModel)
        if sModel not in dBottomWeightsLids:
            dBottomWeightsLids[sModel] = aModelWeights

        for sSecondaryM in sSecondaryModels:
            if sSecondaryM not in dBottomWeightsLids:
                aTransferredWeights = weights.simpleTransferValues(sModel, sSecondaryM, aModelWeights)
                dBottomWeightsLids[sSecondaryM] = aTransferredWeights

    if dSplitAlongCurve:
        global dSplitAlongCurveWeights
        aaaParamSplitWeights = []
        for sM in [sModel] + sSecondaryModels:
            sKey = '%s_%s_%s' % (sM,
                                 dSplitAlongCurve['sCurve'],
                                 '_'.join('%0.3f' % fV for fV in dSplitAlongCurve['fParams']))
            if sKey not in dSplitAlongCurveWeights:
                aaWeights = geometry.generateMeshToCurveParamWeights(sM, dSplitAlongCurve['sCurve'], dSplitAlongCurve['fParams'], iSmoothIterations=dSplitAlongCurve['iSmoothIterations'])
                dSplitAlongCurveWeights[sKey] = aaWeights
            else:
                aaWeights = dSplitAlongCurveWeights[sKey]
            aaaParamSplitWeights.append(aaWeights)
        iCurveParamsCount = len(dSplitAlongCurve['fParams'])
    else:
        iCurveParamsCount = 1


    if iBrowSplinesSplit:
        global dSplitBrowSplinesMainWeights
        aaaBrowSplinesMainWeights = []
        bPerCtrls = iBrowSplinesSplit in [utils.browSplinesSplitOptions.ctrlsUp, utils.browSplinesSplitOptions.ctrlsDown]
        if bPerCtrls:
            sBrowInfluences = utils.data.get('sBrowSplinesCtrlInfluences')
            iBrowSplinesCount = 7
        else:
            sBrowInfluences = utils.data.get('browSplinesMeasureJoints')
            iBrowSplinesCount = len(sBrowInfluences)

        for sM in [sModel] + sSecondaryModels:
            aaaBrowSplinesMainWeights.append(geometry.generateBrowSplineWeights(sM, bPerCtrls=bPerCtrls))
    else:
        iBrowSplinesCount = 1

    if bZipper:
        global dZipperWeights
        aaaZipperSplitWeights = []
        iZipperParamsCount = dZipper['iSampleCount']
        fParams = np.arange(iZipperParamsCount+2)[1:-1] / float(iZipperParamsCount+1)
        for sM in [sModel] + sSecondaryModels:
            sKey = '%s_%s_%d' % (sM, dZipper['sCurve'], iZipperParamsCount)
            if sKey not in dZipperWeights:
                aaWeights = geometry.generateMeshToCurveParamWeights(sM, dZipper['sCurve'], fParams)
                dZipperWeights[sKey] = aaWeights
            else:
                aaWeights = dZipperWeights[sKey]
            aaaZipperSplitWeights.append(aaWeights)
        sZipperOutputs = createOrGetBakedZipperSetup()
    else:
        iZipperParamsCount = 1
        sZipperOutputs = []

    sDeleteMeshes = []
    for tt, sTT in enumerate(sTargets): # main target + inbetweens

        sModels = [sModel] + sSecondaryModels
        for m,sM in enumerate(sModels):
            print ('\n\n MODEL: ', sM)
            sT = sTT if m == 0 else '%s__%s' % (sM, sTT)
            if not cmds.objExists(sT):
                continue

            aTargetPoints = patch.patchFromName(sT).getPoints()
            aPoints = patch.patchFromName(sM).getPoints()
            for zz in range(iZipperParamsCount):
                for pp in range(iCurveParamsCount):
                    for bb in range(iBrowSplinesCount):
                        for s, sSide in enumerate(sSides):
                            for p, sPart in enumerate(sParts):
                                for l in range(iLidTargetsCount):
                                    sFactors = []
                                    for sAttr in sLeftRights[s]:
                                        if 'Bot' in sAttr or 'Top' in sAttr:
                                            if bSplitBotTop:
                                                if p == 0 and 'Bot' in sAttr:
                                                    sFactors.append(dDrivers[sAttr])
                                                elif p == 1 and 'Top' in sAttr:
                                                    sFactors.append(dDrivers[sAttr])
                                            else:
                                                sFactors.append(dDrivers[sAttr])
                                        else:
                                            sFactors.append(dDrivers[sAttr])

                                    aCurrentSplitWeights = np.ones(cmds.polyEvaluate(sM, vertex=True), dtype='float64')
                                    sAlias = '%s%s' % (sTT, sAliasSuffix)
                                    if iZipperParamsCount > 1:
                                        aCurrentSplitWeights *= aaaZipperSplitWeights[m][zz]
                                        sAlias = 'z%02d_%s' % (zz, sAlias)
                                        sFactors.append(sZipperOutputs[zz])
                                    if iCurveParamsCount > 1:
                                        aCurrentSplitWeights *= aaaParamSplitWeights[m][pp]
                                        sAlias = 'p%02d_%s' % (pp, sAlias)
                                        for ss in range(len(dSplitAlongCurve['ssAttrs'])): # TODO: WHAT IF MORE THAN ONE CURVE ?? Maybe add around 3 more extra loops so we can handle combos of more split curves
                                            sFactors.append(_rangeOrDrivenKeys(dSplitAlongCurve['ssAttrs'][ss][pp],  dSplitAlongCurve['ffValues'][ss][pp], fOvershootRange, bControlRigCommands=bControlRigCommands))
                                    if iBrowSplinesCount > 1:
                                        aCurrentSplitWeights *= aaaBrowSplinesMainWeights[m][bb]
                                        sAlias = 'b%02d_%s' % (bb, sAlias)
                                        sFactors.append('%s.%s' % (sBrowInfluences[bb], 'movedDown' if iBrowSplinesSplit == 1 else 'movedUp'))
                                    if len(sParts) > 1:
                                        aCurrentSplitWeights *= dBottomWeightsMouth[sM] if p == 0 else 1.0-dBottomWeightsMouth[sM]
                                        sAlias= '%s_%s' % (sPart, sAlias)
                                    if len(sSides) > 1:
                                        aCurrentSplitWeights *= geometry.getSplitWeights(sM, fSplitRadius)[s]
                                        sAlias= '%s_%s' % (sSide, sAlias)
                                    if ffLidRanges and ffLidFactors[l]:
                                        sFactors.append(ffLidFactors[l][s])
                                        if iLidTargetsCount > 1:
                                            sAlias = '%s_%s' % (utils.getLetter(l).upper(), sAlias)

                                    if np.any(aCurrentSplitWeights):
                                        iSmallerCount = min(len(aCurrentSplitWeights), len(aTargetPoints), len(aPoints))
                                        aCurrentSplitWeights = aCurrentSplitWeights[:iSmallerCount,np.newaxis]
                                        aCurrentSplitPoints = aTargetPoints[:iSmallerCount] * aCurrentSplitWeights + aPoints[:iSmallerCount] * (1.0-aCurrentSplitWeights)

                                        sCurrentTargetName = sAlias if m == 0 else '%s_%s' % (sM,sAlias)
                                        sCurrentTarget = cmds.duplicate(sM, n=sCurrentTargetName)[0]
                                        patch.patchFromName(sCurrentTarget).setPoints(aCurrentSplitPoints)

                                        sTargetAttr = blendShapes.addTargets(sM, [sCurrentTarget], sAliasAttrs=[sAlias])[0]
                                        sReturnTargetAttrs.append(sTargetAttr)
                                        cmds.setAttr('%s.v' % sCurrentTarget, False)
                                        utils.parentToWorld(sCurrentTarget)
                                        sDeleteMeshes.append(sCurrentTarget)
                                        sCombinedDriver = _combineValues(iCombineMode, sFactors, bControlRigCommands=bControlRigCommands)
                                        if sAllPostMultDriversLeftRights[s]:
                                            sCombinedDriver = nodes.createMultiplyNode(sCombinedDriver, sAllPostMultDriversLeftRights[s])
                                        if len(sTargets) == 1:  # no inbetweens
                                            cmds.connectAttr(sCombinedDriver, sTargetAttr)
                                            if bControlRigCommands:
                                                utils.data.addToList(utilsUnreal.kBlendShapeTargetList, [sTargetAttr])
                                        else: # there are inbetweens
                                            if tt == len(sTargets) - 1:  # the full one
                                                sInbetweenDriver = nodes.createRangeNode(sCombinedDriver, aPercs[tt - 1], 1, 0, 1)
                                                if sAllPostMultDriversLeftRights[s]:
                                                    sInbetweenDriver = nodes.createMultiplyNode(sCombinedDriver, sAllPostMultDriversLeftRights[s])
                                                cmds.connectAttr(sInbetweenDriver, sTargetAttr)
                                                utils.addStringAttr(sInbetweenDriver.split('.')[0], 'sCombinedDriverOverride', sCombinedDriver)
                                                if bControlRigCommands:
                                                    utils.data.addToList(utilsUnreal.kBlendShapeTargetList, [sTargetAttr])
                                                    sUnrealCurveName = sTargetAttr.split('.')[-1]
                                                    dAllCurrentInbetweens = utils.data.get(utilsUnreal.kBlendShapeTargetInbetweensList, xDefault={})
                                                    fCurrentInbetweens = dAllCurrentInbetweens.get(sUnrealCurveName, [])
                                                    fCurrentInbetweens.extend([fPerc for fPerc in aPercs if fPerc != 1.0])
                                                    dAllCurrentInbetweens[sUnrealCurveName] = fCurrentInbetweens
                                                    utils.data.store(utilsUnreal.kBlendShapeTargetInbetweensList, dAllCurrentInbetweens)
                                            else:
                                                sInbetweenDriver = nodes.setDrivenKey(sCombinedDriver, [aPercs[tt - 1] if tt > 0 else 0.0, aPercs[tt], aPercs[tt + 1]],
                                                                            None, [0, 1, 0], sInTanType='linear', sOutTanType='linear')
                                                if sAllPostMultDriversLeftRights[s]:
                                                    sInbetweenDriver = nodes.createMultiplyNode(sCombinedDriver, sAllPostMultDriversLeftRights[s])
                                                cmds.connectAttr(sInbetweenDriver, sTargetAttr)


    cmds.delete(sDeleteMeshes)
    sSplitAlongAttrs = []
    if dSplitAlongCurve:
        for ss in range(len(dSplitAlongCurve['ssAttrs'])):
            sSplitAlongAttrs += dSplitAlongCurve['ssAttrs'][ss]
    for sCtrlAttr in list(dPoses.keys()) + sSplitAlongAttrs:
        sCtrl = sCtrlAttr.split('.')[0]
        addIgnoreAttachTargets(sCtrl, utils.flattenedList(sReturnTargetAttrs))

    return sReturnTargetAttrs
    # if bAppleBlendShapes:
    #     return sUnrealCommands
    # else:
    #     return sReturnTargetAttrs



def autoConnectComboTarget(sComboT, sModel, sSecondaryModels, xMirrorAxis=None, bLegacyIgnoreEyeLookHoriz=True):
    ddAllTargetDatas = getAllTargetDatas()

    dComboMainTargets = kangarooShapeEditorTools.getPercsFromComboName(sComboT)

    sMainTargets = list(dComboMainTargets.keys())
    iCombinationCount = 1
    for t, sMainT in enumerate(sMainTargets):
        if bLegacyIgnoreEyeLookHoriz and sMainT in ['eyelookLeft', 'eyelookRight']:
            return False, ('WARNING: skipping combo "%s", because %s is not supported for combos on legacy versions' % (sComboT, sMainT))
        if sMainT not in ddAllTargetDatas:
            return False, ('WARNING: skipping combo "%s", because %s is not found' % (sComboT, sMainT))
        iCombinationCount *= len(ddAllTargetDatas[sMainT])


    for i in range(iCombinationCount):

        dPoses = {}
        dDrivers = {}
        bMirror = False
        bSplitBotTop = False
        iInvert = 1
        fSplitRadien = []
        dSplitAlongCurve = {}
        bZipper = False
        ffLidRanges = []
        bControlRigCommands = True
        iBrowSplinesSplit = 0
        for t, sMainT in enumerate(sMainTargets):

            iIndex = i
            for k in range(t + 1, len(sMainTargets), 1):
                iIndex //= len(ddAllTargetDatas[sMainTargets[k]])
            iIndex %= len(ddAllTargetDatas[sMainTargets[t]])

            dMainTargetData = ddAllTargetDatas[sMainT][iIndex]
            dMainPose = dict(dMainTargetData['dPoses'])
            dMainDriver = dict(dMainTargetData['dDrivers'])
            iPerc = dComboMainTargets[sMainT]
            if iPerc != 100:
                fPerc = iPerc * 0.01
                for sAttr, xValue in list(dMainPose.items()):
                    if isinstance(xValue, (int, float)):
                        dMainPose[sAttr] = xValue * fPerc
                    elif isinstance(xValue, list):
                        if len(xValue) != 2:
                            raise Exception('it is list but not of length 2')
                        dMainPose[sAttr] = [xValue[0], xValue[1] * fPerc]
                    elif isinstance(xValue, tuple):
                        dMainPose[sAttr] = tuple([xValue[0] * fPerc, xValue[1] * fPerc, xValue[2] * fPerc])
                    else:
                        raise Exception('Don\'t know what to do with (%s)' % xValue)

                for sAttr, xValue in list(dMainDriver.items()):
                    if isinstance(xValue, (int, float)):
                        dMainDriver[sAttr] = xValue * fPerc

            dPoses.update(dMainPose)
            dDrivers.update(dMainDriver)

            bMirror = True if dMainTargetData['bMirror'] else bMirror
            bSplitBotTop = True if dMainTargetData['bSplitBotTop'] else bSplitBotTop

            if dMainTargetData['iBrowSplinesSplit']:
                iBrowSplinesSplit = dMainTargetData['iBrowSplinesSplit']

            iInvert = max(iInvert, dMainTargetData['iInvert'])
            if dMainTargetData['bZipper']:
                bZipper = True
            if not dMainTargetData['bControlRigCommands']:
                bControlRigCommands = False

            if bMirror:
                fSplitRadien.append(dMainTargetData['fSplitRadius'])

            if dMainTargetData['dSplitAlongCurve']: #dConnectTargetSplitAlongCurves[sMainT][iIndex]:
                if not dSplitAlongCurve:
                    dSplitAlongCurve = dict(dMainTargetData['dSplitAlongCurve'])
                else:
                    dSplitAlongCurve['ssAttrs'] += dMainTargetData['dSplitAlongCurve']['ssAttrs']
                    dSplitAlongCurve['ffValues'] += dMainTargetData['dSplitAlongCurve']['ffValues']


            if dMainTargetData['ffLidRanges']:
                if ffLidRanges:
                    raise Exception('there\'s a combo shape for more than one lidRange, that\'s not supported')
                ffLidRanges = dMainTargetData['ffLidRanges']

        bIncludesMouthClose = False
        for sT in list(dComboMainTargets.keys()):
            if sT.startswith('mouthClose'):
                bIncludesMouthClose = True
                break

        connectTargets(sModel, sComboT,
                         dPoses=dPoses,
                         dDrivers=dDrivers,
                         bMirror=bMirror,
                         fSplitRadius=np.average(fSplitRadien) if fSplitRadien else 1.0,
                         bSplitBotTop=bSplitBotTop,
                         dSplitAlongCurve=dSplitAlongCurve,
                         bZipper=bZipper,
                         iInvert=iInvert,
                         sSecondaryModels=sSecondaryModels, xMirrorAxis=xMirrorAxis,
                         ffLidRanges=ffLidRanges,
                         iCombineMode=CombineMode.product if bIncludesMouthClose or 'browSplinesSplitJointsDown' in sMainTargets else CombineMode.minimum,
                         sAliasSuffix=utils.getLetter(i),
                         bControlRigCommands=bControlRigCommands,
                         iBrowSplinesSplit=iBrowSplinesSplit)


    return True, ('%s assigned %d times' % (sComboT, iCombinationCount))





# D:/assetsLocal/__REEL__/SUSUBROWS/_temp/temp47.ma