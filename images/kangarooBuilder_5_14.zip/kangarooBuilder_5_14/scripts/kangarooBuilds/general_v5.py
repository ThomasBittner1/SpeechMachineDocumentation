###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np
import pickle
import maya.cmds as cmds
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.constraints as constraints

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls2 as ctrls2
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal
import kangarooTabTools.blendShapes as blendShapes

from collections import defaultdict

kBuilderColor = '#39a9f4'


@builderTools.addToBuild(iOrder=-1001)
def reloadLibraries():
    for module in [utils, nodes, match, puppetTools, segmentsTools, ctrls, ctrls2, ctrls3, ctrls4, sliderCtrls, weights, xforms, curves, patch,
                   deformers, interpolator, geometry, export, unreal, constraints, blendShapes]:
        print('reloading %s' % module.__name__)
        report.report.addLogText('reloading %s' % module.__name__)
        utils.reload2(module)


@builderTools.addToBuild(iOrder=-1000)
def newScene(bAscii=True):
    cmds.file(new=True, f=True)
    sFilePath = os.path.expanduser('~/newScene.%s' % 'ma' if bAscii else 'mb')
    cmds.file(rename=sFilePath)
    cmds.file(save=True, typ='mayaAscii' if bAscii else 'mayaBinary')


@builderTools.addToBuild(iOrder=-100)
def createTopGroups():
    assets.createTopGroups()
    utils.data.store('sBuildingAsset', [assets.getCurrentProject(), assets.assetManager.getCurrentAsset()])
    utils.data.store('bAllSplitAttachersTakeLocals', True)



def checkClashingNames():
    sAllNewNodes = cmds.ls(dag=True)
    sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
    if sClashingNodes:
        print('---CLASHING NODES---')
        for sN in sClashingNodes:
            print(sN)
        cmds.select(sClashingNodes)
    else:
        print('no clashing nodes')


@builderTools.addToBuild(iOrder=-10, dButtons={'find clashing nodes in scene': checkClashingNames})
def importModel(bCheckClashingNames=True, sAsset='__self__', sVersion='__latest__'):
    sModelPath = assets.assetManager.getModelPath(sAsset, sVersion)
    report.report.addLogText('importing from path: %s' % sModelPath)
    if sModelPath:
        sSelBefore = cmds.ls(sl=True)
        sFilesNames = utils.listFilesInFolder(sModelPath,
                                              sEndswith=['.ma', '.MA', '.mb', '.MB', '.obj', '.OBJ', '.fbx', '.FBX', '.abc'])
        report.report.addLogText('found files: %s' % ', '.join(sFilesNames))
        sFiles = [os.path.join(sModelPath, sF) for sF in sFilesNames]

        sNewNodes = utils.importMayaFiles(sFiles)
        if not sNewNodes:
            report.report.addLogText('nothing got imported!')
            return
        if bCheckClashingNames:
            sAllNewNodes = sNewNodes + cmds.listRelatives(sNewNodes, ad=True, f=True)
            sAllNewNodes = cmds.ls(sAllNewNodes)
            sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
            if sClashingNodes:
                print('---CLASHING NODES---')
                report.report.addLogText('clashing nodes')
                for sN in sClashingNodes:
                    print(sN)
                    report.report.addLogText(sN)

                raise Exception('clashing nodes, check script editor')

        if cmds.objExists('model'):
            [cmds.lockNode(sN, lock=False) for sN in sNewNodes]
            cmds.parent(sNewNodes, 'model')
        for sNode in cmds.listRelatives(sNewNodes, ad=True, typ='transform', f=True) or []:
            if cmds.objectType(sNode) == 'transform':
                try:
                    cmds.setAttr('%s.overrideEnabled' % sNode, False)
                except:
                    pass
        cmds.select(sSelBefore)
    else:
        raise Exception('problem with importing model (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=-8)
def importBlueprints():
    sBlueprintPath = assets.assetManager.getCurrentVersionPath(sSubPath='blueprints.ma')
    print('importing blueprints %s ...' % sBlueprintPath)
    report.report.addLogText('importing blueprint rig: %s' % sBlueprintPath)

    sNewNodes = utils.importMayaFiles([sBlueprintPath])


@builderTools.addToBuild(iOrder=-5)
def importMayaFiles():
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='mayaImport/')

    print('sImportPath: ', sImportPath)

    if os.path.exists(sImportPath):
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.ma', '.mb', '.obj', '.fbx', '.abc'], bAbsolute=True)
        print('sFiles: ', sFiles)
        report.report.resetProgress(len(sFiles))

        if sFiles:
            utils.importMayaFiles(sFiles)
        else:
            report.report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sImportPath)
        report.report.addLogText('\ndidn\'t find import path (%s)' % sImportPath)


@builderTools.addToBuild(iOrder=-5)
def importTargets():
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='targets/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.trg'], bAbsolute=True)
    # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
    print('sFiles: ', sFiles)
    report.report.resetProgress(len(sFiles))

    if sFiles:
        for sF in sFiles:
            report.report.addLogText('importing %s' % sF)
            export.importTargets(sF)
            report.report.incrementProgress()
    else:
        report.report.addLogText('no files found')


@builderTools.addToBuild(iOrder=0)
def buildPuppet(bReloadLimbs=False):
    sPuppetFile = assets.assetManager.getCurrentVersionPath(sSubPath='puppet.rig')
    dLimbs = puppetDataUtils.getDictListFromFile(sPuppetFile)

    if bReloadLimbs:
        puppetDataUtils.limbsFromFiles(bReload=True)

    puppetTools.buildRig(all=None, xLimbs=[sPuppetFile, dLimbs], sMaster='master',
                         _bClearBeforeBuild=False, _bReloadLimbs=bReloadLimbs, _bFromUI=False)





def bindMeshesAutoBind(sIgnoreFiles, bWorldSpaceIfNotMatching, bAlwaysWorldSpace):
    sSel = cmds.ls(sl=True)

    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')

    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles)-set(sIgnoreFiles))
    sFiles.sort(key=lambda x:x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles if sF.startswith('skinCluster__')]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    aFileMeanValues = np.zeros((len(sFiles), 3), dtype='float64')
    dMeshFiles = {}
    for f,sFile in enumerate(sFiles):
        print('\n\n\nsFile: ', sFile)
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)
        with open(sFile, 'rb') as handle:
            loadedDict = pickle.load(handle)

        sKeys = list(loadedDict.keys())
        for sK in sKeys:
            if sK.endswith('_geo'):
                print(sK, ' -> ', loadedDict[sK])
                dMeshFiles[loadedDict[sK]] = sFile
            if 'recreateData' in sK and sK.endswith('_points'):
                aFileMeanValues[f] = np.mean(loadedDict[sK], axis=0)


    for sMesh in sSel:
        if len(deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])):
            continue

        aMeanValue = np.mean(patch.patchFromName(sMesh).getAllPoints(), axis=0)
        aFileDiffs = aFileMeanValues - aMeanValue[np.newaxis,:]
        aLengths = np.linalg.norm(aFileDiffs, axis=-1)
        iMin = np.argmin(aLengths)

        sFile = sFiles[iMin]
        cmds.select(sMesh)
        sLoaded, dSkipped = weights._loadFromFile((sFile,None), iLoadMayaSelection = weights.LoadMayaSelection.loadOntoSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=weights.LoadWorldspace.closestPoints)
        dAllSkipped.update(dSkipped)
        sSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
        if sSkinClusters:
            cmds.rename(sSkinClusters[0], sSkinClusters[0].replace('_', ''))

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=50, dButtons={'bind selected meshes with best fitting files':bindMeshesAutoBind})
def loadDeformers(sIgnoreFiles=[], bWorldSpaceIfNotMatching=False, bAlwaysWorldSpace=False):
    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles) - set(sIgnoreFiles))
    sFiles.sort(key=lambda x: x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    for sFile in sFiles:
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)

        iLoadWorldspace = weights.LoadWorldspace.ignore
        if bAlwaysWorldSpace:
            iLoadWorldspace = weights.LoadWorldspace.closestPoints
        elif bWorldSpaceIfNotMatching:
            iLoadWorldspace = weights.LoadWorldspace.closestPointsIfTopologyDiffers

        sLoaded, dSkipped = weights._loadFromFile((sFile, None),
                                                  iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldspace)
        dAllSkipped.update(dSkipped)

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=101)
def loadCtrlShapes(bDoColor=True):
    sCtrlShapesDir = assets.assetManager.getCurrentVersionPath()
    sCtrlMasters = [sF.split('.')[0] for sF in os.listdir(sCtrlShapesDir) if sF.endswith('.ctrls')]
    print('sCtrlMasters: ', sCtrlMasters)
    for sMaster in sCtrlMasters:
        if sMaster == 'ctrls' and len(
                sCtrlMasters) > 1:  # we have new ctrl files, but didn't delete the one from old system yet
            continue
        if cmds.objExists(sMaster):
            sFilePath = os.path.join(sCtrlShapesDir, '%s.ctrls' % sMaster)
            report.report.addLogText('loading file: %s' % sFilePath)
            ctrls.loadCtrls(sFile=sFilePath, bDoColor=bDoColor)



@builderTools.addToBuild(iOrder=1000)
def clean(bDeleteThem=False, bDeleteDisplayLayers=False):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]
    sOutsideNodes = set(sOutsideNodes) - set([utils.getMasterName(), '__faceData__', '__export__', utils.kGeneralDataNode])
    for sN in sOutsideNodes:
        if bDeleteThem:
            if cmds.objExists(sN):
                cmds.delete(sN)
        else:
            try:
                cmds.setAttr('%s.v' % sN, False)
            except: pass

    if bDeleteDisplayLayers:
        for sL in cmds.ls(et='displayLayer'):
            try:
                cmds.delete(sL)
            except:
                pass

        for sObj in cmds.listRelatives('model', ad=True) or []:
            try:
                cmds.setAttr('%s.overrideEnabled' % sObj, False)
            except:
                report.report.addLogText('WARNING - couldn\'t reset override enabled for %s' % sObj)



@builderTools.addToBuild(iOrder=105)
def defaultCtrlAttrDicts():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            cCtrl.setDefaultAttrDict()


@builderTools.addToBuild(iOrder=130)
def ctrlProximityConnections():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            try:
                cCtrl.setDefaultAttrDict()
            except:
                cmds.warning('couldn\'t setDefaultAttr for %s' % cCtrl)

    sProximityCondition = nodes.createConditionNode('master.ctrlVis', '==', 2, 2, 0, sName='ctrlProximity')
    for sCtrl in cmds.controller(q=True, ac=True):
        sTag = cmds.controller(sCtrl, q=True)[0]
        cmds.connectAttr(sProximityCondition, '%s.visibilityMode' % sTag)


@builderTools.addToBuild(iOrder=150)
def goToDefaultPose():
    sCtrls = [sCtrl for sCtrl in cmds.controller(q=True, ac=True)]

    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



@builderTools.addToBuild(iOrder=1000)
def prepareAnimPicker(sCharacter='FullCharacter'):
    sAnimPicker = cmds.createNode('transform', n='AnimPickerData', p=utils.getMasterName())
    utils.addStringAttr(sAnimPicker, 'character', sCharacter)



@builderTools.addToBuild(iOrder=1010)
def prepareForPublish(bDeleteUnrealModel=True):
    '''

    '''
    # utils.data.store('bVersionFolders', True, sNode=utils.kExportNode)

    cmds.flushUndo()

    sAsset = assets.assetManager.getCurrentAsset()
    sUnrealModel = utils.data.get('sUnrealModel', None)
    if not sUnrealModel:
        bDeleteUnrealModel = False

    import kangarooTools.settings as settings
    ddMasters = {'master':{'sFilename':'RIG_%s_[v].ma' % sAsset,
                           'sExtraFiles': 'fbx/RIG_%s.fbx' % (sAsset),
                           'sDelete':['UNREALMODEL'] if bDeleteUnrealModel else []}}
    utils.data.store('ddMasters', ddMasters, sNode=utils.kExportNode)
    utils.data.store('bSaveInsteadOfExport', True, sNode=utils.kExportNode)

    # dConfirms = {'Did you export FBX?':[('Yes', True),
    #                                   ('No, but I don\'t care.', True),
    #                                   ('Oops.. please cancel', False)]}
    # utils.data.store('dConfirms', dConfirms, sNode=utils.kExportNode)


dButtons = {}



@builderTools.addToBuild(iOrder=130, bDisableByDefault=True)
def createUnrealSkeleton(bRemoveJointsWithoutBindPose=True, bRemoveExtraGroupsInModels=True, bMergeGroups=False, bCollapseUnrealJoints=False,
                         bAvoidCycle=True, bBindNewGeometry=True, sEngineName='UNREAL', bCharacterNameInRoot=False, bConnectBlendShapeAnim=False):

    sUnrealSkeleton = '%sSKELETON' % sEngineName.upper()
    sUnrealModel = '%sMODEL' % sEngineName.upper()

    sDupl = cmds.duplicate('skeleton', n=sUnrealSkeleton)[0]
    sChildren = cmds.listRelatives(sDupl, c=True, p=False, f=True)
    sRoot = '%s%s%sRoot' % (assets.assetManager.getCurrentAsset() if bCharacterNameInRoot else '', sEngineName[0].upper(), sEngineName[1:].lower())
    cmds.createNode('joint', n=sRoot, p=sDupl)

    cmds.parent(sChildren, sRoot)
    sJoints = cmds.listRelatives(sRoot, ad=True, f=True)
    sJoints.sort(key=lambda a: len(a), reverse=True)
    dJoints = {}
    dCollapsedUnrealJoints = {}

    for sJ in sJoints:
        sUnrealCollapseJointsAttr = '%s.%sCollapseJoints' % (sJ, sEngineName.lower())
        if cmds.objExists(sUnrealCollapseJointsAttr):
            for sCollapsedJ in eval(cmds.getAttr(sUnrealCollapseJointsAttr)):
                dCollapsedUnrealJoints[sCollapsedJ] = sJ.split('|')[-1]

        sName = sJ.split('|')[-1]
        sSplits = sName.split('_')
        sSplits[0] = '%sU' % sSplits[0]
        sNewName = '_'.join(sSplits)
        cmds.rename(sJ, sNewName)
        dJoints[sName] = sNewName

        sChildren = cmds.listRelatives(sNewName, c=True, p=False)
        if sChildren:
            sChildren = [sN for sN in sChildren if cmds.objectType(sN) in ['transform', 'join']]
            if sChildren:
                cmds.parent(sChildren, w=True)

        # if bChangeAxis:
        #     cmds.rotate(0, -90, -90, sNewName, os=True, r=True)
        if sChildren:
            cmds.parent(sChildren, sNewName)

        if cmds.objectType(sName) == 'joint':
            cmds.parentConstraint(sName, sNewName, mo=True)

    # clean up (joint segments, and clean transform groups
    unreal.unrealifyJointHierarchy(sUnrealSkeleton, bCollapseUnrealJoints=bCollapseUnrealJoints)

    def _funcMap(sJ):
        if bCollapseUnrealJoints:
            sJ = dCollapsedUnrealJoints.get(sJ, sJ)
        if sJ.startswith('jnt_'):
            return utils.replaceStringStart(sJ, 'jnt_', 'jntU_')
        elif sJ.startswith('muscleJnt_'):
            return utils.replaceStringStart(sJ, 'muscleJnt_', 'muscleJntU_')
        else:
            return sJ

    def _funcMapRev(sJ):
        if sJ.startswith('jntU_'):
            return utils.replaceStringStart(sJ, 'jntU_', 'jnt_')
        elif sJ.startswith('muscleJntU_'):
            return utils.replaceStringStart(sJ, 'muscleJntU_', 'muscleJnt_')
        else:
            raise Exception('%s is not a good name for a skin joint' % sJ)



    sMuscles = [sJ for sJ in cmds.ls('muscleJntU_*', et='joint') if not sJ.endswith('End')]
    for sJ in sMuscles:
        sParent = _funcMap(cmds.getAttr('%s.startSpace' % sJ))
        sCurrentParent = cmds.listRelatives(sJ, p=True)[0]
        if sParent != sCurrentParent:
            cmds.parent(sJ, sParent)

    xforms.matrixParentConstraint('global_ctrl', sRoot, bChildParentIsInOrigin=True)
    for sJ in cmds.listRelatives(sRoot, ad=True):
        sOther = _funcMapRev(sJ)
        if sOther == sJ:
            report.report.addLogText('skipping "%s", there is no master joint' % sJ)
        else:
            xforms.matrixParentConstraint(sOther, sJ, bAvoidCycle=bAvoidCycle)
    # oooo2

    # create model
    # switch off deformers for duplicate
    dPrevSkinClusterStates = {}
    dPrevBlendShapeStates = {}
    sBlendshapeMeshes = []
    for sMesh in utils.listMeshes('model'):
        sDeformers = deformers.listAllDeformers(sMesh)
        for sD in sDeformers:
            if cmds.objectType(sD) == 'skinCluster':
                dPrevSkinClusterStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
            elif cmds.objectType(sD) == 'blendShape':
                dPrevBlendShapeStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
                sBlendshapeMeshes.append(sMesh)
            else:
                continue
            cmds.setAttr('%s.nodeState' % sD, 1)


    sDuplicatedModels = cmds.duplicate('model', n=sUnrealModel)[1:]
    sFullNames = [sN for sN in cmds.ls(sDuplicatedModels, l=True) if sUnrealModel in sN]
    sFullNames = sorted(sFullNames, key=lambda a: len(a), reverse=True)
    for sN in sFullNames:
        sName = sN.split('|')[-1]
        cmds.rename(sN, 'unreal_%s' % sName)

    for sMesh in utils.listMeshes(sUnrealModel):
        utils.freezeGeo(sMesh)
    cmds.setAttr('%s.overrideEnabled' % sUnrealModel, 0)

    # set back blendShapes
    [cmds.setAttr(sA, fV) for sA, fV in list(dPrevBlendShapeStates.items())]

    # transfer blendshaes
    sBlendShapesToBake = []
    for sBody in sBlendshapeMeshes:
        sBs = 'blendShape__%s' % sBody
        sTargetMeshes, sAliases, sSkippedTargets = blendShapes.bake(sBody, sBs, bSkipUnchanged=True)

        report.report.addLogText('\nSkipped %d BlendShape Targets of %d for "%s"' %
                                 (len(sSkippedTargets), len(sSkippedTargets) + len(sTargetMeshes), sBody))
        for sSkippedT in sSkippedTargets:
            report.report.addLogText('Skipped Target "%s"...' % sSkippedT)


        sUnrealTargets = deformers.addBlendShapeTargets('unreal_%s' % sBody, sTargetMeshes)
        for t, sT in enumerate(sAliases):
            cmds.connectAttr('%s.%s' % (sBs, sT), sUnrealTargets[t])

        sSourceAttrs = ['%s.%s' % (sBs,sA) for sA in sAliases]

        if bConnectBlendShapeAnim:
            for t,sT in enumerate(sAliases):
                cmds.connectAttr(sSourceAttrs[t], sUnrealTargets[t])
                sBlendShapeJointAttr = '%s.%s' % (sRoot, sT)
                if not cmds.objExists(sBlendShapeJointAttr):
                    cmds.addAttr(sRoot, ln=sT, k=True)
                    cmds.connectAttr(sSourceAttrs[t], sBlendShapeJointAttr)



        cmds.delete(sTargetMeshes)
        sBlendShapesToBake.append(sBs)

    # set back skinClusters
    [cmds.setAttr(sA, fV) for sA, fV in list(dPrevSkinClusterStates.items())]

    utils.addStringAttr(sUnrealModel, 'sBlendShapes', sBlendShapesToBake, bLock=True)
    utils.addStringAttr(sUnrealSkeleton, 'sBlendShapes', sBlendShapesToBake, bLock=True)

    # bind new geometry
    if bBindNewGeometry:
        # if bRemoveJointsWithoutBindPose:
        #     bRemoveJointsWithoutBindPose = False
        #     report.report.addLogText('setting bRemoveJointsWithoutBindPose to False because it wouldn\'t make much sense')
        sUnrealMeshes = utils.listMeshes(sUnrealModel)
        for sUnrealM in sUnrealMeshes:
            sM = utils.replaceStringStart(sUnrealM, 'unreal_', '')
            if not cmds.objExists(sM):
                raise Exception('this mesh doesn\'t exist: %s (%s)' % (sM, sUnrealM))
            pM = patch.patchFromName(sM)
            pUnrealM = patch.patchFromName(sUnrealM)
            if deformers.listAllDeformers(sM, sFilterTypes=['skinCluster']):
                weights.transferSkinCluster([pUnrealM], sFrom=sM, iMode=weights.TransferMode.vertexIndex,
                                            funcMapJoint=_funcMap)

                sOldSkinCluster, _ = pM.getSkinCluster(bSkipWeights=True)
                sUnrealSkinCluster, _ = pUnrealM.getSkinCluster(bSkipWeights=True)

                sConns = cmds.listConnections('%s.matrix' % sOldSkinCluster, p=True, c=True, d=False, s=True)
                # skinCluster__body_ply.matrix[0]', u'jnt_l_thumbMid.worldMatrix', u'skinCluster__body_ply.matrix[1]', u'jnt_l_thumbBase.worldMatrix..
                dOldReferencePlugs = {}
                for c in range(0, len(sConns), 2):
                    sSkinClusterPlug = sConns[c]
                    sReferencePlug = sSkinClusterPlug.replace('.matrix[', '.bindPreMatrix[')
                    sJointMatrix = sConns[c + 1]
                    dOldReferencePlugs[sJointMatrix.split('.')[0]] = sReferencePlug

                sUnrealConns = cmds.listConnections('%s.matrix' % sUnrealSkinCluster, p=True, c=True, d=False, s=True)
                for c in range(0, len(sUnrealConns), 2):
                    sUnrealSkinClusterPlug = sUnrealConns[c]
                    sUnrealJ = sUnrealConns[c + 1].split('.')[0]
                    sJ = _funcMapRev(sUnrealJ)

                    sUnrealReferencePlug = sUnrealSkinClusterPlug.replace('.matrix[', '.bindPreMatrix[')
                    cmds.setAttr(sUnrealReferencePlug, cmds.getAttr(dOldReferencePlugs[sJ]), type='matrix')

    if bRemoveJointsWithoutBindPose:

        sJoints = cmds.listRelatives(sUnrealSkeleton, typ='joint', ad=True, f=True)
        sJoints.sort(key=lambda a: len(a), reverse=True)
        for sJ in sJoints:
            if not cmds.listConnections(sJ, t='dagPose'):
                if not cmds.listRelatives(sJ, c=True):
                    cmds.delete(sJ)

    if bRemoveExtraGroupsInModels:
        sMeshes = utils.listMeshes(sUnrealModel)
        sTransforms = set(cmds.listRelatives(sUnrealModel, typ='transform', ad=True)) - set(sMeshes)
        for sM in sMeshes:
            if cmds.listRelatives(sM, p=True)[0] != sUnrealModel:
                cmds.parent(sM, sUnrealModel)
        cmds.delete(sTransforms)



    # unreal namespace for meshes
    cmds.namespace(add=sEngineName.lower())
    for sNode in cmds.listRelatives(sUnrealModel, ad=True):
        cmds.rename(sNode, sNode.replace('unreal_', '%s:' % sEngineName.lower()))


    cmds.setAttr('%s.v' % sUnrealSkeleton, False)
    cmds.setAttr('%s.v' % sUnrealModel, False)


    if bMergeGroups:
        sChildren = cmds.listRelatives(sUnrealModel, c=True)
        cmds.parent(sChildren, sUnrealSkeleton)
        cmds.delete(sUnrealModel)

    utils.data.store('sUnrealSkeleton', sUnrealSkeleton)
    utils.data.store('sUnrealModel', sUnrealModel)


@builderTools.addToBuild(iOrder=90)
def puppetCustomAttachments():
    return constraints.setupAllPuppetCustomAttachments(bRotateByNeighborVerts=True)




@builderTools.addToBuild(iOrder=145)
def mirrorAnimationTags():

    def _tag(sCtrls, dData={}):

        for sCtrl in utils.toList(sCtrls):
            for s,sSide in enumerate(['l','r']):
                if sSide == 'l':
                    sSideCtrl = sCtrl
                if sSide == 'r':
                    if 'LFT' not in sCtrl:
                        continue
                    sSideCtrl = sCtrl.replace('LFT','RGT')
                    if 'sParent' in dData:
                        dData['sParent'] = dData['sParent'].replace('LFT','RGT]')

                if not cmds.objExists(sSideCtrl):
                    continue
                sParent = dData.get('sParent', None)
                if sParent and not cmds.objExists(sParent):
                    continue

                utils.addStringAttr(sSideCtrl, 'dMirrorData', str(dData), bLock=True)

                cCtrl = ctrls.ctrlFromName(sCtrl)
                if cCtrl.sSuper:
                    utils.addStringAttr(cCtrl.sSuper, 'dMirrorData', str(dData), bLock=True)
                if cCtrl.sPivot:
                    utils.addStringAttr(cCtrl.sPivot, 'dMirrorData', str(dData), bLock=True)
                if cCtrl.sChild:
                    utils.addStringAttr(cCtrl.sChild, 'dMirrorData', str(dData), bLock=True)


    # arms
    for sCtrl in ['clavicleLFT_ctrl', 'armUpperLFT_ctrl', 'armElbowLFT_ctrl', 'armWristLFT_ctrl']:
        _tag([sCtrl], {'sNegate':[]})
    _tag('armIkLFT_ctrl', {'sNegate':[]})
    _tag('armPoleLFT_ctrl', {'sNegate':['translateX'] if not cmds.objExists('grp_r_armPoleOffsetSlider') else []})

    # legs
    for sCtrl in ['legUpperLFT_ctrl', 'legKneeLFT_ctrl', 'legAnkleLFT_ctrl']:
        _tag([sCtrl], {'sNegate':[]})
    _tag('legIkLFT_ctrl', {'sNegate':[]})
    _tag('legPoleLFT_ctrl', {'sNegate':['translateX'] if not cmds.objExists('grp_r_legPoleOffsetSlider') else []})

    # jaw
    if cmds.objExists('ctrl_m_jawOut'):
        fRotX = cmds.getAttr('ctrl_m_jawOut.rx')
        if abs(fRotX) < 1.0: # didn't get oriented (old character)
            _tag('jaw_ctrl', {'sNegate': ['translateZ', 'rotateX', 'rotateY']})

#
# __iPriority = 0
#
# @builderTools.addToBuild(iOrder=145)
# def tagMirrorAnimationTagsMatrix__old():
#
#     def _tag(sCtrls, dData={}):
#         global __iPriority
#
#         for sCtrl in sCtrls:
#             dData['iPriority'] = __iPriority
#             __iPriority += 1
#             for s,sSide in enumerate(['l','r']):
#                 if sSide == 'l':
#                     sSideCtrl = sCtrl
#                 if sSide == 'r':
#                     if 'LFT' not in sCtrl:
#                         continue
#                     sSideCtrl = sCtrl.replace('LFT','RGT')
#                     if 'sParent' in dData:
#                         dData['sParent'] = dData['sParent'].replace('LFT','RGT]')
#
#                 if not cmds.objExists(sSideCtrl):
#                     continue
#                 sParent = dData.get('sParent', None)
#                 if sParent and not cmds.objExists(sParent):
#                     continue
#
#                 utils.addStringAttr(sSideCtrl, 'dMirrorData', str(dData), bLock=True)
#
#     bCogMirrorAxis = [[False, True, True], [True, False, False], [True, False, False], [True, False, False]]
#     _tag(['cog_ctrl'], {'sParent':'global_ctrl', 'bMirrorAxis':bCogMirrorAxis})
#
#     _tag(['spineBase_ctrl'], {'sParent':'cog_ctrl', 'bMirrorAxis':bCogMirrorAxis})
#
#     sSpineFkCtrls = ['cog_ctrl', 'spineBase_ctrl'] + sorted(cmds.ls('spineSplineFk_?_ctrl'))
#     for i in range(len(sSpineFkCtrls)-1):
#         _tag([sSpineFkCtrls[i+1]], {'sParent':sSpineFkCtrls[i], 'bMirrorAxis':bCogMirrorAxis})
#
#     _tag(['spineArchFk_ctrl', 'spineHipsFk_ctrl'], {'sParent': 'spineBase_ctrl', 'bMirrorAxis': bCogMirrorAxis})
#
#     bUparmMirrorAxis = [[True, True, False], [True, True, False], [True, True, False], [False, False, True]]
#     _tag(['clavicleLFT_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bUparmMirrorAxis})
#     _tag(['armUpperLFT_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bUparmMirrorAxis})
#     _tag(['armElbowLFT_ctrl'], {'sNegate':['tx','ty','tz']})
#     _tag(['armWristLFT_ctrl'], {'sParent':sorted(cmds.ls('jnt_l_arm_lowerTwist_???', et='joint'))[-1]})
#     bArmIkMirror =  [[False, False, True], [False, False, True], [False, False, True], [False, False, True]]
#     _tag(['armIkLFT_ctrl', 'armPoleLFT_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bArmIkMirror})
#
#
#     bLegIkMirror = [[True, False, False], [True, False, False], [True, False, False], [True, False, False]]
#     _tag(['legIkLFT_ctrl', 'legPoleLFT_ctrl'], {'sParent':'jnt_m_hips', 'bMirrorAxis':bLegIkMirror})
#     bUplegMirrorAxis = [[True, True, False], [True, True, False], [True, True, False], [False, False, True]]
#     _tag(['legUpperLFT_ctrl'], {'sParent':'jnt_m_hips', 'bMirrorAxis':bLegIkMirror})
#     _tag(['legKneeLFT_ctrl'], {'sNegate':['tx','ty','tz']})
#     _tag(['legAnkleLFT_ctrl'], {'sParent':sorted(cmds.ls('jnt_l_leg_lowerTwist_???', et='joint'))[-1]})
#
#
#     _tag(['legKneeStretchLFT_ctrl'], {'sParent':'jnt_m_hips', 'bMirrorAxis':bLegIkMirror})
#     _tag(['armElbowStretchLFT_ctrl'], {'sParent':'jnt_m_hips', 'bMirrorAxis':bLegIkMirror})
#
#     bNeckMirrorAxis = [[True, True, False], [False, False, True], [False, False, True], [False, False, True]]
#     _tag(['neckBaseIk_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bNeckMirrorAxis})
#     _tag(['neckTopIk_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bNeckMirrorAxis})
#     _tag(['neckMidIk_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bNeckMirrorAxis})
#     _tag(['head_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bNeckMirrorAxis})
#     _tag(['eyesLookAt_ctrl'], {'sParent':'jnt_m_spineSpine_end', 'bMirrorAxis':bNeckMirrorAxis})
#



