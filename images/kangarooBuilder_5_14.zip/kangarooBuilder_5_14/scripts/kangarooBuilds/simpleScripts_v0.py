###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os

import maya.cmds as cmds
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.xforms as xforms

import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.export as export


kBuilderColor = '#39a9f4'


@builderTools.addToBuild(iOrder=-1001)
def reloadLibraries(_report=None):
    for module in [utils, nodes, match, puppetTools, segmentsTools, ctrls, weights, xforms, curves, patch, deformers]:
        print('reloading %s' % module.__name__)
        if _report: _report.addLogText('reloading %s' % module.__name__)
        utils.reload2(module)



@builderTools.addToBuild(iOrder=-1000)
def newScene():
    cmds.file(new=True, f=True)


@builderTools.addToBuild(iOrder=-5)
def importTargets(_report=None):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='targets/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    if sImportPath:
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.trg'], bAbsolute=True)
        # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
        print('sFiles: ', sFiles)
        if _report: _report.resetProgress(len(sFiles))

        if sFiles:
            for sF in sFiles:
                _report.addLogText('importing %s' % sF)
                export.importTargets(sF)
                _report.incrementProgress()
        else:
            if _report: _report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=9)
def importModel(sAsset='__self__', sVersion='__latest__', _report=None):

    sModelPath = assets.assetManager.getModelPath(sAsset, sVersion)
    if _report: _report.addLogText('importing from path: %s' % sModelPath)
    
    if sModelPath:
        sFilesNames = utils.listFilesInFolder(sModelPath, sEndswith=['.ma','.mb', '.obj', '.fbx'])
        if _report: _report.addLogText('found files: %s' % ', '.join(sFilesNames))
        sFiles = [os.path.join(sModelPath, sF) for sF in sFilesNames]
        sNewNodes = utils.importMayaFiles(sFiles)
        if cmds.objExists('model'):
            cmds.parent(sNewNodes, 'model')
        for sNode in cmds.listRelatives(sNewNodes, ad=True, typ='transform') or []:
            try:
                cmds.setAttr('%s.overrideEnabled' % sNode, False)
            except: pass
    else:
        raise Exception('problem with importing model (%s)' % sModelPath)




@builderTools.addToBuild(iOrder=-5)
def importMayaFiles(_report=None):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='mayaImport/')
    
    print('sImportPath: ', sImportPath)
    
    if sImportPath:
        sFilesNames = utils.listFilesInFolder(sImportPath, sEndswith=['.ma','.mb', '.obj', '.fbx', '.OBJ'])
        sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
        print('sFiles: ', sFiles)
        if sFiles:
            utils.importMayaFiles(sFiles, _report=_report)
        else:
            if _report: _report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=50)
def loadDeformers(_report=None):
    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    if _report: _report.addLogText('importing from folder %s..' % deformerFolder)
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=True, sEndswith=['.wts'])
    
    bReturn = None
    print('sAllFiles: ', sFiles)
    dAllSkipped = {}
    for sFile in sFiles:
        if _report: _report.addLogText(sFile)
        sLoaded, dSkipped = weights._loadFromFile((sFile,None), iLoadMayaSelection = weights.LoadMayaSelection.ignoreSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene)
        dAllSkipped.update(dSkipped)


    if dAllSkipped:
        if _report:
            _report.addLogText('\n\nskipped:')
            for sD, sMessage in list(dAllSkipped.items()):
                _report.addLogText('%s (%s)' % (sD, sMessage))
        bReturn = False
    return bReturn



@builderTools.addToBuild(iOrder=1000)
def clean(bDeleteThem=False, bDeleteDisplayLayers=False):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]
    sOutsideNodes = set(sOutsideNodes) - set(['master'])
    for sN in sOutsideNodes:
        if bDeleteThem:
            cmds.delete(sN)
        else:
            cmds.setAttr('%s.v' % sN, False)


    if bDeleteDisplayLayers:
        for sL in cmds.ls(et='displayLayer'):
            try:
                cmds.delete(sL)
            except:
                pass

