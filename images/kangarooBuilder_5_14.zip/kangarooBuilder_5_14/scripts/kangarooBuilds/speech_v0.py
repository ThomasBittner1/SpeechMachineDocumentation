###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from collections import OrderedDict, defaultdict
import numpy as np
import kangarooTools.patch as patch

import kangarooTabTools.builder as builderTools
import os
import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.geometry as geometry
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.assets as assets
import kangarooTools.report as report
import maya.api.OpenMaya as OpenMaya2



# import kangarooTabTools.poser as poser

iColorIndexCtrls = 0
bPolyCtrls = False
kBuilderColor = utils.uiColors.yellow  # '#39a9f4'

kFaceDataNode = '__faceData__'



def exportBps(sFileName, sGroup):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    print('exporting "%s" to "%s" ' % (sGroup, sFile))
    report.report.addLogText('exporting "%s" to "%s" ' % (sGroup, sFile))
    utils.createFolderIfNotExists(sFile)

    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #



def createMatrixCtrlromSelectedPoints(sName, sParent, sSkinningSphere=None, fRotate=(0,0,0), bLockToMiddle=False):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls7.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()


    fnMesh = OpenMaya2.MFnMesh(pSel.mDagPath)
    _, mNormal, _ = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(list(aMean)), space=OpenMaya2.MSpace.kWorld)

    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    xforms.orientThreePoints(sLoc, (mNormal.x, mNormal.y, mNormal.z), (0, 0, -1), fAimVector=(0, 0, 1),
                             fUpVector=(1, 0, 0))

    if bLockToMiddle:
        for sL in ['%s.%s' % (sLoc, sAttr) for sAttr in ['tx', 'ry', 'rz']]:
            cmds.setAttr(sL, 0.0)
            cmds.setAttr(sL, lock=True)


    cmds.rotate(fRotate[0], fRotate[1], fRotate[2], sLoc, r=True, os=True)
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))
    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        cmds.parent(sSkinningSphere, sParent)




# def updateAudioDict(fJawOpenFactor):
#     xDict = locals()
#     print 'xDict: ', xDict
#
#     sDicts = []
#     for sK,fV in xDict.items():
#         sV = ['%0.3f' % fV for fV in utils.toList(fV)]
#         sDicts.append('%s?%s' % (sK, '?'.join(sV)))
#
#     cAudio = ctrls7.ctrlFromName('ctrl_m_audio')
#     sDictString = '/'.join(sDicts)
#     sDictAttr = utils.addStringAttr(cAudio.sCtrl, '__dict__', utils.encodeAudioLipsString(sDictString))
#     cmds.setAttr(sDictAttr, lock=True)


def printEncodedDict(_report=None):
    xDict = utils.createDictFromDecodedAudioLipsString(cmds.getAttr('grp_m_audioPasser.__dict__'))
    if _report:
        _report.addLogText(str(xDict))
    print(xDict)



def updateFffValuesClosed(_uiArgs=None, _report=None):
    sCtrl = 'botLip_ctrl'
    fValues = [cmds.getAttr('%s.%s' % (sCtrl,sA)) for sA in ['ty','tz','rx']]
    _uiArgs['fFffClosed'].setText(str(fValues))


def goToFffClosedValues(fFffClosed, sJawOpenAxis):
    print('go to fff closed values', fFffClosed)
    cmds.setAttr('jaw_ctrl.%s' % sJawOpenAxis, 0.0)
    sCtrl = 'botLip_ctrl'
    [cmds.setAttr('%s.%s' % (sCtrl,sA),fV) for sA,fV in zip(['ty','tz','rx'], fFffClosed)]

updateFffValuesClosed.dSideButtons = {'pose to':goToFffClosedValues}


def updateFffValuesOpen(fJawMaxOpen, sJawOpenAxis, _uiArgs=None, _report=None):
    cmds.setAttr('jaw_ctrl.%s' % sJawOpenAxis, fJawMaxOpen * 0.25)
    sCtrl = 'botLip_ctrl'
    fValues = [cmds.getAttr('%s.%s' % (sCtrl,sA)) for sA in ['ty','tz','rx']]
    _uiArgs['fFffQuaterJaw'].setText(str(fValues))


def goToFffOpenValues(fJawMaxOpen, sJawOpenAxis, fFffQuaterJaw):
    print('go to fff closed values', fFffQuaterJaw)
    cmds.setAttr('jaw_ctrl.%s' % sJawOpenAxis, fJawMaxOpen * 0.25)
    # cmds.setAttr('audio_ctrl.jawOpen', fJawMaxOpen*0.25)
    sCtrl = 'botLip_ctrl'
    [cmds.setAttr('%s.%s' % (sCtrl,sA),fV) for sA,fV in zip(['ty','tz','rx'], fFffQuaterJaw)]
updateFffValuesOpen.dSideButtons = {'pose to':goToFffOpenValues}


def setMouthCtrlsToDefault(sJawOpenAxis):
    cmds.setAttr('jaw_ctrl.%s' % sJawOpenAxis, 0.0)
    sCtrl = 'botLip_ctrl'
    [cmds.setAttr('%s.%s' % (sCtrl,sA), 0) for sA in ['ty','tz','rx']]

kBpGroupName = '_grp_m_audioBps'
kBpFileName = 'audioBps.ma'

def SelectAudioFffJoint():
    cmds.select(['jnt_m_audioFff'])


dButtons = OrderedDict()
dButtons['print dict'] = printEncodedDict
dButtons['Fill F values on jaw.rx=0 from Scene'] = updateFffValuesClosed
dButtons['Fill F values on jaw.rx=fJawMaxOpen*0.25 from Scene'] = updateFffValuesOpen
dButtons['go to default'] = setMouthCtrlsToDefault
dButtons['Create Audio Fff Bp'] = lambda: createMatrixCtrlromSelectedPoints('bp_m_audioFff', kBpGroupName, bLockToMiddle=True)
dButtons['Select Audio Fff for Skin'] = SelectAudioFffJoint
dButtons['Export BPs'] = lambda: exportBps(kBpFileName, kBpGroupName)


def _getCombinedAttr(cC, sAttr):
    if sAttr.startswith('translate') or sAttr.startswith('rotate') or sAttr.startswith('scale'):
        sCombinedAttr = '%s.%sCombined%s' % (cC.sPasser, sAttr[:-1], sAttr[-1])
        if cmds.objExists(sCombinedAttr):
            return sCombinedAttr
    else:
        return None



def _setAsAudioCtrl(sCtrl):
    for sC in utils.toList(sCtrl):
        if isinstance(sC, ctrls7.TbCtrl):
            sC = sC.sCtrl
        cmds.addAttr(sC, ln='bIsAudioCtrl', at='bool', defaultValue=True, k=False)






kTongueBpGroupName = '_grp_m_tongueBps'

dButtons = {}
def createTongueTargetLocators():
    # sBlueprints = cmds.ls('jnt_m_tongueSpine_???', et='joint')


    sCtrls = sorted(cmds.ls('tongueSplineFk_?_ctrl'))
    if len(sCtrls) != 3:
        raise Exception('you need an fkSpline with 3 controls')

    fSliderScale = xforms.distanceBetween(sCtrls[0], sCtrls[-1]) * 1.25

    sBackUp = xforms.createLocator('bp_tongueTarget_back_up', sMatch=sCtrls[0])
    cmds.move(0, fSliderScale * 0.25, 0, sBackUp, r=True, ws=True)
    cmds.rotate(8,0,0, sBackUp, r=True, os=True)

    sFrontS = xforms.createLocator('bp_tongueTarget_front_s', sMatch=sCtrls[2])
    cmds.move(0, fSliderScale * 0.12, 0, sFrontS, r=True, ws=True)

    sFrontUp = xforms.createLocator('bp_tongueTarget_front_up', sMatch=sCtrls[2])
    cmds.move(0, fSliderScale * 0.25, 0, sFrontUp, r=True, ws=True)

    sFrontTh = xforms.createLocator('bp_tongueTarget_front_th', sMatch=sCtrls[2])
    cmds.move(0, fSliderScale * 0.2, fSliderScale * 0.25, sFrontTh, r=True, ws=True)

    sAllLocs = [sBackUp, sFrontS, sFrontUp, sFrontTh]
    fScale = fSliderScale * 0.1
    [cmds.setAttr('%s.localScale' % sL, fScale, fScale, fScale) for sL in sAllLocs]
    cmds.parent(sAllLocs, xforms.createOrReturnTopGroup(kTongueBpGroupName))


def selectTongueTargetLocators():
    cmds.select( 'bp_tongueTarget_front_s', 'bp_tongueTarget_front_up', 'bp_tongueTarget_front_th', 'bp_tongueTarget_back_up')



@builderTools.addToBuild(iOrder=63.6, dButtons={'create blueprints':createTongueTargetLocators, 'select bluerpints':selectTongueTargetLocators, 'Export BPs':lambda:exportBps('tongueAudioBps.ma', kTongueBpGroupName)})
def setupTongue(sFrontCtrl='tongueSplineFk_C_ctrl', sBackCtrl='tongueSplineFk_B_ctrl'):
    sGroup = cmds.createNode('transform', n='grp_tongueSpeech', p='modules')

    # front tongue
    #
    cFrontCtrl = ctrls7.ctrlFromName(utils.toList(sFrontCtrl)[0])
    sFrontBps = ['bp_tongueTarget_front_up', 'bp_tongueTarget_front_s', 'bp_tongueTarget_front_th']
    sFrontLocs = []
    for i,sParentJoint in enumerate(['jnt_m_headMain', 'jnt_m_jawMain', 'jnt_m_headMain']):
        sLoc = xforms.createLocator(utils.replaceStringStart(sFrontBps[i], 'bp_', 'loc_'), sMatch=sFrontBps[i], sParent=sGroup)
        sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sFrontBps[i], cmds.getAttr('%s.worldInverseMatrix' % sParentJoint), '%s.worldMatrix' % sParentJoint])
        nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sLoc, sTargetRot='%s.r' % sLoc)
        sFrontLocs.append(sLoc)

    sFrontNames = ['tongueFrontUp', 'tongueFrontS', 'tongueFrontTh']
    sOffset = cFrontCtrl.appendOffsetGroup('speech')
    sOffsetParent = cmds.listRelatives(sOffset, p=True)[0]
    sConstraint = cmds.parentConstraint([sOffsetParent]+sFrontLocs, sOffset)[0]
    cmds.setAttr('%s.interpType' % sConstraint, 2)

    sAdditions = [1.0]
    for i,sLoc in enumerate(sFrontLocs):
        sAttr = utils.addAttr(cFrontCtrl.sCtrl, ln=sFrontNames[i], minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
        cmds.connectAttr(sAttr, '%s.%sW%d' % (sConstraint, sLoc, i+1))
        sAdditions.append(sAttr)
    sDefault = nodes.createAdditionNode(sAdditions, sOperation='minus')
    nodes.createClampNode(sDefault, 0, 1, sTarget='%s.%sW0' % (sConstraint, sOffsetParent))


    # back tongue
    #
    cBackCtrl = ctrls7.ctrlFromName(utils.toList(sBackCtrl)[0])
    sBackBp = 'bp_tongueTarget_back_up'
    sBackLoc = xforms.createLocator('loc_tongueTarget_back_up', sMatch=sBackBp, sParent=sGroup)
    sParentJoint = 'jnt_m_headMain'
    sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sBackBp, cmds.getAttr('%s.worldInverseMatrix' % sParentJoint), '%s.worldMatrix' % sParentJoint])
    nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sBackLoc, sTargetRot='%s.r' % sBackLoc)
    sOffset = cBackCtrl.appendOffsetGroup('speech')
    xforms.constraintBlend(sOffset, cmds.listRelatives(sOffset, p=True)[0], sBackLoc, cFrontCtrl.sCtrl, 'tongueBackUp')


    if cmds.attributeQuery('maxSretch', node=cFrontCtrl.sCtrl, exists=True):
        cmds.setAttr('%s.maxStretch' % cFrontCtrl.sCtrl, 10)



@builderTools.addToBuild(iOrder=999.1, dButtons=dButtons)
def cleanTongue():
    if cmds.objExists(kTongueBpGroupName):
        sBps = cmds.listRelatives(kTongueBpGroupName, c=True) or []
        nodes.deleteConnectionsAndItself3(sBps)



sSetupNodeName = '__speechMachineSetup__'

def fillSetupNodeCommands(_uiArgs=None):
    sSel = cmds.ls(sl=True)
    sNamespace = utils.getNamespace(sSel[0])
    sSetupNode = '%s%s' % (sNamespace, sSetupNodeName)

    sAttributes = cmds.listAttr('%s__speechMachineSetup__' % sNamespace, userDefined=True)
    sLines = []
    print('\n\n\n #CODE FOR GENERATING SETUPNODE\n')
    print("cmds.createNode('transform', n='%s')" % sSetupNode)
    for sA in sAttributes:
        sAttr = '%s.%s' % (sSetupNode, sA)
        sType = cmds.addAttr(sAttr, q=True, at=True)
        if sType == 'typed':
            sDataType = cmds.addAttr(sAttr, q=True, dt=True)[0]
            sLines.append(f"cmds.addAttr('{sSetupNodeName}', ln='{sA}', dt='{sDataType}')")
            sLines.append(f"cmds.setAttr('{sAttr.split(':')[-1]}', \"{cmds.getAttr(sAttr)}\", type='string')")
        else:
            sLines.append(f"cmds.addAttr('{sSetupNodeName}', ln='{sA}', at='{sType}')")
            sLines.append(f"cmds.setAttr('{sAttr.split(':')[-1]}', {cmds.getAttr(sAttr)})")

    for sLine in sLines:
        print(sLine)
    _uiArgs['sCommands'].setText(str(sLines))



@builderTools.addToBuild(iOrder=164, dButtons={'Fill Commands with Setup Node':fillSetupNodeCommands})
def createSetupNode(sCommands=[]):
    if cmds.objExists(sSetupNodeName):
        cmds.select(sSetupNodeName)
        raise Exception('Setup node already exists')

    cmds.createNode('transform', n='__speechMachineSetup__', p=utils.getMasterName())

    for sLine in sCommands:
        eval(sLine)

    # sJoined = ''.join(['%s\n' % sLine.strip("'") for sLine in sCommands])
    # print (sJoined)
    # eval(sJoined)

