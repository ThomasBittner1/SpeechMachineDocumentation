###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import kangarooTools.utilFunctions as utils
QtWidgets, QtGui, QtCore = utils.importQtModules()
import kangarooTools.utilsQt as utilsQt

from collections import defaultdict, OrderedDict
import numpy as np
import os
import random

import kangarooTabTools.builder as builderTools

import maya.cmds as cmds
import kangarooTools.report as report
import kangarooTools.curves as curves
import kangarooTools.nodes as nodes
import kangarooTools.constraints as constraints
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.weights as weights
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.geometry as geometry
import kangarooTools.defaultAttributes as defaultAttributes


kBuilderColor = utils.uiColors.green



kDynamicsGroupAttr = 'sDynamicsGroup'


@builderTools.addToBuild(iOrder=12)
def fingerBlendJoints(sExcludeJointsWithStrings=[]):
    sOrients = []
    for s, sSide in enumerate(['l','r']):
        sJoints = [sJ for sJ in cmds.listRelatives('jnt_%s_armWrist' % sSide, ad=True, typ='joint')
                   if not sJ.endswith('END') and not sJ.endswith('End') and not sJ.endswith('Fingers') and not sJ.endswith('Scale')]

        for sJ in sJoints:
            bSkip = False
            for sExcludeString in sExcludeJointsWithStrings:
                if sExcludeString in sJ:
                    bSkip = True
                    break
            if bSkip:
                continue

            sOrient = cmds.createNode('joint', name='%sBlend' % sJ, p=sJ)
            cmds.setAttr('%s.t' % sOrient, 0, 0, 0)
            sOrients.append(sOrient)
            cmds.setAttr('%s.radius' % sOrient, cmds.getAttr('%s.radius' % sJ) * 2.5)
            nodes.createVectorMultiplyNode('%s.r' % sJ, -0.5, bVectorByScalar=True, sTarget='%s.r' % sOrient, sName=sJ)

            utils.addAttr(sOrient, ln='unrealBlendJoint', at='bool', defaultValue=True)
            utils.addStringAttr(sOrient, 'blendFrom', sJ)
            utils.addStringAttr(sOrient, 'blendTo', cmds.listRelatives(sJ, p=True, c=False)[0])
            utils.addAttr(sOrient, ln='blendWeight', defaultValue=0.5)



dButtons = {}
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsBlendJoints', 'dDefaultSettings')

@builderTools.addToBuild(iOrder=12, dButtons=dButtons)
def limbBlendJoints(sLeftJoints = [], dDefaultSettings={}):
    sMainGrp = cmds.createNode('transform', n='grp_m_blendJoints', p='skeleton')
    sSkipped = []
    sDefaultSettingAttrsBlendJoints = []
    for sJoint in list(set(sLeftJoints)):

        if isinstance(sJoint, list):
            sJoint, sParentJoint = sJoint
        else:
            sJoint, sParentJoint = sJoint, None
        for s, sSide in enumerate(['l','r']):
            if sSide == 'r':
                sSideJoint = utils.getMirrorName(sJoint)
                if sSideJoint == sJoint or not cmds.objExists(sSideJoint):
                    continue

            else:
                sSideJoint = sJoint

            if not cmds.objExists(sSideJoint):
                report.report.addLogText('skipping %s, because joint doesn\'t exist' % sSideJoint)
                sSkipped.append(sSideJoint)
                continue

            sGrp = cmds.createNode('transform', n='%sBlend' % utils.replaceStringStart(sSideJoint, 'jnt_', 'grp_'), p=sMainGrp)
            sParent = cmds.createNode('transform', n='%sBlendParent' % utils.replaceStringStart(sSideJoint, 'jnt_', 'grp_'), p=sGrp) # -p is temporary for placing
            sBlendGrp = cmds.createNode('transform', n='%sBlendBlend' % utils.replaceStringStart(sSideJoint, 'jnt_', 'grp_'), p=sGrp) # -p is temporary for placing
            sBlendJoint = cmds.createNode('joint', name='%sBlend' % sSideJoint, p=sSideJoint)
            xforms.matrixParentConstraint(sSideJoint, sGrp)
            cmds.parent(sParent, sBlendGrp, sMainGrp)

            sParentSideJoint = cmds.listRelatives(sSideJoint, p=True)[0]
            sParentAttr = utils.addStringAttr(sBlendJoint, 'sParentBlendJoint', sParentSideJoint)
            sDefaultSettingAttrsBlendJoints.append(sParentAttr)
            if sParentAttr in dDefaultSettings:
                sParentSideJoint = dDefaultSettings[sParentAttr]
                cmds.setAttr(sParentAttr, sParentSideJoint, type='string')


            xforms.matrixParentConstraint(sParentSideJoint, sParent, mo=True, skipScale=['x','y','z'])
            xforms.matrixParentConstraint(sParentSideJoint, sBlendGrp, mo=True, skipRotate=['x','y','z'], skipScale=['x','y','z'])

            sOrientBlendAttr = xforms.constraintBlend(sBlendGrp, sGrp, sParent, sBlendJoint, 'blend', func=cmds.orientConstraint, fDefault=0.5)
            sPositionBlendAttr = xforms.constraintBlend(sBlendGrp, sGrp, sParent, sBlendJoint, 'blendPos', func=cmds.pointConstraint, fDefault=0.5)
            if sOrientBlendAttr in dDefaultSettings:
                cmds.setAttr(sOrientBlendAttr, dDefaultSettings[sOrientBlendAttr])
            if sPositionBlendAttr in dDefaultSettings:
                cmds.setAttr(sPositionBlendAttr, dDefaultSettings[sPositionBlendAttr])

            sDefaultSettingAttrsBlendJoints.extend([sOrientBlendAttr, sPositionBlendAttr])

            xforms.matrixParentConstraint(sBlendGrp, sBlendJoint, skipScale=['x','y','z'])

            cmds.setAttr('%s.radius' % sBlendJoint, cmds.getAttr('%s.radius' % sSideJoint)*3)

            # do we need those???
            # utils.addAttr(sBlendJoint, ln='unrealBlendJoint', at='bool', defaultValue=True)
            # utils.addStringAttr(sBlendJoint, 'blendFrom', sSideJoint)
            # utils.addStringAttr(sBlendJoint, 'blendTo', sParentSideJoint)
            # utils.addAttr(sBlendJoint, ln='blendWeight', defaultValue=0.5)

    utils.data.store('sDefaultSettingAttrsBlendJoints', sDefaultSettingAttrsBlendJoints)

    if sSkipped:
        return False




#
# START FINGER POSES
#

def fillFingerPose(ddPoses, sPoseDictName, bMirrorLeftToRight, sAllFingerCtrls, _uiArgs):
    sSelBefore = cmds.ls(sl=True)
    # if bMirrorLeftToRight:
    #     sFingerModules = [sM for sM in utils.getModulesOfType('LFinger') if '_l_' in sM or sM.startswith('l_')]
    # else:
    #     sFingerModules = [sM for sM in utils.getModulesOfType('LFinger')]
    #
    # sFingerModules = [sM for sM in sFingerModules if '_toe' not in sM]
    # sAllCtrls = reduce(lambda a,b:a+b, [eval(cmds.getAttr('%s.__ctrls__' % sM)) for sM in sFingerModules])

    sAllFingerCtrls = [sC for sC in sAllFingerCtrls if cmds.objExists(sC)]
    cAllFingerCtrls = [ctrls7.ctrlFromName(sC) for sC in sAllFingerCtrls]
    cmds.select(sAllFingerCtrls)

    dOutDict = {}
    for cCtrl in cAllFingerCtrls:
        # sOffset = cCtrl.getOffsetByName('poses', bReturnNoneIfNotExists=True)
        fRotate = np.array(cmds.getAttr('%s.r' % cCtrl.sCtrl)[0], dtype='float64')
        if max(np.abs(fRotate)) > 0.001: # np.any(fRotate):
            dOutDict['%s.r' % cCtrl.sCtrl] = [round(v,5) for v in fRotate]

        fTranslate = np.array(cmds.getAttr('%s.t' % cCtrl.sCtrl)[0], dtype='float64')
        if max(np.abs(fTranslate)) > 0.001:
            dOutDict['%s.t' % cCtrl.sCtrl] = [round(v,5) for v in fTranslate]
    ddPoses[sPoseDictName] = dOutDict
    _uiArgs['ddPoses'].setText(str(ddPoses))
    cmds.select(sSelBefore)


def convertFingerPoses(ddPoses, _uiArgs=None):
    dRename = {}
    dRename['dCurlPositive'] = 'armGlobalLFT_ctrl.curl'
    dRename['dCurlNegative'] = 'armGlobalLFT_ctrl.curl negative'
    dRename['dSpreadPositive'] = 'armGlobalLFT_ctrl.spread'
    dRename['dSpreadNegative'] = 'armGlobalLFT_ctrl.spread negative'
    dRename['dBaseCurl'] = 'armGlobalLFT_ctrl.baseCurl'

    for sOld, sNew in dRename.items():
        ddPoses[sNew] = ddPoses.pop(sOld)

    _uiArgs['ddPoses'].setText(str(ddPoses))


def resetFingerPoses(sAllFingerCtrls):
    # sFingerModules = [sM for sM in utils.getModulesOfType('LFinger')]
    # sFingerModules = [sM for sM in sFingerModules if '_toe' not in sM]
    # sAllCtrls = reduce(lambda a,b:a+b, [eval(cmds.getAttr('%s.__ctrls__' % sM)) for sM in sFingerModules])
    ctrls7.goToDefault(sAllFingerCtrls)


def populateFingerValues(dDict):

    cmds.undoInfo(openChunk=True)
    try:
        sCtrls = [sCtrl for sCtrl in cmds.controller(q=True, ac=True)]
        print ('sCtrls: ', sCtrls)
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA,fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)

        for sAttr, fValues in list(dDict.items()):
            for a,sA in enumerate(['x','y','z']):
                sAttribute = '%s%s' % (sAttr, sA)
                print ('setting value for %s: %0.3f' % (sAttribute, fValues[a]))
                try:
                    cmds.setAttr(sAttribute, fValues[a])
                except Exception as e:
                    print ('skipping - %s' % str(e))
                    pass
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


def populateFingerPoseUI(_sListKey, ddPoses, dCustomRanges):
    if _sListKey not in ddPoses:
        report.report.addLogText('\n =============== "%s" is not specified yet =============== ' % _sListKey)

    populateFingerValues(ddPoses.get(_sListKey, {}))

    sCreatedAttrs = utils.data.get('sFingerPosesCreatedAttrs', xDefault=[])
    sAttr = _sListKey.split(' ')[0]

    # why was this there??
    # if sAttr not in sCreatedAttrs and cmds.objExists(sAttr):
    #     cmds.setAttr(sAttr, dCustomRanges.get(sAttr, 10))


def fillFingerPoseUI(_sListKey, ddPoses, bMirrorLeftToRight, sAllFingerCtrls, _uiArgs=None):
    fillFingerPose(ddPoses, _sListKey, bMirrorLeftToRight, sAllFingerCtrls, _uiArgs)
fillFingerPoseUI.dSideButtons = {'pose':populateFingerPoseUI}

dListButtons = OrderedDict()
dListButtons['fill %s'] = fillFingerPoseUI

sAllFingerCtrlsDefault = ['thumbMidLFT_ctrl', 'ringMidLFT_ctrl', 'middleTipLFT_ctrl', 'pinkyTipLFT_ctrl', 'indexBaseIkLFT_ctrl', 'middleBaseIkLFT_ctrl',
                          'pinkyMidLFT_ctrl', 'pinkyBaseIkLFT_ctrl', 'ringTipLFT_ctrl', 'indexMidLFT_ctrl', 'ringBaseLFT_ctrl', 'middleMidLFT_ctrl',
                          'indexBaseLFT_ctrl', 'thumbMetaLFT_ctrl', 'indexTipLFT_ctrl', 'pinkyBaseLFT_ctrl', 'ringBaseIkLFT_ctrl', 'middleBaseLFT_ctrl', 'thumbBaseLFT_ctrl']

@builderTools.addToBuild(iOrder=105, dButtons={'reset':resetFingerPoses, 'convert':convertFingerPoses}, xListButtons=['sPoseKeys', dListButtons], bCanGetDuplicated=True)
def fingerPoses(sPoseKeys=['armGlobalLFT_ctrl.curl', 'armGlobalLFT_ctrl.curl negative', 'armGlobalLFT_ctrl.baseCurl', 'armGlobalLFT_ctrl.spread', 'armGlobalLFT_ctrl.spread negative'], ddPoses={}, sAllFingerCtrls=sAllFingerCtrlsDefault,
                bMirrorLeftToRight=True, dSeparateFingers={'armGlobalLFT_ctrl.curl':['thumb', 'index', 'middle', 'ring', 'pinky']}, dCustomDrivers={}, dCustomRanges={}, bOrderByFingers=False):
    '''
    Pose the fingers into each pose and use the fill buttons at the top to generate the dictionaries in the bottom left.

    -- Mirror --
    Set bMirrorLeftToRight to True, and only work on the left side. He will create the poses in the main function on the \
    right side automatically.

    -- Asymmetry --
    Set bMirrorLeftToRight to False, and for each pose, make sure you pose the fingers of both hands

    To add more pose attributes, adjust the sPoseKeys parameter. To get attributes that also go to negative, just \
    add an additional pose key followed by ' negative'.

    '''
    for s,sSide in enumerate(['l', 'r']):
        sCreatedAttrs = []
        dAttrs = {}
        dPoseKeys = defaultdict(list)
        sDriverLimbs = set()
        for sPoseKey in sPoseKeys:
            sGlobalCtrl, sKey = sPoseKey.split('.')
            sGlobalCtrl = ctrls7.ctrlFromName(sGlobalCtrl).sCtrl

            # getting driverLimb for Unreal
            sLimbAttr = '%s.sLimbCtrl' % sGlobalCtrl
            if cmds.objExists(sLimbAttr):
                sLimb = cmds.getAttr(sLimbAttr)
                if sSide == 'r':
                    sLimb = utils.getMirrorName(sLimb)
                sDriverLimbs.add(sLimb)

            if s == 1:
                sGlobalCtrl = utils.getMirrorName(sGlobalCtrl)
            if not sKey.endswith(' negative'):
                sAttrName = sKey
                sAttr = '%s.%s' % (sGlobalCtrl, sAttrName)
                if not cmds.objExists(sAttr):
                    fMax = dCustomRanges.get(sPoseKey, 10.0)
                    fMin = dCustomRanges.get('%s negative' % sPoseKey, 0.0)
                    utils.addAttr(sGlobalCtrl, ln=sAttrName, at='double', defaultValue=0.0, minValue=fMin, maxValue=fMax, k=True)
                    sCreatedAttrs.append(sAttr)

                dAttrs[sKey] = sAttr
                dPoseKeys[sAttrName].append(sKey)
        if len(sDriverLimbs) != 1:
            raise Exception('There needs to be one driver limb, but there\'s: %s' % list(sDriverLimbs))
        sDriverLimb = sDriverLimbs.pop()

        sUnrealAttrs = list(sCreatedAttrs)

        for sPoseKey in sPoseKeys:
            sGlobalCtrl, sKey = sPoseKey.split('.')
            sGlobalCtrl = ctrls7.ctrlFromName(sGlobalCtrl).sCtrl
            if s == 1:
                sGlobalCtrl = utils.getMirrorName(sGlobalCtrl)
            if sKey.endswith(' negative'):
                sAttrName = sKey.split(' ')[0]
                sAttr = '%s.%s' % (sGlobalCtrl, sAttrName)
                try:
                    cmds.addAttr(sAttr, e=True, minValue=-5.0)
                except:
                    pass
                dAttrs[sKey] = sAttr
                dPoseKeys[sAttrName].append(sKey)


        dProducts = defaultdict(list)
        dUnrealProducts = defaultdict(list)
        sMissingPoseKeys = []
        for sPoseKey in sPoseKeys:
            sKey = sPoseKey.split('.')[1]

            if sPoseKey in dCustomRanges:
                fRangeMax = dCustomRanges[sPoseKey]
            else:
                fRangeMax = -5 if sKey.endswith(' negative') else 10

            if sPoseKey in dCustomDrivers:
                sCustomDriver = dCustomDrivers[sPoseKey]
                if s == 1:
                    sCustomDriver = utils.getMirrorName(sCustomDriver)
                fStartDriven = cmds.getAttr(sCustomDriver)
                cmds.setAttr(dAttrs[sKey], fRangeMax)
                fEndDriven = cmds.getAttr(sCustomDriver)
                cmds.setAttr(dAttrs[sKey], 0)
                sDriver = nodes.createRangeNode(sCustomDriver, fStartDriven, fEndDriven, 0, 1)
            else:
                sDriver = nodes.createRangeNode(dAttrs[sKey], 0, fRangeMax, 0, 1)
            if sPoseKey not in ddPoses:
                sMissingPoseKeys.append(sPoseKey)
                continue
            for sCtrlAttr, fValue in list(ddPoses.get(sPoseKey, {}).items()):
                if bMirrorLeftToRight:
                    if s == 1:
                        sCtrlAttr = utils.getMirrorName(sCtrlAttr)
                else:
                    sCurrentSide = utils.getSide(sCtrlAttr)
                    if s == 0 and sCurrentSide != 'l':
                        continue
                    elif s == 1 and sCurrentSide != 'r':
                        continue
                dProducts[sCtrlAttr].append(nodes.createVectorMultiplyNode(fValue, sDriver, bVectorByScalar=True))

                sPoseKeySide = sPoseKey
                if s==1:
                    sPoseKeySide = utils.getMirrorName(sPoseKey)
                if sCtrlAttr.endswith('.r'):
                    dUnrealProducts[sCtrlAttr].append((sPoseKeySide, (-fValue[0], -fValue[2], -fValue[1])))
                elif sCtrlAttr.endswith('.t'):
                    dUnrealProducts[sCtrlAttr].append((sPoseKeySide, (fValue[0], fValue[2], fValue[1])))
                else:
                    raise Exception('not sure what to do with attribute "%s"' % sCtrlAttr)
        utils.data.store('%s_dFingerPosesUnrealProducts' % sDriverLimb, dict(dUnrealProducts))
        utils.data.store('%s_dFingerPosesUnrealDriverAttrs' % sDriverLimb, sUnrealAttrs)
        utils.data.addToList('unrealFingerDriverLimbs', [sDriverLimb], )
        def addAttribute(sGlobalCtrl, sAttr, sSeparateKey, sFinger):
            sFingerCurl = utils.addAttr(sGlobalCtrl, ln='%s%s' % (sAttr, utils.getFirstLetterUpperCase(sFinger)), at='double', defaultValue=0,
                                        minValue=-5 if len(dPoseKeys[sSeparateKey.split('.')[-1]]) == 2 else 0, maxValue=10, k=True)

            for sPoseKey in sPoseKeys:
                if sPoseKey.split(' ')[0] == sSeparateKey:
                    sDriver = nodes.createRangeNode(sFingerCurl,
                                                    0, -5 if sPoseKey.endswith(' negative') else 10,
                                                    0, 1, sName='%s__%s' % (sFinger, sPoseKey))

                    for sCtrlAttr, fValue in list(ddPoses.get(sPoseKey, {}).items()):
                        if not sCtrlAttr.startswith(sFinger):
                            continue

                        if bMirrorLeftToRight:
                            if s == 1:
                                sCtrlAttr = utils.getMirrorName(sCtrlAttr)
                        else:
                            sCurrentSide = utils.getSide(sCtrlAttr)
                            if s == 0 and sCurrentSide != 'l':
                                continue
                            elif s == 1 and sCurrentSide != 'r':
                                continue
                        dProducts[sCtrlAttr].append(nodes.createVectorMultiplyNode(fValue, sDriver, bVectorByScalar=True))

        if bOrderByFingers:
            dFingers = defaultdict(list)
            for sSeparateKey, sFingers in dSeparateFingers.items():
                for sFinger in sFingers:

                    sGlobalCtrl, sAttr = sSeparateKey.split('.')
                    sGlobalCtrl = ctrls7.ctrlFromName(sGlobalCtrl).sCtrl
                    if s == 1:
                        sGlobalCtrl = utils.getMirrorName(sGlobalCtrl)
                    dFingers[sFinger].append((sGlobalCtrl, sAttr, sSeparateKey))

            for sFinger, xAttrs in dFingers.items():
                for xAttr in xAttrs:
                    addAttribute(xAttr[0], xAttr[1], xAttr[2], sFinger)

        else:
            for sSeparateKey, sFingers in dSeparateFingers.items():
                for sFinger in sFingers:
                    sGlobalCtrl, sAttr = sSeparateKey.split('.')
                    sGlobalCtrl = ctrls7.ctrlFromName(sGlobalCtrl).sCtrl
                    if s == 1:
                        sGlobalCtrl = utils.getMirrorName(sGlobalCtrl)

                    addAttribute(sGlobalCtrl, sAttr, sSeparateKey, sFinger)


        for sCtrlAttr, sProducts in list(dProducts.items()):
            sCtrl, sA = sCtrlAttr.split('.')
            if not cmds.objExists(sCtrl):
                continue
            cCtrl = ctrls7.ctrlFromName(sCtrl)
            sOffset = cCtrl.appendOffsetGroup('poses')
            nodes.createVectorAdditionNode(sProducts, sTarget='%s.%s' % (sOffset, sA.split('.')[-1]), bForce=True)

    for sPoseKey in set(sMissingPoseKeys):
        report.report.addLogText('"%s" is not setup-ed in ddPoses (use the buttons to fill the pose)' % sPoseKey)

    utils.data.store('sFingerPosesCreatedAttrs', sCreatedAttrs)

    if sMissingPoseKeys:
        return False

#
# END FINGER POSES
#


@builderTools.addToBuild(iOrder=106.5, dButtons={}, bCanGetDuplicated=True, bDisableByDefault=True)
def separateFingerAttributes(sGlobal='armGlobalLFT_ctrl', sFingers=[], bFingersAreSpines=False):
    if bFingersAreSpines:
        sBones = ['A', 'B', 'C', 'D']
    else:
        sBones = ['Base', 'Mid', 'Tip']
    
    for s,sSide in enumerate(['l','r']):
        if sSide == 'r':
            sGlobal = utils.getMirrorName(sGlobal)
        for sFinger in sFingers:
            for b,sBone in enumerate(sBones):
                sCtrl = '%s%s%s_ctrl' % (sFinger, sBone, utils.sSides3[s])
                cCtrl = ctrls7.ctrlFromName(sCtrl, bReturnNoneIfNotExists=True)
                if utils.isNone(cCtrl):
                    continue
                sOffset = cCtrl.appendOffsetGroup('attr')
                if b == 0:
                    utils.addAttr(sGlobal, ln='%s%s_Side' % (sFinger,sBone), k=True, sTarget='%s.rz' % sOffset)
                utils.addAttr(sGlobal, ln='%s%s_Bend' % (sFinger,sBone), k=True, sTarget='%s.rx' % sOffset)


def flipMuscleBlueprint():
    sBlueprints = cmds.ls(sl=True)
    for sJ in sBlueprints:
        sChild = cmds.listRelatives(sJ, c=True, typ='joint')[0]
        fChildPos = cmds.xform(sChild, q=True, ws=True, t=True)
        cmds.setAttr('%s.t' % sJ, *fChildPos)
        cmds.rotate(0, 0, 180, sJ, r=True, os=True)
        sStartSpaceAttr = '%s.startSpace' % sJ
        sEndSpaceAttr = '%s.endSpace' % sJ
        if cmds.objExists(sStartSpaceAttr) and cmds.objExists(sEndSpaceAttr):
            sStartSpace = cmds.getAttr(sStartSpaceAttr)
            sEndSpace = cmds.getAttr(sEndSpaceAttr)
            cmds.setAttr(sStartSpaceAttr, sEndSpace, type='string')
            cmds.setAttr(sEndSpaceAttr, sStartSpace, type='string')
        else:
            raise Exception('no attrs')
        
        
def selectedToAttr(sAttrName, bFirstToAll=True):
    try:
        sSel = cmds.ls(sl=True, et='joint')
        sMuscles = [sJ for sJ in sSel if sJ.startswith('muscleJnt_')]
        if len(sMuscles):
            raise Exception('you have muscles selected (%s), \nplease select their blueprints (muscleBp_..) instead' % utils.listToString(sMuscles, iMaxCount=3))
    
        sMuscleBps = [sJ for sJ in sSel if sJ.startswith('muscleBp_')]
        sSpaces = [sJ for sJ in sSel if not sJ.startswith('muscleBp_')]
    
        if not sSpaces:
            raise Exception('need to select a space joint (the one that drives it)')
    
        for sM in sMuscleBps:
            report.report.addLogText(' === setting %s as parent for %s (%s) === ' % (sM, sSpaces[0], sAttrName))
            utils.addStringAttr(sM, sAttrName, sSpaces[0])
    except Exception as e:
        cmds.confirmDialog(m=str(e))
        raise
    

def addLocationAttrs():
    sJoints = cmds.ls(sl=True, et='joint')
    for sJ in sJoints:
        print(sJ)
        sChild = cmds.listRelatives(sJ, c=True, typ='joint', f=True)[0]
        aPoints = xforms.getPositionArray([sJ, sChild])
        fLocalA = utils.multiplyPositionByMatrix(aPoints[0], '%s.worldInverseMatrix' % cmds.getAttr('%s.startSpace' % sJ))
        fLocalB = utils.multiplyPositionByMatrix(aPoints[1], '%s.worldInverseMatrix' % cmds.getAttr('%s.endSpace' % sJ))

        utils.addStringAttr(sJ, 'localA', str(fLocalA))
        utils.addStringAttr(sJ, 'localB', str(fLocalB))






def moveToLocationAttrs():
    cmds.undoInfo(openChunk=True)

    def _checkIfMissing(sJoint, sObj):
        if not cmds.objExists(sObj):
            report.report.addLogText('skipping %s - %s is missing' % (sJoint, sObj))
            return True
        else:
            return False

    try:
        sJoints = cmds.ls(sl=True, et='joint')
        for sJ in sJoints:
            print(sJ)

            sChild = cmds.listRelatives(sJ, c=True, typ='joint', f=True)[0]
            sLocalAAttr = '%s.localA' % sJ
            sLocalBAttr = '%s.localB' % sJ
            if not cmds.objExists(sLocalAAttr) or not cmds.objExists(sLocalBAttr):
                report.report.addLogText('%s: Warping attributes not found ("%s", "%s")' % (sJ, sLocalAAttr, sLocalBAttr))
                continue

            aLocalA = np.array(eval(cmds.getAttr(sLocalAAttr)), dtype='float64')
            aLocalB = np.array(eval(cmds.getAttr(sLocalBAttr)), dtype='float64')

            sStartAttr = '%s.startSpace' % sJ
            if _checkIfMissing(sJ, sStartAttr): continue
            sEndAttr = '%s.endSpace' % sJ
            if _checkIfMissing(sJ, sEndAttr): continue

            sStartJoint = cmds.getAttr(sStartAttr)
            if _checkIfMissing(sJ, sStartJoint): continue
            sEndJoint = cmds.getAttr(sEndAttr)
            if _checkIfMissing(sJ, sEndJoint): continue

            aWorldA = utils.multiplyPositionByMatrix(aLocalA, '%s.worldMatrix' % sStartJoint, bReturnNumpy=True)
            aWorldB = utils.multiplyPositionByMatrix(aLocalB, '%s.worldMatrix' % sEndJoint, bReturnNumpy=True)

            cmds.move(aWorldA[0], aWorldA[1], aWorldA[2], sJ, ws=True, a=True)
            cmds.move(aWorldB[0], aWorldB[1], aWorldB[2], sChild, ws=True, a=True)

    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def setLimitAttr(sPart):
    sSel = cmds.ls(sl=True)
    selectedToAttr('s%sParentParent' % utils.getFirstLetterUpperCase(sPart))
    sPrefix = 'f%s' % utils.getFirstLetterUpperCase(sPart)




def fixChildNames():
    sJoints = [sJ for sJ in cmds.ls('muscleBp_*', sl=True, et='joint') if not sJ.endswith('End')]
    for sJ in sJoints:
        sChild = cmds.listRelatives(sJ, c=True, typ='joint', f=True)[0]
        cmds.rename(sChild, '%sEnd' % sJ)



def makeMuscleJointBlueprint():
    try:
    
        cmds.undoInfo(openChunk=True)
        for sJ in cmds.ls(sl=True, et='joint'):
            if not sJ.startswith('muscleBp'):
                sSplits = sJ.split('_')
                for sSide in ['l','m','r']:
                    if sSide in sSplits:
                        sSplits.remove(sSide)
                        sNewName = 'muscleBp_%s_%s' % (sSide, '_'.join(sSplits))
                        break
                else:
                    sNewName = 'muscleBp_m_%s' % sJ
                sNewName = utils.getUniqueName(sNewName)

                sJ = cmds.rename(sJ, sNewName)
            sChild = cmds.listRelatives(sJ, c=True, typ='joint', f=True)[0]
            sChild = cmds.rename(sChild, '%sEnd' % sJ)

            cmds.setAttr('%s.jointOrientX' % sChild, k=True)
            cmds.setAttr('%s.jointOrientY' % sChild, k=True)
            cmds.setAttr('%s.jointOrientZ' % sChild, k=True)
            cmds.setAttr('%s.jointOrient' % sChild, 0,0,0)

            # utils.addAttr(sJ, ln='locatorVis', at='bool', defaultValue=True, k=True, bReturnIfExists=True)
            # utils.addOffOnAttr(sJ, 'locatorVis', bDefaultValue=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='stretch', defaultValue=1.0, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='squashYPos', defaultValue=1.0, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='squashYNeg', defaultValue=1.0, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='squashZPos', defaultValue=1.0, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='squashZNeg', defaultValue=1.0, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='squashYMinLimit', defaultValue=0.001, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='squashZMinLimit', defaultValue=0.001, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='splineJointCount', at='long', defaultValue=0, min=0, max=20, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='splineCtrlT', defaultValue=0.5, min=0.0, max=1.0, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='springDamping', defaultValue=0.7, k=True, bReturnIfExists=True)

            if cmds.attributeQuery('springStrength', node=sJ, exists=True) and not cmds.attributeQuery('springStrengthX', node=sJ, exists=True):
                cmds.deleteAttr(sJ, attribute='springStrength')
            utils.addAttr(sJ, ln='springStiffness', defaultValue=0.7, k=True, bReturnIfExists=True)
            utils.addAttr(sJ, ln='springStrength', defaultValue=1.0, at='double3', k=True, bReturnIfExists=True)
            utils.addOffOnAttr(sJ, 'EndLimitPosX', bDefaultValue=False, bReturnNonIfExists=True)
            utils.addOffOnAttr(sJ, 'EndLimitPosY', bDefaultValue=False, bReturnNonIfExists=True)
            utils.addOffOnAttr(sJ, 'EndLimitPosZ', bDefaultValue=False, bReturnNonIfExists=True)
            utils.addOffOnAttr(sJ, 'EndLimitNegX', bDefaultValue=False, bReturnNonIfExists=True)
            utils.addOffOnAttr(sJ, 'EndLimitNegY', bDefaultValue=False, bReturnNonIfExists=True)
            utils.addOffOnAttr(sJ, 'EndLimitNegZ', bDefaultValue=False, bReturnNonIfExists=True)
            utils.addOffOnAttr(sJ, 'attachEnd', bDefaultValue=False, bReturnIfExists=True)
            utils.addStringAttr(sJ, kDynamicsGroupAttr, '', bSkipIfAlreadyThere=True)
            sParents = cmds.listRelatives(sJ, p=True, c=False)

            if not sParents or sParents[0] != 'muscleJointBlueprints':
                cmds.parent(sJ, xforms.createIfNotExists('muscleJointBlueprints'))
            
            cmds.setAttr('%s.ty' % sChild, lock=False)
            cmds.setAttr('%s.tz' % sChild, lock=False)
            cmds.setAttr('%s.ty' % sChild, 0.0)
            cmds.setAttr('%s.tz' % sChild, 0.0)
            # cmds.setAttr('%s.ty' % sChild, lock=True)
            # cmds.setAttr('%s.tz' % sChild, lock=True)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



def removeOldLimitAttrs():
    for sJ in cmds.ls(sl=True):
        for sA in ['endLimitMinX', 'endLimitMinY', 'endLimitMinZ', 'endLimitMaxX', 'endLimitMaxY', 'endLimitMaxZ',
                   'startLimitMinX', 'startLimitMinY', 'startLimitMinZ', 'startLimitMaxX', 'startLimitMaxY', 'startLimitMaxZ']:
            sAttr = '%s.%s' % (sJ, sA)
            if cmds.objExists(sAttr):
                cmds.deleteAttr(sAttr)

def fixScale():
    for sJ in cmds.ls(sl=True, et='joint'):
        fScaleX = cmds.getAttr('%s.sx' % sJ)
        cmds.setAttr('%s.s' % sJ, 1,1,1)
        sChild = cmds.listRelatives(sJ, c=True, typ='joint')[0]
        sTxAttr = '%s.tx' % sChild
        cmds.setAttr(sTxAttr, cmds.getAttr(sTxAttr) * fScaleX)


def selectBlueprintsFromMuscles():
    sJoints = cmds.ls('muscleJnt_*', sl=True, et='joint')
    sBlueprints = [utils.replaceStringStart(sJ, 'muscleJnt_', 'muscleBp_') for sJ in sJoints]
    cmds.select([sBp for sBp in sBlueprints if cmds.objExists(sBp)])



def selectAllMuscleJoints():
    sJoints = [sJ for sJ in cmds.ls('muscleBp_*', et='joint') if sJ.endswith('_start')]
    cmds.select(sJoints)



def exportBps(sFileName, sGroup):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    print('exporting "%s" to "%s" ' % (sGroup, sFile))
    report.report.addLogText('exporting "%s" to "%s" ' % (sGroup, sFile))

    if not os.path.exists(os.path.dirname(sFile)):
        os.makedirs(os.path.dirname(sFile))
    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    utils.removeRequiresLines(sFile)




def moveSkinWeightsSelectedMeshes():
    weights.moveSkinClusterWeights(xJoints={'*Spine_???':'Spine_,SpineSquash_'})







####################################################################
# start muscles
####################################################################

def listAllObjectsOfType(iType):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sMuscleNodes = [sN for sN in sAllNodes if cmds.attributeQuery(kTypeAttrName, node=sN, exists=True)]
    return [sN for sN in sMuscleNodes if cmds.getAttr('%s.%s' % (sN,kTypeAttrName)) == iType]


class objectTypes:
    mainJoint = 0
    partJoint = 1
    splineJoint = 2
    middleControl = 3


kTypeAttrName = 'muscleJointObjectType'




def addTypeAttribute(sObject, iType):
    sAttr = '%s.%s' % (sObject, kTypeAttrName)
    if not cmds.objExists(sAttr):
        sTypes = [sKey for sKey in list(objectTypes.__dict__.keys()) if not sKey.startswith('__')]
        sTypes.sort(key=lambda k:objectTypes.__dict__[k])
        sAttr = '%s.%s' % (sObject, kTypeAttrName)
        if cmds.objExists(sAttr):
            cmds.deleteAttr(sAttr)
        cmds.addAttr(sObject, ln=kTypeAttrName, at='enum', en=':'.join(sTypes), dv=iType)
        cmds.setAttr(sAttr, lock=True)


def rebuildFromSelectedBlueprint():
    sSel = [sJ for sJ in cmds.ls(sl=True, et='joint') if sJ.startswith('muscleBp_')]
    for sJ in sSel:
        createMuscleJoint(sJ)


def transferWeightsToSplineJoints():
    xJoints = {}
    sMuscleJoints = [sJ for sJ in listAllObjectsOfType(objectTypes.mainJoint) if ':' not in sJ]
    print ('sMuscleJoints: ', sMuscleJoints)
    for sJ in sMuscleJoints:
        sSplineJointsAttr = '%s.sSplineJoints' % sJ
        if cmds.objExists(sSplineJointsAttr):
            sSplineJoints = eval(cmds.getAttr(sSplineJointsAttr))
            xJoints[sJ] = ';'.join(sSplineJoints)
    print ('xJoints: ', xJoints)
    weights.moveSkinClusterWeights(xJoints=xJoints)


def transferWeightsToMainJoints():
    xJoints = {}
    sSplineJoints = cmds.ls('muscleJnt_?_*_???')
    for sJ in sSplineJoints:
        xJoints[sJ] = '_[0-9]{3}$,'
    
    weights.moveSkinClusterWeights(xJoints=xJoints)


qDialog = None
def muscleDynamicGroupsMenu():
    qMenu = QtWidgets.QMenu()

    def assignNewGroupToSelected():
        global qDialog
    
        def _assign(sGroupName):
            sBlueprintJoints = cmds.ls('muscleBp_*', sl=True, et='joint')
            for sBp in sBlueprintJoints:
                utils.addStringAttr(sBp, kDynamicsGroupAttr, sGroupName)
        
        qDialog = utilsQt.QGetStringDialog(_assign, sMessage='Enter Name for new Group')
        qDialog.show()

        
    qMenu.addAction('== new group on selected blueprints ==', assignNewGroupToSelected)
    
    sBlueprints = [sJ for sJ in cmds.ls('muscleBp_*', et='joint') if not sJ.endswith('End')]
    dGroups = defaultdict(list)
    for sBp in sBlueprints:
        sGroupAttr = '%s.%s' % (sBp, kDynamicsGroupAttr)
        if cmds.objExists(sGroupAttr):
            sGroup = cmds.getAttr(sGroupAttr).strip()
            if sGroup:
                dGroups[sGroup].append(sBp)
                
    for sGroup, sBps in dGroups.items():
        qGroupMenu = qMenu.addMenu('%s (%d)' % (sGroup, len(sBps)))

        def _rename(sGroup=sGroup):
    
            def _renameGroup(sGroupName, sGroup=sGroup):
                for sBp in dGroups[sGroup]:
                    utils.addStringAttr(sBp, kDynamicsGroupAttr, sGroupName)
        
            global qDialog
            qDialog = utilsQt.QGetStringDialog(_renameGroup, sMessage='Enter Name for new Group', sDefault=sGroup)
            qDialog.show()

        def _select(sGroup=sGroup):
            cmds.select(dGroups[sGroup])

        def _addSelection(sGroup=sGroup):
            sBps = cmds.ls('muscleBp_*', sl=True, et='joint')
            for sBp in sBps:
                utils.addStringAttr(sBp, kDynamicsGroupAttr, sGroup)

        qGroupMenu.addAction('select', _select)
        qGroupMenu.addAction('rename', _rename)
        qGroupMenu.addAction('add selection', _addSelection)


    def selectUnassigned():
        sBlueprintJoints = [sJ for sJ in cmds.ls('muscleBp_*', et='joint') if not sJ.endswith('End')]
        sUnassigned = []
        for sBp in sBlueprintJoints:
            sAttr = '%s.%s' % (sBp, kDynamicsGroupAttr)
            if not cmds.objExists(sAttr):
                sUnassigned.append(sBp)
            elif not cmds.getAttr(sAttr).strip():
                sUnassigned.append(sBp)
        if sUnassigned:
            cmds.select(sUnassigned)
        else:
            cmds.confirmDialog(m='Looks like all muscle joints are assigned')

    qMenu.addAction('select unassigned blueprints', selectUnassigned)

    qCursor = QtGui.QCursor()
    qMenu.exec_(qCursor.pos())


dButtons = OrderedDict()
dButtons['Make Muscle Joint BP'] = makeMuscleJointBlueprint
# dButtons['Mirror Selected Muscle Joints'] = mirrorMuscleJoint
dButtons['Set START Space (selected)'] = lambda: selectedToAttr('startSpace')
# dButtons['Set START Space PARENT (selected)'] = lambda: selectedToAttr('startSpaceParent')
dButtons['Set END Space (selected)'] = lambda: selectedToAttr('endSpace')
dButtons['Set END Space PARENT (selected)'] = lambda: selectedToAttr('endSpaceParent')
dButtons['flip muscle blueprint'] = flipMuscleBlueprint
dButtons['select all muscle joints'] = selectAllMuscleJoints
dButtons['WARP: warp selected joints'] = moveToLocationAttrs
dButtons['WARP: add warping info selected joints'] = addLocationAttrs
dButtons['Fix Child NAMES'] = fixChildNames
dButtons['transfer weights to spline joints'] = transferWeightsToSplineJoints
dButtons['transfer weights to main joints'] = transferWeightsToMainJoints
dButtons['Remove old limit attrs'] = removeOldLimitAttrs
dButtons['Clean Scale'] = fixScale
dButtons['Select Blueprints form Muscles'] = selectBlueprintsFromMuscles
dButtons['(Re)build from selected Blueprint'] = rebuildFromSelectedBlueprint
dButtons['Export Muscle Blueprints'] = lambda:exportBps('muscleJoints.ma', 'muscleJointBlueprints')
dButtons['< Dynamics Group >'] = muscleDynamicGroupsMenu


@builderTools.addToBuild(iOrder=13, dButtons=dButtons)
def doAllMuscleJoints():
    random.seed(2)
    sMuscles = [sJ for sJ in cmds.ls('muscleBp_*', et='joint') if not sJ.endswith('End')]

    if cmds.objExists('grp_m_muscleJoints'):
        cmds.delete('grp_m_muscleJoints')

    dMusclesPerMissing = defaultdict(list)
    dMissing = defaultdict(list)
    for sM in sMuscles:
        for sA in ['startSpace', 'endSpace', 'endSpaceParent']:
            sAttr = '%s.%s' % (sM, sA)
            if cmds.objExists(sAttr):
                sJoint = cmds.getAttr(sAttr)
                if sJoint.strip() and not cmds.objExists(sJoint):
                    dMissing[sJoint].append(sAttr)
                    dMusclesPerMissing[sJoint].append(sM)
    if dMissing:
        sPossibleJoints = sorted(cmds.listRelatives('skeleton', ad=True, typ='joint'))
        import kangarooTools.dependencyEditor as dependencyEditor
        utils.reload2(dependencyEditor)
        sMissingJoints = dMissing.keys()
        cmds.select(d=True)
        [cmds.select(sJoints, add=True) for sJoints in dMusclesPerMissing.values()]
        sNewJoints = dependencyEditor.showUi([('%s (%d)' % (sMissingJoint, len(dMusclesPerMissing[sMissingJoint])), sPossibleJoints, 1) for sMissingJoint in sMissingJoints], 'MuscleJoints - Resolve missing Joint Connections')

        for sMissingJ, sNewJ in zip(sMissingJoints, sNewJoints):
            sAttrs = dMissing[sMissingJ]
            for sAttr in sAttrs:
                cmds.setAttr(sAttr, sNewJ, type='string')


    for sM in sMuscles:
        report.report.addLogText('doing muscle: %s' % sM)
        createMuscleJoint(sM)

    cmds.setAttr('muscleJointBlueprints.v', False)


@builderTools.addToBuild(iOrder=999, dButtons=dButtons)
def cleanMuscles():
    utils.reload2(nodes)
    sBlueprints = sorted(cmds.ls('muscleJointBlueprints', dag=True, l=True), key=lambda a: len(a), reverse=True)[:-1]
    for sB in sBlueprints:
        nodes.deleteConnectionsAndItself3(sB)
    sMuscleCleanNodes = utils.data.get('sMuscleCleanNodes', xDefault=[])
    for sNode in sMuscleCleanNodes:
        if cmds.objExists(sNode):
            nodes.deleteConnectionsAndItself3(sNode)



def makeSpring(sCtrl, sTransform, sParent, sBlueprint, sMaster, fNoise=0.1):
    sDynamicGroupAttr = '%s.%s' % (sBlueprint, kDynamicsGroupAttr)
    sDynamicGroup = utils.getFirstLetterUpperCase(cmds.getAttr(sDynamicGroupAttr).strip()) if cmds.objExists(sDynamicGroupAttr) else ''
    
    sEnable = utils.addOffOnAttr(sMaster, 'muscleSpringsEnable', bDefaultValue=False, bNoAnim=True, bReturnIfExists=True)
    sStartFrame = utils.addAttr(sMaster, ln='dynamicsStartFrame', at='long', defaultValue=1001, k=False, cb=True, bReturnIfExists=True)
    sGlobalDamping = utils.addAttr(sMaster, ln='muscleSpringsDamping%s' % sDynamicGroup, at='double', min=0.0, defaultValue=0.6, k=False, cb=True, bReturnIfExists=True)
    sGlobalStiffness = utils.addAttr(sMaster, ln='muscleSpringsStiffness%s' % sDynamicGroup, at='double', min=0.0, defaultValue=0.6, k=False, cb=True, bReturnIfExists=True)
    sStrength = utils.addAttr(sCtrl, ln='springStrength', at='double3', minValue=0.0, defaultValue=1.0, k=True)
    sStiffness = utils.addAttr(sCtrl, ln='springStiffness', minValue=0.0, maxValue=1.0, defaultValue=0.7, k=True)
    sDamping = utils.addAttr(sCtrl, ln='springDamping', minValue=0.0, maxValue=1.0, defaultValue=0.7, k=True)
    sPrevFrame = utils.addAttr(sCtrl, ln='springPrevFrame', minValue=0.0, maxValue=1.0, defaultValue=0)


    # sAdd0 = nodes.createAdditionNode(['%s.springStiffness' % sBlueprint, (random.random() - 0.5) * fNoise], sTarget=sStiffness)
    # sAdd1 = nodes.createAdditionNode(['%s.springDamping' % sBlueprint, (random.random() - 0.5) * fNoise], sTarget=sDamping)
    
    cmds.connectAttr('%s.springStiffness' % sBlueprint, sStiffness)
    cmds.connectAttr('%s.springDamping' % sBlueprint, sDamping)
    cmds.connectAttr('%s.springStrength' % sBlueprint, sStrength)
    
    # utils.data.addToList('sMuscleCleanNodes', [sAdd0.split('.')[0], sAdd1.split('.')[0]])
    # cmds.connectAttr('%s.springStiffness' % sBlueprint, sStiffness)
    # cmds.connectAttr('%s.springDamping' % sBlueprint, sDamping)
    
    sStiffness = nodes.createMultiplyNode(sStiffness, sGlobalStiffness, sFullName='%s_multipl_stiffness' % sCtrl)
    sDamping = nodes.createMultiplyNode(sDamping, sGlobalDamping, sFullName='%s_multipl_damping' % sCtrl)
    
    utils.addAttr(sCtrl, ln='velocityX')
    utils.addAttr(sCtrl, ln='velocityY')
    utils.addAttr(sCtrl, ln='velocityZ')
    sVelocity = '%s.velocity' % sCtrl

    sPosOut = cmds.duplicate(sParent, po=True, n='%s_spring' % sParent)[0]
    sExpr = '''

    if (frame == {5})
    {{
    	{2}X = 0;
    	{2}Y = 0;
    	{2}Z = 0;
    	{4}.tx = {3}.tx;
    	{4}.ty = {3}.ty;
    	{4}.tz = {3}.tz;
    }}
    else
    {{
        vector $target = <<{3}.translateX, {3}.translateY, {3}.translateZ>>;
        vector $vel = <<{2}X, {2}Y, {2}Z>>;
        vector $posDyn = <<{4}.translateX, {4}.translateY, {4}.translateZ>>;

        $acc = ($target - $posDyn) * {0} - $vel * {1};
        $vel += $acc;

        $posDyn += $vel;

        {4}.tx = $posDyn.x;
        {4}.ty = $posDyn.y;
        {4}.tz = $posDyn.z;
        {2}X = $vel.x;
        {2}Y = $vel.y;
        {2}Z = $vel.z;
    }}
    {6} = frame;

                '''.format(sStiffness, sDamping, sVelocity, sParent, sPosOut, sStartFrame, sPrevFrame)
    sExpression = cmds.expression(s=sExpr, ae=True, n='%s_expr' % sTransform)
    nodes.createConditionNode(sEnable, '==', True, 0, 1, sTarget='%s.nodeState' % sExpression)
    
    sLocalSpring = nodes.createPointByMatrixNode('%s.t' % sPosOut, '%s.worldInverseMatrix' % cmds.listRelatives(sTransform, p=True)[0])
    sLocalSpringStrenghted = nodes.createVectorMultiplyNode(sLocalSpring, sStrength)
    nodes.createBlendNode(sEnable, sLocalSpringStrenghted, [0,0,0], bVector=True, sTarget='%s.t' % sTransform)
    


def createMuscleJoint(sBlueprint, fDynamicsNoise=0.1):
    report.report.addLogText('doing live muscle: %s ' % sBlueprint, bPrint=True)
    sEndBlueprint = '%sEnd' % sBlueprint
    if not cmds.objExists(sEndBlueprint):
        raise Exception('%s doesn\'t exist (%s)' % (sEndBlueprint, sBlueprint))

    cmds.select([sBlueprint, sEndBlueprint])
    sJoint, sJointEnd = ('muscleJnt_%s' % sBlueprint[sBlueprint.find('_')+1:]), ('muscleJnt_%s' % sEndBlueprint[sBlueprint.find('_')+1:])
    if not cmds.objExists(sJoint):
        xforms.duplicateJoinChain([sBlueprint, sEndBlueprint], bSwapBpPrefix=True)
    else:
        for sAttr in ['startSpace', 'endSpace', 'endSpaceParent']:
            sBlueprintAttr = '%s.%s' % (sBlueprint, sAttr)
            if cmds.objExists(sBlueprintAttr):
                utils.addStringAttr(sJoint, sAttr,  cmds.getAttr(sBlueprintAttr))

    if abs(cmds.getAttr('%s.ty' % sEndBlueprint)) > 0.00001 or abs(cmds.getAttr('%s.tz' % sEndBlueprint)) > 0.0001:
        cmds.select(sEndBlueprint)
        raise Exception ('"%s" has translation values in Y or Z. Muscle Child joints can only have translation values in X"' % sEndBlueprint)
    
  
    xforms.matchXform(sBlueprint, sJoint)
    xforms.matchXform(sEndBlueprint, sJointEnd)
    
    addTypeAttribute(sJoint, objectTypes.mainJoint)
    utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, '%s.worldInverseMatrix' % sBlueprint)
    utils.addStringAttr(sJointEnd, deformers.kPostRefJointAttr, '%s.worldInverseMatrix' %  sEndBlueprint)
    
    sNodesForDeleteNextTime = []
    
    if not cmds.objExists(sJoint):
        raise Exception('%s does not exist' % sJoint)
    if not cmds.objExists(sJointEnd):
        raise Exception('%s does not exist' % sJointEnd)

    sSplits = sJoint.split('_')
    sSide = sSplits[1]
    sName = sSplits[2]
    sMaster = utils.getMasterName()

    sMusclesRigVis = utils.addOffOnAttr(sMaster, 'musclesRigVis', bReturnIfExists=True, bDefaultValue=False)

    fSideMultipl = -1 if sSide == 'r' else 1

    sMainGrp = xforms.createOrReturnTopGroup('grp_m_muscleJoints', sParent=sMaster)
    cmds.connectAttr(sMusclesRigVis, '%s.v' % sMainGrp, f=True)
    sMuscleGrp = 'grp_%s_%sMuscle' % (sSide, sName)
    if cmds.objExists(sMuscleGrp):
        sNodesForDeleteNextTime = eval(cmds.getAttr('%s.sNodesForDeleteNextTime' % sMuscleGrp))
        cmds.delete(sMuscleGrp)
        sDeleteNodes = [sN for sN in sNodesForDeleteNextTime if cmds.objExists(sN)]
        if sDeleteNodes:
            cmds.delete(sDeleteNodes)

    cmds.createNode('transform', n=sMuscleGrp, p=sMainGrp)

    fJointRadius = cmds.getAttr('%s.radius' % sJoint)
    # sLocVis = '%s.locatorVis' % sJoint

    sStartSpace = utils.getMuscleAttrValue(sJoint, 'startSpace')
    sEndSpace = utils.getMuscleAttrValue(sJoint, 'endSpace')
    sEndSpaceParent = utils.getMuscleAttrValue(sJoint, 'endSpaceParent')

    sStartParentScale = nodes.scaleFromXform(sStartSpace)
    sEndParentScale = nodes.scaleFromXform(sEndSpace)

    if not sStartSpace or not sEndSpace:
        raise Exception('start and end space need to be set')

    utils.parentTo(sJoint, sStartSpace)

    sStartLoc = xforms.createLocator(sName='loc_%s_%sStart' % (sSide, sName), fSize=fJointRadius, sParent=sMuscleGrp)

    # cmds.connectAttr(sLocVis, '%sShape.v' % sStartLoc)
    sMatrixFactors = ['%s.worldMatrix' % sBlueprint,
                       cmds.getAttr('%s.worldInverseMatrix' % sStartSpace),
                       '%s.worldMatrix' % sStartSpace]
    if sSide == 'r':
        sMatrixFactors.insert(0, [-1,0,0,0, 0,-1,0,0, 0,0,-1,0, 0,0,0,1])
    nodes.createMultMatrixNode(sMatrixFactors, sTarget='%s.offsetParentMatrix' % sStartLoc)

    sUp = xforms.createLocator(sName='loc_%s_%sUp' % (sSide, sName), sParent=sStartLoc, fSize=fJointRadius)
    # cmds.connectAttr(sLocVis, '%sShape.v' % sUp)
    cmds.setAttr('%s.translate' % sUp, 0, 0, abs(cmds.getAttr('%s.tx' % sJointEnd)) * 2)

    sLocalEnd = nodes.createPointByMatrixNode(nodes.getWorldPoint(sEndBlueprint), cmds.getAttr('%s.worldInverseMatrix' % sEndSpace))
    sWorldEnd = nodes.createPointByMatrixNode(sLocalEnd, '%s.worldMatrix' % sEndSpace)

    sEndLoc = xforms.createLocator(sName='loc_%s_%sEnd' % (sSide, sName), fSize=fJointRadius, sParent=sMuscleGrp)
    sEndOrientParent = xforms.insertParent(sEndLoc, '%s_orient' % sEndLoc)
    cmds.delete(cmds.orientConstraint(sEndBlueprint, sEndOrientParent))

    nodes.createVectorMultiplyNode([sEndParentScale, sEndParentScale, sEndParentScale], fSideMultipl, bVectorByScalar=True, sTarget='%s.s' % sEndOrientParent)
    # if sSide == 'r':
    #     cmds.setAttr('%s.s' % sEndOrientParent, -1, -1, -1)


    if not sEndSpaceParent:
        cmds.connectAttr(sWorldEnd, '%s.t' % sEndOrientParent)
    else:
        sEndGrp = xforms.createTransform(sName='grp_%s_%sEnd' % (sSide, sName), sParent=sMuscleGrp)
        sEndSpaceParentMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sEndBlueprint,
                                   cmds.getAttr('%s.worldInverseMatrix' % sEndSpaceParent),
                                   '%s.worldMatrix' % sEndSpaceParent])
        nodes.createDecomposeMatrix(sEndSpaceParentMatrix, sTargetPos='%s.t' % sEndGrp)
        cmds.orientConstraint(sEndSpaceParent, sEndGrp)
        # sEndLoc = xforms.createLocator(sName='loc_%s_%sEnd' % (sSide, sName), fSize=fJointRadius, sParent=sEndGrp)
        cmds.parent(sEndOrientParent, sEndGrp)
        
        sWorldEndInLimitSpace = nodes.createPointByMatrixNode(sWorldEnd, '%s.worldInverseMatrix' % sEndGrp)

        sMin = [None, None, None]
        sMax = [None, None, None]
        for a,sA in enumerate(['X','Y','Z']):
            sPosAttr = '%s.EndLimitPos%s' % (sJoint, sA)
            sNegAttr = '%s.EndLimitNeg%s' % (sJoint, sA)
            cmds.connectAttr('%s.EndLimitPos%s' % (sBlueprint, sA), sPosAttr, f=True)
            cmds.connectAttr('%s.EndLimitNeg%s' % (sBlueprint, sA), sNegAttr, f=True)
            sMin[a] = nodes.createConditionNode(sNegAttr, '==', True, 0, -1000000000)
            sMax[a] = nodes.createConditionNode(sPosAttr, '==', True, 0, 1000000000)

        sEndLocExtraParent = xforms.insertParent(sEndOrientParent, '%s_limit' % sEndLoc)
        nodes.createClampNode(sWorldEndInLimitSpace, sMin, sMax, bVector=True, sTarget='%s.t' % sEndLocExtraParent)



    sPointConstraint = cmds.pointConstraint(sStartLoc, sJoint)[0]
    sAimConstraint = cmds.aimConstraint(sEndLoc, sJoint, aim=[fSideMultipl, 0, 0], u=[0, 0, fSideMultipl], wut='object', wuo=sUp)[0]
    cmds.parent(sPointConstraint, sAimConstraint, sMuscleGrp)
    sDistance = nodes.createDistanceNode(nodes.getWorldPoint(sStartLoc), nodes.getWorldPoint(sEndLoc), sDivide=sStartParentScale)


    sScaleMultipl = nodes.createMultiplyNode(sDistance, nodes.createAbsoluteNode('%s.tx' % sEndBlueprint), sOperation='divide')
    sNodesForDeleteNextTime.append(nodes.createBlendNode('%s.stretch' % sJoint, sScaleMultipl, 1, sTarget = '%s.scaleX' % sJoint, sName=sName))
    sSquashMultipl = nodes.fromEquation('1 / %s' % sScaleMultipl, sName=sName )

    for sAxis in ['Y','Z']:
        fSquashAttrPos = '%s.squash%sPos' % (sJoint, sAxis)
        fSquashAttrNeg = '%s.squash%sNeg' % (sJoint, sAxis)
        cmds.connectAttr('%s.squash%sPos' % (sBlueprint, sAxis), fSquashAttrPos, f=True)
        cmds.connectAttr('%s.squash%sNeg' % (sBlueprint, sAxis), fSquashAttrNeg, f=True)

        sCondSquash = nodes.createConditionNode(sSquashMultipl, '>', 1, fSquashAttrPos, fSquashAttrNeg, sName=sName)
        sScale = nodes.createBlendNode(sCondSquash, sSquashMultipl, 1, sName=sName)
        sNodesForDeleteNextTime.extend([sScale, sCondSquash])

        sMinLimit = '%s.squash%sMinLimit' % (sJoint, sAxis)
        if cmds.objExists(sMinLimit):
            sScale = nodes.createConditionNode(sScale, '<', sMinLimit, sMinLimit, sScale)

        cmds.connectAttr(sScale, '%s.scale%s' % (sJoint, sAxis), force=True)

    cmds.connectAttr('%s.stretch' % sBlueprint, '%s.stretch' % sJoint, f=True)

    utils.addStringAttr(sMuscleGrp, 'sNodesForDeleteNextTime', [sAttr.split('.')[0] for sAttr in sNodesForDeleteNextTime])

    sEndLocalX = '%sX' % nodes.createPointByMatrixNode(nodes.getWorldPoint(sEndLoc), '%s.worldInverseMatrix' % sJoint)
    nodes.createBlendNode('%s.attachEnd' % sJoint, sEndLocalX, '%s.tx' % sEndBlueprint, sTarget='%s.tx' % sJointEnd, bForce=True)
    cmds.connectAttr('%s.attachEnd' % sBlueprint, '%s.attachEnd' % sJoint, force=True)

    sSplineJointCountAttr = '%s.splineJointCount' % sBlueprint
    if cmds.objExists(sSplineJointCountAttr):
        iSplineJointCount = cmds.getAttr(sSplineJointCountAttr)

        
        if iSplineJointCount > 0:
            sMuscleCtrlsParents = 'muscleCtrls'
            if not cmds.objExists(sMuscleCtrlsParents):
                cmds.createNode('transform', n=sMuscleCtrlsParents, p='ctrls')
                utils.addOffOnAttr(sMaster, 'muscleCtrlsVis', bDefaultValue=False, sTarget='%s.v' % sMuscleCtrlsParents)

            sSplineGrp = 'grp_muscleSplines'
            if not cmds.objExists(sSplineGrp):
                cmds.createNode('transform', n=sSplineGrp, p=sMaster)
                cmds.connectAttr(sMusclesRigVis, '%s.v' % sSplineGrp)

            sOldSplineSetup = 'grp%s_%sRIG' % (sSide.upper(), sName)
            if cmds.objExists(sOldSplineSetup):
                cmds.delete(sOldSplineSetup)


            sSplineCtrlTAttr = '%s.splineCtrlT' % sBlueprint
            if cmds.objExists(sSplineCtrlTAttr):
                fSplineT = cmds.getAttr(sSplineCtrlTAttr)
            else:
                fSplineT = 0.5
            
            sOldPasser = 'grp_%s_muscle_%sPasser' % (sSide,sName)
            if cmds.objExists(sOldPasser):
                cmds.delete(sOldPasser)
            cMid = ctrls7.create('muscle_%s' % sName, sSide, sAttrs=['t','r','s'], sParent=sMuscleCtrlsParents, fSize=fJointRadius*3, iColorIndex=1)
            sMidSpring = cMid.appendOffsetGroup('spring')
            
            cmds.orientConstraint(sJoint, cMid.sPasser)
            cmds.pointConstraint(sStartLoc, cMid.sPasser, w=1.0-fSplineT)
            cmds.pointConstraint(sEndLoc, cMid.sPasser, w=fSplineT)
            makeSpring(cMid.sCtrl, sMidSpring, cMid.sPasser, sBlueprint, sMaster, fNoise=fDynamicsNoise)
            cmds.connectAttr(sStartParentScale, '%s.sx' % cMid.sPasser)
            cmds.connectAttr(sStartParentScale, '%s.sy' % cMid.sPasser)
            cmds.connectAttr(sStartParentScale, '%s.sz' % cMid.sPasser)

            aPercs = np.array([0.0, 0.15, 0.35, 0.65, 0.85, 1.0], dtype='float64')[:,np.newaxis]
            aEndPoints = xforms.getPositionArray([sStartLoc, sEndLoc])
            aCurvePoints = aEndPoints[0] * (1.0-aPercs) + aEndPoints[1] * aPercs
            sSplineCurve = cmds.curve(p=list(aCurvePoints), n='muscleCurve_%s_%s' % (sSide, sName))
            cmds.parent(sSplineCurve, sMuscleGrp)
            cmds.select(sSplineCurve)
            sInfluences = []
            aaWeights = np.zeros((len(aPercs), 3), dtype='float64')
            for iC, iCvs, sCtrl in [(0, [0,1], sStartLoc), (1, [2,3], cMid.sCtrl), (2, [4,5], sEndLoc)]:
                sInf = xforms.createJoint('inf_%s_%sSplineInfluence_%d' % (sSide,sName,iC), sParent=sMuscleGrp)
                cmds.pointConstraint(sCtrl, sInf)
                cmds.orientConstraint(sCtrl if iC == 1 else sJoint, sInf)
                cmds.scaleConstraint(sJoint, sInf)
                sInfluences.append(sInf)
                aaWeights[np.array(iCvs, dtype=int),iC] = 1.0

            aJointPercs = np.array(np.arange(iSplineJointCount), dtype='float64') / (iSplineJointCount-1)
            aJointParams = curves.getParamsFromPercs(sSplineCurve, aJointPercs)
            # sRotateMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sJoint)
            # sInvRotateMatrix = nodes.createInverseMatrix(sRotateMatrix)
            sSplineJoints = []
            for j in range(iSplineJointCount):
                sJ = xforms.createJoint('muscleJnt_%s_%s_%03d' % (sSide,sName,j), sParent=sJoint, fSize=fJointRadius*0.5)
                cmds.setAttr('%s.inheritsTransform' % sJ, False)
                sPointNode, sPointOnCurve = curves.createPointInfoNode(sSplineCurve, aJointParams[j])
                cmds.connectAttr(sPointOnCurve, '%s.t' % sJ)
                sAimConstraint = constraints.aimConstraintEmpty(sJ)
                sTangentWorld = nodes.createVectorAdditionNode([sPointOnCurve, '%s.tangent' % sPointNode])
                cmds.connectAttr(sTangentWorld, '%s.target[0].targetTranslate' % sAimConstraint)
                cmds.connectAttr('%s.worldMatrix' % sJoint, '%s.worldUpMatrix' % sAimConstraint)
                if j == 0:
                    cmds.scaleConstraint(sJoint, sJ)
                else:
                    cmds.connectAttr('%s.s' % sSplineJoints[0], '%s.s' % sJ)
                sSplineJoints.append(sJ)

            utils.addStringAttr(sJoint, 'sSplineJoints', str(sSplineJoints))
            cmds.skinCluster(sSplineCurve, sInfluences, tsb=True)
            patch.patchFromName(sSplineCurve).setSkinClusterWeights(aaWeights, _bSkipDeformerAdjustLogging=True)





def openPoseEditor():
    import kangarooTools.poseEditor as poseEditor
    utils.reload2(poseEditor)
    poseEditor.showUi()


def fillAndExportFromScene(_uiArgs=None):
    import kangarooTools.poseEditor as poseEditor
    utils.reload2(poseEditor)
    poseEditor.fillAndExportFromScene(_uiArgs=_uiArgs)


def poseEditorModelChangeWarp():
    import kangarooTools.poseEditor as poseEditor
    utils.reload2(poseEditor)
    poseEditor.modelChangeWarp()


def showBakedBlendShapeMeshesInExplorer():
    import kangarooTools.poseEditor as poseEditor
    utils.reload2(poseEditor)
    poseEditor.showBakedBlendShapeMeshesInExplorer()




dButtons = OrderedDict()
dButtons['Open Editor'] = openPoseEditor
dButtons['Fill and Export from Scene'] = fillAndExportFromScene
dButtons['Model Warp selected Meshes (use in exported file)'] = poseEditorModelChangeWarp
dButtons['Show BlendShape File in Explorer'] = showBakedBlendShapeMeshesInExplorer


@builderTools.addToBuild(iOrder=107, dButtons=dButtons, bDisableByDefault=True)
def poseEditorApply(ddInterpolators={}, ddPoseData={}, bSkipBlendShapes=False, bSkipLocators=False):
    import kangarooTools.poseEditor as poseEditor
    utils.reload2(interpolator)
    utils.reload2(poseEditor)
    poseEditor.poseEditorApply(ddInterpolators, ddPoseData, bSkipBlendShapes=bSkipBlendShapes, bSkipLocators=bSkipLocators, bReport=True)




def goToPosesMenu():

    qMenu = QtWidgets.QMenu()

    # sInterpolators = cmds.ls(et='poseInterpolator')
    # sInterpolators = [cmds.listRelatives(sI, p=True)[0] for sI in sInterpolators]
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True)]

    for sI in sInterpolators:
        sNamespace = utils.splitNamespace(sI)[0]
        qInterpMenu = qMenu.addMenu(sI)
        xPoses = eval(cmds.getAttr('%s.xPoses' % sI))
        for xP in xPoses:
            sPose = xP[0]
            fValues = xP[1:]

            def _goTo(_sI=sI, _sPose=sPose, _fValues=fValues, _sNamespace=sNamespace):
                print('_sPose: ', _sPose)
                sCtrl = cmds.getAttr('%s.sCtrl' % _sI)
                sPoseAttrs = eval(cmds.getAttr('%s.sPoseAttrs' % _sI))
                print ('sPoseAttrs: ', sPoseAttrs)
                for sA,fV in zip(sPoseAttrs, _fValues):
                    cmds.setAttr('%s%s.%s' % (_sNamespace, sCtrl, sA), fV)

            qInterpMenu.addAction(sPose, _goTo)

    qCursor = QtGui.QCursor()
    qMenu.exec_(qCursor.pos())




def createRomAnimation(dInterpolators):
    interpolator.createRomAnimation(list(dInterpolators.keys()))



def fillCustomPoseLocators(_uiArgs=None):
    dDict = {}
    sPoseLocs = cmds.ls('_poseLoc__CUSTOMPOSE__*', et='transform')
    for sPoseLoc in sPoseLocs:
        for sA in 'trs':
            fValue = cmds.getAttr('%s.%s' % (sPoseLoc, sA))[0]

            if sA == 's':
                fValue = [fV-1.0 for fV in fValue]
            if np.any(fValue):
                dDict['%s.%s' % (sPoseLoc,sA)] = fValue
    _uiArgs['dPoses'].setText(str(dDict))


def mirrorCustomPosesLocators():
    sPoseLocs = cmds.ls('_poseLoc__CUSTOMPOSE__*', et='transform')
    for sPoseLoc in sPoseLocs:
        sMirrorPoseLoc = sPoseLoc.replace('_l_', '_#_').replace('_r_', '_l_').replace('_#_', '_r_')
        if cmds.objExists(sMirrorPoseLoc) and sMirrorPoseLoc != sPoseLoc:
            for sA in 'trs':
                cmds.setAttr('%s.%s' % (sMirrorPoseLoc,sA), *cmds.getAttr('%s.%s' % (sPoseLoc,sA))[0])


dButtons = OrderedDict()
dButtons['Go To Poses'] = goToPosesMenu
dButtons['Fill poses'] = fillCustomPoseLocators
dButtons['Mirror Locators'] = mirrorCustomPosesLocators
dButtons['create Rom Animation'] = createRomAnimation


@builderTools.addToBuild(iOrder=108, dButtons=dButtons)
def CustomPoses(dInterpolators={'interpolator':{'sCtrls':[]}}, dPoses={}):
    '''
    if Go to Poses buttons don't do anything, you might have to switch the limbs to FK

    Mirror: This one does NOT automatically mirror. To mirror, click "Mirror Locators", adn then "Fill Poses"
    '''
    dPrevSwitchValues = {}
    for sGlobalCtrl in cmds.ls('*Global*_ctrl', et='transform'):
        sSwitchAttr = '%s.fk2ik' % sGlobalCtrl
        if cmds.objExists(sSwitchAttr):
            fCurrentValue = cmds.getAttr(sSwitchAttr)
            if fCurrentValue != 0.0:
                dPrevSwitchValues[sSwitchAttr] = fCurrentValue
            cmds.setAttr(sSwitchAttr, 0.0)


    dInterpolators = dict(dInterpolators)
    print ('dInterpolators 0: ', dInterpolators)
    dMirrrorInterpolators = {}
    for sInterp, dData in dInterpolators.items():
        sMirrorInterp = utils.getMirrorName(sInterp)
        if cmds.objExists(sMirrorInterp) and sMirrorInterp != sInterp:
            dMirrorData = dict(dData)
            dMirrorData['sCtrls'] = utils.mirrorList(list(dData['sCtrls']))
            dMirrrorInterpolators[sMirrorInterp] = dMirrorData
    dInterpolators.update(dMirrrorInterpolators)


    dProductsT = defaultdict(list)
    dProductsR = defaultdict(list)
    dProductsS = defaultdict(list)
    for sInterp, dData in dInterpolators.items():
        for sCtrl in dData['sCtrls']:
            cCtrl = ctrls7.ctrlFromName(sCtrl)
            sOffset = cCtrl.appendOffsetGroup('custompose')
            xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
            for sPose, fX, fY, fZ in xPoses:
                sPoseLoc = f"_poseLoc__CUSTOMPOSE__{sCtrl}__{sInterp}__{sPose}"
                xforms.createLocator(sName=sPoseLoc, sParent=cmds.listRelatives(sOffset, p=True)[0], fSize=cCtrl.fSize)
                dProductsT[sOffset].append(nodes.createVectorMultiplyNode('%s.t' % sPoseLoc, '%s.%s' % (sInterp, sPose), bVectorByScalar=True))
                dProductsR[sOffset].append(nodes.createVectorMultiplyNode('%s.r' % sPoseLoc, '%s.%s' % (sInterp, sPose), bVectorByScalar=True))
                dProductsS[sOffset].append(nodes.createVectorMultiplyNode(nodes.createVectorAdditionNode(['%s.s' % sPoseLoc, [-1,-1,-1]]), '%s.%s' % (sInterp, sPose), bVectorByScalar=True))
                utils.connectPosesLocVis(sPoseLoc)
                cmds.connectAttr('%s.%s' % (sInterp, sPose), '%s.v' % sPoseLoc, force=True)

    for sOffset,sProducts in dProductsT.items():
        nodes.createVectorAdditionNode(sProducts, sTarget='%s.t' % sOffset)
    for sOffset,sProducts in dProductsR.items():
        nodes.createVectorAdditionNode(sProducts, sTarget='%s.r' % sOffset)
    for sOffset,sProducts in dProductsS.items():
        nodes.createVectorAdditionNode([[1,1,1]] + sProducts, sTarget='%s.s' % sOffset)


    for sAttr, fValues in dPoses.items():
        if cmds.objExists(sAttr):
            if sAttr.endswith('.s'):
                cmds.setAttr(sAttr, 1.0+fValues[0], 1.0+fValues[1], 1.0+fValues[2])
            else:
                cmds.setAttr(sAttr, *fValues)

    
    for sAttr, fValue in dPrevSwitchValues.items():
        cmds.setAttr(sAttr, fValue)


dButtons = {}
def recordPoseT(_uiArgs=None):
    dPoseT = {}
    sAllCtrls = ctrls7.getAllCtrlsInScene(bReturnNames=True)
    for sCtrl in sAllCtrls:
        sAllAttrs = utils._getAnimAttrsFromNode(sCtrl)
        for sA in sAllAttrs:
            sAttr = '%s.%s' % (sCtrl, sA)
            fCurrentValue = cmds.getAttr(sAttr)
            try:
                fDefault = utils.getDefaultAttrValue(sAttr)
            except:
                continue
            fDiff = abs(fCurrentValue - fDefault)
            if fDiff > 0.0001:
                dPoseT[sAttr] = fCurrentValue
    
    _uiArgs['dPoseT'].setText(str(dPoseT))
dButtons['record T Pose'] = recordPoseT


@builderTools.addToBuild(iOrder=200, dButtons=dButtons, bDisableByDefault=True)
def humanIkSkeleton(dPoseT={}, bMirrorPoseT=True):
    import kangarooAnimation.humanIk as humanIk
    utils.reload2(humanIk)
    
    humanIk.initiate()
    
    sCharacter = assets.getCurrentAssetRootName().strip()
    
    if bMirrorPoseT:
        dMirrored = {}
        for sAttr, fValue in dPoseT.items():
            sMirrorAttr = utils.getMirrorName(sAttr)
            if sMirrorAttr not in dPoseT:
                dMirrored[sMirrorAttr] = fValue
        dPoseT.update(dMirrored)

    
    dPrevValues = {}
    for sAttr, fValue in dPoseT.items():
        dPrevValues[sAttr] = cmds.getAttr(sAttr)
        cmds.setAttr(sAttr, fValue)
    
    humanIk.createHumanIkSkeleton(sCharacter, bCharacterize=True)

    for sAttr, fPrevValue in dPrevValues.items():
        cmds.setAttr(sAttr, fPrevValue)
 
#
def createScapulaRangeOfMotionAnim():
    sInterpolators = utils.data.get('sClavicleInterpolators')
    interpolator.createRomAnimation(sInterpolators)


def fillScapulaPoses(_uiArgs=None):
    dDict = {}
    sPoseLocs = cmds.ls('_poseLoc__scapulaBlade_*__*', et='transform')
    for sPoseLoc in sPoseLocs:
        for sA in ['t','r']:
            fValue = cmds.getAttr('%s.%s' % (sPoseLoc, sA))[0]
            if np.any(fValue):
                dDict['%s.%s' % (sPoseLoc,sA)] = fValue
    _uiArgs['dPoses'].setText(str(dDict))


def scapulaMirror():
    sLeftLocs = cmds.ls('_poseLoc__scapulaBlade_*_l_*', et='transform')
    for sLeftLoc in sLeftLocs:
        sRightLoc = sLeftLoc.replace('_l_', '_r_')
        for sA in 'trs':
            fLeftValue = cmds.getAttr('%s.%s' % (sLeftLoc,sA))[0]
            cmds.setAttr('%s.%s' % (sRightLoc,sA), *fLeftValue)



@builderTools.addToBuild(iOrder=102, dButtons={'Fill Poses':fillScapulaPoses, 'Create Range Of Motion':createScapulaRangeOfMotionAnim, 'Mirror Locators':scapulaMirror}, bDisableByDefault=True)
def scapulaBlade(dPoses={}, fUparmUp=-70, fUparmDown=45, fUparmForward=-75, fUparmBack=70, fScapulaUp=-25, fScapulaDown=25, fScapulaForward=-25, fScapulaBack=25):
    sInterpolators = []
    sInterpolators.append(interpolator.createSignedAngleInterpolator2('scapulaBlade_clavicle_l_upDown', 'jnt_l_clavicleMain', 'jnt_m_spineSpine_end', 'clavicle_l_ctrl.rz', iForwardAxis=0, iUpAxis=2,
                                         xPoses=[('up', [0, -40], blendShapes.DrivenKeyCurveType.linear),
                                                 ('down', [0, 35], blendShapes.DrivenKeyCurveType.linear)], bComputeInParentSpace=False)[0])
    sInterpolators.append(interpolator.createSignedAngleInterpolator2('scapulaBlade_clavicle_l_forwardBack', 'jnt_l_clavicleMain', 'jnt_m_spineSpine_end', 'clavicle_l_ctrl.rx', iForwardAxis=1, iUpAxis=0,
                                         xPoses=[('forward', [0, -30], blendShapes.DrivenKeyCurveType.linear),
                                                 ('back', [0, 30], blendShapes.DrivenKeyCurveType.linear)], bComputeInParentSpace=False)[0])


    sInterpolators.append(interpolator.createSignedAngleInterpolator2('scapulaBlade_uparm_l_upDown', 'jnt_l_arm_upperTwist_000', 'jnt_l_clavicleMain', 'armUpper_l_ctrl.rz', iForwardAxis=0, iUpAxis=2,
                                         xPoses=[('up', [0, -60], blendShapes.DrivenKeyCurveType.linear),
                                                 ('down', [0, 35], blendShapes.DrivenKeyCurveType.linear)], bComputeInParentSpace=False)[0])
    sInterpolators.append(interpolator.createSignedAngleInterpolator2('scapulaBlade_uparm_l_forwardBack', 'jnt_l_arm_upperTwist_000', 'jnt_l_clavicleMain', 'armUpper_l_ctrl.rx', iForwardAxis=1, iUpAxis=0,
                                         xPoses=[('forward', [0, -80], blendShapes.DrivenKeyCurveType.linear),
                                                 ('back', [0, 80], blendShapes.DrivenKeyCurveType.linear)], bComputeInParentSpace=False)[0])


    utils.data.store('sClavicleInterpolators', sInterpolators)

    for s,sSide in enumerate('lr'):
        sCtrl = f'scapula_{sSide}_ctrl'

        sAutoAttr = utils.addAttr(sCtrl, ln='auto', min=0, max=1, dv=1, k=True)

        if not cmds.objExists(sCtrl):
            report.report.addLogText('skipping scapula ctrl ("%s") is missing' % (sCtrl))
            return True

        cScapula = ctrls7.ctrlFromName(sCtrl)
        sOffset = cScapula.appendOffsetGroup('pose')
        sMultiplsR = []
        sMultiplsT = []
        for sInterp in sInterpolators:
            if sSide == 'r':
                sInterp = utils.getMirrorName(sInterp)
            xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
            for sPose, fX, fY, fZ in xPoses:
                sPoseLoc = f"_poseLoc__{sInterp}__{sPose}"
                xforms.createLocator(sName=sPoseLoc, sParent=cmds.listRelatives(sOffset, p=True)[0], fSize=cScapula.fSize)
                sMultiplsR.append(nodes.createVectorMultiplyNode('%s.r' % sPoseLoc, '%s.%s' % (sInterp, sPose), bVectorByScalar=True))
                sMultiplsT.append(nodes.createVectorMultiplyNode('%s.t' % sPoseLoc, '%s.%s' % (sInterp, sPose), bVectorByScalar=True))
                utils.connectPosesLocVis(sPoseLoc)
                cmds.connectAttr('%s.%s' % (sInterp, sPose), '%s.v' % sPoseLoc, force=True)

        sRotations = nodes.createVectorAdditionNode(sMultiplsR)
        nodes.createBlendNode(sAutoAttr, sRotations, [0,0,0], bVector=True, sTarget='%s.r' % sOffset)
        sTranslations = nodes.createVectorAdditionNode(sMultiplsT)
        nodes.createBlendNode(sAutoAttr, sTranslations, [0,0,0], bVector=True, sTarget='%s.t' % sOffset)


    for sAttr,fValues in dPoses.items():
        if cmds.objExists(sAttr) and '_l_' in sAttr:
            cmds.setAttr(sAttr, *fValues)
            sMirrorAttr = utils.getMirrorName(sAttr)
            cmds.setAttr(sMirrorAttr, *fValues)


@builderTools.addToBuild(iOrder=102, dButtons=dButtons, bDisableByDefault=True)
def impactJiggle(iFrameLength=15, iFrequency=4, fSpeedRange=[6,12], fReducedSpeed=2.5, sJoint='jnt_l_legFingers'):

    sMaster = utils.getMasterName()
    for s,sSide in enumerate(['l','r']):
        if sSide == 'r':
            sJoint = utils.getMirrorName(sJoint)

        fJointRadius = cmds.getAttr('%s.radius' % sJoint)
        sSphere = cmds.polySphere(n='impactSphere_%s' % sJoint, r=fJointRadius*10)[0]
        cmds.parent(sSphere, sMaster)

        sShader = cmds.shadingNode('surfaceShader', asShader=True, n='impactSphereShader')
        sSphereVis = utils.addOffOnAttr(sMaster, 'impactSpheres', bDefaultValue=False, bReturnIfExists=True)
        cmds.connectAttr(sSphereVis, '%s.v' % sSphere)
        cmds.select(sSphere)
        cmds.hyperShade(assign=sShader)

        cmds.pointConstraint(sJoint, sSphere)
        sStartFrame = utils.addAttr(sMaster, ln='dynamicsStartFrame', at='long', defaultValue=1001, k=False, cb=True, bReturnIfExists=True)
        sSpeedMinAttr = utils.addAttr(sSphere, ln='speedMin', defaultValue=fSpeedRange[0], k=False, cb=True, bReturnIfExists=True)
        sSpeedMaxAttr = utils.addAttr(sSphere, ln='speedMax', defaultValue=fSpeedRange[1], k=False, cb=True, bReturnIfExists=True)
        sReducedImpactSpeed = utils.addAttr(sSphere, ln='reducedImpactSpeed', defaultValue=fReducedSpeed, k=False, cb=True, bReturnIfExists=True)

        sPreviousPosition = utils.addAttr(sSphere, ln='previousPosition', at='double3', k=True, bReturnIfExists=True)
        sPreviousVelocity = utils.addAttr(sSphere, ln='previousVelocity', at='double3', k=True, bReturnIfExists=True)
        sPreviousSpeed = utils.addAttr(sSphere, ln='previousSpeed', at='double', k=True, bReturnIfExists=True)
        sCurrentPosAttr = utils.addAttr(sSphere, ln='currentPosition', at='double3', k=True, bReturnIfExists=True)
        cmds.connectAttr(nodes.getWorldPoint(sJoint), sCurrentPosAttr)

        sAnimFrame = utils.addAttr(sSphere, ln='animFrame', at='double', k=True, bReturnIfExists=True)
        sLastImpactStrength = utils.addAttr(sSphere, ln='lastImpactStrength', at='double', k=True, bReturnIfExists=True)
        sJiggleAttr = utils.addAttr(sSphere, ln='jiggleAnim', at='double', k=True, bReturnIfExists=True)
        sJiggleStrengthedAttr = utils.addAttr(sSphere, ln='jiggleAnimStrengthed', at='double', k=True, bReturnIfExists=True)


        aValues = np.zeros(iFrequency*2, dtype='float64')
        aValues[np.arange(0, len(aValues), 2)] = np.arange(iFrequency*2, 0, -2) / (iFrequency*2)
        aTimes = np.linspace(iFrameLength, 0, iFrequency*2)

        nodes.setDrivenKey(sAnimFrame, aTimes, sJiggleAttr, aValues)
        nodes.createMultiplyNode(sJiggleAttr, sLastImpactStrength, sTarget=sJiggleStrengthedAttr)

        sVisType = utils.addAttr(sSphere, ln='visType', at='enum', en='full:strenghted', k=True, dv=1)

        sJiggleAttrShow = nodes.createConditionNode(sVisType, '==', 0, sJiggleAttr, sJiggleStrengthedAttr)

        nodes.setDrivenKey(sJiggleAttrShow, [0, 1], '%s.outColorR' % sShader, [1,1])
        nodes.setDrivenKey(sJiggleAttrShow, [0, 1], '%s.outColorG' % sShader, [1,0])
        nodes.setDrivenKey(sJiggleAttrShow, [0, 1], '%s.outColorB' % sShader, [1,0])

        sExpr = '''
    
        if (frame == {0})
        {{
         
            {2}X = {1}X;
            {2}Y = {1}Y;
            {2}Z = {1}Z; 
            {8} = 0;
            {4} = 0;
        }}
        else
        {{
            vector $previous = <<{2}X, {2}Y, {2}Z>>;
            vector $current = <<{1}X, {1}Y, {1}Z>>;
            vector $vel = $current - $previous;
            float $currentSpeed = mag($vel);
            float $previousSpeed = {4};
            
            if ($currentSpeed < {7})
            {{
                if ($previousSpeed > {5})
                {{
                    {8} = {9} + 1;
                    if ($previousSpeed > {6})
                    {{
                        {10} = 1.0;
                    }} 
                    else
                    {{
                        {10} = ($previousSpeed - {5}) / ({6} - {5});
                    }}
                }}
            }}
            
            {3}X = $vel.x;
            {3}Y = $vel.y;
            {3}Z = $vel.z;
            {4} = $currentSpeed;
        
            {2}X = {1}X;
            {2}Y = {1}Y;
            {2}Z = {1}Z; 
        
            if ({8} > 0)
            {{
                {8} -= 1;
            }}
        }}
    
        '''.format(sStartFrame, sCurrentPosAttr, sPreviousPosition, sPreviousVelocity, sPreviousSpeed, sSpeedMinAttr, sSpeedMaxAttr, sReducedImpactSpeed, sAnimFrame, iFrameLength, sLastImpactStrength)
        print (sExpr)

        cmds.expression(s=sExpr, ae=True, n='expression_impact_%s' % sJoint)
        # nodes.createConditionNode(sEnable, '==', True, 0, 1, sTarget='%s.nodeState' % sExpression)




''' 
human ik stuff:
    
    mm.eval( 'hikSetCurrentCharacter("' + char + '")' )
    mm.eval( 'hikUpdateCharacterList()' )
    mm.eval( 'hikSetCurrentSourceFromCharacter("' + char + '")' )
    mm.eval( 'hikUpdateSourceList()' )
        charNodes = mm.eval( 'hikGetSkeletonNodes "' + char + '"' )

        mm.eval( 'HIKCharacterControlsTool' )

    
'''


'''

    for sI in sInterpolators:
        # sNamespace = utils.splitNamespace(sI)[0]

        xPoses = eval(cmds.getAttr('%s.xPoses' % sI))
        sPoses = [xP[0] for xP in xPoses]

        sDoPoses = []
        for sP in sPoses[1:]:
            sPoseAttr = '%s.%s' % (sI, sP)
            fValue = cmds.getAttr(sPoseAttr)
            xPoseAttrs.append([sPoseAttr, fValue])

    xSorted = sorted(xPoseAttrs, key=lambda a:a[1])
    sPose, fValue = xSorted[-1]
    if cmds.confirmDialog(m='set for pose "%s" that has current value of %0.1f?' % (xHighestPose[0], xHighestPose[1]), button=['yes', 'no, cancel']) == 'yes':
        pass



'''


