###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np
import pickle
import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.constraints as constraints
import kangarooTools.utilsUnreal as utilsUnreal

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls2 as ctrls2
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.ctrls5 as ctrls5
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal
import kangarooTabTools.blendShapes as blendShapes

from collections import defaultdict

kBuilderColor = '#39a9f4'


@builderTools.addToBuild(iOrder=-1001)
def reloadLibraries():
    for module in [utils, nodes, match, puppetTools, segmentsTools, ctrls, ctrls2, ctrls3, ctrls4, ctrls5, sliderCtrls, weights, xforms, curves, patch,
                   deformers, interpolator, geometry, export, unreal, constraints, blendShapes, utilsUnreal]:
        print('reloading %s' % module.__name__)
        report.report.addLogText('reloading %s' % module.__name__)
        utils.reload2(module)

        try:
            import controlRig.prepare as prepare
            utils.reload2(prepare)

            import kangarooTabTools.blendShapesPro as blendShapesPro
            utils.reload2(blendShapesPro)

        except:
            report.report.addLogText ('skipping controlRig import')


@builderTools.addToBuild(iOrder=-1000)
def newScene(bAscii=True):
    cmds.file(new=True, f=True)
    sFilePath = os.path.expanduser('~/newScene.%s' % 'ma' if bAscii else 'mb')
    cmds.file(rename=sFilePath)
    cmds.file(save=True, typ='mayaAscii' if bAscii else 'mayaBinary')


@builderTools.addToBuild(iOrder=-100)
def createTopGroups():
    assets.createTopGroups()
    utils.data.store('sBuildingAsset', [assets.getCurrentProject(), assets.assetManager.getCurrentAsset()])
    utils.data.store('bAllSplitAttachersTakeLocals', True)



def checkClashingNames():
    sAllNewNodes = cmds.ls(dag=True)
    sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
    if sClashingNodes:
        print('---CLASHING NODES---')
        for sN in sClashingNodes:
            print(sN)
        cmds.select(sClashingNodes)
    else:
        print('no clashing nodes')


@builderTools.addToBuild(iOrder=-10, dButtons={'find clashing nodes in scene': checkClashingNames})
def importModel(bCheckClashingNames=True, sAsset='__self__', sVersion='__latest__'):
    sModelPath = assets.assetManager.getModelPath(sAsset, sVersion)
    report.report.addLogText('importing from path: %s' % sModelPath)
    if sModelPath:
        sSelBefore = cmds.ls(sl=True)
        sFilesNames = utils.listFilesInFolder(sModelPath,
                                              sEndswith=['.ma', '.MA', '.mb', '.MB', '.obj', '.OBJ', '.fbx', '.FBX', '.abc'])
        report.report.addLogText('found files: %s' % ', '.join(sFilesNames))
        sFiles = [os.path.join(sModelPath, sF) for sF in sFilesNames]

        sNewNodes = utils.importMayaFiles(sFiles)
        if not sNewNodes:
            report.report.addLogText('nothing got imported!')
            return
        if bCheckClashingNames:
            sAllNewNodes = sNewNodes + cmds.listRelatives(sNewNodes, ad=True, f=True)
            sAllNewNodes = cmds.ls(sAllNewNodes)
            sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
            if sClashingNodes:
                print('---CLASHING NODES---')
                report.report.addLogText('clashing nodes')
                for sN in sClashingNodes:
                    print(sN)
                    report.report.addLogText(sN)

                raise Exception('clashing nodes, check script editor')

        if cmds.objExists('model'):
            [cmds.lockNode(sN, lock=False) for sN in sNewNodes]
            cmds.parent(sNewNodes, 'model')
        for sNode in cmds.listRelatives(sNewNodes, ad=True, typ='transform', f=True) or []:
            if cmds.objectType(sNode) == 'transform':
                try:
                    cmds.setAttr('%s.overrideEnabled' % sNode, False)
                except:
                    pass
        cmds.select(sSelBefore)
    else:
        raise Exception('problem with importing model (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=-8)
def importBlueprints():
    sBlueprintPath = assets.assetManager.getCurrentVersionPath(sSubPath='blueprints.ma')
    print('importing blueprints %s ...' % sBlueprintPath)
    report.report.addLogText('importing blueprint rig: %s' % sBlueprintPath)

    sNewNodes = utils.importMayaFiles([sBlueprintPath])


@builderTools.addToBuild(iOrder=-5)
def importMayaFiles(dSettings={'file.ma':{'sNamespace':'NAMESPACE'}}):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='mayaImport/')

    print('sImportPath: ', sImportPath)

    if os.path.exists(sImportPath):
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.ma', '.mb', '.obj', '.fbx', '.abc'], bAbsolute=True)
        print('sFiles: ', sFiles)
        report.report.resetProgress(len(sFiles))


        if sFiles:
            for sFile in sFiles:
                sFileName = os.path.basename(sFile)
                sNamespace = None
                if sFileName in dSettings:
                    sNamespace = dSettings[sFileName].get('sNamespace', None)
                utils.importMayaFiles(sFile, sNamespace=sNamespace)
        else:
            report.report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sImportPath)
        report.report.addLogText('\ndidn\'t find import path (%s)' % sImportPath)


@builderTools.addToBuild(iOrder=-5)
def importTargets(bOrderByDateOfModification=True):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='targets/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.trg'], bAbsolute=True)
    # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
    print('sFiles: ', sFiles)
    report.report.resetProgress(len(sFiles))

    if sFiles:
        fTimes = [os.path.getmtime(sF) for sF in sFiles]
        if bOrderByDateOfModification:
            aSorted = np.argsort(fTimes)
        else:
            aSorted = np.argsort(sFiles)
        sFiles = np.array(sFiles)[aSorted]

        for sF in sFiles:
            report.report.addLogText('importing %s' % sF)
            export.importTargets(sF)
            report.report.incrementProgress()
    else:
        report.report.addLogText('no files found')


@builderTools.addToBuild(iOrder=0)
def buildPuppet(bReloadLimbs=False, bUeControlRig=False):
    sPuppetFile = assets.assetManager.getCurrentVersionPath(sSubPath='puppet.rig')
    dLimbs = puppetDataUtils.getDictListFromFile(sPuppetFile)

    if bReloadLimbs:
        puppetDataUtils.limbsFromFiles(bReload=True)

    puppetTools.buildRig(all=None, xLimbs=[sPuppetFile, dLimbs], sMaster='master',
                         _bClearBeforeBuild=False, _bReloadLimbs=bReloadLimbs, _bFromUI=False, _bBuildUnrealPuppet=bUeControlRig)





def bindMeshesAutoBind(sIgnoreFiles, bWorldSpaceIfNotMatching, bAlwaysWorldSpace):
    sSel = cmds.ls(sl=True)

    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')

    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles)-set(sIgnoreFiles))
    sFiles.sort(key=lambda x:x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles if sF.startswith('skinCluster__')]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    aFileMeanValues = np.zeros((len(sFiles), 3), dtype='float64')
    dMeshFiles = {}
    for f,sFile in enumerate(sFiles):
        print('\n\n\nsFile: ', sFile)
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)
        with open(sFile, 'rb') as handle:
            loadedDict = pickle.load(handle)

        sKeys = list(loadedDict.keys())
        for sK in sKeys:
            if sK.endswith('_geo'):
                print(sK, ' -> ', loadedDict[sK])
                dMeshFiles[loadedDict[sK]] = sFile
            if 'recreateData' in sK and sK.endswith('_points'):
                aFileMeanValues[f] = np.mean(loadedDict[sK], axis=0)


    for sMesh in sSel:
        if len(deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])):
            continue

        aMeanValue = np.mean(patch.patchFromName(sMesh).getAllPoints(), axis=0)
        aFileDiffs = aFileMeanValues - aMeanValue[np.newaxis,:]
        aLengths = np.linalg.norm(aFileDiffs, axis=-1)
        iMin = np.argmin(aLengths)

        sFile = sFiles[iMin]
        cmds.select(sMesh)
        sLoaded, dSkipped = weights._loadFromFile((sFile,None), iLoadMayaSelection = weights.LoadMayaSelection.loadOntoSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=weights.LoadWorldspace.closestPoints)
        dAllSkipped.update(dSkipped)
        sSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
        if sSkinClusters:
            cmds.rename(sSkinClusters[0], sSkinClusters[0].replace('_', ''))

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=50, dButtons={'bind selected meshes with best fitting files':bindMeshesAutoBind})
def loadDeformers(sIgnoreFiles=[], bWorldSpaceIfNotMatching=False, bAlwaysWorldSpace=False):
    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles) - set(sIgnoreFiles))
    sFiles.sort(key=lambda x: x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    for sFile in sFiles:
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)

        iLoadWorldspace = weights.LoadWorldspace.ignore
        if bAlwaysWorldSpace:
            iLoadWorldspace = weights.LoadWorldspace.closestPoints
        elif bWorldSpaceIfNotMatching:
            iLoadWorldspace = weights.LoadWorldspace.closestPointsIfTopologyDiffers

        sLoaded, dSkipped = weights._loadFromFile((sFile, None),
                                                  iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldspace)
        dAllSkipped.update(dSkipped)

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=101)
def loadCtrlShapes(bDoColor=True):
    sCtrlShapesDir = assets.assetManager.getCurrentVersionPath()
    sCtrlMasters = [sF.split('.')[0] for sF in os.listdir(sCtrlShapesDir) if sF.endswith('.ctrls')]
    print('sCtrlMasters: ', sCtrlMasters)
    for sMaster in sCtrlMasters:
        if sMaster == 'ctrls' and len(
                sCtrlMasters) > 1:  # we have new ctrl files, but didn't delete the one from old system yet
            continue
        if cmds.objExists(sMaster):
            sFilePath = os.path.join(sCtrlShapesDir, '%s.ctrls' % sMaster)
            report.report.addLogText('loading file: %s' % sFilePath)
            ctrls.loadCtrls(sFile=sFilePath, bDoColor=bDoColor)



@builderTools.addToBuild(iOrder=1000)
def clean(bDeleteThem=False, bDeleteDisplayLayers=False):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]
    sOutsideNodes = set(sOutsideNodes) - set([utils.getMasterName(), '__faceData__', '__export__', utils.kGeneralDataNode])
    for sN in sOutsideNodes:
        if bDeleteThem:
            if cmds.objExists(sN):
                cmds.delete(sN)
        else:
            try:
                cmds.setAttr('%s.v' % sN, False)
            except: pass

    if bDeleteDisplayLayers:
        for sL in cmds.ls(et='displayLayer'):
            try:
                cmds.delete(sL)
            except:
                pass

        for sObj in cmds.listRelatives('model', ad=True) or []:
            try:
                cmds.setAttr('%s.overrideEnabled' % sObj, False)
            except:
                report.report.addLogText('WARNING - couldn\'t reset override enabled for %s' % sObj)



@builderTools.addToBuild(iOrder=105)
def defaultCtrlAttrDicts():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            cCtrl.setDefaultAttrDict()


@builderTools.addToBuild(iOrder=130)
def ctrlProximityConnections():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            try:
                cCtrl.setDefaultAttrDict()
            except:
                cmds.warning('couldn\'t setDefaultAttr for %s' % cCtrl)

    sProximityCondition = nodes.createConditionNode('master.ctrlVis', '==', 2, 2, 0, sName='ctrlProximity')
    for sCtrl in cmds.controller(q=True, ac=True):
        sTag = cmds.controller(sCtrl, q=True)[0]
        cmds.connectAttr(sProximityCondition, '%s.visibilityMode' % sTag)


@builderTools.addToBuild(iOrder=150)
def goToDefaultPose():
    sCtrls = [sCtrl for sCtrl in cmds.controller(q=True, ac=True)]

    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



@builderTools.addToBuild(iOrder=1000)
def prepareAnimPicker(sCharacter='FullCharacter'):
    sAnimPicker = cmds.createNode('transform', n='AnimPickerData', p=utils.getMasterName())
    utils.addStringAttr(sAnimPicker, 'character', sCharacter)



@builderTools.addToBuild(iOrder=1010)
def prepareForPublish(sRenameMaster='master', bDeleteUnrealModel=True):
    '''

    '''
    # utils.data.store('bVersionFolders', True, sNode=utils.kExportNode)

    cmds.flushUndo()

    sAsset = assets.assetManager.getCurrentAsset()
    sUnrealModel = utils.data.get('sUnrealModel', None)
    if not sUnrealModel:
        bDeleteUnrealModel = False

    utils.addStringAttr('master', 'sOldMasterName', 'master')
    sMaster = cmds.rename('master', sRenameMaster)
    ddMasters = {sMaster:{'sFilename':'RIG_%s_[v].ma' % sAsset,
                           'sExtraFiles': 'fbx/RIG_%s.fbx' % (sAsset),
                           'sDelete':['GAMEMODEL'] if bDeleteUnrealModel else []}}
    utils.data.store('ddMasters', ddMasters, sNode=utils.kExportNode)
    utils.data.store('bSaveInsteadOfExport', True, sNode=utils.kExportNode)

    # dConfirms = {'Did you export FBX?':[('Yes', True),
    #                                   ('No, but I don\'t care.', True),
    #                                   ('Oops.. please cancel', False)]}
    # utils.data.store('dConfirms', dConfirms, sNode=utils.kExportNode)


dButtons = {}



@builderTools.addToBuild(iOrder=-1002, bDisableByDefault=True)
def mayaVersionChecker(sVersion='2022'):
    sCurrentVersion = cmds.about(version=True)
    sVersion = str(sVersion)
    if sCurrentVersion != sVersion:
        raise Exception('Current version is %s, but it needs to be built in %s' % (sCurrentVersion, sVersion))


@builderTools.addToBuild(iOrder=90)
def puppetCustomAttachments(bLegacyWrongDeformerOrder=False):
    return constraints.setupAllPuppetCustomAttachments(bRotateByNeighborVerts=True, bLegacyWrongDeformerOrder=False, bLegacyIgnoreScale=False)




def exportFbxButton():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    sAsset = assets.assetManager.getCurrentAsset()

    if not os.path.exists(sPath):
        os.makedirs(sPath)
    sFilePath = os.path.join(sPath, 'GAME_%s.fbx' % sAsset).replace('\\', '/')

    report.report.incrementProgress()


    # unreal
    bUnrealExists = cmds.objExists('GAMESKELETON')
    if not bUnrealExists:
        report.report.addLogText('====== no unreal rig in scene!!! ======')
        return
    else:
        report.report.addLogText('\nexporting %s' % sFilePath)

    sNodes = ['GAMESKELETON', 'GAMEMODEL']
    cmds.parent(sNodes, w=True)

    sAllConnections = []
    report.report.addLogText('temporarily unplugging connections..', bRefresh=True, bIncrementProgress=True)
    try:
        for sNode in cmds.listRelatives('GAMESKELETON', ad=True, typ='joint'):
            sConnections = cmds.listConnections(sNode, s=True, d=False, p=True, c=True) or []
            for i in range(0,len(sConnections),2):
                cmds.disconnectAttr(sConnections[i+1], sConnections[i])
            sAllConnections += sConnections

        report.report.addLogText('exporting..', bRefresh=True, bIncrementProgress=True)
        for sN in cmds.ls(sNodes, dag=True):
            cmds.setAttr('%s.overrideEnabled' % sN, False)
            cmds.setAttr('%s.v' % sN, True)
        cmds.select(sNodes)

        sExportString = 'FBXExport -f "%s" -FBXExportSmoothingGroups True -s' % sFilePath.replace('\\', '/')
        mel.eval('FBXResetExport')
        mel.eval(sExportString)
    except:
        raise
    finally:
        for i in range(0,len(sAllConnections),2):
            cmds.connectAttr(sAllConnections[i+1], sAllConnections[i])
        cmds.parent(sNodes, utils.getMasterName())
        [cmds.setAttr('%s.v' % sNode, False) for sNode in sNodes]




def explorerFbx():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    utils.openExplorer(sPath)


# def dumpUnrealCodeLinesToFile():
#     import kangarooTools.utilsUnreal as utilsUnreal
#     utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=130, bDisableByDefault=True, dButtons={'export FBX':exportFbxButton, 'explorer FBX':explorerFbx,
                                                                       'Print ThomasRiggingNode code':unreal.printAllThomasBittnerRiggingNodeCode})
def createUnrealSkeleton(bRemoveJointsWithoutBindPose=False, bLeavifyLimbs=False,
                         bConnectBlendShapeAnim=False, bSkipUnchangedOnBlendShapeBake=True, bLiveLinkJoints=False):

    cmds.namespace(add='game')


    sDupl = cmds.duplicate('skeleton', n='GAMESKELETON')[0]
    sChildren = cmds.listRelatives(sDupl, c=True, p=False, f=True)

    sRoot = cmds.createNode('joint', n='game:root', p=sDupl)

    cmds.parent(sChildren, sRoot)
    sJoints = cmds.listRelatives(sRoot, ad=True, f=True)
    sJoints.sort(key=lambda a: len(a), reverse=True)
    dJoints = {}

    dCollapsedUnrealJoints = {}

    for sJ in sJoints:
        sUnrealCollapseJointsAttr = '%s.unrealCollapseJoints' % sJ
        if cmds.objExists(sUnrealCollapseJointsAttr):
            for sCollapsedJ in eval(cmds.getAttr(sUnrealCollapseJointsAttr)):
                dCollapsedUnrealJoints[sCollapsedJ] = sJ.split('|')[-1]

        sName = sJ.split('|')[-1]
        sNewName = 'game:%s' % sName
        cmds.rename(sJ, sNewName)
        dJoints[sName] = sNewName

        sChildren = cmds.listRelatives(sNewName, c=True, p=False)
        if sChildren:
            sChildren = [sN for sN in sChildren if cmds.objectType(sN) in ['transform', 'join']]
            if sChildren:
                cmds.parent(sChildren, w=True)

        # if bChangeAxis:
        #     cmds.rotate(0, -90, -90, sNewName, os=True, r=True)
        if sChildren:
            cmds.parent(sChildren, sNewName)

        if cmds.objectType(sName) == 'joint':
            cmds.parentConstraint(sName, sNewName, mo=True)



    # clean up (joint segments, and clean transform groups
    report.report.addLogText('Unrealify Joint Hierarchy', bRefresh=True)
    unreal.unrealifyJointHierarchy('GAMESKELETON', bCollapseUnrealJoints=False, bNamespace=True)

    def _getUnrealJoint(__sJ):
        return 'game:%s' % __sJ


    def _getAnimJoint(__sJ):
        return __sJ.split(':')[-1]

    sMuscles = [sJ for sJ in cmds.ls('game:muscleJnt_*', et='joint') if not sJ.endswith('End')]
    for sJ in sMuscles:
        sParent = _getUnrealJoint(cmds.getAttr('%s.startSpace' % sJ))
        sCurrentParent = cmds.listRelatives(sJ, p=True)[0]
        if sParent != sCurrentParent:
            cmds.parent(sJ, sParent)


    xforms.matrixParentConstraint('global_ctrl', sRoot, bChildParentIsInOrigin=True)
    for sJ in cmds.listRelatives(sRoot, ad=True):
        sOther = _getAnimJoint(sJ)
        if sOther == sJ:
            report.report.addLogText('skipping "%s", there is no master joint' % sJ, bRefresh=True)
        else:
            xforms.matrixParentConstraint(sOther, sJ, bAvoidCycle=False)

    # create model
    # switch off deformers for duplicate
    dPrevSkinClusterStates = {}
    dPrevBlendShapeStates = {}
    sBlendshapeMeshes = []


    report.report.addLogText('Duplicate the models...', bRefresh=True)


    report.report.incrementProgress()
    for sMesh in utils.listMeshes('model'):
        sDeformers = deformers.listAllDeformers(sMesh)
        for sD in sDeformers:
            if cmds.objectType(sD) == 'skinCluster':
                dPrevSkinClusterStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
            elif cmds.objectType(sD) == 'blendShape':
                dPrevBlendShapeStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
                sBlendshapeMeshes.append(sMesh)
            else:
                continue
            cmds.setAttr('%s.nodeState' % sD, 1)

    sBlendshapeMeshes = list(set(sBlendshapeMeshes))

    sUnrealModel = 'GAMEMODEL'
    sUnrealModelChildren = cmds.duplicate('model', n=sUnrealModel)[1:]

    sFullNames = [sN for sN in cmds.ls(sUnrealModelChildren, l=True) if sUnrealModel in sN]
    sFullNames = sorted(sFullNames, key=lambda a: len(a), reverse=True)
    for n,sN in enumerate(sFullNames):
        sName = sN.split('|')[-1]
        sFullNames[n] = cmds.rename(sN, 'game:%s' % sName)

    report.report.resetProgress(len(utils.flattenedList(sFullNames)))
    report.report.addLogText('clean up meshes for lod %s' % 'model')
    for sN in sFullNames:
        report.report.incrementProgress()
        if  cmds.objectType(sN) == 'transform':
            sAllShapes = cmds.listRelatives(sN, s=True, f=True) or []
            sNoIntermShapes = cmds.listRelatives(sN, s=True, ni=True, f=True) or []
            sDeleteShapes = set(sAllShapes) - set(sNoIntermShapes)
            sKeepShapes = set(sAllShapes) - set(sDeleteShapes)
            if sDeleteShapes:
                cmds.delete(list(sDeleteShapes))

            # fix shapes that don't get renamed
            for sS in sKeepShapes:
                sNameS = sS.split('|')[-1]
                if not sNameS.startswith('game:'):
                    cmds.rename(sS, 'game:%s' % sNameS)


    # set back blendShapes
    [cmds.setAttr(sA,fV) for sA,fV in list(dPrevBlendShapeStates.items())]

    report.report.addLogText('transfer blendShapes', bRefresh=True)
    # transfer blendshaes
    sBlendShapesToBake = []

    sBlendShapeJoint = cmds.listRelatives('GAMESKELETON', ad=True, typ='joint')[-1]
    for sBody in sBlendshapeMeshes:
        sBlendShapes = deformers.listAllDeformers(sBody, sFilterTypes=['blendShape'])
        if len(sBlendShapes) > 1:
            raise Exception('there are more than one blendShapes for %s' % sBody)

        sBs = sBlendShapes[0]
        sTargetMeshes, sAliases, sSkippedTargets = blendShapes.bake(sBody, sBs, bSkipUnchanged=bSkipUnchangedOnBlendShapeBake)

        report.report.addLogText('\nSkipped %d BlendShape Targets of %d for "%s"' %
                                 (len(sSkippedTargets), len(sSkippedTargets) + len(sTargetMeshes), sBody))
        for sSkippedT in sSkippedTargets:
            report.report.addLogText('Skipped Target "%s"...' % sSkippedT)

        sSourceAttrs = ['%s.%s' % (sBs,sA) for sA in sAliases]
        sBlendShapesToBake.append(sBs)

        sAliasDupls = utils.getDuplicates(sAliases)
        if sAliasDupls:
            raise Exception('The alias %s appears in more than one blendShapes' % utils.listToString(sAliasDupls))

        sBlendShape = cmds.blendShape(sTargetMeshes, 'game:%s' % sBody)[0]
        deformers.makeNotExport(sBlendShape)
        sUnrealTargets = ['%s.%s' % (sBlendShape,sT) for sT in blendShapes.getOrderedTargets(sBlendShape)]

        if bConnectBlendShapeAnim:
            for t,sT in enumerate(sAliases):
                cmds.connectAttr(sSourceAttrs[t], sUnrealTargets[t])
                sBlendShapeJointAttr = '%s.%s' % (sBlendShapeJoint, sT)
                if not cmds.objExists(sBlendShapeJointAttr):
                    cmds.addAttr(sBlendShapeJoint, ln=sT, k=True)
                    cmds.connectAttr(sSourceAttrs[t], sBlendShapeJointAttr)

        cmds.delete(sTargetMeshes)

    # set back skinClusters
    [cmds.setAttr(sA,fV) for sA,fV in list(dPrevSkinClusterStates.items())]

    if bLiveLinkJoints:
        unreal.generateBlendShapeValueJointsFromMeshes(sMeshes=sBlendshapeMeshes, sParentJoint=sRoot)
        sJoints = cmds.ls('liveLink__**', et='joint')
        for sJ in sJoints:
            sTargets = eval(cmds.getAttr('%s.sTargets' % sJ))
            sName = 'liveLink__%s' % '__'.join(sTargets)
            cmds.rename(sJ, sName)

    if bLeavifyLimbs:
        sFirstTwistJoints = cmds.ls('game:jnt_*Twist_000', et='joint')
        unreal.leavifyTwistJoints(sFirstTwistJoints)


    report.report.addLogText('bind new geometry', bRefresh=True)

    utils.addStringAttr('GAMEMODEL', 'sBlendShapes', sBlendShapesToBake, bLock=True)

    # bind new geometry
    sUnrealMeshes = utils.listMeshes('GAMEMODEL')
    report.report.resetProgress(len(sUnrealMeshes))
    for sUnrealM in sUnrealMeshes:
        report.report.addLogText('binding mesh %s' % sUnrealM, bIncrementProgress=True)

        sM = utils.replaceStringStart(sUnrealM, 'game:', '')
        if not cmds.objExists(sM):
            raise Exception('this mesh doesn\'t exist: %s (%s)' % (sM, sUnrealM))
        pM = patch.patchFromName(sM)
        pUnrealM = patch.patchFromName(sUnrealM)
        if deformers.listAllDeformers(sM, sFilterTypes=['skinCluster']):
            weights.transferSkinCluster([pUnrealM], sFrom=sM, iMode=weights.TransferMode.vertexIndex, funcMapJoint=_getUnrealJoint, bLogReport=False, bPostNormalize=True)

            sOldSkinCluster, _ = pM.getSkinCluster(bSkipWeights=True)
            sUnrealSkinCluster, _ = pUnrealM.getSkinCluster(bSkipWeights=True)

            sConns = cmds.listConnections('%s.matrix' % sOldSkinCluster, p=True, c=True, d=False, s=True)
            # skinCluster__body_ply.matrix[0]', u'jnt_l_thumbMid.worldMatrix', u'skinCluster__body_ply.matrix[1]', u'jnt_l_thumbBase.worldMatrix..
            dOldReferencePlugs = {}
            for c in range(0, len(sConns), 2):
                sSkinClusterPlug = sConns[c]
                sReferencePlug = sSkinClusterPlug.replace('.matrix[', '.bindPreMatrix[')
                sJointMatrix = sConns[c+1]
                dOldReferencePlugs[sJointMatrix.split('.')[0]] = sReferencePlug

            sUnrealConns = cmds.listConnections('%s.matrix' % sUnrealSkinCluster, p=True, c=True, d=False, s=True)
            for c in range(0, len(sUnrealConns), 2):
                sUnrealSkinClusterPlug = sUnrealConns[c]
                sUnrealJ = sUnrealConns[c+1].split('.')[0]

                sJ = _getAnimJoint(sUnrealJ)

                sUnrealReferencePlug = sUnrealSkinClusterPlug.replace('.matrix[', '.bindPreMatrix[')
                # if sJ not in dOldReferencePlugs:
                #     raise Exception, 'problem transferring mesh "%s" ("%s"), you may have skinweights assigned to joints that get deleted ' % (sM, sJ)

                bFoundReferencePlug = False
                for _sJ in [sJ]:
                    if _sJ in dOldReferencePlugs:
                        cmds.setAttr(sUnrealReferencePlug, cmds.getAttr(dOldReferencePlugs[_sJ]), type='matrix')
                        bFoundReferencePlug = True
                if not bFoundReferencePlug:
                    print('dOldReferencePlugs: ', dOldReferencePlugs)
                    raise Exception('problem transferring mesh "%s" ("%s"), you may have skinweights assigned to joints that get deleted ' % (sM, [sJ] + sCollapsedNonExistingUnrealJoints))



    # if bUnrealNamespaceForMeshes:
    #     cmds.namespace(add='game')
    #     for sNode in cmds.listRelatives('GAMEMODEL', ad=True):
    #         cmds.rename(sNode, sNode.replace('unreal_', 'game:'))


    cmds.setAttr('GAMEMODEL.v', False)
    cmds.setAttr('GAMESKELETON.v', False)


    if bRemoveJointsWithoutBindPose:
        sJoints = cmds.listRelatives('GAMESKELETON', typ='joint', ad=True, f=True)
        sJoints.sort(key=lambda a: len(a), reverse=True)
        for sJ in sJoints:
            if not cmds.listConnections(sJ, t='dagPose'):
                if not cmds.listRelatives(sJ, c=True):
                    cmds.delete(sJ)

    if utils.data.exists('sUnrealCodeLines'):
        utilsUnreal.generateControlShapeCode()
        utilsUnreal.generateMuscleJointsCode()




