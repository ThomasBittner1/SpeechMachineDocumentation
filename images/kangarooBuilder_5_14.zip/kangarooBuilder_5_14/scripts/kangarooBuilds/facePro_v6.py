###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



'''

changes from _v3:
eye_r_ctrl keeps the orientation now. in V3 it was flipped to make it parallel. However now the new
function ParallelEyes is taking care of it

'''


from collections import OrderedDict, defaultdict
import numpy as np
import os
import kangarooTools.patch as patch
import kangarooTools.report as report
import time
import pickle
import math

QtWidgets, QtGui, QtCore = utils.importQtModules()


import kangarooShapeEditor.kangarooShapeEditorTools as kangarooShapeEditorTools

import kangarooTabTools.builder as builderTools
import kangarooTabTools.unreal as unreal

import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.barycentric as barycentric
import kangarooTools.topology as topology
import kangarooTools.curves as curves
import kangarooTools.surfaces as surfaces
import kangarooTools.nodes as nodes
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.constraints as constraints
import kangarooTabTools.blendShapesPro as blendShapesPro
import kangarooTabTools.weights as weights
import kangarooTabTools.ctrls6 as ctrls6
import kangarooTabTools.geometry as geometry
import kangarooTools.utilsUnreal as utilsUnreal

iColorIndexCtrls = 0
kBuilderColor = utils.uiColors.orange
kEyelidBuilderColor = utils.uiColors.orangeDark


sHeadCtrl = None
def headCtrl():
    global sHeadCtrl
    if sHeadCtrl == None:
        sHeadCtrl = utils.translateCtrlName('ctrl_m_head')
    return sHeadCtrl

sJawCtrl = None
def jawCtrl():
    global sJawCtrl
    if sJawCtrl == None:
        sJawCtrl = utils.translateCtrlName('ctrl_m_jaw')
    return sJawCtrl


def exportBps(sFileName, sGroup):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    print('exporting "%s" to "%s" ' % (sGroup, sFile))
    report.report.addLogText('exporting "%s" to "%s" ' % (sGroup, sFile))
    utils.createFolderIfNotExists(sFile)

    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #


def createTransformFromSelectedPoints(sName, sParent, bLockToMiddle=False, sSkinningSphere=None, bNoTransform=False):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.spaceLocator(n=sName)[0]
    print('aMean: ', aMean)
    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))

    if bLockToMiddle:
        for sL in ['%s.%s' % (sLoc, sAttr) for sAttr in ['tx', 'ry', 'rz']]:
            cmds.setAttr(sL, 0.0)
            cmds.setAttr(sL, lock=True)

    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        print('bNoTransform:', bNoTransform)
        if bNoTransform:
            cmds.parent(sSkinningSphere, sParent)
            cmds.delete(sLoc)
    return sLoc




def createMatrixCtrlromSelectedPoints(sName, sParent, sSkinningSphere=None, fRotate=(0,0,0)):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls6.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    fnMesh = OpenMaya2.MFnMesh(pSel.mDagPath)
    _, mNormal, _ = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(list(aMean)), space=OpenMaya2.MSpace.kWorld)

    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    xforms.orientThreePoints(sLoc, (mNormal.x, mNormal.y, mNormal.z), (0, 0, -1), fAimVector=(0, 0, 1),
                             fUpVector=(1, 0, 0))

    cmds.rotate(fRotate[0], fRotate[1], fRotate[2], sLoc, r=True, os=True)
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))
    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        cmds.parent(sSkinningSphere, sParent)


def createMatrixCtrlFromTransform(sName, sParent, sTransform=None):
    if sTransform == None:
        sTransform = cmds.ls(sl=True)[0]

    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls6.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    cmds.delete(cmds.parentConstraint(sTransform, sLoc))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))



def mirrorGroup(sGrp, bDeleteNewChildren=False):
    sMirrorName = utils.getMirrorName(sGrp)
    if not cmds.objExists(sMirrorName):
        if not cmds.objExists(sGrp):
            return None
        sMirrorGrp = cmds.duplicate(sGrp, n=sMirrorName)[0]
        if bDeleteNewChildren:
            cmds.delete(cmds.listRelatives(sMirrorGrp, c=True, f=True))

        sTemp = cmds.createNode('transform')
        sOldParent = cmds.listRelatives(sMirrorGrp, p=True)
        cmds.parent(sMirrorGrp, sTemp)
        cmds.setAttr('%s.sx' % sTemp, -1)
        if sOldParent:
            cmds.parent(sMirrorGrp, sOldParent)
        else:
            cmds.parent(sMirrorGrp, w=True)
        # cmds.setAttr('%s.tx' % sMirrorGrp, -cmds.getAttr('%s.tx' % sMirrorGrp))

        cmds.delete(sTemp)
        return sMirrorGrp
    return sMirrorName


def createBpCurve(sName, sParent, fDirection=(1, 0, 0), bTrackedOrder=False):  # , bInToOut=None, bBotToTop=None):
    if cmds.objExists(sName):
        cmds.delete(sName)
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sCurve = curves.createCurveFromSelectedVerts(sName=sName, fDirection=fDirection,
                                                 bTrackedSelectionOrder=bTrackedOrder)
    utils.addStringAttr(sCurve, 'sMesh', sMesh)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.select(sCurve)


def createBothBpCurves(sName, sParent, fDirection=(1, 0, 0)):
    # if cmds.objExists(sName): cmds.delete(sName)
    # utils.reload2(curves)
    sCurve, sLocA, sLocB = curves.createCurveWithSeparationLocs(sName, fDirection=fDirection)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.parent(sLocA, sLocB, sCurve)
    cmds.select(sCurve)


def createBpUpVectorCurve(sName, sMainCurve):
    sMesh = cmds.getAttr('%s.sMesh' % sMainCurve)
    if not cmds.objExists(sMainCurve):
        raise Exception('"%s" doesn\'t exist - make sure you run the previous steps' % sMainCurve)
    if not cmds.objExists(sMesh):
        raise Exception('"%s" doesn\'t exist anymore' % sMesh)

    fClosest = cmds.kt_findClosestPoints(fromMesh=sMainCurve, toMesh=sMesh, returnNormals=True)
    aClosest = np.array(fClosest, dtype='float64').reshape(-1, 6)
    aNormals = aClosest[:, 3:6]
    aNormals /= np.linalg.norm(aNormals, axis=1).reshape(-1, 1)
    fLength = curves.getLength(sMainCurve)

    if cmds.objExists(sName):
        cmds.delete(sName)
    sNewCurve = cmds.duplicate(sMainCurve, n=sName)[0]
    pNewCurve = patch.patchFromName(sNewCurve)
    aPushedOutPoints = pNewCurve.getPoints() + aNormals * (fLength * 0.1)
    pNewCurve.setPoints(aPushedOutPoints)


def _getFaceCtrlGrp():
    sName = 'faceCtrls'
    if not cmds.objExists(sName):
        sSelBefore = cmds.ls(sl=True)
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.ctrlVis' % sMaster, '%s.v' % sName)
        cmds.select(sSelBefore)

    return sName


def getFaceGrp():
    sName = 'faceRig'
    if not cmds.objExists(sName):
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sName)
    return sName


def getParentJointOrigin(sParentJoint):
    sName = '%sOrigin' % sParentJoint
    if not cmds.objExists(sName):
        xforms.createJoint(sName, sParent=getFaceGrp(), sMatch=sParentJoint)
    return sName



# def recordJawPose(_uiArgs=None):
#     fRotation = cmds.getAttr('jaw_ctrl.r')[0]
#     fTranslation = cmds.getAttr('jaw_ctrl.t')[0]
#     _uiArgs['fRotation'].setText(str(fRotation))
#     _uiArgs['fTranslation'].setText(str(fTranslation))



@builderTools.addToBuild(iOrder=10, dButtons={}, bDisableByDefault=True)
def reloadModules():
    utils.reload2(blendShapesPro)

@builderTools.addToBuild(iOrder=62.1, dButtons={}, bDisableByDefault=True)
def jawAutoTranslate(fOverwriteRotation=None, fOverwriteTranslation=None, sSuffix=''):
    '''
    in order for this to work, make sure in the blueprints the polevector is pointing down, and the
    fAdjustAxisOrientation is [0,0,0]
    Basically minus rotateZ is opening the jaw

    This should be taken from the blendShape
    '''

    #
    # if not utils.data.exists('sBakedBlendShapeJawOpenTranslation%s' % sSuffix):
    #     report.report.addLogText('no jawOpen setup from blendShape file')
    #     return False

    if utils.isNone(fOverwriteTranslation):
        fTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation%s' % sSuffix)
        report.report.addLogText('taking from blendShape file translation: %s' % str(fTranslation))
    else:
        fTranslation = fOverwriteTranslation

    if utils.isNone(fOverwriteRotation):
        fRotation = utils.data.get('sBakedBlendShapeJawOpenRotation%s' % sSuffix)
        report.report.addLogText('taking from blendShape file rotation: %s' % str(fRotation))
    else:
        fRotation = fOverwriteRotation

    fDriverValue = fRotation[2]


    sJawCtrl = 'jaw%s_ctrl' % sSuffix
    sJawJoint = 'jnt_m_jaw%sMain' % sSuffix

    cmds.setAttr('%s.r' % sJawCtrl, 0,0,0)
    cmds.setAttr('%s.t' % sJawCtrl, 0,0,0)

    cCtrl = ctrls6.ctrlFromName(sJawCtrl)
    sOffsetTranslation = cCtrl.appendOffsetGroup('poseTranslation')
    sOffsetRotation = cCtrl.appendOffsetGroup('poseRotation')

    sDriverValue = '%s.rz' % sJawCtrl
    sDriverValueClampedPre = nodes.createClampNode(sDriverValue, 0, 10000000)
    sDriverValueClampedPost = nodes.createClampNode(sDriverValue, -10000000, fDriverValue)
    sDriverValueClampedOffsetPost = nodes.createAdditionNode([sDriverValueClampedPost, fDriverValue], sOperation='minus')

    # sRotation = nodes.createVectorAdditionNode([fRotation, [0,0,sDriverValue]], sOperation='minus')

    sRangeRot = nodes.createRangeNode(sDriverValue, 0, fDriverValue, [0,0,0], fRotation,
                                      bOutRangeIsVector=True)

    sSubtract = nodes.createVectorAdditionNode([sRangeRot, [0,0,sDriverValue]],
                                               sOperation='minus')

    # to do: add overshoot and undershoot
    nodes.createVectorAdditionNode([[0,0,sDriverValueClampedPre], sSubtract, [0,0,sDriverValueClampedOffsetPost]], sTarget='%s.r' % sOffsetRotation)

    nodes.createRangeNode(sDriverValue, 0, fDriverValue, [0,0,0], fTranslation,
                          sTarget='%s.t' % sOffsetTranslation, bOutRangeIsVector=True)

    utils.addStringAttr(sJawJoint, 'fOpenRotation', str(fRotation))
    utils.addStringAttr(sJawJoint, 'fOpenTranslation', str(fTranslation))

    utils.data.store('fJawAutoTranslateDriverValue%s' % sSuffix, fDriverValue, sNode=utils.kFaceDataNode)

    sUnrealCommands = []
    sUnrealCommands.append('\n\n# auto jaw\n')
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox()")
    sUnrealCommands.append("eJawOffset = jaw_ctrl.addOffset('auto')")

    sUnrealCommands.append("fDriverValue = %0.3f" % fDriverValue)
    sUnrealCommands.append("sDriverValue = '%s.Pitch' % nodes.getControlRotator(jaw_ctrl.eControl, bLocal=True)")
    sUnrealCommands.append("sDriverValueClampedPre = nodes.createClampNode(sDriverValue, 0, 10000000)")
    sUnrealCommands.append("sDriverValueClampedPost = nodes.createClampNode(sDriverValue, -10000000, fDriverValue)")
    sUnrealCommands.append("sDriverValueClampedOffsetPost = nodes.createBasicCalculateNode([sDriverValueClampedPost, fDriverValue], sOperation='Subtract')")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("sRangeRot = nodes.createRemapNode(sDriverValue, 0, fDriverValue, [0,0,0], %s, bOutIsVector=True)" % utilsUnreal.flipVectorToUnreal(fRotation))
    sUnrealCommands.append("sSubtract = nodes.createBasicCalculateNode([sRangeRot, [0,sDriverValue,0]], sOperation='Subtract', iPinType=pins.PinType.integer)")
    sUnrealCommands.append("sOffsetRotationValue = nodes.createBasicCalculateNode([[0,sDriverValueClampedPre,0], sSubtract, [0,sDriverValueClampedOffsetPost,0]], sOperation='Add', iPinType=pins.PinType.vector)")
    sUnrealCommands.append("sOffsetTranslationValue = nodes.createRemapNode(sDriverValue, 0, fDriverValue, [0,0,0], %s, bOutIsVector=True)" % utilsUnreal.flipVectorToUnreal(fTranslation))
    sUnrealCommands.append("sQuat = nodes.createFromEulerNode(sOffsetRotationValue)")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("nodes.createSetTransformExecuteNode(eJawOffset, [sOffsetTranslationValue, sQuat, None], bLocal=True)")
    sUnrealCommands.append("controllers.closeCommentBox('Auto Jaw')")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()







def mainBrowOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_mainBrow', [0, 0.5, 1])
    sNames = ['A', 'B', 'C']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sMainBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls6.createSimpleCurve('matrixNames', sName='bpLoc_l_mainBrowOrientation%s' % sNames[i], sParent=sBrowsMainGrp)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)



def bindMainEyebrows():
    sBody = cmds.ls(sl=True)[0]
    sJoints = [sJ for sJ in cmds.ls('jnt_?_brows_*', et='joint') if not sJ.endswith('_ref') and 'Inf' not in sJ]
    sJoints += cmds.ls('jnt_?_*Eyebrow', et='joint')

    sSkinCluster = 'skinCluster__%s' % sBody
    if cmds.objExists(sSkinCluster):
        deformers.addInfluences(sSkinCluster, sJoints)
    else:
        deformers.skinMesh(sBody, sJoints)




sBrowsMainGrp = '_grp_m_browsBpMain'

dSelectSiblingsMenu = {}
dSelectSiblingsMenu['all'] = lambda:cmds.select(cmds.ls('grp_l_brow*_*Sibling*', et='transform'))

dSelectSiblingsMenu['all post'] = lambda:cmds.select(cmds.ls('grp_l_brow*_postSibling*', et='transform'))
dSelectSiblingsMenu['all pre'] = lambda:cmds.select(cmds.ls('grp_l_brow*_preSibling*', et='transform'))
dSelectSiblingsMenu['all post up'] = lambda:cmds.select(cmds.ls('grp_l_brow*_postSiblingUp', et='transform'))
dSelectSiblingsMenu['all pre down'] = lambda:cmds.select(cmds.ls('grp_l_brow*_preSiblingDown', et='transform'))
dSelectSiblingsMenu['inner pre tangent'] = lambda:cmds.select(cmds.ls('grp_l_browTangentAOutOffset_preTangentSibling*', et='transform'))

dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_mainBrow', sBrowsMainGrp, fDirection=(1, 0, 0))
dButtons['Create Left Brow Curve'].dSideButtons = {'?':['eyebrowVerts.jpg']}
dButtons['Create Left Brow Orientation Locators'] = mainBrowOrientationLocators
dButtons['=== SELECT LEFT SIBLINGS ==='] = dSelectSiblingsMenu
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsBrows', 'dDefaultSettingValuesBrows')

dButtons['Add Influences to Selected'] = bindMainEyebrows

dButtons['- Export Brows Main BPs -'] = lambda: exportBps('faceBlueprintsBrowsMain.ma', sBrowsMainGrp)


@builderTools.addToBuild(iOrder=30, dButtons=dButtons, bDisableByDefault=True)
def browsSplines(sAttachMesh='', iCurveJoints=None, sVisAttrCtr='head_ctrl', sParentJoint='jnt_m_headMain', bMiddleCtrl=True, dDefaultSettingValuesBrows={}):
    sDefaultSettingAttrsBrows = []
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    sCtrlVis = utils.addOffOnAttr(utils.toList(sVisAttrCtr)[0], 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    utils.data.store('iBrowCurveJoints', iCurveJoints, sNode=utils.kFaceDataNode)

    sBrowsOrig = cmds.createNode('transform', name='grp_browsOrig', p=getFaceGrp())


    # sSkinJoints = []

    sBpCurves = ['bpCurve_%s_mainBrow' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleBrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv)

    bJointsPerCvs = True if isinstance(iCurveJoints, type(None)) else False

    print('bJointsPerCvs: ', bJointsPerCvs)

    aaCurvePoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                    curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aaCtrlPoints = [[aaCurvePoints[0][0], aaCurvePoints[0][3], aaCurvePoints[0][6]],
                    [aaCurvePoints[1][0], aaCurvePoints[1][3], aaCurvePoints[1][6]]]

    sCurves = [cmds.curve(p=aaCurvePoints[0], n='curve_l_brows'), cmds.curve(p=aaCurvePoints[1], n='curve_r_brows')]


    if bJointsPerCvs:
        aaPoints = [np.array(cmds.xform('%s.cv[*]' % sBpCurves[0], q=True, ws=True, t=True)).reshape(-1,3),
                    np.array(cmds.xform('%s.cv[*]' % sBpCurves[1], q=True, ws=True, t=True)).reshape(-1,3)]
        ffParams = [curves.getParamsFromPoints(sCurves[0], aaPoints[0]),
                    curves.getParamsFromPoints(sCurves[1], aaPoints[1])]
    else:
        ffParams = [curves.getParamsFromPercs(sCurves[0], np.linspace(0.0, 1.0, iCurveJoints)),
                    curves.getParamsFromPercs(sCurves[1], np.linspace(0.0, 1.0, iCurveJoints))]
        aaPoints = [curves.getPointsFromParams(sCurves[0], ffParams[0], bReturnNumpy=True),
                    curves.getPointsFromParams(sCurves[1], ffParams[1], bReturnNumpy=True)]



    aaaWeights = [utils.bSpline3([1,0,0], len(aaPoints[0])),
                 utils.bSpline3([0,1,0], len(aaPoints[0])),
                 utils.bSpline3([0,0,1], len(aaPoints[0]))], \
                [utils.bSpline3([1, 0, 0], len(aaPoints[1])),
                 utils.bSpline3([0, 1, 0], len(aaPoints[1])),
                 utils.bSpline3([0, 0, 1], len(aaPoints[1]))]

    # collect orients
    ssBpOrients = []
    for s,sSide in enumerate(['l','r']):
        sBpOrients = []
        for sName in ['A', 'B', 'C']:
            sBpOrient = 'bpLoc_%s_mainBrowOrientation%s' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_mainBrowOrientation%s' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    xforms.mirrorCurveTransforms(sLeftBpOrient)
            sBpOrients.append(sBpOrient)
        ssBpOrients.append(sBpOrients)

    # make up curves
    aaCurveUpPoints = []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1

        aaPushForwardWeights =  [utils.bSpline3([1, 0, 0], 7),
                                  utils.bSpline3([0, 1, 0], 7),
                                  utils.bSpline3([0, 0, 1], 7)]

        aForwardPoints =    utils.getNumpyMatrixFromTransform(ssBpOrients[s][0])[2,0:3] * aaPushForwardWeights[0][:,np.newaxis] + \
                            utils.getNumpyMatrixFromTransform(ssBpOrients[s][1])[2,0:3] * aaPushForwardWeights[1][:,np.newaxis] + \
                            utils.getNumpyMatrixFromTransform(ssBpOrients[s][2])[2,0:3] * aaPushForwardWeights[2][:,np.newaxis]
        aCurveUpPoints = aaCurvePoints[s] + aForwardPoints * fSliderScale * fSideMultipl
        aaCurveUpPoints.append(aCurveUpPoints)


    sUpCurves = [cmds.curve(p=aaCurveUpPoints[0], n='curve_l_browsUp'), cmds.curve(p=aaCurveUpPoints[1], n='curve_r_browsUp')]


    for sCrv in (sCurves + sUpCurves ):
        cmds.parent(sCrv, sBrowsOrig)

    sInvParentRotationMatrix = nodes.getRotationMatrix2('%s.worldInverseMatrix' % sParentJoint)
    ccCtrls = [], []
    cMainCtrls = []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1

        aUps = np.zeros((2, 3, 3), dtype='float64')

        for c, sName in enumerate(['A', 'B', 'C']):

            cC = ctrls6.create(sName='browSplines%s' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(), fMatchPos=aaCtrlPoints[s][c], sShape='cube', fSliderScale=fSliderScale,
                               sAttrs=['t','r','sy','sz'], fSize=0.25)
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            ccCtrls[s].append(cC)
            sPoseOffset = cC.appendOffsetGroup('pose')

            sBpOrients[s] = 'bpLoc_%s_mainBrowOrientation%s' % (sSide, sName)

            aMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sBpOrients[s]), dtype='float64').reshape(4, 4)
            aUps[s, c] = aMatrix[1][:3] * fSideMultipl
            cC.sUnscaledCtrl = xforms.insertParent(cC.sOut, 'grp_%s_browUnscaled%s' % (sSide, sName), bMatchParentTransform=True)
            nodes.createVectorMultiplyNode([1,1,1], '%s.s' % cC.sCtrl, sOperation='divide', sTarget='%s.s' % cC.sUnscaledCtrl)
            cC.sExtraMove, cC.sSecondPasser = cC.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'], bAddSecondPasser=True)

            cC.sJumpedOut = cmds.duplicate(cC.sOut, n='%sJumped' % cC.sOut, po=True)[0]
            constraints.matrixParentConstraint(cC.sOut, cC.sJumpedOut, sJumpOverTransforms=[cC.sExtraMove, cC.sSecondPasser])
            cC.sRotationMatrix = nodes.createMultMatrixNode([nodes.getRotationMatrix2('%s.worldMatrix' % cC.sJumpedOut, sName='Brows_rotation_%s_%s' % (sSide, sName)),
                                                             sInvParentRotationMatrix])
            cC.sJointAimAtNeighborAttr = utils.addAttr(cC.sCtrl, ln='jointAimAtNeighbor', min=0, max=1, dv=0, k=True)
            sDefaultSettingAttrsBrows.append(cC.sJointAimAtNeighborAttr)

            # driver attributes for poses
            sTotalTranslate = utils.addAttr(cC.sPasser, ln='totalTranslate', at='double3', k=True)
            sSignedSecondPasser = nodes.createVectorMultiplyNode('%s.t' % cC.sSecondPasser, fSliderScale * fSideMultipl, sOperation='divide', bVectorByScalar=True)
            nodes.createVectorAdditionNode(['%s.t' % cC.sCtrl, '%s.t' % sPoseOffset, sSignedSecondPasser], sTarget=sTotalTranslate)


        xforms.orientThreePoints(ccCtrls[s][0].sPasser, aUps[s, 0], ccCtrls[s][1].sOut, fAimVector=[0, fSideMultipl, 0], fUpVector=[fSideMultipl, 0, 0])
        xforms.orientThreePoints(ccCtrls[s][2].sPasser, aUps[s, 2], ccCtrls[s][1].sOut, fAimVector=[0, fSideMultipl, 0], fUpVector=[-fSideMultipl, 0, 0])
        sUpMiddle = ((aaCtrlPoints[s][0] - aaCtrlPoints[s][1]) - (aaCtrlPoints[s][2] - aaCtrlPoints[s][1])) * 0.5
        xforms.orientThreePoints(ccCtrls[s][1].sPasser, aUps[s, 1], sUpMiddle, fAimVector=[0, fSideMultipl, 0], fUpVector=[-fSideMultipl, 0, 0])

        cBrowTransform = ctrls6.create(sName='browMain', sSide=sSide, sParent=_getFaceCtrlGrp(), fSliderScale=fSliderScale,
                          sMatch=ccCtrls[s][1].sCtrl, sShape='locator', iColorIndex=0, sAttrs=['t','r'], fSize=1.0)
        constraints.matrixParentConstraint(sParentJoint, cBrowTransform.sPasser, mo=True)

        cMainCtrls.append(cBrowTransform)
        cBrowTransform.sExtraMove = cBrowTransform.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])

        for c,cC in enumerate(ccCtrls[s]):
            constraints.matrixParentConstraint(sParentJoint, cC.sPasser, mo=True)
            constraints.matrixParentConstraint(cBrowTransform.sOut, cC.sSecondPasser, sJumpOverTransforms=[cBrowTransform.sExtraMove, cBrowTransform.sPasser], mo=True)
            # sPoseOffset = cC.appendOffsetGroup('pose')
            sPoseOffset = cC.getOffsetByName('pose')
            sPreSibling = cmds.duplicate(sPoseOffset, n='%s_preSiblingDown' % sPoseOffset, po=True)[0]
            sDriverValue = utils.addAttr(sPreSibling, ln='driverValue', dv=-0.5, k=True)
            nodes.createRangeNode('%s.ty' % cBrowTransform.sCtrl, 0, sDriverValue, [0,0,0], '%s.t' % sPreSibling, sTarget='%s.t' % sPoseOffset, bOutRangeIsVector=True)
            nodes.createRangeNode('%s.ty' % cBrowTransform.sCtrl, 0, sDriverValue, [0,0,0], '%s.r' % sPreSibling, sTarget='%s.r' % sPoseOffset, bOutRangeIsVector=True)
            sDefaultSettingAttrsBrows.extend(['%s.%s' % (sPreSibling, sA) for sA in ['tx','ty','tz','rx','ry','rz']])
            sDefaultSettingAttrsBrows.append(sDriverValue)
            cmds.controller(cC.sCtrl, cBrowTransform.sCtrl, parent=True)


    if bMiddleCtrl:
        sMiddleBp = 'bpJnt_m_browMiddle'
        if not cmds.objExists(sMiddleBp):
            cmds.createNode('joint', n=sMiddleBp, p=sBrowsMainGrp)
            cmds.delete(cmds.pointConstraint(ccCtrls[0][0].sCtrl, ccCtrls[1][0].sCtrl, sMiddleBp))
        cBrowMiddle = ctrls6.create(sName='browMiddle', sSide='m', sParent=_getFaceCtrlGrp(), fSliderScale=fSliderScale,
                              sMatch=sMiddleBp, sShape='cube', iColorIndex=1, sAttrs=['t','r','s'], fSize=0.25)
        cBrowMiddle.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
        sMoveWithSidesGrp = cBrowMiddle.appendOffsetGroup('movewithsides')
        sPushGrp = cBrowMiddle.appendOffsetGroup('push')
        sMiddle = xforms.createJoint('jnt_m_browMiddle', sMatch=sMiddleBp, sParent=sParentJoint, fSize=fSliderScale * 0.325)
        sMiddleDefault = xforms.createJoint('jnt_m_browMiddleDefault', sMatch=sMiddleBp, sParent=sParentJoint, fSize=fSliderScale * 0.35)
        constraints.matrixParentConstraint(sParentJoint, cBrowMiddle.sPasser, mo=True)
        constraints.matrixParentConstraint(cBrowMiddle.sCtrl, sMiddle, sJumpOverTransforms=[cBrowMiddle.sExtraMove, cBrowMiddle.sPasser])
        constraints.matrixParentConstraint(sMoveWithSidesGrp, sMiddleDefault, sJumpOverTransforms=[cBrowMiddle.sExtraMove, cBrowMiddle.sPasser])
        nodes.createVectorMultiplyNode('%s.t' % sPushGrp, -1.0, bVectorByScalar=True, sTarget='%s.t' % cBrowMiddle.sOut)

        sFollowAttr = utils.addAttr(cBrowMiddle.sCtrl, ln='follow', min=0, max=1, dv=1.0, k=True)
        sPushAttr = utils.addAttr(cBrowMiddle.sCtrl, ln='autoPush', min=0, dv=0.1, k=True)
        sScaleAttr = utils.addAttr(cBrowMiddle.sCtrl, ln='autoScale', min=0, dv=0.6, max=1.0, k=True)
        sDefaultSettingAttrsBrows.extend([sFollowAttr, sPushAttr, sScaleAttr])

        sSideTranslation = nodes.createVectorAdditionNode(['%s.totalTranslate' % ccCtrls[0][0].sPasser, '%s.totalTranslate' % ccCtrls[1][0].sPasser])
        sSideTranslation = nodes.createVectorMultiplyNode(sSideTranslation, 0.5, bVectorByScalar=True)
        sMoveOffset = nodes.createVectorMultiplyNode(sSideTranslation, sFollowAttr, bVectorByScalar=True)
        cmds.connectAttr('%sY' % sMoveOffset, '%s.ty' % sMoveWithSidesGrp)
        cmds.connectAttr('%sZ' % sMoveOffset, '%s.tz' % sMoveWithSidesGrp)

        sFactor = nodes.createDistanceNode(nodes.getWorldPoint(ccCtrls[0][0].sJumpedOut), nodes.getWorldPoint(ccCtrls[1][0].sJumpedOut),
                                           fNormalized=1.0, sDivide=nodes.scaleFromXform(sParentJoint), sName='browsMiddleDistance')
        nodes.createRangeNode(sFactor, 1.0, 0.1, 0.0, sPushAttr, sTarget='%s.tz' % sPushGrp)
        nodes.createRangeNode(sFactor, 1.0, 0.1, 1.0, sScaleAttr, sTarget='%s.sx' % sPushGrp)

        cmds.scaleConstraint(sMiddle, sMiddleDefault)



    # ctrl aiming setup
    ssJoints = [], []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1
        for c, sLetter in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            cC.sInfParent = xforms.createTransform('grp_%s_browInf%s' % (sSide, sLetter), sParent=cC.sJumpedOut)

            cC.sInfs = []

            cC.cTangents = []
            for d,sDir in enumerate(['in', 'out']):
                if (c==0 and d==0) or (c==2 and d==1):
                    continue
                cC.sInfs.append(xforms.createJoint('jnt_%s_browInf%s%s' % (sSide, sLetter, utils.getFirstLetterUpperCase(sDir)),
                                                   sParent=cC.sInfParent, fSize=0.5, xPos=[[-0.01, 0.01][d],0,0]))
                cTangent = ctrls6.create('browTangent%s%s' % (sLetter, utils.getFirstLetterUpperCase(sDir)), sSide=sSide, sMatch=cC.sInfs[0], sShape='revL',
                                    sParent=cC.sInfParent, sAttrs=['rx','ry','rz', 'sx','sy','sz'], fSize=fSliderScale*0.4, iColorIndex=0, fRotateShape=[-90,0,0])
                sExtraMove = cTangent.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
                cmds.controller(cTangent.sCtrl, cC.sCtrl, parent=True)

                if d == 0:
                    cmds.setAttr('%s.sx' % cTangent.sSlider, -fSideMultipl)
                    cmds.setAttr('%s.sx' % cTangent.sOut, -fSideMultipl)
                sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cTangent.sOut, '%s.worldInverseMatrix' % sExtraMove])
                nodes.createDecomposeMatrix(sMatrix, '%s.t' % cC.sInfs[-1], '%s.r' % cC.sInfs[-1], '%s.s' % cC.sInfs[-1])
                utils.addOffOnAttr(cC.sCtrl, 'tangentCtrlVis', bReturnIfExists=True, sTarget='%s.v' % cTangent.sPasser)

                cTangent.sPose = cTangent.appendOffsetGroup('pose')

                cC.cTangents.append(cTangent)


            [cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf) for sInf in cC.sInfs]

            cC.sAimer = xforms.createLocator('loc_%s_browAimer%s' % (sSide, sLetter), sParent=cC.sPasser)
            nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cC.sExtraMove, sTarget='%s.t' % cC.sAimer)
            cC.sAimTarget = xforms.createLocator('loc_%s_browAimTarget%s' % (sSide, sLetter), sParent=cC.sPasser)
            nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cC.sExtraMove, sTarget='%s.t' % cC.sAimTarget)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sAimer)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sAimTarget)

            sRelativeMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl, '%s.worldInverseMatrix' % cC.sExtraMove])
            cC.sTwist = '%sX' % nodes.createDecomposeMatrix(sRelativeMatrix, bReturnRotate=True)
            cmds.setAttr('%s.inputRotateOrder' % cC.sTwist.split('.')[0], 1) # to have x last


        for sAimer, sInfParent, sAimTargets, fAim in [(ccCtrls[s][0].sAimer, ccCtrls[s][0].sInfParent, [ccCtrls[s][1].sAimTarget], [fSideMultipl,0,0]),
                                                      (ccCtrls[s][1].sAimer, ccCtrls[s][1].sInfParent, [ccCtrls[s][0].sAimTarget, ccCtrls[s][2].sAimTarget], [-fSideMultipl,0,0]),
                                                      (ccCtrls[s][2].sAimer, ccCtrls[s][2].sInfParent, [ccCtrls[s][1].sAimTarget], [-fSideMultipl,0,0])]:
            sAimConstraint = constraints.aimConstraintEmpty(sAimer, aim=fAim)

            sPasserInv = '%s.worldInverseMatrix' % cmds.listRelatives(sAimer, p=True)[0]
            if len(sAimTargets) == 1:
                sAimPointTotal = nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[0]), sPasserInv)

            elif len(sAimTargets) == 2:
                sTranslateConnection = cmds.listConnections('%s.t' % sAimer, s=True, d=False, p=True)[0]
                sAimPoint0 = nodes.createVectorAdditionNode([nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[0]), sPasserInv), sTranslateConnection], sOperation='minus')
                sAimPoint1 = nodes.createVectorAdditionNode([nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[1]), sPasserInv), sTranslateConnection], sOperation='minus')
                sAimPoint1 = nodes.createVectorMultiplyNode(sAimPoint1, -1, bVectorByScalar=True)
                sAimPointTotal = nodes.createVectorAdditionNode([sTranslateConnection, sAimPoint0, sAimPoint1])

            cmds.connectAttr(sAimPointTotal, '%s.target[0].targetTranslate' % sAimConstraint)
            cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sInfParent)


    for s,sSide in enumerate(['l','r']):
        # create skin joints
        print('\n\n\n')
        sUpGroups = []
        sPointOnCurves = []
        for j, fP in enumerate(ffParams[s]):
            sJ = 'jnt_%s_brows_%03d' % (sSide, j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
                xforms.resetJoint(sJ)
                cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.25)
            else:
                sJ = xforms.createJoint(sJ, fSize=fSliderScale * 0.25, sParent=sParentJoint)


            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)

            sUp = xforms.createTransform(sName='grp_%s_browsUp_%03d' % (sSide, j))
            cmds.parent(sUp, sBrowsOrig)

            ssJoints[s].append(sJ)
            sUpGroups.append(sUp)

            # scale
            sMultipls = [nodes.createVectorMultiplyNode('%s.s' % ccCtrls[s][c].sCtrl, aaaWeights[s][c][j], bVectorByScalar=True) for c in [0,1,2]]
            nodes.createVectorAdditionNode(sMultipls, sTarget='%s.s' % sJ)


            _, sPosOnCurve = curves.createPointInfoNode(sCurves[s], fParam=fP)
            sPointOnCurves.append(sPosOnCurve)




        for j, fP in enumerate(ffParams[s]):
            sJ = ssJoints[s][j]
            sUp = sUpGroups[j]

            # pos
            sPos = nodes.createPointByMatrixNode(sPointOnCurves[j], '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)

            # upPos
            _, sUpPosOnCurve = curves.createPointInfoNode(sUpCurves[s], fParam=fP)
            nodes.createPointByMatrixNode(sUpPosOnCurve, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sUp)

            sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0,0,fSideMultipl], up=[fSideMultipl,0,0] if j == 0 else [-1,0,0])
            nodes.createPointByMatrixNode(sUpPosOnCurve, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

            sAimingUpPoint = nodes.createPointByMatrixNode(sPointOnCurves[j+1 if j == 0 else j-1], '%s.worldInverseMatrix' % sParentJoint)
            sLiveUp = nodes.createVectorAdditionNode([sAimingUpPoint, sPos], sOperation='minus')

            sBlendedRotateMatrix = nodes.createBlendMatrixNode([ccCtrls[s][0].sRotationMatrix, ccCtrls[s][1].sRotationMatrix, ccCtrls[s][2].sRotationMatrix],
                                                               [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]])

            fStaticLocalUp = nodes.createPointByMatrixNode(sLiveUp, nodes.createInverseMatrix(sBlendedRotateMatrix, bJustValues=True), bJustValues=True)
            sLocalUp = nodes.createPointByMatrixNode(fStaticLocalUp, sBlendedRotateMatrix)

            sBlendAttr = nodes.createDotProductNode([ccCtrls[s][0].sJointAimAtNeighborAttr, ccCtrls[s][1].sJointAimAtNeighborAttr, ccCtrls[s][2].sJointAimAtNeighborAttr],
                                                   [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]])
            nodes.createBlendNode(sBlendAttr, sLiveUp, sLocalUp, bVector=True, sTarget='%s.worldUpVector' % sAimConstraint)

            # twist
            nodes.createDotProductNode([ccCtrls[s][0].sTwist, ccCtrls[s][1].sTwist, ccCtrls[s][2].sTwist],
                                       [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]],
                                       sTarget='%s.offsetX' % sAimConstraint)


        # post brow ctrls
        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            sDrivenGrp = cC.sOut
            sRangesR = []
            sRangesT = []
            for sDir,fRot,sDriverA,fDriverCtrlValue in [('up', (0,0,0), 'Y', 1.0),
                                                          ('down', (0,0,0), 'Y', -0.5),
                                                          ('in', (0,0,0), 'X', -0.5)]:
                sPostSibling = utils.replaceStringEnd(sDrivenGrp, 'Out', '_postSibling%s' % utils.getFirstLetterUpperCase(sDir))
                sPostSibling = utils.replaceStringStart(sPostSibling, 'ctrl_', 'grp_')
                sPostSibling = cmds.duplicate(sDrivenGrp, n=sPostSibling, po=True)[0]
                cmds.setAttr('%s.r' % sPostSibling, *fRot)
                sDriverValue = utils.addAttr(sPostSibling, ln='driverCtrlValue%s' % utils.getFirstLetterUpperCase(sDriverA), k=True, dv=fDriverCtrlValue)

                sDriverAttr = '%s.totalTranslate%s' % (cC.sPasser, sDriverA)

                sDriverValueMultipl = nodes.createMultiplyNode(sDriverValue, 100)
                sRangesR.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                      [0,0,0],
                                                      nodes.createVectorMultiplyNode('%s.r' % sPostSibling, 100, bVectorByScalar=True),
                                                      bOutRangeIsVector=True, sName='r_%s_%s' % (sDir, sDriverA)))
                sRangesT.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                      [0,0,0],
                                                      nodes.createVectorMultiplyNode('%s.t' % sPostSibling, 100, bVectorByScalar=True),
                                                      bOutRangeIsVector=True, sName='t_%s_%s' % (sDir, sDriverA)))

                sDefaultSettingAttrsBrows.extend(['%s.%s' % (sPostSibling, sA) for sA in ['tx','ty','tz','rx','ry','rz']])
                sDefaultSettingAttrsBrows.append(sDriverValue)

            nodes.createVectorAdditionNode(sRangesR, sTarget='%s.r' % sDrivenGrp)
            nodes.createVectorAdditionNode(sRangesT, sTarget='%s.t' % sDrivenGrp)

        # pre tangent ctrls
        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            for sDrivenGrp in [cTangent.sPose for cTangent in cC.cTangents]:
                sRangesR = []
                for sDir,fRot,sDriverA,fDriverCtrlValue in [('up', (0,0,0), 'Y', 1.0),
                                                              ('down', (0,0,0), 'Y', -0.5),
                                                              ('in', (0,0,0), 'X', -0.5)]:
                    sPreTangentSibling = utils.replaceStringEnd(sDrivenGrp, 'Pose', '_preTangentSibling%s' % utils.getFirstLetterUpperCase(sDir))
                    sPreTangentSibling = cmds.duplicate(sDrivenGrp, n=sPreTangentSibling, po=True)[0]
                    cmds.setAttr('%s.r' % sPreTangentSibling, *fRot)
                    sDriverValue = utils.addAttr(sPreTangentSibling, ln='driverCtrlValueTangents%s' % utils.getFirstLetterUpperCase(sDriverA), k=True, dv=fDriverCtrlValue, bReturnIfExists=True)

                    sDriverAttr = '%s.totalTranslate%s' % (cC.sPasser, sDriverA)

                    sDriverValueMultipl = nodes.createMultiplyNode(sDriverValue, 100)
                    sRangesR.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                          [0,0,0],
                                                          nodes.createVectorMultiplyNode('%s.r' % sPreTangentSibling, 100, bVectorByScalar=True),
                                                          bOutRangeIsVector=True, sName='r_%s_%s' % (sDir, sDriverA)))

                    sDefaultSettingAttrsBrows.extend(['%s.%s' % (sPreTangentSibling, sA) for sA in ['rx','ry','rz']])
                    sDefaultSettingAttrsBrows.append(sDriverValue)

                nodes.createVectorAdditionNode(sRangesR, sTarget='%s.r' % sDrivenGrp)


        weights.skinCurveBSpline4(patch.patchFromName(sCurves[s]), utils.flattenedList([cC.sInfs for cC in ccCtrls[s]]))
        weights.skinCurveBSpline4(patch.patchFromName(sUpCurves[s]), utils.flattenedList([cC.sInfs for cC in ccCtrls[s]]))


    cSideCtrls = utils.flattenedList(ccCtrls)
    for cC in cSideCtrls + cMainCtrls + utils.flattenedList([cC.cTangents for cC in cSideCtrls]):
        cC.setDefaultAttrDict()
    if bMiddleCtrl:
        cBrowMiddle.setDefaultAttrDict()

    utils.data.store('sDefaultSettingAttrsBrows', sDefaultSettingAttrsBrows)
    for sA,fV in dDefaultSettingValuesBrows.items():
        if cmds.objExists(sA):
            cmds.setAttr(sA, fV)
        else:
            report.report.addLogText('skipping "%s", doesn\'t exist..' % sA)



def bindTweakers(sStringMatch='jnt_?_tweakerLids*'):
    sBodyMeshes = cmds.ls(sl=True)
    sBody = sBodyMeshes[0]
    sJoints = [sJ for sJ in cmds.ls(sStringMatch, et='joint') if not sJ.endswith('_ref') and 'Inf' not in sJ]
    sSkinCluster = 'skinCluster__%s__TWEAKERS' % sBody
    if not cmds.objExists(sSkinCluster):
        deformers.skinMesh(sBody, sName='skinCluster__%s__TWEAKERS' % sBody,
                           sInfluences=['jnt_m_faceZero'] + sJoints,
                           bAlwaysAddDefaultWeights=True)
    else:
        print('adding influences: ', sJoints)
        deformers.addInfluences(sSkinCluster, sJoints)


kTweakerLidsBpGroupName = '_grp_m_eyesBpTWEAKER'


dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_tweakerLids', kTweakerLidsBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['create Right Curve and Locators'] = lambda: createBothBpCurves('bpCurve_r_tweakerLids', kTweakerLidsBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['create Right Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerLids*')
dButtons['- Export Eyelid Tweaker BPs -'] = lambda: exportBps('faceBlueprintsTweakerLids.ma', kTweakerLidsBpGroupName)



# to do: check that disabled live rotation setup
@builderTools.addToBuild(iOrder=85.0, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_lids(sAttachMesh=[], fMidPercs=[0.25, 0.5, 0.75], sNames=['inner', 'mid', 'outer'], sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    if len(fMidPercs) != len(sNames):
        raise Exception('fMidPercs and sNames need to have same count (%d -> %d)' % (len(fMidPercs), len(sNames)))

    for sCrv in ['bpCurve_l_tweakerLids', 'bpCurve_r_tweakerLids']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_tweakerLids', 'locB_l_tweakerLids', 'locA_r_tweakerLids', 'locB_r_tweakerLids']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_l_tweakerLids', 'locA_l_tweakerLids', 'locB_l_tweakerLids', 'bpCurve_l_botLid',
                                            'bpCurve_l_topLid'))
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_r_tweakerLids', 'locA_r_tweakerLids', 'locB_r_tweakerLids', 'bpCurve_r_botLid',
                                            'bpCurve_r_topLid'))

    fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccLidCtrls = [[], []]
    sCornerNames = ['cornerIn', 'cornerOut']
    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    sssCtrlJoints = [[], []], [[], []]
    for s, sSide in enumerate(['l', 'r']):

        # bottom tops
        for p,sPart in enumerate(['bot','top']):
            fCtrlParams = curves.getParamsFromPercs(ssCurves[s][p], fMidPercs)
            aTangents = curves.getTangentsFromParams(ssCurves[s][p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(ssCurves[s][p], fCtrlParams)
            for c, fP, sN in zip(range(len(fCtrlParams)), fCtrlParams, sNames):
                sName = 'eyelid%s%s' % (utils.getFirstLetterUpperCase(sN), utils.getFirstLetterUpperCase(sPart))

                cC = ctrls6.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, fSliderScale=fSliderScale,
                                  sAttrs=['t','r','s'], fSize=0.1, sShape='cube', fMatchPos=aCtrlPoints[c])
                cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

                xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangents[c], fAimVector=[0,0,-1], fUpVector=[1,0,0] )
                cC.sSurfaceInfoNode = None

                cccBotTopCtrls[s][p].append(cC)
                ccLidCtrls[s].append(cC)

        # corners
        fCtrlParams = curves.getParamsFromPercs(ssCurves[s][0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(ssCurves[s][0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, sCornerNames):
            sName = 'eyelid%s' % (utils.getFirstLetterUpperCase(sN))

            cC = ctrls6.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, sMatch='jnt_%s_eyeMain' % sSide,
                              sAttrs=['t','r'], fSize=0.1, sShape='cube', fMatchPos=aCtrlPoints[c], fSliderScale=fSliderScale)

            if c == 0:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -1], fUpVector=[1, 0, 0])
            cC.sSurfaceInfoNode = None

            ccCornerCtrls[s].append(cC)
            ccLidCtrls[s].append(cC)

        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, ctrls6.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s]).sCtrl, parent=True)


        sEyePoint = nodes.getWorldPoint(sEyeJoints[s])
        for c,cC in enumerate(ccLidCtrls[s]):
            cC.sJ = 'jnt_%s_tweakerLids_%s' % (sSide, cC.sName)
            sssCtrlJoints[s][p].append(cC.sJ)
            if cmds.objExists(cC.sJ):
                xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
                xforms.resetTransform(cC.sJ, jo=True)
            else:
                cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

            utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

            cmds.setAttr('%s.radius' % cC.sJ, 0.1)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJ)


            sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
            sDecomposeMatrix = nodes.createDecomposeMatrix('%s.worldMatrix' % sCtrlParent, bReturnRotate=True)
            sNoRotMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(cC.sCtrl),
                                                         xRotate=sDecomposeMatrix,
                                                         xScale='%s.outputScale' % sDecomposeMatrix.split('.')[0])
            sInverseNoRotMatrix = nodes.createInverseMatrix(sNoRotMatrix)

            sAimTargetLocal = nodes.createPointByMatrixNode(sEyePoint, sInverseNoRotMatrix)
            nodes.createSimpleAimConstraint2(sAimTargetLocal, cC.sOut, bRotateUp=False, xAimVector=[0, 0, -1], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
            sLocalCtrlPlane = ['%s.tx' % cC.sCtrl, '%s.ty' % cC.sCtrl, 0]
            sDistanceInsidePlane = nodes.createDistanceNode([0,0,0], sLocalCtrlPlane)
            sCtrlPlane = nodes.createPointByMatrixNode(sLocalCtrlPlane, '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0])
            sDiff = nodes.createVectorAdditionNode([sCtrlPlane, sEyePoint], sOperation='minus')
            sDistance = nodes.createDistanceNode([0,0,0], sDiff)
            sNormDiff = nodes.createVectorMultiplyNode(sDiff, sDistance, sOperation='divide', bVectorByScalar=True)

            sAutoPushAttr = utils.addAttr(cC.sCtrl, ln='autoPushOut', k=True, dv=2)
            sAutoPush = nodes.createMultiplyNode(sDistanceInsidePlane, sAutoPushAttr)
            sPushOutDistance = nodes.createAdditionNode([cmds.getAttr(sDistance), '%s.tz' % cC.sCtrl, sAutoPush])
            sScaledDiff = nodes.createVectorMultiplyNode(sNormDiff, sPushOutDistance, bVectorByScalar=True)
            sWorldPos = nodes.createVectorAdditionNode([sEyePoint, sScaledDiff])

            sCtrlPlaneMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalCtrlPlane),
                                                           '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0]])
            sInvCtrlPlaneMatrix = nodes.createInverseMatrix(sCtrlPlaneMatrix)
            nodes.createPointByMatrixNode(sWorldPos, sInvCtrlPlaneMatrix, sTarget='%s.t' % cC.sOut)



    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr(utils.flattenedList(sssCtrlJoints))

    for cC in ccLidCtrls[0]+ccLidCtrls[1]:
        sAttachDeformers = [sD for sD in ctrls6.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls6.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers,
                                                 bRotate=False if 'CORNER' in cC.sCtrl.upper() else True)

    utils.data.addToList('sAllTweakerCtrlsForUnreal', [cC.sCtrl for cC in ccLidCtrls[0]+ccLidCtrls[1]])






kMouthPostBpGroupName = '_grp_m_mouthBpsTweakers'


dButtons = OrderedDict()
dButtons['Create Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_tweakerLips', kMouthPostBpGroupName, fDirection=(-1, 0, 0))
dButtons['Attach Joints to Selected'] = lambda: bindTweakers('jnt_?_tweakerLips*')
# dButtons['Add Bind Corner Rot (do the normal bind first and then open mouth and select mesh)'] = bindCornerRotPostLips
dButtons['- Export Lips Tweaker BPs -'] = lambda: exportBps('faceBlueprintsMouthTweakers.ma', kMouthPostBpGroupName)



@builderTools.addToBuild(iOrder=85.2, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_lips(sAttachMesh=[], fHalfPercs=[0.0, 0.25, 0.5], bFlipInnerBpCurves=False, bOrientAttach=True, sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sPostCtrls = cmds.createNode('transform', n='grp_lipsTweakerCtrls', p='ctrls')
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    sBpCurves = ['bpCurve_m_%sTweakerLips' % sPart for sPart in ['bot', 'top']]
    if bFlipInnerBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs('bpCurve_m_tweakerLips', 'locA_m_tweakerLips', 'locB_m_tweakerLips', sBpCurves[1], sBpCurves[0])
    else:
        curves.separateCurveUsingSeparationLocs('bpCurve_m_tweakerLips', 'locA_m_tweakerLips', 'locB_m_tweakerLips', sBpCurves[0], sBpCurves[1])

    aHalfPercs = np.array(fHalfPercs, dtype='float64')
    aCtrlPercs = np.concatenate([aHalfPercs, 1.0-aHalfPercs[::-1][1:]])
    iCtrlCount = len(aCtrlPercs)
    report.report.addLogText('Params: %s' % list(aCtrlPercs))
    aSides, aInds = utils.convertMiddleSequenceToSides(iCtrlCount)

    aaPoints = []

    for p,sPart in enumerate(['bot','top']):
        aPoints = curves.getPointsFromPercs(sBpCurves[p], aCtrlPercs, bReturnNumpy=True)
        if True:
            pBpCurve = patch.patchFromName(sBpCurves[p])
            aBpPoints = pBpCurve.getPoints()
            iPoints = xforms.findClosestPoints(aPoints, aBpPoints)
            aPoints = aBpPoints[iPoints]

        aaPoints.append(aPoints)

    fCurveEndsDistance = barycentric.distanceBetween('%s.cv[0]' % sBpCurves[0], '%s.cv[%d]' % (sBpCurves[0], len(cmds.ls('%s.cv[*]' % sBpCurves[0], flatten=True))-1)) * 0.5
    fSliderScale = fCurveEndsDistance * 0.25

    dCommonFlags = {'sShape': 'cube', 'fSize': 1, 'sAttrs':['t','r','s'],
                    'sParent': sPostCtrls, 'iColorIndex': 2, 'fSliderScale':fSliderScale}

    cCorners = [ctrls6.create(sName='tweakerLipsCorner', sSide='l', fMatchPos=aaPoints[0][0], **dCommonFlags),
                ctrls6.create(sName='tweakerLipsCorner', sSide='r', fMatchPos=aaPoints[0][-1], **dCommonFlags)]

    ccCtrls = [], []

    for p,sPart in enumerate(['bot','top']):
        for i in range(iCtrlCount):
            if i in [0,iCtrlCount-1]:
                continue
            cC = ctrls6.create(sName='tweakerLips%s' % utils.getFirstLetterUpperCase(sPart), iIndex=aInds[i], sSide=aSides[i],
                               fMatchPos=aaPoints[p][i], **dCommonFlags)
            ccCtrls[p].append(cC)

    aLocalUp = utils.getNumpyMatrixFromTransform('mouth_ctrl')[2,0:3]

    # orient the controls
    for i in range(iCtrlCount):

        fSideMultipl = -1.0 if aSides[i] == 'r' else 1.0
        if i in [0, iCtrlCount-1]:
            if i == 0:
                aLocalAim = (aaPoints[0][1]+aaPoints[1][1]) * 0.5 - aaPoints[0][0]
                xforms.orientThreePoints(cCorners[0].sPasser, aLocalAim, aLocalUp, fAimVector=[-1,0,0], fUpVector=[0,0,1])
            else:
                aLocalAim = (aaPoints[0][-2]+aaPoints[1][-2]) * 0.5 - aaPoints[0][-1]
                xforms.orientThreePoints(cCorners[1].sPasser, aLocalAim, aLocalUp, fAimVector=[1,0,0], fUpVector=[0,0,-1])
        else:
            c = i - 1
            for p,sPart in enumerate(['bot','top']):
                aLocalAim = ((aaPoints[p][i-1]-aaPoints[p][i]) - (aaPoints[p][i+1]-aaPoints[p][i]))
                xforms.orientThreePoints(ccCtrls[p][c].sPasser, aLocalAim, aLocalUp, fAimVector=[1, 0, 0], fUpVector=[0, 0, fSideMultipl])


    cAllLipCtrls = cCorners + ccCtrls[0] + ccCtrls[1]
    for c,cC in enumerate(cAllLipCtrls):
        cC.sJ = 'jnt_%s_tweakerLips_%s' % (cC.sSide, cC.sName.replace('tweaker',''))
        if cC.iIndex != None:
            cC.sJ = '%s_%03d' % (cC.sJ, cC.iIndex)

        if cmds.objExists(cC.sJ):
            xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
            xforms.resetTransform(cC.sJ, jo=True)
        else:
            cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

        cmds.setAttr('%s.v' % cC.sJ, False)
        cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

        utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr([cC.sJ for cC in cAllLipCtrls])

    for cC in cAllLipCtrls:
        sAttachDeformers = [sD for sD in ctrls6.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls6.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers,
                                                 bRotate=False if 'CORNER' in cC.sCtrl.upper() else True)

    utils.data.addToList('sAllTweakerCtrlsForUnreal', [cC.sCtrl for cC in cAllLipCtrls])





kTweakerSocketsBpGroupName = '_grp_m_tweakerSocketsBp'


dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_tweakerSockets', kTweakerSocketsBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['create Right Curve and Locators'] = lambda: createBothBpCurves('bpCurve_r_tweakerSockets', kTweakerSocketsBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['create Right Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerSockets*')
# dButtons['Add Tangent Influences to Selected'] = bindEyelidCornerRotPostLips
dButtons['- Export Tweaker Sockets BPs -'] = lambda: exportBps('faceBlueprintsTweakerSockets.ma', kTweakerSocketsBpGroupName)



# to do: check that disabled live rotation setup
@builderTools.addToBuild(iOrder=85.1, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_sockets(sAttachMesh=[], fMidPercs=[0.25, 0.5, 0.75], sNames=['inner', 'mid', 'outer'], sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    if len(fMidPercs) != len(sNames):
        raise Exception('fMidPercs and sNames need to have same count (%d -> %d)' % (len(fMidPercs), len(sNames)))

    for sCrv in ['bpCurve_l_tweakerSockets', 'bpCurve_r_tweakerSockets']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_tweakerSockets', 'locB_l_tweakerSockets', 'locA_r_tweakerSockets', 'locB_r_tweakerSockets']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_l_tweakerSockets', 'locA_l_tweakerSockets', 'locB_l_tweakerSockets', 'bpCurve_l_botLid',
                                            'bpCurve_l_topLid'))
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_r_tweakerSockets', 'locA_r_tweakerSockets', 'locB_r_tweakerSockets', 'bpCurve_r_botLid',
                                            'bpCurve_r_topLid'))

    fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccSocketsCtrls = [[], []]
    sCornerNames = ['cornerIn', 'cornerOut']
    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    sssCtrlJoints = [[], []], [[], []]
    for s, sSide in enumerate(['l', 'r']):

        aEyeJointMatrix = utils.getNumpyMatrixFromTransform(sEyeJoints[s])
        for p,sPart in enumerate(['bot','top']):
            fCtrlParams = curves.getParamsFromPercs(ssCurves[s][p], fMidPercs)
            aTangents = curves.getTangentsFromParams(ssCurves[s][p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(ssCurves[s][p], fCtrlParams)
            for c, fP, sN in zip(range(len(fCtrlParams)), fCtrlParams, sNames):
                sName = 'tweakerSocket%s%s' % (utils.getFirstLetterUpperCase(sN), utils.getFirstLetterUpperCase(sPart))

                cC = ctrls6.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, fSliderScale=fSliderScale,
                                  sAttrs=['t','r','s'], fSize=0.1, sShape='sphere', fMatchPos=aCtrlPoints[c])
                cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

                xforms.orientThreePoints(cC.sPasser, aEyeJointMatrix[1,0:3], aTangents[c], fAimVector=[0,1,0], fUpVector=[1,0,0] )
                cC.sSurfaceInfoNode = None

                cccBotTopCtrls[s][p].append(cC)
                ccSocketsCtrls[s].append(cC)

        # corners
        fCtrlParams = curves.getParamsFromPercs(ssCurves[s][0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(ssCurves[s][0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, sCornerNames):
            sName = 'tweakerSocket%s' % (utils.getFirstLetterUpperCase(sN))

            cC = ctrls6.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, sMatch='jnt_%s_eyeMain' % sSide,
                              sAttrs=['t','r'], fSize=0.1, sShape='sphere', fMatchPos=aCtrlPoints[c], fSliderScale=1.0)

            if c == 0:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            cmds.delete(cmds.orientConstraint(sEyeJoints[s], cC.sPasser))
            # xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -1], fUpVector=[1, 0, 0])
            cC.sSurfaceInfoNode = None

            ccCornerCtrls[s].append(cC)
            ccSocketsCtrls[s].append(cC)

        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, ctrls6.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s]).sCtrl, parent=True)


        sEyePoint = nodes.getWorldPoint(sEyeJoints[s])
        for c,cC in enumerate(ccSocketsCtrls[s]):
            cC.sJ = 'jnt_%s_%s' % (sSide, cC.sName)
            sssCtrlJoints[s][p].append(cC.sJ)
            if cmds.objExists(cC.sJ):
                xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
                xforms.resetTransform(cC.sJ, jo=True)
            else:
                cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

            utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

            cmds.setAttr('%s.radius' % cC.sJ, fSliderScale * 0.005)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJ)


            sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
            sDecomposeMatrix = nodes.createDecomposeMatrix('%s.worldMatrix' % sCtrlParent, bReturnRotate=True)
            sNoRotMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(cC.sCtrl),
                                                         xRotate=sDecomposeMatrix,
                                                         xScale='%s.outputScale' % sDecomposeMatrix.split('.')[0])
            sInverseNoRotMatrix = nodes.createInverseMatrix(sNoRotMatrix)

            sAimTargetLocal = nodes.createPointByMatrixNode(sEyePoint, sInverseNoRotMatrix)
            nodes.createSimpleAimConstraint2(sAimTargetLocal, cC.sOut, bRotateUp=False, xAimVector=[0, 0, -1], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
            sLocalCtrlPlane = ['%s.tx' % cC.sCtrl, '%s.ty' % cC.sCtrl, 0]
            sDistanceInsidePlane = nodes.createDistanceNode([0,0,0], sLocalCtrlPlane)
            sCtrlPlane = nodes.createPointByMatrixNode(sLocalCtrlPlane, '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0])
            sDiff = nodes.createVectorAdditionNode([sCtrlPlane, sEyePoint], sOperation='minus')
            sDistance = nodes.createDistanceNode([0,0,0], sDiff)
            sNormDiff = nodes.createVectorMultiplyNode(sDiff, sDistance, sOperation='divide', bVectorByScalar=True)

            sAutoPushAttr = utils.addAttr(cC.sCtrl, ln='autoPushOut', k=True, dv=2)
            sAutoPush = nodes.createMultiplyNode(sDistanceInsidePlane, sAutoPushAttr)
            sPushOutDistance = nodes.createAdditionNode([cmds.getAttr(sDistance), '%s.tz' % cC.sCtrl, sAutoPush])
            sScaledDiff = nodes.createVectorMultiplyNode(sNormDiff, sPushOutDistance, bVectorByScalar=True)
            sWorldPos = nodes.createVectorAdditionNode([sEyePoint, sScaledDiff])

            sCtrlPlaneMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalCtrlPlane),
                                                           '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0]])
            sInvCtrlPlaneMatrix = nodes.createInverseMatrix(sCtrlPlaneMatrix)
            nodes.createPointByMatrixNode(sWorldPos, sInvCtrlPlaneMatrix, sTarget='%s.t' % cC.sOut)


    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr(utils.flattenedList(sssCtrlJoints))

    for cC in ccSocketsCtrls[0]+ccSocketsCtrls[1]:
        sAttachDeformers = [sD for sD in ctrls6.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls6.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers,
                                                 bRotate=False if 'CORNER' in cC.sCtrl.upper() else True)

    utils.data.addToList('sAllTweakerCtrlsForUnreal', [cC.sCtrl for cC in ccSocketsCtrls[0]+ccSocketsCtrls[1]])



kTweakerBrowsSplinesBpGroupName = '_grp_m_tweakerBrowsSplinesBpMain'

def tweakerBrowOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_tweakerBrowsSplines', [0, 0.5, 1])
    sNames = ['A', 'B', 'C']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sMainBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls6.createSimpleCurve('matrixNames', sName='bpLoc_l_tweakerBrowsSplinesOrientation%s' % sNames[i], sParent=kTweakerBrowsSplinesBpGroupName)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)


dSelectSiblingsMenu = {}
dSelectSiblingsMenu['all'] = lambda: cmds.select(cmds.ls('grp_l_tweakerBrowSplines*_*Sibling*', et='transform'))

dSelectSiblingsMenu['all post'] = lambda: cmds.select(cmds.ls('grp_l_browsSplines*_postSibling*', et='transform'))
dSelectSiblingsMenu['all pre'] = lambda: cmds.select(cmds.ls('grp_l_browsSplines*_preSibling*', et='transform'))
dSelectSiblingsMenu['all post up'] = lambda: cmds.select(cmds.ls('grp_l_browsSplines*_postSiblingUp', et='transform'))
dSelectSiblingsMenu['all pre down'] = lambda: cmds.select(cmds.ls('grp_l_browsSplines*_preSiblingDown', et='transform'))
dSelectSiblingsMenu['inner pre tangent'] = lambda: cmds.select(cmds.ls('grp_l_browTangentAOutOffset_preTangentSiblingTweakerBrowsSplines*', et='transform'))

dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_tweakerBrowsSplines', kTweakerBrowsSplinesBpGroupName, fDirection=(1, 0, 0))
dButtons['Create Left Brow Orientation Locators'] = tweakerBrowOrientationLocators
dButtons['=== SELECT LEFT SIBLINGS ==='] = dSelectSiblingsMenu
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsTweakerBrowsSplines', 'dDefaultSettingValuesBrows')

dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerBrowsSplines*')

dButtons['- Export Tweaker Brows Splines BPs -'] = lambda: exportBps('faceBlueprintsTweakerBrowsSplines.ma', kTweakerBrowsSplinesBpGroupName)


@builderTools.addToBuild(iOrder=85.3, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_browsSplines(sAttachMesh='', iCurveJoints=None, sVisAttrCtr='head_ctrl', sParentJoint='jnt_m_headMain', dDefaultSettingValuesBrows={}):
    sDefaultSettingAttrsBrows = []
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    sCtrlVis = utils.addOffOnAttr(utils.toList(sVisAttrCtr)[0], 'faceTweakerCtrlVis', bDefaultValue=True,
                                  bReturnIfExists=True)

    utils.data.store('iBrowCurveJoints', iCurveJoints, sNode=utils.kFaceDataNode)

    sBrowsOrig = cmds.createNode('transform', name='grp_tweakerBrowsSplinesOrig', p=getFaceGrp())

    sRefParentJoint = cmds.createNode('transform', name='grp_refParentJoint', p=sBrowsOrig)
    constraints.matrixParentConstraint(sParentJoint, sRefParentJoint)
    # sSkinJoints = []

    sBpCurves = ['bpCurve_%s_tweakerBrowsSplines' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleBrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv)

    bJointsPerCvs = True if isinstance(iCurveJoints, type(None)) else False

    print('bJointsPerCvs: ', bJointsPerCvs)

    aaCurvePoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                     curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aaCtrlPoints = [[aaCurvePoints[0][0], aaCurvePoints[0][3], aaCurvePoints[0][6]],
                    [aaCurvePoints[1][0], aaCurvePoints[1][3], aaCurvePoints[1][6]]]

    sCurves = [cmds.curve(p=aaCurvePoints[0], n='curve_l_tweakerBrows'), cmds.curve(p=aaCurvePoints[1], n='curve_r_tweakerBrows')]
    sRefCurves = [cmds.curve(p=aaCurvePoints[0], n='curve_l_tweakerBrows_ref'), cmds.curve(p=aaCurvePoints[1], n='curve_r_tweakerBrows_ref')]

    if bJointsPerCvs:
        aaPoints = [np.array(cmds.xform('%s.cv[*]' % sBpCurves[0], q=True, ws=True, t=True)).reshape(-1, 3),
                    np.array(cmds.xform('%s.cv[*]' % sBpCurves[1], q=True, ws=True, t=True)).reshape(-1, 3)]
        ffParams = [curves.getParamsFromPoints(sCurves[0], aaPoints[0]),
                    curves.getParamsFromPoints(sCurves[1], aaPoints[1])]
    else:
        ffParams = [curves.getParamsFromPercs(sCurves[0], np.linspace(0.0, 1.0, iCurveJoints)),
                    curves.getParamsFromPercs(sCurves[1], np.linspace(0.0, 1.0, iCurveJoints))]
        aaPoints = [curves.getPointsFromParams(sCurves[0], ffParams[0], bReturnNumpy=True),
                    curves.getPointsFromParams(sCurves[1], ffParams[1], bReturnNumpy=True)]

    aaaWeights = [utils.bSpline3([1, 0, 0], len(aaPoints[0])),
                  utils.bSpline3([0, 1, 0], len(aaPoints[0])),
                  utils.bSpline3([0, 0, 1], len(aaPoints[0]))], \
        [utils.bSpline3([1, 0, 0], len(aaPoints[1])),
         utils.bSpline3([0, 1, 0], len(aaPoints[1])),
         utils.bSpline3([0, 0, 1], len(aaPoints[1]))]

    # collect orients
    ssBpOrients = []
    for s, sSide in enumerate(['l', 'r']):
        sBpOrients = []
        for sName in ['A', 'B', 'C']:
            sBpOrient = 'bpLoc_%s_tweakerBrowsSplinesOrientation%s' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_tweakerBrowsSplinesOrientation%s' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    xforms.mirrorCurveTransforms(sLeftBpOrient)
            sBpOrients.append(sBpOrient)
        ssBpOrients.append(sBpOrients)

    # make up curves
    aaCurveUpPoints = []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        aaPushForwardWeights = [utils.bSpline3([1, 0, 0], 7),
                                utils.bSpline3([0, 1, 0], 7),
                                utils.bSpline3([0, 0, 1], 7)]

        aForwardPoints = utils.getNumpyMatrixFromTransform(ssBpOrients[s][0])[2, 0:3] * aaPushForwardWeights[0][:,np.newaxis] + \
                         utils.getNumpyMatrixFromTransform(ssBpOrients[s][1])[2, 0:3] * aaPushForwardWeights[1][:,np.newaxis] + \
                         utils.getNumpyMatrixFromTransform(ssBpOrients[s][2])[2, 0:3] * aaPushForwardWeights[2][:,np.newaxis]
        aForwardPoints *= fSideMultipl
        aCurveUpPoints = aaCurvePoints[s] + aForwardPoints * fSliderScale
        aaCurveUpPoints.append(aCurveUpPoints)

    sUpCurves = [cmds.curve(p=aaCurveUpPoints[0], n='curve_l_tweakerBrowsSplinesUp'), cmds.curve(p=aaCurveUpPoints[1], n='curve_r_tweakerBrowsSplinesUp')]
    sRefUpCurves = [cmds.curve(p=aaCurveUpPoints[0], n='curve_l_tweakerBrowsSplinesUp_ref'), cmds.curve(p=aaCurveUpPoints[1], n='curve_r_tweakerBrowsSplinesUp_ref')]

    for sCrv in (sCurves + sUpCurves + sRefCurves, sRefUpCurves):
        cmds.parent(sCrv, sBrowsOrig)

    sInvParentRotationMatrix = nodes.getRotationMatrix2('%s.worldInverseMatrix' % sParentJoint)
    ccCtrls = [], []
    cMainCtrls = []
    for s, sSide in enumerate(['l', 'r']):

        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        aUps = np.zeros((2, 3, 3), dtype='float64')

        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ctrls6.create(sName='tweakerBrowSplines%s' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(),
                               fMatchPos=aaCtrlPoints[s][c], sShape='cube', fSliderScale=fSliderScale,
                               sAttrs=['t', 'r', 'sy', 'sz'], fSize=0.25)
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            ccCtrls[s].append(cC)
            sPoseOffset = cC.appendOffsetGroup('pose')

            sBpOrients[s] = 'bpLoc_%s_tweakerBrowsSplinesOrientation%s' % (sSide, sName)

            aMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sBpOrients[s]), dtype='float64').reshape(4, 4)
            aUps[s, c] = aMatrix[1][:3] * fSideMultipl

            cC.sUnscaledCtrl = xforms.insertParent(cC.sOut, 'grp_%s_tweakerBrowSplinesUnscaled%s' % (sSide, sName),
                                                   bMatchParentTransform=True)
            nodes.createVectorMultiplyNode([1, 1, 1], '%s.s' % cC.sCtrl, sOperation='divide',
                                           sTarget='%s.s' % cC.sUnscaledCtrl)
            cC.sExtraMove, cC.sSecondPasser = cC.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'],
                                                                                bAddSecondPasser=True)

            cC.sJumpedOut = cmds.duplicate(cC.sOut, n='%sJumped' % cC.sOut, po=True)[0]
            constraints.matrixParentConstraint(cC.sOut, cC.sJumpedOut, sJumpOverTransforms=[cC.sExtraMove, cC.sSecondPasser])
            cC.sRotationMatrix = nodes.createMultMatrixNode([nodes.getRotationMatrix2('%s.worldMatrix' % cC.sJumpedOut, sName='tweakerBrows_rotation_%s_%s' % (sSide, sName)), sInvParentRotationMatrix])
            cC.sRefRotationMatrix = nodes.createMultMatrixNode([nodes.getRotationMatrix2('%s.worldMatrix' % cC.sPasser, sName='tweakerBrows_ref_rotation_%s_%s' % (sSide, sName)), sInvParentRotationMatrix])
            cC.sJointAimAtNeighborAttr = utils.addAttr(cC.sCtrl, ln='jointAimAtNeighbor', min=0, max=1, dv=0, k=True)
            sDefaultSettingAttrsBrows.append(cC.sJointAimAtNeighborAttr)

            # driver attributes for poses
            sTotalTranslate = utils.addAttr(cC.sPasser, ln='totalTranslate', at='double3', k=True)
            sSignedSecondPasser = nodes.createVectorMultiplyNode('%s.t' % cC.sSecondPasser, fSliderScale * fSideMultipl,
                                                                 sOperation='divide', bVectorByScalar=True)
            nodes.createVectorAdditionNode(['%s.t' % cC.sCtrl, '%s.t' % sPoseOffset, sSignedSecondPasser],
                                           sTarget=sTotalTranslate)

        xforms.orientThreePoints(ccCtrls[s][0].sPasser, aUps[s, 0], ccCtrls[s][1].sOut, fAimVector=[0, fSideMultipl, 0], fUpVector=[fSideMultipl, 0, 0])
        xforms.orientThreePoints(ccCtrls[s][2].sPasser, aUps[s, 2], ccCtrls[s][1].sOut, fAimVector=[0, fSideMultipl, 0], fUpVector=[-fSideMultipl, 0, 0])
        sUpMiddle = ((aaCtrlPoints[s][0] - aaCtrlPoints[s][1]) - (aaCtrlPoints[s][2] - aaCtrlPoints[s][1])) * 0.5
        xforms.orientThreePoints(ccCtrls[s][1].sPasser, aUps[s, 1], sUpMiddle, fAimVector=[0, fSideMultipl, 0], fUpVector=[-fSideMultipl, 0, 0])

        cBrowTransform = ctrls6.create(sName='tweakerBrowSplineMain', sSide=sSide, sParent=_getFaceCtrlGrp(), fSliderScale=fSliderScale,
                                       sMatch=ccCtrls[s][1].sCtrl, sShape='locator', iColorIndex=0, sAttrs=['t', 'r'], fSize=1.0)

        cMainCtrls.append(cBrowTransform)
        cBrowTransform.sExtraMove = cBrowTransform.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])

        for c, cC in enumerate(ccCtrls[s]):

            sBrowTransformParentGrp = cmds.listRelatives(cBrowTransform.sCtrl, p=True)[0]
            sBrowTransformJumpedParent = nodes.createMultMatrixNode(['%s.worldMatrix' % sBrowTransformParentGrp,
                                                                   '%s.worldInverseMatrix' % cBrowTransform.sExtraMove,
                                                                   '%s.worldMatrix' % cBrowTransform.sPasser])
            fSecondPasserLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSecondPasser, '%s.worldInverseMatrix' % sBrowTransformParentGrp], bJustValues=True)
            sInverse = nodes.createInverseMatrix(nodes.createMultMatrixNode([fSecondPasserLocal, sBrowTransformJumpedParent]))
            sBrowTransformInSecondPasserSpace = nodes.createMultMatrixNode(['%s.matrix' % cBrowTransform.sCtrl, sBrowTransformJumpedParent, sInverse])
            fLocal = nodes.createMultMatrixNode(['%s.matrix' % cC.sSecondPasser, nodes.createInverseMatrix(sBrowTransformInSecondPasserSpace)], bJustValues=True)
            sLocal2 = nodes.createMultMatrixNode([fLocal, sBrowTransformInSecondPasserSpace])
            nodes.createDecomposeMatrix(sLocal2, sTargetPos='%s.t' % cC.sSecondPasser, sTargetRot='%s.r' % cC.sSecondPasser)


            sPoseOffset = cC.getOffsetByName('pose')
            sPreSibling = cmds.duplicate(sPoseOffset, n='%s_preSiblingDown' % sPoseOffset, po=True)[0]
            sDriverValue = utils.addAttr(sPreSibling, ln='driverValue', dv=-0.5, k=True)
            nodes.createRangeNode('%s.ty' % cBrowTransform.sCtrl, 0, sDriverValue, [0, 0, 0], '%s.t' % sPreSibling,
                                  sTarget='%s.t' % sPoseOffset, bOutRangeIsVector=True)
            nodes.createRangeNode('%s.ty' % cBrowTransform.sCtrl, 0, sDriverValue, [0, 0, 0], '%s.r' % sPreSibling,
                                  sTarget='%s.r' % sPoseOffset, bOutRangeIsVector=True)
            sDefaultSettingAttrsBrows.extend(
                ['%s.%s' % (sPreSibling, sA) for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']])
            sDefaultSettingAttrsBrows.append(sDriverValue)
            cmds.controller(cC.sCtrl, cBrowTransform.sCtrl, parent=True)


    # ctrl aiming setup
    ssJoints = [], []
    ssRefJoints = [], []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1 if sSide == 'r' else 1
        for c, sLetter in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            cC.sInfParent = xforms.createTransform('grp_%s_tweakerBrowSplinesInf%s' % (sSide, sLetter), sParent=cC.sJumpedOut)
            cC.sRefInfParent = xforms.createTransform('grp_%s_tweakerBrowSplinesInf%s_ref' % (sSide, sLetter), sParent=cC.sPasser)

            cC.sInfs = []
            cC.sRefInfs = []
            cC.cTangents = []
            for d, sDir in enumerate(['in', 'out']):
                if (c == 0 and d == 0) or (c == 2 and d == 1):
                    continue
                cC.sInfs.append(xforms.createJoint('jnt_%s_tweakerBrowSplinesInf%s%s' % (sSide, sLetter, utils.getFirstLetterUpperCase(sDir)),
                                sParent=cC.sInfParent, fSize=1.5, xPos=[[-0.01, 0.01][d], 0, 0]))
                cC.sRefInfs.append(xforms.createJoint('jnt_%s_tweakerBrowSplinesInf%s%s_ref' % (sSide, sLetter, utils.getFirstLetterUpperCase(sDir)),
                                sParent=cC.sRefInfParent, fSize=1.8, xPos=[[-0.01, 0.01][d], 0, 0]))

                cTangent = ctrls6.create('tweakerBrowSplineTangent%s%s' % (sLetter, utils.getFirstLetterUpperCase(sDir)),
                                         sSide=sSide, sMatch=cC.sInfs[0], sShape='revL',
                                         sParent=cC.sInfParent, sAttrs=['rx', 'ry', 'rz', 'sx', 'sy', 'sz'],
                                         fSize=fSliderScale * 0.4, iColorIndex=0, fRotateShape=[-90, 0, 0])
                sExtraMove = cTangent.createExtraMoveTransformAndTag(['skinCluster__*face*__BEND'])
                cmds.controller(cTangent.sCtrl, cC.sCtrl, parent=True)

                if d == 0:
                    cmds.setAttr('%s.sx' % cTangent.sSlider, -fSideMultipl)
                    cmds.setAttr('%s.sx' % cTangent.sOut, -fSideMultipl)
                sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cTangent.sOut, '%s.worldInverseMatrix' % sExtraMove])
                nodes.createDecomposeMatrix(sMatrix, '%s.t' % cC.sInfs[-1], '%s.r' % cC.sInfs[-1], '%s.s' % cC.sInfs[-1])
                utils.addOffOnAttr(cC.sCtrl, 'tangentCtrlVis', bReturnIfExists=True, sTarget='%s.v' % cTangent.sPasser)

                cTangent.sPose = cTangent.appendOffsetGroup('pose')

                cC.cTangents.append(cTangent)

            [cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf) for sInf in cC.sInfs+cC.sRefInfs]

            cC.sAimer = xforms.createLocator('loc_%s_tweakerBrowAimer%s' % (sSide, sLetter), sParent=cC.sPasser)
            cC.sAimTarget = xforms.createLocator('loc_%s_tweakerBrowAimTarget%s' % (sSide, sLetter), sParent=cC.sPasser)
            nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cC.sExtraMove, sTarget='%s.t' % cC.sAimer)
            nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cC.sExtraMove, sTarget='%s.t' % cC.sAimTarget)

            cC.sRefAimer = xforms.createLocator('loc_%s_tweakerBrowAimer%s_ref' % (sSide, sLetter), sParent=cC.sPasser)
            cC.sRefAimTarget = xforms.createLocator('loc_%s_tweakerBrowAimTarget%s_ref' % (sSide, sLetter), sParent=cC.sPasser)
            xforms.matchXform(cC.sAimer, cC.sRefAimer)
            xforms.matchXform(cC.sAimTarget, cC.sRefAimTarget)


            for sTransform in [cC.sAimer, cC.sAimTarget, cC.sRefAimer, cC.sRefAimTarget]:
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sTransform)

            sRelativeMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl, '%s.worldInverseMatrix' % cC.sExtraMove])
            cC.sTwist = '%sX' % nodes.createDecomposeMatrix(sRelativeMatrix, bReturnRotate=True)
            cmds.setAttr('%s.inputRotateOrder' % cC.sTwist.split('.')[0], 1)  # to have x last

        for sAimer, sInfParent, sAimTargets, fAim in [
            (ccCtrls[s][0].sAimer, ccCtrls[s][0].sInfParent, [ccCtrls[s][1].sAimTarget], [fSideMultipl, 0, 0]),
            (ccCtrls[s][1].sAimer, ccCtrls[s][1].sInfParent, [ccCtrls[s][0].sAimTarget, ccCtrls[s][2].sAimTarget], [-fSideMultipl, 0, 0]),
            (ccCtrls[s][2].sAimer, ccCtrls[s][2].sInfParent, [ccCtrls[s][1].sAimTarget], [-fSideMultipl, 0, 0]),
            (ccCtrls[s][0].sRefAimer, ccCtrls[s][0].sRefInfParent, [ccCtrls[s][1].sRefAimTarget], [fSideMultipl, 0, 0]),
            (ccCtrls[s][1].sRefAimer, ccCtrls[s][1].sRefInfParent, [ccCtrls[s][0].sRefAimTarget, ccCtrls[s][2].sAimTarget], [-fSideMultipl, 0, 0]),
            (ccCtrls[s][2].sRefAimer, ccCtrls[s][2].sRefInfParent, [ccCtrls[s][1].sRefAimTarget], [-fSideMultipl, 0, 0])]:
            sAimConstraint = constraints.aimConstraintEmpty(sAimer, aim=fAim)

            sPasserInv = '%s.worldInverseMatrix' % cmds.listRelatives(sAimer, p=True)[0]
            if len(sAimTargets) == 1:
                sAimPointTotal = nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[0]), sPasserInv)

            elif len(sAimTargets) == 2:
                sTranslateConnections = cmds.listConnections('%s.t' % sAimer, s=True, d=False, p=True)
                if sTranslateConnections:
                    sAimPoint0 = nodes.createVectorAdditionNode([nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[0]), sPasserInv), sTranslateConnections[0]], sOperation='minus')
                    sAimPoint1 = nodes.createVectorAdditionNode([nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[1]), sPasserInv), sTranslateConnections[0]], sOperation='minus')
                    sAimPoint1 = nodes.createVectorMultiplyNode(sAimPoint1, -1, bVectorByScalar=True)
                    sAimPointTotal = nodes.createVectorAdditionNode([sTranslateConnections[0], sAimPoint0, sAimPoint1])
                else:
                    sAimPoint0 = nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[0]), sPasserInv)
                    sAimPoint1 = nodes.createPointByMatrixNode(nodes.getWorldPoint(sAimTargets[1]), sPasserInv)
                    sAimPointTotal = nodes.createVectorAdditionNode([sAimPoint0, sAimPoint1], sOperation='minus')

            cmds.connectAttr(sAimPointTotal, '%s.target[0].targetTranslate' % sAimConstraint)
            cmds.connectAttr('%s.constraintRotate' % sAimConstraint, '%s.r' % sInfParent)

    for s, sSide in enumerate(['l', 'r']):
        # create skin joints
        sUpGroups = []
        sRefUpGroups = []
        sPointOnCurves = []
        sRefPointOnCurves = []
        for j, fP in enumerate(ffParams[s]):
            sJ = 'jnt_%s_tweakerBrowsSplines_%03d' % (sSide, j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
                xforms.resetJoint(sJ)
                cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.25)
            else:
                sJ = xforms.createJoint(sJ, fSize=fSliderScale * 0.25, sParent=sParentJoint)

            sRefJ = xforms.createJoint('jnt_%s_tweakerBrowSplines_%03d_ref' % (sSide, j), fSize=fSliderScale * 0.33, sParent=sRefParentJoint)

            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)

            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)

            sUp = xforms.createTransform(sName='grp_%s_tweakerBrowsUp_%03d' % (sSide, j))
            sRefUp = xforms.createTransform(sName='grp_%s_tweakerBrowsUp_%03d_ref' % (sSide, j))
            cmds.parent(sUp, sBrowsOrig)

            ssJoints[s].append(sJ)
            sUpGroups.append(sUp)
            ssRefJoints[s].append(sRefJ)
            sRefUpGroups.append(sRefUp)

            # scale
            sMultipls = [nodes.createVectorMultiplyNode('%s.s' % ccCtrls[s][c].sCtrl, aaaWeights[s][c][j], bVectorByScalar=True) for c in [0, 1, 2]]
            nodes.createVectorAdditionNode(sMultipls, sTarget='%s.s' % sJ)

            _, sPosOnCurve = curves.createPointInfoNode(sCurves[s], fParam=fP)
            sPointOnCurves.append(sPosOnCurve)

            _, sRefPosOnCurve = curves.createPointInfoNode(sRefCurves[s], fParam=fP)
            sRefPointOnCurves.append(sRefPosOnCurve)

        for j, fP in enumerate(ffParams[s]):
            sJ = ssJoints[s][j]
            sRefJ = ssRefJoints[s][j]
            sUp = sUpGroups[j]
            sRefUp = sRefUpGroups[j]

            # pos
            sPos = nodes.createPointByMatrixNode(sPointOnCurves[j], '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            sRefPos = nodes.createPointByMatrixNode(sRefPointOnCurves[j], '%s.worldInverseMatrix' % sRefParentJoint, sTarget='%s.t' % sRefJ)

            # upPos
            _, sUpPosOnCurve = curves.createPointInfoNode(sUpCurves[s], fParam=fP)
            nodes.createPointByMatrixNode(sUpPosOnCurve, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sUp)
            _, sRefUpPosOnCurve = curves.createPointInfoNode(sRefUpCurves[s], fParam=fP)
            nodes.createPointByMatrixNode(sRefUpPosOnCurve, '%s.worldInverseMatrix' % sRefParentJoint, sTarget='%s.t' % sRefUp)

            sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, fSideMultipl], up=[fSideMultipl, 0, 0] if j == 0 else [-1, 0, 0])
            nodes.createPointByMatrixNode(sUpPosOnCurve, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            sRefAimConstraint = constraints.aimConstraintEmpty(sRefJ, aim=[0, 0, fSideMultipl], up=[fSideMultipl, 0, 0] if j == 0 else [-1, 0, 0])
            nodes.createPointByMatrixNode(sRefUpPosOnCurve, '%s.worldInverseMatrix' % sRefParentJoint, sTarget='%s.target[0].targetTranslate' % sRefAimConstraint)

            sAimingUpPoint = nodes.createPointByMatrixNode(sPointOnCurves[j + 1 if j == 0 else j - 1], '%s.worldInverseMatrix' % sParentJoint)
            sLiveUp = nodes.createVectorAdditionNode([sAimingUpPoint, sPos], sOperation='minus')
            sRefAimingUpPoint = nodes.createPointByMatrixNode(sRefPointOnCurves[j + 1 if j == 0 else j - 1], '%s.worldInverseMatrix' % sRefParentJoint)
            sRefLiveUp = nodes.createVectorAdditionNode([sRefAimingUpPoint, sRefPos], sOperation='minus')


            sBlendedRotateMatrix = nodes.createBlendMatrixNode([ccCtrls[s][0].sRotationMatrix, ccCtrls[s][1].sRotationMatrix, ccCtrls[s][2].sRotationMatrix],
                                                                    [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]])
            sRefBlendedRotateMatrix = nodes.createBlendMatrixNode([ccCtrls[s][0].sRefRotationMatrix, ccCtrls[s][1].sRefRotationMatrix, ccCtrls[s][2].sRefRotationMatrix],
                                                                    [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]])

            fStaticLocalUp = nodes.createPointByMatrixNode(sLiveUp, nodes.createInverseMatrix(sBlendedRotateMatrix, bJustValues=True), bJustValues=True)
            sLocalUp = nodes.createPointByMatrixNode(fStaticLocalUp, sBlendedRotateMatrix)
            sRefLocalUp = nodes.createPointByMatrixNode(fStaticLocalUp, sRefBlendedRotateMatrix)

            sBlendAttr = nodes.createDotProductNode([ccCtrls[s][0].sJointAimAtNeighborAttr, ccCtrls[s][1].sJointAimAtNeighborAttr, ccCtrls[s][2].sJointAimAtNeighborAttr],
                                                    [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]])
            nodes.createBlendNode(sBlendAttr, sLiveUp, sLocalUp, bVector=True, sTarget='%s.worldUpVector' % sAimConstraint)
            nodes.createBlendNode(sBlendAttr, sRefLiveUp, sRefLocalUp, bVector=True, sTarget='%s.worldUpVector' % sRefAimConstraint)

            # twist
            nodes.createDotProductNode([ccCtrls[s][0].sTwist, ccCtrls[s][1].sTwist, ccCtrls[s][2].sTwist],
                                       [aaaWeights[s][0][j], aaaWeights[s][1][j], aaaWeights[s][2][j]], sTarget='%s.offsetX' % sAimConstraint)
            cmds.setAttr('%s.offset' % sRefAimConstraint, *(cmds.getAttr('%s.offset' % sAimConstraint)[0]))

        # post brow ctrls
        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            sDrivenGrp = cC.sOut
            sRangesR = []
            sRangesT = []
            for sDir, fRot, sDriverA, fDriverCtrlValue in [('up', (0, 0, 0), 'Y', 1.0),
                                                           ('down', (0, 0, 0), 'Y', -0.5),
                                                           ('in', (0, 0, 0), 'X', -0.5)]:
                sPostSibling = utils.replaceStringEnd(sDrivenGrp, 'Out',
                                                      '_postSibling%s' % utils.getFirstLetterUpperCase(sDir))
                sPostSibling = utils.replaceStringStart(sPostSibling, 'ctrl_', 'grp_')
                sPostSibling = cmds.duplicate(sDrivenGrp, n=sPostSibling, po=True)[0]
                cmds.setAttr('%s.r' % sPostSibling, *fRot)
                sDriverValue = utils.addAttr(sPostSibling,
                                             ln='driverCtrlValue%s' % utils.getFirstLetterUpperCase(sDriverA), k=True,
                                             dv=fDriverCtrlValue)

                sDriverAttr = '%s.totalTranslate%s' % (cC.sPasser, sDriverA)

                sDriverValueMultipl = nodes.createMultiplyNode(sDriverValue, 100)
                sRangesR.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                      [0, 0, 0],
                                                      nodes.createVectorMultiplyNode('%s.r' % sPostSibling, 100, bVectorByScalar=True),
                                                      bOutRangeIsVector=True, sName='r_%s_%s' % (sDir, sDriverA)))
                sRangesT.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,
                                                      [0, 0, 0],
                                                      nodes.createVectorMultiplyNode('%s.t' % sPostSibling, 100, bVectorByScalar=True),
                                                      bOutRangeIsVector=True, sName='t_%s_%s' % (sDir, sDriverA)))

                sDefaultSettingAttrsBrows.extend(['%s.%s' % (sPostSibling, sA) for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']])
                sDefaultSettingAttrsBrows.append(sDriverValue)

            nodes.createVectorAdditionNode(sRangesR, sTarget='%s.r' % sDrivenGrp)
            nodes.createVectorAdditionNode(sRangesT, sTarget='%s.t' % sDrivenGrp)

        # pre tangent ctrls
        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ccCtrls[s][c]
            for sDrivenGrp in [cTangent.sPose for cTangent in cC.cTangents]:
                sRangesR = []
                for sDir, fRot, sDriverA, fDriverCtrlValue in [('up', (0, 0, 0), 'Y', 1.0),
                                                               ('down', (0, 0, 0), 'Y', -0.5),
                                                               ('in', (0, 0, 0), 'X', -0.5)]:
                    sPreTangentSibling = utils.replaceStringEnd(sDrivenGrp, 'Pose', '_preTangentSiblingTweakerBrowsSplines%s' % utils.getFirstLetterUpperCase(sDir))
                    sPreTangentSibling = cmds.duplicate(sDrivenGrp, n=sPreTangentSibling, po=True)[0]
                    cmds.setAttr('%s.r' % sPreTangentSibling, *fRot)
                    sDriverValue = utils.addAttr(sPreTangentSibling, ln='driverCtrlValueTangents%s' % utils.getFirstLetterUpperCase(sDriverA), k=True, dv=fDriverCtrlValue, bReturnIfExists=True)

                    sDriverAttr = '%s.totalTranslate%s' % (cC.sPasser, sDriverA)

                    sDriverValueMultipl = nodes.createMultiplyNode(sDriverValue, 100)
                    sRangesR.append(nodes.createRangeNode(sDriverAttr, 0, sDriverValueMultipl,[0, 0, 0],
                                                          nodes.createVectorMultiplyNode('%s.r' % sPreTangentSibling,100, bVectorByScalar=True),
                                                          bOutRangeIsVector=True, sName='r_%s_%s' % (sDir, sDriverA)))

                    sDefaultSettingAttrsBrows.extend(['%s.%s' % (sPreTangentSibling, sA) for sA in ['rx', 'ry', 'rz']])
                    sDefaultSettingAttrsBrows.append(sDriverValue)

                nodes.createVectorAdditionNode(sRangesR, sTarget='%s.r' % sDrivenGrp)

        weights.skinCurveBSpline4(patch.patchFromName(sCurves[s]), utils.flattenedList([cC.sInfs for cC in ccCtrls[s]]))
        weights.skinCurveBSpline4(patch.patchFromName(sUpCurves[s]), utils.flattenedList([cC.sInfs for cC in ccCtrls[s]]))
        weights.skinCurveBSpline4(patch.patchFromName(sRefCurves[s]), utils.flattenedList([cC.sRefInfs for cC in ccCtrls[s]]))
        weights.skinCurveBSpline4(patch.patchFromName(sRefUpCurves[s]), utils.flattenedList([cC.sRefInfs for cC in ccCtrls[s]]))

    deformers.connectJointReferencesFromAttr(utils.flattenedList(ssJoints))

    cSideCtrls = utils.flattenedList(ccCtrls)
    for cC in cSideCtrls + cMainCtrls + utils.flattenedList([cC.cTangents for cC in cSideCtrls]):
        cC.setDefaultAttrDict()

    utils.data.store('sDefaultSettingAttrsTweakerBrowsSplines', sDefaultSettingAttrsBrows)
    for sA, fV in dDefaultSettingValuesBrows.items():
        if cmds.objExists(sA):
            cmds.setAttr(sA, fV)
        else:
            report.report.addLogText('skipping "%s", doesn\'t exist..' % sA)


    createOrFixFaceZero()
    for cC in cSideCtrls + cMainCtrls:
        sAttachDeformers = [sD for sD in ctrls6.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls6.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers, bRotate=True)



kTweakerBrowsSimpleBpGroupName = '_grp_m_tweakerBrowsSimpleBpMain'

def tweakerBrowOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_tweakerBrowsSimple', [0, 0.5, 1])
    sNames = ['A', 'B', 'C']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sMainBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls6.createSimpleCurve('matrixNames', sName='bpLoc_l_tweakerBrowsSimpleOrientation%s' % sNames[i], sParent=kTweakerBrowsSimpleBpGroupName)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)


dSelectSiblingsMenu = {}
dSelectSiblingsMenu['all'] = lambda: cmds.select(cmds.ls('grp_l_tweakerBrowsSimple*_*Sibling*', et='transform'))


dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_tweakerBrowsSimple', kTweakerBrowsSimpleBpGroupName, fDirection=(1, 0, 0))
dButtons['Create Left Brow Orientation Locators'] = tweakerBrowOrientationLocators
dButtons['=== SELECT LEFT SIBLINGS ==='] = dSelectSiblingsMenu
dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsTweakerBrowsSimple', 'dDefaultSettingValuesTweakerBrowsSimple')

dButtons['Add Influences to Selected'] = lambda:bindTweakers('jnt_?_tweakerBrowsSimple*')

dButtons['- Export Tweaker brows Simple BPs -'] = lambda: exportBps('faceBlueprintsTweakerBrowsSimple.ma', kTweakerBrowsSimpleBpGroupName)


@builderTools.addToBuild(iOrder=85.4, dButtons=dButtons, bDisableByDefault=True)
def TWEAKER_browsSimple(sAttachMesh='', sVisAttrCtr='head_ctrl', sParentJoint='jnt_m_headMain', dDefaultSettingValuesBrows={}):
    sDefaultSettingAttrsBrows = []
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    sCtrlVis = utils.addOffOnAttr(utils.toList(sVisAttrCtr)[0], 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)


    sBpCurves = ['bpCurve_%s_tweakerBrowsSimple' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleBrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv)

    aaCurvePoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                     curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aaCtrlPoints = [[aaCurvePoints[0][0], aaCurvePoints[0][3], aaCurvePoints[0][6]],
                    [aaCurvePoints[1][0], aaCurvePoints[1][3], aaCurvePoints[1][6]]]

    # collect orients
    ssBpOrients = []
    for s, sSide in enumerate(['l', 'r']):
        sBpOrients = []
        for sName in ['A', 'B', 'C']:
            sBpOrient = 'bpLoc_%s_tweakerBrowsSimpleOrientation%s' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_tweakerBrowsSimpleOrientation%s' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    xforms.mirrorCurveTransforms(sLeftBpOrient)
            sBpOrients.append(sBpOrient)
        ssBpOrients.append(sBpOrients)


    # make up curves
    ccCtrls = [], []
    ssJoints = [], []
    for s, sSide in enumerate(['l', 'r']):

        for c, sName in enumerate(['A', 'B', 'C']):
            cC = ctrls6.create(sName='tweakerBrow%s' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(),
                               fMatchPos=aaCtrlPoints[s][c], sShape='cube', fSliderScale=fSliderScale,
                               sAttrs=['t', 'r', 'sy', 'sz'], fSize=0.25)
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            ccCtrls[s].append(cC)

            sBpOrient = 'bpLoc_%s_tweakerBrowsSimpleOrientation%s' % (sSide, sName)
            if cmds.objExists(sBpOrient):
                cmds.delete(cmds.orientConstraint(sBpOrient, cC.sPasser))

            sJ = 'jnt_%s_tweakerBrowsSimple_%s' % (sSide, sName)
            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
                xforms.resetJoint(sJ)
                cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.25)
            else:
                sJ = xforms.createJoint(sJ, fSize=fSliderScale * 0.25, sParent=sParentJoint)

            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
            constraints.matrixParentConstraint(cC.sOut, sJ)

            sRefJ = xforms.createJoint('jnt_%s_tweakerBrowsSimple_%s_ref' % (sSide, sName), fSize=fSliderScale * 0.33, sParent=cC.sPasser)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            xforms.matchXform(sJ, sRefJ)

            ssJoints[s].append(sJ)

    deformers.connectJointReferencesFromAttr(utils.flattenedList(ssJoints))

    for cC in utils.flattenedList(ccCtrls):
        cC.setDefaultAttrDict()
        sAttachDeformers = [sD for sD in ctrls6.kDefaultFaceAttachDeformers if 'TWEAKER' not in sD]
        ctrls6.tagTransformForParallelAttachment(cC.sPasser, sAttachDeformers, bRotate=True)





def proceduralBind_zipper(iBindLipRows, fBindMultipls):
    _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='Zipper', sSkinClusterSuffix='ZIPPER')

dButtons = {}
dButtons['bind selected'] = proceduralBind_zipper



@builderTools.addToBuild(iOrder=84, dButtons=dButtons, bDisableByDefault=True)
def postZipper(sMesh=None, sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain', sLipPressMesh=None, sClosedMesh=None, iBindLipRows=[3,3], fBindMultipls=[1.0,1.0,1.0], fOvershoot=0.05):

    sMesh = utils.objFromArg(sMesh)

    if utils.data.get('bMouthJointType', sNode=utils.kFaceDataNode, xDefault=False) == True:
        report.report.addLogText('skipping because mouth rig has joint setup')
        return

    sZipperGrpOrigin = cmds.createNode('transform', n='grp_zipperOrigin') #, p=getFaceGrp())
    # fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode)
    sZipperGrpWorld = cmds.createNode('transform', n='grp_zipperWorld') #, p=getFaceGrp())
    constraints.matrixParentConstraint(sParentJoint, sZipperGrpWorld)


    # zipper
    cCornerCtrls = [ctrls6.ctrlFromName('lipsCorner_l_ctrl'), ctrls6.ctrlFromName('lipsCorner_r_ctrl')]
    sSealLeft = utils.addAttr(cCornerCtrls[0].sCtrl, ln='seal', at='double',  defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
    sSealRight = utils.addAttr(cCornerCtrls[1].sCtrl, ln='seal', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)

    sSealFadeLengthLeft = utils.addAttr(cCornerCtrls[0].sCtrl, ln='sealFade', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
    sSealFadeLengthRight = utils.addAttr(cCornerCtrls[1].sCtrl, ln='sealFade', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)

    sSealLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealLeft, sSealFadeLengthLeft), sName='left_sealByFade')
    sSealRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealRight, sSealFadeLengthRight), sName='right_sealByFade')

    sBpCurvesA = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]

    sZipperCurves = [cmds.duplicate(sBpCurvesA[0], n='crv_m_botZipper')[0], cmds.duplicate(sBpCurvesA[1], n='crv_m_topZipper')[0]]
    cmds.parent(sZipperCurves, sZipperGrpOrigin)

    pMesh = patch.patchFromName(sMesh)
    aMeshPoints = pMesh.getPoints()
    aClosedMeshPoints = aMeshPoints if not sClosedMesh else patch.patchFromName(sClosedMesh).getPoints()

    aHeadMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sParentJoint), dtype='float64').reshape(4,4)
    aHeadMatrixInverse = np.linalg.inv(aHeadMatrix)

    aClosedMeshPointsLocal = np.dot(utils.makePoint4Array(aClosedMeshPoints), aHeadMatrixInverse)[:,0:3]
    if sLipPressMesh:
        aLipPressMeshPoints = patch.patchFromName(sLipPressMesh).getPoints()
        aLipPressPointsLocal = np.dot(utils.makePoint4Array(aLipPressMeshPoints), aHeadMatrixInverse)[:,0:3]


    ssJoints = [], []
    ssRefJoints = [], []
    aaPoints = [None, None]
    for p,sPart in enumerate(['bot','top']):
        aAllPartPoints = np.array(cmds.xform('%s.cv[*]' % sZipperCurves[p], q=True, t=True, ws=True), dtype='float64').reshape(-1,3)
        if p == 0:
            aaPoints[p] = aAllPartPoints
        else:
            aaPoints[p] = aAllPartPoints[1:-1]

        aSides, aInds = utils.convertMiddleSequenceToSides(len(aaPoints[p]))
        for j,aPoint in enumerate(aaPoints[p]):
            sRefJ = cmds.createNode('joint', n='jnt_%s_%sRefZipper_%03d' % (aSides[j], sPart, aInds[j]), p=sZipperGrpWorld)
            sJ = 'jnt_%s_%sZipper_%03d' % (aSides[j], sPart, aInds[j])
            if not cmds.objExists(sJ):
                sJ = cmds.createNode('joint', n=sJ, p=sZipperGrpWorld)
            else:
                cmds.parent(sJ, sZipperGrpWorld)
            utils.matchJointRadius(sJ, 'jnt_m_headMain', 0.2)
            utils.matchJointRadius(sRefJ, 'jnt_m_headMain', 0.5)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            ssJoints[p].append(sJ)
            ssRefJoints[p].append(sRefJ)
            cmds.setAttr('%s.v' % sRefJ, False)

    aaClosestIds = [xforms.findClosestPoints(aaPoints[0], aMeshPoints),
                    xforms.findClosestPoints(aaPoints[1], aMeshPoints)]

    aClosestIds = np.concatenate([aaClosestIds[0], aaClosestIds[1]])
    cmds.select(ssJoints[0], ssJoints[1])

    sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh
    if cmds.objExists(sSkinCluster):
        cmds.setAttr('%s.envelope' % sSkinCluster, 0.0)

    sLocs = constraints.parallelTransformAsDeformers(sMesh, aClosestIds, sParent=sZipperGrpOrigin,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint,
                                                     sDeformers=['skinCluster__%s' % sMesh])
    [cmds.setAttr('%s.localScale' % sL, 0.02, 0.02, 0.02) for sL in sLocs]

    ssLocs = sLocs[:len(aaPoints[0])], sLocs[len(aaPoints[0]):]
    for p,sPart in enumerate(['bot','top']):
        for j,sJ  in enumerate(ssJoints[p]):
            cmds.pointConstraint(ssLocs[p][j], ssRefJoints[p][j])
            cmds.delete(cmds.pointConstraint(ssLocs[p][j], ssJoints[p][j]))


    cmds.skinCluster(sZipperCurves[0], ssRefJoints[0], tsb=True)
    cmds.skinCluster(sZipperCurves[1], ssRefJoints[1], tsb=True)

    ffOppositeParams = []
    ffOppositeParams.append(curves.getParamsFromPoints(sZipperCurves[1], aaPoints[0]))
    ffOppositeParams.append(curves.getParamsFromPoints(sZipperCurves[0], aaPoints[1]))


    if sLipPressMesh:
        sLipPressAttr = utils.addAttr('mouth_ctrl', ln='lipPress', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True, bReturnIfExists=True)
    else:
        sLipPressAttr = 0.0

    sOverShoot = utils.addAttr('grp_m_mouthPasser', ln='zipperOverShoot', k=True, dv=fOvershoot)

    for p,sPart in enumerate(['bot','top']):
        aSides, aInds = utils.convertMiddleSequenceToSides(len(aaPoints[p]))

        fLeftPercs = utils.bSpline4([0,0,1,1], aValues=np.arange(len(ffOppositeParams[p])) / float(len(ffOppositeParams[p])-1))
        fRightPercs = 1.0 - fLeftPercs
        sPositionAdditions = []
        sAllLeftRightSealsClamped = []
        sBlendPlusOvershoot = nodes.createAdditionNode([0.5, sOverShoot])
        for j,sJ in enumerate(ssJoints[p]):
            cmds.setAttr('%s.jo' % sJ, 0,0,0)
            cmds.setAttr('%s.jo' % sRefJ, 0,0,0)

            deformers.connectRefsOnCurrentSkinClusters(sJ)
            sLeftRightSeals = cmds.createNode('plusMinusAverage', n='plus_%s_sumSeals_%03d' % (aSides[j], aInds[j]))

            sEndLeft = nodes.createAdditionNode([fLeftPercs[j], sSealFadeLengthLeft],
                                          sName='%s_left_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeLeft = nodes.createRangeNode(sSealLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0,
                                               sName='%s_left_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sEndRight = nodes.createAdditionNode([fRightPercs[j], sSealFadeLengthRight], sName='%s_right_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeRight = nodes.createRangeNode(sSealRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='%s_right_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sAllClose = nodes.createAdditionNode(['%s.output1D' % sLeftRightSeals, sLipPressAttr])
            sAllCloseClamped = nodes.createClampNode(sAllClose, 0, 1)

            _, sPosOnNode = curves.createPointInfoNode(sZipperCurves[0 if p == 1 else 1], fParam=ffOppositeParams[p][j], sName='%sSeal_%03d' % (sPart, j))
            sPosOnNodeLocal = nodes.createPointByMatrixNode(sPosOnNode, '%s.worldInverseMatrix' % sParentJoint)
            sPosOnNodeBlend = nodes.createBlendNode(sBlendPlusOvershoot, sPosOnNodeLocal, '%s.t' % ssRefJoints[p][j], bVector=True)

            sNewOffset = nodes.createVectorAdditionNode([sPosOnNodeBlend, '%s.t' % ssRefJoints[p][j]], sOperation='minus')

            sOffsetMultipls = []
            sOffsetMultipls.append(nodes.createVectorMultiplyNode(sNewOffset, sAllCloseClamped, bVectorByScalar=True))
            sAdd = nodes.createVectorAdditionNode(['%s.t' % ssRefJoints[p][j]] + sOffsetMultipls, '%s.t' % ssJoints[p][j])
            sPositionAdditions.append(sAdd.split('.')[0])
            sAllLeftRightSealsClamped.append(sAllCloseClamped)

        cCornerCtrl = ctrls6.ctrlFromName('lipsCorner_l_ctrl')
        cmds.setAttr('%s.seal' % cCornerCtrl.sCtrl, 1.0)
        for j,sJ in enumerate(ssJoints[p]):
            aPos = np.array(cmds.getAttr('%s.t' % ssJoints[p][j])[0], dtype='float64')
            aOffset = aClosedMeshPointsLocal[aaClosestIds[p][j]] - aPos
            sMult = nodes.createVectorMultiplyNode(aOffset, sAllLeftRightSealsClamped[j], bVectorByScalar=True)
            cmds.connectAttr(sMult, '%s.input3D[2]' % sPositionAdditions[j])
        cmds.setAttr('%s.seal' % cCornerCtrl.sCtrl, 0.0)

        if sLipPressMesh:
            cmds.setAttr(sLipPressAttr, 1.0)
            for j,sJ in enumerate(ssJoints[p]):
                aPos = np.array(cmds.getAttr('%s.t' % ssJoints[p][j])[0], dtype='float64')
                aOffset = aLipPressPointsLocal[aaClosestIds[p][j]] - aPos
                sDiff = nodes.createAdditionNode([sLipPressAttr, sAllLeftRightSealsClamped[j]], sOperation='minus')
                sDiff = nodes.createClampNode(sDiff, 0, 1)
                sMult = nodes.createVectorMultiplyNode(aOffset, sDiff, bVectorByScalar=True)
                cmds.connectAttr(sMult, '%s.input3D[3]' % sPositionAdditions[j])
            cmds.setAttr(sLipPressAttr, 0.0)


    createOrFixFaceZero()


    sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh

    # fix skinCluster if it's already there from loadDeformers
    if cmds.objExists(sSkinCluster):
        sJoints = cmds.ls('jnt_?_???Zipper_???', et='joint')
        if cmds.objExists(sSkinCluster):
            cmds.setAttr('%s.envelope' % sSkinCluster, True)

        for j, sJoint in enumerate(sJoints):
            sRefJoint = sJoint.replace('Zipper', 'RefZipper')
            if not cmds.objExists(sRefJoint):
                continue

            sMatrixConnections = cmds.listConnections('%s.worldMatrix' % sJoint, p=True, t='skinCluster', s=False,
                                                      d=True)
            if not sMatrixConnections:
                continue
            sMatrixConnections = [sC for sC in sMatrixConnections if sC.startswith(sSkinCluster)]
            if not sMatrixConnections:
                continue

            iIndex = utils.indexFromName(sMatrixConnections[0])
            cmds.connectAttr('%s.worldInverseMatrix' % sRefJoint, '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex),
                             f=True)


    if sLipPressMesh:
        # sModels = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)
        # sSecondaryModels = [] if len(sModels) <= 1 else sModels[1:]
        blendShapesPro.connectTargets(sMesh, sLipPressMesh, dPoses={sLipPressAttr: 1.0}, bMirror=False, iInvert=2)

    cmds.parent(sZipperGrpOrigin, sZipperGrpWorld, 'modules')





@builderTools.addToBuild(iOrder=84.5, bDisableByDefault=True)
def blendShapifyPostZipper(iSampleCount=8, fJawRotationZ=-30):

    sMirrorJointAxes = utils.data.get('sMirrorJointAxes', xDefault=[]) #, xDefault=[])

    sSuffixes = utils.data.get('sImportedHeadSuffixes')
    bReturn = None
    sBpCurvesA = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]
    utils.data.store('dZipper', {'iSampleCount': iSampleCount, 'sCurve': sBpCurvesA[0]})
    blendShapesPro.createOrGetZipperSetup()

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={})
    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={})
    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={})
    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={})
    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={})
    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={})
    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={})
    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={})
    dConnectTargetLidRanges = utils.data.get('dConnectTargetLidRanges', xDefault={})
    dConnectTargetControlRigCommands = utils.data.get('dConnectTargetControlRigCommands', xDefault={})

    utils.addListKey(dConnectTargetPoses, 'zipper')
    utils.addListKey(dConnectTargetDrivers, 'zipper')
    utils.addListKey(dConnectTargetMirrors, 'zipper')
    utils.addListKey(dConnectTargetSplitRadien, 'zipper')
    utils.addListKey(dConnectTargetSplitBotTops, 'zipper')
    utils.addListKey(dConnectTargetInverts, 'zipper')
    utils.addListKey(dConnectTargetSplitAlongCurves, 'zipper')
    utils.addListKey(dConnectTargetZippers, 'zipper')
    utils.addListKey(dConnectTargetLidRanges, 'zipper')
    utils.addListKey(dConnectTargetControlRigCommands, 'zipper')

    dConnectTargetPoses['zipper'].append({})
    dConnectTargetDrivers['zipper'].append({})
    dConnectTargetMirrors['zipper'].append(False)
    dConnectTargetSplitRadien['zipper'].append(1.0)
    dConnectTargetSplitBotTops['zipper'].append(False)
    dConnectTargetInverts['zipper'].append(2)
    dConnectTargetSplitAlongCurves['zipper'].append({})
    dConnectTargetZippers['zipper'].append(True)
    dConnectTargetLidRanges['zipper'].append([])
    dConnectTargetControlRigCommands['zipper'].append(True)



    utils.addListKey(dConnectTargetPoses, 'jawOpenZipper')
    utils.addListKey(dConnectTargetDrivers, 'jawOpenZipper')
    utils.addListKey(dConnectTargetMirrors, 'jawOpenZipper')
    utils.addListKey(dConnectTargetSplitRadien, 'jawOpenZipper')
    utils.addListKey(dConnectTargetSplitBotTops, 'jawOpenZipper')
    utils.addListKey(dConnectTargetInverts, 'jawOpenZipper')
    utils.addListKey(dConnectTargetSplitAlongCurves, 'jawOpenZipper')
    utils.addListKey(dConnectTargetZippers, 'jawOpenZipper')
    utils.addListKey(dConnectTargetLidRanges, 'jawOpenZipper')
    utils.addListKey(dConnectTargetControlRigCommands, 'jawOpenZipper')

    dConnectTargetPoses['jawOpenZipper'].append({'jaw_ctrl.rz':fJawRotationZ})
    dConnectTargetDrivers['jawOpenZipper'].append({})
    dConnectTargetMirrors['jawOpenZipper'].append(False)
    dConnectTargetSplitRadien['jawOpenZipper'].append(1.0)
    dConnectTargetSplitBotTops['jawOpenZipper'].append(False)
    dConnectTargetInverts['jawOpenZipper'].append(0)
    dConnectTargetSplitAlongCurves['jawOpenZipper'].append({})
    dConnectTargetZippers['jawOpenZipper'].append(True)
    dConnectTargetLidRanges['jawOpenZipper'].append([])
    dConnectTargetControlRigCommands['jawOpenZipper'].append(True)

    utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
    utils.data.store('dConnectTargetDrivers', dConnectTargetDrivers)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)
    utils.data.store('dConnectTargetInverts', dConnectTargetInverts)
    utils.data.store('dConnectTargetSplitAlongCurves', dConnectTargetSplitAlongCurves)
    utils.data.store('dConnectTargetZippers', dConnectTargetZippers)
    utils.data.store('dConnectTargetLidRanges', dConnectTargetLidRanges)
    utils.data.store('dConnectTargetControlRigCommands', dConnectTargetControlRigCommands)


    bDeletePrevSetup = True
    def _getZipperComboName(sTargets):
        sTargets = utils.toList(sTargets)
        sAllTargets = sorted(sTargets)
        return '_'.join(sAllTargets + ['zipper'])


    # xMirrorAxis = sMirrorJointAxes[suf] if suf < len(sMirrorJointAxes) else None
    sSuffix = ''
    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sSecondaryModels = utils.data.get('sAllSecondaryModels%s' % sSuffix)

    dTargets = OrderedDict()
    dTargets[_getZipperComboName('jawOpenZipper')] = {'jaw_ctrl.rz':fJawRotationZ}
    dTargets[_getZipperComboName('lowerDown')] = {'lipsBot_l_ctrl.ty':-1.0}
    dTargets[_getZipperComboName('upperUp')] = {'lipsTop_l_ctrl.ty':1.0}
    dTargets[_getZipperComboName('lipStretch')] = {'lipStretch_l_ctrl.ty':1.0}
    dTargets[_getZipperComboName('funnel')] = {'mouth_ctrl.tz':1.0}
    dTargets[_getZipperComboName(['lowerDown', 'upperUp'])] = {'lipsBot_l_ctrl.ty':-1.0, 'lipsTop_l_ctrl.ty':1.0}
    for sTarget, dPoses in list(dTargets.items()):
        dTargets[sTarget] = blendShapesPro._mirrorAttrsDict(dPoses)

    report.report.resetProgress(len(dTargets))

    for sComboT, dPose in list(dTargets.items()):
        report.report.addLogText('combo shape "%s"..' % sComboT, bRefresh=True, bIncrementProgress=True)
        if not cmds.objExists(sComboT):

            sMainTargets = sComboT.split('_')
            bSkip = False
            for sT in sMainTargets:
                if sT not in ['zipper', 'jawOpenZipper'] and not cmds.objExists(sT):
                    report.report.addLogText('missing main target: "%s"' % sT)
                    bSkip = True
                    # break
            if bSkip:
                continue

            dPrev = {}
            for sA,fV in list(dPose.items()):
                dPrev[sA] = cmds.getAttr(sA)
                cmds.setAttr(sA, fV)

            cmds.setAttr('lipsCorner_l%s_ctrl.seal' % sSuffix, 1.0)
            cmds.duplicate(sModel, n=sComboT)
            cmds.setAttr('lipsCorner_l%s_ctrl.seal' % sSuffix, 0.0)

            utils.parentToWorld(sComboT)
            cmds.setAttr('%s.v' % sComboT, False)
            for sA,fV in list(dPrev.items()):
                cmds.setAttr(sA,fV)

        bSuccess, sMessage = blendShapesPro.autoConnectComboTarget(sComboT, sModel, sSecondaryModels, bLegacyIgnoreEyeLookHoriz=False)

        report.report.addLogText(sMessage)
        if not bSuccess:
            bReturn = False

    if bDeletePrevSetup:
        for sMesh in [sModel] + sSecondaryModels:
            sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh
            if cmds.objExists(sSkinCluster):
                cmds.delete(sSkinCluster)

    cmds.setAttr('lipsCorner_l_ctrl.seal', 0.0)

    if bDeletePrevSetup:
        for sAttr in ['lipsCorner_l_ctrl.seal', 'lipsCorner_l_ctrl.sealFade', 'lipsCorner_r_ctrl.seal', 'lipsCorner_r_ctrl.sealFade']:
            cmds.deleteAttr(sAttr)
        cmds.delete('grp_zipperOrigin', 'grp_zipperWorld')

        cmds.renameAttr('lipsCorner_l_ctrl.sealB', 'seal')
        cmds.renameAttr('lipsCorner_l_ctrl.sealFadeB', 'sealFade')
        cmds.renameAttr('lipsCorner_r_ctrl.sealB', 'seal')
        cmds.renameAttr('lipsCorner_r_ctrl.sealFadeB', 'sealFade')



    return bReturn


dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls6.exportSliderBps
@builderTools.addToBuild(iOrder=50.01, dButtons=dButtons, bDisableByDefault=True)
def eyeSpecular(ddMeshes={'eyesLookAt_l_ctrl':{'A':[], 'B':[]}}, bMirrorToRight=True, bFirstReversesOthers=False):
    for sCtrl, dData in list(ddMeshes.items()):
        sFirstHoriz = [None, None]
        sFirstVert = [None, None]
        sReverseOthersAttr = [None, None]

        for l, sLetter in enumerate(sorted(list(dData.keys()))):
            sMeshes = dData[sLetter]
            if not sMeshes:
                continue

            sInputCtrlSide = utils.getSide(sCtrl)
            if sInputCtrlSide == 'm':
                sSides = ['m']
                bMirrors = [False]
            elif sInputCtrlSide == 'l':
                if bMirrorToRight:
                    sSides = ['l','r']
                    bMirrors = [False, True]
                else:
                    sSides = ['l']
                    bMirrors = [False]
            elif sInputCtrlSide == 'r':
                sSides = ['r']
                bMirrors = [False]

            for s,sSide in enumerate(sSides):

                fSideMultipl = -1.0 if sSide == 'r' else 1.0

                if bMirrors[s]:
                    sMeshesSide = utils.mirrorList(list(sMeshes))
                    sCtrlSide = utils.getMirrorName(sCtrl)
                else:
                    sMeshesSide = list(sMeshes)
                    sCtrlSide = sCtrl

                sEyeJoint = cmds.getAttr('%s.sEyeJoint' % sCtrlSide)
                sTransformJoint = cmds.listRelatives(sEyeJoint, p=True)[0]

                sSpecParent = 'jnt_%s_specJointParent' % sSide
                if not cmds.objExists(sSpecParent):
                    sSpecParent = xforms.createJoint(sSpecParent, sParent=sTransformJoint)

                    sEyeFollow = utils.addAttr(sCtrlSide, ln='specFollow', minValue=0, maxValue=1, k=True)
                    sSpecTwist = utils.addAttr(sCtrlSide, ln='specTwist', k=True)
                    if sSide == 'r':
                        sSpecTwist = nodes.createMultiplyNode(sSpecTwist, -1)
                    # cmds.connectAttr(sSpecTwist, '%s.rx' % sSpecParent)
                    sBlendMatrix = nodes.createBlendMatrixNode([cmds.getAttr('%s.matrix' % sEyeJoint), '%s.matrix' % sEyeJoint],
                                                               [nodes.createReverseNode(sEyeFollow), sEyeFollow])
                    sParentMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xRotate=[sSpecTwist, 0,0]),
                                                                   sBlendMatrix])
                    nodes.createDecomposeMatrix(sParentMatrix, sTargetRot='%s.r' % sSpecParent)



                    if bFirstReversesOthers:
                        sReverseOthersAttr[s] = utils.addAttr(sCtrlSide, ln='firstReversesOthers', min=0, max=1, dv=1, k=True)

                aaPoints = [patch.patchFromName(sM).getPoints() for sM in sMeshesSide]
                aPoints = np.concatenate(aaPoints)
                aMeshCenter = np.mean(aPoints, axis=0)

                sBaseJoint = xforms.createJoint(sEyeJoint.replace('Main', 'Spec%s' % sLetter), sMatch=sEyeJoint, sParent=sSpecParent)
                sJoint = sEyeJoint.replace('Main', 'SpecEnd%s' % sLetter)
                if not cmds.objExists(sJoint):
                    xforms.createJoint(sJoint, xPos = aMeshCenter)
                else:
                    cmds.setAttr('%s.t' % sJoint, *list(aMeshCenter))

                cmds.delete(cmds.aimConstraint(sJoint, sBaseJoint, wut='objectrotation', wuo=sTransformJoint, aim=[fSideMultipl,0,0]))
                cmds.makeIdentity(sBaseJoint, r=True, apply=True)
                cmds.parent(sJoint, sBaseJoint)
                cmds.setAttr('%s.jo' % sJoint, 0,0,0)
                utils.matchJointRadius([sBaseJoint, sJoint], sEyeJoint, 0.75)
                deformers.resetJointReferences(sJoint)

                for sM in sMeshesSide:
                    if not deformers.listAllDeformers(sM, sFilterTypes=['skinCluster']):
                        cmds.skinCluster(sM, sJoint, tsb=True)

                sSpecVert = utils.addAttr(sCtrlSide, ln='specVert%s' % sLetter, k=True)
                if bFirstReversesOthers:
                    if l == 0:
                        sFirstVert[s] = sSpecVert
                    else:
                        sSpecVert = nodes.createAdditionNode([sSpecVert, nodes.createMultiplyNode(sFirstVert[s], sReverseOthersAttr[s])],
                                                             sOperation='minus', sName='addFirst')
                cmds.connectAttr(sSpecVert, '%s.rz' % sBaseJoint)

                sSpecHoriz = utils.addAttr(sCtrlSide, ln='specHoriz%s' % sLetter, k=True)
                if sSide == 'r':
                    sSpecHoriz = nodes.createMultiplyNode(sSpecHoriz, -1)
                if bFirstReversesOthers:
                    if l == 0:
                        sFirstHoriz[s] = sSpecHoriz
                    else:
                        sSpecHoriz = nodes.createAdditionNode([sSpecHoriz, nodes.createMultiplyNode(sFirstHoriz[s], sReverseOthersAttr[s])],
                                                              sOperation='minus', sName='addFirst')
                cmds.connectAttr(sSpecHoriz, '%s.ry' % sBaseJoint)

                sLiftAttr = utils.addAttr(sCtrlSide, ln='specLift%s' % sLetter, k=True)
                if sSide == 'r':
                    sLiftAttr = nodes.createMultiplyNode(sLiftAttr, -1)
                nodes.createAdditionNode([cmds.getAttr('%s.tx' % sJoint), sLiftAttr], sTarget='%s.tx' % sJoint)

                sScaleAttr = utils.addAttr(sCtrlSide, ln='specScale%s' % sLetter, dv=1, k=True)
                cmds.connectAttr(sScaleAttr, '%s.sx' % sJoint)
                cmds.connectAttr(sScaleAttr, '%s.sy' % sJoint)
                cmds.connectAttr(sScaleAttr, '%s.sz' % sJoint)



def createOrFixFaceZero():
    sZero = 'jnt_m_faceZero'
    if not cmds.objExists(sZero):
        cmds.createNode('joint', n=sZero, p='modules')
    else:
        if not cmds.listRelatives(sZero, p=True):
            cmds.parent(sZero, 'modules')


dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls6.exportSliderBps
@builderTools.addToBuild(iOrder=24, dButtons=dButtons, bCanGetDuplicated=True)
def BASELidCtrls(sParentJoint='jnt_m_headMain', sLookUpStrengthes=[1,1], sLookDownStrengthes=[1,1], bPolyCtrls=False, fInnerBlink=None, sSuffix=''):
    '''
    This creates the ctrls "blink_l_ctrl", "lidBot_l_ctrl" and "lidTop_l_ctrl"
    
    fInnerBlink is for creatures that have a membrane blink, such as birds. If it's None, it won't create a joint, but if it's a float vector such as [0,100,0], it'll create a joint
    That float vector is the default of the blink rotation.,
    IMPORTANT: this float vector will likely get overwritten in the importBlendShapeFile() function!
    '''

    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if s == 1 else 1.0
        sEyeJoints = ['jnt_%s_eye%sMain' % (sSide, sSuffix), 'jnt_%s_eye%sIris' % (sSide, sSuffix)]
        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        # sParent = xforms.createTransform('grp_%s_eyeLid%sParent' % (sSide, sSuffix), sParent='modules',
        #                                  sMatch=sEyeJoints[0])
        # sOutwardsRotParent = cmds.createNode('transform', n='grp_%s_eyeLid%sOutwardsRotate' % (sSide, sSuffix),
        #                                      p=sParent)
        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1] - aJointPositions[0])

        if sSide == 'l':
            aBlinkPos = aJointPositions[1] + np.array([fRadius * fSideMultipl, 0, 0])

            cBlinks = ctrls6.createSliderCtrl('blink%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                              fBpPos=aBlinkPos, fRangeY=[-1, 0.5],
                                              sAttach=sParentJoint, fScale=fSliderScale, bPoly=bPolyCtrls,
                                              bExportMirrorBps=True)

            cBotLids = ctrls6.createSliderCtrl('lidBot%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                                 fRangeY=[-1, 1.0], sAttach=sParentJoint,
                                                 fScale=fSliderScale * 0.5,
                                                 fBpPos=aBlinkPos + np.array(
                                                     [fSliderScale * fSideMultipl, -1 * fSliderScale, 0]),
                                                 bPoly=bPolyCtrls, bExportMirrorBps=True)
            cTopLids = ctrls6.createSliderCtrl('lidTop%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                                 fRangeY=[-1, 1.0], sAttach=sParentJoint,
                                                 fScale=fSliderScale * 0.5,
                                                 fBpPos=aBlinkPos + np.array(
                                                     [fSliderScale * fSideMultipl, 1 * fSliderScale, 0]),
                                                 bPoly=bPolyCtrls, bExportMirrorBps=True)

            ccExtraBlinks = [cBotLids, cTopLids]

        
        for cC in cBlinks + cBotLids + cTopLids:
            cC.createExtraMoveTransformAndTag(['skinCluster__*face*__TWEAKER'])


        cAim = ctrls6.ctrlFromName('eyesLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)
        if not cAim:
            cAim = ctrls6.ctrlFromName('eyeLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)

        # drivers for shapes:
        for p,sPart in enumerate(['bot','top']):
            sBlendExtraDownShape = nodes.createRangeNode('%s.ty' % ccExtraBlinks[p][s].sCtrl, 0, -1.0, 0, 1)
            sBlendExtraUpShape = nodes.createRangeNode('%s.ty' % ccExtraBlinks[p][s].sCtrl, 0, 1.0, 0, 1)
            sBlendsFollowDownShape = nodes.createRangeNode('%s.lookVert' % cAim.sPasser, 0, -5.0, 0, 1)
            sBlendsFollowUpShape = nodes.createRangeNode('%s.lookVert' % cAim.sPasser, 0, 5, 0, 1)

            sBlendsFollowDownShape = nodes.createMultiplyNode(sBlendsFollowDownShape, sLookDownStrengthes[p])
            sBlendsFollowUpShape = nodes.createMultiplyNode(sBlendsFollowUpShape, sLookUpStrengthes[p])

            sShapeDriverDown = utils.addAttr(ccExtraBlinks[p][s].sPasser, ln='shapeDriverDown', k=True)
            sShapeDriverUp = utils.addAttr(ccExtraBlinks[p][s].sPasser, ln='shapeDriverUp', k=True)
            sAdditions = nodes.createVectorAdditionNode([[sBlendExtraDownShape, sBlendExtraUpShape, 0], [sBlendsFollowDownShape, sBlendsFollowUpShape, 0]])
            cmds.connectAttr('%sx' % sAdditions, sShapeDriverDown)
            cmds.connectAttr('%sy' % sAdditions, sShapeDriverUp)



        sBlinkLineAttr = utils.addAttr(cBlinks[s].sCtrl, ln='blinkLine', min=0.0, max=1.0, dv=0.5, k=True)
        for p,sPart in enumerate(['bot','top']):

            sBlendAttr = utils.addAttr(cBlinks[s].sPasser, ln='blendCurve%s' % utils.getFirstLetterUpperCase(sPart), k=True)

            if sPart == 'bot':
                sLookVert = nodes.createAdditionNode(['%s.shapeDriverUp' % ccExtraBlinks[0][s].sPasser, '%s.shapeDriverDown' % ccExtraBlinks[0][s].sPasser], sOperation='minus')

                nodes.createAdditionNode([nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1, sBlinkLineAttr]),
                                          sLookVert], sTarget=sBlendAttr)
            else:
                sLookVert = nodes.createAdditionNode(['%s.shapeDriverUp' % ccExtraBlinks[1][s].sPasser, '%s.shapeDriverDown' % ccExtraBlinks[1][s].sPasser], sOperation='minus')

                sMainBlink = nodes.createConditionNode('%s.ty' % cBlinks[s].sCtrl, '<', 0,
                                                       nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1, nodes.createReverseNode(sBlinkLineAttr)]),
                                                       nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1.75])) # -1.75 means that the main blink up will be 1.75 of the extra up shape
                nodes.createAdditionNode([sMainBlink,
                                          nodes.createMultiplyNode(sLookVert, -1)],
                                          sTarget=sBlendAttr)

    if fInnerBlink != None:
        for s, sSide in enumerate(['l', 'r']):
            sEyeJoint = 'jnt_%s_eyeMain' % sSide
            cBlinks[s] = ctrls6.ctrlFromName('blink%s_ctrl' % utils.sSides3[s])
            sLidJoint = cmds.duplicate(sEyeJoint, n='jnt_%s_innerEyeLid' % sSide, po=True)[0]
            cmds.parent(sLidJoint, sEyeJoint)
            sCloseAttr = utils.addAttr(cBlinks[s].sCtrl, ln='innerBlink', min=0, max=1, k=True)
            
            sInnerBlinkRotate = utils.addAttr(cBlinks[s].sPasser, ln='innerBlinkRotate', at='double3', k=True)
            for sA,fV in zip(['X','Y','Z'], fInnerBlink):
                cmds.setAttr('%s%s' % (sInnerBlinkRotate,sA),fV)
                
            nodes.createRangeNode(sCloseAttr, 0, 1, [0,0,0], sInnerBlinkRotate, bOutRangeIsVector=True, sTarget='%s.r' % sLidJoint)


dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def fillBlinkValues(fExtraBlinkCtrlStrengthes, _uiArgs=None):
    sCtrl = 'blink_l_ctrl'
    sPasser = ctrls6.ctrlFromName(sCtrl).sPasser
    # sPasser = 'grp_l_blinkPasser'
    print('sPasser: ',sPasser)
    if not cmds.objExists(sPasser):
        if not cmds.objExists(sPasser):
            raise Exception('eye blink passer not found')

    _uiArgs['fBlinkValues'].setText(str([cmds.getAttr('%s.botBlink' % sPasser), cmds.getAttr('%s.topBlink' % sPasser)]))
    _uiArgs['fBlinkTwistValues'].setText(str([cmds.getAttr('%s.botBlinkTwist' % sPasser), cmds.getAttr('%s.topBlinkTwist' % sPasser)]))
    _uiArgs['fWideValues'].setText(str([cmds.getAttr('%s.botWide' % sPasser), cmds.getAttr('%s.topWide' % sPasser)]))
    _uiArgs['fFollowUps'].setText(str([cmds.getAttr('%s.followBotUp' % sPasser), cmds.getAttr('%s.followTopUp' % sPasser)]))
    _uiArgs['fFollowDowns'].setText(str([cmds.getAttr('%s.followBotDown' % sPasser), cmds.getAttr('%s.followTopDown' % sPasser)]))


    for i, sCtrl in enumerate(['lidBot_l_ctrl', 'lidTop_l_ctrl']):
        if cmds.objExists(sCtrl):
            cCtrl = ctrls6.ctrlFromName(sCtrl)
            sPasser = cCtrl.sPasser
            fExtraBlinkCtrlStrengthes[i] = round(cmds.getAttr('%s.fExtraBlinkCtrlStrength' % sPasser), 3)
        _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(fExtraBlinkCtrlStrengthes))

    # _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(cmds.getAttr('%s.fExtraBlinkCtrlStrengthes' % sPasser)))



kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill blink values'] = fillBlinkValues


def proceduralBind_lidSplineUndo(bSeparateSkinCluster):
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sAllJoints = cmds.ls('jnt_?_???SkinLidSpline_???', et='joint')
    weights.moveSkinClusterWeights(sMesh, xJoints={sJ:'jnt_m_headMain' for sJ in sAllJoints})



def proceduralBind_lidSpline(iBindRows, bSeparateSkinCluster):

    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        if bSeparateSkinCluster:
            sSkinCluster = 'skinCluster__%s__LIDSPLINE' % (sMesh)
            sSkinClusterTemp = 'TEMP__skinCluster__%s__LIDSPLINE' % (sMesh)
            if cmds.objExists(sSkinClusterTemp):
                cmds.delete(sSkinClusterTemp)
            deformers.skinMesh(sMesh, ['jnt_m_faceZero'], sName=sSkinClusterTemp, bAlwaysAddDefaultWeights=True)
        else:
            sSkinCluster = 'skinCluster__%s' % (sMesh)
            sSkinClusterTemp = 'skinCluster__%s' % (sMesh)


        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()





        # fJointWeightings = np.interp(np.arange(sJoints), iIndices, [1, 0.5, ]
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()

        utils.reload2(weights)
        sAllJoints = cmds.ls('jnt_l_???SkinLidSpline_???', et='joint')
        weights.bindToClosestVertexAndExpand([pMesh], sJoints=sAllJoints,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iBindRows[0], iExpandedFadeOutLoops=iBindRows[1],
                                             sChooseSkinCluster=sSkinClusterTemp)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)
        if bSeparateSkinCluster:

            if cmds.objExists(sSkinCluster):
                pTransferTo = pMesh
                for pSel in pSelection:
                    if pSel.getName() == pMesh.getName():
                        pTransferTo = pSel
                        break

                weights.transferSkinCluster([pTransferTo], sFrom=sSkinClusterTemp, sChooseSkinCluster=sSkinCluster, iMode=weights.TransferMode.vertexIndex)
                cmds.delete(sSkinClusterTemp)
            else:
                cmds.rename(sSkinClusterTemp, sSkinCluster)


            cmds.setAttr('%s.skinningMethod' % sSkinCluster, 1)

            deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)


kEyeSplinesPostBpGroupName = '_grp_m_eyeSplinesBp'
kEyeSplinesPostBpFileName = 'faceBlueprintsEyeSplines.ma'




def _generateLidCorrective(sModel, sParts):
    print ('sModel: ', sModel)
    if sModel:
        sModel = utils.toList(sModel)[0]
    else:
        raise Exception('no model given')

    sSecondaryMeshes = [sM for sM in cmds.ls(sl=True) if sM != sModel]

    cBlink = ctrls6.ctrlFromName('blink_l_ctrl')
    iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % cBlink.sPasser) * 100),
                -int(cmds.getAttr('%s.blendCurveTop' % cBlink.sPasser) * 100)]
    sNewMeshes = []

    sStringSplits = ['','']
    for p,sPart in enumerate(['bot','top']):
        if sPart.upper() in sParts.upper():
            iValue = iBotTops[p]
            sStringSplits[p] = '%03d' % iValue if iValue > 0 else 'n%03d' % -iValue
    sString = kSplineLideCorrectiveSep.join(sStringSplits)

    for i, sM in enumerate([sModel] + sSecondaryMeshes):
        sNewMesh = '%s%s%s' % (kSplineLidCorrectivePrefix, kSplineLideCorrectiveSep, sString)

        if i > 0:
            sNewMesh = '%s__%s' % (sM, sNewMesh)

        if not cmds.objExists(sNewMesh):
            cmds.duplicate(sM, n=sNewMesh)
            print ('sNewMesh: ', sNewMesh)
            utils.parentToWorld(sNewMesh)
        sNewMeshes.append(sNewMesh)

    cmds.select(sNewMeshes)


def generateLidCorrectiveBot(sModel):
    _generateLidCorrective(sModel, 'bot')

def generateLidCorrectiveBotTop(sModel):
    _generateLidCorrective(sModel, 'botTop')

def generateLidCorrectiveTop(sModel):
    _generateLidCorrective(sModel, 'top')


#EXCLUDE START LIDSPLINES

dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_lidSplines', kEyeSplinesPostBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {
    '?': [['Select vertices and click button.', 'eyelidVertices.jpg'],
          ['Locators indicate separation points between bottom and top eyelid. ' \
           'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['== BIND =='] = {'bind to joints on selected Mesh': proceduralBind_lidSpline, 'transfer back to jnt_m_headMain on selected Mesh':proceduralBind_lidSplineUndo}
dButtons['- Export Eye Splines BPs -'] = lambda: exportBps(kEyeSplinesPostBpFileName, kEyeSplinesPostBpGroupName)

dButtons['Generate Lid Corrective from selected'] = {'botTop':generateLidCorrectiveBotTop,
                                                     'bot':generateLidCorrectiveBot,
                                                     'top': generateLidCorrectiveTop}


@builderTools.addToBuild(iOrder=24.4, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def splineLidSetupSQUASHED(sModel='', sLeftMeshes=[], sRightMeshes=[], bLattice=True, fLivePole=0.5, fDefaultBlinkLine=0.5, fDefaultOverShoot=1.025, fMidPercs=[0.25, 0.5, 0.75], fWidenFactors=[0.5,0.5],
                                 bPolyCtrls=False, sParentJoint='jnt_m_headMain', iBindRows=[2,3], bSeparateSkinCluster=False):
    '''
    fLivePole: if 1.0, the joints orientations are aligning to the curve
    '''
    if not len(sLeftMeshes) and not len(sRightMeshes):
        raise Exception('need to specify sLeftMeshes and sRightMeshes')

    ssMeshes = [sLeftMeshes, sRightMeshes]
    _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bLattice)
    splineLidSetup(sModel=sModel, fMidPercs=fMidPercs, bPolyCtrls=bPolyCtrls, fLivePole=fLivePole, fDefaultBlinkLine=fDefaultBlinkLine, bSeparateSkinCluster=bSeparateSkinCluster,
                         fDefaultOverShoot=fDefaultOverShoot, sParentJoint=sParentJoint, fWidenFactors=fWidenFactors, _bSquashed=True)


# to do: ctrl orientations are not following latticed movement
@builderTools.addToBuild(iOrder=24.3, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def splineLidSetup(fMidPercs=[0.25, 0.5, 0.75], fLivePole=0.5, fDefaultBlinkLine=0.5,
                         sParentJoint='jnt_m_headMain', iBindRows=[2,3], fWidenFactors=[0.5,0.5], fDefaultOverShoot=1.025, bSeparateSkinCluster=False, bLidsCanPushOut=True, iSkipSplineJoints=0, _bSquashed=False):
    '''
    fLivePole: if 1.0, the joints orientations are aligning to the curve
    
    Adjusting wide shapes: on running the function, he creates curve_?_*LidSplineWideTarget* curves inside the blueprint group. \
    Simply adjust those and export blueprints. If right side is not there, it'll get mirrored automatically
    '''

    # sModel = utils.objFromArg(sModel)

    sGrp = cmds.createNode('transform', n='grp_eyeSplines', p='modules')
    createOrFixFaceZero()

    # if _bSquashed:
    #     sNurbsSpheres = ['nurbs_l_eyeRigSphere', 'nurbs_r_eyeRigSphere']

    for sCrv in ['bpCurve_l_lidSplines', 'bpCurve_r_lidSplines']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_lidSplines', 'locB_l_lidSplines', 'locA_r_lidSplines', 'locB_r_lidSplines']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(
        curves.separateCurveUsingSeparationLocs('bpCurve_l_lidSplines', 'locA_l_lidSplines', 'locB_l_lidSplines', 'bpCurve_l_botLidSpline',
                                                'bpCurve_l_topLidSpline'))
    ssCurves.append(
        curves.separateCurveUsingSeparationLocs('bpCurve_r_lidSplines', 'locA_r_lidSplines', 'locB_r_lidSplines', 'bpCurve_r_botLidSpline',
                                                'bpCurve_r_topLidSpline'))

    # fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccEyeCtrls = [[], []]
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]

    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    # sssCtrlJoints = [[], []], [[], []]
    # sNurbsSpheres = ['nurbs_l_eyeRigSphere', 'nurbs_r_eyeRigSphere']
    sSuffix = ''

    for s, sSide in enumerate(['l', 'r']):

        sParent = xforms.createJoint('jnt_%s_eyeLidSplineParent' % sSide, sParent=sParentJoint, sMatch=ssEyeJoints[s][0], fSize=0.5  )
        utils.matchJointRadius(sParent, sEyeJoints[s], 1.15)

        cmds.setAttr('%s.segmentScaleCompensate' % sParent, False)

        fSideMultipl = -1.0 if sSide == 'r' else 1.0


        aJointPositions = xforms.getPositionArray(ssEyeJoints[s])
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        # cEyeCtrl = ctrls6.ctrlFromName('eye%s_ctrl' % utils.sSides3[s])
        cEyeTransform = ctrls6.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])
        cBlink = ctrls6.ctrlFromName('blink%s%s_ctrl' % (sSuffix, utils.sSides3[s]))
        cExtraBlinks = [ctrls6.ctrlFromName('lidBot%s%s_ctrl' % (sSuffix, utils.sSides3[s])),
                        ctrls6.ctrlFromName('lidTop%s%s_ctrl' % (sSuffix, utils.sSides3[s]))]
        cAim = ctrls6.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s])
        sEyeTransformJoint = 'jnt_%s_eyeTransform' % sSide

        sBlinkLineAttr = '%s.blinkLine' % cBlink.sCtrl
        cmds.setAttr(sBlinkLineAttr, fDefaultBlinkLine)

        if bSeparateSkinCluster:
            sEyeTransformJointLive = cmds.duplicate(sEyeTransformJoint, n='jnt_%s_eyeTransformLive' % sSide, po=True)[0]
            cmds.parent(sEyeTransformJointLive, sEyeTransformJoint)
            fLocalEyeTransform = nodes.createMultMatrixNode( ['%s.worldMatrix' % sEyeTransformJointLive, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
            sEyeTransformInverseRef = nodes.createInverseMatrix(nodes.createMultMatrixNode([fLocalEyeTransform, '%s.worldMatrix' % sParentJoint]))
            utils.addStringAttr(sEyeTransformJointLive, deformers.kPostRefJointAttr, sEyeTransformInverseRef)

        sTransformJoint = 'jnt_%s_eyeTransform' % sSide
        sTransformJointRotMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sTransformJoint)
        sTransformJointRotInverseMatrix = nodes.createInverseMatrix(sTransformJointRotMatrix)


        ffBlinkPoses = [('%s.ty' % cExtraBlinks[0].sCtrl, 1.0), ('%s.ty' % cExtraBlinks[1].sCtrl, -1.0)]
        sStartCurves = []
        if _bSquashed:
            ssLattices = utils.data.get('ssEyeLattices')
            for p,sPart in enumerate(['bot','top']):
                sTempDupl = cmds.duplicate(ssCurves[s][p], n='tempDuplCurve')[0]
                sTempLattice = deformers.applyLattice(ssLattices[s], ssCurves[s][p])
                cmds.setAttr('%s.outsideLattice' % sTempLattice, 1)
                sInvert = geometry.invertShapeDeformers(sTempDupl, ssCurves[s][p], sInvertName='curve_%s_%sInverted' % (sSide,sPart))
                sStartCurves.append(sInvert)
                deformers.disconnectLattice(sTempLattice)
                cmds.delete(sTempLattice)
                cmds.delete(sTempDupl)
            cmds.parent(sStartCurves, sGrp)
        else:
            sStartCurves = ssCurves[s]

        aaPoints = [patch.patchFromName(sStartCurves[0]).getPoints(),
                    patch.patchFromName(sStartCurves[1]).getPoints()]
        aNonSkippedIndices = [utils.getFilteredFromAvoidIndices(len(aaPoints[0]), iSkipSplineJoints),
                              utils.getFilteredFromAvoidIndices(len(aaPoints[1]), iSkipSplineJoints)]
        aaPoints = [aaPoints[0][aNonSkippedIndices[0]], aaPoints[1][aNonSkippedIndices[1]]]

        aaLocalPoints = [np.dot(utils.makePoint4Array(aaPoints[0]), np.linalg.inv(utils.getNumpyMatrixFromTransform(cEyeTransform.sOut)))[:,0:3],
                         np.dot(utils.makePoint4Array(aaPoints[1]), np.linalg.inv(utils.getNumpyMatrixFromTransform(cEyeTransform.sOut)))[:, 0:3]]
        iBiggerCvCount = max(len(aaPoints[0]), len(aaPoints[1]))


        sTransformGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransform' % sSide, p=sGrp)
        sOriginTransformGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransformOrigin' % sSide, p=sGrp)
        sCtrlGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesCtrls' % sSide, p='ctrls')
        constraints.matrixParentConstraint(sEyeTransformJoint, sTransformGrp)
        constraints.matrixParentConstraint(sEyeTransformJoint, sOriginTransformGrp) #, mo=True)
        constraints.matrixParentConstraint(cEyeTransform.sOut, sCtrlGrp)



        sTransformRefGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransformRef' % sSide, p=sGrp)
        cmds.xform(sTransformRefGrp, m=cmds.xform(sTransformGrp, q=True, m=True))

        sTempDuplCurves = [cmds.duplicate(sStartCurves[0], n='curve_%s_tempDuplBot' % sSide)[0],
                          cmds.duplicate(sStartCurves[1], n='curve_%s_tempDuplBot' % sSide)[0]]

        cmds.parent(sTempDuplCurves, sOriginTransformGrp)

        sMaxStaticCurves = [curves.rebuildWithCvCount(sTempDuplCurves[0], iCvCount=iBiggerCvCount, iDegree=2, sNewName='curve_%s_lidSplineBot_static' % sSide),
                            curves.rebuildWithCvCount(sTempDuplCurves[1], iCvCount=iBiggerCvCount, iDegree=2, sNewName='curve_%s_lidSplineTop_static' % sSide)]
        sMaxBlendingCurves = [cmds.duplicate(sMaxStaticCurves[0], n='curve_%s_lidSplineMaxBlendingBot' % sSide)[0],
                              cmds.duplicate(sMaxStaticCurves[1], n='curve_%s_lidSplineMaxBlendingTop' % sSide)[0]]
        aaMaxPoints = [patch.patchFromName(sMaxStaticCurves[0]).getPoints(),
                       patch.patchFromName(sMaxStaticCurves[1]).getPoints()]

        sBlendingCurves = [cmds.curve(p=aaPoints[0], d=2, n='curve_%s_lidSplineBlendingBot' % sSide),
                            cmds.curve(p=aaPoints[1], d=2, n='curve_%s_lidSplineBlendingTop' % sSide)]
        curves.fixShapeName(sBlendingCurves)
        cmds.parent(sBlendingCurves, sGrp)
        sCtrlBlendingCurves = [cmds.duplicate(sBlendingCurves[0], n='curve_%s_lidSplineBlendingCtrlsBot' % sSide)[0],
                                cmds.duplicate(sBlendingCurves[1], n='curve_%s_lidSplineBlendingCtrlsTop' % sSide)[0]]


        sBlink = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0,-1,0,1)
        # sLookVert = '%s.lookVert' % cAim.sPasser
        # sBlendingTargetAttrs = []


        ssWideTargetCurves = [None, None]
        for p,sPart in enumerate(['bot','top']):
            ssWideTargetCurves[p] = ['curve_%s_%sLidSplineWideTarget' % (sSide,sPart), 'curve_%s_%sLidSplineWideTargetOther' % (sSide,sPart)]
            for pp,sCurve in enumerate(ssWideTargetCurves[p]):
                if not cmds.objExists(sCurve):
                    sMirrorCurve = utils.getMirrorName(sCurve)
                    if cmds.objExists(sMirrorCurve):
                        aPoints = patch.patchFromName(sMirrorCurve).getPoints()
                        aPoints[:, 0] *= -1.0
                    else:
                        if pp == 0:
                            aPoints = aaMaxPoints[p] - (aaMaxPoints[1-p]-aaMaxPoints[p]) * fWidenFactors[p]
                        else:
                            aPoints = aaMaxPoints[1-p]
                    cmds.curve(p=aPoints, d=1, n=sCurve)

                utils.parentTo(sCurve, kEyeSplinesPostBpGroupName)

        sOverShootAttr = utils.addAttr(cBlink.sPasser, ln='overShootOnBlinkFactor', dv=fDefaultOverShoot, k=True)

        sBlendingTargetAttrs = ['%s.blendCurveBot' % cBlink.sPasser, '%s.blendCurveTop' % cBlink.sPasser]

        for p,sPart in enumerate(['bot','top']):

            sTargetAttrs = blendShapesPro.addTargets(sMaxBlendingCurves[p], [sMaxStaticCurves[1-p], ssWideTargetCurves[p][0]])
            sOtherTargetAttr = blendShapesPro.addTargets(sMaxBlendingCurves[1-p], [ssWideTargetCurves[p][1]])[0]

            nodes.createConditionNode(sBlendingTargetAttrs[p], '>=', 0, nodes.createMultiplyNode(sBlendingTargetAttrs[p], sOverShootAttr), 0, sTarget=sTargetAttrs[0])
            nodes.createConditionNode(sBlendingTargetAttrs[p], '<', 0, nodes.createMultiplyNode(sBlendingTargetAttrs[p], -1), 0, sTarget=[sTargetAttrs[1], sOtherTargetAttr])


        ffCtrlParams = [curves.getParamsFromPercs(sBlendingCurves[0], fMidPercs),
                        curves.getParamsFromPercs(sBlendingCurves[1], fMidPercs)]
        # ctrls - bottom tops
        fCtrlSize = len(ssCurves[0][p]) * 0.02
        for p, sPart in enumerate(['bot', 'top']):
            fCtrlParams = ffCtrlParams[p]
            # aTangents = curves.getTangentsFromParams(sBlendingCurves[p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(sBlendingCurves[p], fCtrlParams)
            for c, fP in enumerate(fCtrlParams):
                if _bSquashed:
                    cC = ctrls6.create(sName='eyeSplineAttach%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide, iIndex=c,
                                       sParent=sTransformGrp,
                                       fSliderScale=fSliderScale, bIsNoCtrl=True,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])
                    cC.cC = ctrls6.create(sName='eyeSpline%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide, iIndex=c,
                                       sParent=sCtrlGrp, iColorIndex=2,
                                       fSliderScale=fSliderScale,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])

                    cC.cAnim = cC.cC
                    for sA in ['t','r','s']:
                        cmds.connectAttr('%s.%s' % (cC.cC.sCtrl,sA), '%s.%s' % (cC.sCtrl,sA))
                else:
                    cC = ctrls6.create(sName='eyeSpline%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide, iIndex=c,
                                       sParent=sCtrlGrp, iColorIndex=2,
                                       fSliderScale=fSliderScale,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])
                    cC.createExtraMoveTransformAndTag(ctrls6.kDefaultFaceAttachDeformers[2:])
                    cC.cAnim = cC

                cmds.connectAttr(sCtrlVis, '%s.v' % cC.cAnim.sPasser)

                cC.sJoint = cmds.createNode('joint', n='jnt_%s_%sCtrl_%03d' % (sSide, sPart, c), p=cC.sPasser)
                constraints.matrixParentConstraint(cC.sOut, cC.sJoint, sJumpOverTransforms=[cC.getOffsetByName('extramove'), cC.sPasser])

                utils.matchJointRadius(cC.sJoint, sEyeJoints[s], 0.5)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                cccBotTopCtrls[s][p].append(cC)
                ccEyeCtrls[s].append(cC)

        # ctrls - corners
        fCtrlParams = curves.getParamsFromPercs(sStartCurves[0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(sStartCurves[0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, ['cornerIn', 'cornerOut']):
            sName = 'eyeSpline%s' % (utils.getFirstLetterUpperCase(sN))

            if _bSquashed:
                cC = ctrls6.create(sName='%sAttach' % sName, sSide=sSide, sParent=sTransformGrp,
                                   sMatch='jnt_%s_eyeMain' % sSide, bIsNoCtrl=True,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cC = ctrls6.create(sName=sName, sSide=sSide, sParent=sCtrlGrp, iColorIndex=2,
                                   sMatch='jnt_%s_eyeMain' % sSide,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cAnim = cC.cC

                for sA in ['t', 'r', 's']:
                    cmds.connectAttr('%s.%s' % (cC.cC.sCtrl, sA), '%s.%s' % (cC.sCtrl, sA))

            else:
                cC = ctrls6.create(sName=sName, sSide=sSide, sParent=sCtrlGrp, iColorIndex=2,
                                   sMatch='jnt_%s_eyeMain' % sSide,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.createExtraMoveTransformAndTag(ctrls6.kDefaultFaceAttachDeformers[2:])
                cC.cAnim = cC


            if c == 0:
                aPoints = xforms.getPositionArray(
                    [cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0] + aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray(
                    [cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0] + aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1

            xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -fSideMultipl],
                                     fUpVector=[fSideMultipl, 0, 0])
            if _bSquashed:
                cmds.delete(cmds.parentConstraint(cC.sPasser, cC.cC.sPasser))
            cC.sJoint = cmds.createNode('joint', n='jnt_%s_%sCtrlCorner_%03d' % (sSide, sPart, c), p=cC.sPasser)
            constraints.matrixParentConstraint(cC.sOut, cC.sJoint, sJumpOverTransforms=[cC.getOffsetByName('extramove'), cC.sPasser])
            utils.matchJointRadius(cC.sJoint, sEyeJoints[s], 0.5)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
            utils.addStringAttr(cC.sJoint, deformers.kPostRefJointAttr, cC.sSlider)

            ccCornerCtrls[s].append(cC)
            ccEyeCtrls[s].append(cC)



        for cC in ccCornerCtrls[s] + utils.flattenedList(cccBotTopCtrls[s]):
            # utils.addStringAttr(cC.cAnim.appendOffsetGroup('blendshape', bBelowPasser=True, bMatchParentTransform=True),
            #                     'attachToLidBlendShapes', sModel)
            utils.addStringAttr(cC.sJoint, deformers.kPostRefJointAttr, cC.sPasser)




        # push out sJoints, and deform sBlendingCurves/sCtrlBlendingCurves. To do: calculate in transformGrp's space, so the joint gets rotation (for the offset between joint and cvs)
        for p,sPart in enumerate(['bot','top']):
            fParams = curves.getParamsFromPoints(sMaxBlendingCurves[p], aaPoints[p])
            sJoints = []
            for j,fParam in enumerate(fParams):
                sInfoNode, sInfoPos = curves.createPointInfoNode(sMaxBlendingCurves[p], fParam=fParams[j], sName='eyeSpline_%s_%sPushOutSpline_%03d' % (sSide,sPart,j))
                sJ = cmds.createNode('joint', n='jnt_%s_%sPushOutSpline_%03d' % (sSide, sPart, j), p=sGrp)
                utils.matchJointRadius(sJ, sEyeJoints[s], 0.4)
                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)
                sLength = nodes.createDistanceNode(sLocalPoint, [0, 0, 0])
                sFactor = nodes.createMultiplyNode(cmds.getAttr(sLength), sLength, sOperation='divide', sName='eyeSpline_%s_%sFactor_%03d' % (sSide,sPart,j))
                sFactor = nodes.createConditionNode(sFactor, '>', 1.0, sFactor, 1.0, sName='eyeSpline_%s_%sFactor_%03d' % (sSide,sPart,j))
                sScaledLocalPoint = nodes.createVectorMultiplyNode(sLocalPoint, sFactor, bVectorByScalar=True)
                sWorldPoint = nodes.createPointByMatrixNode(sScaledLocalPoint, '%s.worldMatrix' % cEyeTransform.sOut)
                cmds.connectAttr(sWorldPoint, '%s.t' % sJ)
                # constraints.pointAndAimConstraint(sJ, sWorldPoint, nodes.getWorldPoint(cEyeTransform.sOut),
                #                                   nodes.createVectorAdditionNode([sWorldPoint, '%s.tangent' % sInfoNode]),
                #                                   aim=[0, 0, -1], up=[1, 0, 0])
                sJoints.append(sJ)

            cmds.skinCluster(sBlendingCurves[p], sJoints, tsb=True)
            cmds.skinCluster(sCtrlBlendingCurves[p], sJoints, tsb=True)

        # positions on sBlendingCurves
        ssCurvePositions = [], []
        ffParams = []
        ssSkinNodes = [], []
        for p,sPart in enumerate(['bot','top']):
            fParams = curves.getParamsFromPoints(sBlendingCurves[p], aaPoints[p])
            for j,fParam in enumerate(fParams):
                # if j == 0:
                #     ssCurvePositions[p].append(nodes.getWorldPoint(ccCornerCtrls[s][0].sOut))
                # elif j == len(fParams)-1:
                #     ssCurvePositions[p].append(nodes.getWorldPoint(ccCornerCtrls[s][1].sOut))
                # else:
                sNode, sPos = curves.createPointInfoNode(sBlendingCurves[p], fParam=fParams[j])
                ssCurvePositions[p].append(sPos)
                ssSkinNodes[p].append(sNode)
            ffParams.append(fParams)

        sLivePoleAttr = utils.addAttr(cBlink.sPasser, ln='livePole', min=0, max=1, dv=fLivePole, k=True)

        sCombinedCurves = []
        for p,sPart in enumerate(['bot','top']):
            sEvenTangents = []
            sEvenJoints = []

            # create even joints and attach them
            for j,fParam in enumerate(ffParams[p]):
                if p == 0 and j in [0,len(ffParams[p])-1]:
                    sEvenTangents.append(None)
                    continue
                sJ = cmds.createNode('joint', n='jnt_%s_%sEvenLidSpline_%03d' % (sSide, sPart, j), p=sTransformGrp)
                utils.matchJointRadius(sJ, sEyeJoints[s], 0.36)

                sEvenJoints.append(sJ)
                sInfoPos = ssCurvePositions[p][j]

                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)
                sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0], bConnectJointOrient=False)
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)

                jUp = j+1 if j == 0 else j-1
                sWorldTangent = nodes.createVectorAdditionNode([ssCurvePositions[p][jUp], ssCurvePositions[p][j]], sOperation='minus')

                sTangent = nodes.createPointByMatrixNode(sWorldTangent,
                                                        sTransformJointRotInverseMatrix)

                sTangent = nodes.createBlendNode(sLivePoleAttr, sTangent, cmds.getAttr(sTangent)[0], bVector=True)
                sEvenTangents.append(sTangent)
                cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr(sLocalPoint, '%s.t' % sJ)


            # attach ctrls
            cCtrlCurveNodes = []
            for c,cC in enumerate(cccBotTopCtrls[s][p]):
                sNode, sInfoPos = curves.createPointInfoNode(sBlendingCurves[p], fParam=ffCtrlParams[p][c])
                nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut, sTarget='%s.t' % cC.sPasser)
                cCtrlCurveNodes.append(sNode)
                sAimConstraint = constraints.aimConstraintEmpty(cC.sPasser, aim=[0, 0, -1], up=[1, 0, 0])
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sTransformJointRotInverseMatrix)
                cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)

                if _bSquashed:
                    sInfoNodeSquashed, sInfoPos = curves.createPointInfoNode(sCtrlBlendingCurves[p])#, fParam=ffCtrlParams[p][c])
                    cmds.connectAttr('%s.parameter' % sNode, '%s.parameter' % sInfoNodeSquashed)
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  sTarget='%s.t' % cC.cC.sPasser)
                    sAimConstraint = constraints.aimConstraintEmpty(cC.cC.sPasser, aim=[0, 0, -1], up=[1, 0, 0])
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNodeSquashed, sTransformJointRotInverseMatrix)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)

            # attach corner ctrls
            if p == 0:
                for c,cC in enumerate(ccCornerCtrls[s]):
                    sOffset = xforms.createTransform('grp_%s_eyeLidCtrlConstraint_%d' % (sSide,c), sMatch=cC.sPasser, sParent=sTransformGrp)
                    sInfoNodeSquashed, sInfoPos = curves.createPointInfoNode(sCtrlBlendingCurves[p],
                                                                             fParam=0 if c == 0 else curves.getParamLength(sCtrlBlendingCurves[p]))
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  sTarget='%s.t' % sOffset)
                    sAimConstraint = constraints.aimConstraintEmpty(sOffset, aim=[0, 0, -1], up=[1, 0, 0])
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNodeSquashed, sTransformJointRotInverseMatrix)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                    if _bSquashed:
                        constraints.matrixParentConstraint(sOffset, cC.cC.sPasser, mo=True)



            sCombinedCurve = cmds.duplicate(sBlendingCurves[p], n='curve_%s_%sCombined' % (sSide, sPart))[0]
            cmds.skinCluster(sCombinedCurve, sEvenJoints, tsb=True)
            sCombinedCurves.append(sCombinedCurve)
            # cmds.blendShape(sBlendingCurves[p], sCombinedCurve, w=[0,1])



            # create and attach skin joints
            sSphericalJoints = []
            sSkinJoints = []
            for j, fParam in enumerate(ffParams[p]):
                if p == 0 and j in [0, len(ffParams[p]) - 1]:
                    continue
                if _bSquashed:
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSphericalLidSpline_%03d' % (sSide, sPart, j),
                                         p=sTransformGrp)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.30)
                    sSphericalJoints.append(sJ)
                else:
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSkinLidSpline_%03d' % (sSide, sPart, j),
                                         p=sTransformJoint)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.30)
                    sSkinJoints.append(sJ)

                _, sInfoPos = curves.createPointInfoNode(sCombinedCurves[p], fParam=ffParams[p][j])

                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)

                # push out again
                sLength = nodes.createDistanceNode(sLocalPoint, [0, 0, 0])
                sFactor = nodes.createMultiplyNode(cmds.getAttr(sLength), sLength, sOperation='divide')

                # this is to be able to push the joints away from the eyeball. Maybe put it back in future..?
                if bLidsCanPushOut:
                    sFactor = nodes.createConditionNode(sFactor, '>', 1.0, sFactor, 1.0)
                sLocalPoint = nodes.createVectorMultiplyNode(sLocalPoint, sFactor, bVectorByScalar=True)

                aLocalOffset = aaLocalPoints[p][j] - np.array(cmds.getAttr(sLocalPoint)[0], dtype='float64')
                sLocalPoint = nodes.createVectorAdditionNode([sLocalPoint, aLocalOffset])

                sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0],
                                                                bConnectJointOrient=False)
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                cmds.connectAttr(sEvenTangents[j], '%s.worldUpVector' % sAimConstraint)

                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr(sLocalPoint, '%s.t' % sJ)


            # maintain percs with driven keys
            fDrivenParams = [-0.5, 0.0, 0.5, 1.0]
            for sInfoNodes, sCurve in [(ssSkinNodes[p], sBlendingCurves[p]),
                                       (cCtrlCurveNodes, sBlendingCurves[p])]:
                ffDrivenValues = []
                fParams = [cmds.getAttr('%s.parameter' % sN) for sN in sInfoNodes]
                fPercs = curves.getPercsFromParams(sCurve, fParams)

                for i,fV in enumerate(fDrivenParams):
                    cmds.setAttr(ffBlinkPoses[p][0], ffBlinkPoses[p][1] * fV)
                    ffDrivenValues.append(curves.getParamsFromPercs(sCurve, fPercs))
                cmds.setAttr(ffBlinkPoses[p][0], 0)

                for j,sN in enumerate(sInfoNodes):
                    nodes.disconnectAttr('%s.parameter' % sN)

                    fDrivenValues = [ffDrivenValues[i][j] for i in range(len(fDrivenParams))]
                    nodes.setDrivenKey(sBlendingTargetAttrs[p], fDrivenParams, '%s.parameter' % sN, fDrivenValues)


            # lattice curve
            if _bSquashed:
                sLatticeCurve = cmds.curve(p=aaPoints[p], d=1, n='curve_%s_%sLattice' % (sSide,sPart))

                aTransformMatrix = utils.getNumpyMatrixFromTransform(sTransformGrp)
                aPointsLocal = np.dot(utils.makePoint4Array(aaPoints[p]), np.linalg.inv(aTransformMatrix))[:,0:3]
                aPointsLocal *= 0.95
                aUpPoints = np.dot(utils.makePoint4Array(aPointsLocal), aTransformMatrix)[:,0:3]
                sLatticeUpCurve = cmds.curve(p=aUpPoints, d=1, n='curve_%s_%sUpLattice' % (sSide,sPart))
                cmds.parent(sLatticeCurve, sLatticeUpCurve, sGrp)
                fParams = curves.getParamsFromTransforms(sLatticeCurve, sSphericalJoints)
                cmds.skinCluster(sLatticeCurve, sSphericalJoints, tsb=True)
                cmds.skinCluster(sLatticeUpCurve, sSphericalJoints, tsb=True)

                deformers.applyLattice(ssLattices[s], sLatticeCurve)
                deformers.applyLattice(ssLattices[s], sLatticeUpCurve)
                for j,fParam in enumerate(fParams):
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSkinLidSpline_%03d' % (sSide, sPart, j),
                                         p=sTransformJoint)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.30)
                    sInfoNode, sInfoPos = curves.createPointInfoNode(sLatticeCurve, fParam=fParams[j])
                    _, sInfoUpPos = curves.createPointInfoNode(sLatticeUpCurve, fParam=fParams[j])
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % sTransformJoint, sTarget='%s.t' % sJ)
                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0],
                                                                    bConnectJointOrient=False)
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    nodes.createPointByMatrixNode(sInfoUpPos, '%s.worldInverseMatrix' % sTransformJoint, '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNode, sTransformJointRotInverseMatrix)
                    sTangent = nodes.createBlendNode(sLivePoleAttr, sTangent, cmds.getAttr(sTangent)[0], bVector=True)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                    sSkinJoints.append(sJ)


                deformers.applyLattice(ssLattices[s], sCtrlBlendingCurves[p])


            # reference matrix:
            if bSeparateSkinCluster:
                for sJ in sSkinJoints:
                    fLocalMatrix = nodes.createMultMatrixNode(
                        ['%s.worldMatrix' % sJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                    sRefMatrix = nodes.createMultMatrixNode([fLocalMatrix, '%s.worldMatrix' % sParentJoint])
                    sRevInvMatrix = nodes.createInverseMatrix(sRefMatrix)
                    utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRevInvMatrix)

        sCtrlSkinClusters = [] #bot/top
        for p,sPart in enumerate(['bot','top']):

            sCtrlJoints = [cC.sJoint for cC in [ccCornerCtrls[s][0]]+cccBotTopCtrls[s][p]+[ccCornerCtrls[s][1]]]
            sCtrlSkinCluster = deformers.skinMesh(sCombinedCurves[p], ['jnt_m_faceZero'],
                                                  bAlwaysCreateManually=True, bAlwaysAddDefaultWeights=True,
                                                  sName='skinCluster__lidSplines_%s_%s_%02d' % (sSide,sPart,0), _bSkipDeformerAdjustLogging=True)
            weights.skinCurveBSpline4(patch.patchFromName(sCombinedCurves[p]), sCtrlJoints,
                                      sChooseSkinCluster=sCtrlSkinCluster, bStrongEnds=True,
                                      iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)
            
            sCtrlSkinClusters.append(sCtrlSkinCluster)
        
        # bottom lid follow top controls on blink
        cmds.setAttr('%s.ty' % cBlink.sCtrl, -1)
        sTopToBotSkinCluster = weights.transferSkinCluster(patch.patchFromName(sCombinedCurves[0]), sFrom=sCtrlSkinClusters[1],
                                                           bAutoCreateNewSkinCluster='%s_otherside' % sSide, _bSkipDeformerAdjustLogging=True)[0]
        cmds.setAttr('%s.ty' % cBlink.sCtrl, 0)
        sBotFollowTopCtrlsAttr = utils.addAttr(cBlink.sCtrl, ln='botFollowTopCtrlsOnBlink', min=0, max=1, dv=0, k=True)
        nodes.createMultiplyNode(sBotFollowTopCtrlsAttr, sBlink, sTarget='%s.envelope' % sTopToBotSkinCluster)

        # if _bSquashed:
        #     for p,sPart in enumerate(['bot','top']):
        #         deformers.applyLattice(ssLattices[s], sCombinedCurves[p])

        # pick walk
        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, cEyeTransform.sCtrl, parent=True)

#EXCLUDE END LIDSPLINES


kSplineLidCorrectivePrefix = 'splineLidCorrective'
kSplineLideCorrectiveSep = 'X'

@builderTools.addToBuild(iOrder=62.3, dButtons=dButtons, bDisableByDefault=True)
def applySplineLidCorrectives(sModel=None):
    if sModel:
        sModel = utils.toList(sModel)[0]
    else:
        raise Exception('no model given')

    sCorrectives = cmds.ls('%s*' % kSplineLidCorrectivePrefix, et='transform')

    xxCorrs = [[], []]
    for sCorr in sCorrectives:
        report.report.addLogText('"%s"...' % sCorr)

        sBotTopSplits = sCorr.split(kSplineLideCorrectiveSep)[-2:]
        for p,sPart in enumerate(['bot','top']):
            if sBotTopSplits[p]:
                print ('sBotTopSplits[p]: ', sBotTopSplits[p])
                if sBotTopSplits[p].startswith('n'):
                    iValue = -int(sBotTopSplits[p][1:])
                else:
                    iValue = int(sBotTopSplits[p])
                fValue = iValue * 0.01
                bBoth = True if sBotTopSplits[1-p] else False
                xxCorrs[p].append((sCorr, fValue, bBoth))



    for p,sPart in enumerate(['bot','top']):
        print ('\n\n\n PART: ', sPart)
        xCorrsSorted = sorted(xxCorrs[p], key=lambda x:x[1])

        for x,xCorr in enumerate(xCorrsSorted):
            sCorr, fValue, bBoth = xCorr
            if p == 1 and bBoth:
                continue
            fBothValues = [None, None]
            fBothValues[p] = fValue
            if p == 0 and bBoth:
                for xOppCorr in xxCorrs[1]:
                    sOppCorr, fOppValue, _ = xOppCorr
                    if sCorr == sOppCorr:
                        fBothValues[1] = fOppValue

            ffLidRanges = [[], []]

            for pp,fV in enumerate(fBothValues):
                if fV == None:
                    continue
                fRange = [None, fV, None]
                if fV > 0.9999:
                    fFloorValue = 0.0
                else:
                    fFloorValue = math.floor(fV)
                fCeilValue = math.ceil(fV)


                if x > 0:
                    fRange[0] = xCorrsSorted[x-1][1]
                    if fV > 0.0 and fRange[0] < 0.0:
                        fRange[0] = 0.0
                else:
                    fRange[0] = fFloorValue
                if fRange[0] == fRange[1]:
                    fRange[0] = None
                print ('x: ', x, 'xCorrsSorted: ', xCorrsSorted)
                if x < len(xCorrsSorted)-1:
                    fRange[2] = xCorrsSorted[x+1][1]

                    if fV < 0.0 and fRange[2] > 0.0:
                        fRange[2] = 0.0
                else:
                    if fRange[1] == -1:
                        fRange[2] = 0
                    else:
                        fRange[2] = fCeilValue
                if fRange[2] == fRange[1]:
                    fRange[2] = None


                if fRange[0] == None and fRange[2] == None:
                    raise Exception('Something wrong with the algorithm.. both ends are None')

                ffLidRanges[pp] = fRange

            
            report.report.addLogText('==== sCorr: %s, ffLidRanges, %s' % (sCorr, ffLidRanges))

            sSecondaryModels = [sO.split('__')[0] for sO in cmds.ls('*__%s' % sCorr)]
            blendShapesPro.connectTargets(sModel, sCorr, ffLidRanges=ffLidRanges, iInvert=2, sSecondaryModels=sSecondaryModels)
            # if bMakeNotExportWeights:
            #     deformers.makeBlendShapesNoExport([sModel]+sSecondaryModels)


@builderTools.addToBuild(iOrder=51, dButtons={}, bDisableByDefault=True)
def eyeLatticeCtrls(sLeftMeshes=[], sRightMeshes=[], sSkinMeshes=[], fScale=[1.0, 1.0, 1.0], fTranslate=[0,0,0], fEye_l_ctrl_defaultR=[0,0,0]):
    '''
    To place/scale the controls/lattice, set the fScale and fTranslate values. To find those values, just translate/scale the lattice boxes around and record their values
    '''
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]

    if not sLeftMeshes and not sRightMeshes:
        raise Exception('need to specify meshes (sLeftMeshes, sRightMeshes, sSkinMeshes)')

    ssEyeMeshes = [sLeftMeshes, sRightMeshes]

    sGrp = cmds.createNode('transform', n='grp_eyeLatticeSetup', p='modules')


    for s,sSide in enumerate(['l','r']):
        fEyeLength = abs(cmds.getAttr('%s.tx' % ssEyeJoints[s][1]))
        sEyeCtrl = ctrls6.ctrlFromName('eye%s_ctrl' % utils.sSides3[s]).sCtrl
        cEyeTransform = ctrls6.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])

        sTempMatchTransform = cmds.createNode('transform')
        cmds.delete(cmds.orientConstraint(cEyeTransform.sCtrl, sTempMatchTransform))

        # if not bLegacyOrient:
        sConstrDelete = cmds.parentConstraint(sEyeCtrl, sTempMatchTransform, mo=True)

        cmds.setAttr('%s.r' % sEyeCtrl, *fEye_l_ctrl_defaultR)

        # if not bLegacyOrient:
        cmds.delete(sConstrDelete)


        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        for m, sMesh in enumerate(ssEyeMeshes[s]+sSkinMeshes):
            # sName = 'lattice_%s_eyeball' % sSide
            sLatDeformer = 'lattice__%s__%s_EYE' % (sMesh, sSide)
            if m == 0:
                if cmds.objExists(sLatDeformer):
                    sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                    sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                else:
                    sLatDeformer, sLat, sLatBase = cmds.lattice(sMesh, n=sLatDeformer)

                cmds.setAttr('%s.sDivisions' % sLat, 2)
                cmds.setAttr('%s.tDivisions' % sLat, 3)
                cmds.setAttr('%s.uDivisions' % sLat, 2)
                cmds.setAttr('%s.localInfluenceS' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceT' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceU' % sLatDeformer, 2)

                sParent = cmds.createNode('transform', n='grp_%s_eyeLattice' % sSide, p=sGrp)
                sScaleParent = cmds.createNode('transform', n='grp_%s_eyeLatticeScale' % sSide, p=sParent)
                cmds.parent(sLat, sLatBase, sScaleParent)
                cmds.setAttr('%s.s' % sLat, fScale[0], fScale[1], fScale[2])
                cmds.setAttr('%s.s' % sLatBase, fScale[0], fScale[1], fScale[2])
                cmds.setAttr('%s.t' % sLat, fTranslate[0], fTranslate[1], fTranslate[2])
                cmds.setAttr('%s.t' % sLatBase, fTranslate[0], fTranslate[1], fTranslate[2])

            else:
                # sLatDeformer, _sLat, _sLatBase = cmds.lattice(sMesh)#, divisions=(2, 3, 2), ldv=(2, 2, 2))
                if cmds.objExists(sLatDeformer):
                    _sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                    _sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                else:
                    sLatDeformer, _sLat, _sLatBase = cmds.lattice(sMesh, n=sLatDeformer)
                cmds.setAttr('%s.localInfluenceS' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceT' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceU' % sLatDeformer, 2)
                cmds.connectAttr('%sShape.latticeOutput' % sLat, '%s.deformedLatticePoints' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLat, '%s.deformedLatticeMatrix' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLatBase, '%s.baseLatticeMatrix' % sLatDeformer, f=True)
                cmds.delete(_sLat, _sLatBase)

            cmds.setAttr('%s.outsideLattice' % sLatDeformer, 1)

            # if it's a mesh per side, we more likely won't need to paint weights
            if sMesh not in sSkinMeshes:
                if sMesh not in ssEyeMeshes[1-s]:
                    deformers.makeNotExport(sLatDeformer)

        cmds.delete(cmds.parentConstraint(ssEyeJoints[s][0], sParent))
        cmds.setAttr('%s.sx' % sParent, fSideMultipl)
        cmds.setAttr('%s.sy' % sParent, fSideMultipl)
        constraints.matrixParentConstraint(cEyeTransform.sOut, sParent, mo=True)
        fParentScale = fEyeLength * 2.0
        cmds.setAttr('%s.s' % sScaleParent, fParentScale, fParentScale, fParentScale*fSideMultipl)

        sJoints = []
        sOrigin = xforms.createTransform('grp_%s_latticeOrigin' % sSide, sMatch=cEyeTransform.sPasser, sParent=sGrp)

        xLatticePointData = [['bot', ('pt[0:1][0][0]', 'pt[0:1][0][1]'), ('pt[1][0][0:1]',)],
                            ['top', ('pt[0:1][2][0]', 'pt[0:1][2][1]'), ('pt[1][2][0:1]',)],
                            ['in', ('pt[0:1][1][1]',), ('pt[1][1][1]',)],
                            ['out', ('pt[0:1][1][0]',), ('pt[1][1][0]',)]]
        dJoints = {}
        dCtrls = {}
        for sName, sPoints, sCtrlPoints in xLatticePointData:
            aCtrlPos = np.average(np.array(cmds.xform(['%s.%s' % (sLat,sP) for sP in sCtrlPoints], q=True, ws=True, t=True)).reshape(-1,3), axis=0)
            cmds.setAttr('%s.t' % sTempMatchTransform, *list(aCtrlPos))
            cC = ctrls6.create(sName='%sEyeLattice' % sName, sSide=sSide, sParent=_getFaceCtrlGrp(), sMatch=sTempMatchTransform,
                              sAttrs=['t','r','sx'] if sName in ['bot','top'] else ['t','r'],
                              fRotateShape=(0, 0, 0) if sName in ['bot','top'] else (0,0,-90),
                              iColorIndex=1, fSliderScale=fEyeLength,
                              sShape='triangle', fSize=0.5)
            cC.createExtraMoveTransformAndTag(['skinCluster__*face*__TWEAKER'])
            if sName == 'bot':
                cmds.setAttr('%s.sy' % cC.sSlider, cmds.getAttr('%s.sy' % cC.sSlider) * -1.0)
                cmds.setAttr('%s.sy' % cC.sOut, cmds.getAttr('%s.sy' % cC.sOut) / -1.0)
            if sName == 'out':
                cmds.setAttr('%s.sx' % cC.sSlider, cmds.getAttr('%s.sx' % cC.sSlider) * -1.0)
                cmds.setAttr('%s.sx' % cC.sOut, cmds.getAttr('%s.sx' % cC.sOut) / -1.0)
            
            constraints.matrixParentConstraint(cEyeTransform.sCtrl, cC.sPasser, mo=True, skipTranslate=['x','y','z'] if sName in ['in', 'out'] else [])
            sJ = cmds.createNode('joint', n='jnt_%s_%sEyelattice' % (sSide,sName), p=sOrigin)
            cmds.setAttr('%s.radius' % sJ, fEyeLength*0.1)
            # cmds.setAttr('%s.v' % sJ, False)


            sMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut,
                                                  '%s.worldInverseMatrix' % cC.getOffsetByName('extramove'),
                                                  '%s.worldMatrix' % cC.sPasser,
                                                  '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  ])
            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ)
            # nodes.transformInLocalSpace(cC.sOut, cEyeTransform.sOut, sJ)

            sJoints.append(sJ)
            dJoints[sName] = sJ
            dCtrls[sName] = cC

            if sName in ['in', 'out']:
                sPoints = []
                for sPart in ['bot','top']:
                    cPart = dCtrls[sPart]
                    sPoint = xforms.createTransform('grp_%s_%sConstr%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)), sParent=cPart.sOut, sMatch=cC.sOut)
                    cmds.setAttr('%s.ty' % sPoint, 0.0)
                    cmds.parent(sPoint, cPart.sPasser)
                    constraints.matrixParentConstraint(cPart.sOut, sPoint, mo=True, sJumpOverTransforms=[cPart.getOffsetByName('extramove'), cPart.sPasser])
                    sPoints.append(sPoint)

                cmds.pointConstraint(sPoints[0], sPoints[1], cC.sPasser)

        sSkinCluster = cmds.skinCluster(sLat, sJoints, tsb=True, maximumInfluences=1)[0]
        for sName, sPoints, sCtrlPoints in xLatticePointData:
            cmds.skinPercent(sSkinCluster, ['%s.%s' % (sLat,sP) for sP in sPoints], transformValue=[dJoints[sName], 1])

        cmds.delete(sTempMatchTransform)
        cmds.setAttr('%s.r' % sEyeCtrl, 0,0,0)





dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def recordSiblings(_uiArgs=None):

    dPoses = {}
    sSiblings = [sT for sT in cmds.listRelatives('jnt_l_eyeLidParent', c=True) if sT.startswith('grp_l_sibling') or sT.startswith('l_sibling')]

    print('sSiblings: ',sSiblings)
    for sT in sSiblings:
        sPrintT = sT
        if sPrintT.endswith('_Grp'):
            sPrintT = 'grp_%s' % sPrintT[:-4]
        for sA in ['t','r','s']:
            sAttr = '%s.%s' % (sT,sA)
            sPrintAttr = '%s.%s' % (sPrintT,sA)
            dPoses[sPrintAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dSiblingPoses'].setText(str(dPoses))



def selectSiblings(_uiArgs=None):

    dPoses = {}
    sSiblings = [sT for sT in cmds.listRelatives('jnt_l_eyeLidParent', c=True) if sT.startswith('grp_l_sibling') or sT.startswith('l_sibling')]

    cmds.select(sSiblings)


kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill left sibling poses'] = recordSiblings
dButtons['select left sibling transforms'] = selectSiblings



def _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bLattice, fScaleTheScale):
    utils.data.store('bLatticeEyes', bLattice)
    # utils.data.store('bScaleSquash', bScaleSquash)

    ssLattices = [None, None], [None, None]
    if not bLattice:
        fEyeballSquashValues = cmds.getAttr('%s.s' % ssMeshes[0][0])[0]
        fEyeballSquashValues = [abs(fEyeballSquashValues[0]), abs(fEyeballSquashValues[1]), abs(fEyeballSquashValues[2])]
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]
    sNurbsSpheres = []
    for s,sSide in enumerate(['l','r']):
        sSphere = cmds.sphere(n='nurbs_%s_eyeRigSphere' % sSide, r=cmds.getAttr('%s.tx' % ssEyeJoints[s][1]))[0]
        cmds.delete(cmds.parentConstraint(ssEyeJoints[s][0], sSphere))
        ssMeshes[s].append(sSphere)
        sNurbsSpheres.append(sSphere)
        sSkinCluster = cmds.skinCluster(sSphere, ssEyeJoints[s][0], tsb=True)
        deformers.makeNotExport(sSkinCluster)

    cmds.parent(sNurbsSpheres, 'modules')
    if bLattice:
        sLatticeDeformers = []
        for s,sSide in enumerate(['l','r']):
            for sM in ssMeshes[s]:
                sDefs = deformers.listAllDeformers(sM, sFilterTypes=['ffd'], bSkipGeoTest=True)
                sLatticeDeformers += sDefs
                for sD in sDefs:
                    sLatticeConn = cmds.listConnections(sD, t='lattice', s=True, d=False)
                    if sLatticeConn:
                        ssLattices[s][0] = sLatticeConn[0]
                    sBaseLatticeConn = cmds.listConnections(sD, t='baseLattice', s=True, d=False)
                    if sBaseLatticeConn:
                        ssLattices[s][1] = sBaseLatticeConn[0]

                    sConns = cmds.listConnections(sD, t='lattice', s=True, d=False, c=True, p=True) or []
                    sConns += cmds.listConnections(sD, t='baseLattice', s=True, d=False, c=True, p=True) or []
                    print('sConns: ', sConns)
                    for i in range(0, len(sConns), 2):
                        cmds.disconnectAttr(sConns[i+1], sConns[i])

        if sLatticeDeformers:
            cmds.delete(sLatticeDeformers)


    utils.data.store('ssEyeLattices', ssLattices)
    utils.data.store('ssEyeMeshes', ssMeshes)
    sSuffix = ''
    for s, sSide in enumerate(['l', 'r']):

        cEyeCtrl = ctrls6.ctrlFromName('eye%s_ctrl' % utils.sSides3[s])
        cEyeTransform = ctrls6.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])


        if not bLattice:
            for sM in ssMeshes[s]:
                fValues = cmds.getAttr('%s.s' % sM)[0]
                fSquashToOne = fValues[0]/fEyeballSquashValues[0], fValues[1]/fEyeballSquashValues[1], fValues[2]/fEyeballSquashValues[2]
                if sM not in sNurbsSpheres:
                    cmds.setAttr('%s.s' % sM, *fSquashToOne)

        if bLattice:
            sLatticeGrp = cmds.createNode('transform', n='grp_%s_latticeGrp' % sSide, p='modules')
            constraints.matrixParentConstraint(cEyeTransform.sOut, sLatticeGrp)
            print ('ssLattices: ', ssLattices)
            cmds.parent(ssLattices[s], sLatticeGrp)
            cmds.select(sLatticeGrp)

        else: # used to be bSquashedEyeballs
            sEyeballSquashAttrs = [utils.addAttr(cEyeTransform.sPasser, ln='squashX', defaultValue=fEyeballSquashValues[2], k=True),
                                  utils.addAttr(cEyeTransform.sPasser, ln='squashY', defaultValue=fEyeballSquashValues[1], k=True),
                                  utils.addAttr(cEyeTransform.sPasser, ln='squashZ', defaultValue=fEyeballSquashValues[0], k=True)]
            sEyeballSquashSwitch = utils.addAttr(cEyeTransform.sPasser, ln='squashSwitch', defaultValue=0.0, k=True, min=0, max=1)
            sEyeballSquashScaleTheScale = utils.addAttr(cEyeTransform.sPasser, ln='squashExtra', defaultValue=fScaleTheScale, k=True)
            sDiff = nodes.createVectorAdditionNode([sEyeballSquashAttrs, [1,1,1]], sOperation='minus')
            sMultipl = nodes.createVectorMultiplyNode(sDiff, sEyeballSquashScaleTheScale, bVectorByScalar=True)
            sEyeballSquashAdded = nodes.createVectorAdditionNode([sMultipl, [1,1,1]])
            
            sEyeballSquash = nodes.createBlendNode(sEyeballSquashSwitch, sEyeballSquashAdded, [1,1,1], bVector=True)
            sSquashGrp = xforms.insertParent(ssEyeJoints[s][0], sName='grp_%s_eyeSquash' % sSide)
            nodes.deleteConnection('%s.s' % ssEyeJoints[s][0])
            nodes.deleteConnection('%s.r' % ssEyeJoints[s][0])


            cmds.connectAttr(sEyeballSquash, '%s.s' % sSquashGrp)
            sEyeInPasser = cmds.createNode('transform', n='grp_%s_eyeInPasser' % sSide, p='grp_%s_eyeTransformPasser' % sSide)
            constraints.matrixParentConstraint(cEyeCtrl.sOut, sEyeInPasser)
            cmds.connectAttr('%s.r' % sEyeInPasser, '%s.r' % ssEyeJoints[s][0])



@builderTools.addToBuild(iOrder=24.2, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def simpleLidSetup(sParentJoint='jnt_m_headMain', dSiblingPoses={}, sLeftMeshes=[], sRightMeshes=[], bModelHasLattice=False, fScaleTheScale=1.0):
    '''
    for the behavior of the joints towards the controls, adjust the sibling groups. They are in the same
    parents as the eyelid joints (select button "select blink joints" to find them)

    Adjust the left side, and he'll mirror the right side for you
    '''

    ssMeshes = [sLeftMeshes, sRightMeshes]

    if ssMeshes[0] or ssMeshes[1]:
        _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bModelHasLattice, fScaleTheScale)
    sEyeLimbNames = ['l_eye', 'r_eye']
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeIris'], ['jnt_r_eyeMain', 'jnt_r_eyeIris']]
    sEyeTransformJoints = ['jnt_l_eyeTransform', 'jnt_r_eyeTransform']
    sSuffix = ''
    for s,sSide in enumerate(['l','r']):
        sParent = xforms.createJoint('jnt_%s_eyeLidParent' % sSide, sParent=sParentJoint, sMatch=sEyeTransformJoints[s], fSize=0.5)
        cmds.setAttr('%s.segmentScaleCompensate' % sParent, False)
        constraints.matrixParentConstraint(sEyeTransformJoints[s], sParent)

        # aJointPositions = xforms.getPositionArray(ssEyeJoints[s])

        cBlink = ctrls6.ctrlFromName('blink%s%s_ctrl' % (sSuffix, utils.sSides3[s]))
        cExtraBlinks = [ctrls6.ctrlFromName('lidBot%s%s_ctrl' % (sSuffix, utils.sSides3[s])),
                        ctrls6.ctrlFromName('lidTop%s%s_ctrl' % (sSuffix, utils.sSides3[s]))]
        cAim = ctrls6.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s], bReturnNoneIfNotExists=True)
        if not cAim:
            cAim = ctrls6.ctrlFromName('eyeLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)


        # cmds.setAttr('%s.s' % cBlink.sSlider, fSideMultipl,  fSideMultipl, fSideMultipl)
        cmds.controller(cBlink.sCtrl, headCtrl(), parent=True)

        sBlinkJoints = [xforms.createJoint('jnt_%s_eyeBlinkBot' % sSide, sMatch=ssEyeJoints[s][0], sParent=sParent),
                        xforms.createJoint('jnt_%s_eyeBlinkTop' % sSide, sMatch=ssEyeJoints[s][0], sParent=sParent)]


        sEyeOpen = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0,-1, 1, 0)


        sLookVert = '%s.lookVert' % cAim.sPasser
        sSwitchedLookY = nodes.createMultiplyArrayNode([sLookVert, 0.5, sEyeOpen])

        for p,sPart in enumerate(['bot','top']):
            sSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingWideMain = cmds.createNode('transform', n='grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingExtraDown = cmds.createNode('transform', n='grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingExtraUp = cmds.createNode('transform', n='grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)

            # sSiblingFollowDown = cmds.createNode('transform', n='grp_%s_siblingFollowDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            # sSiblingFollowUp = cmds.createNode('transform', n='grp_%s_siblingFollowUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)

            # default attributes..
            if p == 0:
                cmds.setAttr('%s.rz' % sSiblingBlinkMain, 30)
                cmds.setAttr('%s.rz' % sSiblingWideMain, -5)
            else:
                cmds.setAttr('%s.rz' % sSiblingBlinkMain, -30)
                cmds.setAttr('%s.rz' % sSiblingWideMain, 10)
            cmds.setAttr('%s.rz' % sSiblingExtraDown, -30)
            cmds.setAttr('%s.rz' % sSiblingExtraUp, 30)
            # cmds.setAttr('%s.rz' % sSiblingFollowDown, -30)
            # cmds.setAttr('%s.rz' % sSiblingFollowUp, 30)

            for sA in ['t','r','s']:
                fDefault = [1,1,1] if sA == 's' else [0,0,0]
                sBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sSiblingBlinkMain, sA), bOutRangeIsVector=True)
                sBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sSiblingWideMain, sA), bOutRangeIsVector=True)
                sBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                sBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)

                sBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                sBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)

                if sA in ['t','r']:
                    nodes.createVectorAdditionNode([sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp], sTarget='%s.%s' % (sBlinkJoints[p], sA))
                else:
                    nodes.createMultiplyArrayNode([sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp], bVector=True, sTarget='%s.%s' % (sBlinkJoints[p], sA))


        for sAttr, fValues in list(dSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if not cmds.objExists(sAttrSide):
                report.report.addLogText('skipping setting siblingPoses for %s (doesn\'t exist)' % sAttrSide)
                continue
            if sAttr.endswith('.t') and sSide == 'r':
                cmds.setAttr(sAttrSide, -fValues[0], -fValues[1], -fValues[2])
            else:
                cmds.setAttr(sAttrSide, *fValues)

    sUnrealCodeLines = ['\n\n# Lid Setup\n\n']
    # sUnrealMocapCodeLines = ['\n\n# Lid Setup\n\n']

    for s,sSide in enumerate(['l','r']):
        ssUnrealTranslations = [], []
        ssUnrealRotations = [], []
        ssUnrealScales = [], []

        for p,sPart in enumerate(['bot','top']):
            sSiblingBlinkMain = 'grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingWideMain = 'grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraDown = 'grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraUp = 'grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sList = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp]
            for sT in sList:
                ssUnrealTranslations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.t' % sT)[0], bBoneSpace=True))
                ssUnrealRotations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.r' % sT)[0], bEuler=True, bBoneSpace=True))
                ssUnrealScales[p].append(cmds.getAttr('%s.s' % sT)[0])
                
        sUnrealCodeLines.append("functions.lidSetup([%s, %s, %s], \n\t\t\t[%s, %s, %s], sSide='%s', sLookVertVarName='lookVert_%s', sLookHorizVarName='lookHoriz_%s')" %
                         (ssUnrealTranslations[0], ssUnrealRotations[0], ssUnrealScales[0], ssUnrealTranslations[1], ssUnrealRotations[1], ssUnrealScales[1], sSide, sEyeLimbNames[s], sEyeLimbNames[s]))
        # sUnrealMocapCodeLines.append("functions.lidSetupApple([%s, %s, %s], \n\t\t\t[%s, %s, %s], sSide='%s')" %
        #                  (ssUnrealTranslations[0], ssUnrealRotations[0], ssUnrealScales[0], ssUnrealTranslations[1], ssUnrealRotations[1], ssUnrealScales[1], sSide))



    report.report.addLogText('\n'.join(sUnrealCodeLines), bPrint=True)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()
    utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)



@builderTools.addToBuild(iOrder=50.1, dButtons={})
def activateEyeSQUASHED():
    if cmds.objExists('grp_l_eyeTransformPasser.squashSwitch'):
        cmds.setAttr('grp_l_eyeTransformPasser.squashSwitch', 1.0)
    if cmds.objExists('grp_r_eyeTransformPasser.squashSwitch'):
        cmds.setAttr('grp_r_eyeTransformPasser.squashSwitch', 1.0)


    if utils.data.get('bLatticeEyes') == True:
        ssLattices = utils.data.get('ssEyeLattices')
        ssEyeMeshes = utils.data.get('ssEyeMeshes')
        for s,sSide in enumerate(['l','t']):
            for sM in ssEyeMeshes[s]:
                sLattice, sBaseLattice = ssLattices[s]
                sLatDeformer, _sLat, _sLatBase = cmds.lattice(sM, divisions=(2, 3, 2), ldv=(2, 2, 2))
                cmds.connectAttr('%sShape.latticeOutput' % sLattice, '%s.deformedLatticePoints' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLattice, '%s.deformedLatticeMatrix' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sBaseLattice, '%s.baseLatticeMatrix' % sLatDeformer, f=True)
                cmds.setAttr('%s.outsideLattice' % sLatDeformer, 1)
                cmds.delete(_sLat, _sLatBase)
                deformers.makeNotExport(sLatDeformer)

dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls6.exportSliderBps



@builderTools.addToBuild(iOrder=89, dButtons=dButtons)
def parallelAttachTransforms(sScaleJoint='jnt_m_headMain', sDefaultAttachMesh=[], bReorderDeformers=True):

    if sDefaultAttachMesh:
        sDefaultAttachMesh = utils.toList(sDefaultAttachMesh)[0]
    else:
        sDefaultAttachMesh = None

    ctrls6.parallelAttachTransforms(sDefaultAttachMesh, sScaleJoint, bReorderDeformers=bReorderDeformers)


    # dButtons = {}
kLashesBpGrp = '_grp_m_lashesBps'
kLashesBpFileName = 'faceBlueprintsLashes.ma'


def recordLashesSiblings(_uiArgs=None):
    sSiblings = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.lashesSibling' % sT) and '_l_' in sT]
    dPoses = {}
    for sT in sSiblings:
        for sA in ['t','r','s']:
            sAttr = '%s.%s' % (sT,sA)
            dPoses[sAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dSiblingPoses'].setText(str(dPoses))


def recordLashesSiblingsRef(_uiArgs=None):
    sSiblings = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.lashesSiblingRef' % sT) and '_l_' in sT]
    dPoses = {}
    for sT in sSiblings:
        for sA in ['t','r']:
            sAttr = '%s.%s' % (sT,sA)
            dPoses[sAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dRefSiblingPoses'].setText(str(dPoses))



def bindLashes(bRef):

    sSelBefore = cmds.ls(sl=True)
    sJoints = [sJ for sJ in cmds.ls('jnt_?_lashesBot_*', et='joint') if not sJ.endswith('_ref')]
    sJoints += [sJ for sJ in cmds.ls('jnt_?_lashesTop_*', et='joint') if not sJ.endswith('_ref')]
    sMeshes = cmds.ls(sl=True)
    for sMesh in sMeshes:
        if bRef:
            sSkinCluster = 'skinCluster__%s__LASH' % sMesh
            sJoints = ['jnt_m_faceZero'] + sJoints
        else:
            sSkinCluster = 'skinCluster__%s' % sMesh

        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sName=sSkinCluster,
                               sInfluences=sJoints,
                               bAlwaysAddDefaultWeights=True)
            deformers.reorderDeformer(sSkinCluster, ['skinCluster__%s__POST' % sMesh], sMesh)


        else:
            deformers.addInfluences(sSkinCluster, sJoints)

    if bRef:
        sDefaultSkinCluster = 'skinCluster__%s' % sMesh
        if not cmds.objExists(sDefaultSkinCluster):
            cmds.confirmDialog(m='Joints got bound to "%s", however you need to create "%s", which is transferring default skincluster from body' %
                                 (sSkinCluster, sDefaultSkinCluster))

    if sSelBefore:
        cmds.select(sSelBefore)




def selectSiblings():
    cmds.select(cmds.ls('*LashSibling*', et='transform'))



def generateNewLashesSibling():
    cBlink = ctrls6.ctrlFromName('blink_l_ctrl')
    iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % cBlink.sPasser) * 100),
                int(cmds.getAttr('%s.blendCurveTop' % cBlink.sPasser) * 100)]

    dSiblings = getLashesSiblingsInfo()

    dSiblings['bot.%d' % iBotTops[0]] = {}
    dSiblings['top.%d' % iBotTops[1]] = {}

    createLashesSiblingsSetup(dSiblings)



def createLashesSiblingsSetup(dSiblings, _bBlendLastToZero=False):

    dSiblings['bot.000'] = {}
    dSiblings['top.000'] = {}

    print ('dSibling keys: ', dSiblings.keys())
    sNames = ['inner', 'mid', 'outer']
    dSiblingTranslates = defaultdict(list)
    dSiblingRotates = defaultdict(list)
    dSiblingScales = defaultdict(list)
    for s,sSide in enumerate(['l','r']):
        for sKey, dPoses in dSiblings.items():
            sPart, sPos = sKey.split('.')
            iDriverValue = int(sPos)
            for sName in sNames:
                cCtrl = ctrls6.ctrlFromName('%sLashes%s_%s_ctrl' % (sName, utils.getFirstLetterUpperCase(sPart), sSide))
                sPose = cCtrl.getOffsetByName('pose')
                sSign = 'p' if iDriverValue >= 0 else 'n'
                sSibling = 'grp_%s_%s_lashSibling_%s_%s%03d' % (sSide, sName, sPart, sSign, abs(iDriverValue))
                if not cmds.objExists(sSibling):
                    cmds.createNode('transform', n=sSibling, p=cCtrl.sSlider)
                    xforms.matchXform(sPose, sSibling)
                    fValues = dPoses.get(sName, [(0,0,0), (0,0,0), (1,1,1)])
                    cmds.setAttr('%s.t' % sSibling, *fValues[0])
                    cmds.setAttr('%s.r' % sSibling, *fValues[1])
                    cmds.setAttr('%s.s' % sSibling, *fValues[2])
                dSiblingTranslates['%s.%s' % (sPose, sPart)].append(('%s.t' % sSibling, iDriverValue))
                dSiblingRotates['%s.%s' % (sPose, sPart)].append(('%s.r' % sSibling, iDriverValue))
                dSiblingScales['%s.%s' % (sPose, sPart)].append((nodes.createVectorAdditionNode(['%s.s' % sSibling, [-1,-1,-1]]), iDriverValue))


    for sOutA, dData in [('t', dSiblingTranslates),
                         ('r', dSiblingRotates),
                         ('s', dSiblingScales)]:

        for sPosePart, xValues in dData.items():
            sPose, sPart = sPosePart.split('.')
            xValues = sorted(xValues, key=lambda a:a[1])
            sSide = utils.getSide(sPose)
            sDriverAttr = 'grp_%s_blinkPasser.blendCurve%s' % (sSide, utils.getFirstLetterUpperCase(sPart))

            for i, xV in enumerate(xValues):
                sSiblingAttr = xV[0]
                fDriverValue = xV[1] * 0.01
                if i == 0:
                    sPrevSiblingAttr = [0,0,0]
                    fPrevDriverValue = -1.0
                else:
                    sPrevSiblingAttr = xValues[i-1][0]
                    fPrevDriverValue = xValues[i-1][1] * 0.01

                sRange = nodes.createRangeNode(sDriverAttr, fPrevDriverValue, fDriverValue, sPrevSiblingAttr, sSiblingAttr, bOutRangeIsVector=True)
                sOutput = nodes.createConditionNode(sDriverAttr, '<=', fDriverValue, sRange, [-55, -55, -55], bVector=True)
                if i == 0:
                    if sOutA == 's':
                        nodes.createVectorAdditionNode([sOutput, [1,1,1]], sTarget='%s.%s' % (sPose, sOutA), bForce=True)
                    else:
                        cmds.connectAttr(sOutput, '%s.%s' % (sPose, sOutA), force=True)
                else:
                    cmds.connectAttr(sOutput, '%s.colorIfFalse' % sPrevCondition)
                sPrevCondition = sOutput.split('.')[0]

            if _bBlendLastToZero:
                sLastRange = nodes.createRangeNode(sDriverAttr, fDriverValue, 1, sSiblingAttr, [0,0,0], bOutRangeIsVector=True)
                cmds.connectAttr(sLastRange, '%s.colorIfFalse' % sPrevCondition)
            else:
                cmds.connectAttr(sSiblingAttr, '%s.colorIfFalse' % sPrevCondition)


def getLashesSiblingsInfo():
    dSiblings = defaultdict(dict)
    for p,sPart in enumerate(['bot','top']):
        for sName in ['inner', 'mid', 'outer']:

            sSiblings = cmds.ls('grp_l_%s_lashSibling_%s_????' % (sName, sPart), et='transform')  # grp_l_mid_lashSibling_top_040
            for sSibling in sSiblings:
                sDriverValue = sSibling.split('_')[-1]
                iDriverValue = int(sDriverValue[1:]) * (-1 if sDriverValue[0] == 'n' else 1)
                if iDriverValue != 0:
                    dSiblings['%s.%d' % (sPart, iDriverValue)][sName] = [cmds.getAttr('%s.t' % sSibling)[0], cmds.getAttr('%s.r' % sSibling)[0], cmds.getAttr('%s.s' % sSibling)[0]]

    return dict(dSiblings)



def fillLashesSibling(_uiArgs=None):
    dSiblings = getLashesSiblingsInfo()
    _uiArgs['dSiblings'].setText(str(dSiblings))




dButtons = OrderedDict()
dButtons['Create Top Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesTop', kLashesBpGrp)
dButtons['Create Bot Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesBot', kLashesBpGrp)
dButtons['Create Top End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesTopEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Create Bot End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesBotEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Select Siblings'] = selectSiblings
dButtons['Fill Siblings'] = fillLashesSibling
dButtons['Generate Siblings at Current Lid Pose'] = generateNewLashesSibling
# dButtons['Fill Siblings Ref'] = recordLashesSiblingsRef # not sure what that was about..
dButtons['BIND Eyelashes (selected)'] = bindLashes
dButtons['- Export Lashes BPs -'] = lambda: exportBps(kLashesBpFileName, kLashesBpGrp)





@builderTools.addToBuild(iOrder=55, dButtons=dButtons, bDisableByDefault=True)
def lashesSetup_splineLids(sAttachMesh=[], sParentJoint='jnt_m_headMain', bDoBot=True, bDoTop=True, dSiblings={}, iJointStep=1, bCtrlVisDefault=False):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sGrp = cmds.createNode('transform', n='grp_lashes', p='modules')

    ssBpCurves = [['bpCurve_l_lashesBot', 'bpCurve_l_lashesTop'], ['bpCurve_r_lashesBot', 'bpCurve_r_lashesTop']]
    ssBpCurvesEnd = [['bpCurve_l_lashesBotEnd', 'bpCurve_l_lashesTopEnd'], ['bpCurve_r_lashesBotEnd', 'bpCurve_r_lashesTopEnd']]

    aaPoints = [], []
    aaClosestIds = [], []
    bDoes = [bDoBot, bDoTop]
    for s,sSide in enumerate(['l', 'r']):

        for p, sBpCurve in enumerate(ssBpCurves[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)
        for p, sBpCurve in enumerate(ssBpCurvesEnd[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)

        for p,sPart in enumerate(['bot','top']):
            if bDoes[p]:
                aPoints = patch.patchFromName(ssBpCurves[s][p]).getAllPoints()
                aIndices = np.arange(len(aPoints), step=iJointStep)
                aIndices[-1] = len(aPoints)-1
                aPoints = aPoints[aIndices]
                aaPoints[s].append(aPoints)
                aaClosestIds[s].append(xforms.getClosestIdsFromPoints(sAttachMesh, aPoints))
            else:
                aaPoints[s].append([])
                aaClosestIds[s].append([])

    aAllClosestIds = np.array(utils.flattenedList(aaClosestIds))

    sAllLocs = constraints.parallelTransformAsDeformers2(sAttachMesh, aAllClosestIds, sParent=sGrp,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint, #bConnectEnvelopes=False,
                                                     sDeformers=['skinCluster__%s' % sAttachMesh])#, 'skinCluster__%s__BEND' % sAttachMesh])
    aAllLocs = np.array(sAllLocs)


    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'lashesCtrlVis', bDefaultValue=bCtrlVisDefault)
    sssJoints = [[[], []], [[], []]]
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        fEyeJointRadius = cmds.getAttr('jnt_%s_eyeMain.radius' % sSide)
        for p, sPart in enumerate(['bot', 'top']):
            if bDoes[p]:
                sCurveEnd = cmds.duplicate(ssBpCurvesEnd[s][p], n=utils.replaceStringStart(ssBpCurvesEnd[s][p], 'bpCurve_', 'curve_'))[0]
                curves.fixShapeName(sCurveEnd)

                cmds.parent(sCurveEnd, sGrp)

                aClosestIds = aaClosestIds[s][p]
                aInds = utils.findOneArrayInAnother(aAllClosestIds, aClosestIds)
                sLocs = aAllLocs[aInds]
                aPoints = aaPoints[s][p]
                aPercs = curves.getPercsFromPoints(ssBpCurves[s][p], aPoints)
                aParams = curves.getParamsFromPercs(sCurveEnd, aPercs)
                aEndPoints = curves.getPointsFromParams(sCurveEnd, aParams, bReturnNumpy=True)
                for j,sL in enumerate(sLocs):
                    sJ = 'jnt_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j)
                    if cmds.objExists(sJ):
                        cmds.parent(sJ, sParentJoint)
                        cmds.setAttr('%s.v' % sJ, True)
                        xforms.resetJoint(sJ)
                    else:
                        cmds.createNode('joint', n=sJ, p=sParentJoint)
                    cmds.move(aPoints[j,0], aPoints[j,1], aPoints[j,2], sJ, a=True, ws=True)
                    sssJoints[s][p].append(sJ)
                    sJEnd = cmds.createNode('joint', n='jnt_%s_lashes%sEnd_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p=sJ)
                    cmds.setAttr('%s.radius' % sJ, fEyeJointRadius*0.15)
                    cmds.setAttr('%s.radius' % sJEnd, fEyeJointRadius*0.15)

                    fLength = np.linalg.norm(aEndPoints[j]-aPoints[j])

                    cmds.setAttr('%s.tx' % sJEnd, fLength*fSideMultipl)

                    constraints.matrixParentConstraint(sL, sJ, skipRotate=['x','y','z'], mo=True)


                for j, sJ in enumerate(sssJoints[s][p]):
                    _, sAimPos = curves.createPointInfoNode(sCurveEnd, fParam=aParams[j])

                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[fSideMultipl, 0, 0])
                    nodes.createPointByMatrixNode(sAimPos, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                    jUp = j+1 if j == 0 else j-1
                    sConnectionJ = cmds.listConnections('%s.t' % sssJoints[s][p][j], s=True, d=False, p=True)[0]
                    sConnectionUpJ = cmds.listConnections('%s.t' % sssJoints[s][p][jUp], s=True, d=False, p=True)[0]
                    nodes.createVectorAdditionNode([sConnectionUpJ, sConnectionJ], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)




                aCtrlPercs = np.array([0, 0.5, 1], dtype='float64')
                fCtrlPoints = curves.getPointsFromPercs(sCurveEnd, aCtrlPercs)
                aLocInds = np.array(aCtrlPercs*(len(sLocs)-1), dtype=int)
                sInfluences = []
                for c,sName in enumerate(['inner', 'mid', 'outer']):

                    cC = ctrls6.create('%sLashes%s' % (sName, utils.getFirstLetterUpperCase(sPart)), sSide, sParent='ctrls', sAttrs=['t','r'],
                                      sMatch='jnt_%s_eyeMain' % sSide, fMatchPos=fCtrlPoints[c], iColorIndex=2, sShape='sphere')
                    cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)
                    cC.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[3:]])
                    constraints.matrixParentConstraint(sLocs[aLocInds[c]], cC.sPasser, mo=True)

                    constraints.matrixParentConstraint(cC.sCtrl, cC.sOut, sJumpOverTransforms=[cC.sExtraMove, cC.sPasser], skipScale=['x','y','z'])
                    cC.sJoint = cmds.createNode('joint', p=cC.sOut, n='jnt_%s_%sLashes%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)))
                    cmds.setAttr('%s.radius' % cC.sJoint, fEyeJointRadius * 0.35)

                    cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                    sInfluences.append(cC.sJoint)

                    cC.appendOffsetGroup('pose')


                cmds.skinCluster(sCurveEnd, sInfluences, tsb=True)


    createLashesSiblingsSetup(dSiblings)



    deformers.resetJointReferences(utils.flattenedList(sssJoints))











def selectSiblings():
    cmds.select(cmds.ls('*LashSibling*', et='transform'))


dButtons = OrderedDict()
dButtons['Create Top Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesTop', kLashesBpGrp)
dButtons['Create Bot Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesBot', kLashesBpGrp)
dButtons['Create Top End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesTopEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Create Bot End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesBotEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Select Siblings'] = selectSiblings
dButtons['Fill Siblings'] = recordLashesSiblings
# dButtons['Fill Siblings Ref'] = recordLashesSiblingsRef # not sure what that was about..
dButtons['BIND Eyelashes (selected)'] = bindLashes
dButtons['- Export Lashes BPs -'] = lambda: exportBps(kLashesBpFileName, kLashesBpGrp)



# ref stuff might not work anymore!  we'll have to create a separate function for that
@builderTools.addToBuild(iOrder=65, dButtons=dButtons, bDisableByDefault=True)
def lashesSetup_blendShapeLids(sAttachMesh=[], sParentJoint='jnt_m_headMain', bDoBot=True, bDoTop=True, dSiblingPoses={}, dRefSiblingPoses={}, iJointStep=1, bCtrlVisDefault=False):
    '''
    NOT WORKING YET! NEEDS TO BE CLEANED UP
    '''

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sGrp = cmds.createNode('transform', n='grp_lashes', p='modules')

    ssBpCurves = [['bpCurve_l_lashesBot', 'bpCurve_l_lashesTop'], ['bpCurve_r_lashesBot', 'bpCurve_r_lashesTop']]
    ssBpCurvesEnd = [['bpCurve_l_lashesBotEnd', 'bpCurve_l_lashesTopEnd'], ['bpCurve_r_lashesBotEnd', 'bpCurve_r_lashesTopEnd']]

    aaPoints = [], []
    aaClosestIds = [], []
    bDoes = [bDoBot, bDoTop]
    for s,sSide in enumerate(['l', 'r']):

        for p, sBpCurve in enumerate(ssBpCurves[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)
        for p, sBpCurve in enumerate(ssBpCurvesEnd[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)

        for p,sPart in enumerate(['bot','top']):
            if bDoes[p]:
                aPoints = patch.patchFromName(ssBpCurves[s][p]).getAllPoints()
                aIndices = np.arange(len(aPoints), step=iJointStep)
                aIndices[-1] = len(aPoints)-1
                aPoints = aPoints[aIndices]
                aaPoints[s].append(aPoints)
                aaClosestIds[s].append(xforms.getClosestIdsFromPoints(sAttachMesh, aPoints))
            else:
                aaPoints[s].append([])
                aaClosestIds[s].append([])

    aAllClosestIds = np.array(utils.flattenedList(aaClosestIds))

    sAllLocs = constraints.parallelTransformAsDeformers2(sAttachMesh, aAllClosestIds, sParent=sGrp,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint, #bConnectEnvelopes=False,
                                                     sDeformers=['skinCluster__%s' % sAttachMesh])#, 'skinCluster__%s__BEND' % sAttachMesh])
    aAllLocs = np.array(sAllLocs)


    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'lashesCtrlVis', bDefaultValue=bCtrlVisDefault)
    sssJoints = [[[], []], [[], []]]
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        cBlink = ctrls6.ctrlFromName('blink%s_ctrl' % utils.sSides3[s])
        cExtraBlinks = [ctrls6.ctrlFromName('lidBot%s_ctrl' % utils.sSides3[s]), ctrls6.ctrlFromName('lidTop%s_ctrl' % utils.sSides3[s])]
        cLookAt = ctrls6.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s])
        sSwitchedLookY = nodes.createMultiplyNode('%s.lidFollow' % cLookAt.sCtrl, 'grp_%s_eyesLookAtPasser.lookVert' % sSide)

        fEyeJointRadius = cmds.getAttr('jnt_%s_eyeMain.radius' % sSide)
        for p, sPart in enumerate(['bot', 'top']):
            if bDoes[p]:
                sCurveEnd = cmds.duplicate(ssBpCurvesEnd[s][p], n=utils.replaceStringStart(ssBpCurvesEnd[s][p], 'bpCurve_', 'curve_'))[0]
                curves.fixShapeName(sCurveEnd)

                cmds.parent(sCurveEnd, sGrp)

                aClosestIds = aaClosestIds[s][p]
                aInds = utils.findOneArrayInAnother(aAllClosestIds, aClosestIds)
                sLocs = aAllLocs[aInds]
                aPoints = aaPoints[s][p]
                aPercs = curves.getPercsFromPoints(ssBpCurves[s][p], aPoints)
                aParams = curves.getParamsFromPercs(sCurveEnd, aPercs)
                aEndPoints = curves.getPointsFromParams(sCurveEnd, aParams, bReturnNumpy=True)
                for j,sL in enumerate(sLocs):
                    sJ = 'jnt_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j)
                    if cmds.objExists(sJ):
                        cmds.parent(sJ, sParentJoint)
                        cmds.setAttr('%s.v' % sJ, True)
                        xforms.resetJoint(sJ)
                    else:
                        cmds.createNode('joint', n=sJ, p=sParentJoint)
                    cmds.move(aPoints[j,0], aPoints[j,1], aPoints[j,2], sJ, a=True, ws=True)
                    sssJoints[s][p].append(sJ)
                    sJEnd = cmds.createNode('joint', n='jnt_%s_lashes%sEnd_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p=sJ)
                    cmds.setAttr('%s.radius' % sJ, fEyeJointRadius*0.15)
                    cmds.setAttr('%s.radius' % sJEnd, fEyeJointRadius*0.15)

                    fLength = np.linalg.norm(aEndPoints[j]-aPoints[j])

                    cmds.setAttr('%s.tx' % sJEnd, fLength*fSideMultipl)

                    constraints.matrixParentConstraint(sL, sJ, skipRotate=['x','y','z'], mo=True)


                for j, sJ in enumerate(sssJoints[s][p]):
                    _, sAimPos = curves.createPointInfoNode(sCurveEnd, fParam=aParams[j])

                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[fSideMultipl, 0, 0])
                    nodes.createPointByMatrixNode(sAimPos, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                    jUp = j+1 if j == 0 else j-1
                    sConnectionJ = cmds.listConnections('%s.t' % sssJoints[s][p][j], s=True, d=False, p=True)[0]
                    sConnectionUpJ = cmds.listConnections('%s.t' % sssJoints[s][p][jUp], s=True, d=False, p=True)[0]
                    nodes.createVectorAdditionNode([sConnectionUpJ, sConnectionJ], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)




                aCtrlPercs = np.array([0, 0.5, 1], dtype='float64')
                fCtrlPoints = curves.getPointsFromPercs(sCurveEnd, aCtrlPercs)
                aLocInds = np.array(aCtrlPercs*(len(sLocs)-1), dtype=int)
                sInfluences = []
                for c,sName in enumerate(['inner', 'mid', 'outer']):

                    cC = ctrls6.create('%sLashes%s' % (sName, utils.getFirstLetterUpperCase(sPart)), sSide, sParent='ctrls', sAttrs=['t','r'],
                                      sMatch='jnt_%s_eyeMain' % sSide, fMatchPos=fCtrlPoints[c], iColorIndex=2, sShape='sphere')
                    cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)
                    cC.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[3:]])
                    constraints.matrixParentConstraint(sLocs[aLocInds[c]], cC.sPasser, mo=True)

                    constraints.matrixParentConstraint(cC.sCtrl, cC.sOut, sJumpOverTransforms=[cC.sExtraMove, cC.sPasser], skipScale=['x','y','z'])
                    cC.sJoint = cmds.createNode('joint', p=cC.sOut, n='jnt_%s_%sLashes%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)))
                    cmds.setAttr('%s.radius' % cC.sJoint, fEyeJointRadius * 0.35)

                    cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                    sInfluences.append(cC.sJoint)

                    sPoseOffset = cC.appendOffsetGroup('pose')

                    sSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingBlink%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingWideMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingWide%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingExtraDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraDown%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingExtraUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraUp%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingFollowDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowDown%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingFollowUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowUp%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblings = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp, sSiblingFollowDown, sSiblingFollowUp]
                    [cmds.addAttr(sT, ln='lashesSibling') for sT in sSiblings]
                    for sA in ['t', 'r', 's']:
                        fDefault = [1,1,1] if sA == 's' else [0,0,0]
                        sBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sSiblingBlinkMain, sA), bOutRangeIsVector=True)
                        sBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sSiblingWideMain, sA), bOutRangeIsVector=True)
                        sBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                        sBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)
                        sBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sSiblingFollowDown, sA), bOutRangeIsVector=True)
                        sBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sSiblingFollowUp, sA), bOutRangeIsVector=True)
                        sAllSiblings = [sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp]
                        if sA in ['t','r']:
                            nodes.createVectorAdditionNode(sAllSiblings, sTarget='%s.%s' % (sPoseOffset, sA))
                        else:
                            nodes.createMultiplyArrayNode(sAllSiblings, bVector=True, sTarget='%s.%s' % (cC.sOut, sA))

                    # if sSide == 'r':
                    #     cmds.setAttr('%s.s' % sSliderOffset, 1, -1, 1)
                cmds.skinCluster(sCurveEnd, sInfluences, tsb=True)

        for sAttr, fValues in list(dSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if cmds.objExists(sAttrSide):
                cmds.setAttr(sAttrSide, *fValues)

        for sAttr, fValues in list(dRefSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if cmds.objExists(sAttrSide):
                cmds.setAttr(sAttrSide, *fValues)

    deformers.resetJointReferences(utils.flattenedList(sssJoints))



def openShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)

    cmds.file(sFullPath, open=True, force=True)


def saveAsShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    cmds.file(rename=sFullPath)
    cmds.file(force=True, type='mayaAscii', save=True)


def referenceShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)

    utils.importMayaFiles(sFullPath, sNamespace='shapes', bReference=True)



dButtons = OrderedDict()
dButtons['open shape editor file'] = openShapeEditorFile
dButtons['saveAs shape editor file'] = saveAsShapeEditorFile
dButtons['reference shape editor file'] = referenceShapeEditorFile
dButtons['- Export *Slider* BPs -'] = ctrls6.exportSliderBps


@builderTools.addToBuild(iOrder=62, dButtons=dButtons, bCanGetDuplicated=True)
def importBlendShapeFile(sFile='blendShapes.ma', sBlendShape='', bRemoveReferenceWhenDone=True, sSuffix='', bApplyInnerBlinkValues=True):
    utils.reload2(kangarooShapeEditorTools)
    kangarooShapeEditorTools.importBlendShapeFile(sFile=sFile, sBlendShape=sBlendShape, bRemoveReferenceWhenDone=bRemoveReferenceWhenDone, sSuffix=sSuffix, report=report, bApplyInnerBlinkValues=bApplyInnerBlinkValues)



def selectMapMeshesFromMesh():
    sSel = cmds.ls(sl=True)
    sSelect = []
    for sMesh in sSel:
        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            report.report.addLogText('%s Map not exists: ' % sMapMesh)
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)
        sSelect.append(sMapMesh)
    cmds.select(sSelect)


@builderTools.addToBuild(iOrder=61, dButtons={'Create Or Select Map Meshes from Selection':selectMapMeshesFromMesh})
def importMapMeshes(sDefaultMeshes=[]):
    '''
    map meshes per mesh is meshname__MAPS
    on those the clusters are named MAP__meshName__myName
    and those are exported as meshname__myName.map
    '''
    for sMesh in sDefaultMeshes:
        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)


    sMapFolder = assets.assetManager.getCurrentVersionPath(sSubPath='maps')
    if not os.path.exists(sMapFolder):
        return
    sMapFiles = os.listdir(sMapFolder)
    for sFile in sMapFiles:
        sSplits = sFile.split('.')[0].split('__')
        if len(sSplits) != 2:
            report.report.addLogText('%s does not have the right name standard. Skipping..' % sFile)
            continue

        report.report.addLogText('importing map: %s' % sFile)
        sMesh, sMapName = sSplits

        with open(os.path.join(sMapFolder, sFile), 'rb') as handle:
            fWeights = pickle.load(handle)

        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)
        sCluster = 'MAP__%s__%s' % (sMesh, sMapName)
        if not cmds.objExists(sCluster):
            _, sTempHandle = cmds.cluster(sMapMesh, n=sCluster)
            nodes.deleteConnectionsAndItself2(cmds.ls(sTempHandle, dag=True))
        cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, len(fWeights)-1), *fWeights)



# def createMouthPivotCurve():
#     sCurveInner, sLocsInner = 'bpCurve_m_lipsInner', ['locA_m_lipsInner', 'locB_m_lipsInner']
#     sCurveOuter, sLocsOuter = 'bpCurve_m_lipsOuter', ['locA_m_lipsOuter', 'locB_m_lipsOuter']
#     sPivotCurve = cmds.duplicate(sCurveOuter, n='bpCurve_m_lipsPivot')[0]
#     sLocsPivots = [cmds.rename('%s|%s' % (sPivotCurve, sLocsOuter[0]), 'locA_m_lipsPivot'),
#                    cmds.rename('%s|%s' % (sPivotCurve, sLocsOuter[1]), 'locB_m_lipsPivot')]
#
#     # cmds.blendShape(sCurveOuter, sCurveInner, w=[0,0.5])
#     cmds.delete(cmds.pointConstraint(sLocsInner[0], sLocsOuter[0], sLocsPivots[0]))
#     cmds.delete(cmds.pointConstraint(sLocsInner[1], sLocsOuter[1], sLocsPivots[1]))


kMouthBpGroupName = '_grp_m_mouthBps'
kMouthBpFileName = 'faceBlueprintsMouth.ma'


dButtons = OrderedDict()
dCurveHelpA = {'?':['Select the most inner vertex loop, and then place the locators as needed,'\
                                                        '\nto indicate splitting point between bottom and top.'
                                                        '\nThe curve will be broken up at a random point, but that\'s ok. Ideally the '\
                                                        '\nbottom and top part of the curves will be a close together as possible,'\
                                                        '\nbut that\'s depending on the model.'
                                                        '\nIMPORTANT: if at the front the top lip part is lower then the bottom lip part, '\
                                                        '\nyou need to set bFlipInnerBpCurves to True', 'mouthInnerCurves.JPG']}

dCurveHelpB = {'?':['Select the row for the outer curve. This is mainly for the control positions', 'mouthOuterCurves.JPG']}

dButtons['Create Inner Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsInner', kMouthBpGroupName, fDirection=(-1, 0, 0))
dButtons['Create Inner Curves and Locators'].dSideButtons = dCurveHelpA
dButtons['Create Outer Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsOuter', kMouthBpGroupName, fDirection=(-1, 0, 0))
dButtons['Create Outer Curves and Locators'].dSideButtons = dCurveHelpB
# dButtons['Create Pivot Curve'] = createMouthPivotCurve



def _attachAndSelectJoints(sJointsString):
    sJoints = cmds.ls(sJointsString, et='joint')
    for sObj in cmds.ls(sl=True):
        sSkinCluster = deformers.convertChooseSkinCluster(None, sObj)
        deformers.addInfluences(sSkinCluster, sJoints)
    cmds.select(sJoints)




def createMouthSlidingPlane():
    sPlane = cmds.nurbsPlane(name='bpNurbs_l_cornerSlidePlane', w=2.0, u=3, v=3)[0]
    cmds.parent(sPlane, xforms.createOrReturnTopGroup(kMouthBpGroupName))

dButtons['Create Corner Sliding Planes'] = createMouthSlidingPlane
createMouthSlidingPlane.dSideButtons = {'?':['This should be roughtly the shape of the teeth. '\
                                 '\nIt\'s to have the corner controls move in a not so linear way.', 'slidingPlane.jpg']}
createMouthSlidingPlane.dSideButtons = {'?':['This should be roughtly the shape of the teeth. '\
                                 '\nIt\'s to have the corner controls move in a not so linear way.', 'slidingPlane.jpg']}

dButtons['Create Mouth Pivot'] = lambda: createMatrixCtrlFromTransform('bp_m_mouthPivot', kMouthBpGroupName, sTransform='jnt_m_headMain')




kkDefaultPoses = {'cornerOut':{'sCtrlDriverAttr':'lipsCorner_l_ctrl.tx', 'fCtrlDriverValue':1.0, 'dPose':{}},
                  'cornerIn':{'sCtrlDriverAttr':'lipsCorner_l_ctrl.tx', 'fCtrlDriverValue':-1.0, 'dPose':{}},
                 'cornerUp':{'sCtrlDriverAttr':'lipsCorner_l_ctrl.ty', 'fCtrlDriverValue':1.0, 'dPose':{}},
                 'cornerDown':{'sCtrlDriverAttr':'lipsCorner_l_ctrl.ty', 'fCtrlDriverValue':-1.0, 'dPose':{}},
                 'jawOpen':{'sCtrlDriverAttr':'jaw_ctrl.rz', 'fCtrlDriverValue':-20.0, 'dPose':{}},
                 'funnel':{'sCtrlDriverAttr':'mouth_ctrl.tz', 'fCtrlDriverValue':1.0, 'dPose':{}},
                 'mouthClose':{'sCtrlDriverAttr':'mouth_ctrl.mouthClose', 'fCtrlDriverValue':1.0, 'dPose':{}, 'fJawOpenValue':-10},
                 'botRollIn': {'sCtrlDriverAttr': 'mouthBot_ctrl.rx', 'fCtrlDriverValue': -45, 'dPose': {}},
                 'botRollOut': {'sCtrlDriverAttr': 'mouthBot_ctrl.rx', 'fCtrlDriverValue': 45, 'dPose': {}},
                 'topRollIn': {'sCtrlDriverAttr': 'mouthTop_ctrl.rx', 'fCtrlDriverValue': 45, 'dPose': {}},
                 'topRollOut': {'sCtrlDriverAttr': 'mouthTop_ctrl.rx', 'fCtrlDriverValue': -45, 'dPose': {}},
                 'lipPress': {'sCtrlDriverAttr': 'mouth_ctrl.tz', 'fCtrlDriverValue': -1.0, 'dPose': {}}}

kAllPoseKeys = ['jawOpen',  'cornerOut', 'cornerIn', 'cornerUp', 'cornerDown', 'funnel', 'lipPress', 'mouthClose', 'botRollIn', 'topRollIn', 'botRollOut', 'topRollOut']
kAllPoseKeyCombos = ['cornerOut_cornerUp', 'cornerOut_cornerDown', 'cornerIn_cornerUp', 'cornerIn_cornerDown']
dSetPosesMenu = OrderedDict()


def getMouthPoseCtrls():
    ccPoseCtrls = []
    for p, sPart in enumerate(['bot', 'top']):
        sPartUpper = utils.getFirstLetterUpperCase(sPart)
        sPartCtrls = cmds.ls('lips%s_?_ctrl' % sPartUpper) + cmds.ls('lips%s_ctrl' % sPartUpper) + cmds.ls('detail%s???_?_ctrl' % sPartUpper) + \
                     ['mouth%s_ctrl' % sPartUpper,
                      'cornerTangent%s_l_ctrl' % sPartUpper,
                      'cornerTangent%s_r_ctrl' % sPartUpper,
                      'lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']
        ccPoseCtrls.append([ctrls6.ctrlFromName(sC) for sC in sPartCtrls])
    return ccPoseCtrls


def connectFaceCtrlPosesAllDims(ddPoses):
    connectFaceCtrlPoses(ddPoses, -1)

def connectFaceCtrlPosesJustMain(ddPoses):
    connectFaceCtrlPoses(ddPoses, 1)


def connectFaceCtrlPoses(ddPoses, iMaxDim=-1):
    ddPoseDriverDatas = utils.data.get('ddFaceCtrlDriverDatas')
    
    ccPoseCtrls = getMouthPoseCtrls()

    sCombos = [sPoseKey for sPoseKey in ddPoseDriverDatas.keys()] + kAllPoseKeyCombos

    dProducts = {}
    for sCombo in sCombos: # in ddPoseDriverDatas.items():
        if sCombo not in ddPoses:
            continue
        
        if iMaxDim != -1:
            iDim = sCombo.count('_') + 1
            if iDim > iMaxDim:
                continue

        dPose = ddPoses[sCombo]['dPose']

        sPoseKeys = sCombo.split('_')

        dPoseDriverDatas = [ddPoseDriverDatas[sPoseKey] for sPoseKey in sPoseKeys]
        
        sParts = ['all']
        for dData in dPoseDriverDatas:
            if dData['bBotTop']:
                sParts = ['bot', 'top']
                
        sDriverCtrlAttrs = utils.flattenedList([ddPoseDriverDatas[sPoseKey].get('sCtrlDriverAttrs', []) for sPoseKey in sPoseKeys])
        sDriverCtrlAttrs = [utils.getLongAttrName(sAttr) for sAttr in sDriverCtrlAttrs]

        sDriverCtrls = list(set([sAttr.split('.')[0] for sAttr in sDriverCtrlAttrs]))
        for p, sPart in enumerate(sParts):
            dDrivers = {}
            dDrivers['l'] = nodes.createMinimumNode([dData['driver_%s' % sPart]['driver_l'] for dData in dPoseDriverDatas])
            dDrivers['r'] = nodes.createMinimumNode([dData['driver_%s' % sPart]['driver_r'] for dData in dPoseDriverDatas])
            dDrivers['m'] = nodes.createMinimumNode([dData['driver_%s' % sPart]['driver_m'] for dData in dPoseDriverDatas])

            cPoseCtrls = ccPoseCtrls[p] if len(sParts) == 2 else list(set(ccPoseCtrls[0] + ccPoseCtrls[1]))
            for cC in cPoseCtrls:
                if cC.sCtrl in sDriverCtrls:
                    continue
                sOffsetGrp = cC.getOffsetByName('poses')
                dP = dPose.get(cC.sCtrl, {})
                if dP:
                    for sA, fV in list(dP.items()):
                        sA = utils.dLongAttributes.get(sA, sA)
                        sAttr = '%s.%s' % (cC.sCtrl, sA)
                        
                        if sAttr in sDriverCtrlAttrs:
                            break
                        
                        sOffsetAttr = '%s.%s' % (sOffsetGrp, sA)
                        if not cmds.objExists(sOffsetAttr):
                            continue
                        fDefaultValue = cmds.getAttr(sAttr)
                        
                        if cmds.objExists(sOffsetAttr):
                            if sOffsetAttr not in dProducts:
                                dProducts[sOffsetAttr] = [[1.0, fDefaultValue]]
                            
                            fCornerFactor = 0.5 if cC.sCtrl.startswith('lipsCorner') else 1.0
                            utils.addStringAttr(dDrivers[cC.sSide].split('.')[0], 'faceCtrlDriverPoseKey', '%s___%s' % (sCombo, dDrivers[cC.sSide]))
                            dProducts[sOffsetAttr].append([dDrivers[cC.sSide], fV * fCornerFactor - fDefaultValue])
    
    for sOffsetAttr, xProducts in dProducts.items():
        nodes.createInfiniteDotProduct(xProducts, sTarget=sOffsetAttr, bForce=True)


# todo: add support for numbered lip ctrls
def disconnectFaceCtrlPoses(ddPoses):
    ddPoseDriverDatas = utils.data.get('ddFaceCtrlDriverDatas')
    
    ccPoseCtrls = getMouthPoseCtrls()
    for cC in ccPoseCtrls[0] + ccPoseCtrls[1]:
        sOffsetGrp = cC.getOffsetByName('poses')
        for sA in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']:
            
            sAttr = '%s.%s' % (sOffsetGrp, sA)
            print ('sAttr: ', sAttr)
            sConns = cmds.listConnections(sAttr, s=True, d=False, skipConversionNodes=True, c=True, p=True) or []
            
            for i in range(0, len(sConns), 2):
                cmds.disconnectAttr(sConns[i+1], sConns[i])
            
            if sA.startswith('s'):
                cmds.setAttr(sAttr, 1.0)
            else:
                cmds.setAttr(sAttr, 0.0)

dSetPosesMenu['disconnect poses'] = disconnectFaceCtrlPoses
dSetPosesMenu['connect poses'] = connectFaceCtrlPosesAllDims
dSetPosesMenu['connect poses (just main)'] = connectFaceCtrlPosesJustMain


def disableAllLipPush():
    for sCtrl in cmds.ls('lipsTop*ctrl', et='transform'):
        sAttr = '%s.lipPush' % sCtrl
        if cmds.objExists(sAttr):
            cmds.setAttr(sAttr, 0)


for sCombo in kAllPoseKeys + kAllPoseKeyCombos:
    def _fill(ddPoses, _uiArgs=None, _sCombo=sCombo):
        try:
            ddPoses = updateDdPoses(ddPoses)
            cCtrls = utils.flattenedList(getMouthPoseCtrls())
            dPose = {}
            for cC in cCtrls:
                sAttrs = list(utils._getAnimAttrsFromNode(cC.sCtrl).keys())
                dDefaultAttrs = eval(cmds.getAttr('%s.dDefaultAttrs' % cC.sCtrl))
                dObjPose = {}
                for sA in sAttrs:
                    sAttr = '%s.%s' % (cC.sCtrl,sA)
                    fValue = cmds.getAttr(sAttr)
                    if abs(fValue-dDefaultAttrs[sA]) > 0.0001:
                        dObjPose[sA] = fValue
                if dObjPose:
                    dPose[cC.sCtrl] = dObjPose
            if _sCombo not in ddPoses:
                ddPoses[_sCombo] = {}
            ddPoses[_sCombo]['dPose'] = dPose
            _uiArgs['ddPoses'].setText(str(ddPoses))
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        

    def _poseTo(ddPoses, _uiArgs=None, _sCombo=sCombo):
        disableAllLipPush()
        try:
            for sPoseKey in _sCombo.split('_'):
                ddPoses = updateDdPoses(ddPoses)
                if sPoseKey in ddPoses:
                    sCtrlDriverAttr = ddPoses[sPoseKey]['sCtrlDriverAttr']
                    cmds.setAttr(sCtrlDriverAttr, ddPoses[sPoseKey]['fCtrlDriverValue'])
                 
                    if utils.getSide(sCtrlDriverAttr) == 'l':
                        sOther = utils.getMirrorName(sCtrlDriverAttr)
                        cmds.setAttr(sOther, ddPoses[sPoseKey]['fCtrlDriverValue'])
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise

 
    def _setAttrsCtrls(ddPoses, _uiArgs=None, _sCombo=sCombo):
        try:
            ddPoses = updateDdPoses(ddPoses)
            for sPoseKey in _sCombo.split('_') + [_sCombo]:
                if sPoseKey in ddPoses:
                    ddPoseKeyPoses = ddPoses[sPoseKey]
                    if 'dPose' in ddPoseKeyPoses:
                        dPose = ddPoseKeyPoses['dPose']
                
                        # duplicated code in _animateCtrls
                        if '_' not in sPoseKey:  # make sre it's not a combo
                            sCtrlDriverAttrs = [ddPoses[sPoseKey]['sCtrlDriverAttr']]
                            fCtrlDriverValue = ddPoses[sPoseKey]['fCtrlDriverValue']
                            sMirroredDriverAttr = utils.getMirrorName(sCtrlDriverAttrs[0])
                            if sMirroredDriverAttr != sCtrlDriverAttrs[0] and cmds.objExists(sMirroredDriverAttr):
                                sCtrlDriverAttrs.append(sMirroredDriverAttr)
                            for sCtrlDriverAttr in sCtrlDriverAttrs:
                                sDriver, sDriverA = sCtrlDriverAttr.split('.')
                                dPose[sDriver] = {sDriverA:fCtrlDriverValue}
                                if utils.getSide(sCtrlDriverAttr) != 'm':
                                    dPose[sDriver] = {sDriverA:fCtrlDriverValue}
                        
                        for sCtrl, dAttrs in dPose.items():
                            for sA, fV in dAttrs.items():
                                cmds.setAttr('%s.%s' % (sCtrl,sA), fV)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise

    def _animateCtrls(ddPoses, _uiArgs=None, _sCombo=sCombo):
        try:
            disableAllLipPush()
            fMinTime = cmds.playbackOptions(q=True, minTime=True)
            fMaxTime = cmds.playbackOptions(q=True, maxTime=True)
            for sPoseKey in _sCombo.split('_') + [_sCombo]:
                if sPoseKey in ddPoses:
                    ddPoseKeyPoses = ddPoses[sPoseKey]
                    if 'dPose' in ddPoseKeyPoses:
                        dPose = ddPoseKeyPoses['dPose']
        
                # duplicated code in _setAttrsCtrls
                if '_' not in sPoseKey: # make sre it's not a combo
                    sCtrlDriverAttrs = [ddPoses[sPoseKey]['sCtrlDriverAttr']]
                    fCtrlDriverValue = ddPoses[sPoseKey]['fCtrlDriverValue']
                    sMirroredDriverAttr = utils.getMirrorName(sCtrlDriverAttrs[0])
                    if sMirroredDriverAttr != sCtrlDriverAttrs[0] and cmds.objExists(sMirroredDriverAttr):
                        sCtrlDriverAttrs.append(sMirroredDriverAttr)
                    for sCtrlDriverAttr in sCtrlDriverAttrs:
                        sDriver, sDriverA = sCtrlDriverAttr.split('.')
                        dPose[sDriver] = {sDriverA:fCtrlDriverValue}
                        if utils.getSide(sCtrlDriverAttr) != 'm':
                            dPose[sDriver] = {sDriverA:fCtrlDriverValue}
                
    
                for sCtrl, dAttrs in dPose.items():
                    for sA, fV in dAttrs.items():
                        sAttr = '%s.%s' % (sCtrl,sA)
                        cmds.setKeyframe(sAttr, t=fMinTime, v=cmds.getAttr(sAttr))
                        cmds.setKeyframe(sAttr, t=fMaxTime, v=fV)
                        
                        # cmds.setAttr('%s.%s' % (sCtrl,sA), fV)
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise

    def _disconnect(ddPoses, _uiArgs=None, _sCombo=sCombo):
        sAllDrivers = [sN for sN in cmds.ls() if cmds.attributeQuery('faceCtrlDriverPoseKey', node=sN, exists=True)]
        iTotalConnectionsCut = 0
        for sDriver in sAllDrivers:
            sInfo = cmds.getAttr('%s.faceCtrlDriverPoseKey' % sDriver)
            sCombo, sDriverOutAttr = sInfo.split('___')
            if sCombo == _sCombo:
                sConnections = cmds.listConnections(sDriverOutAttr, s=False, d=True, p=True) or []
                for sConn in sConnections:
                    cmds.disconnectAttr(sDriverOutAttr, sConn)
                    cmds.setAttr(sConn, 0.0)
                iTotalConnectionsCut += len(sConnections)
        print ('cut %d connections' % iTotalConnectionsCut)



    dPoseMenu = OrderedDict()
    dPoseMenu['pose Driver'] = _poseTo
    dPoseMenu['setAttrs to ctrls for %s' % sCombo] = _setAttrsCtrls
    dPoseMenu['animate ctrls for %s' % sCombo] = _animateCtrls
    dPoseMenu['disconnect %s Pose' % sCombo] = _disconnect
    dPoseMenu['fill %s Pose' % sCombo] = _fill
    dSetPosesMenu[sCombo] = dPoseMenu






def createPosesRom(ddPoses):
    cmds.setKeyframe('jaw_ctrl.rz', t=1, v=0)
    cmds.setKeyframe('jaw_ctrl.rz', t=10, v=ddPoses['jawOpen']['fCtrlDriverValue'])
    cmds.setKeyframe('jaw_ctrl.rz', t=20, v=0)

    for s,sSide in enumerate(['l','r']):
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=20, v=0)
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=30, v=ddPoses['cornerOut']['fCtrlDriverValue'])
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=40, v=ddPoses['cornerOut']['fCtrlDriverValue'])
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=50, v=0)

    cmds.setKeyframe('jaw_ctrl.rz', t=30, v=0)
    cmds.setKeyframe('jaw_ctrl.rz', t=40, v=ddPoses['jawOpen']['fCtrlDriverValue'])
    cmds.setKeyframe('jaw_ctrl.rz', t=50, v=0)

    cmds.setKeyframe('mouth_ctrl.tz', t=50, v=0)
    cmds.setKeyframe('mouth_ctrl.tz', t=60, v=1.0)
    cmds.setKeyframe('mouth_ctrl.tz', t=70, v=-1.0)
    cmds.setKeyframe('mouth_ctrl.tz', t=80, v=-1.0)

    cmds.playbackOptions(e=True, minTime=1, maxTime=80)



def _mirror():
    cCtrls = getMouthPoseCtrls()
    for cC in utils.flattenedList(cCtrls):
        sC = cC.sCtrl
        sSide = utils.getSide(sC)
        if sSide == 'l':
            sOther = utils.getMirrorName(sC)
            for sA in ['tx','ty','tz','rx','ry','rz']:
                sAttr = '%s.%s' % (sOther,sA)
                if cmds.getAttr(sAttr, settable=True):
                    cmds.setAttr(sAttr, cmds.getAttr('%s.%s' % (sC,sA)))
dSetPosesMenu['mirror ctrls'] = _mirror


def _resetDriversAndCtrls(ddPoses):
    for sKey in kAllPoseKeys:
        sDriver = ddPoses[sKey]['sCtrlDriverAttr']
        cmds.setAttr(sDriver, 0)

    sCtrls = []
    for sKey in kAllPoseKeys:
        sCtrls += utils.data.get('%sCtrlKey' % sKey) or []
    for sC in sCtrls:
        sBothCtrls = [sC]
        sOtherCtrl = utils.getMirrorName(sC)
        if sOtherCtrl != sC:
            sBothCtrls.append(sOtherCtrl)
        for sCC in sBothCtrls:
            for sA in ['tx','ty','tz','rx','ry','rz']:
                sAttr = '%s.%s' % (sCC,sA)
                if cmds.getAttr(sAttr, settable=True):
                    cmds.setAttr(sAttr, 0)
dSetPosesMenu['reset all drivers and ctrls'] = _resetDriversAndCtrls


dSetPosesMenu['ROM animation'] = createPosesRom

dButtons['=== POSES ==='] = dSetPosesMenu



# m_mouthPasser_Grp -> grp_m_mouthPasser
def translateAttrToStandard(sAttr):
    sSplits = sAttr.split('.')
    sObj = sSplits[0]
    if not cmds.objExists(sObj):
        sSplitsB = sObj.split('_')
        if len(sSplitsB) >= 3:
            sSplitsB = [sSplitsB[-1].lower()] + sSplitsB[0:-1]
        sObj = '_'.join(sSplitsB)
        sSplits[0] = sObj
        sNewAttr = '.'.join(sSplits)
        if cmds.objExists(sNewAttr):
            return sNewAttr
    return sAttr





def createStaticSlideCurves():
    sSelect = []
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    for sCurve in sCurves:
        if not cmds.objExists(sCurve):
            cmds.confirmDialog(m='For creating this blueprint, you need to run the function first')
        else:
            sNewCurve = utils.replaceStringStart(sCurve, 'curve_', 'bpCurve_')
            sSelect.append(sNewCurve)
            if cmds.objExists(sNewCurve):
                if cmds.confirmDialog(m='Curve "%s" already exists. Recreate?' % sNewCurve, button=['yes', 'no']) == 'no':
                    continue
                else:
                    cmds.delete(sNewCurve)
            cmds.duplicate(sCurve, n=sNewCurve)
            cmds.parent(sNewCurve, kMouthBpGroupName)
    if sSelect:
        cmds.select(sSelect)


def selectStaticSlideCurveBps():
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    sSel = []
    for sCurve in sCurves:
        sNewCurve = utils.replaceStringStart(sCurve, 'curve_', 'bpCurve_')
        if cmds.objExists(sNewCurve):
            sSel.append(sNewCurve)
    if sSel:
        cmds.select(sSel)

def selectRiggedOnes():
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    cmds.select(sCurves)


dButtons['=== Static Blueprint Curves (Optional) ==='] = {'Create Blueprints': createStaticSlideCurves, 'Select Blueprints':selectStaticSlideCurveBps, 'Select Rigged':selectRiggedOnes}


dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu()

dSquashStretchMenu = {}
def bakeSquashStretchShapes(ddSquashStretchSettings, _uiArgs=None):

    sModel = cmds.ls(sl=True)[0]

    sNew = []
    for sKey, sValueKey in [('sShrinkTarget', 'fShrinkCornerValue'),
                            ('sExpandTarget', 'fExpandCornerValue')]:
        sTarget = ddSquashStretchSettings[sKey]
        if cmds.objExists(sTarget):
            cmds.delete(sTarget)
        fValue = ddSquashStretchSettings[sValueKey]
        cmds.setAttr('lipsCorner_l_ctrl.tx', fValue)
        cmds.setAttr('lipsCorner_r_ctrl.tx', fValue)

        cmds.duplicate(sModel, n=sTarget)
        utils.parentToWorld(sTarget)
        sNew.append(sTarget)

    cmds.setAttr('lipsCorner_l_ctrl.tx', 0)
    cmds.setAttr('lipsCorner_r_ctrl.tx', 0)
    cmds.select(sNew)
dSquashStretchMenu['Bake Shapes'] = bakeSquashStretchShapes


dButtons['=== SQUASH STRETCH ==='] = dSquashStretchMenu


dButtons['- Export Mouth BPs -'] = lambda: exportBps(kMouthBpFileName, kMouthBpGroupName)
dButtons['- Export *Slider* BPs -'] = ctrls6.exportSliderBps


# curve_m_botMouth gets rotation on pucker!!!!



def updateDdPoses(ddPoses):
    ddPoses = dict(ddPoses)
    for sKey, dValues in kkDefaultPoses.items():
        if sKey not in ddPoses:
            ddPoses[sKey] = dValues
        else:
            for a,b in dValues.items():
                if a not in ddPoses[sKey]:
                    ddPoses[sKey][a] = b
    return ddPoses


kMouthSplineCurves = ['curve_m_botMouth', 'curve_m_topMouth']
kMouthJawOpenCorrectiveCurves = ['jawOpenBotMouth', 'jawOpenTopMouth']
def selectMouthSplineCurves():
    cmds.select(kMouthSplineCurves)

def selectMouthSplineCorrectiveCurves():
    cmds.select(kMouthJawOpenCorrectiveCurves)


def generateCorrectiveCurves():
    sReturn = []
    for c,sCurve in enumerate(kMouthSplineCurves):
        sCorrCurve = kMouthJawOpenCorrectiveCurves[c]
        if cmds.objExists(sCorrCurve):
            cmds.delete(sCorrCurve)
        cmds.duplicate(sCurve, n=sCorrCurve)[0]
        cmds.parent(sCorrCurve, kMouthBpGroupName)
        sReturn.append(sCorrCurve)
    cmds.select(sReturn)


def mirrorCorrectiveCurves():
    for sCorr in kMouthJawOpenCorrectiveCurves:
        pCurve = patch.patchFromName(sCorr)
        aCvs = pCurve.getPoints()
        aMirrorCvs = np.copy(aCvs[::-1])
        aMirrorCvs[:,0] *= -1.0
        iMirrorIds = np.arange(len(aCvs)//2 + 1, len(aCvs), 1)
        aCvs[iMirrorIds] = aMirrorCvs[iMirrorIds]
        aCvs[len(aCvs)//2, 0] = 0.0
        pCurve.setPoints(aCvs)

# probably not needed anymore since curves are smoother
dButtons['=== SPLINE CURVE CORRECTIVES ==='] = {'select rigged curves':selectMouthSplineCurves,
                                                'select correctives':selectMouthSplineCorrectiveCurves,
                                                'generate correctives':generateCorrectiveCurves,
                                                'mirror correctives curves':mirrorCorrectiveCurves}




@builderTools.addToBuild(iOrder=62.2, dButtons=dButtons)
def BASEMouthCtrls(sAttachMesh=[], bSPLINES=False, bCorners=True, bBorders=True, bLimitOnNonSplineMode=True, bFrontBoxCtrls=True, bFlipInnerMouthBpCurves=False,
                        fLeftLipParamPercs=[0.33],
                        bPolyCtrls=False, xMirrorAxis=None, sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain',
                        dDefaultSettingValues={}, 
                        ddSquashStretchSettings={'bScaleJoints':True, 'fShrinkCornerValue':-1, 'fExpandCornerValue':1.0, 'sShrinkTarget':'mouthSquash', 'sExpandTarget':'mouthStretch'},
                        ddPoses=kkDefaultPoses, iSkipSplineJoints=0,
                         sSuffix=''):
    '''
    1. Create the inner and outer curves (check the locators)
    2. MOST IMPORTANT: set bFlipInnerMouthCurves accordingly!!
    3. for bSplines, create the Corner Sliding Planes

    :param fLeftLipParamPercs
    Changes lip control position or add more controls. By default it's None, which is similar to [0.33].
    To add a middle control: [0.33, 0.5]
    To have 2 extra controls: [0.15, 0.3, 0.5]

    :param fLeftPuckerStrenth:
    Changes behavior of lipCorner_l_ctrl going forward (inside)
    Example: [0.15, 0.3, 0.5]
    
    if lipsCorner_l_ctrl moving negative causes joints to behave unstable, create the Puckerslide Blueprint
    '''

    sDefaultSettingAttrs = []
    utils.data.store('bMouthSplines%s' % sSuffix, bSPLINES)

    # xMirrorAxis = sMirrorJointAxes[suf] if suf < len(sMirrorJointAxes) else None
    fLipCtrlScale = 1.0
    sInputCurveInner = 'bpCurve_m_lipsInner%s' % sSuffix
    sInputCurveOuter = 'bpCurve_m_lipsOuter%s' % sSuffix

    sBpCurvesA = ['bpCurve_m_%sLipInner%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]
    sBpCurvesB = ['bpCurve_m_%sLipOuter%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]

    utils.data.store('sBpCurvesA%s' % sSuffix, sBpCurvesA)
    utils.data.store('sBpCurvesB%s' % sSuffix, sBpCurvesB)

    # aHeadMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')
    if cmds.objExists('bp_m_mouthPivot'):
        aMouthSlideMatrix = utils.getNumpyMatrixFromTransform('bp_m_mouthPivot')
    else:
        aMouthSlideMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')

    aMouthRotationSlideMatrix = aMouthSlideMatrix[0:3,0:3]
        

    if bFlipInnerMouthBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs(sInputCurveInner, 'locA_m_lipsInner%s' % sSuffix,
                                                'locB_m_lipsInner%s' % sSuffix, sBpCurvesA[1], sBpCurvesA[0])
    else:
        curves.separateCurveUsingSeparationLocs(sInputCurveInner, 'locA_m_lipsInner%s' % sSuffix,
                                                'locB_m_lipsInner%s' % sSuffix, sBpCurvesA[0], sBpCurvesA[1])

    curves.separateCurveUsingSeparationLocs(sInputCurveOuter, 'locA_m_lipsOuter%s' % sSuffix,
                                            'locB_m_lipsOuter%s' % sSuffix, sBpCurvesB[0], sBpCurvesB[1])

    utils.data.store('bLipCurves%s' % sSuffix, True)
    fMouthCurveEndsDistance = barycentric.distanceBetween('%s.cv[0]' % sBpCurvesA[0], '%s.cv[%d]' % (sBpCurvesA[0], len(cmds.ls('%s.cv[*]' % sBpCurvesA[0], flatten=True))-1))
    utils.data.store('fMouthCurveEndsDistance%s' % sSuffix, fMouthCurveEndsDistance)
    fMouthSliderScale = fMouthCurveEndsDistance * 0.25

    aBotMiddle = curves.getPointsFromPercs(sBpCurvesA[0], [0.5], bReturnNumpy=True)[0]
    aTopMiddle = curves.getPointsFromPercs(sBpCurvesA[1], [0.5], bReturnNumpy=True)[0]
    aMouthCtrlFront = (aTopMiddle + aBotMiddle) * 0.5 + np.array([0,0,fMouthSliderScale*0.5], dtype='float64')

    sMouthTransformOrigin = cmds.createNode('transform', n='sMouthTransformOrigin', p=getFaceGrp())

    cmds.setAttr('%s.t' % sMouthTransformOrigin, *list(aMouthCtrlFront))
    sMouthGrpJoints = cmds.createNode('transform', n='grp_m_mouthJoints',
                                      p=sMouthTransformOrigin)  # an origin group, because below are nodes getting curveInfo datas
    cmds.move(0, 0, 0, sMouthGrpJoints, ws=True, a=True)

    iMidInd = 1
    aCtrlPercs = np.array([0.0, 0.5, 1.0], dtype='float64')

    # else:
    #     iMidInd = 3
    #     aCtrlPercs = np.array([0.0, 0.1667, 0.3334, 0.5, 0.6667, 0.833334, 1.0], dtype='float64')

    sCtrlBpCurves = sBpCurvesA if bSPLINES else sBpCurvesB


    ffCtrlPoints = []
    ffCtrlPoints.append(curves.getPointsFromPercs(sCtrlBpCurves[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPoints.append(curves.getPointsFromPercs(sCtrlBpCurves[1], aCtrlPercs, bReturnNumpy=True))

    ffCtrlPointsB = []
    # not finding bpCurve_m_botLipOuter
    ffCtrlPointsB.append(curves.getPointsFromPercs(sBpCurvesB[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPointsB.append(curves.getPointsFromPercs(sBpCurvesB[1], aCtrlPercs, bReturnNumpy=True))

    aMouthCtrlsOffset = np.array([0,0,0]) if bSPLINES else np.array([0, 0, fMouthCurveEndsDistance * 0.1], dtype='float64')

    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sTargets = set(utils.data.get('sBakedBlendshapeTargets%s' % sSuffix, xDefault=[]))

    aCornerTangent = curves.getTangentsFromPercs(sBpCurvesA[0], [0.1], bReturnNumpy=True)[0]

    if bCorners:
        cCorners = ctrls6.createSliderCtrl('lipsCorner%s' % sSuffix, 'l', fBpPos=ffCtrlPoints[0][0] + aMouthCtrlsOffset,
                                           fRangeX=[-1.0, 1.0], fRangeY=[-1.0, 1.0], fRangeZ=[-1,1],
                                           sShape='cube', sAttach=None if bSPLINES else sModel, bBorder=bBorders,
                                           bPoly=bPolyCtrls, fScale=fMouthSliderScale,
                                           xMirrorAxis=xMirrorAxis, sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                            dAlignVectors = {'sAim': aMouthRotationSlideMatrix[0],
                                                             'sUp': -aCornerTangent,
                                                             'fAimVector': [0, 1, 0], 'fUpVector': [1, 0, 0]})
        for s,sSide in enumerate(['l','r']):
            for sPoseKey in ['cornerOut', 'cornerIn', 'cornerUp', 'cornerDown']:
                sPoseAttr = utils.addAttr(cCorners[s].sPasser, ln=sPoseKey, dv=ddPoses[sPoseKey]['fCtrlDriverValue'], k=True)
                cmds.setAttr(sPoseAttr, lock=True)

        if bSPLINES:
            if sAttachMesh:
                sAttachMesh = utils.toList(sAttachMesh)[0]
            else:
                raise Exception('no attachmesh given')

            for cC in cCorners:
                cC.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[2:]])
                cC.sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                                '%s.worldInverseMatrix' % cC.sExtraMove,
                                                                '%s.worldMatrix' % cC.sPasser])
                cC.sJumpedInverseMatrix = nodes.createInverseMatrix(cC.sJumpedMatrix)
                cC.sJumpedPos = nodes.createDecomposeMatrix(cC.sJumpedMatrix)
                # ctrls6.createExtraMoveTransformAndTag(cCorners[1], [sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[2:]])
            
            utils.addAttr(cCorners[0].sCtrl, ln='botScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[0].sCtrl, ln='botScaleZ', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='botScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='botScaleZ', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[0].sCtrl, ln='topScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[0].sCtrl, ln='topScaleZ', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='topScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='topScaleZ', min=0.1, dv=1.0, k=True)

        cCorners[0].fPerc = 0
        cCorners[1].fPerc = 1


        if bSPLINES:
            for s,sSide in enumerate(['l','r']):
                cmds.xform('sliderBp_%s_lipsCorner' % sSide, t=ffCtrlPoints[0][0 if s == 0 else -1], ws=True)

    else:
        if bSPLINES:
            raise Exception('bCorners needs to be On if bSPLINES is on')
        cCorners = []

    # bot top ctrls
    if bFrontBoxCtrls:
        cBot = ctrls6.createSliderCtrl('mouthBot%s' % sSuffix, 'm', sShape='cube', fBpPos=ffCtrlPoints[0][iMidInd] + aMouthCtrlsOffset,
                                bBorder=False, fScaleShape=[1, 0.1, 0.1], fRangeX=[-1, 1], fRangeY=[-1, 1], fRangeZ=[-1, 1],
                                sAttach=None if bSPLINES else sModel,
                                sAddAttrs=['rx', 'ry', 'rz'] if bSPLINES else [])[0]
        cmds.setAttr('%s.s' % cBot.sSlider, fMouthSliderScale, fMouthSliderScale, fMouthSliderScale)
        cTop = ctrls6.createSliderCtrl('mouthTop%s' % sSuffix, 'm', sShape='cube', fBpPos=ffCtrlPoints[1][iMidInd] + aMouthCtrlsOffset,
                                bBorder=False, fScaleShape=[1, 0.1, 0.1], fRangeX=[-1, 1], fRangeY=[-1, 1], fRangeZ=[-1, 1],
                                sAttach=None if bSPLINES else sModel,
                                sAddAttrs=['rx', 'ry', 'rz'] if bSPLINES else [])[0]
        cmds.setAttr('%s.s' % cTop.sSlider, fMouthSliderScale, fMouthSliderScale, fMouthSliderScale)
        cBot.fPerc = 0.5
        cTop.fPerc = 0.5
        cBotTops = [cBot, cTop]
        if bSPLINES:
            for cC in cBotTops:
                cC.createExtraMoveTransformAndTag(ctrls6.kDefaultFaceAttachDeformers[2:])
                sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                            '%s.worldInverseMatrix' % cC.sExtraMove])
                cC.sJumped = cmds.duplicate(cC.sExtraMove, po=True, n=utils.replaceStringEnd(cC.sCtrl, '_ctrl', '_jumped'))[0]
                nodes.createDecomposeMatrix(sJumpedMatrix, sTargetPos='%s.t' % cC.sJumped, sTargetRot='%s.r' % cC.sJumped, sTargetScale='%s.s' % cC.sJumped)
                cC.sJumpedMatrix = '%s.worldMatrix' % cC.sJumped
                cC.sJumpedInverseMatrix = '%s.worldInverseMatrix' % cC.sJumped

    else:
        cBotTops = []

    sLowerDown = 'lowerDown%s' % sSuffix
    sLowerUp = 'lowerUp%s' % sSuffix
    sUpperDown = 'upperDown%s' % sSuffix
    sUpperUp = 'upperUp%s' % sSuffix

    if bSPLINES:
        fLowerRangeY = [-1,1]
        fLowerRangeX = [-1,1]
        fLowerRangeZ = [-1,1]
        fUpperRangeY = [-1,1]
        fUpperRangeX = [-1,1]
        fUpperRangeZ = [-1,1]
    else:
        if sLowerDown in sTargets or sLowerUp in sTargets:
            fLowerRangeY = [-1.0 if sLowerDown in sTargets else 0.0, 1.0 if sLowerUp in sTargets else 0.0]
        else:
            fLowerRangeY = [-1,0] # just to have a default
        fLowerRangeX = [0,0]
        fLowerRangeZ = [0,0]
        if sUpperDown in sTargets or sUpperUp in sTargets:
            fUpperRangeY = [-1.0 if sUpperDown in sTargets else 0.0, 1.0 if sUpperUp in sTargets else 0.0]
        else:
            fUpperRangeY = [0,1] # just to have a default
        fUpperRangeX = [0,0]
        fUpperRangeZ = [0,0]


    utils.reload2(ctrls6)
    if fLeftLipParamPercs != None:
        fLeftLipParamPercs.sort()
        if fLeftLipParamPercs[-1] > 0.5:
            raise Exception('fLeftLipParamPercs values can only go from 0 to 0.5')

        aParams = np.array(fLeftLipParamPercs) * curves.getParamLength(sCtrlBpCurves[0]) # we have to do params, because it will be calculated faster for each mesh point later
        aPercs = curves.getPercsFromParams(sCtrlBpCurves[0], aParams)
        aLeftLowerPoints = curves.getPointsFromPercs(sCtrlBpCurves[0], aPercs, bReturnNumpy=True)
        aLeftLowerTangents = curves.getTangentsFromPercs(sCtrlBpCurves[0], aPercs, bReturnNumpy=True)

        cBotLips = [None] * (len(fLeftLipParamPercs) * 2)
        if fLeftLipParamPercs[-1] == 0.5:
            cBotLips = cBotLips[:-1]


        for i, aPoint in enumerate(aLeftLowerPoints):
            sS = 'm' if fLeftLipParamPercs[i] == 0.5 else 'l'
            if fLeftLipParamPercs[i] == 0.5:
                sI = ''
            elif len(fLeftLipParamPercs) <= 2:
                sI = ''
            else:
                sI = '%d' % i
            _cCtrls = ctrls6.createSliderCtrl('lipsBot%s%s' % (sI, sSuffix), sSide=sS, fBpPos=aPoint + aMouthCtrlsOffset, bRedoTranslation=True,
                                              sAttach=None if bSPLINES else sModel, fRangeY=fLowerRangeY, fRangeX=fLowerRangeX, fRangeZ=fLowerRangeZ, bPoly=bPolyCtrls,
                                              fScale=fMouthSliderScale,
                                              dAlignVectors={'sAim':-aMouthRotationSlideMatrix[2] if sS == 'm' else -aLeftLowerTangents[i],
                                                             'sUp':aMouthRotationSlideMatrix[0],
                                                             'fAimVector':[1,0,0], 'fUpVector':[0,1,0]},
                                              xMirrorAxis=xMirrorAxis, bBorder=bBorders, sAddAttrs=['rx','ry','rz', 'sx','sy','sz'] if bSPLINES else [])
            _cCtrls[0].fPerc = fLeftLipParamPercs[i]
            if sS == 'l':
                _cCtrls[1].fPerc = 1.0 - fLeftLipParamPercs[i]
            cBotLips[i] = _cCtrls[0]
            if sS == 'l':
                cBotLips[-(i + 1)] = _cCtrls[1]

        if fLeftLipParamPercs[-1] == 0.5:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-2::-1]]
        else:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-1::-1]]
        dSplitAlongCurve = {'ssAttrs': [['%s.ty' % cC.sCtrl for cC in cBotLips]],
                            'ffValues': [[-1.0] * len(cBotLips)],
                            'fParams': fPassParams,
                            'sCurve': sBpCurvesA[0]}
        utils.data.store('dLipSplitAlongCurve%s' % sSuffix, dSplitAlongCurve)


        # top
        aLeftUpperPoints = curves.getPointsFromPercs(sCtrlBpCurves[1], aPercs, bReturnNumpy=True)
        aLeftUpperTangents = curves.getTangentsFromPercs(sCtrlBpCurves[1], aPercs, bReturnNumpy=True)

        cTopLips = [None] * (len(fLeftLipParamPercs)*2)
        if fLeftLipParamPercs[-1] == 0.5:
            del cTopLips[-1]

        for i, aPoint in enumerate(aLeftUpperPoints):
            sS = 'm' if fLeftLipParamPercs[i] == 0.5 else 'l'
            if fLeftLipParamPercs[i] == 0.5:
                sI = ''
            elif len(fLeftLipParamPercs) <= 2:
                sI = ''
            else:
                sI = '%d' % i
            _cCtrls = ctrls6.createSliderCtrl('lipsTop%s%s' % (sI, sSuffix), sSide=sS, fBpPos=aPoint+aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel, bRedoTranslation=True,
                                              fRangeX=fUpperRangeX, fRangeY=fUpperRangeY, fRangeZ=fUpperRangeZ, bPoly=bPolyCtrls,
                                              fScale=fMouthSliderScale,
                                              dAlignVectors={'sAim':-aMouthRotationSlideMatrix[2] if sS == 'm' else -aLeftUpperTangents[i],
                                                             'sUp':aMouthRotationSlideMatrix[0],
                                                             'fAimVector':[1,0,0], 'fUpVector':[0,1,0]},
                                              xMirrorAxis=xMirrorAxis,
                                              sAddAttrs=['rx','ry','rz','sy','sz'] if bSPLINES else [],
                                              bBorder=bBorders)
            # cmds.transformLimits(_cCtrls[0].sCtrl, sy=(0.1,5), esy=(True, True))
            # cmds.transformLimits(_cCtrls[0].sCtrl, sz=(0.1,5), esz=(True, True))
            # cmds.transformLimits(_cCtrls[1].sCtrl, sy=(0.1,5), esy=(True, True))
            # cmds.transformLimits(_cCtrls[1].sCtrl, sz=(0.1,5), esz=(True, True))

            _cCtrls[0].fPerc = fLeftLipParamPercs[i]
            if sS == 'l':
                _cCtrls[1].fPerc = 1.0 - fLeftLipParamPercs[i]
            cTopLips[i] = _cCtrls[0]
            if sS == 'l':
                cTopLips[-(i+1)] = _cCtrls[1]

        if fLeftLipParamPercs[-1] == 0.5:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-2::-1]]
        else:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-1::-1]]

        dSplitAlongCurve = {'ssAttrs':[['%s.ty' % cC.sCtrl for cC in cTopLips]],
                         'ffValues':[[1.0] * len(cTopLips)],
                         'fParams':fPassParams,
                         'sCurve':sBpCurvesA[1]}
        utils.data.store('dUpperSplitAlongCurve%s' % sSuffix, dSplitAlongCurve)


    else: # we should be able to get rid of this
        # lower simple left/right
        aLeftLowerPoint = curves.getPointsFromPercs(sCtrlBpCurves[0], [0.33], bReturnNumpy=True)[0]
        aLeftLowerTangent = curves.getTangentsFromPercs(sCtrlBpCurves[0], [0.33], bReturnNumpy=True)[0]

        cBotLips = ctrls6.createSliderCtrl('lipsBot%s' % sSuffix, sSide='l',
                                           fBpPos=aLeftLowerPoint + aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel,
                                           fRangeX=fLowerRangeX, fRangeY=fLowerRangeY, fRangeZ=fLowerRangeZ, bPoly=bPolyCtrls,
                                           fScale=fMouthSliderScale, sAlignOnModel=[sModel, sLowerUp, sLowerDown],
                                           xMirrorAxis=xMirrorAxis,
                                           sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                           bBorder=bBorders,
                                           dAlignVectors={'sAim': -aLeftLowerTangent, 'sUp': aMouthRotationSlideMatrix[0], 'fAimVector': [1, 0, 0], 'fUpVector': [0, 1, 0]},
                                           )
        cBotLips[0].fPerc = 0.333
        cBotLips[1].fPerc = 0.667
        utils.data.store('sLipBotCtrls', [cBotLips[0].sCtrl, cBotLips[1].sCtrl])


        # upper simple left/right
        aLeftUpperPoint = curves.getPointsFromPercs(sCtrlBpCurves[1], [0.333], bReturnNumpy=True)[0]
        aLeftUpperTangent = curves.getTangentsFromPercs(sCtrlBpCurves[1], [0.33], bReturnNumpy=True)[0]

        cTopLips = ctrls6.createSliderCtrl('lipsTop%s' % sSuffix, sSide='l', fBpPos=aLeftUpperPoint+aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel,
                                            fRangeX=fUpperRangeX, fRangeY=fUpperRangeY, fRangeZ=fUpperRangeZ, bPoly=bPolyCtrls,
                                            fScale=fMouthSliderScale, sAlignOnModel=[sModel, sLowerUp, sLowerDown], xMirrorAxis=xMirrorAxis,
                                            sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                            dAlignVectors={'sAim': -aLeftUpperTangent, 'sUp': aMouthRotationSlideMatrix[0], 'fAimVector': [1, 0, 0], 'fUpVector': [0, 1, 0]},
                                           bBorder=bBorders)
        cTopLips[0].fPerc = 0.333
        cTopLips[1].fPerc = 0.667
        utils.data.store('sLipTopCtrls', [cTopLips[0].sCtrl, cTopLips[1].sCtrl])

    ccLipCtrls = [cBotLips, cTopLips]
    # if bSPLINES:
    #     for cCtrl in cBotLips+cTopLips:
    #         ctrls6.createExtraMoveTransformAndTag(cCtrl, [sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[2:]])

    sOrientGuide = xforms.createTransform('lipsOrientGuide', sMatch='jnt_m_headMain')
    if cmds.objExists('bp_m_mouthPivot'):
        cmds.delete(cmds.orientConstraint('bp_m_mouthPivot', sOrientGuide))
    cmds.rotate(90, 90, 0, sOrientGuide, os=True, r=True)
    
    
    # cMouthTransform
    cMouth = ctrls6.createSliderCtrl('mouth%s' % sSuffix, 'm', sShape='locator', sMatch=sOrientGuide, fBpPos=aMouthCtrlFront,
                                  bBorder=False, fScaleShape=[1,1,1], fRangeX=[-1,1], fRangeY=[-1,1], fRangeZ=[-1,1],
                                  sAttach=sParentJoint if bSPLINES else sModel, fScale=fMouthSliderScale, sAddAttrs=['r', 's'] if bSPLINES else [])[0]
    fOutScale =  cmds.xform(cMouth.sOut, q=True, s=True, ws=True)
    cmds.setAttr('%s.s' % cMouth.sOut, 1.0 / fOutScale[0], 1.0 / fOutScale[1], 1.0 / fOutScale[2])

    if False:
        cmds.connectAttr('%s.sx' % cMouth.sCtrl, '%s.sy' % cMouth.sCtrl)
        cmds.connectAttr('%s.sx' % cMouth.sCtrl, '%s.sz' % cMouth.sCtrl)
        cmds.setAttr('%s.sz' % cMouth.sCtrl, lock=True) #, keyable=False, channelBox=False)
        cmds.setAttr('%s.sy' % cMouth.sCtrl, lock=True) #, keyable=False, channelBox=False)

    if bSPLINES:
        cMouth.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[2:]])
        iIdsAlongCurve = cmds.kt_findClosestPoints(fromMesh=sInputCurveInner, toMesh=sAttachMesh, vertex=True)
        iIdsAlongCurve = [int(iId) for iId in iIdsAlongCurve]
        utils.addStringAttr(cMouth.sPasser, 'iIdsAlongCurve', iIdsAlongCurve, bLock=True)

    cMouth.fPerc = 0.5
    cAllCtrls = ccLipCtrls[0] + ccLipCtrls[1] + cCorners + cBotTops + [cMouth]
    if bCorners:
        ccRows = [[cCorners[0]] + ccLipCtrls[0] + [cCorners[1]],
                  [cCorners[0]] + ccLipCtrls[1] + [cCorners[1]]]
    else:
        ccRows = ccLipCtrls

    for cC in ccLipCtrls[0][::-1] + ccLipCtrls[1][::-1] + cCorners[::-1]:
        cmds.controller(cC.sCtrl, cMouth.sCtrl, parent=True)


    if bSPLINES or not bLimitOnNonSplineMode:
        for cC in cAllCtrls:
            cmds.transformLimits(cC.sCtrl, etx=[False, False], ety=[False, False], etz=[False, False])
            ctrls6.disconnectFromSliderBp(cC)

        # need to set cMouth back because it's used for funnel and lipPress
        cmds.transformLimits(cMouth.sCtrl, etz=[True, True])


    bMouthSplinesExecuted = False

    # EXCLUDE START MOUTHSPLINES

    if bSPLINES:
        bMouthSplinesExecuted = True
        sGrp = cmds.createNode('transform', n='grp_mouthSplines', p='modules')

        sParentGrp = cmds.createNode('transform', n='grp_mouthSplinesParentJoint', p=sGrp)
        constraints.matrixParentConstraint(sParentJoint, sParentGrp)

        # create extra ctrl grps
        def addPosingControls(cAddPosingCtrls):

            dOffsetsPerCtrls = defaultdict(list)
            sCtrlsPerPose = []
            for c, cC in enumerate(cAddPosingCtrls):
                sNewOffset = cC.appendOffsetGroup('poses')
                sCtrlsPerPose.append(cC.sCtrl)
                dOffsetsPerCtrls[cC.sCtrl].append(sNewOffset)

        addPosingControls(ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners)# + cCornerTangents


        fCurveLengthes = [curves.getLength(sBpCurvesA[0]), curves.getLength(sBpCurvesA[1])]



        # slide pivots
        sSlideBp = 'bp_m_mouthPivot'
        sMouthPivot = xforms.createLocator('loc_m_mouthPivot', sParent=sParentGrp, sMatch=sSlideBp, fSize=fCurveLengthes[0]*0.035)
        xforms.insertParent(sMouthPivot, 'grp_m_mouthPivotParent')

        sMouthPivotFront = 'jnt_m_mouthPivotFrontHead'
        if cmds.objExists(sMouthPivotFront):
            cmds.parent(sMouthPivotFront, sParentJoint)
            cmds.delete(cmds.parentConstraint(cMouth.sCtrl, sMouthPivotFront))
        else:
            xforms.createJoint(sMouthPivotFront, sParent=sParentJoint, sMatch=cMouth.sCtrl)
        cmds.setAttr('%s.segmentScaleCompensate' % sMouthPivotFront, False)

        sMouthPivotFrontRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sMouthPivotFront)
        sMouthPivotFrontInvRotationMatrix = nodes.createInverseMatrix(sMouthPivotFrontRotationMatrix)

        sGrpMouthPivotFront = xforms.createTransform('grp_m_mouthPivotFront', sParent=sParentGrp, sMatch=cMouth.sCtrl)#, fSize=fCurveLengthes[0]*0.05) # it was a joint before... why?
        sAnimMatrix = nodes.createComposeMatrixNode(xRotate='%s.r' % cMouth.sCtrl, xScale='%s.s' % cMouth.sCtrl)
        fMouthPivotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sMouthPivotFront, '%s.worldInverseMatrix' % sMouthPivot], bJustValues=True)
        sFrontMatrix = nodes.createMultMatrixNode([sAnimMatrix,
                                                   fMouthPivotOffset,
                                                   '%s.worldMatrix' % sMouthPivot,
                                                   '%s.worldInverseMatrix' % sParentJoint])
        nodes.createDecomposeMatrix(sFrontMatrix, sTargetPos='%s.t' % sMouthPivotFront, sTargetRot='%s.r' % sMouthPivotFront, sTargetScale='%s.s' % sMouthPivotFront)
        nodes.createDecomposeMatrix(sFrontMatrix, sTargetPos='%s.t' % sGrpMouthPivotFront, sTargetRot='%s.r' % sGrpMouthPivotFront, sTargetScale='%s.s' % sGrpMouthPivotFront)


        sLipsCtrlsParent = cmds.createNode('transform', n='lipsCtrlParent', p='faceCtrls')
        constraints.matrixParentConstraint(sMouthPivotFront, sLipsCtrlsParent)
        cmds.parent([cC.sPasser for cC in utils.flattenedList(ccRows)], sLipsCtrlsParent)
        cmds.parent(cBotTops[0].sPasser, cBotTops[1].sPasser, sLipsCtrlsParent)



        sJawMouthPivot = 'jnt_m_mouthPivotFrontJaw'
        if cmds.objExists(sJawMouthPivot):
            cmds.parent(sJawMouthPivot, sParentJoint)
            xforms.resetTransform(sJawMouthPivot, jo=True)
            cmds.delete(cmds.parentConstraint(sJawJoint, sJawMouthPivot))
        else:
            xforms.createJoint(sJawMouthPivot, sParent=sParentJoint, sMatch=sJawJoint)

        cmds.setAttr('%s.segmentScaleCompensate' % sMouthPivotFront, False)
        utils.matchJointRadius([sMouthPivotFront, sJawMouthPivot], 'jnt_m_headMain', 0.1)

        sJawSliderFrontMatrix = nodes.createMultMatrixNode([sAnimMatrix,
                                                        nodes.createMultMatrixNode(['%s.worldMatrix' % cMouth.sCtrl, '%s.worldInverseMatrix' % sJawJoint], bJustValues=True),
                                                       '%s.worldMatrix' % sJawJoint,
                                                       '%s.worldInverseMatrix' % sParentJoint,
                                                       nodes.createMultMatrixNode(['%s.worldMatrix' % sParentJoint, '%s.worldInverseMatrix' % sMouthPivot], bJustValues=True),
                                                       '%s.worldMatrix' % sMouthPivot,
                                                       '%s.worldInverseMatrix' % sParentJoint], sName='jawSliderMatrix')
        nodes.createDecomposeMatrix(sJawSliderFrontMatrix, sTargetPos='%s.t' % sJawMouthPivot, sTargetRot='%s.r' % sJawMouthPivot)#, sTargetScale='%s.s' % sJawMouthPivot)
        cmds.connectAttr('%s.s' % sMouthPivotFront, '%s.s' % sJawMouthPivot)

        sJawSliderRotateMatrix = nodes.getRotationMatrix2(nodes.createMultMatrixNode(['%s.worldMatrix' % sJawMouthPivot, '%s.worldInverseMatrix' % sMouthPivotFront]),
                                                          bScale=False, sName='rotJawSliderMatrix')
        deformers.resetJointReferences([sMouthPivotFront, sJawMouthPivot])


        sHorizontalStrengthRotate = utils.addAttr(cMouth.sPasser, ln='horizontalRotateStrength', dv=10, k=True)
        sHorizontalStrengthRotateTwist = utils.addAttr(cMouth.sPasser, ln='horizontalRotateTwistStrength', dv=0, k=False)
        sHorizontalStrengthRotateVert = utils.addAttr(cMouth.sPasser, ln='horizontalRotateVertStrength', dv=0, k=False)
        sHorizontalStrengthTranslateAttr = [utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthX', k=True),
                                            utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthY', k=True),
                                            utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthZ', k=True)]
        sDefaultSettingAttrs.extend([sHorizontalStrengthRotate, sHorizontalStrengthRotateTwist, sHorizontalStrengthRotateVert])
        sDefaultSettingAttrs.extend(sHorizontalStrengthTranslateAttr)
        
        sVerticalStrengthRotate = utils.addAttr(cMouth.sPasser, ln='verticalRotateStrength', dv=5, k=True)
        sVerticalStrengthRotateTwist = utils.addAttr(cMouth.sPasser, ln='verticalRotateTwistStrength', dv=0, k=True)
        sVerticalStrengthRotateHoriz = utils.addAttr(cMouth.sPasser, ln='verticalRotateHorizStrength', dv=0, k=True)
        sVerticalStrengthTranslateAttr = [utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthX', k=True),
                                          utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthY', k=True),
                                          utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthZ', k=True)]
        sDefaultSettingAttrs.extend([sVerticalStrengthRotate, sVerticalStrengthRotateTwist, sVerticalStrengthRotateHoriz])
        sDefaultSettingAttrs.extend(sVerticalStrengthTranslateAttr)

        sMouthX = '%s.tx' % cMouth.sCtrl
        sMouthY = '%s.ty' % cMouth.sCtrl
        sMouthAbsX = nodes.createAbsoluteNode(sMouthX)
        sMouthAbsY = nodes.createAbsoluteNode(sMouthY)


        sVerticalStrengthTranslateAttr = nodes.createVectorMultiplyNode(sVerticalStrengthTranslateAttr, [-1, 1, -1])
        sVerticalStrengthTranslateAttr = ['%sY' % sVerticalStrengthTranslateAttr, '%sZ' % sVerticalStrengthTranslateAttr, '%sX' % sVerticalStrengthTranslateAttr]
        sVerticalStrengthTranslate = nodes.createVectorMultiplyNode(sVerticalStrengthTranslateAttr, fCurveLengthes[0]*0.035, bVectorByScalar=True)
        sVertResult = nodes.createVectorMultiplyNode(sVerticalStrengthTranslate, [sMouthY, sMouthAbsY, sMouthAbsY])

        sHorizontalStrengthTranslateAttr = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslateAttr, [-1, 1, -1])
        sHorizontalStrengthTranslateAttr = ['%sY' % sHorizontalStrengthTranslateAttr, '%sZ' % sHorizontalStrengthTranslateAttr, '%sX' % sHorizontalStrengthTranslateAttr]
        sHorizontalStrengthTranslate = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslateAttr, fCurveLengthes[0]*0.035, bVectorByScalar=True)
        sHorizResult = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslate, [sMouthAbsX, sMouthAbsX, sMouthX])
        nodes.createVectorAdditionNode([sVertResult, sHorizResult], sTarget='%s.t' % sMouthPivot)



        sHorizontalRotateResults = [nodes.createMultiplyNode(sHorizontalStrengthRotate, '%s.tx' % cMouth.sCtrl),
                                    nodes.createMultiplyNode(sHorizontalStrengthRotateTwist, '%s.tx' % cMouth.sCtrl),
                                    nodes.createMultiplyNode(sHorizontalStrengthRotateVert, nodes.createAbsoluteNode('%s.tx' % cMouth.sCtrl))]
        sVerticalRotateResults =  [nodes.createMultiplyNode(sVerticalStrengthRotateHoriz, nodes.createAbsoluteNode('%s.ty' % cMouth.sCtrl)),
                                   nodes.createMultiplyNode(sVerticalStrengthRotateTwist, '%s.ty' % cMouth.sCtrl),
                                   nodes.createMultiplyNode(sVerticalStrengthRotate, '%s.ty' % cMouth.sCtrl)]
        
        nodes.createVectorAdditionNode([sHorizontalRotateResults, sVerticalRotateResults], sTarget='%s.r' % sMouthPivot)

        sParentRotMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sMouthPivotFront)
        sParentRotInverseMatrix = nodes.createInverseMatrix(sParentRotMatrix)
        constraints.matrixParentConstraint(sJawMouthPivot, cBotTops[0].sPasser, mo=True)
        constraints.matrixParentConstraint(sMouthPivotFront, cBotTops[1].sPasser, mo=True)

        # static sliding curve
        aaPoints = [patch.patchFromName(sBpCurvesA[0]).getPoints(), patch.patchFromName(sBpCurvesA[1]).getPoints()]
        for p in range(2):
            aNonSkippedIndices = utils.getFilteredFromAvoidIndices(len(aaPoints[p]), iSkipSplineJoints)
            aaPoints[p] = aaPoints[p][aNonSkippedIndices]

        aaPercs = [curves.getPercsFromPoints(sBpCurvesA[0], aaPoints[0]), curves.getPercsFromPoints(sBpCurvesA[1], aaPoints[1])]
        aaOuterPoints = [curves.getPointsFromPercs(sBpCurvesB[0], aaPercs[0]), curves.getPointsFromPercs(sBpCurvesB[1], aaPercs[1])]

        aMouthPivotFront = utils.getNumpyMatrixFromTransform(sMouthPivotFront)
        aInvMouthPivotFront = np.linalg.inv(aMouthPivotFront)
        aaLocalPoints = [np.dot(utils.makePoint4Array(aaPoints[0]), aInvMouthPivotFront)[:, 0:3],
                         np.dot(utils.makePoint4Array(aaPoints[1]), aInvMouthPivotFront)[:, 0:3]]
        # iMaxCurve = np.argmax([len(aaPoints[0]), len(aaPoints[1])])


        # only creating one sliding curve - using same for the top one
        sStaticSlideCurves = ['curve_l_mouthStaticSlide', 'curve_r_mouthStaticSlide']
        sStaticSlideUpCurves = ['curve_l_mouthStaticSlideUp', 'curve_r_mouthStaticSlideUp']
        sStaticSlideCurvesBp = [utils.replaceStringStart(sStaticSlideCurves[0], 'curve_', 'bpCurve_'), utils.replaceStringStart(sStaticSlideCurves[1], 'curve_', 'bpCurve_')]
        sStaticSlideUpCurvesBp = [utils.replaceStringStart(sStaticSlideUpCurves[0], 'curve_', 'bpCurve_'), utils.replaceStringStart(sStaticSlideUpCurves[1], 'curve_', 'bpCurve_')]

        aSlidePoints = np.copy(aaPoints[0])
        if True: # averaging in X of slide pivot
            aSlidePoints4 = utils.makePoint4Array(aSlidePoints)
            aSlidePointsLocal4 = np.dot(aSlidePoints4, np.linalg.inv(aMouthSlideMatrix))
            aSlidePointsLocal4[:,0] = np.average(aSlidePointsLocal4[:,0])
            aSlidePoints = np.dot(aSlidePointsLocal4, aMouthSlideMatrix)[:,0:3]
        aSlideUpPoints = aSlidePoints + aMouthSlideMatrix[0,0:3] * fCurveLengthes[0] * 0.05

        for s,sSide in enumerate(['l','r']):
            if cmds.objExists(sStaticSlideCurvesBp[s]):
                cmds.duplicate(sStaticSlideCurvesBp[s], n=sStaticSlideCurves[s])
            else:
                if cmds.objExists(sStaticSlideCurvesBp[1-s]):
                    sMirrored = geometry.meshMirrorNoBase([patch.patchFromName(sStaticSlideCurvesBp[1-s])], bWorld=True)[0]
                    cmds.rename(sMirrored, sStaticSlideCurves[s])
                else:
                    cmds.curve(p=aSlidePoints if s==0 else aSlidePoints[::-1], d=2, n=sStaticSlideCurves[s])
            if cmds.objExists(sStaticSlideUpCurvesBp[s]):
                cmds.duplicate(sStaticSlideUpCurvesBp[s], n=sStaticSlideUpCurves[s])
            else:
                if cmds.objExists(sStaticSlideUpCurvesBp[1-s]):
                    sMirrored = geometry.meshMirrorNoBase([patch.patchFromName(sStaticSlideUpCurvesBp[1-s])])[0]
                    cmds.rename(sMirrored, sStaticSlideUpCurves[s])
                else:
                   cmds.curve(p=aSlideUpPoints if s==0 else aSlideUpPoints[::-1], d=2, n=sStaticSlideUpCurves[s])
    
            cmds.skinCluster(sStaticSlideCurves[s], sMouthPivotFront, tsb=True)
            cmds.skinCluster(sStaticSlideUpCurves[s], sMouthPivotFront, tsb=True)

        cmds.parent(sStaticSlideCurves, sStaticSlideUpCurves, sGrp)



        sCornerSlidePlanes = []
        sCornerSlidePlanesOrig = []
        for s,sSide in enumerate(['l','r']):
            sBpSurface = 'bpNurbs_%s_cornerSlidePlane' % sSide
            if not cmds.objExists(sBpSurface):
                sMirrorSurface = utils.getMirrorName(sBpSurface)
                if not cmds.objExists(sMirrorSurface):
                    raise Exception('Corner Slide plane missing')
                cmds.duplicate(sMirrorSurface, n=sBpSurface)
                sTemp = cmds.createNode('transform', n='tempDelete')
                cmds.parent(sBpSurface, sTemp)
                cmds.setAttr('%s.sx' % sTemp, -1)
                cmds.parent(sBpSurface, kMouthBpGroupName)
                cmds.delete(sTemp)
            sSurface = cmds.duplicate(sBpSurface, n=utils.replaceStringStart(sBpSurface, 'bpN', 'n'))[0]
            cmds.parent(sSurface, sGrpMouthPivotFront)
            cmds.makeIdentity(sSurface, apply=True, t=True, r=True, s=True)
            cmds.setAttr('%s.rotatePivot' % sSurface, 0, 0, 0)
            cmds.setAttr('%s.scalePivot' % sSurface, 0, 0, 0)

            sSurfaceOrig = cmds.duplicate(sSurface, n='%s_orig' % sSurface)[0]
            for sA in ['t','r','s']:
                cmds.connectAttr('%s.%s' % (sSurface,sA), '%s.%s' % (sSurfaceOrig,sA))
            cmds.parent(sSurfaceOrig, sGrp)

            cmds.setAttr('%s.v' % sSurface, False)
            cmds.setAttr('%s.v' % sSurfaceOrig, False)
            sCornerSlidePlanesOrig.append(sSurfaceOrig)
            sCornerSlidePlanes.append(sSurface)



        sAttrs = ['tx','ty','tz','rx','ry','rz']
        ssJawSpaces = [(sJawMouthPivot, sGrpMouthPivotFront), (cBotTops[0].sJumped, sGrpMouthPivotFront), (sJawMouthPivot, cBotTops[1].sJumped)]
        sCornerNotUp = nodes.createRangeNode('lipsCorner_l_ctrl.ty', 0, 1, 1, 0), nodes.createRangeNode('lipsCorner_r_ctrl.ty', 0, 1, 1, 0)
        for cc,cCtrls in enumerate((cCorners, ccLipCtrls[0], ccLipCtrls[1])):
            for c,cC in enumerate(cCtrls):
                cC.cOrig = ctrls6.create('%sOrig' % cC.sName, cC.sSide, cC.iIndex, sMatch=cC.sCtrl, sParent=sLipsCtrlsParent,
                                         bIsNoCtrl=True, sAttrs=sAttrs)

                constraints.matrixParentConstraint(cC.sPasser, cC.cOrig.sPasser)

                sJawAttachAttr = utils.addAttr(cC.sCtrl, ln='jawAttach', min=0, max=1, dv=0, k=True)
                if 'TOP' in cC.sCtrl.upper() or 'CORNER' in cC.sCtrl.upper():
                    sJawAttach = nodes.createMultiplyNode(sJawAttachAttr, sCornerNotUp[1 if cC.sSide == 'r' else 0])
                else:
                    sJawAttach = sJawAttachAttr
                fSecondToFirst = nodes.createMultMatrixNode(['%s.worldMatrix' % ssJawSpaces[cc][0], '%s.worldInverseMatrix' % ssJawSpaces[cc][1]], bJustValues=True)
                sDefaultSettingAttrs.append(sJawAttachAttr)
                utils.addToListStringAttr(cC.sCtrl, utils.kSkipKeyImportAttrs, ['jawAttach'])
                sSecondOffsetted = nodes.createMultMatrixNode([fSecondToFirst, '%s.worldMatrix' % ssJawSpaces[cc][1]])
                sBlendMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % ssJawSpaces[cc][0], sSecondOffsetted],
                                                            [sJawAttach, nodes.createReverseNode(sJawAttach)])

                fAttachOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser, '%s.worldInverseMatrix' % ssJawSpaces[cc][0]], bJustValues=True)
                sAttachMatrix = nodes.createMultMatrixNode([fAttachOffset, sBlendMatrix, '%s.worldInverseMatrix' % sLipsCtrlsParent])


                nodes.createDecomposeMatrix(sAttachMatrix, sTargetPos='%s.t' % cC.sPasser, sTargetRot = '%s.r' % cC.sPasser)#, sTargetScale='%s.s' % cC.sPasser)

                sRelMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut, '%s.worldInverseMatrix' % cC.sSlider])

                if cc > 0: # not corners. because corners have a much more complicated setup further below
                    nodes.createDecomposeMatrix(sRelMatrix, sTargetPos='%s.t' % cC.cOrig.sCtrl, sTargetRot='%s.r' % cC.cOrig.sCtrl)



        fCornerJawAttach = 0.35
        for p, fMidStrength in enumerate([1, 0]):
            iHalfSize = len(ccLipCtrls[p]) // 2
            if len(ccLipCtrls[p]) % 2:
                iHalfSize += 1
            for c in range(iHalfSize):
                fMidPerc = (c+1) / float(iHalfSize)
                fMidPercRev = (1-fMidPerc) ** 3
                fMidPerc = 1-fMidPercRev
                fJawAttach = fCornerJawAttach * (1.0-fMidPerc) + fMidStrength * (fMidPerc)
                cmds.setAttr('%s.jawAttach' % ccLipCtrls[p][c].sCtrl, fJawAttach)
                cmds.setAttr('%s.jawAttach' % ccLipCtrls[p][-(c+1)].sCtrl, fJawAttach)

        for cC in cCorners:
            cmds.setAttr('%s.jawAttach' % cC.sCtrl, fCornerJawAttach)



        # corner slide setup
        sCornerSlideLocs = []
        for s,cCorner in enumerate(cCorners):
            sNegTranslateZGroup = xforms.insertParent(cCorner.sOut, '%s_tz' % cCorner.sOut, bMatchParentTransform=True)
            nodes.createMultiplyNode('%s.tz' % cCorner.sCtrl, -1.0, sTarget='%s.tz' % sNegTranslateZGroup)
            sLocalCornerMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sNegTranslateZGroup, '%s.worldInverseMatrix' % cCorner.sSlider])
            cCorner.sDecomp = nodes.createDecomposeMatrix(sLocalCornerMatrix).split('.')[0]

            fTranslates = (0,0), (0,2), (0,-2), (3,0), (-1,0)
            fCornerPoints = []
            for fT in fTranslates:
                cmds.setAttr('%s.tx' % cCorner.sCtrl, fT[0])
                cmds.setAttr('%s.ty' % cCorner.sCtrl, fT[1])
                fCornerPoints.append(cmds.xform(cCorner.sCtrl, q=True, ws=True, t=True))
            cmds.setAttr('%s.tx' % cCorner.sCtrl, 0)
            cmds.setAttr('%s.ty' % cCorner.sCtrl, 0)
            fUvs = surfaces.getParamsFromPoints(sCornerSlidePlanes[s], fCornerPoints)

            sUp = nodes.createRangeNode('%s.outputTranslateY' % cCorner.sDecomp, 0, fTranslates[1][1], fUvs[0][1], fUvs[1][1], bInfinity=True)
            sDown = nodes.createRangeNode('%s.outputTranslateY' % cCorner.sDecomp, 0, fTranslates[2][1], fUvs[0][1], fUvs[2][1], bInfinity=True)
            sOut = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sDecomp, 0, fTranslates[3][0], fUvs[0][0], fUvs[3][0], bInfinity=True)
            sIn = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sDecomp, 0, fTranslates[4][0], fUvs[0][0], fUvs[4][0], bInfinity=True)

            sSlideLoc = xforms.createLocator('loc_%s_mouthSlideLoc' % utils.sSides1[s], sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035) # is at werid location
            sCornerSlideLocs.append(sSlideLoc)
            sSurfaceNode, sSlidePos = surfaces.createPointInfoNode(sCornerSlidePlanesOrig[s], fUvs[0][0], fUvs[0][1], sTargetPos='%s.t' % sSlideLoc)

            sAimConstraint = constraints.aimConstraintEmpty(sSlideLoc)
            nodes.createVectorAdditionNode([sSlidePos, '%s.normal' % sSurfaceNode],
                                           sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            cmds.connectAttr('%s.tangentU' % sSurfaceNode, '%s.worldUpVector' % sAimConstraint)

            nodes.createConditionNode('%s.outputTranslateY' % cCorner.sDecomp, '>', 0, sUp, sDown, sTarget='%s.parameterV' % sSurfaceNode)
            nodes.createConditionNode('%s.outputTranslateX' % cCorner.sDecomp, '>', 0, sOut, sIn, sTarget='%s.parameterU' % sSurfaceNode)


            sAnimRotMatrix = nodes.createComposeMatrixNode(xRotate='%s.outputRotate' % cCorner.sDecomp)

            sFirstOffset = cmds.listRelatives(cCorner.cOrig.sCtrl, p=True)[0]
            sWorldCtrlWithoutJaw = nodes.createMultMatrixNode([nodes.createMultMatrixNode(['%s.worldMatrix' % sFirstOffset, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True),
                                                               '%s.worldMatrix' % sMouthPivotFront])

            fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.cOrig.sCtrl, '%s.worldInverseMatrix' % sSlideLoc], bJustValues=True)
            sMatrix = nodes.createMultMatrixNode([sAnimRotMatrix,
                                                  nodes.createComposeMatrixNode([0,0,'%s.tz' % cCorner.sCtrl]),
                                                  fOffset,
                                                  '%s.worldMatrix' % sSlideLoc,
                                                  nodes.createInverseMatrix(sWorldCtrlWithoutJaw)])

            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % cCorner.cOrig.sCtrl, sTargetRot='%s.r' % cCorner.cOrig.sCtrl)
            cmds.transformLimits(cCorner.sCtrl, etx=[True,False], tx=[-1,1000])


            cCorner.sInOutTxSum = utils.addAttr(cCorner.sCtrl, ln='txSum', k=True)
            cmds.connectAttr('%s.tx' % cCorner.sCtrl, cCorner.sInOutTxSum) #temporary connect, will be overwritten later



        # create JustAnim transforms. JustAnim transforms are just the animation of corner and lips. the bot/top box ctrls are extracted in a clamped way
        # those are to calculate better tangent orienting or jawOpen pose
        for cC in ccRows[0]+ccRows[1]:
            cC.sJustAnims = [None, None]
        for p,sPart in enumerate(['bot','top']):

            # create sJustAnim transforms for lip ctrls
            for c,cC in enumerate(ccLipCtrls[p]):
                cC.sJustAnims[p] = cmds.createNode('transform', n='grp_%s_%sJustAnim' % (cC.sSide, cC.sName), p=sGrpMouthPivotFront)

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlider, '%s.worldInverseMatrix' % sGrpMouthPivotFront], bJustValues=True)
                sAnim = nodes.createComposeMatrixNode(nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sOut), '%s.parentInverseMatrix' % cC.getOffsetByName('poses')))
                sJustAnimMatrix = nodes.createMultMatrixNode([sAnim, fOffset])
                nodes.createDecomposeMatrix(sJustAnimMatrix, sTargetPos='%s.t' % cC.sJustAnims[p], sTargetRot='%s.r' % cC.sJustAnims[p])

            # create sJustAnim transforms for corners
            for s,cC in enumerate(cCorners):
                sSliderInPasserSpace = nodes.createMultMatrixNode(['%s.matrix' % cC.sSlider, '%s.worldMatrix' % cC.sPasser])
                sSliderInPasserSpaceInverse = nodes.createInverseMatrix(sSliderInPasserSpace)
                
                fCornerFromBoxOffset = nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cBotTops[p].sJumped, bJustValues=True)
                sWorldCornerFromBox = nodes.createPointByMatrixNode(fCornerFromBoxOffset, '%s.worldMatrix' % cBotTops[p].sJumped)

                sTranslationPlusPoses = nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.parentInverseMatrix' % cC.getOffsetByName('poses'))
                sTranslateXY = ['%sX' % sTranslationPlusPoses, '%sY' % sTranslationPlusPoses, 0]

                sCornerFromBoxInCornerSpace = nodes.createPointByMatrixNode(sWorldCornerFromBox, sSliderInPasserSpaceInverse)

                cC.sJustAnims[p] = cmds.createNode('transform', n='grp_%s_%s%sJustAnim' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), p=sGrpMouthPivotFront)

                fOffset = nodes.createMultMatrixNode([sSliderInPasserSpace, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)

                sClamped = [None, None, '%sZ' % sCornerFromBoxInCornerSpace]
                sClamped[0] = '%sX' % sCornerFromBoxInCornerSpace

                sMaxY = nodes.createConditionNode('%sY' % sTranslationPlusPoses, '<' if p==0 else '>', 0, '%sY' % sTranslationPlusPoses, 0)
                if p == 0:
                    sClamped[1] = nodes.createClampNode('%sY' % sCornerFromBoxInCornerSpace, sMaxY, 0)
                else:
                    sClamped[1] = nodes.createClampNode('%sY' % sCornerFromBoxInCornerSpace, 0, sMaxY)

                sDiff = nodes.createVectorAdditionNode([sTranslateXY, sClamped], sOperation='minus')

                sAnim = nodes.createComposeMatrixNode(sDiff)
                sJustAnimMatrix = nodes.createMultMatrixNode([sAnim, fOffset])
                nodes.createDecomposeMatrix(sJustAnimMatrix, sTargetPos='%s.t' % cC.sJustAnims[p], sTargetRot='%s.r' % cC.sJustAnims[p])


        # generate values for static sliding curves
        fStaticCurveMidParams = [curves.getParamsFromPercs(sStaticSlideCurves[0], [0.5])[0], curves.getParamsFromPercs(sStaticSlideCurves[1], [0.5])[0]]

        for s, sSide in enumerate(['l', 'r']):
            fCurveLength = curves.getLength(sStaticSlideCurves[s])
            for p,sPart in enumerate(['bot','top']):
                cSideCtrls = [cC for cC in ccLipCtrls[p] if cC.sSide == sSide]
                aParams = curves.getParamsFromTransforms(sStaticSlideCurves[s], [cC.sCtrl for cC in cSideCtrls], bReturnNumpy=True)
                aPercs = curves.getPercsFromParams(sStaticSlideCurves[s], aParams, bReturnNumpy=True)
                for cC,fParam,fPerc in zip(cSideCtrls, aParams, aPercs):
                    cC.fParamStaticCurve = fParam
                    cC.fDistance = fCurveLength * fPerc
                
                # not tested yet!
                for cC in ccLipCtrls[p]:
                    if cC.sSide == 'm':
                        cC.fParamStaticCurve = fStaticCurveMidParams[s]
                        cC.fDistance = fCurveLength * 0.5

        for p,sPart in enumerate(['bot','top']):

            sEndTangents = [None, None]
            for c,cC in enumerate(ccLipCtrls[p]):
                if cC.sSide == 'm':
                    continue
                iSide = 1 if cC.sSide == 'r' else 0
                fSideMultipl = -1.0 if cC.sSide == 'r' else 1.0
                sMove = cC.appendOffsetGroup('movetocorner', sAboveOtherOffset='poses')
                sFollowY = utils.addAttr(cC.sPasser, ln='followCornerY', min=0, max=1, k=True)
                sFollowPathOut = utils.addAttr(cC.sPasser, ln='followCornerPathOut', min=0, max=1, k=True)
                sFollowPathIn = utils.addAttr(cC.sPasser, ln='followCornerPathIn', min=0, max=1, k=True)

                sDefaultSettingAttrs.append(sFollowY)
                sDefaultSettingAttrs.append(sFollowPathOut)
                sDefaultSettingAttrs.append(sFollowPathIn)

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[iSide].sJustAnims[p], '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)
                sParentMatrix = nodes.createMultMatrixNode([fOffset, '%s.worldMatrix' % sMouthPivotFront])
                sParentInverseMatrix = nodes.createInverseMatrix(sParentMatrix)
                sLocalMovingMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[iSide].sJustAnims[p], sParentInverseMatrix])
                sDecomp = nodes.createDecomposeMatrix(sLocalMovingMatrix)
                fDefaultValue = abs(cC.fPerc - 0.5)
                cmds.setAttr(sFollowY, fDefaultValue)
                cmds.setAttr(sFollowPathOut, fDefaultValue)
                cmds.setAttr(sFollowPathIn, fDefaultValue)

                sFollowPath = nodes.createConditionNode(cCorners[iSide].sInOutTxSum, '>', 0, sFollowPathOut, sFollowPathIn)


                fScaleFactorForUpDown = nodes.createMultiplyNode(1.0, '%s.sx' % cC.sPasser, sOperation='divide')
                fScaledForUpDown = nodes.createVectorMultiplyNode(sDecomp, fScaleFactorForUpDown, bVectorByScalar=True)
                sUpDown = '%sY' % fScaledForUpDown
                nodes.createMultiplyNode(sFollowY, sUpDown, sTarget='%s.ty' % sMove)


                sScaleFactorForPath = nodes.createMultiplyNode('%s.sx' % cCorners[iSide].sPasser, '%s.sx' % cC.sPasser, sOperation='divide')
                sScaledForPath = nodes.createVectorMultiplyNode(sDecomp, sScaleFactorForPath, bVectorByScalar=True)

                # sBack = nodes.createConditionNode('%sX' % sScaledForPath, '>', 0, '%sX' % sScaledForPath, 0.0)
                sBackForward = '%sX' % sScaledForPath

                cC.sSlidingGrpOut = cC.appendOffsetGroup('movetocornerpath', sAboveOtherOffset='poses')
                cC.sSlidingLocOut = xforms.createLocator('loc_%s_%sOutSlidingCopy_%03d' % (cC.sSide, cC.sName, 0 if utils.isNone(cC.iIndex) else cC.iIndex), sParent=sMouthPivotFront, fSize=fCurveLengthes[0]*0.035)
                sNode, sPos = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=cC.fParamStaticCurve)
                sUpNode, sUpPos = curves.createPointInfoNode(sStaticSlideUpCurves[iSide], fParam=cC.fParamStaticCurve)
                sPosAddition = nodes.createVectorAdditionNode([sPos]) #, sTarget='%s.t' % cC.sSlidingLocOut)
                nodes.createPointByMatrixNode(sPosAddition, '%s.worldInverseMatrix' % sMouthPivotFront, sTarget='%s.t' % cC.sSlidingLocOut)

                sAimConstraint = constraints.aimConstraintEmpty(cC.sSlidingLocOut, aim=[fSideMultipl,0,0])
                sTargetPos = nodes.createVectorAdditionNode([sPosAddition, '%s.tangent' % sNode])
                nodes.createPointByMatrixNode(sTargetPos, '%s.worldInverseMatrix' % sMouthPivotFront, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                sUpVector = nodes.createVectorAdditionNode([sUpPos, sPos], sOperation='minus')
                nodes.createPointByMatrixNode(sUpVector, sMouthPivotFrontInvRotationMatrix, sTarget='%s.worldUpVector' % sAimConstraint)

                fDistanceToCorner = abs((0) - cC.fDistance) # aaDistances[iSide][c])
                sDistanceToCornerBySpeed = nodes.createMultiplyNode(fDistanceToCorner, sFollowPath, sOperation='divide')

                # [cmds.connectAttr(sGlobalMouthScale, '%s.s%s' % (cC.sSlidingLocOut, sA)) for sA in ['x', 'y', 'z']]

                sPos = nodes.createRangeNode(sBackForward, 0, sDistanceToCornerBySpeed, cC.fParamStaticCurve, 0.0)
                sNeg = nodes.createRangeNode(sBackForward, 0, nodes.createMultiplyNode(sDistanceToCornerBySpeed,-1),
                                             cC.fParamStaticCurve, curves.getParamLength(sStaticSlideCurves[iSide]))
                nodes.createConditionNode(sBackForward, '>', 0, sPos, sNeg, sTarget=['%s.parameter' % sNode, '%s.parameter' % sUpNode])


                sSlidingLocLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingLocOut, '%s.worldInverseMatrix' % sMouthPivotFront])
                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingGrpOut, '%s.worldInverseMatrix' % cC.sSlidingLocOut], bJustValues=True)

                fAttachHeadSpaceNoJawMotion = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlider, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)

                sSlidingInLocal = nodes.createMultMatrixNode([fOffset,
                                                              # nodes.createComposeMatrixNode(xScale=[sMouthScale, sMouthScale, sMouthScale]),
                                                              sSlidingLocLocal,
                                                              nodes.createInverseMatrix(fAttachHeadSpaceNoJawMotion, bJustValues=True)])
                nodes.createDecomposeMatrix(sSlidingInLocal, sTargetPos='%s.t' % cC.sSlidingGrpOut, sTargetRot='%s.r' % cC.sSlidingGrpOut)


                # for after it reached the end
                if sEndTangents[iSide] == None:
                    sCornerInfoNode, _ = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=0.0)
                    sNormTangent = nodes.createNormalizedVector('%s.tangent' % sCornerInfoNode)
                    sEndTangents[iSide] = nodes.createVectorMultiplyNode(sNormTangent, -100, bVectorByScalar=True)
                # sBack2 = nodes.createConditionNode(sBackForward, '>', 0, sBackForward, 0.0) # actually it's not necessary, sBack would be enough, too. (tried to fix some update bug but didn't work anyway)

                nodes.createRangeNode(sBackForward, sDistanceToCornerBySpeed, 100, [0,0,0], nodes.createVectorMultiplyNode(sEndTangents[iSide], sFollowPath, bVectorByScalar=True),
                                       sTarget='%s.input3D[1]' % sPosAddition.split('.')[0], bOutRangeIsVector=True)

                # range_noname31 causes issue. is getting a weirdly high valueXYZ, and then snapping back





        # addPosingControls(ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners)# + cCornerTangents


        for s,sSide in enumerate(['l','r']):
            nodes.createAdditionNode(['%s.tx' % cCorners[s].sCtrl, '%s.tx' % cCorners[s].getOffsetByName('poses')], sTarget=cCorners[s].sInOutTxSum, bForce=True)



        def addAttrInclPoseCtrls(cC, ln, defaultValue=0, minValue=0, maxValue=1, k=True):
            sPoseCtrlsString = utils.getStringAttr(cC.sCtrl, 'sPoseCtrls', '[]')
            sPoseCtrls = eval(sPoseCtrlsString)
            sAttrs = []

            for c,sC in enumerate([cC.sCtrl]+sPoseCtrls):
                sAttrs.append(utils.addAttr(sC, ln=ln,
                                            defaultValue=defaultValue if c == 0 else 0,
                                            k=k, minValue=minValue, maxValue=maxValue))
            sSumAttr = utils.addAttr(cC.sPasser, ln='%sSum' % ln, k=True)
            nodes.createAdditionNode(sAttrs, sTarget=sSumAttr)
            return sSumAttr


        # create additional attributes
        for s,sSide in enumerate(['l','r']):
            cCorners[s].sRoundAttr = addAttrInclPoseCtrls(cCorners[s], ln='pointyRound', minValue=0, maxValue=1, k=True)
            cCorners[s].sRoundExceedAttr = utils.addAttr(cCorners[s].sPasser, ln='pointyRoundExceed', k=True)
            cCorners[s].sRoundExceedAutoAttr = utils.addAttr(cCorners[s].sPasser, ln='pointyRoundExceedWhenOn', k=True)

            cCorners[s].sTangentScales = [utils.addAttr(cCorners[s].sPasser, ln='tangentScaleBot', k=True, dv=1),
                                          utils.addAttr(cCorners[s].sPasser, ln='tangentScaleTop', k=True, dv=1)]
            cCorners[s].sTangentScalesAuto = [utils.addAttr(cCorners[s].sPasser, ln='tangentScaleBotAuto', k=True, dv=1),
                                              utils.addAttr(cCorners[s].sPasser, ln='tangentScaleTopAuto', k=True, dv=1)]
            sScaleSumNode = nodes.createVectorAdditionNode([ [cCorners[s].sTangentScales[0], cCorners[s].sTangentScales[1], 0],
                                                             [cCorners[s].sTangentScalesAuto[0], cCorners[s].sTangentScalesAuto[1], 0],
                                                             [-1,-1,0]]) # -1 = -2 + 1
            cCorners[s].sScaleSums = ['%sx' % sScaleSumNode, '%sy' % sScaleSumNode]
            utils.data.store('sTangentScalesAuto_%s' % sSide, cCorners[s].sTangentScalesAuto)


            cCorners[s].sSeal = addAttrInclPoseCtrls(cCorners[s], ln='seal', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
            cCorners[s].sSealFadeLength = utils.addAttr(cCorners[s].sCtrl, ln='sealFade', defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)


        ssPartInfluences = [[], []]
        ccCornerTangents = [[], []]
        # create control influence joints
        for p,sPart in enumerate(['bot','top']):
            fCurveLengthes[p] = curves.getLength(sBpCurvesA[0])
            fPartMult = 1 if p == 0 else -1

            for c,cC in enumerate(ccRows[p]):
                s = ['l','r','m'].index(cC.sSide)
                sI = cmds.createNode('joint', n='inf_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), p=cC.cOrig.sOut)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sI)
                sAimToNeighborsAttr = utils.addAttr(cC.sPasser, ln='aimToNeighbors', min=0, max=1, dv=0.0 if cC.sSide == 'm' else 1.0, k=True, bReturnIfExists=True)
                sDefaultSettingAttrs.append(sAimToNeighborsAttr)
                sNoRotCtrl = cmds.duplicate(cC.cOrig.sCtrl, n='grp_%s_%sMouthNoRot%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), po=True)[0]
                cmds.connectAttr('%s.t' % cC.cOrig.sCtrl, '%s.t' % sNoRotCtrl)
                if c in [0, len(ccRows[p])-1]: # corners
                    sParentI = xforms.insertParent(sI, 'parent_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)))
                    sTangentParent = '%sTangentParent' % utils.replaceStringStart(cC.sOut, 'ctrl_', 'grp_')
                    if not cmds.objExists(sTangentParent):
                        cmds.duplicate(cC.sOut, n=sTangentParent)[0]
                        cmds.parent(sTangentParent, cC.sCtrl)
                        xforms.matchLocalTransformAttributes(cC.sOut, sTangentParent)

                    cTangent = ctrls6.create('cornerTangent%s' % utils.getFirstLetterUpperCase(sPart), sSide=cC.sSide, sMatch=sI, sShape='revL',
                                                 sParent=sTangentParent, sAttrs=['rx','ry','rz'], fRotateShape=[180,0,0], fSize=fCurveLengthes[0]*0.2, iColorIndex=0)

                    cTangent.sJumpedMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cTangent.sCtrl,
                                                                             '%s.worldInverseMatrix' % cC.sExtraMove,
                                                                             '%s.worldMatrix' % cC.sPasser])

                    ccCornerTangents[s].append(cTangent)
                    sCtrlVis = utils.addOffOnAttr(cC.sCtrl, 'tangentCtrl%sVis' % utils.getFirstLetterUpperCase(sPart), bDefaultValue=True, bReturnIfExists=True)
                    sDefaultSettingAttrs.append(sCtrlVis)
                    
                    cmds.connectAttr(sCtrlVis, '%s.v' % cTangent.sPasser)
                    cmds.connectAttr('%s.r' % sParentI, '%s.r' % cTangent.sPasser)
                    cmds.connectAttr('%s.ro' % sParentI, '%s.ro' % cTangent.sPasser)
                    sTangentAnimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cTangent.sOut, '%s.worldInverseMatrix' % cTangent.sPasser])
                    nodes.createDecomposeMatrix(sTangentAnimMatrix, sTargetPos='%s.t' % sI, sTargetRot='%s.r' % sI)
                    sAimConstraint = constraints.aimConstraintEmpty(sParentI)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0, 0, 1)

                    if c == 0:
                        sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][1].cOrig.sCtrl), '%s.worldInverseMatrix' % sNoRotCtrl)
                    else:
                        sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][-2].cOrig.sCtrl), '%s.worldInverseMatrix' % sNoRotCtrl)
                    fLength = np.linalg.norm(np.array(cmds.getAttr(sAimTarget)[0], dtype='float64'))

                    sRoundRotate = nodes.createAdditionNode([cC.sRoundExceedAttr,
                                                             nodes.createMultiplyNode(cC.sRoundExceedAutoAttr, cC.sRoundAttr)])

                    sSignedRoundRotate = sRoundRotate if p == 0 else nodes.createMultiplyNode(sRoundRotate, -1)

                    sExceededRoundAimTarget = nodes.createPointByMatrixNode([0, fLength*(-fPartMult), 0],
                                                                            nodes.createComposeMatrixNode(xRotate=[0,0,sSignedRoundRotate]))

                    nodes.createBlendNode(cC.sRoundAttr, sExceededRoundAimTarget, sAimTarget, bVector=True,
                                                       sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                    cmds.connectAttr(cCorners[0 if c == 0 else 1].sScaleSums[p], '%s.sx' % sI)



                else:
                    sAimConstraint = constraints.aimConstraintEmpty(sI)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0, 0, 1)

                    sAimTargetA = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][c-1].sJustAnims[p]), '%s.worldInverseMatrix' % cC.sJustAnims[p])
                    sAimTargetB = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][c+1].sJustAnims[p]), '%s.worldInverseMatrix' % cC.sJustAnims[p])
                    sAimTarget = nodes.createVectorAdditionNode([sAimTargetA, sAimTargetB], sOperation='minus')

                    nodes.createBlendNode(sAimToNeighborsAttr, sAimTarget, cmds.getAttr(sAimTarget)[0], bVector=True,
                                                         sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                ssPartInfluences[p].append(sI)


        ddPoses = updateDdPoses(ddPoses)

        cCornerTangents = utils.flattenedList(ccCornerTangents)
        addPosingControls(cCornerTangents)
        # print ('cPosingCtrls: ', cPosingCtrls)

        ## jaw open pose
        sJawDriverAttr = ddPoses['jawOpen']['sCtrlDriverAttr']

        for cC in cBotTops:
            sMatrixSkipped = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl,
                                                        '%s.worldInverseMatrix' % cC.getOffsetByName('extramove'),
                                                         '%s.worldMatrix' % cC.sPasser])
            cC.sCtrlHeight = '%sY' % nodes.createPointByMatrixNode(nodes.createDecomposeMatrix(sMatrixSkipped), '%s.worldInverseMatrix' % sMouthPivotFront)
            if False:
                sAttr = utils.addAttr(cC.sCtrl, ln='ctrlHeight', k=True)
                cmds.connectAttr(cC.sCtrlHeight, sAttr)

            
        for cC in cCorners:
            cC.sCtrlHeight = '%sY' % nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sPasser), '%s.worldInverseMatrix' % sMouthPivotFront)
            if False:
                sAttr = utils.addAttr(cC.sCtrl, ln='ctrlHeight', k=True)
                cmds.connectAttr(cC.sCtrlHeight, sAttr)





        ## POSES
        
        ddPoseDriverDatas = {}

        # first create the jawAloneDriver so poses are only activated if jaw is on
        sJawAngle = xforms.getSignedAngle3('jnt_m_jawMain', 'jnt_m_headMain', iAngleAxis=2)
        fJawAnglePoses = [cmds.getAttr(sJawAngle), None]
        cmds.setAttr(sJawDriverAttr, ddPoses['jawOpen']['fCtrlDriverValue'])
        fJawAnglePoses[1] = cmds.getAttr(sJawAngle)
        cmds.setAttr(sJawDriverAttr, 0.0)
        sJawAloneDriver = nodes.createRangeNode(sJawAngle, fJawAnglePoses[0], fJawAnglePoses[1], 0, 1, sName='jawAloneDriver')

        utils.addAttr('jnt_m_jawMain', ln='jawOpenPoseOverrideRotZ', dv=ddPoses['jawOpen']['fCtrlDriverValue'], k=True)

        xBoxHeights = [[[None, None], [None, None], [None, None]],
                       [[None, None], [None, None], [None, None]]]
        sCornerAverageCtrlHeight = nodes.createBlendNode(0.5, cCorners[0].sCtrlHeight, cCorners[1].sCtrlHeight)
        for p,sPart in enumerate(['bot','top']):
            #left:
            xBoxHeights[p][0][0] = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, cCorners[0].sCtrlHeight], sOperation='minus')
            xBoxHeights[p][0][1] = cmds.getAttr(xBoxHeights[p][0][0])
            if False:
                sInfoAttr = utils.addAttr(cCorners[0].sCtrl, ln='boxHeight_%s' % sPart, k=True)
                cmds.connectAttr(xBoxHeights[p][0][0], sInfoAttr)
            
            
            # right:
            xBoxHeights[p][1][0] = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, cCorners[1].sCtrlHeight], sOperation='minus')
            xBoxHeights[p][1][1] = cmds.getAttr(xBoxHeights[p][1][0])
            if False:
                sInfoAttr = utils.addAttr(cCorners[1].sCtrl, ln='boxHeight_%s' % sPart, k=True)
                cmds.connectAttr(xBoxHeights[p][1][0], sInfoAttr)

            
            # middle:
            xBoxHeights[p][2][0] = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, sCornerAverageCtrlHeight], sOperation='minus')
            xBoxHeights[p][2][1] = cmds.getAttr(xBoxHeights[p][2][0])

        # jawopen drivers
        ddPoseDriverDatas['jawOpen'] = {'bBotTop': True, 'driver_bot': {}, 'driver_top': {}}
        for p,sPart in enumerate(['bot','top']):

            cmds.setAttr(sJawDriverAttr, ddPoses['jawOpen']['fCtrlDriverValue'])
            fPosedBoxHeightLeft = cmds.getAttr(xBoxHeights[p][0][0])
            fPosedBoxHeightRight = cmds.getAttr(xBoxHeights[p][1][0])
            fPosedBoxHeightMiddle = cmds.getAttr(xBoxHeights[p][2][0])
            cmds.setAttr(sJawDriverAttr, 0)

            ddPoseDriverDatas['jawOpen']['driver_%s' % sPart]['driver_l'] = nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][0][0], xBoxHeights[p][0][1], fPosedBoxHeightLeft, 0, 1),
                                                                                               sJawAloneDriver], sName='jawOpen_l_%s_' % utils.getFirstLetterUpperCase(sPart))
            ddPoseDriverDatas['jawOpen']['driver_%s' % sPart]['driver_r'] = nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][1][0], xBoxHeights[p][1][1], fPosedBoxHeightRight, 0, 1), 
                                                                                               sJawAloneDriver], sName='jawOpen_r_%s_' % utils.getFirstLetterUpperCase(sPart))
            ddPoseDriverDatas['jawOpen']['driver_%s' % sPart]['driver_m'] = nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][2][0], xBoxHeights[p][1][1], fPosedBoxHeightMiddle, 0, 1),
                                                                                               sJawAloneDriver], sName='jawOpen_m_%s_' % utils.getFirstLetterUpperCase(sPart))

            ddPoseDriverDatas['jawOpen']['sCtrlDriverAttrs'] = [sJawDriverAttr]

        utils.addStringAttr('jnt_m_jawMain', 'jawOpen_driver_bot', ddPoseDriverDatas['jawOpen']['driver_bot']['driver_l'])
        utils.addStringAttr('jnt_m_jawMain', 'jawOpen_driver_top', ddPoseDriverDatas['jawOpen']['driver_top']['driver_l'])


        iPosePower = 1
        # for cornerUp/Down we need different xBoxHeights
        xBoxHeights = [[[None, None], [None, None], [None, None]],
                       [[None, None], [None, None], [None, None]]]
        cCorners[0].sCtrlInBoxSpaces = [None, None]
        cCorners[1].sCtrlInBoxSpaces = [None, None]
        for p, sPart in enumerate(['bot', 'top']):
            cCorners[0].sCtrlInBoxSpaces[p] = nodes.createPointByMatrixNode(cCorners[0].sJumpedPos, cBotTops[p].sJumpedInverseMatrix)
            cCorners[1].sCtrlInBoxSpaces[p] = nodes.createPointByMatrixNode(cCorners[1].sJumpedPos, cBotTops[p].sJumpedInverseMatrix)

            # left:
            xBoxHeights[p][0][0] = '%sY' % cCorners[0].sCtrlInBoxSpaces[p]
            xBoxHeights[p][0][1] = cmds.getAttr(xBoxHeights[p][0][0])
            if False:
                sInfoAttr = utils.addAttr(cCorners[0].sCtrl, ln='boxHeight2_%s' % sPart, k=True)
                cmds.connectAttr(xBoxHeights[p][0][0], sInfoAttr)

            # right:
            xBoxHeights[p][1][0] = '%sY' % cCorners[1].sCtrlInBoxSpaces[p]
            xBoxHeights[p][1][1] = cmds.getAttr(xBoxHeights[p][1][0])
            if False:
                sInfoAttr = utils.addAttr(cCorners[1].sCtrl, ln='boxHeight2_%s' % sPart, k=True)
                cmds.connectAttr(xBoxHeights[p][1][0], sInfoAttr)

            # middle:
            xBoxHeights[p][2][0] = nodes.createBlendNode(0.5, xBoxHeights[p][0][0], xBoxHeights[p][1][0])
            xBoxHeights[p][2][1] = cmds.getAttr(xBoxHeights[p][2][0])


        for sPoseKey, p in [('cornerUp', 1), ('cornerDown', 1)]:
            ddPoseDriverDatas[sPoseKey] = {'bBotTop': True, 'driver_bot': {}, 'driver_top': {}}

            sCtrlDriverAttrs = [ddPoses[sPoseKey]['sCtrlDriverAttr']]
            sCtrlDriverAttrs.append(utils.getMirrorName(sCtrlDriverAttrs[0]))
            fPoseValue = ddPoses[sPoseKey]['fCtrlDriverValue']

            sNormalizedCtrlDrivers = [nodes.createRangeNode(sCtrlDriverAttrs[s], 0, fPoseValue, 0, 1) for s in [0,1]]
            sCombinedNormalizedCtrlDriver = nodes.createBlendNode(0.5, sNormalizedCtrlDrivers[0], sNormalizedCtrlDrivers[1])


            for p,sPart in enumerate(['bot','top']):

                cmds.setAttr(sCtrlDriverAttrs[0], ddPoses[sPoseKey]['fCtrlDriverValue'])
                cmds.setAttr(sCtrlDriverAttrs[1], ddPoses[sPoseKey]['fCtrlDriverValue'])
                fPosedBoxHeightLeft = cmds.getAttr(xBoxHeights[p][0][0])
                fPosedBoxHeightRight = cmds.getAttr(xBoxHeights[p][1][0])
                fPosedBoxHeightMiddle = cmds.getAttr(xBoxHeights[p][2][0])
                cmds.setAttr(sCtrlDriverAttrs[0], 0)
                cmds.setAttr(sCtrlDriverAttrs[1], 0)

                ddPoseDriverDatas[sPoseKey]['driver_%s' % sPart]['driver_l'] = \
                    nodes.createMultiplyNode(nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][0][0], xBoxHeights[p][0][1], fPosedBoxHeightLeft, 0, 1),
                                                                    sNormalizedCtrlDrivers[0]], sName='%s_l_' % sPoseKey),  iPosePower, sOperation='power')
                ddPoseDriverDatas[sPoseKey]['driver_%s' % sPart]['driver_r'] = \
                    nodes.createMultiplyNode(nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][1][0], xBoxHeights[p][1][1], fPosedBoxHeightRight, 0, 1),
                                                                    sNormalizedCtrlDrivers[1]], sName='%s_r_' % sPoseKey), iPosePower, sOperation='power')

                ddPoseDriverDatas[sPoseKey]['driver_%s' % sPart]['driver_m'] = \
                    nodes.createMultiplyNode(nodes.createMinimumNode([nodes.createRangeNode(xBoxHeights[p][2][0], xBoxHeights[p][1][1], fPosedBoxHeightMiddle, 0, 1),
                                                                    sCombinedNormalizedCtrlDriver], sName='%s_m_' % sPoseKey), iPosePower, sOperation='power')
                ddPoseDriverDatas[sPoseKey]['sCtrlDriverAttrs'] = sCtrlDriverAttrs



        ## create drivers of lip roll

        for p,sPart in enumerate(['bot','top']):
            sAngle = xforms.getSignedAngle3(cBotTops[p].sCtrl, cBotTops[p].sSlider, iUpAxis=2)
            sAngleAttr = utils.addAttr(cBotTops[p].sPasser, ln='rollAngle', k=True)
            nodes.createMultiplyNode(sAngle, -1, sTarget=sAngleAttr)

            for sPoseKeyType in ['RollIn', 'RollOut']:
                sPoseKey = '%s%s' % (sPart, sPoseKeyType)
                ddPoseDriverDatas[sPoseKey] = {'bBotTop': False, 'driver_all': {}, 'driver_bot': {}, 'driver_top': {}}
                sCtrlDriverAttrs = [ddPoses[sPoseKey]['sCtrlDriverAttr']]
                sCtrlDriverAttrs.append(utils.getMirrorName(sCtrlDriverAttrs[0]))

                fPoseValue = ddPoses[sPoseKey]['fCtrlDriverValue']
                sRange = nodes.createRangeNode(sAngleAttr, 0, fPoseValue, 0, 1)
                ddPoseDriverDatas[sPoseKey]['driver_all']['driver_l'] = sRange
                ddPoseDriverDatas[sPoseKey]['driver_all']['driver_r'] = sRange
                ddPoseDriverDatas[sPoseKey]['driver_all']['driver_m'] = sRange

                # just to keep the pose creating function simple (combos)
                for _sPart in ['bot','top']:
                    ddPoseDriverDatas[sPoseKey]['driver_%s' % _sPart]['driver_l'] = ddPoseDriverDatas[sPoseKey]['driver_all']['driver_l']
                    ddPoseDriverDatas[sPoseKey]['driver_%s' % _sPart]['driver_r'] = ddPoseDriverDatas[sPoseKey]['driver_all']['driver_r']
                    ddPoseDriverDatas[sPoseKey]['driver_%s' % _sPart]['driver_m'] = ddPoseDriverDatas[sPoseKey]['driver_all']['driver_m']

                ddPoseDriverDatas[sPoseKey]['sCtrlDriverAttrs'] = sCtrlDriverAttrs

        ## create drivers of simple poses
        for sPoseKey in ['cornerOut', 'cornerIn', 'funnel', 'lipPress']:
            ddPoseDriverDatas[sPoseKey] = {'bBotTop': False, 'driver_all': {}, 'driver_bot': {}, 'driver_top': {}}
            print ('sPoseKey: ', sPoseKey)
            print ('ddPoses[sPoseKey]: ', ddPoses[sPoseKey])
            sCtrlDriverAttrs = [ddPoses[sPoseKey]['sCtrlDriverAttr']]
            sCtrlDriverAttrs.append(utils.getMirrorName(sCtrlDriverAttrs[0]))

            fPoseValue = ddPoses[sPoseKey]['fCtrlDriverValue']
            sLeft = nodes.createRangeNode(sCtrlDriverAttrs[0], 0, fPoseValue, 0, 1)
            sRight = nodes.createRangeNode(sCtrlDriverAttrs[1], 0, fPoseValue, 0, 1)
            ddPoseDriverDatas[sPoseKey]['driver_all']['driver_l'] = sLeft
            ddPoseDriverDatas[sPoseKey]['driver_all']['driver_r'] = sRight
            ddPoseDriverDatas[sPoseKey]['driver_all']['driver_m'] = nodes.createBlendNode(0.5, sLeft, sRight)

            # just to keep the pose creating function simple (combos)
            for p,sPart in enumerate(['bot','top']):
                ddPoseDriverDatas[sPoseKey]['driver_%s' % sPart]['driver_l'] = ddPoseDriverDatas[sPoseKey]['driver_all']['driver_l']
                ddPoseDriverDatas[sPoseKey]['driver_%s' % sPart]['driver_r'] = ddPoseDriverDatas[sPoseKey]['driver_all']['driver_r']
                ddPoseDriverDatas[sPoseKey]['driver_%s' % sPart]['driver_m'] = ddPoseDriverDatas[sPoseKey]['driver_all']['driver_m']

            ddPoseDriverDatas[sPoseKey]['sCtrlDriverAttrs'] = sCtrlDriverAttrs


        utils.data.store('ddFaceCtrlDriverDatas', ddPoseDriverDatas)

        # connectFaceCtrlPoses(ddPoses)


        # END OF POSES


        # move ctrl shapes to outer curves
        for p, cCtrls in enumerate([(ccLipCtrls[0] + [cBotTops[0]] + cCorners),
                                    (ccLipCtrls[1] + [cBotTops[1]])]): #excluded cBotTop ctrls
            aCurrentPositions = xforms.getPositionArray([cC.sCtrl for cC in cCtrls])
            if True: # find by closest
                aMoveToPositions = curves.getPointsFromPoints(sBpCurvesB[p], aCurrentPositions, bReturnNumpy=True)
            else: # find by percentage
                fCtrlPercs = [cC.fPerc for cC in cCtrls]
                aMoveToPositions = curves.getPointsFromPercs(sBpCurvesB[p], fCtrlPercs, bReturnNumpy=True)
            aMoves = aMoveToPositions - aCurrentPositions
            for c,cC in enumerate(cCtrls):
                pCtrl = patch.patchFromName(cC.sShape)
                pCtrl.setPoints(pCtrl.getPoints() + aMoves[c])

        # slide ctrls

        cSlideCtrls = ccLipCtrls[0]+ccLipCtrls[1]

        fCurveLengths = [curves.getLength(sStaticSlideCurves[0]), curves.getLength(sStaticSlideCurves[1])]
        for s,cCorner in enumerate(cCorners):
            sPuckerFactor = utils.addAttr(cCorner.sPasser, ln='puckerFactor', k=True, min=0.1, max=10, dv=1.0)
            sDefaultSettingAttrs.append(sPuckerFactor)
            cCorner.sFullPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(cCorner.sCtrl), '%s.worldInverseMatrix' % cCorner.sSlider)
            sCornerX = nodes.createMultiplyNode('%sX' % cCorner.sFullPoint, '%s.sx' % cCorner.sPasser)
            sPuckerDistance = nodes.createConditionNode(sCornerX, '<', 0, sCornerX, 0.0)
            sPuckerDistance = nodes.createMultiplyNode(sPuckerDistance, sPuckerFactor)

            sMidPercAttr = utils.addAttr(cCorner.sPasser, ln='midPerc', k=True)
            sNegHalfCurveLength = nodes.createMultiplyArrayNode([-fCurveLengths[s] * 0.5, 1]) #sGlobalMouthScale])
            nodes.createMultiplyNode(sPuckerDistance, sNegHalfCurveLength, sOperation='divide', sTarget=sMidPercAttr)


        for cCtrl in cBotLips+cTopLips:
            cCtrl.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[2:]])



        #
        # lipsEnd joints
        #
        sLipsEndJoints = []
        for s, sSide in enumerate(['l', 'r']):
            # lipsEnd joint
            sLipsEnd = 'jnt_%s_lipsEnd' % sSide
            if cmds.objExists(sLipsEnd):
                cmds.parent(sLipsEnd, sMouthPivotFront)
            else:
                cmds.createNode('joint', n=sLipsEnd, p=sMouthPivotFront)
            xforms.resetTransform(sLipsEnd, jo=True)
            cmds.setAttr('%s.radius' % sLipsEnd, fCurveLengthes[0] * 0.075)
            cmds.setAttr('%s.segmentScaleCompensate' % sLipsEnd, False)
            sLipsEndJoints.append(sLipsEnd)
            


        #
        # start doing the splines 
        #
        ssSmallJointMatrices = [None, None]
        ssBigJointMatrices = [[], []]
        ssLocMatrices = [None, None]
        ssSmallJoints = [[], []]
        ssBigJoints = [[], []]

        for p,sPart in enumerate(['bot','top']):
            fCurveLengthes[p] = curves.getLength(sBpCurvesA[0])
            fPartMult = 1 if p == 0 else -1



            # cRow = [cCorners[0]] + ccLipCtrls[p] + [cCorners[1]]
            fPercs = [0] + curves.getPercsFromTransforms(sBpCurvesA[p], [cC.sCtrl for cC in ccLipCtrls[p]]) + [1]
            fPercs = utils.addTangents(fPercs, bRemoveMains=False)
            sCurve = curves.rebuildWithPercs(sBpCurvesA[p], fPercs, bCreateNew=True, sName='curve_m_%sMouth' % sPart, sParent=sGrp)
            sPivotCurve = cmds.duplicate(sCurve, n='%sPivot' % sCurve)[0]
            cmds.setAttr('%sShape.lineWidth' % sPivotCurve, 10.0)
            cmds.setAttr('%sShape.lineWidth' % sCurve, 5.0)
            cmds.parent(sPivotCurve, utils.getMasterName())
            utils.addOffOnAttr(cMouth.sPasser, 'pivotCurveVis', sTarget='%s.v' % sPivotCurve, bReturnIfExists=True)

            utils.data.store('sRoundExceedWhenOnAttrs', [cCorners[0].sRoundExceedAutoAttr, cCorners[1].sRoundExceedAutoAttr])
            cmds.skinCluster(sCurve, ssPartInfluences[p], tsb=True, mi=1)
            pCurve = patch.patchFromName(sCurve)
            weights.skinCurveBSpline4(pCurve, ssPartInfluences[p], bStrongEnds=True, iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)
            pCurve.aIds = pCurve.aIds[1:-1]
            weights.smoothSkinWeights([pCurve], iIterations=2, _bSkipDeformerAdjustLogging=True)
            iSplineJointCount = len(aaPoints[p])


            sPivotInfluences = [xforms.createJoint('%s_pivot' % sI, fSize=cmds.getAttr('%s.radius' % sI), sParent=sI) for sI in ssPartInfluences[p]]
            cmds.skinCluster(sPivotCurve, sPivotInfluences, tsb=True, mi=1)
            pPivotCurve = patch.patchFromName(sPivotCurve)
            _, sGetInfs, aaWeights = patch.patchFromName(pCurve.getTransformName()).getSkinCluster() # it has to be reset, because the previous one has less aIds
            pPivotCurve.setSkinClusterWeights(aaWeights, ['%s_pivot' % sI for sI in sGetInfs])
            for c,cC in enumerate(ccRows[p]):

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl, '%s.worldInverseMatrix' % ssPartInfluences[p][c]], bJustValues=True)
                sTranslations = [utils.addAttr(cC.sPasser, ln='%s_pivotX' % sPart, k=True, dv=dDefaultSettingValues.get('%s.%s_pivotX' % (cC.sPasser, sPart), 0)),
                                 utils.addAttr(cC.sPasser, ln='%s_pivotY' % sPart, k=True, dv=dDefaultSettingValues.get('%s.%s_pivotY' % (cC.sPasser, sPart), 0)),
                                 utils.addAttr(cC.sPasser, ln='%s_pivotZ' % sPart, k=True, dv=dDefaultSettingValues.get('%s.%s_pivotZ' % (cC.sPasser, sPart), 0))]

                sMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sTranslations), fOffset])
                nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % sPivotInfluences[c])
                sDefaultSettingAttrs.extend(sTranslations)

            sSides, iIndices = utils.convertMiddleSequenceToSides(iSplineJointCount)
            sLocs = []
            fParams = curves.getParamsFromPoints(sCurve, aaPoints[p])
            aPercs = curves.getPercsFromParams(sCurve, fParams, bReturnNumpy=True)


            for j in range(iSplineJointCount):
                sJ = 'jnt_%s_%sMouthSplineSmall_%03d' % (sSides[j], sPart, iIndices[j])
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sMouthPivotFront)
                else:
                    cmds.createNode('joint', n=sJ, p=sMouthPivotFront)
                xforms.resetTransform(sJ, jo=True)
                cmds.setAttr('%s.radius' % sJ, fCurveLengthes[p]*0.025)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                utils.addAttr(sJ, ln='createdFromFaceRigFunction')
                sPercAttr = utils.addAttr(sJ, ln='perc', dv=aPercs[j], k=True)
                cmds.setAttr(sPercAttr, lock=True)
                ssSmallJoints[p].append(sJ)

            for j in range(iSplineJointCount):
                sJ = 'jnt_%s_%sMouthSplineBig_%03d' % (sSides[j], sPart, iIndices[j])
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sMouthPivotFront)
                else:
                    cmds.createNode('joint', n=sJ, p=sMouthPivotFront)
                xforms.resetTransform(sJ, jo=True)
                cmds.setAttr('%s.radius' % sJ, fCurveLengthes[p]*0.05)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                utils.addAttr(sJ, ln='createdFromFaceRigFunction')
                utils.addStringAttr(sJ, 'skinParent', ssSmallJoints[p][j], bLock=True)
                ssBigJoints[p].append(sJ)

            fCtrlPercs = np.array([cC.fPerc for cC in ccRows[p]], dtype='float64')
            xCtrlWeightings = xforms.getCtrlWeightings(aPercs, fCtrlPercs)

            sTwistUps = []
            for c,cC in enumerate(ccRows[p]):
                sRotMatrix = nodes.createMultMatrixNode([nodes.getRotationMatrix2('%s.worldMatrix' % cC.cOrig.sCtrl), sParentRotInverseMatrix])
                sTwistUps.append(nodes.createPointByMatrixNode([0, 0, 1], sRotMatrix))
                cC.sLiveTangentAttr = utils.addAttr(cC.sPasser, ln='liveTangent', min=0, max=1, k=True, dv=0.0, bReturnIfExists=True)
                sDefaultSettingAttrs.append(cC.sLiveTangentAttr)

                
            # create locs
            #
            for j,fP in enumerate(fParams):
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                sAimGrp = xforms.createTransform('grp_%s_%sMouthSpline_%03d' % (sSides[j], sPart, iIndices[j]), sParent=sGrpMouthPivotFront)
                sLoc = xforms.createLocator('loc_%s_%sMouthSpline_%03d' % (sSides[j], sPart, iIndices[j]), sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035)
                sPivotLoc = xforms.createLocator('loc_%s_%sMouthSplinePivot_%03d' % (sSides[j], sPart, iIndices[j]), sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035)
                sPivotStaticLoc = xforms.createLocator('loc_%s_%sMouthSplinePivotStatic_%03d' % (sSides[j], sPart, iIndices[j]), sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.035)
                sNode, sPos = curves.createPointInfoNode(sCurve, fP)
                sPivotNode, sPivotPos = curves.createPointInfoNode(sPivotCurve, fP)
                sLocalPos = nodes.createPointByMatrixNode(sPos, '%s.worldInverseMatrix' % sMouthPivotFront)
                sPivotLocalPos = nodes.createPointByMatrixNode(sPivotPos, '%s.worldInverseMatrix' % sMouthPivotFront)

                sUpBlend = nodes.createBlendNode(fBlend, sTwistUps[iCtrl1], sTwistUps[iCtrl0], bVector=True)


                # pivot aim:
                sPivotAimConstraint = constraints.aimConstraintEmpty(sPivotLoc, aim=[0,1,0], up=[-1,0,0]) # aim will be set back to [0,0,1] below
                nodes.createPointByMatrixNode('%s.tangent' % sPivotNode, sParentRotInverseMatrix, sTarget='%s.worldUpVector' % sPivotAimConstraint)
                nodes.createVectorAdditionNode([sPivotLocalPos, sUpBlend], sTarget='%s.target[0].targetTranslate' % sPivotAimConstraint)
                cmds.connectAttr(sPivotLocalPos, '%s.t' % sPivotLoc)

                sPivotStaticAimConstraint = constraints.aimConstraintEmpty(sPivotStaticLoc, aim=[0,1,0], up=[-1,0,0]) # aim will be set back to [0,0,1] below
                nodes.createPointByMatrixNode('%s.tangent' % sPivotNode, sParentRotInverseMatrix, sTarget='%s.worldUpVector' % sPivotStaticAimConstraint)
                nodes.createVectorAdditionNode([sPivotLocalPos, cmds.getAttr(sUpBlend)[0]], sTarget='%s.target[0].targetTranslate' % sPivotStaticAimConstraint)
                cmds.connectAttr(sPivotLocalPos, '%s.t' % sPivotStaticLoc)


                aLocalPos = np.array(cmds.getAttr(sLocalPos)[0], dtype='float64')
                fSmallOffset = aaLocalPoints[p][j] - aLocalPos
                nodes.createVectorAdditionNode([sLocalPos, fSmallOffset], sTarget='%s.t' % sAimGrp)
                sAimConstraint = constraints.aimConstraintEmpty(sAimGrp, aim=[0,1,0], up=[-1,0,0]) # aim will be set back to [0,0,1] below
                sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sParentRotInverseMatrix)
                sLiveTangentBlend = nodes.createBlendNode(fBlend, ccRows[p][iCtrl1].sLiveTangentAttr, ccRows[p][iCtrl0].sLiveTangentAttr)
                nodes.createBlendNode(sLiveTangentBlend, sTangent, cmds.getAttr(sTangent)[0], bVector=True, sTarget='%s.worldUpVector' % sAimConstraint)
                fFinalXform = cmds.getAttr('%s.worldMatrix' % sAimGrp)



                # constraints.matrixParentConstraint(sAimGrp, sLoc)
                sFinalLocMatrix = nodes.createMultMatrixNode(['%s.matrix' % sAimGrp,
                                                            '%s.inverseMatrix' % sPivotStaticLoc,
                                                            '%s.matrix' % sPivotLoc])
                nodes.createDecomposeMatrix(sFinalLocMatrix, sTargetPos='%s.t' % sLoc, sTargetRot='%s.r' % sLoc)

                nodes.createVectorAdditionNode([sLocalPos, sUpBlend], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                constraints.computeAimOffset(sAimConstraint, fFinalXform)

                sLocs.append(sLoc)

            ssLocMatrices[p] = ['%s.matrix' % sL for sL in sLocs]


            # big joint matrices resetting the orientation to be like head/jaw
            #
            aOuterDelta = aaOuterPoints[p] - aaPoints[p]
            for j,sM in enumerate(ssLocMatrices[p]):
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]

                sOuterM = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(aOuterDelta[j]), sM])

                sDecompPos = nodes.createDecomposeMatrix(sOuterM)
                sDecomp = sDecompPos.split('.')[0]

                sJawAttachBlended = nodes.createBlendNode(fBlend, '%s.jawAttach' % ccRows[p][iCtrl1].sCtrl,
                                                                  '%s.jawAttach' % ccRows[p][iCtrl0].sCtrl, sName='jawAttach_%03d_' % j)
                sBlendedRotMatrix = nodes.createBlendMatrixNode([sJawSliderRotateMatrix, cmds.getAttr(sJawSliderRotateMatrix)],
                                                                [sJawAttachBlended, nodes.createReverseNode(sJawAttachBlended)], sName='jawAttach_%03d_' % j)

                sResetMatrix = nodes.createComposeMatrixNode(xTranslate = sDecompPos,
                                                             xRotate = nodes.createDecomposeMatrix(sBlendedRotMatrix, bReturnRotate=True),
                                                             xScale = '%s.outputScale' % sDecomp, sName='jawAttach_%03d_' % j)

                ssBigJointMatrices[p].append(sResetMatrix)




            # this is slide locs for the ends to keep the lipsEnd joints later stable. The following loop has similarities to the previous one
            if p == 0:
                for s,sSide in enumerate(['l','r']):
                    fP = fParams[0] if sSide == 'l' else fParams[-1]
                    sStableEnd = xforms.createLocator('loc_%s_stableEnd' % sSide, sParent=sGrpMouthPivotFront, fSize=fCurveLengthes[p]*0.05)
                    sNode, sPos = curves.createPointInfoNode(sCurve, fP)
                    sLocalPos = nodes.createPointByMatrixNode(sPos, '%s.worldInverseMatrix' % sMouthPivotFront)
    
                    aLocalPos = np.array(cmds.getAttr(sLocalPos)[0], dtype='float64')
                    fSmallOffset = aaLocalPoints[p][0 if sSide=='l' else -1] - aLocalPos
    
                    nodes.createVectorAdditionNode([sLocalPos, fSmallOffset], sTarget='%s.t' % sStableEnd)
    
                    sAimConstraint = constraints.aimConstraintEmpty(sStableEnd, aim=[0,0,1], up=[-1,0,0])
    
                    sUpBlend = sTwistUps[0 if sSide=='l' else -1]
                    nodes.createVectorAdditionNode([sLocalPos, sUpBlend], sTarget='%s.target[0].targetTranslate' % sAimConstraint, bJustValues=True)
    
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sParentRotInverseMatrix)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, *cmds.getAttr(sTangent)[0])



                    # this is almost a copy of the previous block, where the joints get the slide
                    sSplinesPlusPucker = '%s.matrix' % sStableEnd

                    # blend with no mouthCtrl (inverse against it)
                    fLocalMouthPivot = nodes.createMultMatrixNode(['%s.worldMatrix' % sMouthPivotFront, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                    sStaticMouthPivotFront = nodes.createMultMatrixNode([fLocalMouthPivot, '%s.worldMatrix' % sParentJoint])
                    sSplinesPlusSidingLocalNoMouth = nodes.createMultMatrixNode([sSplinesPlusPucker, sStaticMouthPivotFront, '%s.worldInverseMatrix' % sMouthPivotFront])

                    sLipsEndFollowMouthT = utils.addAttr(cMouth.sPasser, ln='lipsEndFollowMouthT', min=0, max=1, dv=1.0, k=True, bReturnIfExists=True)
                    sLipsEndFollowMouthR = utils.addAttr(cMouth.sPasser, ln='lipsEndFollowMouthR', min=0, max=1, dv=0.0, k=True, bReturnIfExists=True)
                    sDefaultSettingAttrs.extend([sLipsEndFollowMouthT, sLipsEndFollowMouthR])

                    sMouthPivotFrontBlendedT = nodes.createBlendMatrixNode([sSplinesPlusPucker, sSplinesPlusSidingLocalNoMouth],
                                                                          [sLipsEndFollowMouthT, nodes.createReverseNode(sLipsEndFollowMouthT)])
                    sMouthPivotFrontBlendedR = nodes.createBlendMatrixNode([sSplinesPlusPucker, sSplinesPlusSidingLocalNoMouth],
                                                                          [sLipsEndFollowMouthR, nodes.createReverseNode(sLipsEndFollowMouthR)])

                    sMouthPivotRotationScale = nodes.createDecomposeMatrix(sMouthPivotFrontBlendedR).split('.')[0]
                    sMouthPivotTranslate = nodes.createDecomposeMatrix(sMouthPivotFrontBlendedT).split('.')[0]
                    sBlendedMatrix = nodes.createComposeMatrixNode(xTranslate='%s.outputTranslate' % sMouthPivotTranslate,
                                                                   xRotate='%s.outputRotate' % sMouthPivotRotationScale,
                                                                   xScale='%s.outputScale' % sMouthPivotTranslate,
                                                                   xShear='%s.outputShear' % sMouthPivotTranslate)
                    cmds.connectAttr(sBlendedMatrix, '%s.offsetParentMatrix' % sLipsEndJoints[s])

                createPostRefAttrFromCurrentWorld(sLipsEndJoints)
                deformers.resetJointReferences(sLipsEndJoints)


            # squash/stretch
            #
            sSquashStretchMatrices = []
            sPoints = [nodes.createDecomposeMatrix(sM) for sM in ssLocMatrices[p]]
            ssDistances = [], []
            for j in range(1, len(sPoints) // 2 + 1, 1):
                ssDistances[0].append(nodes.createDistanceNode(sPoints[j], sPoints[j - 1]))
            for j in range(len(sPoints) - 2, len(sPoints) // 2 - 1, -1):
                ssDistances[1].append(nodes.createDistanceNode(sPoints[j], sPoints[j + 1]))

            sSideDistanceSums = []
            aaSideScaleWeights = []
            for s, fWeights in enumerate([[1, 1, 0, 0], [0, 0, 1, 1]]):
                sSum = nodes.createAdditionNode(ssDistances[s], sFullName='sum_%s_mouthScale' % utils.sSides1[s])
                sSideDistanceSums.append(sSum)
                aaSideScaleWeights.append(utils.bSpline4(fWeights, aValues=aPercs))

            ddSquashStretchSettings['sDriverLeft'] = sSideDistanceSums[0]
            utils.data.store('ddSquashStretchSettings', ddSquashStretchSettings)

            if not ddSquashStretchSettings['bScaleJoints']:
                sSquashStretchMatrices = ssLocMatrices[p]
            else:
                sSquashStrengthHeight = utils.addAttr(cMouth.sPasser, ln='squashStrengthHeight', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sSquashStrengthDepth = utils.addAttr(cMouth.sPasser, ln='squashStrengthDepth', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sStretchStrengthHeight = utils.addAttr(cMouth.sPasser, ln='stretchStrengthHeight', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sStretchStrengthDepth = utils.addAttr(cMouth.sPasser, ln='stretchStrengthDepth', min=0, dv=0.25, k=True, bReturnIfExists=True)
                sDefaultSettingAttrs += [sSquashStrengthHeight, sStretchStrengthHeight, sSquashStrengthDepth, sStretchStrengthDepth]

                sCtrlScaleDiffs = []
                for c,cC in enumerate(ccRows[p]):
                    if c in [0, len(ccRows[p])-1]:
                        sScaleAttr = '%s.%sScale' % (cC.sCtrl, sPart)
                    else:
                        sScaleAttr = '%s.scale' % (cC.sCtrl)
                    sClamp = nodes.createClampNode([1.0, '%sY' % sScaleAttr, '%sZ' % sScaleAttr], [0.1, 0.1, 0.1], [10, 10, 10], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sScaleDiff = nodes.createVectorAdditionNode([sClamp, [1,1,1]], sOperation='minus', sName='%s_%s_squashStretch' % (sSide, sPart))
                    sCtrlScaleDiffs.append(sScaleDiff)

                sSideScaleAdditions = []
                for s, sSide in enumerate(['l', 'r']):
                    sLipsLengthFactor = nodes.createMultiplyNode(cmds.getAttr(sSideDistanceSums[s]), sSideDistanceSums[s], sOperation='divide', sName='l_%s_squashStretchFactor' % (sPart))

                    sStretchFactor = nodes.createConditionNode(sLipsLengthFactor, '<', 1.0, 1.0, 0.0)
                    sSquashFactor = nodes.createReverseNode(sStretchFactor)
                    sStrength = nodes.createVectorAdditionNode([nodes.createVectorMultiplyNode([0, sStretchStrengthHeight, sStretchStrengthDepth], sStretchFactor, bVectorByScalar=True),
                                                                nodes.createVectorMultiplyNode([0, sSquashStrengthHeight, sSquashStrengthDepth], sSquashFactor, bVectorByScalar=True)])
                    
                    sScaleAddition = nodes.createVectorAdditionNode([[sLipsLengthFactor, sLipsLengthFactor, sLipsLengthFactor], [-1, -1, -1]])
                    sSideScaleAdditions.append(nodes.createVectorMultiplyNode(sScaleAddition, sStrength))
                    
                for j, sJ in enumerate(ssSmallJoints[p]):

                    sAdditions = []
                    # left right scale from lengths
                    for s,sSide in enumerate(['l','r']):
                        sAdditions.append(nodes.createVectorMultiplyNode(sSideScaleAdditions[s], aaSideScaleWeights[s][j], bVectorByScalar=True, sName='%s_%s_squashStretch_%03d_' % (sSide,sPart,j)))

                    # ctrl scales
                    iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                    sAdditions.append(nodes.createBlendNode(fBlend, sCtrlScaleDiffs[iCtrl1], sCtrlScaleDiffs[iCtrl0], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart)))

                    sScale = nodes.createVectorAdditionNode([[1,1,1]] + sAdditions, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sScale = nodes.createClampNode(sScale, [0.1, 0.1, 0.1], [100.0, 100.0, 100.0], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sLocalScaleMatrix = nodes.createComposeMatrixNode(xScale=sScale, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sSquashStretchMatrices.append(nodes.createMultMatrixNode([sLocalScaleMatrix, ssLocMatrices[p][j]], sName='%sSquashStretch_%03d' % (sPart,j)))
                    
            ssSmallJointMatrices[p] = sSquashStretchMatrices



        # lip seal
        #
        ssSmallDecomposeMatrices = [[nodes.createDecomposeMatrix(sM, sName='_bot_beforeLipSeal_%03d' % j) for j,sM in enumerate(ssSmallJointMatrices[0])],
                                    [nodes.createDecomposeMatrix(sM, sName='_top_beforeLipSeal_%03d' % j) for j,sM in enumerate(ssSmallJointMatrices[1])]]

        sSealLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (cCorners[0].sSeal, cCorners[0].sSealFadeLength), sName='left_sealByFade')
        sSealRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (cCorners[1].sSeal, cCorners[1].sSealFadeLength), sName='right_sealByFade')

        for p,sPart in enumerate(['bot','top']):
            fLeftPercs = utils.bSpline4([0, 0, 1, 1], aValues=np.arange(len(aaPoints[p])) / float(len(aaPoints[p]) - 1))
            fRightPercs = 1.0 - fLeftPercs
            aPercsToOther = curves.getPercsFromPoints(sBpCurvesA[1 - p], aaPoints[p], bReturnNumpy=True)
            aPercsAtOther = curves.getPercsFromPoints(sBpCurvesA[1 - p], aaPoints[1 - p], bReturnNumpy=True)
            iClosestJoints = xforms.findClosestFloats(aPercsToOther, aPercsAtOther)

            xOtherJointWeightings = []
            for j in range(len(aPercsToOther)):
                iJoint0 = iClosestJoints[j]
                iJoint1 = iClosestJoints[j]
                if aPercsToOther[j] < aPercsAtOther[iJoint0]:
                    if iJoint0 > 0:
                        iJoint1 = iJoint0 - 1
                elif aPercsToOther[j] > aPercsAtOther[iJoint0]:
                    if iJoint0 < len(aPercsAtOther) - 2:
                        iJoint1 = iJoint1 + 1
                fBlend = utils.projectToRange(aPercsToOther[j], aPercsAtOther[iJoint0], aPercsAtOther[iJoint1], 0, 1)

                xOtherJointWeightings.append([iJoint0, iJoint1, fBlend])

            for j in range(len(aaPoints[p])):
                sLeftRightSeals = cmds.createNode('plusMinusAverage', n='plus_sumSeals_%03d' % j)

                sEndLeft = nodes.createAdditionNode([fLeftPercs[j], cCorners[0].sSealFadeLength], sName='left_sealFadeLength_%03d' % j)
                sRangeLeft = nodes.createRangeNode(sSealLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0, sName='left_seal_%03d' % j)
                nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

                sEndRight = nodes.createAdditionNode([fRightPercs[j], cCorners[1].sSealFadeLength], sName='right_sealFadeLength_%03d' % j)
                sRangeRight = nodes.createRangeNode(sSealRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='right_seal_%03d' % j)
                nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

                sClamp = nodes.createClampNode('%s.output1D' % sLeftRightSeals, 0, 1, sName='lipSeal_%s_%03d' % (sPart,j))
                sJointBlendStrength = nodes.createMultiplyNode(sClamp, 0.5, sName='lipSeal_%s_%03d' % (sPart,j))

                # get other joint weightings
                iJoint0, iJoint1, fBlend = xOtherJointWeightings[j]
                sOtherPos = nodes.createBlendNode(fBlend, ssSmallDecomposeMatrices[1-p][iJoint1],
                                                          ssSmallDecomposeMatrices[1-p][iJoint0], bVector=True, sName='lipSeal_%s_%03d_' % (sPart,j))
                fOffset = np.array(aaLocalPoints[p][j], dtype='float64') - np.array(cmds.getAttr(sOtherPos)[0], dtype='float64')
                sOffsettedOtherPos = nodes.createVectorAdditionNode([sOtherPos, list(fOffset)], sName='lipSeal_%s_%03d_' % (sPart,j))
                sBlendPos = nodes.createBlendNode(sJointBlendStrength, sOffsettedOtherPos, ssSmallDecomposeMatrices[p][j], bVector=True, sName='lipSeal_%s_%03d_' % (sPart,j))
                sNewM = nodes.createComposeMatrixNode(xTranslate=sBlendPos,
                                                      xRotate='%s.outputRotate' % ssSmallDecomposeMatrices[p][j].split('.')[0],
                                                      xScale='%s.outputScale' % ssSmallDecomposeMatrices[p][j].split('.')[0], sName='lipSeal_%s_%03d_' % (sPart,j))
                ssSmallJointMatrices[p][j] = sNewM

        # detail ctrls
        #
        for p,sPart in enumerate(['bot','top']):
            cDetails = []

            sPoints = [nodes.createDecomposeMatrix(sM) for sM in ssSmallJointMatrices[p]]

            for j,sJ in enumerate(ssSmallJoints[p]):
                sSide = utils.getSide(sJ)
                fSideMultipl = -1.0 if sSide == 'r' else 1.0
                iIndex = int(sJ.split('_')[-1])
                cDetail = ctrls6.create('detail%s' % utils.getFirstLetterUpperCase(sPart), sSide, iIndex, sShape='sphere', fSize=fCurveLengthes[0]*0.1,
                                        iColorIndex=1, sParent=sLipsCtrlsParent, sAttrs=['t','r','s'])
                cDetail.appendOffsetGroup('poses')
                cmds.connectAttr(sPoints[j], '%s.t' % cDetail.sPasser)

                sAimConstraint = constraints.aimConstraintEmpty(cDetail.sPasser, up=[0,fSideMultipl,0])

                if j == 0:
                    cmds.connectAttr(sPoints[j+1], '%s.target[0].targetTranslate' % sAimConstraint)
                    cmds.setAttr('%s.aimVector' % sAimConstraint, -1,0,0)
                elif j == len(ssSmallJointMatrices[p])-1:
                    cmds.connectAttr(sPoints[j-1], '%s.target[0].targetTranslate' % sAimConstraint)
                    cmds.setAttr('%s.aimVector' % sAimConstraint, -1,0,0)
                else:
                    sVectorA = nodes.createVectorAdditionNode([sPoints[j+1], sPoints[j]], sOperation='minus')
                    sVectorB = nodes.createVectorAdditionNode([sPoints[j], sPoints[j-1]], sOperation='minus')
                    nodes.createVectorAdditionNode([sPoints[j], sVectorA, sVectorB], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                    cmds.setAttr('%s.aimVector' % sAimConstraint, -1,0,0)

                cDetail.createExtraMoveTransformAndTag([sD.replace('*face*', sAttachMesh) for sD in ctrls6.kDefaultFaceAttachDeformers[2:]])

                ssSmallJointMatrices[p][j] = nodes.createMultMatrixNode([ssSmallJointMatrices[p][j],
                                                                         '%s.inverseMatrix' % cDetail.sPasser,
                                                                         '%s.worldMatrix' % cDetail.sCtrl,
                                                                         '%s.worldInverseMatrix' % cDetail.sExtraMove,
                                                                         '%s.worldMatrix' % cDetail.sPasser,
                                                                         '%s.worldInverseMatrix' % sLipsCtrlsParent])

                cDetail.setDefaultAttrDict()
                cDetails.append(cDetail)

            for j, cDetail in enumerate(cDetails if p == 1 else cDetails[::-1]):
                cmds.controller(cDetail.sCtrl, cMouth.sCtrl, parent=True)



        # finally set them
        for p,sPart in enumerate(['bot','top']):
            # finally connect the small joints
            for j,sJ in enumerate(ssSmallJoints[p]):
                cmds.connectAttr(ssSmallJointMatrices[p][j], '%s.offsetParentMatrix' % sJ)
                xforms.resetTransform(sJ, jo=True)
                # nodes.createDecomposeMatrix(ssSmallJointMatrices[p][j], sTargetPos = '%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ, sName='finalDecomposeSmall_%s_%03d' % (sPart,j))
            utils.data.store('%sLipJointsSmall' % sPart, ssSmallJoints[p])


            # finally connect the big joints
            for j,sJ in enumerate(ssBigJoints[p]):
                nodes.createDecomposeMatrix(ssBigJointMatrices[p][j], sTargetPos = '%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ, sName='finalDecomposeBig_%s_%03d' % (sPart,j))


        for sJoint in utils.flattenedList(ssBigJoints) + utils.flattenedList(ssSmallJoints):
            utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, cmds.getAttr('%s.worldInverseMatrix' % sJoint))
            deformers.resetJointReferences(sJoint)


        connectFaceCtrlPoses(ddPoses)



        # lip push
        for cBot, cTop in zip(ccLipCtrls[0], ccLipCtrls[1]):
            sLipPushAttr = utils.addAttr(cTop.sCtrl, ln='lipPush', min=0, max=1, dv=0, k=True)
            sDecompBotCtrl = nodes.createDecomposeMatrix('%s.worldMatrix' % cBot.sCtrl)
            fBotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cBot.sPasser, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)
            sPasserDefaultMatrix = nodes.createMultMatrixNode([fBotOffset, '%s.worldMatrix' % sMouthPivotFront])
            if cBot.sSide == 'r':
                sPasserDefaultMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xScale=[-1, -1, -1]), sPasserDefaultMatrix])

            sPasserDefaultRotation = nodes.createDecomposeMatrix(sPasserDefaultMatrix, bReturnRotate=True)
            sBotNoRot = nodes.createComposeMatrixNode(xTranslate=sDecompBotCtrl, xRotate=sPasserDefaultRotation, xScale='%s.outputScale' % sPasserDefaultRotation.split('.')[0])
            sPlane = nodes.createMultMatrixNode([sBotNoRot, '%s.worldInverseMatrix' % cBot.sExtraMove, '%s.worldMatrix' % cBot.sPasser])
            sPlaneInv = nodes.createInverseMatrix(sPlane)
            sTopInPlane = nodes.createMultMatrixNode(['%s.worldMatrix' % cTop.sCtrl,
                                                      '%s.worldInverseMatrix' % cTop.sExtraMove, '%s.worldMatrix' % cTop.sPasser,
                                                      sPlaneInv])

            sTopInPlaneY = '%sY' % nodes.createDecomposeMatrix(sTopInPlane)
            fTopInPlaneY = cmds.getAttr(sTopInPlaneY)
            sSide = cBot.sSide

            sImpactingPoseKeys = ['cornerOut', 'cornerIn', 'cornerUp', 'cornerDown', 'botRollIn', 'topRollIn', 'lipPress']
            iDotNodesCount = math.ceil(len(sImpactingPoseKeys) / 3)
            sDotNodeOutputs = [nodes.createDotProductNode([0,0,0], [0,0,0]) for _ in range(iDotNodesCount)]
            sBlendedDefaultTopInPlaneY = nodes.createAdditionNode([fTopInPlaneY] + sDotNodeOutputs)
            sDotNodes = [sO.split('.')[0] for sO in sDotNodeOutputs]
            for p,sPoseKey in enumerate(sImpactingPoseKeys):
                iNode = p // 3
                iAttr = p % 3
                sInput1 =  '%s.input1%s' % (sDotNodes[iNode], ['X','Y','Z'][iAttr])
                sInput2 =  '%s.input2%s' % (sDotNodes[iNode], ['X','Y','Z'][iAttr])
                sCtrlDriverAttrs = [ddPoses[sPoseKey]['sCtrlDriverAttr']]
                sCtrlDriverAttrs.append(utils.getMirrorName(sCtrlDriverAttrs[0]))

                for sAttr in sCtrlDriverAttrs:
                    cmds.setAttr(sAttr, ddPoses[sPoseKey]['fCtrlDriverValue'])
                fValue = cmds.getAttr(sTopInPlaneY) - cmds.getAttr(sBlendedDefaultTopInPlaneY)
                for sAttr in sCtrlDriverAttrs:
                    cmds.setAttr(sAttr, 0.0)

                cmds.connectAttr(ddPoseDriverDatas[sPoseKey]['driver_top']['driver_%s' % sSide], sInput1)
                cmds.setAttr(sInput2, fValue)

            sDiff = nodes.createAdditionNode([sTopInPlaneY, sBlendedDefaultTopInPlaneY], sOperation='minus')
            sPushValue = nodes.createConditionNode(sDiff, '<', 0, nodes.createMultiplyNode(sDiff, -1), 0)
            nodes.createBlendNode(sLipPushAttr, sPushValue, 0, sTarget='%s.ty' % cTop.sOut)
            cmds.select(cTop.sOut)
            cmds.setAttr(sLipPushAttr, 1.0)



        for sA, fV in list(dDefaultSettingValues.items()):
            if cmds.objExists(sA):
                try:
                    cmds.setAttr(sA, fV)
                except Exception as e:
                    report.report.addLogText('skipping saved default value "%s" (errors: "%s")' % (sA, str(e)))
            else:
                report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)

        # spline correctives for jawOpen - we probably don't need anymore since the curves are smoother
        for p,sPart in enumerate(['bot','top']):
            if cmds.objExists(kMouthJawOpenCorrectiveCurves[p]):
                blendShapesPro.connectTargets(kMouthSplineCurves[p], kMouthJawOpenCorrectiveCurves[p],
                                              dPoses={'jaw_ctrl.rz':ddPoses['jawOpen']['fCtrlDriverValue']},
                                              dDrivers={ddPoseDriverDatas['jawOpen']['driver_%s' % sPart]['driver_l']:None}, iInvert=2)



        for cCtrl in utils.flattenedList(ccRows + ccCornerTangents + cBotTops + [cMouth]):
            cCtrl.setDefaultAttrDict()


    # EXCLUDE END MOUTHSPLINES


    for sCurve in sBpCurvesA+sBpCurvesB:
        cmds.setAttr('%s.v' % sCurve, False)
    
    cmds.setAttr('%s.v' % kMouthBpGroupName, False)
    utils.data.store('sDefaultSettingAttrs', sDefaultSettingAttrs)




def roundCornerRom(fJawRotates, fCornerRange):
    cmds.setKeyframe('lipsCorner_l_ctrl.pointyRound', t=1, v=0.0)
    cmds.setKeyframe('lipsCorner_r_ctrl.pointyRound', t=1, v=0.0)
    fCurrentTime = 5.0
    cmds.setKeyframe('lipsCorner_l_ctrl.pointyRound', t=fCurrentTime, v=1.0)
    cmds.setKeyframe('lipsCorner_r_ctrl.pointyRound', t=fCurrentTime, v=1.0)
    sJawAttr = '%s.rz' % jawCtrl()
    sCornerAttrs = ['lipsCorner_l_ctrl.translateX', 'lipsCorner_r_ctrl.translateX']
    fCurrentTime = 5.0
    for fJawRotate in ([0.0] + fJawRotates):
        cmds.setKeyframe(sJawAttr, t=fCurrentTime, v=fJawRotate)
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=0)
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=0)
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=fCornerRange[0])
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=fCornerRange[0])
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=fCornerRange[1])
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=fCornerRange[1])
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=0)
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=0)
        fCurrentTime += 5.0

    cmds.playbackOptions(e=True, minTime=0, maxTime=fCurrentTime)

            


@builderTools.addToBuild(iOrder=65, bDisableByDefault=True, dButtons={'create rom':roundCornerRom})
def calibratePointyRound(fCornerRange=[-1,1.5], fJointIndexFromLeft=1.0, fJawRotates=[-8, -15, -25], fTangentScales=[1,1.5,2.0], fPostMultipl=1.0):
    '''
    If "fJointIndexFromLeft" is 0.0, then he's taking the 2nd joint from the very left or right to \
    analize the roundness during the calibrating. If it's one, then it's the 1st Sjoint. If there \
    are issues calibrating, this is the first value you should experiment with.

    To find the values for fTangentScales: break the connections to inf_l_lipsCornerMouthInfluenceBot and inf_l_lipsCornerMouthInfluenceTop,
    and try scaling it while mouth is open

    fPostMultipl happens after the calibration
    '''

    if utils.data.get('bMouthSplines', xDefault=False) == False:
        report.report.addLogText('skipping because mouth is not setup with bSPLINES')
        return False


    kPointyRoundPrefix = 'pointyRoundCalibrate__'

    sOldNodes = cmds.ls('%s*' % kPointyRoundPrefix)
    if sOldNodes:
        cmds.delete(sOldNodes)

    # sCornerCtrls = ['lipsCorner_l_ctrl', 'lipsCorner_r_ctrl']
    cCornerCtrls = [ctrls6.ctrlFromName('lipsCorner_l_ctrl'),
                    ctrls6.ctrlFromName('lipsCorner_r_ctrl')]


    sCalibrateNodeOutputs = []
    try:
        ssLipJoints = [None, None]
        for p,sPart in enumerate(['bot','top']):
            ssLipJoints[p] = utils.data.get('%sLipJointsSmall' % sPart)

        iJointIndexFromLeftFloor = int(math.floor(fJointIndexFromLeft))
        if (fJointIndexFromLeft - iJointIndexFromLeftFloor) < 0.0001:
            iJointIndexFromLeftCeil = iJointIndexFromLeftFloor + 1
        else:
            iJointIndexFromLeftCeil = int(math.ceil(fJointIndexFromLeft))
        fJointT = fJointIndexFromLeft - iJointIndexFromLeftFloor


        sPointBotFloor = nodes.getWorldPoint(ssLipJoints[0][iJointIndexFromLeftFloor])
        sPointBotCeil = nodes.getWorldPoint(ssLipJoints[0][iJointIndexFromLeftCeil])

        sPointTopFloor = nodes.getWorldPoint(ssLipJoints[1][iJointIndexFromLeftFloor])
        sPointTopCeil = nodes.getWorldPoint(ssLipJoints[1][iJointIndexFromLeftCeil])


        sOpenDriver = nodes.createDistanceNode(nodes.getWorldPoint('mouthBot_ctrl'), nodes.getWorldPoint('mouthTop_ctrl'))

        sJawAttr = '%s.rz' % jawCtrl()

        fClosedValue = cmds.getAttr(sOpenDriver)
        fOpenValues = []
        for r, fRot in enumerate(fJawRotates):
            cmds.setAttr(sJawAttr, fRot)
            fOpenValues.append(cmds.getAttr(sOpenDriver))
        cmds.setAttr(sJawAttr, 0.0)

        sExceedWhenOnAttrs = utils.data.get('sRoundExceedWhenOnAttrs')
        sPointyRoundAttrs = ['%s.pointyRound' % cCornerCtrls[0].sCtrl, '%s.pointyRound' % cCornerCtrls[1].sCtrl]
        sPointyRoundAttrSums = ['%s.pointyRoundSum' % cCornerCtrls[0].sPasser, '%s.pointyRoundSum' % cCornerCtrls[1].sPasser]

        for s, sSide in enumerate(['l', 'r']):
            sTangentScalesAuto = utils.data.get('sTangentScalesAuto_%s' % sSide)
            # sJoints = ['inf_%s_lipsCornerMouthInfluenceBot' % sSide, 'inf_%s_lipsCornerMouthInfluenceTop' % sSide]
            sDrivenKeys0 = nodes.setDrivenKey(sOpenDriver, [fClosedValue] + fOpenValues, None, [1] + fTangentScales)
            sDrivenKeys1 = nodes.setDrivenKey(sOpenDriver, [fClosedValue] + fOpenValues, None, [1] + fTangentScales)

            nodes.createBlendNode(sPointyRoundAttrSums[s], sDrivenKeys0, 1.0, sTarget=sTangentScalesAuto[0], bForce=True)
            nodes.createBlendNode(sPointyRoundAttrSums[s], sDrivenKeys1, 1.0, sTarget=sTangentScalesAuto[1], bForce=True)


        sTempCalibrateParentMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(ssLipJoints[0][0]),
                                                                   xRotate=nodes.createDecomposeMatrix('ctrl_l_lipsCornerOrigOut.worldMatrix', bReturnRotate=True))

        sTempCalibrateParentInverseMatrix = nodes.createInverseMatrix(sTempCalibrateParentMatrix)
        sTempCalibratePointBot = nodes.createPointByMatrixNode(nodes.createBlendNode(fJointT, sPointBotCeil, sPointBotFloor, bVector=True),
                                                               sTempCalibrateParentInverseMatrix)
        sTempCalibratePointTop = nodes.createPointByMatrixNode(nodes.createBlendNode(fJointT, sPointTopCeil, sPointTopFloor, bVector=True),
                                                               sTempCalibrateParentInverseMatrix)

        sTempCalibratePointNormalizedBot = nodes.createNormalizedVector(['%sX' % sTempCalibratePointBot, '%sY' % sTempCalibratePointBot, 0])
        sTempCalibratePointNormalizedTop = nodes.createNormalizedVector(['%sX' % sTempCalibratePointTop, '%sY' % sTempCalibratePointTop, 0])

        sTempDot = nodes.createDotProductNode(sTempCalibratePointNormalizedBot, sTempCalibratePointNormalizedTop)
        sTempAverageHoriz = nodes.createBlendNode(0.5, '%sX' % sTempCalibratePointNormalizedBot, '%sX' % sTempCalibratePointNormalizedTop)

        sParentLoc = cmds.spaceLocator(n='calibrateInfo')[0]
        sLoc0 = cmds.spaceLocator()[0]
        sLoc1 = cmds.spaceLocator()[0]
        sLoc2 = cmds.spaceLocator()[0]
        cmds.parent(sLoc0, sLoc1, sLoc2, sParentLoc)
        cmds.connectAttr(sTempCalibratePointNormalizedBot, '%s.t' % sLoc0)
        cmds.connectAttr(sTempCalibratePointNormalizedTop, '%s.t' % sLoc1)
        cmds.connectAttr(sTempAverageHoriz, '%s.tx' % sLoc2)
        cmds.connectAttr(sTempDot, '%s.ty' % sLoc2)
        def calibrate():
            fDirection = -1 if cmds.getAttr(sTempAverageHoriz) > 0 else 1
            iTestingCount = 18
            fValues = np.arange(iTestingCount) * 5 * fDirection
            fDots = [0] * iTestingCount
            for v, fValue in enumerate(fValues): #(18 = 90 / 5)
                cmds.setAttr(sExceedWhenOnAttrs[0], float(fValue))
                fDots[v] = cmds.getAttr(sTempDot)
            iSmallestDot = np.argmin(fDots)
            return fValues[iSmallestDot]


        # cmds.setAttr(sPointyRoundAttrs[0], 1.0 - cmds.getAttr(sPointyRoundAttrSums[0]))
        report.report.resetProgress(len(fJawRotates))
        ssDrivenKeys = [], []
        for fJawRotate in fJawRotates:
            print('\n\n\n ============ JAWROTATE: ', fJawRotate)

            cmds.setAttr(sJawAttr, fJawRotate)
            cmds.setAttr(sPointyRoundAttrs[0], 0.0)
            cmds.setAttr(sPointyRoundAttrs[0], 1.0 - cmds.getAttr(sPointyRoundAttrSums[0]))

            # fLipOutDriverValues = [-0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0, 1.5]
            iHorizCount = 8
            fLipOutDriverValues =  np.interp(np.arange(iHorizCount), [0, iHorizCount-1], fCornerRange)

            aValues = np.zeros(len(fLipOutDriverValues), dtype='float64')
            for v,fX in enumerate(fLipOutDriverValues):
                print('=================== calibrating.. ', fX, fJawRotate)
                cmds.setAttr('%s.tx' % cCornerCtrls[0].sCtrl, fX)
                aValues[v] = calibrate()
            aValues *= fPostMultipl

            for s, sSide in enumerate(['l','r']):
                sDks = nodes.setDrivenKey('%s.tx' % cCornerCtrls[s].sCtrl, fLipOutDriverValues, None, aValues)
                ssDrivenKeys[s].append(sDks)
                sCalibrateNodeOutputs.append(sDks)
            report.report.incrementProgress()

        cmds.setAttr(sPointyRoundAttrs[0], 0.0)
        cmds.setAttr(sJawAttr, 0.0)
        cmds.setAttr('%s.tx' % cCornerCtrls[0].sCtrl, 0.0)


        sCalibrateNodeOutputs.append(sOpenDriver)


        for s,sSide in enumerate(['l','r']):
            sPrevCond = 0.0
            for r in range(len(fJawRotates) - 1):
                iFrom = r
                iTo =  r+1
                sRange = nodes.createRangeNode(sOpenDriver, fOpenValues[iFrom], fOpenValues[iTo], ssDrivenKeys[s][iFrom], ssDrivenKeys[s][iTo],
                                               sName='%s_pointyRoundCondition_%03d' % (sSide,r))
                sNewCond = nodes.createConditionNode(sOpenDriver, '<', fOpenValues[iTo], sRange, 0,
                                                     sName='%s_pointyRoundCondition_%03d' % (sSide,r))

                if r == 0:
                    cmds.connectAttr(sNewCond, sExceedWhenOnAttrs[s])
                else:
                    sPrevCondNode = sPrevCond.split('.')[0]
                    cmds.connectAttr(sNewCond, '%s.colorIfFalseR' % sPrevCondNode)
                    if r == len(fJawRotates) - 2:
                        sNewCondNode = sNewCond.split('.')[0]
                        cmds.connectAttr(ssDrivenKeys[s][iTo], '%s.colorIfFalseR' % sNewCondNode)

                sPrevCond = sNewCond
                sCalibrateNodeOutputs += [sRange, sNewCond]

    except:
        raise
    finally:
        for o, sO in enumerate(sCalibrateNodeOutputs):
            sNode = sO.split('.')[0]
            sCalibrateNodeOutputs[o] = cmds.rename(sNode, '%s%s' % (kPointyRoundPrefix, sNode))


sCheekGroupName = '_grp_m_cheekBps'
kCheekFileName = 'blueprintCheek.ma'
dButtons = OrderedDict()
dButtons['Create Left Cheek Curve (Tracked Order)'] = lambda: createBpCurve('bpCurve_l_cheek', sCheekGroupName,
                                                                            fDirection=(0, 1, 0), bTrackedOrder=True)
dButtons['Create Left Cheek Curve (Tracked Order)'].dSideButtons = {'?':['The vertices here don\'t have to be neighbor vertices, as long '\
                                                            '\nas you select them in the correct order', 'cheekTrackedOrder.jpg']}
dButtons['Create Left Cheek Curve'] = lambda: createBpCurve('bpCurve_l_cheek', sCheekGroupName,
                                                            fDirection=(0, 1, 0))
dButtons['Create Left Cheek Curve'].dSideButtons = {'?':['If the vertices all neighbors, you can use that '\
                                             'button instead of the one above']}
dButtons['Create Left Cheek PushOut Curve'] = lambda: createBpUpVectorCurve('bpCurve_l_cheekUp',
                                                                            'bpCurve_l_cheek')
dButtons['Create Left Cheek PushOut Curve'].dSideButtons = {'?':['no selection needed, he\'ll create the curve himself']}

dButtons['=== DEFAULT ATTRS ==='] = defaultAttributes.getDefaultAttrsMenu('sDefaultSettingAttrsCheeks', 'dDefaultSettingValuesCheeks')


dButtons['Export BPs'] = lambda: exportBps(kCheekFileName, sCheekGroupName)


@builderTools.addToBuild(iOrder=62.4, dButtons=dButtons, bDisableByDefault=True)
def cheekSetup(sParentJoint='jnt_m_headMain', fCtrlPercs=[0.33, 0.66], iCheekCurveJointCount=8, dDefaultSettingValuesCheeks={}):
    sDefaultSettingAttrsCheeks = []
    
    sGroup = cmds.createNode('transform', n='grp_cheekSetup', p='modules')
    fCtrlPercs = [0.0] + fCtrlPercs + [1.0]
    ccCtrls = [], []
    ssJoints = [], []
    sGlobalScale = nodes.getScaleFromXform(sParentJoint)
    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        sBpCurve = 'bpCurve_%s_cheek' % sSide
        sBpUpCurve = 'bpCurve_%s_cheekUp' % sSide
        
        curves.mirrorIfNotExists(sBpCurve)
        curves.mirrorIfNotExists(sBpUpCurve)
        
        aCtrlPoints = curves.getPointsFromPercs(sBpCurve, fCtrlPercs)
        aCtrlPointsUp = curves.getPointsFromPercs(sBpUpCurve, fCtrlPercs)
        sCurve = cmds.curve(p=aCtrlPoints, n='curve_%s_cheek' % sSide)
        sCurveUp = cmds.curve(p=aCtrlPointsUp, n='curve_%s_cheekUp' % sSide)
        cmds.parent(sCurve, sCurveUp, sGroup)
        
        aCtrlPoints = patch.patchFromName(sCurve).getPoints()
        aTangents = curves.getTangentsFromPercs(sCurve, fCtrlPercs)
        aCtrlPointsUp = patch.patchFromName(sCurveUp).getPoints()
        fCurveLength = curves.getLength(sCurve)
        fCtrlSize = fCurveLength * 0.1
        fSliderScale = fCurveLength * 0.1
        sTempLoc = cmds.spaceLocator()[0]
        sInfluences = []
        for c, fParam in enumerate(fCtrlPercs):
            cmds.setAttr('%s.t' % sTempLoc, *list(aCtrlPoints[c]))
            xforms.orientThreePoints(sTempLoc, aCtrlPointsUp[c]-aCtrlPoints[c], aTangents[c], fAimVector=[0,0,fSideMultipl], fUpVector=[-fSideMultipl,0,0])
            cCtrl = ctrls6.create('cheek', sSide, c, sShape='sphere', sAttrs=['t'], fSize=fCtrlSize, fSliderScale=fSliderScale, sParent=_getFaceCtrlGrp(), sMatch=sTempLoc, iSlider=2)

            constraints.matrixParentConstraint(sParentJoint, cCtrl.sPasser, mo=True)
            ccCtrls[s].append(cCtrl)
            sInf = cmds.createNode('joint', n='inf_%s_cheek_%03d' % (sSide, c), p=cCtrl.sPasser)
            cmds.setAttr('%s.radius' % sInf, fCtrlSize*0.5)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf)
            sInfluences.append(sInf)
            
            
            if c in [0,len(fCtrlPercs)-1]:
                cCtrl.convertToSimpleTransforms()
            else:
                #
                # move with corners
                #
                cCtrl.createExtraMoveTransformAndTag(ctrls6.kDefaultFaceAttachDeformers[2:])

                sCtrlMove = nodes.createPointByMatrixNode(nodes.getWorldPoint(cCtrl.sOut), '%s.worldInverseMatrix' % cCtrl.sExtraMove)
                nodes.createVectorMultiplyNode(sCtrlMove, 2.5, bVectorByScalar=True, sTarget='%s.t' % sInf)


                sMoveToAttrs = [utils.addAttr(cCtrl.sPasser, ln='moveToCorner%s' % sSuffix, k=True, min=0, max=1, dv=0.25) for sSuffix in ['Horiz', 'Vert', 'Depth']]
                sMoveOffset = cCtrl.appendOffsetGroup('movewithcorner')
                sCorner = 'jnt_%s_lipsEnd' % sSide
                fCtrlPos = cmds.xform(cCtrl.sCtrl, q=True, ws=True, t=True)
                
                fStraightMatrix = list(utils.fIdentityMatrix)
                fStraightMatrix[12:15] = fCtrlPos

                fCtrlInCorner = nodes.createPointByMatrixNode(fCtrlPos, '%s.worldInverseMatrix' % sCorner, bJustValues=True)
                sFullMoveCtrl = nodes.createPointByMatrixNode(fCtrlInCorner, '%s.worldMatrix' % sCorner)

                fStraightMatrixInSlider = nodes.createMultMatrixNode([fStraightMatrix, '%s.worldInverseMatrix' % cCtrl.sSlider], bJustValues=True)
                sSliderStraightened = nodes.createMultMatrixNode([fStraightMatrixInSlider, '%s.worldMatrix' % cCtrl.sSlider,
                                                                  '%s.worldInverseMatrix' % cCtrl.sExtraMove, '%s.worldMatrix' % cCtrl.sPasser])
                sSliderStraightenedInv = nodes.createInverseMatrix(sSliderStraightened)
                
                sFullMoveCtrlInStraight = nodes.createPointByMatrixNode(sFullMoveCtrl, sSliderStraightenedInv)
                
                sFullMoveCtrlStrenghted = nodes.createVectorMultiplyNode(sMoveToAttrs, sFullMoveCtrlInStraight)
                sDefaultSettingAttrsCheeks.extend(sMoveToAttrs)

                fSliderInPasser = nodes.createMultMatrixNode(['%s.worldMatrix' % cCtrl.sSlider, '%s.worldInverseMatrix' % cCtrl.sPasser], bJustValues=True)
                sSliderInPasser = nodes.createMultMatrixNode([fSliderInPasser, '%s.worldMatrix' % cCtrl.sPasser])
                sMoveCtrlWorld = nodes.createPointByMatrixNode(sFullMoveCtrlStrenghted, sSliderStraightened)
                nodes.createPointByMatrixNode(sMoveCtrlWorld, nodes.createInverseMatrix(sSliderInPasser), sTarget='%s.t' % sMoveOffset)
                
                #
                # push out
                #
                sPushOutAttr = utils.addAttr(cCtrl.sPasser, ln='pushOut', k=True, min=0, max=10, dv=0.25)
                sPushOutOffset = cCtrl.appendOffsetGroup('pushfromcorner')
                sDistance = nodes.createDistanceNode(nodes.getWorldPoint(sCorner), nodes.getWorldPoint(cCtrl.sPasser), sDivide='%sX' % sGlobalScale)
                fDistance = cmds.getAttr(sDistance)
                sDistanceStrength = nodes.createRangeNode(sDistance, fDistance, 0, 0, fDistance)
                nodes.createMultiplyNode(sDistanceStrength, sPushOutAttr, sTarget='%s.tz' % sPushOutOffset)
                sDefaultSettingAttrsCheeks.append(sPushOutAttr)

            
        cmds.skinCluster(sCurve, sInfluences, tsb=True)
        cmds.skinCluster(sCurveUp, sInfluences, tsb=True)
        cmds.delete(sTempLoc)


        # joints
        aJointPercs = np.arange(iCheekCurveJointCount) / (iCheekCurveJointCount-1)
        fJointParams = curves.getParamsFromPercs(sCurve, aJointPercs)
        sParentRotationMatrix = nodes.getRotationMatrix2('%s.worldMatrix' % sParentJoint)
        sParentRotationMatrixInv = nodes.createInverseMatrix(sParentRotationMatrix)
        for j,fParam in enumerate(fJointParams):
            sInfoNode, sPoint = curves.createPointInfoNode(sCurve, fParam)
            sInfoNodeUp, sPointUp = curves.createPointInfoNode(sCurveUp, fParam)
            sJ = 'jnt_%s_cheek_%03d' % (sSide,j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
            else:
                cmds.createNode('joint', n=sJ, p=sParentJoint)
            cmds.setAttr('%s.radius' % sJ, fCtrlSize*0.3)
            nodes.createPointByMatrixNode(sPoint, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            sAimConstraint = constraints.aimConstraintEmpty(sJ)
            nodes.createPointByMatrixNode(sPointUp, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            fTangent = cmds.getAttr('%s.tangent' % sInfoNode)[0]
            nodes.createPointByMatrixNode(fTangent, sParentRotationMatrixInv, sTarget='%s.worldUpVector' % sAimConstraint)
            ssJoints[s].append(sJ)
        
    createPostRefAttrFromCurrentWorld(ssJoints[0] + ssJoints[1])
    utils.data.store('sDefaultSettingAttrsCheeks', sDefaultSettingAttrsCheeks)
    deformers.resetJointReferences(ssJoints[0] + ssJoints[1])

    for sA, fV in list(dDefaultSettingValuesCheeks.items()):
        if cmds.objExists(sA):
            try:
                cmds.setAttr(sA, fV)
            except Exception as e:
                report.report.addLogText('skipping saved default value "%s" (errors: "%s")' % (sA, str(e)))
        else:
            report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)


dButtons = OrderedDict()
dButtons['select MAP meshes'] = lambda: cmds.select(cmds.ls('*__MAPS', et='transform'))

dButtons['- Export *Slider* BPs -'] = ctrls6.exportSliderBps
@builderTools.addToBuild(iOrder=63, dButtons=dButtons)
def blendShapesAndSliders(dSplitRadienFactors={'fOuterBrow':1.0, 'fMouthPucker':1.0, 'fMouthCorner':0.75, 'fUpperLips':0.5, 'fLowerLips':0.5, 'fBlink':1.0, 'fNostril':0.25}, iUpperLowerSmoothIterations=3,
                            sMirrorJointAxes=[], dSkip={'bSkipCornerShapes':False, 'bSkipMouthDirectionShapes':False, 'bSkipLipShapes':False, 'bSkipJawShapes':False, 'bSkipLidCloseShapes':False},
                            ddTargetsAsAttributes={'lipsCorner_l_ctrl':{'sTarget':'', 'fSplitRadius':0.5}},
                            ddExtraTargetSliders=[{'sName':'newName', 'dTargets':{'sTargetUp':'', 'sTargetDown':'', 'sTargetIn':'', 'sTargetOut':''}, 'bMirror':True}],
                            ddCorrectives={'TARGETNAME': {'dPoses': {'lipsCorner_l_ctrl.tx': 1.0}, 'fSplitRadius': 0.5, 'bMirror':True, 'sDrivers':[]}},
                            sIgnoreTargets=[]):


    # _importMapMeshes()
    bMouthSplines = utils.data.get('bMouthSplines', xDefault=False)

    blendShapesPro.clearWeightsCache()

    fUpperLipsSplitRadiusFactor = dSplitRadienFactors['fUpperLips']
    fLowerLipsSplitRadiusFactor = dSplitRadienFactors['fUpperLips']
    fOuterBrowSplitRadiusFactor = dSplitRadienFactors['fOuterBrow']
    fMouthPuckerSplitRadiusFactor = dSplitRadienFactors['fMouthPucker']
    fMouthCornerSplitRadiusFactor = dSplitRadienFactors['fMouthCorner']
    fBlinkSplitRadiusFactor = dSplitRadienFactors['fBlink']
    fNostrilSplitRadiusFactor = dSplitRadienFactors['fNostril']


    # sSuffixes = utils.data.get('sImportedHeadSuffixes', xDefault=['']) #, xDefault=[])
    utils.data.store('sMirrorJointAxes', sMirrorJointAxes) #, xDefault=[])
    bReturn = None
    sSuffix = ''
    xMirrorAxis = None

    report.report.resetProgress(12)
    fBlinkSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.1
    fNoseSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.2
    fBrowSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.5


    report.report.addLogText('splitting blueprints... ', bIncrementProgress=True)

    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sTargets = set(utils.data.get('sBakedBlendshapeTargets%s' % sSuffix, xDefault=[])) - set(sIgnoreTargets)


    sSecondaryModels = []
    for sT in sTargets:
        if '__' in sT:
            sSecondaryModels.append(sT.split('__')[0])
    sSecondaryModels = list(set(sSecondaryModels) - set(sTargets)) # without minus targets he would catch inbetweens as secondaryModels
    sSecondaryModels = [sM for sM in sSecondaryModels if cmds.objExists(sM)]

    sSecondaryModels += utils.data.get('sExtraSecondaryModels%s' % sSuffix, xDefault=[])

    utils.data.store('sAllSecondaryModels%s' % sSuffix, sSecondaryModels)

    sParentJoint = 'jnt_m_headMain'
    sJawJoint = 'jnt_m_jawMain'



    fMouthCurveEndsDistance = utils.data.get('fMouthCurveEndsDistance%s' % sSuffix, xDefault=1.0)
    fMouthSplitRadius = fMouthCurveEndsDistance * 0.5
    # fMouthSliderScale = fMouthCurveEndsDistance * 0.25

    bLipCurves = utils.data.get('bLipCurves%s' % sSuffix, xDefault=False)

    if bLipCurves:
        cCorners = [ctrls6.ctrlFromName('lipsCorner_l_ctrl', bReturnNoneIfNotExists=True), ctrls6.ctrlFromName('lipsCorner_r_ctrl', bReturnNoneIfNotExists=True)]

        if cCorners[0]:
            ddSquashStretchSettings = utils.data.get('ddSquashStretchSettings')
            if not utils.isNone(ddSquashStretchSettings):
                blendShapesPro.connectTargets(sModel, ddSquashStretchSettings['sShrinkTarget'],
                                           dPoses={'%s.tx' % cCorners[0].sCtrl: ddSquashStretchSettings['fShrinkCornerValue']},
                                           # dDrivers={ddSquashStretchSettings['sDriverLeft']:None},
                                           fSplitRadius=fMouthSplitRadius,
                                           bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bMirror=True)

                blendShapesPro.connectTargets(sModel, ddSquashStretchSettings['sExpandTarget'],
                                           dPoses={'%s.tx' % cCorners[0].sCtrl: ddSquashStretchSettings['fExpandCornerValue']},
                                           # dDrivers={ddSquashStretchSettings['sDriverLeft']:None},
                                           fSplitRadius=fMouthSplitRadius,
                                           bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bMirror=True)
        # ddSquashStretchSettings = {'bScaleJoints': True, 'fShrinkCornerValue': -1, 'fExpandCornerValue': 1.0,
        #                            'sShrinkTarget': 'mouthSquash', 'sExpandTarget': 'mouthStretch'},
        else:
            cCorners = None



        report.report.addLogText('upper/lower lips... ', bIncrementProgress=True)
        if not dSkip.get('bSkipLipShapes', False):
            sLowerDown = 'lowerDown%s' % sSuffix
            sLowerUp = 'lowerUp%s' % sSuffix
            sUpperDown = 'upperDown%s' % sSuffix
            sUpperUp = 'upperUp%s' % sSuffix
            cBot = ctrls6.ctrlFromName('mouthBot_ctrl')
            cTop = ctrls6.ctrlFromName('mouthTop_ctrl')
            cMouth = ctrls6.ctrlFromName('mouth_ctrl')

            if sLowerDown in sTargets or sLowerUp in sTargets:
                fBotVertRange = [-1.0 if sLowerDown in sTargets else 0.0, 1.0 if sLowerUp in sTargets else 0.0]
                blendShapesPro.connectTargets(sModel, sLowerUp, dPoses={'%s.ty' % cBot.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sLowerDown, dPoses={'%s.ty' % cBot.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                ctrls6.setSliderRange(cBot, fRangeY=fBotVertRange, bAdjustBorders=True)

                dLowerSplitAlongCurve = utils.data.get('dLipSplitAlongCurve%s' % sSuffix)

                if not utils.isNone(dLowerSplitAlongCurve):
                    dLowerSplitAlongCurve['iSmoothIterations'] = iUpperLowerSmoothIterations
                    blendShapesPro.connectTargets(sModel, sLowerDown, dPoses={}, dSplitAlongCurve=dLowerSplitAlongCurve, bMirror=False,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    dLowerSplitAlongCurve['ffValues'] = [[1.0] * len(dLowerSplitAlongCurve['ffValues'][0])]
                    blendShapesPro.connectTargets(sModel, sLowerUp, dPoses={}, dSplitAlongCurve=dLowerSplitAlongCurve, bMirror=False,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                else: # simple left/right
                    sLipBotCtrls = utils.data.get('sLipBotCtrls')
                    blendShapesPro.connectTargets(sModel, sLowerDown, dPoses={'%s.ty' % sLipBotCtrls[0]: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    blendShapesPro.connectTargets(sModel, sLowerUp, dPoses={'%s.ty' % sLipBotCtrls[0]: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



            if sUpperUp in sTargets or sUpperDown in sTargets:
                fTopVertRange = [-1.0 if sUpperDown in sTargets else 0.0, 1.0 if sUpperUp in sTargets else 0.0]

                blendShapesPro.connectTargets(sModel, sUpperUp, dPoses={'%s.ty' % cTop.sCtrl: 1}, fSplitRadius=fMouthSplitRadius * fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sUpperDown, dPoses={'%s.ty' % cTop.sCtrl: -1}, fSplitRadius=fMouthSplitRadius * fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                ctrls6.setSliderRange(cTop, fRangeY=fTopVertRange, bAdjustBorders=True)

                dUpperSplitAlongCurve = utils.data.get('dUpperSplitAlongCurve%s' % sSuffix)
                if not utils.isNone(dUpperSplitAlongCurve):
                    dUpperSplitAlongCurve['iSmoothIterations'] = iUpperLowerSmoothIterations
                    blendShapesPro.connectTargets(sModel, sUpperUp, dPoses={}, dSplitAlongCurve=dUpperSplitAlongCurve, bMirror=False, bControlRigCommands=True,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis)
                    dUpperSplitAlongCurve['ffValues'] = [[-1.0] * len(dUpperSplitAlongCurve['ffValues'][0])]
                    blendShapesPro.connectTargets(sModel, sUpperDown, dPoses={}, dSplitAlongCurve=dUpperSplitAlongCurve, bMirror=False, bControlRigCommands=True,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis)
                else: # simple left/right. MIGHT NEVER GET INTO THIS ANYMORE ?!
                    sLipTopCtrls = utils.data.get('sLipTopCtrls')

                    blendShapesPro.connectTargets(sModel, sUpperUp, dPoses={'%s.ty' % sLipTopCtrls[0]: 1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    blendShapesPro.connectTargets(sModel, sUpperDown, dPoses={'%s.ty' % sLipTopCtrls[0]: -1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        if not utils.isNone(cCorners):
            for sTarget in ['mouthRound']:
                sTargetSuffix = '%s%s' % (sTarget, sSuffix)
                if cmds.objExists(sTargetSuffix):
                    sAttrs = [utils.addAttr(cCorners[s].sCtrl, ln=sTarget, minValue=0.0, maxValue=1.0, k=True) for s in [0, 1]]
                    blendShapesPro.connectTargets(sModel, sTargetSuffix, dPoses={sAttrs[0]:1.0}, fSplitRadius=fMouthSplitRadius * fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels)

    report.report.addLogText('brows... ', bIncrementProgress=True)

    sBrowIn = 'browIn%s' % sSuffix
    sBrowOut = 'browOut%s' % sSuffix
    sInnerBrowDown = 'innerBrowDown%s' % sSuffix
    sInnerBrowUp = 'innerBrowUp%s' % sSuffix

    sInnerBrowShapes = [sInnerBrowUp, sInnerBrowDown, sBrowIn, sBrowOut]
    if sTargets.intersection(set(sInnerBrowShapes)):
        fRangeX = [-1,1]
        fRangeY = [-1,1]

        if not cmds.objExists(sBrowIn):
            fRangeX[0] = 0
        if not cmds.objExists(sBrowOut):
            fRangeX[1] = 0
        if not cmds.objExists(sInnerBrowDown):
            fRangeY[0] = 0
        if not cmds.objExists(sInnerBrowUp):
            fRangeY[1] = 0

        cInnerBrows = ctrls6.createSliderCtrl('innerEyebrow%s' % sSuffix, 'l', fRangeX=fRangeX, fRangeY=fRangeY, sAttach=sModel,
                                                    sAlignOnModel=[sModel]+sInnerBrowShapes, xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, 'innerBrowUp%s' % sSuffix, dPoses={'%s.ty' % cInnerBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        blendShapesPro.connectTargets(sModel, 'innerBrowDown%s' % sSuffix, dPoses={'%s.ty' % cInnerBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,1], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        blendShapesPro.connectTargets(sModel, 'browIn%s' % sSuffix, dPoses={'%s.tx' % cInnerBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, 'browOut%s' % sSuffix, dPoses={'%s.tx' % cInnerBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sOuterBrowUp = 'outerBrowUp%s' % sSuffix
    sOuterBrowDown = 'outerBrowDown%s' % sSuffix
    if sOuterBrowUp in sTargets or sOuterBrowDown in sTargets:
        fRangeY = [-1,1]
        if not cmds.objExists(sOuterBrowDown):
            fRangeY[0] = 0
        if not cmds.objExists(sOuterBrowUp):
            fRangeY[1] = 0

        cOuterBrows = ctrls6.createSliderCtrl('outerEyebrow%s' % sSuffix, 'l', fRangeY=fRangeY, sAttach=sModel,
                                                    sAlignOnModel=[sModel, 'outerBrowUp', 'outerBrowDown'], xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, sOuterBrowUp, dPoses={'%s.ty' % cOuterBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*fOuterBrowSplitRadiusFactor,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, sOuterBrowDown, dPoses={'%s.ty' % cOuterBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*fOuterBrowSplitRadiusFactor,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    # brow spline ctrls
    sSplineBrowCtrls = sorted(cmds.ls('brow?_l_ctrl', et='transform'))
    for sBrowCtrl in sSplineBrowCtrls:
        sLetter = sBrowCtrl[sBrowCtrl.find('_')-1]
        for sTarget, dPoses in [('browUp%s' % sLetter, {'brow%s_l_ctrl.ty' % sLetter: 1.0}),
                                ('browDown%s' % sLetter, {'brow%s_l_ctrl.ty' % sLetter: -0.5}),
                                ('browIn%s' % sLetter, {'brow%s_l_ctrl.tx' % sLetter: -0.5})]:
            if cmds.objExists(sTarget):
                cBrowCtrl = ctrls6.ctrlFromName(sBrowCtrl)
                sDirectionLetter = list(dPoses.keys())[0][-1].upper()
                sDriver = '%s.totalTranslate%s' % (cBrowCtrl.sPasser, sDirectionLetter)
                if not cmds.objExists(sDriver):
                    raise Exception('driver attribute doesn\'t exist ("%s")' % sDriver)
                blendShapesPro.connectTargets(sModel, sTarget, dPoses=dPoses, dDrivers={sDriver:None},
                                              fSplitRadius=fBrowSplitRadius * 0.5, sSecondaryModels=sSecondaryModels,
                                              fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2)


    report.report.addLogText('cheeks... ', bIncrementProgress=True)

    sCheekRaiser = 'cheekRaiser%s' % sSuffix
    sCheekUp = 'cheekUp%s' % sSuffix
    if not cmds.objExists(sCheekRaiser) and cmds.objExists(sCheekUp):
        sCheekRaiser = sCheekUp
    sCheekLower = 'cheekLower%s' % sSuffix

    if sCheekRaiser in sTargets or sCheekLower in sTargets:
        fRangeY = [-1, 1]
        if not cmds.objExists(sCheekLower):
            fRangeY[0] = 0
        if not cmds.objExists(sCheekRaiser):
            fRangeY[1] = 0

        cCheekRaiser = ctrls6.createSliderCtrl('cheekRaiser%s' % sSuffix, 'l', fRangeY=fRangeY, sAttach=sModel, sAlignOnModel=[sModel, 'cheekRaiser', 'cheekLower'],
                                                     xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, sCheekRaiser, dPoses={'%s.ty' % cCheekRaiser[0].sCtrl: 1.0}, fSplitRadius=fNoseSplitRadius,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, sCheekLower, dPoses={'%s.ty' % cCheekRaiser[0].sCtrl: -1.0}, fSplitRadius=fNoseSplitRadius,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sSquint = 'squint%s' % sSuffix
    if sSquint in sTargets:
        cSquints = ctrls6.createSliderCtrl(sSquint, 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sSquint])
        blendShapesPro.connectTargets(sModel, sSquint, dPoses={'%s.ty' % cSquints[0].sCtrl:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)


    sCheekOut = 'cheekOut%s' % sSuffix
    if not cmds.objExists(sCheekOut):
        sCheekOut = 'puff%s' % sSuffix
    sCheekIn = 'cheekIn%s' % sSuffix

    if sCheekOut in sTargets or sCheekIn in sTargets:
        fPuffRange = [-1,1]
        if sCheekOut not in sTargets:
            fPuffRange[1] = 0.0
        if sCheekIn not in sTargets:
            fPuffRange[0] = 0.0

        cPuffs = ctrls6.createSliderCtrl('puff%s' % sSuffix, 'l', fRangeY=fPuffRange, sShape='doubleArrowSquareY', sAttach=sModel,
                                               sAlignOnModel=[sModel, sCheekOut, sCheekIn], xMirrorAxis=xMirrorAxis)
        if sCheekOut in sTargets:
            blendShapesPro.connectTargets(sModel, sCheekOut, dPoses={'%s.ty' % cPuffs[0].sCtrl:1.0}, fSplitRadius=fMouthSplitRadius,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        if sCheekIn in sTargets:
            blendShapesPro.connectTargets(sModel, sCheekIn, dPoses={'%s.ty' % cPuffs[0].sCtrl:-1.0}, fSplitRadius=fMouthSplitRadius,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


    sPuffFront = 'puffFront%s' % sSuffix
    if sPuffFront in sTargets:
        cPuffFront = ctrls6.createSliderCtrl('puffFront', 'm', fRangeY=[0,1], sShape='doubleArrowSquareY', sAttach=sModel, sAlignOnModel=[sModel, sPuffFront])
        blendShapesPro.connectTargets(sModel, sPuffFront, dPoses={'%s.ty' % cPuffFront[0].sCtrl:1.0}, bMirror=False,
                                   sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10])

    sLipStretch = 'lipStretch%s' % sSuffix
    if sLipStretch in sTargets:
        cLipStretch = ctrls6.createSliderCtrl('lipStretch', 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sLipStretch])
        blendShapesPro.connectTargets(sModel, sLipStretch, dPoses={'%s.ty' % cLipStretch[0].sCtrl:1.0}, fSplitRadius=fMouthSplitRadius * fLowerLipsSplitRadiusFactor,
                                   sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)

    sNeckStretch = 'neckStretch%s' % sSuffix
    if sNeckStretch in sTargets:
        cNeckStretch = ctrls6.createSliderCtrl('neckStretch', 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sNeckStretch])
        blendShapesPro.connectTargets(sModel, sNeckStretch, dPoses={'%s.ty' % cNeckStretch[0].sCtrl:1.0},
                                   sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], fSplitRadius=fMouthSplitRadius * fLowerLipsSplitRadiusFactor, bControlRigCommands=True)




    report.report.addLogText('nose... ', bIncrementProgress=True)


    sNoseWrinkler = 'noseWrinkler%s' % sSuffix
    sNoseDown = 'noseDown%s' % sSuffix
    if sNoseWrinkler in sTargets or sNoseDown in sTargets:
        fRange = [0,0]
        if sNoseWrinkler in sTargets:
            fRange[1] = 1.0
        if sNoseDown in sTargets:
            fRange[0] = -1.0

        cNoseWrinklers = ctrls6.createSliderCtrl('noseWrinkler%s' % sSuffix, 'l', fRangeY=fRange,
                                                       sShape='doubleArrowSquareY', sAttach=sModel, sAlignOnModel=[sModel, sNoseWrinkler], xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, sNoseWrinkler, dPoses={'%s.ty' % cNoseWrinklers[0].sCtrl:1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, sNoseDown, dPoses={'%s.ty' % cNoseWrinklers[0].sCtrl:-1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)

    sNostrilIn = 'nostrilIn%s' % sSuffix
    sNostrilOut = 'nostrilOut%s' % sSuffix
    if sNostrilIn in sTargets or sNostrilOut in sTargets:
        fNostrilRange = [-1,1]
        if sNostrilIn not in sTargets:
            fNostrilRange[0] = 0.0
        if sNostrilOut not in sTargets:
            fNostrilRange[1] = 0.0

        cNostrils = ctrls6.createSliderCtrl('nostril%s' % sSuffix, 'l', fRangeX=fNostrilRange,
                                                  sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, None, None, sNostrilIn, sNostrilOut], xMirrorAxis=xMirrorAxis)
        if sNostrilOut in sTargets:
            blendShapesPro.connectTargets(sModel, sNostrilOut, dPoses={'%s.tx' % cNostrils[0].sCtrl:1.0}, fSplitRadius=fNoseSplitRadius*fNostrilSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        if sNostrilIn in sTargets:
            blendShapesPro.connectTargets(sModel, sNostrilIn, dPoses={'%s.tx' % cNostrils[0].sCtrl:-1.0}, fSplitRadius=fNoseSplitRadius*fNostrilSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


    if not dSkip.get('bSkipJawShapes', False):
        report.report.addLogText('jaw... ', bIncrementProgress=True)

        if utils.data.exists('sBakedBlendShapeJawOpenRotation%s' % sSuffix):
            if bMouthSplines:
                sJawOpenOverrideAttrRotZ = cmds.getAttr('jnt_m_jawMain.jawOpenPoseOverrideRotZ')
                sDriverBot = cmds.getAttr('jnt_m_jawMain.jawOpen_driver_bot')
                sDriverTop = cmds.getAttr('jnt_m_jawMain.jawOpen_driver_top')
                blendShapesPro.connectTargets(sModel, 'jawOpen%s' % sSuffix, bSplitBotTop=True,
                                              dPoses={'jaw%s_ctrl.rz' % sSuffix: sJawOpenOverrideAttrRotZ},
                                              dDrivers={sDriverBot:None, sDriverTop:None},
                                              iInvert=2,
                                              bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                              bControlRigCommands=True)
            else:
                fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation%s' % sSuffix)
                blendShapesPro.connectTargets(sModel, 'jawOpen%s' % sSuffix,
                                           dPoses={'jaw%s_ctrl.r' % sSuffix: tuple(fJawOpenRotation)},
                                           dDrivers={'jaw%s_ctrl.rz' % sSuffix:fJawOpenRotation[2]},
                                           iInvert=2,
                                           bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, bControlRigCommands=True)
        else:
            report.report.addLogText('skipping jaw because not set up in blendShape file')

    report.report.addLogText('eyelids... ', bIncrementProgress=True)

    cBlinkCtrls = [ctrls6.ctrlFromName('blink%s_l_ctrl' % sSuffix), ctrls6.ctrlFromName('blink%s_r_ctrl' % sSuffix)]
    sBlink = 'blink%s' % sSuffix
    sBlinkCurvedUp = 'blinkCurvedUp%s' % sSuffix
    sLeftLidTop = ctrls6.ctrlFromName('lidTop%s_l_ctrl' % sSuffix).sCtrl
    sLeftLidBot = ctrls6.ctrlFromName('lidBot%s_l_ctrl' % sSuffix).sCtrl

    if not dSkip.get('bSkipLidCloseShapes', False):
        if cmds.objExists('blinkCurvedUp'):
            utils.addAttr(cBlinkCtrls[0].sCtrl, ln='upCurveBlink', minValue=0.0, maxValue=1.0, k=True)
            utils.addAttr(cBlinkCtrls[1].sCtrl, ln='upCurveBlink', minValue=0.0, maxValue=1.0, k=True)
            blendShapesPro.connectTargets(sModel, sBlink, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:[0,-1.0], '%s.upCurveBlink' % cBlinkCtrls[0].sCtrl:[1,0]}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, sSecondaryModels=sSecondaryModels, bReturnIfNotExist=True, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            blendShapesPro.connectTargets(sModel, sBlinkCurvedUp, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:[0,-1.0], '%s.upCurveBlink' % cBlinkCtrls[0].sCtrl:[0,1]}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, sSecondaryModels=sSecondaryModels, bReturnIfNotExist=True, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        else:
            blendShapesPro.connectTargets(sModel, sBlink, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:-1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        blendShapesPro.connectTargets(sModel, 'eyeUpperDown%s' % sSuffix, dPoses={'%s.ty' % sLeftLidTop: -1.0}, fSplitRadius=fBlinkSplitRadius * fBlinkSplitRadiusFactor,
                                   iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, 'eyeLowerUp%s' % sSuffix, dPoses={'%s.ty' % sLeftLidBot:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                    iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    blendShapesPro.connectTargets(sModel, 'eyeWide%s' % sSuffix, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:0.5}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
    blendShapesPro.connectTargets(sModel, 'eyeUpperUp%s' % sSuffix, dPoses={'%s.ty' % sLeftLidTop:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    blendShapesPro.connectTargets(sModel, 'eyeLowerDown%s' % sSuffix, dPoses={'%s.ty' % sLeftLidBot:-1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    dEyelookPoses = utils.data.get('dEyelookPoses', xDefault={})

    if dEyelookPoses:
        sEyePoints = []
        sPoseAdditions = []
        for s,sSide in enumerate(['l','r']):
            sEyeRotAttr = 'jnt_%s_eyeMain.r' % sSide
            sPlug = cmds.listConnections(sEyeRotAttr, p=True, s=True, d=False)[0]
            cmds.disconnectAttr(sPlug, sEyeRotAttr)
            sAddition = nodes.createVectorAdditionNode([sPlug, [0,0,0]], sFullName='addition_%s_tempPoseEye' % sSide, sTarget=sEyeRotAttr)
            sPoseAdditions.append('%s.input3D[1]' % sAddition.split('.')[0])

        for sDirection, bVert in [('eyelookDown',True), ('eyelookUp',True), ('eyelookLeft',False), ('eyelookRight',False)]:
            fEyeRotPose = dEyelookPoses.get(sDirection, None)
            if not utils.isNone(fEyeRotPose):
                cLeftLookAt = ctrls6.ctrlFromName('eyesLookAt_l_ctrl', bReturnNoneIfNotExists=True)
                print ('cLeftLookAt: ', cLeftLookAt)
                if not cLeftLookAt:
                    cLeftLookAt = ctrls6.ctrlFromName('eyeLookAt_l_ctrl')
                
                sDriver = '%s.lookVert' % cLeftLookAt.sPasser if bVert else '%s.lookHoriz' % cLeftLookAt.sPasser
                # sUnrealDriver = 'sLookVert_l_eye' if bVert else 'sLookHoriz_l_eye'
                
                print ('cLeftLookAt: ', cLeftLookAt.sCtrl)
                blendShapesPro.connectTargets(sModel, sDirection,
                                           dPoses = {sPoseAdditions[0]: fEyeRotPose, sPoseAdditions[1]: (fEyeRotPose[0], -fEyeRotPose[1], fEyeRotPose[2])},
                                           dDrivers = {sDriver:None, '%s.lidFollow' % cLeftLookAt.sCtrl:1},
                                           fSplitRadius=fBlinkSplitRadius * fBlinkSplitRadiusFactor,
                                           iInvert=0, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    sMouthClose = 'mouthClose%s' % sSuffix
    if bLipCurves:

        if not dSkip.get('bSkipMouthDirectionShapes', False):
            report.report.addLogText('mouth directions... ', bIncrementProgress=True)

            blendShapesPro.connectTargets(sModel, 'mouthLeft%s' % sSuffix, dPoses={'%s.tx' % cMouth.sCtrl:1.0}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            if cmds.objExists('mouthLeft') and not cmds.objExists('mouthRight'):
                cmds.duplicate('mouthLeft', n='mouthRight')
                geometry.meshMirrorMiddle([patch.patchFromName('mouthRight')], iDirection=geometry.MirrorDirection.flip, bControlRigCommands=True)

            blendShapesPro.connectTargets(sModel, 'mouthRight%s' % sSuffix, dPoses={'%s.tx' % cMouth.sCtrl:-1.0}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)

            blendShapesPro.connectTargets(sModel, 'mouthUp%s' % sSuffix, dPoses={'%s.ty' % cMouth.sCtrl:1.0}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)
            blendShapesPro.connectTargets(sModel, 'mouthDown%s' % sSuffix, dPoses={'%s.ty' % cMouth.sCtrl:-1.0}, iInvert=2 if bMouthSplines else 0,
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)

            if not bMouthSplines:
                blendShapesPro.connectTargets(sModel, 'mouthLeft%s' % sSuffix, dPoses={'%s.tx' % cBot.sCtrl:1.0, '%s.tx' % cTop.sCtrl:1.0}, bSplitBotTop=True, iInvert=2 if bMouthSplines else 0,
                                            bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, 'mouthRight%s' % sSuffix, dPoses={'%s.tx' % cBot.sCtrl:-1.0, '%s.tx' % cTop.sCtrl:-1.0}, bSplitBotTop=True, iInvert=2 if bMouthSplines else 0,
                                            bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=None if bMouthSplines else [0,10], bControlRigCommands=True)


        report.report.addLogText('lip corners... ', bIncrementProgress=True)

        if not utils.isNone(cCorners) and not dSkip.get('bSkipCornerShapes', False):

            sCornerUp = 'cornerUp%s' % sSuffix
            sCornerDown = 'cornerDown%s' % sSuffix
            sCornerOut = 'cornerOut%s' % sSuffix
            sPucker = 'pucker%s' % sSuffix
            fCornerUpValue = cmds.getAttr('grp_l_lipsCornerPasser.cornerUp')
            fCornerDownValue = cmds.getAttr('grp_l_lipsCornerPasser.cornerDown')
            fCornerOutValue = cmds.getAttr('grp_l_lipsCornerPasser.cornerOut')
            fCornerInValue = cmds.getAttr('grp_l_lipsCornerPasser.cornerIn')
            blendShapesPro.connectTargets(sModel, sCornerUp, dPoses={'%s.ty' % cCorners[0].sCtrl:fCornerUpValue}, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True,
                                        iInvert=2 if bMouthSplines else 0)
            blendShapesPro.connectTargets(sModel, sCornerDown, dPoses={'%s.ty' % cCorners[0].sCtrl:fCornerDownValue}, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True,
                                        iInvert = 2 if bMouthSplines else 0)
            blendShapesPro.connectTargets(sModel, sCornerOut, dPoses={'%s.tx' % cCorners[0].sCtrl:fCornerOutValue}, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True,
                                        iInvert=2 if bMouthSplines else 0)
            blendShapesPro.connectTargets(sModel, sPucker, dPoses={'%s.tx' % cCorners[0].sCtrl:fCornerInValue}, fSplitRadius=fMouthSplitRadius*fMouthPuckerSplitRadiusFactor,
                                        bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True,
                                        iInvert=2 if bMouthSplines else 0)


        if not dSkip.get('bSkipLipShapes', False):
            fTopRollRange = [0,0]
            report.report.addLogText('lip rolls... ', bIncrementProgress=True)
            if 'upperRollOut' in sTargets or 'upperRollIn' in sTargets:
                fTopRollRange = [-1.0 if 'upperRollIn' in sTargets else 0.0, 1.0 if 'upperRollOut' in sTargets else 0.0]
                blendShapesPro.connectTargets(sModel, 'upperRollOut%s' % sSuffix, dPoses={'%s.tz' % cTop.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, 'upperRollIn%s' % sSuffix, dPoses={'%s.tz' % cTop.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            if not bMouthSplines:
                ctrls6.setSliderRange(cTop, fRangeZ=fTopRollRange, bAdjustBorders=True)


            fBotRollRange = [0, 0]
            if 'lowerRollOut' in sTargets or 'lowerRollIn' in sTargets:
                fBotRollRange = [-1.0 if 'lowerRollIn' in sTargets else 0.0, 1.0 if 'lowerRollOut' in sTargets else 0.0]
                blendShapesPro.connectTargets(sModel, 'lowerRollOut%s' % sSuffix, dPoses={'%s.tz' % cBot.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, 'lowerRollIn%s' % sSuffix, dPoses={'%s.tz' % cBot.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

            if not bMouthSplines:
                ctrls6.setSliderRange(cBot, fRangeZ=fBotRollRange, bAdjustBorders=True)


            report.report.addLogText('lipPress/funnel/fff... ', bIncrementProgress=True)

        # blendShapesPro.connectTargets(sModel, 'forward%s' % sSuffix, dPoses={'mouthBot_ctrl.tz':1, 'mouthTop_ctrl.tz':1}, fSplitRadius=8.0, bSplitBotTop=True,
        #                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10])

        if not dSkip.get('bSkipLipShapes', False):
            bMouthSplines = utils.data.get('bMouthSplines%s' % sSuffix)
            
            if 'funnel' in sTargets:
                blendShapesPro.connectTargets(sModel, 'funnel%s' % sSuffix, dPoses={'mouth_ctrl.tz':1}, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True,
                                              iInvert=2 if bMouthSplines else 0)

            if 'lipPress' in sTargets:
                blendShapesPro.connectTargets(sModel, 'lipPress%s' % sSuffix, dPoses={'mouth_ctrl.tz':-1}, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True,
                                              iInvert=2 if bMouthSplines else 0)


    report.report.addLogText('Extra Targets... ', bIncrementProgress=True)
    for sCtrl, dData in list(ddTargetsAsAttributes.items()):
        sTarget = dData.get('sTarget', None)
        if not sTarget:
            continue
            # raise Exception, '%s in ddTargetsAsAttributes doesn\'t have a sTarget defined' % sTarget

        sTargetSuffix = '%s%s' % (sTarget, sSuffix)
        sCtrlSuffix = '%s%s' % (sCtrl, sSuffix)
        fSplitRadius = dData.get('fSplitRadius', 0.2)
        if utils.getSide(sCtrl) == 'l':
            sAttrs = [utils.addAttr(sCtrlSuffix, ln=sTarget, min=0, max=1, dv=0, k=True),
                      utils.addAttr(utils.getMirrorName(sCtrlSuffix), ln=sTarget, min=0, max=1, dv=0, k=True)]
            bMirror = True
        else:
            sAttrs = [utils.addAttr(sCtrlSuffix, ln=sTarget, min=0, max=1, dv=0, k=True)]
            bMirror = False

        blendShapesPro.connectTargets(sModel, sTargetSuffix, dPoses={sAttrs[0]:1.0},
                                    fSplitRadius=fSplitRadius,
                                    sSecondaryModels=sSecondaryModels,
                                    bMirror=bMirror)


    for dSlider in ddExtraTargetSliders:
        sExtraTargets = [None] * 4
        dTargets = dSlider['dTargets']
        bControlRigCommands = dSlider.get('bDoControlRig', True)

        bOneOfThemExists = False
        for k, sKey in enumerate(['sTargetUp', 'sTargetDown', 'sTargetOut', 'sTargetIn']):
            sValue = dTargets.get(sKey, '')
            if sValue and cmds.objExists(sValue):
                sExtraTargets[k] = sValue
                bOneOfThemExists = True

        if bOneOfThemExists:
            fRangeY = [0,0]
            fRangeX = [0,0]
            if sExtraTargets[0] or sExtraTargets[1]:
                fRangeY = [-1 if sExtraTargets[1] else 0,
                          1 if sExtraTargets[0] else 0]
            if sExtraTargets[2] or sExtraTargets[3]:
                fRangeX = [-1 if sExtraTargets[3] else 0,
                          1 if sExtraTargets[2] else 0]



            bMirror = dSlider.get('bMirror', True)
            cSliders = ctrls6.createSliderCtrl('%s%s' % (dSlider['sName'], sSuffix), 'l' if bMirror else 'm', fRangeX=fRangeX, fRangeY=fRangeY, sAttach=sModel,
                                                sShape=dSlider.get('sShape', 'sphere'), sAlignOnModel=[sModel]+sExtraTargets, xMirrorAxis=xMirrorAxis)

            if sExtraTargets[0]: # up
                blendShapesPro.connectTargets(sModel, sExtraTargets[0], dPoses={'%s.ty' % cSliders[0].sCtrl: 1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)
            if sExtraTargets[1]: # down
                blendShapesPro.connectTargets(sModel, sExtraTargets[1], dPoses={'%s.ty' % cSliders[0].sCtrl: -1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)
            if sExtraTargets[2]: # in
                blendShapesPro.connectTargets(sModel, sExtraTargets[2], dPoses={'%s.tx' % cSliders[0].sCtrl: 1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)
            if sExtraTargets[3]: # out
                blendShapesPro.connectTargets(sModel, sExtraTargets[3], dPoses={'%s.tx' % cSliders[0].sCtrl: -1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror, bControlRigCommands=bControlRigCommands)


    for sTarget, dData in list(ddCorrectives.items()):
        if not cmds.objExists(sTarget):
            continue
        dDrivers = {}
        if dData['sDrivers']:
            dDrivers = {sD:None for sD in dData['sDrivers']}

        blendShapesPro.connectTargets(sModel, '%s%s' % (sTarget, sSuffix),
                                    dPoses=dData['dPoses'],
                                    fSplitRadius=dData.get('fSplitRadius', 0.2),
                                    sSecondaryModels=sSecondaryModels,
                                    bMirror=dData.get('bMirror', True),
                                    dDrivers = dDrivers,
                                    iInvert=2)


    report.report.addLogText('mouth close... ', bIncrementProgress=True)

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={}) # should be defaultDict(list), but that can't be stored
    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={}) # should be defaultDict(list), but that can't be stored
    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={})
    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={})
    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={})
    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={})
    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={})
    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={})
    dConnectTargetControlRigCommands = utils.data.get('dConnectTargetControlRigCommands', xDefault={})
    dConnectTargetLidRanges = utils.data.get('dConnectTargetLidRanges', xDefault={})


    if bLipCurves:
        sMouthCloseAttr = utils.addAttr('mouth_ctrl', ln=sMouthClose, minValue=0.0, maxValue=1.0, k=True, bReturnIfExists=True)

        utils.addListKey(dConnectTargetPoses, sMouthClose)
        utils.addListKey(dConnectTargetDrivers, sMouthClose)
        utils.addListKey(dConnectTargetMirrors, sMouthClose)
        utils.addListKey(dConnectTargetSplitRadien, sMouthClose)
        utils.addListKey(dConnectTargetSplitBotTops, sMouthClose)
        utils.addListKey(dConnectTargetInverts, sMouthClose)
        utils.addListKey(dConnectTargetSplitAlongCurves, sMouthClose)
        utils.addListKey(dConnectTargetZippers, sMouthClose)
        utils.addListKey(dConnectTargetLidRanges, sMouthClose)
        utils.addListKey(dConnectTargetControlRigCommands, sMouthClose)

        dConnectTargetPoses[sMouthClose].append({sMouthCloseAttr: 1.0})
        dConnectTargetDrivers[sMouthClose].append({sMouthCloseAttr: [0,1]}) # in the normal command this is created manually.
        dConnectTargetMirrors[sMouthClose].append(False)
        dConnectTargetSplitRadien[sMouthClose].append(1.0)
        dConnectTargetSplitBotTops[sMouthClose].append(False)
        dConnectTargetInverts[sMouthClose].append(2)
        dConnectTargetSplitAlongCurves[sMouthClose].append({})
        dConnectTargetZippers[sMouthClose].append({})
        dConnectTargetLidRanges[sMouthClose].append([])
        dConnectTargetControlRigCommands[sMouthClose].append([])


    utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
    utils.data.store('dConnectTargetDrivers', dConnectTargetDrivers)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)
    utils.data.store('dConnectTargetInverts', dConnectTargetInverts)
    utils.data.store('dConnectTargetSplitAlongCurves', dConnectTargetSplitAlongCurves)
    utils.data.store('dConnectTargetZippers', dConnectTargetZippers)
    utils.data.store('dConnectTargetLidRanges', dConnectTargetLidRanges)
    utils.data.store('dConnectTargetControlRigCommands', dConnectTargetControlRigCommands)

    # combo shapes
    sComboTargets = [sT for sT in sTargets if '_' in sT and '__' not in sT]
    sComboTargets.sort(key=lambda sT:len(sT.split('_')))

    report.report.addLogText('All the combos......', bIncrementProgress=True, bRefresh=True)
    report.report.resetProgress(len(sComboTargets))

    for sComboT in sComboTargets:
        bSuccess, sMessage = blendShapesPro.autoConnectComboTarget(sComboT, sModel, sSecondaryModels, xMirrorAxis=xMirrorAxis, bLegacyIgnoreEyeLookHoriz=False)
        report.report.addLogText(sMessage, bRefresh=True, bIncrementProgress=True)
        if not bSuccess:
            bReturn = False

    # for sM in [sModel] + sSecondaryModels:
    #     if not utils.isNone(sM):
    #         for sBlendShape in deformers.listAllDeformers(sM, sFilterTypes=['blendShape']):
    #             deformers.makeNotExport(sBlendShape)

    return bReturn



# @builderTools.addToBuild(iOrder=85, dButtons=dButtons, bDisableByDefault=True)
# def createSpeechParentCtrls():
#     sliderctrls6.addParentCtrl('lipsCorner_l_ctrl')
#     sliderctrls6.addParentCtrl('lipsBot_l_ctrl', bTurnOffParentAttr=True)
#     sliderctrls6.addParentCtrl('lipsTop_l_ctrl', bTurnOffParentAttr=True)
#






def _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='LipsDetail', sSkinClusterSuffix='DETAIL'):

    iBindLipRows = iBindLipRows
    fBotMultipl, fCornerMultipl, fTopMultipl = fBindMultipls



    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        sSkinCluster = 'skinCluster__%s__%s' % (sMesh, sSkinClusterSuffix)
        sSkinClusterTemp = 'TEMP__skinCluster__%s__%s' % (sMesh, sSkinClusterSuffix)


        if cmds.objExists(sSkinClusterTemp):
            cmds.delete(sSkinClusterTemp)
        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()


        deformers.skinMesh(sMesh, ['jnt_m_faceZero'], sName=sSkinClusterTemp, bAlwaysAddDefaultWeights=True)

        weights.smoothSkinWeights([pMesh], iIterations=2, sChooseSkinCluster=sSkinClusterTemp)
        report.report.incrementProgress(bRefresh=True)
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)


        report.report.addLogText('\nskinning lips..', bRefresh=True)
        fTimeBefore = time.time()


        sAllJoints = []
        fAllValues = []


        bIgnoreMostOut = False # probably useless...
        if bIgnoreMostOut:
            iStart = 1
            iEnd = -1
        else:
            iStart = 0
            iEnd = None

        # left top
        sJoints = ['jnt_m_top%s_000' % sSuffix] + sorted(cmds.ls('jnt_l_top%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fTopMultipl, fTopMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # left bot
        sJoints = sorted(cmds.ls('jnt_l_bot%s_???' % sSuffix, et='joint'), reverse=True) + ['jnt_m_bot%s_000' % sSuffix]
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fBotMultipl, fBotMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        # right bot
        sJoints = sorted(cmds.ls('jnt_r_bot%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fBotMultipl, fBotMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # right top
        sJoints = sorted(cmds.ls('jnt_r_top%s_???' % sSuffix, et='joint'), reverse=True)
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fTopMultipl, fTopMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        print('sAlLJoins: ', sAllJoints)
        print('fAllValues: ', fAllValues)

        fJointWeightings = np.array(fAllValues, dtype='float64')
        print('fJointWeightings: ', fJointWeightings)


        # fJointWeightings = np.interp(np.arange(sJoints), iIndices, [1, 0.5, ]
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()
        weights.bindToClosestVertexAndExpand([pMesh], sJoints=sAllJoints, fJointWeightings=fJointWeightings,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iBindLipRows[0], iExpandedFadeOutLoops=iBindLipRows[1],
                                             sChooseSkinCluster=sSkinClusterTemp)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)


        if cmds.objExists(sSkinCluster):
            pTransferTo = pMesh
            for pSel in pSelection:
                if pSel.getName() == pMesh.getName():
                    pTransferTo = pSel
                    break

            weights.transferSkinCluster([pTransferTo], sFrom=sSkinClusterTemp, sChooseSkinCluster=sSkinCluster, iMode=weights.TransferMode.vertexIndex)
            cmds.delete(sSkinClusterTemp)
        else:
            cmds.rename(sSkinClusterTemp, sSkinCluster)

        deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)



def proceduralBind_details(iBindLipRows, fBindMultipls):
    _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='LipsDetail', sSkinClusterSuffix='DETAIL')


dButtons = {}
dButtons['bind selected'] = proceduralBind_details


@builderTools.addToBuild(iOrder=95, dButtons=dButtons, bDisableByDefault=True)
def DETAILS_mouth(sAttachMesh=[], iBindLipRows=[3,3], fBindMultipls=[1.0,1.0,1.0]):
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')
    pMesh = patch.patchFromName(sAttachMesh)
    sBpCurves = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]
    iiVerts = [topology.getIdsAlongCurve(pMesh, sBpCurves[0])[0],
               topology.getIdsAlongCurve(pMesh, sBpCurves[1])[0]]
    iiVerts[1] = iiVerts[1][1:-1]
    fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode) or cmds.getAttr('jnt_m_jawEnd.tx') * 0.2

    sGroup = cmds.createNode('transform', n='grp_details', p='modules')
    ssJoints = [[], []]
    ssRefJoints = [[], []]
    for p,sPart in enumerate(['bot','top']):
        sSides, iInds = utils.convertMiddleSequenceToSides(len(iiVerts[p]))
        for i, iVert in enumerate(iiVerts[p]):
            sJ = 'jnt_%s_%sLipsDetail_%03d' % (sSides[i], sPart, iInds[i])
            if not cmds.objExists(sJ):
                xforms.createJoint(sJ, fSize=fSliderScale*0.1)
            sRefJ = xforms.createJoint('jnt_%s_%sLipsDetail_%03d_ref' % (sSides[i], sPart, iInds[i]), fSize=fSliderScale*0.1)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            ssJoints[p].append(sJ)
            ssRefJoints[p].append(sRefJ)

            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJ)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sRefJ)


    sSkinClusters = [sS for sS in deformers.listAllDeformers(sAttachMesh, sFilterTypes=['skinCluster']) if 'DETAIL' not in sS]
    sLocs = constraints.parallelTransformAsDeformers(sAttachMesh, iiVerts[0]+iiVerts[1], sDeformers=sSkinClusters, sParent=sGroup, fTargetMinimumDistance=0.01)
    ssLocs = [sLocs[0:len(iiVerts[0])], sLocs[len(iiVerts[0]):]]
    sCtrlsGrp = cmds.createNode('grp_detailCtrls', p='ctrls')
    sVisAttr = utils.addOffOnAttr('head_ctrl', 'lipsDetailCtrlsVis', False, sTarget='%s.v' % sCtrlsGrp)
    ccCtrls = [], []
    for p,sPart in enumerate(['bot','top']):

        sSides, iInds = utils.convertMiddleSequenceToSides(len(iiVerts[p]))
        for i, iVert in enumerate(iiVerts[p]):
            cC = ctrls6.create('%sDetail' % sPart, sSide=sSides[i], iIndex=iInds[i], sParent=sCtrlsGrp, sShape='circleZ', iColorIndex=3, fMatchPos=ssLocs[p][i],
                               fSliderScale=fSliderScale, sAttrs=['t','r','s'])
            cmds.connectAttr(sVisAttr, '%s.v' % cC.sPasser)
            aHeadMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')

            iUp = i-1 if sSides[i] == 'r' else i+1
            fSideMultipl = -1.0 if sSides[i] == 'r' else 1.0
            xforms.orientThreePoints(cC.sPasser, aHeadMatrix[0,0:3], ssLocs[p][iUp], fAimVector=[0,fSideMultipl,0], fUpVector=[fSideMultipl,0,0])
            cmds.parent(ssJoints[p][i], cC.sOut)
            cmds.parent(ssRefJoints[p][i], cC.sPasser)
            xforms.resetTransform(ssJoints[p][i])
            xforms.resetTransform(ssRefJoints[p][i])

            # sSlider = cC.appendOffsetGroup('slider')
            # fSideMultipl = -1.0 if sSides[i] == 'r' else 1.0
            # cmds.setAttr('%s.s' % sSlider, fSideMultipl * fSliderScale*0.2, fSliderScale*0.2, fSliderScale*0.2)
            # cmds.setAttr('%s.s' % cC.sOut, fSideMultipl * 1.0/(fSliderScale*0.2), 1/(fSliderScale*0.2), 1/(fSliderScale*0.2))

            constraints.matrixParentConstraint(ssLocs[p][i], cC.sPasser, mo=True)
            ccCtrls[p].append(cC)


    for cC in ccCtrls[0] + ccCtrls[1][::-1]:
        cmds.controller(cC.sCtrl, 'mouth_ctrl' if cmds.objExists('mouth_ctrl') else 'head_ctrl', parent=True)

    # utils.reload2(deformers)
    deformers.connectRefsOnCurrentSkinClusters(ssJoints[0]+ssJoints[1])

    cmds.select(ssJoints[0]+ssJoints[1])




# ***************************
# **** Bend Controls  *******
# ***************************

kBendBpGroupName = '_grp_m_faceBendBps'
kBendBpFileName = 'faceBlueprintsFaceBend.ma'


def placeBendBpCircles():
    xforms.createOrReturnTopGroup(kBendBpGroupName)
    cmds.delete(cmds.parentConstraint('jnt_m_headMain', kBendBpGroupName))
    sCircles = []
    fScale = xforms.distanceBetween('jnt_m_jawEnd', 'jnt_m_headEnd') * 0.5
    for sName, sMatch, fS in [('bp_m_bendBot', 'jnt_m_jawEnd', 0.5),
                              ('bp_m_bendMid', 'bp_l_eye_main', 1.0),
                              ('bp_m_bendTop', 'jnt_m_headEnd', 0.75)]:
        sCircle = cmds.circle(name=sName)[0]
        cmds.parent(sCircle, kBendBpGroupName)
        # cmds.setAttr('%s.rz' % sCircle, 90)
        cmds.rotate(90, 0, 0, '%s.cv[*]' % sCircle)
        cmds.setAttr('%s.s' % sCircle, fScale * fS, fScale * fS, fScale * fS)
        sCircles.append(sCircle)
        cmds.delete(cmds.pointConstraint(sMatch, sCircle))

    cmds.setAttr('%s.ty' % sCircles[1], 0)
    cmds.setAttr('%s.tz' % sCircles[1], 0)

    cmds.select(sCircles)




daBodyWeights2d = {}
daBodyInfluences = {}

def bendSetupConnectInfluencesToSelection():
    sMeshes = cmds.ls(sl=True)


    for sMesh in sMeshes:

        sBendInfluences = ['jnt_m_faceZero', 'jnt_m_faceBendMiddle'] + \
                          cmds.ls('jnt_m_botFaceBendSquash_???', et='joint') + cmds.ls('jnt_m_topFaceBendSquash_???', et='joint')

        sSkinCluster = 'skinCluster__%s__BEND' % sMesh
        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sBendInfluences, sName=sSkinCluster, bAlwaysAddDefaultWeights=True, bAlwaysCreateManually=True)
        else:
            deformers.addInfluences(sSkinCluster, sBendInfluences)

    cmds.select(sMeshes)


def bendSetupBindSelectedToMiddle():
    sMeshes = cmds.ls(sl=True)

    for sMesh in sMeshes:

        sBendInfluences = ['jnt_m_faceZero', 'jnt_m_faceBendMiddle']

        sSkinCluster = 'skinCluster__%s__BEND' % sMesh
        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sBendInfluences, sName=sSkinCluster, bAlwaysAddDefaultWeights=True, bAlwaysCreateManually=True)
        else:
            deformers.addInfluences(sSkinCluster, sBendInfluences)
        pBody = patch.patchFromName(sMesh)

        pBody.setSkinClusterWeights(np.ones(pBody.getTotalCount(), dtype='float64')[:,np.newaxis], sInfluences=['jnt_m_faceBendMiddle'], sChooseSkinCluster=sSkinCluster)

    cmds.select(sMeshes)






def bendRomAnim():
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=1, v=1.0)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=10, v=1.25)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=20, v=0.8)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=30, v=1.0)

    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=30, v=0.0)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=40, v=0.25)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=50, v=-0.25)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=60, v=0.0)

    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=60, v=0.0)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=70, v=0.25)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=80, v=-0.25)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=90, v=0.0)


    cmds.playbackOptions(e=True, minTime=0, maxTime=100)

placeBendBpCircles.dSideButtons = {'?':[['No selection needed. After clicking the button, it should look like '\
                             '\nthe picture below. If it doesn\'t, check the joints "jnt_m_jawEnd", "jnt_m_headMain" and "jnt_m_headEnd"'],
                            'bendCircles.jpg']}


dButtons = OrderedDict()
dButtons['create BPs'] = placeBendBpCircles
dButtons['connect influences (selected meshes)'] = bendSetupConnectInfluencesToSelection
dButtons['bind to Middle (selected meshes)'] = bendSetupBindSelectedToMiddle
dButtons['SELECT'] = {'main joint':lambda:cmds.select('jnt_m_faceBendMiddle'),
                      'bot & top joints':lambda:cmds.select('jnt_m_???FaceBendSquash_???'),
                      'bot joints':lambda:cmds.select('jnt_m_botFaceBendSquash_???'),
                      'top joints':lambda:cmds.select('jnt_m_topFaceBendSquash_???')}
dButtons['create rom anim'] = bendRomAnim
dButtons['- Export Bend BPs -'] = lambda: exportBps(kBendBpFileName, kBendBpGroupName)


@builderTools.addToBuild(iOrder=62.5, dButtons=dButtons, bDisableByDefault=True)
def createBendSetup(sParentJoint='jnt_m_headMain', bBotTopChains=True, iBotTopJointCounts=[6, 6], fDefaultPivot=[0,0,0], fPivotDefaultTranslation=[0,0,0]):
    '''
    This creates the controls "ctrl_m_botFaceSquashStretch", "ctrl_m_midFaceSquashStretch" and "ctrl_m_topFaceSquashStretch"
    '''
    fSliderScale = cmds.getAttr('jnt_m_jawEnd.tx') * 0.5
    fJointRadius = xforms.getAverageJointRadius()
    fCtrlSize = fSliderScale * 4
    sBendGrp = cmds.createNode('transform', name='grp_m_faceBend', p=getFaceGrp())
    aParentJointMatrix = utils.getNumpyMatrixFromTransform(sParentJoint)
    constraints.matrixParentConstraint(sParentJoint, sBendGrp, skipScale=[])
    sBps = ['bp_m_bend%s' % sN for sN in ['Bot', 'Mid', 'Top']]
    cCtrls = []

    cMiddleCtrl = ctrls6.create(sName='faceSquashStretch', sSide='m', sParent=_getFaceCtrlGrp(), fRotateShape=(0, 90, 0),
                      sAttrs=['t','r','s'], fSliderScale=fSliderScale,
                      sMatch=sBps[1], sShape='circleY', fSize=fCtrlSize / fSliderScale, bPivot=True)
    cmds.controller(cMiddleCtrl.sCtrl, headCtrl(), parent=True)

    constraints.matrixParentConstraint(sParentJoint, cMiddleCtrl.sPasser, mo=True, skipScale=[])

    sMiddleJ = 'jnt_m_faceBendMiddle'
    if not cmds.objExists(sMiddleJ):
        cmds.createNode('joint', n=sMiddleJ)
    cmds.setAttr('%s.radius' % sMiddleJ, fSliderScale * 0.1)
    xforms.parentJointNoTransform(sMiddleJ, cMiddleCtrl.sOut)
    xforms.resetTransform(sMiddleJ, jo=True)# if not bLegacyJointOrientIssue else False)
    sLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sMiddleJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
    sRefMatrix = nodes.createMultMatrixNode([sLocalMatrix, '%s.worldMatrix' % sParentJoint])
    sInvRefMatrix = nodes.createInverseMatrix(sRefMatrix)
    utils.addStringAttr(sMiddleJ, deformers.kPostRefJointAttr, sInvRefMatrix)
    deformers.connectJointReferencesFromAttr(sMiddleJ)
    cmds.setAttr('%s.t' % cMiddleCtrl.sPivot, *fDefaultPivot)
    cmds.connectAttr('master.skeletonVis', '%s.v' % sMiddleJ)

    sSquashStretch = utils.addAttr(cMiddleCtrl.sCtrl, ln='squashStretch', k=True)
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sy' % cMiddleCtrl.sRevR, [0, 1, 10])
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sx' % cMiddleCtrl.sRevR, [10, 1, 0])
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sz' % cMiddleCtrl.sRevR, [10, 1, 0])

    if bBotTopChains:
        cC = ctrls6.create(sName='faceSquashStretchBot', sSide='m', sParent=_getFaceCtrlGrp(),
                          sAttrs=['t', 'r', 's'], fRotateShape=(90, 0, 90), fSliderScale=fSliderScale,
                          sMatch=[sBps[0], sBps[1]], sShape='circleY', fSize=fCtrlSize / fSliderScale)
        cCtrls.append(cC)
        cC = ctrls6.create(sName='faceSquashStretchTop', sSide='m', sParent=_getFaceCtrlGrp(),
                           sAttrs=['t', 'r', 's'], fRotateShape=(90, 0, 90), fSliderScale=fSliderScale,
                          sMatch=[sBps[2], sBps[1]], sShape='circleY', fSize=fCtrlSize / fSliderScale)
        cCtrls.append(cC)

        for cC in cCtrls:
            constraints.matrixParentConstraint(sMiddleJ, cC.sPasser, mo=True, skipScale=[])
            cmds.controller(cC.sCtrl, cMiddleCtrl.sCtrl, parent=True)

        aPoints = xforms.getPositionArray(sBps)

        aAllCurvePoints = np.array([aPoints[0],
                                    aPoints[0] * 0.33 + aPoints[1] * 0.66,
                                    aPoints[1],
                                    aPoints[1] * 0.66 + aPoints[2] * 0.33,
                                    aPoints[2]], dtype='float64')
        aTopTangent = aAllCurvePoints[3] - aAllCurvePoints[2]
        aBotTangent = aAllCurvePoints[1] - aAllCurvePoints[2]
        fTopTangentLength = np.linalg.norm(aTopTangent)
        fBotTangentLength = np.linalg.norm(aBotTangent)
        aTopTangent /= fTopTangentLength
        aBotTangent /= fBotTangentLength
        aTopSmoothed = (aTopTangent - aBotTangent) * 0.5
        aBotSmoothed = -aTopSmoothed
        aTopSmoothed *= fTopTangentLength
        aBotSmoothed *= fBotTangentLength
        aAllCurvePoints[1] = aAllCurvePoints[2] + aBotSmoothed.reshape(1, 3)
        aAllCurvePoints[3] = aAllCurvePoints[2] + aTopSmoothed.reshape(1, 3)
        cmds.curve(p=aAllCurvePoints)

        aaRanges = [np.arange(2, -1, -1), np.arange(2, 5, 1)]
        ssJoints = [], []
        ssSquashJoints = [], []

        for p, sPart in enumerate(['bot', 'top']):
            fPartMultipl = -1.0 if sPart == 'top' else 1.0
            cCtrl = cCtrls[p]
            sCurve = cmds.curve(n='curve_m_%sFaceBend_Temp' % sPart, p=aAllCurvePoints[aaRanges[p]], d=2)
            fEyeHeightPerc = 0.0
            curves.rebuildWithPercs(sCurve, fPercs=[0,
                                                    fEyeHeightPerc,  # *0.9,
                                                    fEyeHeightPerc + (1.0 - fEyeHeightPerc) * 0.5,
                                                    1.0])

            aPoints = curves.getPointsFromPercs(sCurve, np.linspace(0, 1, iBotTopJointCounts[p]), bReturnNumpy=True)

            # first create skinParent joints for easier binding
            aPoints4 = utils.makePoint4Array(aPoints)
            aPointsLocal4 = np.dot(aPoints4, np.linalg.inv(aParentJointMatrix))
            aPointsLocalAverage = np.average(aPointsLocal4, axis=0)
            aPointsLocal4[:, 1] = aPointsLocalAverage[1]
            aPointsLocal4[:, 2] = aPointsLocalAverage[2]
            aParentSkinPoints = np.dot(aPointsLocal4, aParentJointMatrix)[:, 0:3]
            sSkinParentJoints = xforms.createJointChain(aParentSkinPoints,
                                                        ['jnt_m_%sFaceBendSkinParent_%03d' % (sPart, j) for j in
                                                         range(len(aParentSkinPoints))],
                                                        sParent=sBendGrp)

            sPrev = sMiddleJ
            for j in range(iBotTopJointCounts[p]):
                sJ = 'jnt_m_%sFaceBend_%03d' % (sPart, j)
                sSquashJ = 'jnt_m_%sFaceBendSquash_%03d' % (sPart, j)
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sPrev)
                    xforms.resetTransform(sJ, jo=True)
                else:
                    cmds.createNode('joint', n=sJ, p=sPrev)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                cmds.setAttr('%s.radius' % sJ, fJointRadius)
                cmds.xform(sJ, t=aPoints[j], ws=True)


                if j < iBotTopJointCounts[p] - 1:
                    if cmds.objExists(sSquashJ):
                        cmds.parent(sSquashJ, sJ)
                        xforms.resetTransform(sSquashJ, jo=True)
                    else:
                        cmds.createNode('joint', n=sSquashJ, p=sJ)
                    cmds.setAttr('%s.radius' % sSquashJ, fJointRadius * 1.5)
                    cmds.setAttr('%s.segmentScaleCompensate' % sSquashJ, False)
                    utils.addStringAttr(sSquashJ, 'skinParent', sSkinParentJoints[j], bLock=True)
                    ssSquashJoints[p].append(sSquashJ)

                ssJoints[p].append(sJ)
                sPrev = sJ

            # ref:
            for sJ in ssJoints[p] + ssSquashJoints[p]:
                fLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                sRefMatrix = nodes.createMultMatrixNode([fLocalMatrix, '%s.worldMatrix' % sParentJoint], sName='%s_ref' % sJ)
                sInvRefMatrix = nodes.createInverseMatrix(sRefMatrix, sName='%s_invRef' % sJ)
                utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sInvRefMatrix)


            deformers.connectJointReferencesFromAttr(ssJoints[p])
            deformers.connectJointReferencesFromAttr(ssSquashJoints[p])

            sScaleAttrSquash = [1,
                                utils.addAttr(cCtrl.sPasser, ln='autoSquashWidth', min=0, max=10, dv=1, k=True),
                                utils.addAttr(cCtrl.sPasser, ln='autoSquashDepth', min=0, max=10, dv=0.2, k=True)]
            sScaleAttrStretch = [1,
                                utils.addAttr(cCtrl.sPasser, ln='autoStretchWidth', min=0, max=10, dv=1, k=True),
                                utils.addAttr(cCtrl.sPasser, ln='autoStretchDepth', min=0, max=10, dv=0.2, k=True)]

            aOutStretchStrength = np.arange(len(ssJoints[p])) / float(len(ssJoints[p])-1)
            aOutStretchStrengthStartQuick = 1.0 - np.power(1.0-aOutStretchStrength, 2)
            aOutStretchStrengthScale = (1+np.arange(len(ssJoints[p]))) / float(len(ssJoints[p]))

            sCtrlScaleDiff = nodes.createVectorAdditionNode(['%s.s' % cCtrl.sCtrl, [1,1,1]], sOperation='minus')
            for j, sJ in enumerate(ssJoints[p]):
                sCtrlTranslate = nodes.createVectorMultiplyNode('%s.t' % cCtrl.sCtrl, (aOutStretchStrengthStartQuick[j] * fSliderScale * (2.0 / iBotTopJointCounts[p])), bVectorByScalar=True)
                nodes.createVectorAdditionNode([cmds.getAttr('%s.t' % sJ)[0], sCtrlTranslate], sTarget='%s.t' % sJ, sName='squashAddToJoint')

                sCtrlRotate = nodes.createVectorMultiplyNode('%s.r' % cCtrl.sCtrl, (aOutStretchStrength[j] * fSliderScale * (0.5 / iBotTopJointCounts[p])), bVectorByScalar=True)
                nodes.createVectorAdditionNode([cmds.getAttr('%s.r' % sJ)[0], sCtrlRotate], sTarget='%s.r' % sJ, sName='squashAddToJoint')

                if j < len(ssSquashJoints[p]):
                    sNextJ = ssJoints[p][j+1]
                    sSquashJ = ssSquashJoints[p][j]
                    sDistance = nodes.createDistanceNode([0,0,0], '%s.t' % sNextJ, fNormalized=1.0)
                    sDivided = nodes.createMultiplyNode(1, sDistance, sOperation='divide')
                    sAutoScaleDiff = nodes.createVectorAdditionNode([[sDivided, sDistance, sDivided], [1,1,1]], sOperation='minus')
                    sScaleAttr = nodes.createConditionNode(sDistance, '<', 1.0, sScaleAttrSquash, sScaleAttrStretch, bVector=True)
                    sAutoScaleDiff = nodes.createVectorMultiplyNode(sAutoScaleDiff, sScaleAttr)
                    sCtrlScale = nodes.createVectorMultiplyNode(sCtrlScaleDiff, aOutStretchStrength[j], bVectorByScalar=True)
                    sAutoScale = nodes.createVectorMultiplyNode(sAutoScaleDiff, aOutStretchStrengthScale[j], bVectorByScalar=True)
                    nodes.createVectorAdditionNode([[1,1,1], sCtrlScale, sAutoScale], sTarget='%s.s' % sSquashJ, sName='squashAddToJoint')

                    if False: # aim setup (causing more issues than benefits)
                        fSquashBeforeAim = cmds.getAttr('%s.worldMatrix' % sSquashJ)
                        sAimConstraint = constraints.aimConstraintEmpty(sSquashJ, aim=[0,-fPartMultipl,0], up=[1,0,0])
                        cmds.connectAttr('%s.t' % sNextJ, '%s.target[0].targetTranslate' % sAimConstraint)
                        cmds.setAttr('%s.worldUpVector' % sAimConstraint, 1,0,0)
                        constraints.computeAimOffset(sAimConstraint, fSquashBeforeAim)



    [cC.setDefaultAttrDict() for cC in cCtrls]

    cmds.setAttr('faceSquashStretchPivot_ctrl.t', *fPivotDefaultTranslation)
    createOrFixFaceZero()
    cmds.setAttr('_grp_m_faceBendBps.v', False)



@builderTools.addToBuild(iOrder=131, dButtons={}, bDisableByDefault=True)
def unrealSliderCtrls(sSkipCtrls=[]):
    dExtraCtrlReplacements = utilsUnreal.generateSliderCtrlsCode(sSkipCtrls=sSkipCtrls)
    utils.data.store('dExtraCtrlReplacements', dExtraCtrlReplacements)


@builderTools.addToBuild(iOrder=131.05, dButtons={}, bDisableByDefault=True)
def unrealPostCtrls():
    sUnrealCommands = ['\n\n#Creating Post Ctrls\n']

    # sCtrls = ['eyelidMidBot_l_ctrl']
    sCtrls = utils.data.get('sAllPostCtrlsForUnreal')
    sCreatedCtrls = []
    for sCtrl in sCtrls:
        cCtrl = ctrls6.ctrlFromName(sCtrl)
        fColor = cmds.getAttr('%s.overrideColorRGB' % cCtrl.sShape)[0]
        fSliderScale = cmds.getAttr('%s.sx' % cCtrl.sSlider)
        sUnrealCommands.append(utilsUnreal.createUnrealCtrl(cCtrl, sShapeName='Box_Solid', fSize=0.018 / fSliderScale, fOverwriteColor=fColor)[1])
        sCreatedCtrls.append(sCtrl)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utils.data.addToList(utilsUnreal.kCreatedUnrealSliderCtrls, sCreatedCtrls)
    utils.data.addToList(utilsUnreal.kCreatedUnrealCtrls, sCreatedCtrls)
    utilsUnreal.dumpUnrealCodeLinesToFile()



@builderTools.addToBuild(iOrder=131.2, dButtons={}, bDisableByDefault=True)
def unrealTransformSliderCtrls(dSimpleConstraints={'jnt_m_headMain':[]}, iMaxFactors=2, bOnlySimple=True):

    sUnrealCommands = ['\n\n#Transform SliderCtrl Passers\n']
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox()")

    sAllSliderCtrls = utils.data.get(utilsUnreal.kCreatedUnrealSliderCtrls)
    sAlreadyConstrained = []
    for sJoint, sCtrls in dSimpleConstraints.items():
        sUnrealCommands.append("ePassers = nodes.createHierarchyTransformArrayNode([%s])" % ', '.join(["%s.ePasser" % sCtrl for sCtrl in sCtrls if cmds.objExists(sCtrl)]))
        sUnrealCommands.append("sForEach = nodes.createForEachExecuteNode(ePassers)")
        sUnrealCommands.append("nodes.createParentConstraintExecuteNode([hierarchy.ConstraintParent(hierarchy.Element('%s', 'Bone'))], '%%s.Element' %% sForEach, bMaintainOffset=True)" % sJoint)
        sUnrealCommands.append("controllers.goToParentExecute()")
        sAlreadyConstrained.extend(sCtrls)

    if not bOnlySimple:

        ssJoints = [[] for _ in range(len(sAllSliderCtrls))]
        ffWeights = [[] for _ in range(len(sAllSliderCtrls))]

        # first gather joint attachment infos and create getTransformNodes..
        sCreatedGetTransformNodes = set()
        sCreatedUnrealNodes = utils.data.get('sCreatedUnrealNodes', xDefault=[])

        dFirstValues = {}
        ddProducts = defaultdict(list)

        for c,sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            cCtrl = ctrls6.ctrlFromName(sCtrl)
            sDecomp = cmds.listConnections('%s.t' % cCtrl.sPasser, s=True, d=False)[0]
            sMatrixMult = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]

            if cmds.objectType(sMatrixMult) == 'wtAddMatrix':
                sLoc = cmds.listConnections('%s.matrixIn[1]' % sMatrixMult, s=True, d=False)[0]
                if sLoc.startswith('loc_'):
                    sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
                    sBlendEnvelope = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]
                    sBlendAllInfluencesNode = cmds.listConnections('%s.wtMatrix[0].matrixIn' % sBlendEnvelope, s=True, d=False)[0]

                    for j in range(10): # per joint
                        sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sBlendAllInfluencesNode, j), s=True, d=False)
                        if j == 0:
                            sFirstMatrixConn = sMatrixConns[0]
                        if not sMatrixConns:
                            break
                        sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                        fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sBlendAllInfluencesNode, j))
                        ssJoints[c].append(sJoint)
                        ffWeights[c].append(fWeight)
                    bCheckBlendShapes = True
                else:
                    ffWeights[c] = [1.0]
                    ssJoints[c] = [sLoc]
                    bCheckBlendShapes = False
            else:
                ffWeights[c] = [1.0]
                ssJoints[c] = ['jnt_m_headMain']
                bCheckBlendShapes = False

            print ('bCheckBlendShapes: ', bCheckBlendShapes)
            if bCheckBlendShapes:
                sPointToMatrix = cmds.listConnections('%s.matrixIn[0]' % sFirstMatrixConn, s=True, d=False)[0]
                sBlendBlendShape = cmds.listConnections('%s.inputTranslate' % sPointToMatrix, s=True, d=False)[0]

                sAdditionNode = cmds.listConnections('%s.color1' % sBlendBlendShape, s=True, d=False)[0]
                fFirstValue = cmds.getAttr('%s.input3D[0]' % sAdditionNode)[0]
                dFirstValues[sCtrl] = utilsUnreal.flipVectorToUnreal(fFirstValue)

                for b in range(1, 100000, 1):
                    sMults = cmds.listConnections('%s.input3D[%d]' % (sAdditionNode, b), s=True, d=False)
                    if not sMults:
                        break
                    sRangeNode = cmds.listConnections('%s.input2X' % sMults[0], s=True, d=False)[0]
                    if sRangeNode in sCreatedUnrealNodes:
                        fValues = cmds.getAttr('%s.input1' % sMults[0])[0]
                        ddProducts[sCtrl].append(('%s_output' % sRangeNode, utilsUnreal.flipVectorToUnreal(fValues)))


        # create the blendShape nodes
        for c,sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            if sCtrl in ddProducts:
                sProducts = ddProducts[sCtrl]
            else:
                continue
            print ('sCtrl: ', sCtrl)
            print ('ddProducts[sCtrl]: ', ddProducts[sCtrl])
            fFirstValue = dFirstValues[sCtrl]
            sUnrealCommands.append("# blendShape connections")
            sUnrealCommands.append("\ncontrollers.setNewColumn()")
            i = -1
            sProductVars = []
            print ('sProducts: ', sProducts)
            sProducts = sorted(sProducts, key=lambda a:np.linalg.norm(a[1]), reverse=True)

            for sOutput, fValues in sProducts[:min(iMaxFactors, len(sProducts))]:
                i += 1
                if np.linalg.norm(fValues) < 0.001:
                    break
                sProductVars.append('sProduct_%d' % i)
                sUnrealCommands.append("%s = nodes.createBasicCalculateNode([[%0.3f, %0.3f, %0.3f], [%s,%s,%s]], sOperation='Multiply', iPinType=pins.PinType.vector)" %
                                       (sProductVars[-1], fValues[0], fValues[1], fValues[2], sOutput, sOutput, sOutput))

            sUnrealCommands.append("%s_blendShapeSum = nodes.createBasicCalculateNode([[%0.3f, %0.3f, %0.3f]] + [%s], bVector=True, sOperation='Add')" %
                                   (sCtrl, fFirstValue[0], fFirstValue[1], fFirstValue[2], ', '.join(sProductVars)))

        # create the get bone nodes
        sUnrealCommands.append("\n# create get bone nodes")
        sUnrealCommands.append("\ncontrollers.setNewColumn()")
        for c,sCtrl in enumerate(sAllSliderCtrls):
            for sJoint in ssJoints[c]:
                if '%s_initial' % sJoint not in sCreatedGetTransformNodes:
                    sUnrealCommands.append("%s_initial = nodes.getTransformNode(hierarchy.Element('%s', 'Bone'), bInitial=True)" % (sJoint, sJoint))
                    sUnrealCommands.append("%s_current = nodes.getTransformNode(hierarchy.Element('%s', 'Bone'))" % (sJoint, sJoint))
                    sCreatedGetTransformNodes.add('%s_initial' % sJoint)

        # now go through and connect the control passers to the previously created getTransformNodes
        sUnrealCommands.append("# connect them all to the bone nodes")
        for c, sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            sUnrealCommands.append("\ncontrollers.setNewColumn()")
            sUnrealCommands.append("%s_initial = nodes.getTransformNode(%s.ePasser, bInitial=True)" % (sCtrl, sCtrl))
            sBlendShapedCtrl = '%s_initial' % sCtrl
            if sCtrl in ddProducts:
                sBlendShapedCtrl = "[%s_blendShapeSum, '%%s.Rotation' %% %s, '%%s.Scale3D' %% %s]"  % (sCtrl, sBlendShapedCtrl, sBlendShapedCtrl)

            for j,sJoint in enumerate(ssJoints[c]):
                sUnrealCommands.append("relativeToJoint = nodes.createMakeRelativeNode(%s, %s_initial)" % (sBlendShapedCtrl, sJoint))
                sUnrealCommands.append("%s_pointMoved = nodes.createMakeAbsoluteNode(relativeToJoint, %s_current)" % (sJoint, sJoint))

            sOutTransform = '%s_pointMoved' % ssJoints[c][0]
            if len(ssJoints[c]) > 1:
                fPrevWeightSum = ffWeights[c][0]
                for jj in range(1, len(ssJoints[c]), 1):
                    fWeight = ffWeights[c][jj] / (ffWeights[c][jj] + fPrevWeightSum)
                    fPrevWeightSum += ffWeights[c][jj]
                    sInterpName = '%s_interp_%d' % (sCtrl, jj)
                    sUnrealCommands.append("%s = nodes.createTransformInterpolateNode(%0.3f, %s, %s_pointMoved)" % (sInterpName, fWeight, sOutTransform, ssJoints[c][jj]))
                    sOutTransform = sInterpName

        sUnrealCommands.append("nodes.createSetTransformExecuteNode(%s.ePasser, %s)" % (sCtrl, sOutTransform))

    sUnrealCommands.append("controllers.closeCommentBox('Transform SliderCtrl Passers')")


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


def _replaceTargetsWithOthers(sTargetAttrs, sOtherGrp):
    sTargetShortAttrs = [sAttr.split('.')[-1] for sAttr in sTargetAttrs]

    sFoundTargets = []
    sSearchMeshes = utils.listMeshes(sOtherGrp)
    for sMesh in sSearchMeshes:
        sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]
            for sTarget in deformers.getBlendShapeTargets(sBlendShape):
                if sTarget in sTargetShortAttrs:
                    sFoundTargets.append('%s.%s' % (sBlendShape, sTarget))

    sTargetAttrs = sorted(sFoundTargets, key=lambda a: a.split('.')[-1].count('_'))
    return sTargetAttrs



# depricated
# @builderTools.addToBuild(iOrder=131.12, dButtons={}, bDisableByDefault=True)
def unrealConnectBlendShapesBackwardsOld(sLookForTargetsUnder=None):
    ''' not fully working. Shuldn't really be used'''

    dDriverReplacements = {'grp_l_eyesLookAtPasser.lookVert':('eyesLookAt_l_ctrl.translateZ', 2),
                           'grp_r_eyesLookAtPasser.lookVert':('eyesLookAt_r_ctrl.translateZ', 2),
                           'grp_l_eyesLookAtPasser.lookHoriz':('eyesLookAt_l_ctrl.translateZ', 2),
                           'grp_r_eyesLookAtPasser.lookHoriz':('eyesLookAt_r_ctrl.translateZ', 2)}


    sTargetAttrs = utils.data.get(utilsUnreal.kBlendShapeTargetList)


    if sLookForTargetsUnder:
        sTargetAttrs = _replaceTargetsWithOthers(sTargetAttrs, sLookForTargetsUnder)

    sUnrealBackwardsCommands = []
    sUnrealBackwardsCommands.append('\n\n# BlendShape Target Weights (Curve) BACKWARDS Connections\n\n')

    sUnrealBackwardsCommands.append("nodes.newSequencerPlug()")
    sUnrealBackwardsCommands.append("controllers.openCommentBox()")
    sCompletedCurves = set()
    for sAttribute in sTargetAttrs:
        if sAttribute == None:
            continue
        sCurveAttr = sAttribute.split('.')[-1]

        if sCurveAttr in sCompletedCurves:
            continue
        else:
            sCompletedCurves.add(sCurveAttr)

        sConns = cmds.listConnections(sAttribute, s=True, d=False, p=True, skipConversionNodes=True) or []

        if not sConns:
            continue

        sCollectionNode = sConns[0].split('.')[0]
        if cmds.objectType(sCollectionNode) == 'condition':
            sRangeOutputs = eval(cmds.getAttr('%s.sFactors' % sCollectionNode))
        else:
            sRangeOutputs = [sConns[0]]

        sUnrealBackwardsCommands.append('\n\n# BlendShape Weight sAttribute (backwards): %s' % sAttribute)

        xDrivenCtrls = []
        for sRangeOutput in sRangeOutputs:
            sRangeNode, sAttr = sRangeOutput.split('.')
            sDriver = cmds.listConnections('%s.valueX' % sRangeNode, s=True, d=False, p=True, skipConversionNodes=True)[0]
            sDriverNode, sCtrlDriverAttr = sDriver.split('.')

            if sDriver in dDriverReplacements:
                xDrivenCtrls.append(dDriverReplacements[sDriver])

            elif sDriverNode.endswith('_ctrl'):
                fValue = getPoseFromRangeNode(sRangeNode)
                if sCtrlDriverAttr == 'upCurveBlink':
                    if fValue == 1.0:
                        xDrivenCtrls = []
                        break
                    elif fValue == 0.0:
                        continue
                    else:
                        raise Exception('Not sure what to do when upCurveBlink is %0.3f' % (fValue))
                xDrivenCtrls.append((sDriver, fValue))


        if len(xDrivenCtrls) == 1:
            sUnrealBackwardsCommands.append("%s = nodes.createGetCurveValue('%s')" % (sCurveAttr, sCurveAttr))
            sUnrealBackwardsCommands.append("%s_range = nodes.createRemapNode(%s, 0,1,0,%0.3f)" % (sCurveAttr, sCurveAttr, xDrivenCtrls[0][1]))
            sCtrl, sAttr = xDrivenCtrls[0][0].split('.')
            sUnrealBackwardsCommands.append("nodes.createSetChannelNode(hierarchy.Element('%s', 'Control'), '%s', %s_range)" % (sCtrl, sAttr, sCurveAttr))


    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)



def getPoseFromRangeNode(sRangeNode, bJustSign=False):
    sBeforeOverShootAttr = '%s.fBeforeOverShoot' % sRangeNode
    if cmds.objExists(sBeforeOverShootAttr):
        fBeforeOverShoot = eval(cmds.getAttr(sBeforeOverShootAttr))
        fPose = fBeforeOverShoot[1] if fBeforeOverShoot[0] == 0 else fBeforeOverShoot[0]
    else:
        fOldMinX, fOldMinMax = cmds.getAttr('%s.oldMinX' % sRangeNode), cmds.getAttr('%s.oldMaxX' % sRangeNode)
        fPose = fOldMinMax if fOldMinX == 0 else fOldMinX

    if bJustSign:
        return 1 if fPose > 0 else -1
    else:
        return fPose



@builderTools.addToBuild(iOrder=131.15, dButtons={}, bDisableByDefault=True)
def unrealConnectBlendShapes(sLookForTargetsUnder=None):

    dDriverReplacements = {'grp_l_eyesLookAtPasser.lookVert':'sLookVert_l_eye',
                           'grp_r_eyesLookAtPasser.lookVert':'sLookVert_r_eye',
                           'grp_l_eyesLookAtPasser.lookHoriz':'sLookHoriz_l_eye',
                           'grp_r_eyesLookAtPasser.lookHoriz':'sLookHoriz_r_eye'}
    dExtraCtrlReplacements = utils.data.get('dExtraCtrlReplacements', xDefault={})

    dDriverReplacements.update(dExtraCtrlReplacements)

    # for i in range(100):
    #     dDriverReplacements['zipperOut_%03d' % i] = 'sZipperResults[%d]' % i

    bZipper = False

    sCreatedUnrealCtrls = utils.data.get(utilsUnreal.kCreatedUnrealCtrls)
    sTargetAttrs = utils.data.get(utilsUnreal.kBlendShapeTargetList)


    if sLookForTargetsUnder:
        sTargetAttrs = _replaceTargetsWithOthers(sTargetAttrs, sLookForTargetsUnder)


    sUnrealCommands = []
    sUnrealCommands.append('\n\n# BlendShape Target Weights (Curve) Connections\n\n')
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("sLookVert_l_eye = nodes.createGetVariableNode(hierarchy.Variable('lookVert_l_eye'))")
    sUnrealCommands.append("sLookHoriz_l_eye = nodes.createGetVariableNode(hierarchy.Variable('lookHoriz_l_eye'))")
    sUnrealCommands.append("sLookVert_r_eye = nodes.createGetVariableNode(hierarchy.Variable('lookVert_r_eye'))")
    sUnrealCommands.append("sLookHoriz_r_eye = nodes.createGetVariableNode(hierarchy.Variable('lookHoriz_r_eye'))")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox()")
    sCreatedUnrealNodes = set()
    sCompletedCurves = set()
    for sAttribute in sTargetAttrs:

        print ('%s...' % sAttribute)
        if sAttribute == None:
            continue
        sCurveAttr = sAttribute.split('.')[-1]

        if sCurveAttr in sCompletedCurves:
            continue
        else:
            sCompletedCurves.add(sCurveAttr)

        # sUnrealCommands.append("controllers.setNewColumn()")
        xxDrivers = []

        sConns = cmds.listConnections(sAttribute, s=True, d=False, p=True, skipConversionNodes=True) or []
        sNode = sConns[0].split('.')[0]

        if cmds.objectType(sNode) == 'condition':
            sRangeOutputs = eval(cmds.getAttr('%s.sFactors' % sNode))
        else:
            sRangeOutputs = [sConns[0]]

        bAllRangesAreThere = True
        sUnrealCommands.append('\n\n# BlendShape Weight sAttribute: %s' % sAttribute)
        for sRangeOutput in sRangeOutputs:
            sRangeNode, sAttr = sRangeOutput.split('.')
            if sRangeNode.startswith('zipperOut_'):
                sName, iNumber = utils.getNumberAtEnd(sRangeNode)
                xxDrivers.append(['sZipperResults[%d]' % iNumber, (0,1,0,1)])
                bZipper = True
            else:
                sDriver = cmds.listConnections('%s.valueX' % sRangeNode, s=True, d=False, p=True, skipConversionNodes=True)[0]
                sDriverNode, sDriverAttr = sDriver.split('.')

                # sDriverUnrealCommands = [] # stupid.. we can replace that
                if sDriver in dDriverReplacements:
                    xxDrivers.append([dDriverReplacements[sDriver], nodes.getRangeFromRangeNode(sRangeNode)])
                elif sDriverNode.endswith('_ctrl'):
                    if sDriverNode not in sCreatedUnrealCtrls:
                        continue
                    if sDriverAttr.startswith('translate'):
                        sGetNodeVariableName = '%s_getTranslation' % sDriverNode
                        if sGetNodeVariableName not in sCreatedUnrealNodes:
                            sUnrealCommands.append(
                                "%s = nodes.getTransformNode(%s.eControl, bLocal=True)" % (sGetNodeVariableName, sDriverNode))
                            sCreatedUnrealNodes.add(sGetNodeVariableName)
                        if sDriverAttr == 'translateX':
                            sAxis = 'Translation.X'
                        elif sDriverAttr == 'translateY':
                            sAxis = 'Translation.Z'
                        elif sDriverAttr == 'translateZ':
                            sAxis = 'Translation.Y'
                        else:
                            raise Exception('not sure what attr "%s" is' % sDriverAttr)
                        xxDrivers.append(["'%%s.%s' %% %s" % (sAxis, sGetNodeVariableName), nodes.getRangeFromRangeNode(sRangeNode)]) # ['%s.Translation.Z' % lipsCorner_l_ctrl_getTranslation

                        # sUnrealDriverOutAttribute = "'%%s.Translation.%s' %% %s_getTranslation" % (sAxis, sDriverNode)
                    elif sDriverAttr.startswith('rotate'):
                        sGetNodeVariableName = '%s_getRotation' % sDriverNode
                        if sGetNodeVariableName not in sCreatedUnrealNodes:
                            sUnrealCommands.append(
                                "%s = nodes.getControlRotator(%s.eControl, bLocal=True)" % (sGetNodeVariableName, sDriverNode))
                            sCreatedUnrealNodes.add(sGetNodeVariableName)
                        if sDriverAttr == 'rotateX':
                            sAxis = 'Roll'
                        elif sDriverAttr == 'rotateY':
                            sAxis = 'Yaw'
                        elif sDriverAttr == 'rotateZ':
                            sAxis = 'Pitch'
                        else:
                            raise Exception('not sure what attr "%s" is' % sDriverAttr)
                        xxDrivers.append(["'%%s.%s' %% %s" % (sAxis, sGetNodeVariableName), nodes.getRangeFromRangeNode(sRangeNode)])

                    else:
                        report.report.addLogText('not sure what type of attribute "%s" is' % sDriverAttr)
                        bAllRangesAreThere = False
                        break

        if bAllRangesAreThere and len(xxDrivers):
            sUnrealCommands.append("controllers.setNewColumn()")
            sDriverStrings = ["[%s, %s]" % (xD[0], str(xD[1])) for xD in xxDrivers]
            sUnrealCommands.append("functions.curveDriver('%s', [%s])" % (sCurveAttr, ', '.join(sDriverStrings)))
    sUnrealCommands.append("controllers.closeCommentBox('BlendShape Connections')")

    if bZipper:
        dZipper = utils.data.get('dZipper')
        sZipperUnrealCommands = ['\n\n#Zipper\n']
        sZipperUnrealCommands.append("sZipperResults = functions.zipper(%d, [lipsCorner_l_ctrl.eControl, lipsCorner_r_ctrl.eControl])" % (dZipper['iSampleCount']))
        sUnrealCommands = sZipperUnrealCommands + sUnrealCommands

    report.report.addLogText('\n'.join(sUnrealCommands), bPrint=True)
    utils.data.addToList('sCreatedUnrealNodes', sCreatedUnrealNodes)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()
    utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)



@builderTools.addToBuild(iOrder=131.11, dButtons={}, bDisableByDefault=True)
def unrealConnectControlsToAppleCurves(fLookUpDownInOutTranslate=[15,-15,-15,15]):
    sUnrealMocapBackwardsCodeLines = []
    sUnrealMocapBackwardsCodeLines.append('\n\n# BlendShape Target Weights (Curve) Connections (Apple) \n\n')

    fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation')
    fJawOpenTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation')

    dDict = {}
    dDict['blink_l_ctrl.translateZ'] = [(-1,'eyeBlinkLeft'), (0.5,'eyeWideLeft')]
    dDict['blink_r_ctrl.translateZ'] = [(-1,'eyeBlinkRight'), (0.5,'eyeWideRight')]
    dDict['innerEyebrow_l_ctrl.translateZ'] = [(-1,'browDownLeft'), (1,'browInnerUp')]
    dDict['innerEyebrow_r_ctrl.translateZ'] = [(-1,'browDownRight'), (1,'browInnerUp')]
    dDict['outerEyebrow_l_ctrl.translateZ'] = [(1,'browOuterUpLeft')]
    dDict['outerEyebrow_r_ctrl.translateZ'] = [(1,'browOuterUpRight')]
    dDict['cheekRaiser_l_ctrl.translateZ'] = [(1,'cheekSquintLeft')]
    dDict['cheekRaiser_r_ctrl.translateZ'] = [(1,'cheekSquintRight')]
    dDict['puff_l_ctrl.translateZ'] = [(1,'cheekPuff')]
    dDict['puff_r_ctrl.translateZ'] = [(1,'cheekPuff')]
    dDict['jaw_ctrl.rotateY'] = [(-fJawOpenRotation[2], 'jawOpen')]
    dDict['jaw_ctrl.translateY'] = [(-3.0, 'jawLeft')]
    dDict['jaw_ctrl.translateY'] = [(3.0, 'jawRight')]
    dDict['jaw_ctrl.translateX'] = [(3.0, 'jawForward')]
    dDict['mouth_ctrl.translateY'] = [(1.0, 'mouthFunnel')]

    dDict['mouthBot_ctrl.translateY'] = [(-1.0, 'mouthRollLower'), (1.0, 'mouthShrugLower')]
    dDict['mouthTop_ctrl.translateY'] = [(-1.0, 'mouthRollUpper'), (1.0, 'mouthShrugUpper')]

    dDict['lipsBot_l_ctrl.translateZ'] = [(1.0, 'mouthLowerDownLeft')]
    dDict['lipsBot0_r_ctrl.translateZ'] = [(1.0, 'mouthLowerDownRight')]
    dDict['lipsTop_l_ctrl.translateZ'] = [(1.0, 'mouthUpperUpLeft')]
    dDict['lipsTop0_r_ctrl.translateZ'] = [(1.0, 'mouthUpperUpRight')]

    dDict['noseWrinkler_l_ctrl.translateZ'] = [(1.0, 'noseSneerLeft')]
    dDict['noseWrinkler_r_ctrl.translateZ'] = [(1.0, 'noseSneerRight')]
    dDict['lipsCorner_l_ctrl.translateX'] = [(1.0, 'mouthDimpleLeft')]
    dDict['lipsCorner_r_ctrl.translateX'] = [(1.0, 'mouthDimpleRight')]
    dDict['lipsCorner_l_ctrl.translateZ'] = [(1.0, 'mouthSmileLeft'), (-1.0, 'mouthFrownLeft')]
    dDict['lipsCorner_r_ctrl.translateZ'] = [(1.0, 'mouthSmileRight'), (-1.0, 'mouthFrownRight')]
    dDict['lipSretch_l_ctrl.translateZ'] = [(1.0, 'mouthStretchLeft')]
    dDict['lipSretch_r_ctrl.translateZ'] = [(1.0, 'mouthStretchRight')]

    fUp, fDown, fIn, fOut = fLookUpDownInOutTranslate
    dDict['eyesLookAt_l_ctrl.translateZ'] = [(fUp, 'eyeLookUpLeft'), (fDown, 'eyeLookDownLeft')]
    dDict['eyesLookAt_l_ctrl.translateX'] = [(fIn, 'eyeLookInLeft'), (fOut, 'eyeLookOutLeft')]
    dDict['eyesLookAt_r_ctrl.translateZ'] = [(fUp, 'eyeLookUpRight'), (fDown, 'eyeLookDownRight')]
    dDict['eyesLookAt_r_ctrl.translateX'] = [(fIn, 'eyeLookInRight'), (fOut, 'eyeLookOutRight')]


    dDictExisting = {sControlValue:xPoses for sControlValue,xPoses in dDict.items() if cmds.objExists(sControlValue)}
    sUnrealMocapBackwardsCodeLines.append("functions.moveCtrlsByAppleCurves(%s)" % str(dDictExisting))


    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealMocapBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)

    utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealMocapBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)


    # drive apple curves in Maya
    sCurveNames = []
    for _, xPoses in dDictExisting.items():
        sCurveNames.extend([y for x,y in xPoses])
    sTargets = unreal.addEmptyUnrealTargets(sCurveNames)
    print ('sTargets: ', sTargets)
    dTargets = {sTarget.split('.')[-1]:sTarget for sTarget in sTargets}

    sConnected = set()
    for sUnrealCtrlAttr, xPoses in dDictExisting.items():
        if sUnrealCtrlAttr.endswith('Y'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Y', 'Z')
        elif sUnrealCtrlAttr.endswith('Z'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Z', 'Y')
        elif sUnrealCtrlAttr.endswith('X'):
            sMayaCtrlAttr = sUnrealCtrlAttr
        else:
            raise Exception('attribute %s not supported' % sUnrealCtrlAttr)
        
        for fPose, sCurve in xPoses:
            if sCurve not in sConnected:
                nodes.createRangeNode(sMayaCtrlAttr, 0, fPose, 0, 1, sTarget=dTargets[sCurve], sName='appleCurve_%s' % sMayaCtrlAttr)
                sConnected.add(sCurve)



def createPostRefAttrFromCurrentWorld(sJoints):
    for sJoint in utils.toList(sJoints):
        utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, str(utils.invertFlatMatrix(cmds.xform(sJoint, q=True, m=True, ws=True))))





