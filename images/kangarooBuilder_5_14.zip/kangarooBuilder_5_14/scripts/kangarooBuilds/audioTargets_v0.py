###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from collections import OrderedDict, defaultdict
import numpy as np
import kangarooTools.patch as patch

import kangarooTabTools.builder as builderTools
import os
import maya.cmds as cmds
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.nodes as nodes
import kangarooTools.xforms as xforms
import kangarooTools.curves as curves
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.geometry as geometry
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.assets as assets
import kangarooTools.report as report
import maya.api.OpenMaya as OpenMaya2



# import kangarooTabTools.poser as poser

iColorIndexCtrls = 0
bPolyCtrls = False
kBuilderColor = utils.uiColors.yellow  # '#39a9f4'

kFaceDataNode = '__faceData__'



def exportBps(sFileName, sGroup):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    print('exporting "%s" to "%s" ' % (sGroup, sFile))
    report.report.addLogText('exporting "%s" to "%s" ' % (sGroup, sFile))
    utils.createFolderIfNotExists(sFile)

    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #



def createMatrixCtrlromSelectedPoints(sName, sParent, sSkinningSphere=None, fRotate=(0,0,0), bLockToMiddle=False):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()


    fnMesh = OpenMaya2.MFnMesh(pSel.mDagPath)
    _, mNormal, _ = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(list(aMean)), space=OpenMaya2.MSpace.kWorld)

    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    xforms.orientThreePoints(sLoc, (mNormal.x, mNormal.y, mNormal.z), (0, 0, -1), fAimVector=(0, 0, 1),
                             fUpVector=(1, 0, 0))

    if bLockToMiddle:
        for sL in ['%s.%s' % (sLoc, sAttr) for sAttr in ['tx', 'ry', 'rz']]:
            cmds.setAttr(sL, 0.0)
            cmds.setAttr(sL, lock=True)


    cmds.rotate(fRotate[0], fRotate[1], fRotate[2], sLoc, r=True, os=True)
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))
    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        cmds.parent(sSkinningSphere, sParent)




def updateAudioDict(fJawMaxOpen, fBotTeethT, fTopTeethT, fTongueBaseT, fFffClosed, fFffQuaterJaw, fCornerRange):
    xDict = locals()
    print('xDict: ', xDict)

    sDicts = []
    for sK,fV in list(xDict.items()):
        sV = ['%0.3f' % fV for fV in utils.toList(fV)]
        sDicts.append('%s?%s' % (sK, '?'.join(sV)))

    cAudio = ctrls.ctrlFromName('ctrl_m_audio')
    sDictString = '/'.join(sDicts)
    sDictAttr = utils.addStringAttr(cAudio.sPasser, '__dict__', utils.encodeAudioLipsString(sDictString))
    cmds.setAttr(sDictAttr, lock=True)


def printEncodedDict(_report=None):
    xDict = utils.createDictFromDecodedAudioLipsString(cmds.getAttr('grp_m_audioPasser.__dict__'))
    if _report:
        _report.addLogText(str(xDict))
    print(xDict)



def updateFffValuesClosed(_uiArgs=None, _report=None):
    sCtrl = 'botLip_ctrl'
    fValues = [cmds.getAttr('%s.%s' % (sCtrl,sA)) for sA in ['ty','tz','rx']]
    _uiArgs['fFffClosed'].setText(str(fValues))

def goToFffClosedValues(fFffClosed):
    print('go to fff closed values', fFffClosed)
    sCtrl = 'botLip_ctrl'
    [cmds.setAttr('%s.%s' % (sCtrl,sA),fV) for sA,fV in zip(['ty','tz','rx'], fFffClosed)]
    cmds.setAttr('audio_ctrl.jawOpen', 0.0)

updateFffValuesClosed.dSideButtons = {'pose to':goToFffClosedValues}


def updateFffValuesOpen(fJawMaxOpen, _uiArgs=None, _report=None):
    cmds.setAttr('audio_ctrl.jawOpen', fJawMaxOpen * 0.25)
    sCtrl = 'botLip_ctrl'
    fValues = [cmds.getAttr('%s.%s' % (sCtrl,sA)) for sA in ['ty','tz','rx']]
    _uiArgs['fFffQuaterJaw'].setText(str(fValues))


def goToFffOpenValues(fJawMaxOpen, fFffQuaterJaw):
    print('go to fff closed values', fFffQuaterJaw)
    cmds.setAttr('audio_ctrl.jawOpen', fJawMaxOpen*0.25)
    sCtrl = 'botLip_ctrl'
    [cmds.setAttr('%s.%s' % (sCtrl,sA),fV) for sA,fV in zip(['ty','tz','rx'], fFffQuaterJaw)]
updateFffValuesOpen.dSideButtons = {'pose to':goToFffOpenValues}


def setMouthCtrlsToDefault():
    cmds.setAttr('audio_ctrl.jawOpen', 0.0)
    sCtrl = 'botLip_ctrl'
    [cmds.setAttr('%s.%s' % (sCtrl,sA), 0) for sA in ['ty','tz','rx']]

kBpGroupName = '_grp_m_audioBps'
kBpFileName = 'audioBps.ma'

def SelectAudioFffJoint():
    cmds.select(['jnt_m_audioFff'])


dButtons = OrderedDict()
dButtons['update dict'] = updateAudioDict
dButtons['print dict'] = printEncodedDict
dButtons['Fill F values on jaw.rx=0 from Scene'] = updateFffValuesClosed
dButtons['Fill F values on jaw.rx=fJawMaxOpen*0.25 from Scene'] = updateFffValuesOpen
dButtons['go to default'] = setMouthCtrlsToDefault
dButtons['Create Audio Fff Bp'] = lambda: createMatrixCtrlromSelectedPoints('bp_m_audioFff', kBpGroupName, bLockToMiddle=True)
dButtons['Select Audio Fff for Skin'] = SelectAudioFffJoint
dButtons['Export BPs'] = lambda: exportBps(kBpFileName, kBpGroupName)


def _getCombinedAttr(cC, sAttr):
    if sAttr.startswith('translate') or sAttr.startswith('rotate') or sAttr.startswith('scale'):
        sCombinedAttr = '%s.%sCombined%s' % (cC.sPasser, sAttr[:-1], sAttr[-1])
        if cmds.objExists(sCombinedAttr):
            return sCombinedAttr
    else:
        return None



def _setAsAudioCtrl(sCtrl):
    for sC in utils.toList(sCtrl):
        if isinstance(sC, ctrls.TbCtrl):
            sC = sC.sCtrl
        cmds.addAttr(sC, ln='bIsAudioCtrl', at='bool', defaultValue=True, k=False)



@builderTools.addToBuild(iOrder=63.5, dButtons=dButtons)
def createCtrls(fJawMaxOpen=12.0, fBotTeethT=[0,0,0], fTopTeethT=[0,0,0], fTongueBaseT=[0,0,0],
                     fFffClosed=[0.1,0.65, 25], fFffQuaterJaw=[0.1,0.65,25], fCornerRange=[-0.8, 0.8]):

    '''
    The dict holds the values from the bottom parameters, and it goes into the rig for the lip Sync Tool \
    to  use for creating the animation.

    Most important one to set first is fJawOpen. This is the rx value of ctrl_m_jaw when jaw is open \
    the most. Basically the limit.
    fBotCloseY, fBotCloseZ and fBotCloseRot are values for the mouthBot_ctrl to close the mouth when \
    jaw is on its max open.
    fTopCloseY, fTopCloseZ, fTopCloseRot are the same for the mouthTop_ctrl control.

    The F shape needs more attention:
    fJawFffMaxOpen is the widest the jaw can be open on F
    fFffBotY, fFffBotZ and fFffTopY are lists with 2 items. The first item is the value of the mouthBot_ctrl or mouthTop_ctrl \
    when Jaw is at 0, and the second items are the values when Jaw is at fJawFffMaxOpen.

    fBotTeethT, fTopTeethT and fTongueBaseT are simple translation values where controls will be moved to \
    when lip Sync Animation is created.
    '''


    sModel = 'body_geo'

    sMouthCtrl = 'mouth_ctrl'
    fSliderScale = utils.data.get('mouthSliderScale', sNode=kFaceDataNode)

    cAudio = ctrls.create(sName='audio', sSide='m', sParent='faceCtrls', sShape='A', fSize=fSliderScale*2.5, iColorIndex=2)
    _setAsAudioCtrl(cAudio.sCtrl)
    aPos = np.average(np.array(cmds.xform('%s.cv[*]' % sMouthCtrl, q=True, ws=True, t=True)).reshape(-1,3), axis=0)
    cmds.setAttr('%s.t' % cAudio.sPasser, aPos[0], aPos[1], aPos[2] + 2.0)
    cmds.parentConstraint(sMouthCtrl, cAudio.sPasser, mo=True)
    sCtrlVis = utils.addAttr(cAudio.sCtrl, ln='ctrlVis', at='enum', en='Off:On', defaultValue=0, k=True)

    # add character specific values
    updateAudioDict(fJawMaxOpen, fBotTeethT, fTopTeethT, fTongueBaseT, fFffClosed, fFffQuaterJaw, fCornerRange)


    sBlendAttr = utils.addAttr(cAudio.sCtrl, ln='enable', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
    sBlendRev = nodes.createReverseNode(sBlendAttr)



    # Fff Ctrl
    sFffBp = 'bp_m_audioFff'
    fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode) or cmds.getAttr('jnt_m_jawEnd.tx') * 0.2

    sParentJoint = 'jnt_m_jawMain'
    cFffCtrl = ctrls.create(sName='audioF', sSide='m', sShape='cube',
                         fRotateShape=[0, 0, 0], sParent='faceCtrls',
                         sMatch=sFffBp, iColorIndex=2, sLockHide=['tx','ry', 'rz', 's', 'v'], fSize=1.0)
    _setAsAudioCtrl(cFffCtrl)
    sFffJoint = 'jnt_m_audioFff'
    if cmds.objExists(sFffJoint):
        cmds.delete(cmds.parentConstraint(sFffBp, sFffJoint))
        cmds.parent(sFffJoint, 'jnt_m_jawMain')
        deformers.resetJointReferences(sFffJoint)
    else:
        xforms.createJoint(sFffJoint, fSize=fSliderScale * 0.1, sParent='jnt_m_jawMain', sMatch=sFffBp)


    sJawLocalMatrix = nodes.createMultMatrixNode(['jnt_m_jawMain.worldMatrix', 'jnt_m_headMain.worldInverseMatrix'])
    sFffInJawMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cFffCtrl.sPasser, 'jnt_m_jawMain.worldInverseMatrix'], bJustValues=True)

    sHeadInAudioValues = nodes.createMultMatrixNode(['jnt_m_headMain.worldMatrix', '%s.worldInverseMatrix' % cAudio.sCtrl], bJustValues=True)
    sJawInAudio = nodes.createMultMatrixNode([sFffInJawMatrix, sJawLocalMatrix, sHeadInAudioValues, '%s.worldMatrix' % cAudio.sCtrl])
    nodes.createDecomposeMatrix(sJawInAudio, sTargetPos='%s.t' % cFffCtrl.sPasser, sTargetRot='%s.r' % cFffCtrl.sPasser)

    sAnimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cFffCtrl.sCtrl, '%s.worldInverseMatrix' % cFffCtrl.sPasser])
    sPasserOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cFffCtrl.sPasser, 'jnt_m_jawMain.worldInverseMatrix'], bJustValues=True)
    sFffJointMatrix = nodes.createMultMatrixNode([sAnimMatrix, sPasserOffset])

    sBlendedJointMatrix = nodes.createBlendMatrixNode([sFffJointMatrix, sFffInJawMatrix], [sBlendAttr, sBlendRev])

    nodes.createDecomposeMatrix(sBlendedJointMatrix, sTargetPos='%s.t' % sFffJoint, sTargetRot='%s.r' % sFffJoint)
    deformers.resetJointReferences(sFffJoint)



    # corners
    sCorner = 'lipsCornerLFT_ctrl'
    fPos = cmds.xform(sCorner, q=True, ws=True, t=True)
    fPos[2] += 2.0
    _sCtrls = sliderCtrls.createSliderCtrl('audioLipsCorner', fRangeX=[-1,1], fRangeY=[0,1], sMatch=sCorner, fBpPos=fPos, sShape='cube', iColorIndex=2, sAttach='audio_ctrl')
    _setAsAudioCtrl(_sCtrls)

    sTopLip = 'lipsTopLFT_ctrl'
    fPos = cmds.xform(sTopLip, q=True, ws=True, t=True)
    fPos[2] += 2.0
    _sCtrls = sliderCtrls.createSliderCtrl('audioLipsTop', fRangeY=[0,1], fRangeZ=[0,1], sMatch=sCorner, fBpPos=fPos, sShape='sphere', iColorIndex=2, sAttach='audio_ctrl')
    _setAsAudioCtrl(_sCtrls)

    sBotLip = 'lipsBotLFT_ctrl'
    fPos = cmds.xform(sBotLip, q=True, ws=True, t=True)
    fPos[2] += 2.0
    _sCtrls = sliderCtrls.createSliderCtrl('audioLipsBot', fRangeY=[0,-1], fRangeZ=[0,1], sMatch=sCorner, fBpPos=fPos, sShape='sphere', iColorIndex=2, sAttach='audio_ctrl')
    _setAsAudioCtrl(_sCtrls)

    sPuff = 'puffLFT_ctrl'
    fPos = cmds.xform(sPuff, q=True, ws=True, t=True)
    fPos[2] += 2.0
    _sCtrls = sliderCtrls.createSliderCtrl('audioPuff', fRangeY=[0,1], sMatch=sPuff, fBpPos=fPos, sShape='doubleArrowSquareY', iColorIndex=2, sAttach='audio_ctrl')
    _setAsAudioCtrl(_sCtrls)

    # jaw
    cJaw = ctrls.ctrlFromName('jaw_ctrl')
    xforms.insertParent(cJaw.sOut, 'jawResetOut')
    sAudioJawOpenAttr = utils.addAttr(cAudio.sCtrl, ln='jawOpen', k=True, minValue=0.0, maxValue=fJawMaxOpen)
    sAudioLipPressAttr = utils.addAttr(cAudio.sCtrl, ln='lipPress', k=True, minValue=0.0, maxValue=1.0)
    sAudioCloseAttr = utils.addAttr(cAudio.sCtrl, ln='mouthClose', k=True, minValue=0.0, maxValue=1.0)
    sOpenCloseAttr = 'jaw_ctrl.openClosePose'

    nodes.createMultiplyArrayNode([sAudioJawOpenAttr, -1.0, sBlendAttr], sTarget='%s.rz' % cJaw.sOut)
    if not cmds.objExists(sOpenCloseAttr):
        raise Exception('The attribute %s is missing, it needs to be created in the character script')
    fOpenClose = cmds.getAttr(sOpenCloseAttr)


    ddCopyPoses = OrderedDict()
    ddAudioPoses = OrderedDict()

    ddCopyPoses['ooo'] = {'lipsCornerLFT_ctrl.tx':-1.0}
    ddCopyPoses['eee'] = {'lipsCornerLFT_ctrl.tx':1.0}
    ddCopyPoses['up'] = {'lipsCornerLFT_ctrl.ty':1.0}
    ddCopyPoses['outUp'] = {'lipsCornerLFT_ctrl.tx':1.0, 'lipsCornerLFT_ctrl.ty':1.0}
    ddCopyPoses['upperUp'] = {'lipsTopLFT_ctrl.ty':1.0}
    ddCopyPoses['lowerDown'] = {'lipsBotLFT_ctrl.ty':-1.0}
    ddCopyPoses['lowerForward'] = {'mouthBot_ctrl.tz':1.0}
    ddCopyPoses['upperForward'] = {'mouthTop_ctrl.tz':1.0}
    ddCopyPoses['lowerForward'] = {'mouthBot_ctrl.tz':1.0}
    ddCopyPoses['upperForward'] = {'mouthTop_ctrl.tz':1.0}
    ddCopyPoses['lowerFunnel'] = {'mouthBot_ctrl.ty':-1.0, 'mouthBot_ctrl.tz':1.0}
    ddCopyPoses['upperFunnel'] = {'mouthTop_ctrl.ty':1.0, 'mouthTop_ctrl.tz':1.0}
    ddCopyPoses['puff'] = {'puffLFT_ctrl.ty':1.0}
    ddCopyPoses['lipPress'] = {'jaw_ctrl.lipPress':1.0}
    ddCopyPoses['audioMouthClose'] = {'jaw_ctrl.rx':fOpenClose, 'jaw_ctrl.mouthClose':1.0}

    ddAudioPoses['lowerForward'] = {'audioLipsBotLFT_ctrl.tz':1.0}
    ddAudioPoses['upperForward'] = {'audioLipsTopLFT_ctrl.tz':1.0}
    ddAudioPoses['lowerFunnel'] = {'audioLipsBotLFT_ctrl.ty':-1.0, 'audioLipsBotLFT_ctrl.tz':1.0}
    ddAudioPoses['upperFunnel'] = {'audioLipsTopLFT_ctrl.ty':1.0, 'audioLipsTopLFT_ctrl.tz':1.0}
    ddAudioPoses['lipPress'] = {sAudioLipPressAttr:1.0}
    ddAudioPoses['audioMouthClose'] = {sAudioJawOpenAttr:fOpenClose, sAudioCloseAttr:1.0}


    sInverts = ['outUp', 'lowerFunnel', 'upperFunnel', 'audioMouthClose']
    for sTarget, dPose in list(ddCopyPoses.items()):
        dMirroredPose = dict(dPose)
        for sA, fV in list(dPose.items()):
            if utils.getSide(sA) == 'l':
                sMirrorA = utils.getMirrorName(sA)
                if sMirrorA not in dPose:
                    dMirroredPose[sMirrorA] = fV
        dPose.update(dMirroredPose)
    for sTarget, dPose in list(ddAudioPoses.items()):
        dMirroredPose = dict(dPose)
        for sA, fV in list(dPose.items()):
            if utils.getSide(sA) == 'l':
                sMirrorA = utils.getMirrorName(sA)
                if sMirrorA not in dPose:
                    dMirroredPose[sMirrorA] = fV
        dPose.update(dMirroredPose)

    dDupls = {}
    for sTarget, dPose in list(ddCopyPoses.items()):
        dDefaults = {sA:cmds.getAttr(sA) for sA in list(dPose.keys())}
        for sA,fV in list(dPose.items()):
            cmds.setAttr(sA, fV)
        sDupl = cmds.duplicate(sModel, n=sTarget)[0]
        cmds.parent(sDupl, w=True)
        for sA,fV in list(dDefaults.items()):
            cmds.setAttr(sA, fV)
        cmds.setAttr('%s.v' % sDupl, False)
        dDupls[sTarget] = sDupl

    for sTarget, dPose in list(ddCopyPoses.items()):
        if sTarget in ddAudioPoses:
            dAudioPose = ddAudioPoses[sTarget]
        else:
            dAudioPose = {'audio%s' % utils.getFirstLetterUpperCase(sA):fA for sA,fA in list(dPose.items())}

        dAudioPosePass = dict(dAudioPose)
        dAudioPosePass[sBlendAttr] = 1.0
        interpolator.connectTargets(sModel, dDupls[sTarget], dPoses=dAudioPosePass, fSplitRadius=1.5,
                                    bInvert=True if sTarget in sInverts else False, dMultDrivers={sBlendAttr:1.0})

    # ease out cornerIn when lips are forward
    #
    fFunnelReduceStrength = 0.75 # 1 means full remove
    dPose = {'audioLipsBotLFT_ctrl.ty': -1.0, 'audioLipsTopLFT_ctrl.tz': 1.0, 'audioLipsBotLFT_ctrl.tz': 1.0, 'audioLipsTopLFT_ctrl.tz': 1.0}
    dPose['audioLipsCornerLFT_ctrl.tx'] = -(1.0 - fFunnelReduceStrength)
    dFullPose = dict(dPose)
    for sA,fV in list(dPose.items()):
        dFullPose[utils.getMirrorName(sA)] = fV

    dDefaults = {sA:cmds.getAttr(sA) for sA in list(dFullPose.keys())}
    for sA,fV in list(dFullPose.items()):
        cmds.setAttr(sA,fV)

    sFunnelReduce = cmds.duplicate(sModel, n='funnelReduce')[0]
    cmds.parent(sFunnelReduce, w=True)
    cmds.setAttr('%s.v' % sFunnelReduce, False)
    for sA,fV in list(dDefaults.items()):
        cmds.setAttr(sA,fV)
    dPose['audioLipsCornerLFT_ctrl.tx'] = -1.0
    interpolator.connectTargets(sModel, sFunnelReduce, dPoses=dPose, fSplitRadius=1.5, bInvert=True, dMultDrivers={sBlendAttr:1.0})


    # sCtrl vis
    for sCtrl in [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.bIsAudioCtrl' % sT)]:
        if sCtrl == 'audio_ctrl':
            continue
        cCtrl = ctrls.ctrlFromName(sCtrl)
        cmds.connectAttr(sCtrlVis, '%s.v' % cCtrl.sPasser)


    # debug attrs
    #
    sDebugAttrA = utils.addAttr('grp_m_audioPasser', ln='debugAttrA', k=True, bReturnIfExists=True)
    sDebugAttrB = utils.addAttr('grp_m_audioPasser', ln='debugAttrB', k=True, bReturnIfExists=True)
    sDebugAttrC = utils.addAttr('grp_m_audioPasser', ln='debugAttrC', k=True, bReturnIfExists=True)
    sDebugAttrD = utils.addAttr('grp_m_audioPasser', ln='debugAttrD', k=True, bReturnIfExists=True)





@builderTools.addToBuild(iOrder=63.8)
def createDisableOpen():
    sAudioCtrl = 'audio_ctrl'
    sBlendAttr = '%s.enable' % sAudioCtrl
    sDisableOpenAttr = utils.addAttr(sAudioCtrl, ln='disableJawOpen', minValue=0.0, maxValue=1.0, k=True)

    sBlendedDisableAttr = nodes.createMultiplyNode(sBlendAttr, sDisableOpenAttr)
    sOn = nodes.createReverseNode(sBlendedDisableAttr)

    sOutAttrs = ['lipsBotLFT_ctrl.ty', 'lipsTopLFT_ctrl.ty', 'lipsBotRGT_ctrl.ty', 'lipsTopRGT_ctrl.ty', 'mouthBot_ctrl.ty', 'mouthTop_ctrl.ty']
    for sAttr in sOutAttrs:
        sPlugs = cmds.listConnections(sAttr, p=True, d=True)
        for sPlug in sPlugs:
            cmds.disconnectAttr(sAttr, sPlug)
            nodes.createMultiplyNode(sAttr, sOn, sTarget=sPlug)

    xforms.createReverseChild('jaw_ctrl', sBlendAttr=sDisableOpenAttr)



kTongueBpGroupName = '_grp_m_tongueBps'

dButtons = {}
def createTongueTargetLocators():
    # sBlueprints = cmds.ls('jnt_m_tongueSpine_???', et='joint')


    sCtrls = sorted(cmds.ls('tongueSplineFk_?_ctrl'))
    if len(sCtrls) != 3:
        raise Exception('you need an fkSpline with 3 controls')

    fSliderScale = xforms.distanceBetween(sCtrls[0], sCtrls[-1]) * 1.25

    sBackUp = xforms.createLocator('bp_tongueTarget_back_up', sMatch=sCtrls[0])
    cmds.move(0, fSliderScale * 0.25, 0, sBackUp, r=True, ws=True)
    cmds.rotate(8,0,0, sBackUp, r=True, os=True)

    sFrontS = xforms.createLocator('bp_tongueTarget_front_s', sMatch=sCtrls[2])
    cmds.move(0, fSliderScale * 0.12, 0, sFrontS, r=True, ws=True)

    sFrontUp = xforms.createLocator('bp_tongueTarget_front_up', sMatch=sCtrls[2])
    cmds.move(0, fSliderScale * 0.25, 0, sFrontUp, r=True, ws=True)

    sFrontTh = xforms.createLocator('bp_tongueTarget_front_th', sMatch=sCtrls[2])
    cmds.move(0, fSliderScale * 0.2, fSliderScale * 0.25, sFrontTh, r=True, ws=True)

    sAllLocs = [sBackUp, sFrontS, sFrontUp, sFrontTh]
    fScale = fSliderScale * 0.1
    [cmds.setAttr('%s.localScale' % sL, fScale, fScale, fScale) for sL in sAllLocs]
    cmds.parent(sAllLocs, xforms.createOrReturnTopGroup(kTongueBpGroupName))



@builderTools.addToBuild(iOrder=63.6, dButtons={'create tongue target locators':createTongueTargetLocators, 'Export BPs':lambda:exportBps('tongueAudioBps.ma', kTongueBpGroupName)})
def setupTongue():
    sCtrls = sorted(cmds.ls('tongueSplineFk_?_ctrl'))
    if len(sCtrls) != 3:
        raise Exception('you need an fkSpline with 3 controls')

    sAudioCtrl = 'audio_ctrl'
    sBlend = 'audio_ctrl.enable'

    sGrp = cmds.createNode('transform', n='grp_tongueAudio', p='modules')
    # front tongue
    sFrontBps = ['bp_tongueTarget_front_up', 'bp_tongueTarget_front_s', 'bp_tongueTarget_front_th']
    sFrontLocs = []
    for i,sBp in enumerate(sFrontBps):
        sFrontLocs.append(xforms.createLocator(utils.replaceStringStart(sFrontBps[i], 'bp_', 'loc_'), sMatch=sBp, sParent=sGrp))
        cmds.parentConstraint(sBp, sFrontLocs[-1])

    sFrontNames = ['tongueFrontUp', 'tongueFrontS', 'tongueFrontTh']
    cFrontCtrl = ctrls.ctrlFromName(sCtrls[2])
    sConstraint = cmds.parentConstraint([cFrontCtrl.sPasser]+sFrontLocs, cFrontCtrl.sOffsets[0])[0]
    sAdditions = [1.0]
    for i,sLoc in enumerate(sFrontLocs):
        sAttr = utils.addAttr(sAudioCtrl, ln=sFrontNames[i], minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True)
        sMult = nodes.createMultiplyNode(sAttr, sBlend, sTarget='%s.%sW%d' % (sConstraint, sLoc, i+1))
        # cmds.connectAttr(sAttr, '%s.%sW%d' % (sConstraint, sLoc, i+1))
        sAdditions.append(sMult)
    sDefault = nodes.createAdditionNode(sAdditions, sOperation='minus')
    nodes.createClampNode(sDefault, 0, 1, sTarget='%s.%sW0' % (sConstraint, cFrontCtrl.sPasser))

    # back tongue
    cBackCtrl = ctrls.ctrlFromName(sCtrls[0])
    sBackLoc = xforms.createLocator('loc_tongueTarget_back_up', sMatch='bp_tongueTarget_back_up', sParent=sGrp)
    cmds.parentConstraint('bp_tongueTarget_back_up', sBackLoc)
    xforms.constraintBlend(cBackCtrl.sOffsets[0], cBackCtrl.sPasser, sBackLoc, sAudioCtrl, 'tongueBackUp')

    cmds.setAttr('%s.maxStretch' % sCtrls[-1], 10)



@builderTools.addToBuild(iOrder=165, dButtons=dButtons)
def safelyDeleteTongueBlueprints():
    if cmds.objExists(kTongueBpGroupName):
        sBps = cmds.listRelatives(kTongueBpGroupName, c=True) or []
        for sBp in sBps:
            sLoc = utils.replaceStringStart(sBp, 'bp_', 'loc_')
            if cmds.objExists(sLoc):
                sAttrs = ['tx','ty','tz','rx','ry','rz']
                fValues = [cmds.getAttr('%s.%s' % (sLoc,sA)) for sA in sAttrs]
                sConstraint = cmds.parentConstraint(sLoc, q=True)
                if sConstraint:
                    cmds.delete(sConstraint)
                    [cmds.setAttr('%s.%s' % (sLoc, sA), fV) for sA,fV in zip(sAttrs,fValues)]


