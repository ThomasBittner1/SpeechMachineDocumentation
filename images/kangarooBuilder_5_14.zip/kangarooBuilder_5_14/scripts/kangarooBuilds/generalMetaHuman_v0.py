###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np


import maya.cmds as cmds
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal

from collections import defaultdict

kBuilderColor = '#39a9f4'


@builderTools.addToBuild(iOrder=-1001)
def reloadLibraries():
    for module in [utils, nodes, match, puppetTools, segmentsTools, ctrls, sliderCtrls, weights, xforms, curves, patch,
                   deformers, interpolator, geometry, export, unreal]:
        print('reloading %s' % module.__name__)
        report.report.addLogText('reloading %s' % module.__name__)
        reload(module)


@builderTools.addToBuild(iOrder=-1000)
def newScene(bAscii=True):
    cmds.file(new=True, f=True)
    sFilePath = os.path.expanduser('~/newScene.%s' % 'ma' if bAscii else 'mb')
    cmds.file(rename=sFilePath)
    cmds.file(save=True, typ='mayaAscii' if bAscii else 'mayaBinary')


@builderTools.addToBuild(iOrder=-100)
def createTopGroups():
    assets.createTopGroups()
    utils.data.store('sBuildingAsset', [assets.getCurrentProject(), assets.assetManager.getCurrentAsset()])
    utils.data.store('bAllSplitAttachersTakeLocals', True)



def checkClashingNames():
    sAllNewNodes = cmds.ls(dag=True)
    sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
    if sClashingNodes:
        print('---CLASHING NODES---')
        for sN in sClashingNodes:
            print(sN)
        cmds.select(sClashingNodes)
    else:
        print('no clashing nodes')



kNamespace = 'metaHuman'
@builderTools.addToBuild(iOrder=-11, dButtons={'find clashing nodes in scene': checkClashingNames})
def importMetaHuman(sPath=''):
    sRootNodes = utils.importMayaFiles([sPath], bReference=True, sNamespace=kNamespace)
    cmds.parent(sRootNodes, 'master')
    cmds.setAttr('%s:root_drv.rx' % kNamespace, -90)


@builderTools.addToBuild(iOrder=-10, dButtons={'find clashing nodes in scene': checkClashingNames}, bDisableByDefault=True)
def importModel(bCheckClashingNames=True, sAsset='__self__', sVersion='__latest__'):
    sModelPath = assets.assetManager.getModelPath(sAsset, sVersion)
    report.report.addLogText('importing from path: %s' % sModelPath)

    if sModelPath:
        sFilesNames = utils.listFilesInFolder(sModelPath,
                                              sEndswith=['.ma', '.MA', '.mb', '.MB', '.obj', '.OBJ', '.fbx', '.FBX'])
        report.report.addLogText('found files: %s' % ', '.join(sFilesNames))
        sFiles = [os.path.join(sModelPath, sF) for sF in sFilesNames]

        sNewNodes = utils.importMayaFiles(sFiles)
        if not sNewNodes:
            report.report.addLogText('nothing got imported!')
            return
        if bCheckClashingNames:
            sAllNewNodes = sNewNodes + cmds.listRelatives(sNewNodes, ad=True, f=True)
            sAllNewNodes = cmds.ls(sAllNewNodes)
            sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
            if sClashingNodes:
                print('---CLASHING NODES---')
                report.report.addLogText('clashing nodes')
                for sN in sClashingNodes:
                    print(sN)
                    report.report.addLogText(sN)

                raise Exception('clashing nodes, check script editor')

        if cmds.objExists('model'):
            [cmds.lockNode(sN, lock=False) for sN in sNewNodes]
            cmds.parent(sNewNodes, 'model')
        for sNode in cmds.listRelatives(sNewNodes, ad=True, typ='transform', f=True) or []:
            if cmds.objectType(sNode) == 'transform':
                try:
                    cmds.setAttr('%s.overrideEnabled' % sNode, False)
                except:
                    pass
    else:
        raise Exception('problem with importing model (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=-8)
def importBlueprints():
    sBlueprintPath = assets.assetManager.getCurrentVersionPath(sSubPath='blueprints.ma')
    print('importing blueprints %s ...' % sBlueprintPath)
    report.report.addLogText('importing blueprint rig: %s' % sBlueprintPath)

    sNewNodes = utils.importMayaFiles([sBlueprintPath])


@builderTools.addToBuild(iOrder=-5)
def importMayaFiles():
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='mayaImport/')

    print('sImportPath: ', sImportPath)

    if os.path.exists(sImportPath):
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.ma', '.mb', '.obj', '.fbx', '.abc'], bAbsolute=True)
        print('sFiles: ', sFiles)
        report.report.resetProgress(len(sFiles))

        if sFiles:
            utils.importMayaFiles(sFiles)
        else:
            report.report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sImportPath)
        report.report.addLogText('\ndidn\'t find import path (%s)' % sImportPath)


@builderTools.addToBuild(iOrder=-5)
def importTargets():
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='targets/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.trg'], bAbsolute=True)
    # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
    print('sFiles: ', sFiles)
    report.report.resetProgress(len(sFiles))

    if sFiles:
        for sF in sFiles:
            report.report.addLogText('importing %s' % sF)
            export.importTargets(sF)
            report.report.incrementProgress()
    else:
        report.report.addLogText('no files found')


@builderTools.addToBuild(iOrder=0)
def buildPuppet(bReloadLimbs=False):
    sPuppetFile = assets.assetManager.getCurrentVersionPath(sSubPath='puppet.rig')
    dLimbs = puppetDataUtils.getDictListFromFile(sPuppetFile)

    if bReloadLimbs:
        puppetDataUtils.limbsFromFiles(bReload=True)

    puppetTools.buildRig(all=None, xLimbs=[sPuppetFile, dLimbs], sMaster='master',
                         _bClearBeforeBuild=False, _bReloadLimbs=bReloadLimbs, _bFromUI=False)



@builderTools.addToBuild(iOrder=50)
def loadDeformers(sIgnoreFiles=[], bWorldSpaceIfNotMatching=False, bAlwaysWorldSpace=False):
    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles) - set(sIgnoreFiles))
    sFiles.sort(key=lambda x: x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    for sFile in sFiles:
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)

        iLoadWorldspace = weights.LoadWorldspace.ignore
        if bAlwaysWorldSpace:
            iLoadWorldspace = weights.LoadWorldspace.closestPoints
        elif bWorldSpaceIfNotMatching:
            iLoadWorldspace = weights.LoadWorldspace.closestPointsIfTopologyDiffers

        sLoaded, dSkipped = weights._loadFromFile((sFile, None),
                                                  iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldspace)
        dAllSkipped.update(dSkipped)

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=101)
def loadCtrlShapes(bDoColor=True):
    sCtrlShapesDir = assets.assetManager.getCurrentVersionPath()
    sCtrlMasters = [sF.split('.')[0] for sF in os.listdir(sCtrlShapesDir) if sF.endswith('.ctrls')]
    print('sCtrlMasters: ', sCtrlMasters)
    for sMaster in sCtrlMasters:
        if sMaster == 'ctrls' and len(
                sCtrlMasters) > 1:  # we have new ctrl files, but didn't delete the one from old system yet
            continue
        if cmds.objExists(sMaster):
            sFilePath = os.path.join(sCtrlShapesDir, '%s.ctrls' % sMaster)
            report.report.addLogText('loading file: %s' % sFilePath)
            ctrls.loadCtrls(sFile=sFilePath, bDoColor=bDoColor)



@builderTools.addToBuild(iOrder=1000)
def clean(bDeleteThem=False, bDeleteDisplayLayers=False):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]
    sOutsideNodes = set(sOutsideNodes) - set([utils.getMasterName(), '__faceData__', '__export__', utils.kGeneralDataNode, 'metaHuman:rig'])
    for sN in sOutsideNodes:
        if bDeleteThem:
            if cmds.objExists(sN):
                cmds.delete(sN)
        else:
            try:
                cmds.setAttr('%s.v' % sN, False)
            except: pass

    if bDeleteDisplayLayers:
        for sL in cmds.ls(et='displayLayer'):
            try:
                cmds.delete(sL)
            except:
                pass

        for sObj in cmds.listRelatives('model', ad=True) or []:
            try:
                cmds.setAttr('%s.overrideEnabled' % sObj, False)
            except:
                raise Exception('couldn\'t reset override enabled for %s' % sObj)



@builderTools.addToBuild(iOrder=105)
def defaultCtrlAttrDicts():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            cCtrl.setDefaultAttrDict()


@builderTools.addToBuild(iOrder=130)
def ctrlProximityConnections():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            try:
                cCtrl.setDefaultAttrDict()
            except:
                cmds.warning('couldn\'t setDefaultAttr for %s' % cCtrl)

    sProximityCondition = nodes.createConditionNode('master.ctrlVis', '==', 2, 2, 0, sName='ctrlProximity')
    for sCtrl in cmds.controller(q=True, ac=True):
        sTag = cmds.controller(sCtrl, q=True)[0]
        cmds.connectAttr(sProximityCondition, '%s.visibilityMode' % sTag)


@builderTools.addToBuild(iOrder=150)
def goToDefaultPose():
    sCtrls = [sCtrl for sCtrl in cmds.controller(q=True, ac=True)]

    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)


@builderTools.addToBuild(iOrder=140, dButtons={})
def lockLocalCtrls():
    sNonCtrls = [sN for sN in cmds.ls('*_ctrl') if not ctrls.isCtrl(sN)]
    if cmds.objExists('faceRig'):
        sNonCtrls.append('faceRig')

    for sT in sNonCtrls:
        sAttrs = cmds.listAttr(sT, keyable=False, channelBox=True, scalar=True, visible=True, leaf=True) or []
        sAttrs += cmds.listAttr(sT, keyable=True, scalar=True, visible=True, leaf=True) or []
        for sA in sAttrs:
            cmds.setAttr('%s.%s' % (sT, sA), lock=True)



@builderTools.addToBuild(iOrder=1000)
def prepareAnimPicker(sCharacter='FullCharacter'):
    sAnimPicker = cmds.createNode('transform', n='AnimPickerData', p=utils.getMasterName())
    utils.addStringAttr(sAnimPicker, 'character', sCharacter)



@builderTools.addToBuild(iOrder=1010)
def prepareForPublish(bDeleteUnrealModel=True):
    '''

    '''
    # utils.data.store('bVersionFolders', True, sNode=utils.kExportNode)

    cmds.flushUndo()

    sAsset = assets.assetManager.getCurrentAsset()
    sUnrealModel = utils.data.get('sUnrealModel', None)
    if not sUnrealModel:
        bDeleteUnrealModel = False

    import kangarooTools.settings as settings
    ddMasters = {'master':{'sFilename':'RIG_%s_[v].ma' % sAsset,
                           'sExtraFiles': 'fbx/RIG_%s.fbx' % (sAsset),
                           'sDelete':['UNREALMODEL'] if bDeleteUnrealModel else []}}
    utils.data.store('ddMasters', ddMasters, sNode=utils.kExportNode)

    # dConfirms = {'Did you export FBX?':[('Yes', True),
    #                                   ('No, but I don\'t care.', True),
    #                                   ('Oops.. please cancel', False)]}
    # utils.data.store('dConfirms', dConfirms, sNode=utils.kExportNode)


dButtons = {}


@builderTools.addToBuild(iOrder=90)
def puppetCustomAttachments():
    sTransforms = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.sPuppetParentAttachment' % sT)]
    dMeshAttach = defaultdict(list)
    bSkippedSomething = False
    for sT in sTransforms:
        print('sT: ', sT)
        sParent = cmds.getAttr('%s.sPuppetParentAttachment' % sT)
        sScaleTransform = cmds.getAttr('%s.sPuppetParentAttachmentScaleTransform' % sT)

        if not cmds.objExists(sParent.split('.')[0]):
            report.report.addLogText('skipping custom attacher for Limb "%s" ("%s"), constrainer "%s" not found' % (
            cmds.getAttr('%s.sLimb' % sT), sT, sParent))
            bSkippedSomething = True
            continue


        if '.' in sParent:
            sSplits = sParent.split('.')
            if len(sSplits) == 2 and sSplits[1] == 'mesh':
                dMeshAttach['%s.%s' % (sParent.split('.')[0], sScaleTransform)].append(sT)
            else:
                report.report.addLogText('skipping custom attacher for Limb "%s" ("%s"), constrainer "%s" not found' % (cmds.getAttr('%s.sLimb' % sT), sT, sParent))
                bSkippedSomething = True
                continue
        else:
            xforms.matrixParentConstraint(sParent, sT, mo=True)


    for sMeshInfo, sTransforms in list(dMeshAttach.items()):
        sLimbs = list(set([cmds.getAttr('%s.sLimb' % sT) for sT in sTransforms]))
        try:
            sMesh, sScaleTransform = sMeshInfo.split('.')
            aPoints = xforms.getPositionArray(sTransforms)
            aIds = xforms.getClosestIdsFromPoints(sMesh, aPoints)

            sSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
            if not sSkinClusters:
                report.report.addLogText('skipping custom attacher for Limb "%s", no skinCluster found on mesh "%s"' % (utils.listToString(sLimbs), sMesh))
                bSkippedSomething = True
                continue

            sLocsParent = xforms.createIfNotExists('grp_customTransforms', sParent='modules')
            sLocs = deformers.blendShapeSkinClusterToPositions(sMesh, aIds, bDoSkinCluster=True, sParent=sLocsParent,
                                                               sSkinClusters=sSkinClusters, sScaleJoint=sScaleTransform)
            for t, sTransform in enumerate(sTransforms):
                xforms.matrixParentConstraint(sLocs[t], sTransform, mo=True)
        except Exception as e:
            report.report.addLogText('problems running custom attacher %s: %s' % (utils.listToString(sLimbs), e))

    if bSkippedSomething:
        return False





def _constraintWithRoot(sMaster, sChild, sRoot):
    xforms.matrixParentConstraint(sMaster, sChild, mo=True, bKeepJointOrient=True)
    cmds.parentConstraint(sMaster, sChild, mo=True)
    # sParent = cmds.listRelatives(sChild, p=True, c=False)[0]
    # sMultiply = nodes.createMultMatrixNode(['%s.worldMatrix' % sMaster,
    #                                         '%s.worldMatrix' % sRoot,
    #                                         '%s.worldInverseMatrix' % sParent], sName='PC_%s' % sMaster)
    #
    # nodes.createDecomposeMatrix(sMultiply, sTargetPos='%s.t' % sChild, sTargetRot='%s.r' % sChild, sTargetScale='%s.s' % sChild)



@builderTools.addToBuild(iOrder=5)
def constrainDriverRig():
    reload(xforms)
    sNamespace = 'metaHuman:'
    sPelvis = '%spelvis_drv' % sNamespace
    sRoot = '%sroot_drv' % sNamespace
    sSpineJoints = ['%sspine_%s_drv' % (sNamespace, sIndex) for sIndex in ['01', '02', '03', '04', '05']]
    sKangarooSpineJoints = ['jnt_m_spineSpine_%s' % sIndex for sIndex in ['000', '001', '002', '003', 'end']]

    sNeckJoints = ['%sneck_01_drv' % sNamespace, '%sneck_02_drv' % sNamespace, '%shead_drv' % sNamespace]
    sKangarooNeckJoints = ['jnt_m_neckSpine_%s' % sIndex for sIndex in ['000', '001']]
    sKangarooNeckJoints.append('jnt_m_headMain')

    _constraintWithRoot('jnt_m_hips', sPelvis, sRoot)

    for sJ, sKangarooJ in zip(sSpineJoints, sKangarooSpineJoints):
        _constraintWithRoot(sKangarooJ, sJ, sRoot)

    for sJ, sKangarooJ in zip(sNeckJoints, sKangarooNeckJoints):
        _constraintWithRoot(sKangarooJ, sJ, sRoot)

    for s, sSide in enumerate(['l', 'r']):
        sUpperLeg = '%sthigh_%s_drv' % (sNamespace, sSide)
        sKnee = '%scalf_%s_drv' % (sNamespace, sSide)
        sFoot = '%sfoot_%s_drv' % (sNamespace, sSide)
        sBall = '%sball_%s_drv' % (sNamespace, sSide)

        _constraintWithRoot('jnt_%s_leg_upperTwist_000' % sSide, sUpperLeg, sRoot)
        _constraintWithRoot('jnt_%s_leg_lowerTwist_000' % sSide, sKnee, sRoot)
        _constraintWithRoot('jnt_%s_legWrist' % sSide, sFoot, sRoot)
        _constraintWithRoot('jnt_%s_legFingers' % sSide, sBall, sRoot)

        sUpperArm = '%supperarm_%s_drv' % (sNamespace, sSide)
        sElbow = '%slowerarm_%s_drv' % (sNamespace, sSide)
        sClavicle = '%sclavicle_%s_drv' % (sNamespace, sSide)
        sHand = '%shand_%s_drv' % (sNamespace, sSide)

        _constraintWithRoot('jnt_%s_clavicleMain' % sSide, sClavicle, sRoot)
        _constraintWithRoot('jnt_%s_arm_upperTwist_000' % sSide, sUpperArm, sRoot)
        _constraintWithRoot('jnt_%s_arm_lowerTwist_000' % sSide, sElbow, sRoot)
        _constraintWithRoot('jnt_%s_armWrist' % sSide, sHand, sRoot)
        # _constraintWithRoot('jnt_%s_armFingers' % sSide, sBall, sRoot)


        for sFinger in ['index', 'middle', 'ring', 'pinky']:
            sMetaFingerJoints = ['%s%s_%s_%s_drv' % (sNamespace, sFinger, sPart, sSide) for sPart in ['metacarpal', '01', '02', '03']]
            sKangarooFingers = ['jnt_%s_%s%s' % (sSide, sFinger, sPart) for sPart in ['Meta', 'Base', 'Mid', 'Tip']]
            for sJ, sKangarooJ in zip(sMetaFingerJoints, sKangarooFingers):
                _constraintWithRoot(sKangarooJ, sJ, sRoot)


        sMetaThumbJoints = ['%s%s_%s_%s_drv' % (sNamespace, 'thumb', sPart, sSide) for sPart in ['01', '02', '03']]
        sKangarooThumbs = ['jnt_%s_%s%s' % (sSide, 'thumb', sPart) for sPart in ['Meta', 'Base', 'Mid', 'Tip']]
        for sJ, sKangarooJ in zip(sMetaThumbJoints, sKangarooThumbs):
            _constraintWithRoot(sKangarooJ, sJ, sRoot)



def makeArmStraight():
    sTempGrp = cmds.createNode('transform')
    cmds.setAttr('__l_arm_Features__.fk2ik', 1.0)
    sIk = 'armIkLFT_ctrl'
    fUpperLength = xforms.distanceBetween('jnt_l_arm_upperTwist_000', 'jnt_l_arm_lowerTwist_000')
    fLowerLength = xforms.distanceBetween('jnt_l_arm_lowerTwist_000', 'jnt_l_armWrist')
    fArmLength = fUpperLength + fLowerLength
    fShoulderPoint = np.array(cmds.xform('jnt_l_arm_upperTwist_000', q=True, ws=True, t=True))
    fIkPoint = fShoulderPoint + np.array([fArmLength, 0,0])
    cmds.xform(sIk, t=fIkPoint, ws=True)
    cmds.setAttr('%s.softIk' % sIk, 0.0)

    for sFinger in ['index', 'middle', 'ring', 'pinky']:
        sBaseCtrl = '%sBaseLFT_ctrl' % sFinger
        if cmds.objExists(sBaseCtrl):
            for sLimb in ['mid', 'tip']:
                sLimbCtrl = '%s%sLFT_ctrl' % (sFinger, utils.getFirstLetterUpperCase(sLimb))
                cmds.delete(cmds.orientConstraint(sBaseCtrl, sLimbCtrl))


def recordStraightPose(_uiArgs=None):
    dPose = {}
    for sFinger in ['thumb', 'index', 'middle', 'ring', 'pinky']:
        sBaseCtrl = '%sBaseLFT_ctrl' % sFinger
        if cmds.objExists(sBaseCtrl):
            for sLimb in ['base', 'mid', 'tip']:
                sLimbCtrl = '%s%sLFT_ctrl' % (sFinger, utils.getFirstLetterUpperCase(sLimb))
                if cmds.objExists(sLimbCtrl):
                    fRot = cmds.getAttr('%s.r' % sLimbCtrl)[0]
                    dPose['%s.r' % sLimbCtrl] = fRot

    for sAttr in ['armIkLFT_ctrl.t', 'armIkLFT_ctrl.r', 'armPoleLFT_ctrl.t', 'armPoleLFT_ctrl.r']:
        fValues = cmds.getAttr(sAttr)[0]
        dPose[sAttr] = fValues

    _uiArgs['dPose'].setText(str(dPose))




dButtons = {}
dButtons['make straight'] = makeArmStraight
dButtons['record straight pose'] = recordStraightPose

@builderTools.addToBuild(iOrder=144, dButtons=dButtons)
def motionCaptureTags(dPose={}):
    utils.addStringAttr(utils.getMasterName(), 'mocapArmT', str(dPose), bLock=True)





@builderTools.addToBuild(iOrder=145)
def mirrorAnimationTags():

    def _tag(sCtrls, dData={}):

        for sCtrl in utils.toList(sCtrls):
            for s,sSide in enumerate(['l','r']):
                if sSide == 'l':
                    sSideCtrl = sCtrl
                if sSide == 'r':
                    if 'LFT' not in sCtrl:
                        continue
                    sSideCtrl = sCtrl.replace('LFT','RGT')
                    if 'sParent' in dData:
                        dData['sParent'] = dData['sParent'].replace('LFT','RGT]')

                if not cmds.objExists(sSideCtrl):
                    continue
                sParent = dData.get('sParent', None)
                if sParent and not cmds.objExists(sParent):
                    continue

                utils.addStringAttr(sSideCtrl, 'dMirrorData', str(dData), bLock=True)

                cCtrl = ctrls.ctrlFromName(sCtrl)
                if cCtrl.sSuper:
                    utils.addStringAttr(cCtrl.sSuper, 'dMirrorData', str(dData), bLock=True)
                if cCtrl.sPivot:
                    utils.addStringAttr(cCtrl.sPivot, 'dMirrorData', str(dData), bLock=True)
                if cCtrl.sChild:
                    utils.addStringAttr(cCtrl.sChild, 'dMirrorData', str(dData), bLock=True)


    # arms
    for sCtrl in ['clavicleLFT_ctrl', 'armUpperLFT_ctrl', 'armElbowLFT_ctrl', 'armWristLFT_ctrl']:
        _tag([sCtrl], {'sNegate':[]})
    _tag('armIkLFT_ctrl', {'sNegate':[]})
    _tag('armPoleLFT_ctrl', {'sNegate':['translateX'] if not cmds.objExists('grp_r_armPoleOffsetSlider') else []})

    # legs
    for sCtrl in ['legUpperLFT_ctrl', 'legKneeLFT_ctrl', 'legAnkleLFT_ctrl']:
        _tag([sCtrl], {'sNegate':[]})
    _tag('legIkLFT_ctrl', {'sNegate':[]})
    _tag('legPoleLFT_ctrl', {'sNegate':['translateX'] if not cmds.objExists('grp_r_legPoleOffsetSlider') else []})

    # jaw
    if cmds.objExists('ctrl_m_jawOut'):
        fRotX = cmds.getAttr('ctrl_m_jawOut.rx')
        if abs(fRotX) < 1.0: # didn't get oriented (old character)
            _tag('jaw_ctrl', {'sNegate': ['translateZ', 'rotateX', 'rotateY']})

