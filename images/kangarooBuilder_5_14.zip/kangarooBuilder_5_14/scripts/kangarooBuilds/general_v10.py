###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np
import pickle
import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.surfaces as surfaces
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.constraints as constraints
import kangarooTools.utilsUnreal as utilsUnreal

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls2 as ctrls2
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.ctrls5 as ctrls5
import kangarooTabTools.ctrls6 as ctrls6
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.ctrls8 as ctrls8
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.blendShapesPro as blendShapesPro

from collections import defaultdict

kBuilderColor = '#39a9f4'


@builderTools.addToBuild(iOrder=-1001)
def reloadLibraries():
    for module in [utils, nodes, match, puppetTools, segmentsTools, ctrls, ctrls2, ctrls3, ctrls4, ctrls5, ctrls6, ctrls7, ctrls8, sliderCtrls, weights, xforms, curves, surfaces, patch,
                   deformers, interpolator, geometry, export, unreal, constraints, blendShapes, blendShapesPro, utilsUnreal]:
        print('reloading %s' % module.__name__)
        report.report.addLogText('reloading %s' % module.__name__)
        utils.reload2(module)

        try:
            import controlRig.prepare as prepare
            utils.reload2(prepare)


        except:
            report.report.addLogText ('skipping controlRig import')



@builderTools.addToBuild(iOrder=-9, dButtons={})
def cleanModel(sCleanNormalsMeshes=[], sDeleteColorSetsMeshes=[]):
    sCleanNormalsMeshes = [sM for sM in sCleanNormalsMeshes if cmds.objExists(sM)]
    if sCleanNormalsMeshes:
        cmds.polyNormalPerVertex( sCleanNormalsMeshes, ufn = True )
        for sM in sCleanNormalsMeshes:
            cmds.polySoftEdge( sM, a=180, ch=False)
        cmds.delete(sCleanNormalsMeshes, ch=True)

    sDeleteColorSetsMeshes = [sM for sM in sDeleteColorSetsMeshes if cmds.objExists(sM)]
    if sDeleteColorSetsMeshes:
        geometry.deleteColorSets(sDeleteColorSetsMeshes)



@builderTools.addToBuild(iOrder=5)
def greyShader(sMeshes=[]):
    sShader = cmds.shadingNode('lambert', asShader=True, n='defaultGreyShader')
    cmds.setAttr('%s.color' % sShader, 0.3, 0.3, 0.3)
    
    cmds.select(sMeshes)
    cmds.hyperShade(assign=sShader)


@builderTools.addToBuild(iOrder=-1000)
def newScene(bAscii=True):
    ctrls7.checkBeforeNewScene(assets.assetManager.getCurrentVersionPath())
    weights.checkBeforeNewScene(assets.assetManager.getCurrentVersionPath(sSubPath='deformers'))

    
    cmds.file(new=True, f=True)
    sFilePath = os.path.expanduser('~/newScene.%s' % 'ma' if bAscii else 'mb')
    cmds.file(rename=sFilePath)
    cmds.file(save=True, typ='mayaAscii' if bAscii else 'mayaBinary')


@builderTools.addToBuild(iOrder=-100)
def createTopGroups(sModelGroupName='model', iModelVisDefault=1, iRigVisDefault=0, iSkeletonVisDefault=1, bSideIsSingleSign=True):
    assets.createTopGroups(iModelVisDefault=iModelVisDefault, iRigVisDefault=iRigVisDefault, iSkeletonVisDefault=iSkeletonVisDefault, sModel=sModelGroupName)
    utils.data.store('sBuildingAsset', [assets.getCurrentProject(), assets.assetManager.getCurrentAsset()])
    utils.data.store('bAllSplitAttachersTakeLocals', True) # actually not needed anymore
    utils.data.store('bSideIsSingleSign', bSideIsSingleSign)
    cmds.createNode('joint', n='jnt_m_zero', p='modules')


@builderTools.addToBuild(iOrder=1005)
def setTopGroupAttributes(iModelVisDefault=2, iRigVisDefault=0, iSkeletonVisDefault=0):
    sMaster = utils.getMasterName()
    cmds.setAttr('%s.modelVis' % sMaster, iModelVisDefault)
    cmds.setAttr('%s.rigVis' % sMaster, iRigVisDefault)
    cmds.setAttr('%s.skeletonVis' % sMaster, iSkeletonVisDefault)

    sPoseLocVis = '%s.posesLocVIS' % sMaster
    if cmds.objExists(sPoseLocVis):
        cmds.setAttr(sPoseLocVis, False)




def checkClashingNames():
    sAllNewNodes = cmds.ls(dag=True)
    sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
    if sClashingNodes:
        print('---CLASHING NODES---')
        for sN in sClashingNodes:
            print(sN)
        cmds.select(sClashingNodes)
    else:
        print('no clashing nodes')


@builderTools.addToBuild(iOrder=-10, dButtons={'find clashing nodes in scene': checkClashingNames})
def importModel(bCheckClashingNames=True, bReference=False, sAsset='__self__', sVersion='__latest__'):
    sModelPath = assets.assetManager.getModelPath(sAsset, sVersion)
    report.report.addLogText('importing from path: %s' % sModelPath)
    if sModelPath:
        sSelBefore = cmds.ls(sl=True)
        sFilesNames = utils.listFilesInFolder(sModelPath,
                                              sEndswith=['.ma', '.MA', '.mb', '.MB', '.obj', '.OBJ', '.fbx', '.FBX', '.abc'])
        report.report.addLogText('found files: %s' % ', '.join(sFilesNames))
        sFiles = [os.path.join(sModelPath, sF) for sF in sFilesNames]

        sNewNodes = utils.importMayaFiles(sFiles, bReference=bReference)
        if not sNewNodes:
            report.report.addLogText('nothing got imported!')
            return
        if bCheckClashingNames:
            sAllNewNodes = sNewNodes + cmds.listRelatives(sNewNodes, ad=True, f=True)
            sAllNewNodes = cmds.ls(sAllNewNodes)
            sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
            if sClashingNodes:
                print('---CLASHING NODES---')
                report.report.addLogText('clashing nodes')
                for sN in sClashingNodes:
                    print(sN)
                    report.report.addLogText(sN)

                raise Exception('clashing nodes, check script editor')

        sModelGroup = utils.data.get('sModelGroupName')
        print ('sModelGroup: ', sModelGroup)
        if sModelGroup:
            [cmds.lockNode(sN, lock=False) for sN in sNewNodes]
            cmds.parent(sNewNodes, sModelGroup)
            utils.addStringAttr(utils.getMasterName(), 'sModelFiles', str([os.path.join(sModelPath,sF).replace('\\','/') for sF in sFilesNames]), bLock=True)

        for sNode in cmds.listRelatives(sNewNodes, ad=True, typ='transform', f=True) or []:
            if cmds.objectType(sNode) == 'transform':
                try:
                    cmds.setAttr('%s.overrideEnabled' % sNode, False)
                except:
                    pass
        cmds.select(sSelBefore)
    else:
        raise Exception('problem with importing model (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=-8)
def importBlueprints():
    sBlueprintPath = assets.assetManager.getCurrentVersionPath(sSubPath='blueprints.ma')
    print('importing blueprints %s ...' % sBlueprintPath)
    report.report.addLogText('importing blueprint rig: %s' % sBlueprintPath)

    sNewNodes = utils.importMayaFiles([sBlueprintPath])


@builderTools.addToBuild(iOrder=-5)
def importMayaFiles(dSettings={'file.ma':{'sNamespace':'NAMESPACE'}}):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='mayaImport/')

    print('sImportPath: ', sImportPath)

    if os.path.exists(sImportPath):
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.ma', '.mb', '.obj', '.fbx', '.abc'], bAbsolute=True)
        print('sFiles: ', sFiles)
        report.report.resetProgress(len(sFiles))


        if sFiles:
            for sFile in sFiles:
                sFileName = os.path.basename(sFile)
                sNamespace = None
                if sFileName in dSettings:
                    sNamespace = dSettings[sFileName].get('sNamespace', None)
                utils.importMayaFiles(sFile, sNamespace=sNamespace)
        else:
            report.report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sImportPath)
        report.report.addLogText('\ndidn\'t find import path (%s)' % sImportPath)


@builderTools.addToBuild(iOrder=-5)
def importTargets(bOrderByDateOfModification=True):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='targets/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.trg'], bAbsolute=True)
    # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
    print('sFiles: ', sFiles)
    report.report.resetProgress(len(sFiles))

    if sFiles:
        fTimes = [os.path.getmtime(sF) for sF in sFiles]
        if bOrderByDateOfModification:
            aSorted = np.argsort(fTimes)
        else:
            aSorted = np.argsort(sFiles)
        sFiles = np.array(sFiles)[aSorted]

        for sF in sFiles:
            report.report.addLogText('importing %s' % sF)
            export.importTargets(sF)
            report.report.incrementProgress()
    else:
        report.report.addLogText('no files found')





@builderTools.addToBuild(iOrder=0)
def buildPuppet(bMetahumanJoints=False):
    sPuppetFile = assets.assetManager.getCurrentVersionPath(sSubPath='puppet.rig')
    dLimbs = puppetDataUtils.getDictListFromFile(sPuppetFile)
    dLimbs = [dL for dL in dLimbs if dL.get('bDisabledFILE', False) == False]

    utils.data.store('bMetahumanJoints', bMetahumanJoints)

    puppetDataUtils.limbsFromFiles(bReload=True)

    puppetTools.buildRig(all=None, xLimbs=[sPuppetFile, dLimbs], sMaster='master',
                         _bClearBeforeBuild=False, _bReloadLimbs=True, _bFromUI=False, _bMetahumanJoints=bMetahumanJoints)

    # to make sure posing ctrls
    sAllCtrls = ctrls7.getAllCtrlsInScene(bReturnNames=True)
    for sCtrl in sAllCtrls:
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls7.ctrlFromName(sCtrl)
            cCtrl.setDefaultAttrDict()


    for sCtrl in ['placement_ctrl', 'global_ctrl']:
        if cmds.objExists(sCtrl):
            cmds.setAttr(f'{sCtrl}.childVIS', True)
            cmds.setAttr(f'{sCtrl}.superVIS', True)



def bindMeshesAutoBind(sIgnoreFiles, bWorldSpaceIfNotMatching, bAlwaysWorldSpace):
    sSel = cmds.ls(sl=True)

    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')

    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles)-set(sIgnoreFiles))
    sFiles.sort(key=lambda x:x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles if sF.startswith('skinCluster__')]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    aFileMeanValues = np.zeros((len(sFiles), 3), dtype='float64')
    dMeshFiles = {}
    for f,sFile in enumerate(sFiles):
        print('\n\n\nsFile: ', sFile)
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)
        with open(sFile, 'rb') as handle:
            loadedDict = pickle.load(handle)

        sKeys = list(loadedDict.keys())
        for sK in sKeys:
            if sK.endswith('_geo'):
                print(sK, ' -> ', loadedDict[sK])
                dMeshFiles[loadedDict[sK]] = sFile
            if 'recreateData' in sK and sK.endswith('_points'):
                aFileMeanValues[f] = np.mean(loadedDict[sK], axis=0)


    for sMesh in sSel:
        if len(deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])):
            continue

        aMeanValue = np.mean(patch.patchFromName(sMesh).getAllPoints(), axis=0)
        aFileDiffs = aFileMeanValues - aMeanValue[np.newaxis,:]
        aLengths = np.linalg.norm(aFileDiffs, axis=-1)
        iMin = np.argmin(aLengths)

        sFile = sFiles[iMin]
        cmds.select(sMesh)
        sLoaded, dSkipped = weights._loadFromFile((sFile,None), iLoadMayaSelection = weights.LoadMayaSelection.loadOntoSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=weights.LoadWorldspace.closestPoints)
        dAllSkipped.update(dSkipped)
        sSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
        if sSkinClusters:
            cmds.rename(sSkinClusters[0], sSkinClusters[0].replace('_', ''))

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=50, dButtons={'bind selected meshes with best fitting files':bindMeshesAutoBind})
def loadDeformers(sIgnoreFiles=[], bWorldSpaceIfNotMatching=False, bAlwaysWorldSpace=False):
    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts', '.npz'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles) - set(sIgnoreFiles))
    sFiles.sort(key=lambda x: x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    for sFile in sFiles:
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)

        iLoadWorldspace = weights.LoadWorldspace.ignore
        if bAlwaysWorldSpace:
            iLoadWorldspace = weights.LoadWorldspace.closestPoints
        elif bWorldSpaceIfNotMatching:
            iLoadWorldspace = weights.LoadWorldspace.closestPointsIfTopologyDiffers

        sLoaded, dSkipped = weights._loadFromFile((sFile, None),
                                                  iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldspace)
        dAllSkipped.update(dSkipped)

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=101)
def loadCtrlShapes(bDoColor=False):
    sCtrlShapesDir = assets.assetManager.getCurrentVersionPath()
    sCtrlMasters = [sF.split('.')[0] for sF in os.listdir(sCtrlShapesDir) if sF.endswith('.ctrls')]
    print('sCtrlMasters: ', sCtrlMasters)
    for sMaster in sCtrlMasters:
        if sMaster == 'ctrls' and len(sCtrlMasters) > 1:  # we have new ctrl files, but didn't delete the one from old system yet
            continue
        if cmds.objExists(sMaster):
            sFilePath = os.path.join(sCtrlShapesDir, '%s.ctrls' % sMaster)
            report.report.addLogText('loading file: %s' % sFilePath)
            ctrls7.loadCtrls(sFile=sFilePath, bDoColor=bDoColor)



@builderTools.addToBuild(iOrder=1000)
def clean(bDeleteThem=False, bDeleteDisplayLayers=False):
    sModelGroup = utils.data.get('sModelGroupName')

    for sSurface in ['l_surface_forehead_down', 'r_surface_forehead_down']:
        if cmds.objExists(sSurface):
            cmds.delete(sSurface, ch=True)


    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]
    sOutsideNodes = set(sOutsideNodes) - set([utils.getMasterName(), '__faceData__', '__export__', utils.kGeneralDataNode, 'GAMESKELETON', 'GAMEMODEL'])
    for sN in sOutsideNodes:
        if bDeleteThem:
            if cmds.objExists(sN):
                cmds.delete(sN)
        else:
            try:
                cmds.setAttr('%s.v' % sN, False)
            except: pass

    if bDeleteDisplayLayers:
        for sL in cmds.ls(et='displayLayer'):
            try:
                cmds.delete(sL)
            except:
                pass
        print ('sModelGroup: ', sModelGroup)
        for sObj in cmds.listRelatives(sModelGroup, ad=True, f=True) or []:
            try:
                cmds.setAttr('%s.overrideEnabled' % sObj, False)
            except:
                report.report.addLogText('WARNING - couldn\'t reset override enabled for %s' % sObj)



@builderTools.addToBuild(iOrder=106)
def updateDefaultCtrlAttrDicts():
    sAllCtrls = ctrls8.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls8.ctrlFromName(sCtrl)
            cCtrl.setDefaultAttrDict()


# @builderTools.addToBuild(iOrder=130)
# def ctrlProximityConnections():
#     sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
#     report.report.resetProgress(len(sAllCtrls))
#
#     for sCtrl in sAllCtrls:
#         report.report.incrementProgress()
#         if ctrls.isCtrl(sCtrl):
#             cCtrl = ctrls.ctrlFromName(sCtrl)
#             try:
#                 cCtrl.setDefaultAttrDict()
#             except:
#                 cmds.warning('couldn\'t setDefaultAttr for %s' % cCtrl)
#
#     sProximityCondition = nodes.createConditionNode('master.ctrlVis', '==', 2, 2, 0, sName='ctrlProximity')
#     for sCtrl in cmds.controller(q=True, ac=True):
#         sTag = cmds.controller(sCtrl, q=True)[0]
#         cmds.connectAttr(sProximityCondition, '%s.visibilityMode' % sTag)


@builderTools.addToBuild(iOrder=150)
def goToDefaultPose():
    sCtrls = [sCtrl for sCtrl in cmds.controller(q=True, ac=True)]

    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



@builderTools.addToBuild(iOrder=1000)
def prepareAnimPicker(sCharacter='FullCharacter'):
    sAnimPicker = cmds.createNode('transform', n='AnimPickerData', p=utils.getMasterName())
    utils.addStringAttr(sAnimPicker, 'character', sCharacter)



@builderTools.addToBuild(iOrder=1010)
def prepareForPublish(sRenameMaster='master', bDeleteUnrealModel=True):
    '''

    '''
    # utils.data.store('bVersionFolders', True, sNode=utils.kExportNode)

    cmds.flushUndo()

    sAsset = assets.assetManager.getCurrentAsset()
    sUnrealModel = utils.data.get('sUnrealModel', None)
    if not sUnrealModel:
        bDeleteUnrealModel = False

    utils.addStringAttr('master', 'sOldMasterName', 'master')
    sMaster = cmds.rename('master', sRenameMaster)
    ddMasters = {sMaster:{'sFilename':'RIG_%s_[v].ma' % sAsset,
                           'sExtraFiles': 'fbx/GAME_%s.fbx' % (sAsset),
                           'sDelete':['GAMEMODEL'] if bDeleteUnrealModel else []}}
    utils.data.store('ddMasters', ddMasters, sNode=utils.kExportNode)
    utils.data.store('bSaveInsteadOfExport', True, sNode=utils.kExportNode)

    # dConfirms = {'Did you export FBX?':[('Yes', True),
    #                                   ('No, but I don\'t care.', True),
    #                                   ('Oops.. please cancel', False)]}
    # utils.data.store('dConfirms', dConfirms, sNode=utils.kExportNode)


dButtons = {}



@builderTools.addToBuild(iOrder=-1002, bDisableByDefault=True)
def mayaVersionChecker(sVersion='2022'):
    sCurrentVersion = cmds.about(version=True)
    sVersion = str(sVersion)
    if sCurrentVersion != sVersion:
        raise Exception('Current version is %s, but it needs to be built in %s' % (sCurrentVersion, sVersion))


@builderTools.addToBuild(iOrder=90)
def puppetCustomAttachments(bLegacyWrongDeformerOrder=False):
    return constraints.setupAllPuppetCustomAttachments(bRotateByNeighborVerts=True, bLegacyWrongDeformerOrder=False, bLegacyIgnoreScale=False)




def exportFbxButton():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    sAsset = assets.assetManager.getCurrentAsset()

    if not os.path.exists(sPath):
        os.makedirs(sPath)
    sFilePath = os.path.join(sPath, 'GAME_%s.fbx' % sAsset).replace('\\', '/')

    report.report.incrementProgress()


    # unreal
    bUnrealExists = cmds.objExists('GAMESKELETON')
    if not bUnrealExists:
        report.report.addLogText('====== no unreal rig in scene!!! ======')
        return
    else:
        report.report.addLogText('\nexporting %s' % sFilePath)

    sNodes = ['GAMESKELETON']
    cmds.parent(sNodes, w=True)

    sAllConnections = []
    report.report.addLogText('temporarily unplugging connections..', bRefresh=True, bIncrementProgress=True)
    try:
        for sNode in cmds.listRelatives('GAMESKELETON', ad=True, typ='joint'):
            sConnections = cmds.listConnections(sNode, s=True, d=False, p=True, c=True) or []
            for i in range(0,len(sConnections),2):
                cmds.disconnectAttr(sConnections[i+1], sConnections[i])
            sAllConnections += sConnections

        report.report.addLogText('exporting..', bRefresh=True, bIncrementProgress=True)
        for sN in cmds.ls(sNodes, dag=True):
            cmds.setAttr('%s.overrideEnabled' % sN, False)
            cmds.setAttr('%s.v' % sN, True)
        cmds.select(sNodes)

        sExportString = 'FBXExport -f "%s" -FBXExportSmoothingGroups True -s' % sFilePath.replace('\\', '/')
        mel.eval('FBXResetExport')
        mel.eval(sExportString)
    except:
        raise
    finally:
        for i in range(0,len(sAllConnections),2):
            cmds.connectAttr(sAllConnections[i+1], sAllConnections[i])
        cmds.parent(sNodes, utils.getMasterName())
        [cmds.setAttr('%s.v' % sNode, False) for sNode in sNodes]




def explorerFbx():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    utils.openExplorer(sPath)


# def dumpUnrealCodeLinesToFile():
#     import kangarooTools.utilsUnreal as utilsUnreal
#     utilsUnreal.dumpUnrealCodeLinesToFile()

def getMannequinMapData():
    xxMapData = []
    xxMapData.append(['jnt_r_armWrist', 'ik_hand_gun', True, None])
    xxMapData.append(['jnt_l_armWrist', 'ik_hand_l', True, None])
    xxMapData.append(['jnt_l_legWrist', 'ik_foot_l', True, None])
    xxMapData.append(['jnt_m_hips', 'pelvis', True,  [(0,0,-1),(1,0,0)]])
    xxMapData.append(['jnt_l_leg_upperTwist_000', 'thigh_l', True, [(-1,0,0),(0,1,0)]])
    xxMapData.append(['jnt_l_leg_upperTwist_001', 'thigh_twist_01_l', True, None])
    xxMapData.append(['jnt_l_leg_upperTwist_002', 'thigh_twist_02_l', True, None])
    xxMapData.append(['jnt_l_leg_lowerTwist_000', 'calf_l', True, [[-1,0,0], [0,1,0]]])
    xxMapData.append(['jnt_l_leg_lowerTwist_001', 'calf_twist_01_l', True, None])
    xxMapData.append(['jnt_l_leg_lowerTwist_002', 'calf_twist_02_l', True, None])
    xxMapData.append(['jnt_l_legWrist', 'foot_l', True, None])
    xxMapData.append(['jnt_l_legFingers', 'ball_l', True, None])
    xxMapData.append(['jnt_m_spineSpine_000', 'spine_01', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_001', 'spine_02', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_002', 'spine_03', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_003', 'spine_04', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_end', 'spine_05', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_clavicleMain', 'clavicle_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_upperTwist_000', 'upperarm_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_upperTwist_001', 'upperarm_twist_01_l', True, None])
    xxMapData.append(['jnt_l_arm_upperTwist_002', 'upperarm_twist_02_l', True, None])
    xxMapData.append(['jnt_l_arm_lowerTwist_000', 'lowerarm_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_lowerTwist_001', 'lowerarm_twist_01_l', True, None])
    xxMapData.append(['jnt_l_arm_lowerTwist_002', 'lowerarm_twist_02_l', True, None])
    xxMapData.append(['jnt_l_armWrist', 'hand_l', True, [(1,0,0), (0,0,-1)]])
    xxMapData.append(['jnt_m_neckSpine_000', 'neck_01', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_neckSpine_001', 'neck_02', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_headMain', 'head', True, [(1,0,0),(0,1,0)]])
    xxMapData.append(['ctrl_l_legHeelOut', 'heel_l', True, [(0,0,1),(0,1,0)]])
    xxMapData.append(['ctrl_l_legToesRevOut', 'tip_l', True, [(0,0,1),(0,1,0)]])

    sKangarooFingerBones = ['jnt_l_%sMeta', 'jnt_l_%sBase', 'jnt_l_%sMid', 'jnt_l_%sTip']
    sUnrealFingerBones = ['%s_metacarpal_l', '%s_01_l', '%s_02_l', '%s_03_l']
    for sFinger in ['thumb', 'index', 'middle', 'ring', 'pinky']:
        for sKangaroPattern, sUnrealPattern in zip(sKangarooFingerBones, sUnrealFingerBones[1:] if sFinger == 'thumb' else sUnrealFingerBones):
            sKangarooJoint = sKangaroPattern % sFinger
            sUnrealJoint = sUnrealPattern % sFinger
            if cmds.objExists('game:%s' % sUnrealJoint):
                xxMapData.append([sKangarooJoint, sUnrealJoint, True, [(1, 0, 0), (0, -1, 0)]])

    xxRightData = []
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        if utils.getSide(sKangaroo) == 'l':
            xxRightData.append([utils.getMirrorName(sKangaroo), utils.replaceStringEnd(sUnreal, '_l', '_r'), bPosition, xRotation])
    xxMapData += xxRightData

    return xxMapData


def getInitialUnrealJointsMannequin(xxMapData=None):
    if utils.isNone(xxMapData):
        xxMapData = getMannequinMapData()
    xxExtraSkinData = []
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        sAttr = '%s.segmentsData' % sKangaroo
        if cmds.objExists(sAttr):
            dSegmentsData = eval(cmds.getAttr(sAttr)) # {'sSearchReplace': 'Spine;SpineSquash'}";
            sSearchReplace = dSegmentsData.get('sSearchReplace', None)
            if not utils.isNone(sSearchReplace):
                sSearch, sReplace = sSearchReplace.split(';')
                if sSearch in sKangaroo:
                    sReplacedJoint = sKangaroo.replace(sSearch, sReplace)
                    if cmds.objExists(sReplacedJoint):
                        xxExtraSkinData.append([sReplacedJoint, sUnreal, bPosition, xRotation])
    xxMapData += xxExtraSkinData

    return {sKangaroo: sUnreal for sKangaroo, sUnreal, bPosition, xRotation in xxMapData}





@builderTools.addToBuild(iOrder=130, bDisableByDefault=True, dButtons={'export FBX':exportFbxButton, 'explorer FBX':explorerFbx})
def create_GAMESKELETON(bConnectBlendShapeAnim=True, bCheckDeformerFiles=False, bExtraJoints=True, bIgnoreNonBoundJoints=False, sIgnoreMeshes=[]):

    # xxMapData = getMetahumanMapData()

    # the squash joint of the end has no meaning, and is better to just delete for the things to come (TODO: spine lib should take care of that in future)
    # sBadSpineEndJoint = 'jnt_m_spineSpineSquash_004'
    # if cmds.objExists(sBadSpineEndJoint):
    #     if cmds.listConnections(sBadSpineEndJoint, s=False, d=True, t='skinCluster'):
    #         raise Exception('"%s" is bound, please delete it, since it would cause trouble with Game Rig' % sBadSpineEndJoint)
    dUnrealJoints = utils.data.get('dUnrealJoints', xDefault={})


    if not cmds.objExists('GAMESKELETON'):
        cmds.createNode('transform', n='GAMESKELETON', p=utils.getMasterName())
    if not cmds.objExists('GAMEMODEL'):
        cmds.createNode('transform', n='GAMEMODEL', p='GAMESKELETON')
    if not cmds.namespace(exists='game'):
        cmds.namespace(add='game')

    if bExtraJoints:
        # extra limb joints
        # sAllJoints = cmds.ls('grp_jnt_m_cog_SCALE_skeleton', dag=True, et='joint', l=True)
        sAllJoints = cmds.ls('skeleton', dag=True, et='joint', l=True)
        sAllJoints = sorted(sAllJoints, key=lambda a:len(a))
        for sFullJ in sAllJoints:
            sJ = sFullJ.split('|')[-1]
            if sJ not in dUnrealJoints:
                if bIgnoreNonBoundJoints and not cmds.attributeQuery('_forceKeepForGames_', node=sJ, exists=True):
                    if not cmds.listConnections(sJ, t='dagPose'): # not cmds.listRelatives(sJ, c=True) and not
                        continue

                print ('sJ: ', sJ)
                sParent = sJ
                for i in range(10):
                    sParents = cmds.listRelatives(sParent, p=True)
                    if utils.isNone(sParents):
                        sUnrealParent = 'GAMESKELETON'
                        break
                    else:
                        sParent = sParents[0]

                    if sParent in dUnrealJoints:
                        sUnrealParent = 'game:%s' % dUnrealJoints[sParent]
                        break

                sDuplJ = cmds.duplicate(sJ, parentOnly=True, n='game:%s' % sJ)[0]
                cmds.parent(sDuplJ, sUnrealParent)
                xforms.matchXform(sJ, sDuplJ)

                dUnrealJoints[sJ] = sDuplJ.split(':')[-1]

        # fix the transform groups above the eye joints
        for sJoint in ['game:jnt_l_eyeMain', 'game:jnt_r_eyeMain']:
            if cmds.objExists(sJoint):
                sJointParent = cmds.listRelatives(sJoint, p=True)[0]
                if sJointParent.startswith('transform'):
                    cmds.setAttr('%s.s' % sJointParent, 1, 1, 1)
                    sNewParent = cmds.listRelatives(sJointParent, p=True)[0]
                    cmds.parent(sJoint, sNewParent)
                    cmds.delete(sJointParent)


    # muscle joints
    sMuscleJoints = [sJ for sJ in cmds.ls('grp_m_muscleJoints', dag=True, et='joint') if not sJ.endswith('End')]
    for sJ in sMuscleJoints:
        sStartSpaceAttr = '%s.startSpace' % sJ
        if not cmds.objExists(sStartSpaceAttr):
            continue
        sStartSpace = cmds.getAttr(sStartSpaceAttr)
        sGameJ = cmds.duplicate(sJ, n='game:%s' % sJ, po=True)[0]
        sUnrealStartSpace = 'game:%s' % dUnrealJoints[sStartSpace]
        cmds.parent(sGameJ, sUnrealStartSpace)
        dUnrealJoints[sJ] = sJ

    sMuscles = [sJ for sJ in cmds.ls('game:muscleJnt_*', et='joint') if not sJ.endswith('End')]
    for sJ in sMuscles:
        sParent = 'game:%s' % dUnrealJoints[cmds.getAttr('%s.startSpace' % sJ)]
        sCurrentParent = cmds.listRelatives(sJ, p=True)[0]
        if sParent != sCurrentParent:
            cmds.parent(sJ, sParent)


    if True:
        sFirstTwistJoints = cmds.ls('game:jnt_*Twist_000', et='joint')
        unreal.leavifyTwistJoints(sFirstTwistJoints)



    # fix values
    sChildren = cmds.listRelatives('GAMESKELETON', p=False, c=True, typ='joint')
    if sChildren:
        cmds.parent(sChildren, w=True)
    cmds.setAttr('GAMESKELETON.r', 0,0,0 )
    if sChildren:
        cmds.parent(sChildren, 'GAMESKELETON')

    # utils.parentToWorld('GAMESKELETON')

    sRotateJoints = utils.addAttr('GAMESKELETON', ln='rotateJoints', at='double3', k=True)
    sRotatedMatrix = nodes.createComposeMatrixNode(xRotate=sRotateJoints)

    sConstrainedUnrealJoints = set()
    for sKangarooJ in ['placement_ctrl'] + sorted(dUnrealJoints.keys(), key=lambda a:len(a)):
        sUnrealJ = 'root' if sKangarooJ == 'placement_ctrl' else dUnrealJoints[sKangarooJ]
        sUnrealFullJ = 'game:%s' % sUnrealJ
        if cmds.objExists(sUnrealFullJ) and cmds.objExists(sKangarooJ):
            if sUnrealFullJ not in sConstrainedUnrealJoints:
                # xforms.matrixParentConstraint(sKangarooJ, sUnrealFullJ, mo=True)
                cmds.setAttr('%s.jo' % sUnrealFullJ, lock=False)
                xforms.jointOrientToRotation(sUnrealFullJ)
                cmds.setAttr('%s.jo' % sUnrealFullJ, lock=True)
                fOffsetMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sUnrealFullJ, '%s.worldInverseMatrix' % sKangarooJ], bJustValues=True)
                sRotatedJointMatrix = nodes.createMultMatrixNode([fOffsetMatrix, '%s.worldMatrix' % sKangarooJ, sRotatedMatrix, '%s.parentInverseMatrix' % sUnrealFullJ])
                nodes.createDecomposeMatrix(sRotatedJointMatrix, sTargetPos='%s.t' % sUnrealFullJ, sTargetRot='%s.r' % sUnrealFullJ, sTargetScale='%s.s' % sUnrealFullJ)
                sConstrainedUnrealJoints.add(sUnrealFullJ)

    def _getUnrealJoint(sJoint):
        if sJoint in dUnrealJoints:
            return 'game:%s' % dUnrealJoints[sJoint]
        else:
            sLeftOverJoint = 'game:jnt_leftOverJointThatShouldntBeThere'
            if not cmds.objExists(sLeftOverJoint):
                cmds.createNode('joint', n=sLeftOverJoint, p='game:root')
            return sLeftOverJoint



    # switch off deformers for duplicate
    dPrevSkinClusterStates = {}
    dPrevBlendShapeStates = {}
    sBlendshapeMeshes = []

    report.report.addLogText('Duplicate the models...', bRefresh=True)

    report.report.incrementProgress()
    for sMesh in utils.listMeshes('model'):
        if sMesh in sIgnoreMeshes:
            continue
        sDeformers = deformers.listAllDeformers(sMesh)
        for sD in sDeformers:
            if cmds.objectType(sD) == 'skinCluster':
                dPrevSkinClusterStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
            elif cmds.objectType(sD) == 'blendShape':
                dPrevBlendShapeStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
                sBlendshapeMeshes.append(sMesh)
            else:
                continue
            cmds.setAttr('%s.nodeState' % sD, 1)

    sBlendshapeMeshes = list(set(sBlendshapeMeshes))


    # sUnrealModel = 'GAMEMODEL'
    sDuplicates = cmds.duplicate('model')
    sTopDuplicate = sDuplicates[0]
    sUnrealModelChildren = sDuplicates[1:]

    sFullNames = [sN for sN in cmds.ls(sUnrealModelChildren, l=True) if sTopDuplicate in sN]
    sFullNames = sorted(sFullNames, key=lambda a: len(a), reverse=True)
    for n,sN in enumerate(sFullNames):
        if not cmds.objExists(sN):
            continue
        sName = sN.split('|')[-1]
        if sName not in sIgnoreMeshes:
            sFullNames[n] = cmds.rename(sN, 'game:%s' % sName)
        else:
            cmds.delete(sN)
            sFullNames[n] = None
    sFullNames = [sN for sN in sFullNames if sN]

    sUnrealModel = 'GAMEMODEL'
    if not cmds.objExists(sUnrealModel):
        cmds.createNode('transform', n=sUnrealModel, p=utils.getMasterName())
    cmds.parent(cmds.listRelatives(sTopDuplicate, c=True, f=True), sUnrealModel)
    cmds.delete(sTopDuplicate)


    report.report.resetProgress(len(utils.flattenedList(sFullNames)))
    report.report.addLogText('clean up meshes for lod %s' % 'model')
    for sN in sFullNames:
        report.report.incrementProgress()
        if  cmds.objectType(sN) == 'transform':
            sAllShapes = cmds.listRelatives(sN, s=True, f=True) or []
            sNoIntermShapes = cmds.listRelatives(sN, s=True, ni=True, f=True) or []
            sDeleteShapes = set(sAllShapes) - set(sNoIntermShapes)
            sKeepShapes = set(sAllShapes) - set(sDeleteShapes)
            if sDeleteShapes:
                cmds.delete(list(sDeleteShapes))

            # fix shapes that don't get renamed
            for sS in sKeepShapes:
                sNameS = sS.split('|')[-1]
                if not sNameS.startswith('game:'):
                    cmds.rename(sS, 'game:%s' % sNameS)

    # cmds.parent(sUnrealModel, 'GAMESKELETON')

    # transfer blendshaes
    sBlendShapesToBake = []

    # set back blendshapes
    [cmds.setAttr(sA,fV) for sA,fV in list(dPrevBlendShapeStates.items())]

    sBlendShapeJoint = cmds.listRelatives('GAMESKELETON', ad=True, typ='joint')[-1]
    for sBody in sBlendshapeMeshes:
        sBlendShapes = deformers.listAllDeformers(sBody, sFilterTypes=['blendShape'])
        if len(sBlendShapes) > 1:
            raise Exception('there are more than one blendShapes for %s' % sBody)

        sBs = sBlendShapes[0]
        sTargetMeshes, sAliases, sSkippedTargets = blendShapes.bake(sBody, sBs, bSkipUnchanged=False)

        report.report.addLogText('\nSkipped %d BlendShape Targets of %d for "%s"' %
                                 (len(sSkippedTargets), len(sSkippedTargets) + len(sTargetMeshes), sBody))
        for sSkippedT in sSkippedTargets:
            report.report.addLogText('Skipped Target "%s"...' % sSkippedT)

        sSourceAttrs = ['%s.%s' % (sBs,sA) for sA in sAliases]
        sBlendShapesToBake.append(sBs)

        sAliasDupls = utils.getDuplicates(sAliases)
        if sAliasDupls:
            raise Exception('The alias %s appears in more than one blendShapes' % utils.listToString(sAliasDupls))

        sGameBlendShape = cmds.blendShape(sTargetMeshes, 'game:%s' % sBody)[0]
        deformers.makeNotExport(sGameBlendShape)

        if bConnectBlendShapeAnim:
            for t,sT in enumerate(sAliases):
                sSourceAttr = '%s.%s' % (sBs, sT)
                sSourceConnection = cmds.listConnections(sSourceAttr, s=True, d=False, p=True)
                if sSourceConnection:
                    cmds.connectAttr(sSourceConnection[0], '%s.%s' % (sGameBlendShape, sT))
                    sBlendShapeJointAttr = '%s.%s' % (sBlendShapeJoint, sT)
                    if not cmds.objExists(sBlendShapeJointAttr):
                        cmds.addAttr(sBlendShapeJoint, ln=sT, k=True)
                        cmds.connectAttr(sSourceAttr, sBlendShapeJointAttr)

        cmds.delete(sTargetMeshes)




    # bind new geometry
    sUnrealMeshes = utils.listMeshes('GAMEMODEL')
    report.report.resetProgress(len(sUnrealMeshes))


    def _getUnrealJoint(sJoint):
        if sJoint in dUnrealJoints:
            return 'game:%s' % dUnrealJoints[sJoint]
        else:
            sLeftOverJoint = 'game:jnt_leftOverJointThatShouldntBeThere'
            if not cmds.objExists(sLeftOverJoint):
                cmds.createNode('joint', n=sLeftOverJoint, p='game:root')
            return sLeftOverJoint


    # transfer or load skinClusters
    sDeformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    for sUnrealM in sUnrealMeshes:
        if not sUnrealM.startswith('game:'):
            continue
        sFileName = 'skinCluster__%s.wts' % sUnrealM.replace(':', '_') # because sUnrealM starts with game:
        sFilePath = os.path.join(sDeformerFolder, sFileName)

        if bCheckDeformerFiles and os.path.exists(sFilePath):
            report.report.addLogText('loading weights for mesh %s..' % sUnrealM, bIncrementProgress=True)
            sLoaded, dSkipped = weights._loadFromFile((sFilePath, None), iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection)
        else:
            report.report.addLogText('binding mesh %s..' % sUnrealM, bIncrementProgress=True)
            sM = utils.replaceStringStart(sUnrealM, 'game:', '')
            if not cmds.objExists(sM):
                raise Exception('this mesh doesn\'t exist: %s (%s)' % (sM, sUnrealM))
            # pM = patch.patchFromName(sM)
            pUnrealM = patch.patchFromName(sUnrealM)
            sSkinClusters = deformers.listAllDeformers(sM, sFilterTypes=['skinCluster'])
            if sSkinClusters:
                sShortestNameSkinCluster = deformers.chooseMainSkinClusterFromList(sSkinClusters)
                weights.transferSkinCluster([pUnrealM], sFrom=sShortestNameSkinCluster, iMode=weights.TransferMode.vertexIndex, funcMapJoint=_getUnrealJoint,
                                            bLogReport=False, bPostNormalize=True, _bSkipDeformerAdjustLogging=True)


    # set back skinClusters
    [cmds.setAttr(sA,fV) for sA,fV in list(dPrevSkinClusterStates.items())]

    for sMayaJ, sUnrealJ in dUnrealJoints.items():
        if cmds.objExists(sMayaJ):
            utils.addStringAttr(sMayaJ, 'sGameJoint', sUnrealJ)


    cmds.setAttr('GAMEMODEL.v', False)
    cmds.setAttr('GAMESKELETON.v', False)

    utils.data.store('dUnrealJoints', dUnrealJoints)

    unreal.createOrParentBlendShapeDummySphere() # this just parents it if needed






@builderTools.addToBuild(iOrder=131.5, dButtons={})
def visibilityAttributes(dData={'master.cuffCtrlsVis': {'bDefault':False, 'bUnreal':True, 'sNodeStrings':[]}}):
    bReturn = None
    sCommands = ['\n\n#visibility attributes']
    sCommands.append("nodes.newSequencerPlug()")
    sCommands.append("controllers.openCommentBox('Ctrl Visibilities')")

    # sCreatedUnrealCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    # print ('sCreatedUnrealCtrls: ', sCreatedUnrealCtrls)

    for sMasterAttr, xCtrlStrings in dData.items():
        if isinstance(xCtrlStrings, list):
            sCtrlStrings, bDefault, bUnreal = xCtrlStrings, False, True
        else:
            sCtrlStrings = xCtrlStrings['sNodeStrings']
            bDefault = xCtrlStrings.get('bDefault', True)
            bUnreal = xCtrlStrings.get('bUnreal', True)

        sSplits = sMasterAttr.split('.')
        if len(sSplits) == 1:
            sMasterCtrl, sA = 'master', sSplits[0]
        else:
            sMasterCtrl, sA = sSplits

        sMasterAttr = utils.addOffOnAttr(sMasterCtrl, sA, bDefaultValue=bDefault, bReturnIfExists=True)
        sCtrls = []
        for sCtrlStr in sCtrlStrings:
            sCtrls += cmds.ls(sCtrlStr, et='transform') + cmds.ls(sCtrlStr, et='joint')
        sCtrls = list(set(sCtrls))
        # sCtrlsSet = set(sCtrls)

        sCtrls = sorted(cmds.ls(sCtrls, l=True), key=lambda a:len(a))

        sConnectedTransformsLong = []
        if not len(sCtrls):
            report.report.addLogText('No Ctrls found for "%s"' % sMasterAttr)
            bReturn = False
        else:
            sLogSlaveAttrs = []
            for sCtrl in sCtrls:

                bAlreadyTakenCareOf = False
                for sConnectedT in sConnectedTransformsLong:
                    if sCtrl.startswith('%s|' % sConnectedT):
                        bAlreadyTakenCareOf = True
                        break

                if not bAlreadyTakenCareOf:
                    sSlaveAttr = '%s.v' % sCtrl
                    while True:
                        if cmds.getAttr(sSlaveAttr, settable=True):
                            break
                        else:
                            _sCtrl = sSlaveAttr.split('.')[0]
                            _sParents = cmds.listRelatives(_sCtrl, p=True)
                            if not _sParents:
                                raise Exception('no vis attribute found for "%s"' % sCtrl)
                            else:
                                sSlaveAttr = '%s.v' % _sParents[0]
                    sLogSlaveAttrs.append(sSlaveAttr)
                    cmds.connectAttr(sMasterAttr, sSlaveAttr)
                    sConnectedTransformsLong.append(cmds.ls(sSlaveAttr.split('.')[0], l=True)[0])

            if bUnreal and False:
                sCtrlChildren = cmds.listRelatives(sCtrls, c=True, ad=True) or []
                sAllCtrlShortNames = [sC.split('|')[-1] for sC in sCtrls+sCtrlChildren]
                sIntersectedUnrealCtrls = set(sAllCtrlShortNames).intersection(sCreatedUnrealCtrls)
                if sIntersectedUnrealCtrls:
                    if sMasterCtrl in sCreatedUnrealCtrls:
                        sUnrealMasterCtrl = sMasterCtrl
                    else:
                        sUnrealMasterCtrl = dUnrealCtrlMapper[sMasterCtrl]
                    sCommands.append('controllers.setNewColumn()')
                    sCommands.append("functions.createVisAttrFunction('%s', '%s', %s, bDefault=%s)" % (sA, sUnrealMasterCtrl, sorted(sIntersectedUnrealCtrls), bDefault))
                    report.report.addLogText('Connected %d Ctrls for "%s" (%s)' % (len(sLogSlaveAttrs), sMasterAttr, utils.listToString(sLogSlaveAttrs, iMaxCount=5)))

    sCommands.append("controllers.closeCommentBox('Ctrl Visibilities')")
    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()

    return bReturn
