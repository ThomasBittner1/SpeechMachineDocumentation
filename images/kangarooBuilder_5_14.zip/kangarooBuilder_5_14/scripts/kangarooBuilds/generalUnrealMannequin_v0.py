###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np
import pickle
import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.constraints as constraints

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.ctrls2 as ctrls2
import kangarooTabTools.ctrls3 as ctrls3
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal
import kangarooTabTools.blendShapes as blendShapes
import kangarooTools.utilsUnreal as utilsUnreal

from collections import defaultdict

kBuilderColor = '#39a9f4'


@builderTools.addToBuild(iOrder=-1001)
def reloadLibraries():
    for module in [utils, nodes, match, puppetTools, segmentsTools, ctrls, ctrls2, ctrls3, ctrls4, sliderCtrls, weights, xforms, curves, patch,
                   deformers, interpolator, geometry, export, unreal, constraints, blendShapes, utilsUnreal]:
        print('reloading %s' % module.__name__)
        report.report.addLogText('reloading %s' % module.__name__)
        utils.reload2(module)

        try:
            import kangarooTabTools.blendShapesPro as blendShapesPro
            utils.reload2(blendShapesPro)

        except:
            report.report.addLogText ('skipping controlRig import')


@builderTools.addToBuild(iOrder=-1000)
def newScene(bAscii=True):
    cmds.file(new=True, f=True)
    sFilePath = os.path.expanduser('~/newScene.%s' % 'ma' if bAscii else 'mb')
    cmds.file(rename=sFilePath)
    cmds.file(save=True, typ='mayaAscii' if bAscii else 'mayaBinary')


@builderTools.addToBuild(iOrder=-100)
def createTopGroups(iModelVisDefault=1, iRigVisDefault=0, iSkeletonVisDefault=1):
    assets.createTopGroups(iModelVisDefault=iModelVisDefault, iRigVisDefault=iRigVisDefault, iSkeletonVisDefault=iSkeletonVisDefault)

    utils.data.store('sBuildingAsset', [assets.getCurrentProject(), assets.assetManager.getCurrentAsset()])
    utils.data.store('bAllSplitAttachersTakeLocals', True)


@builderTools.addToBuild(iOrder=1005)
def setTopGroupAttributes(iModelVisDefault=2, iRigVisDefault=0, iSkeletonVisDefault=0):
    cmds.setAttr('%s.modelVis' % (utils.getMasterName()), iModelVisDefault)
    cmds.setAttr('%s.rigVis' % (utils.getMasterName()), iRigVisDefault)
    cmds.setAttr('%s.skeletonVis' % (utils.getMasterName()), iSkeletonVisDefault)




def checkClashingNames():
    sAllNewNodes = cmds.ls(dag=True)
    sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
    if sClashingNodes:
        print('---CLASHING NODES---')
        for sN in sClashingNodes:
            print(sN)
        cmds.select(sClashingNodes)
    else:
        print('no clashing nodes')


@builderTools.addToBuild(iOrder=-10, dButtons={'find clashing nodes in scene': checkClashingNames})
def importModel(bCheckClashingNames=True, sAsset='__self__', sVersion='__latest__'):
    sModelPath = assets.assetManager.getModelPath(sAsset, sVersion)
    report.report.addLogText('importing from path: %s' % sModelPath)
    if sModelPath:
        sSelBefore = cmds.ls(sl=True)
        sFilesNames = utils.listFilesInFolder(sModelPath,
                                              sEndswith=['.ma', '.MA', '.mb', '.MB', '.obj', '.OBJ', '.fbx', '.FBX', '.abc'])
        report.report.addLogText('found files: %s' % ', '.join(sFilesNames))
        sFiles = [os.path.join(sModelPath, sF) for sF in sFilesNames]

        sNewNodes = utils.importMayaFiles(sFiles)
        if not sNewNodes:
            report.report.addLogText('nothing got imported!')
            return
        if bCheckClashingNames:
            sAllNewNodes = sNewNodes + cmds.listRelatives(sNewNodes, ad=True, f=True)
            sAllNewNodes = cmds.ls(sAllNewNodes)
            sClashingNodes = [sN for sN in sAllNewNodes if '|' in sN]
            if sClashingNodes:
                print('---CLASHING NODES---')
                report.report.addLogText('clashing nodes')
                for sN in sClashingNodes:
                    print(sN)
                    report.report.addLogText(sN)

                raise Exception('clashing nodes, check script editor')

        if cmds.objExists('model'):
            [cmds.lockNode(sN, lock=False) for sN in sNewNodes]
            cmds.parent(sNewNodes, 'model')
        for sNode in cmds.listRelatives(sNewNodes, ad=True, typ='transform', f=True) or []:
            if cmds.objectType(sNode) == 'transform':
                try:
                    cmds.setAttr('%s.overrideEnabled' % sNode, False)
                except:
                    pass
        cmds.select(sSelBefore)
    else:
        raise Exception('problem with importing model (%s)' % sModelPath)


@builderTools.addToBuild(iOrder=-8)
def importBlueprints():
    sBlueprintPath = assets.assetManager.getCurrentVersionPath(sSubPath='blueprints.ma')
    print('importing blueprints %s ...' % sBlueprintPath)
    report.report.addLogText('importing blueprint rig: %s' % sBlueprintPath)

    sNewNodes = utils.importMayaFiles([sBlueprintPath])


@builderTools.addToBuild(iOrder=-5)
def importMayaFiles(dSettings={'file.ma':{'sNamespace':'NAMESPACE'}}):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='mayaImport/')

    print('sImportPath: ', sImportPath)

    if os.path.exists(sImportPath):
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.ma', '.mb', '.obj', '.fbx', '.abc'], bAbsolute=True)
        print('sFiles: ', sFiles)
        report.report.resetProgress(len(sFiles))


        if sFiles:
            for sFile in sFiles:
                sFileName = os.path.basename(sFile)
                sNamespace = None
                if sFileName in dSettings:
                    sNamespace = dSettings[sFileName].get('sNamespace', None)
                utils.importMayaFiles(sFile, sNamespace=sNamespace)
        else:
            report.report.addLogText('no files found')
    else:
        print('didn\'t find import path (%s)' % sImportPath)
        report.report.addLogText('\ndidn\'t find import path (%s)' % sImportPath)


@builderTools.addToBuild(iOrder=-5)
def importTargets(bOrderByDateOfModification=True):
    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='targets/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.trg'], bAbsolute=True)
    # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
    print('sFiles: ', sFiles)
    report.report.resetProgress(len(sFiles))

    if sFiles:
        fTimes = [os.path.getmtime(sF) for sF in sFiles]
        if bOrderByDateOfModification:
            aSorted = np.argsort(fTimes)
        else:
            aSorted = np.argsort(sFiles)
        sFiles = np.array(sFiles)[aSorted]

        for sF in sFiles:
            report.report.addLogText('importing %s' % sF)
            export.importTargets(sF)
            report.report.incrementProgress()
    else:
        report.report.addLogText('no files found')


sAvoidUeControlRigLimbs = ['m_global', 'm_cog', 'm_spine', 'l_leg', 'r_leg', 'm_hips', 'm_spine', 'l_clavicle', 'r_clavicle', 'l_arm',
                           'r_arm', 'm_neck', 'm_head', 'l_index', 'l_middle', 'l_ring', 'l_pinky', 'l_thumb', 'r_index', 'r_middle', 'r_ring', 'r_pinky', 'r_thumb',
                           'l_eye', 'r_eye']


@builderTools.addToBuild(iOrder=0)
def buildPuppet(bReloadLimbs=False, sExtraAvoidLimbs=[]):
    sPuppetFile = assets.assetManager.getCurrentVersionPath(sSubPath='puppet.rig')
    dLimbs = puppetDataUtils.getDictListFromFile(sPuppetFile)

    if bReloadLimbs:
        puppetDataUtils.limbsFromFiles(bReload=True)

    puppetTools.buildRig(all=None, xLimbs=[sPuppetFile, dLimbs], sMaster='master',
                         _bClearBeforeBuild=False, _bReloadLimbs=bReloadLimbs, _bFromUI=False, _bBuildUnrealPuppet=True, _sAvoidUeControlRigLimbs=sAvoidUeControlRigLimbs+sExtraAvoidLimbs)

    for sAttr in ['legKneeStretchLFT_ctrl.doubleKnee', 'legKneeStretchRGT_ctrl.doubleKnee', 'armElbowStretchLFT_ctrl.doubleKnee', 'armElbowStretchRGT_ctrl.doubleKnee']:
        if cmds.objExists(sAttr):
            cmds.setAttr(sAttr, 0)




def bindMeshesAutoBind(sIgnoreFiles, bWorldSpaceIfNotMatching, bAlwaysWorldSpace):
    sSel = cmds.ls(sl=True)

    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')

    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles)-set(sIgnoreFiles))
    sFiles.sort(key=lambda x:x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles if sF.startswith('skinCluster__')]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    aFileMeanValues = np.zeros((len(sFiles), 3), dtype='float64')
    dMeshFiles = {}
    for f,sFile in enumerate(sFiles):
        print('\n\n\nsFile: ', sFile)
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)
        with open(sFile, 'rb') as handle:
            loadedDict = pickle.load(handle)

        sKeys = list(loadedDict.keys())
        for sK in sKeys:
            if sK.endswith('_geo'):
                print(sK, ' -> ', loadedDict[sK])
                dMeshFiles[loadedDict[sK]] = sFile
            if 'recreateData' in sK and sK.endswith('_points'):
                aFileMeanValues[f] = np.mean(loadedDict[sK], axis=0)


    for sMesh in sSel:
        if len(deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])):
            continue

        aMeanValue = np.mean(patch.patchFromName(sMesh).getAllPoints(), axis=0)
        aFileDiffs = aFileMeanValues - aMeanValue[np.newaxis,:]
        aLengths = np.linalg.norm(aFileDiffs, axis=-1)
        iMin = np.argmin(aLengths)

        sFile = sFiles[iMin]
        cmds.select(sMesh)
        sLoaded, dSkipped = weights._loadFromFile((sFile,None), iLoadMayaSelection = weights.LoadMayaSelection.loadOntoSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=weights.LoadWorldspace.closestPoints)
        dAllSkipped.update(dSkipped)
        sSkinClusters = deformers.listAllDeformers(sMesh, sFilterTypes=['skinCluster'])
        if sSkinClusters:
            cmds.rename(sSkinClusters[0], sSkinClusters[0].replace('_', ''))

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=50, dButtons={'bind selected meshes with best fitting files':bindMeshesAutoBind})
def loadDeformers(sIgnoreFiles=[], bWorldSpaceIfNotMatching=False, bAlwaysWorldSpace=False):
    deformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    report.report.addLogText('importing from folder %s..' % deformerFolder)
    if not os.path.exists(deformerFolder):
        report.report.addLogText('Deformer Folder "%s" not found' % deformerFolder)
        return False
    sFiles = utils.listFilesInFolder(deformerFolder, bAbsolute=False, sEndswith=['.wts'])
    if sIgnoreFiles:
        regex = re.compile('|'.join(sIgnoreFiles))
        sIgnoreFiles = filter(regex.match, sFiles)
        sFiles = list(set(sFiles) - set(sIgnoreFiles))
    sFiles.sort(key=lambda x: x.startswith('deltaMush'))
    sFiles = [os.path.join(deformerFolder, sF) for sF in sFiles]

    bReturn = None
    dAllSkipped = {}
    report.report.resetProgress(len(sFiles))
    for sFile in sFiles:
        report.report.addLogText(sFile, bRefresh=False, bIncrementProgress=True)

        iLoadWorldspace = weights.LoadWorldspace.ignore
        if bAlwaysWorldSpace:
            iLoadWorldspace = weights.LoadWorldspace.closestPoints
        elif bWorldSpaceIfNotMatching:
            iLoadWorldspace = weights.LoadWorldspace.closestPointsIfTopologyDiffers

        sLoaded, dSkipped = weights._loadFromFile((sFile, None),
                                                  iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection,
                                                  iCheckMissingInfluences=patch.MissingInfluencesOptions.createAndAddMissingInfluencesInScene,
                                                  iLoadWorldspace=iLoadWorldspace)
        dAllSkipped.update(dSkipped)

    if dAllSkipped:
        report.report.addLogText('\n\nskipped: ')
        for sDeformer, sReason in list(dAllSkipped.items()):
            report.report.addLogText('%s: %s' % (sDeformer, sReason))

        bReturn = False
    return bReturn


@builderTools.addToBuild(iOrder=101)
def loadCtrlShapes(bDoColor=True):
    sCtrlShapesDir = assets.assetManager.getCurrentVersionPath()
    sCtrlMasters = [sF.split('.')[0] for sF in os.listdir(sCtrlShapesDir) if sF.endswith('.ctrls')]
    print('sCtrlMasters: ', sCtrlMasters)
    for sMaster in sCtrlMasters:
        if sMaster == 'ctrls' and len(
                sCtrlMasters) > 1:  # we have new ctrl files, but didn't delete the one from old system yet
            continue
        if cmds.objExists(sMaster):
            sFilePath = os.path.join(sCtrlShapesDir, '%s.ctrls' % sMaster)
            report.report.addLogText('loading file: %s' % sFilePath)
            ctrls.loadCtrls(sFile=sFilePath, bDoColor=bDoColor)



@builderTools.addToBuild(iOrder=1000)
def clean(bDeleteThem=False, bDeleteDisplayLayers=False):
    sAllNodes = cmds.ls(et='transform') + cmds.ls(et='joint')
    sOutsideNodes = [sN for sN in sAllNodes if not cmds.listRelatives(sN, p=True)]
    sOutsideNodes = set(sOutsideNodes) - set([utils.getMasterName(), '__faceData__', '__export__', utils.kGeneralDataNode, 'GAMESKELETON'])
    for sN in sOutsideNodes:
        if bDeleteThem:
            if cmds.objExists(sN):
                cmds.delete(sN)
        else:
            try:
                cmds.setAttr('%s.v' % sN, False)
            except: pass

    if bDeleteDisplayLayers:
        for sL in cmds.ls(et='displayLayer'):
            try:
                cmds.delete(sL)
            except:
                pass

        for sObj in cmds.listRelatives('model', ad=True) or []:
            try:
                cmds.setAttr('%s.overrideEnabled' % sObj, False)
            except:
                report.report.addLogText('WARNING - couldn\'t reset override enabled for %s' % sObj)



@builderTools.addToBuild(iOrder=105)
def defaultCtrlAttrDicts():
    sAllCtrls = ctrls.getAllCtrlsInScene(bReturnNames=True)
    report.report.resetProgress(len(sAllCtrls))

    for sCtrl in sAllCtrls:
        report.report.incrementProgress()
        if ctrls.isCtrl(sCtrl):
            cCtrl = ctrls.ctrlFromName(sCtrl)
            cCtrl.setDefaultAttrDict()


@builderTools.addToBuild(iOrder=150)
def goToDefaultPose():
    sCtrls = [sCtrl for sCtrl in cmds.controller(q=True, ac=True)]

    cmds.undoInfo(openChunk=True)
    try:
        for sCtrl in sCtrls:
            sFullAttr = '%s.dDefaultAttrs' % sCtrl
            if cmds.objExists(sFullAttr):
                dDefaultAttrs = eval(cmds.getAttr(sFullAttr))
                for sA, fV in list(dDefaultAttrs.items()):
                    sFullAttr = '%s.%s' % (sCtrl, sA)
                    cmds.setAttr(sFullAttr, fV)
    except:
        raise
    finally:
        cmds.undoInfo(closeChunk=True)



@builderTools.addToBuild(iOrder=1000)
def prepareAnimPicker(sCharacter='FullCharacter'):
    sAnimPicker = cmds.createNode('transform', n='AnimPickerData', p=utils.getMasterName())
    utils.addStringAttr(sAnimPicker, 'character', sCharacter)



@builderTools.addToBuild(iOrder=1010)
def prepareForPublish(bDeleteUnrealModel=True):
    '''

    '''
    # utils.data.store('bVersionFolders', True, sNode=utils.kExportNode)

    cmds.flushUndo()

    sAsset = assets.assetManager.getCurrentAsset()
    sUnrealModel = utils.data.get('sUnrealModel', None)
    if not sUnrealModel:
        bDeleteUnrealModel = False

    import kangarooTools.settings as settings
    ddMasters = {'master':{'sFilename':'RIG_%s_[v].ma' % sAsset,
                           'sExtraFiles': 'fbx/RIG_%s.fbx' % (sAsset),
                           'sDelete':['GAMEMODEL'] if bDeleteUnrealModel else []}}
    utils.data.store('ddMasters', ddMasters, sNode=utils.kExportNode)
    utils.data.store('bSaveInsteadOfExport', True, sNode=utils.kExportNode)

    # dConfirms = {'Did you export FBX?':[('Yes', True),
    #                                   ('No, but I don\'t care.', True),
    #                                   ('Oops.. please cancel', False)]}
    # utils.data.store('dConfirms', dConfirms, sNode=utils.kExportNode)


dButtons = {}



@builderTools.addToBuild(iOrder=90)
def puppetCustomAttachments():
    return constraints.setupAllPuppetCustomAttachments(bRotateByNeighborVerts=True)




def exportFbxButton():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    sAsset = assets.assetManager.getCurrentAsset()

    if not os.path.exists(sPath):
        os.makedirs(sPath)
    sFilePath = os.path.join(sPath, 'GAME_%s.fbx' % sAsset).replace('\\', '/')

    report.report.incrementProgress()


    # unreal
    bUnrealExists = cmds.objExists('GAMESKELETON')
    if not bUnrealExists:
        report.report.addLogText('====== no unreal rig in scene!!! ======')
        return
    else:
        report.report.addLogText('\nexporting %s' % sFilePath)

    sNodes = ['GAMESKELETON']
    # cmds.parent(sNodes, w=True)

    sAllConnections = []
    report.report.addLogText('temporarily unplugging connections..', bRefresh=True, bIncrementProgress=True)
    try:
        for sNode in cmds.listRelatives('GAMESKELETON', ad=True, typ='joint'):
            sConnections = cmds.listConnections(sNode, s=True, d=False, p=True, c=True) or []
            for i in range(0,len(sConnections),2):
                cmds.disconnectAttr(sConnections[i+1], sConnections[i])
            sAllConnections += sConnections

        report.report.addLogText('exporting..', bRefresh=True, bIncrementProgress=True)
        for sN in cmds.ls(sNodes, dag=True):
            cmds.setAttr('%s.overrideEnabled' % sN, False)
            cmds.setAttr('%s.v' % sN, True)
        cmds.select(sNodes)

        sExportString = 'FBXExport -f "%s" -FBXExportSmoothingGroups True -s' % sFilePath.replace('\\', '/')
        mel.eval('FBXResetExport')
        mel.eval(sExportString)
    except:
        raise
    finally:
        for i in range(0,len(sAllConnections),2):
            cmds.connectAttr(sAllConnections[i+1], sAllConnections[i])
        # utils.parentTo(sNodes, utils.getMasterName())
        [cmds.setAttr('%s.v' % sNode, False) for sNode in sNodes]




def explorerFbx():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    utils.openExplorer(sPath)



def connectControlsToGameRig(sTestNamespace):
    cmds.setAttr('legGlobalLFT_ctrl.fk2ik', 0.0)
    cmds.setAttr('legGlobalRGT_ctrl.fk2ik', 0.0)
    ssPairs = [
        ('game:spine_01', 'spineA_ctrl'),
        ('game:spine_02', 'spineB_ctrl'),
        ('game:spine_03', 'spineC_ctrl'),
        ('game:spine_04', 'spineD_ctrl'),
        ('game:hand_r', 'armWristChildRGT_ctrl'),
        ('game:hand_r', 'armWristChildRGT_ctrl'),
        ('game:clavicle_l', 'clavicleLFT_ctrl'),
        ('game:upperarm_l', 'armUpperChildLFT_ctrl'),
        ('game:lowerarm_l', 'armElbowChildLFT_ctrl'),
        ('game:hand_l', 'armWristChildLFT_ctrl'),
        ('game:clavicle_r', 'clavicleRGT_ctrl'),
        ('game:upperarm_r', 'armUpperChildRGT_ctrl'),
        ('game:lowerarm_r', 'armElbowChildRGT_ctrl'),
        ('game:hand_r', 'armWristChildRGT_ctrl'),
        ('game:neck_01', 'neckA_ctrl'),
        ('game:neck_02', 'neckB_ctrl'),
        ('game:head', 'head_ctrl'),
        ('game:thigh_l', 'legUpperLFT_ctrl'),
        ('game:calf_l', 'legKneeLFT_ctrl'),
        ('game:foot_l', 'legAnkleLFT_ctrl'),
        ('game:ball_l', 'legToesFKLFT_ctrl'),
        ('game:thigh_r', 'legUpperRGT_ctrl'),
        ('game:calf_r', 'legKneeRGT_ctrl'),
        ('game:foot_r', 'legAnkleRGT_ctrl'),
        ('game:ball_r', 'legToesFKRGT_ctrl'),
    ]
    for sGame, sMaya in ssPairs:
        sSkipTranslate = []
        sSkipRotate = []
        for sA in ['x','y','z']:
            if cmds.getAttr('%s.translate%s' % (sMaya, sA.upper()), lock=True):
                sSkipTranslate.append(sA)
            if cmds.getAttr('%s.rotate%s' % (sMaya, sA.upper()), lock=True):
                sSkipRotate.append(sA)

        cmds.parentConstraint(sGame, sMaya, mo=True, skipTranslate=sSkipTranslate, skipRotate=sSkipRotate)


    for sGameJoint, _ in ssPairs:
        sAnimated = '%s%s' % (sTestNamespace, sGameJoint.split(':')[-1])
        cmds.parentConstraint(sAnimated, sGameJoint)



sUnrealHelpers = ['ankle_bck_l', 'ankle_bck_r', 'ankle_fwd_l', 'ankle_fwd_r', 'calf_correctiveRoot_l', 'calf_correctiveRoot_r', 'clavicle_out_l', 'clavicle_out_r',
                  'clavicle_pec_l', 'clavicle_pec_r', 'clavicle_scap_l', 'clavicle_scap_r', 'lowerarm_correctiveRoot_l', 'lowerarm_correctiveRoot_r', 'spine_04_latissimus_l',
                  'spine_04_latissimus_r', 'thigh_bck_l', 'thigh_bck_lwr_l', 'thigh_bck_lwr_r', 'thigh_bck_r', 'thigh_fwd_l', 'thigh_fwd_lwr_l', 'thigh_fwd_lwr_r',
                  'thigh_fwd_r', 'thigh_in_l', 'thigh_in_r', 'thigh_out_l', 'thigh_out_r', 'upperarm_bck_l', 'upperarm_bck_r', 'upperarm_bicep_l', 'upperarm_bicep_r',
                  'upperarm_fwd_l', 'upperarm_fwd_r', 'upperarm_in_l', 'upperarm_in_r', 'upperarm_out_l', 'upperarm_out_r', 'upperarm_tricep_l', 'upperarm_tricep_r',
                  'wrist_inner_l', 'wrist_inner_r', 'wrist_outer_l', 'wrist_outer_r', 'upperarm_twistCor_01_l', 'upperarm_twistCor_02_l', 'upperarm_twistCor_01_r', 'upperarm_twistCor_02_r',
                  'upperarm_correctiveRoot_l', 'upperarm_correctiveRoot_r', 'thigh_correctiveRoot_l', 'thigh_correctiveRoot_r']

@builderTools.addToBuild(iOrder=130, bDisableByDefault=True, dButtons={'export FBX':exportFbxButton, 'explorer FBX':explorerFbx,
                                                                       'Print ThomasRiggingNode code':unreal.printAllThomasBittnerRiggingNodeCode,
                                                                       'Connect Maya Ctrls to GAME Rig':connectControlsToGameRig})
def create_GAMESKELETON(bConnectBlendShapeAnim=False, bDeleteUnrealHelpers=True, bConnectJoints=True, bCheckDeformerFiles=False, bExtraJoints=True, bIgnoreNonBoundJoints=True):
    xxMapData = getMetahumanMapData()
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        sNamespacedUnreal = 'game:%s' % sUnreal
        if not cmds.objExists(sKangaroo):
            if cmds.objExists(sNamespacedUnreal):
                pass
        else:
            if bPosition:
                cmds.delete(cmds.pointConstraint(sKangaroo, sNamespacedUnreal))
            if xRotation:
                fAim, fUp = xRotation
                sTempAim = xforms.createLocator('tempAim', sParent=sKangaroo, xPos=[1,0,0])
                sTempUp = xforms.createLocator('tempUp', sParent=sKangaroo, xPos=[0,1,0])
                cmds.delete(cmds.aimConstraint(sTempAim, sNamespacedUnreal, wut='object', wuo=sTempUp, aim=fAim, u=fUp))
                cmds.delete(sTempAim, sTempUp)
                cmds.makeIdentity(sNamespacedUnreal, r=True, apply=True)

            if cmds.objectType(sNamespacedUnreal) == 'joint' and cmds.objectType(sKangaroo) == 'joint':
                xforms.matchRadius(sNamespacedUnreal, sKangaroo)

    dUnrealJoints = getInitialUnrealJoints()
    if bExtraJoints:
        # extra limb joints
        sAllJoints = cmds.ls('grp_jnt_m_cog_SCALE_skeleton', dag=True, et='joint', l=True)
        sAllJoints = sorted(sAllJoints, key=lambda a:len(a))
        for sFullJ in sAllJoints:
            sJ = sFullJ.split('|')[-1]
            if sJ not in dUnrealJoints:
                if bIgnoreNonBoundJoints and not cmds.attributeQuery('_forceKeepForGames_', node=sJ, exists=True):
                    if not cmds.listConnections(sJ, t='dagPose'): # not cmds.listRelatives(sJ, c=True) and not
                        continue

                sParent = sJ
                for i in range(10):
                    sParent = cmds.listRelatives(sParent, p=True)[0]
                    if sParent in dUnrealJoints:
                        sUnrealParent = 'game:%s' % dUnrealJoints[sParent]
                        break

                sDuplJ = cmds.duplicate(sJ, parentOnly=False if sJ in ['jnt_l_eyeTransform', 'jnt_r_eyeTransform'] else True)[0]
                cmds.parent(sDuplJ, sUnrealParent)
                sDuplJ = cmds.rename(sDuplJ, 'game:%s' % sJ)
                sDuplChildren = cmds.listRelatives(sDuplJ, ad=True, f=True) or []
                sDuplChildren = sorted(sDuplChildren, key=lambda a:len(a), reverse=True)
                for sChild in sDuplChildren:
                    cmds.rename(sChild, 'game:%s' % sChild.split('|')[-1])
                sSortedNewJoints = [sFullJ.split('|')[-1] for sFullJ in sorted(cmds.ls(sDuplJ, dag=True, et='joint'), key=lambda a:len(a))] # those are game:... joints
                for sJ in sSortedNewJoints:
                    cmds.delete(cmds.parentConstraint(sJ.split(':')[-1], sJ))
                for sJ in sSortedNewJoints:
                    dUnrealJoints[sJ.split(':')[-1]] = sJ.split(':')[-1]


    # muscle joints
    sMuscleJoints = [sJ for sJ in cmds.ls('grp_m_muscleJoints', dag=True, et='joint') if not sJ.endswith('End')]
    for sJ in sMuscleJoints:
        sStartSpaceAttr = '%s.startSpace' % sJ
        if not cmds.objExists(sStartSpaceAttr):
            continue
        sStartSpace = cmds.getAttr(sStartSpaceAttr)
        sGameJ = cmds.duplicate(sJ, n='game:%s' % sJ, po=True)[0]
        sUnrealStartSpace = 'game:%s' % dUnrealJoints[sStartSpace]
        cmds.parent(sGameJ, sUnrealStartSpace)
        dUnrealJoints[sJ] = sJ

    sMuscles = [sJ for sJ in cmds.ls('game:muscleJnt_*', et='joint') if not sJ.endswith('End')]
    for sJ in sMuscles:
        sParent = 'game:%s' % dUnrealJoints[cmds.getAttr('%s.startSpace' % sJ)]
        sCurrentParent = cmds.listRelatives(sJ, p=True)[0]
        if sParent != sCurrentParent:
            cmds.parent(sJ, sParent)


    if bConnectJoints:
        sConstrainedUnrealJoints = set()
        for sKangarooJ in sorted(dUnrealJoints.keys(), key=lambda a:len(a)):
            sUnrealJ = dUnrealJoints[sKangarooJ]
            sUnrealFullJ = 'game:%s' % sUnrealJ
            if cmds.objExists(sUnrealFullJ) and cmds.objExists(sKangarooJ):
                if sUnrealFullJ not in sConstrainedUnrealJoints:
                    xforms.matrixParentConstraint(sKangarooJ, sUnrealFullJ, mo=True)
                    sConstrainedUnrealJoints.add(sUnrealFullJ)


    def _getUnrealJoint(sJoint):
        if sJoint in dUnrealJoints:
            return 'game:%s' % dUnrealJoints[sJoint]
        else:
            sLeftOverJoint = 'game:jnt_leftOverJointThatShouldntBeThere'
            if not cmds.objExists(sLeftOverJoint):
                cmds.createNode('joint', n=sLeftOverJoint, p='game:root')
            return sLeftOverJoint


    cmds.rename('game:SKM_Manny', 'GAMESKELETON')
    # utils.parentTo('GAMESKELETON', utils.getMasterName())
    utils.parentToWorld('GAMESKELETON')
    if bDeleteUnrealHelpers:
        for sJ in sUnrealHelpers:
            sNamespacedJ = 'game:%s' % sJ
            if cmds.objExists(sNamespacedJ):
                cmds.delete(sNamespacedJ)

    # switch off deformers for duplicate
    dPrevSkinClusterStates = {}
    dPrevBlendShapeStates = {}
    sBlendshapeMeshes = []

    report.report.addLogText('Duplicate the models...', bRefresh=True)


    report.report.incrementProgress()
    for sMesh in utils.listMeshes('model'):
        sDeformers = deformers.listAllDeformers(sMesh)
        for sD in sDeformers:
            if cmds.objectType(sD) == 'skinCluster':
                dPrevSkinClusterStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
            elif cmds.objectType(sD) == 'blendShape':
                dPrevBlendShapeStates['%s.nodeState' % sD] = cmds.getAttr('%s.nodeState' % sD)
                sBlendshapeMeshes.append(sMesh)
            else:
                continue
            cmds.setAttr('%s.nodeState' % sD, 1)

    sBlendshapeMeshes = list(set(sBlendshapeMeshes))


    sUnrealModel = 'GAMEMODEL'
    sUnrealModelChildren = cmds.duplicate('model', n=sUnrealModel)[1:]
    cmds.setAttr('%s.overrideEnabled' % sUnrealModel, False)

    sFullNames = [sN for sN in cmds.ls(sUnrealModelChildren, l=True) if sUnrealModel in sN]
    sFullNames = sorted(sFullNames, key=lambda a: len(a), reverse=True)
    for n,sN in enumerate(sFullNames):
        sName = sN.split('|')[-1]
        sFullNames[n] = cmds.rename(sN, 'game:%s' % sName)

    report.report.resetProgress(len(utils.flattenedList(sFullNames)))
    report.report.addLogText('clean up meshes for lod %s' % 'model')
    for sN in sFullNames:
        report.report.incrementProgress()
        if  cmds.objectType(sN) == 'transform':
            sAllShapes = cmds.listRelatives(sN, s=True, f=True) or []
            sNoIntermShapes = cmds.listRelatives(sN, s=True, ni=True, f=True) or []
            sDeleteShapes = set(sAllShapes) - set(sNoIntermShapes)
            sKeepShapes = set(sAllShapes) - set(sDeleteShapes)
            if sDeleteShapes:
                cmds.delete(list(sDeleteShapes))

            # fix shapes that don't get renamed
            for sS in sKeepShapes:
                sNameS = sS.split('|')[-1]
                if not sNameS.startswith('game:'):
                    cmds.rename(sS, 'game:%s' % sNameS)

    # transfer blendshaes
    sBlendShapesToBake = []

    # set back blendshapes
    [cmds.setAttr(sA,fV) for sA,fV in list(dPrevBlendShapeStates.items())]

    sBlendShapeJoint = cmds.listRelatives('GAMESKELETON', ad=True, typ='joint')[-1]
    for sBody in sBlendshapeMeshes:
        sBlendShapes = deformers.listAllDeformers(sBody, sFilterTypes=['blendShape'])
        if len(sBlendShapes) > 1:
            raise Exception('there are more than one blendShapes for %s' % sBody)

        sBs = sBlendShapes[0]
        sTargetMeshes, sAliases, sSkippedTargets = blendShapes.bake(sBody, sBs, bSkipUnchanged=False)

        report.report.addLogText('\nSkipped %d BlendShape Targets of %d for "%s"' %
                                 (len(sSkippedTargets), len(sSkippedTargets) + len(sTargetMeshes), sBody))
        for sSkippedT in sSkippedTargets:
            report.report.addLogText('Skipped Target "%s"...' % sSkippedT)

        # sSourceAttrs = ['%s.%s' % (sBs,sA) for sA in sAliases]
        sBlendShapesToBake.append(sBs)

        sAliasDupls = utils.getDuplicates(sAliases)
        if sAliasDupls:
            raise Exception('The alias %s appears in more than one blendShapes' % utils.listToString(sAliasDupls))

        sGameBlendShape = cmds.blendShape(sTargetMeshes, 'game:%s' % sBody)[0]
        deformers.makeNotExport(sGameBlendShape)
        # sUnrealTargets = ['%s.%s' % (sGameBlendShape,sT) for sT in blendShapes.getOrderedTargets(sGameBlendShape)]

        if bConnectBlendShapeAnim:
            for t,sT in enumerate(sAliases):
                sSourceAttr = '%s.%s' % (sBs, sT)
                cmds.connectAttr(sSourceAttr, '%s.%s' % (sGameBlendShape, sT))
                sBlendShapeJointAttr = '%s.%s' % (sBlendShapeJoint, sT)
                if not cmds.objExists(sBlendShapeJointAttr):
                    cmds.addAttr(sBlendShapeJoint, ln=sT, k=True)
                    cmds.connectAttr(sSourceAttr, sBlendShapeJointAttr)

        cmds.delete(sTargetMeshes)




    # bind new geometry
    sUnrealMeshes = utils.listMeshes('GAMEMODEL')
    report.report.resetProgress(len(sUnrealMeshes))

    sDeformerFolder = assets.assetManager.getCurrentVersionPath(sSubPath='deformers')
    for sUnrealM in sUnrealMeshes:
        sFileName = 'skinCluster__%s.wts' % sUnrealM.replace(':', '_') # because sUnrealM starts with game:
        sFilePath = os.path.join(sDeformerFolder, sFileName)

        if bCheckDeformerFiles and os.path.exists(sFilePath):
            report.report.addLogText('loading weights for mesh %s..' % sUnrealM, bIncrementProgress=True)
            sLoaded, dSkipped = weights._loadFromFile((sFilePath, None), iLoadMayaSelection=weights.LoadMayaSelection.ignoreSelection)
        else:
            report.report.addLogText('binding mesh %s..' % sUnrealM, bIncrementProgress=True)
            sM = utils.replaceStringStart(sUnrealM, 'game:', '')
            if not cmds.objExists(sM):
                raise Exception('this mesh doesn\'t exist: %s (%s)' % (sM, sUnrealM))
            # pM = patch.patchFromName(sM)
            pUnrealM = patch.patchFromName(sUnrealM)
            sSkinClusters = deformers.listAllDeformers(sM, sFilterTypes=['skinCluster'])
            if sSkinClusters:
                sShortestNameSkinCluster = sorted(sSkinClusters, key=lambda a:len(a))[0] # sorting to have skinCluster with shortest name
                weights.transferSkinCluster([pUnrealM], sFrom=sShortestNameSkinCluster, iMode=weights.TransferMode.vertexIndex, funcMapJoint=_getUnrealJoint, bLogReport=False, bPostNormalize=True)


    # set back skinClusters
    [cmds.setAttr(sA,fV) for sA,fV in list(dPrevSkinClusterStates.items())]



    cmds.parent('GAMEMODEL', 'GAMESKELETON')
    # cmds.setAttr('GAMEMODEL.v', False)
    cmds.setAttr('GAMESKELETON.v', False)

    utils.data.store('dUnrealJoints', dUnrealJoints)


def getMetahumanMapData():
    xxMapData = []
    xxMapData.append(['jnt_r_armWrist', 'ik_hand_gun', True, None])
    xxMapData.append(['jnt_l_armWrist', 'ik_hand_l', True, None])
    xxMapData.append(['jnt_l_legWrist', 'ik_foot_l', True, None])
    xxMapData.append(['jnt_m_hips', 'pelvis', True,  [(0,0,-1),(1,0,0)]])
    xxMapData.append(['jnt_l_leg_upperTwist_000', 'thigh_l', True, [(-1,0,0),(0,1,0)]])
    xxMapData.append(['jnt_l_leg_upperTwist_001', 'thigh_twist_01_l', True, None])
    xxMapData.append(['jnt_l_leg_upperTwist_002', 'thigh_twist_02_l', True, None])
    xxMapData.append(['jnt_l_leg_lowerTwist_000', 'calf_l', True, [[-1,0,0], [0,1,0]]])
    xxMapData.append(['jnt_l_leg_lowerTwist_001', 'calf_twist_01_l', True, None])
    xxMapData.append(['jnt_l_leg_lowerTwist_002', 'calf_twist_02_l', True, None])
    xxMapData.append(['jnt_l_legWrist', 'foot_l', True, None])
    xxMapData.append(['jnt_l_legFingers', 'ball_l', True, None])
    xxMapData.append(['jnt_m_spineSpine_000', 'spine_01', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_001', 'spine_02', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_002', 'spine_03', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_003', 'spine_04', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_spineSpine_end', 'spine_05', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_clavicleMain', 'clavicle_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_upperTwist_000', 'upperarm_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_upperTwist_001', 'upperarm_twist_01_l', True, None])
    xxMapData.append(['jnt_l_arm_upperTwist_002', 'upperarm_twist_02_l', True, None])
    xxMapData.append(['jnt_l_arm_lowerTwist_000', 'lowerarm_l', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_l_arm_lowerTwist_001', 'lowerarm_twist_01_l', True, None])
    xxMapData.append(['jnt_l_arm_lowerTwist_002', 'lowerarm_twist_02_l', True, None])
    xxMapData.append(['jnt_l_armWrist', 'hand_l', True, [(1,0,0), (0,0,-1)]])
    xxMapData.append(['jnt_m_neckSpine_000', 'neck_01', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_neckSpine_001', 'neck_02', True, [(1,0,0),(0,-1,0)]])
    xxMapData.append(['jnt_m_headMain', 'head', True, [(1,0,0),(0,1,0)]])
    xxMapData.append(['ctrl_l_legHeelOut', 'heel_l', True, [(0,0,1),(0,1,0)]])
    xxMapData.append(['ctrl_l_legToesRevOut', 'tip_l', True, [(0,0,1),(0,1,0)]])

    sKangarooFingerBones = ['jnt_l_%sMeta', 'jnt_l_%sBase', 'jnt_l_%sMid', 'jnt_l_%sTip']
    sUnrealFingerBones = ['%s_metacarpal_l', '%s_01_l', '%s_02_l', '%s_03_l']
    for sFinger in ['thumb', 'index', 'middle', 'ring', 'pinky']:
        for sKangaroPattern, sUnrealPattern in zip(sKangarooFingerBones, sUnrealFingerBones[1:] if sFinger == 'thumb' else sUnrealFingerBones):
            sKangarooJoint = sKangaroPattern % sFinger
            sUnrealJoint = sUnrealPattern % sFinger
            if cmds.objExists('game:%s' % sUnrealJoint):
                xxMapData.append([sKangarooJoint, sUnrealJoint, True, [(1, 0, 0), (0, -1, 0)]])

    xxRightData = []
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        if utils.getSide(sKangaroo) == 'l':
            xxRightData.append([utils.getMirrorName(sKangaroo), utils.replaceStringEnd(sUnreal, '_l', '_r'), bPosition, xRotation])
    xxMapData += xxRightData

    return xxMapData




def getInitialUnrealJoints():
    xxMapData = getMetahumanMapData()
    xxExtraSkinData = []
    for sKangaroo, sUnreal, bPosition, xRotation in xxMapData:
        sAttr = '%s.segmentsData' % sKangaroo
        if cmds.objExists(sAttr):
            dSegmentsData = eval(cmds.getAttr(sAttr)) # {'sSearchReplace': 'Spine;SpineSquash'}";
            sSearchReplace = dSegmentsData.get('sSearchReplace', None)
            if not utils.isNone(sSearchReplace):
                sSearch, sReplace = sSearchReplace.split(';')
                if sSearch in sKangaroo:
                    sReplacedJoint = sKangaroo.replace(sSearch, sReplace)
                    if cmds.objExists(sReplacedJoint):
                        xxExtraSkinData.append([sReplacedJoint, sUnreal, bPosition, xRotation])
    # xxExtraSkinData.append(['jnt_l_thumbMeta', 'hand_l', None, None])
    # xxExtraSkinData.append(['jnt_r_thumbMeta', 'hand_r', None, None])
    xxMapData += xxExtraSkinData

    return {sKangaroo: sUnreal for sKangaroo, sUnreal, bPosition, xRotation in xxMapData}


@builderTools.addToBuild(iOrder=-3)
def pythonStartFile(sForwardFunction=None, sBackwardsFunction=None):

    sInitiateSequencerString = "controllers.__iCurrentSolver__ = %d\nnodes.createSequencer()\nnodes.newSequencerPlug(bForce=True)  # we'll just leave an empty slot at the beginning to maybe connect some test control in there"

    sUnrealCodeLines = []

    if sForwardFunction:
        sUnrealCodeLines.append("nodes.startFunction('%s')" % sForwardFunction)
        utils.data.store('pythonStartedFunction', True)



    sUnrealCodeLines.append(sInitiateSequencerString % 0)

    utils.data.store(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True)

    utils.data.store(utilsUnreal.kUnrealMocapCodeLines, [sInitiateSequencerString % 0])
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True, sKey=utilsUnreal.kUnrealMocapCodeLines)


    sUnrealBackwardsCodeLines = []
    sUnrealBackwardsCodeLines.append('\n\n')
    sUnrealBackwardsCodeLines.append(sInitiateSequencerString % 2)
    sUnrealBackwardsCodeLines.append(kAddBackwardsCtrlInitiations)
    sUnrealBackwardsCodeLines.append('\n\n')
    sUnrealBackwardsCodeLines.append("try: nodes.createBackwardsEvent()")
    sUnrealBackwardsCodeLines.append("except: print ('backwardsEvent seems to already exist')")
    if sBackwardsFunction:
        sUnrealBackwardsCodeLines.append("nodes.startFunction('%s')" % sBackwardsFunction)
        utils.data.store('pythonStartedFunctionBackwards', True)


    utils.data.store(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True, sKey=utilsUnreal.kUnrealBackwardsCodeLines)


kAddBackwardsCtrlInitiations = '#Add Backwards Ctrl Initiations..'

@builderTools.addToBuild(iOrder=2)
def initiateCtrlsInBackwards(bReloadLimbs=False, sExtraAvoidLimbs=[]):
    sCommands = ['\n\n#Initiate created ctrls']

    sCreatedCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    for sCtrl in sCreatedCtrls:
        sCommands.append("%s = hierarchy.Ctrl().initFromExisting('%s')" % (sCtrl, sCtrl))

    # utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sCommands)
    # utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)

    sFilePath = utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)
    if utils.isTextInFile(sFilePath, kAddBackwardsCtrlInitiations):
        utils.searchReplaceFile(sFilePath, kAddBackwardsCtrlInitiations, '\n'.join(sCommands))
    else:
        raise Exception ('no place found to add the code lines')



@builderTools.addToBuild(iOrder=-2)
def pythonTwistJointsEntry():
    sCommands = ['# Twist Joints']

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=130.3)
def pythonCreateTwistJoints():
    sCommands = ['# Twist Joints']
    sCommands.append("nodes.startFunction('kangaroo_twistJoints')")
    sCommands.append("nodes.newSequencerPlug()")

    sLeaves = [sJ.split(':')[-1] for sJ in sorted(cmds.ls('game:upperarm_twist_??_l', et='joint'))]
    ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fAimVector, fDefaultNormalizedElbow = utilsUnreal.getTwistInfo('l_arm', 'jnt_l_arm_upperTwist_000', 'game:upperarm_l', 'game:lowerarm_l')
    sCommands.append("functions.twistUpper('upperarm_l', 'clavicle_l', 'lowerarm_l', %s, ffNoTwistParentMatrix=%s, sPlaneAxis='%s', fUpperUpVector=%s, fUpperUpVectorGameJoint=%s, fDefaultNormalizedElbow=%s, fAimVector=%s)" %
                     (str(sLeaves), ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fDefaultNormalizedElbow, fAimVector))

    sCommands.append("controllers.setNewColumn()")
    sLeaves = [sJ.split(':')[-1] for sJ in sorted(cmds.ls('game:upperarm_twist_??_r', et='joint'))]
    ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fAimVector, fDefaultNormalizedElbow = utilsUnreal.getTwistInfo('r_arm', 'jnt_r_arm_upperTwist_000', 'game:upperarm_r', 'game:lowerarm_r')
    sCommands.append("functions.twistUpper('upperarm_r', 'clavicle_r', 'lowerarm_r', %s, ffNoTwistParentMatrix=%s, sPlaneAxis='%s', fUpperUpVector=%s, fUpperUpVectorGameJoint=%s, fDefaultNormalizedElbow=%s, fAimVector=%s)" %
                     (str(sLeaves), ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fDefaultNormalizedElbow, fAimVector))

    sCommands.append("controllers.setNewColumn()")
    sLeaves = [sJ.split(':')[-1] for sJ in sorted(cmds.ls('game:thigh_twist_??_l', et='joint'))]
    ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fAimVector, fDefaultNormalizedElbow = utilsUnreal.getTwistInfo('l_leg', 'jnt_l_leg_upperTwist_000', 'game:thigh_l', 'game:calf_l')
    sCommands.append("functions.twistUpper('thigh_l', 'pelvis', 'calf_l', %s, ffNoTwistParentMatrix=%s, sPlaneAxis='%s', fUpperUpVector=%s, fUpperUpVectorGameJoint=%s, fDefaultNormalizedElbow=%s, fAimVector=%s)" %
                     (str(sLeaves),ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fDefaultNormalizedElbow, fAimVector))

    sCommands.append("controllers.setNewColumn()")
    sLeaves = [sJ.split(':')[-1] for sJ in sorted(cmds.ls('game:thigh_twist_??_r', et='joint'))]
    ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fAimVector, fDefaultNormalizedElbow = utilsUnreal.getTwistInfo('r_leg', 'jnt_r_leg_upperTwist_000', 'game:thigh_r', 'game:calf_r')
    sCommands.append("functions.twistUpper('thigh_r', 'pelvis', 'calf_r', %s, ffNoTwistParentMatrix=%s, sPlaneAxis='%s', fUpperUpVector=%s, fUpperUpVectorGameJoint=%s, fDefaultNormalizedElbow=%s, fAimVector=%s)" %
                     (str(sLeaves),ffUpperOffsetMatrix, sPlaneAxis, fUpperUpVector, fUpperUpVectorGameJoint, fDefaultNormalizedElbow, fAimVector))

    sCommands.append("controllers.setNewColumn()")
    sLeaves = [sJ.split(':')[-1] for sJ in sorted(cmds.ls('game:lowerarm_twist_??_l', et='joint'))]
    sCommands.append("functions.twistLower('hand_l', %s)" % str(sLeaves))
    sCommands.append("controllers.setNewColumn()")
    sLeaves = [sJ.split(':')[-1] for sJ in sorted(cmds.ls('game:lowerarm_twist_??_r', et='joint'))]
    sCommands.append("functions.twistLower('hand_r', %s)" % str(sLeaves))

    sCommands.append("nodes.endCurrentFunction()")
    # sCommands.append("nodes.newSequencerPlug()")

    # sCommands.append("nodes.addFunctionNode('twistJoints')")

    # anim rig file
    sFilePath = utilsUnreal.createOutFilePath()
    if utils.isTextInFile(sFilePath, sCommands[0]):
        utils.searchReplaceFile(sFilePath, sCommands[0], '\n'.join(sCommands))
    else:
        utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile()

    # rokoko file
    sFilePath = utilsUnreal.createOutFilePath(utilsUnreal.kUnrealMocapCodeLines)
    if utils.isTextInFile(sFilePath, sCommands[0]):
        utils.searchReplaceFile(sFilePath, sCommands[0], '\n'.join(sCommands))
    else:
        utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)


@builderTools.addToBuild(iOrder=130.15)
def pythonBlendJoints():
    sBlendJoints = [sJ for sJ in cmds.ls('game:*Blend', et='joint') if cmds.attributeQuery('blendFrom', node=sJ, exists=True)]
    if sBlendJoints:
        sFromJoints = [cmds.getAttr('%s.blendFrom' % sJ) for sJ in sBlendJoints]
        sToJoints = [cmds.getAttr('%s.blendTo' % sJ) for sJ in sBlendJoints]
        sCommands = ['\n\n# Blend Joints']

        sCommands.append("functions.blendJoints(%s)" % list(zip([sJ.split(':')[-1] for sJ in sBlendJoints], sFromJoints, sToJoints)))

        utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=130.1)
def pythonMuscleJoints():
    dUnrealJoints = utils.data.get('dUnrealJoints')
    sCommands =['# Muscle Joints']
    sCommands.extend(utilsUnreal.generateMuscleJointsCode(dUnrealJointsMapper=dUnrealJoints, bPieceLines=True))
    # anim rig file
    sFilePath = utilsUnreal.createOutFilePath()
    if utils.isTextInFile(sFilePath, sCommands[0]):
        utils.searchReplaceFile(sFilePath, sCommands[0], '\n'.join(sCommands))
    else:
        utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile()

    # rokoko file
    sFilePath = utilsUnreal.createOutFilePath(utilsUnreal.kUnrealMocapCodeLines)
    if utils.isTextInFile(sFilePath, sCommands[0]):
        utils.searchReplaceFile(sFilePath, sCommands[0], '\n'.join(sCommands))
    else:
        utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)


@builderTools.addToBuild(iOrder=130.11)
def pythonSortLimbs():
    sFilePath = utilsUnreal.createOutFilePath()

    with open(sFilePath) as sText:
        sAllLines = list(sText)
        dAllPieces = []
        i = -1
        while True:
            i += 1
            if i >= len(sAllLines):
                break
            if '# PIECE.START' in sAllLines[i]:
                print ('piece start: ', sAllLines[i])
                sName = sAllLines[i].split(':')[-1].strip()
                dNewPiece = {'sName':sName, 'sInputs':[], 'sOutputs':[]}
                for k in range(i+1, len(sAllLines), 1):
                    if sAllLines[k].startswith('# PIECE.INPUTS'):
                        sInputs = eval(sAllLines[k].split(':')[-1])
                        dNewPiece['sInputs'].extend(sInputs)
                    elif sAllLines[k].startswith('# PIECE.OUTPUTS'):
                        sString = sAllLines[k].split(':')[-1]
                        sInputs = eval(sString)
                        dNewPiece['sOutputs'].extend(sInputs)
                    elif sAllLines[k].startswith('# PIECE.END'):
                        dNewPiece['iLineRange'] = [i,k+1]
                        dAllPieces.append(dNewPiece)
                        i = k
                        break


    for i,dPiece in enumerate(dAllPieces):
        dPiece['sInputs'] = set(dPiece['sInputs'])
        dPiece['sOutputs'] = set(dPiece['sOutputs'])
        dAllPieces[i] = dPiece


    iOrder = list(range(len(dAllPieces)))
    for iCount in range(len(dAllPieces)): # until we don't have to anymore
        bDidSomething = False
        for i in range(len(iOrder)):
            iInd = iOrder[i]
            for k in range(len(iOrder)-1, i, -1):
                if dAllPieces[iInd]['sInputs'].intersection(dAllPieces[iOrder[k]]['sOutputs']):
                    report.report.addLogText('moving %s to after %s' % (dAllPieces[iInd]['sName'], dAllPieces[iOrder[k]]['sName']))
                    iOrder.pop(i)
                    iOrder.insert(k, iInd)
                    bDidSomething = True
                    break
        if not bDidSomething:
            break
    report.report.addLogText('sorted %d times' % iCount)

    sAllLinesCopy = list(sAllLines)
    for dPiece in dAllPieces[::-1]:
        print ('removing lines from %s' % dPiece['sName'])
        iRange = dPiece['iLineRange']
        del sAllLines[iRange[0]:iRange[1]]

    sNewLinesChain = []
    for i in range(len(iOrder)):
        iRange = dAllPieces[iOrder[i]]['iLineRange']
        sNewLinesChain.extend(sAllLinesCopy[iRange[0]:iRange[1]])

    iStartLine = dAllPieces[0]['iLineRange'][0]

    sAllLines = sAllLines[:iStartLine] + sNewLinesChain + sAllLines[iStartLine:]
    utils.createTextFile(sFilePath, sAllLines)




@builderTools.addToBuild(iOrder=130.2)
def pythonReplacePuppetJoints():
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sFile = utilsUnreal.createOutFilePath()

    with open(sFile, 'r') as file:
        filedata = file.read()

    for sMayaJoint, sUnrealJoint in dUnrealJoints.items():
        if sMayaJoint != sUnrealJoint:
            filedata = filedata.replace("'%s'" % sMayaJoint, "'%s'" % sUnrealJoint)

    with open(sFile, 'w') as file:
        file.write(filedata)


@builderTools.addToBuild(iOrder=130.11)
def pythonCustomAttachers():
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sFile = utilsUnreal.createOutFilePath()
    sTransforms = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.sPuppetParentAttachment' % sT) and ':' not in sT]
    print ('sTransforms: ', sTransforms)
    ssJoints = [[] for _ in range(len(sTransforms))]
    ffWeights = [[] for _ in range(len(sTransforms))]

    for c,sTransform in enumerate(sTransforms):
        sDecomp = cmds.listConnections('%s.t' % sTransform, s=True, d=False)[0]
        sMatrixMult = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]


        sLoc = cmds.listConnections('%s.matrixIn[1]' % sMatrixMult, s=True, d=False)[0]
        if sLoc.startswith('loc_'):
            sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
            sBlendEnvelope = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]
            sBlendAllInfluencesNode = cmds.listConnections('%s.wtMatrix[0].matrixIn' % sBlendEnvelope, s=True, d=False)[0]

            for j in range(10): # per joint
                sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sBlendAllInfluencesNode, j), s=True, d=False)
                if j == 0:
                    sFirstMatrixConn = sMatrixConns[0]
                if not sMatrixConns:
                    break
                sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sBlendAllInfluencesNode, j))
                ssJoints[c].append(sJoint)
                ffWeights[c].append(fWeight)



    with open(sFile, 'r') as file:
        filedata = file.read()

    for sTransform, sJoints, fWeights in zip(sTransforms, ssJoints, ffWeights):
        sCurrentLine = '# CUSTOMATTACHER %s' % sTransform
        sLines = [sCurrentLine]
        sLines.append(utilsUnreal.createUnrealNull(sTransform, sTransform)[1])
        sUnrealJoints = [dUnrealJoints.get(sJ,sJ) for sJ in sJoints]
        sTargets = ', '.join(["(library.getElementKey('%s', 'Bone'), %0.3f)" % (sJ,fW) for sJ,fW in zip(sUnrealJoints,fWeights)])
        sLines.append("nodes.createParentConstraintExecuteNode([%s], %s, bMaintainOffset=True)" % (sTargets, sTransform))
        sLines.append('# PIECE.INPUTS: %s' % str(sUnrealJoints))
        filedata = filedata.replace(sCurrentLine, '\n'.join(sLines))

    with open(sFile, 'w') as file:
        file.write(filedata)



@builderTools.addToBuild(iOrder=130.4)
def pythonShapeCtrls():
    utilsUnreal.generateControlShapeCode(sSkipLimbs=sAvoidUeControlRigLimbs)


@builderTools.addToBuild(iOrder=130.5)
def pythonInterpolators():
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sUnrealCommands = ['\n\n#UplegUp Interpolators']
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('uplegType', node=sT, exists=True)]
    sMayaHip = 'jnt_m_hips'
    sHip = dUnrealJoints.get(sMayaHip, sMayaHip)


    def _convertSpaceValue(iCurrentAxis, fValues):
        aMayaHipMatrix = utils.getNumpyMatrixFromTransform(sMayaHip)
        aHipMatrix = utils.getNumpyMatrixFromTransform('game:%s' % sHip)
        fPoints4 = [[0,0,0,1], [0,0,0,1]]
        for v,fV in enumerate(fValues):
            fPoints4[v][iCurrentAxis] = fV

        aGlobalPoints4 = np.dot(np.array(fPoints4, dtype='float64'), aMayaHipMatrix)
        aUnrealLocalPoints = np.dot(aGlobalPoints4, np.linalg.inv(aHipMatrix))
        aDiffs = np.abs(aUnrealLocalPoints[1] - aUnrealLocalPoints[0])
        iUnrealAxis = np.argmax(aDiffs)
        aUnrealValues = aUnrealLocalPoints[:,iUnrealAxis]
        if iUnrealAxis == 1:
            aUnrealValues *= -1.0
        return iUnrealAxis, list(aUnrealValues)


    for sInterp in sInterpolators:
        sSide = utils.getSide(sInterp)

        sMayaKnee = 'jnt_%s_leg_lowerTwist_000' % sSide
        sKnee = dUnrealJoints.get(sMayaKnee, sMayaKnee)

        sDrivenKeys = eval(cmds.getAttr('%s.drivenKeys' % sInterp))
        ffLocalPoints = []
        ffValues = []
        # sPoseTargets = []

        iCurrentAxes = [1,0,2]
        iUnrealAxes = []
        for a,sNode in enumerate(sDrivenKeys):
            fValues = cmds.keyframe(sNode, q=True, valueChange=True)
            ffValues.append(fValues)
            fTimes = cmds.keyframe(sNode, q=True, floatChange=True)
            iUnrealAxis, fUnrealTimes = _convertSpaceValue(iCurrentAxes[a], fTimes)
            ffLocalPoints.append(fUnrealTimes)
            iUnrealAxes.append(iUnrealAxis)
            # sAnimCurves = cmds.listConnections('%s.up' % sInterp, s=False, d=True, t='animCurveUL')
            # sTargets = []
            # for sAnimC in sAnimCurves:
            #     sTargetPlugs = cmds.listConnections('%s.output' % sAnimC, s=False, d=True, p=True, t='blendShape') or []
            #     sTargets += [sPlug.split('.')[-1] for sPlug in sTargetPlugs]
            # if not sTargets:
            #     continue
        # sPoseTargets.append(list(set(sTargets))) # it only takes one target currently

        sUnrealCommands.append("%s_up = functions.uplegUpInterpolator('%s', '%s', '%s', iUnrealAxes=%s, ffLocalPoints=%s, ffValues=%s)" % (sInterp, sInterp, sHip, sKnee, iUnrealAxes, ffLocalPoints, ffValues))

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()




    sUnrealCommands = ['\n\n#Angle Interpolators']
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('angleType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoints = eval(cmds.getAttr('%s.sJoints' % sInterp))
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        iCurveTypes = eval(cmds.getAttr('%s.iCurveTypes' % sInterp))
        ffAngleRanges = eval(cmds.getAttr('%s.ffAngleRanges' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        sPoseTargets = []
        sReturns = []
        ffPassRanges = []
        iPassCurveTypes = []
        for p,sPose in enumerate(sPoseNames):
            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue
            # sTargets = []
            # for sAnimC in sAnimCurves:
            #     sTargetPlugs = cmds.listConnections('%s.output' % sAnimC, s=False, d=True, p=True, t='blendShape') or []
            #     sTargets += [sPlug.split('.')[-1] for sPlug in sTargetPlugs]
            # if not sTargets:
            #     continue
            ffPassRanges.append(ffAngleRanges[p])
            # sPoseTargets.append(list(set(sTargets))) # it only takes one target currently
            sReturns.append('%s_%s' % (sInterp, sPose))
            iPassCurveTypes.append(iCurveTypes[p])
        if sReturns:
            sUnrealJoints = [dUnrealJoints.get(sJ, sJ) for sJ in sJoints]
            sUnrealCommands.append("%s = functions.angleInterpolator('%s', %s, %s, iCurveTypes=%s)" %
                                   (', '.join(sReturns), sInterp, str(sUnrealJoints), str(ffPassRanges), iPassCurveTypes))

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()



    sUnrealCommands = ['\n\n#SignedAngle Interpolators']
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('signedAngleType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoints = eval(cmds.getAttr('%s.sJoints' % sInterp))
        sTwist, sParent = sJoints

        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        iCurveTypes = eval(cmds.getAttr('%s.iCurveTypes' % sInterp))
        ffAngleRanges = eval(cmds.getAttr('%s.ffAngleRanges' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        # sPoseTargets = []
        sReturns = []
        ffPassRanges = []
        iPassCurveTypes = []
        for p,sPose in enumerate(sPoseNames):
            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue
            # sTargets = []
            # for sAnimC in sAnimCurves:
            #     sTargetPlugs = cmds.listConnections('%s.output' % sAnimC, s=False, d=True, p=True, t='blendShape') or []
            #     sTargets += [sPlug.split('.')[-1] for sPlug in sTargetPlugs]
            # if not sTargets:
            #     continue
            ffPassRanges.append(ffAngleRanges[p])
            # sPoseTargets.append(list(set(sTargets))) # it only takes one target currently
            sReturns.append('%s_%s' % (sInterp, sPose))
            iPassCurveTypes.append(iCurveTypes[p])
        if sReturns:
            sUnrealCommands.append("%s = functions.signedAngleInterpolator('%s', '%s', '%s', %s, iCurveTypes=%s)" %
                                   (', '.join(sReturns), sInterp, dUnrealJoints.get(sTwist, sTwist), dUnrealJoints.get(sParent, sParent), str(ffPassRanges), iPassCurveTypes))


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


    sUnrealCommands = ['\n\n#Cone Interpolators']
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('coneType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoint = cmds.getAttr('%s.sJoint' % sInterp)
        sUnrealJoint = dUnrealJoints.get(sJoint, sJoint)
        sParent = cmds.getAttr('%s.sParent' % sInterp)
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        aPoint4 = np.array([1,0,0,1], dtype='float64')
        ffUnrealConePoints = []
        ffRanges = []
        sPoseTargets = []
        sReturns = []
        fJointLength = np.round(cmds.getAttr('%s.tx' % cmds.listRelatives(sJoint, c=True)[0]), 3)

        aJointMatrix = utils.getNumpyMatrixFromTransform(sJoint)
        aUnrealJointMatrix = utils.getNumpyMatrixFromTransform('game:%s' % sUnrealJoint)
        iCurveTypes = []
        for sPose in sPoseNames:
            sCone = '%s_%s_cone' % (sInterp, sPose)
            if not cmds.objExists(sCone):
                raise Exception('Cone "%s" doesn\'t exist' % sCone)

            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue

            iCurveTypes.append(cmds.getAttr('%s.interp' % sCone))

            aConeMatrix = utils.getNumpyMatrixFromTransform(sCone, bWorld=False)
            aConeMatrix[0] *= fJointLength / np.linalg.norm(aConeMatrix[0])
            aConeMatrix[1] *= fJointLength / np.linalg.norm(aConeMatrix[1])
            aConeMatrix[2] *= fJointLength / np.linalg.norm(aConeMatrix[2])

            aConePoint = np.dot(aPoint4, aConeMatrix)
            aWorldPoint = np.dot(aConePoint, aJointMatrix)
            aUnrealPoint = np.dot(aWorldPoint, np.linalg.inv(aUnrealJointMatrix))

            sReturns.append('%s_%s' % (sInterp, sPose))
            ffUnrealConePoints.append((aUnrealPoint[0], -aUnrealPoint[1], aUnrealPoint[2]))
            ffRanges.append((cmds.getAttr('%s.innerAngle' % sCone), cmds.getAttr('%s.outerAngle' % sCone)))

        if sReturns:
            sUnrealParent = dUnrealJoints.get(sParent, sParent)
            sUnrealCommands.append("%s = functions.coneInterpolator('%s', '%s', '%s', %0.3f, %s, %s, %s)" %
                                   (', '.join(sReturns), sInterp, sUnrealJoint, sUnrealParent, fJointLength, str(ffUnrealConePoints), str(ffRanges), str(iCurveTypes)))

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()



    sUnrealCommands = ['\n\n#BlendShape Connections']
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.setNewColumn()")

    sTargetPlugs = utils.data.get(utilsUnreal.kBodyBlendShapeTargetList)
    sCompletedsCurveNames = set()
    for sPlug in sTargetPlugs or []:
        sUnrealCommands.append("controllers.setNewColumn()")

        if utils.isNone(sPlug):
            continue
        sCurveName = sPlug.split('.')[-1]
        if sCurveName in sCompletedsCurveNames:
            continue
        sCompletedsCurveNames.add(sCurveName)

        sConns = cmds.listConnections(sPlug, s=True, d=False, p=True)
        if not sConns:
            continue
        sNode, sA = sConns[0].split('.')
        sFactorsAttr = '%s.sFactors' % sNode

        if cmds.objExists(sFactorsAttr):
            sFactors = eval(cmds.getAttr(sFactorsAttr))
        else:
            sFactors = sConns[0]

        if len(sFactors) > 1:
            sFinalAttr = '%s_output' % sNode
            sFactorNames = [sF.replace('.', '_') for sF in sFactors]
            sUnrealCommands.append("%s = nodes.createExtremeNode([%s], bMinimum=True)" % (sFinalAttr, ', '.join(sFactorNames)))
        else:
            sFinalAttr = sConns[0].replace('.', '_')

        sUnrealCommands.append("nodes.setCurveValueExecuteNode('%s', %s)" % (sCurveName, sFinalAttr))



    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=133.9)
def pythonEndFile():
    sUnrealCommands = []

    if utils.data.get('pythonStartedFunction', xDefault=False):
        sUnrealCommands.append("nodes.endCurrentFunction()")

    sUnrealCommands.append("\n\nfTimeAfter = time.time()")
    sUnrealCommands.append("print('========== DONE!!! ========== it took %s' % library.secondsNice(fTimeAfter-fTimeBefore))")
    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()




dUnrealCtrlMapper = {}
dUnrealCtrlMapper['master'] = 'global_ctrl'
dUnrealCtrlMapper['head_ctrl'] = 'head_ctrl'


@builderTools.addToBuild(iOrder=131.5, dButtons={})
def visibilityAttributes(dData={'master.cuffCtrlsVis': {'bDefault':False, 'bUnreal':True, 'sNodeStrings':[]}}):
    bReturn = None
    sCommands = ['\n\n#visibility attributes']
    sCommands.append("nodes.newSequencerPlug()")
    sCommands.append("controllers.openCommentBox('Ctrl Visibilities')")

    sCreatedUnrealCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    print ('sCreatedUnrealCtrls: ', sCreatedUnrealCtrls)

    for sMasterAttr, xCtrlStrings in dData.items():
        if isinstance(xCtrlStrings, list):
            sCtrlStrings, bDefault, bUnreal = xCtrlStrings, False, True
        else:
            sCtrlStrings = xCtrlStrings['sNodeStrings']
            bDefault = xCtrlStrings.get('bDefault', True)
            bUnreal = xCtrlStrings.get('bUnreal', True)

        sSplits = sMasterAttr.split('.')
        if len(sSplits) == 1:
            sMasterCtrl, sA = 'master', sSplits[0]
        else:
            sMasterCtrl, sA = sSplits

        sMasterAttr = utils.addOffOnAttr(sMasterCtrl, sA, bDefaultValue=bDefault, bReturnIfExists=True)
        sCtrls = []
        for sCtrlStr in sCtrlStrings:
            sCtrls += cmds.ls(sCtrlStr, et='transform') + cmds.ls(sCtrlStr, et='joint')
        sCtrls = list(set(sCtrls))
        sCtrlsSet = set(sCtrls)

        sCtrls = sorted(cmds.ls(sCtrls, l=True), key=lambda a:len(a))

        sConnectedTransformsLong = []
        if not len(sCtrls):
            report.report.addLogText('No Ctrls found for "%s"' % sMasterAttr)
            bReturn = False
        else:
            sLogSlaveAttrs = []
            for sCtrl in sCtrls:

                bAlreadyTakenCareOf = False
                for sConnectedT in sConnectedTransformsLong:
                    if sCtrl.startswith('%s|' % sConnectedT):
                        bAlreadyTakenCareOf = True
                        break

                if not bAlreadyTakenCareOf:
                    sSlaveAttr = '%s.v' % sCtrl
                    while True:
                        if cmds.getAttr(sSlaveAttr, settable=True):
                            break
                        else:
                            _sCtrl = sSlaveAttr.split('.')[0]
                            _sParents = cmds.listRelatives(_sCtrl, p=True)
                            if not _sParents:
                                raise Exception('no vis attribute found for "%s"' % sCtrl)
                            else:
                                sSlaveAttr = '%s.v' % _sParents[0]
                    sLogSlaveAttrs.append(sSlaveAttr)
                    cmds.connectAttr(sMasterAttr, sSlaveAttr)
                    sConnectedTransformsLong.append(cmds.ls(sSlaveAttr.split('.')[0], l=True)[0])

            if bUnreal:
                sIntersectedUnrealCtrls = sCtrlsSet.intersection(sCreatedUnrealCtrls)
                if sIntersectedUnrealCtrls:
                    if sMasterCtrl in sCreatedUnrealCtrls:
                        sUnrealMasterCtrl = sMasterCtrl
                    else:
                        sUnrealMasterCtrl = dUnrealCtrlMapper[sMasterCtrl]
                    sCommands.append('controllers.setNewColumn()')
                    sCommands.append("functions.createVisAttrFunction('%s', '%s', %s, bDefault=%s)" % (sA, sUnrealMasterCtrl, [sC.split('|')[-1] for sC in sIntersectedUnrealCtrls], bDefault))
                    report.report.addLogText('Connected %d Ctrls for "%s" (%s)' % (len(sLogSlaveAttrs), sMasterAttr, utils.listToString(sLogSlaveAttrs, iMaxCount=5)))


    sCommands.append("controllers.closeCommentBox('Ctrl Visibilities')")
    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()

    return bReturn





@builderTools.addToBuild(iOrder=160, bDisableByDefault=True)
def constrainMayaRigToUnrealForMLDeformer():
    ssPairs = [
                ('game:clavicle_l', 'clavicleLFT_ctrl'),
                ('game:upperarm_l', 'armUpperChildLFT_ctrl'),
                ('game:lowerarm_l', 'armElbowChildLFT_ctrl'),
                ('game:hand_l', 'armWristChildLFT_ctrl'),
                ('game:clavicle_r', 'clavicleRGT_ctrl'),
                ('game:upperarm_r', 'armUpperChildRGT_ctrl'),
                ('game:lowerarm_r', 'armElbowChildRGT_ctrl'),
                ('game:hand_r', 'armWristChildRGT_ctrl'),
               ]
    for sGame, sMaya in ssPairs:
        cmds.parentConstraint(sGame, sMaya, skipTranslate=['x','y','z'], mo=True)




@builderTools.addToBuild(iOrder=131.9, dButtons={}, bDisableByDefault=True)
def unrealCodeEnding():
    sUnrealCommands = ["fTimeAfter = time.time()"]
    sUnrealCommands.append("print('\\n================ DONE! it took: %0.3f seconds (%0.3f minutes)' % ((fTimeAfter - fTimeBefore), (fTimeAfter - fTimeBefore)/60.0))")
    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


