###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
import re
import numpy as np
import pickle
import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.assets as assets
import kangarooTools.utilFunctions as utils
import kangarooTools.nodes as nodes
import kangarooTools.curves as curves
import kangarooTools.report as report
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTools.constraints as constraints
import kangarooTools.utilsUnreal as utilsUnreal

import kangarooTools.puppetDataUtils as puppetDataUtils
import kangarooTools.match as match
import kangarooTools.patch as patch
import kangarooTools.deformers as deformers
import kangarooTabTools.interpolator as interpolator
import kangarooTabTools.puppet as puppetTools
import kangarooTabTools.segments as segmentsTools
import kangarooTabTools.ctrls7 as ctrls7
import kangarooTabTools.weights as weights
import kangarooTabTools.builder as builderTools
import kangarooTabTools.geometry as geometry
import kangarooTabTools.export as export
import kangarooTabTools.unreal as unreal
import kangarooTabTools.blendShapes as blendShapes
import kangarooTabTools.blendShapesPro as blendShapesPro

from collections import defaultdict

kBuilderColor = '#a9ff00'

kAddBackwardsCtrlInitiations = '#Add Backwards Ctrl Initiations..'
# get rid of this?
sDoBackwardsLimbs=['m_placement', 'm_cog', 'm_spine', 'm_hips',  'l_clavicle', 'l_arm', 'l_leg', 'l_thumb', 'l_index', 'l_middle', 'l_ring', 'l_pinky',
                                                                 'r_clavicle', 'r_arm', 'r_leg', 'r_thumb', 'r_index', 'r_middle', 'r_ring', 'r_pinky', 'm_neck', 'm_head']


@builderTools.addToBuild(iOrder=-3)
def unrealPythonStartFile(sAvoidForwardLimbs=[], sAvoidBackwardsLimbs=[]): #, dUnrealAvoidLimbs={'forward':[], 'backwards':[]}):
    utils.data.store('bBuildUnrealPuppet', True)
    # utils.data.store('bMannequin', bMannequin)
    utils.data.store('sUnrealAvoidForwardLimbs', sAvoidForwardLimbs)
    utils.data.store('sUnrealAvoidBackwardsLimbs', sAvoidBackwardsLimbs)
    # utils.data.store('sDoBackwardsLimbs', sDoBackwardsLimbs)


    sSetSolverString = "controllers.__iCurrentSolver__ = %d"

    sUnrealCodeLines = []
    sUnrealCodeLines.append(sSetSolverString % 0)
    sUnrealCodeLines.append("nodes.startFunction('FORWARD', bSequencer=True)")
    utils.data.store('pythonStartedFunction', True)


    utils.data.store(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True)


    sUnrealBackwardsCodeLines = []
    sUnrealBackwardsCodeLines.append('\n\n')
    sUnrealBackwardsCodeLines.append(sSetSolverString % 1)
    sUnrealBackwardsCodeLines.append(kAddBackwardsCtrlInitiations)
    sUnrealBackwardsCodeLines.append('\n\n')
    sUnrealBackwardsCodeLines.append("try: nodes.createBackwardsEvent()")
    sUnrealBackwardsCodeLines.append("except: print ('backwardsEvent seems to already exist')")
    sUnrealBackwardsCodeLines.append("nodes.startFunction('BACKWARDS', bSequencer=True)")


    utils.data.store(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(bStartFromTemplate=True, sKey=utilsUnreal.kUnrealBackwardsCodeLines)







@builderTools.addToBuild(iOrder=133.9)
def pythonEndFile():
    sUnrealCommands = []
    sUnrealBackwardsCommands = []

    sUnrealCommands.append("nodes.endCurrentFunction()")
    sUnrealBackwardsCommands.append("nodes.endCurrentFunction()")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()

    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)




@builderTools.addToBuild(iOrder=106.5, bDisableByDefault=True)
def pythonFingerPoses():
    sUnrealDriverLimbs = utils.data.get('unrealFingerDriverLimbs')
    print ('sUnrealDriverLimbs: ', sUnrealDriverLimbs)

    sCreatedCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    sFilePath = utilsUnreal.createOutFilePath()
    with open(sFilePath, 'rt') as sText:
        sAllLines = list(sText)
        print ('sUnrealDriverLimbs: ', sUnrealDriverLimbs)
        for sLimbName in sUnrealDriverLimbs:
            dUnrealProducts = utils.data.get('%s_dFingerPosesUnrealProducts' % sLimbName)
            print ('dUnrealProducts: ', dUnrealProducts)

            sCommands = ['\n\n# FINGER POSES %s' % sLimbName.upper()]
            sCommands.append("unrealUI.logMessage('Finger Poses %s...')" % sLimbName)
            sCommands.append("unrealUI.incrementProgress()")

            utilsUnreal.setNewColumn(sWriteCommands=sCommands)

            sCommands.append('dFingerPosesDrivers = {}')
            dRanges = {}
            sCreatedPoseKeys = set()
            # {'indexBase_l_ctrl.r': [('armGlobal_l_ctrl.curl', [102.07447, 0.0, 0.0]), ('armGlobal_l_ctrl.curl negative', [-13.90678, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', [95.58889, 0.0, 0.0]), ('armGlob
            for sCtrlAttr, xPoses in dUnrealProducts.items():
                for sKey, fVector in xPoses:
                    if sKey in sCreatedPoseKeys:
                        continue
                    sSplits = sKey.split('.')
                    sDriverCtrl = sSplits[0]
                    sDriverA = sSplits[1].split(' ')[0]
                    sDriverAttr = '%s.%s' % (sDriverCtrl,sDriverA)
                    if sDriverCtrl not in sCreatedCtrls:
                        cDriverCtrl = ctrls7.ctrlFromName(sDriverCtrl)
                        utilsUnreal.createUnrealCtrl(cDriverCtrl, sWriteCommands=sCommands)
                        sCreatedCtrls.add(cDriverCtrl.sCtrl)
                    if sDriverAttr not in dRanges:
                        fRange = [cmds.addAttr(sDriverAttr, q=True, min=True), cmds.addAttr(sDriverAttr, q=True, max=True)]
                        sCommands.append("hierarchy.createFloatControl('%s', eParent=%s.eControl, fRange=[%0.3f, %0.3f])" % (sDriverA, sDriverCtrl, fRange[0], fRange[1]))
                        dRanges[sDriverAttr] = fRange

                    if sKey.endswith('negative'):
                        sCommands.append("dFingerPosesDrivers['%s'] = functions.mapFloatControl('%s', '%s', %d)" % (sKey, sDriverCtrl, sDriverA, dRanges[sDriverAttr][0]))
                    else:
                        sCommands.append("dFingerPosesDrivers['%s'] = functions.mapFloatControl('%s', '%s', %d)" % (sKey, sDriverCtrl, sDriverA, dRanges[sDriverAttr][1]))
                    sCreatedPoseKeys.add(sKey)

            dUnrealFingerFunctions = utils.data.get('dUnrealFingerFunctions')
            sUsedUnrealFingerFunctions = list(set(dUnrealFingerFunctions.values()))

            ddLimbsPasserRotations = {sUnrealFunc:defaultdict(dict) for sUnrealFunc in sUsedUnrealFingerFunctions}
            ddLimbsPasserTranslations = {sUnrealFunc:defaultdict(dict) for sUnrealFunc in sUsedUnrealFingerFunctions}
            # sBones = ['meta', 'base', 'mid', 'tip']
            sAllFingerLimbs = set()
            for sCtrlAttr, xPoses in dUnrealProducts.items():
                sCtrl,sA = sCtrlAttr.split('.')
                sFingerLimbName = cmds.getAttr('%s.sLimbCtrl' % sCtrl)
                sUnrealFunc = dUnrealFingerFunctions[sFingerLimbName]
                sPasser = utils.replaceStringStart(ctrls7.ctrlFromName(sCtrl).sPasser, 'grp_', '')
                if sA == 'r':
                    ddLimbsPasserRotations[sUnrealFunc][sFingerLimbName][sPasser] = xPoses
                elif sA == 't':
                    ddLimbsPasserTranslations[sUnrealFunc][sFingerLimbName][sPasser] = xPoses
                sAllFingerLimbs.add(sFingerLimbName)

            dRotationsMaxPasserCounts = {}
            dTranslationsMaxPasserCounts = {}
            for sUnrealFunc in sUsedUnrealFingerFunctions:
                dRotationsMaxPasserCounts[sUnrealFunc] = max([len(x) for x in ddLimbsPasserRotations[sUnrealFunc].values()]) if len(ddLimbsPasserRotations[sUnrealFunc].values()) else 0
                dTranslationsMaxPasserCounts[sUnrealFunc] = max([len(x) for x in ddLimbsPasserTranslations[sUnrealFunc].values()]) if len(ddLimbsPasserTranslations[sUnrealFunc].values()) else 0


            for sFingerLimb in sAllFingerLimbs:
                sUnrealFunc = dUnrealFingerFunctions[sFingerLimb]
                # .r
                sWritePassersRotation = [None] * dRotationsMaxPasserCounts[sUnrealFunc]
                xWristPosesRotation = [None] * dRotationsMaxPasserCounts[sUnrealFunc]
                for p,sPasser in enumerate(ddLimbsPasserRotations[sUnrealFunc][sFingerLimb].keys()):
                    sWritePassersRotation[p] = sPasser
                    xWristPosesRotation[p] = ddLimbsPasserRotations[sUnrealFunc][sFingerLimb][sPasser]

                # .t
                sWritePassersTranslation = [None] * dTranslationsMaxPasserCounts[sUnrealFunc]
                xWristPosesTranslation = [None] * dTranslationsMaxPasserCounts[sUnrealFunc]
                for p,sPasser in enumerate(ddLimbsPasserTranslations[sUnrealFunc][sFingerLimb].keys()):
                    sWritePassersTranslation[p] = sPasser
                    xWristPosesTranslation[p] = ddLimbsPasserTranslations[sUnrealFunc][sFingerLimb][sPasser]
                for l,sLine in enumerate(sAllLines):
                    if sLine.strip().startswith(('functions.createFingerFunction', 'functions.createDogToeFunction')):
                        sLineSplits = sLine.split('#')
                        if sLineSplits[-1].strip() == sFingerLimb:
                            iBracketsPos = sLineSplits[0].rfind(')')
                            sLineSplits[0] = sLineSplits[0][:iBracketsPos] + \
                                            ', dFingerPosesDrivers=dFingerPosesDrivers, sPosePassersRotation=%s, xPasserPosesRotation=%s, sPosePassersTranslation=%s, xPasserPosesTranslation=%s' % \
                                             (sWritePassersRotation, xWristPosesRotation, sWritePassersTranslation, xWristPosesTranslation) + \
                                            sLineSplits[0][iBracketsPos:]
                            sAllLines[l] = '#'.join(sLineSplits)
                            break

            iInsertToLine = None
            for i,sLine in enumerate(sAllLines):
                if sLine.strip() == '# PIECE.END: %s' % sLimbName:
                    iInsertToLine = i
            if utils.isNone(iInsertToLine):
                raise Exception('Piece End of "%s" not found in file' % sLimbName)
            sAllLines = sAllLines[:iInsertToLine] + ['%s\n' % sCommand for sCommand in sCommands] + sAllLines[iInsertToLine:]

    utils.createTextFile(sFilePath, sAllLines)




kAddBackwardsCtrlInitiations = '#Add Backwards Ctrl Initiations..'
@builderTools.addToBuild(iOrder=120)
def initiateCtrlsInBackwards(bReloadLimbs=False, sExtraAvoidLimbs=[]):
    sCommands = ['\n\n#Initiate created ctrls']

    sCreatedCtrls = set(utils.data.get(utilsUnreal.kCreatedUnrealCtrls))
    for sCtrl in sCreatedCtrls:
        sCommands.append("%s = hierarchy.Ctrl().initFromExisting('%s')" % (sCtrl, sCtrl))

    sFilePath = utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)
    if utils.isTextInFile(sFilePath, kAddBackwardsCtrlInitiations):
        utils.searchReplaceFile(sFilePath, kAddBackwardsCtrlInitiations, '\n'.join(sCommands))
    else:
        raise Exception ('no place found to add the code lines')




@builderTools.addToBuild(iOrder=130.1)
def pythonMuscleJoints():
    dUnrealJoints = utils.data.get('dUnrealJoints')
    sCommands =['# Muscle Joints']
    sCommands.extend(utilsUnreal.generateMuscleJointsCode(dUnrealJointsMapper=dUnrealJoints, bPieceLines=True))
    # anim rig file
    sFilePath = utilsUnreal.createOutFilePath()
    if utils.isTextInFile(sFilePath, sCommands[0]):
        utils.searchReplaceFile(sFilePath, sCommands[0], '\n'.join(sCommands))
    else:
        utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
        utilsUnreal.dumpUnrealCodeLinesToFile()




@builderTools.addToBuild(iOrder=130.15)
def unrealPythonBlendJoints():
    sBlendJoints = [sJ for sJ in cmds.ls('game:*Blend', et='joint') if cmds.attributeQuery('unrealBlendJoint', node=sJ, exists=True)]
    for sFullJ in sBlendJoints:
        if cmds.getAttr('%s.unrealBlendJoint' % sFullJ) == True:
            sJ = sFullJ.split(':')[-1]
            sBlendFrom = cmds.getAttr('%s.blendFrom' % sFullJ)
            sBlendTo = cmds.getAttr('%s.blendTo' % sFullJ)
            fWeight = cmds.getAttr('%s.blendWeight' % sFullJ)
            sCommands = ['\n\n# Blend Joints']

            sCommands.append(f'# PIECE.START: {sJ}')
            sCommands.append('# PIECE.TYPE: blendJoint')

            sCommands.append(f"# PIECE.INPUTS: ['{sBlendFrom}', '{sBlendTo}']")
            sCommands.append(f"# PIECE.OUTPUTS: ['{sJ}']")

            sCommands.append(f"functions.blendJoints([('{sJ}', '{sBlendFrom}', '{sBlendTo}', {fWeight})])")
            sCommands.append(f'# PIECE.END: {sJ}')


            utils.data.addToList(utilsUnreal.kUnrealCodeLines, sCommands)
            utilsUnreal.dumpUnrealCodeLinesToFile()





@builderTools.addToBuild(iOrder=130.5)
def unrealPythonInterpolators():
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sUnrealCommands = []

    sUnrealCommands.append('\n\n#UplegUp Interpolators')
    sUnrealCommands.append("nodes.startFunction('kangaroo_interpolators', bSequencer=True)")

    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('uplegType', node=sT, exists=True)]
    sMayaHip = 'jnt_m_hips'
    sHip = dUnrealJoints.get(sMayaHip, sMayaHip)


    def _convertSpaceValue(iCurrentAxis, fValues):
        aMayaHipMatrix = utils.getNumpyMatrixFromTransform(sMayaHip)
        aHipMatrix = utils.getNumpyMatrixFromTransform('game:%s' % sHip)
        fPoints4 = [[0,0,0,1], [0,0,0,1]]
        for v,fV in enumerate(fValues):
            fPoints4[v][iCurrentAxis] = fV

        aGlobalPoints4 = np.dot(np.array(fPoints4, dtype='float64'), aMayaHipMatrix)
        aUnrealLocalPoints = np.dot(aGlobalPoints4, np.linalg.inv(aHipMatrix))
        aDiffs = np.abs(aUnrealLocalPoints[1] - aUnrealLocalPoints[0])
        iUnrealAxis = np.argmax(aDiffs)
        aUnrealValues = aUnrealLocalPoints[:,iUnrealAxis]
        if iUnrealAxis == 1:
            aUnrealValues *= -1.0
        return iUnrealAxis, list(aUnrealValues)


    for sInterp in sInterpolators:
        sSide = utils.getSide(sInterp)

        sMayaKnee = 'jnt_%s_leg_lowerTwist_000' % sSide
        sKnee = dUnrealJoints.get(sMayaKnee, sMayaKnee)

        sDrivenKeys = eval(cmds.getAttr('%s.drivenKeys' % sInterp))
        ffLocalPoints = []
        ffValues = []
        # sPoseTargets = []

        iCurrentAxes = [1,0,2]
        iUnrealAxes = []
        for a,sNode in enumerate(sDrivenKeys):
            fValues = cmds.keyframe(sNode, q=True, valueChange=True)
            ffValues.append(fValues)
            fTimes = cmds.keyframe(sNode, q=True, floatChange=True)
            iUnrealAxis, fUnrealTimes = _convertSpaceValue(iCurrentAxes[a], fTimes)
            ffLocalPoints.append(fUnrealTimes)
            iUnrealAxes.append(iUnrealAxis)

        sUnrealCommands.append("%s_up = functions.uplegUpInterpolator('%s', '%s', '%s', iUnrealAxes=%s, ffLocalPoints=%s, ffValues=%s)" % (sInterp, sInterp, sHip, sKnee, iUnrealAxes, ffLocalPoints, ffValues))



    sUnrealCommands.append('\n\n#Angle Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('angleType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoints = eval(cmds.getAttr('%s.sJoints' % sInterp))
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        iCurveTypes = eval(cmds.getAttr('%s.iCurveTypes' % sInterp))
        ffAngleRanges = eval(cmds.getAttr('%s.ffAngleRanges' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        sPoseTargets = []
        sReturns = []
        ffPassRanges = []
        iPassCurveTypes = []
        for p,sPose in enumerate(sPoseNames):
            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue
            ffPassRanges.append(ffAngleRanges[p])
            # sPoseTargets.append(list(set(sTargets))) # it only takes one target currently
            sReturns.append('%s_%s' % (sInterp, sPose))
            iPassCurveTypes.append(iCurveTypes[p])
        if sReturns:
            sUnrealJoints = [dUnrealJoints.get(sJ, sJ) for sJ in sJoints]
            sUnrealCommands.append("%s = functions.angleInterpolator(%s, %s, iCurveTypes=%s) # %s" %
                                   (', '.join(sReturns), str(sUnrealJoints), str(ffPassRanges), iPassCurveTypes, sInterp))


    sUnrealCommands.append('\n\n#Signed Angle Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('signedAngleType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoints = eval(cmds.getAttr('%s.sJoints' % sInterp))
        sTwist, sParent = sJoints

        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        iCurveTypes = eval(cmds.getAttr('%s.iCurveTypes' % sInterp))
        ffAngleRanges = eval(cmds.getAttr('%s.ffAngleRanges' % sInterp))
        iForwardAxis = eval(cmds.getAttr('%s.iForwardAxis' % sInterp))
        iUpAxis = eval(cmds.getAttr('%s.iUpAxis' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        # sPoseTargets = []
        sReturns = []
        ffPassRanges = []
        iPassCurveTypes = []
        for p,sPose in enumerate(sPoseNames):
            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue
            ffPassRanges.append(ffAngleRanges[p])
            sReturns.append('%s_%s' % (sInterp, sPose))
            iPassCurveTypes.append(iCurveTypes[p])
        if sReturns:
            iUnrealForwardAxis = xforms.getClosestAxis('game:%s' % dUnrealJoints.get(sTwist, sTwist), sTwist, iForwardAxis, bSigned=True)
            iUnrealUpAxis = xforms.getClosestAxis('game:%s' % dUnrealJoints.get(sTwist, sTwist), sTwist, iUpAxis, bSigned=True)
            if iUnrealForwardAxis == 1:
                iUnrealForwardAxis = 4
            elif iUnrealForwardAxis == 4:
                iUnrealForwardAxis = 1
            if iUnrealUpAxis == 1:
                iUnrealUpAxis = 4
            elif iUnrealUpAxis == 4:
                iUnrealUpAxis = 1

            fForwardVector = [0, 0, 0]
            fForwardVector[iUnrealForwardAxis % 3] = 1 if iUnrealForwardAxis < 3 else -1
            fUpVector = [0, 0, 0]
            fUpVector[iUnrealUpAxis % 3] = 1 if iUnrealUpAxis < 3 else -1
            sUnrealCommands.append(f"{', '.join(sReturns)} = functions.signedAngleInterpolator('{dUnrealJoints.get(sTwist, sTwist)}', '{dUnrealJoints.get(sParent, sParent)}', {str(ffPassRanges)}, "
                                   f"iCurveTypes={iPassCurveTypes}, iAngleAxis=0, fForwardVector={fForwardVector}, fUpVector={fUpVector}) # {sInterp}")



    sUnrealCommands.append('\n\n#Cone Interpolators')
    sInterpolators = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('xPoses', node=sT, exists=True) and cmds.attributeQuery('coneType', node=sT, exists=True)]
    for sInterp in sInterpolators:
        sJoint = cmds.getAttr('%s.sJoint' % sInterp)
        sUnrealJoint = dUnrealJoints.get(sJoint, sJoint)
        sParent = cmds.getAttr('%s.sParent' % sInterp)
        xPoses = eval(cmds.getAttr('%s.xPoses' % sInterp))
        sPoseNames = [sN for sN,_,_,_ in xPoses]
        aPoint4 = np.array([1,0,0,1], dtype='float64')
        ffUnrealConePoints = []
        ffRanges = []
        sPoseTargets = []
        sReturns = []
        fJointLength = np.round(cmds.getAttr('%s.tx' % cmds.listRelatives(sJoint, c=True)[0]), 3)

        aJointMatrix = utils.getNumpyMatrixFromTransform(sJoint)
        aUnrealJointMatrix = utils.getNumpyMatrixFromTransform('game:%s' % sUnrealJoint)
        iCurveTypes = []
        for sPose in sPoseNames:
            sCone = '%s_%s_cone' % (sInterp, sPose)
            if not cmds.objExists(sCone):
                raise Exception('Cone "%s" doesn\'t exist' % sCone)

            sAnimCurves = cmds.listConnections('%s.%s' % (sInterp, sPose), s=False, d=True)
            if not sAnimCurves:
                continue

            iCurveTypes.append(cmds.getAttr('%s.interp' % sCone))

            aConeMatrix = utils.getNumpyMatrixFromTransform(sCone, bWorld=False)
            aConeMatrix[0] *= fJointLength / np.linalg.norm(aConeMatrix[0])
            aConeMatrix[1] *= fJointLength / np.linalg.norm(aConeMatrix[1])
            aConeMatrix[2] *= fJointLength / np.linalg.norm(aConeMatrix[2])

            aConePoint = np.dot(aPoint4, aConeMatrix)
            aWorldPoint = np.dot(aConePoint, aJointMatrix)
            aUnrealPoint = np.dot(aWorldPoint, np.linalg.inv(aUnrealJointMatrix))

            sReturns.append('%s_%s' % (sInterp, sPose))
            ffUnrealConePoints.append((aUnrealPoint[0], -aUnrealPoint[1], aUnrealPoint[2]))
            ffRanges.append((cmds.getAttr('%s.innerAngle' % sCone), cmds.getAttr('%s.outerAngle' % sCone)))

        if sReturns:
            sUnrealParent = dUnrealJoints.get(sParent, sParent)
            sUnrealCommands.append("%s = functions.coneInterpolator('%s', '%s', %0.3f, %s, %s, %s) # %s" %
                                   (', '.join(sReturns), sUnrealJoint, sUnrealParent, fJointLength, str(ffUnrealConePoints), str(ffRanges), str(iCurveTypes), sInterp))

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


    sUnrealCommands = ['\n\n#BlendShape Connections']
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.setNewColumn()")

    sTargetPlugs = utils.data.get(utilsUnreal.kBodyBlendShapeTargetList, xDefault=[])
    sCompletedsCurveNames = set()
    for sPlug in sTargetPlugs:
        sUnrealCommands.append("controllers.setNewColumn()")

        if utils.isNone(sPlug):
            continue
        sCurveName = sPlug.split('.')[-1]
        if sCurveName in sCompletedsCurveNames:
            continue
        sCompletedsCurveNames.add(sCurveName)

        sConns = cmds.listConnections(sPlug, s=True, d=False, p=True)
        if not sConns:
            continue
        sNode, sA = sConns[0].split('.')
        sFactorsAttr = '%s.sFactors' % sNode

        if cmds.objExists(sFactorsAttr):
            sFactors = eval(cmds.getAttr(sFactorsAttr))
        else:
            sFactors = sConns[0]

        if len(sFactors) > 1:
            sFinalAttr = '%s_output' % sNode
            sFactorNames = [sF.replace('.', '_') for sF in sFactors]
            sUnrealCommands.append("%s = nodes.createExtremeNode([%s], bMinimum=True)" % (sFinalAttr, ', '.join(sFactorNames)))
        else:
            sFinalAttr = sConns[0].replace('.', '_')

        sUnrealCommands.append("nodes.setCurveValueExecuteNode('%s', %s)" % (sCurveName, sFinalAttr))

    sUnrealCommands.append("nodes.endCurrentFunction()")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()



@builderTools.addToBuild(iOrder=134)
def pythonUiify():
    for sFilePath in [utilsUnreal.createOutFilePath(), utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]:
        report.report.addLogText('Uiifying "%s"...' % sFilePath)
        bIndent = False
        with open(sFilePath) as sText:
            sAllLines = list(sText)

            # count pieces and add increment lines
            iPieceCounter = 0
            i = -1
            while i < len(sAllLines)-1:
                i += 1
                if 'unrealUI.incrementProgress()' in sAllLines[i]:
                    iPieceCounter += 1

            # add the try, and open UI function
            i = -1
            while i < len(sAllLines)-1:
                i += 1

                if sAllLines[i].startswith('eOrigin = '):
                    sInsertLines = []
                    sInsertLines.append("def run():\n")
                    sInsertLines.append("    unrealUI.logMessage('============ %s ============', bLogTimeWhenDone=False)\n" % assets.assetManager.getCurrentAsset())
                    sInsertLines.append("    fStartTime = time.time()\n")
                    sInsertLines.append("    try:\n")
                    sAllLines = sAllLines[0:i] + sInsertLines + sAllLines[i:]
                    i += len(sInsertLines)
                    bIndent = True

                if bIndent:
                    sAllLines[i] = "        %s" % sAllLines[i]

            # ending
            sAllLines.append("    except:\n")
            sAllLines.append("        sError = traceback.format_exc()\n")
            sAllLines.append("        unrealUI.logMessage(sError)\n")
            sAllLines.append("        raise\n")
            sAllLines.append("\n")
            sAllLines.append("    unrealUI.logMessage('\\nDone! It took %s' % (library.secondsNice(time.time()-fStartTime)))\n")
            sAllLines.append("\n")
            sAllLines.append("unrealUI.openWindow(run, %d)\n" % iPieceCounter)

        utils.createTextFile(sFilePath, sAllLines)


@builderTools.addToBuild(iOrder=130.3, bDisableByDefault=True)
def pythonBrowSplines():
    sUnrealCodeLines = ['\n\n# BROWS SPLINES\n']
    sUnrealCodeLines.append("unrealUI.logMessage('Brows Splines...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")

    aaaWeights = utils.data.get('browsSplineBsplineWeights')
    dDefaultSettingValuesBrows = utils.data.get('dDefaultSettingValuesBrows')

    ssCtrls = [None, None]
    for s,sSide in enumerate(['l','r']):
        sUnrealCodeLines.append('\n\n## %s' % utils.sSides[s].upper())
        cMainCtrl = ctrls7.ctrlFromName('browMain_%s_ctrl' % sSide)
        utilsUnreal.createUnrealCtrl(cMainCtrl, sWriteCommands=sUnrealCodeLines)
        ssCtrls[s] = ['browSplinesA_%s_ctrl' % sSide, 'browSplinesB_%s_ctrl' % sSide, 'browSplinesC_%s_ctrl' % sSide]
        sAllTangentCtrls = []
        for sCtrl in ssCtrls[s]:
            cCtrl = ctrls7.ctrlFromName(sCtrl)
            utilsUnreal.createUnrealCtrl(cCtrl, bOut=True, sWriteCommands=sUnrealCodeLines) # sParentVar='%s.eControl' % cMainCtrl.sCtrl
            sTangentCtrls = eval(cmds.getAttr('%s.sTangentCtrls' % sCtrl))
            for sTangentCtrl in sTangentCtrls:
                utilsUnreal.createUnrealCtrl(ctrls7.ctrlFromName(sTangentCtrl), sParentVar='%s.eOut' % sCtrl, sShapeName='Square_Thick', sWriteCommands=sUnrealCodeLines)
                sAllTangentCtrls.append(sTangentCtrl)
            sCurve = 'curve_%s_brows' % sSide
            pCurve = patch.patchFromName(sCurve)
            _, sInfluences, aaWeights = pCurve.getSkinCluster()
            aCurvePoints = pCurve.getPoints()
            aInfluences = np.array(sInfluences)
            xPoints = []
            for i in range(len(aaWeights)):
                aInds = np.argsort(aaWeights[i])[::-1]
                xInfs = []
                for ii in range(2):
                    iIndex = aInds[ii]
                    fWeight = aaWeights[i][iIndex]
                    if fWeight > 0.001:
                        xInfs.append((cmds.getAttr('%s.sCtrl' % aInfluences[iIndex]), fWeight))

                xPoints.append((utilsUnreal.flipVectorToUnreal(list(aCurvePoints[i])), xInfs))

        dPreSiblingValues = {}
        dPreSiblingDriverValues = {}
        dPostSiblingValues = defaultdict(dict)
        dPostSiblingDriverValues = defaultdict(dict)
        dTangentPreSiblingValues = defaultdict(dict)
        dTangentPreSiblingDriverValues = defaultdict(dict)
        print ('dDefaultSettingValuesBrows: ', dDefaultSettingValuesBrows)
        for sAttr,fValue in dDefaultSettingValuesBrows.items():
            if utils.getSide(sAttr) == sSide:
                if 'preSibling' in sAttr:
                    if not sAttr.endswith('.driverValue') and abs(fValue) > 0.01:
                        sSibling, sA = sAttr.split('.')
                        sCtrl = utils.getStringAttr(sSibling, 'sCtrl', None)
                        iControlIndex = ['browSplinesA_%s_ctrl' % sSide, 'browSplinesB_%s_ctrl' % sSide, 'browSplinesC_%s_ctrl' % sSide].index(sCtrl)
                        dUnrealA = {'tx':'TranslateX', 'ty':'TranslateZ', 'tz':'TranslateY'}
                        sUnrealAttr = '%d.%s' % (iControlIndex, dUnrealA[sA])
                        dPreSiblingValues[sUnrealAttr] = fValue
                        dPreSiblingDriverValues[iControlIndex] = dDefaultSettingValuesBrows['%s.driverValue' % sSibling]
                elif 'preTangentSibling' in sAttr:
                    if not sAttr.endswith('.driverCtrlValueTangents') and abs(fValue) > 0.01:
                        sSibling, sA = sAttr.split('.')
                        sNameChain = utils.camelToChain(sSibling).split('_')
                        sDirection = sNameChain[-1]
                        sCtrl = utils.getStringAttr(sSibling, 'sCtrl', None)
                        iControlIndex = ['browTangentAOut_%s_ctrl' % sSide, 'browTangentBIn_%s_ctrl' % sSide, 'browTangentBOut_%s_ctrl' % sSide, 'browTangentCIn_%s_ctrl' % sSide].index(sCtrl)
                        dUnrealA = {'rx':'RotateX', 'ry':'RotateY', 'rz':'RotateY'}
                        sUnrealAttr = '%d.%s' % (iControlIndex, dUnrealA[sA])
                        dTangentPreSiblingValues[sDirection][sUnrealAttr] = -fValue
                        dTangentPreSiblingDriverValues[sDirection][iControlIndex] = dDefaultSettingValuesBrows['%s.driverCtrlValueTangents' % sSibling]
                elif 'postSibling' in sAttr:
                    if '.driverCtrlValue' not in sAttr and abs(fValue) > 0.01:
                        sSibling, sA = sAttr.split('.')
                        sNameChain = utils.camelToChain(sSibling).split('_')
                        sDirection = sNameChain[-1]
                        sCtrl = utils.getStringAttr(sSibling, 'sCtrl', None)
                        iControlIndex = ['browSplinesA_%s_ctrl' % sSide, 'browSplinesB_%s_ctrl' % sSide, 'browSplinesC_%s_ctrl' % sSide].index(sCtrl)
                        dUnrealA = {'rx':'RotateX', 'ry':'RotateY', 'rz':'RotateY'}
                        sUnrealAttr = '%d.%s' % (iControlIndex, dUnrealA[sA])
                        dPostSiblingValues[sDirection][sUnrealAttr] = -fValue
                        dPostSiblingDriverValues[sDirection][iControlIndex] = dDefaultSettingValuesBrows['%s.driverCtrlValue' % sSibling]




        sJoints = sorted(cmds.ls('jnt_%s_brows_???' % sSide, et='joint'))
        fVerticalDefaults = [cmds.getAttr('%s.defaultY' % sJ) for sJ in sJoints]
        fVerticalDowns = [cmds.getAttr('%s.verticalDownPose' % sJ) for sJ in sJoints]
        fVerticalUps = [cmds.getAttr('%s.verticalUpPose' % sJ) for sJ in sJoints]
        sUnrealCodeLines.append(f"sBrows_{sSide} = functions.splineBrows(cMainCtrl={cMainCtrl.sCtrl}, cCtrls={utilsUnreal.listNice(ssCtrls[s])}, "
                                f"cTangentCtrls={utilsUnreal.listNice(sAllTangentCtrls)}, xPoints={str(xPoints)}, sJoints={str(sJoints)}, fJointWeights0={list(aaaWeights[s][0])}, fJointWeights1={list(aaaWeights[s][1])}, sSide='{sSide}', "
                                f"\n\t\t\t\tdPreSiblingValues={str(dict(dPreSiblingValues))}, dPreSiblingDriverValues={str(dPreSiblingDriverValues)}, "
                                f"\n\t\t\t\tdTangentPreSiblingValuesAllDirections={str(dict(dTangentPreSiblingValues))}, dTangentPreSiblingDriverValuesAllDirections={str(dict(dTangentPreSiblingDriverValues))},"
                                f"\n\t\t\t\tdPostSiblingValuesAllDirections={str(dict(dPostSiblingValues))}, dPostSiblingDriverValuesAllDirections={str(dict(dPostSiblingDriverValues))},"
                                f"\n\t\t\t\tfVerticalDefaults={str(fVerticalDefaults)}, fVerticalDowns={str(fVerticalDowns)}, fVerticalUps={str(fVerticalUps)})")

    cMiddle = ctrls7.ctrlFromName('browMiddle_ctrl')
    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)
    utilsUnreal.createUnrealCtrl(cMiddle, sWriteCommands=sUnrealCodeLines)
    sUnrealCodeLines.append(f"functions.browsMiddle(cMiddle={cMiddle.sCtrl}, sBone='jnt_m_browMiddle', sBoneDefault='jnt_m_browMiddleDefault', sBrowsNodeLeft=sBrows_l, sBrowsNodeRight=sBrows_r, "
                            f"cBrowsControlLeft={ssCtrls[0][0]}, cBrowsControlRight={ssCtrls[1][0]}, "
                            f"fFollow={cmds.getAttr('%s.follow' % cMiddle.sCtrl)}, fAutoPush={cmds.getAttr('%s.autoPush' % cMiddle.sCtrl)}, fAutoScale={cmds.getAttr('%s.autoScale' % cMiddle.sCtrl)})")
    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=131.02, bDisableByDefault=True)
def pythonLidSplines():

    utils.reload2(utilsUnreal)
    sUnrealCodeLines = ['\n\n# LID SPLINES \n']
    sUnrealCodeLines.append("unrealUI.logMessage('Lid Splines...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")

    sEyeTransformCtrls = [utilsUnreal.ctrlInitFromExisting('eyeTransform_l_ctrl', sUnrealCodeLines), utilsUnreal.ctrlInitFromExisting('eyeTransform_r_ctrl', sUnrealCodeLines)]
    aEyeTransformJointMatrices = [utils.getNumpyMatrixFromTransform('jnt_l_eyeTransform'), utils.getNumpyMatrixFromTransform('jnt_r_eyeTransform')]
    # aInvEyeTransformJointMatrices = [np.linalg.inv(aEyeTransformJointMatrices[0]), np.linalg.inv(aEyeTransformJointMatrices[1])]
    # aaaMaxPoints = [[], []]
    for s,sSide in enumerate(['l', 'r']):

        ccCtrls = [None, None]
        sUnrealCodeLines.append('\n\n## %s' % utils.sSides[s].upper())
        cCornerCtrls = [ctrls7.ctrlFromName('eyeSplineCornerIn_%s_ctrl' % sSide), ctrls7.ctrlFromName('eyeSplineCornerOut_%s_ctrl' % sSide)]
        cCornerCtrls[0].cTangents = []
        cCornerCtrls[1].cTangents = []
        utilsUnreal.createUnrealCtrl(cCornerCtrls[0], bOut=True, sParentVar='%s.eControl' % sEyeTransformCtrls[s], sWriteCommands=sUnrealCodeLines)
        utilsUnreal.createUnrealCtrl(cCornerCtrls[1], bOut=True, sParentVar='%s.eControl' % sEyeTransformCtrls[s], sWriteCommands=sUnrealCodeLines)

        ssMaxNulls = [], []
        xxCtrlWeights = [], []
        for p,sPart in enumerate(['bot','top']):
            cCtrls = [ctrls7.ctrlFromName(sC) for sC in cmds.ls('eyeSpline%s?_%s_ctrl' % (sPart.title(), sSide), et='transform')]
            for cCtrl in cCtrls:
                utilsUnreal.createUnrealCtrl(cCtrl, bOut=True, sParentVar='%s.eControl' % sEyeTransformCtrls[s], sWriteCommands=sUnrealCodeLines)
            ccCtrls[p] = cCtrls

            cTangentIn = ctrls7.ctrlFromName('eyeSplineCornerInTangent%s_%s_ctrl' % (sPart.title(), sSide))
            cTangentOut = ctrls7.ctrlFromName('eyeSplineCornerOutTangent%s_%s_ctrl' % (sPart.title(), sSide))
            utilsUnreal.createUnrealCtrl(cTangentIn, sParentVar='%s.eControl' % cCornerCtrls[0].sCtrl, sShapeName='Square_Thick', sWriteCommands=sUnrealCodeLines)
            utilsUnreal.createUnrealCtrl(cTangentOut, sParentVar='%s.eControl' % cCornerCtrls[1].sCtrl, sShapeName='Square_Thick', sWriteCommands=sUnrealCodeLines)
            cCornerCtrls[0].cTangents.append(cTangentIn)
            cCornerCtrls[1].cTangents.append(cTangentOut)

            aMaxPointsBot = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineMaxBlendingBot' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aMaxPointsTop = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineMaxBlendingTop' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aMaxPointsBot[:,1] *= -1.0 # Negating Y to translate to Unreal
            aMaxPointsTop[:,1] *= -1.0 # Negating Y to translate to Unreal
            aPointsBot = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineBlendingBot' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aPointsTop = utils.makePointsRelative(patch.patchFromName('curve_%s_lidSplineBlendingTop' % sSide).getPoints(), 'jnt_%s_eyeTransform' % sSide)
            aPointsBot[:,1] *= -1.0 # Negating Y to translate to Unreal
            aPointsTop[:,1] *= -1.0 # Negating Y to translate to Unreal


            sCombinedCurve = 'curve_%s_%sCombined' % (sSide, sPart)
            _, sCtrlInfluences, aaCtrlWeights = patch.patchFromName(sCombinedCurve).getSkinCluster(sChooseSkinCluster='skinCluster__%s__CTRLS' % sCombinedCurve)
            for i in range(len(aaCtrlWeights)): # per vertex
                aBiggest = np.argsort(aaCtrlWeights[i])[::-1]
                xxCtrlWeights[p].append([(cmds.getAttr('%s.sCtrl' % sCtrlInfluences[aBiggest[0]]), cmds.getAttr('%s.sCtrl' % sCtrlInfluences[aBiggest[1]])),
                                         (aaCtrlWeights[i,aBiggest[0]], aaCtrlWeights[i,aBiggest[1]])])

        cBlink = ctrls7.ctrlFromName('blink_%s_ctrl' % sSide)
        utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)



        sUnrealCodeLines.append(f"LidSplines_{sSide} = functions.lidSplines(cMainCtrl={sEyeTransformCtrls[s]}, cBotCtrls={utilsUnreal.listNice(ccCtrls[0])}, cTopCtrls={utilsUnreal.listNice(ccCtrls[1])},"
                                f"\n\t\t\t\tcCornerCtrls={utilsUnreal.listNice(cCornerCtrls)}, cTangentInCtrls={utilsUnreal.listNice(cCornerCtrls[0].cTangents)}, cTangentOutCtrls={utilsUnreal.listNice(cCornerCtrls[1].cTangents)},"
                                f"\n\t\t\t\tffBotMaxPoints={utilsUnreal.listNice(aMaxPointsBot)},"
                                f"\n\t\t\t\tffTopMaxPoints={utilsUnreal.listNice(aMaxPointsTop)},"#
                                f"\n\t\t\t\tffBotPoints={utilsUnreal.listNice(aPointsBot[1:-1])},"
                                f"\n\t\t\t\tffTopPoints={utilsUnreal.listNice(aPointsTop)},"#
                                f"\n\t\t\t\tsBotBones={str(cmds.ls('jnt_%s_botSkinLidSpline_???' % sSide, et='joint'))},"#
                                f"\n\t\t\t\tsTopBones={str(cmds.ls('jnt_%s_topSkinLidSpline_???' % sSide, et='joint'))},"#
                                f"\n\t\t\t\txCtrlWeightsBot={str(xxCtrlWeights[0][1:-1])},"#
                                f"\n\t\t\t\txCtrlWeightsTop={str(xxCtrlWeights[1])},"#
                                f"\n\t\t\t\tcBlink={cBlink.sCtrl}, fDefaultBlinkLine={cmds.getAttr('%s.blinkLine' % cBlink.sCtrl)}, sTransformBone='jnt_{sSide}_eyeTransform', fLivePole={cmds.getAttr('%s.livePole' % cBlink.sPasser)})")#

    utilsUnreal.setNewColumn(sWriteCommands=sUnrealCodeLines)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()


@builderTools.addToBuild(iOrder=130.2)
def pythonSortLimbs():
    for sFilePath in [utilsUnreal.createOutFilePath(), utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]:
        with open(sFilePath) as sText:
            sAllLines = list(sText)
            dAllPieces = []
            i = -1
            while True:
                i += 1
                if i >= len(sAllLines):
                    break
                if '# PIECE.START' in sAllLines[i]:
                    print ('piece start: ', sAllLines[i])
                    sName = sAllLines[i].split(':')[-1].strip()
                    dNewPiece = {'sName':sName, 'sInputs':[], 'sOutputs':[], 'sType':None, 'sReplacedLines':False}
                    for k in range(i+1, len(sAllLines), 1):
                        if sAllLines[k].startswith('# PIECE.INPUTS'):
                            sInputs = eval(sAllLines[k].split(':')[-1])
                            dNewPiece['sInputs'].extend(sInputs)
                        if sAllLines[k].startswith('# PIECE.TYPE'):
                            dNewPiece['sType'] = sAllLines[k].split(':')[-1].strip()
                        elif sAllLines[k].startswith('# PIECE.OUTPUTS'):
                            sString = sAllLines[k].split(':')[-1]
                            sInputs = eval(sString)
                            dNewPiece['sOutputs'].extend(sInputs)
                        elif sAllLines[k].startswith('# PIECE.END'):
                            dNewPiece['iLineRange'] = [i,k+1]
                            dAllPieces.append(dNewPiece)
                            i = k
                            break


        for i,dPiece in enumerate(dAllPieces):
            dPiece['sInputs'] = set(dPiece['sInputs'])
            dPiece['sOutputs'] = set(dPiece['sOutputs'])
            dAllPieces[i] = dPiece

        iOrder = list(range(len(dAllPieces)))
        for iCount in range(len(dAllPieces)): # until we don't have anymore
            bDidSomething = False
            for i in range(len(iOrder)):
                iInd = iOrder[i]
                for k in range(len(iOrder)-1, i, -1):
                    if dAllPieces[iInd]['sInputs'].intersection(dAllPieces[iOrder[k]]['sOutputs']):
                        report.report.addLogText('moving %s to after %s' % (dAllPieces[iInd]['sName'], dAllPieces[iOrder[k]]['sName']))
                        iOrder.pop(i)
                        iOrder.insert(k, iInd)
                        bDidSomething = True
                        break
            if not bDidSomething:
                break
        report.report.addLogText('sorted %d times' % iCount)

        sAllLinesCopy = list(sAllLines)
        for dPiece in dAllPieces[::-1]:
            print ('removing lines from %s' % dPiece['sName'])
            iRange = dPiece['iLineRange']
            del sAllLines[iRange[0]:iRange[1]]


        dOrderedPieces = [dAllPieces[i] for i in iOrder]

        def _getGroups(sType):
            iiGroups = []
            i = -1
            while i < len(dOrderedPieces) - 1:
                i += 1
                if dOrderedPieces[i]['sType'] == sType:
                    iiGroups.append([i, None])
                    while i < len(dOrderedPieces):
                        i += 1
                        if i >= len(dOrderedPieces) or dOrderedPieces[i]['sType'] != sType:
                            iiGroups[-1][1] = i
                            break
            return iiGroups

        # combine muscles into functions
        iiMuscleGroups = _getGroups('muscleJoint')
        for i,iMuscleGroup in enumerate(iiMuscleGroups[::-1]):
            sFunctionName = 'Muscles %s' % utils.getLetter(len(iiMuscleGroups)-i-1)
            dGroupedPiece = {}
            dGroupedPiece['sType'] = 'Muscle Group'
            sReplacedLines = ['\n', '\n']
            sReplacedLines.append("unrealUI.logMessage('%s...')\n" % sFunctionName)
            sReplacedLines.append("unrealUI.incrementProgress()\n")

            sReplacedLines.append('controllers.setNewColumn()\n')
            sReplacedLines.append("nodes.startFunction('%s') # muscle group function" % sFunctionName)
            for dPiece in dOrderedPieces[iMuscleGroup[0]:iMuscleGroup[1]]:
                iRange = dPiece['iLineRange']
                sReplacedLines.extend(['\n'] + sAllLinesCopy[iRange[0]:iRange[1]] + ['\n'])
            sReplacedLines.append("nodes.endCurrentFunction() # muscle group function")

            dGroupedPiece['sReplacedLines'] = sReplacedLines
            del dOrderedPieces[iMuscleGroup[0]:iMuscleGroup[1]]
            dOrderedPieces.insert(iMuscleGroup[0], dGroupedPiece)


        # combine blendJoints into functions
        iiBlendGroups = _getGroups('blendJoint')
        for iBlendGroup in iiBlendGroups[::-1]:
            dGroupedPiece = {}
            dGroupedPiece['sType'] = 'Blend Group'
            sReplacedLines = ['\n', '\n']
            sReplacedLines.append("unrealUI.logMessage('Blend Joints...')\n")
            sReplacedLines.append("unrealUI.incrementProgress()\n")

            sAttributeStrings = []
            for dPiece in dOrderedPieces[iBlendGroup[0]:iBlendGroup[1]]:
                iRange = dPiece['iLineRange']
                for sLine in sAllLinesCopy[iRange[0]:iRange[1]]:
                    print('sLine: ', sLine)
                    if sLine.strip().startswith('functions.blendJoints(['): # functions.blendJoints([('jnt_l_arm_lowerTwist_000Blend', 'upperarm_twist_03_l', 'lowerarm_l')])
                        iStartIndex = sLine.rfind('(')
                        iEndIndex = sLine.find(')')
                        sAttributeStrings.append(sLine[iStartIndex:iEndIndex+1])
                        break
            sReplacedLines.append('functions.blendJoints([%s]) # combined' % ', '.join(sAttributeStrings))
            dGroupedPiece['sReplacedLines'] = sReplacedLines
            del dOrderedPieces[iBlendGroup[0]:iBlendGroup[1]]
            dOrderedPieces.insert(iBlendGroup[0], dGroupedPiece)


        # with dOrderPieces create sNewLinesChain that we can later put into the File
        sNewLinesChain = []
        for dPiece in dOrderedPieces:
            sReplacedLines = dPiece['sReplacedLines']
            if sReplacedLines:
                sNewLinesChain.extend(sReplacedLines)
            else:
                iRange = dPiece['iLineRange']
                sNewLinesChain.extend(['\n'] + sAllLinesCopy[iRange[0]:iRange[1]] + ['\n'])


        # put sNewLinesChain into the File
        iStartLine = dAllPieces[0]['iLineRange'][0]
        sAllLines = sAllLines[:iStartLine] + sNewLinesChain + sAllLines[iStartLine:]
        utils.createTextFile(sFilePath, sAllLines)



@builderTools.addToBuild(iOrder=131, dButtons={}, bDisableByDefault=False)
def pythonUnrealSliderCtrls(sSkipCtrls=[]):
    utilsUnreal.generateSliderCtrlsCode(sSkipCtrls=sSkipCtrls)



@builderTools.addToBuild(iOrder=131.1, dButtons={}, bDisableByDefault=False)
def pythonUnrealSimpleLidSetup():
    sUnrealCodeLines = ['\n\n# Lid Setup\n\n']
    sUnrealCodeLines.append("unrealUI.logMessage('Lid Setup...')")
    sUnrealCodeLines.append("unrealUI.incrementProgress()")
    sUnrealCodeLines.append("sAllEyePosesFunction = nodes.startFunction('allEyePoses', bMutable=True, bSequencer=True)")

    for s, sSide in enumerate(['l', 'r']):
        utilsUnreal.newSequencerPlug(sWriteCommands=sUnrealCodeLines)

        sUnrealCodeLines.append("controllers.openCommentBox('Joint Poses %s_eye')" % sSide)

        ssUnrealTranslations = [], []
        ssUnrealRotations = [], []
        ssUnrealScales = [], []

        for p, sPart in enumerate(['bot', 'top']):
            sSiblingBlinkMain = 'grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingWideMain = 'grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraDown = 'grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraUp = 'grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sList = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp]
            for sT in sList:
                ssUnrealTranslations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.t' % sT)[0], bBoneSpace=True))
                ssUnrealRotations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.r' % sT)[0], bEuler=True, bBoneSpace=True))
                ssUnrealScales[p].append(cmds.getAttr('%s.s' % sT)[0])

        sUnrealCodeLines.append("functions.lidSetup([%s, %s, %s], \n\t\t\t[%s, %s, %s], sSide='%s', sLookVertVarName='lookVert_%s', sLookHorizVarName='lookHoriz_%s')" %
            (ssUnrealTranslations[0], ssUnrealRotations[0], ssUnrealScales[0], ssUnrealTranslations[1], ssUnrealRotations[1], ssUnrealScales[1], sSide, '%s_eye' % sSide, '%s_eye' % sSide))

        sUnrealCodeLines.append("controllers.closeCommentBox('Joint Poses %s_eye')" % sSide)

    sUnrealCodeLines.append("nodes.endCurrentFunction(bAddToExecute=True)")

    report.report.addLogText('\n'.join(sUnrealCodeLines), bPrint=True)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()




@builderTools.addToBuild(iOrder=131.2, dButtons={}, bDisableByDefault=False)
def unrealTransformSliderCtrls(dSimpleConstraints={'jnt_m_headMain':[]}, iMaxFactors=2, bOnlySimple=True):

    sUnrealCommands = ['\n\n#Transform SliderCtrl Passers\n']
    sUnrealCommands.append("unrealUI.logMessage('Transform SliderCtrl Passers...')")
    sUnrealCommands.append("unrealUI.incrementProgress()")
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox('Transform SliderCtrl Passers')")

    sAllSliderCtrls = utils.data.get(utilsUnreal.kCreatedUnrealSliderCtrls)
    sAlreadyConstrained = []
    for sJoint, sCtrls in dSimpleConstraints.items():
        sUnrealCommands.append("ePassers = nodes.createHierarchyTransformArrayNode([%s])" % ', '.join(["%s.ePasser" % sCtrl for sCtrl in sCtrls if cmds.objExists(sCtrl)]))
        sUnrealCommands.append("sForEach = nodes.createForEachExecuteNode(ePassers)")
        sUnrealCommands.append("nodes.createParentConstraintExecuteNode([(library.getElementKey('%s', 'Bone'), 1)], '%%s.Element' %% sForEach, bMaintainOffset=True)" % sJoint)
        sUnrealCommands.append("controllers.goToParentExecute()")
        sAlreadyConstrained.extend(sCtrls)

    if not bOnlySimple:

        ssJoints = [[] for _ in range(len(sAllSliderCtrls))]
        ffWeights = [[] for _ in range(len(sAllSliderCtrls))]

        # first gather joint attachment infos and create getTransformNodes..
        sCreatedGetTransformNodes = set()
        sCreatedUnrealNodes = utils.data.get('sCreatedUnrealNodes', xDefault=[])

        dFirstValues = {}
        ddProducts = defaultdict(list)

        for c,sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            cCtrl = ctrls7.ctrlFromName(sCtrl)
            sDecomp = cmds.listConnections('%s.t' % cCtrl.sPasser, s=True, d=False)[0]
            sMatrixMult = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]

            if cmds.objectType(sMatrixMult) == 'wtAddMatrix':
                sLoc = cmds.listConnections('%s.matrixIn[1]' % sMatrixMult, s=True, d=False)[0]
                if sLoc.startswith('loc_'):
                    sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
                    sBlendEnvelope = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]
                    sBlendAllInfluencesNode = cmds.listConnections('%s.wtMatrix[0].matrixIn' % sBlendEnvelope, s=True, d=False)[0]

                    for j in range(10): # per joint
                        sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sBlendAllInfluencesNode, j), s=True, d=False)
                        if j == 0:
                            sFirstMatrixConn = sMatrixConns[0]
                        if not sMatrixConns:
                            break
                        sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                        fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sBlendAllInfluencesNode, j))
                        ssJoints[c].append(sJoint)
                        ffWeights[c].append(fWeight)
                    bCheckBlendShapes = True
                else:
                    ffWeights[c] = [1.0]
                    ssJoints[c] = [sLoc]
                    bCheckBlendShapes = False
            else:
                ffWeights[c] = [1.0]
                ssJoints[c] = ['jnt_m_headMain']
                bCheckBlendShapes = False

            print ('bCheckBlendShapes: ', bCheckBlendShapes)
            if bCheckBlendShapes:
                sPointToMatrix = cmds.listConnections('%s.matrixIn[0]' % sFirstMatrixConn, s=True, d=False)[0]
                sBlendBlendShape = cmds.listConnections('%s.inputTranslate' % sPointToMatrix, s=True, d=False)[0]

                sAdditionNode = cmds.listConnections('%s.color1' % sBlendBlendShape, s=True, d=False)[0]
                fFirstValue = cmds.getAttr('%s.input3D[0]' % sAdditionNode)[0]
                dFirstValues[sCtrl] = utilsUnreal.flipVectorToUnreal(fFirstValue)

                for b in range(1, 100000, 1):
                    sMults = cmds.listConnections('%s.input3D[%d]' % (sAdditionNode, b), s=True, d=False)
                    if not sMults:
                        break
                    sRangeNode = cmds.listConnections('%s.input2X' % sMults[0], s=True, d=False)[0]
                    if sRangeNode in sCreatedUnrealNodes:
                        fValues = cmds.getAttr('%s.input1' % sMults[0])[0]
                        ddProducts[sCtrl].append(('%s_output' % sRangeNode, utilsUnreal.flipVectorToUnreal(fValues)))


        # create the blendShape nodes
        for c,sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            if sCtrl in ddProducts:
                sProducts = ddProducts[sCtrl]
            else:
                continue
            print ('sCtrl: ', sCtrl)
            print ('ddProducts[sCtrl]: ', ddProducts[sCtrl])
            fFirstValue = dFirstValues[sCtrl]
            sUnrealCommands.append("# blendShape connections")
            sUnrealCommands.append("\ncontrollers.setNewColumn()")
            i = -1
            sProductVars = []
            print ('sProducts: ', sProducts)
            sProducts = sorted(sProducts, key=lambda a:np.linalg.norm(a[1]), reverse=True)

            for sOutput, fValues in sProducts[:min(iMaxFactors, len(sProducts))]:
                i += 1
                if np.linalg.norm(fValues) < 0.001:
                    break
                sProductVars.append('sProduct_%d' % i)
                sUnrealCommands.append("%s = nodes.createBasicCalculateNode([[%0.3f, %0.3f, %0.3f], [%s,%s,%s]], sOperation='Multiply', iPinType=pins.PinType.vector)" %
                                       (sProductVars[-1], fValues[0], fValues[1], fValues[2], sOutput, sOutput, sOutput))

            sUnrealCommands.append("%s_blendShapeSum = nodes.createBasicCalculateNode([[%0.3f, %0.3f, %0.3f]] + [%s], bVector=True, sOperation='Add')" %
                                   (sCtrl, fFirstValue[0], fFirstValue[1], fFirstValue[2], ', '.join(sProductVars)))

        # create the get bone nodes
        sUnrealCommands.append("\n# create get bone nodes")
        sUnrealCommands.append("\ncontrollers.setNewColumn()")
        for c,sCtrl in enumerate(sAllSliderCtrls):
            for sJoint in ssJoints[c]:
                if '%s_initial' % sJoint not in sCreatedGetTransformNodes:
                    sUnrealCommands.append("%s_initial = nodes.getTransformNode(library.getElementKey('%s', 'Bone'), bInitial=True)" % (sJoint, sJoint))
                    sUnrealCommands.append("%s_current = nodes.getTransformNode(library.getElementKey('%s', 'Bone'))" % (sJoint, sJoint))
                    sCreatedGetTransformNodes.add('%s_initial' % sJoint)

        # now go through and connect the control passers to the previously created getTransformNodes
        sUnrealCommands.append("# connect them all to the bone nodes")
        for c, sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            sUnrealCommands.append("\ncontrollers.setNewColumn()")
            sUnrealCommands.append("%s_initial = nodes.getTransformNode(%s.ePasser, bInitial=True)" % (sCtrl, sCtrl))
            sBlendShapedCtrl = '%s_initial' % sCtrl
            if sCtrl in ddProducts:
                sBlendShapedCtrl = "[%s_blendShapeSum, '%%s.Rotation' %% %s, '%%s.Scale3D' %% %s]"  % (sCtrl, sBlendShapedCtrl, sBlendShapedCtrl)

            for j,sJoint in enumerate(ssJoints[c]):
                sUnrealCommands.append("relativeToJoint = nodes.createMakeRelativeNode(%s, %s_initial)" % (sBlendShapedCtrl, sJoint))
                sUnrealCommands.append("%s_pointMoved = nodes.createMakeAbsoluteNode(relativeToJoint, %s_current)" % (sJoint, sJoint))

            sOutTransform = '%s_pointMoved' % ssJoints[c][0]
            if len(ssJoints[c]) > 1:
                fPrevWeightSum = ffWeights[c][0]
                for jj in range(1, len(ssJoints[c]), 1):
                    fWeight = ffWeights[c][jj] / (ffWeights[c][jj] + fPrevWeightSum)
                    fPrevWeightSum += ffWeights[c][jj]
                    sInterpName = '%s_interp_%d' % (sCtrl, jj)
                    sUnrealCommands.append("%s = nodes.createTransformInterpolateNode(%0.3f, %s, %s_pointMoved)" % (sInterpName, fWeight, sOutTransform, ssJoints[c][jj]))
                    sOutTransform = sInterpName

        sUnrealCommands.append("nodes.createSetTransformExecuteNode(%s.ePasser, %s)" % (sCtrl, sOutTransform))

    sUnrealCommands.append("controllers.closeCommentBox('Transform SliderCtrl Passers')")


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()




@builderTools.addToBuild(iOrder=130.11)
def pythonCustomAttachers(bErrorOnEmptyAttachers=True):
    dUnrealJoints = utils.data.get('dUnrealJoints')

    sTransforms = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.sPuppetParentAttachment' % sT) and ':' not in sT]
    print ('sTransforms: ', sTransforms)
    ssJoints = [[] for _ in range(len(sTransforms))]
    ffWeights = [[] for _ in range(len(sTransforms))]
    bReturn = None
    for c,sTransform in enumerate(sTransforms):
        # print ('sTransform: ', sTransform)
        sDecomps = cmds.listConnections('%s.t' % sTransform, s=True, d=False) or []
        if not sDecomps:
            bReturn = False
            report.report.addLogText('No connection for attacher transform "%s"' % sTransform)
            continue
        sMatrixMult = cmds.listConnections('%s.inputMatrix' % sDecomps[0], s=True, d=False)[0]


        sLoc = cmds.listConnections('%s.matrixIn[1]' % sMatrixMult, s=True, d=False)[0]
        if sLoc.startswith('loc_'):
            sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
            sBlendEnvelopeOrAllInfluences = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]
            if sBlendEnvelopeOrAllInfluences.startswith('wtAddMatrix_blendEnvelope_'):
                sAllInfluencesNode = cmds.listConnections('%s.wtMatrix[0].matrixIn' % sBlendEnvelopeOrAllInfluences, s=True, d=False)[0]
            else:
                sAllInfluencesNode = sBlendEnvelopeOrAllInfluences

            for j in range(10): # per joint
                sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sAllInfluencesNode, j), s=True, d=False)
                if j == 0:
                    sFirstMatrixConn = sMatrixConns[0]
                if not sMatrixConns:
                    break
                sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sAllInfluencesNode, j))
                ssJoints[c].append(sJoint)
                ffWeights[c].append(fWeight)


    sFiles = [utilsUnreal.createOutFilePath(),
              utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]

    for f,sFile in enumerate(sFiles):
        with open(sFile, 'r') as file:
            sFileData = file.read()

        for sTransform, sJoints, fWeights in zip(sTransforms, ssJoints, ffWeights):
            sEntryLine = '# CUSTOMATTACHER %s' % sTransform
            sLines = [sEntryLine]
            if f == 0:
                utilsUnreal.createUnrealNull(sTransform, sTransform, sWriteCommands=sLines)
            else:
                sLines.append(f"{sTransform} = library.getElementKey('{sTransform}', 'Null')")
            sUnrealJoints = [dUnrealJoints.get(sJ,sJ) for sJ in sJoints]

            sTargets = ', '.join(["(library.getElementKey('%s', 'Bone'), %0.3f)" % (sJ,fW) for sJ,fW in zip(sUnrealJoints,fWeights)])
            sLines.append("nodes.createParentConstraintExecuteNode([%s], %s, bMaintainOffset=True)" % (sTargets, sTransform))
            sLines.append('# PIECE.INPUTS: %s' % str(sUnrealJoints))
            sFileData = sFileData.replace(sEntryLine, '\n'.join(sLines))

        with open(sFile, 'w') as file:
            file.write(sFileData)

    return bReturn





@builderTools.addToBuild(iOrder=132)
def pythonShapeCtrls():
    utils.reload2(utilsUnreal)
    sUnrealAvoidForwardLimbs = utils.data.get('sUnrealAvoidForwardLimbs')
    utilsUnreal.generateControlShapeCode(sSkipLimbs=sUnrealAvoidForwardLimbs)



dMetahumanLimbs = {}
dMetahumanLimbs['m_placement'] = ['game:root']
dMetahumanLimbs['m_neck'] = ['game:neck_01', 'game:neck_02']
dMetahumanLimbs['m_spine'] = ['game:spine_01', 'game:spine_02', 'game:spine_03', 'game:spine_04', 'game:spine_05']
dMetahumanLimbs['m_head'] = ['game:head']
dMetahumanLimbs['l_arm'] = ['game:upperarm_l', 'game:lowerarm_l', 'game:hand_l', 'game:upperarm_twist_01_l', 'game:upperarm_twist_02_l', 'game:upperarm_twist_03_l', 'game:lowerarm_twist_01_l', 'game:lowerarm_twist_02_l', 'game:lowerarm_twist_03_l']
dMetahumanLimbs['r_arm'] = ['game:upperarm_r', 'game:lowerarm_r', 'game:hand_r', 'game:upperarm_twist_01_r', 'game:upperarm_twist_02_r', 'game:upperarm_twist_03_r', 'game:lowerarm_twist_01_r', 'game:lowerarm_twist_02_r', 'game:lowerarm_twist_03_r']
dMetahumanLimbs['l_leg'] = ['game:thigh_l', 'game:calf_l', 'game:foot_l', 'game:ball_l', 'game:thigh_twist_01_l', 'game:thigh_twist_02_l', 'game:thigh_twist_03_l', 'game:calf_twist_01_l', 'game:calf_twist_02_l', 'game:calf_twist_03_l']
dMetahumanLimbs['r_leg'] = ['game:thigh_r', 'game:calf_r', 'game:foot_r', 'game:ball_r', 'game:thigh_twist_01_r', 'game:thigh_twist_02_r', 'game:thigh_twist_03_r', 'game:calf_twist_01_r', 'game:calf_twist_02_r', 'game:calf_twist_03_r']



@builderTools.addToBuild(iOrder=132.5)
def pythonReplacePuppetJoints():
    dAllUsedOutputs = utils.data.get('dAllUsedOutputs')
    print ('dAllUsedOutputs: ', dAllUsedOutputs)
    dUnrealJoints = utils.data.get('dUnrealJoints')

    bMetahumanJoints = utils.data.get('bMetahumanJoints')

    sAllJointsInGameSkeleton = cmds.listRelatives('GAMESKELETON', typ='joint', ad=True)

    for sFile in [utilsUnreal.createOutFilePath(),
                  utilsUnreal.createOutFilePath(utilsUnreal.kUnrealBackwardsCodeLines)]:

        with open(sFile, 'r') as file:
            filedata = file.read()

        for sMayaJoint, sUnrealJoint in dUnrealJoints.items():
            if sMayaJoint != sUnrealJoint:
                filedata = filedata.replace("'%s'" % sMayaJoint, "'%s'" % sUnrealJoint)


        for sMayaJoint, sLimbName in dAllUsedOutputs.items():
            if 'game:%s' % sMayaJoint not in sAllJointsInGameSkeleton:
                if sMayaJoint not in dUnrealJoints: # if it would be in there, it'd be taken care of already
                    if bMetahumanJoints and sLimbName in dMetahumanLimbs:
                        iClosest = xforms.findClosestJoints(xforms.getPositionArray([sMayaJoint]), dMetahumanLimbs[sLimbName])[0]
                        sMetahumanJoint = dMetahumanLimbs[sLimbName][iClosest].split(':')[-1]
                        filedata = filedata.replace("'%s'" % sMayaJoint, "'%s'" % sMetahumanJoint)
                    else: # could be something like m_cog that doesn't have a joint
                        sLimbNameAttr = '%s.sLimbJoint' % sMayaJoint
                        if cmds.objExists(sLimbNameAttr):
                            sModuleGrp = 'grp_%sModule' % cmds.getAttr(sLimbNameAttr)
                            sCtrls = eval(cmds.getAttr('%s.__ctrls__' % sModuleGrp))
                            iClosest = xforms.findClosestPoints(xforms.getPositionArray([sMayaJoint]), xforms.getPositionArray(sCtrls))[0]
                            filedata = filedata.replace("library.getElementKey('%s', 'Bone')" % sMayaJoint, "%s.eControl" % sCtrls[iClosest])


        with open(sFile, 'w') as file:
            file.write(filedata)



@builderTools.addToBuild(iOrder=131.15, dButtons={}, bDisableByDefault=False)
def unrealConnectBlendShapes(sLookForTargetsUnder=None):

    dDriverReplacements = {'grp_l_eyesLookAtPasser.lookVert':'sLookVert_l_eye',
                           'grp_r_eyesLookAtPasser.lookVert':'sLookVert_r_eye',
                           'grp_l_eyesLookAtPasser.lookHoriz':'sLookHoriz_l_eye',
                           'grp_r_eyesLookAtPasser.lookHoriz':'sLookHoriz_r_eye'}
    # dExtraCtrlReplacements = utils.data.get('dExtraCtrlReplacements', xDefault={})

    # dDriverReplacements.update(dExtraCtrlReplacements)

    # for i in range(100):
    #     dDriverReplacements['zipperOut_%03d' % i] = 'sZipperResults[%d]' % i

    bZipper = False

    sCreatedUnrealCtrls = utils.data.get(utilsUnreal.kCreatedUnrealCtrls)
    sTargetAttrs = utils.data.get(utilsUnreal.kBlendShapeTargetList)


    # if sLookForTargetsUnder:
    #     sTargetAttrs = _replaceTargetsWithOthers(sTargetAttrs, sLookForTargetsUnder)


    sUnrealCommands = []
    sUnrealCommands.append('\n\n# BlendShape Target Weights (Curve) Connections\n\n')

    sUnrealCommands.append("unrealUI.logMessage('Connect Blendshapes...')")
    sUnrealCommands.append("unrealUI.incrementProgress()")

    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("nodes.startFunction('kangaroo_blendShapeTargets', bSequencer=False)")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("sLookVert_l_eye = nodes.createGetVariableNode(hierarchy.Variable('lookVert_l_eye'))")
    sUnrealCommands.append("sLookHoriz_l_eye = nodes.createGetVariableNode(hierarchy.Variable('lookHoriz_l_eye'))")
    sUnrealCommands.append("sLookVert_r_eye = nodes.createGetVariableNode(hierarchy.Variable('lookVert_r_eye'))")
    sUnrealCommands.append("sLookHoriz_r_eye = nodes.createGetVariableNode(hierarchy.Variable('lookHoriz_r_eye'))")
    sUnrealCommands.append("controllers.setNewColumn()")
    # sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox('BlendShape Connections')")
    sCreatedUnrealNodes = set()
    sCompletedCurves = set()
    for sAttribute in sTargetAttrs:

        print ('%s...' % sAttribute)
        if sAttribute == None:
            continue
        sCurveAttr = sAttribute.split('.')[-1]

        if sCurveAttr in sCompletedCurves:
            continue
        else:
            sCompletedCurves.add(sCurveAttr)

        # sUnrealCommands.append("controllers.setNewColumn()")
        xxDrivers = []

        sConns = cmds.listConnections(sAttribute, s=True, d=False, p=True, skipConversionNodes=True) or []
        sNode = sConns[0].split('.')[0]

        if cmds.objectType(sNode) == 'condition':
            sRangeOutputs = eval(cmds.getAttr('%s.sFactors' % sNode)) # ['range_blink_l_ctrl_ty1.outValueX', 'range_blink_l_ctrl_upCurveBlink1.outValueX']
        else:
            sRangeOutputs = [sConns[0]]

        bAllRangesAreThere = True
        sUnrealCommands.append('\n\n# BlendShape Weight sAttribute: %s' % sAttribute)
        for sRangeOutput in sRangeOutputs:
            sRangeNode, sAttr = sRangeOutput.split('.')
            if sRangeNode.startswith('zipperOut_'):
                sName, iNumber = utils.getNumberAtEnd(sRangeNode)
                xxDrivers.append(['sZipperResults[%d]' % iNumber, (0,1,0,1)])
                bZipper = True
            else:
                sDriver = cmds.listConnections('%s.valueX' % sRangeNode, s=True, d=False, p=True, skipConversionNodes=True)[0]
                sDriverNode, sDriverAttr = sDriver.split('.')

                # sDriverUnrealCommands = [] # stupid.. we can replace that
                if sDriver in dDriverReplacements:
                    xxDrivers.append([dDriverReplacements[sDriver], nodes.getRangeFromRangeNode(sRangeNode)])
                elif sDriverNode.endswith('_ctrl'):
                    if sDriverNode not in sCreatedUnrealCtrls:
                        continue
                    if sDriverAttr.startswith('translate'):
                        sGetNodeVariableName = '%s_getTranslation' % sDriverNode
                        if sGetNodeVariableName not in sCreatedUnrealNodes:
                            sUnrealCommands.append(
                                "%s = nodes.getTransformNode(%s.eControl, bLocal=True)" % (sGetNodeVariableName, sDriverNode))
                            sCreatedUnrealNodes.add(sGetNodeVariableName)
                        if sDriverAttr == 'translateX':
                            sAxis = 'Translation.X'
                        elif sDriverAttr == 'translateY':
                            sAxis = 'Translation.Z'
                        elif sDriverAttr == 'translateZ':
                            sAxis = 'Translation.Y'
                        else:
                            raise Exception('not sure what attr "%s" is' % sDriverAttr)
                        xxDrivers.append(["'%%s.%s' %% %s" % (sAxis, sGetNodeVariableName), nodes.getRangeFromRangeNode(sRangeNode)]) # ['%s.Translation.Z' % lipsCornerLFT_ctrl_getTranslation

                        # sUnrealDriverOutAttribute = "'%%s.Translation.%s' %% %s_getTranslation" % (sAxis, sDriverNode)
                    elif sDriverAttr.startswith('rotate'):
                        sGetNodeVariableName = '%s_getRotation' % sDriverNode
                        if sGetNodeVariableName not in sCreatedUnrealNodes:
                            sUnrealCommands.append(
                                "%s = nodes.getControlRotator(%s.eControl, bLocal=True)" % (sGetNodeVariableName, sDriverNode))
                            sCreatedUnrealNodes.add(sGetNodeVariableName)
                        if sDriverAttr == 'rotateX':
                            sAxis = 'Roll'
                        elif sDriverAttr == 'rotateY':
                            sAxis = 'Yaw'
                        elif sDriverAttr == 'rotateZ':
                            sAxis = 'Pitch'
                        else:
                            raise Exception('not sure what attr "%s" is' % sDriverAttr)
                        xxDrivers.append(["'%%s.%s' %% %s" % (sAxis, sGetNodeVariableName), nodes.getRangeFromRangeNode(sRangeNode)])

                    else: # custom attributes, like upCurve blink
                        sGetNodeVariableName = '%s_%s' % (sDriverNode, sDriverAttr)
                        sUnrealCommands.append("%s = nodes.createGetChannelNodeOLD('%s', '%s')" % (sGetNodeVariableName, sDriverAttr, sDriverNode))
                        dDriverReplacements[sDriver] = sGetNodeVariableName
                        xxDrivers.append([sGetNodeVariableName, nodes.getRangeFromRangeNode(sRangeNode)])
                        # report.report.addLogText('not sure what type of attribute "%s" is' % sDriverAttr)
                        # bAllRangesAreThere = False
                        # break

        if bAllRangesAreThere and len(xxDrivers):
            sUnrealCommands.append("controllers.setNewColumn()")
            sDriverStrings = ["[%s, %s, 'VALUE']" % (xD[0], str(xD[1])) for xD in xxDrivers]
            sUnrealCommands.append("functions.curveDriver('%s', [%s])" % (sCurveAttr, ', '.join(sDriverStrings)))
    sUnrealCommands.append("controllers.closeCommentBox('BlendShape Connections')")

    if bZipper:
        dZipper = utils.data.get('dZipper')
        sZipperUnrealCommands = ['\n\n#Zipper\n']
        sZipperUnrealCommands.append("sZipperResults = functions.zipper(%d, [lipsCornerLFT_ctrl.eControl, lipsCornerRGT_ctrl.eControl])" % (dZipper['iSampleCount']))
        sUnrealCommands = sZipperUnrealCommands + sUnrealCommands

    report.report.addLogText('\n'.join(sUnrealCommands), bPrint=True)
    utils.data.addToList('sCreatedUnrealNodes', sCreatedUnrealNodes)

    sUnrealCommands.append("nodes.endCurrentFunction(bAddToExecute=True)")


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()
    # utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealCommands)
    # utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)


@builderTools.addToBuild(iOrder=131.11, dButtons={}, bDisableByDefault=True)
def unrealConnectControlsToAppleCurves(fLookUpDownInOutTranslate=[15, -15, -15, 15]):
    sUnrealMocapBackwardsCodeLines = []
    sUnrealMocapBackwardsCodeLines.append('\n\n# BlendShape Target Weights (Curve) Connections (Apple) \n\n')

    fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation')
    fJawOpenTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation')

    dDict = {}
    dDict['blink_l_ctrl.translateZ'] = [(-1, 'eyeBlinkLeft'), (0.5, 'eyeWideLeft')]
    dDict['blink_r_ctrl.translateZ'] = [(-1, 'eyeBlinkRight'), (0.5, 'eyeWideRight')]
    dDict['innerEyebrow_l_ctrl.translateZ'] = [(-1, 'browDownLeft'), (1, 'browInnerUp')]
    dDict['innerEyebrow_r_ctrl.translateZ'] = [(-1, 'browDownRight'), (1, 'browInnerUp')]
    dDict['outerEyebrow_l_ctrl.translateZ'] = [(1, 'browOuterUpLeft')]
    dDict['outerEyebrow_r_ctrl.translateZ'] = [(1, 'browOuterUpRight')]
    dDict['cheekRaiser_l_ctrl.translateZ'] = [(1, 'cheekSquintLeft')]
    dDict['cheekRaiser_r_ctrl.translateZ'] = [(1, 'cheekSquintRight')]
    dDict['puff_l_ctrl.translateZ'] = [(1, 'cheekPuff')]
    dDict['puff_r_ctrl.translateZ'] = [(1, 'cheekPuff')]
    dDict['jaw_ctrl.rotateY'] = [(-fJawOpenRotation[2], 'jawOpen')]
    dDict['jaw_ctrl.translateY'] = [(-3.0, 'jawLeft')]
    dDict['jaw_ctrl.translateY'] = [(3.0, 'jawRight')]
    dDict['jaw_ctrl.translateX'] = [(3.0, 'jawForward')]
    dDict['mouth_ctrl.translateY'] = [(1.0, 'mouthFunnel')]

    dDict['mouthBot_ctrl.translateY'] = [(-1.0, 'mouthRollLower'), (1.0, 'mouthShrugLower')]
    dDict['mouthTop_ctrl.translateY'] = [(-1.0, 'mouthRollUpper'), (1.0, 'mouthShrugUpper')]

    dDict['lipsBot_l_ctrl.translateZ'] = [(-1.0, 'mouthLowerDownLeft')]
    dDict['lipsBot_r_ctrl.translateZ'] = [(-1.0, 'mouthLowerDownRight')]
    dDict['lipsTop_l_ctrl.translateZ'] = [(1.0, 'mouthUpperUpLeft')]
    dDict['lipsTop_r_ctrl.translateZ'] = [(1.0, 'mouthUpperUpRight')]

    dDict['noseWrinkler_l_ctrl.translateZ'] = [(1.0, 'noseSneerLeft')]
    dDict['noseWrinkler_r_ctrl.translateZ'] = [(1.0, 'noseSneerRight')]
    dDict['lipsCorner_l_ctrl.translateX'] = [(1.0, 'mouthDimpleLeft')]
    dDict['lipsCorner_r_ctrl.translateX'] = [(1.0, 'mouthDimpleRight')]
    dDict['lipsCorner_l_ctrl.translateX'] = [(-1.0, 'mouthPucker')]
    dDict['lipsCorner_r_ctrl.translateX'] = [(-1.0, 'mouthPucker')]
    dDict['lipsCorner_l_ctrl.translateZ'] = [(1.0, 'mouthSmileLeft'), (-1.0, 'mouthFrownLeft')]
    dDict['lipsCorner_r_ctrl.translateZ'] = [(1.0, 'mouthSmileRight'), (-1.0, 'mouthFrownRight')]
    dDict['lipSretch_l_ctrl.translateZ'] = [(1.0, 'mouthStretchLeft')]
    dDict['lipSretch_r_ctrl.translateZ'] = [(1.0, 'mouthStretchRight')]

    fUp, fDown, fIn, fOut = fLookUpDownInOutTranslate
    dDict['eyesLookAt_l_ctrl.translateZ'] = [(fUp, 'eyeLookUpLeft'), (fDown, 'eyeLookDownLeft')]
    dDict['eyesLookAt_l_ctrl.translateX'] = [(fIn, 'eyeLookInLeft'), (fOut, 'eyeLookOutLeft')]
    dDict['eyesLookAt_r_ctrl.translateZ'] = [(fUp, 'eyeLookUpRight'), (fDown, 'eyeLookDownRight')]
    dDict['eyesLookAt_r_ctrl.translateX'] = [(fIn, 'eyeLookInRight'), (fOut, 'eyeLookOutRight')]

    dDictExisting = {sControlValue: xPoses for sControlValue, xPoses in dDict.items() if cmds.objExists(sControlValue)}
    sUnrealMocapBackwardsCodeLines.append("functions.moveCtrlsByAppleCurves(%s)" % str(dDictExisting))

    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealMocapBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)

    # utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealMocapBackwardsCodeLines)
    # utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)

    # drive apple curves in Maya
    sCurveNames = []
    for _, xPoses in dDictExisting.items():
        sCurveNames.extend([y for x, y in xPoses])
    sTargets = unreal.addEmptyUnrealTargets(sCurveNames)
    print('sTargets: ', sTargets)
    dTargets = {sTarget.split('.')[-1]: sTarget for sTarget in sTargets}

    sConnected = set()
    for sUnrealCtrlAttr, xPoses in dDictExisting.items():
        if sUnrealCtrlAttr.endswith('Y'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Y', 'Z')
        elif sUnrealCtrlAttr.endswith('Z'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Z', 'Y')
        elif sUnrealCtrlAttr.endswith('X'):
            sMayaCtrlAttr = sUnrealCtrlAttr
        else:
            raise Exception('attribute %s not supported' % sUnrealCtrlAttr)

        for fPose, sCurve in xPoses:
            if sCurve not in sConnected:
                nodes.createRangeNode(sMayaCtrlAttr, 0, fPose, 0, 1, sTarget=dTargets[sCurve],
                                      sName='appleCurve_%s' % sMayaCtrlAttr)
                sConnected.add(sCurve)





@builderTools.addToBuild(iOrder=131.05, dButtons={}, bDisableByDefault=True)
def pythonPostCtrls():
    sUnrealCommands = ['\n\n#Creating Post Ctrls\n']

    # sCtrls = ['eyelidMidBotLFT_ctrl']
    sCtrls = utils.data.get('sAllPostCtrlsForUnreal')
    sCreatedCtrls = []
    for sCtrl in sCtrls:
        cCtrl = ctrls7.ctrlFromName(sCtrl)
        fColor = cmds.getAttr('%s.overrideColorRGB' % cCtrl.sShape)[0]
        fSliderScale = cmds.getAttr('%s.sx' % cCtrl.sSlider)
        sUnrealCommands.append(utilsUnreal.createUnrealCtrl(cCtrl, sShapeName='Box_Solid', fSize=0.018 / fSliderScale, fOverwriteColor=fColor)[1])
        sCreatedCtrls.append(sCtrl)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utils.data.addToList(utilsUnreal.kCreatedUnrealSliderCtrls, sCreatedCtrls)
    utils.data.addToList(utilsUnreal.kCreatedUnrealCtrls, sCreatedCtrls)
    utilsUnreal.dumpUnrealCodeLinesToFile()

