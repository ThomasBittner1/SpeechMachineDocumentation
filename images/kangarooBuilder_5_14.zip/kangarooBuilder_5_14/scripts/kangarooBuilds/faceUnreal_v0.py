###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from collections import OrderedDict, defaultdict
import numpy as np
import os
import kangarooTools.patch as patch
import math
import time
import pickle
import traceback

import kangarooTabTools.builder as builderTools

import maya.cmds as cmds
import maya.mel as mel
import kangarooTools.utilFunctions as utils
import kangarooTools.deformers as deformers
import kangarooTools.barycentric as barycentric
import kangarooTools.topology as topology
import kangarooTools.curves as curves
import kangarooTools.surfaces as surfaces
import kangarooTools.nodes as nodes
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.sliderCtrls as sliderCtrls
import kangarooTabTools.weights as weights
import kangarooTabTools.ctrls as ctrls
import kangarooTabTools.unreal as unreal
import kangarooTabTools.geometry as geometry
import maya.api.OpenMaya as OpenMaya2
import kangarooLimbs.spine_v1 as spine

# import kangarooTabTools.poser as poser

iColorIndexCtrls = 0
bPolyCtrls = False
kBuilderColor = utils.uiColors.orange  # '#39a9f4'


sHeadCtrl = None
def headCtrl():
    global sHeadCtrl
    if sHeadCtrl == None:
        sHeadCtrl = utils.translateCtrlName('ctrl_m_head')
    return sHeadCtrl

sJawCtrl = None
def jawCtrl():
    global sJawCtrl
    if sJawCtrl == None:
        sJawCtrl = utils.translateCtrlName('ctrl_m_jaw')
    return sJawCtrl


def exportBps(sFileName, sGroup, _report=None):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    sMessage = 'exporting "%s" to "%s" ' % (sGroup, sFile)
    print(sMessage)
    print('_report: ', _report)
    if _report:
        _report.addLogText(sMessage)
    utils.createFolderIfNotExists(sFile)

    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #


def createTransformFromSelectedPoints(sName, sParent, bLockToMiddle=False, sSkinningSphere=None, bNoTransform=False):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.spaceLocator(n=sName)[0]
    print('aMean: ', aMean)
    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))

    if bLockToMiddle:
        for sL in ['%s.%s' % (sLoc, sAttr) for sAttr in ['tx', 'ry', 'rz']]:
            cmds.setAttr(sL, 0.0)
            cmds.setAttr(sL, lock=True)

    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        print('bNoTransform:', bNoTransform)
        if bNoTransform:
            cmds.parent(sSkinningSphere, sParent)
            cmds.delete(sLoc)
    return sLoc


def createMatrixCtrlromSelectedPoints(sName, sParent, sSkinningSphere=None, fRotate=(0,0,0)):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    fnMesh = OpenMaya2.MFnMesh(pSel.mDagPath)
    _, mNormal, _ = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(list(aMean)), space=OpenMaya2.MSpace.kWorld)

    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    xforms.orientThreePoints(sLoc, (mNormal.x, mNormal.y, mNormal.z), (0, 0, -1), fAimVector=(0, 0, 1),
                             fUpVector=(1, 0, 0))

    cmds.rotate(fRotate[0], fRotate[1], fRotate[2], sLoc, r=True, os=True)
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))
    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        cmds.parent(sSkinningSphere, sParent)


def mirrorGroup(sGrp, bDeleteNewChildren=False):
    sMirrorName = utils.getMirrorName(sGrp)
    if not cmds.objExists(sMirrorName):
        if not cmds.objExists(sGrp):
            return None
        sMirrorGrp = cmds.duplicate(sGrp, n=sMirrorName)[0]
        if bDeleteNewChildren:
            cmds.delete(cmds.listRelatives(sMirrorGrp, c=True, f=True))

        sTemp = cmds.createNode('transform')
        sOldParent = cmds.listRelatives(sMirrorGrp, p=True)
        cmds.parent(sMirrorGrp, sTemp)
        cmds.setAttr('%s.sx' % sTemp, -1)
        if sOldParent:
            cmds.parent(sMirrorGrp, sOldParent)
        else:
            cmds.parent(sMirrorGrp, w=True)
        # cmds.setAttr('%s.tx' % sMirrorGrp, -cmds.getAttr('%s.tx' % sMirrorGrp))

        cmds.delete(sTemp)
        return sMirrorGrp
    return sMirrorName


def createBpCurve(sName, sParent, fDirection=(1, 0, 0), bTrackedOrder=False):  # , bInToOut=None, bBotToTop=None):
    if cmds.objExists(sName):
        cmds.delete(sName)
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sCurve = curves.createCurveFromSelectedVerts(sName=sName, fDirection=fDirection,
                                                 bTrackedSelectionOrder=bTrackedOrder)
    utils.addStringAttr(sCurve, 'sMesh', sMesh)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.select(sCurve)


def createBothBpCurves(sName, sParent, fDirection=(1, 0, 0)):
    # if cmds.objExists(sName): cmds.delete(sName)
    utils.reload2(curves)
    sCurve, sLocA, sLocB = curves.createCurveWithSeparationLocs(sName, fDirection=fDirection)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.parent(sLocA, sLocB, sCurve)
    cmds.select(sCurve)


def createBpUpVectorCurve(sName, sMainCurve):
    sMesh = cmds.getAttr('%s.sMesh' % sMainCurve)
    if not cmds.objExists(sMainCurve):
        raise Exception('"%s" doesn\'t exist - make sure you run the previous steps' % sMainCurve)
    if not cmds.objExists(sMesh):
        raise Exception('"%s" doesn\'t exist anymore' % sMesh)

    fClosest = cmds.kt_findClosestPoints(fromMesh=sMainCurve, toMesh=sMesh, returnNormals=True)
    aClosest = np.array(fClosest, dtype='float64').reshape(-1, 6)
    aNormals = aClosest[:, 3:6]
    aNormals /= np.linalg.norm(aNormals, axis=1).reshape(-1, 1)
    fLength = curves.getLength(sMainCurve)

    if cmds.objExists(sName):
        cmds.delete(sName)
    sNewCurve = cmds.duplicate(sMainCurve, n=sName)[0]
    pNewCurve = patch.patchFromName(sNewCurve)
    aPushedOutPoints = pNewCurve.getPoints() + aNormals * (fLength * 0.1)
    pNewCurve.setPoints(aPushedOutPoints)


def _getFaceCtrlGrp():
    sName = 'faceCtrls'
    if not cmds.objExists(sName):
        sSelBefore = cmds.ls(sl=True)
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.ctrlVis' % sMaster, '%s.v' % sName)
        cmds.select(sSelBefore)

    return sName


# def _getFaceCtrlHeadSpaceGrp(sParentJoint='jnt_m_headMain'):
#     sName = 'faceCtrlsSpace_%s' % sParentJoint
#     if not cmds.objExists(sName):
#         sSelBefore = cmds.ls(sl=True)
#         xforms.createOrReturnTopGroup(sName, sParent=_getFaceCtrlGrp())
#         xforms.matrixParentConstraint(sParentJoint, sName)
#         cmds.select(sSelBefore)
#     return sName


def getFaceGrp():
    sName = 'faceRig'
    if not cmds.objExists(sName):
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sName)
    return sName


def getParentJointOrigin(sParentJoint):
    sName = '%sOrigin' % sParentJoint
    if not cmds.objExists(sName):
        xforms.createJoint(sName, sParent=getFaceGrp(), sMatch=sParentJoint)
    return sName



# to do: get rid of eyelash values
@builderTools.addToBuild(iOrder=20, dButtons={})
def preSetup(sBodyMeshes=['Realistic_White_Male_Low_Poly'], sExtraMeshes=[], _report=None):
    '''
    this creates a __faceData__ object that holds important info about geometry etc.
    Make sure you set the mesh names at the bottom
    '''

    print('sBodyMeshes: ', sBodyMeshes)

    cmds.createNode('joint', name='jnt_m_faceZero', p=getFaceGrp())
    utils.data.store('allBodyMeshes', sBodyMeshes, sNode=utils.kFaceDataNode)
    sBodyMesh = sBodyMeshes[0]

    sMapMesh = cmds.duplicate(sBodyMesh, n='MAPS__%s' % sBodyMesh)
    cmds.parent(sMapMesh, w=True)


    sImportPath = assets.assetManager.getCurrentVersionPath(sSubPath='maps/')
    if not os.path.exists(sImportPath):
        cmds.warning('path doesn\'t exist')
        return False

    if sImportPath:
        sFiles = utils.listFilesInFolder(sImportPath, sEndswith=['.map'], bAbsolute=True)
        # sFiles = [os.path.join(sImportPath, sF) for sF in sFilesNames]
        print('sFiles: ', sFiles)
        if _report: _report.resetProgress(len(sFiles))

        for sFile in sFiles:
            _report.addLogText('importing %s' % sFile)
            sName = os.path.basename(sFile).split('.')[0]
            sDeformer = cmds.deformer(sMapMesh, type='cluster', n='MAP__%s' % sName)[0]
            aValues = geometry.getMapFromFile(sFile)
            cmds.setAttr(geometry._getMapAttr(sDeformer), *list(aValues))
            _report.incrementProgress()


    # create no_PreJoints mesh
    sDupl = cmds.duplicate(sBodyMesh, n='%s_noPreJoints' % sBodyMesh)[0]
    cmds.parent(sDupl, w=True)
    cmds.setAttr('%s.v' % sDupl, False)








kTeethBpGroupName = '_grp_m_teethBps'
kTeethBpFileName = 'faceBlueprintsTeeth.ma'

def SelectTeethJoints():
    cmds.select(['jnt_m_topTeeth', 'jnt_m_botTeeth'])


dButtons = OrderedDict()
dButtons['Top Teeth Locator'] = lambda: createTransformFromSelectedPoints('bp_m_topTeeth', kTeethBpGroupName,
                                                                  bLockToMiddle=True)
dButtons['Bottom Teeth Locator'] = lambda: createTransformFromSelectedPoints('bp_m_botTeeth', kTeethBpGroupName,
                                                                     bLockToMiddle=True)
dButtons['Select Joints'] = SelectTeethJoints
dButtons['Export Teeth BPs'] = lambda: exportBps(kTeethBpFileName, kTeethBpGroupName)


@builderTools.addToBuild(iOrder=47, dButtons=dButtons)
def createTeethSetup(sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain', _report=None):


    sBps = ['bp_m_botTeeth', 'bp_m_topTeeth']
    fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode) #cmds.getAttr('jnt_m_jawEnd.tx') * 0.2

    sTeethGrpOrigin = cmds.createNode('transform', name='grp_m_teethOrigin', parent=getFaceGrp())
    cCtrls = []
    for p, sPart in enumerate(['bot', 'top']):
        sBp = sBps[p]
        cC = ctrls.create(sName='%sTeeth' % sPart, sSide='m', sParent=_getFaceCtrlGrp(), sShape='squareY',
                                fRotateShape=[0, 0, 0],
                                sMatch=sBp, iColorIndex=iColorIndexCtrls, sLockHide=['v'], fSize=0.2)
        cC.sJoint = xforms.createJoint('jnt_m_%sTeeth' % sPart, fSize=fSliderScale * 0.1, sParent=cC.sOut)
        cmds.setAttr('%s.v' % cC.sJoint, False)
        cCtrls.append(cC)

        sSliderOffset = cC.appendOffsetGroup('slider', bAboveCtrl=True)
        cmds.setAttr('%s.s' % sSliderOffset, fSliderScale, fSliderScale, fSliderScale)
        cmds.setAttr('%s.s' % cC.sOut, 1.0 / (fSliderScale), 1.0 / fSliderScale, 1.0 / fSliderScale)
        cC.iPart = p

    xforms.matrixParentConstraint(sJawJoint, cCtrls[0].sPasser, mo=True)
    xforms.matrixParentConstraint(sParentJoint, cCtrls[1].sPasser, mo=True)

# ***************************
# **** END OF Teeth   *******
# ***************************








kMouthBpGroupName = '_grp_m_mouthBps'
kMouthBpFileName = 'faceBlueprintsMouth.ma'


dButtons = OrderedDict()
dButtons['Create Inner Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsA', kMouthBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['Create Inner Curves and Locators'].dSideButtons = {'?':['Select the most inner vertex loop, and then place the locators as needed,'\
                                                    '\nto indicate splitting point between bottom and top.'
                                                    '\nThe curve will be broken up at a random point, but that\'s ok. Ideally the '\
                                                    '\nbottom and top part of the curves will be a close together as possible,'\
                                                    '\nbut that\'s depending on the model.' 
                                                    '\nIMPORTANT: if at the front the top lip part is lower then the bottom lip part, '\
                                                    '\nyou need to set bFlipInnerBpCurves to True', 'mouthInnerCurves.JPG']}

dButtons['Create Outer Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsB', kMouthBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['Create Outer Curves and Locators'].dSideButtons = {'?':['Select the row for the outer curve. This is mainly for the control positions',
                                                      'mouthOuterCurves.JPG']}
dButtons['Export Mouth BPs'] = lambda: exportBps(kMouthBpFileName, kMouthBpGroupName)




@builderTools.addToBuild(iOrder=23, dButtons=dButtons)
def createMouthSetup(sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain', bFlipInnerBpCurves=False, bDoubleSideCtrls=False, bTopLipsDown=False, bBotLipsUp=False):
    utils.reload2(sliderCtrls)
    for s,sSide in enumerate(['l','r']):
        sBp = 'bpNurbs_%s_cornerSlidePlane' % sSide
        if cmds.objExists(sBp):
            cmds.duplicate(sBp, n=utils.replaceStringStart(sBp, 'bpN', 'n'))

    # get blueprints
    #
    fLipCtrlScale = 1.0
    sBpCurvesA = ['bpCurve_m_%sLipA' % sPart for sPart in ['bot', 'top']]
    sBpCurvesB = ['bpCurve_m_%sLipB' % sPart for sPart in ['bot', 'top']]

    if bFlipInnerBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs('bpCurve_m_lipsA', 'locA_m_lipsA', 'locB_m_lipsA', sBpCurvesA[1], sBpCurvesA[0])
    else:
        curves.separateCurveUsingSeparationLocs('bpCurve_m_lipsA', 'locA_m_lipsA', 'locB_m_lipsA', sBpCurvesA[0], sBpCurvesA[1])

    curves.separateCurveUsingSeparationLocs('bpCurve_m_lipsB', 'locA_m_lipsB', 'locB_m_lipsB', sBpCurvesB[0], sBpCurvesB[1])

    # sFaceMesh = utils.data.get('faceMeshes', sNode=utils.kFaceDataNode)[iMeshIndex]
    sBodyMesh = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]

    # sMouthGrpOrigin = cmds.createNode('transform', n='grp_mouthOrigin', p=getFaceGrp())

    fSliderScale = curves.getLength(sBpCurvesA[0]) * 0.1
    utils.data.store('mouthSliderScale', fSliderScale, sNode=utils.kFaceDataNode)

    aBotMiddle = curves.getPointsFromPercs(sBpCurvesA[0], [0.5], bReturnNumpy=True)[0]
    aTopMiddle = curves.getPointsFromPercs(sBpCurvesA[1], [0.5], bReturnNumpy=True)[0]
    aMouthCtrlFront = (aTopMiddle + aBotMiddle) * 0.5


    sMouthTransformOrigin = cmds.createNode('transform', n='sMouthTransformOrigin', p=getFaceGrp())

    cmds.setAttr('%s.t' % sMouthTransformOrigin, *list(aMouthCtrlFront))
    sMouthGrpJoints = cmds.createNode('transform', n='grp_m_mouthJoints',
                                      p=sMouthTransformOrigin)  # an origin group, because below are nodes getting curveInfo datas
    cmds.move(0, 0, 0, sMouthGrpJoints, ws=True, a=True)



    aCtrlPercs = np.array([0.0, 0.25, 0.5, 0.75, 1.0], dtype='float64')

    ffCtrlPoints = []
    ffCtrlPoints.append(curves.getPointsFromPercs(sBpCurvesB[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPoints.append(curves.getPointsFromPercs(sBpCurvesB[1], aCtrlPercs, bReturnNumpy=True))
    iMidInd = 2

    # cMouthTransform
    cMouthTransform = ctrls.create(sName='mouth', sSide='m', sLockHide=['v', 'r', 's', 'ro'], bPoly=bPolyCtrls,
                                   sShape='locator', sParent=_getFaceCtrlGrp(), fMatchPos=aMouthCtrlFront,
                                   fSize=2.5)
    sliderCtrls._addSliderGroups(cMouthTransform, False)
    cmds.transformLimits(cMouthTransform.sCtrl, tx=(-1, 1), etx=(True, True))
    cmds.transformLimits(cMouthTransform.sCtrl, ty=(-1, 1), ety=(True, True))
    cmds.setAttr('%s.s' % cMouthTransform.sSlider, fSliderScale, fSliderScale, fSliderScale)

    cBotTop = []
    for p,sPart in enumerate(['bot','top']):
        cC = sliderCtrls.createSliderCtrl('mouth%s' % utils.getFirstLetterUpperCase(sPart), 'm', sShape='cube', fBpPos=ffCtrlPoints[p][iMidInd],
                                          bBorder=False, fScaleShape=[5,0.5,0.5], fRangeX=[-1,1], fRangeY=[-1,1], fRangeZ=[-1,1],
                                          sAttach=sJawJoint if p == 0 else sParentJoint)[0]
        cBotTop.append(cC)
        cmds.setAttr('%s.s' % cC.sSlider, fSliderScale, fSliderScale, fSliderScale)

    xforms.matrixParentConstraint(sParentJoint, cMouthTransform.sPasser, mo=True)


    cLeft, cRight = sliderCtrls.createSliderCtrl('lipsCorner', 'l', fBpPos=ffCtrlPoints[0][0], fRangeX=[-1.0,1.0], fRangeY=[-1.0,1.0], sShape='cube', sAttach=sBodyMesh)

    if not bDoubleSideCtrls:
        cTopLeft,cTopRight = sliderCtrls.createSliderCtrl('lipsTop', sSide='l', fBpPos=ffCtrlPoints[1][1], sAttach=sBodyMesh,
                                                          fRangeY=[-1.0 if bTopLipsDown else 0.0, 1.0], dAuto={'auto:%s.ty:ty:1.0' % cBotTop[1].sCtrl:[0.0, 1.0, 0.0, 1.0]})
        cBotLeft, cBotRight = sliderCtrls.createSliderCtrl('lipsBot', sSide='l', fBpPos=ffCtrlPoints[0][1], sAttach=sBodyMesh,
                                                           fRangeY=[-1.0, 1.0 if bBotLipsUp else 0.0], dAuto={'auto:%s.ty:ty:1.0' % cBotTop[0].sCtrl:[0.0, -1.0, 0.0, -1.0]})


    cCornerCtrls = [cLeft, cRight]
    cccSideCtrls = [[[cBotLeft], [cBotRight]], [[cTopLeft], [cTopRight]]]
    ccLeftToRight = [[cCornerCtrls[0], cccSideCtrls[p][0][0], cccSideCtrls[p][1][0], cCornerCtrls[1]] for p in [0, 1]]


    for p, sPart in enumerate(['bot', 'top']):
        sList = [cC.sCtrl for cC in ccLeftToRight[p]]
        utils.data.store('%sLipCtrlsLocal' % sPart, str(sList), sNode=utils.kFaceDataNode)


    for p, sPart in enumerate(['bot', 'top']):
        for c, cC in enumerate(ccLeftToRight[p]):
            if p == 1 and c in [0, len(ccLeftToRight[p]) - 1]:
                continue

            fSideMultipl = -1 if cC.sSide == 'r' else 1
            cmds.setAttr('%s.s' % cC.sSlider, fSliderScale * fSideMultipl, fSliderScale * fSideMultipl, fSliderScale * fSideMultipl)



    for s,sSide in enumerate(['l','r']):
        xforms.createBarycentricCornerWeightsAttrs('%s.t' % cCornerCtrls[s].sCtrl, sSide, cCornerCtrls[s].sCtrl)







kMouthPreBpGroupName = '_grp_m_mouthBpsPRE'
kMouthPreBpFileName = 'faceBlueprintsMouthPRE.ma'




dButtons = OrderedDict()
dButtons['Create Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_preLips', kMouthPreBpGroupName, fDirection=(-1, 0, 0))
def exportPreMouthBps(_report=None):
    exportBps(kMouthPreBpFileName, kMouthPreBpGroupName, _report=_report)
dButtons['Export Mouth Pre BPs'] = lambda: exportBps(kMouthPreBpFileName, kMouthPreBpGroupName)



@builderTools.addToBuild(iOrder=52, dButtons=dButtons, bDisableByDefault=True)
def PRE_mouth(sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain', bFlipInnerBpCurves=False, bDoubleSideCtrls=False, bStraightCornerCtrls=True, sSeals=['mouth_ctrl.lipSeal']):
    sMouthPreGrp = cmds.createNode('transform', n='grp_preMouthOrigin', p=getFaceGrp())
    sPreCtrls = cmds.createNode('transform', n='grp_mouthPreCtrls', p='ctrls')
    sBody = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]

    sBpCurves = ['bpCurve_m_botPreLips' , 'bpCurve_m_topPreLips']

    # sBpCurves = ['bpCurve_m_%sPreLips' % sPart for sPart in ['bot', 'top']]
    if bFlipInnerBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs('bpCurve_m_preLips', 'locA_m_preLips', 'locB_m_preLips', sBpCurves[1], sBpCurves[0])
    else:
        curves.separateCurveUsingSeparationLocs('bpCurve_m_preLips', 'locA_m_preLips', 'locB_m_preLips', sBpCurves[0], sBpCurves[1])

    dCommonFlags = {'sShape':'cube', 'fSize':1, #0.5,
                    'sParent': sPreCtrls, 'iColorIndex': 2}

    if not bDoubleSideCtrls:
        iMidInd = 2
        aCtrlPercs = np.array([0.0, 0.25, 0.5, 0.75, 1.0], dtype='float64')
    else:
        iMidInd = 3
        aCtrlPercs = np.array([0.0, 0.16666, 0.3333, 0.5, 0.6666, 0.83333, 1.0], dtype='float64')

    ffCtrlPoints = []
    ffCtrlPoints.append(curves.getPointsFromPercs(sBpCurves[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPoints.append(curves.getPointsFromPercs(sBpCurves[1], aCtrlPercs, bReturnNumpy=True))


    fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode)


    cLeft = ctrls.create(sName='preLipsCorner', sSide='l', fMatchPos=ffCtrlPoints[0][0], **dCommonFlags)
    cRight = ctrls.create(sName='preLipsCorner', sSide='r', fMatchPos=ffCtrlPoints[0][-1], **dCommonFlags)
    cTop = ctrls.create(sName='preLipsTop', sSide='m', fMatchPos=ffCtrlPoints[1][iMidInd], **dCommonFlags)
    cBot = ctrls.create(sName='preLipsBot', sSide='m', fMatchPos=ffCtrlPoints[0][iMidInd], **dCommonFlags)

    if not bDoubleSideCtrls:
        cTopLeft = ctrls.create(sName='preLipsTop', sSide='l', fMatchPos=ffCtrlPoints[1][1], **dCommonFlags)
        cTopRight = ctrls.create(sName='preLipsTop', sSide='r', fMatchPos=ffCtrlPoints[1][3], **dCommonFlags)
        cBotLeft = ctrls.create(sName='preLipsBot', sSide='l', fMatchPos=ffCtrlPoints[0][1], **dCommonFlags)
        cBotRight = ctrls.create(sName='preLipsBot', sSide='r', fMatchPos=ffCtrlPoints[0][3], **dCommonFlags)
    else:
        cTopLeftA = ctrls.create(sName='preLipsTopA', sSide='l', fMatchPos=ffCtrlPoints[1][1], **dCommonFlags)
        cTopRightA = ctrls.create(sName='preLipsTopA', sSide='r', fMatchPos=ffCtrlPoints[1][5], **dCommonFlags)
        cBotLeftA = ctrls.create(sName='preLipsBotA', sSide='l', fMatchPos=ffCtrlPoints[0][1], **dCommonFlags)
        cBotRightA = ctrls.create(sName='preLipsBotA', sSide='r', fMatchPos=ffCtrlPoints[0][5], **dCommonFlags)
        cTopLeftB = ctrls.create(sName='preLipsTopB', sSide='l', fMatchPos=ffCtrlPoints[1][2], **dCommonFlags)
        cTopRightB = ctrls.create(sName='preLipsTopB', sSide='r', fMatchPos=ffCtrlPoints[1][4], **dCommonFlags)
        cBotLeftB = ctrls.create(sName='preLipsBotB', sSide='l', fMatchPos=ffCtrlPoints[0][2], **dCommonFlags)
        cBotRightB = ctrls.create(sName='preLipsBotB', sSide='r', fMatchPos=ffCtrlPoints[0][4],  **dCommonFlags)


    cCornerCtrls = [cLeft, cRight]
    cMidCtrls = [cBot, cTop]

    if not bDoubleSideCtrls:
        cccSideCtrls = [[[cBotLeft], [cBotRight]], [[cTopLeft], [cTopRight]]]
        ccLeftToRight = [[cCornerCtrls[0], cccSideCtrls[p][0][0], cMidCtrls[p], cccSideCtrls[p][1][0], cCornerCtrls[1]] for p in [0, 1]]
        cAllLipCtrls = [cLeft, cRight, cTop, cBot, cTopLeft, cTopRight, cBotLeft, cBotRight]
    else:
        cccSideCtrls = [[[cBotLeftA,cBotLeftB], [cBotRightA,cBotRightB]], [[cTopLeftA,cTopLeftB], [cTopRightA,cTopRightB]]]
        ccLeftToRight = [[cCornerCtrls[0], cccSideCtrls[p][0][0], cccSideCtrls[p][0][1], cMidCtrls[p], cccSideCtrls[p][1][1], cccSideCtrls[p][1][0], cCornerCtrls[1]] for p in [0, 1]]
        cAllLipCtrls = [cLeft, cRight, cTop, cBot, cTopLeftA, cTopLeftB, cTopRightA, cTopRightB, cBotLeftA, cBotLeftB, cBotRightA, cBotRightB]


    for cC in cAllLipCtrls:
        cC.aPoint = np.array(cmds.xform(cC.sCtrl, q=True, ws=True, t=True), dtype='float64')



    # orient the controls and make side controls move with corner controls
    for s, sSide in enumerate(['l', 'r']):

        fSideMultipl = -1 if sSide == 'r' else 1
        sLocalAimPos = ((cccSideCtrls[0][s][0].aPoint + cccSideCtrls[1][s][0].aPoint) * 0.5) - cCornerCtrls[s].aPoint
        if bStraightCornerCtrls:
            sLocalAimPos[1] = 0

        sTempAim = xforms.createLocator('temp', xPos=cCornerCtrls[s].aPoint+sLocalAimPos)
        cmds.delete(cmds.aimConstraint(sTempAim, cCornerCtrls[s].sPasser, wut='object', aim=[-fSideMultipl,0,0], u=[0,-fSideMultipl,0]))

        for p,sPart in enumerate(['bot','top']):
            aParams = curves.getParamsFromPoints(sBpCurves[p], [cC.aPoint for cC in ccLeftToRight[p]], bReturnNumpy=True)
            aTangents = curves.getTangentsFromParams(sBpCurves[p], aParams, bReturnNumpy=True)
            for c,cC in enumerate(ccLeftToRight[p][1:-1]):
                c += 1
                fSideMultipl = -1.0 if cC.sSide == 'r' else 1.0
                xforms.orientThreePoints(cC.sPasser,
                                         [1,0,0] if c == iMidInd else -aTangents[c],
                                         [0,fSideMultipl,0])

    # create geo attach locators
    sBody = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]
    aClosestIds = xforms.getClosestIdsFromPoints(sBody, xforms.getPositionArray([cC.sCtrl for cC in cAllLipCtrls]))
    sModel = '%s_noPreJoints' % sBody
    sLocs = deformers.blendShapeSkinClusterToPositions(sModel, aClosestIds, sBlendShape='blendShape__%s' % sModel, sParent=sMouthPreGrp,
                                                     fTargetMinimumDistance=0.01, bDoSkinCluster=True, sScaleJoint=sParentJoint, bConnectEnvelopes=False,
                                                     sSkinClusters=['skinCluster__%s' % sModel])



    for c,cC in enumerate(cAllLipCtrls):
        sJ = 'jnt_%s_mouthPRE_%s' % (cC.sSide, cC.sName)
        if cmds.objExists(sJ):
            cmds.parent(sJ, sParentJoint)
            xforms.resetJoint(sJ)
        else:
            cmds.createNode('joint', n=sJ, p=sParentJoint)

        cmds.setAttr('%s.radius' % sJ, 0.2)
        sSlider = cC.appendOffsetGroup('slider')

        xforms.matrixParentConstraint(sLocs[c], cC.sPasser, mo=True)
        xforms.matrixParentConstraint(cC.sOut, sJ)

        fSideMultipl = -1.0 if cC.sSide == 'r' else 1.0
        cmds.setAttr('%s.s' % sSlider, fSliderScale*fSideMultipl, fSliderScale*fSideMultipl, fSliderScale*fSideMultipl)

        deformers.resetJointReferences([sJ])

    if sSeals:
        for i in range(3):
            iInd = i+1
            sCenter = cmds.createNode('transform', n='mouthSealCenter_%d' % i, p='modules')
            sConstr = cmds.parentConstraint(ccLeftToRight[0][iInd].sPasser, ccLeftToRight[1][iInd].sPasser, sCenter)[0]
            cmds.setAttr('%s.interpType' % sConstr, 2)
            for p,sPart in enumerate(['bot','top']):
                cC = ccLeftToRight[p][iInd]
                sSealOffsets = cC.appendOffsetGroups(len(sSeals), 'seal', bMatchParentTransform=True)

                for m, sSeal in enumerate(sSeals):
                    cmds.setAttr(sSeal, 1.0)

                    sCtrl, sAttr = sSeal.split('.')
                    xforms.constraintBlend(sSealOffsets[m], cmds.listRelatives(sSealOffsets[m], p=True, c=False)[0],
                                           sCenter, sCtrl, sAttr, bMaintainOffset=True, kwargs={'skipRotate':['x','y','z']})

                    cmds.setAttr(sSeal, 0.0)






kEyelidPreBpGroupName = '_grp_m_eyesBpPRE'
kEyelidPreBpFileName = 'faceBlueprintsEyesPRE.ma'


dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_lids', kEyelidPreBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}


def fillPreEyePose(_uiArgs=None):

    sCtrls = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.preEyePoses' % sT)]
    dPoses = {}
    for sC in sCtrls:
        if utils.getSide(sC) == 'r':
            continue

        fRotate = cmds.getAttr('%s.r' % sC)[0]
        fTranslate = cmds.getAttr('%s.t' % sC)[0]
        if np.any(fRotate):
            dPoses['%s.r' % sC] = fRotate
        if np.any(fTranslate):
            dPoses['%s.t' % sC] = fTranslate

    _uiArgs['dPoses'].setText(str(dPoses))


def exportPreEyeBps(_report=None):
    exportBps(kEyelidPreBpFileName, kEyelidPreBpGroupName, _report=_report)
dButtons['Fill dPose'] = fillPreEyePose
dButtons['Export Pre Eyes BPs'] = exportPreEyeBps



@builderTools.addToBuild(iOrder=52.4, dButtons=dButtons, bDisableByDefault=True)
def PRE_eyes(fBotBlinks=[1,1,1], fTopBlinks=[1,1,1], dBlinkPoses={}, dTopBlink={}, dBotBlink={}, dPoses={}):

    sBodyMesh = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]
    aMirrorTable = patch.patchFromName(sBodyMesh).getMirrorTable()
    for sCrv in ['bpCurve_l_lids', 'bpCurve_r_lids']:
        curves.mirrorIfNotExists(sCrv, sMirrorMesh=sBodyMesh, aMirrorTable=aMirrorTable)

    sGrp = cmds.createNode('transform', n='grp_eyes', p='modules')

    for sLoc in ['locA_l_lids', 'locB_l_lids', 'locA_r_lids', 'locB_r_lids']:
        xforms.mirrorIfNotExists(sLoc, sMirrorMesh=sBodyMesh, aMirrorTable=aMirrorTable)

    ssCurves = []
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_l_lids', 'locA_l_lids', 'locB_l_lids', 'bpCurve_l_botLid',
                                            'bpCurve_l_topLid'))
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_r_lids', 'locA_r_lids', 'locB_r_lids', 'bpCurve_r_botLid',
                                            'bpCurve_r_topLid'))

    fSliderScale = curves.getLength(ssCurves[0][0])

    cccCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    cEyeCtrls = []
    sNames =  ['inner', 'mid', 'outer']
    sCornerNames = ['cornerIn', 'cornerOut']
    sParentJoints = [], []
    sAttachTransforms = []
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        sEyeTransform = 'jnt_%s_eyeTransform' % sSide
        # bottom tops
        for p,sPart in enumerate(['bot','top']):
            fCtrlParams = curves.getParamsFromPercs(ssCurves[s][p], [0.25, 0.5, 0.75])
            aTangents = curves.getTangentsFromParams(ssCurves[s][p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(ssCurves[s][p], fCtrlParams)
            sParentJoints[s].append('jnt_%s_eyeBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart)))
            for c, fP, sN in zip([0,1,2], fCtrlParams, sNames):
                sName = 'eyelid%s%s' % (utils.getFirstLetterUpperCase(sN), utils.getFirstLetterUpperCase(sPart))

                cC = ctrls.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2,
                                  sLockHide=['v'], fSize=0.05, sShape='cube', fMatchPos=aCtrlPoints[c])
                sBlinkMain = cC.appendOffsetGroup('blinkMain')
                sBlinkSecondary = cC.appendOffsetGroup('blinkSecondary')
                cC.sSlider = cC.appendOffsetGroup('slider')
                cmds.setAttr('%s.s' % cC.sSlider, fSliderScale, fSliderScale * fSideMultipl, fSliderScale)

                xforms.orientThreePoints(cC.sPasser,
                                         aTangents[c],
                                         [0,fSideMultipl,0])
                sBlinkMainDown = cmds.duplicate(sBlinkMain, po=True, n='%s_down' % sBlinkMain)[0]
                sBlinkMainUp = cmds.duplicate(sBlinkMain, po=True, n='%s_up' % sBlinkMain)[0]
                sBlinkSecondaryDown = cmds.duplicate(sBlinkSecondary, po=True, n='%s_down' % sBlinkSecondary)[0]
                sBlinkSecondaryUp = cmds.duplicate(sBlinkSecondary, po=True, n='%s_up' % sBlinkSecondary)[0]

                for sT in [sBlinkMainDown, sBlinkMainUp, sBlinkSecondaryDown, sBlinkSecondaryUp]:
                    cmds.addAttr(sT, ln='preEyePoses', k=True)

                for sA in ['r','t']:
                    sBlinks = [nodes.createRangeNode('blink%s_ctrl.ty' % utils.sSides3[s], 0,-1, [0,0,0], '%s.%s' % (sBlinkMainDown,sA), bOutRangeIsVector=True),
                               nodes.createRangeNode('blink%s_ctrl.ty' % utils.sSides3[s], 0, 0.5, [0, 0, 0], '%s.%s' % (sBlinkMainUp,sA), bOutRangeIsVector=True)]
                    nodes.createVectorAdditionNode(sBlinks, sTarget='%s.%s' % (sBlinkMain,sA))

                sLidCtrl = 'lid%s%s_ctrl' % (utils.getFirstLetterUpperCase(sPart), utils.sSides3[s])
                for sA in ['r','t']:
                    sBlinksSec = [nodes.createRangeNode('%s.ty' % sLidCtrl, 0,-1, [0,0,0], '%s.%s' % (sBlinkSecondaryDown,sA), bOutRangeIsVector=True),
                                    nodes.createRangeNode('%s.ty' % sLidCtrl, 0,1, [0,0,0], '%s.%s' % (sBlinkSecondaryUp,sA), bOutRangeIsVector=True)]
                    nodes.createVectorAdditionNode(sBlinksSec, sTarget='%s.%s' % (sBlinkSecondary,sA))

                cccCtrls[s][p].append(cC)
                cEyeCtrls.append(cC)
                fBlinks = fBotBlinks if p == 0 else fTopBlinks

                sConstrainOffset = cC.appendOffsetGroup('constrain')

                sTargetA = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser, cmds.getAttr('%s.worldInverseMatrix' % sEyeTransform), '%s.worldMatrix' % sEyeTransform])
                sTargetB = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser, cmds.getAttr('%s.worldInverseMatrix' % sParentJoints[s][p]), '%s.worldMatrix' % sParentJoints[s][p]])

                sMatrixBlend = nodes.createBlendMatrixNode([sTargetA, sTargetB], [1.0-fBlinks[c], fBlinks[c]])
                sBlendOffset = nodes.createMultMatrixNode([sMatrixBlend, '%s.worldInverseMatrix' % cC.sPasser])
                nodes.createDecomposeMatrix(sBlendOffset, sTargetPos='%s.t' % sConstrainOffset, sTargetRot='%s.r' % sConstrainOffset)
                sAttachTransforms.append(cC.sPasser)


        # corners
        fCtrlParams = curves.getParamsFromPercs(ssCurves[s][0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(ssCurves[s][0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, sCornerNames):
            sName = 'eyelid%s' % (utils.getFirstLetterUpperCase(sN))

            cC = ctrls.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, sMatch='jnt_%s_eyeMain' % sSide,
                              sLockHide=['v'], fSize=0.05, sShape='cube', fMatchPos=aCtrlPoints[c])
            cC.sSlider = cC.appendOffsetGroup('slider')
            cmds.setAttr('%s.s' % cC.sSlider, fSliderScale, fSliderScale * fSideMultipl, fSliderScale)

            # cmds.rotate(0,90,0, cC.sPasser, os=True, r=True)

            aPoints = xforms.getPositionArray([cccCtrls[s][0][1].sCtrl, cccCtrls[s][1][1].sCtrl, cC.sCtrl])
            aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]

            xforms.orientThreePoints(cC.sPasser,
                                     aTangent,
                                     [0, fSideMultipl, 0])

            ccCornerCtrls[s].append(cC)
            cEyeCtrls.append(cC)
            xforms.matrixParentConstraint(sEyeTransform, cC.sPasser, mo=True)


    sModel = '%s_noPreJoints' % sBodyMesh
    aClosestIds = xforms.getClosestIdsFromPoints(sModel, xforms.getPositionArray(sAttachTransforms))
    sLocs = deformers.blendShapeSkinClusterToPositions(sModel, aClosestIds,
                                                       sBlendShape='blendShape__%s' % sModel,
                                                       sParent=sGrp,
                                                       fTargetMinimumDistance=0.01, bDoSkinCluster=False,
                                                       bConnectEnvelopes=False)

    for c,sLoc in enumerate(sLocs):
        xforms.matrixParentConstraint(sLoc, sAttachTransforms[c], mo=True)


    for sAttr,fValues in list(dPoses.items()):
        sMirrorAttr = utils.getMirrorName(sAttr)
        cmds.setAttr(sAttr, *fValues)
        cmds.setAttr(sMirrorAttr, *fValues)


    for c,cC in enumerate(cEyeCtrls):
        iPart = 0 if 'Bot' in cC.sName else 1
        s = 0 if cC.sSide == 'l' else 1
        sJ = 'jnt_%s_eyesPRE_%s' % (cC.sSide, cC.sName)
        sParentJoint = sParentJoints[s][iPart]

        if cmds.objExists(sJ):
            cmds.parent(sJ, sParentJoint)
            xforms.resetJoint(sJ)
        else:
            cmds.createNode('joint', n=sJ, p=sParentJoint)

        cmds.setAttr('%s.radius' % sJ, 0.2)
        xforms.matrixParentConstraint(cC.sOut, sJ)
        deformers.resetJointReferences([sJ])




# PRE EYE BROWS

def browPreOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_eyebrow', [0, 0.5, 1])
    sNames = ['inner', 'mid', 'outer']
    for i, aP in enumerate(aPoints):
        sLoc = xforms.createLocator(sName='bpLoc_l_%sBrowOrientationPre' % sNames[i], sParent=sEyebrowsPreGrp)
        cmds.setAttr('%s.t' % sLoc, *list(aP))



sEyebrowsPreGrp = '_grp_m_browsBpPRE'
kEyebrowsPreFileName = 'faceBlueprintsBrowsPRE.ma'

dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_eyebrow', sEyebrowsPreGrp, fDirection=(1, 0, 0))
dButtons['Create Left Brow Curve'].dSideButtons = {'?':['eyebrowVerts.jpg']}

dButtons['Create Optional Left Brow Orientation Locators'] = browPreOrientationLocators
dButtons['Create Optional Left Brow Orientation Locators'].dSideButtons = {'?':['If you are not happy with the orientation, this creates a locator \n'\
                                                                    'that you can use to specify a better orientation']}


def exportBrowsBps(_report=None):
    exportBps(kEyebrowsPreFileName, sEyebrowsPreGrp, _report=_report)
dButtons['Export Brows BPs'] = exportBrowsBps


@builderTools.addToBuild(iOrder=52.2, dButtons=dButtons)
def PRE_brows(sParentJoint='jnt_m_headMain', iMeshIndex=0, iCurveJoints=None, bScaleCtrl=False):
    sBodyMesh = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[iMeshIndex]
    aMirrorTable = patch.patchFromName(sBodyMesh).getMirrorTable()

    pFaceMesh = patch.patchFromName(sBodyMesh)

    utils.data.store('iEyebrowCurveJoints', iCurveJoints, sNode=utils.kFaceDataNode)

    sBrowsOrig = cmds.createNode('transform', name='grp_eyebrowsOrig', p=getFaceGrp())

    sScale = nodes.scaleFromXform(sParentJoint)

    sSkinJoints = []

    sBpCurves = ['bpCurve_%s_eyebrow' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleEyebrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv, sMirrorMesh=sBodyMesh, aMirrorTable=aMirrorTable)

    aaPoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aMiddle = (aaPoints[0][0] + aaPoints[1][0]) * 0.5
    aaMiddlePoints = [np.array(
        [aMiddle, aaPoints[0][0] * 0.34 + aMiddle * 0.66, aaPoints[0][0] * 0.66 + aMiddle * 0.34, aaPoints[0][0]],
        dtype='float64'),
                      np.array([aMiddle, aaPoints[1][0] * 0.34 + aMiddle * 0.66, aaPoints[1][0] * 0.66 + aMiddle * 0.34,
                                aaPoints[1][0]], dtype='float64')]

    sCurves = [cmds.curve(p=aaPoints[0], n='curve_l_eyebrows'), cmds.curve(p=aaPoints[1], n='curve_r_eyebrows')]
    sMiddleCurves = [cmds.curve(p=aaMiddlePoints[0], n='curve_l_middleEyebrows'),
                     cmds.curve(p=aaMiddlePoints[1], n='curve_r_middleEyebrows')]

    for sCrv in (sCurves + sMiddleCurves):
        cmds.parent(sCrv, sBrowsOrig)

    if iCurveJoints:
        ffParams = [curves.getParamsFromPercs(sCurves[0], np.linspace(0.0, 1.0, iCurveJoints)),
                    curves.getParamsFromPercs(sCurves[1], np.linspace(0.0, 1.0, iCurveJoints))]

        ffMiddleParams = [np.linspace(0.0, 1.0, iCurveJoints / 4), np.linspace(0.0, 1.0, iCurveJoints / 4)]
    else:
        ffParams = [topology.getIdsAlongCurve(pFaceMesh, sCurves[0])[1],
                    topology.getIdsAlongCurve(pFaceMesh, sCurves[1])[1]]
        ffMiddleParams = [topology.getIdsAlongCurve(pFaceMesh, sMiddleCurves[0])[1][:-1],
                          topology.getIdsAlongCurve(pFaceMesh, sMiddleCurves[1])[1][:-1]]

    ccCtrls = [], []

    for s, sSide in enumerate(['l', 'r']):
        for sName in ['inner', 'mid', 'outer']:
            try:
                xforms.mirrorIfNotExists('bpLoc_%s_%sBrow' % (sSide, sName), sMirrorMesh=sBodyMesh, aMirrorTable=aMirrorTable)
            except:
                pass

        fSideMultipl = -1 if sSide == 'r' else 1
        aCtrlPoints = [aaPoints[s][0], aaPoints[s][3], aaPoints[s][6]]  # [0,3,6]

        fnMesh = OpenMaya2.MFnMesh(pFaceMesh.mDagPath)
        mDir = OpenMaya2.MFloatVector([0, 0, -1])
        aOffset = np.array([0, fSliderScale * 0.35, 0.0])
        aUps = np.zeros((2, 3, 3), dtype='float64')

        for c, sName in enumerate(['inner', 'mid', 'outer']):

            sLockHide = ['sx', 'v', 'rx','ry']
            if not bScaleCtrl: sLockHide += ['sy','sz']
            cC = ctrls.create(sName='%sPreEyebrow' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(),
                                    bPoly=bPolyCtrls,
                                    fMatchPos=aCtrlPoints[c], sShape='cube',
                                    iColorIndex=2, sLockHide=sLockHide, fSize=0.15)
            sSlider = cC.appendOffsetGroup('slider')
            cmds.setAttr('%s.s' % sSlider, fSideMultipl*fSliderScale, fSliderScale, fSliderScale)

            ccCtrls[s].append(cC)
            sBpOrient = 'bpLoc_%s_%sBrowOrientation' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_%sBrowOrientation' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    mirrorGroup(sLeftBpOrient)

            if cmds.objExists(sBpOrient):
                aMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sBpOrient), dtype='float64').reshape(4, 4)
                aUps[s, c] = aMatrix[1][:3]
            else:
                mInters, _, _, _, _, _ = fnMesh.closestIntersection(OpenMaya2.MFloatPoint(aCtrlPoints[c] + aOffset),
                                                                    mDir, OpenMaya2.MSpace.kWorld, 1000, True)
                aUps[s, c] = mInters.x, mInters.y, mInters.z
                aUps[s, c] -= aCtrlPoints[c]

        xforms.orientThreePoints(ccCtrls[s][0].sPasser, aUps[s, 0], ccCtrls[s][1].sOut, fAimVector=[0, 1, 0],
                                 fUpVector=[fSideMultipl, 0, 0])
        xforms.orientThreePoints(ccCtrls[s][2].sPasser, aUps[s, 2], ccCtrls[s][1].sOut, fAimVector=[0, 1, 0],
                                 fUpVector=[-fSideMultipl, 0, 0])
        sUpMiddle = ((aCtrlPoints[0] - aCtrlPoints[1]) - (aCtrlPoints[2] - aCtrlPoints[1])) * 0.5
        xforms.orientThreePoints(ccCtrls[s][1].sPasser, aUps[s, 1], sUpMiddle, fAimVector=[0, 1, 0],
                                 fUpVector=[-fSideMultipl, 0, 0])



    ssRefJoints = [], []
    for s, sSide in enumerate(['l', 'r']):
        for c, sName in enumerate(['inner', 'mid', 'outer']):
            cC = ccCtrls[s][c]
            cC.sJoint = xforms.createJoint('jnt_%s_%sEyebrowCtrl' % (sSide, sName), sParent=cC.sOut, fSize=1.0 * fSliderScale)
            cmds.setAttr('%s.v' % cC.sJoint, False)
            nodes.createMultiplyNode('%s.rz' % cC.sCtrl, -1, sTarget='%s.rz' % cC.sJoint)

        sLocalLeft = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][0].sOut),
                                                   '%s.worldInverseMatrix' % ccCtrls[s][1].sCtrl,
                                                   sName='%s_brows_leftLocalCtrl' % (sSide))
        sLocalRight = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][2].sOut),
                                                    '%s.worldInverseMatrix' % ccCtrls[s][1].sCtrl,
                                                    sName='%s_brows_rightLocalCtrl' % (sSide))

        sSum = nodes.createVectorAdditionNode([sLocalLeft, sLocalRight], sOperation='minus',
                                              sName='%s_eyebrow_midCtrlSum' % sSide)

        sNoRotatePasser = xforms.createTransform('grp_%s_midNoRotatePasser' % sSide, sParent=sBrowsOrig, sMatch=ccCtrls[s][1].sPasser)
        sAddRotatePasser = xforms.createTransform('grp_%s_midAddRotatePasser' % sSide, sParent=sNoRotatePasser, sMatch=ccCtrls[s][1].sPasser)
        xforms.matrixParentConstraint(ccCtrls[s][1].sCtrl, sNoRotatePasser)

        sMidAimer = cmds.createNode('transform', n='grp_%s_eyebrowMidAimer' % (sSide), p=sAddRotatePasser)
        nodes.createVectorMultiplyNode(sSum, 0.5, bVectorByScalar=True,
                                                  sName='%s_brows_midCtrlHalf' % (sSide), sTarget='%s.t' % sMidAimer)

        cmds.aimConstraint(ccCtrls[s][1].sCtrl, ccCtrls[s][0].sOut, aimVector=[1, 0, 0], upVector=[0, fSideMultipl, 0],
                           worldUpType='objectrotation', worldUpObject=ccCtrls[s][0].sCtrl)
        cmds.aimConstraint(sMidAimer, ccCtrls[s][1].sOut, aimVector=[1, 0, 0], upVector=[0, -fSideMultipl, 0],
                           worldUpType='objectrotation', worldUpObject=ccCtrls[s][1].sCtrl)
        cmds.aimConstraint(ccCtrls[s][1].sCtrl, ccCtrls[s][2].sOut, aimVector=[1, 0, 0], upVector=[0, -fSideMultipl, 0],
                           worldUpType='objectrotation', worldUpObject=ccCtrls[s][2].sCtrl)



        # this pops: ctrl_l_midEyebrowLocalOut
        # create skin joints
        dProducts = defaultdict(list)
        print('\n\n\n')
        # sScaleCombs = [nodes.createVectorMultiplyNode('%s.s' % cBrowTransforms[s].sCtrl, '%s.s' % cC.sCtrl) for cC in ccCtrls[s]]
        sJoints = []
        for j, fP in enumerate(ffParams[s]):
            # sRefJ = cmds.createNode('joint', n='jnt_%s_preEyelids_%s_ref' % (cC.sSide, cC.sName), p=sExtra)

            sJ = 'jnt_%s_browsPRE_%03d' % (sSide, j + len(ffMiddleParams[s]) - 1)
            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
                xforms.resetJoint(sJ)
            else:
                sJ = xforms.createJoint(sJ, sParent=sParentJoint)

            cmds.setAttr('%s.radius' % sJ, 0.2)

            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
            sSkinJoints.append(sJ)
            sJoints.append(sJ)
            _, sPosOnCurve = curves.createPointInfoNode(sCurves[s], fParam=fP)
            cmds.setAttr('%s.t' % sJ, *list(cmds.getAttr(sPosOnCurve)[0]))

            nodes.createPointByMatrixNode(sPosOnCurve, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            # cmds.connectAttr(sPosOnCurve, '%s.t' % sJ)

            deformers.resetJointReferences([sJ])
        cmds.skinCluster(sCurves[s], [cC.sJoint for cC in ccCtrls[s]], tsb=True)


    # create geo attach locators
    AttachTransforms = [cC.sPasser for cC in (ccCtrls[0]+ccCtrls[1])] + ssRefJoints[0] + ssRefJoints[1]
    sBody = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]
    aClosestIds = xforms.getClosestIdsFromPoints(sBody, xforms.getPositionArray(AttachTransforms))

    sModel = '%s_noPreJoints' % sBody
    sLocs = deformers.blendShapeSkinClusterToPositions(sModel, aClosestIds, sBlendShape='blendShape__%s' % sModel, sParent=sBrowsOrig,
                                                     fTargetMinimumDistance=0.01, bDoSkinCluster=True, sScaleJoint=sParentJoint, bConnectEnvelopes=False,
                                                     sSkinClusters=['skinCluster__%s' % sModel])



    for t,sT in enumerate(AttachTransforms):
        xforms.matrixParentConstraint(sLocs[t], sT, mo=True)




def upperCheekOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_upperCheek', [0, 0.5, 1])
    sNames = ['inner', 'mid', 'outer']
    for i, aP in enumerate(aPoints):
        sLoc = xforms.createLocator(sName='bpLoc_l_%sUpperCheekOrientation' % sNames[i], sParent=sUpperCheekGrp)
        cmds.setAttr('%s.t' % sLoc, *list(aP))






sUpperCheekGrp = '_grp_m_upperCheekBpsPRE'
kUpperCheekFileName = 'faceBlueprintsUpperCheekPRE.ma'
dButtons = OrderedDict()
dButtons['Create Left UpperCheek Curve'] = lambda: createBpCurve('bpCurve_l_upperCheek', sUpperCheekGrp, fDirection=(1, 0, 0))
# dButtons['Create Left UpperCheek Curve'].dSideButtons = {'?':['eyebrowVerts.jpg']}

dButtons['Create Optional Left UpperCheek Orientation Locators'] = upperCheekOrientationLocators
dButtons['Create Optional Left UpperCheek Orientation Locators'].dSideButtons = {'?':['If you are not happy with the orientation, this creates a locator \n'\
                                                                    'that you can use to specify a better orientation']}

dButtons['Export BPs'] = lambda: exportBps(kUpperCheekFileName, sUpperCheekGrp)


@builderTools.addToBuild(iOrder=52.3, dButtons=dButtons)
def PRE_upperCheek(sParentJoint='jnt_m_headMain', iMeshIndex=0, iCurveJoints=None, bScaleCtrl=False):
    sBodyMesh = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[iMeshIndex]
    aMirrorTable = patch.patchFromName(sBodyMesh).getMirrorTable()


    pFaceMesh = patch.patchFromName(sBodyMesh)

    utils.data.store('iUpperCheekCurveJoints', iCurveJoints, sNode=utils.kFaceDataNode)

    sUpperCheekOrig = cmds.createNode('transform', name='grp_upperCheekOrig', p=getFaceGrp())

    sSkinJoints = []

    sBpCurves = ['bpCurve_%s_upperCheek' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleUpperCheek', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv, sMirrorMesh=sBodyMesh, aMirrorTable=aMirrorTable)

    aaPoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aMiddle = (aaPoints[0][0] + aaPoints[1][0]) * 0.5
    aaMiddlePoints = [np.array(
        [aMiddle, aaPoints[0][0] * 0.34 + aMiddle * 0.66, aaPoints[0][0] * 0.66 + aMiddle * 0.34, aaPoints[0][0]],
        dtype='float64'),
                      np.array([aMiddle, aaPoints[1][0] * 0.34 + aMiddle * 0.66, aaPoints[1][0] * 0.66 + aMiddle * 0.34,
                                aaPoints[1][0]], dtype='float64')]

    sCurves = [cmds.curve(p=aaPoints[0], n='curve_l_upperCheek'), cmds.curve(p=aaPoints[1], n='curve_r_upperCheek')]
    sMiddleCurves = [cmds.curve(p=aaMiddlePoints[0], n='curve_l_middleUpperCheek'),
                     cmds.curve(p=aaMiddlePoints[1], n='curve_r_middleUpperCheek')]

    for sCrv in (sCurves + sMiddleCurves):
        cmds.parent(sCrv, sUpperCheekOrig)

    if iCurveJoints:
        ffParams = [curves.getParamsFromPercs(sCurves[0], np.linspace(0.0, 1.0, iCurveJoints)),
                    curves.getParamsFromPercs(sCurves[1], np.linspace(0.0, 1.0, iCurveJoints))]

        ffMiddleParams = [np.linspace(0.0, 1.0, iCurveJoints / 4), np.linspace(0.0, 1.0, iCurveJoints / 4)]
    else:
        ffParams = [topology.getIdsAlongCurve(pFaceMesh, sCurves[0])[1],
                    topology.getIdsAlongCurve(pFaceMesh, sCurves[1])[1]]
        ffMiddleParams = [topology.getIdsAlongCurve(pFaceMesh, sMiddleCurves[0])[1][:-1],
                          topology.getIdsAlongCurve(pFaceMesh, sMiddleCurves[1])[1][:-1]]

    ccCtrls = [], []

    for s, sSide in enumerate(['l', 'r']):
        for sName in ['inner', 'mid', 'outer']:
            try:
                xforms.mirrorIfNotExists('bpLoc_%s_%sBrow' % (sSide, sName), sMirrorMesh=sBodyMesh, aMirrorTable=aMirrorTable)
            except:
                pass

        fSideMultipl = -1 if sSide == 'r' else 1
        aCtrlPoints = [aaPoints[s][0], aaPoints[s][3], aaPoints[s][6]]  # [0,3,6]

        fnMesh = OpenMaya2.MFnMesh(pFaceMesh.mDagPath)
        mDir = OpenMaya2.MFloatVector([0, 0, -1])
        aOffset = np.array([0, fSliderScale * 0.35, 0.0])
        aUps = np.zeros((2, 3, 3), dtype='float64')

        for c, sName in enumerate(['inner', 'mid', 'outer']):

            sLockHide = ['sx', 'v', 'rx','ry']
            if not bScaleCtrl: sLockHide += ['sy','sz']
            cC = ctrls.create(sName='%sPreUpperCheek' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(),
                                    bPoly=bPolyCtrls,
                                    fMatchPos=aCtrlPoints[c], sShape='cube',
                                    iColorIndex=2, sLockHide=sLockHide, fSize=0.15)
            sSlider = cC.appendOffsetGroup('slider')
            cmds.setAttr('%s.s' % sSlider, fSideMultipl*fSliderScale, fSliderScale, fSliderScale)

            ccCtrls[s].append(cC)
            sBpOrient = 'bpLoc_%s_%sUpperCheekOrientation' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_%sUpperCheekOrientation' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    mirrorGroup(sLeftBpOrient)

            if cmds.objExists(sBpOrient):
                aMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sBpOrient), dtype='float64').reshape(4, 4)
                aUps[s, c] = aMatrix[1][:3]
            else:
                mInters, _, _, _, _, _ = fnMesh.closestIntersection(OpenMaya2.MFloatPoint(aCtrlPoints[c] + aOffset),
                                                                    mDir, OpenMaya2.MSpace.kWorld, 1000, True)
                aUps[s, c] = mInters.x, mInters.y, mInters.z
                aUps[s, c] -= aCtrlPoints[c]

        xforms.orientThreePoints(ccCtrls[s][0].sPasser, aUps[s, 0], ccCtrls[s][1].sOut, fAimVector=[0, 1, 0],
                                 fUpVector=[fSideMultipl, 0, 0])
        xforms.orientThreePoints(ccCtrls[s][2].sPasser, aUps[s, 2], ccCtrls[s][1].sOut, fAimVector=[0, 1, 0],
                                 fUpVector=[-fSideMultipl, 0, 0])
        sUpMiddle = ((aCtrlPoints[0] - aCtrlPoints[1]) - (aCtrlPoints[2] - aCtrlPoints[1])) * 0.5
        xforms.orientThreePoints(ccCtrls[s][1].sPasser, aUps[s, 1], sUpMiddle, fAimVector=[0, 1, 0],
                                 fUpVector=[-fSideMultipl, 0, 0])



    ssRefJoints = [], []
    for s, sSide in enumerate(['l', 'r']):
        for c, sName in enumerate(['inner', 'mid', 'outer']):
            cC = ccCtrls[s][c]
            cC.sJoint = xforms.createJoint('jnt_%s_%sUpperCheekCtrl' % (sSide, sName), sParent=cC.sOut, fSize=1.0 * fSliderScale)
            cmds.setAttr('%s.v' % cC.sJoint, False)
            nodes.createMultiplyNode('%s.rz' % cC.sCtrl, -1, sTarget='%s.rz' % cC.sJoint)


        sLocalLeft = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][0].sOut),
                                                   '%s.worldInverseMatrix' % ccCtrls[s][1].sCtrl,
                                                   sName='%s_upperCheek_leftLocalCtrl' % (sSide))
        sLocalRight = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][2].sOut),
                                                    '%s.worldInverseMatrix' % ccCtrls[s][1].sCtrl,
                                                    sName='%s_upperCheek_rightLocalCtrl' % (sSide))

        sSum = nodes.createVectorAdditionNode([sLocalLeft, sLocalRight], sOperation='minus',
                                              sName='%s_eyebrow_midCtrlSum' % sSide)

        sNoRotatePasser = xforms.createTransform('grp_%s_midNoRotatePasser' % sSide, sParent=sUpperCheekOrig, sMatch=ccCtrls[s][1].sPasser)
        sAddRotatePasser = xforms.createTransform('grp_%s_midAddRotatePasser' % sSide, sParent=sNoRotatePasser, sMatch=ccCtrls[s][1].sPasser)
        xforms.matrixParentConstraint(ccCtrls[s][1].sCtrl, sNoRotatePasser)

        sMidAimer = cmds.createNode('transform', n='grp_%s_eyebrowMidAimer' % (sSide), p=sAddRotatePasser)
        nodes.createVectorMultiplyNode(sSum, 0.5, bVectorByScalar=True,
                                                  sName='%s_uppercheek_midCtrlHalf' % (sSide), sTarget='%s.t' % sMidAimer)

        cmds.aimConstraint(ccCtrls[s][1].sCtrl, ccCtrls[s][0].sOut, aimVector=[1, 0, 0], upVector=[0, fSideMultipl, 0],
                           worldUpType='objectrotation', worldUpObject=ccCtrls[s][0].sCtrl)
        cmds.aimConstraint(sMidAimer, ccCtrls[s][1].sOut, aimVector=[1, 0, 0], upVector=[0, -fSideMultipl, 0],
                           worldUpType='objectrotation', worldUpObject=ccCtrls[s][1].sCtrl)
        cmds.aimConstraint(ccCtrls[s][1].sCtrl, ccCtrls[s][2].sOut, aimVector=[1, 0, 0], upVector=[0, -fSideMultipl, 0],
                           worldUpType='objectrotation', worldUpObject=ccCtrls[s][2].sCtrl)


        # this pops: ctrl_l_midUpperCheekLocalOut
        # create skin joints
        sJoints = []
        for j, fP in enumerate(ffParams[s]):
            sJ = 'jnt_%s_upperCheekPRE_%03d' % (sSide, j + len(ffMiddleParams[s]) - 1)

            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
                xforms.resetJoint(sJ)
            else:
                sJ = xforms.createJoint(sJ, sParent=sParentJoint)
            cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
            cmds.setAttr('%s.radius' % sJ, 0.2)


            sSkinJoints.append(sJ)
            sJoints.append(sJ)
            _, sPosOnCurve = curves.createPointInfoNode(sCurves[s], fParam=fP)
            nodes.createPointByMatrixNode(sPosOnCurve, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            # cmds.connectAttr(sPosOnCurve, '%s.t' % sJ)
            deformers.resetJointReferences([sJ])


        cmds.skinCluster(sCurves[s], [cC.sJoint for cC in ccCtrls[s]], tsb=True)

    # create geo attach locators
    AttachTransforms = [cC.sPasser for cC in (ccCtrls[0]+ccCtrls[1])] + ssRefJoints[0] + ssRefJoints[1]
    sBody = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]
    aClosestIds = xforms.getClosestIdsFromPoints(sBody, xforms.getPositionArray(AttachTransforms))
    sModel = '%s_noPreJoints' % sBody
    sLocs = deformers.blendShapeSkinClusterToPositions(sModel, aClosestIds, sBlendShape='blendShape__%s' % sModel, sParent=sUpperCheekOrig,
                                                     fTargetMinimumDistance=0.01, bDoSkinCluster=True, sScaleJoint=sParentJoint,
                                                     sSkinClusters=['skinCluster__%s' % sModel])


    for t,sT in enumerate(AttachTransforms):
        xforms.matrixParentConstraint(sLocs[t], sT, mo=True)







dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def fillBlinkValues(_uiArgs=None):
    sPasser = 'grp_l_blinkPasser'
    _uiArgs['fBlinkValues'].setText(str([cmds.getAttr('%s.botBlink' % sPasser), cmds.getAttr('%s.topBlink' % sPasser)]))
    _uiArgs['fBlinkTwistValues'].setText(str([cmds.getAttr('%s.botBlinkTwist' % sPasser), cmds.getAttr('%s.topBlinkTwist' % sPasser)]))
    _uiArgs['fWideValues'].setText(str([cmds.getAttr('%s.botWide' % sPasser), cmds.getAttr('%s.topWide' % sPasser)]))
    _uiArgs['fFollowUps'].setText(str([cmds.getAttr('%s.followBotUp' % sPasser), cmds.getAttr('%s.followTopUp' % sPasser)]))
    _uiArgs['fFollowDowns'].setText(str([cmds.getAttr('%s.followBotDown' % sPasser), cmds.getAttr('%s.followTopDown' % sPasser)]))
    _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(cmds.getAttr('%s.fExtraBlinkCtrlStrengthes' % sPasser)))



kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill blink values'] = fillBlinkValues
dButtons['Export Eye BPs'] = lambda: exportBps(kEyeBpFileName, kEyeBpGroupName)




@builderTools.addToBuild(iOrder=24.4, dButtons=dButtons)
def createEyeSetup(sParentJoint='jnt_m_headMain', fBlinkValues=[10,-30], fBlinkTwistValues=[0,0], fFollowUps=[45, 45], fFollowDowns=[-45,-45], fWideValues=[0, 15], fExtraBlinkCtrlStrengthes=[30,30]):
    for s, sSide in enumerate(['l', 'r']):
        sLookAtCtrl = 'eyesLookAt%s_ctrl' % utils.sSides3[s]
        if not cmds.objExists(sLookAtCtrl):
            sLookAtCtrl = 'eyesLookAtEyelookAt%s_ctrl' % utils.sSides3[s]

        fSideMultipl = -1.0 if s == 1 else 1.0
        sBpWrinkler = 'bp_%s_blink' % sSide
        if not cmds.objExists(sBpWrinkler):
            mirrorGroup(utils.getMirrorName(sBpWrinkler))

        sEyeJoints = ['jnt_%s_eyeMain' % sSide, 'jnt_%s_eyeEnd' % sSide]
        sParent = xforms.createJoint('jnt_%s_eyeLidParent' % sSide, sParent=sParentJoint, sMatch=sEyeJoints[0])

        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        cEyeCtrl = ctrls.ctrlFromName('eye%s_ctrl' % utils.sSides3[s])

        cEyeTransform = ctrls.create(sName='eyeTransform', sSide=sSide, sParent=_getFaceCtrlGrp(),
                                   sShape='locator', iColorIndex=2,
                                   sMatch=sEyeJoints[0], sLockHide=['v'],
                                   fSize=10)

        if sSide == 'r':
            cmds.rotate(180, 0, 0, cEyeTransform.sPasser, os=True, r=True)

        sSlider = cEyeTransform.appendOffsetGroup('slider')
        cmds.setAttr('%s.s' % sSlider, fSliderScale, fSliderScale*fSideMultipl, fSliderScale)
        cmds.setAttr('%s.s' % cEyeTransform.sOut, 1.0/fSliderScale, 1.0/(fSliderScale*fSideMultipl),1.0/fSliderScale)

        xforms.matrixParentConstraint(cEyeTransform.sOut, cEyeCtrl.appendOffsetGroup('transform'))
        xforms.matrixParentConstraint(sParentJoint, cEyeTransform.sPasser, mo=True)
        xforms.matrixParentConstraint(cEyeTransform.sOut, sParent, mo=True)
        xforms.createJoint('jnt_%s_eyeTransform' % sSide, sParent=sParentJoint)
        xforms.matrixParentConstraint(cEyeTransform.sOut, 'jnt_%s_eyeTransform' % sSide, mo=True)


        aBlinkPos = aJointPositions[1] + np.array([fRadius*fSideMultipl, 0, 0])

        cBlink = sliderCtrls.createSliderCtrl('blink', sSide, sShape='doubleArrowSquareY', fBpPos=aBlinkPos, fRangeY=[-1,0.5], bMirror=False, fScale=fSliderScale, sAttach=sParentJoint)[0]

        cBlinkBot = sliderCtrls.createSliderCtrl('lidBot', sSide, sShape='doubleArrowSquareY', fRangeY=[-1,1.0], sAttach=sParentJoint, fScale=fSliderScale*0.5,
                                                 fBpPos=aBlinkPos + np.array([fSliderScale*fSideMultipl, -2*fSliderScale, 0]), bMirror=False)[0]
        cBlinkTop = sliderCtrls.createSliderCtrl('lidTop', sSide, sShape='doubleArrowSquareY', fRangeY=[-1,1.0], sAttach=sParentJoint, fScale=fSliderScale*0.5,
                                                 fBpPos=aBlinkPos + np.array([fSliderScale*fSideMultipl, 2*fSliderScale, 0]), bMirror=False)[0]

        sBlinkRev = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, 1, 0)

        cmds.setAttr('%s.s' % cBlink.sSlider, fSliderScale * fSideMultipl, fSliderScale * fSideMultipl, fSliderScale * fSideMultipl)
        cmds.controller(cBlink.sCtrl, headCtrl(), parent=True)

        sFollowJoints = [xforms.createJoint('jnt_%s_eyeFollowBot' % sSide, sParent=sParent),
                        xforms.createJoint('jnt_%s_eyeFollowTop' % sSide, sParent=sParent)]

        sBlinkJoints = [xforms.createJoint('jnt_%s_eyeBlinkBot' % sSide, sMatch=sEyeJoints[0], sParent=sFollowJoints[0]),
                        xforms.createJoint('jnt_%s_eyeBlinkTop' % sSide, sMatch=sEyeJoints[0], sParent=sFollowJoints[1])]

        sAttrs = [utils.addAttr(cBlink.sPasser, ln='botBlink', k=True, defaultValue=fBlinkValues[0]),
                  utils.addAttr(cBlink.sPasser, ln='topBlink', k=True, defaultValue=fBlinkValues[1])]
        sWideAttrs = [utils.addAttr(cBlink.sPasser, ln='botWide', k=True, defaultValue=fWideValues[0]),
                  utils.addAttr(cBlink.sPasser, ln='topWide', k=True, defaultValue=fWideValues[1])]
        sTwistAttrs = [utils.addAttr(cBlink.sPasser, ln='botBlinkTwist', k=True, defaultValue=fBlinkTwistValues[0]),
                    utils.addAttr(cBlink.sPasser, ln='topBlinkTwist', k=True, defaultValue=fBlinkTwistValues[1])]

        sExtraBlinks = [xforms.insertParent(sFollowJoints[0], 'grp_%s_eyeExtraBlinkBot' % sSide),
                       xforms.insertParent(sFollowJoints[1], 'grp_%s_eyeExtraBlinkTop' % sSide)]
        sLidPassers = [xforms.insertParent(sExtraBlinks[0], 'grp_%s_eyeBlinkBotPasser' % sSide),
                       xforms.insertParent(sExtraBlinks[1], 'grp_%s_eyeBlinkTopPasser' % sSide)]


        sEndPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint('jnt_%s_eyeEnd' % sSide), '%s.worldInverseMatrix' % sParent)

        sLookX = utils.addAttr(sLookAtCtrl, ln='lookHoriz', k=False)#, cb=True)
        sLookY = utils.addAttr(sLookAtCtrl, ln='lookVert', k=False)#, cb=True)
        cmds.connectAttr('%sZ' % sEndPoint, sLookX)
        cmds.connectAttr('%sY' % sEndPoint, sLookY)

        sDrivenUp = nodes.setDrivenKeyController('%s.ty' % sLookAtCtrl, [0, 60], '%sY' % sEndPoint, None, [0, 1])
        sDrivenDown = nodes.setDrivenKeyController('%s.ty' % sLookAtCtrl, [0, -60], '%sY' % sEndPoint, None, [0, 1])


        # sExtraBlinkStrengthAttr = utils.addAttr(cBlink.sPasser, ln='extraBlinkStrength', k=True, defaultValue=fBlinkValues[0])
        sBlinkBot = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, 0, sAttrs[0])
        sBlinkTop = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, 0, sAttrs[1])
        sWideBot = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, 0, sWideAttrs[0])
        sWideTop = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, 0, sWideAttrs[1])
        nodes.createConditionNode('%s.ty' % cBlink.sCtrl, '>', 0.0, sWideBot, sBlinkBot, sTarget='%s.rz' % sBlinkJoints[0])
        nodes.createConditionNode('%s.ty' % cBlink.sCtrl, '>', 0.0, sWideTop, sBlinkTop, sTarget='%s.rz' % sBlinkJoints[1])

        # nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, 0, nodes.createMultiplyNode(sTwistAttrs[0], fSideMultipl), sTarget='%s.rx' % sBlinkJoints[0])
        # nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, 0, nodes.createMultiplyNode(sTwistAttrs[1], fSideMultipl), sTarget='%s.rx' % sBlinkJoints[1])

        nodes.setDrivenKey('%s.ty' % cBlinkBot.sCtrl, [-1,0,1], '%s.rz' % sExtraBlinks[0], [-fExtraBlinkCtrlStrengthes[0],0,fExtraBlinkCtrlStrengthes[0]])
        nodes.setDrivenKey('%s.ty' % cBlinkTop.sCtrl, [-1,0,1], '%s.rz' % sExtraBlinks[1], [-fExtraBlinkCtrlStrengthes[1],0,fExtraBlinkCtrlStrengthes[1]])



        sFollowBotDown = utils.addAttr(cBlink.sPasser, ln='followBotDown', k=True, defaultValue=fFollowDowns[0])
        sFollowBotUp = utils.addAttr(cBlink.sPasser, ln='followBotUp', k=True, defaultValue=fFollowUps[0])
        sFollowTopDown = utils.addAttr(cBlink.sPasser, ln='followTopDown', k=True, defaultValue=fFollowDowns[1])
        sFollowTopUp = utils.addAttr(cBlink.sPasser, ln='followTopUp', k=True, defaultValue=fFollowUps[1])

        sLidFollow = utils.addAttr(sLookAtCtrl, ln='lidFollow', minValue=0.0, maxValue=1, defaultValue=0.5, k=True)
        sBots = [nodes.createMultiplyArrayNode([sLidFollow, sDrivenDown, sFollowBotDown, sBlinkRev]),
                 nodes.createMultiplyArrayNode([sLidFollow, sDrivenUp, sFollowBotUp, sBlinkRev])]
        sTops = [nodes.createMultiplyArrayNode([sLidFollow, sDrivenDown, sFollowTopDown, sBlinkRev]),
                 nodes.createMultiplyArrayNode([sLidFollow, sDrivenUp, sFollowTopUp, sBlinkRev])]
        nodes.createAdditionNode(sBots, sTarget='%s.rz' % sFollowJoints[0])
        nodes.createAdditionNode(sTops, sTarget='%s.rz' % sFollowJoints[1])

        # pupils
        sPupilAttr = utils.addAttr(sLookAtCtrl, ln='pupilScale', minValue=0.2, maxValue=3, defaultValue=1.0, k=True)
        cmds.connectAttr(sPupilAttr, '%s.sx' % sEyeJoints[1])
        cmds.connectAttr(sPupilAttr, '%s.sy' % sEyeJoints[1])
        cmds.connectAttr(sPupilAttr, '%s.sz' % sEyeJoints[1])






@builderTools.addToBuild(iOrder=64)
def SLIDERS_attachCtrls(sScaleJoint='jnt_m_headMain'):
    sBodyMeshes = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)
    sModel = '%s_noPreJoints' % sBodyMeshes[0]
    sliderCtrls.attachAllCtrls(sModel, sScaleJoint=sScaleJoint)



@builderTools.addToBuild(iOrder=70)
def createFbxSkeleton(bChangeAxis=False):
    sDupl = cmds.duplicate('skeleton', n='UNREALSKELETON')[0]
    sChildren = cmds.listRelatives(sDupl, c=True, p=False, f=True)
    sRoot = cmds.createNode('joint', n='unrealRoot', p=sDupl)

    cmds.parent(sChildren, sRoot)
    sJoints = cmds.listRelatives(sRoot, ad=True, f=True)
    sJoints.sort(key=lambda a: len(a), reverse=True)
    dJoints = {}
    for sJ in sJoints:
        print('sJ: ', sJ)
        sName = sJ.split('|')[-1]
        sSplits = sName.split('_')
        sSplits[0] = '%sU' % sSplits[0]
        sNewName = '_'.join(sSplits)
        cmds.rename(sJ, sNewName)
        dJoints[sName] = sNewName

        sChildren = cmds.listRelatives(sNewName, c=True, p=False)
        if sChildren:
            sChildren = [sN for sN in sChildren if cmds.objectType(sN) in ['transform', 'join']]
            if sChildren:
                cmds.parent(sChildren, w=True)

        if bChangeAxis:
            cmds.rotate(0, -90, -90, sNewName, os=True, r=True)
        if sChildren:
            print('sNewName: ', sNewName)
            print('sChildren: ', sChildren)
            cmds.parent(sChildren, sNewName)

        if cmds.objectType(sName) == 'joint':
            xforms.matrixParentConstraint(sName, sNewName, mo=True)
    sShapes = cmds.listRelatives('model', typ='mesh', ad=True)
    sMeshes = list(set([cmds.listRelatives(sS, p=True, c=False)[0] for sS in sShapes]))

    for sM in sMeshes:
        pM = patch.patchFromName(sM)
        weights.moveSkinClusterWeights([pM], dJoints, iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)

    xforms.unrealifyJointHierarchy('UNREALSKELETON')




def explorerFbx():
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')
    utils.openExplorer(sPath)







@builderTools.addToBuild(iOrder=1005, dButtons={'Explorer':explorerFbx})
def exportFBX(bDeleteMaster=True, _report=None):
    '''
    Save before running this
    '''
    # sAsset = assets.assetManager.getCurrentAsset()
    sPath = assets.assetManager.getCurrentVersionPath(sSubPath='fbx')

    sFilePath = os.path.join(sPath, 'face.fbx')
    if _report:
        _report.addLogText('exporting %s' % sFilePath)
        _report.incrementProgress()

    for sJ in cmds.listRelatives('UNREALSKELETON', ad=True):
        sAttrs = ['tx','ty','tz','rx','ry','rz','sx','sy','sz']
        fValues = [cmds.getAttr('%s.%s' % (sJ,sA)) for sA in sAttrs]
        sConnections = cmds.listConnections(sJ, s=True, d=False) or []
        print('sConnections0: ', sConnections)
        sConnections = [sC for sC in sConnections if 'dagNode' not in cmds.nodeType(sC, i=True)]
        print('sConnections1: ', sConnections)
        if sConnections:
            cmds.delete(sConnections)
        [cmds.setAttr('%s.%s' % (sJ, sA), fV) for sA,fV in zip(sAttrs,fValues)]



    if not os.path.exists(sPath):
        os.makedirs(sPath)
    sNodes = ['UNREALSKELETON', 'model']
    cmds.parent(sNodes, w=True)
    if bDeleteMaster:
        cmds.delete('master')
    cmds.select(sNodes)
    sExportString = 'FBXExport -f "%s" -s' % sFilePath.replace('\\', '/')
    mel.eval(sExportString)
    if not bDeleteMaster:
        cmds.parent(sNodes, 'master')

# utils.data.store('sFbxFiles', sFbxFiles, sNode=utils.kExportNode)
# utils.data.store('sFbxGroups', sAllGroups, sNode=utils.kExportNode)



@builderTools.addToBuild(iOrder=135, dButtons={})
def generateLiveLinkJoints():
    sBody = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)[0]
    sBlendShape = 'blendShape__%s' % sBody
    sTargets = deformers.getBlendShapeTargets(sBlendShape)
    print(len(sTargets))

    for sT in sTargets:
        unreal.addLiveLinkTarget(sT, 'jntU_m_headMain')





dUnrealAxisSwap = {}
dUnrealAxisSwap['x'] = ('x', 1)
dUnrealAxisSwap['y'] = ('y', 1)
dUnrealAxisSwap['z'] = ('z', 1)
# dUnrealAxisSwap['x'] = ('y', -1)
# dUnrealAxisSwap['y'] = ('z', 1)
# dUnrealAxisSwap['z'] = ('x', 1)


@builderTools.addToBuild(iOrder=140, dButtons={})
def FbxLiveLinkJoints(_report=None):
    sJoints = cmds.ls('liveLink__*', et='joint')
    sBlendShapes = cmds.ls(et='blendShape')
    dBlendShapes = {}
    for sB in sBlendShapes:
        print('sB: ', sB)
        sAliasAttrs = cmds.aliasAttr(sB, q=True)
        if sAliasAttrs:
            sTargets = sAliasAttrs[::2]
            for sT in sTargets:
                if sT not in dBlendShapes:
                    dBlendShapes[sT] = sB

    sUnrealCommands = ''
    for sJ in sJoints:
        sTargets = utils.replaceStringEnd(sJ, '__', '').split('__')[1:]
        print('sTargets: ', sTargets)
        for t,sT in enumerate(sTargets): # maximum 3 Targets
            sBlendShape = dBlendShapes[sT]

            # because we are performing it on an unreal oriented rig, we'll have to swap it to unreal axes,
            # and then KangarooRiggingNode will swap it back
            sAxis, fMultipl = dUnrealAxisSwap[['x','y','z'][t]]
            nodes.createMultiplyNode('%s.%s' % (sBlendShape, sT), 10, sTarget='%s.t%s' % (sJ, sAxis))
            sUnrealCommands += '\nTRANSLATIONDRIVER %s %s.%s %s 0/10/0/1' % (sT, sJ, ['tx','ty','tz'][t], cmds.listRelatives(sJ, p=True)[0])

    if _report:
        _report.addLogText(sUnrealCommands)

