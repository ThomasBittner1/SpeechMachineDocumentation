###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



'''

changes from _v3:
eyeRGT_ctrl keeps the orientation now. in V3 it was flipped to make it parallel. However now the new
function ParallelEyes is taking care of it

'''


from collections import OrderedDict, defaultdict
import numpy as np
import os
import kangarooTools.patch as patch
import kangarooTools.report as report
import time
import pickle
import math

import kangarooTools.utilFunctions as utils

QtWidgets, QtGui, QtCore = utils.importQtModules()


import kangarooShapeEditor.kangarooShapeEditorTools as kangarooShapeEditorTools

import kangarooTabTools.builder as builderTools
import kangarooTabTools.unreal as unreal

import maya.cmds as cmds
import maya.api.OpenMaya as OpenMaya2
import kangarooTools.deformers as deformers
import kangarooTools.barycentric as barycentric
import kangarooTools.topology as topology
import kangarooTools.curves as curves
import kangarooTools.surfaces as surfaces
import kangarooTools.nodes as nodes
import kangarooTools.assets as assets
import kangarooTools.xforms as xforms
import kangarooTools.constraints as constraints
import kangarooTabTools.blendShapesPro as blendShapesPro
import kangarooTabTools.weights as weights
import kangarooTabTools.ctrls4 as ctrls4
import kangarooTabTools.ctrls5 as ctrls5
import kangarooTabTools.geometry as geometry
import kangarooTools.utilsUnreal as utilsUnreal

iColorIndexCtrls = 0
kBuilderColor = utils.uiColors.orange
kEyelidBuilderColor = utils.uiColors.orangeDark


sHeadCtrl = None
def headCtrl():
    global sHeadCtrl
    if sHeadCtrl == None:
        sHeadCtrl = utils.translateCtrlName('ctrl_m_head')
    return sHeadCtrl

sJawCtrl = None
def jawCtrl():
    global sJawCtrl
    if sJawCtrl == None:
        sJawCtrl = utils.translateCtrlName('ctrl_m_jaw')
    return sJawCtrl


def exportBps(sFileName, sGroup):
    sFile = assets.assetManager.getCurrentVersionPath(os.path.join('mayaImport', sFileName))
    cmds.select(sGroup)
    print('exporting "%s" to "%s" ' % (sGroup, sFile))
    report.report.addLogText('exporting "%s" to "%s" ' % (sGroup, sFile))
    utils.createFolderIfNotExists(sFile)

    cmds.file(sFile, pr=False, es=True, force=True, typ='mayaAscii', options="v=0;", constructionHistory=False)
    #


def createTransformFromSelectedPoints(sName, sParent, bLockToMiddle=False, sSkinningSphere=None, bNoTransform=False):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.spaceLocator(n=sName)[0]
    print('aMean: ', aMean)
    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))

    if bLockToMiddle:
        for sL in ['%s.%s' % (sLoc, sAttr) for sAttr in ['tx', 'ry', 'rz']]:
            cmds.setAttr(sL, 0.0)
            cmds.setAttr(sL, lock=True)

    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        print('bNoTransform:', bNoTransform)
        if bNoTransform:
            cmds.parent(sSkinningSphere, sParent)
            cmds.delete(sLoc)
    return sLoc


def createMatrixCtrlromSelectedPoints(sName, sParent, sSkinningSphere=None, fRotate=(0,0,0)):
    pSel = patch.getSelectedPatches()[0]
    if pSel.aIds.size in [0, pSel.aIds.size - 1]:
        raise Exception('select one vertex of the mesh')

    aMean = np.mean(pSel.getPoints(), axis=0)
    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls5.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    fnMesh = OpenMaya2.MFnMesh(pSel.mDagPath)
    _, mNormal, _ = fnMesh.getClosestPointAndNormal(OpenMaya2.MPoint(list(aMean)), space=OpenMaya2.MSpace.kWorld)

    cmds.setAttr('%s.t' % sLoc, *list(aMean))
    xforms.orientThreePoints(sLoc, (mNormal.x, mNormal.y, mNormal.z), (0, 0, -1), fAimVector=(0, 0, 1),
                             fUpVector=(1, 0, 0))

    cmds.rotate(fRotate[0], fRotate[1], fRotate[2], sLoc, r=True, os=True)
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))
    if sSkinningSphere:
        patch.createSkinningSphere(sSkinningSphere, sLoc, sParent=sLoc)
        cmds.parent(sSkinningSphere, sParent)


def createMatrixCtrlFromTransform(sName, sParent, sTransform=None):
    if sTransform == None:
        sTransform = cmds.ls(sl=True)[0]

    sLoc = cmds.createNode('transform', n=sName)
    curves.addShapeWithPoints(sLoc, ctrls5.dCtrlShapes['matrix'])
    cmds.select(sLoc)
    cmds.ToggleLocalRotationAxes()

    cmds.delete(cmds.parentConstraint(sTransform, sLoc))
    cmds.parent(sLoc, xforms.createOrReturnTopGroup(sParent))



def mirrorGroup(sGrp, bDeleteNewChildren=False):
    sMirrorName = utils.getMirrorName(sGrp)
    if not cmds.objExists(sMirrorName):
        if not cmds.objExists(sGrp):
            return None
        sMirrorGrp = cmds.duplicate(sGrp, n=sMirrorName)[0]
        if bDeleteNewChildren:
            cmds.delete(cmds.listRelatives(sMirrorGrp, c=True, f=True))

        sTemp = cmds.createNode('transform')
        sOldParent = cmds.listRelatives(sMirrorGrp, p=True)
        cmds.parent(sMirrorGrp, sTemp)
        cmds.setAttr('%s.sx' % sTemp, -1)
        if sOldParent:
            cmds.parent(sMirrorGrp, sOldParent)
        else:
            cmds.parent(sMirrorGrp, w=True)
        # cmds.setAttr('%s.tx' % sMirrorGrp, -cmds.getAttr('%s.tx' % sMirrorGrp))

        cmds.delete(sTemp)
        return sMirrorGrp
    return sMirrorName


def createBpCurve(sName, sParent, fDirection=(1, 0, 0), bTrackedOrder=False):  # , bInToOut=None, bBotToTop=None):
    if cmds.objExists(sName):
        cmds.delete(sName)
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sCurve = curves.createCurveFromSelectedVerts(sName=sName, fDirection=fDirection,
                                                 bTrackedSelectionOrder=bTrackedOrder)
    utils.addStringAttr(sCurve, 'sMesh', sMesh)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.select(sCurve)


def createBothBpCurves(sName, sParent, fDirection=(1, 0, 0)):
    # if cmds.objExists(sName): cmds.delete(sName)
    # utils.reload2(curves)
    sCurve, sLocA, sLocB = curves.createCurveWithSeparationLocs(sName, fDirection=fDirection)

    cmds.parent(sCurve, xforms.createOrReturnTopGroup(sParent))
    cmds.parent(sLocA, sLocB, sCurve)
    cmds.select(sCurve)


def createBpUpVectorCurve(sName, sMainCurve):
    sMesh = cmds.getAttr('%s.sMesh' % sMainCurve)
    if not cmds.objExists(sMainCurve):
        raise Exception('"%s" doesn\'t exist - make sure you run the previous steps' % sMainCurve)
    if not cmds.objExists(sMesh):
        raise Exception('"%s" doesn\'t exist anymore' % sMesh)

    fClosest = cmds.kt_findClosestPoints(fromMesh=sMainCurve, toMesh=sMesh, returnNormals=True)
    aClosest = np.array(fClosest, dtype='float64').reshape(-1, 6)
    aNormals = aClosest[:, 3:6]
    aNormals /= np.linalg.norm(aNormals, axis=1).reshape(-1, 1)
    fLength = curves.getLength(sMainCurve)

    if cmds.objExists(sName):
        cmds.delete(sName)
    sNewCurve = cmds.duplicate(sMainCurve, n=sName)[0]
    pNewCurve = patch.patchFromName(sNewCurve)
    aPushedOutPoints = pNewCurve.getPoints() + aNormals * (fLength * 0.1)
    pNewCurve.setPoints(aPushedOutPoints)


def _getFaceCtrlGrp():
    sName = 'faceCtrls'
    if not cmds.objExists(sName):
        sSelBefore = cmds.ls(sl=True)
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.ctrlVis' % sMaster, '%s.v' % sName)
        cmds.select(sSelBefore)

    return sName


def getFaceGrp():
    sName = 'faceRig'
    if not cmds.objExists(sName):
        sMaster = utils.getMasterName()
        xforms.createOrReturnTopGroup(sName, sParent=sMaster)
        cmds.connectAttr('%s.rigVis' % sMaster, '%s.v' % sName)
    return sName


def getParentJointOrigin(sParentJoint):
    sName = '%sOrigin' % sParentJoint
    if not cmds.objExists(sName):
        xforms.createJoint(sName, sParent=getFaceGrp(), sMatch=sParentJoint)
    return sName



# def recordJawPose(_uiArgs=None):
#     fRotation = cmds.getAttr('jaw_ctrl.r')[0]
#     fTranslation = cmds.getAttr('jaw_ctrl.t')[0]
#     _uiArgs['fRotation'].setText(str(fRotation))
#     _uiArgs['fTranslation'].setText(str(fTranslation))



@builderTools.addToBuild(iOrder=10, dButtons={}, bDisableByDefault=True)
def reloadModules():
    utils.reload2(blendShapesPro)

@builderTools.addToBuild(iOrder=62.1, dButtons={}, bDisableByDefault=True)
def jawAutoTranslate(fOverwriteRotation=None, fOverwriteTranslation=None, sSuffix=''):
    '''
    in order for this to work, make sure in the blueprints the polevector is pointing down, and the
    fAdjustAxisOrientation is [0,0,0]
    Basically minus rotateZ is opening the jaw

    This should be taken from the blendShape
    '''

    #
    # if not utils.data.exists('sBakedBlendShapeJawOpenTranslation%s' % sSuffix):
    #     report.report.addLogText('no jawOpen setup from blendShape file')
    #     return False

    if utils.isNone(fOverwriteTranslation):
        fTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation%s' % sSuffix)
        report.report.addLogText('taking from blendShape file translation: %s' % str(fTranslation))
    else:
        fTranslation = fOverwriteTranslation

    if utils.isNone(fOverwriteRotation):
        fRotation = utils.data.get('sBakedBlendShapeJawOpenRotation%s' % sSuffix)
        report.report.addLogText('taking from blendShape file rotation: %s' % str(fRotation))
    else:
        fRotation = fOverwriteRotation

    fDriverValue = fRotation[2]


    sJawCtrl = 'jaw%s_ctrl' % sSuffix
    sJawJoint = 'jnt_m_jaw%sMain' % sSuffix

    cmds.setAttr('%s.r' % sJawCtrl, 0,0,0)
    cmds.setAttr('%s.t' % sJawCtrl, 0,0,0)

    cCtrl = ctrls5.ctrlFromName(sJawCtrl)
    sOffsetTranslation = cCtrl.appendOffsetGroup('poseTranslation')
    sOffsetRotation = cCtrl.appendOffsetGroup('poseRotation')

    sDriverValue = '%s.rz' % sJawCtrl
    sDriverValueClampedPre = nodes.createClampNode(sDriverValue, 0, 10000000)
    sDriverValueClampedPost = nodes.createClampNode(sDriverValue, -10000000, fDriverValue)
    sDriverValueClampedOffsetPost = nodes.createAdditionNode([sDriverValueClampedPost, fDriverValue], sOperation='minus')

    # sRotation = nodes.createVectorAdditionNode([fRotation, [0,0,sDriverValue]], sOperation='minus')

    sRangeRot = nodes.createRangeNode(sDriverValue, 0, fDriverValue, [0,0,0], fRotation,
                                      bOutRangeIsVector=True)

    sSubtract = nodes.createVectorAdditionNode([sRangeRot, [0,0,sDriverValue]],
                                               sOperation='minus')

    # to do: add overshoot and undershoot
    nodes.createVectorAdditionNode([[0,0,sDriverValueClampedPre], sSubtract, [0,0,sDriverValueClampedOffsetPost]], sTarget='%s.r' % sOffsetRotation)

    nodes.createRangeNode(sDriverValue, 0, fDriverValue, [0,0,0], fTranslation,
                          sTarget='%s.t' % sOffsetTranslation, bOutRangeIsVector=True)

    utils.addStringAttr(sJawJoint, 'fOpenRotation', str(fRotation))
    utils.addStringAttr(sJawJoint, 'fOpenTranslation', str(fTranslation))

    utils.data.store('fJawAutoTranslateDriverValue%s' % sSuffix, fDriverValue, sNode=utils.kFaceDataNode)

    sUnrealCommands = []
    sUnrealCommands.append('\n\n# auto jaw\n')
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox()")
    sUnrealCommands.append("eJawOffset = jaw_ctrl.addOffset('auto')")

    sUnrealCommands.append("fDriverValue = %0.3f" % fDriverValue)
    sUnrealCommands.append("sDriverValue = '%s.Pitch' % nodes.getControlRotator(jaw_ctrl.eControl, bLocal=True)")
    sUnrealCommands.append("sDriverValueClampedPre = nodes.createClampNode(sDriverValue, 0, 10000000)")
    sUnrealCommands.append("sDriverValueClampedPost = nodes.createClampNode(sDriverValue, -10000000, fDriverValue)")
    sUnrealCommands.append("sDriverValueClampedOffsetPost = nodes.createBasicCalculateNode([sDriverValueClampedPost, fDriverValue], sOperation='Subtract')")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("sRangeRot = nodes.createRemapNode(sDriverValue, 0, fDriverValue, [0,0,0], %s, bOutIsVector=True)" % utilsUnreal.flipVectorToUnreal(fRotation))
    sUnrealCommands.append("sSubtract = nodes.createBasicCalculateNode([sRangeRot, [0,sDriverValue,0]], sOperation='Subtract', iPinType=pins.PinType.integer)")
    sUnrealCommands.append("sOffsetRotationValue = nodes.createBasicCalculateNode([[0,sDriverValueClampedPre,0], sSubtract, [0,sDriverValueClampedOffsetPost,0]], sOperation='Add', iPinType=pins.PinType.vector)")
    sUnrealCommands.append("sOffsetTranslationValue = nodes.createRemapNode(sDriverValue, 0, fDriverValue, [0,0,0], %s, bOutIsVector=True)" % utilsUnreal.flipVectorToUnreal(fTranslation))
    sUnrealCommands.append("sQuat = nodes.createFromEulerNode(sOffsetRotationValue)")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("nodes.createSetTransformExecuteNode(eJawOffset, [sOffsetTranslationValue, sQuat, None], bLocal=True)")
    sUnrealCommands.append("controllers.closeCommentBox('Auto Jaw')")

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()

def bindPostLips():

    sBody = cmds.ls(sl=True)[0]

    sJoints = [sJ for sJ in cmds.ls('jnt_?_mouthPOST_*', et='joint') if not sJ.endswith('_ref')]

    sSkinCluster = 'skinCluster__%s__POST' % sBody
    if not cmds.objExists(sSkinCluster):
        print('create skinCluster with joints: %s' % sJoints)
        deformers.skinMesh(sBody, sName='skinCluster__%s__POST' % sBody,
                           sInfluences=['jnt_m_faceZero'] + sJoints,
                           bAlwaysAddDefaultWeights=True)
    else:
        print('adding influences to %s: %s' % (sSkinCluster, sJoints))
        deformers.addInfluences(sSkinCluster, sJoints)


kMouthPostBpGroupName = '_grp_m_mouthBpsPOST'
kMouthPostBpFileName = 'faceBlueprintsMouthPOST.ma'


dButtons = OrderedDict()
dButtons['Create Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_postLips', kMouthPostBpGroupName, fDirection=(-1, 0, 0))
dButtons['Attach Joints to Selected'] = bindPostLips
# dButtons['Add Bind Corner Rot (do the normal bind first and then open mouth and select mesh)'] = bindCornerRotPostLips
dButtons['- Export Mouth Post BPs -'] = lambda: exportBps(kMouthPostBpFileName, kMouthPostBpGroupName)



@builderTools.addToBuild(iOrder=85, dButtons=dButtons, bDisableByDefault=True)
def POST_mouth(sAttachMesh=[], fHalfPercs=[0.0, 0.25, 0.5], bFlipInnerBpCurves=False, bOrientAttach=True, sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sPostCtrls = cmds.createNode('transform', n='grp_mouthPostCtrls', p='ctrls')
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    sBpCurves = ['bpCurve_m_%sPostLipA' % sPart for sPart in ['bot', 'top']]
    if bFlipInnerBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs('bpCurve_m_postLips', 'locA_m_postLips', 'locB_m_postLips', sBpCurves[1], sBpCurves[0])
    else:
        curves.separateCurveUsingSeparationLocs('bpCurve_m_postLips', 'locA_m_postLips', 'locB_m_postLips', sBpCurves[0], sBpCurves[1])

    aHalfPercs = np.array(fHalfPercs, dtype='float64')
    aCtrlPercs = np.concatenate([aHalfPercs, 1.0-aHalfPercs[::-1][1:]])
    iCtrlCount = len(aCtrlPercs)
    report.report.addLogText('Params: %s' % list(aCtrlPercs))
    aSides, aInds = utils.convertMiddleSequenceToSides(iCtrlCount)

    aaPoints = []

    for p,sPart in enumerate(['bot','top']):
        aPoints = curves.getPointsFromPercs(sBpCurves[p], aCtrlPercs, bReturnNumpy=True)
        if True:
            pBpCurve = patch.patchFromName(sBpCurves[p])
            aBpPoints = pBpCurve.getPoints()
            iPoints = xforms.findClosestPoints(aPoints, aBpPoints)
            aPoints = aBpPoints[iPoints]

        aaPoints.append(aPoints)

    fCurveEndsDistance = barycentric.distanceBetween('%s.cv[0]' % sBpCurves[0], '%s.cv[%d]' % (sBpCurves[0], len(cmds.ls('%s.cv[*]' % sBpCurves[0], flatten=True))-1)) * 0.5
    fSliderScale = fCurveEndsDistance * 0.25

    dCommonFlags = {'sShape': 'cube', 'fSize': 1, 'sAttrs':['t','r','s'],
                    'sParent': sPostCtrls, 'iColorIndex': 2, 'fSliderScale':fSliderScale}

    cCorners = [ctrls5.create(sName='postLipsCorner', sSide='l', fMatchPos=aaPoints[0][0], **dCommonFlags),
                ctrls5.create(sName='postLipsCorner', sSide='r', fMatchPos=aaPoints[0][-1], **dCommonFlags)]

    ccCtrls = [], []

    for p,sPart in enumerate(['bot','top']):
        for i in range(iCtrlCount):
            if i in [0,iCtrlCount-1]:
                continue
            cC = ctrls5.create(sName='postLips%s' % utils.getFirstLetterUpperCase(sPart), iIndex=aInds[i], sSide=aSides[i],
                               fMatchPos=aaPoints[p][i], **dCommonFlags)
            ccCtrls[p].append(cC)

    aLocalUp = utils.getNumpyMatrixFromTransform('mouth_ctrl')[2,0:3]

    # orient the controls
    print('aaPoints: ', aaPoints)
    for i in range(iCtrlCount):

        fSideMultipl = -1.0 if aSides[i] == 'r' else 1.0
        if i in [0, iCtrlCount-1]:
            if i == 0:
                aLocalAim = (aaPoints[0][1]+aaPoints[1][1]) * 0.5 - aaPoints[0][0]
                xforms.orientThreePoints(cCorners[0].sPasser, aLocalAim, aLocalUp, fAimVector=[-1,0,0], fUpVector=[0,0,1])
            else:
                aLocalAim = (aaPoints[0][-2]+aaPoints[1][-2]) * 0.5 - aaPoints[0][-1]
                xforms.orientThreePoints(cCorners[1].sPasser, aLocalAim, aLocalUp, fAimVector=[1,0,0], fUpVector=[0,0,-1])
        else:
            c = i - 1
            for p,sPart in enumerate(['bot','top']):
                aLocalAim = ((aaPoints[p][i-1]-aaPoints[p][i]) - (aaPoints[p][i+1]-aaPoints[p][i]))
                xforms.orientThreePoints(ccCtrls[p][c].sPasser, aLocalAim, aLocalUp, fAimVector=[1, 0, 0], fUpVector=[0, 0, fSideMultipl])


    cAllLipCtrls = cCorners + ccCtrls[0] + ccCtrls[1]
    for c,cC in enumerate(cAllLipCtrls):
        cC.sJ = 'jnt_%s_mouthPOST_%s' % (cC.sSide, cC.sName)
        if cC.iIndex != None:
            cC.sJ = '%s_%03d' % (cC.sJ, cC.iIndex)

        if cmds.objExists(cC.sJ):
            xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
            xforms.resetTransform(cC.sJ, jo=True)
        else:
            cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

        cmds.setAttr('%s.v' % cC.sJ, False)
        cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

        utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr([cC.sJ for cC in cAllLipCtrls])

    sPostAttachTransforms = [cC.sPasser for cC in cAllLipCtrls]
    if bOrientAttach:
        [utils.addOffOnAttr(sT, deformers.kRotateByNeighborVerts, False if 'Corner' in sT else True) for sT in sPostAttachTransforms]

    if sSkipAttachDeformers:
        sSkipAttachDeformersString = '.'.join(sorted(sSkipAttachDeformers))
        [utils.addStringAttr(sT, kSkipAttachDeformers, str(sSkipAttachDeformersString)) for sT in sPostAttachTransforms]

    utils.data.addToList('sAllPostCtrlsForUnreal', [cC.sCtrl for cC in cAllLipCtrls])


    utils.data.addToList('postAttachTransforms', sPostAttachTransforms)
    utils.data.addToList('postAttachTransformMeshes', [sAttachMesh] * len(sPostAttachTransforms))



@builderTools.addToBuild(iOrder=89, dButtons={}, bDisableByDefault=True)
def attachPOST(sParentJoint='jnt_m_headMain', sAdditionalSkinClusters=[]):

    # utils.reload2(deformers)
    sGrp = cmds.createNode('transform', n='grp_attachPostCtrls', p='modules')
    sPostAttachTransforms = utils.data.get('postAttachTransforms', xDefault=[])
    sPostAttachTransformMeshes = utils.data.get('postAttachTransformMeshes', xDefault=[])
    if len(sPostAttachTransforms) != len(sPostAttachTransformMeshes):
        raise Exception('sPostAttachTransforms has different count than sPostAttachTransformMeshes (%d -> %d)' % \
                         (len(sPostAttachTransforms), len(sPostAttachTransformMeshes)))

    dTransforms = defaultdict(list)
    for sT, sM in zip(sPostAttachTransforms, sPostAttachTransformMeshes):
        dTransforms[sM].append(sT)


    for sBody, sAllMeshTransforms in list(dTransforms.items()):
        sAllMeshDeformers = [sS for sS in ['skinCluster__%s' % sBody, 'skinCluster__%s__ZIPPER' % sBody,
                                       'skinCluster__%s__BEND' % sBody,
                                       'lattice__%s__l_EYE' % sBody,
                                       'lattice__%s__r_EYE' % sBody] if cmds.objExists(sS)]
        sAllMeshDeformers += [sS for sS in utils.toList(sAdditionalSkinClusters) if sS in cmds.listHistory(sBody)]

        sCurrentDeformersOnMesh = deformers.listAllDeformers(sBody, sFilterTypes=['skinCluster', 'ffd'])
        sReorderedMeshDeformers = [sS for sS in sCurrentDeformersOnMesh if sS in sAllMeshDeformers][::-1]

        dSplitSkipDeformers = defaultdict(list)
        for sT in sAllMeshTransforms:
            sSkipAttachDeformersAttr = '%s.sSkipAttachDeformers' % sT
            if cmds.objExists(sSkipAttachDeformersAttr):
                dSplitSkipDeformers[cmds.getAttr(sSkipAttachDeformersAttr)].append(sT)
            else:
                dSplitSkipDeformers[''].append(sT)


        print ('dSplitSkipDeformers: ', dSplitSkipDeformers)
        for sSkip, sTransforms in dSplitSkipDeformers.items():


            aClosestIds = xforms.getClosestIdsFromPoints(sBody, xforms.getPositionArray(sTransforms))


            bRotateByNeighborVerts = []
            for sT in sTransforms:
                sAttr = '%s.%s' % (sT, deformers.kRotateByNeighborVerts)
                if cmds.objExists(sAttr):
                    bRotateByNeighborVerts.append(cmds.getAttr(sAttr))
                else:
                    bRotateByNeighborVerts.append(False)


            dSplitSkipDeformers = defaultdict(list)
            for sT in sTransforms:
                sSkipAttachDeformersAttr = '%s.sSkipAttachDeformers' % sT
                if cmds.objExists(sSkipAttachDeformersAttr):
                    dSplitSkipDeformers[cmds.getAttr(sSkipAttachDeformersAttr)].append(sT)
                else:
                    dSplitSkipDeformers[''].append(sT)

            sSkip = sSkip.split('.')
            sReorderedDeformers = [sD for sD in sReorderedMeshDeformers if sD not in sSkip]

            print ('sBody: ', sBody)
            sLocs = constraints.parallelTransformAsDeformers(sBody, aClosestIds, sParent=sGrp,
                                                             fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint,
                                                             sDeformers=sReorderedDeformers, bRotateByNeighborVerts=bRotateByNeighborVerts)

            for c,sT in enumerate(sTransforms):
                xforms.matrixParentConstraint(sLocs[c], sT, mo=True)


def bindPostEyes():
    sBodyMeshes = cmds.ls(sl=True)
    sBody = sBodyMeshes[0]
    sJoints = [sJ for sJ in cmds.ls('jnt_?_eyesPOST_*', et='joint') if not sJ.endswith('_ref')]

    sSkinCluster = 'skinCluster__%s__POST' % sBody
    if not cmds.objExists(sSkinCluster):
        deformers.skinMesh(sBody, sName='skinCluster__%s__POST' % sBody,
                           sInfluences=['jnt_m_faceZero'] + sJoints,
                           bAlwaysAddDefaultWeights=True)
    else:
        print('adding influences: ', sJoints)
        deformers.addInfluences(sSkinCluster, sJoints)


kEyelidPostBpGroupName = '_grp_m_eyesBpPOST'
kEyelidPostBpFileName = 'faceBlueprintsEyesPOST.ma'


def bindEyelidCornerRotPostLips():
    sBody = cmds.ls(sl=True)[0]
    sAllSkinClusters = deformers.listAllDeformers(sBody, sFilterTypes=['skinCluster'])
    sPostSkinClusters = [sS for sS in sAllSkinClusters if sS.endswith('__POST')]
    if not sPostSkinClusters:
        raise Exception('no post skinCluster was found on %s' % sBody)

    dJoints = {}
    for s,sSide in enumerate(['l','r']):
        sJoints = ['jnt_%s_eyesPOST_eyelidCornerIn' % sSide, 'jnt_%s_eyesPOST_eyelidCornerInBot' % sSide, 'jnt_%s_eyesPOST_eyelidCornerInTop' % sSide]
        dJoints.update({sJ: '; '.join(sJoints) for sJ in sJoints})
        sJoints = ['jnt_%s_eyesPOST_eyelidCornerOut' % sSide, 'jnt_%s_eyesPOST_eyelidCornerOutBot' % sSide, 'jnt_%s_eyesPOST_eyelidCornerOutTop' % sSide]
        dJoints.update({sJ: '; '.join(sJoints) for sJ in sJoints})

    weights.moveSkinClusterWeights(patch.patchFromName(sBody),
                                   xJoints=dJoints,
                                   iSmoothBorderMask=5, iSmoothSteps=0, sChooseSkinCluster=sPostSkinClusters[0])




dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_lids', kEyelidPostBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['create Right Curve and Locators'] = lambda: createBothBpCurves('bpCurve_r_lids', kEyelidPostBpGroupName,
                                                                        fDirection=(-1, 0, 0))
dButtons['create Right Curve and Locators'].dSideButtons = {'?':[['Select vertices and click button.', 'eyelidVertices.jpg'],
                                                    ['Locators indicate separation points between bottom and top eyelid. '\
                                                     'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['Add Influences to Selected'] = bindPostEyes
# dButtons['Add Tangent Influences to Selected'] = bindEyelidCornerRotPostLips
dButtons['- Export Eyelid Post BPs -'] = lambda: exportBps(kEyelidPostBpFileName, kEyelidPostBpGroupName)



# to do: check that disabled live rotation setup
@builderTools.addToBuild(iOrder=85, dButtons=dButtons, bDisableByDefault=True)
def POST_lids(sAttachMesh=[], fMidPercs=[0.25, 0.5, 0.75], sNames=['inner', 'mid', 'outer'], sSkipAttachDeformers=[]):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    if len(fMidPercs) != len(sNames):
        raise Exception('fMidPercs and sNames need to have same count (%d -> %d)' % (len(fMidPercs), len(sNames)))

    for sCrv in ['bpCurve_l_lids', 'bpCurve_r_lids']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_lids', 'locB_l_lids', 'locA_r_lids', 'locB_r_lids']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_l_lids', 'locA_l_lids', 'locB_l_lids', 'bpCurve_l_botLid',
                                            'bpCurve_l_topLid'))
    ssCurves.append(curves.separateCurveUsingSeparationLocs('bpCurve_r_lids', 'locA_r_lids', 'locB_r_lids', 'bpCurve_r_botLid',
                                            'bpCurve_r_topLid'))

    fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccEyeCtrls = [[], []]
    sCornerNames = ['cornerIn', 'cornerOut']
    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    sssCtrlJoints = [[], []], [[], []]
    sNurbsSpheres = ['nurbs_l_eyeRigSphere', 'nurbs_r_eyeRigSphere']
    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0

        # bottom tops
        for p,sPart in enumerate(['bot','top']):
            fCtrlParams = curves.getParamsFromPercs(ssCurves[s][p], fMidPercs)
            aTangents = curves.getTangentsFromParams(ssCurves[s][p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(ssCurves[s][p], fCtrlParams)
            for c, fP, sN in zip(range(len(fCtrlParams)), fCtrlParams, sNames):
                sName = 'eyelid%s%s' % (utils.getFirstLetterUpperCase(sN), utils.getFirstLetterUpperCase(sPart))

                cC = ctrls5.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, fSliderScale=fSliderScale,
                                  sAttrs=['t','r','s'], fSize=0.1, sShape='cube', fMatchPos=aCtrlPoints[c])
                cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

                if cmds.objExists(sNurbsSpheres[s]):
                    sClosestNode, _ = surfaces.createClosestPointNode(sNurbsSpheres[s], nodes.getWorldPoint(cC.sCtrl))
                    cC.sSurfaceInfoNode, _ = surfaces.createPointInfoNode(sNurbsSpheres[s], '%s.parameterU' % sClosestNode, '%s.parameterV' % sClosestNode)
                    xforms.orientThreePoints(cC.sPasser, cmds.getAttr('%s.normal' % cC.sSurfaceInfoNode)[0], aTangents[c],
                                             fAimVector=[0,0,1], fUpVector=[fSideMultipl,0,0])
                    xforms.orientThreePoints(cC.sPasser, cmds.getAttr('%s.normal' % cC.sSurfaceInfoNode)[0], aTangents[c],
                                             fAimVector=[0,0,1], fUpVector=[fSideMultipl,0,0])

                    #ref
                    sRefClosestNode, _ = surfaces.createClosestPointNode(sNurbsSpheres[s], nodes.getWorldPoint(cC.sPasser))
                    cC.sRefSurfaceInfoNode, _ = surfaces.createPointInfoNode(sNurbsSpheres[s], '%s.parameterU' % sRefClosestNode, '%s.parameterV' % sRefClosestNode)

                else:
                    xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangents[c], fAimVector=[0,0,-1], fUpVector=[1,0,0] )
                    cC.sSurfaceInfoNode = None

                cccBotTopCtrls[s][p].append(cC)
                ccEyeCtrls[s].append(cC)

        # corners
        fCtrlParams = curves.getParamsFromPercs(ssCurves[s][0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(ssCurves[s][0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, sCornerNames):
            sName = 'eyelid%s' % (utils.getFirstLetterUpperCase(sN))

            cC = ctrls5.create(sName=sName, sSide=sSide, sParent=_getFaceCtrlGrp(), iColorIndex=2, sMatch='jnt_%s_eyeMain' % sSide,
                              sAttrs=['t','r'], fSize=0.1, sShape='cube', fMatchPos=aCtrlPoints[c], fSliderScale=fSliderScale)

            if c == 0:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray([cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0]+aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            if cmds.objExists(sNurbsSpheres[s]):
                sClosestNode, _ = surfaces.createClosestPointNode(sNurbsSpheres[s], nodes.getWorldPoint(cC.sCtrl))
                cC.sSurfaceInfoNode, _ = surfaces.createPointInfoNode(sNurbsSpheres[s], '%s.parameterU' % sClosestNode, '%s.parameterV' % sClosestNode)
                xforms.orientThreePoints(cC.sPasser, cmds.getAttr('%s.normal' % cC.sSurfaceInfoNode)[0], aTangent, fAimVector=[0, 0, fSideMultipl], fUpVector=[1, 0, 0])
            else:
                xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -1], fUpVector=[1, 0, 0])
                cC.sSurfaceInfoNode = None

            ccCornerCtrls[s].append(cC)
            ccEyeCtrls[s].append(cC)

        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, ctrls5.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s]).sCtrl, parent=True)


        sEyePoint = nodes.getWorldPoint(sEyeJoints[s])
        for c,cC in enumerate(ccEyeCtrls[s]):
            cC.sJ = 'jnt_%s_eyesPOST_%s' % (sSide, cC.sName)
            sssCtrlJoints[s][p].append(cC.sJ)
            if cmds.objExists(cC.sJ):
                xforms.parentJointNoTransform(cC.sJ, cC.sCtrl)
                xforms.resetTransform(cC.sJ, jo=True)
            else:
                cmds.createNode('joint', n=cC.sJ, p=cC.sCtrl)

            # cC.sRefG = cmds.createNode('transform', n='%s_refGrp' % cC.sJ, p=cmds.listRelatives(cC.sCtrl, p=True, c=False)[0])
            # cC.sRefJ = cmds.createNode('joint', n='%s_ref' % cC.sJ, p=cC.sRefG)
            # cmds.delete(cmds.scaleConstraint(cC.sJ, cC.sRefG))
            utils.addStringAttr(cC.sJ, deformers.kPostRefJointAttr, cC.sSlider)

            cmds.setAttr('%s.radius' % cC.sJ, 0.1)
            # cmds.setAttr('%s.radius' % cC.sRefJ, 0.15)
            fSideMultipl = -1.0 if cC.sSide == 'r' else 1.0
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJ)
            # cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sRefG)
            # cmds.setAttr('%s.s' % cC.sSlider, fSliderScale, fSliderScale*fSideMultipl, fSliderScale)


            sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
            sDecomposeMatrix = nodes.createDecomposeMatrix('%s.worldMatrix' % sCtrlParent, bReturnRotate=True)
            sNoRotMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(cC.sCtrl),
                                                         xRotate=sDecomposeMatrix,
                                                         xScale='%s.outputScale' % sDecomposeMatrix.split('.')[0])
            sInverseNoRotMatrix = nodes.createInverseMatrix(sNoRotMatrix)

            if cC.sSurfaceInfoNode != None:
                sAimTarget = nodes.createVectorAdditionNode([nodes.getWorldPoint(cC.sCtrl), '%s.normal' % cC.sSurfaceInfoNode])
                sAimTargetLocal = nodes.createPointByMatrixNode(sAimTarget, sInverseNoRotMatrix)
                nodes.createSimpleAimConstraint2(sAimTargetLocal, cC.sOut, bRotateUp=False, xAimVector=[0,0,fSideMultipl], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
            else:
                sAimTargetLocal = nodes.createPointByMatrixNode(sEyePoint, sInverseNoRotMatrix)
                nodes.createSimpleAimConstraint2(sAimTargetLocal, cC.sOut, bRotateUp=False, xAimVector=[0, 0, -1], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
                sLocalCtrlPlane = ['%s.tx' % cC.sCtrl, '%s.ty' % cC.sCtrl, 0]
                sDistanceInsidePlane = nodes.createDistanceNode([0,0,0], sLocalCtrlPlane)
                sCtrlPlane = nodes.createPointByMatrixNode(sLocalCtrlPlane, '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0])
                sDiff = nodes.createVectorAdditionNode([sCtrlPlane, sEyePoint], sOperation='minus')
                sDistance = nodes.createDistanceNode([0,0,0], sDiff)
                sNormDiff = nodes.createVectorMultiplyNode(sDiff, sDistance, sOperation='divide', bVectorByScalar=True)

                sAutoPushAttr = utils.addAttr(cC.sCtrl, ln='autoPushOut', k=True, dv=2)
                sAutoPush = nodes.createMultiplyNode(sDistanceInsidePlane, sAutoPushAttr)
                sPushOutDistance = nodes.createAdditionNode([cmds.getAttr(sDistance), '%s.tz' % cC.sCtrl, sAutoPush])
                sScaledDiff = nodes.createVectorMultiplyNode(sNormDiff, sPushOutDistance, bVectorByScalar=True)
                sWorldPos = nodes.createVectorAdditionNode([sEyePoint, sScaledDiff])

                sCtrlPlaneMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(sLocalCtrlPlane),
                                                               '%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0]])
                sInvCtrlPlaneMatrix = nodes.createInverseMatrix(sCtrlPlaneMatrix)
                nodes.createPointByMatrixNode(sWorldPos, sInvCtrlPlaneMatrix, sTarget='%s.t' % cC.sOut)

            # ref
            # if cC.sSurfaceInfoNode != None:
            #     sRefAimTarget = nodes.createVectorAdditionNode([nodes.getWorldPoint(cC.sSlider), '%s.normal' % cC.sSurfaceInfoNode])
            #     sRefAimTargetLocal = nodes.createPointByMatrixNode(sRefAimTarget, '%s.worldInverseMatrix' % cC.sSlider)
            #     nodes.createSimpleAimConstraint2(sRefAimTargetLocal, cC.sRefG, bRotateUp=False, xAimVector=[0,0,fSideMultipl], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sCtrl)
            # else:
            #     sRefAimTargetLocal = nodes.createPointByMatrixNode(sEyePoint, '%s.worldInverseMatrix' % cC.sSlider)
            #     nodes.createSimpleAimConstraint2(sRefAimTargetLocal, cC.sRefG, bRotateUp=False, xAimVector=[0, 0, -1], xUpVector=[0, 1, 0], xWorldUpVector=[1, 0, 0], sParent=cC.sRefJ)
            #
            #     sRefPoint = nodes.getWorldPoint(cC.sSlider)
            #     sDiff = nodes.createVectorAdditionNode([sRefPoint, sEyePoint], sOperation='mienus')
            #     sDistance = nodes.createDistanceNode([0,0,0], sDiff)
            #     sNormDiff = nodes.createVectorMultiplyNode(sDiff, sDistance, sOperation='divide', bVectorByScalar=True)
            #
            #     sScaledDiff = nodes.createVectorMultiplyNode(sNormDiff, cmds.getAttr(sDistance), bVectorByScalar=True)
            #     sWorldPos = nodes.createVectorAdditionNode([sEyePoint, sScaledDiff])
            #
            #     nodes.createPointByMatrixNode(sWorldPos, '%s.worldInverseMatrix' % cC.sSlider, sTarget='%s.t' % cC.sRefG)


    createOrFixFaceZero()

    deformers.connectJointReferencesFromAttr(utils.flattenedList(sssCtrlJoints))

    utils.data.addToList('sAllPostCtrlsForUnreal', [cC.sCtrl for cC in ccEyeCtrls[0]+ccEyeCtrls[1]])

    sPostAttachTransforms = [cC.sPasser for cC in ccEyeCtrls[0]+ccEyeCtrls[1]]
    [utils.addOffOnAttr(sT, deformers.kRotateByNeighborVerts, False if 'Corner' in sT else True) for sT in sPostAttachTransforms]
    if sSkipAttachDeformers:
        sSkipAttachDeformersString = '.'.join(sorted(sSkipAttachDeformers))
        [utils.addStringAttr(sT, kSkipAttachDeformers, str(sSkipAttachDeformersString)) for sT in sPostAttachTransforms]

    utils.data.addToList('postAttachTransforms', sPostAttachTransforms)
    utils.data.addToList('postAttachTransformMeshes', [sAttachMesh] * len(sPostAttachTransforms))




def browOrientationLocators():
    aPoints = curves.getPointsFromPercs('bpCurve_l_eyebrow', [0, 0.5, 1])
    sNames = ['inner', 'mid', 'outer']
    sLocs = []
    for i, aP in enumerate(aPoints):
        # sLoc = xforms.createLocator(sName='bpLoc_l_%sBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        sLoc = ctrls5.createSimpleCurve('matrixNames', sName='bpLoc_l_%sBrowOrientation' % sNames[i], sParent=sEyebrowsPostGrp)
        cmds.setAttr('%s.t' % sLoc, *list(aP))
        sLocs.append(sLoc)

    cmds.select(sLocs)



def bindPostEyebrows():
    sBody = cmds.ls(sl=True)[0]
    sJoints = [sJ for sJ in cmds.ls('jnt_?_browsPOST_*', et='joint') if not sJ.endswith('_ref')]
    sJoints += cmds.ls('jnt_?_*EyebrowPOST', et='joint')

    sSkinCluster = 'skinCluster__%s__POST' % sBody
    if not cmds.objExists(sSkinCluster):
        deformers.skinMesh(sBody, sName='skinCluster__%s__POST' % sBody,
                           sInfluences=['jnt_m_faceZero'] + sJoints,
                           bAlwaysAddDefaultWeights=True)
    else:
        print('adding influences: ', sJoints)
        deformers.addInfluences(sSkinCluster, sJoints)



sEyebrowsPostGrp = '_grp_m_browsBpPOST'
kEyebrowsPostFileName = 'faceBlueprintsBrowsPOST.ma'

dButtons = OrderedDict()
dButtons['Create Left Brow Curve'] = lambda: createBpCurve('bpCurve_l_eyebrow', sEyebrowsPostGrp, fDirection=(1, 0, 0))
dButtons['Create Left Brow Curve'].dSideButtons = {'?':['eyebrowVerts.jpg']}
dButtons['Create Left Brow Orientation Locators'] = browOrientationLocators

dButtons['Add Influences to Selected'] = bindPostEyebrows

dButtons['- Export Brows Post BPs -'] = lambda: exportBps(kEyebrowsPostFileName, sEyebrowsPostGrp)


@builderTools.addToBuild(iOrder=86, dButtons=dButtons, bDisableByDefault=True)
def POST_brows(sAttachMesh='', bSplines=True, iCurveJoints=None, bPolyCtrls=False, sSkipAttachDeformers=[], sVisAttrCtr='head_ctrl'):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')

    pFaceMesh = patch.patchFromName(sAttachMesh)
    sCtrlVis = utils.addOffOnAttr(utils.toList(sVisAttrCtr)[0], 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    utils.data.store('iEyebrowCurveJoints', iCurveJoints, sNode=utils.kFaceDataNode)

    sBrowsOrig = cmds.createNode('transform', name='grp_eyebrowsOrig', p=getFaceGrp())


    # sSkinJoints = []

    sBpCurves = ['bpCurve_%s_eyebrow' % sSide for sSide in ['l', 'r']]

    fSliderScale = curves.getLength(sBpCurves[0]) * 0.4
    utils.data.store('fSliderScaleEyebrows', fSliderScale, sNode=utils.kFaceDataNode)

    for sCrv in sBpCurves:
        curves.mirrorIfNotExists(sCrv)

    bJointsPerCvs = True if isinstance(iCurveJoints, type(None)) else False

    print('bJointsPerCvs: ', bJointsPerCvs)

    aaCurvePoints = [curves.getPointsFromPercs(sBpCurves[0], np.linspace(0.0, 1.0, 7), bReturnNumpy=True),
                    curves.getPointsFromPercs(sBpCurves[1], np.linspace(0.0, 1.0, 7), bReturnNumpy=True)]
    aaCtrlPoints = [[aaCurvePoints[0][0], aaCurvePoints[0][3], aaCurvePoints[0][6]],
                    [aaCurvePoints[1][0], aaCurvePoints[1][3], aaCurvePoints[1][6]]]

    sCurves = [cmds.curve(p=aaCurvePoints[0], n='curve_l_eyebrows'), cmds.curve(p=aaCurvePoints[1], n='curve_r_eyebrows')]


    if bJointsPerCvs:
        aaPoints = [np.array(cmds.xform('%s.cv[*]' % sCurves[0], q=True, ws=True, t=True)).reshape(-1,3),
                    np.array(cmds.xform('%s.cv[*]' % sCurves[1], q=True, ws=True, t=True)).reshape(-1,3)]
        ffParams = [curves.getParamsFromPoints(sCurves[0], aaPoints[0]),
                    curves.getParamsFromPoints(sCurves[1], aaPoints[1])]
    else:
        ffParams = [curves.getParamsFromPercs(sCurves[0], np.linspace(0.0, 1.0, iCurveJoints)),
                    curves.getParamsFromPercs(sCurves[1], np.linspace(0.0, 1.0, iCurveJoints))]
        aaPoints = [curves.getPointsFromParams(sCurves[0], ffParams[0], bReturnNumpy=True),
                    curves.getPointsFromParams(sCurves[1], ffParams[1], bReturnNumpy=True)]


    sRefCurves = [cmds.curve(p=aaCurvePoints[0], n='curve_l_eyebrowsRef'), cmds.curve(p=aaCurvePoints[1], n='curve_r_eyebrowsRef')]

    aaaWeights = [utils.bSpline3([1,0,0], len(aaPoints[0])),
                 utils.bSpline3([0,1,0], len(aaPoints[0])),
                 utils.bSpline3([0,0,1], len(aaPoints[0]))], \
                [utils.bSpline3([1, 0, 0], len(aaPoints[1])),
                 utils.bSpline3([0, 1, 0], len(aaPoints[1])),
                 utils.bSpline3([0, 0, 1], len(aaPoints[1]))]

    # collect orients
    ssBpOrients = []
    for s,sSide in enumerate(['l','r']):
        sBpOrients = []
        for sName in ['inner', 'mid', 'outer']:
            sBpOrient = 'bpLoc_%s_%sBrowOrientation' % (sSide, sName)
            if sSide == 'r':
                sLeftBpOrient = 'bpLoc_l_%sBrowOrientation' % sName
                if not cmds.objExists(sBpOrient) and cmds.objExists(sLeftBpOrient):
                    mirrorGroup(sLeftBpOrient)
            sBpOrients.append(sBpOrient)
        ssBpOrients.append(sBpOrients)

    # make up curves
    aaCurveUpPoints = []
    for s, sSide in enumerate(['l', 'r']):
        aaPushForwardWeights =  [utils.bSpline3([1, 0, 0], 7),
                                  utils.bSpline3([0, 1, 0], 7),
                                  utils.bSpline3([0, 0, 1], 7)]

        aForwardPoints =    utils.getNumpyMatrixFromTransform(ssBpOrients[s][0])[2,0:3] * aaPushForwardWeights[0][:,np.newaxis] + \
                            utils.getNumpyMatrixFromTransform(ssBpOrients[s][1])[2,0:3] * aaPushForwardWeights[1][:,np.newaxis] + \
                            utils.getNumpyMatrixFromTransform(ssBpOrients[s][2])[2,0:3] * aaPushForwardWeights[2][:,np.newaxis]
        aCurveUpPoints = aaCurvePoints[s] + aForwardPoints * fSliderScale
        aaCurveUpPoints.append(aCurveUpPoints)


    sUpCurves = [cmds.curve(p=aaCurveUpPoints[0], n='curve_l_eyebrowsUp'), cmds.curve(p=aaCurveUpPoints[1], n='curve_r_eyebrowsUp')]
    sUpRefCurves = [cmds.curve(p=aaCurveUpPoints[0], n='curve_l_eyebrowsUpRef'), cmds.curve(p=aaCurveUpPoints[1], n='curve_r_eyebrowsUpRef')]


    for sCrv in (sCurves + sRefCurves + sUpCurves + sUpRefCurves):
        cmds.parent(sCrv, sBrowsOrig)


    ccCtrls = [], []
    cMainCtrls = []
    for s, sSide in enumerate(['l', 'r']):
        for sName in ['inner', 'mid', 'outer']:
            try:
                xforms.mirrorIfNotExists('bpLoc_%s_%sBrow' % (sSide, sName))
            except:
                pass

        fSideMultipl = -1 if sSide == 'r' else 1



        fnMesh = OpenMaya2.MFnMesh(pFaceMesh.mDagPath)
        # aOffset = np.array([0, fSliderScale * 0.35, 0.0])
        aUps = np.zeros((2, 3, 3), dtype='float64')

        for c, sName in enumerate(['inner', 'mid', 'outer']):

            cC = ctrls5.create(sName='%sPostEyebrow' % (sName), sSide=sSide, sParent=_getFaceCtrlGrp(),
                                    bPoly=bPolyCtrls, iSlider=3,
                                    fMatchPos=aaCtrlPoints[s][c], sShape='cube', fSliderScale=fSliderScale,
                                    iColorIndex=2, sAttrs=['t','r','sy','sz'], fSize=0.25)

            # sSlider = cC.appendOffsetGroup('slider')
            # cmds.setAttr('%s.s' % sSlider, fSideMultipl*fSliderScale, fSliderScale, fSliderScale)
            cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

            ccCtrls[s].append(cC)
            sBpOrients[s] = 'bpLoc_%s_%sBrowOrientation' % (sSide, sName)

            aMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sBpOrients[s]), dtype='float64').reshape(4, 4)
            aUps[s, c] = aMatrix[1][:3]

            cC.sUnscaledCtrl = xforms.insertParent(cC.sOut, 'grp_%s_%sPostEyebrowUnscaled' % (sSide, sName), bMatchParentTransform=True)
            nodes.createVectorMultiplyNode([1,1,1], '%s.s' % cC.sCtrl, sOperation='divide', sTarget='%s.s' % cC.sUnscaledCtrl)

        xforms.orientThreePoints(ccCtrls[s][0].sPasser, aUps[s, 0], ccCtrls[s][1].sOut, fAimVector=[0, 1, 0],
                                 fUpVector=[fSideMultipl, 0, 0])
        xforms.orientThreePoints(ccCtrls[s][2].sPasser, aUps[s, 2], ccCtrls[s][1].sOut, fAimVector=[0, 1, 0],
                                 fUpVector=[-fSideMultipl, 0, 0])
        sUpMiddle = ((aaCtrlPoints[s][0] - aaCtrlPoints[s][1]) - (aaCtrlPoints[s][2] - aaCtrlPoints[s][1])) * 0.5
        xforms.orientThreePoints(ccCtrls[s][1].sPasser, aUps[s, 1], sUpMiddle, fAimVector=[0, 1, 0],
                                 fUpVector=[-fSideMultipl, 0, 0])

        cBrowTransform = ctrls5.create(sName='postEyebrowParent', sSide=sSide, sParent=_getFaceCtrlGrp(), fSliderScale=fSliderScale,
                          bPoly=bPolyCtrls, sMatch=ccCtrls[s][1].sCtrl, sShape='locator', iColorIndex=2, sAttrs=['t','r'], fSize=0.5)
        # sSlider = cBrowTransform.appendOffsetGroup('slider')

        # if sSide == 'r':
        #     cmds.setAttr('%s.s' % sSlider, -1, -1, -1)
        #     cmds.setAttr('%s.s' % cBrowTransform.sOut, -1, -1, -1)
        cMainCtrls.append(cBrowTransform)
        for c,cC in enumerate(ccCtrls[s]):
            sOffset = cC.appendOffsetGroup('maintransform', bBelowPasser=True, bMatchParentTransform=True)
            sMoveByMainMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser,
                                                             '%s.worldInverseMatrix' % cBrowTransform.sPasser,
                                                             '%s.worldMatrix' % cBrowTransform.sOut,
                                                             '%s.worldInverseMatrix' % cC.sPasser])
            nodes.createDecomposeMatrix(sMoveByMainMatrix, sTargetPos='%s.t' % sOffset, sTargetRot='%s.r' % sOffset, sTargetScale='%s.s' % sOffset)



    if bSplines:
        ssRefGroups = [], []
        ssJoints = [], []
        for s, sSide in enumerate(['l', 'r']):
            for c, sName in enumerate(['inner', 'mid', 'outer']):
                cC = ccCtrls[s][c]
                cC.sJoint = xforms.createJoint('jnt_%s_%sEyebrowCtrl' % (sSide, sName), sParent=cC.sOut, fSize=0.38 * fSliderScale) # not factoring by sliderScale because it's already scaled by it
                cC.sRefJoint = xforms.createJoint('jnt_%s_%sEyebrowCtrlRef' % (sSide, sName), sParent=cC.sPasser, fSize=0.35 * fSliderScale)
                cmds.setAttr('%s.s' % cC.sRefJoint, *cmds.getAttr('%s.s' % cC.sSlider)[0])

                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sRefJoint)


            # this needs to be repeated for the refs
            sLocalLeft = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][0].sOut),
                                                       '%s.worldInverseMatrix' % ccCtrls[s][1].sUnscaledCtrl,
                                                       sName='%s_eyebrow_leftLocalCtrl' % (sSide))
            sLocalRight = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][2].sOut),
                                                        '%s.worldInverseMatrix' % ccCtrls[s][1].sUnscaledCtrl,
                                                        sName='%s_eyebrow_rightLocalCtrl' % (sSide))

            sSum = nodes.createVectorAdditionNode([sLocalLeft, sLocalRight], sOperation='minus',
                                                  sName='%s_eyebrow_midCtrlSum' % sSide)

            sNoRotatePasser = xforms.createTransform('grp_%s_midNoRotatePasser' % sSide, sParent=sBrowsOrig, sMatch=ccCtrls[s][1].sPasser)
            sAddRotatePasser = xforms.createTransform('grp_%s_midAddRotatePasser' % sSide, sParent=sNoRotatePasser, sMatch=ccCtrls[s][1].sPasser)
            xforms.matrixParentConstraint(ccCtrls[s][1].sUnscaledCtrl, sNoRotatePasser)

            sMidAimer = cmds.createNode('transform', n='grp_%s_eyebrowMidAimer' % (sSide), p=sAddRotatePasser)
            sHalfSum = nodes.createVectorMultiplyNode(sSum, 0.5, bVectorByScalar=True,
                                                      sName='%s_eyebrow_midCtrlHalf' % (sSide))

            sAdjustTangentAttr = utils.addAttr(ccCtrls[s][1].sCtrl, ln='autoTangent', min=0.0, max=1.0, dv=1.0, k=True)
            nodes.createBlendNode(sAdjustTangentAttr, sHalfSum, cmds.getAttr(sHalfSum)[0], bVector=True, sTarget='%s.t' % sMidAimer)


            # do the same aimConstraint setup for ref part
            sLocalLeftRef = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][0].sPasser),
                                                       '%s.worldInverseMatrix' % ccCtrls[s][1].sPasser,
                                                       sName='%s_eyebrow_leftLocalCtrlRef' % (sSide))
            sLocalRightRef = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccCtrls[s][2].sPasser),
                                                        '%s.worldInverseMatrix' % ccCtrls[s][1].sPasser,
                                                        sName='%s_eyebrow_rightLocalCtrlRef' % (sSide))

            sSumRef = nodes.createVectorAdditionNode([sLocalLeftRef, sLocalRightRef], sOperation='minus',
                                                  sName='%s_eyebrow_midCtrlSum' % sSide)

            sNoRotatePasserRef = xforms.createTransform('grp_%s_midNoRotatePasser' % sSide, sParent=sBrowsOrig, sMatch=ccCtrls[s][1].sPasser)
            sAddRotatePasserRef = xforms.createTransform('grp_%s_midAddRotatePasser' % sSide, sParent=sNoRotatePasserRef, sMatch=ccCtrls[s][1].sPasser)
            xforms.matrixParentConstraint(ccCtrls[s][1].sPasser, sNoRotatePasserRef)

            sMidAimerRef = cmds.createNode('transform', n='grp_%s_eyebrowMidAimerRef' % (sSide), p=sAddRotatePasserRef)
            nodes.createVectorMultiplyNode(sSumRef, 0.5, bVectorByScalar=True,
                                                      sName='%s_brow_midCtrlHalfRef' % (sSide), sTarget='%s.t' % sMidAimerRef)


            for sAimingParent, sAimingObject, sTarget, bIsRef, bAimOut in [(ccCtrls[s][0].sCtrl, ccCtrls[s][0].sOut, ccCtrls[s][1].sCtrl, False, True),
                                                                                       (ccCtrls[s][1].sCtrl, ccCtrls[s][1].sOut, sMidAimer, False, False),
                                                                                       (ccCtrls[s][2].sCtrl, ccCtrls[s][2].sOut, ccCtrls[s][1].sCtrl, False, False),
                                                                                       (ccCtrls[s][0].sPasser, ccCtrls[s][0].sRefJoint, ccCtrls[s][1].sPasser, True, True),
                                                                                       (ccCtrls[s][1].sPasser, ccCtrls[s][1].sRefJoint, sMidAimerRef, True, False),
                                                                                       (ccCtrls[s][2].sPasser, ccCtrls[s][2].sRefJoint, ccCtrls[s][1].sPasser, True, False)]:
                if bIsRef:
                    sInverseNoRotMatrix = '%s.worldInverseMatrix' % sAimingParent
                else:
                    sNoRotCtrl = cmds.listRelatives(cmds.listRelatives(sAimingParent, p=True)[0], p=True)[0]
                    if sSide == 'r':
                        sNoRotCtrl = cmds.createNode('transform', p=sNoRotCtrl)
                        cmds.setAttr('%s.sx' % sNoRotCtrl, -1.0)

                    sDecomposeMatrix = nodes.createDecomposeMatrix('%s.worldMatrix' % sNoRotCtrl, bReturnRotate=True)
                    sNoRotMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(sAimingParent),
                                                                 xRotate=sDecomposeMatrix,
                                                                 xScale='%s.outputScale' % sDecomposeMatrix.split('.')[0])
                    sInverseNoRotMatrix = nodes.createInverseMatrix(sNoRotMatrix)

                sLocalAim = nodes.createPointByMatrixNode(nodes.getWorldPoint(sTarget), sInverseNoRotMatrix)

                fAimVector = [1,0,0] if bAimOut else [-1,0,0]
                nodes.createSimpleAimConstraint2(sLocalAim, sAimingObject, sParent=sAimingObject, bRotateUp=True,
                                                 xAimVector=fAimVector, xUpVector=[0,fSideMultipl,0], sName='ctrlAim_%s' % sAimingParent)


            # create skin joints
            print('\n\n\n')
            sUpJoints = []
            sUpRefJoints = []
            sPointOnCurves = []
            sRefPointOnCurves = []
            for j, fP in enumerate(ffParams[s]):
                sJ = 'jnt_%s_browsPOST_%03d' % (sSide, j)
                sRefG = xforms.createTransform('grp_%s_browsRefPOST_%03d' % (sSide, j), sParent=sBrowsOrig)
                ssRefGroups[s].append(sRefG)
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sRefG)
                    xforms.resetJoint(sJ)
                    cmds.setAttr('%s.radius' % sJ, fSliderScale * 0.25)
                else:
                    sJ = xforms.createJoint(sJ, fSize=fSliderScale * 0.25, sParent=sRefG)

                utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefG)

                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)

                sUp = xforms.createTransform(sName='grp_%s_browsPOSTup_%03d' % (sSide, j))
                sUpRefJ = xforms.createTransform('%s_ref' % sUp, sParent=sBrowsOrig)
                cmds.parent(sUp, sUpRefJ)

                # sSkinJoints.append(sJ)
                ssJoints[s].append(sJ)
                # sRefGroups.append(sRefG)
                sUpJoints.append(sUp)
                sUpRefJoints.append(sUpRefJ)

                # scale
                sMultipls = [nodes.createVectorMultiplyNode('%s.s' % ccCtrls[s][c].sCtrl, aaaWeights[s][c][j], bVectorByScalar=True) for c in [0,1,2]]
                nodes.createVectorAdditionNode(sMultipls, sTarget='%s.s' % sJ)


                _, sPosOnCurve = curves.createPointInfoNode(sCurves[s], fParam=fP)
                sPointOnCurves.append(sPosOnCurve)
                _, sRefPosOnCurve = curves.createPointInfoNode(sRefCurves[s], fParam=fP)
                sRefPointOnCurves.append(sRefPosOnCurve)

            for j, fP in enumerate(ffParams[s]):
                sJ = ssJoints[s][j]
                sRefG = ssRefGroups[s][j]
                sUp = sUpJoints[j]
                sUpRefJ = sUpRefJoints[j]

                # pos
                nodes.createPointByMatrixNode(sPointOnCurves[j], '%s.worldInverseMatrix' % sRefG, sTarget='%s.t' % sJ)
                cmds.connectAttr(sRefPointOnCurves[j], '%s.t' % sRefG)

                # upPos
                _, sUpPosOnCurve = curves.createPointInfoNode(sUpCurves[s], fParam=fP)
                _, sUpRefPosOnCurve = curves.createPointInfoNode(sUpRefCurves[s], fParam=fP)
                nodes.createPointByMatrixNode(sUpPosOnCurve, '%s.worldInverseMatrix' % sUpRefJ, sTarget='%s.t' % sUp)
                cmds.connectAttr(sUpRefPosOnCurve, '%s.t' % sUpRefJ)

                iAimingUpIndex = j+1 if j == 0 else j-1
                sAimingUpPoint = nodes.createPointByMatrixNode(sPointOnCurves[iAimingUpIndex], '%s.worldInverseMatrix' % ssRefGroups[s][j])
                xforms.aimConstraintSmallObjects(sUp, sJ, aimVector=[0, 0, 1], upVector=[fSideMultipl,0,0], sName='browParamAim_%03d' % j,
                                                 xUpMatrix=nodes.createComposeMatrixNode(sAimingUpPoint), bRotateUp=False)


                sRefParent = cmds.listRelatives(sRefG, p=True)[0] # there should be a better parent on the ref
                sRefAimingUpPoint = nodes.createPointByMatrixNode(sRefPointOnCurves[iAimingUpIndex], '%s.worldInverseMatrix' % sRefParent)
                xforms.aimConstraintSmallObjects(sUpRefJ, sRefG, aimVector=[0, 0, 1], upVector=[fSideMultipl,0,0], sName='browParamAimRef_%03d' % j,
                                                 xUpMatrix=nodes.createComposeMatrixNode(sRefAimingUpPoint), bRotateUp=False)




            for cC in ccCtrls[s]:
                cmds.delete(cmds.parentConstraint(cC.sJoint, cC.sRefJoint))
            cmds.skinCluster(sCurves[s], [cC.sJoint for cC in ccCtrls[s]], tsb=True)
            cmds.skinCluster(sUpCurves[s], [cC.sJoint for cC in ccCtrls[s]], tsb=True)
            cmds.skinCluster(sRefCurves[s], [cC.sRefJoint for cC in ccCtrls[s]], tsb=True)
            cmds.skinCluster(sUpRefCurves[s], [cC.sRefJoint for cC in ccCtrls[s]], tsb=True)


        createOrFixFaceZero()
        deformers.connectJointReferencesFromAttr(ssJoints[0]+ssJoints[1])

    else: # NOT bSlines
        sJoints = []
        for s,sSide in enumerate(['l','r']):
            for c,cC in enumerate(ccCtrls[s]):

                sJ = 'jnt_%s_%sPOST' % (sSide, cC.sName)
                if cmds.objExists(sJ):
                    xforms.parentJointNoTransform(sJ, cC.sCtrl)
                    xforms.resetTransform(sJ, jo=True)
                else:
                    sJ = xforms.createJoint(sJ, sParent=cC.sCtrl)

                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJ)

                # sCtrlMovingOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sCtrl, '%s.worldInverseMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0]])
                sMovingOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cmds.listRelatives(cC.sCtrl, p=True)[0],
                                                            '%s.worldInverseMatrix' % cMainCtrls[s].sCtrl,
                                                            '%s.worldMatrix' % cmds.listRelatives(cMainCtrls[s].sCtrl, p=True)[0]])

                utils.addStringAttr(sJ, deformers.kPostRefJointAttr, nodes.createInverseMatrix(sMovingOffset))
                sJoints.append(sJ)

        createOrFixFaceZero()
        deformers.connectRefsOnCurrentSkinClusters(sJoints)


    sPostAttachTransforms = [cC.sPasser for cC in (ccCtrls[0]+ccCtrls[1]+cMainCtrls)]

    # if bOrientAttach:
    #     [utils.addOffOnAttr(sT, deformers.kRotateByNeighborVerts, True) for sT in sPostAttachTransforms]
    if sSkipAttachDeformers:
        sSkipAttachDeformersString = '.'.join(sorted(sSkipAttachDeformers))
        [utils.addStringAttr(sT, kSkipAttachDeformers, str(sSkipAttachDeformersString)) for sT in sPostAttachTransforms]

    utils.data.addToList('postAttachTransforms', sPostAttachTransforms)
    utils.data.addToList('postAttachTransformMeshes', [sAttachMesh] * len(sPostAttachTransforms))

kSkipAttachDeformers = 'sSkipAttachDeformers'

@builderTools.addToBuild(iOrder=92, bDisableByDefault=True)
def blendShapifyPOST(bScale=False):
    def _cCtrlFromJoint(sJoint):
        _sParent = sJoint
        for i in range(10):
            try:
                _sParent = cmds.listRelatives(_sParent, p=True)[0]
            except Exception as e:
                raise Exception('Problem with %s, seems to be outside the hierarchy (e)' % (sJoint, e))
            if _sParent.endswith('_ctrl'):
                return _sParent

    for sSkinCluster in cmds.ls('*__POST', et='skinCluster'):
        iiEyebrowJoints = [], []
        sMesh = cmds.skinCluster(sSkinCluster, q=True, g=True)[0]
        sMesh = cmds.listRelatives(sMesh, p=True)[0]
        pMesh = patch.patchFromName(sMesh)
        aPoints = pMesh.getPoints()
        _, sInfluences, aWeights2d = pMesh.getSkinCluster(sChooseSkinCluster=sSkinCluster)
        print ('aWeights2d: ', aWeights2d.shape)
        for j,sJ in enumerate(sInfluences):
            print('sJ: ', sJ)
            if np.any(aWeights2d[:, j]):
                if 'postLips' in sJ or 'EyebrowPOST' in sJ or 'eyesPOST' in sJ:
                    sCtrl = _cCtrlFromJoint(sJ)
                    aMatrix = utils.getNumpyMatrixFromTransform(sCtrl)

                    for a in range(3):
                        sTarget = cmds.duplicate(sMesh, n='%sShape%s%s' % (sMesh, sJ.replace('_',''), ['X','Y','Z'][a]))[0]
                        aTargetPoints = np.array(aPoints)
                        aTargetPoints += aWeights2d[:,j,np.newaxis] * aMatrix[a,0:3]
                        patch.patchFromName(sTarget).setPoints(aTargetPoints)
                        dPoses = {'%s.%s' % (sCtrl, ['tx','ty','tz'][a]):1.0}
                        blendShapesPro.connectTargets(sMesh, sTarget, dPoses=dPoses, bMirror=False, fOvershootRange=[10,10], bControlRigCommands=True)
                        cmds.delete(sTarget)

                    if bScale:
                        for a in range(3):
                            sTarget = cmds.duplicate(sMesh, n='%sShape%sScale%s' % (sMesh, sJ.replace('_',''), ['X','Y','Z'][a]))[0]
                            aTargetPoints = np.array(aPoints)
                            aTargetPoints4 = utils.makePoint4Array(aTargetPoints)
                            aInvMatrix = np.linalg.inv(aMatrix)
                            aLocalTargetPoints4 = np.dot(aTargetPoints4, aInvMatrix)
                            aLocalTargetPoints4[:,a] = 0
                            aWorldTargetPoints4 = np.dot(aLocalTargetPoints4, aMatrix)
                            aWorldTargetPoints = aWorldTargetPoints4[:,0:3]
                            aTargetPoints = aTargetPoints * (1-aWeights2d[:,j,np.newaxis]) + aWorldTargetPoints * aWeights2d[:,j,np.newaxis]
                            patch.patchFromName(sTarget).setPoints(aTargetPoints)
                            dPoses = {'%s.%s' % (sCtrl, ['sx','sy','sz'][a]):[1, 0]}
                            blendShapesPro.connectTargets(sMesh, sTarget, dPoses=dPoses, bMirror=False, fOvershootRange=[10,10])
                            cmds.delete(sTarget)

                    for sA in ['rx','ry','rz','sx','sy','sz','v','ro']:
                        cmds.setAttr('%s.%s' % (sCtrl, sA), lock=True, keyable=False, channelBox=False)

                    if bScale:
                        for sA in ['sx', 'sy', 'sz']:
                            cmds.setAttr('%s.%s' % (sCtrl, sA), lock=False, channelBox=True)
                            cmds.setAttr('%s.%s' % (sCtrl, sA), keyable=True)

                if 'EyebrowPOST' in sJ:
                    iSide = utils.getSideIndex(sJ)
                    iiEyebrowJoints[iSide].append(j)


        for s,sSide in enumerate(['l','r']):
            if iiEyebrowJoints[s]:

                aBrowTransformWeights = np.zeros(len(aWeights2d), dtype='float64')
                print ('aBrowTransformWeights: ', aBrowTransformWeights.shape)
                print ('aWeights2d: ', aWeights2d.shape)
                for iJ in iiEyebrowJoints[s]:
                    aBrowTransformWeights += aWeights2d[:,iJ]

                sCtrl = ['postEyebrowParent_l_ctrl', 'postEyebrowParent_r_ctrl'][s]
                aMatrix = utils.getNumpyMatrixFromTransform(sCtrl)
                for a in range(3):
                    sTarget = cmds.duplicate(sMesh, n='%sShape%s%s' % (sMesh, sJ.replace('_', ''), ['X', 'Y', 'Z'][a]))[0]
                    aTargetPoints = np.array(aPoints)
                    aTargetPoints += aBrowTransformWeights[:,np.newaxis] * aMatrix[a, 0:3]
                    patch.patchFromName(sTarget).setPoints(aTargetPoints)
                    dPoses = {'%s.%s' % (sCtrl, ['tx', 'ty', 'tz'][a]): 1.0}

                    blendShapesPro.connectTargets(sMesh, sTarget, dPoses=dPoses, bMirror=False, fOvershootRange=[10, 10])
                    cmds.delete(sTarget)

                for sA in ['rx', 'ry', 'rz', 'sx', 'sy', 'sz', 'v', 'ro']:
                    cmds.setAttr('%s.%s' % (sCtrl, sA), lock=True, keyable=False, channelBox=False)


        cmds.delete(sSkinCluster)




def proceduralBind_zipper(iBindLipRows, fBindMultipls):
    _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='Zipper', sSkinClusterSuffix='ZIPPER')

dButtons = {}
dButtons['bind selected'] = proceduralBind_zipper



@builderTools.addToBuild(iOrder=84, dButtons=dButtons, bDisableByDefault=True)
def postZipper(sMesh=None, sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain', sLipPressMesh=None, sClosedMesh=None, iBindLipRows=[3,3], fBindMultipls=[1.0,1.0,1.0], fOvershoot=0.05):

    sMesh = utils.objFromArg(sMesh)

    if utils.data.get('bMouthJointType', sNode=utils.kFaceDataNode, xDefault=False) == True:
        report.report.addLogText('skipping because mouth rig has joint setup')
        return

    sZipperGrpOrigin = cmds.createNode('transform', n='grp_zipperOrigin') #, p=getFaceGrp())
    # fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode)
    sZipperGrpWorld = cmds.createNode('transform', n='grp_zipperWorld') #, p=getFaceGrp())
    xforms.matrixParentConstraint(sParentJoint, sZipperGrpWorld)


    # zipper
    cCornerCtrls = [ctrls5.ctrlFromName('lipsCornerLFT_ctrl'), ctrls5.ctrlFromName('lipsCornerRGT_ctrl')]
    sSealLeft = utils.addAttr(cCornerCtrls[0].sCtrl, ln='seal', at='double',  defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
    sSealRight = utils.addAttr(cCornerCtrls[1].sCtrl, ln='seal', at='double', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)

    sSealFadeLengthLeft = utils.addAttr(cCornerCtrls[0].sCtrl, ln='sealFade', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)
    sSealFadeLengthRight = utils.addAttr(cCornerCtrls[1].sCtrl, ln='sealFade', at='double', bReturnIfExists=True, defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)

    sSealLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealLeft, sSealFadeLengthLeft), sName='left_sealByFade')
    sSealRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (sSealRight, sSealFadeLengthRight), sName='right_sealByFade')

    sBpCurvesA = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]

    sZipperCurves = [cmds.duplicate(sBpCurvesA[0], n='crv_m_botZipper')[0], cmds.duplicate(sBpCurvesA[1], n='crv_m_topZipper')[0]]
    cmds.parent(sZipperCurves, sZipperGrpOrigin)

    pMesh = patch.patchFromName(sMesh)
    aMeshPoints = pMesh.getPoints()
    aClosedMeshPoints = aMeshPoints if not sClosedMesh else patch.patchFromName(sClosedMesh).getPoints()

    aHeadMatrix = np.array(cmds.getAttr('%s.worldMatrix' % sParentJoint), dtype='float64').reshape(4,4)
    aHeadMatrixInverse = np.linalg.inv(aHeadMatrix)

    aClosedMeshPointsLocal = np.dot(utils.makePoint4Array(aClosedMeshPoints), aHeadMatrixInverse)[:,0:3]
    if sLipPressMesh:
        aLipPressMeshPoints = patch.patchFromName(sLipPressMesh).getPoints()
        aLipPressPointsLocal = np.dot(utils.makePoint4Array(aLipPressMeshPoints), aHeadMatrixInverse)[:,0:3]


    ssJoints = [], []
    ssRefJoints = [], []
    aaPoints = [None, None]
    for p,sPart in enumerate(['bot','top']):
        aAllPartPoints = np.array(cmds.xform('%s.cv[*]' % sZipperCurves[p], q=True, t=True, ws=True), dtype='float64').reshape(-1,3)
        if p == 0:
            aaPoints[p] = aAllPartPoints
        else:
            aaPoints[p] = aAllPartPoints[1:-1]

        aSides, aInds = utils.convertMiddleSequenceToSides(len(aaPoints[p]))
        for j,aPoint in enumerate(aaPoints[p]):
            sRefJ = cmds.createNode('joint', n='jnt_%s_%sRefZipper_%03d' % (aSides[j], sPart, aInds[j]), p=sZipperGrpWorld)
            sJ = 'jnt_%s_%sZipper_%03d' % (aSides[j], sPart, aInds[j])
            if not cmds.objExists(sJ):
                sJ = cmds.createNode('joint', n=sJ, p=sZipperGrpWorld)
            else:
                cmds.parent(sJ, sZipperGrpWorld)
            utils.matchJointRadius(sJ, 'jnt_m_headMain', 0.2)
            utils.matchJointRadius(sRefJ, 'jnt_m_headMain', 0.5)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            ssJoints[p].append(sJ)
            ssRefJoints[p].append(sRefJ)
            cmds.setAttr('%s.v' % sRefJ, False)

    aaClosestIds = [xforms.findClosestPoints(aaPoints[0], aMeshPoints),
                    xforms.findClosestPoints(aaPoints[1], aMeshPoints)]

    aClosestIds = np.concatenate([aaClosestIds[0], aaClosestIds[1]])
    cmds.select(ssJoints[0], ssJoints[1])

    sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh
    if cmds.objExists(sSkinCluster):
        cmds.setAttr('%s.envelope' % sSkinCluster, 0.0)

    sLocs = constraints.parallelTransformAsDeformers(sMesh, aClosestIds, sParent=sZipperGrpOrigin,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint,
                                                     sDeformers=['skinCluster__%s' % sMesh])
    [cmds.setAttr('%s.localScale' % sL, 0.02, 0.02, 0.02) for sL in sLocs]

    ssLocs = sLocs[:len(aaPoints[0])], sLocs[len(aaPoints[0]):]
    for p,sPart in enumerate(['bot','top']):
        for j,sJ  in enumerate(ssJoints[p]):
            cmds.pointConstraint(ssLocs[p][j], ssRefJoints[p][j])
            cmds.delete(cmds.pointConstraint(ssLocs[p][j], ssJoints[p][j]))


    cmds.skinCluster(sZipperCurves[0], ssRefJoints[0], tsb=True)
    cmds.skinCluster(sZipperCurves[1], ssRefJoints[1], tsb=True)

    ffOppositeParams = []
    ffOppositeParams.append(curves.getParamsFromPoints(sZipperCurves[1], aaPoints[0]))
    ffOppositeParams.append(curves.getParamsFromPoints(sZipperCurves[0], aaPoints[1]))


    if sLipPressMesh:
        sLipPressAttr = utils.addAttr('mouth_ctrl', ln='lipPress', minValue=0.0, maxValue=1.0, defaultValue=0.0, k=True, bReturnIfExists=True)
    else:
        sLipPressAttr = 0.0

    sOverShoot = utils.addAttr('grp_m_mouthPasser', ln='zipperOverShoot', k=True, dv=fOvershoot)

    for p,sPart in enumerate(['bot','top']):
        aSides, aInds = utils.convertMiddleSequenceToSides(len(aaPoints[p]))

        fLeftPercs = utils.bSpline4([0,0,1,1], aValues=np.arange(len(ffOppositeParams[p])) / float(len(ffOppositeParams[p])-1))
        fRightPercs = 1.0 - fLeftPercs
        sPositionAdditions = []
        sAllLeftRightSealsClamped = []
        sBlendPlusOvershoot = nodes.createAdditionNode([0.5, sOverShoot])
        for j,sJ in enumerate(ssJoints[p]):
            cmds.setAttr('%s.jo' % sJ, 0,0,0)
            cmds.setAttr('%s.jo' % sRefJ, 0,0,0)

            deformers.connectRefsOnCurrentSkinClusters(sJ)
            sLeftRightSeals = cmds.createNode('plusMinusAverage', n='plus_%s_sumSeals_%03d' % (aSides[j], aInds[j]))

            sEndLeft = nodes.createAdditionNode([fLeftPercs[j], sSealFadeLengthLeft],
                                          sName='%s_left_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeLeft = nodes.createRangeNode(sSealLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0,
                                               sName='%s_left_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sEndRight = nodes.createAdditionNode([fRightPercs[j], sSealFadeLengthRight], sName='%s_right_sealFadeLength_%03d' % (aSides[j], aInds[j]))
            sRangeRight = nodes.createRangeNode(sSealRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='%s_right_seal_%03d' % (aSides[j], aInds[j]))
            nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

            sAllClose = nodes.createAdditionNode(['%s.output1D' % sLeftRightSeals, sLipPressAttr])
            sAllCloseClamped = nodes.createClampNode(sAllClose, 0, 1)

            _, sPosOnNode = curves.createPointInfoNode(sZipperCurves[0 if p == 1 else 1], fParam=ffOppositeParams[p][j], sName='%sSeal_%03d' % (sPart, j))
            sPosOnNodeLocal = nodes.createPointByMatrixNode(sPosOnNode, '%s.worldInverseMatrix' % sParentJoint)
            sPosOnNodeBlend = nodes.createBlendNode(sBlendPlusOvershoot, sPosOnNodeLocal, '%s.t' % ssRefJoints[p][j], bVector=True)

            sNewOffset = nodes.createVectorAdditionNode([sPosOnNodeBlend, '%s.t' % ssRefJoints[p][j]], sOperation='minus')

            sOffsetMultipls = []
            sOffsetMultipls.append(nodes.createVectorMultiplyNode(sNewOffset, sAllCloseClamped, bVectorByScalar=True))
            sAdd = nodes.createVectorAdditionNode(['%s.t' % ssRefJoints[p][j]] + sOffsetMultipls, '%s.t' % ssJoints[p][j])
            sPositionAdditions.append(sAdd.split('.')[0])
            sAllLeftRightSealsClamped.append(sAllCloseClamped)

        cCornerCtrl = ctrls5.ctrlFromName('lipsCornerLFT_ctrl')
        cmds.setAttr('%s.seal' % cCornerCtrl.sCtrl, 1.0)
        for j,sJ in enumerate(ssJoints[p]):
            aPos = np.array(cmds.getAttr('%s.t' % ssJoints[p][j])[0], dtype='float64')
            aOffset = aClosedMeshPointsLocal[aaClosestIds[p][j]] - aPos
            sMult = nodes.createVectorMultiplyNode(aOffset, sAllLeftRightSealsClamped[j], bVectorByScalar=True)
            cmds.connectAttr(sMult, '%s.input3D[2]' % sPositionAdditions[j])
        cmds.setAttr('%s.seal' % cCornerCtrl.sCtrl, 0.0)

        if sLipPressMesh:
            cmds.setAttr(sLipPressAttr, 1.0)
            for j,sJ in enumerate(ssJoints[p]):
                aPos = np.array(cmds.getAttr('%s.t' % ssJoints[p][j])[0], dtype='float64')
                aOffset = aLipPressPointsLocal[aaClosestIds[p][j]] - aPos
                sDiff = nodes.createAdditionNode([sLipPressAttr, sAllLeftRightSealsClamped[j]], sOperation='minus')
                sDiff = nodes.createClampNode(sDiff, 0, 1)
                sMult = nodes.createVectorMultiplyNode(aOffset, sDiff, bVectorByScalar=True)
                cmds.connectAttr(sMult, '%s.input3D[3]' % sPositionAdditions[j])
            cmds.setAttr(sLipPressAttr, 0.0)


    createOrFixFaceZero()


    sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh

    # fix skinCluster if it's already there from loadDeformers
    if cmds.objExists(sSkinCluster):
        sJoints = cmds.ls('jnt_?_???Zipper_???', et='joint')
        if cmds.objExists(sSkinCluster):
            cmds.setAttr('%s.envelope' % sSkinCluster, True)

        for j, sJoint in enumerate(sJoints):
            sRefJoint = sJoint.replace('Zipper', 'RefZipper')
            if not cmds.objExists(sRefJoint):
                continue

            sMatrixConnections = cmds.listConnections('%s.worldMatrix' % sJoint, p=True, t='skinCluster', s=False,
                                                      d=True)
            if not sMatrixConnections:
                continue
            sMatrixConnections = [sC for sC in sMatrixConnections if sC.startswith(sSkinCluster)]
            if not sMatrixConnections:
                continue

            iIndex = utils.indexFromName(sMatrixConnections[0])
            cmds.connectAttr('%s.worldInverseMatrix' % sRefJoint, '%s.bindPreMatrix[%d]' % (sSkinCluster, iIndex),
                             f=True)


    if sLipPressMesh:
        # sModels = utils.data.get('allBodyMeshes', sNode=utils.kFaceDataNode)
        # sSecondaryModels = [] if len(sModels) <= 1 else sModels[1:]
        blendShapesPro.connectTargets(sMesh, sLipPressMesh, dPoses={sLipPressAttr: 1.0}, bMirror=False, iInvert=2)

    cmds.parent(sZipperGrpOrigin, sZipperGrpWorld, 'modules')





@builderTools.addToBuild(iOrder=84.5, bDisableByDefault=True)
def blendShapifyPostZipper(iSampleCount=8, fJawRotationZ=-30):

    sMirrorJointAxes = utils.data.get('sMirrorJointAxes', xDefault=[]) #, xDefault=[])

    sSuffixes = utils.data.get('sImportedHeadSuffixes')
    bReturn = None
    sBpCurvesA = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]
    utils.data.store('dZipper', {'iSampleCount': iSampleCount, 'sCurve': sBpCurvesA[0]})
    blendShapesPro.createOrGetZipperSetup()

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={})
    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={})
    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={})
    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={})
    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={})
    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={})
    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={})
    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={})
    dConnectTargetLidRanges = utils.data.get('dConnectTargetLidRanges', xDefault={})
    dConnectTargetControlRigCommands = utils.data.get('dConnectTargetControlRigCommands', xDefault={})

    utils.addListKey(dConnectTargetPoses, 'zipper')
    utils.addListKey(dConnectTargetDrivers, 'zipper')
    utils.addListKey(dConnectTargetMirrors, 'zipper')
    utils.addListKey(dConnectTargetSplitRadien, 'zipper')
    utils.addListKey(dConnectTargetSplitBotTops, 'zipper')
    utils.addListKey(dConnectTargetInverts, 'zipper')
    utils.addListKey(dConnectTargetSplitAlongCurves, 'zipper')
    utils.addListKey(dConnectTargetZippers, 'zipper')
    utils.addListKey(dConnectTargetLidRanges, 'zipper')
    utils.addListKey(dConnectTargetControlRigCommands, 'zipper')

    dConnectTargetPoses['zipper'].append({})
    dConnectTargetDrivers['zipper'].append({})
    dConnectTargetMirrors['zipper'].append(False)
    dConnectTargetSplitRadien['zipper'].append(1.0)
    dConnectTargetSplitBotTops['zipper'].append(False)
    dConnectTargetInverts['zipper'].append(2)
    dConnectTargetSplitAlongCurves['zipper'].append({})
    dConnectTargetZippers['zipper'].append(True)
    dConnectTargetLidRanges['zipper'].append([])
    dConnectTargetControlRigCommands['zipper'].append(True)



    utils.addListKey(dConnectTargetPoses, 'jawOpenZipper')
    utils.addListKey(dConnectTargetDrivers, 'jawOpenZipper')
    utils.addListKey(dConnectTargetMirrors, 'jawOpenZipper')
    utils.addListKey(dConnectTargetSplitRadien, 'jawOpenZipper')
    utils.addListKey(dConnectTargetSplitBotTops, 'jawOpenZipper')
    utils.addListKey(dConnectTargetInverts, 'jawOpenZipper')
    utils.addListKey(dConnectTargetSplitAlongCurves, 'jawOpenZipper')
    utils.addListKey(dConnectTargetZippers, 'jawOpenZipper')
    utils.addListKey(dConnectTargetLidRanges, 'jawOpenZipper')
    utils.addListKey(dConnectTargetControlRigCommands, 'jawOpenZipper')

    dConnectTargetPoses['jawOpenZipper'].append({'jaw_ctrl.rz':fJawRotationZ})
    dConnectTargetDrivers['jawOpenZipper'].append({})
    dConnectTargetMirrors['jawOpenZipper'].append(False)
    dConnectTargetSplitRadien['jawOpenZipper'].append(1.0)
    dConnectTargetSplitBotTops['jawOpenZipper'].append(False)
    dConnectTargetInverts['jawOpenZipper'].append(0)
    dConnectTargetSplitAlongCurves['jawOpenZipper'].append({})
    dConnectTargetZippers['jawOpenZipper'].append(True)
    dConnectTargetLidRanges['jawOpenZipper'].append([])
    dConnectTargetControlRigCommands['jawOpenZipper'].append(True)

    utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
    utils.data.store('dConnectTargetDrivers', dConnectTargetDrivers)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)
    utils.data.store('dConnectTargetInverts', dConnectTargetInverts)
    utils.data.store('dConnectTargetSplitAlongCurves', dConnectTargetSplitAlongCurves)
    utils.data.store('dConnectTargetZippers', dConnectTargetZippers)
    utils.data.store('dConnectTargetLidRanges', dConnectTargetLidRanges)
    utils.data.store('dConnectTargetControlRigCommands', dConnectTargetControlRigCommands)


    bDeletePrevSetup = True
    def _getZipperComboName(sTargets):
        sTargets = utils.toList(sTargets)
        sAllTargets = sorted(sTargets)
        return '_'.join(sAllTargets + ['zipper'])


    # xMirrorAxis = sMirrorJointAxes[suf] if suf < len(sMirrorJointAxes) else None
    sSuffix = ''
    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sSecondaryModels = utils.data.get('sAllSecondaryModels%s' % sSuffix)

    dTargets = OrderedDict()
    dTargets[_getZipperComboName('jawOpenZipper')] = {'jaw_ctrl.rz':fJawRotationZ}
    dTargets[_getZipperComboName('lowerDown')] = {'lipsBotLFT_ctrl.ty':-1.0}
    dTargets[_getZipperComboName('upperUp')] = {'lipsTopLFT_ctrl.ty':1.0}
    dTargets[_getZipperComboName('lipStretch')] = {'lipStretchLFT_ctrl.ty':1.0}
    dTargets[_getZipperComboName('funnel')] = {'mouth_ctrl.tz':1.0}
    dTargets[_getZipperComboName(['lowerDown', 'upperUp'])] = {'lipsBotLFT_ctrl.ty':-1.0, 'lipsTopLFT_ctrl.ty':1.0}
    for sTarget, dPoses in list(dTargets.items()):
        dTargets[sTarget] = blendShapesPro._mirrorAttrsDict(dPoses)

    report.report.resetProgress(len(dTargets))

    for sComboT, dPose in list(dTargets.items()):
        report.report.addLogText('combo shape "%s"..' % sComboT, bRefresh=True, bIncrementProgress=True)
        if not cmds.objExists(sComboT):

            sMainTargets = sComboT.split('_')
            bSkip = False
            for sT in sMainTargets:
                if sT not in ['zipper', 'jawOpenZipper'] and not cmds.objExists(sT):
                    report.report.addLogText('missing main target: "%s"' % sT)
                    bSkip = True
                    # break
            if bSkip:
                continue

            dPrev = {}
            for sA,fV in list(dPose.items()):
                dPrev[sA] = cmds.getAttr(sA)
                cmds.setAttr(sA, fV)

            cmds.setAttr('lipsCornerLFT%s_ctrl.seal' % sSuffix, 1.0)
            cmds.duplicate(sModel, n=sComboT)
            cmds.setAttr('lipsCornerLFT%s_ctrl.seal' % sSuffix, 0.0)

            utils.parentToWorld(sComboT)
            cmds.setAttr('%s.v' % sComboT, False)
            for sA,fV in list(dPrev.items()):
                cmds.setAttr(sA,fV)

        bSuccess, sMessage = blendShapesPro.autoConnectComboTarget(sComboT, sModel, sSecondaryModels, bLegacyIgnoreEyeLookHoriz=False)

        report.report.addLogText(sMessage)
        if not bSuccess:
            bReturn = False

    if bDeletePrevSetup:
        for sMesh in [sModel] + sSecondaryModels:
            sSkinCluster = 'skinCluster__%s__ZIPPER' % sMesh
            if cmds.objExists(sSkinCluster):
                cmds.delete(sSkinCluster)

    cmds.setAttr('lipsCornerLFT_ctrl.seal', 0.0)

    if bDeletePrevSetup:
        for sAttr in ['lipsCornerLFT_ctrl.seal', 'lipsCornerLFT_ctrl.sealFade', 'lipsCornerRGT_ctrl.seal', 'lipsCornerRGT_ctrl.sealFade']:
            cmds.deleteAttr(sAttr)
        cmds.delete('grp_zipperOrigin', 'grp_zipperWorld')

        cmds.renameAttr('lipsCornerLFT_ctrl.sealB', 'seal')
        cmds.renameAttr('lipsCornerLFT_ctrl.sealFadeB', 'sealFade')
        cmds.renameAttr('lipsCornerRGT_ctrl.sealB', 'seal')
        cmds.renameAttr('lipsCornerRGT_ctrl.sealFadeB', 'sealFade')



    return bReturn


dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls5.exportSliderBps
@builderTools.addToBuild(iOrder=50.01, dButtons=dButtons, bDisableByDefault=True)
def eyeSpecular(ddMeshes={'eyesLookAtLFT_ctrl':{'A':[], 'B':[]}}, bMirrorToRight=True, bFirstReversesOthers=False):
    for sCtrl, dData in list(ddMeshes.items()):
        sFirstHoriz = [None, None]
        sFirstVert = [None, None]
        sReverseOthersAttr = [None, None]

        for l, sLetter in enumerate(sorted(list(dData.keys()))):
            sMeshes = dData[sLetter]
            if not sMeshes:
                continue

            sInputCtrlSide = utils.getSide(sCtrl)
            if sInputCtrlSide == 'm':
                sSides = ['m']
                bMirrors = [False]
            elif sInputCtrlSide == 'l':
                if bMirrorToRight:
                    sSides = ['l','r']
                    bMirrors = [False, True]
                else:
                    sSides = ['l']
                    bMirrors = [False]
            elif sInputCtrlSide == 'r':
                sSides = ['r']
                bMirrors = [False]

            for s,sSide in enumerate(sSides):

                fSideMultipl = -1.0 if sSide == 'r' else 1.0

                if bMirrors[s]:
                    sMeshesSide = utils.mirrorList(list(sMeshes))
                    sCtrlSide = utils.getMirrorName(sCtrl)
                else:
                    sMeshesSide = list(sMeshes)
                    sCtrlSide = sCtrl

                sEyeJoint = cmds.getAttr('%s.sEyeJoint' % sCtrlSide)
                sTransformJoint = cmds.listRelatives(sEyeJoint, p=True)[0]

                sSpecParent = 'jnt_%s_specJointParent' % sSide
                if not cmds.objExists(sSpecParent):
                    sSpecParent = xforms.createJoint(sSpecParent, sParent=sTransformJoint)

                    sEyeFollow = utils.addAttr(sCtrlSide, ln='specFollow', minValue=0, maxValue=1, k=True)
                    sSpecTwist = utils.addAttr(sCtrlSide, ln='specTwist', k=True)
                    if sSide == 'r':
                        sSpecTwist = nodes.createMultiplyNode(sSpecTwist, -1)
                    # cmds.connectAttr(sSpecTwist, '%s.rx' % sSpecParent)
                    sBlendMatrix = nodes.createBlendMatrixNode([cmds.getAttr('%s.matrix' % sEyeJoint), '%s.matrix' % sEyeJoint],
                                                               [nodes.createReverseNode(sEyeFollow), sEyeFollow])
                    sParentMatrix = nodes.createMultMatrixNode([nodes.createComposeMatrixNode(xRotate=[sSpecTwist, 0,0]),
                                                                   sBlendMatrix])
                    nodes.createDecomposeMatrix(sParentMatrix, sTargetRot='%s.r' % sSpecParent)



                    if bFirstReversesOthers:
                        sReverseOthersAttr[s] = utils.addAttr(sCtrlSide, ln='firstReversesOthers', min=0, max=1, dv=1, k=True)

                aaPoints = [patch.patchFromName(sM).getPoints() for sM in sMeshesSide]
                aPoints = np.concatenate(aaPoints)
                aMeshCenter = np.mean(aPoints, axis=0)

                sBaseJoint = xforms.createJoint(sEyeJoint.replace('Main', 'Spec%s' % sLetter), sMatch=sEyeJoint, sParent=sSpecParent)
                sJoint = sEyeJoint.replace('Main', 'SpecEnd%s' % sLetter)
                if not cmds.objExists(sJoint):
                    xforms.createJoint(sJoint, xPos = aMeshCenter)
                else:
                    cmds.setAttr('%s.t' % sJoint, *list(aMeshCenter))

                cmds.delete(cmds.aimConstraint(sJoint, sBaseJoint, wut='objectrotation', wuo=sTransformJoint, aim=[fSideMultipl,0,0]))
                cmds.makeIdentity(sBaseJoint, r=True, apply=True)
                cmds.parent(sJoint, sBaseJoint)
                cmds.setAttr('%s.jo' % sJoint, 0,0,0)
                utils.matchJointRadius([sBaseJoint, sJoint], sEyeJoint, 0.75)
                deformers.resetJointReferences(sJoint)

                for sM in sMeshesSide:
                    if not deformers.listAllDeformers(sM, sFilterTypes=['skinCluster']):
                        cmds.skinCluster(sM, sJoint, tsb=True)

                sSpecVert = utils.addAttr(sCtrlSide, ln='specVert%s' % sLetter, k=True)
                if bFirstReversesOthers:
                    if l == 0:
                        sFirstVert[s] = sSpecVert
                    else:
                        sSpecVert = nodes.createAdditionNode([sSpecVert, nodes.createMultiplyNode(sFirstVert[s], sReverseOthersAttr[s])],
                                                             sOperation='minus', sName='addFirst')
                cmds.connectAttr(sSpecVert, '%s.rz' % sBaseJoint)

                sSpecHoriz = utils.addAttr(sCtrlSide, ln='specHoriz%s' % sLetter, k=True)
                if sSide == 'r':
                    sSpecHoriz = nodes.createMultiplyNode(sSpecHoriz, -1)
                if bFirstReversesOthers:
                    if l == 0:
                        sFirstHoriz[s] = sSpecHoriz
                    else:
                        sSpecHoriz = nodes.createAdditionNode([sSpecHoriz, nodes.createMultiplyNode(sFirstHoriz[s], sReverseOthersAttr[s])],
                                                              sOperation='minus', sName='addFirst')
                cmds.connectAttr(sSpecHoriz, '%s.ry' % sBaseJoint)

                sLiftAttr = utils.addAttr(sCtrlSide, ln='specLift%s' % sLetter, k=True)
                if sSide == 'r':
                    sLiftAttr = nodes.createMultiplyNode(sLiftAttr, -1)
                nodes.createAdditionNode([cmds.getAttr('%s.tx' % sJoint), sLiftAttr], sTarget='%s.tx' % sJoint)

                sScaleAttr = utils.addAttr(sCtrlSide, ln='specScale%s' % sLetter, dv=1, k=True)
                cmds.connectAttr(sScaleAttr, '%s.sx' % sJoint)
                cmds.connectAttr(sScaleAttr, '%s.sy' % sJoint)
                cmds.connectAttr(sScaleAttr, '%s.sz' % sJoint)



def createOrFixFaceZero():
    sZero = 'jnt_m_faceZero'
    if not cmds.objExists(sZero):
        cmds.createNode('joint', n=sZero, p='modules')
    else:
        if not cmds.listRelatives(sZero, p=True):
            cmds.parent(sZero, 'modules')


dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls5.exportSliderBps
@builderTools.addToBuild(iOrder=24, dButtons=dButtons, bCanGetDuplicated=True)
def createBASELidCtrls(sParentJoint='jnt_m_headMain', sLookUpStrengthes=[1,1], sLookDownStrengthes=[1,1], bPolyCtrls=False, fInnerBlink=None, sSuffix=''):
    '''
    This creates the ctrls "blinkLFT_ctrl", "lidBotLFT_ctrl" and "lidTopLFT_ctrl"
    
    fInnerBlink is for creatures that have a membrane blink, such as birds. If it's None, it won't create a joint, but if it's a float vector such as [0,100,0], it'll create a joint
    That float vector is the default of the blink rotation.,
    IMPORTANT: this float vector will likely get overwritten in the importBlendShapeFile() function!
    '''

    for s, sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if s == 1 else 1.0
        sEyeJoints = ['jnt_%s_eye%sMain' % (sSide, sSuffix), 'jnt_%s_eye%sEnd' % (sSide, sSuffix)]
        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        # sParent = xforms.createTransform('grp_%s_eyeLid%sParent' % (sSide, sSuffix), sParent='modules',
        #                                  sMatch=sEyeJoints[0])
        # sOutwardsRotParent = cmds.createNode('transform', n='grp_%s_eyeLid%sOutwardsRotate' % (sSide, sSuffix),
        #                                      p=sParent)
        aJointPositions = xforms.getPositionArray(sEyeJoints)
        fRadius = np.linalg.norm(aJointPositions[1] - aJointPositions[0])

        if sSide == 'l':
            aBlinkPos = aJointPositions[1] + np.array([fRadius * fSideMultipl, 0, 0])

            cBlinks = ctrls5.createSliderCtrl('blink%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                              fBpPos=aBlinkPos, fRangeY=[-1, 0.5],
                                              sAttach=sParentJoint, fScale=fSliderScale, bPoly=bPolyCtrls,
                                              bExportMirrorBps=True)

            cBotLids = ctrls5.createSliderCtrl('lidBot%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                                 fRangeY=[-1, 1.0], sAttach=sParentJoint,
                                                 fScale=fSliderScale * 0.5,
                                                 fBpPos=aBlinkPos + np.array(
                                                     [fSliderScale * fSideMultipl, -1 * fSliderScale, 0]),
                                                 bPoly=bPolyCtrls, bExportMirrorBps=True)
            cTopLids = ctrls5.createSliderCtrl('lidTop%s' % sSuffix, sSide, sShape='doubleArrowSquareY',
                                                 fRangeY=[-1, 1.0], sAttach=sParentJoint,
                                                 fScale=fSliderScale * 0.5,
                                                 fBpPos=aBlinkPos + np.array(
                                                     [fSliderScale * fSideMultipl, 1 * fSliderScale, 0]),
                                                 bPoly=bPolyCtrls, bExportMirrorBps=True)

            ccExtraBlinks = [cBotLids, cTopLids]

        cAim = ctrls5.ctrlFromName('eyesLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)
        if not cAim:
            cAim = ctrls5.ctrlFromName('eyeLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)

        # drivers for shapes:
        for p,sPart in enumerate(['bot','top']):
            sBlendExtraDownShape = nodes.createRangeNode('%s.ty' % ccExtraBlinks[p][s].sCtrl, 0, -1.0, 0, 1)
            sBlendExtraUpShape = nodes.createRangeNode('%s.ty' % ccExtraBlinks[p][s].sCtrl, 0, 1.0, 0, 1)
            sBlendsFollowDownShape = nodes.createRangeNode('%s.lookVert' % cAim.sPasser, 0, -5.0, 0, 1)
            sBlendsFollowUpShape = nodes.createRangeNode('%s.lookVert' % cAim.sPasser, 0, 5, 0, 1)

            sBlendsFollowDownShape = nodes.createMultiplyNode(sBlendsFollowDownShape, sLookDownStrengthes[p])
            sBlendsFollowUpShape = nodes.createMultiplyNode(sBlendsFollowUpShape, sLookUpStrengthes[p])

            sShapeDriverDown = utils.addAttr(ccExtraBlinks[p][s].sPasser, ln='shapeDriverDown', k=True)
            sShapeDriverUp = utils.addAttr(ccExtraBlinks[p][s].sPasser, ln='shapeDriverUp', k=True)
            sAdditions = nodes.createVectorAdditionNode([[sBlendExtraDownShape, sBlendExtraUpShape, 0], [sBlendsFollowDownShape, sBlendsFollowUpShape, 0]])
            cmds.connectAttr('%sx' % sAdditions, sShapeDriverDown)
            cmds.connectAttr('%sy' % sAdditions, sShapeDriverUp)



        sBlinkLineAttr = utils.addAttr(cBlinks[s].sCtrl, ln='blinkLine', min=0.0, max=1.0, dv=0.5, k=True)
        for p,sPart in enumerate(['bot','top']):

            sBlendAttr = utils.addAttr(cBlinks[s].sPasser, ln='blendCurve%s' % utils.getFirstLetterUpperCase(sPart), k=True)

            if sPart == 'bot':
                sLookVert = nodes.createAdditionNode(['%s.shapeDriverUp' % ccExtraBlinks[0][s].sPasser, '%s.shapeDriverDown' % ccExtraBlinks[0][s].sPasser], sOperation='minus')

                nodes.createAdditionNode([nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1, sBlinkLineAttr]),
                                          sLookVert], sTarget=sBlendAttr)
            else:
                sLookVert = nodes.createAdditionNode(['%s.shapeDriverUp' % ccExtraBlinks[1][s].sPasser, '%s.shapeDriverDown' % ccExtraBlinks[1][s].sPasser], sOperation='minus')

                sMainBlink = nodes.createConditionNode('%s.ty' % cBlinks[s].sCtrl, '<', 0,
                                                       nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1, nodes.createReverseNode(sBlinkLineAttr)]),
                                                       nodes.createMultiplyArrayNode(['%s.ty' % cBlinks[s].sCtrl, -1.75])) # -1.75 means that the main blink up will be 1.75 of the extra up shape
                nodes.createAdditionNode([sMainBlink,
                                          nodes.createMultiplyNode(sLookVert, -1)],
                                          sTarget=sBlendAttr)

    if fInnerBlink != None:
        for s, sSide in enumerate(['l', 'r']):
            sEyeJoint = 'jnt_%s_eyeMain' % sSide
            cBlinks[s] = ctrls5.ctrlFromName('blink%s_ctrl' % utils.sSides3[s])
            sLidJoint = cmds.duplicate(sEyeJoint, n='jnt_%s_innerEyeLid' % sSide, po=True)[0]
            cmds.parent(sLidJoint, sEyeJoint)
            sCloseAttr = utils.addAttr(cBlinks[s].sCtrl, ln='innerBlink', min=0, max=1, k=True)
            
            sInnerBlinkRotate = utils.addAttr(cBlinks[s].sPasser, ln='innerBlinkRotate', at='double3', k=True)
            for sA,fV in zip(['X','Y','Z'], fInnerBlink):
                cmds.setAttr('%s%s' % (sInnerBlinkRotate,sA),fV)
                
            nodes.createRangeNode(sCloseAttr, 0, 1, [0,0,0], sInnerBlinkRotate, bOutRangeIsVector=True, sTarget='%s.r' % sLidJoint)


dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def fillBlinkValues(fExtraBlinkCtrlStrengthes, _uiArgs=None):
    sCtrl = 'blinkLFT_ctrl'
    sPasser = ctrls5.ctrlFromName(sCtrl).sPasser
    # sPasser = 'grp_l_blinkPasser'
    print('sPasser: ',sPasser)
    if not cmds.objExists(sPasser):
        if not cmds.objExists(sPasser):
            raise Exception('eye blink passer not found')

    _uiArgs['fBlinkValues'].setText(str([cmds.getAttr('%s.botBlink' % sPasser), cmds.getAttr('%s.topBlink' % sPasser)]))
    _uiArgs['fBlinkTwistValues'].setText(str([cmds.getAttr('%s.botBlinkTwist' % sPasser), cmds.getAttr('%s.topBlinkTwist' % sPasser)]))
    _uiArgs['fWideValues'].setText(str([cmds.getAttr('%s.botWide' % sPasser), cmds.getAttr('%s.topWide' % sPasser)]))
    _uiArgs['fFollowUps'].setText(str([cmds.getAttr('%s.followBotUp' % sPasser), cmds.getAttr('%s.followTopUp' % sPasser)]))
    _uiArgs['fFollowDowns'].setText(str([cmds.getAttr('%s.followBotDown' % sPasser), cmds.getAttr('%s.followTopDown' % sPasser)]))


    for i, sCtrl in enumerate(['lidBotLFT_ctrl', 'lidTopLFT_ctrl']):
        if cmds.objExists(sCtrl):
            cCtrl = ctrls5.ctrlFromName(sCtrl)
            sPasser = cCtrl.sPasser
            fExtraBlinkCtrlStrengthes[i] = round(cmds.getAttr('%s.fExtraBlinkCtrlStrength' % sPasser), 3)
        _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(fExtraBlinkCtrlStrengthes))

    # _uiArgs['fExtraBlinkCtrlStrengthes'].setText(str(cmds.getAttr('%s.fExtraBlinkCtrlStrengthes' % sPasser)))



kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill blink values'] = fillBlinkValues


def proceduralBind_lidSplineUndo(bSeparateSkinCluster):
    sMesh = cmds.ls(sl=True)[0].split('.')[0]
    sAllJoints = cmds.ls('jnt_?_???SkinLidSpline_???', et='joint')
    weights.moveSkinClusterWeights(sMesh, xJoints={sJ:'jnt_m_headMain' for sJ in sAllJoints})



def proceduralBind_lidSpline(iBindRows, bSeparateSkinCluster):

    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        if bSeparateSkinCluster:
            sSkinCluster = 'skinCluster__%s__LIDSPLINE' % (sMesh)
            sSkinClusterTemp = 'TEMP__skinCluster__%s__LIDSPLINE' % (sMesh)
            if cmds.objExists(sSkinClusterTemp):
                cmds.delete(sSkinClusterTemp)
            deformers.skinMesh(sMesh, ['jnt_m_faceZero'], sName=sSkinClusterTemp, bAlwaysAddDefaultWeights=True)
        else:
            sSkinCluster = 'skinCluster__%s' % (sMesh)
            sSkinClusterTemp = 'skinCluster__%s' % (sMesh)


        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()





        # fJointWeightings = np.interp(np.arange(sJoints), iIndices, [1, 0.5, ]
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()

        sAllJoints = cmds.ls('jnt_?_???SkinLidSpline_???', et='joint')
        weights.bindToClosestVertexAndExpand([pMesh], sJoints=sAllJoints,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iBindRows[0], iExpandedFadeOutLoops=iBindRows[1],
                                             sChooseSkinCluster=sSkinClusterTemp)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)
        if bSeparateSkinCluster:

            if cmds.objExists(sSkinCluster):
                pTransferTo = pMesh
                for pSel in pSelection:
                    if pSel.getName() == pMesh.getName():
                        pTransferTo = pSel
                        break

                weights.transferSkinCluster([pTransferTo], sFrom=sSkinClusterTemp, sChooseSkinCluster=sSkinCluster, iMode=weights.TransferMode.vertexIndex)
                cmds.delete(sSkinClusterTemp)
            else:
                cmds.rename(sSkinClusterTemp, sSkinCluster)


            cmds.setAttr('%s.skinningMethod' % sSkinCluster, 1)

            deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)


kEyeSplinesPostBpGroupName = '_grp_m_eyeSplinesBp'
kEyeSplinesPostBpFileName = 'faceBlueprintsEyeSplines.ma'




def _generateLidCorrective(sModel, sParts):
    print ('sModel: ', sModel)
    if sModel:
        sModel = utils.toList(sModel)[0]
    else:
        raise Exception('no model given')

    sSecondaryMeshes = [sM for sM in cmds.ls(sl=True) if sM != sModel]

    cBlink = ctrls5.ctrlFromName('blinkLFT_ctrl')
    iBotTops = [int(cmds.getAttr('%s.blendCurveBot' % cBlink.sPasser) * 100),
                -int(cmds.getAttr('%s.blendCurveTop' % cBlink.sPasser) * 100)]
    sNewMeshes = []

    sStringSplits = ['','']
    for p,sPart in enumerate(['bot','top']):
        if sPart.upper() in sParts.upper():
            iValue = iBotTops[p]
            sStringSplits[p] = '%03d' % iValue if iValue > 0 else 'n%03d' % -iValue
    sString = kSplineLideCorrectiveSep.join(sStringSplits)

    for i, sM in enumerate([sModel] + sSecondaryMeshes):
        sNewMesh = '%s%s%s' % (kSplineLidCorrectivePrefix, kSplineLideCorrectiveSep, sString)

        if i > 0:
            sNewMesh = '%s__%s' % (sM, sNewMesh)

        if not cmds.objExists(sNewMesh):
            cmds.duplicate(sM, n=sNewMesh)
            print ('sNewMesh: ', sNewMesh)
            utils.parentToWorld(sNewMesh)
        sNewMeshes.append(sNewMesh)

    cmds.select(sNewMeshes)


def generateLidCorrectiveBot(sModel):
    _generateLidCorrective(sModel, 'bot')

def generateLidCorrectiveBotTop(sModel):
    _generateLidCorrective(sModel, 'botTop')

def generateLidCorrectiveTop(sModel):
    _generateLidCorrective(sModel, 'top')


#EXCLUDE START LIDSPLINES

dButtons = OrderedDict()
dButtons['create Left Curve and Locators'] = lambda: createBothBpCurves('bpCurve_l_lidSplines', kEyeSplinesPostBpGroupName,
                                                                        fDirection=(1, 0, 0))
dButtons['create Left Curve and Locators'].dSideButtons = {
    '?': [['Select vertices and click button.', 'eyelidVertices.jpg'],
          ['Locators indicate separation points between bottom and top eyelid. ' \
           'Adjust if needed', 'eyelidCurvesLocators.jpg']]}
dButtons['== BIND =='] = {'bind to joints on selected Mesh': proceduralBind_lidSpline, 'transfer back to jnt_m_headMain on selected Mesh':proceduralBind_lidSplineUndo}
dButtons['- Export Eye Splines BPs -'] = lambda: exportBps(kEyeSplinesPostBpFileName, kEyeSplinesPostBpGroupName)

dButtons['Generate Lid Corrective from selected'] = {'botTop':generateLidCorrectiveBotTop,
                                                     'bot':generateLidCorrectiveBot,
                                                     'top': generateLidCorrectiveTop}


@builderTools.addToBuild(iOrder=24.4, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def createSplineLidSetupSQUASHED(sModel='', sLeftMeshes=[], sRightMeshes=[], bLattice=True, fLivePole=0.5, fDefaultBlinkLine=0.5, fDefaultOverShoot=1.025, fMidPercs=[0.25, 0.5, 0.75], fWidenFactors=[0.5,0.5],
                                 bPolyCtrls=False, sParentJoint='jnt_m_headMain', iBindRows=[2,3], bSeparateSkinCluster=False):
    '''
    fLivePole: if 1.0, the joints orientations are aligning to the curve
    '''
    if not len(sLeftMeshes) and not len(sRightMeshes):
        raise Exception('need to specify sLeftMeshes and sRightMeshes')

    ssMeshes = [sLeftMeshes, sRightMeshes]
    _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bLattice)
    createSplineLidSetup(sModel=sModel, fMidPercs=fMidPercs, bPolyCtrls=bPolyCtrls, fLivePole=fLivePole, fDefaultBlinkLine=fDefaultBlinkLine, bSeparateSkinCluster=bSeparateSkinCluster,
                         fDefaultOverShoot=fDefaultOverShoot, sParentJoint=sParentJoint, fWidenFactors=fWidenFactors, _bSquashed=True)


# to do: ctrl orientations are not following latticed movement
@builderTools.addToBuild(iOrder=24.3, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def createSplineLidSetup(sModel='', fMidPercs=[0.25, 0.5, 0.75], fLivePole=0.5, fDefaultBlinkLine=0.5,
                         sParentJoint='jnt_m_headMain', iBindRows=[2,3], fWidenFactors=[0.5,0.5], fDefaultOverShoot=1.025, bSeparateSkinCluster=False, bLidsCanPushOut=True, _bSquashed=False):
    '''
    fLivePole: if 1.0, the joints orientations are aligning to the curve
    
    Adjusting wide shapes: on running the function, he creates curve_?_*LidSplineWideTarget* curves inside the blueprint group. \
    Simply adjust those and export blueprints. If right side is not there, it'll get mirrored automatically
    '''

    sModel = utils.objFromArg(sModel)

    sGrp = cmds.createNode('transform', n='grp_eyeSplines', p='modules')
    createOrFixFaceZero()

    # if _bSquashed:
    #     sNurbsSpheres = ['nurbs_l_eyeRigSphere', 'nurbs_r_eyeRigSphere']

    for sCrv in ['bpCurve_l_lidSplines', 'bpCurve_r_lidSplines']:
        curves.mirrorIfNotExists(sCrv)

    for sLoc in ['locA_l_lidSplines', 'locB_l_lidSplines', 'locA_r_lidSplines', 'locB_r_lidSplines']:
        xforms.mirrorIfNotExists(sLoc)
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'faceTweakerCtrlVis', bDefaultValue=True, bReturnIfExists=True)

    ssCurves = []
    ssCurves.append(
        curves.separateCurveUsingSeparationLocs('bpCurve_l_lidSplines', 'locA_l_lidSplines', 'locB_l_lidSplines', 'bpCurve_l_botLidSpline',
                                                'bpCurve_l_topLidSpline'))
    ssCurves.append(
        curves.separateCurveUsingSeparationLocs('bpCurve_r_lidSplines', 'locA_r_lidSplines', 'locB_r_lidSplines', 'bpCurve_r_botLidSpline',
                                                'bpCurve_r_topLidSpline'))

    # fSliderScale = curves.getLength(ssCurves[0][0])

    cccBotTopCtrls = [[], []], [[], []]
    ccCornerCtrls = [[], []]
    ccEyeCtrls = [[], []]
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeEnd'], ['jnt_r_eyeMain', 'jnt_r_eyeEnd']]

    sEyeJoints = ['jnt_l_eyeMain', 'jnt_r_eyeMain']
    # sssCtrlJoints = [[], []], [[], []]
    # sNurbsSpheres = ['nurbs_l_eyeRigSphere', 'nurbs_r_eyeRigSphere']
    sSuffix = ''

    for s, sSide in enumerate(['l', 'r']):

        sParent = xforms.createJoint('jnt_%s_eyeLidSplineParent' % sSide, sParent=sParentJoint, sMatch=ssEyeJoints[s][0], fSize=0.5  )
        utils.matchJointRadius(sParent, sEyeJoints[s], 1.15)

        cmds.setAttr('%s.segmentScaleCompensate' % sParent, False)

        fSideMultipl = -1.0 if sSide == 'r' else 1.0


        aJointPositions = xforms.getPositionArray(ssEyeJoints[s])
        fRadius = np.linalg.norm(aJointPositions[1]-aJointPositions[0])
        fSliderScale = fRadius * 0.5

        # cEyeCtrl = ctrls5.ctrlFromName('eye%s_ctrl' % utils.sSides3[s])
        cEyeTransform = ctrls5.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])
        cBlink = ctrls5.ctrlFromName('blink%s%s_ctrl' % (sSuffix, utils.sSides3[s]))
        cExtraBlinks = [ctrls5.ctrlFromName('lidBot%s%s_ctrl' % (sSuffix, utils.sSides3[s])),
                        ctrls5.ctrlFromName('lidTop%s%s_ctrl' % (sSuffix, utils.sSides3[s]))]
        cAim = ctrls5.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s])
        sEyeTransformJoint = 'jnt_%s_eyeTransform' % sSide

        sBlinkLineAttr = '%s.blinkLine' % cBlink.sCtrl
        cmds.setAttr(sBlinkLineAttr, fDefaultBlinkLine)

        if bSeparateSkinCluster:
            sEyeTransformJointLive = cmds.duplicate(sEyeTransformJoint, n='jnt_%s_eyeTransformLive' % sSide, po=True)[0]
            cmds.parent(sEyeTransformJointLive, sEyeTransformJoint)
            fLocalEyeTransform = nodes.createMultMatrixNode( ['%s.worldMatrix' % sEyeTransformJointLive, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
            sEyeTransformInverseRef = nodes.createInverseMatrix(nodes.createMultMatrixNode([fLocalEyeTransform, '%s.worldMatrix' % sParentJoint]))
            utils.addStringAttr(sEyeTransformJointLive, deformers.kPostRefJointAttr, sEyeTransformInverseRef)

        sTransformJoint = 'jnt_%s_eyeTransform' % sSide
        sTransformJointRotMatrix = nodes.getRotationMatrix('%s.worldMatrix' % sTransformJoint)
        sTransformJointRotInverseMatrix = nodes.createInverseMatrix(sTransformJointRotMatrix)


        ffBlinkPoses = [('%s.ty' % cExtraBlinks[0].sCtrl, 1.0), ('%s.ty' % cExtraBlinks[1].sCtrl, -1.0)]
        sStartCurves = []
        if _bSquashed:
            ssLattices = utils.data.get('ssEyeLattices')
            for p,sPart in enumerate(['bot','top']):
                sTempDupl = cmds.duplicate(ssCurves[s][p], n='tempDuplCurve')[0]
                sTempLattice = deformers.applyLattice(ssLattices[s], ssCurves[s][p])
                cmds.setAttr('%s.outsideLattice' % sTempLattice, 1)
                sInvert = geometry.invertShapeDeformers(sTempDupl, ssCurves[s][p], sInvertName='curve_%s_%sInverted' % (sSide,sPart))
                sStartCurves.append(sInvert)
                deformers.disconnectLattice(sTempLattice)
                cmds.delete(sTempLattice)
                cmds.delete(sTempDupl)
            cmds.parent(sStartCurves, sGrp)
        else:
            sStartCurves = ssCurves[s]

        aaPoints = [patch.patchFromName(sStartCurves[0]).getPoints(),
                    patch.patchFromName(sStartCurves[1]).getPoints()]
        aaLocalPoints = [np.dot(utils.makePoint4Array(aaPoints[0]), np.linalg.inv(utils.getNumpyMatrixFromTransform(cEyeTransform.sOut)))[:,0:3],
                         np.dot(utils.makePoint4Array(aaPoints[1]), np.linalg.inv(utils.getNumpyMatrixFromTransform(cEyeTransform.sOut)))[:, 0:3]]
        iBiggerCvCount = max(len(aaPoints[0]), len(aaPoints[1]))


        sTransformGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransform' % sSide, p=sGrp)
        sOriginTransformGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransformOrigin' % sSide, p=sGrp)
        sCtrlGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesCtrls' % sSide, p='ctrls')
        xforms.matrixParentConstraint(sEyeTransformJoint, sTransformGrp)
        xforms.matrixParentConstraint(sEyeTransformJoint, sOriginTransformGrp, mo=True)
        xforms.matrixParentConstraint(cEyeTransform.sOut, sCtrlGrp)



        sTransformRefGrp = cmds.createNode('transform', n='grp_%s_eyeSplinesTransformRef' % sSide, p=sGrp)
        cmds.xform(sTransformRefGrp, m=cmds.xform(sTransformGrp, q=True, m=True))

        sTempDuplCurves = [cmds.duplicate(sStartCurves[0], n='curve_%s_tempDuplBot' % sSide)[0],
                          cmds.duplicate(sStartCurves[1], n='curve_%s_tempDuplBot' % sSide)[0]]

        cmds.parent(sTempDuplCurves, sOriginTransformGrp)

        sMaxStaticCurves = [curves.rebuildWithCvCount(sTempDuplCurves[0], iCvCount=iBiggerCvCount, iDegree=2, sNewName='curve_%s_lidSplineBot_static' % sSide),
                            curves.rebuildWithCvCount(sTempDuplCurves[1], iCvCount=iBiggerCvCount, iDegree=2, sNewName='curve_%s_lidSplineTop_static' % sSide)]
        sMaxBlendingCurves = [cmds.duplicate(sMaxStaticCurves[0], n='curve_%s_lidSplineMaxBlendingBot' % sSide)[0],
                              cmds.duplicate(sMaxStaticCurves[1], n='curve_%s_lidSplineMaxBlendingTop' % sSide)[0]]
        aaMaxPoints = [patch.patchFromName(sMaxStaticCurves[0]).getPoints(),
                       patch.patchFromName(sMaxStaticCurves[1]).getPoints()]

        sBlendingCurves = [cmds.curve(p=aaPoints[0], d=2, n='curve_%s_lidSplineBlendingBot' % sSide),
                            cmds.curve(p=aaPoints[1], d=2, n='curve_%s_lidSplineBlendingTop' % sSide)]
        curves.fixShapeName(sBlendingCurves)
        cmds.parent(sBlendingCurves, sGrp)
        sCtrlBlendingCurves = [cmds.duplicate(sBlendingCurves[0], n='curve_%s_lidSplineBlendingCtrlsBot' % sSide)[0],
                                cmds.duplicate(sBlendingCurves[1], n='curve_%s_lidSplineBlendingCtrlsTop' % sSide)[0]]


        sBlink = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0,-1,0,1)
        # sLookVert = '%s.lookVert' % cAim.sPasser
        # sBlendingTargetAttrs = []


        ssWideTargetCurves = [None, None]
        for p,sPart in enumerate(['bot','top']):
            ssWideTargetCurves[p] = ['curve_%s_%sLidSplineWideTarget' % (sSide,sPart), 'curve_%s_%sLidSplineWideTargetOther' % (sSide,sPart)]
            for pp,sCurve in enumerate(ssWideTargetCurves[p]):
                if not cmds.objExists(sCurve):
                    sMirrorCurve = utils.getMirrorName(sCurve)
                    if cmds.objExists(sMirrorCurve):
                        aPoints = patch.patchFromName(sMirrorCurve).getPoints()
                        aPoints[:, 0] *= -1.0
                    else:
                        if pp == 0:
                            aPoints = aaMaxPoints[p] - (aaMaxPoints[1-p]-aaMaxPoints[p]) * fWidenFactors[p]
                        else:
                            aPoints = aaMaxPoints[1-p]
                    cmds.curve(p=aPoints, d=1, n=sCurve)

                utils.parentTo(sCurve, kEyeSplinesPostBpGroupName)

        sOverShootAttr = utils.addAttr(cBlink.sPasser, ln='overShootOnBlinkFactor', dv=fDefaultOverShoot, k=True)

        sBlendingTargetAttrs = ['%s.blendCurveBot' % cBlink.sPasser, '%s.blendCurveTop' % cBlink.sPasser]

        for p,sPart in enumerate(['bot','top']):

            sTargetAttrs = blendShapesPro.addTargets(sMaxBlendingCurves[p], [sMaxStaticCurves[1-p], ssWideTargetCurves[p][0]])
            sOtherTargetAttr = blendShapesPro.addTargets(sMaxBlendingCurves[1-p], [ssWideTargetCurves[p][1]])[0]

            nodes.createConditionNode(sBlendingTargetAttrs[p], '>=', 0, nodes.createMultiplyNode(sBlendingTargetAttrs[p], sOverShootAttr), 0, sTarget=sTargetAttrs[0])
            nodes.createConditionNode(sBlendingTargetAttrs[p], '<', 0, nodes.createMultiplyNode(sBlendingTargetAttrs[p], -1), 0, sTarget=[sTargetAttrs[1], sOtherTargetAttr])


        ffCtrlParams = [curves.getParamsFromPercs(sBlendingCurves[0], fMidPercs),
                        curves.getParamsFromPercs(sBlendingCurves[1], fMidPercs)]
        # ctrls - bottom tops
        fCtrlSize = len(ssCurves[0][p]) * 0.02
        for p, sPart in enumerate(['bot', 'top']):
            fCtrlParams = ffCtrlParams[p]
            # aTangents = curves.getTangentsFromParams(sBlendingCurves[p], fCtrlParams)
            aCtrlPoints = curves.getPointsFromParams(sBlendingCurves[p], fCtrlParams)
            for c, fP in enumerate(fCtrlParams):
                if _bSquashed:
                    cC = ctrls5.create(sName='eyeSplineAttach%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide, iIndex=c,
                                       sParent=sTransformGrp,
                                       fSliderScale=fSliderScale, bIsNoCtrl=True,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])
                    cC.cC = ctrls5.create(sName='eyeSpline%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide, iIndex=c,
                                       sParent=sCtrlGrp, iColorIndex=2,
                                       fSliderScale=fSliderScale,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])

                    cC.cAnim = cC.cC
                    for sA in ['t','r','s']:
                        cmds.connectAttr('%s.%s' % (cC.cC.sCtrl,sA), '%s.%s' % (cC.sCtrl,sA))
                else:
                    cC = ctrls5.create(sName='eyeSpline%s' % utils.getFirstLetterUpperCase(sPart), sSide=sSide, iIndex=c,
                                       sParent=sCtrlGrp, iColorIndex=2,
                                       fSliderScale=fSliderScale,
                                       sAttrs=['t', 'r', 's'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c])
                    cC.cAnim = cC

                cmds.connectAttr(sCtrlVis, '%s.v' % cC.cAnim.sPasser)

                cC.sJoint = cmds.createNode('joint', n='jnt_%s_%sCtrl_%03d' % (sSide, sPart, c), p=cC.sOut)
                utils.matchJointRadius(cC.sJoint, sEyeJoints[s], 0.5)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                cccBotTopCtrls[s][p].append(cC)
                ccEyeCtrls[s].append(cC)

        # ctrls - corners
        fCtrlParams = curves.getParamsFromPercs(sStartCurves[0], [0, 1])
        aCtrlPoints = curves.getPointsFromParams(sStartCurves[0], fCtrlParams)
        for c, fP, sN in zip([0, 1], fCtrlParams, ['cornerIn', 'cornerOut']):
            sName = 'eyeSpline%s' % (utils.getFirstLetterUpperCase(sN))

            if _bSquashed:
                cC = ctrls5.create(sName='%sAttach' % sName, sSide=sSide, sParent=sTransformGrp,
                                   sMatch='jnt_%s_eyeMain' % sSide, bIsNoCtrl=True,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cC = ctrls5.create(sName=sName, sSide=sSide, sParent=sCtrlGrp, iColorIndex=2,
                                   sMatch='jnt_%s_eyeMain' % sSide,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cAnim = cC.cC

                for sA in ['t', 'r', 's']:
                    cmds.connectAttr('%s.%s' % (cC.cC.sCtrl, sA), '%s.%s' % (cC.sCtrl, sA))

            else:
                cC = ctrls5.create(sName=sName, sSide=sSide, sParent=sCtrlGrp, iColorIndex=2,
                                   sMatch='jnt_%s_eyeMain' % sSide,
                                   sAttrs=['t', 'r'], fSize=fCtrlSize, sShape='cube', fMatchPos=aCtrlPoints[c],
                                   fSliderScale=fSliderScale)
                cC.cAnim = cC


            if c == 0:
                aPoints = xforms.getPositionArray(
                    [cccBotTopCtrls[s][0][0].sCtrl, cccBotTopCtrls[s][1][0].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0] + aPoints[1]) * 0.5 - aPoints[2]
            else:
                aPoints = xforms.getPositionArray(
                    [cccBotTopCtrls[s][0][-1].sCtrl, cccBotTopCtrls[s][1][-1].sCtrl, cC.sCtrl])
                aTangent = (aPoints[0] + aPoints[1]) * 0.5 - aPoints[2]
                aTangent *= -1

            xforms.orientThreePoints(cC.sPasser, sEyeJoints[s], aTangent, fAimVector=[0, 0, -fSideMultipl],
                                     fUpVector=[fSideMultipl, 0, 0])
            if _bSquashed:
                cmds.delete(cmds.parentConstraint(cC.sPasser, cC.cC.sPasser))
            cC.sJoint = cmds.createNode('joint', n='jnt_%s_%sCtrlCorner_%03d' % (sSide, sPart, c), p=cC.sOut)
            utils.matchJointRadius(cC.sJoint, sEyeJoints[s], 0.5)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
            utils.addStringAttr(cC.sJoint, deformers.kPostRefJointAttr, cC.sSlider)

            ccCornerCtrls[s].append(cC)
            ccEyeCtrls[s].append(cC)



        for cC in ccCornerCtrls[s] + utils.flattenedList(cccBotTopCtrls[s]):
            utils.addStringAttr(cC.cAnim.appendOffsetGroup('blendshape', bBelowPasser=True, bMatchParentTransform=True),
                                'attachToLidBlendShapes', sModel)
            utils.addStringAttr(cC.sJoint, deformers.kPostRefJointAttr, cC.sPasser)




        # push out sJoints, and deform sBlendingCurves/sCtrlBlendingCurves. To do: calculate in transformGrp's space, so the the joint gets rotation (for the offset between joint and cvs)
        for p,sPart in enumerate(['bot','top']):
            fParams = curves.getParamsFromPoints(sMaxBlendingCurves[p], aaPoints[p])
            sJoints = []
            for j,fParam in enumerate(fParams):
                sInfoNode, sInfoPos = curves.createPointInfoNode(sMaxBlendingCurves[p], fParam=fParams[j], sName='eyeSpline_%s_%sPushOutSpline_%03d' % (sSide,sPart,j))
                sJ = cmds.createNode('joint', n='jnt_%s_%sPushOutSpline_%03d' % (sSide, sPart, j), p=sGrp)
                utils.matchJointRadius(sJ, sEyeJoints[s], 0.4)
                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)
                sLength = nodes.createDistanceNode(sLocalPoint, [0, 0, 0])
                sFactor = nodes.createMultiplyNode(cmds.getAttr(sLength), sLength, sOperation='divide', sName='eyeSpline_%s_%sFactor_%03d' % (sSide,sPart,j))
                sFactor = nodes.createConditionNode(sFactor, '>', 1.0, sFactor, 1.0, sName='eyeSpline_%s_%sFactor_%03d' % (sSide,sPart,j))
                sScaledLocalPoint = nodes.createVectorMultiplyNode(sLocalPoint, sFactor, bVectorByScalar=True)
                sWorldPoint = nodes.createPointByMatrixNode(sScaledLocalPoint, '%s.worldMatrix' % cEyeTransform.sOut)
                cmds.connectAttr(sWorldPoint, '%s.t' % sJ)
                # constraints.pointAndAimConstraint(sJ, sWorldPoint, nodes.getWorldPoint(cEyeTransform.sOut),
                #                                   nodes.createVectorAdditionNode([sWorldPoint, '%s.tangent' % sInfoNode]),
                #                                   aim=[0, 0, -1], up=[1, 0, 0])
                sJoints.append(sJ)

            cmds.skinCluster(sBlendingCurves[p], sJoints, tsb=True)
            cmds.skinCluster(sCtrlBlendingCurves[p], sJoints, tsb=True)

        # positions on sBlendingCurves
        ssCurvePositions = [], []
        ffParams = []
        ssSkinNodes = [], []
        for p,sPart in enumerate(['bot','top']):
            fParams = curves.getParamsFromPoints(sBlendingCurves[p], aaPoints[p])
            for j,fParam in enumerate(fParams):
                # if j == 0:
                #     ssCurvePositions[p].append(nodes.getWorldPoint(ccCornerCtrls[s][0].sOut))
                # elif j == len(fParams)-1:
                #     ssCurvePositions[p].append(nodes.getWorldPoint(ccCornerCtrls[s][1].sOut))
                # else:
                sNode, sPos = curves.createPointInfoNode(sBlendingCurves[p], fParam=fParams[j])
                ssCurvePositions[p].append(sPos)
                ssSkinNodes[p].append(sNode)
            ffParams.append(fParams)

        sLivePoleAttr = utils.addAttr(cBlink.sPasser, ln='livePole', min=0, max=1, dv=fLivePole, k=True)

        sCombinedCurves = []
        for p,sPart in enumerate(['bot','top']):
            sEvenTangents = []
            sEvenJoints = []

            # create even joints and attach them
            for j,fParam in enumerate(ffParams[p]):
                if p == 0 and j in [0,len(ffParams[p])-1]:
                    sEvenTangents.append(None)
                    continue
                sJ = cmds.createNode('joint', n='jnt_%s_%sEvenLidSpline_%03d' % (sSide, sPart, j), p=sTransformGrp)
                utils.matchJointRadius(sJ, sEyeJoints[s], 0.36)

                sEvenJoints.append(sJ)
                sInfoPos = ssCurvePositions[p][j]

                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)
                sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0], bConnectJointOrient=False)
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)

                jUp = j+1 if j == 0 else j-1
                sWorldTangent = nodes.createVectorAdditionNode([ssCurvePositions[p][jUp], ssCurvePositions[p][j]], sOperation='minus')

                sTangent = nodes.createPointByMatrixNode(sWorldTangent,
                                                        sTransformJointRotInverseMatrix)

                sTangent = nodes.createBlendNode(sLivePoleAttr, sTangent, cmds.getAttr(sTangent)[0], bVector=True)
                sEvenTangents.append(sTangent)
                cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr(sLocalPoint, '%s.t' % sJ)


            # attach ctrls
            cCtrlCurveNodes = []
            for c,cC in enumerate(cccBotTopCtrls[s][p]):
                sNode, sInfoPos = curves.createPointInfoNode(sBlendingCurves[p], fParam=ffCtrlParams[p][c])
                nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut, sTarget='%s.t' % cC.sPasser)
                cCtrlCurveNodes.append(sNode)
                sAimConstraint = constraints.aimConstraintEmpty(cC.sPasser, aim=[0, 0, -1], up=[1, 0, 0])
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sTransformJointRotInverseMatrix)
                cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)

                if _bSquashed:
                    sInfoNodeSquashed, sInfoPos = curves.createPointInfoNode(sCtrlBlendingCurves[p])#, fParam=ffCtrlParams[p][c])
                    cmds.connectAttr('%s.parameter' % sNode, '%s.parameter' % sInfoNodeSquashed)
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  sTarget='%s.t' % cC.cC.sPasser)
                    sAimConstraint = constraints.aimConstraintEmpty(cC.cC.sPasser, aim=[0, 0, -1], up=[1, 0, 0])
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNodeSquashed, sTransformJointRotInverseMatrix)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)

            # attach corner ctrls
            if p == 0:
                for c,cC in enumerate(ccCornerCtrls[s]):
                    sOffset = xforms.createTransform('grp_%s_eyeLidCtrlConstraint_%d' % (sSide,c), sMatch=cC.sPasser, sParent=sTransformGrp)
                    sInfoNodeSquashed, sInfoPos = curves.createPointInfoNode(sCtrlBlendingCurves[p],
                                                                             fParam=0 if c == 0 else curves.getParamLength(sCtrlBlendingCurves[p]))
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut,
                                                  sTarget='%s.t' % sOffset)
                    sAimConstraint = constraints.aimConstraintEmpty(sOffset, aim=[0, 0, -1], up=[1, 0, 0])
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNodeSquashed, sTransformJointRotInverseMatrix)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                    if _bSquashed:
                        xforms.matrixParentConstraint(sOffset, cC.cC.sPasser, mo=True)



            sCombinedCurve = cmds.duplicate(sBlendingCurves[p], n='curve_%s_%sCombined' % (sSide, sPart))[0]
            cmds.skinCluster(sCombinedCurve, sEvenJoints, tsb=True)
            sCombinedCurves.append(sCombinedCurve)
            # cmds.blendShape(sBlendingCurves[p], sCombinedCurve, w=[0,1])



            # create and attach skin joints
            sSphericalJoints = []
            sSkinJoints = []
            for j, fParam in enumerate(ffParams[p]):
                if p == 0 and j in [0, len(ffParams[p]) - 1]:
                    continue
                if _bSquashed:
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSphericalLidSpline_%03d' % (sSide, sPart, j),
                                         p=sTransformGrp)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.30)
                    sSphericalJoints.append(sJ)
                else:
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSkinLidSpline_%03d' % (sSide, sPart, j),
                                         p=sTransformJoint)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.30)
                    sSkinJoints.append(sJ)

                _, sInfoPos = curves.createPointInfoNode(sCombinedCurves[p], fParam=ffParams[p][j])

                sLocalPoint = nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % cEyeTransform.sOut)

                # push out again
                sLength = nodes.createDistanceNode(sLocalPoint, [0, 0, 0])
                sFactor = nodes.createMultiplyNode(cmds.getAttr(sLength), sLength, sOperation='divide')

                # this is to be able to push the joints away from the eyeball. Maybe put it back in future..?
                if bLidsCanPushOut:
                    sFactor = nodes.createConditionNode(sFactor, '>', 1.0, sFactor, 1.0)
                sLocalPoint = nodes.createVectorMultiplyNode(sLocalPoint, sFactor, bVectorByScalar=True)

                aLocalOffset = aaLocalPoints[p][j] - np.array(cmds.getAttr(sLocalPoint)[0], dtype='float64')
                sLocalPoint = nodes.createVectorAdditionNode([sLocalPoint, aLocalOffset])

                sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0],
                                                                bConnectJointOrient=False)
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr('jnt_m_faceZero.t', '%s.target[0].targetTranslate' % sAimConstraint)
                cmds.connectAttr(sEvenTangents[j], '%s.worldUpVector' % sAimConstraint)

                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                cmds.connectAttr(sLocalPoint, '%s.t' % sJ)


            # maintain percs with driven keys
            fDrivenParams = [-0.5, 0.0, 0.5, 1.0]
            for sInfoNodes, sCurve in [(ssSkinNodes[p], sBlendingCurves[p]),
                                       (cCtrlCurveNodes, sBlendingCurves[p])]:
                ffDrivenValues = []
                fParams = [cmds.getAttr('%s.parameter' % sN) for sN in sInfoNodes]
                fPercs = curves.getPercsFromParams(sCurve, fParams)

                for i,fV in enumerate(fDrivenParams):
                    cmds.setAttr(ffBlinkPoses[p][0], ffBlinkPoses[p][1] * fV)
                    ffDrivenValues.append(curves.getParamsFromPercs(sCurve, fPercs))
                cmds.setAttr(ffBlinkPoses[p][0], 0)

                for j,sN in enumerate(sInfoNodes):
                    nodes.disconnectAttr('%s.parameter' % sN)

                    fDrivenValues = [ffDrivenValues[i][j] for i in range(len(fDrivenParams))]
                    nodes.setDrivenKey(sBlendingTargetAttrs[p], fDrivenParams, '%s.parameter' % sN, fDrivenValues)


            # lattice curve
            if _bSquashed:
                sLatticeCurve = cmds.curve(p=aaPoints[p], d=1, n='curve_%s_%sLattice' % (sSide,sPart))

                aTransformMatrix = utils.getNumpyMatrixFromTransform(sTransformGrp)
                aPointsLocal = np.dot(utils.makePoint4Array(aaPoints[p]), np.linalg.inv(aTransformMatrix))[:,0:3]
                aPointsLocal *= 0.95
                aUpPoints = np.dot(utils.makePoint4Array(aPointsLocal), aTransformMatrix)[:,0:3]
                sLatticeUpCurve = cmds.curve(p=aUpPoints, d=1, n='curve_%s_%sUpLattice' % (sSide,sPart))
                cmds.parent(sLatticeCurve, sLatticeUpCurve, sGrp)
                fParams = curves.getParamsFromTransforms(sLatticeCurve, sSphericalJoints)
                cmds.skinCluster(sLatticeCurve, sSphericalJoints, tsb=True)
                cmds.skinCluster(sLatticeUpCurve, sSphericalJoints, tsb=True)

                deformers.applyLattice(ssLattices[s], sLatticeCurve)
                deformers.applyLattice(ssLattices[s], sLatticeUpCurve)
                for j,fParam in enumerate(fParams):
                    sJ = cmds.createNode('joint', n='jnt_%s_%sSkinLidSpline_%03d' % (sSide, sPart, j),
                                         p=sTransformJoint)
                    utils.matchJointRadius(sJ, sEyeJoints[s], 0.30)
                    sInfoNode, sInfoPos = curves.createPointInfoNode(sLatticeCurve, fParam=fParams[j])
                    _, sInfoUpPos = curves.createPointInfoNode(sLatticeUpCurve, fParam=fParams[j])
                    nodes.createPointByMatrixNode(sInfoPos, '%s.worldInverseMatrix' % sTransformJoint, sTarget='%s.t' % sJ)
                    sAimConstraint = constraints.aimConstraintEmpty(sJ, aim=[0, 0, -1], up=[1, 0, 0],
                                                                    bConnectJointOrient=False)
                    # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                    nodes.createPointByMatrixNode(sInfoUpPos, '%s.worldInverseMatrix' % sTransformJoint, '%s.target[0].targetTranslate' % sAimConstraint)
                    sTangent = nodes.createPointByMatrixNode('%s.tangent' % sInfoNode, sTransformJointRotInverseMatrix)
                    sTangent = nodes.createBlendNode(sLivePoleAttr, sTangent, cmds.getAttr(sTangent)[0], bVector=True)
                    cmds.connectAttr(sTangent, '%s.worldUpVector' % sAimConstraint)
                    sSkinJoints.append(sJ)


                deformers.applyLattice(ssLattices[s], sCtrlBlendingCurves[p])


            # reference matrix:
            if bSeparateSkinCluster:
                for sJ in sSkinJoints:
                    fLocalMatrix = nodes.createMultMatrixNode(
                        ['%s.worldMatrix' % sJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                    sRefMatrix = nodes.createMultMatrixNode([fLocalMatrix, '%s.worldMatrix' % sParentJoint])
                    sRevInvMatrix = nodes.createInverseMatrix(sRefMatrix)
                    utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRevInvMatrix)

        sCtrlSkinClusters = [] #bot/top
        for p,sPart in enumerate(['bot','top']):

            sCtrlJoints = [cC.sJoint for cC in [ccCornerCtrls[s][0]]+cccBotTopCtrls[s][p]+[ccCornerCtrls[s][1]]]
            sCtrlSkinCluster = deformers.skinMesh(sCombinedCurves[p], ['jnt_m_faceZero'],
                                                  bAlwaysCreateManually=True, bAlwaysAddDefaultWeights=True,
                                                  sName='skinCluster__lidSplines_%s_%s_%02d' % (sSide,sPart,0), _bSkipDeformerAdjustLogging=True)
            weights.skinCurveBSpline4(patch.patchFromName(sCombinedCurves[p]), sCtrlJoints,
                                      sChooseSkinCluster=sCtrlSkinCluster, bStrongEnds=True,
                                      iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)
            
            sCtrlSkinClusters.append(sCtrlSkinCluster)
        
        # bottom lid follow top controls on blink
        cmds.setAttr('%s.ty' % cBlink.sCtrl, -1)
        sTopToBotSkinCluster = weights.transferSkinCluster(patch.patchFromName(sCombinedCurves[0]), sFrom=sCtrlSkinClusters[1],
                                                           bAutoCreateNewSkinCluster='%s_otherside' % sSide, _bSkipDeformerAdjustLogging=True)[0]
        cmds.setAttr('%s.ty' % cBlink.sCtrl, 0)
        sBotFollowTopCtrlsAttr = utils.addAttr(cBlink.sCtrl, ln='botFollowTopCtrlsOnBlink', min=0, max=1, dv=0, k=True)
        nodes.createMultiplyNode(sBotFollowTopCtrlsAttr, sBlink, sTarget='%s.envelope' % sTopToBotSkinCluster)

        # if _bSquashed:
        #     for p,sPart in enumerate(['bot','top']):
        #         deformers.applyLattice(ssLattices[s], sCombinedCurves[p])

        # pick walk
        for cC in [ccCornerCtrls[s][0]] + cccBotTopCtrls[s][1] + [ccCornerCtrls[s][1]] + cccBotTopCtrls[s][0][::-1]:
            cmds.controller(cC.sCtrl, cEyeTransform.sCtrl, parent=True)

#EXCLUDE END LIDSPLINES


kSplineLidCorrectivePrefix = 'splineLidCorrective'
kSplineLideCorrectiveSep = 'X'

@builderTools.addToBuild(iOrder=62.3, dButtons=dButtons, bDisableByDefault=True)
def applyEyeLidCorrectives(sModel=None, bMakeNotExportWeights=True):
    if sModel:
        sModel = utils.toList(sModel)[0]
    else:
        raise Exception('no model given')

    sCorrectives = cmds.ls('%s*' % kSplineLidCorrectivePrefix, et='transform')

    xxCorrs = [[], []]
    for sCorr in sCorrectives:
        report.report.addLogText('"%s"...' % sCorr)

        sBotTopSplits = sCorr.split(kSplineLideCorrectiveSep)[-2:]
        for p,sPart in enumerate(['bot','top']):
            if sBotTopSplits[p]:
                print ('sBotTopSplits[p]: ', sBotTopSplits[p])
                if sBotTopSplits[p].startswith('n'):
                    iValue = -int(sBotTopSplits[p][1:])
                else:
                    iValue = int(sBotTopSplits[p])
                fValue = iValue * 0.01
                bBoth = True if sBotTopSplits[1-p] else False
                xxCorrs[p].append((sCorr, fValue, bBoth))



    for p,sPart in enumerate(['bot','top']):
        print ('\n\n\n PART: ', sPart)
        xCorrsSorted = sorted(xxCorrs[p], key=lambda x:x[1])

        for x,xCorr in enumerate(xCorrsSorted):
            sCorr, fValue, bBoth = xCorr
            if p == 1 and bBoth:
                continue
            fBothValues = [None, None]
            fBothValues[p] = fValue
            if p == 0 and bBoth:
                for xOppCorr in xxCorrs[1]:
                    sOppCorr, fOppValue, _ = xOppCorr
                    if sCorr == sOppCorr:
                        fBothValues[1] = fOppValue

            ffLidRanges = [[], []]

            for pp,fV in enumerate(fBothValues):
                if fV == None:
                    continue
                fRange = [None, fV, None]
                fFloorValue = math.floor(fV)
                fCeilValue = math.ceil(fV)
                if x > 0:
                    fRange[0] = xCorrsSorted[x-1][1]
                    if fV > 0.0 and fRange[0] < 0.0:
                        fRange[0] = 0.0
                else:
                    fRange[0] = fFloorValue
                if fRange[0] == fRange[1]:
                    fRange[0] = None
                print ('x: ', x, 'xCorrsSorted: ', xCorrsSorted)
                if x < len(xCorrsSorted)-1:
                    fRange[2] = xCorrsSorted[x+1][1]

                    if fV < 0.0 and fRange[2] > 0.0:
                        fRange[2] = 0.0
                else:
                    if fRange[1] == -1:
                        fRange[2] = 0
                    else:
                        fRange[2] = fCeilValue
                if fRange[2] == fRange[1]:
                    fRange[2] = None


                if fRange[0] == None and fRange[2] == None:
                    raise Exception('Something wrong with the algorithm.. both ends are None')

                ffLidRanges[pp] = fRange

            
            report.report.addLogText('==== sCorr: %s, ffLidRanges, %s' % (sCorr, ffLidRanges))

            sSecondaryModels = [sO.split('__')[0] for sO in cmds.ls('*__%s' % sCorr)]
            blendShapesPro.connectTargets(sModel, sCorr, ffLidRanges=ffLidRanges, iInvert=2, sSecondaryModels=sSecondaryModels)
            if bMakeNotExportWeights:
                deformers.makeBlendShapesNoExport([sModel]+sSecondaryModels)


@builderTools.addToBuild(iOrder=51, dButtons={}, bDisableByDefault=True)
def createEyeLatticeCtrls(sLeftMeshes=[], sRightMeshes=[], sSkinMeshes=[], fScale=1.2, fEyeLFT_ctrl_defaultR=[0,0,0], bAddNoExportFlagToEyes=True):#, bLegacyOrient=False):
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeEnd'], ['jnt_r_eyeMain', 'jnt_r_eyeEnd']]
    ssEyeMeshes = [sLeftMeshes, sRightMeshes]

    sGrp = cmds.createNode('transform', n='grp_eyeLatticeSetup', p='modules')


    for s,sSide in enumerate(['l','r']):
        fEyeLength = abs(cmds.getAttr('%s.tx' % ssEyeJoints[s][1]))
        sEyeCtrl = ctrls5.ctrlFromName('eye%s_ctrl' % utils.sSides3[s]).sCtrl
        cEyeTransform = ctrls5.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])

        sTempMatchTransform = cmds.createNode('transform')
        cmds.delete(cmds.orientConstraint(cEyeTransform.sCtrl, sTempMatchTransform))

        # if not bLegacyOrient:
        sConstrDelete = cmds.parentConstraint(sEyeCtrl, sTempMatchTransform, mo=True)

        cmds.setAttr('%s.r' % sEyeCtrl, *fEyeLFT_ctrl_defaultR)

        # if not bLegacyOrient:
        cmds.delete(sConstrDelete)


        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        for m, sMesh in enumerate(ssEyeMeshes[s]+sSkinMeshes):
            # sName = 'lattice_%s_eyeball' % sSide
            sLatDeformer = 'lattice__%s__%s_EYE' % (sMesh, sSide)
            if m == 0:
                if cmds.objExists(sLatDeformer):
                    sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                    sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                else:
                    sLatDeformer, sLat, sLatBase = cmds.lattice(sMesh, n=sLatDeformer)

                cmds.setAttr('%s.sDivisions' % sLat, 2)
                cmds.setAttr('%s.tDivisions' % sLat, 3)
                cmds.setAttr('%s.uDivisions' % sLat, 2)
                cmds.setAttr('%s.localInfluenceS' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceT' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceU' % sLatDeformer, 2)

                sParent = cmds.createNode('transform', n='grp_%s_eyeLattice' % sSide, p=sGrp)
                sScaleParent = cmds.createNode('transform', n='grp_%s_eyeLatticeScale' % sSide, p=sParent)
                cmds.parent(sLat, sLatBase, sScaleParent)
                cmds.setAttr('%s.s' % sLat, fScale, fScale, fScale)
                cmds.setAttr('%s.s' % sLatBase, fScale, fScale, fScale)
            else:
                # sLatDeformer, _sLat, _sLatBase = cmds.lattice(sMesh)#, divisions=(2, 3, 2), ldv=(2, 2, 2))
                if cmds.objExists(sLatDeformer):
                    _sLat = cmds.listConnections('%s.deformedLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                    _sLatBase = cmds.listConnections('%s.baseLatticeMatrix' % sLatDeformer, s=True, d=False)[0]
                else:
                    sLatDeformer, _sLat, _sLatBase = cmds.lattice(sMesh, n=sLatDeformer)
                cmds.setAttr('%s.localInfluenceS' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceT' % sLatDeformer, 2)
                cmds.setAttr('%s.localInfluenceU' % sLatDeformer, 2)
                cmds.connectAttr('%sShape.latticeOutput' % sLat, '%s.deformedLatticePoints' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLat, '%s.deformedLatticeMatrix' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLatBase, '%s.baseLatticeMatrix' % sLatDeformer, f=True)
                cmds.delete(_sLat, _sLatBase)

            cmds.setAttr('%s.outsideLattice' % sLatDeformer, 1)
            if bAddNoExportFlagToEyes:
                if sMesh not in sSkinMeshes:
                    deformers.makeNotExport(sLatDeformer)

        cmds.delete(cmds.parentConstraint(ssEyeJoints[s][0], sParent))
        cmds.setAttr('%s.sx' % sParent, fSideMultipl)
        cmds.setAttr('%s.sy' % sParent, fSideMultipl)
        xforms.matrixParentConstraint(cEyeTransform.sOut, sParent, mo=True)
        fParentScale = fEyeLength * 2.0
        cmds.setAttr('%s.s' % sScaleParent, fParentScale, fParentScale, fParentScale*fSideMultipl)

        sJoints = []
        sOrigin = xforms.createTransform('grp_%s_latticeOrigin' % sSide, sMatch=cEyeTransform.sPasser, sParent=sGrp)

        xLatticePointData = [['bot', ('pt[0:1][0][0]', 'pt[0:1][0][1]'), ('pt[1][0][0:1]',)],
                            ['top', ('pt[0:1][2][0]', 'pt[0:1][2][1]'), ('pt[1][2][0:1]',)],
                            ['in', ('pt[0:1][1][1]',), ('pt[1][1][1]',)],
                            ['out', ('pt[0:1][1][0]',), ('pt[1][1][0]',)]]
        dJoints = {}
        dCtrls = {}
        for sName, sPoints, sCtrlPoints in xLatticePointData:
            aCtrlPos = np.average(np.array(cmds.xform(['%s.%s' % (sLat,sP) for sP in sCtrlPoints], q=True, ws=True, t=True)).reshape(-1,3), axis=0)
            cmds.setAttr('%s.t' % sTempMatchTransform, *list(aCtrlPos))
            cC = ctrls5.create(sName='%sEyeLattice' % sName, sSide=sSide, sParent=_getFaceCtrlGrp(), sMatch=sTempMatchTransform,
                              sAttrs=['t','r','sx'] if sName in ['bot','top'] else ['t','r'],
                              fRotateShape=(0, 0, 0) if sName in ['bot','top'] else (0,0,-90),
                              iColorIndex=1, fSliderScale=fEyeLength,
                              sShape='triangle', fSize=0.5)

            if sName == 'bot':
                cmds.setAttr('%s.sy' % cC.sSlider, cmds.getAttr('%s.sy' % cC.sSlider) * -1.0)
                cmds.setAttr('%s.sy' % cC.sOut, cmds.getAttr('%s.sy' % cC.sOut) / -1.0)
            if sName == 'out':
                cmds.setAttr('%s.sx' % cC.sSlider, cmds.getAttr('%s.sx' % cC.sSlider) * -1.0)
                cmds.setAttr('%s.sx' % cC.sOut, cmds.getAttr('%s.sx' % cC.sOut) / -1.0)
            xforms.matrixParentConstraint(cEyeTransform.sCtrl, cC.sPasser, mo=True)
            sJ = cmds.createNode('joint', n='jnt_%s_%sEyelattice' % (sSide,sName), p=sOrigin)
            cmds.setAttr('%s.radius' % sJ, fEyeLength*0.1)
            # cmds.setAttr('%s.v' % sJ, False)

            nodes.transformInLocalSpace(cC.sOut, cEyeTransform.sOut, sJ)

            sJoints.append(sJ)
            dJoints[sName] = sJ
            dCtrls[sName] = cC
            if sName in ['in', 'out']:
                sBot = xforms.createTransform('grp_%s_%sConstrBot' % (sSide,sName), sParent=dCtrls['bot'].sOut, sMatch=cC.sOut)
                cmds.setAttr('%s.ty' % sBot, 0.0)
                sTop = xforms.createTransform('grp_%s_%sConstrTop' % (sSide,sName), sParent=dCtrls['top'].sOut, sMatch=cC.sOut)
                cmds.setAttr('%s.ty' % sTop, 0.0)
                sPointGrp = cC.appendOffsetGroup('pointConstraint')
                cmds.pointConstraint(sBot, sTop, sPointGrp)

        sSkinCluster = cmds.skinCluster(sLat, sJoints, tsb=True, maximumInfluences=1)[0]
        for sName, sPoints, sCtrlPoints in xLatticePointData:
            cmds.skinPercent(sSkinCluster, ['%s.%s' % (sLat,sP) for sP in sPoints], transformValue=[dJoints[sName], 1])

        cmds.delete(sTempMatchTransform)
        cmds.setAttr('%s.r' % sEyeCtrl, 0,0,0)





dButtons = OrderedDict()

def selectBlinkJoints():
    cmds.select(cmds.ls('jnt_?_eyeBlink???', et='joint'))

def selectEyeTransformJoints():
    cmds.select(cmds.ls('jnt_?_eyeTransform', et='joint'))


def recordSiblings(_uiArgs=None):

    dPoses = {}
    sSiblings = [sT for sT in cmds.listRelatives('jnt_l_eyeLidParent', c=True) if sT.startswith('grp_l_sibling') or sT.startswith('l_sibling')]

    print('sSiblings: ',sSiblings)
    for sT in sSiblings:
        sPrintT = sT
        if sPrintT.endswith('_Grp'):
            sPrintT = 'grp_%s' % sPrintT[:-4]
        for sA in ['t','r','s']:
            sAttr = '%s.%s' % (sT,sA)
            sPrintAttr = '%s.%s' % (sPrintT,sA)
            dPoses[sPrintAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dSiblingPoses'].setText(str(dPoses))



def selectSiblings(_uiArgs=None):

    dPoses = {}
    sSiblings = [sT for sT in cmds.listRelatives('jnt_l_eyeLidParent', c=True) if sT.startswith('grp_l_sibling') or sT.startswith('l_sibling')]

    cmds.select(sSiblings)


kEyeBpGroupName = '_grp_m_eyeBps'
kEyeBpFileName = 'faceBlueprintsEye.ma'

dButtons['select blink bind joints'] = selectBlinkJoints
dButtons['select transform bind joints'] = selectEyeTransformJoints
dButtons['fill left sibling poses'] = recordSiblings
dButtons['select left sibling transforms'] = selectSiblings



def _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bLattice, fScaleTheScale):
    utils.data.store('bLatticeEyes', bLattice)
    # utils.data.store('bScaleSquash', bScaleSquash)

    ssLattices = [None, None], [None, None]
    if not bLattice:
        fEyeballSquashValues = cmds.getAttr('%s.s' % ssMeshes[0][0])[0]
        fEyeballSquashValues = [abs(fEyeballSquashValues[0]), abs(fEyeballSquashValues[1]), abs(fEyeballSquashValues[2])]
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeEnd'], ['jnt_r_eyeMain', 'jnt_r_eyeEnd']]
    sNurbsSpheres = []
    for s,sSide in enumerate(['l','r']):
        sSphere = cmds.sphere(n='nurbs_%s_eyeRigSphere' % sSide, r=cmds.getAttr('%s.tx' % ssEyeJoints[s][1]))[0]
        cmds.delete(cmds.parentConstraint(ssEyeJoints[s][0], sSphere))
        ssMeshes[s].append(sSphere)
        sNurbsSpheres.append(sSphere)
        sSkinCluster = cmds.skinCluster(sSphere, ssEyeJoints[s][0], tsb=True)
        deformers.makeNotExport(sSkinCluster)

    cmds.parent(sNurbsSpheres, 'modules')
    if bLattice:
        sLatticeDeformers = []
        for s,sSide in enumerate(['l','r']):
            for sM in ssMeshes[s]:
                sDefs = deformers.listAllDeformers(sM, sFilterTypes=['ffd'], bSkipGeoTest=True)
                sLatticeDeformers += sDefs
                for sD in sDefs:
                    sLatticeConn = cmds.listConnections(sD, t='lattice', s=True, d=False)
                    if sLatticeConn:
                        ssLattices[s][0] = sLatticeConn[0]
                    sBaseLatticeConn = cmds.listConnections(sD, t='baseLattice', s=True, d=False)
                    if sBaseLatticeConn:
                        ssLattices[s][1] = sBaseLatticeConn[0]

                    sConns = cmds.listConnections(sD, t='lattice', s=True, d=False, c=True, p=True) or []
                    sConns += cmds.listConnections(sD, t='baseLattice', s=True, d=False, c=True, p=True) or []
                    print('sConns: ', sConns)
                    for i in range(0, len(sConns), 2):
                        cmds.disconnectAttr(sConns[i+1], sConns[i])

        if sLatticeDeformers:
            cmds.delete(sLatticeDeformers)


    utils.data.store('ssEyeLattices', ssLattices)
    utils.data.store('ssEyeMeshes', ssMeshes)
    sSuffix = ''
    for s, sSide in enumerate(['l', 'r']):

        cEyeCtrl = ctrls5.ctrlFromName('eye%s_ctrl' % utils.sSides3[s])
        cEyeTransform = ctrls5.ctrlFromName('eyeTransform%s_ctrl' % utils.sSides3[s])


        if not bLattice:
            for sM in ssMeshes[s]:
                fValues = cmds.getAttr('%s.s' % sM)[0]
                fSquashToOne = fValues[0]/fEyeballSquashValues[0], fValues[1]/fEyeballSquashValues[1], fValues[2]/fEyeballSquashValues[2]
                if sM not in sNurbsSpheres:
                    cmds.setAttr('%s.s' % sM, *fSquashToOne)

        if bLattice:
            sLatticeGrp = cmds.createNode('transform', n='grp_%s_latticeGrp' % sSide, p='modules')
            xforms.matrixParentConstraint(cEyeTransform.sOut, sLatticeGrp)
            print ('ssLattices: ', ssLattices)
            cmds.parent(ssLattices[s], sLatticeGrp)
            cmds.select(sLatticeGrp)

        else: # used to be bSquashedEyeballs
            sEyeballSquashAttrs = [utils.addAttr(cEyeTransform.sPasser, ln='squashX', defaultValue=fEyeballSquashValues[2], k=True),
                                  utils.addAttr(cEyeTransform.sPasser, ln='squashY', defaultValue=fEyeballSquashValues[1], k=True),
                                  utils.addAttr(cEyeTransform.sPasser, ln='squashZ', defaultValue=fEyeballSquashValues[0], k=True)]
            sEyeballSquashSwitch = utils.addAttr(cEyeTransform.sPasser, ln='squashSwitch', defaultValue=0.0, k=True, min=0, max=1)
            sEyeballSquashScaleTheScale = utils.addAttr(cEyeTransform.sPasser, ln='squashExtra', defaultValue=fScaleTheScale, k=True)
            sDiff = nodes.createVectorAdditionNode([sEyeballSquashAttrs, [1,1,1]], sOperation='minus')
            sMultipl = nodes.createVectorMultiplyNode(sDiff, sEyeballSquashScaleTheScale, bVectorByScalar=True)
            sEyeballSquashAdded = nodes.createVectorAdditionNode([sMultipl, [1,1,1]])
            
            sEyeballSquash = nodes.createBlendNode(sEyeballSquashSwitch, sEyeballSquashAdded, [1,1,1], bVector=True)
            sSquashGrp = xforms.insertParent(ssEyeJoints[s][0], sName='grp_%s_eyeSquash' % sSide)
            nodes.deleteConnection('%s.s' % ssEyeJoints[s][0])
            nodes.deleteConnection('%s.r' % ssEyeJoints[s][0])


            cmds.connectAttr(sEyeballSquash, '%s.s' % sSquashGrp)
            sEyeInPasser = cmds.createNode('transform', n='grp_%s_eyeInPasser' % sSide, p='grp_%s_eyeTransformPasser' % sSide)
            xforms.matrixParentConstraint(cEyeCtrl.sOut, sEyeInPasser)
            cmds.connectAttr('%s.r' % sEyeInPasser, '%s.r' % ssEyeJoints[s][0])



@builderTools.addToBuild(iOrder=24.2, dButtons=dButtons, bDisableByDefault=True, sJustOneKey='lidsSetup', sOverwriteColor=kEyelidBuilderColor)
def createSimpleLidSetup(sParentJoint='jnt_m_headMain', dSiblingPoses={}, sLeftMeshes=[], sRightMeshes=[], bModelHasLattice=False, fScaleTheScale=1.0):
    '''
    for the behavior of the joints towards the controls, adjust the sibling groups. They are in the same
    parents as the eyelid joints (select button "select blink joints" to find them)

    Adjust the left side, and he'll mirror the right side for you
    '''

    ssMeshes = [sLeftMeshes, sRightMeshes]

    if ssMeshes[0] or ssMeshes[1]:
        _unsquashEyesAndCreateNurbsSpheres(ssMeshes, bModelHasLattice, fScaleTheScale)
    sEyeLimbNames = ['l_eye', 'r_eye']
    ssEyeJoints = [['jnt_l_eyeMain', 'jnt_l_eyeEnd'], ['jnt_r_eyeMain', 'jnt_r_eyeEnd']]
    sEyeTransformJoints = ['jnt_l_eyeTransform', 'jnt_r_eyeTransform']
    sSuffix = ''
    for s,sSide in enumerate(['l','r']):
        sParent = xforms.createJoint('jnt_%s_eyeLidParent' % sSide, sParent=sParentJoint, sMatch=sEyeTransformJoints[s], fSize=0.5)
        cmds.setAttr('%s.segmentScaleCompensate' % sParent, False)
        xforms.matrixParentConstraint(sEyeTransformJoints[s], sParent)

        # aJointPositions = xforms.getPositionArray(ssEyeJoints[s])

        cBlink = ctrls5.ctrlFromName('blink%s%s_ctrl' % (sSuffix, utils.sSides3[s]))
        cExtraBlinks = [ctrls5.ctrlFromName('lidBot%s%s_ctrl' % (sSuffix, utils.sSides3[s])),
                        ctrls5.ctrlFromName('lidTop%s%s_ctrl' % (sSuffix, utils.sSides3[s]))]
        cAim = ctrls5.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s], bReturnNoneIfNotExists=True)
        if not cAim:
            cAim = ctrls5.ctrlFromName('eyeLookAt%s%s_ctrl' % (sSuffix, utils.sSides3[s]), bReturnNoneIfNotExists=True)


        # cmds.setAttr('%s.s' % cBlink.sSlider, fSideMultipl,  fSideMultipl, fSideMultipl)
        cmds.controller(cBlink.sCtrl, headCtrl(), parent=True)

        sBlinkJoints = [xforms.createJoint('jnt_%s_eyeBlinkBot' % sSide, sMatch=ssEyeJoints[s][0], sParent=sParent),
                        xforms.createJoint('jnt_%s_eyeBlinkTop' % sSide, sMatch=ssEyeJoints[s][0], sParent=sParent)]


        sEyeOpen = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0,-1, 1, 0)


        sLookVert = '%s.lookVert' % cAim.sPasser
        sSwitchedLookY = nodes.createMultiplyArrayNode([sLookVert, 0.5, sEyeOpen])

        for p,sPart in enumerate(['bot','top']):
            sSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingWideMain = cmds.createNode('transform', n='grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingExtraDown = cmds.createNode('transform', n='grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            sSiblingExtraUp = cmds.createNode('transform', n='grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)

            # sSiblingFollowDown = cmds.createNode('transform', n='grp_%s_siblingFollowDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)
            # sSiblingFollowUp = cmds.createNode('transform', n='grp_%s_siblingFollowUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart)), p=sParent)

            # default attributes..
            if p == 0:
                cmds.setAttr('%s.rz' % sSiblingBlinkMain, 30)
                cmds.setAttr('%s.rz' % sSiblingWideMain, -5)
            else:
                cmds.setAttr('%s.rz' % sSiblingBlinkMain, -30)
                cmds.setAttr('%s.rz' % sSiblingWideMain, 10)
            cmds.setAttr('%s.rz' % sSiblingExtraDown, -30)
            cmds.setAttr('%s.rz' % sSiblingExtraUp, 30)
            # cmds.setAttr('%s.rz' % sSiblingFollowDown, -30)
            # cmds.setAttr('%s.rz' % sSiblingFollowUp, 30)

            for sA in ['t','r','s']:
                fDefault = [1,1,1] if sA == 's' else [0,0,0]
                sBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sSiblingBlinkMain, sA), bOutRangeIsVector=True)
                sBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sSiblingWideMain, sA), bOutRangeIsVector=True)
                sBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                sBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)

                sBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                sBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)

                if sA in ['t','r']:
                    nodes.createVectorAdditionNode([sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp], sTarget='%s.%s' % (sBlinkJoints[p], sA))
                else:
                    nodes.createMultiplyArrayNode([sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp], bVector=True, sTarget='%s.%s' % (sBlinkJoints[p], sA))


        for sAttr, fValues in list(dSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if not cmds.objExists(sAttrSide):
                report.report.addLogText('skipping setting siblingPoses for %s (doesn\'t exist)' % sAttrSide)
                continue
            if sAttr.endswith('.t') and sSide == 'r':
                cmds.setAttr(sAttrSide, -fValues[0], -fValues[1], -fValues[2])
            else:
                cmds.setAttr(sAttrSide, *fValues)

    sUnrealCodeLines = ['\n\n# Lid Setup\n\n']
    # sUnrealMocapCodeLines = ['\n\n# Lid Setup\n\n']

    for s,sSide in enumerate(['l','r']):
        ssUnrealTranslations = [], []
        ssUnrealRotations = [], []
        ssUnrealScales = [], []

        for p,sPart in enumerate(['bot','top']):
            sSiblingBlinkMain = 'grp_%s_siblingBlink%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingWideMain = 'grp_%s_siblingWide%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraDown = 'grp_%s_siblingExtraDown%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sSiblingExtraUp = 'grp_%s_siblingExtraUp%s' % (sSide, utils.getFirstLetterUpperCase(sPart))
            sList = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp]
            for sT in sList:
                ssUnrealTranslations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.t' % sT)[0], bBoneSpace=True))
                ssUnrealRotations[p].append(utilsUnreal.flipVectorToUnreal(cmds.getAttr('%s.r' % sT)[0], bEuler=True, bBoneSpace=True))
                ssUnrealScales[p].append(cmds.getAttr('%s.s' % sT)[0])
                
        sUnrealCodeLines.append("functions.lidSetup([%s, %s, %s], \n\t\t\t[%s, %s, %s], sSide='%s', sLookVertVarName='lookVert_%s', sLookHorizVarName='lookHoriz_%s')" %
                         (ssUnrealTranslations[0], ssUnrealRotations[0], ssUnrealScales[0], ssUnrealTranslations[1], ssUnrealRotations[1], ssUnrealScales[1], sSide, sEyeLimbNames[s], sEyeLimbNames[s]))
        # sUnrealMocapCodeLines.append("functions.lidSetupApple([%s, %s, %s], \n\t\t\t[%s, %s, %s], sSide='%s')" %
        #                  (ssUnrealTranslations[0], ssUnrealRotations[0], ssUnrealScales[0], ssUnrealTranslations[1], ssUnrealRotations[1], ssUnrealScales[1], sSide))



    report.report.addLogText('\n'.join(sUnrealCodeLines), bPrint=True)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile()
    utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)



@builderTools.addToBuild(iOrder=50.1, dButtons={})
def activateEyeSQUASHED():
    if cmds.objExists('grp_l_eyeTransformPasser.squashSwitch'):
        cmds.setAttr('grp_l_eyeTransformPasser.squashSwitch', 1.0)
    if cmds.objExists('grp_r_eyeTransformPasser.squashSwitch'):
        cmds.setAttr('grp_r_eyeTransformPasser.squashSwitch', 1.0)


    if utils.data.get('bLatticeEyes') == True:
        ssLattices = utils.data.get('ssEyeLattices')
        ssEyeMeshes = utils.data.get('ssEyeMeshes')
        for s,sSide in enumerate(['l','t']):
            for sM in ssEyeMeshes[s]:
                sLattice, sBaseLattice = ssLattices[s]
                sLatDeformer, _sLat, _sLatBase = cmds.lattice(sM, divisions=(2, 3, 2), ldv=(2, 2, 2))
                cmds.connectAttr('%sShape.latticeOutput' % sLattice, '%s.deformedLatticePoints' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sLattice, '%s.deformedLatticeMatrix' % sLatDeformer, f=True)
                cmds.connectAttr('%sShape.worldMatrix[0]' % sBaseLattice, '%s.baseLatticeMatrix' % sLatDeformer, f=True)
                cmds.setAttr('%s.outsideLattice' % sLatDeformer, 1)
                cmds.delete(_sLat, _sLatBase)
                deformers.makeNotExport(sLatDeformer)

dButtons = {}
dButtons['- Export *Slider* BPs -'] = ctrls5.exportSliderBps

@builderTools.addToBuild(iOrder=64, dButtons=dButtons)
def attachSliders(sScaleJoint='jnt_m_headMain', sAdditionalSkinClusters=[]):

    sAttachTransforms = [sT for sT in cmds.ls(et='transform') if cmds.attributeQuery('attachToLidBlendShapes', node=sT, exists=True)]
    if sAttachTransforms:
        sMesh = cmds.getAttr('%s.attachToLidBlendShapes' % sAttachTransforms[0])
        sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        report.report.addLogText('sMesh: ', sMesh)
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]
            aPoints = xforms.getPositionArray(sAttachTransforms)
            sMesh = cmds.getAttr('%s.attachToLidBlendShapes' % sAttachTransforms[0])
            aIds = xforms.getClosestIdsFromPoints(sMesh, aPoints)
            sTargets = list(blendShapesPro.getTargetsDictFromBlendShape(sBlendShape).values())
            sIgnoreTargets = [sT for sT in sTargets if 'eye' not in sT]
            sLocs = constraints.parallelTransformAsDeformers(sMesh, aIds, sBlendShape=sBlendShape, sDeformers=[], fTargetMinimumDistance=0.01,
                                                     ssIgnoreTargets=[sIgnoreTargets for i in range(len(aIds))], sParent='grp_eyeSplines')
            for t,sT in enumerate(sAttachTransforms):
                sParent = cmds.listRelatives(sT, p=True, c=False)[0]
                sPoint = nodes.createPointByMatrixNode('%s.t' % sLocs[t], cmds.getAttr('%s.worldInverseMatrix' % sParent))
                fDefaultPoint = cmds.getAttr(sPoint)[0]
                nodes.createVectorAdditionNode([sPoint, fDefaultPoint], sOperation='minus', sTarget='%s.t' % sT)
    utils.reload2(ctrls4)
    ctrls5.attachAllSliderCtrls(sScaleJoint=sScaleJoint, sAdditionalSkinClusters=utils.toList(sAdditionalSkinClusters), bReorderSkinClusters=True)



    dButtons = {}
kLashesBpGrp = '_grp_m_lashesBps'
kLashesBpFileName = 'faceBlueprintsLashes.ma'


def recordLashesSiblings(_uiArgs=None):
    sSiblings = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.lashesSibling' % sT) and '_l_' in sT]
    dPoses = {}
    for sT in sSiblings:
        for sA in ['t','r','s']:
            sAttr = '%s.%s' % (sT,sA)
            dPoses[sAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dSiblingPoses'].setText(str(dPoses))


def recordLashesSiblingsRef(_uiArgs=None):
    sSiblings = [sT for sT in cmds.ls(et='transform') if cmds.objExists('%s.lashesSiblingRef' % sT) and '_l_' in sT]
    dPoses = {}
    for sT in sSiblings:
        for sA in ['t','r']:
            sAttr = '%s.%s' % (sT,sA)
            dPoses[sAttr] = cmds.getAttr(sAttr)[0]
    _uiArgs['dRefSiblingPoses'].setText(str(dPoses))



def bindLashes(bRef):

    sSelBefore = cmds.ls(sl=True)
    sJoints = [sJ for sJ in cmds.ls('jnt_?_lashesBot_*', et='joint') if not sJ.endswith('_ref')]
    sJoints += [sJ for sJ in cmds.ls('jnt_?_lashesTop_*', et='joint') if not sJ.endswith('_ref')]
    sMeshes = cmds.ls(sl=True)
    for sMesh in sMeshes:
        if bRef:
            sSkinCluster = 'skinCluster__%s__LASH' % sMesh
            sJoints = ['jnt_m_faceZero'] + sJoints
        else:
            sSkinCluster = 'skinCluster__%s' % sMesh

        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sMesh, sName=sSkinCluster,
                               sInfluences=sJoints,
                               bAlwaysAddDefaultWeights=True)
            deformers.reorderDeformer(sSkinCluster, ['skinCluster__%s__POST' % sMesh], sMesh)


        else:
            deformers.addInfluences(sSkinCluster, sJoints)

    if bRef:
        sDefaultSkinCluster = 'skinCluster__%s' % sMesh
        if not cmds.objExists(sDefaultSkinCluster):
            cmds.confirmDialog(m='Joints got bound to "%s", however you need to create "%s", which is transferring default skincluster from body' %
                                 (sSkinCluster, sDefaultSkinCluster))

    if sSelBefore:
        cmds.select(sSelBefore)


def selectSiblings():
    cmds.select(cmds.ls('*LashSibling*', et='transform'))


dButtons = OrderedDict()
dButtons['Create Bot Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesBot', kLashesBpGrp)
dButtons['Create Top Base Curve'] = lambda: createBpCurve('bpCurve_l_lashesTop', kLashesBpGrp)
dButtons['Create Bot End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesBotEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Create Top End Curve (TO)'] = lambda: createBpCurve('bpCurve_l_lashesTopEnd', kLashesBpGrp, bTrackedOrder=True)
dButtons['Select Siblings'] = selectSiblings
dButtons['Fill Siblings'] = recordLashesSiblings
# dButtons['Fill Siblings Ref'] = recordLashesSiblingsRef # not sure what that was about..
dButtons['BIND Eyelashes (selected)'] = bindLashes
dButtons['- Export Lashes BPs -'] = lambda: exportBps(kLashesBpFileName, kLashesBpGrp)



@builderTools.addToBuild(iOrder=68, dButtons=dButtons, bDisableByDefault=True)
def createLashesSetup(sAttachMesh=[], sParentJoint='jnt_m_headMain', bDoBot=True, bDoTop=True, dSiblingPoses={}, dRefSiblingPoses={}, iJointStep=1, bRef=False):

    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')


    sGrp = cmds.createNode('transform', n='grp_lashes', p='modules')

    ssBpCurves = [['bpCurve_l_lashesBot', 'bpCurve_l_lashesTop'], ['bpCurve_r_lashesBot', 'bpCurve_r_lashesTop']]
    ssBpCurvesEnd = [['bpCurve_l_lashesBotEnd', 'bpCurve_l_lashesTopEnd'], ['bpCurve_r_lashesBotEnd', 'bpCurve_r_lashesTopEnd']]

    aaPoints = [], []
    aaClosestIds = [], []
    bDoes = [bDoBot, bDoTop]
    for s,sSide in enumerate(['l', 'r']):

        for p, sBpCurve in enumerate(ssBpCurves[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)
        for p, sBpCurve in enumerate(ssBpCurvesEnd[s]):
            if bDoes[p]:
                curves.mirrorIfNotExists(sBpCurve)

        for p,sPart in enumerate(['bot','top']):
            if bDoes[p]:
                aPoints = patch.patchFromName(ssBpCurves[s][p]).getAllPoints()
                aIndices = np.arange(len(aPoints), step=iJointStep)
                aIndices[-1] = len(aPoints)-1
                aPoints = aPoints[aIndices]
                aaPoints[s].append(aPoints)
                aaClosestIds[s].append(xforms.getClosestIdsFromPoints(sAttachMesh, aPoints))
            else:
                aaPoints[s].append([])
                aaClosestIds[s].append([])

    aAllClosestIds = np.array(utils.flattenedList(aaClosestIds))
    # print 'sAttachMesh: ', sAttachMesh
    sAllLocs = constraints.parallelTransformAsDeformers(sAttachMesh, aAllClosestIds, sParent=sGrp,
                                                     fTargetMinimumDistance=0.01, sScaleJoint=sParentJoint, #bConnectEnvelopes=False,
                                                     sDeformers=['skinCluster__%s' % sAttachMesh])
    aAllLocs = np.array(sAllLocs)


    # sExtraCtrls = [['lidBotLFT_ctrl', 'lidTopLFT_ctrl'], ['lidBotRGT_ctrl', 'lidTopRGT_ctrl']]
    sCtrlVis = utils.addOffOnAttr('head_ctrl', 'lashesCtrlVis', bDefaultValue=False)

    for s,sSide in enumerate(['l', 'r']):
        cBlink = ctrls5.ctrlFromName('blink%s_ctrl' % utils.sSides3[s])
        cExtraBlinks = [ctrls5.ctrlFromName('lidBot%s_ctrl' % utils.sSides3[s]), ctrls5.ctrlFromName('lidTop%s_ctrl' % utils.sSides3[s])]
        cLookAt = ctrls5.ctrlFromName('eyesLookAt%s_ctrl' % utils.sSides3[s])
        sSwitchedLookY = nodes.createMultiplyNode('%s.lidFollow' % cLookAt.sCtrl, 'grp_%s_eyesLookAtPasser.lookVert' % sSide)

        fEyeJointRadius = cmds.getAttr('jnt_%s_eyeMain.radius' % sSide)
        for p, sPart in enumerate(['bot', 'top']):
            if bDoes[p]:
                sCurveEnd = cmds.duplicate(ssBpCurvesEnd[s][p], n=utils.replaceStringStart(ssBpCurvesEnd[s][p], 'bpCurve_', 'curve_'))[0]
                curves.fixShapeName(sCurveEnd)

                cmds.parent(sCurveEnd, sGrp)
                if bRef:
                    sRefCurveEnd = cmds.duplicate(sCurveEnd, n=utils.replaceStringStart(ssBpCurvesEnd[s][p], 'bpCurve_', 'curveRef_'))[0]
                    curves.fixShapeName(sRefCurveEnd)

                aClosestIds = aaClosestIds[s][p]
                aInds = utils.findOneArrayInAnother(aAllClosestIds, aClosestIds)
                sLocs = aAllLocs[aInds]
                aPoints = aaPoints[s][p]
                aPercs = curves.getPercsFromPoints(ssBpCurves[s][p], aPoints)
                aParams = curves.getParamsFromPercs(sCurveEnd, aPercs)
                aEndPoints = curves.getPointsFromParams(sCurveEnd, aParams, bReturnNumpy=True)
                for j,sL in enumerate(sLocs):
                    sG = cmds.createNode('transform', n='grp_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p='modules')
                    sJ = 'jnt_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j)

                    if cmds.objExists(sJ):
                        cmds.parent(sJ, 'jnt_m_headMain')
                        cmds.setAttr('%s.v' % sJ, True)
                        xforms.resetJoint(sJ)
                    else:
                        cmds.createNode('joint', n=sJ, p='jnt_m_headMain')
                    sJEnd = cmds.createNode('joint', n='jnt_%s_lashes%sEnd_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p=sJ)
                    cmds.setAttr('%s.radius' % sJ, fEyeJointRadius*0.15)
                    cmds.setAttr('%s.radius' % sJEnd, fEyeJointRadius*0.15)

                    fLength = np.linalg.norm(aEndPoints[j]-aPoints[j])

                    cmds.setAttr('%s.tx' % sJEnd, fLength)

                    if bRef:
                        sRefG = cmds.createNode('transform', n='grp_%s_lashes%s_%03d' % (sSide, utils.getFirstLetterUpperCase(sPart), j), p='modules')
                        sRefJ = 'jnt_%s_lashes%s_%03d_ref' % (sSide, utils.getFirstLetterUpperCase(sPart), j)
                        cmds.createNode('joint', n=sRefJ, p='jnt_m_headMain')
                        utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
                        cmds.setAttr('%s.radius' % sJEnd, fEyeJointRadius*0.1)


                    xforms.matrixParentConstraint(sL, sG, skipRotate=['x','y','z'])
                    _, sAimPos = curves.createPointInfoNode(sCurveEnd, fParam=aParams[j])
                    jUp = j+1 if j == 0 else j-1
                    nodes.createSimpleAimConstraint2(sAimPos, sG, xUpMatrix='%s.worldMatrix' % sLocs[jUp], sParent=sGrp)
                    xforms.matrixParentConstraint(sG, sJ)

                    if bRef:
                        deformers.connectRefsOnCurrentSkinClusters([sJ])
                    else:
                        deformers.resetJointReferences([sJ])

                    if bRef:
                        _, sAimPosRef = curves.createPointInfoNode(sRefCurveEnd, fParam=aParams[j])
                        xforms.matrixParentConstraint(sL, sRefG, skipRotate=['x', 'y', 'z'])
                        nodes.createSimpleAimConstraint2(sAimPosRef, sRefG, xUpMatrix='%s.worldMatrix' % sLocs[jUp], sParent=sGrp)
                        xforms.matrixParentConstraint(sRefG, sRefJ)


                aCtrlPercs = np.array([0, 0.5, 1], dtype='float64')
                fCtrlPoints = curves.getPointsFromPercs(sCurveEnd, aCtrlPercs)
                aLocInds = np.array(aCtrlPercs*(len(sLocs)-1), dtype=int)
                sInfluences = []
                if bRef:
                    sRefInfluences = []
                for c,sName in enumerate(['inner', 'mid', 'outer']):

                    cC = ctrls5.create('%sLashes%s' % (sName, utils.getFirstLetterUpperCase(sPart)), sSide, sParent='ctrls', sAttrs=['t','r'],
                                      sMatch='jnt_%s_eyeMain' % sSide, fMatchPos=fCtrlPoints[c], iColorIndex=2, sShape='sphere')
                    cmds.connectAttr(sCtrlVis, '%s.v' % cC.sPasser)

                    xforms.matrixParentConstraint(sLocs[aLocInds[c]], cC.sPasser, mo=True)
                    cC.sJoint = cmds.createNode('joint', p=cC.sOut, n='jnt_%s_%sLashes%s' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)))
                    cmds.setAttr('%s.radius' % cC.sJoint, fEyeJointRadius * 0.35)

                    cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sJoint)
                    sInfluences.append(cC.sJoint)

                    if bRef:
                        sMoveRefGrp = cC.appendOffsetGroup('moveref')
                        cC.sRefJoint = cmds.createNode('joint', p=sMoveRefGrp, n='jnt_%s_%sLashes%s_ref' % (sSide,sName, utils.getFirstLetterUpperCase(sPart)))
                        cmds.setAttr('%s.radius' % cC.sRefJoint, fEyeJointRadius*0.3)
                        sRefInfluences.append(cC.sRefJoint)
                        cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % cC.sRefJoint)

                    # sSliderOffset = cC.appendOffsetGroup('slider')
                    sPoseOffset = cC.appendOffsetGroup('pose')

                    sSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingBlink%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingWideMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingWide%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingExtraDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraDown%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingExtraUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraUp%s' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingFollowDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowDown%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblingFollowUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowUp%s' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                    sSiblings = [sSiblingBlinkMain, sSiblingWideMain, sSiblingExtraDown, sSiblingExtraUp, sSiblingFollowDown, sSiblingFollowUp]
                    [cmds.addAttr(sT, ln='lashesSibling') for sT in sSiblings]
                    for sA in ['t', 'r', 's']:
                        fDefault = [1,1,1] if sA == 's' else [0,0,0]
                        sBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sSiblingBlinkMain, sA), bOutRangeIsVector=True)
                        sBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sSiblingWideMain, sA), bOutRangeIsVector=True)
                        sBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sSiblingExtraDown, sA), bOutRangeIsVector=True)
                        sBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sSiblingExtraUp, sA), bOutRangeIsVector=True)
                        sBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sSiblingFollowDown, sA), bOutRangeIsVector=True)
                        sBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sSiblingFollowUp, sA), bOutRangeIsVector=True)
                        sAllSiblings = [sBlendMain, sBlendWide, sBlendExtraDown, sBlendExtraUp, sBlendsFollowDown, sBlendsFollowUp]
                        if sA in ['t','r']:
                            nodes.createVectorAdditionNode(sAllSiblings, sTarget='%s.%s' % (sPoseOffset, sA))
                        else:
                            nodes.createMultiplyArrayNode(sAllSiblings, bVector=True, sTarget='%s.%s' % (cC.sOut, sA))

                    if bRef:
                        sRefSiblingBlinkMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingBlink%sRef' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                        sRefSiblingWideMain = cmds.createNode('transform', n='grp_%s_%sLashSiblingWide%sRef' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                        sRefSiblingExtraDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraDown%sRef' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                        sRefSiblingExtraUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingExtraUp%sRef' % (sSide, sName,  utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                        sRefSiblingFollowDown = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowDown%sRef' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                        sRefSiblingFollowUp = cmds.createNode('transform', n='grp_%s_%sLashSiblingFollowUp%sRef' % (sSide, sName, utils.getFirstLetterUpperCase(sPart)), p=cC.sSlider)
                        sRefSiblings = [sRefSiblingBlinkMain, sRefSiblingWideMain, sRefSiblingExtraDown, sRefSiblingExtraUp, sRefSiblingFollowDown, sRefSiblingFollowUp]
                        [cmds.addAttr(sT, ln='lashesSiblingRef') for sT in sRefSiblings]
                        # [cmds.setAttr('%s.s' % sT, lock=True) for sT in sRefSiblings]

                        for sA in ['t', 'r', 's']:
                            fDefault = [1,1,1] if sA == 's' else [0,0,0]
                            sRefBlendMain = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, fDefault, '%s.%s' % (sRefSiblingBlinkMain, sA), bOutRangeIsVector=True)
                            sRefBlendWide = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, 0.5, fDefault, '%s.%s' % (sRefSiblingWideMain, sA), bOutRangeIsVector=True)
                            sRefBlendExtraDown = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, -1.0, fDefault, '%s.%s' % (sRefSiblingExtraDown, sA), bOutRangeIsVector=True)
                            sRefBlendExtraUp = nodes.createRangeNode('%s.ty' % cExtraBlinks[p].sCtrl, 0, 1.0, fDefault, '%s.%s' % (sRefSiblingExtraUp, sA), bOutRangeIsVector=True)
                            sRefBlendsFollowDown = nodes.createRangeNode(sSwitchedLookY, 0, -0.707, fDefault, '%s.%s' % (sRefSiblingFollowDown, sA), bOutRangeIsVector=True)
                            sRefBlendsFollowUp = nodes.createRangeNode(sSwitchedLookY, 0, 0.707, fDefault, '%s.%s' % (sRefSiblingFollowUp, sA), bOutRangeIsVector=True)
                            sAllRefSiblings = [sRefBlendMain, sRefBlendWide, sRefBlendExtraDown, sRefBlendExtraUp, sRefBlendsFollowDown, sRefBlendsFollowUp]
                            if sA in ['t', 'r']:
                                nodes.createVectorAdditionNode(sAllRefSiblings, sTarget='%s.%s' % (sMoveRefGrp, sA))
                            else:
                                nodes.createMultiplyArrayNode(sAllRefSiblings, bVector=True, sTarget='%s.%s' % (sMoveRefGrp, sA))

                    # if sSide == 'r':
                    #     cmds.setAttr('%s.s' % sSliderOffset, 1, -1, 1)
                cmds.skinCluster(sCurveEnd, sInfluences, tsb=True)
                if bRef:
                    cmds.skinCluster(sRefCurveEnd, sRefInfluences, tsb=True)

        for sAttr, fValues in list(dSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if cmds.objExists(sAttrSide):
                cmds.setAttr(sAttrSide, *fValues)

        for sAttr, fValues in list(dRefSiblingPoses.items()):
            sAttrSide = sAttr if sSide == 'l' else utils.getMirrorName(sAttr)
            if cmds.objExists(sAttrSide):
                cmds.setAttr(sAttrSide, *fValues)





def openShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)

    cmds.file(sFullPath, open=True, force=True)


def saveAsShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    cmds.file(rename=sFullPath)
    cmds.file(force=True, type='mayaAscii', save=True)


def referenceShapeEditorFile(sFile):
    sFullPath = os.path.join(assets.assetManager.getCurrentVersionPath(), sFile)
    if not os.path.exists(sFullPath):
        raise Exception('BlendShape file not found: %s' % sFullPath)

    utils.importMayaFiles(sFullPath, sNamespace='shapes', bReference=True)



dButtons = OrderedDict()
dButtons['open shape editor file'] = openShapeEditorFile
dButtons['saveAs shape editor file'] = saveAsShapeEditorFile
dButtons['reference shape editor file'] = referenceShapeEditorFile
dButtons['- Export *Slider* BPs -'] = ctrls5.exportSliderBps


@builderTools.addToBuild(iOrder=62, dButtons=dButtons, bCanGetDuplicated=True)
def importBlendShapeFile(sFile='', sBlendShape='', bRemoveReferenceWhenDone=True, sSuffix='', bApplyInnerBlinkValues=True):
    utils.reload2(kangarooShapeEditorTools)
    kangarooShapeEditorTools.importBlendShapeFile(sFile=sFile, sBlendShape=sBlendShape, bRemoveReferenceWhenDone=bRemoveReferenceWhenDone, sSuffix=sSuffix, report=report, bApplyInnerBlinkValues=bApplyInnerBlinkValues)



def selectMapMeshesFromMesh():
    sSel = cmds.ls(sl=True)
    sSelect = []
    for sMesh in sSel:
        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            report.report.addLogText('%s Map not exists: ' % sMapMesh)
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)
        sSelect.append(sMapMesh)
    cmds.select(sSelect)


@builderTools.addToBuild(iOrder=61, dButtons={'Create Or Select Map Meshes from Selection':selectMapMeshesFromMesh})
def importMapMeshes(sDefaultMeshes=[]):
    '''
    map meshes per mesh is meshname__MAPS
    on those the clusters are named MAP__meshName__myName
    and those are exported as meshname__myName.map
    '''
    for sMesh in sDefaultMeshes:
        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)


    sMapFolder = assets.assetManager.getCurrentVersionPath(sSubPath='maps')
    if not os.path.exists(sMapFolder):
        return
    sMapFiles = os.listdir(sMapFolder)
    for sFile in sMapFiles:
        sSplits = sFile.split('.')[0].split('__')
        if len(sSplits) != 2:
            report.report.addLogText('%s does not have the right name standard. Skipping..' % sFile)
            continue

        report.report.addLogText('importing map: %s' % sFile)
        sMesh, sMapName = sSplits

        with open(os.path.join(sMapFolder, sFile), 'rb') as handle:
            fWeights = pickle.load(handle)

        sMapMesh = '%s__MAPS' % sMesh
        if not cmds.objExists(sMapMesh):
            cmds.duplicate(sMesh, n=sMapMesh)
            utils.parentToWorld(sMapMesh)
            cmds.setAttr('%s.v' % sMapMesh, False)
        sCluster = 'MAP__%s__%s' % (sMesh, sMapName)
        if not cmds.objExists(sCluster):
            _, sTempHandle = cmds.cluster(sMapMesh, n=sCluster)
            nodes.deleteConnectionsAndItself2(cmds.ls(sTempHandle, dag=True))
        cmds.setAttr('%s.weightList[0].weights[0:%d]' % (sCluster, len(fWeights)-1), *fWeights)



kMouthBpGroupName = '_grp_m_mouthBps'
kMouthBpFileName = 'faceBlueprintsMouth.ma'


dButtons = OrderedDict()
dCurveHelpA = {'?':['Select the most inner vertex loop, and then place the locators as needed,'\
                                                        '\nto indicate splitting point between bottom and top.'
                                                        '\nThe curve will be broken up at a random point, but that\'s ok. Ideally the '\
                                                        '\nbottom and top part of the curves will be a close together as possible,'\
                                                        '\nbut that\'s depending on the model.'
                                                        '\nIMPORTANT: if at the front the top lip part is lower then the bottom lip part, '\
                                                        '\nyou need to set bFlipInnerBpCurves to True', 'mouthInnerCurves.JPG']}

dCurveHelpB = {'?':['Select the row for the outer curve. This is mainly for the control positions', 'mouthOuterCurves.JPG']}

dButtons['Create Inner Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsInner', kMouthBpGroupName, fDirection=(-1, 0, 0))
dButtons['Create Inner Curves and Locators'].dSideButtons = dCurveHelpA
dButtons['Create Outer Curves and Locators'] = lambda: createBothBpCurves('bpCurve_m_lipsOuter', kMouthBpGroupName, fDirection=(-1, 0, 0))
dButtons['Create Outer Curves and Locators'].dSideButtons = dCurveHelpB



def _attachAndSelectJoints(sJointsString):
    sJoints = cmds.ls(sJointsString, et='joint')
    for sObj in cmds.ls(sl=True):
        sSkinCluster = deformers.convertChooseSkinCluster(None, sObj)
        deformers.addInfluences(sSkinCluster, sJoints)
    cmds.select(sJoints)



dMouthJointsBindMenu = OrderedDict()

def bindBigJoints(ddBindSettings):
    dMultipls = ddBindSettings['dMultipls']
    dBig = ddBindSettings['iBindRowsBig']
    proceduralBind_mouthSplineJoints(dBig['iRigidRows'], dBig['iSmoothRows'],
                                     dMultipls['fBot'], dMultipls['fSide'], dMultipls['fTop'],
                                     sSuffix='MouthSplineBig')
dMouthJointsBindMenu['ADD to big joints'] = bindBigJoints


def bindSmallJoints(ddBindSettings):
    dMultipls = ddBindSettings['dMultipls']
    dSmall = ddBindSettings['iBindRowsSmall']
    proceduralBind_mouthSplineJoints(dSmall['iRigidRows'], dSmall['iSmoothRows'],
                                     dMultipls['fBot'], dMultipls['fSide'], dMultipls['fTop'],
                                     sSuffix='MouthSplineSmall')

dMouthJointsBindMenu['ADD to small joints'] = bindSmallJoints


def backToHeadJaw():
    sTopJoints = cmds.ls('jnt_?_topMouthSpline*_???', et='joint')
    sBotJoints = cmds.ls('jnt_?_botMouthSpline*_???', et='joint')
    dJoints = {sJ: 'jnt_m_headMain' for sJ in sTopJoints}
    dJoints.update({sJ: 'jnt_m_jawMain' for sJ in sBotJoints})
    weights.moveSkinClusterWeights(xJoints=dJoints)




dMouthJointsBindMenu['MOVE small/big TO head/jaw'] = backToHeadJaw
dMouthJointsBindMenu['MOVE small TO big joints'] = lambda: weights.moveSkinClusterWeights(None, {'*MouthSplineSmall*': 'Small,Big'})
dMouthJointsBindMenu['MOVE big TO small joints'] = lambda: weights.moveSkinClusterWeights(None, {'*MouthSplineBig*': 'Big,Small'})
dMouthJointsBindMenu['Attach/Select Lips End Joints'] = lambda: _attachAndSelectJoints('jnt_?_lipsEnd')
dMouthJointsBindMenu['Attach/Select lower slide joint (jaw)'] = lambda: _attachAndSelectJoints('jnt_m_slidePivotFrontJaw')
dMouthJointsBindMenu['Attach/Select upper slide joint (head)'] = lambda: _attachAndSelectJoints('jnt_m_slidePivotFrontHead')




def createMouthSlidingPlane():
    sPlane = cmds.nurbsPlane(name='bpNurbs_l_cornerSlidePlane', w=2.0, u=3, v=3)[0]
    cmds.parent(sPlane, xforms.createOrReturnTopGroup(kMouthBpGroupName))

dButtons['Create Corner Sliding Planes'] = createMouthSlidingPlane
createMouthSlidingPlane.dSideButtons = {'?':['This should be roughtly the shape of the teeth. '\
                                 '\nIt\'s to have the corner controls move in a not so linear way.', 'slidingPlane.jpg']}
createMouthSlidingPlane.dSideButtons = {'?':['This should be roughtly the shape of the teeth. '\
                                 '\nIt\'s to have the corner controls move in a not so linear way.', 'slidingPlane.jpg']}

# maybe this should be in the MOUTH SLIDE menu??
dButtons['Create Mouth Slider Pivot'] = lambda: createMatrixCtrlFromTransform('bp_m_mouthSlide', kMouthBpGroupName, sTransform='jnt_m_headMain')

dButtons['=== BIND ==='] = dMouthJointsBindMenu

dDefaultRollValues = {}
dDefaultRollValues['bot_rot_OUT'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.8, 0.9])}
dDefaultRollValues['bot_rot_IN'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.8, 0.9])}
dDefaultRollValues['bot_up_OUT'] = {'ffKeys':([0, 0.2, 0.5], [0, -0.08, -0.09])}
dDefaultRollValues['bot_forw_OUT'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.8, 0.9])}
dDefaultRollValues['bot_up_IN'] = {'ffKeys':([0, 0.2, 0.5], [0, -0.08, -0.09])}
dDefaultRollValues['bot_forw_IN'] = {'ffKeys':([0, 0.2, 0.5], [0, -0.8, -0.9])}

dDefaultRollValues['top_rot_OUT'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.8, 0.9])}
dDefaultRollValues['top_rot_IN'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.8, 0.9])}
dDefaultRollValues['top_up_OUT'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.08, 0.09])}
dDefaultRollValues['top_forw_OUT'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.8, 0.9])}
dDefaultRollValues['top_up_IN'] = {'ffKeys':([0, 0.2, 0.5], [0, 0.08, 0.09])}
dDefaultRollValues['top_forw_IN'] = {'ffKeys':([0, 0.2, 0.5], [0, -0.8, -0.9])}
kRollNodePrefix = 'animCurve_mouthSplinesRoll_'

iSkipRollSetFromDrivenKeyCounter = 0
def createRollDrivenKeys(ddRollValues):
    global iSkipRollSetFromDrivenKeyCounter
    sSelBefore = cmds.ls(sl=True)
    cmds.undoInfo(openChunk=True)
    try:
        for sPart in ['bot', 'top']:
            for sKey in ['rot_OUT', 'rot_IN', 'up_OUT', 'forw_OUT', 'up_IN', 'forw_IN']:
                sDirection = sKey.split('_')[-1]
                sPartKey = '%s_%s' % (sPart, sKey)
                ffKeys = ddRollValues[sPartKey]['ffKeys']
                dTangentFlags = ddRollValues[sPartKey].get('dTangentFlags', {})
                
                sDummyAttr = 'roll_dummyAttributes_%s_%s.%s' % (sPart, sDirection, sKey)
                sOldCurves = cmds.listConnections(sDummyAttr, s=True, d=False)
                if sOldCurves:
                    cmds.delete(sOldCurves)
                
                sDrivenKeyOutput = nodes.setDrivenKey(None, ffKeys[0], None, ffKeys[1], dTangentFlags=dTangentFlags,
                                   sFullName='%s%s' % (kRollNodePrefix, sPartKey))
                cmds.connectAttr(sDrivenKeyOutput, sDummyAttr)

                iSkipRollSetFromDrivenKeyCounter += 1
        
    except:
        raise
    finally:
        cmds.select(sSelBefore)
        cmds.undoInfo(closeChunk=True)
        iSkipRollSetFromDrivenKeyCounter -= 1
        



# sTempRollDriverOutput = 'loc_tempRollDriver.tx'
def setRollValuesFromDrivenKeys(sParts=['bot','top'], bForce=False):
    global iSkipRollSetFromDrivenKeyCounter
    
    if iSkipRollSetFromDrivenKeyCounter:
        if bForce:
            iSkipRollSetFromDrivenKeyCounter = 0
        else:
            iSkipRollSetFromDrivenKeyCounter -= 1
            return
    
    print('run setRollValuesFromDrivenKeys...')
    sSuffix = ''
    sBpCurvesA = ['bpCurve_m_%sLipInner%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]
    
    cmds.undoInfo(swf=False)
    try:
        
        for p,sPart in enumerate(sParts):
            fPartMult = -1 if sPart == 'top' else 1
            fCurveLength = curves.getLength(sBpCurvesA[p])
            
            fTranslateUnit = fCurveLength * 0.001
            fRollPercs = [cmds.getAttr('%s.perc' % sJ) for sJ in cmds.ls('jnt_?_%sMouthSplineSmall_???' % sPart, et='joint')]
            fRollPercs.sort()
            
            dNodes = {}
            dNodes[cmds.duplicate('%s%s_rot_OUT' % (kRollNodePrefix, sPart))[0]] = ['mult_%sMouthSpline_%03d_rotX_OUT.input1X', 1.0, fPartMult]
            dNodes[cmds.duplicate('%s%s_rot_IN' % (kRollNodePrefix, sPart))[0]] = ['mult_%sMouthSpline_%03d_rotX_IN.input1X', 1.0, fPartMult]
            dNodes[cmds.duplicate('%s%s_up_OUT' % (kRollNodePrefix, sPart))[0]] = ['mult_%sMouthSpline_%03d_translate_OUT.input1Y', 1.0, fTranslateUnit]
            dNodes[cmds.duplicate('%s%s_forw_OUT' % (kRollNodePrefix, sPart))[0]] = ['mult_%sMouthSpline_%03d_translate_OUT.input1Z', 1.0, fTranslateUnit]
            dNodes[cmds.duplicate('%s%s_up_IN' % (kRollNodePrefix, sPart))[0]] = ['mult_%sMouthSpline_%03d_translate_IN.input1Y', -1.0, fTranslateUnit]
            dNodes[cmds.duplicate('%s%s_forw_IN' % (kRollNodePrefix, sPart))[0]] =  ['mult_%sMouthSpline_%03d_translate_IN.input1Z', -1.0, fTranslateUnit]
            
            for j, fPerc in enumerate(fRollPercs):
                if fPerc > 0.5:
                    fPerc = 1 - fPerc
                
                for sNode, xData in dNodes.items():
                    cmds.setAttr('%s.input' % sNode, fPerc)
                    sSetAttr, fMult1, fMult2 = xData
                    cmds.setAttr(sSetAttr % (sPart,j), cmds.getAttr('%s.output' % sNode) * fMult1 * fMult2)
            
            cmds.delete(list(dNodes.keys()))
    except:
        raise
    finally:
        cmds.undoInfo(swf=True)


def fillRollValues(_uiArgs=None):
    ddRollValues = {}
    sNodes = cmds.ls('%s*' % kRollNodePrefix)
    if not sNodes:
        raise Exception('Temp driven keys not found, you may have to run this step right after calling the function')

    for sN in sNodes:
        sDictKey = sN[len(kRollNodePrefix):]

        ffKeys = cmds.getAttr('%s.keyTimeValue[*]' % sN)
        fTimes = [fK[0] for fK in ffKeys]
        fValues = [fK[1] for fK in ffKeys]

        dFlags = {}
        for sCommandFlag in ['inAngle', 'outAngle', 'inWeight', 'outWeight', 'inTangentType', 'outTangentType']:
            dFlags[str(sCommandFlag)] = cmds.keyTangent(sN, **{'q': True, sCommandFlag: True})

        ddRollValues[sDictKey] = {'ffKeys':[fTimes, fValues], 'dTangentFlags':dict(dFlags)}

    report.report.addLogText(str(ddRollValues))
    _uiArgs['ddRollValues'].setText(str(ddRollValues))


def rollRomAnim():
    #in
    cmds.setKeyframe('mouthBot_ctrl.rx', t=1, v=0)
    cmds.setKeyframe('mouthBot_ctrl.rx', t=20, v=-90)
    cmds.setKeyframe('mouthBot_ctrl.rx', t=40, v=0)
    cmds.setKeyframe('mouthTop_ctrl.rx', t=1, v=0)
    cmds.setKeyframe('mouthTop_ctrl.rx', t=20, v=90)
    cmds.setKeyframe('mouthTop_ctrl.rx', t=40, v=0)

    #out
    cmds.setKeyframe('mouthBot_ctrl.rx', t=40, v=0)
    cmds.setKeyframe('mouthBot_ctrl.rx', t=60, v=90)
    cmds.setKeyframe('mouthBot_ctrl.rx', t=80, v=0)
    cmds.setKeyframe('mouthTop_ctrl.rx', t=40, v=0)
    cmds.setKeyframe('mouthTop_ctrl.rx', t=60, v=-90)
    cmds.setKeyframe('mouthTop_ctrl.rx', t=80, v=0)


dRollMarkingMenu = OrderedDict()
# dRollMarkingMenu['Select IN AnimCurve nodes'] = {'lower': lambda: cmds.select('%sbot_*IN' % kRollNodePrefix), 'upper': lambda: cmds.select('%stop_*IN' % kRollNodePrefix), 'all': lambda: cmds.select('%s???_*IN' % kRollNodePrefix)}
# dRollMarkingMenu['Select OUT AnimCurve nodes'] = {'lower': lambda: cmds.select('%sbot_*OUT' % kRollNodePrefix), 'upper': lambda: cmds.select('%stop_*OUT' % kRollNodePrefix), 'all': lambda: cmds.select('%s???_*OUT' % kRollNodePrefix)}
dRollMarkingMenu['Select AnimCurve nodes'] = lambda: cmds.select('roll_dummyAttributes_*_*')
dRollMarkingMenu['Force Update Rig from AnimCurve nodes'] = setRollValuesFromDrivenKeys
dRollMarkingMenu['Reset DrivenKeys from Filled (Saved) values'] = createRollDrivenKeys
dRollMarkingMenu['Fill (Save) all Roll Values'] = fillRollValues
dRollMarkingMenu['ROM animation'] = rollRomAnim
dButtons['=== ROLL ==='] = dRollMarkingMenu



# kAllPoseKeysSplit = ['jawOpenBot', 'jawOpenTop', 'cornerOut', 'funnel', 'lipPress']
kAllPoseKeys = ['jawOpen', 'jawOpen', 'cornerOut', 'funnel', 'lipPress', 'mouthClose']
dSetPosesMenu = OrderedDict()


for sPoseKey in kAllPoseKeys:
    def _fill(ddPoses, _uiArgs=None, _sPoseKey=sPoseKey):
        try:
            sCtrlKey = '%sCtrlKey' % _sPoseKey
            sCtrls = utils.data.get(sCtrlKey)
            # sDriverAttr = ddPoses[_sPoseKey]['sDriverAttr']
            # ddPoses[_sPoseKey]['fDriverValue'] = cmds.getAttr(sDriverAttr)
            dPose = {}
            for sC in sCtrls:
                dObjPose = {}
                sAttrs = list(utils._getAnimAttrsFromNode(sC).keys())
    
                for sA in sAttrs:
                    sAttr = '%s.%s' % (sC,sA)
    
                    fValue = cmds.getAttr(sAttr)
                    if abs(fValue) > 0.0001:
                        dObjPose[sA] = fValue
                if dObjPose:
                    dPose[sC] = dObjPose
    
            ddPoses[_sPoseKey]['dPose'] = dPose
            _uiArgs['ddPoses'].setText(str(ddPoses))
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise
        

    def _poseTo(ddPoses, _uiArgs=None, _sPoseKey=sPoseKey):
        sDriverAttr = ctrls5.verifyCtrlName(ddPoses[_sPoseKey]['sDriverAttr'])
        cmds.setAttr(sDriverAttr, ddPoses[_sPoseKey]['fDriverValue'])

        if _sPoseKey == 'mouthClose':
            fJawOpenValue = ddPoses[_sPoseKey]['fJawOpenValue']
            sJawOpenDriver = ddPoses['jawOpen']['sDriverAttr']
            cmds.setAttr(sJawOpenDriver, fJawOpenValue)

        if utils.getSide(sDriverAttr) == 'l':
            sOther = utils.getMirrorName(sDriverAttr)
            cmds.setAttr(sOther, ddPoses[_sPoseKey]['fDriverValue'])


    def _selectCtrls(ddPoses, _uiArgs=None, _sPoseKey=sPoseKey):
        sCtrlKey = '%sCtrlKey' % _sPoseKey
        sCtrls = utils.data.get(sCtrlKey)
        cmds.select([sC for sC in sCtrls if cmds.objExists(sC)])


    def _setAttrsCtrls(ddPoses, _uiArgs=None, _sPoseKey=sPoseKey):
        dPose = ddPoses[_sPoseKey]['dPose']
        for sCtrl, dAttrs in dPose.items():
            for sA, fV in dAttrs.items():
                cmds.setAttr('%s.%s' % (sCtrl,sA), fV)


    def _removePoseConnections(ddPoses, _uiArgs=None, _sPoseKey=sPoseKey):
        sCtrls = utils.data.get('%sCtrlKey' % _sPoseKey) or []

        for sC in sCtrls:
            dDefaultAttrs = eval(cmds.getAttr('%s.dMouthDefaultValues' % sC))
            sAttrs = utils._getAnimAttrsFromNode(sC).keys()
            for sA in sAttrs:
                sAttr = '%s.%s' % (sC, sA)
                cmds.getAttr(sAttr, settable=True)
            cC = ctrls5.ctrlFromName(sC)
            for sOffsetName in [('%spose' % sKey.lower()) for sKey in kAllPoseKeys]:
                sOffset = cC.getOffsetByName(sOffsetName, bReturnNoneIfNotExists=True)
                if sOffset:
                    for sA in sAttrs:
                        sAttr = '%s.%s' % (sOffset, sA)
                        if cmds.objExists(sAttr):
                            nodes.disconnectAttr(sAttr)
                            if sA in ['sx', 'sy', 'sz', 'scaleX', 'scaleY', 'scaleZ']:
                                cmds.setAttr(sAttr, dDefaultAttrs[sA])
                            else:
                                cmds.setAttr(sAttr, 0)


    def _allThree(ddPoses, _uiArgs=None, _sPoseKey=sPoseKey):
        _removePoseConnections(ddPoses, _uiArgs=_uiArgs, _sPoseKey=_sPoseKey)
        _poseTo(ddPoses, _uiArgs=_uiArgs, _sPoseKey=_sPoseKey)
        _setAttrsCtrls(ddPoses, _uiArgs=_uiArgs, _sPoseKey=_sPoseKey)


    dPoseMenu = OrderedDict()
    dPoseMenu['pose Driver'] = _poseTo
    dPoseMenu['setAttrs to ctrls for %s' % sPoseKey] = _setAttrsCtrls
    dPoseMenu['fill %s Pose' % sPoseKey] = _fill
    dPoseMenu['select ctrls for %s' % sPoseKey] = _selectCtrls
    dPoseMenu['delete pose connections for %s' % sPoseKey] = _removePoseConnections
    dPoseMenu['pose driver / delete conns / setAttrs %s' % sPoseKey] = _allThree
    dSetPosesMenu[sPoseKey] = dPoseMenu



def frontSlideRom():
    cmds.setKeyframe('mouth_ctrl.ty', t=1, v=0)
    cmds.setKeyframe('mouth_ctrl.ty', t=10, v=1)
    cmds.setKeyframe('mouth_ctrl.ty', t=20, v=-1)
    cmds.setKeyframe('mouth_ctrl.ty', t=30, v=0)
    cmds.setKeyframe('mouth_ctrl.tx', t=30, v=0)
    cmds.setKeyframe('mouth_ctrl.tx', t=40, v=1)
    cmds.setKeyframe('mouth_ctrl.tx', t=50, v=0)
    cmds.setKeyframe('mouth_ctrl.tx', t=60, v=-1)
    cmds.setKeyframe('mouth_ctrl.tx', t=70, v=0)


dFrontSlideMenu = {'create rom anim':frontSlideRom, 'select settings ctrl':lambda: cmds.select('grp_m_mouthPasser')}


def createPosesRom(ddPoses):
    cmds.setKeyframe('jaw_ctrl.rz', t=1, v=0)
    cmds.setKeyframe('jaw_ctrl.rz', t=10, v=ddPoses['jawOpen']['fDriverValue'])
    cmds.setKeyframe('jaw_ctrl.rz', t=20, v=0)

    for s,sSide in enumerate(['l','r']):
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=20, v=0)
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=30, v=ddPoses['cornerOut']['fDriverValue'])
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=40, v=ddPoses['cornerOut']['fDriverValue'])
        cmds.setKeyframe('lipsCorner%s_ctrl.tx' % utils.sSides3[s], t=50, v=0)

    cmds.setKeyframe('jaw_ctrl.rz', t=30, v=0)
    cmds.setKeyframe('jaw_ctrl.rz', t=40, v=ddPoses['jawOpen']['fDriverValue'])
    cmds.setKeyframe('jaw_ctrl.rz', t=50, v=0)

    cmds.setKeyframe('mouth_ctrl.tz', t=50, v=0)
    cmds.setKeyframe('mouth_ctrl.tz', t=60, v=1.0)
    cmds.setKeyframe('mouth_ctrl.tz', t=70, v=-1.0)
    cmds.setKeyframe('mouth_ctrl.tz', t=80, v=-1.0)

    cmds.playbackOptions(e=True, minTime=1, maxTime=80)



def _mirror():
    sCtrls = []
    for sKey in kAllPoseKeys:
        sCtrls += utils.data.get('%sCtrlKey' % sKey) or []
    for sC in sCtrls:
        sSide = utils.getSide(sC)
        if sSide == 'l':
            sOther = utils.getMirrorName(sC)
            for sA in ['tx','ty','tz','rx','ry','rz']:
                sAttr = '%s.%s' % (sOther,sA)
                if cmds.getAttr(sAttr, settable=True):
                    cmds.setAttr(sAttr, cmds.getAttr('%s.%s' % (sC,sA)))
dSetPosesMenu['mirror ctrls'] = _mirror


def _resetDriversAndCtrls(ddPoses):
    for sKey in kAllPoseKeys:
        sDriver = ddPoses[sKey]['sDriverAttr']
        cmds.setAttr(sDriver, 0)

    sCtrls = []
    for sKey in kAllPoseKeys:
        sCtrls += utils.data.get('%sCtrlKey' % sKey) or []
    for sC in sCtrls:
        sBothCtrls = [sC]
        sOtherCtrl = utils.getMirrorName(sC)
        if sOtherCtrl != sC:
            sBothCtrls.append(sOtherCtrl)
        for sCC in sBothCtrls:
            for sA in ['tx','ty','tz','rx','ry','rz']:
                sAttr = '%s.%s' % (sCC,sA)
                if cmds.getAttr(sAttr, settable=True):
                    cmds.setAttr(sAttr, 0)
dSetPosesMenu['reset all drivers and ctrls'] = _resetDriversAndCtrls


dSetPosesMenu['ROM animation'] = createPosesRom

dButtons['=== POSES ==='] = dSetPosesMenu


dButtons['=== MOUTH SLIDE ==='] = dFrontSlideMenu



# m_mouthPasser_Grp -> grp_m_mouthPasser
def translateAttrToStandard(sAttr):
    sSplits = sAttr.split('.')
    sObj = sSplits[0]
    if not cmds.objExists(sObj):
        sSplitsB = sObj.split('_')
        if len(sSplitsB) >= 3:
            sSplitsB = [sSplitsB[-1].lower()] + sSplitsB[0:-1]
        sObj = '_'.join(sSplitsB)
        sSplits[0] = sObj
        sNewAttr = '.'.join(sSplits)
        if cmds.objExists(sNewAttr):
            return sNewAttr
    return sAttr


# grp_m_mouthPasser -> m_mouthPasser_Grp
def translateAttrToTypeEnd(sAttr):
    sSplits = sAttr.split('.')
    sObj = sSplits[0]
    if not cmds.objExists(sObj):
        sSplitsB = sObj.split('_')
        if len(sSplitsB) >= 3:
            sSplitsB = sSplitsB[1:] + [utils.getFirstLetterUpperCase(sSplitsB[0])]
        sObj = '_'.join(sSplitsB)
        sSplits[0] = sObj
        sNewAttr = '.'.join(sSplits)
        # if cmds.objExists(sNewAttr):
        return sNewAttr
    return sAttr





def getDefaultAttrsMenu(sKey='sDefaultSettingAttrs', sArgName='dDefaultSettingValues'):
    dDefaultAttrsMenu = OrderedDict()
    
    def _getDefaultAttrsAndTranslated(sKey):
        sAttrs = utils.data.get(sKey)
        dTranslatedAttrs = {}
        for sAttr in sAttrs:
            dTranslatedAttrs[sAttr] = translateAttrToTypeEnd(sAttr)
        return sAttrs, dTranslatedAttrs
    
    
    def infoSettingAttrs(_sKey=sKey):
        sAttrs, dTranslatedAttrs = _getDefaultAttrsAndTranslated(_sKey)
        cmds.confirmDialog(t='attributes to save', m='\n'.join(sAttrs))
    dDefaultAttrsMenu['Info'] = infoSettingAttrs
    
    
    def selectSettingAttrs(_sKey=sKey):
        sAttrs, dTranslatedAttrs = _getDefaultAttrsAndTranslated(_sKey)
    
        sObjs = list(set([sA.split('.')[0] for sA in sAttrs]))
        cmds.select(sObjs)
    
    dDefaultAttrsMenu['Select'] = selectSettingAttrs
    
    
    def _mirror(_sKey=sKey):
        sAttrs, dTranslatedAttrs = _getDefaultAttrsAndTranslated(_sKey)
    
        dValues = {sA:cmds.getAttr(dTranslatedAttrs[sA]) for sA in sAttrs}
        for sAttr in dValues.keys():
            if utils.getSide(sAttr) == 'r':
                sMirrorAttr = utils.getMirrorName(sAttr)
                if cmds.objExists(sMirrorAttr):
                    print ('mirroring %s to %s' % (sMirrorAttr, sAttr))
                    cmds.setAttr(sAttr, cmds.getAttr(sMirrorAttr))
    dDefaultAttrsMenu['Mirror'] = _mirror
    
    
    def clearDefaultAttrsFlag(_uiArgs=None):
        _uiArgs['dDefaultSettingValues'].setText('{}')
    dDefaultAttrsMenu['Clear'] = clearDefaultAttrsFlag
    
    
    def _fill(_sKey=sKey, _uiArgs=None):
        sAttrs, dTranslatedAttrs = _getDefaultAttrsAndTranslated(_sKey)
        dValues = {sA:cmds.getAttr(dTranslatedAttrs[sA]) for sA in sAttrs}
        _uiArgs[sArgName].setText(str(dValues))
    dDefaultAttrsMenu['Fill all values'] = _fill

    return dDefaultAttrsMenu



def createStaticSlideCurves():
    sSelect = []
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    for sCurve in sCurves:
        if not cmds.objExists(sCurve):
            cmds.confirmDialog(m='For creating this blueprint, you need to run the function first')
        else:
            sNewCurve = utils.replaceStringStart(sCurve, 'curve_', 'bpCurve_')
            sSelect.append(sNewCurve)
            if cmds.objExists(sNewCurve):
                if cmds.confirmDialog(m='Curve "%s" already exists. Recreate?' % sNewCurve, button=['yes', 'no']) == 'no':
                    continue
                else:
                    cmds.delete(sNewCurve)
            cmds.duplicate(sCurve, n=sNewCurve)
            cmds.parent(sNewCurve, kMouthBpGroupName)
    if sSelect:
        cmds.select(sSelect)


def selectStaticSlideCurveBps():
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    sSel = []
    for sCurve in sCurves:
        sNewCurve = utils.replaceStringStart(sCurve, 'curve_', 'bpCurve_')
        if cmds.objExists(sNewCurve):
            sSel.append(sNewCurve)
    if sSel:
        cmds.select(sSel)

def selectRiggedOnes():
    sCurves = ['curve_l_mouthStaticSlide', 'curve_l_mouthStaticSlideUp']
    cmds.select(sCurves)


dButtons['=== Static Blueprint Curves (Optional) ==='] = {'Create Blueprints': createStaticSlideCurves, 'Select Blueprints':selectStaticSlideCurveBps, 'Select Rigged':selectRiggedOnes}


dButtons['=== DEFAULT ATTRS ==='] = getDefaultAttrsMenu()

dSquashStretchMenu = {}
def bakeSquashStretchShapes(ddSquashStretchSettings, _uiArgs=None):

    sModel = cmds.ls(sl=True)[0]

    sNew = []
    for sKey, sValueKey in [('sShrinkTarget', 'fShrinkCornerValue'),
                            ('sExpandTarget', 'fExpandCornerValue')]:
        sTarget = ddSquashStretchSettings[sKey]
        if cmds.objExists(sTarget):
            cmds.delete(sTarget)
        fValue = ddSquashStretchSettings[sValueKey]
        cmds.setAttr('lipsCornerLFT_ctrl.tx', fValue)
        cmds.setAttr('lipsCornerRGT_ctrl.tx', fValue)

        cmds.duplicate(sModel, n=sTarget)
        utils.parentToWorld(sTarget)
        sNew.append(sTarget)

    cmds.setAttr('lipsCornerLFT_ctrl.tx', 0)
    cmds.setAttr('lipsCornerRGT_ctrl.tx', 0)
    cmds.select(sNew)
dSquashStretchMenu['Bake Shapes'] = bakeSquashStretchShapes


dButtons['=== SQUASH STRETCH ==='] = dSquashStretchMenu


dButtons['- Export Mouth BPs -'] = lambda: exportBps(kMouthBpFileName, kMouthBpGroupName)
dButtons['- Export *Slider* BPs -'] = ctrls5.exportSliderBps


# curve_m_botMouth gets rotation on pucker!!!!


QtWidgets, QtGui, QtCore = utils.importQtModules()

class QMouthPaintUI(QtWidgets.QDialog):

    def __init__(self):
        super(QMouthPaintUI, self).__init__(None, QtCore.Qt.WindowStaysOnTopHint)

        import kangarooTools.utilsQt as utilsQt
        utils.reload2(utilsQt)

        layout = QtWidgets.QBoxLayout(QtWidgets.QBoxLayout.TopToBottom, self)
        
        qJointLoopsLayout = utilsQt.createGroupBoxLayout(layout, 'Joint Loops')
        self.qRowBlend = utilsQt.createFloatSlider(qJointLoopsLayout, 'Blend', 0.0, 1.0, 1.0)
        self.qRigidLoops = self._addField(qJointLoopsLayout, 'rigid loops', '2')
        self.qFadeLoops = self._addField(qJointLoopsLayout, 'fade loops', '2')
        self.qTopPerc = self._addField(qJointLoopsLayout, 'top perc', '1.0')
        self.qCornerPerc = self._addField(qJointLoopsLayout, 'corner perc', '1.0')
        self.qBotPerc = self._addField(qJointLoopsLayout, 'bot perc', '1.0')
        
        qAddToRowsLayout = QtWidgets.QHBoxLayout()
        qJointLoopsLayout.addLayout( qAddToRowsLayout)
        qAddToBigJoints = QtWidgets.QPushButton('Add to BigJoints')
        qAddToBigJoints.clicked.connect(lambda: self.addToRowJoints(bBig=True))
        qJointLoopsLayout.addWidget(qAddToBigJoints)
        qAddToRowsLayout.addWidget(qAddToBigJoints)
        qAddToSmallJoints = QtWidgets.QPushButton('Add to SmallJoints')
        qAddToSmallJoints.clicked.connect(lambda: self.addToRowJoints(bBig=False))
        qAddToRowsLayout.addWidget(qAddToSmallJoints)


        qMoveLayout = utilsQt.createGroupBoxLayout(layout, 'Move Weights')

        # self.qMoveStrength = self._addField(qMoveLayout, 'Move Strength', '1.0')
        self.qMoveStrength = utilsQt.createFloatSlider(qMoveLayout, 'Move Strength', 0.0, 1.0, 1.0)
        for sButton, func in [('move big/small back to head/jaw', self.backToHeadJaw),
                              ('move lipsEnd back to jaw/head', lambda: self.moveWeights({'jnt_l_lipsEnd':'jnt_m_headMain;jnt_m_jawMain', 'jnt_r_lipsEnd':'jnt_m_headMain;jnt_m_jawMain'})),
                              ('move small to big joints', lambda: self.moveWeights({'*MouthSplineSmall*': 'Small,Big'})),
                              ('move big to small joints', lambda: self.moveWeights({'*MouthSplineBig*': 'Big,Small'})),
                              ('move head/jaw to lipEnds', self.headJawToLipsEnd),
                              ('move to cheeks', lambda: self.moveWeights({"['jnt_m_headMain', 'jnt_m_jawMain', 'jnt_l_lipsEnd']": 'jnt_l_cheek_???'})),
                              ('move big to small joints', lambda: self.moveWeights({'*MouthSplineBig*': 'Big,Small'})),
                              ('move head to jaw', lambda: self.moveWeights({'jnt_m_headMain':'jnt_m_jawMain'})),
                              ('move jaw to head', lambda: self.moveWeights({'jnt_m_jawMain':'jnt_m_headMain'})),
                              ]:
            qButton = QtWidgets.QPushButton(sButton)
            qButton.clicked.connect(func)
            qMoveLayout.addWidget(qButton)
            
        layout.addStretch()


    def getRowBlend(self):
        return max(0, min(1, eval(self.qRowBlend.text())))


    def getMoveStrength(self):
        return max(0, min(1, eval(self.qMoveStrength.text())))


    def backToHeadJaw(self):
        sTopJoints = cmds.ls('jnt_?_topMouthSpline*_???', et='joint')
        sBotJoints = cmds.ls('jnt_?_botMouthSpline*_???', et='joint')
        dJoints = {sJ: 'jnt_m_headMain' for sJ in sTopJoints}
        dJoints.update({sJ: 'jnt_m_jawMain' for sJ in sBotJoints})
        weights.moveSkinClusterWeights(xJoints=dJoints, fStrength=eval(self.qMoveStrength.text()))
        

    def moveWeights(self, dDict):
        weights.moveSkinClusterWeights(None, dDict, fStrength=self.getMoveStrength())
        

    def addToRowJoints(self, bBig=False):
        try:
            proceduralBind_mouthSplineJoints(eval(self.qRigidLoops.text()), eval(self.qFadeLoops.text()),
                                             eval(self.qBotPerc.text()), eval(self.qCornerPerc.text()), eval(self.qTopPerc.text()),
                                             fBlend=self.getRowBlend(), sSuffix='MouthSplineBig' if bBig else 'MouthSplineSmall')
        except Exception as e:
            cmds.confirmDialog(m=str(e))
            raise


    def _addField(self, layout, sName, sDefaultValue):
        qNewLayout = QtWidgets.QHBoxLayout()
        qLabel = QtWidgets.QLabel(sName)
        qNewLayout.addWidget(qLabel)
        
        qLineEdit = QtWidgets.QLineEdit(sDefaultValue)
        qNewLayout.addWidget(qLineEdit)
        layout.addLayout(qNewLayout)
        return qLineEdit


    def headJawToLipsEnd(self):
        dJoints = {'jnt_m_headMain': 'jnt_l_lipsEnd',
                   'jnt_m_jawMain': 'jnt_l_lipsEnd'}
        utils.reload2(deformers)
        weights.moveSkinClusterWeights(xJoints=dJoints, fStrength=eval(self.qMoveStrength.text()),
                                       iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)




qMouthPaintUI = None
def openMouthPaintUI(ddBindSettings):
    global qMouthPaintUI
    qMouthPaintUI = QMouthPaintUI()
    qMouthPaintUI.show()


dButtons['**** Mouth Paint UI ****'] = openMouthPaintUI


@builderTools.addToBuild(iOrder=62.2, dButtons=dButtons)
def createBASEMouthCtrls(bSPLINES=False, bCorners=True, bBorders=True, bLimitOnNonSplineMode=True, bFrontBoxCtrls=True, bFlipInnerMouthBpCurves=False,
                        fLeftLipParamPercs=[0.33],
                        bPolyCtrls=False, xMirrorAxis=None, sParentJoint='jnt_m_headMain', sJawJoint='jnt_m_jawMain',
                        ddBindSettings={'iBindRowsBig':{'iRigidRows':8, 'iSmoothRows':8}, 'iBindRowsSmall':{'iRigidRows':4, 'iSmoothRows':4}, 'dMultipls':{'fBot':1.0, 'fSide':1.0, 'fTop':1.0}},
                        ddRollValues=dDefaultRollValues, dDefaultSettingValues={}, bStaticSlideCurveMirror=True,
                        ddSquashStretchSettings={'bScaleJoints':True, 'fShrinkCornerValue':-1, 'fExpandCornerValue':1.0, 'sShrinkTarget':'mouthSquash', 'sExpandTarget':'mouthStretch'},
                        ddPoses={'cornerOut':{'sDriverAttr':'lipsCornerLFT_ctrl.tx', 'fDriverValue':1.0, 'dPose':{}},
                                 'jawOpen':{'sDriverAttr':'jaw_ctrl.rz', 'fDriverValue':-25.0, 'dPose':{}},
                                 'funnel':{'sDriverAttr':'mouth_ctrl.tz', 'fDriverValue':1.0, 'dPose':{}},
                                 'mouthClose':{'sDriverAttr':'mouth_ctrl.mouthClose', 'fDriverValue':1.0, 'dPose':{}, 'fJawOpenValue':-10},
                                 'lipPress': {'sDriverAttr': 'mouth_ctrl.tz', 'fDriverValue': -1.0, 'dPose': {}}},
                         sSuffix=''):
    '''
    1. Create the inner and outer curves (check the locators)
    2. MOST IMPORTANT: set bFlipInnerMouthCurves accordingly!!
    3. for bSplines, create the Corner Sliding Planes

    :param fLeftLipParamPercs
    Changes lip control position or add more controls. By default it's None, which is similar to [0.33].
    To add a middle control: [0.33, 0.5]
    To have 2 extra controls: [0.15, 0.3, 0.5]

    :param fLeftPuckerStrenth:
    Changes behavior of lipCornerLFT_ctrl going forward (inside)
    Example: [0.15, 0.3, 0.5]
    
    if lipsCornerLFT_ctrl moving negative causes joints to behave unstable, create the Puckerslide Blueprint
    '''

    sDefaultSettingAttrs = []
    utils.data.store('bMouthSplines%s' % sSuffix, bSPLINES)

    # xMirrorAxis = sMirrorJointAxes[suf] if suf < len(sMirrorJointAxes) else None
    fLipCtrlScale = 1.0
    sInputCurveInner = 'bpCurve_m_lipsInner%s' % sSuffix
    sInputCurveOuter = 'bpCurve_m_lipsOuter%s' % sSuffix

    sBpCurvesA = ['bpCurve_m_%sLipInner%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]
    sBpCurvesB = ['bpCurve_m_%sLipOuter%s' % (sPart, sSuffix) for sPart in ['bot', 'top']]

    utils.data.store('sBpCurvesA%s' % sSuffix, sBpCurvesA)
    utils.data.store('sBpCurvesB%s' % sSuffix, sBpCurvesB)

    # aHeadMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')
    if cmds.objExists('bp_m_mouthSlide'):
        aMouthSlideMatrix = utils.getNumpyMatrixFromTransform('bp_m_mouthSlide')
    else:
        aMouthSlideMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')

    aMouthRotationSlideMatrix = aMouthSlideMatrix[0:3,0:3]
        

    if bFlipInnerMouthBpCurves:  # when mouth is so closed, that he'll think the top lip is the bottom lip...
        curves.separateCurveUsingSeparationLocs(sInputCurveInner, 'locA_m_lipsInner%s' % sSuffix,
                                                'locB_m_lipsInner%s' % sSuffix, sBpCurvesA[1], sBpCurvesA[0])
    else:
        curves.separateCurveUsingSeparationLocs(sInputCurveInner, 'locA_m_lipsInner%s' % sSuffix,
                                                'locB_m_lipsInner%s' % sSuffix, sBpCurvesA[0], sBpCurvesA[1])

    curves.separateCurveUsingSeparationLocs(sInputCurveOuter, 'locA_m_lipsOuter%s' % sSuffix,
                                            'locB_m_lipsOuter%s' % sSuffix, sBpCurvesB[0], sBpCurvesB[1])

    utils.data.store('bLipCurves%s' % sSuffix, True)
    fMouthCurveEndsDistance = barycentric.distanceBetween('%s.cv[0]' % sBpCurvesA[0], '%s.cv[%d]' % (sBpCurvesA[0], len(cmds.ls('%s.cv[*]' % sBpCurvesA[0], flatten=True))-1))
    utils.data.store('fMouthCurveEndsDistance%s' % sSuffix, fMouthCurveEndsDistance)
    fMouthSliderScale = fMouthCurveEndsDistance * 0.25

    aBotMiddle = curves.getPointsFromPercs(sBpCurvesA[0], [0.5], bReturnNumpy=True)[0]
    aTopMiddle = curves.getPointsFromPercs(sBpCurvesA[1], [0.5], bReturnNumpy=True)[0]
    aMouthCtrlFront = (aTopMiddle + aBotMiddle) * 0.5 + np.array([0,0,fMouthSliderScale*0.5], dtype='float64')

    sMouthTransformOrigin = cmds.createNode('transform', n='sMouthTransformOrigin', p=getFaceGrp())

    cmds.setAttr('%s.t' % sMouthTransformOrigin, *list(aMouthCtrlFront))
    sMouthGrpJoints = cmds.createNode('transform', n='grp_m_mouthJoints',
                                      p=sMouthTransformOrigin)  # an origin group, because below are nodes getting curveInfo datas
    cmds.move(0, 0, 0, sMouthGrpJoints, ws=True, a=True)

    iMidInd = 1
    aCtrlPercs = np.array([0.0, 0.5, 1.0], dtype='float64')

    # else:
    #     iMidInd = 3
    #     aCtrlPercs = np.array([0.0, 0.1667, 0.3334, 0.5, 0.6667, 0.833334, 1.0], dtype='float64')

    sCtrlBpCurves = sBpCurvesA if bSPLINES else sBpCurvesB


    ffCtrlPoints = []
    ffCtrlPoints.append(curves.getPointsFromPercs(sCtrlBpCurves[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPoints.append(curves.getPointsFromPercs(sCtrlBpCurves[1], aCtrlPercs, bReturnNumpy=True))

    ffCtrlPointsB = []
    # not finding bpCurve_m_botLipOuter
    ffCtrlPointsB.append(curves.getPointsFromPercs(sBpCurvesB[0], aCtrlPercs, bReturnNumpy=True))
    ffCtrlPointsB.append(curves.getPointsFromPercs(sBpCurvesB[1], aCtrlPercs, bReturnNumpy=True))

    aMouthCtrlsOffset = np.array([0,0,0]) if bSPLINES else np.array([0, 0, fMouthCurveEndsDistance * 0.1], dtype='float64')

    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sTargets = set(utils.data.get('sBakedBlendshapeTargets%s' % sSuffix, xDefault=[]))

    aCornerTangent = curves.getTangentsFromPercs(sBpCurvesA[0], [0.0], bReturnNumpy=True)[0]

    if bCorners:
        cCorners = ctrls5.createSliderCtrl('lipsCorner%s' % sSuffix, 'l', fBpPos=ffCtrlPoints[0][0] + aMouthCtrlsOffset,
                                           fRangeX=[-1.0, 1.0], fRangeY=[-1.0, 1.0], fRangeZ=[0,0],
                                           sShape='cube', sAttach=None if bSPLINES else sModel, bBorder=bBorders,
                                           bPoly=bPolyCtrls, fScale=fMouthSliderScale,
                                           xMirrorAxis=xMirrorAxis, sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                            dAlignVectors = {'sAim': aMouthRotationSlideMatrix[0],
                                                             'sUp': -aCornerTangent,
                                                             'fAimVector': [0, 1, 0], 'fUpVector': [1, 0, 0]})
        
        if bSPLINES:
            utils.addAttr(cCorners[0].sCtrl, ln='botScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[0].sCtrl, ln='botScaleZ', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='botScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='botScaleZ', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[0].sCtrl, ln='topScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[0].sCtrl, ln='topScaleZ', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='topScaleY', min=0.1, dv=1.0, k=True)
            utils.addAttr(cCorners[1].sCtrl, ln='topScaleZ', min=0.1, dv=1.0, k=True)

        cCorners[0].fPerc = 0
        cCorners[1].fPerc = 1


        if bSPLINES:
            for s,sSide in enumerate(['l','r']):
                cmds.xform('sliderBp_%s_lipsCorner' % sSide, t=ffCtrlPoints[0][0 if s == 0 else -1], ws=True)

    else:
        if bSPLINES:
            raise Exception('bCorners needs to be On if bSPLINES is on')
        cCorners = []

    # bot top ctrls
    if bFrontBoxCtrls:
        cBot = ctrls5.createSliderCtrl('mouthBot%s' % sSuffix, 'm', sShape='cube', fBpPos=ffCtrlPointsB[0][iMidInd] + aMouthCtrlsOffset,
                                bBorder=False, fScaleShape=[1, 0.1, 0.1], fRangeX=[-1, 1], fRangeY=[-1, 1], fRangeZ=[-1, 1],
                                sAttach=None if bSPLINES else sModel,
                                sAddAttrs=['rx', 'ry', 'rz'] if bSPLINES else [])[0]
        cmds.setAttr('%s.s' % cBot.sSlider, fMouthSliderScale, fMouthSliderScale, fMouthSliderScale)
        cTop = ctrls5.createSliderCtrl('mouthTop%s' % sSuffix, 'm', sShape='cube', fBpPos=ffCtrlPointsB[1][iMidInd] + aMouthCtrlsOffset,
                                bBorder=False, fScaleShape=[1, 0.1, 0.1], fRangeX=[-1, 1], fRangeY=[-1, 1], fRangeZ=[-1, 1],
                                sAttach=None if bSPLINES else sModel,
                                sAddAttrs=['rx', 'ry', 'rz'] if bSPLINES else [])[0]
        cmds.setAttr('%s.s' % cTop.sSlider, fMouthSliderScale, fMouthSliderScale, fMouthSliderScale)
        cBot.fPerc = 0.5
        cTop.fPerc = 0.5
        cBotTops = [cBot, cTop]

        # if bSPLINES:
        #     for p,sPart in enumerate(['bot','top']):
        #         nodes.createMultiplyNode('%s.tz' % cBotTops[p].sCtrl, -1, sTarget='%s.tz' % cBotTops[p].sOut)

    else:
        cBotTops = []

    sLowerDown = 'lowerDown%s' % sSuffix
    sLowerUp = 'lowerUp%s' % sSuffix
    sUpperDown = 'upperDown%s' % sSuffix
    sUpperUp = 'upperUp%s' % sSuffix

    if bSPLINES:
        fLowerRangeY = [-1,1]
        fLowerRangeX = [-1,1]
        fLowerRangeZ = [-1,1]
        fUpperRangeY = [-1,1]
        fUpperRangeX = [-1,1]
        fUpperRangeZ = [-1,1]
    else:
        if sLowerDown in sTargets or sLowerUp in sTargets:
            fLowerRangeY = [-1.0 if sLowerDown in sTargets else 0.0, 1.0 if sLowerUp in sTargets else 0.0]
        else:
            fLowerRangeY = [-1,0] # just to have a default
        fLowerRangeX = [0,0]
        fLowerRangeZ = [0,0]
        if sUpperDown in sTargets or sUpperUp in sTargets:
            fUpperRangeY = [-1.0 if sUpperDown in sTargets else 0.0, 1.0 if sUpperUp in sTargets else 0.0]
        else:
            fUpperRangeY = [0,1] # just to have a default
        fUpperRangeX = [0,0]
        fUpperRangeZ = [0,0]


    utils.reload2(ctrls5)
    if fLeftLipParamPercs != None:
        fLeftLipParamPercs.sort()
        if fLeftLipParamPercs[-1] > 0.5:
            raise Exception('fLeftLipParamPercs values can only go from 0 to 0.5')

        aParams = np.array(fLeftLipParamPercs) * curves.getParamLength(sCtrlBpCurves[0]) # we have to do params, because it will be calculated faster for each mesh point later
        aPercs = curves.getPercsFromParams(sBpCurvesA[0], aParams)
        aLeftLowerPoints = curves.getPointsFromPercs(sBpCurvesB[0], aPercs, bReturnNumpy=True)
        aLeftLowerTangents = curves.getTangentsFromPercs(sBpCurvesB[0], aPercs, bReturnNumpy=True)

        cBotLips = [None] * (len(fLeftLipParamPercs) * 2)
        if fLeftLipParamPercs[-1] == 0.5:
            cBotLips = cBotLips[:-1]


        for i, aPoint in enumerate(aLeftLowerPoints):
            sS = 'm' if fLeftLipParamPercs[i] == 0.5 else 'l'
            if fLeftLipParamPercs[i] == 0.5:
                sI = ''
            elif len(fLeftLipParamPercs) <= 2:
                sI = ''
            else:
                sI = '%d' % i
            _cCtrls = ctrls5.createSliderCtrl('lipsBot%s%s' % (sI, sSuffix), sSide=sS, fBpPos=aPoint + aMouthCtrlsOffset, bRedoTranslation=True,
                                              sAttach=None if bSPLINES else sModel, fRangeY=fLowerRangeY, fRangeX=fLowerRangeX, fRangeZ=fLowerRangeZ, bPoly=bPolyCtrls,
                                              fScale=fMouthSliderScale,
                                              dAlignVectors={'sAim':-aMouthRotationSlideMatrix[2] if sS == 'm' else -aLeftLowerTangents[i],
                                                             'sUp':aMouthRotationSlideMatrix[0],
                                                             'fAimVector':[1,0,0], 'fUpVector':[0,1,0]},
                                              xMirrorAxis=xMirrorAxis, bBorder=bBorders, sAddAttrs=['rx','ry','rz', 'sx','sy','sz'] if bSPLINES else [])
            _cCtrls[0].fPerc = fLeftLipParamPercs[i]
            if sS == 'l':
                _cCtrls[1].fPerc = 1.0 - fLeftLipParamPercs[i]
            cBotLips[i] = _cCtrls[0]
            if sS == 'l':
                cBotLips[-(i + 1)] = _cCtrls[1]

        if fLeftLipParamPercs[-1] == 0.5:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-2::-1]]
        else:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-1::-1]]
        dSplitAlongCurve = {'ssAttrs': [['%s.ty' % cC.sCtrl for cC in cBotLips]],
                            'ffValues': [[-1.0] * len(cBotLips)],
                            'fParams': fPassParams,
                            'sCurve': sBpCurvesA[0]}
        utils.data.store('dLipSplitAlongCurve%s' % sSuffix, dSplitAlongCurve)


        # top
        aLeftUpperPoints = curves.getPointsFromPercs(sBpCurvesB[1], aPercs, bReturnNumpy=True)
        aLeftUpperTangents = curves.getTangentsFromPercs(sBpCurvesB[1], aPercs, bReturnNumpy=True)

        cTopLips = [None] * (len(fLeftLipParamPercs)*2)
        if fLeftLipParamPercs[-1] == 0.5:
            del cTopLips[-1]

        for i, aPoint in enumerate(aLeftUpperPoints):
            sS = 'm' if fLeftLipParamPercs[i] == 0.5 else 'l'
            if fLeftLipParamPercs[i] == 0.5:
                sI = ''
            elif len(fLeftLipParamPercs) <= 2:
                sI = ''
            else:
                sI = '%d' % i
            _cCtrls = ctrls5.createSliderCtrl('lipsTop%s%s' % (sI, sSuffix), sSide=sS, fBpPos=aPoint+aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel, bRedoTranslation=True,
                                              fRangeX=fUpperRangeX, fRangeY=fUpperRangeY, fRangeZ=fUpperRangeZ, bPoly=bPolyCtrls,
                                              fScale=fMouthSliderScale,
                                              dAlignVectors={'sAim':-aMouthRotationSlideMatrix[2] if sS == 'm' else -aLeftUpperTangents[i],
                                                             'sUp':aMouthRotationSlideMatrix[0],
                                                             'fAimVector':[1,0,0], 'fUpVector':[0,1,0]},
                                              xMirrorAxis=xMirrorAxis,
                                              sAddAttrs=['rx','ry','rz','sy','sz'] if bSPLINES else [],
                                              bBorder=bBorders)
            # cmds.transformLimits(_cCtrls[0].sCtrl, sy=(0.1,5), esy=(True, True))
            # cmds.transformLimits(_cCtrls[0].sCtrl, sz=(0.1,5), esz=(True, True))
            # cmds.transformLimits(_cCtrls[1].sCtrl, sy=(0.1,5), esy=(True, True))
            # cmds.transformLimits(_cCtrls[1].sCtrl, sz=(0.1,5), esz=(True, True))

            _cCtrls[0].fPerc = fLeftLipParamPercs[i]
            if sS == 'l':
                _cCtrls[1].fPerc = 1.0 - fLeftLipParamPercs[i]
            cTopLips[i] = _cCtrls[0]
            if sS == 'l':
                cTopLips[-(i+1)] = _cCtrls[1]

        if fLeftLipParamPercs[-1] == 0.5:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-2::-1]]
        else:
            fPassParams = fLeftLipParamPercs + [1.0 - a for a in fLeftLipParamPercs[-1::-1]]

        dSplitAlongCurve = {'ssAttrs':[['%s.ty' % cC.sCtrl for cC in cTopLips]],
                         'ffValues':[[1.0] * len(cTopLips)],
                         'fParams':fPassParams,
                         'sCurve':sBpCurvesA[1]}
        utils.data.store('dUpperSplitAlongCurve%s' % sSuffix, dSplitAlongCurve)


    else: # we should be able to get rid of this
        # lower simple left/right
        aLeftLowerPoint = curves.getPointsFromPercs(sCtrlBpCurves[0], [0.33], bReturnNumpy=True)[0]
        aLeftLowerTangent = curves.getTangentsFromPercs(sCtrlBpCurves[0], [0.33], bReturnNumpy=True)[0]

        cBotLips = ctrls5.createSliderCtrl('lipsBot%s' % sSuffix, sSide='l',
                                           fBpPos=aLeftLowerPoint + aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel,
                                           fRangeX=fLowerRangeX, fRangeY=fLowerRangeY, fRangeZ=fLowerRangeZ, bPoly=bPolyCtrls,
                                           fScale=fMouthSliderScale, sAlignOnModel=[sModel, sLowerUp, sLowerDown],
                                           xMirrorAxis=xMirrorAxis,
                                           sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                           bBorder=bBorders,
                                           dAlignVectors={'sAim': -aLeftLowerTangent, 'sUp': aMouthRotationSlideMatrix[0], 'fAimVector': [1, 0, 0], 'fUpVector': [0, 1, 0]},
                                           )
        cBotLips[0].fPerc = 0.333
        cBotLips[1].fPerc = 0.667
        utils.data.store('sLipBotCtrls', [cBotLips[0].sCtrl, cBotLips[1].sCtrl])


        # upper simple left/right
        aLeftUpperPoint = curves.getPointsFromPercs(sCtrlBpCurves[1], [0.333], bReturnNumpy=True)[0]

        cTopLips = ctrls5.createSliderCtrl('lipsTop%s' % sSuffix, sSide='l', fBpPos=aLeftUpperPoint+aMouthCtrlsOffset, sAttach=None if bSPLINES else sModel,
                                            fRangeX=fUpperRangeX, fRangeY=fUpperRangeY, fRangeZ=fUpperRangeZ, bPoly=bPolyCtrls,
                                            fScale=fMouthSliderScale, sAlignOnModel=[sModel, sLowerUp, sLowerDown], xMirrorAxis=xMirrorAxis,
                                            sAddAttrs=['rx','ry','rz'] if bSPLINES else [],
                                            dAlignVectors={'sAim': -aLeftLowerTangent, 'sUp': aMouthRotationSlideMatrix[0], 'fAimVector': [1, 0, 0], 'fUpVector': [0, 1, 0]},
                                           bBorder=bBorders)
        cTopLips[0].fPerc = 0.333
        cTopLips[1].fPerc = 0.667
        utils.data.store('sLipTopCtrls', [cTopLips[0].sCtrl, cTopLips[1].sCtrl])

    ccLipCtrls = [cBotLips, cTopLips]


    sOrientGuide = xforms.createTransform('lipsOrientGuide', sMatch='jnt_m_headMain')
    if cmds.objExists('bp_m_mouthSlide'):
        cmds.delete(cmds.orientConstraint('bp_m_mouthSlide', sOrientGuide))
    cmds.rotate(90, 90, 0, sOrientGuide, os=True, r=True)
    
    
    # cMouthTransform
    cMouth = ctrls5.createSliderCtrl('mouth%s' % sSuffix, 'm', sShape='locator', sMatch=sOrientGuide, fBpPos=aMouthCtrlFront,
                                  bBorder=False, fScaleShape=[1,1,1], fRangeX=[-1,1], fRangeY=[-1,1], fRangeZ=[-1,1],
                                  sAttach=sParentJoint if bSPLINES else sModel, fScale=fMouthSliderScale, sAddAttrs=['r', 'scaleUF'] if bSPLINES else [])[0]
    sMouthScale = '%s.scaleUF' % cMouth.sCtrl

    sGlobalMouthScale = '%s.outputScaleX' % nodes.createDecomposeMatrix('%s.worldMatrix' % cMouth.sOut).split('.')[0]

    sGlobalMouthScale = nodes.createMultiplyNode(sGlobalMouthScale, cmds.getAttr(sGlobalMouthScale), sOperation='divide')
    cMouth.fPerc = 0.5
    cAllCtrls = ccLipCtrls[0] + ccLipCtrls[1] + cCorners + cBotTops + [cMouth]
    if bCorners:
        ccRows = [[cCorners[0]] + ccLipCtrls[0] + [cCorners[1]],
                  [cCorners[0]] + ccLipCtrls[1] + [cCorners[1]]]
    else:
        ccRows = ccLipCtrls

    for cC in ccLipCtrls[0][::-1] + ccLipCtrls[1][::-1] + cCorners[::-1]:
        cmds.controller(cC.sCtrl, cMouth.sCtrl, parent=True)


    if bSPLINES or not bLimitOnNonSplineMode:
        for cC in cAllCtrls:
            cmds.transformLimits(cC.sCtrl, etx=[False, False], ety=[False, False], etz=[False, False])
            ctrls5.disconnectFromSliderBp(cC)

        # need to set cMouth back because it's used for funnel and lipPress
        cmds.transformLimits(cMouth.sCtrl, etz=[True, True])


    bMouthSplinesExecuted = False

    # EXCLUDE START MOUTHSPLINES

    if bSPLINES:
        bMouthSplinesExecuted = True

        sGrp = cmds.createNode('transform', n='grp_mouthSplines', p='modules')

        fCurveLengthes = [curves.getLength(sBpCurvesA[0]), curves.getLength(sBpCurvesA[1])]

        sParentGrp = cmds.createNode('transform', n='grp_mouthSplinesParentJoint', p=sGrp)
        xforms.matrixParentConstraint(sParentJoint, sParentGrp)


        # slide pivots
        sSlideBp = 'bp_m_mouthSlide'
        sSlidePivot = xforms.createLocator('loc_m_slidePivot', sParent=sParentGrp, sMatch=sSlideBp, fSize=fCurveLengthes[0]*0.035)
        xforms.insertParent(sSlidePivot, 'grp_m_slidePivotParent')

        sSlidePivotFront = 'jnt_m_slidePivotFrontHead'
        if cmds.objExists(sSlidePivotFront):
            cmds.parent(sSlidePivotFront, sParentJoint)
            cmds.delete(cmds.parentConstraint(cMouth.sCtrl, sSlidePivotFront))
        else:
            xforms.createJoint(sSlidePivotFront, sParent=sParentJoint, sMatch=cMouth.sCtrl)
        cmds.setAttr('%s.segmentScaleCompensate' % sSlidePivotFront, False)


        sGrpSlidePivotFront = xforms.createTransform('grp_m_slidePivotFront', sParent=sParentGrp, sMatch=cMouth.sCtrl)#, fSize=fCurveLengthes[0]*0.05) # it was a joint before... why?
        sAnimMatrix = nodes.createComposeMatrixNode(xRotate='%s.r' % cMouth.sCtrl, xScale='%s.s' % cMouth.sCtrl)
        fSlidePivotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sSlidePivotFront, '%s.worldInverseMatrix' % sSlidePivot], bJustValues=True)
        sFrontMatrix = nodes.createMultMatrixNode([sAnimMatrix,
                                                   fSlidePivotOffset,
                                                   '%s.worldMatrix' % sSlidePivot,
                                                   '%s.worldInverseMatrix' % sParentJoint])
        nodes.createDecomposeMatrix(sFrontMatrix, sTargetPos='%s.t' % sSlidePivotFront, sTargetRot='%s.r' % sSlidePivotFront, sTargetScale='%s.s' % sSlidePivotFront)
        nodes.createDecomposeMatrix(sFrontMatrix, sTargetPos='%s.t' % sGrpSlidePivotFront, sTargetRot='%s.r' % sGrpSlidePivotFront, sTargetScale='%s.s' % sGrpSlidePivotFront)

        sJawSlidePivot = 'jnt_m_slidePivotFrontJaw'
        if cmds.objExists(sJawSlidePivot):
            cmds.parent(sJawSlidePivot, sParentJoint)
            xforms.resetTransform(sJawSlidePivot, jo=True)
            cmds.delete(cmds.parentConstraint(sJawJoint, sJawSlidePivot))
        else:
            xforms.createJoint(sJawSlidePivot, sParent=sParentJoint, sMatch=sJawJoint)

        cmds.setAttr('%s.segmentScaleCompensate' % sSlidePivotFront, False)
        utils.matchJointRadius([sSlidePivotFront, sJawSlidePivot], 'jnt_m_headMain', 0.1)


        sJawSliderFrontMatrix = nodes.createMultMatrixNode([sAnimMatrix,
                                                        nodes.createMultMatrixNode(['%s.worldMatrix' % cMouth.sCtrl, '%s.worldInverseMatrix' % sJawJoint], bJustValues=True),
                                                       '%s.worldMatrix' % sJawJoint,
                                                       '%s.worldInverseMatrix' % sParentJoint,
                                                       nodes.createMultMatrixNode(['%s.worldMatrix' % sParentJoint, '%s.worldInverseMatrix' % sSlidePivot], bJustValues=True),
                                                       '%s.worldMatrix' % sSlidePivot,
                                                       '%s.worldInverseMatrix' % sParentJoint], sName='jawSliderMatrix')
        nodes.createDecomposeMatrix(sJawSliderFrontMatrix, sTargetPos='%s.t' % sJawSlidePivot, sTargetRot='%s.r' % sJawSlidePivot)#, sTargetScale='%s.s' % sJawSlidePivot)
        cmds.connectAttr('%s.s' % sSlidePivotFront, '%s.s' % sJawSlidePivot)

        sJawSliderRotateMatrix = nodes.getRotationMatrix(nodes.createMultMatrixNode(['%s.worldMatrix' % sJawSlidePivot, '%s.worldInverseMatrix' % sSlidePivotFront]),
                                                          bScale=False, sName='rotJawSliderMatrix')
        deformers.resetJointReferences([sSlidePivotFront, sJawSlidePivot])


        sHorizontalStrengthRotate = utils.addAttr(cMouth.sPasser, ln='horizontalRotateStrength', dv=10, k=True)
        sHorizontalStrengthRotateTwist = utils.addAttr(cMouth.sPasser, ln='horizontalRotateTwistStrength', dv=0, k=False)
        sHorizontalStrengthRotateVert = utils.addAttr(cMouth.sPasser, ln='horizontalRotateVertStrength', dv=0, k=False)
        sHorizontalStrengthTranslateAttr = [utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthX', k=True),
                                            utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthY', k=True),
                                            utils.addAttr(cMouth.sPasser, ln='horizontalTranslateStrengthZ', k=True)]
        sDefaultSettingAttrs.extend([sHorizontalStrengthRotate, sHorizontalStrengthRotateTwist, sHorizontalStrengthRotateVert])
        sDefaultSettingAttrs.extend(sHorizontalStrengthTranslateAttr)
        
        sVerticalStrengthRotate = utils.addAttr(cMouth.sPasser, ln='verticalRotateStrength', dv=5, k=True)
        sVerticalStrengthRotateTwist = utils.addAttr(cMouth.sPasser, ln='verticalRotateTwistStrength', dv=0, k=True)
        sVerticalStrengthRotateHoriz = utils.addAttr(cMouth.sPasser, ln='verticalRotateHorizStrength', dv=0, k=True)
        sVerticalStrengthTranslateAttr = [utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthX', k=True),
                                          utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthY', k=True),
                                          utils.addAttr(cMouth.sPasser, ln='verticalTranslateStrengthZ', k=True)]
        sDefaultSettingAttrs.extend([sVerticalStrengthRotate, sVerticalStrengthRotateTwist, sVerticalStrengthRotateHoriz])
        sDefaultSettingAttrs.extend(sVerticalStrengthTranslateAttr)

        sMouthX = '%s.tx' % cMouth.sCtrl
        sMouthY = '%s.ty' % cMouth.sCtrl
        sMouthAbsX = nodes.createAbsoluteNode(sMouthX)
        sMouthAbsY = nodes.createAbsoluteNode(sMouthY)


        sVerticalStrengthTranslateAttr = nodes.createVectorMultiplyNode(sVerticalStrengthTranslateAttr, [-1, 1, -1])
        sVerticalStrengthTranslateAttr = ['%sY' % sVerticalStrengthTranslateAttr, '%sZ' % sVerticalStrengthTranslateAttr, '%sX' % sVerticalStrengthTranslateAttr]
        sVerticalStrengthTranslate = nodes.createVectorMultiplyNode(sVerticalStrengthTranslateAttr, fCurveLengthes[0]*0.035, bVectorByScalar=True)
        sVertResult = nodes.createVectorMultiplyNode(sVerticalStrengthTranslate, [sMouthY, sMouthAbsY, sMouthAbsY])

        sHorizontalStrengthTranslateAttr = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslateAttr, [-1, 1, -1])
        sHorizontalStrengthTranslateAttr = ['%sY' % sHorizontalStrengthTranslateAttr, '%sZ' % sHorizontalStrengthTranslateAttr, '%sX' % sHorizontalStrengthTranslateAttr]
        sHorizontalStrengthTranslate = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslateAttr, fCurveLengthes[0]*0.035, bVectorByScalar=True)
        sHorizResult = nodes.createVectorMultiplyNode(sHorizontalStrengthTranslate, [sMouthAbsX, sMouthAbsX, sMouthX])
        nodes.createVectorAdditionNode([sVertResult, sHorizResult], sTarget='%s.t' % sSlidePivot)



        sHorizontalRotateResults = [nodes.createMultiplyNode(sHorizontalStrengthRotate, '%s.tx' % cMouth.sCtrl),
                                    nodes.createMultiplyNode(sHorizontalStrengthRotateTwist, '%s.tx' % cMouth.sCtrl),
                                    nodes.createMultiplyNode(sHorizontalStrengthRotateVert, nodes.createAbsoluteNode('%s.tx' % cMouth.sCtrl))]
        sVerticalRotateResults =  [nodes.createMultiplyNode(sVerticalStrengthRotateHoriz, nodes.createAbsoluteNode('%s.ty' % cMouth.sCtrl)),
                                   nodes.createMultiplyNode(sVerticalStrengthRotateTwist, '%s.ty' % cMouth.sCtrl),
                                   nodes.createMultiplyNode(sVerticalStrengthRotate, '%s.ty' % cMouth.sCtrl)]
        
        nodes.createVectorAdditionNode([sHorizontalRotateResults, sVerticalRotateResults], sTarget='%s.r' % sSlidePivot)

        sParentRotMatrix = nodes.getRotationMatrix('%s.worldMatrix' % sSlidePivotFront)
        sParentRotInverseMatrix = nodes.createInverseMatrix(sParentRotMatrix)
        xforms.matrixParentConstraint(sJawSlidePivot, cBotTops[0].sPasser, mo=True)
        xforms.matrixParentConstraint(sSlidePivotFront, cBotTops[1].sPasser, mo=True)

        # static sliding curve
        aaPoints = [patch.patchFromName(sBpCurvesA[0]).getPoints(), patch.patchFromName(sBpCurvesA[1]).getPoints()]
        aSlidePivotFront = utils.getNumpyMatrixFromTransform(sSlidePivotFront)
        aInvSlidePivotFront = np.linalg.inv(aSlidePivotFront)
        aaLocalPoints = [np.dot(utils.makePoint4Array(aaPoints[0]), aInvSlidePivotFront)[:, 0:3],
                         np.dot(utils.makePoint4Array(aaPoints[1]), aInvSlidePivotFront)[:, 0:3]]
        # iMaxCurve = np.argmax([len(aaPoints[0]), len(aaPoints[1])])


        # only creating one sliding curve - using same for the top one
        sStaticSlideCurves = ['curve_l_mouthStaticSlide', 'curve_r_mouthStaticSlide']
        sStaticSlideUpCurves = ['curve_l_mouthStaticSlideUp', 'curve_r_mouthStaticSlideUp']
        sStaticSlideCurvesBp = [utils.replaceStringStart(sStaticSlideCurves[0], 'curve_', 'bpCurve_'), utils.replaceStringStart(sStaticSlideCurves[1], 'curve_', 'bpCurve_')]
        sStaticSlideUpCurvesBp = [utils.replaceStringStart(sStaticSlideUpCurves[0], 'curve_', 'bpCurve_'), utils.replaceStringStart(sStaticSlideUpCurves[1], 'curve_', 'bpCurve_')]

        aSlidePoints = np.copy(aaPoints[0])
        if True: # averaging in X of slide pivot
            aSlidePoints4 = utils.makePoint4Array(aSlidePoints)
            aSlidePointsLocal4 = np.dot(aSlidePoints4, np.linalg.inv(aMouthSlideMatrix))
            aSlidePointsLocal4[:,0] = np.average(aSlidePointsLocal4[:,0])
            aSlidePoints = np.dot(aSlidePointsLocal4, aMouthSlideMatrix)[:,0:3]
        aSlideUpPoints = aSlidePoints + aMouthSlideMatrix[0,0:3] * fCurveLengthes[0] * 0.05

        for s,sSide in enumerate(['l','r']):
            if cmds.objExists(sStaticSlideCurvesBp[s]):
                cmds.duplicate(sStaticSlideCurvesBp[s], n=sStaticSlideCurves[s])
            else:
                if cmds.objExists(sStaticSlideCurvesBp[1-s]):
                    sMirrored = geometry.meshMirrorNoBase([patch.patchFromName(sStaticSlideCurvesBp[1-s])], bWorld=True)[0]
                    cmds.rename(sMirrored, sStaticSlideCurves[s])
                else:
                    cmds.curve(p=aSlidePoints if s==0 else aSlidePoints[::-1], d=2, n=sStaticSlideCurves[s])
            if cmds.objExists(sStaticSlideUpCurvesBp[s]):
                cmds.duplicate(sStaticSlideUpCurvesBp[s], n=sStaticSlideUpCurves[s])
            else:
                if cmds.objExists(sStaticSlideUpCurvesBp[1-s]):
                    sMirrored = geometry.meshMirrorNoBase([patch.patchFromName(sStaticSlideUpCurvesBp[1-s])])[0]
                    cmds.rename(sMirrored, sStaticSlideUpCurves[s])
                else:
                   cmds.curve(p=aSlideUpPoints if s==0 else aSlideUpPoints[::-1], d=2, n=sStaticSlideUpCurves[s])
    
            cmds.skinCluster(sStaticSlideCurves[s], sSlidePivotFront, tsb=True)
            cmds.skinCluster(sStaticSlideUpCurves[s], sSlidePivotFront, tsb=True)

        cmds.parent(sStaticSlideCurves, sStaticSlideUpCurves, sGrp)

        # extract box rotations
        for p,sPart in enumerate(['bot','top']):
            fPartMultipl = -1.0 if p == 1 else 1.0
            cBox = cBotTops[p]

            cBox.sNoRoll = cmds.duplicate(cBox.sCtrl, po=True, n='%s_noRoll' % utils.replaceStringEnd(cBox.sCtrl, '_ctrl', ''))[0]
            sCtrlLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cBox.sCtrl, '%s.worldInverseMatrix' % cBox.sSlider])
            sCtrlLocalDecompPos = nodes.createDecomposeMatrix(sCtrlLocalMatrix)
            cmds.connectAttr(sCtrlLocalDecompPos, '%s.t' % cBox.sNoRoll)
            sAimPoint = nodes.createPointByMatrixNode([1, 0, 0], sCtrlLocalMatrix)
            sAimConstraint = constraints.aimConstraintEmpty(cBox.sNoRoll)
            cmds.connectAttr(sAimPoint, '%s.target[0].targetTranslate' % sAimConstraint)

            sAnimLocal = nodes.createMultMatrixNode([sCtrlLocalMatrix, '%s.inverseMatrix' % cBox.sNoRoll])
            sPointY = nodes.createPointByMatrixNode([0, fPartMultipl, 0], sAnimLocal)
            sAngle = nodes.createAngleNode(sPointY, [0, fPartMultipl, 0])
            sSignedAngle = nodes.createConditionNode('%sZ' % sPointY, '>', 0, sAngle, nodes.createMultiplyNode(sAngle, -1))
            cBox.sRollAttr = utils.addAttr(cBox.sPasser, ln='roll', k=True)
            cmds.connectAttr(sSignedAngle, cBox.sRollAttr)



        sCornerSlidePlanes = []
        for s,sSide in enumerate(['l','r']):
            sBpSurface = 'bpNurbs_%s_cornerSlidePlane' % sSide
            if not cmds.objExists(sBpSurface):
                sMirrorSurface = utils.getMirrorName(sBpSurface)
                if not cmds.objExists(sMirrorSurface):
                    raise Exception('Corner Slide plane missing')
                cmds.duplicate(sMirrorSurface, n=sBpSurface)
                sTemp = cmds.createNode('transform', n='tempDelete')
                cmds.parent(sBpSurface, sTemp)
                cmds.setAttr('%s.sx' % sTemp, -1)
                cmds.parent(sBpSurface, kMouthBpGroupName)
                cmds.delete(sTemp)
            sSurface = cmds.duplicate(sBpSurface, n=utils.replaceStringStart(sBpSurface, 'bpN', 'n'))[0]
            cmds.makeIdentity(sSurface, apply=True, t=True, r=True, s=True)
            sCornerSlidePlanes.append(sSurface)
            cmds.parent(sSurface, sGrpSlidePivotFront)


        sAttrs = ['tx','ty','tz','rx','ry','rz']
        ssJawSpaces = [(sJawSlidePivot, sGrpSlidePivotFront), (cBotTops[0].sNoRoll, sGrpSlidePivotFront), (sJawSlidePivot, cBotTops[1].sNoRoll)]
        for cc,cCtrls in enumerate((cCorners, ccLipCtrls[0], ccLipCtrls[1])):
            for c,cC in enumerate(cCtrls):
                cC.cOrig = ctrls5.create('%sOrig' % cC.sName, cC.sSide, cC.iIndex, sMatch=cC.sCtrl, sParent=sGrp,
                                         bIsNoCtrl=True, sAttrs=sAttrs)
                cC.cOrig.sCtrl = cmds.rename(cC.cOrig.sCtrl, utils.replaceStringEnd(cC.sCtrl, '_ctrl', ''))
                xforms.matrixParentConstraint(cC.sPasser, cC.cOrig.sPasser)
                # cC.sAttach = xforms.insertParent(cC.sPasser, utils.getUniqueName('grp_%s_%s_attach' % (cC.sSide, cC.sName)))

                sJawAttachAttr = utils.addAttr(cC.sCtrl, ln='jawAttach', min=0, max=1, dv=0, k=True)
                fSecondToFirst = nodes.createMultMatrixNode(['%s.worldMatrix' % ssJawSpaces[cc][0], '%s.worldInverseMatrix' % ssJawSpaces[cc][1]], bJustValues=True)
                sDefaultSettingAttrs.append(sJawAttachAttr)
                utils.addToListStringAttr(cC.sCtrl, utils.kSkipKeyImportAttrs, ['jawAttach'])
                sSecondOffsetted = nodes.createMultMatrixNode([fSecondToFirst, '%s.worldMatrix' % ssJawSpaces[cc][1]])
                sBlendMatrix = nodes.createBlendMatrixNode(['%s.worldMatrix' % ssJawSpaces[cc][0], sSecondOffsetted],
                                                                [sJawAttachAttr, nodes.createReverseNode(sJawAttachAttr)])

                fAttachOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser, '%s.worldInverseMatrix' % ssJawSpaces[cc][0]], bJustValues=True)
                sAttachMatrix = nodes.createMultMatrixNode([fAttachOffset, sBlendMatrix])

                nodes.createDecomposeMatrix(sAttachMatrix, sTargetPos='%s.t' % cC.sPasser, sTargetRot = '%s.r' % cC.sPasser, sTargetScale='%s.s' % cC.sPasser)

                sRelMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sOut, '%s.worldInverseMatrix' % cC.sSlider])

                if cc > 0: # not corners. because corners have a much more complicated setup further below
                    nodes.createDecomposeMatrix(sRelMatrix, sTargetPos='%s.t' % cC.cOrig.sCtrl, sTargetRot='%s.r' % cC.cOrig.sCtrl)



        fCornerJawAttach = 0.35
        for p, fMidStrength in enumerate([1, 0]):
            iHalfSize = len(ccLipCtrls[p]) // 2
            if len(ccLipCtrls[p]) % 2:
                iHalfSize += 1
            for c in range(iHalfSize):
                fMidPerc = (c+1) / float(iHalfSize)
                fMidPercRev = (1-fMidPerc) ** 3
                fMidPerc = 1-fMidPercRev
                fJawAttach = fCornerJawAttach * (1.0-fMidPerc) + fMidStrength * (fMidPerc)
                cmds.setAttr('%s.jawAttach' % ccLipCtrls[p][c].sCtrl, fJawAttach)
                cmds.setAttr('%s.jawAttach' % ccLipCtrls[p][-(c+1)].sCtrl, fJawAttach)

        for cC in cCorners:
            cmds.setAttr('%s.jawAttach' % cC.sCtrl, fCornerJawAttach)



        # corner slide setup
        sCornerSlideLocs = []
        for s,cCorner in enumerate(cCorners):
            sLocalCornerMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.sCtrl, '%s.worldInverseMatrix' % cCorner.sSlider])
            cCorner.sDecomp = nodes.createDecomposeMatrix(sLocalCornerMatrix).split('.')[0]

            fTranslates = (0,0), (0,2), (0,-2), (3,0)
            fCornerPoints = []
            for fT in fTranslates:
                cmds.setAttr('%s.tx' % cCorner.sCtrl, fT[0])
                cmds.setAttr('%s.ty' % cCorner.sCtrl, fT[1])
                fCornerPoints.append(cmds.xform(cCorner.sCtrl, q=True, ws=True, t=True))
            cmds.setAttr('%s.tx' % cCorner.sCtrl, 0)
            cmds.setAttr('%s.ty' % cCorner.sCtrl, 0)
            fUvs = surfaces.getParamsFromPoints(sCornerSlidePlanes[s], fCornerPoints)

            sUp = nodes.createRangeNode('%s.outputTranslateY' % cCorner.sDecomp, 0, fTranslates[1][1], fUvs[0][1], fUvs[1][1], bInfinity=True)
            sDown = nodes.createRangeNode('%s.outputTranslateY' % cCorner.sDecomp, 0, fTranslates[2][1], fUvs[0][1], fUvs[2][1], bInfinity=True)
            sOut = nodes.createRangeNode('%s.outputTranslateX' % cCorner.sDecomp, 0, fTranslates[3][0], fUvs[0][0], fUvs[3][0], bInfinity=True)

            sSlideLoc = xforms.createLocator('loc_%s_mouthSlideLoc' % utils.sSides1[s], sParent=sGrpSlidePivotFront, fSize=fCurveLengthes[p]*0.035)
            sCornerSlideLocs.append(sSlideLoc)
            sSurfaceNode, sSlidePos = surfaces.createPointInfoNode(sCornerSlidePlanes[s], fUvs[0][0], fUvs[0][1])

            if False: # corner push out... we might get it back?
                sAlongNormalLength = nodes.createMultiplyNode('%s.tz' % cCorners[s].sCtrl, '%s.sx' % cCorners[s].sPasser)
                if s == 1:
                    sAlongNormalLength = nodes.createMultiplyNode(sAlongNormalLength, -1)
                sAlongNormal = nodes.createVectorMultiplyNode(nodes.createNormalizedVector('%s.normal' % sSurfaceNode),
                                                              sAlongNormalLength,
                                                              bVectorByScalar=True)

                sPos = nodes.createVectorAdditionNode([sSlidePos, sAlongNormal])
            else:
                sPos = sSlidePos

            sLocalPos = nodes.createPointByMatrixNode(sPos, '%s.worldInverseMatrix' % sSlidePivotFront, sTarget='%s.t' % sSlideLoc)

            sAimConstraint = constraints.aimConstraintEmpty(sSlideLoc)
            # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
            nodes.createVectorAdditionNode([sLocalPos, nodes.createPointByMatrixNode('%s.normal' % sSurfaceNode, sParentRotInverseMatrix)],
                                           sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            nodes.createPointByMatrixNode('%s.tangentU' % sSurfaceNode, sParentRotInverseMatrix, sTarget='%s.worldUpVector' % sAimConstraint)

            nodes.createConditionNode('%s.outputTranslateY' % cCorner.sDecomp, '>', 0, sUp, sDown, sTarget='%s.parameterV' % sSurfaceNode)
            nodes.createConditionNode('%s.outputTranslateX' % cCorner.sDecomp, '>', 0, sOut, fUvs[0][0], sTarget='%s.parameterU' % sSurfaceNode)

            sLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.sCtrl, '%s.worldInverseMatrix' % cCorner.sSlider])
            sAnimRot = nodes.createDecomposeMatrix(sLocalMatrix, bReturnRotate=True)
            sAnimRotMatrix = nodes.createComposeMatrixNode(xRotate=sAnimRot)

            sFirstOffset = cmds.listRelatives(cCorner.cOrig.sCtrl, p=True)[0]
            sWorldCtrlWithoutJaw = nodes.createMultMatrixNode([nodes.createMultMatrixNode(['%s.worldMatrix' % sFirstOffset, '%s.worldInverseMatrix' % sSlidePivotFront], bJustValues=True),
                                                               '%s.worldMatrix' % sSlidePivotFront])

            fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorner.cOrig.sCtrl, '%s.worldInverseMatrix' % sSlideLoc], bJustValues=True)
            sMatrix = nodes.createMultMatrixNode([sAnimRotMatrix,
                                                  fOffset,
                                                  '%s.worldMatrix' % sSlideLoc,
                                                  nodes.createInverseMatrix(sWorldCtrlWithoutJaw)])

            nodes.createDecomposeMatrix(sMatrix, sTargetPos='%s.t' % cCorner.cOrig.sCtrl, sTargetRot='%s.r' % cCorner.cOrig.sCtrl)
            cmds.transformLimits(cCorner.sCtrl, etx=[True,False], tx=[-1,1000])




        # create JustAnim transforms
        for cC in ccRows[0]+ccRows[1]:
            cC.sJustAnims = [None, None]
        for p,sPart in enumerate(['bot','top']):
            fPartMult = 1 if p == 0 else -1
            # create sJustAnim transforms for lip ctrls
            for c,cC in enumerate(ccLipCtrls[p]):
                sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
                cC.sJustAnims[p] = cmds.createNode('transform', n='grp_%s_%sJustAnim' % (cC.sSide, cC.sName), p=sGrpSlidePivotFront)

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sCtrlParent, '%s.worldInverseMatrix' % sGrpSlidePivotFront], bJustValues=True)
                sAnim = nodes.createComposeMatrixNode('%s.t' % cC.sCtrl)
                sJustAnimMatrix = nodes.createMultMatrixNode([sAnim, fOffset])
                nodes.createDecomposeMatrix(sJustAnimMatrix, sTargetPos='%s.t' % cC.sJustAnims[p], sTargetRot='%s.r' % cC.sJustAnims[p])

            # create sJustAnim transforms for corners
            for s,cC in enumerate(cCorners):
                sCtrlParent = cmds.listRelatives(cC.sCtrl, p=True)[0]
                fCornerFromBoxOffset = nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % cBotTops[p].sNoRoll, bJustValues=True)
                sWorldCornerFromBox = nodes.createPointByMatrixNode(fCornerFromBoxOffset, '%s.worldMatrix' % cBotTops[p].sNoRoll)

                sTranslateXY = ['%s.tx' % cC.sCtrl, '%s.ty' % cC.sCtrl, 0]

                sCornerFromBoxInCornerSpace = nodes.createPointByMatrixNode(sWorldCornerFromBox, '%s.worldInverseMatrix' % sCtrlParent)

                cC.sJustAnims[p] = cmds.createNode('transform', n='grp_%s_%s%sJustAnim' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), p=sGrpSlidePivotFront)

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % sCtrlParent, '%s.worldInverseMatrix' % sSlidePivotFront], bJustValues=True)

                # sMax = ['%s.tx' % cC.sCtrl, nodes.createConditionNode('%s.ty' % cC.sCtrl, '<' if p == 0 else '>', 0, '%s.ty' % cC.sCtrl, 0), 0]

                sClamped = [None, None, '%sZ' % sCornerFromBoxInCornerSpace]
                sClamped[0] = nodes.createClampNode('%sX' % sCornerFromBoxInCornerSpace, 0, '%s.tx' % cC.sCtrl)
                sMaxY = nodes.createConditionNode('%s.ty' % cC.sCtrl, '<' if p == 0 else '>', 0, '%s.ty' % cC.sCtrl, 0)
                if p == 0:
                    sClamped[1] = nodes.createClampNode('%sY' % sCornerFromBoxInCornerSpace, sMaxY, 0)
                else:
                    sClamped[1] = nodes.createClampNode('%sY' % sCornerFromBoxInCornerSpace, 0, sMaxY)

                sDiff = nodes.createVectorAdditionNode([sTranslateXY, sClamped], sOperation='minus')

                sAnim = nodes.createComposeMatrixNode(sDiff)
                sJustAnimMatrix = nodes.createMultMatrixNode([sAnim, fOffset])
                nodes.createDecomposeMatrix(sJustAnimMatrix, sTargetPos='%s.t' % cC.sJustAnims[p], sTargetRot='%s.r' % cC.sJustAnims[p])


        # generate values for static sliding curves
        fStaticCurveMidParams = [curves.getParamsFromPercs(sStaticSlideCurves[0], [0.5])[0], curves.getParamsFromPercs(sStaticSlideCurves[1], [0.5])[0]]

        for s, sSide in enumerate(['l', 'r']):
            fCurveLength = curves.getLength(sStaticSlideCurves[s])
            for p,sPart in enumerate(['bot','top']):
                cSideCtrls = [cC for cC in ccLipCtrls[p] if cC.sSide == sSide]
                aParams = curves.getParamsFromTransforms(sStaticSlideCurves[s], [cC.sCtrl for cC in cSideCtrls], bReturnNumpy=True)
                aPercs = curves.getPercsFromParams(sStaticSlideCurves[s], aParams, bReturnNumpy=True)
                for cC,fParam,fPerc in zip(cSideCtrls, aParams, aPercs):
                    cC.fParamStaticCurve = fParam
                    cC.fDistance = fCurveLength * fPerc
                
                # not tested yet!
                for cC in ccLipCtrls[p]:
                    if cC.sSide == 'm':
                        cC.fParamStaticCurve = fStaticCurveMidParams[s]
                        cC.fDistance = fCurveLength * 0.5

        for p,sPart in enumerate(['bot','top']):
            # aaCtrlStaticCurveParams = [curves.getParamsFromTransforms(sStaticSlideCurves[0], [cC.sCtrl for cC in ccLipCtrls[p]], bReturnNumpy=True),
            #                             curves.getParamsFromTransforms(sStaticSlideCurves[1], [cC.sCtrl for cC in ccLipCtrls[p]], bReturnNumpy=True)]
            # aaPercs = [curves.getPercsFromParams(sStaticSlideCurves[0], aaCtrlStaticCurveParams[0], bReturnNumpy=True),
            #           curves.getPercsFromParams(sStaticSlideCurves[1], aaCtrlStaticCurveParams[1], bReturnNumpy=True)]
            # fCurveLengths = [curves.getLength(sStaticSlideCurves[0]), curves.getLength(sStaticSlideCurves[1])]
            # aaDistances = [aaPercs[0] * fCurveLengths, aaPercs[1] * fCurveLengths]
            # fKnotEnds = [curves.getParamLength(sStaticSlideCurves[0]), curves.getParamLength(sStaticSlideCurves[1])]

            sEndTangents = [None, None]
            for c,cC in enumerate(ccLipCtrls[p]):
                if cC.sSide == 'm':
                    continue
                iSide = 1 if cC.sSide == 'r' else 0
                fSideMultipl = -1.0 if cC.sSide == 'r' else 1.0
                sMove = cC.appendOffsetGroup('movetocorner')
                sFollowY = utils.addAttr(cC.sCtrl, ln='followCornerY', min=0, max=1, k=True)
                sFollowPath = utils.addAttr(cC.sCtrl, ln='followCornerPath', min=0, max=1, k=True)
                utils.addToListStringAttr(cC.sCtrl, utils.kSkipKeyImportAttrs, ['followCornerY', 'followCornerPath'])

                sDefaultSettingAttrs.append(sFollowY)
                sDefaultSettingAttrs.append(sFollowPath)

                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[iSide].sJustAnims[p], '%s.worldInverseMatrix' % sSlidePivotFront], bJustValues=True)
                sParentMatrix = nodes.createMultMatrixNode([fOffset, '%s.worldMatrix' % sSlidePivotFront])
                sParentInverseMatrix = nodes.createInverseMatrix(sParentMatrix)
                sLocalMovingMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cCorners[iSide].sJustAnims[p], sParentInverseMatrix])
                sDecomp = nodes.createDecomposeMatrix(sLocalMovingMatrix)
                fDefaultValue = abs(cC.fPerc - 0.5)
                cmds.setAttr(sFollowY, fDefaultValue)
                cmds.setAttr(sFollowPath, fDefaultValue)
                fScaleFactorForUpDown = nodes.createMultiplyNode(1.0, '%s.sx' % cC.sPasser, sOperation='divide')
                fScaledForUpDown = nodes.createVectorMultiplyNode(sDecomp, fScaleFactorForUpDown, bVectorByScalar=True)
                sUpDown = '%sY' % fScaledForUpDown
                nodes.createMultiplyNode(sFollowY, sUpDown, sTarget='%s.ty' % sMove)


                fScaleFactorForPath = nodes.createMultiplyNode('%s.sx' % cCorners[iSide].sPasser, '%s.sx' % cC.sPasser, sOperation='divide')
                fScaledForPath = nodes.createVectorMultiplyNode(sDecomp, fScaleFactorForPath, bVectorByScalar=True)
                sBack = nodes.createConditionNode('%sX' % fScaledForPath, '>', 0, '%sX' % fScaledForPath, 0.0)


                cC.sSlidingGrpOut = cC.appendOffsetGroup('movetocornerpath')
                cC.sSlidingLocOut = xforms.createLocator('grp_%s_%sOutSlidingCopy_%03d' % (cC.sSide, cC.sName, 0 if utils.isNone(cC.iIndex) else cC.iIndex), sParent=sGrp, fSize=fCurveLengthes[0]*0.035)
                print ('cC: ', cC)
                sNode, sPos = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=cC.fParamStaticCurve)
                sUpNode, sUpPos = curves.createPointInfoNode(sStaticSlideUpCurves[iSide], fParam=cC.fParamStaticCurve)
                sPosAddition = nodes.createVectorAdditionNode([sPos], sTarget='%s.t' % cC.sSlidingLocOut)

                sAimConstraint = constraints.aimConstraintEmpty(cC.sSlidingLocOut, aim=[fSideMultipl,0,0])
                nodes.createVectorAdditionNode([sPosAddition, '%s.tangent' % sNode], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                nodes.createVectorAdditionNode([sUpPos, sPos], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)

                fDistanceToCorner = abs((0) - cC.fDistance) # aaDistances[iSide][c])
                sDistanceToCornerBySpeed = nodes.createMultiplyNode(fDistanceToCorner, sFollowPath, sOperation='divide')

                [cmds.connectAttr(sGlobalMouthScale, '%s.s%s' % (cC.sSlidingLocOut, sA)) for sA in ['x', 'y', 'z']]

                nodes.createRangeNode(sBack, 0, sDistanceToCornerBySpeed, cC.fParamStaticCurve, 0.0,
                                       sTarget=['%s.parameter' % sNode, '%s.parameter' % sUpNode])

                sSlidingLocLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingLocOut, '%s.worldInverseMatrix' % sSlidePivotFront])
                fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingGrpOut, '%s.worldInverseMatrix' % cC.sSlidingLocOut], bJustValues=True)

                fAttachHeadSpaceNoJawMotion = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlider, '%s.worldInverseMatrix' % sSlidePivotFront], bJustValues=True)

                sSlidingInLocal = nodes.createMultMatrixNode([fOffset,
                                                              nodes.createComposeMatrixNode(xScale=[sMouthScale, sMouthScale, sMouthScale]),
                                                              sSlidingLocLocal,
                                                              nodes.createInverseMatrix(fAttachHeadSpaceNoJawMotion, bJustValues=True)])
                nodes.createDecomposeMatrix(sSlidingInLocal, sTargetPos='%s.t' % cC.sSlidingGrpOut, sTargetRot='%s.r' % cC.sSlidingGrpOut)


                # for after it reached the end
                if sEndTangents[iSide] == None:
                    sCornerInfoNode, _ = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=0.0)
                    sNormTangent = nodes.createNormalizedVector('%s.tangent' % sCornerInfoNode)
                    sEndTangents[iSide] = nodes.createVectorMultiplyNode(sNormTangent, -100 * fSideMultipl, bVectorByScalar=True)
                sBack2 = nodes.createConditionNode('%sX' % fScaledForPath, '>', 0, '%sX' % fScaledForPath, 0.0) # actually it's not necessary, sBack would be enough, too. (tried to fix some update bug but didn't work anyway)

                nodes.createRangeNode(sBack2, sDistanceToCornerBySpeed, 100, [0,0,0], nodes.createVectorMultiplyNode(sEndTangents[iSide], sFollowPath, bVectorByScalar=True),
                                       sTarget='%s.input3D[1]' % sPosAddition.split('.')[0], bOutRangeIsVector=True)

                # range_noname31 causes issue. is getting a weirdly high valueXYZ, and then snapping back



        # create extra ctrl grps
        cPosingCtrls = []

        def addPosingControls(cAddPosingCtrls):

            dOffsetsPerCtrls = defaultdict(list)
            for pp, sPose in enumerate(kAllPoseKeys):
                sCtrlsPerPose = []
                for c, cC in enumerate(cAddPosingCtrls):
                    sNewOffset = cC.appendOffsetGroup('%spose' % sPose.lower())
                    sCtrlsPerPose.append(cC.sCtrl)
                    dOffsetsPerCtrls[cC.sCtrl].append(sNewOffset)

                utils.data.addToList('%sCtrlKey' % sPose, sCtrlsPerPose)

            for c, cC in enumerate(cAddPosingCtrls):
                utils.addToListStringAttr(cC.sCtrl, 'sPoseCtrls', dOffsetsPerCtrls[cC.sCtrl])
                cPosingCtrls.append(cC)

        addPosingControls(ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners)# + cCornerTangents




        def addAttrInclPoseCtrls(cC, ln, defaultValue=0, minValue=0, maxValue=1, k=True):
            sPoseCtrlsString = utils.getStringAttr(cC.sCtrl, 'sPoseCtrls', '[]')
            sPoseCtrls = eval(sPoseCtrlsString)
            sAttrs = []

            for c,sC in enumerate([cC.sCtrl]+sPoseCtrls):
                sAttrs.append(utils.addAttr(sC, ln=ln,
                                            defaultValue=defaultValue if c == 0 else 0,
                                            k=k, minValue=minValue, maxValue=maxValue))
            sSumAttr = utils.addAttr(cC.sPasser, ln='%sSum' % ln, k=True)
            nodes.createAdditionNode(sAttrs, sTarget=sSumAttr)
            return sSumAttr


        # create additional attributes
        for s,sSide in enumerate(['l','r']):
            cCorners[s].sRoundAttr = addAttrInclPoseCtrls(cCorners[s], ln='pointyRound', minValue=0, maxValue=1, k=True)
            cCorners[s].sRoundExceedAttr = utils.addAttr(cCorners[s].sPasser, ln='pointyRoundExceed', k=True)
            cCorners[s].sRoundExceedAutoAttr = utils.addAttr(cCorners[s].sPasser, ln='pointyRoundExceedWhenOn', k=True)

            cCorners[s].sTangentScales = [utils.addAttr(cCorners[s].sPasser, ln='tangentScaleBot', k=True, dv=1),
                                          utils.addAttr(cCorners[s].sPasser, ln='tangentScaleTop', k=True, dv=1)]
            cCorners[s].sTangentScalesAuto = [utils.addAttr(cCorners[s].sPasser, ln='tangentScaleBotAuto', k=True, dv=1),
                                              utils.addAttr(cCorners[s].sPasser, ln='tangentScaleTopAuto', k=True, dv=1)]
            sScaleSumNode = nodes.createVectorAdditionNode([ [cCorners[s].sTangentScales[0], cCorners[s].sTangentScales[1], 0],
                                                             [cCorners[s].sTangentScalesAuto[0], cCorners[s].sTangentScalesAuto[1], 0],
                                                             [-1,-1,0]]) # -1 = -2 + 1
            cCorners[s].sScaleSums = ['%sx' % sScaleSumNode, '%sy' % sScaleSumNode]
            utils.data.store('sTangentScalesAuto_%s' % sSide, cCorners[s].sTangentScalesAuto)


            cCorners[s].sSeal = addAttrInclPoseCtrls(cCorners[s], ln='seal', defaultValue=0.0, minValue=0.0, maxValue=1.0, k=True)
            cCorners[s].sSealFadeLength = utils.addAttr(cCorners[s].sCtrl, ln='sealFade', defaultValue=0.4, minValue=0.01, maxValue=1.0, k=True)


        ssPartInfluences = [[], []]
        ccCornerTangents = [[], []]
        # create control influence joints
        for p,sPart in enumerate(['bot','top']):
            fCurveLengthes[p] = curves.getLength(sBpCurvesA[0])
            fPartMult = 1 if p == 0 else -1

            for c,cC in enumerate(ccRows[p]):
                s = ['l','r','m'].index(cC.sSide)
                sI = cmds.createNode('joint', n='inf_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), p=cC.cOrig.sOut)
                cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sI)
                sAimToNeighborsAttr = utils.addAttr(cC.sPasser, ln='aimToNeighbors', min=0, max=1, dv=0.0 if cC.sSide == 'm' else 1.0, k=True, bReturnIfExists=True)
                sDefaultSettingAttrs.append(sAimToNeighborsAttr)
                sNoRotCtrl = cmds.duplicate(cC.cOrig.sCtrl, n='grp_%s_%sMouthNoRot%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)), po=True)[0]
                cmds.connectAttr('%s.t' % cC.cOrig.sCtrl, '%s.t' % sNoRotCtrl)
                if c in [0, len(ccRows[p])-1]: # corners
                    sParentI = xforms.insertParent(sI, 'parent_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, utils.getFirstLetterUpperCase(sPart)))
                    cTangentCtrl = ctrls5.create('cornerTangent%s' % utils.getFirstLetterUpperCase(sPart), sSide=cC.sSide, sMatch=sI, sShape='revL',
                                                 sParent=cC.sOut, sAttrs=['rx','ry','rz'], fRotateShape=[180,0,0], fSize=fCurveLengthes[0]*0.15, iColorIndex=2)
                    ccCornerTangents[s].append(cTangentCtrl)
                    sCtrlVis = utils.addOffOnAttr(cC.sCtrl, 'tangentCtrl%sVis' % utils.getFirstLetterUpperCase(sPart), bDefaultValue=False, bReturnIfExists=True)
                    cmds.connectAttr(sCtrlVis, '%s.v' % cTangentCtrl.sPasser)
                    cmds.connectAttr('%s.r' % sParentI, '%s.r' % cTangentCtrl.sPasser)
                    cmds.connectAttr('%s.ro' % sParentI, '%s.ro' % cTangentCtrl.sPasser)
                    # cmds.connectAttr('%s.r' % cTangentCtrl.sCtrl, '%s.r' % sI)
                    # cmds.connectAttr('%s.ro' % cTangentCtrl.sCtrl, '%s.ro' % sI)
                    sTangentAnimMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % cTangentCtrl.sOut, '%s.worldInverseMatrix' % cTangentCtrl.sPasser])
                    nodes.createDecomposeMatrix(sTangentAnimMatrix, sTargetPos='%s.t' % sI, sTargetRot='%s.r' % sI)
                    sAimConstraint = constraints.aimConstraintEmpty(sParentI)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0, 0, 1)

                    if c == 0:
                        sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][1].cOrig.sCtrl), '%s.worldInverseMatrix' % sNoRotCtrl)
                    else:
                        sAimTarget = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][-2].cOrig.sCtrl), '%s.worldInverseMatrix' % sNoRotCtrl)
                    fLength = np.linalg.norm(np.array(cmds.getAttr(sAimTarget)[0], dtype='float64'))

                    sRoundRotate = nodes.createAdditionNode([cC.sRoundExceedAttr,
                                                             nodes.createMultiplyNode(cC.sRoundExceedAutoAttr, cC.sRoundAttr)])

                    sSignedRoundRotate = sRoundRotate if p == 0 else nodes.createMultiplyNode(sRoundRotate, -1)

                    sExceededRoundAimTarget = nodes.createPointByMatrixNode([0, fLength*(-fPartMult), 0],
                                                                            nodes.createComposeMatrixNode(xRotate=[0,0,sSignedRoundRotate]))

                    nodes.createBlendNode(cC.sRoundAttr, sExceededRoundAimTarget, sAimTarget, bVector=True,
                                                       sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                    cmds.connectAttr(cCorners[0 if c == 0 else 1].sScaleSums[p], '%s.sx' % sI)



                else:
                    sAimConstraint = constraints.aimConstraintEmpty(sI)
                    cmds.setAttr('%s.worldUpVector' % sAimConstraint, 0, 0, 1)

                    sAimTargetA = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][c-1].sJustAnims[p]), '%s.worldInverseMatrix' % cC.sJustAnims[p])
                    sAimTargetB = nodes.createPointByMatrixNode(nodes.getWorldPoint(ccRows[p][c+1].sJustAnims[p]), '%s.worldInverseMatrix' % cC.sJustAnims[p])
                    sAimTarget = nodes.createVectorAdditionNode([sAimTargetA, sAimTargetB], sOperation='minus')

                    nodes.createBlendNode(sAimToNeighborsAttr, sAimTarget, cmds.getAttr(sAimTarget)[0], bVector=True,
                                                         sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                ssPartInfluences[p].append(sI)

        cCornerTangents = utils.flattenedList(ccCornerTangents)
        addPosingControls(cCornerTangents)
        print ('cPosingCtrls: ', cPosingCtrls)

        ## jaw open pose
        sJawDriverAttr = ddPoses['jawOpen']['sDriverAttr']

        for cC in cBotTops:
            cC.sCtrlHeight = '%sY' % nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sCtrl), '%s.worldInverseMatrix' % sSlidePivotFront)
        for cC in cCorners:
            cC.sCtrlHeight = '%sY' % nodes.createPointByMatrixNode(nodes.getWorldPoint(cC.sPasser), '%s.worldInverseMatrix' % sSlidePivotFront)

        sCornerAverageCtrlHeight = nodes.createBlendNode(0.5, cCorners[0].sCtrlHeight, cCorners[1].sCtrlHeight)


        dOutputs = defaultdict(list)
        for p,sPart in enumerate(['bot','top']):

            sBoxHeightLeft = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, cCorners[0].sCtrlHeight], sOperation='minus')
            fBoxHeightLeft = cmds.getAttr(sBoxHeightLeft)
            sBoxHeightRight = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, cCorners[1].sCtrlHeight], sOperation='minus')
            fBoxHeightRight = cmds.getAttr(sBoxHeightRight)
            sBoxHeightMiddle = nodes.createAdditionNode([cBotTops[p].sCtrlHeight, sCornerAverageCtrlHeight], sOperation='minus')
            fBoxHeightMiddle = cmds.getAttr(sBoxHeightRight)
            cmds.setAttr(sJawDriverAttr, ddPoses['jawOpen']['fDriverValue'])
            fPosedBoxHeightLeft = cmds.getAttr(sBoxHeightLeft)
            fPosedBoxHeightRight = cmds.getAttr(sBoxHeightRight)
            fPosedBoxHeightMiddle = cmds.getAttr(sBoxHeightMiddle)

            dPose = ddPoses['jawOpen']['dPose']
            sJawOpenInfoAttrLeft = utils.addAttr(cBotTops[p].sPasser, ln='jawOpenPoseLeft', k=True)
            sJawOpenInfoAttrRight = utils.addAttr(cBotTops[p].sPasser, ln='jawOpenPoseRight', k=True)
            sJawOpenInfoAttrMiddle = utils.addAttr(cBotTops[p].sPasser, ln='jawOpenPoseMiddle', k=True)

            dPoseOns = {}
            dPoseOns['l'] = nodes.createRangeNode(sBoxHeightLeft, fBoxHeightLeft, fPosedBoxHeightLeft, 0, 1, sTarget=sJawOpenInfoAttrLeft)
            dPoseOns['r'] = nodes.createRangeNode(sBoxHeightRight, fBoxHeightRight, fPosedBoxHeightRight, 0, 1, sTarget=sJawOpenInfoAttrRight)
            dPoseOns['m'] = nodes.createRangeNode(sBoxHeightMiddle, fBoxHeightMiddle, fPosedBoxHeightMiddle, 0, 1, sTarget=sJawOpenInfoAttrMiddle)
            # sCustomPoseOn = nodes.createRangeNode(sJawDriverAttr, 0, ddPoses['jawOpen']['fDriverValue'], 0, 1)

            cAllCornerRelatedCtrls = cCorners + utils.flattenedList(ccCornerTangents)
            for cC in ccLipCtrls[p] + cAllCornerRelatedCtrls:
                sOffsetGrp = cC.getOffsetByName('jawopenpose')
                dP = dPose.get(cC.sCtrl, {})
                if dP:
                    
                    for sA,fV in list(dP.items()):
                        sOffsetAttr = '%s.%s' % (sOffsetGrp,sA)
                        if cmds.objExists(sOffsetAttr):
                            if sA.startswith('scale'):
                                sOutput = nodes.createRangeNode(dPoseOns[cC.sSide], 0, 1, 1, fV)
                            else:
                                sOutput = nodes.createMultiplyNode(dPoseOns[cC.sSide], fV)

                            if cC in cAllCornerRelatedCtrls: # those will be iterated 2 times
                                dOutputs[sOffsetAttr].append(nodes.createMultiplyNode(sOutput, 0.5))
                            else:
                                dOutputs[sOffsetAttr].append(sOutput)
                                
            cmds.setAttr(sJawDriverAttr, 0)

        for sOffsetAttr, sOutputs in dOutputs.items():
            if len(sOutputs) > 1:
                nodes.createAdditionNode(sOutputs, sTarget=sOffsetAttr, sName='addBotTopJawPose')
            else:
                cmds.connectAttr(sOutputs[0], sOffsetAttr)
                


        ## corner out pose
        dPose = ddPoses['cornerOut']['dPose']
        sCornerOutDriverAttrs = [ctrls5.verifyCtrlName(ddPoses['cornerOut']['sDriverAttr'])]
        sCornerOutDriverAttrs.append(utils.getMirrorName(sCornerOutDriverAttrs[0]))

        dPoseOns = {}
        fPoseValue = ddPoses['cornerOut']['fDriverValue']
        print('fPoseValue: ', fPoseValue)
        dPoseOns['l'] = nodes.createRangeNode(sCornerOutDriverAttrs[0], 0, fPoseValue, 0, 1)
        dPoseOns['r'] = nodes.createRangeNode(sCornerOutDriverAttrs[1], 0, fPoseValue, 0, 1)
        dPoseOns['m'] = nodes.createBlendNode(0.5, dPoseOns['l'], dPoseOns['r'])
        for cC in ccLipCtrls[0] + ccLipCtrls[1] + cCornerTangents:
            sOffsetGrp = cC.getOffsetByName('corneroutpose')
            dP = dPose.get(cC.sCtrl, {})
            if dP:
                for sA,fV in list(dP.items()):
                    sOffsetAttr = '%s.%s' % (sOffsetGrp, sA)
                    if cmds.objExists(sOffsetAttr):
                        nodes.createMultiplyNode(dPoseOns[cC.sSide], fV, sTarget=sOffsetAttr)


        # funnel pose
        dPose = ddPoses['funnel']['dPose']
        sFunnelDriverAttrs = [ddPoses['funnel']['sDriverAttr']]
        sFunnelDriverAttrs.append(utils.getMirrorName(sFunnelDriverAttrs[0]))

        dPoseOns = {}
        fPoseValue = ddPoses['funnel']['fDriverValue']

        dPoseOns['l'] = nodes.createRangeNode(sFunnelDriverAttrs[0], 0, fPoseValue, 0, 1)
        dPoseOns['r'] = nodes.createRangeNode(sFunnelDriverAttrs[1], 0, fPoseValue, 0, 1)
        dPoseOns['m'] = nodes.createBlendNode(0.5, dPoseOns['l'], dPoseOns['r'])
        for cC in ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners + cCornerTangents:
            sOffsetGrp = cC.getOffsetByName('funnelpose')
            dP = dPose.get(cC.sCtrl, {})
            if dP:
                for sA,fV in list(dP.items()):
                    sOffsetAttr = '%s.%s' % (sOffsetGrp, sA)
                    if cmds.objExists(sOffsetAttr):
                        if sA.startswith('scale'):
                            nodes.createRangeNode(dPoseOns[cC.sSide], 0, 1, 1, fV, sTarget=sOffsetAttr)
                        else:
                            nodes.createMultiplyNode(dPoseOns[cC.sSide], fV, sTarget=sOffsetAttr)


        # lipPress pose
        dPose = ddPoses['lipPress']['dPose']
        sLipPressDriverAttrs = [ddPoses['lipPress']['sDriverAttr']]
        sLipPressDriverAttrs.append(utils.getMirrorName(sLipPressDriverAttrs[0]))

        dPoseOns = {}
        fPoseValue = ddPoses['lipPress']['fDriverValue']

        dPoseOns['l'] = nodes.createRangeNode(sLipPressDriverAttrs[0], 0, fPoseValue, 0, 1)
        dPoseOns['r'] = nodes.createRangeNode(sLipPressDriverAttrs[1], 0, fPoseValue, 0, 1)
        dPoseOns['m'] = nodes.createBlendNode(0.5, dPoseOns['l'], dPoseOns['r'])
        for cC in ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners + cCornerTangents:
            sOffsetGrp = cC.getOffsetByName('lippresspose')
            dP = dPose.get(cC.sCtrl, {})
            if dP:
                for sA,fV in list(dP.items()):
                    sOffsetAttr = '%s.%s' % (sOffsetGrp, sA)
                    if cmds.objExists(sOffsetAttr):
                        if sA.startswith('scale'):
                            nodes.createRangeNode(dPoseOns[cC.sSide], 0, 1, 1, fV, sTarget=sOffsetAttr)
                        else:
                            nodes.createMultiplyNode(dPoseOns[cC.sSide], fV, sTarget=sOffsetAttr)

        # mouthClose pose
        sMouthCloseDriverAttr = utils.addAttr(cMouth.sCtrl, ln='mouthClose', minValue=0, maxValue=1, k=True)
        dPose = ddPoses['mouthClose']['dPose']

        sJawOpenRange = nodes.createRangeNode(sJawDriverAttr, 0, ddPoses['mouthClose']['fJawOpenValue'], 0, 1)
        fFinalPoseValue = nodes.createMultiplyNode(sJawOpenRange, sMouthCloseDriverAttr)
        for cC in ccLipCtrls[0] + ccLipCtrls[1] + cBotTops + cCorners + cCornerTangents:
            sOffsetGrp = cC.getOffsetByName('mouthclosepose')
            dP = dPose.get(cC.sCtrl, {})
            if dP:
                for sA,fV in list(dP.items()):
                    sOffsetAttr = '%s.%s' % (sOffsetGrp, sA)
                    if cmds.objExists(sOffsetAttr):
                        # nodes.createMultiplyNode(fFinalPoseValue, fV, sTarget=sOffsetAttr)
                        if sA.startswith('scale'):
                            nodes.createRangeNode(fFinalPoseValue, 0, 1, 1, fV, sTarget=sOffsetAttr)
                        else:
                            nodes.createMultiplyNode(fFinalPoseValue, fV, sTarget=sOffsetAttr)


        # move ctrl shapes to outer curves
        # for p, cCtrls in enumerate([(ccLipCtrls[0] + [cBotTops[0]] + cCorners),
        #                             (ccLipCtrls[1] + [cBotTops[1]])]):
        for p, cCtrls in enumerate([(ccLipCtrls[0] + [] + cCorners),
                                    (ccLipCtrls[1] + [])]): #excluded cBotTop ctrls
            aCurrentPositions = xforms.getPositionArray([cC.sCtrl for cC in cCtrls])
            if True: # find by closest
                aMoveToPositions = curves.getPointsFromPoints(sBpCurvesB[p], aCurrentPositions, bReturnNumpy=True)
            else: # find by percentage
                fCtrlPercs = [cC.fPerc for cC in cCtrls]
                aMoveToPositions = curves.getPointsFromPercs(sBpCurvesB[p], fCtrlPercs, bReturnNumpy=True)
            aMoves = aMoveToPositions - aCurrentPositions
            for c,cC in enumerate(cCtrls):
                pCtrl = patch.patchFromName(cC.sShape)
                pCtrl.setPoints(pCtrl.getPoints() + aMoves[c])

        # slide ctrls

        cSlideCtrls = ccLipCtrls[0]+ccLipCtrls[1]
        # aaCtrlStaticCurveParams = [curves.getParamsFromTransforms(sStaticSlideCurves[0], [cC.sCtrl for cC in cSlideCtrls], bReturnNumpy=True),
        #             curves.getParamsFromTransforms(sStaticSlideCurves[1], [cC.sCtrl for cC in cSlideCtrls], bReturnNumpy=True)]
        # fStaticCurveMidParams = [curves.getParamsFromPercs(sStaticSlideCurves[0], [0.5])[0], curves.getParamsFromPercs(sStaticSlideCurves[1], [0.5])[0]]

        fCurveLengths = [curves.getLength(sStaticSlideCurves[0]), curves.getLength(sStaticSlideCurves[1])]
        for s,cCorner in enumerate(cCorners):
            sPuckerFactor = utils.addAttr(cCorner.sPasser, ln='puckerFactor', k=True, min=0.1, max=10, dv=1.0)
            sDefaultSettingAttrs.append(sPuckerFactor)
            cCorner.sFullPoint = nodes.createPointByMatrixNode(nodes.getWorldPoint(cCorner.sCtrl), '%s.worldInverseMatrix' % cCorner.sSlider)
            sCornerX = nodes.createMultiplyNode('%sX' % cCorner.sFullPoint, '%s.sx' % cCorner.sPasser)
            sPuckerDistance = nodes.createConditionNode(sCornerX, '<', 0, sCornerX, 0.0)
            sPuckerDistance = nodes.createMultiplyNode(sPuckerDistance, sPuckerFactor)

            sMidPercAttr = utils.addAttr(cCorner.sPasser, ln='midPerc', k=True)
            sNegHalfCurveLength = nodes.createMultiplyArrayNode([-fCurveLengths[s] * 0.5, sGlobalMouthScale])
            nodes.createMultiplyNode(sPuckerDistance, sNegHalfCurveLength, sOperation='divide', sTarget=sMidPercAttr)


        for c,cC in enumerate(cSlideCtrls):
            iSide = 1 if cC.sSide == 'r' else 0

            sMidPercFactorAttr = utils.addAttr(cC.sPasser, ln='puckerMidPercFactor', k=True, dv=1.0, min=0.0, max=1.0)
            sDefaultSettingAttrs.append(sMidPercFactorAttr)
            sMidPercAttr = utils.addAttr(cC.sPasser, ln='midPerc', k=True)
            nodes.createMultiplyNode('%s.midPerc' % cCorners[iSide].sPasser, sMidPercFactorAttr, sTarget=sMidPercAttr)

            cC.sSlidingGrp = cC.appendOffsetGroup('slidinggrp', bBelowPasser=True) # getting strange values on scale
            cC.sSlidingLoc = xforms.createLocator('grp_%s_%sPuckerSlidingCopy_%03d' % (cC.sSide, cC.sName, 0 if utils.isNone(cC.iIndex) else cC.iIndex), sParent=sGrp, fSize=fCurveLengthes[0]*0.035)
            sNode, sPos = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=cC.fParamStaticCurve, sTargetPos='%s.t' % cC.sSlidingLoc)
            [cmds.connectAttr(sGlobalMouthScale, '%s.s%s' % (cC.sSlidingLoc, sA)) for sA in ['x', 'y', 'z']]

            sUpNode, sUpPos = curves.createPointInfoNode(sStaticSlideUpCurves[iSide], fParam=cC.fParamStaticCurve)

            sAimConstraint = constraints.aimConstraintEmpty(cC.sSlidingLoc)
            nodes.createVectorAdditionNode([sPos, '%s.tangent' % sNode], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            nodes.createVectorAdditionNode([sUpPos, sPos], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)

            nodes.createRangeNode(sMidPercAttr, 0, 1, cC.fParamStaticCurve, fStaticCurveMidParams[iSide],
                                   sTarget=['%s.parameter' % sNode, '%s.parameter' % sUpNode])

            sSlidingLocLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingLoc, '%s.worldInverseMatrix' % sSlidePivotFront])
            fOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sSlidingGrp, '%s.worldInverseMatrix' % cC.sSlidingLoc], bJustValues=True)

            fAttachHeadSpaceNoJawMotion = nodes.createMultMatrixNode(['%s.worldMatrix' % cC.sPasser, '%s.worldInverseMatrix' % sSlidePivotFront], bJustValues=True)

            sSlidingInLocal = nodes.createMultMatrixNode([fOffset,
                                                          nodes.createComposeMatrixNode(xScale=[sMouthScale, sMouthScale, sMouthScale]),
                                                          sSlidingLocLocal,
                                                          nodes.createInverseMatrix(fAttachHeadSpaceNoJawMotion, bJustValues=True)])
            nodes.createDecomposeMatrix(sSlidingInLocal, sTargetPos='%s.t' % cC.sSlidingGrp, sTargetRot='%s.r' % cC.sSlidingGrp)

        # sRollDrivenKeyOutputs = []
        # if not cmds.objExists(sTempRollDriverOutput):
        #     cmds.spaceLocator(n=sTempRollDriverOutput.split('.')[0])


        # lip push
        for cBot, cTop in zip(ccLipCtrls[0], ccLipCtrls[1]):
            sLipPushAttr = utils.addAttr(cTop.sCtrl, ln='lipPush', min=0, max=1, dv=0, k=True)
            fTopToBotOffset = nodes.createMultMatrixNode(['%s.worldMatrix' % cTop.sCtrl, '%s.worldInverseMatrix' % cBot.sCtrl], bJustValues=True)
            sPlane = nodes.createMultMatrixNode([fTopToBotOffset, '%s.worldMatrix' % cBot.sCtrl])
            sPlaneInv = nodes.createInverseMatrix(sPlane)
            sTopInPlane = nodes.createMultMatrixNode(['%s.worldMatrix' % cTop.sCtrl, sPlaneInv])
            sTopInPlanePosY = '%sY' % nodes.createDecomposeMatrix(sTopInPlane)
            sPushValue = nodes.createConditionNode(sTopInPlanePosY, '<', 0, nodes.createMultiplyNode(sTopInPlanePosY, -1), 0)
            nodes.createBlendNode(sLipPushAttr, sPushValue, 0, sTarget='%s.ty' % cTop.sOut)


        #
        # lipsEnd joints
        #
        sLipsEndJoints = []
        for s, sSide in enumerate(['l', 'r']):
            # lipsEnd joint
            sLipsEnd = 'jnt_%s_lipsEnd' % sSide
            if cmds.objExists(sLipsEnd):
                cmds.parent(sLipsEnd, sSlidePivotFront)
            else:
                cmds.createNode('joint', n=sLipsEnd, p=sSlidePivotFront)
            cmds.setAttr('%s.radius' % sLipsEnd, fCurveLengthes[0] * 0.075)
            cmds.setAttr('%s.segmentScaleCompensate' % sLipsEnd, False)
            sLipsEndJoints.append(sLipsEnd)
            


        #
        # start doing the splines 
        #
        ssSmallJointMatrices = [None, None]
        ssBigJointMatrices = [None, None]
        ssSmallJoints = [[], []]
        ssBigJoints = [[], []]
        sRollScriptJobAttrs = []

        for p,sPart in enumerate(['bot','top']):
            fCurveLengthes[p] = curves.getLength(sBpCurvesA[0])
            fPartMult = 1 if p == 0 else -1



            # cRow = [cCorners[0]] + ccLipCtrls[p] + [cCorners[1]]
            fPercs = [0] + curves.getPercsFromTransforms(sBpCurvesA[p], [cC.sCtrl for cC in ccLipCtrls[p]]) + [1]
            fPercs = utils.addTangents(fPercs)
            sCurve = curves.rebuildWithPercs(sBpCurvesA[p], fPercs, bCreateNew=True, sName='curve_m_%sMouth' % sPart, sParent=sGrp)



            utils.data.store('sRoundExceedWhenOnAttrs', [cCorners[0].sRoundExceedAutoAttr, cCorners[1].sRoundExceedAutoAttr])
            cmds.skinCluster(sCurve, ssPartInfluences[p], tsb=True, mi=1)
            weights.skinCurveBSpline4(patch.patchFromName(sCurve), ssPartInfluences[p],
                                      bStrongEnds=True,
                                      iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster)

            iSplineJointCount = len(aaPoints[p])

            sSides, iIndices = utils.convertMiddleSequenceToSides(iSplineJointCount)
            sLocs = []
            fParams = curves.getParamsFromPoints(sCurve, aaPoints[p])
            aPercs = curves.getPercsFromParams(sCurve, fParams, bReturnNumpy=True)

            for j in range(iSplineJointCount):
                sJ = 'jnt_%s_%sMouthSplineSmall_%03d' % (sSides[j], sPart, iIndices[j])
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sSlidePivotFront)
                else:
                    cmds.createNode('joint', n=sJ, p=sSlidePivotFront)
                xforms.resetTransform(sJ, jo=True)
                cmds.setAttr('%s.radius' % sJ, fCurveLengthes[p]*0.025)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)

                sPercAttr = utils.addAttr(sJ, ln='perc', dv=aPercs[j], k=True)
                cmds.setAttr(sPercAttr, lock=True)
                ssSmallJoints[p].append(sJ)

            for j in range(iSplineJointCount):
                sJ = 'jnt_%s_%sMouthSplineBig_%03d' % (sSides[j], sPart, iIndices[j])
                if cmds.objExists(sJ):
                    cmds.parent(sJ, sSlidePivotFront)
                else:
                    cmds.createNode('joint', n=sJ, p=sSlidePivotFront)
                xforms.resetTransform(sJ, jo=True)
                cmds.setAttr('%s.radius' % sJ, fCurveLengthes[p]*0.05)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                ssBigJoints[p].append(sJ)



            fCtrlPercs = np.array([cC.fPerc for cC in ccRows[p]], dtype='float64')
            xCtrlWeightings = xforms.getCtrlWeightings(aPercs, fCtrlPercs)

            for cC in ccRows[p]:
                cC.cOrig.sLocalRotateMatrix = nodes.createMultMatrixNode([nodes.getRotationMatrix('%s.worldMatrix' % cC.cOrig.sCtrl),
                                                                        sParentRotInverseMatrix])

            # create locs
            for j,fP in enumerate(fParams):
                sLoc = xforms.createLocator('loc_%s_%sMouthSpline_%03d' % (sSides[j], sPart, iIndices[j]), sParent=sGrpSlidePivotFront, fSize=fCurveLengthes[p]*0.035)
                sNode, sPos = curves.createPointInfoNode(sCurve, fP)
                sLocalPos = nodes.createPointByMatrixNode(sPos, '%s.worldInverseMatrix' % sSlidePivotFront)


                aLocalPos = np.array(cmds.getAttr(sLocalPos)[0], dtype='float64')
                fSmallOffset = aaLocalPoints[p][j] - aLocalPos

                nodes.createVectorAdditionNode([sLocalPos, fSmallOffset], sTarget='%s.t' % sLoc)

                sAimConstraint = constraints.aimConstraintEmpty(sLoc, aim=[0,0,1], up=[-1,0,0])
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                sUpCtrl0 = nodes.createPointByMatrixNode([0,0,1], ccRows[p][iCtrl0].cOrig.sLocalRotateMatrix)
                sUpCtrl1 = nodes.createPointByMatrixNode([0,0,1], ccRows[p][iCtrl1].cOrig.sLocalRotateMatrix)
                sUpBlend = nodes.createBlendNode(fBlend, sUpCtrl1, sUpCtrl0, bVector=True)
                nodes.createVectorAdditionNode([sLocalPos, sUpBlend], sTarget='%s.target[0].targetTranslate' % sAimConstraint)

                sTangent = nodes.createPointByMatrixNode('%s.tangent' % sNode, sParentRotInverseMatrix)
                cmds.setAttr('%s.worldUpVector' % sAimConstraint, *cmds.getAttr(sTangent)[0])
                sLocs.append(sLoc)

            # slide joints
            sSlideJointMatrices = []
            aaJointStaticCurveParams = [curves.getParamsFromTransforms(sStaticSlideCurves[0], sLocs, bReturnNumpy=True),
                                        curves.getParamsFromTransforms(sStaticSlideCurves[1], sLocs, bReturnNumpy=True)]
            # fStaticCurveMidParams = [curves.getParamsFromPercs(sStaticSlideCurves[0], [0.5])[0], curves.getParamsFromPercs(sStaticSlideCurves[1], [0.5])[0]]

            for j,sJ in enumerate(ssSmallJoints[p]):
                
                sSide = utils.getSide(sJ)
                iSide = ['l','r','m'].index(sSide)
                if iSide == 2:
                    iSide = 0
                    
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                sCtrlAttr0 = '%s.midPerc' % ccRows[p][iCtrl0].sPasser
                sCtrlAttr1 = '%s.midPerc' % ccRows[p][iCtrl1].sPasser
                sJointMidPerc = nodes.createBlendNode(fBlend, sCtrlAttr1, sCtrlAttr0, sName='mouthSlide_%s_%03d_' % (sPart,j))

                sSlideCopy = xforms.createLocator('%sSlideCopy' % utils.replaceStringStart(sJ, 'jnt_', 'loc_'), sParent=sGrp, fSize=fCurveLengthes[p]*0.03)
                nodes.createDecomposeMatrix('%s.worldMatrix' % cMouth.sCtrl, sTargetScale='%s.s' % sSlideCopy, sName='mouthSlide_%s_%03d_' % (sPart,j))
                # cmds.connectAttr('%s.s' % cMouth.sCtrl, '%s.s' % sSlideCopy)
                sNode, sPos = curves.createPointInfoNode(sStaticSlideCurves[iSide], fParam=aaJointStaticCurveParams[iSide][j], sTargetPos='%s.t' % sSlideCopy, sName='mouthSlide_%s_%03d_' % (sPart,j))
                sUpNode, sUpPos = curves.createPointInfoNode(sStaticSlideUpCurves[iSide], fParam=aaJointStaticCurveParams[iSide][j], sName='mouthSlide_%s_%03d_' % (sPart,j))
                sAimConstraint = constraints.aimConstraintEmpty(sSlideCopy, sName='mouthSlide_%s_%03d_' % (sPart,j))
                # cmds.setAttr('%s.worldUpType' % sAimConstraint, 2)
                nodes.createVectorAdditionNode([sPos, '%s.tangent' % sNode], sTarget='%s.target[0].targetTranslate' % sAimConstraint, sName='mouthSlide_%s_%03d_' % (sPart,j))
                nodes.createVectorAdditionNode([sUpPos, sPos], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint, sName='mouthSlide_%s_%03d_' % (sPart,j))

                nodes.createRangeNode(sJointMidPerc, 0, 1, aaJointStaticCurveParams[iSide][j], fStaticCurveMidParams[iSide],
                                      sTarget=['%s.parameter' % sNode, '%s.parameter' % sUpNode], sName='mouthSlide_%s_%03d_' % (sPart,j))

                sLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % sSlideCopy, '%s.worldInverseMatrix' % sSlidePivotFront], sName='mouthSlide_%s_%03d_' % (sPart,j))
                sSplineOffsetToLocal = nodes.createMultMatrixNode(['%s.matrix' % sLocs[j], nodes.createInverseMatrix(sLocal, bJustValues=True)])
                sSplinesPlusSliding = nodes.createMultMatrixNode([sSplineOffsetToLocal, sLocal], sName='mouthSlideFinal_%s_%03d_' % (sPart,j))
                sSlideJointMatrices.append(sSplinesPlusSliding)


            if p == 0:
                # this is almost a copy of the previous block, where the joints get the pucker slide
                for s,sLipsEndJ in enumerate(sLipsEndJoints):
                    sSide = utils.sSides[s]
                    sJointMidPerc = '%s.midPerc' % ccRows[0][-1 if s == 1 else 0].sPasser
                    
                    fParam = 0
                    sSlideCopy = xforms.createLocator('%sSlideCopy' % utils.replaceStringStart(sLipsEndJ, 'jnt_', 'loc_'), sParent=sGrp, fSize=fCurveLengthes[p]*0.03)
                    nodes.createDecomposeMatrix('%s.worldMatrix' % cMouth.sCtrl, sTargetScale='%s.s' % sSlideCopy)
                    # cmds.connectAttr('%s.s' % cMouth.sCtrl, '%s.s' % sSlideCopy)
                    sNode, sPos = curves.createPointInfoNode(sStaticSlideCurves[s], fParam=fParam, sTargetPos='%s.t' % sSlideCopy, sName='%s_puckerSlide' % sSide)
                    sUpNode, sUpPos = curves.createPointInfoNode(sStaticSlideUpCurves[s], fParam=fParam, sName='%s_puckerSlideUp' % sSide)
                    sAimConstraint = constraints.aimConstraintEmpty(sSlideCopy, sName='puckerSlideAimConstraint_%s' % sSide)
                    nodes.createVectorAdditionNode([sPos, '%s.tangent' % sNode], sTarget='%s.target[0].targetTranslate' % sAimConstraint)
                    nodes.createVectorAdditionNode([sUpPos, sPos], sOperation='minus', sTarget='%s.worldUpVector' % sAimConstraint)
    
                    sLipsEndFollowPucker = utils.addAttr(cMouth.sPasser, ln='lipsEndFollowPucker', min=0, max=1, dv=0.5, k=True, bReturnIfExists=True)
                    sDefaultSettingAttrs.append(sLipsEndFollowPucker)
                    
                    sJointMidPerc = nodes.createMultiplyNode(sJointMidPerc,  sLipsEndFollowPucker)
                    nodes.createRangeNode(sJointMidPerc, 0, 1, fParam, fStaticCurveMidParams[s], sTarget=['%s.parameter' % sNode, '%s.parameter' % sUpNode])
    
                    sLocal = nodes.createMultMatrixNode(['%s.worldMatrix' % sSlideCopy, '%s.worldInverseMatrix' % sSlidePivotFront], sName='%s_mouthSlideLocal' % sSide)
                    sSplineOffsetToLocal = nodes.createMultMatrixNode(['%s.matrix' % sLocs[-1 if s == 1 else 0], nodes.createInverseMatrix(sLocal, bJustValues=True)], sName='%s_mouthSplineOffsetToLocal' % sSide)
                    sSplinesPlusSliding = nodes.createMultMatrixNode([sSplineOffsetToLocal, sLocal], sName='mouthSplinesPlusSliding_%03d' % j)
                    nodes.createDecomposeMatrix(sSplinesPlusSliding, sTargetPos='%s.t' % sLipsEndJoints[s], sTargetRot='%s.r' % sLipsEndJoints[s], sTargetScale='%s.s' % sLipsEndJoints[s])

                createPostRefAttrFromCurrentWorld(sLipsEndJoints)
                deformers.resetJointReferences(sLipsEndJoints)

            sRollDriver = cBotTops[p].sRollAttr
            sDummyAttributeNodeIn = cmds.createNode('transform', n='roll_dummyAttributes_%s_IN' % sPart)
            sDummyAttributeNodeOut = cmds.createNode('transform', n='roll_dummyAttributes_%s_OUT' % sPart)

            
            # create driven keys for adjusting
            for sKey in ['rot_OUT', 'rot_IN', 'up_OUT', 'forw_OUT', 'up_IN', 'forw_IN']:
                sDummyAttr = utils.addAttr(sDummyAttributeNodeIn if 'IN' in sKey else sDummyAttributeNodeOut, ln=sKey, k=True)
                sRollScriptJobAttrs.append(sDummyAttr)

            

            sRollMatrices = []
            for j,sM in enumerate(sSlideJointMatrices):
                sRotate = nodes.createConditionNode(sRollDriver, '>', 0,
                                                    nodes.createMultiplyNode(555, sRollDriver, sFullName='mult_%sMouthSpline_%03d_rotX_OUT' % (sPart,j)),
                                                    nodes.createMultiplyNode(555, sRollDriver, sFullName='mult_%sMouthSpline_%03d_rotX_IN' % (sPart,j)))

                sTranslate = nodes.createConditionNode(sRollDriver, '>', 0,
                                                    nodes.createVectorMultiplyNode([0,0,0], [sRollDriver, sRollDriver, sRollDriver], sFullName='mult_%sMouthSpline_%03d_translate_OUT' % (sPart,j)),
                                                    nodes.createVectorMultiplyNode([0,0,0], [sRollDriver, sRollDriver, sRollDriver], sFullName='mult_%sMouthSpline_%03d_translate_IN' % (sPart,j)),
                                                       bVector=True, sName='roll_%s_%03d_' % (sPart, j))

                sRollMatrix = nodes.createComposeMatrixNode(xTranslate=sTranslate, xRotate=[sRotate,0,0], sName='roll_%s_%03d_' % (sPart, j))
                sRollMatrices.append(nodes.createMultMatrixNode([sRollMatrix, sM], sName='roll_%s_%03d_' % (sPart, j)))

            # squash/stretch
            # to do: addition nodes can be optimized? And other nodes also
            sSquashStretchMatrices = []
            sPoints = [nodes.createDecomposeMatrix(sM) for sM in sRollMatrices]
            ssDistances = [], []
            for j in range(1, len(sPoints) // 2 + 1, 1):
                ssDistances[0].append(nodes.createDistanceNode(sPoints[j], sPoints[j - 1]))
            for j in range(len(sPoints) - 2, len(sPoints) // 2 - 1, -1):
                ssDistances[1].append(nodes.createDistanceNode(sPoints[j], sPoints[j + 1]))

            sSideDistanceSums = []
            aaSideScaleWeights = []
            for s, fWeights in enumerate([[1, 1, 0, 0], [0, 0, 1, 1]]):
                sSum = nodes.createAdditionNode(ssDistances[s], sFullName='sum_%s_mouthScale' % utils.sSides1[s])
                sSideDistanceSums.append(sSum)
                aaSideScaleWeights.append(utils.bSpline4(fWeights, aValues=aPercs))

            ddSquashStretchSettings['sDriverLeft'] = sSideDistanceSums[0]
            utils.data.store('ddSquashStretchSettings', ddSquashStretchSettings)

            if not ddSquashStretchSettings['bScaleJoints']:
                sSquashStretchMatrices = sRollMatrices
            else:
                sSquashStrengthHeight = utils.addAttr(cMouth.sPasser, ln='squashStrengthHeight', min=0, dv=1, k=True, bReturnIfExists=True)
                sSquashStrengthDepth = utils.addAttr(cMouth.sPasser, ln='squashStrengthDepth', min=0, dv=1, k=True, bReturnIfExists=True)
                sStretchStrengthHeight = utils.addAttr(cMouth.sPasser, ln='stretchStrengthHeight', min=0, dv=1, k=True, bReturnIfExists=True)
                sStretchStrengthDepth = utils.addAttr(cMouth.sPasser, ln='stretchStrengthDepth', min=0, dv=1, k=True, bReturnIfExists=True)
                sFactors = [nodes.createMultiplyNode(cmds.getAttr(sSideDistanceSums[0]), sSideDistanceSums[0], sOperation='divide', sName='l_%s_squashStretchFactor' % (sPart)),
                            nodes.createMultiplyNode(cmds.getAttr(sSideDistanceSums[1]), sSideDistanceSums[1], sOperation='divide', sName='r_%s_squashStretchFactor' % (sPart))]
                sDefaultSettingAttrs += [sSquashStrengthHeight, sStretchStrengthHeight, sSquashStrengthDepth, sStretchStrengthDepth]

                sCtrlScaleDiffs = []
                for c,cC in enumerate(ccRows[p]):
                    if c in [0, len(ccRows[p])-1]:
                        sScaleAttr = '%s.%sScale' % (cC.sCtrl, sPart)
                    else:
                        sScaleAttr = '%s.scale' % (cC.sCtrl)
                    sClamp = nodes.createClampNode([1.0, '%sY' % sScaleAttr, '%sZ' % sScaleAttr], [0.1, 0.1, 0.1], [10, 10, 10], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sScaleDiff = nodes.createVectorAdditionNode([sClamp, [1,1,1]], sOperation='minus', sName='%s_%s_squashStretch' % (sSide, sPart))
                    sCtrlScaleDiffs.append(sScaleDiff)

                for j, sJ in enumerate(ssSmallJoints[p]):

                    sAdditions = []

                    # left right scale from lengths
                    for s,sSide in enumerate(['l','r']):

                        sSideSquashStrength = nodes.createVectorMultiplyNode([1, sStretchStrengthHeight, sStretchStrengthDepth], aaSideScaleWeights[s][j], bVectorByScalar=True, sName='%s_%s_squashStretch_%03d_' % (sSide,sPart,j))
                        sSideStretchStrength = nodes.createVectorMultiplyNode([1, sSquashStrengthHeight, sSquashStrengthDepth], aaSideScaleWeights[s][j], bVectorByScalar=True, sName='%s_%s_squashStretch_%03d_' % (sSide,sPart,j))

                        sRanges = []
                        for sScaleType in [sSideSquashStrength, sSideStretchStrength]:
                            sRange = cmds.createNode('setRange', n='range_%s_%s_squashStretch' % (sSide, sPart))
                            cmds.connectAttr(sScaleType, '%s.value' % sRange)
                            cmds.setAttr('%s.oldMin' % sRange, 0,0,0)
                            cmds.setAttr('%s.oldMax' % sRange, 1,1,1)
                            cmds.setAttr('%s.min' % sRange, 1,1,1)
                            cmds.setAttr('%s.maxX' % sRange, 1.0)
                            cmds.connectAttr(sFactors[s], '%s.maxY' % sRange)
                            cmds.connectAttr(sFactors[s], '%s.maxZ' % sRange)
                            sRanges.append('%s.outValue' % sRange)

                        sAdditions.append(nodes.createConditionNode(sFactors[s], '<', 1,
                                          nodes.createVectorAdditionNode([sRanges[0], [1,1,1]], sOperation='minus', sName='%s_%s_squashStretch' % (sSide, sPart)),
                                          nodes.createVectorAdditionNode([sRanges[1], [1,1,1]], sOperation='minus', sName='%s_%s_squashStretch' % (sSide, sPart)), bVector=True))

                    # ctrl scales
                    iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]
                    sAdditions.append(nodes.createBlendNode(fBlend, sCtrlScaleDiffs[iCtrl1], sCtrlScaleDiffs[iCtrl0], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart)))

                    sScale = nodes.createVectorAdditionNode([[1,1,1]] + sAdditions, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sScale = nodes.createClampNode(sScale, [0.1, 0.1, 0.1], [100.0, 100.0, 100.0], bVector=True, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sLocalScaleMatrix = nodes.createComposeMatrixNode(xScale=sScale, sName='%s_%s_squashStretch' % (sSide, sPart))
                    sSquashStretchMatrices.append(nodes.createMultMatrixNode([sLocalScaleMatrix, sRollMatrices[j]], sName='%sSquashStretch_%03d' % (sPart,j)))
                    
            ssSmallJointMatrices[p] = sSquashStretchMatrices

            sResetOrientJointMatrices = []
            for j,sM in enumerate(sSlideJointMatrices):
                iCtrl0, iCtrl1, fBlend = xCtrlWeightings[j]

                sDecompPos = nodes.createDecomposeMatrix(sM)
                sDecomp = sDecompPos.split('.')[0]

                sJawAttachBlended = nodes.createBlendNode(fBlend, '%s.jawAttach' % ccRows[p][iCtrl1].sCtrl,
                                                                  '%s.jawAttach' % ccRows[p][iCtrl0].sCtrl, sName='jawAttach_%03d_' % j)
                sBlendedRotMatrix = nodes.createBlendMatrixNode([sJawSliderRotateMatrix, cmds.getAttr(sJawSliderRotateMatrix)],
                                                                [sJawAttachBlended, nodes.createReverseNode(sJawAttachBlended)], sName='jawAttach_%03d_' % j)

                sResetMatrix = nodes.createComposeMatrixNode(xTranslate = sDecompPos,
                                                             xRotate = nodes.createDecomposeMatrix(sBlendedRotMatrix, bReturnRotate=True),
                                                             xScale = '%s.outputScale' % sDecomp, sName='jawAttach_%03d_' % j)

                sResetOrientJointMatrices.append(sResetMatrix)
            ssBigJointMatrices[p] = sResetOrientJointMatrices

        ssSmallDecomposeMatrices = [[nodes.createDecomposeMatrix(sM, sName='_bot_beforeLipSeal_%03d' % j) for j,sM in enumerate(ssSmallJointMatrices[0])],
                                    [nodes.createDecomposeMatrix(sM, sName='_top_beforeLipSeal_%03d' % j) for j,sM in enumerate(ssSmallJointMatrices[1])]]

        sSealLeftByFade = nodes.fromEquation('%s * (1.0+%s)' % (cCorners[0].sSeal, cCorners[0].sSealFadeLength), sName='left_sealByFade')
        sSealRightByFade = nodes.fromEquation('%s * (1.0+%s)' % (cCorners[1].sSeal, cCorners[1].sSealFadeLength), sName='right_sealByFade')


        for p,sPart in enumerate(['bot','top']):
            fLeftPercs = utils.bSpline4([0, 0, 1, 1], aValues=np.arange(len(aaPoints[p])) / float(len(aaPoints[p]) - 1))
            fRightPercs = 1.0 - fLeftPercs
            aPercsToOther = curves.getPercsFromPoints(sBpCurvesA[1 - p], aaPoints[p], bReturnNumpy=True)
            aPercsAtOther = curves.getPercsFromPoints(sBpCurvesA[1 - p], aaPoints[1 - p], bReturnNumpy=True)
            iClosestJoints = xforms.findClosestFloats(aPercsToOther, aPercsAtOther)

            xOtherJointWeightings = []
            for j in range(len(aPercsToOther)):
                iJoint0 = iClosestJoints[j]
                iJoint1 = iClosestJoints[j]
                if aPercsToOther[j] < aPercsAtOther[iJoint0]:
                    if iJoint0 > 0:
                        iJoint1 = iJoint0 - 1
                elif aPercsToOther[j] > aPercsAtOther[iJoint0]:
                    if iJoint0 < len(aPercsAtOther) - 2:
                        iJoint1 = iJoint1 + 1
                fBlend = utils.projectToRange(aPercsToOther[j], aPercsAtOther[iJoint0], aPercsAtOther[iJoint1], 0, 1)

                xOtherJointWeightings.append([iJoint0, iJoint1, fBlend])

            for j in range(len(aaPoints[p])):
                sLeftRightSeals = cmds.createNode('plusMinusAverage', n='plus_sumSeals_%03d' % j)

                sEndLeft = nodes.createAdditionNode([fLeftPercs[j], cCorners[0].sSealFadeLength], sName='left_sealFadeLength_%03d' % j)
                sRangeLeft = nodes.createRangeNode(sSealLeftByFade, fLeftPercs[j], sEndLeft, 0.0, 1.0, sName='left_seal_%03d' % j)
                nodes.setDrivenKey(sRangeLeft, [0, 1], '%s.input1D[0]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

                sEndRight = nodes.createAdditionNode([fRightPercs[j], cCorners[1].sSealFadeLength], sName='right_sealFadeLength_%03d' % j)
                sRangeRight = nodes.createRangeNode(sSealRightByFade, fRightPercs[j], sEndRight, 0.0, 1.0, sName='right_seal_%03d' % j)
                nodes.setDrivenKey(sRangeRight, [0, 1], '%s.input1D[1]' % sLeftRightSeals, [0, 1], sInTanType='flat', sOutTanType='flat')

                sClamp = nodes.createClampNode('%s.output1D' % sLeftRightSeals, 0, 1, sName='lipSeal_%s_%03d' % (sPart,j))
                sJointBlendStrength = nodes.createMultiplyNode(sClamp, 0.5, sName='lipSeal_%s_%03d' % (sPart,j))

                # get other joint weightings
                iJoint0, iJoint1, fBlend = xOtherJointWeightings[j]
                sOtherPos = nodes.createBlendNode(fBlend, ssSmallDecomposeMatrices[1-p][iJoint1],
                                                          ssSmallDecomposeMatrices[1-p][iJoint0], bVector=True, sName='lipSeal_%s_%03d_' % (sPart,j))
                fOffset = np.array(aaLocalPoints[p][j], dtype='float64') - \
                          np.array(cmds.getAttr(sOtherPos)[0], dtype='float64')
                sOffsettedOtherPos = nodes.createVectorAdditionNode([sOtherPos, list(fOffset)], sName='lipSeal_%s_%03d_' % (sPart,j))
                sBlendPos = nodes.createBlendNode(sJointBlendStrength, sOffsettedOtherPos, ssSmallDecomposeMatrices[p][j], bVector=True, sName='lipSeal_%s_%03d_' % (sPart,j))
                sNewM = nodes.createComposeMatrixNode(xTranslate=sBlendPos,
                                                      xRotate='%s.outputRotate' % ssSmallDecomposeMatrices[p][j].split('.')[0],
                                                      xScale='%s.outputScale' % ssSmallDecomposeMatrices[p][j].split('.')[0], sName='lipSeal_%s_%03d_' % (sPart,j))
                ssSmallJointMatrices[p][j] = sNewM


        # finally set them
        for p,sPart in enumerate(['bot','top']):
            # finally connect the small joints
            for j,sJ in enumerate(ssSmallJoints[p]):
                nodes.createDecomposeMatrix(ssSmallJointMatrices[p][j], sTargetPos = '%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ, sName='finalDecomposeSmall_%s_%03d' % (sPart,j))
            deformers.resetJointReferences(ssSmallJoints[p])
            utils.data.store('%sLipJointsSmall' % sPart, ssSmallJoints[p])


            # finally connect the big joints
            for j,sJ in enumerate(ssBigJoints[p]):
                nodes.createDecomposeMatrix(ssBigJointMatrices[p][j], sTargetPos = '%s.t' % sJ, sTargetRot='%s.r' % sJ, sTargetScale='%s.s' % sJ, sName='finalDecomposeBig_%s_%03d' % (sPart,j))
            deformers.resetJointReferences(ssBigJoints[p])

        createRollDrivenKeys(ddRollValues)

        setRollValuesFromDrivenKeys(bForce=True)


        for sDummyAttr in sRollScriptJobAttrs:
            print('sDummyAttr: ', sDummyAttr)
            cmds.scriptJob(attributeChange=[sDummyAttr, setRollValuesFromDrivenKeys])
        
        # # mouth lipsEnd
        # for s, sSide in enumerate(['l', 'r']):
        #     # # lipsEnd joint
        #     # sLipsEnd = 'jnt_%s_lipsEnd' % sSide
        #     # if cmds.objExists(sLipsEnd):
        #     #     cmds.parent(sLipsEnd, sSlidePivotFront)
        #     # else:
        #     #     cmds.createNode('joint', n=sLipsEnd, p=sSlidePivotFront)
        #     # cmds.setAttr('%s.radius' % sLipsEnd, fCurveLengthes[0] * 0.075)
        #     # cmds.setAttr('%s.segmentScaleCompensate' % sLipsEnd, False)
        #     # sBlend = nodes.createConditionNode('%s.tx' % cCorners[s].sCtrl, '>', 0, 0.0, sLipsEndFollowPuckerAttr)
        #     sOuterLipBigJoint = ssBigJoints[0][-1 if s == 1 else 0]
        #
        #     cmds.connectAttr('%s.ty' % sOuterLipBigJoint, '%s.ty' % sLipsEnd)
        #     fDefaultT = cmds.getAttr('%s.t' % sOuterLipBigJoint)[0]
        #
        #     sCornerSlideLocDefault = xforms.createTransform('loc_%s_cornerSlideLocDefault' % sSide, sParent=sParentGrp,
        #                                                     sMatch=sCornerSlideLocs[s])
        #     sBlendAttr = xforms.constraintBlend(sLipsEnd, sCornerSlideLocDefault, sCornerSlideLocs[s],
        #                                         sCtrl=cMouth.sPasser, sAttr='lipsEndRotateOnSlide',
        #                                         func=cmds.orientConstraint, bMaintainOffset=True)
        #     sDefaultSettingAttrs.append(sBlendAttr)
        #
        #     # utils.addStringAttr(sLipsEnd, deformers.kPostRefJointAttr, str(utils.invertFlatMatrix(cmds.xform(sLipsEnd, q=True, m=True, ws=True))))
        #     createPostRefAttrFromCurrentWorld(sLipsEnd)
        #     deformers.resetJointReferences(sLipsEnd)


        for cC in cPosingCtrls:
            dAttrs = utils._getAnimAttrsFromNode(cC.sCtrl)
            utils.addStringAttr(cC.sCtrl, 'dMouthDefaultValues', str(dAttrs), bLock=True)

        for sA, fV in list(dDefaultSettingValues.items()):
            if cmds.objExists(sA):
                try:
                    cmds.setAttr(sA, fV)
                except Exception as e:
                    report.report.addLogText('skipping saved default value "%s" (errors: "%s")' % (sA, str(e)))
            else:
                report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)

    # EXCLUDE END MOUTHSPLINES


    for sCurve in sBpCurvesA+sBpCurvesB:
        cmds.setAttr('%s.v' % sCurve, False)

    utils.data.store('sDefaultSettingAttrs', sDefaultSettingAttrs)


def roundCornerRom(fJawRotates, fCornerRange):
    cmds.setKeyframe('lipsCornerLFT_ctrl.pointyRound', t=1, v=0.0)
    cmds.setKeyframe('lipsCornerRGT_ctrl.pointyRound', t=1, v=0.0)
    fCurrentTime = 5.0
    cmds.setKeyframe('lipsCornerLFT_ctrl.pointyRound', t=fCurrentTime, v=1.0)
    cmds.setKeyframe('lipsCornerRGT_ctrl.pointyRound', t=fCurrentTime, v=1.0)
    sJawAttr = '%s.rz' % jawCtrl()
    sCornerAttrs = ['lipsCornerLFT_ctrl.translateX', 'lipsCornerRGT_ctrl.translateX']
    fCurrentTime = 5.0
    for fJawRotate in ([0.0] + fJawRotates):
        cmds.setKeyframe(sJawAttr, t=fCurrentTime, v=fJawRotate)
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=0)
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=0)
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=fCornerRange[0])
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=fCornerRange[0])
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=fCornerRange[1])
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=fCornerRange[1])
        fCurrentTime += 5.0
        cmds.setKeyframe(sCornerAttrs[0], t=fCurrentTime, v=0)
        cmds.setKeyframe(sCornerAttrs[1], t=fCurrentTime, v=0)
        fCurrentTime += 5.0

    cmds.playbackOptions(e=True, minTime=0, maxTime=fCurrentTime)

            


@builderTools.addToBuild(iOrder=65, bDisableByDefault=True, dButtons={'create rom':roundCornerRom})
def calibratePointyRound(fCornerRange=[-1,1.5], fJointIndexFromLeft=1.0, fJawRotates=[-8, -15, -25], fTangentScales=[1,1.5,2.0], fPostMultipl=1.0):
    '''
    If "fJointIndexFromLeft" is 0.0, then he's taking the 2nd joint from the very left or right to \
    analize the roundness during the calibrating. If it's one, then it's the 1st Sjoint. If there \
    are issues calibrating, this is the first value you should experiment with.

    To find the values for fTangentScales: break the connections to inf_l_lipsCornerMouthInfluenceBot and inf_l_lipsCornerMouthInfluenceTop,
    and try scaling it while mouth is open

    fPostMultipl happens after the calibration
    '''

    if utils.data.get('bMouthSplines', xDefault=False) == False:
        report.report.addLogText('skipping because mouth is not setup with bSPLINES')
        return False


    kPointyRoundPrefix = 'pointyRoundCalibrate__'

    sOldNodes = cmds.ls('%s*' % kPointyRoundPrefix)
    if sOldNodes:
        cmds.delete(sOldNodes)

    # sCornerCtrls = ['lipsCornerLFT_ctrl', 'lipsCornerRGT_ctrl']
    cCornerCtrls = [ctrls5.ctrlFromName('lipsCornerLFT_ctrl'),
                    ctrls5.ctrlFromName('lipsCornerRGT_ctrl')]


    sCalibrateNodeOutputs = []
    try:
        ssLipJoints = [None, None]
        for p,sPart in enumerate(['bot','top']):
            ssLipJoints[p] = utils.data.get('%sLipJointsSmall' % sPart)

        iJointIndexFromLeftFloor = int(math.floor(fJointIndexFromLeft))
        if (fJointIndexFromLeft - iJointIndexFromLeftFloor) < 0.0001:
            iJointIndexFromLeftCeil = iJointIndexFromLeftFloor + 1
        else:
            iJointIndexFromLeftCeil = int(math.ceil(fJointIndexFromLeft))
        fJointT = fJointIndexFromLeft - iJointIndexFromLeftFloor


        sPointBotFloor = nodes.getWorldPoint(ssLipJoints[0][iJointIndexFromLeftFloor])
        sPointBotCeil = nodes.getWorldPoint(ssLipJoints[0][iJointIndexFromLeftCeil])

        sPointTopFloor = nodes.getWorldPoint(ssLipJoints[1][iJointIndexFromLeftFloor])
        sPointTopCeil = nodes.getWorldPoint(ssLipJoints[1][iJointIndexFromLeftCeil])


        sOpenDriver = nodes.createDistanceNode(nodes.getWorldPoint('mouthBot_ctrl'), nodes.getWorldPoint('mouthTop_ctrl'))

        sJawAttr = '%s.rz' % jawCtrl()

        fClosedValue = cmds.getAttr(sOpenDriver)
        fOpenValues = []
        for r, fRot in enumerate(fJawRotates):
            cmds.setAttr(sJawAttr, fRot)
            fOpenValues.append(cmds.getAttr(sOpenDriver))
        cmds.setAttr(sJawAttr, 0.0)

        sExceedWhenOnAttrs = utils.data.get('sRoundExceedWhenOnAttrs')
        sPointyRoundAttrs = ['%s.pointyRound' % cCornerCtrls[0].sCtrl, '%s.pointyRound' % cCornerCtrls[1].sCtrl]
        sPointyRoundAttrSums = ['%s.pointyRoundSum' % cCornerCtrls[0].sPasser, '%s.pointyRoundSum' % cCornerCtrls[1].sPasser]

        for s, sSide in enumerate(['l', 'r']):
            sTangentScalesAuto = utils.data.get('sTangentScalesAuto_%s' % sSide)
            # sJoints = ['inf_%s_lipsCornerMouthInfluenceBot' % sSide, 'inf_%s_lipsCornerMouthInfluenceTop' % sSide]
            sDrivenKeys0 = nodes.setDrivenKey(sOpenDriver, [fClosedValue] + fOpenValues, None, [1] + fTangentScales)
            sDrivenKeys1 = nodes.setDrivenKey(sOpenDriver, [fClosedValue] + fOpenValues, None, [1] + fTangentScales)

            nodes.createBlendNode(sPointyRoundAttrSums[s], sDrivenKeys0, 1.0, sTarget=sTangentScalesAuto[0], bForce=True)
            nodes.createBlendNode(sPointyRoundAttrSums[s], sDrivenKeys1, 1.0, sTarget=sTangentScalesAuto[1], bForce=True)


        sTempCalibrateParentMatrix = nodes.createComposeMatrixNode(xTranslate=nodes.getWorldPoint(ssLipJoints[0][0]),
                                                                   xRotate=nodes.createDecomposeMatrix('ctrl_l_lipsCornerOrigOut.worldMatrix', bReturnRotate=True))

        sTempCalibrateParentInverseMatrix = nodes.createInverseMatrix(sTempCalibrateParentMatrix)
        sTempCalibratePointBot = nodes.createPointByMatrixNode(nodes.createBlendNode(fJointT, sPointBotCeil, sPointBotFloor, bVector=True),
                                                               sTempCalibrateParentInverseMatrix)
        sTempCalibratePointTop = nodes.createPointByMatrixNode(nodes.createBlendNode(fJointT, sPointTopCeil, sPointTopFloor, bVector=True),
                                                               sTempCalibrateParentInverseMatrix)

        sTempCalibratePointNormalizedBot = nodes.createNormalizedVector(['%sX' % sTempCalibratePointBot, '%sY' % sTempCalibratePointBot, 0])
        sTempCalibratePointNormalizedTop = nodes.createNormalizedVector(['%sX' % sTempCalibratePointTop, '%sY' % sTempCalibratePointTop, 0])

        sTempDot = nodes.createDotProductNode(sTempCalibratePointNormalizedBot, sTempCalibratePointNormalizedTop)
        sTempAverageHoriz = nodes.createBlendNode(0.5, '%sX' % sTempCalibratePointNormalizedBot, '%sX' % sTempCalibratePointNormalizedTop)

        sParentLoc = cmds.spaceLocator(n='calibrateInfo')[0]
        sLoc0 = cmds.spaceLocator()[0]
        sLoc1 = cmds.spaceLocator()[0]
        sLoc2 = cmds.spaceLocator()[0]
        cmds.parent(sLoc0, sLoc1, sLoc2, sParentLoc)
        cmds.connectAttr(sTempCalibratePointNormalizedBot, '%s.t' % sLoc0)
        cmds.connectAttr(sTempCalibratePointNormalizedTop, '%s.t' % sLoc1)
        cmds.connectAttr(sTempAverageHoriz, '%s.tx' % sLoc2)
        cmds.connectAttr(sTempDot, '%s.ty' % sLoc2)
        def calibrate():
            fDirection = -1 if cmds.getAttr(sTempAverageHoriz) > 0 else 1
            iTestingCount = 18
            fValues = np.arange(iTestingCount) * 5 * fDirection
            fDots = [0] * iTestingCount
            for v, fValue in enumerate(fValues): #(18 = 90 / 5)
                cmds.setAttr(sExceedWhenOnAttrs[0], float(fValue))
                fDots[v] = cmds.getAttr(sTempDot)
            iSmallestDot = np.argmin(fDots)
            return fValues[iSmallestDot]


        # cmds.setAttr(sPointyRoundAttrs[0], 1.0 - cmds.getAttr(sPointyRoundAttrSums[0]))
        report.report.resetProgress(len(fJawRotates))
        ssDrivenKeys = [], []
        for fJawRotate in fJawRotates:
            print('\n\n\n ============ JAWROTATE: ', fJawRotate)

            cmds.setAttr(sJawAttr, fJawRotate)
            cmds.setAttr(sPointyRoundAttrs[0], 0.0)
            cmds.setAttr(sPointyRoundAttrs[0], 1.0 - cmds.getAttr(sPointyRoundAttrSums[0]))

            # fLipOutDriverValues = [-0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0, 1.5]
            iHorizCount = 8
            fLipOutDriverValues =  np.interp(np.arange(iHorizCount), [0, iHorizCount-1], fCornerRange)

            aValues = np.zeros(len(fLipOutDriverValues), dtype='float64')
            for v,fX in enumerate(fLipOutDriverValues):
                print('=================== calibrating.. ', fX, fJawRotate)
                cmds.setAttr('%s.tx' % cCornerCtrls[0].sCtrl, fX)
                aValues[v] = calibrate()
            aValues *= fPostMultipl

            for s, sSide in enumerate(['l','r']):
                sDks = nodes.setDrivenKey('%s.tx' % cCornerCtrls[s].sCtrl, fLipOutDriverValues, None, aValues)
                ssDrivenKeys[s].append(sDks)
                sCalibrateNodeOutputs.append(sDks)
            report.report.incrementProgress()

        cmds.setAttr(sPointyRoundAttrs[0], 0.0)
        cmds.setAttr(sJawAttr, 0.0)
        cmds.setAttr('%s.tx' % cCornerCtrls[0].sCtrl, 0.0)


        sCalibrateNodeOutputs.append(sOpenDriver)


        for s,sSide in enumerate(['l','r']):
            sPrevCond = 0.0
            for r in range(len(fJawRotates) - 1):
                iFrom = r
                iTo =  r+1
                sRange = nodes.createRangeNode(sOpenDriver, fOpenValues[iFrom], fOpenValues[iTo], ssDrivenKeys[s][iFrom], ssDrivenKeys[s][iTo],
                                               sName='%s_pointyRoundCondition_%03d' % (sSide,r))
                sNewCond = nodes.createConditionNode(sOpenDriver, '<', fOpenValues[iTo], sRange, 0,
                                                     sName='%s_pointyRoundCondition_%03d' % (sSide,r))

                if r == 0:
                    cmds.connectAttr(sNewCond, sExceedWhenOnAttrs[s])
                else:
                    sPrevCondNode = sPrevCond.split('.')[0]
                    cmds.connectAttr(sNewCond, '%s.colorIfFalseR' % sPrevCondNode)
                    if r == len(fJawRotates) - 2:
                        sNewCondNode = sNewCond.split('.')[0]
                        cmds.connectAttr(ssDrivenKeys[s][iTo], '%s.colorIfFalseR' % sNewCondNode)

                sPrevCond = sNewCond
                sCalibrateNodeOutputs += [sRange, sNewCond]

    except:
        raise
    finally:
        for o, sO in enumerate(sCalibrateNodeOutputs):
            sNode = sO.split('.')[0]
            sCalibrateNodeOutputs[o] = cmds.rename(sNode, '%s%s' % (kPointyRoundPrefix, sNode))


sCheekGroupName = '_grp_m_cheekBps'
kCheekFileName = 'blueprintCheek.ma'
dButtons = OrderedDict()
dButtons['Create Left Cheek Curve (Tracked Order)'] = lambda: createBpCurve('bpCurve_l_cheek', sCheekGroupName,
                                                                            fDirection=(0, 1, 0), bTrackedOrder=True)
dButtons['Create Left Cheek Curve (Tracked Order)'].dSideButtons = {'?':['The vertices here don\'t have to be neighbor vertices, as long '\
                                                            '\nas you select them in the correct order', 'cheekTrackedOrder.jpg']}
dButtons['Create Left Cheek Curve'] = lambda: createBpCurve('bpCurve_l_cheek', sCheekGroupName,
                                                            fDirection=(0, 1, 0))
dButtons['Create Left Cheek Curve'].dSideButtons = {'?':['If the vertices all neighbors, you can use that '\
                                             'button instead of the one above']}
dButtons['Create Left Cheek PushOut Curve'] = lambda: createBpUpVectorCurve('bpCurve_l_cheekUp',
                                                                            'bpCurve_l_cheek')
dButtons['Create Left Cheek PushOut Curve'].dSideButtons = {'?':['no selection needed, he\'ll create the curve himself']}

dButtons['=== DEFAULT ATTRS ==='] = getDefaultAttrsMenu('sDefaultSettingAttrsCheeks', 'dDefaultSettingValuesCheeks')


dButtons['Export BPs'] = lambda: exportBps(kCheekFileName, sCheekGroupName)


@builderTools.addToBuild(iOrder=62.4, dButtons=dButtons, bDisableByDefault=True)
def createCheekSetup(sParentJoint='jnt_m_headMain', fCtrlPercs=[0.33, 0.66], iCheekCurveJointCount=8, dDefaultSettingValuesCheeks={}):
    sDefaultSettingAttrsCheeks = []
    
    sGroup = cmds.createNode('transform', n='grp_cheekSetup', p='modules')
    fCtrlPercs = [0.0] + fCtrlPercs + [1.0]
    ccCtrls = [], []
    ssJoints = [], []
    sGlobalScale = nodes.getScaleFromXform(sParentJoint)

    for s,sSide in enumerate(['l', 'r']):
        fSideMultipl = -1.0 if sSide == 'r' else 1.0
        sBpCurve = 'bpCurve_%s_cheek' % sSide
        sBpUpCurve = 'bpCurve_%s_cheekUp' % sSide
        
        curves.mirrorIfNotExists(sBpCurve)
        curves.mirrorIfNotExists(sBpUpCurve)
        
        aCtrlPoints = curves.getPointsFromPercs(sBpCurve, fCtrlPercs)
        aCtrlPointsUp = curves.getPointsFromPercs(sBpUpCurve, fCtrlPercs)
        sCurve = cmds.curve(p=aCtrlPoints, n='curve_%s_cheek' % sSide)
        sCurveUp = cmds.curve(p=aCtrlPointsUp, n='curve_%s_cheekUp' % sSide)
        cmds.parent(sCurve, sCurveUp, sGroup)
        
        aCtrlPoints = patch.patchFromName(sCurve).getPoints()
        aTangents = curves.getTangentsFromPercs(sCurve, fCtrlPercs)
        aCtrlPointsUp = patch.patchFromName(sCurveUp).getPoints()
        fCurveLength = curves.getLength(sCurve)
        fCtrlSize = fCurveLength * 0.1
        fSliderScale = fCurveLength * 0.1
        sTempLoc = cmds.spaceLocator()[0]
        sInfluences = []
        for c, fParam in enumerate(fCtrlPercs):
            cmds.setAttr('%s.t' % sTempLoc, *list(aCtrlPoints[c]))
            xforms.orientThreePoints(sTempLoc, aCtrlPointsUp[c]-aCtrlPoints[c], aTangents[c], fAimVector=[0,0,fSideMultipl], fUpVector=[-fSideMultipl,0,0])
            cCtrl = ctrls5.create('cheek', sSide, c, sShape='sphere', sAttrs=['t','r'], fSize=fCtrlSize, fSliderScale=fSliderScale, sParent=_getFaceCtrlGrp(), sMatch=sTempLoc, iSlider=2)
            
            xforms.matrixParentConstraint(sParentJoint, cCtrl.sPasser, mo=True)
            ccCtrls[s].append(cCtrl)
            sInf = cmds.createNode('joint', n='inf_%s_cheek_%03d' % (sSide, c), p=cCtrl.sOut)
            cmds.setAttr('%s.radius' % sInf, fCtrlSize*0.5)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sInf)
            sInfluences.append(sInf)
            
            
            if c in [0,len(fCtrlPercs)-1]:
                cCtrl.convertToSimpleTransforms()
            else:
                #
                # move with corners
                #
                sMoveToAttrs = [utils.addAttr(cCtrl.sCtrl, ln='moveToCorner%s' % sSuffix, k=True, min=0, max=1, dv=0.5) for sSuffix in ['Horiz', 'Vert', 'Depth']]
                sMoveOffset = cCtrl.appendOffsetGroup('movewithcorner')
                sCorner = 'jnt_%s_lipsEnd' % sSide
                fCtrlPos = cmds.xform(cCtrl.sCtrl, q=True, ws=True, t=True)
                
                fStraightMatrix = list(utils.fIdentityMatrix)
                fStraightMatrix[12:15] = fCtrlPos

                fCtrlInCorner = nodes.createPointByMatrixNode(fCtrlPos, '%s.worldInverseMatrix' % sCorner, bJustValues=True)
                sFullMoveCtrl = nodes.createPointByMatrixNode(fCtrlInCorner, '%s.worldMatrix' % sCorner)

                fStraightMatrixInSlider = nodes.createMultMatrixNode([fStraightMatrix, '%s.worldInverseMatrix' % cCtrl.sSlider], bJustValues=True)
                sSliderStraightened = nodes.createMultMatrixNode([fStraightMatrixInSlider, '%s.worldMatrix' % cCtrl.sSlider])
                sSliderStraightenedInv = nodes.createInverseMatrix(sSliderStraightened)
                
                sFullMoveCtrlInStraight = nodes.createPointByMatrixNode(sFullMoveCtrl, sSliderStraightenedInv)
                
                sFullMoveCtrlStrenghted = nodes.createVectorMultiplyNode(sMoveToAttrs, sFullMoveCtrlInStraight)
                sDefaultSettingAttrsCheeks.extend(sMoveToAttrs)
                
                sMoveCtrlWorld = nodes.createPointByMatrixNode(sFullMoveCtrlStrenghted, sSliderStraightened)
                nodes.createPointByMatrixNode(sMoveCtrlWorld, '%s.worldInverseMatrix' % cCtrl.sSlider, sTarget='%s.t' % sMoveOffset)
                
                #
                # push out
                #
                sPushOutAttr = utils.addAttr(cCtrl.sCtrl, ln='pushOut', k=True, min=0, max=1, dv=0.5)
                sPushOutOffset = cCtrl.appendOffsetGroup('pushfromcorner')
                sDistance = nodes.createDistanceNode(nodes.getWorldPoint(sCorner), nodes.getWorldPoint(cCtrl.sPasser), sDivide='%sX' % sGlobalScale)
                fDistance = cmds.getAttr(sDistance)
                sDistanceStrength = nodes.createRangeNode(sDistance, fDistance, 0, 0, fDistance)
                nodes.createMultiplyNode(sDistanceStrength, sPushOutAttr, sTarget='%s.tz' % sPushOutOffset)
                sDefaultSettingAttrsCheeks.append(sPushOutAttr)

            
        cmds.skinCluster(sCurve, sInfluences, tsb=True)
        cmds.skinCluster(sCurveUp, sInfluences, tsb=True)
        cmds.delete(sTempLoc)


        # joints
        aJointPercs = np.arange(iCheekCurveJointCount) / (iCheekCurveJointCount-1)
        fJointParams = curves.getParamsFromPercs(sCurve, aJointPercs)
        sParentRotationMatrix = nodes.getRotationMatrix('%s.worldMatrix' % sParentJoint)
        sParentRotationMatrixInv = nodes.createInverseMatrix(sParentRotationMatrix)
        for j,fParam in enumerate(fJointParams):
            sInfoNode, sPoint = curves.createPointInfoNode(sCurve, fParam)
            sInfoNodeUp, sPointUp = curves.createPointInfoNode(sCurveUp, fParam)
            sJ = 'jnt_%s_cheek_%03d' % (sSide,j)
            if cmds.objExists(sJ):
                cmds.parent(sJ, sParentJoint)
            else:
                cmds.createNode('joint', n=sJ, p=sParentJoint)
            cmds.setAttr('%s.radius' % sJ, fCtrlSize*0.3)
            nodes.createPointByMatrixNode(sPoint, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.t' % sJ)
            sAimConstraint = constraints.aimConstraintEmpty(sJ)
            nodes.createPointByMatrixNode(sPointUp, '%s.worldInverseMatrix' % sParentJoint, sTarget='%s.target[0].targetTranslate' % sAimConstraint)
            nodes.createPointByMatrixNode('%s.tangent' % sInfoNode, sParentRotationMatrixInv, sTarget='%s.worldUpVector' % sAimConstraint)
            ssJoints[s].append(sJ)
        
    createPostRefAttrFromCurrentWorld(ssJoints[0] + ssJoints[1])
    utils.data.store('sDefaultSettingAttrsCheeks', sDefaultSettingAttrsCheeks)
    deformers.resetJointReferences(ssJoints[0] + ssJoints[1])

    for sA, fV in list(dDefaultSettingValuesCheeks.items()):
        if cmds.objExists(sA):
            try:
                cmds.setAttr(sA, fV)
            except Exception as e:
                report.report.addLogText('skipping saved default value "%s" (errors: "%s")' % (sA, str(e)))
        else:
            report.report.addLogText('skipping saved default value "%s" (doesn\'t exist)' % sA)


dButtons = OrderedDict()
dButtons['select MAP meshes'] = lambda: cmds.select(cmds.ls('*__MAPS', et='transform'))

dButtons['- Export *Slider* BPs -'] = ctrls5.exportSliderBps
@builderTools.addToBuild(iOrder=63, dButtons=dButtons)
def autoSetupSliders(dSplitRadienFactors={'fOuterBrow':1.0, 'fMouthPucker':1.0, 'fMouthCorner':0.75, 'fUpperLips':0.5, 'fLowerLips':0.5, 'fBlink':1.0, 'fNostril':0.25}, iUpperLowerSmoothIterations=3,
                            sMirrorJointAxes=[], dSkip={'bSkipCornerShapes':False, 'bSkipMouthDirectionShapes':False, 'bSkipLipShapes':False, 'bSkipJawShapes':False, 'bSkipLidCloseShapes':False},
                            ddTargetsAsAttributes={'lipsCornerLFT_ctrl':{'sTarget':'', 'fSplitRadius':0.5}},
                            ddExtraTargetSliders=[{'sName':'newName', 'dTargets':{'sTargetUp':'', 'sTargetDown':'', 'sTargetIn':'', 'sTargetOut':''}, 'bMirror':True}],
                            ddCorrectives={'TARGETNAME': {'dPoses': {'lipsCornerLFT_ctrl.tx': 1.0}, 'fSplitRadius': 0.5, 'bMirror':True, 'sDrivers':[]}},
                            sIgnoreTargets=[]):


    # _importMapMeshes()
    bMouthSplines = utils.data.get('bMouthSplines', xDefault=False)

    blendShapesPro.clearWeightsCache()

    fUpperLipsSplitRadiusFactor = dSplitRadienFactors['fUpperLips']
    fLowerLipsSplitRadiusFactor = dSplitRadienFactors['fUpperLips']
    fOuterBrowSplitRadiusFactor = dSplitRadienFactors['fOuterBrow']
    fMouthPuckerSplitRadiusFactor = dSplitRadienFactors['fMouthPucker']
    fMouthCornerSplitRadiusFactor = dSplitRadienFactors['fMouthCorner']
    fBlinkSplitRadiusFactor = dSplitRadienFactors['fBlink']
    fNostrilSplitRadiusFactor = dSplitRadienFactors['fNostril']


    # sSuffixes = utils.data.get('sImportedHeadSuffixes', xDefault=['']) #, xDefault=[])
    utils.data.store('sMirrorJointAxes', sMirrorJointAxes) #, xDefault=[])
    bReturn = None
    sSuffix = ''
    xMirrorAxis = None

    report.report.resetProgress(12)
    fBlinkSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.1
    fNoseSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.2
    fBrowSplitRadius = xforms.distanceBetween('jnt_l_eye%sMain' % sSuffix, 'jnt_r_eye%sMain' % sSuffix) * 0.5


    report.report.addLogText('splitting blueprints... ', bIncrementProgress=True)

    sModel = utils.data.get('sBakedBlendshapeMainMesh%s' % sSuffix)
    sTargets = set(utils.data.get('sBakedBlendshapeTargets%s' % sSuffix, xDefault=[])) - set(sIgnoreTargets)


    sSecondaryModels = []
    for sT in sTargets:
        if '__' in sT:
            sSecondaryModels.append(sT.split('__')[0])
    sSecondaryModels = list(set(sSecondaryModels) - set(sTargets)) # without minus targets he would catch inbetweens as secondaryModels
    sSecondaryModels = [sM for sM in sSecondaryModels if cmds.objExists(sM)]

    sSecondaryModels += utils.data.get('sExtraSecondaryModels%s' % sSuffix, xDefault=[])

    utils.data.store('sAllSecondaryModels%s' % sSuffix, sSecondaryModels)

    sParentJoint = 'jnt_m_headMain'
    sJawJoint = 'jnt_m_jawMain'


    # for sTarget, dData in list(dControlKeys.items()):
    #     if isinstance(dData, (str,unicode)):
    #         dData = eval(dData)
    #
    #     blendShapesPro.connectTargets(sModel, sTarget,
    #                                 dPoses=dData['dPoses'],
    #                                 # sDriversGetAttr=dData.get('sDriversGetAttr', []),
    #                                 bMirror=dData.get('bMirror', True),
    #                                 fSplitRadius=dData.get('fSplitRadius', 1.0),
    #                                 iInvert=dData.get('iInvert',2),
    #                                 sSecondaryModels=sSecondaryModels,
    #                                 fOvershootRange=[0, 10],
    #                                 xMirrorAxis=xMirrorAxis)

    fMouthCurveEndsDistance = utils.data.get('fMouthCurveEndsDistance%s' % sSuffix, xDefault=1.0)
    fMouthSplitRadius = fMouthCurveEndsDistance * 0.5
    # fMouthSliderScale = fMouthCurveEndsDistance * 0.25

    bLipCurves = utils.data.get('bLipCurves%s' % sSuffix, xDefault=False)

    if bLipCurves:
        cCorners = [ctrls5.ctrlFromName('lipsCornerLFT_ctrl', bReturnNoneIfNotExists=True), ctrls5.ctrlFromName('lipsCornerRGT_ctrl', bReturnNoneIfNotExists=True)]

        if cCorners[0]:
            ddSquashStretchSettings = utils.data.get('ddSquashStretchSettings')
            if not utils.isNone(ddSquashStretchSettings):
                blendShapesPro.connectTargets(sModel, ddSquashStretchSettings['sShrinkTarget'],
                                           dPoses={'%s.tx' % cCorners[0].sCtrl: ddSquashStretchSettings['fShrinkCornerValue']},
                                           # dDrivers={ddSquashStretchSettings['sDriverLeft']:None},
                                           fSplitRadius=fMouthSplitRadius,
                                           bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bMirror=True)

                blendShapesPro.connectTargets(sModel, ddSquashStretchSettings['sExpandTarget'],
                                           dPoses={'%s.tx' % cCorners[0].sCtrl: ddSquashStretchSettings['fExpandCornerValue']},
                                           # dDrivers={ddSquashStretchSettings['sDriverLeft']:None},
                                           fSplitRadius=fMouthSplitRadius,
                                           bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, iInvert=2, bMirror=True)
        # ddSquashStretchSettings = {'bScaleJoints': True, 'fShrinkCornerValue': -1, 'fExpandCornerValue': 1.0,
        #                            'sShrinkTarget': 'mouthSquash', 'sExpandTarget': 'mouthStretch'},
        else:
            cCorners = None



        report.report.addLogText('upper/lower lips... ', bIncrementProgress=True)
        if not dSkip.get('bSkipLipShapes', False):
            sLowerDown = 'lowerDown%s' % sSuffix
            sLowerUp = 'lowerUp%s' % sSuffix
            sUpperDown = 'upperDown%s' % sSuffix
            sUpperUp = 'upperUp%s' % sSuffix
            cBot = ctrls5.ctrlFromName('mouthBot_ctrl')
            cTop = ctrls5.ctrlFromName('mouthTop_ctrl')
            cMouth = ctrls5.ctrlFromName('mouth_ctrl')

            if sLowerDown in sTargets or sLowerUp in sTargets:
                fBotVertRange = [-1.0 if sLowerDown in sTargets else 0.0, 1.0 if sLowerUp in sTargets else 0.0]
                blendShapesPro.connectTargets(sModel, sLowerUp, dPoses={'%s.ty' % cBot.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sLowerDown, dPoses={'%s.ty' % cBot.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                ctrls5.setSliderRange(cBot, fRangeY=fBotVertRange, bAdjustBorders=True)

                dLowerSplitAlongCurve = utils.data.get('dLipSplitAlongCurve%s' % sSuffix)

                if not utils.isNone(dLowerSplitAlongCurve):
                    dLowerSplitAlongCurve['iSmoothIterations'] = iUpperLowerSmoothIterations
                    blendShapesPro.connectTargets(sModel, sLowerDown, dPoses={}, dSplitAlongCurve=dLowerSplitAlongCurve, bMirror=False,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    dLowerSplitAlongCurve['ffValues'] = [[1.0] * len(dLowerSplitAlongCurve['ffValues'][0])]
                    blendShapesPro.connectTargets(sModel, sLowerUp, dPoses={}, dSplitAlongCurve=dLowerSplitAlongCurve, bMirror=False,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                else: # simple left/right
                    sLipBotCtrls = utils.data.get('sLipBotCtrls')
                    blendShapesPro.connectTargets(sModel, sLowerDown, dPoses={'%s.ty' % sLipBotCtrls[0]: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    blendShapesPro.connectTargets(sModel, sLowerUp, dPoses={'%s.ty' % sLipBotCtrls[0]: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



            if sUpperUp in sTargets or sUpperDown in sTargets:
                fTopVertRange = [-1.0 if sUpperDown in sTargets else 0.0, 1.0 if sUpperUp in sTargets else 0.0]

                blendShapesPro.connectTargets(sModel, sUpperUp, dPoses={'%s.ty' % cTop.sCtrl: 1}, fSplitRadius=fMouthSplitRadius * fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sUpperDown, dPoses={'%s.ty' % cTop.sCtrl: -1}, fSplitRadius=fMouthSplitRadius * fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                ctrls5.setSliderRange(cTop, fRangeY=fTopVertRange, bAdjustBorders=True)

                dUpperSplitAlongCurve = utils.data.get('dUpperSplitAlongCurve%s' % sSuffix)
                if not utils.isNone(dUpperSplitAlongCurve):
                    dUpperSplitAlongCurve['iSmoothIterations'] = iUpperLowerSmoothIterations
                    blendShapesPro.connectTargets(sModel, sUpperUp, dPoses={}, dSplitAlongCurve=dUpperSplitAlongCurve, bMirror=False, bControlRigCommands=True,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis)
                    dUpperSplitAlongCurve['ffValues'] = [[-1.0] * len(dUpperSplitAlongCurve['ffValues'][0])]
                    blendShapesPro.connectTargets(sModel, sUpperDown, dPoses={}, dSplitAlongCurve=dUpperSplitAlongCurve, bMirror=False, bControlRigCommands=True,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis)
                else: # simple left/right. MIGHT NEVER GET INTO THIS ANYMORE ?!
                    sLipTopCtrls = utils.data.get('sLipTopCtrls')

                    blendShapesPro.connectTargets(sModel, sUpperUp, dPoses={'%s.ty' % sLipTopCtrls[0]: 1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                    blendShapesPro.connectTargets(sModel, sUpperDown, dPoses={'%s.ty' % sLipTopCtrls[0]: -1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                                bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        if not utils.isNone(cCorners):
            for sTarget in ['mouthRound']:
                sTargetSuffix = '%s%s' % (sTarget, sSuffix)
                if cmds.objExists(sTargetSuffix):
                    sAttrs = [utils.addAttr(cCorners[s].sCtrl, ln=sTarget, minValue=0.0, maxValue=1.0, k=True) for s in [0, 1]]
                    blendShapesPro.connectTargets(sModel, sTargetSuffix, dPoses={sAttrs[0]:1.0}, fSplitRadius=fMouthSplitRadius * fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels)

    report.report.addLogText('brows... ', bIncrementProgress=True)

    sBrowIn = 'browIn%s' % sSuffix
    sBrowOut = 'browOut%s' % sSuffix
    sInnerBrowDown = 'innerBrowDown%s' % sSuffix
    sInnerBrowUp = 'innerBrowUp%s' % sSuffix

    sInnerBrowShapes = [sInnerBrowUp, sInnerBrowDown, sBrowIn, sBrowOut]
    if sTargets.intersection(set(sInnerBrowShapes)):
        fRangeX = [-1,1]
        fRangeY = [-1,1]

        if not cmds.objExists(sBrowIn):
            fRangeX[0] = 0
        if not cmds.objExists(sBrowOut):
            fRangeX[1] = 0
        if not cmds.objExists(sInnerBrowDown):
            fRangeY[0] = 0
        if not cmds.objExists(sInnerBrowUp):
            fRangeY[1] = 0

        cInnerBrows = ctrls5.createSliderCtrl('innerEyebrow%s' % sSuffix, 'l', fRangeX=fRangeX, fRangeY=fRangeY, sAttach=sModel,
                                                    sAlignOnModel=[sModel]+sInnerBrowShapes, xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, 'innerBrowUp%s' % sSuffix, dPoses={'%s.ty' % cInnerBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        blendShapesPro.connectTargets(sModel, 'innerBrowDown%s' % sSuffix, dPoses={'%s.ty' % cInnerBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,1], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        blendShapesPro.connectTargets(sModel, 'browIn%s' % sSuffix, dPoses={'%s.tx' % cInnerBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, 'browOut%s' % sSuffix, dPoses={'%s.tx' % cInnerBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*0.5,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sOuterBrowUp = 'outerBrowUp%s' % sSuffix
    sOuterBrowDown = 'outerBrowDown%s' % sSuffix
    if sOuterBrowUp in sTargets or sOuterBrowDown in sTargets:
        fRangeY = [-1,1]
        if not cmds.objExists(sOuterBrowDown):
            fRangeY[0] = 0
        if not cmds.objExists(sOuterBrowUp):
            fRangeY[1] = 0

        cOuterBrows = ctrls5.createSliderCtrl('outerEyebrow%s' % sSuffix, 'l', fRangeY=fRangeY, sAttach=sModel,
                                                    sAlignOnModel=[sModel, 'outerBrowUp', 'outerBrowDown'], xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, sOuterBrowUp, dPoses={'%s.ty' % cOuterBrows[0].sCtrl:1.0}, fSplitRadius=fBrowSplitRadius*fOuterBrowSplitRadiusFactor,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, sOuterBrowDown, dPoses={'%s.ty' % cOuterBrows[0].sCtrl:-1.0}, fSplitRadius=fBrowSplitRadius*fOuterBrowSplitRadiusFactor,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


    report.report.addLogText('cheeks... ', bIncrementProgress=True)

    sCheekRaiser = 'cheekRaiser%s' % sSuffix
    sCheekUp = 'cheekUp%s' % sSuffix
    if not cmds.objExists(sCheekRaiser) and cmds.objExists(sCheekUp):
        sCheekRaiser = sCheekUp
    sCheekLower = 'cheekLower%s' % sSuffix

    if sCheekRaiser in sTargets or sCheekLower in sTargets:
        fRangeY = [-1, 1]
        if not cmds.objExists(sCheekLower):
            fRangeY[0] = 0
        if not cmds.objExists(sCheekRaiser):
            fRangeY[1] = 0

        cCheekRaiser = ctrls5.createSliderCtrl('cheekRaiser%s' % sSuffix, 'l', fRangeY=fRangeY, sAttach=sModel, sAlignOnModel=[sModel, 'cheekRaiser', 'cheekLower'],
                                                     xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, sCheekRaiser, dPoses={'%s.ty' % cCheekRaiser[0].sCtrl: 1.0}, fSplitRadius=fNoseSplitRadius,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, sCheekLower, dPoses={'%s.ty' % cCheekRaiser[0].sCtrl: -1.0}, fSplitRadius=fNoseSplitRadius,
                                    bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    sSquint = 'squint%s' % sSuffix
    if sSquint in sTargets:
        cSquints = ctrls5.createSliderCtrl(sSquint, 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sSquint])
        blendShapesPro.connectTargets(sModel, sSquint, dPoses={'%s.ty' % cSquints[0].sCtrl:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)


    sCheekOut = 'cheekOut%s' % sSuffix
    if not cmds.objExists(sCheekOut):
        sCheekOut = 'puff%s' % sSuffix
    sCheekIn = 'cheekIn%s' % sSuffix

    if sCheekOut in sTargets or sCheekIn in sTargets:
        fPuffRange = [-1,1]
        if sCheekOut not in sTargets:
            fPuffRange[1] = 0.0
        if sCheekIn not in sTargets:
            fPuffRange[0] = 0.0

        cPuffs = ctrls5.createSliderCtrl('puff%s' % sSuffix, 'l', fRangeY=fPuffRange, sShape='doubleArrowSquareY', sAttach=sModel,
                                               sAlignOnModel=[sModel, sCheekOut, sCheekIn], xMirrorAxis=xMirrorAxis)
        if sCheekOut in sTargets:
            blendShapesPro.connectTargets(sModel, sCheekOut, dPoses={'%s.ty' % cPuffs[0].sCtrl:1.0}, fSplitRadius=fMouthSplitRadius,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        if sCheekIn in sTargets:
            blendShapesPro.connectTargets(sModel, sCheekIn, dPoses={'%s.ty' % cPuffs[0].sCtrl:-1.0}, fSplitRadius=fMouthSplitRadius,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


    sPuffFront = 'puffFront%s' % sSuffix
    if sPuffFront in sTargets:
        cPuffFront = ctrls5.createSliderCtrl('puffFront', 'm', fRangeY=[0,1], sShape='doubleArrowSquareY', sAttach=sModel, sAlignOnModel=[sModel, sPuffFront])
        blendShapesPro.connectTargets(sModel, sPuffFront, dPoses={'%s.ty' % cPuffFront[0].sCtrl:1.0}, bMirror=False,
                                   sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10])

    sLipStretch = 'lipStretch%s' % sSuffix
    if sLipStretch in sTargets:
        cLipStretch = ctrls5.createSliderCtrl('lipStretch', 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sLipStretch])
        blendShapesPro.connectTargets(sModel, sLipStretch, dPoses={'%s.ty' % cLipStretch[0].sCtrl:1.0}, fSplitRadius=fMouthSplitRadius * fLowerLipsSplitRadiusFactor,
                                   sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)

    sNeckStretch = 'neckStretch%s' % sSuffix
    if sNeckStretch in sTargets:
        cNeckStretch = ctrls5.createSliderCtrl('neckStretch', 'l', fRangeY=[0,1], sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, sNeckStretch])
        blendShapesPro.connectTargets(sModel, sNeckStretch, dPoses={'%s.ty' % cNeckStretch[0].sCtrl:1.0},
                                   sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], fSplitRadius=fMouthSplitRadius * fLowerLipsSplitRadiusFactor, bControlRigCommands=True)




    report.report.addLogText('nose... ', bIncrementProgress=True)


    sNoseWrinkler = 'noseWrinkler%s' % sSuffix
    sNoseDown = 'noseDown%s' % sSuffix
    if sNoseWrinkler in sTargets or sNoseDown in sTargets:
        fRange = [0,0]
        if sNoseWrinkler in sTargets:
            fRange[1] = 1.0
        if sNoseDown in sTargets:
            fRange[0] = -1.0

        cNoseWrinklers = ctrls5.createSliderCtrl('noseWrinkler%s' % sSuffix, 'l', fRangeY=fRange,
                                                       sShape='doubleArrowSquareY', sAttach=sModel, sAlignOnModel=[sModel, sNoseWrinkler], xMirrorAxis=xMirrorAxis)
        blendShapesPro.connectTargets(sModel, sNoseWrinkler, dPoses={'%s.ty' % cNoseWrinklers[0].sCtrl:1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, sNoseDown, dPoses={'%s.ty' % cNoseWrinklers[0].sCtrl:-1.0}, fSplitRadius=fNoseSplitRadius,
                                    sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)

    sNostrilIn = 'nostrilIn%s' % sSuffix
    sNostrilOut = 'nostrilOut%s' % sSuffix
    if sNostrilIn in sTargets or sNostrilOut in sTargets:
        fNostrilRange = [-1,1]
        if sNostrilIn not in sTargets:
            fNostrilRange[0] = 0.0
        if sNostrilOut not in sTargets:
            fNostrilRange[1] = 0.0

        cNostrils = ctrls5.createSliderCtrl('nostril%s' % sSuffix, 'l', fRangeX=fNostrilRange,
                                                  sShape='sphere', sAttach=sModel, sAlignOnModel=[sModel, None, None, sNostrilIn, sNostrilOut], xMirrorAxis=xMirrorAxis)
        if sNostrilOut in sTargets:
            blendShapesPro.connectTargets(sModel, sNostrilOut, dPoses={'%s.tx' % cNostrils[0].sCtrl:1.0}, fSplitRadius=fNoseSplitRadius*fNostrilSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        if sNostrilIn in sTargets:
            blendShapesPro.connectTargets(sModel, sNostrilIn, dPoses={'%s.tx' % cNostrils[0].sCtrl:-1.0}, fSplitRadius=fNoseSplitRadius*fNostrilSplitRadiusFactor,
                                        sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


    if not dSkip.get('bSkipJawShapes', False):
        report.report.addLogText('jaw... ', bIncrementProgress=True)

        if utils.data.exists('sBakedBlendShapeJawOpenRotation%s' % sSuffix):
            fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation%s' % sSuffix)
            blendShapesPro.connectTargets(sModel, 'jawOpen%s' % sSuffix,
                                       dPoses={'jaw%s_ctrl.r' % sSuffix: tuple(fJawOpenRotation)},
                                       dDrivers={'jaw%s_ctrl.rz' % sSuffix:fJawOpenRotation[2]},
                                       iInvert=2,
                                       bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, bControlRigCommands=True)
        else:
            report.report.addLogText('skipping jaw because not set up in blendShape file')

    report.report.addLogText('eyelids... ', bIncrementProgress=True)

    cBlinkCtrls = [ctrls5.ctrlFromName('blink%sLFT_ctrl' % sSuffix), ctrls5.ctrlFromName('blink%sRGT_ctrl' % sSuffix)]
    sBlink = 'blink%s' % sSuffix
    sBlinkCurvedUp = 'blinkCurvedUp%s' % sSuffix
    sLeftLidTop = ctrls5.ctrlFromName('lidTop%sLFT_ctrl' % sSuffix).sCtrl
    sLeftLidBot = ctrls5.ctrlFromName('lidBot%sLFT_ctrl' % sSuffix).sCtrl

    if not dSkip.get('bSkipLidCloseShapes', False):
        if cmds.objExists('blinkCurvedUp'):
            utils.addAttr(cBlinkCtrls[0].sCtrl, ln='upCurveBlink', minValue=0.0, maxValue=1.0, k=True)
            utils.addAttr(cBlinkCtrls[1].sCtrl, ln='upCurveBlink', minValue=0.0, maxValue=1.0, k=True)
            blendShapesPro.connectTargets(sModel, sBlink, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:[0,-1.0], '%s.upCurveBlink' % cBlinkCtrls[0].sCtrl:[1,0]}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, sSecondaryModels=sSecondaryModels, bReturnIfNotExist=True, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            blendShapesPro.connectTargets(sModel, sBlinkCurvedUp, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:[0,-1.0], '%s.upCurveBlink' % cBlinkCtrls[0].sCtrl:[0,1]}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, sSecondaryModels=sSecondaryModels, bReturnIfNotExist=True, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        else:
            blendShapesPro.connectTargets(sModel, sBlink, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:-1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                        iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

        blendShapesPro.connectTargets(sModel, 'eyeUpperDown%s' % sSuffix, dPoses={'%s.ty' % sLeftLidTop: -1.0}, fSplitRadius=fBlinkSplitRadius * fBlinkSplitRadiusFactor,
                                   iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
        blendShapesPro.connectTargets(sModel, 'eyeLowerUp%s' % sSuffix, dPoses={'%s.ty' % sLeftLidBot:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                    iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    blendShapesPro.connectTargets(sModel, 'eyeWide%s' % sSuffix, dDrivers={'%s.ty' % cBlinkCtrls[0].sCtrl:0.5}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
    blendShapesPro.connectTargets(sModel, 'eyeUpperUp%s' % sSuffix, dPoses={'%s.ty' % sLeftLidTop:1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

    blendShapesPro.connectTargets(sModel, 'eyeLowerDown%s' % sSuffix, dPoses={'%s.ty' % sLeftLidBot:-1.0}, fSplitRadius=fBlinkSplitRadius*fBlinkSplitRadiusFactor,
                                iInvert=2, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    dEyelookPoses = utils.data.get('dEyelookPoses', xDefault={})

    if dEyelookPoses:
        sEyePoints = []
        sPoseAdditions = []
        for s,sSide in enumerate(['l','r']):
            sEyeRotAttr = 'jnt_%s_eyeMain.r' % sSide
            sPlug = cmds.listConnections(sEyeRotAttr, p=True, s=True, d=False)[0]
            cmds.disconnectAttr(sPlug, sEyeRotAttr)
            sAddition = nodes.createVectorAdditionNode([sPlug, [0,0,0]], sFullName='addition_%s_tempPoseEye' % sSide, sTarget=sEyeRotAttr)
            sPoseAdditions.append('%s.input3D[1]' % sAddition.split('.')[0])

        for sDirection, bVert in [('eyelookDown',True), ('eyelookUp',True), ('eyelookLeft',False), ('eyelookRight',False)]:
            fEyeRotPose = dEyelookPoses.get(sDirection, None)
            if not utils.isNone(fEyeRotPose):
                cLeftLookAt = ctrls5.ctrlFromName('eyesLookAtLFT_ctrl', bReturnNoneIfNotExists=True)
                print ('cLeftLookAt: ', cLeftLookAt)
                if not cLeftLookAt:
                    cLeftLookAt = ctrls5.ctrlFromName('eyeLookAtLFT_ctrl')
                
                sDriver = '%s.lookVert' % cLeftLookAt.sPasser if bVert else '%s.lookHoriz' % cLeftLookAt.sPasser
                # sUnrealDriver = 'sLookVert_l_eye' if bVert else 'sLookHoriz_l_eye'
                
                print ('cLeftLookAt: ', cLeftLookAt.sCtrl)
                blendShapesPro.connectTargets(sModel, sDirection,
                                           dPoses = {sPoseAdditions[0]: fEyeRotPose, sPoseAdditions[1]: (fEyeRotPose[0], -fEyeRotPose[1], fEyeRotPose[2])},
                                           dDrivers = {sDriver:None, '%s.lidFollow' % cLeftLookAt.sCtrl:1},
                                           fSplitRadius=fBlinkSplitRadius * fBlinkSplitRadiusFactor,
                                           iInvert=0, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels,
                                           fOvershootRange=[0, 10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)



    sMouthClose = 'mouthClose%s' % sSuffix
    if bLipCurves:

        if not dSkip.get('bSkipMouthDirectionShapes', False):
            report.report.addLogText('mouth directions... ', bIncrementProgress=True)

            blendShapesPro.connectTargets(sModel, 'mouthLeft%s' % sSuffix, dPoses={'%s.tx' % cMouth.sCtrl:1.0},
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            if cmds.objExists('mouthLeft') and not cmds.objExists('mouthRight'):
                cmds.duplicate('mouthLeft', n='mouthRight')
                geometry.meshMirrorMiddle([patch.patchFromName('mouthRight')], iDirection=geometry.MirrorDirection.flip, bControlRigCommands=True)

            blendShapesPro.connectTargets(sModel, 'mouthRight%s' % sSuffix, dPoses={'%s.tx' % cMouth.sCtrl:-1.0},
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)

            blendShapesPro.connectTargets(sModel, 'mouthUp%s' % sSuffix, dPoses={'%s.ty' % cMouth.sCtrl:1.0},
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)
            blendShapesPro.connectTargets(sModel, 'mouthDown%s' % sSuffix, dPoses={'%s.ty' % cMouth.sCtrl:-1.0},
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)

            blendShapesPro.connectTargets(sModel, 'mouthLeft%s' % sSuffix, dPoses={'%s.tx' % cBot.sCtrl:1.0, '%s.tx' % cTop.sCtrl:1.0}, bSplitBotTop=True,
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)
            blendShapesPro.connectTargets(sModel, 'mouthRight%s' % sSuffix, dPoses={'%s.tx' % cBot.sCtrl:-1.0, '%s.tx' % cTop.sCtrl:-1.0}, bSplitBotTop=True,
                                        bMirror=False, bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True)


        report.report.addLogText('lip corners... ', bIncrementProgress=True)

        if not utils.isNone(cCorners) and not dSkip.get('bSkipCornerShapes', False):

            sCornerUp = 'cornerUp%s' % sSuffix
            sCornerDown = 'cornerDown%s' % sSuffix
            sCornerOut = 'cornerOut%s' % sSuffix
            sCornerOutUp = 'cornerOutUp%s' % sSuffix
            sCornerOutDown = 'cornerOutDown%s' % sSuffix
            sPucker = 'pucker%s' % sSuffix

            if cmds.objExists('cornerOutUp') or cmds.objExists('cornerOutDown'):
                # to do: what if only one exists?
                for s,sSide in enumerate(['l','r']):
                    # sCornerCtrl = 'lipsCorner%s_ctrl' % utils.sSides3[s]
                    xforms.createBarycentricCornerWeightsAttrs('%s.t' % cCorners[s].sCtrl, sSide, cCorners[s].sCtrl)

                blendShapesPro.connectTargets(sModel, sCornerUp, dPoses={'%s.ty' % cCorners[0].sCtrl:1}, dDrivers={'%s.up' % cCorners[0].sCtrl:None},
                                            fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sCornerOut, dPoses={'%s.tx' % cCorners[0].sCtrl:1.0}, dDrivers={'%s.out' % cCorners[0].sCtrl:None},
                                            fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sCornerOutUp, dPoses={'%s.t' % cCorners[0].sCtrl:(1,1,0)}, dDrivers={'%s.outUp' % cCorners[0].sCtrl:None},
                                            fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sCornerDown, dPoses={'%s.ty' % cCorners[0].sCtrl:1}, dDrivers={'%s.down' % cCorners[0].sCtrl:None},
                                            fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sCornerOutDown, dPoses={'%s.t' % cCorners[0].sCtrl:(1,1,0)}, dDrivers={'%s.outDown' % cCorners[0].sCtrl:None},
                                            fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            else:
                blendShapesPro.connectTargets(sModel, sCornerUp, dPoses={'%s.ty' % cCorners[0].sCtrl:1}, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sCornerDown, dPoses={'%s.ty' % cCorners[0].sCtrl:-1}, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, sCornerOut, dPoses={'%s.tx' % cCorners[0].sCtrl:1}, fSplitRadius=fMouthSplitRadius*fMouthCornerSplitRadiusFactor,
                                            sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True, bControlRigCommands=True)

            blendShapesPro.connectTargets(sModel, sPucker, dPoses={'%s.tx' % cCorners[0].sCtrl:-1.0}, fSplitRadius=fMouthSplitRadius*fMouthPuckerSplitRadiusFactor,
                                        bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)


            # sSecondOut = utils.addAttr('lipsCornerLFT_ctrl', ln='secondOut', minValue=0.0, maxValue=1.0, k=True)
            # utils.addAttr('lipsCornerRGT_ctrl', ln='secondOut', minValue=0.0, maxValue=1.0, k=True)
            # blendShapesPro.connectTargets(sModel, sCornerOut, dPoses={sSecondOut: 1.0},
            #                              fSplitRadius=fMouthSplitRadius * fMouthCornerSplitRadiusFactor,
            #                              sSecondaryModels=sSecondaryModels, fOvershootRange=[0, 10],
            #                              xMirrorAxis=xMirrorAxis, bReturnIfNotExist=True)

        if not dSkip.get('bSkipLipShapes', False):
            fTopRollRange = [0,0]
            report.report.addLogText('lip rolls... ', bIncrementProgress=True)
            if 'upperRollOut' in sTargets or 'upperRollIn' in sTargets:
                fTopRollRange = [-1.0 if 'upperRollIn' in sTargets else 0.0, 1.0 if 'upperRollOut' in sTargets else 0.0]
                blendShapesPro.connectTargets(sModel, 'upperRollOut%s' % sSuffix, dPoses={'%s.tz' % cTop.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, 'upperRollIn%s' % sSuffix, dPoses={'%s.tz' % cTop.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fUpperLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
            if not bMouthSplines:
                ctrls5.setSliderRange(cTop, fRangeZ=fTopRollRange, bAdjustBorders=True)


            fBotRollRange = [0, 0]
            if 'lowerRollOut' in sTargets or 'lowerRollIn' in sTargets:
                fBotRollRange = [-1.0 if 'lowerRollIn' in sTargets else 0.0, 1.0 if 'lowerRollOut' in sTargets else 0.0]
                blendShapesPro.connectTargets(sModel, 'lowerRollOut%s' % sSuffix, dPoses={'%s.tz' % cBot.sCtrl: 1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)
                blendShapesPro.connectTargets(sModel, 'lowerRollIn%s' % sSuffix, dPoses={'%s.tz' % cBot.sCtrl: -1}, fSplitRadius=fMouthSplitRadius*fLowerLipsSplitRadiusFactor,
                                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], xMirrorAxis=xMirrorAxis, bControlRigCommands=True)

            if not bMouthSplines:
                ctrls5.setSliderRange(cBot, fRangeZ=fBotRollRange, bAdjustBorders=True)


            report.report.addLogText('lipPress/funnel/fff... ', bIncrementProgress=True)

        # blendShapesPro.connectTargets(sModel, 'forward%s' % sSuffix, dPoses={'mouthBot_ctrl.tz':1, 'mouthTop_ctrl.tz':1}, fSplitRadius=8.0, bSplitBotTop=True,
        #                            bReturnIfNotExist=True, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10])

        if not dSkip.get('bSkipLipShapes', False):
            bMouthSplines = utils.data.get('bMouthSplines%s' % sSuffix)
            
            if 'funnel' in sTargets:
                blendShapesPro.connectTargets(sModel, 'funnel%s' % sSuffix, dPoses={'mouth_ctrl.tz':1}, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True, iInvert=2 if bMouthSplines else 0)

            if 'lipPress' in sTargets:
                blendShapesPro.connectTargets(sModel, 'lipPress%s' % sSuffix, dPoses={'mouth_ctrl.tz':-1}, sSecondaryModels=sSecondaryModels, fOvershootRange=[0,10], bControlRigCommands=True, iInvert=2 if bMouthSplines else 0)


    report.report.addLogText('Extra Targets... ', bIncrementProgress=True)
    for sCtrl, dData in list(ddTargetsAsAttributes.items()):
        sTarget = dData.get('sTarget', None)
        if not sTarget:
            continue
            # raise Exception, '%s in ddTargetsAsAttributes doesn\'t have a sTarget defined' % sTarget

        sTargetSuffix = '%s%s' % (sTarget, sSuffix)
        sCtrlSuffix = '%s%s' % (sCtrl, sSuffix)
        fSplitRadius = dData.get('fSplitRadius', 0.2)
        if utils.getSide(sCtrl) == 'l':
            sAttrs = [utils.addAttr(sCtrlSuffix, ln=sTarget, min=0, max=1, dv=0, k=True),
                      utils.addAttr(utils.getMirrorName(sCtrlSuffix), ln=sTarget, min=0, max=1, dv=0, k=True)]
            bMirror = True
        else:
            sAttrs = [utils.addAttr(sCtrlSuffix, ln=sTarget, min=0, max=1, dv=0, k=True)]
            bMirror = False

        blendShapesPro.connectTargets(sModel, sTargetSuffix, dPoses={sAttrs[0]:1.0},
                                    fSplitRadius=fSplitRadius,
                                    sSecondaryModels=sSecondaryModels,
                                    bMirror=bMirror)


    for dSlider in ddExtraTargetSliders:
        sExtraTargets = [None] * 4
        dTargets = dSlider['dTargets']

        bOneOfThemExists = False
        for k, sKey in enumerate(['sTargetUp', 'sTargetDown', 'sTargetOut', 'sTargetIn']):
            sValue = dTargets.get(sKey, '')
            if sValue and cmds.objExists(sValue):
                sExtraTargets[k] = sValue
                bOneOfThemExists = True

        if bOneOfThemExists:
            fRangeY = [0,0]
            fRangeX = [0,0]
            if sExtraTargets[0] or sExtraTargets[1]:
                fRangeY = [-1 if sExtraTargets[1] else 0,
                          1 if sExtraTargets[0] else 0]
            if sExtraTargets[2] or sExtraTargets[3]:
                fRangeX = [-1 if sExtraTargets[3] else 0,
                          1 if sExtraTargets[2] else 0]



            bMirror = dSlider.get('bMirror', True)
            cSliders = ctrls5.createSliderCtrl('%s%s' % (dSlider['sName'], sSuffix), 'l' if bMirror else 'm', fRangeX=fRangeX, fRangeY=fRangeY, sAttach=sModel,
                                                sShape=dSlider.get('sShape', 'sphere'), sAlignOnModel=[sModel]+sExtraTargets, xMirrorAxis=xMirrorAxis)

            if sExtraTargets[0]: # up
                blendShapesPro.connectTargets(sModel, sExtraTargets[0], dPoses={'%s.ty' % cSliders[0].sCtrl: 1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror)
            if sExtraTargets[1]: # down
                blendShapesPro.connectTargets(sModel, sExtraTargets[1], dPoses={'%s.ty' % cSliders[0].sCtrl: -1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror)
            if sExtraTargets[2]: # in
                blendShapesPro.connectTargets(sModel, sExtraTargets[2], dPoses={'%s.tx' % cSliders[0].sCtrl: 1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror)
            if sExtraTargets[3]: # out
                blendShapesPro.connectTargets(sModel, sExtraTargets[3], dPoses={'%s.tx' % cSliders[0].sCtrl: -1.0},
                                           fSplitRadius=dSlider.get('fSplitRadius', fMouthSplitRadius),
                                           sSecondaryModels=sSecondaryModels,
                                           bMirror=bMirror)


    for sTarget, dData in list(ddCorrectives.items()):
        if not cmds.objExists(sTarget):
            continue
        dDrivers = {}
        if dData['sDrivers']:
            dDrivers = {sD:None for sD in dData['sDrivers']}

        blendShapesPro.connectTargets(sModel, '%s%s' % (sTarget, sSuffix),
                                    dPoses=dData['dPoses'],
                                    fSplitRadius=dData.get('fSplitRadius', 0.2),
                                    sSecondaryModels=sSecondaryModels,
                                    bMirror=dData.get('bMirror', True),
                                    dDrivers = dDrivers,
                                    iInvert=2)


    report.report.addLogText('mouth close... ', bIncrementProgress=True)

    dConnectTargetPoses = utils.data.get('dConnectTargetPoses', xDefault={}) # should be defaultDict(list), but that can't be stored
    dConnectTargetDrivers = utils.data.get('dConnectTargetDrivers', xDefault={}) # should be defaultDict(list), but that can't be stored
    dConnectTargetSplitRadien = utils.data.get('dConnectTargetSplitRadien', xDefault={})
    dConnectTargetMirrors = utils.data.get('dConnectTargetMirrors', xDefault={})
    dConnectTargetSplitBotTops = utils.data.get('dConnectTargetSplitBotTops', xDefault={})
    dConnectTargetInverts = utils.data.get('dConnectTargetInverts', xDefault={})
    dConnectTargetSplitAlongCurves = utils.data.get('dConnectTargetSplitAlongCurves', xDefault={})
    dConnectTargetZippers = utils.data.get('dConnectTargetZippers', xDefault={})
    dConnectTargetControlRigCommands = utils.data.get('dConnectTargetControlRigCommands', xDefault={})
    dConnectTargetLidRanges = utils.data.get('dConnectTargetLidRanges', xDefault={})


    if bLipCurves:
        sMouthCloseAttr = utils.addAttr('mouth_ctrl', ln=sMouthClose, minValue=0.0, maxValue=1.0, k=True, bReturnIfExists=True)

        utils.addListKey(dConnectTargetPoses, sMouthClose)
        utils.addListKey(dConnectTargetDrivers, sMouthClose)
        utils.addListKey(dConnectTargetMirrors, sMouthClose)
        utils.addListKey(dConnectTargetSplitRadien, sMouthClose)
        utils.addListKey(dConnectTargetSplitBotTops, sMouthClose)
        utils.addListKey(dConnectTargetInverts, sMouthClose)
        utils.addListKey(dConnectTargetSplitAlongCurves, sMouthClose)
        utils.addListKey(dConnectTargetZippers, sMouthClose)
        utils.addListKey(dConnectTargetLidRanges, sMouthClose)
        utils.addListKey(dConnectTargetControlRigCommands, sMouthClose)

        dConnectTargetPoses[sMouthClose].append({sMouthCloseAttr: 1.0})
        dConnectTargetDrivers[sMouthClose].append({sMouthCloseAttr: [0,1]}) # in the normal command this is created manually.
        dConnectTargetMirrors[sMouthClose].append(False)
        dConnectTargetSplitRadien[sMouthClose].append(1.0)
        dConnectTargetSplitBotTops[sMouthClose].append(False)
        dConnectTargetInverts[sMouthClose].append(2)
        dConnectTargetSplitAlongCurves[sMouthClose].append({})
        dConnectTargetZippers[sMouthClose].append({})
        dConnectTargetLidRanges[sMouthClose].append([])
        dConnectTargetControlRigCommands[sMouthClose].append([])


    utils.data.store('dConnectTargetPoses', dConnectTargetPoses)
    utils.data.store('dConnectTargetDrivers', dConnectTargetDrivers)
    utils.data.store('dConnectTargetSplitRadien', dConnectTargetSplitRadien)
    utils.data.store('dConnectTargetMirrors', dConnectTargetMirrors)
    utils.data.store('dConnectTargetSplitBotTops', dConnectTargetSplitBotTops)
    utils.data.store('dConnectTargetInverts', dConnectTargetInverts)
    utils.data.store('dConnectTargetSplitAlongCurves', dConnectTargetSplitAlongCurves)
    utils.data.store('dConnectTargetZippers', dConnectTargetZippers)
    utils.data.store('dConnectTargetLidRanges', dConnectTargetLidRanges)
    utils.data.store('dConnectTargetControlRigCommands', dConnectTargetControlRigCommands)

    # combo shapes
    sComboTargets = [sT for sT in sTargets if '_' in sT and '__' not in sT]
    sComboTargets.sort(key=lambda sT:len(sT.split('_')))

    report.report.addLogText('All the combos......', bIncrementProgress=True, bRefresh=True)
    report.report.resetProgress(len(sComboTargets))

    for sComboT in sComboTargets:
        bSuccess, sMessage = blendShapesPro.autoConnectComboTarget(sComboT, sModel, sSecondaryModels, xMirrorAxis=xMirrorAxis, bLegacyIgnoreEyeLookHoriz=False)
        report.report.addLogText(sMessage, bRefresh=True, bIncrementProgress=True)
        if not bSuccess:
            bReturn = False

    for sM in [sModel] + sSecondaryModels:
        if not utils.isNone(sM):
            for sBlendShape in deformers.listAllDeformers(sM, sFilterTypes=['blendShape']):
                deformers.makeNotExport(sBlendShape)

    return bReturn



# @builderTools.addToBuild(iOrder=85, dButtons=dButtons, bDisableByDefault=True)
# def createSpeechParentCtrls():
#     sliderctrls5.addParentCtrl('lipsCornerLFT_ctrl')
#     sliderctrls5.addParentCtrl('lipsBotLFT_ctrl', bTurnOffParentAttr=True)
#     sliderctrls5.addParentCtrl('lipsTopLFT_ctrl', bTurnOffParentAttr=True)
#



def proceduralBind_mouthSplineJoints(iFullWeightLoops, iFadeOutLoops, fBotMultipl, fCornerMultipl, fTopMultipl, fBlend=1.0, sSuffix='MouthSpline'):


    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        sSkinCluster = 'skinCluster__%s' % (sMesh)

        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()


        report.report.addLogText('\nskinning lips..', bRefresh=True)
        fTimeBefore = time.time()


        sAllJoints = []
        fAllValues = []


        bIgnoreMostOut = False # probably useless...
        if bIgnoreMostOut:
            iStart = 1
            iEnd = -1
        else:
            iStart = 0
            iEnd = None

        # left top
        sJoints = ['jnt_m_top%s_000' % sSuffix] + sorted(cmds.ls('jnt_l_top%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fTopMultipl, fTopMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # left bot
        sJoints = sorted(cmds.ls('jnt_l_bot%s_???' % sSuffix, et='joint'), reverse=True) + ['jnt_m_bot%s_000' % sSuffix]
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fBotMultipl, fBotMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        # right bot
        sJoints = sorted(cmds.ls('jnt_r_bot%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fBotMultipl, fBotMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # right top
        sJoints = sorted(cmds.ls('jnt_r_top%s_???' % sSuffix, et='joint'), reverse=True)
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fTopMultipl, fTopMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        print('sAlLJoins: ', sAllJoints)
        print('fAllValues: ', fAllValues)

        fJointWeightings = np.array(fAllValues, dtype='float64')

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()


        _, sOldInfluences = pMesh.getSkinCluster(sChooseSkinCluster=sSkinCluster, bSkipWeights=True)
        # sMaskJoints = ['jnt_m_headMain', 'jnt_m_jawMain']
        # bMasked = False
        # for sJ in sMaskJoints:
        #     if sJ in sOldInfluences:
        #         bMasked = True
        # if bMasked:
        #     for sJ in sOldInfluences:
        #         if sJ not in sMaskJoints+sAllJoints:
        #             cmds.setAttr('%s.liw' % sJ, True)
        #         else:
        #             cmds.setAttr('%s.liw' % sJ, False)

        weights.bindToClosestVertexAndExpand(None, sJoints=sAllJoints, _fJointWeightings=fJointWeightings, fBlend=fBlend,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iFullWeightLoops, iExpandedFadeOutLoops=iFadeOutLoops,
                                             sChooseSkinCluster=sSkinCluster)#, iJointLocks=patch.JointLocks.dontChangeLockedJoints)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)

        deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)




def _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='LipsDetail', sSkinClusterSuffix='DETAIL'):

    iBindLipRows = iBindLipRows
    fBotMultipl, fCornerMultipl, fTopMultipl = fBindMultipls



    sMesh = cmds.ls(sl=True)[0].split('.')[0]

    sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
    [cmds.setAttr('%s.envelope' % sB, 0.0) for sB in sBlendShapes]

    try:
        report.report.resetProgress(6)

        report.report.addLogText('\nskinning bind lipJoints..', bRefresh=True)

        sSkinCluster = 'skinCluster__%s__%s' % (sMesh, sSkinClusterSuffix)
        sSkinClusterTemp = 'TEMP__skinCluster__%s__%s' % (sMesh, sSkinClusterSuffix)


        if cmds.objExists(sSkinClusterTemp):
            cmds.delete(sSkinClusterTemp)
        pSelection = patch.getSelectedPatches()
        pMesh = patch.patchFromName(sMesh)
        sSelBefore = cmds.ls(sl=True)
        fTimeBefore = time.time()


        deformers.skinMesh(sMesh, ['jnt_m_faceZero'], sName=sSkinClusterTemp, bAlwaysAddDefaultWeights=True)

        weights.smoothSkinWeights([pMesh], iIterations=2, sChooseSkinCluster=sSkinClusterTemp)
        report.report.incrementProgress(bRefresh=True)
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)


        report.report.addLogText('\nskinning lips..', bRefresh=True)
        fTimeBefore = time.time()


        sAllJoints = []
        fAllValues = []


        bIgnoreMostOut = False # probably useless...
        if bIgnoreMostOut:
            iStart = 1
            iEnd = -1
        else:
            iStart = 0
            iEnd = None

        # left top
        sJoints = ['jnt_m_top%s_000' % sSuffix] + sorted(cmds.ls('jnt_l_top%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fTopMultipl, fTopMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # left bot
        sJoints = sorted(cmds.ls('jnt_l_bot%s_???' % sSuffix, et='joint'), reverse=True) + ['jnt_m_bot%s_000' % sSuffix]
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fBotMultipl, fBotMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        # right bot
        sJoints = sorted(cmds.ls('jnt_r_bot%s_???' % sSuffix, et='joint'))
        fValues = utils.bSpline4([fBotMultipl, fBotMultipl, fCornerMultipl, fCornerMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[:iEnd]
        fAllValues += list(fValues[:iEnd])

        # right top
        sJoints = sorted(cmds.ls('jnt_r_top%s_???' % sSuffix, et='joint'), reverse=True)
        fValues = utils.bSpline4([fCornerMultipl, fCornerMultipl, fTopMultipl, fTopMultipl], iCount=len(sJoints))
        sAllJoints += sJoints[iStart:]
        fAllValues += list(fValues[iStart:])

        print('sAlLJoins: ', sAllJoints)
        print('fAllValues: ', fAllValues)

        fJointWeightings = np.array(fAllValues, dtype='float64')
        print('fJointWeightings: ', fJointWeightings)


        # fJointWeightings = np.interp(np.arange(sJoints), iIndices, [1, 0.5, ]
        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore), bRefresh=True)

        report.report.addLogText('\nfirst bindToClosestVertexAndExpand()..', bRefresh=True)
        fTimeBefore = time.time()
        weights.bindToClosestVertexAndExpand([pMesh], sJoints=sAllJoints, fJointWeightings=fJointWeightings,
                                             iCheckMissingInfluences=patch.MissingInfluencesOptions.onlyAddMissingInfluencesInSkinCluster,
                                             iExpandedFullWeightLoops=iBindLipRows[0], iExpandedFadeOutLoops=iBindLipRows[1],
                                             sChooseSkinCluster=sSkinClusterTemp)

        report.report.addLogText('%f seconds' % (time.time() - fTimeBefore))
        report.report.incrementProgress(bRefresh=True)


        if cmds.objExists(sSkinCluster):
            pTransferTo = pMesh
            for pSel in pSelection:
                if pSel.getName() == pMesh.getName():
                    pTransferTo = pSel
                    break

            weights.transferSkinCluster([pTransferTo], sFrom=sSkinClusterTemp, sChooseSkinCluster=sSkinCluster, iMode=weights.TransferMode.vertexIndex)
            cmds.delete(sSkinClusterTemp)
        else:
            cmds.rename(sSkinClusterTemp, sSkinCluster)

        deformers.connectRefsOnCurrentSkinClusters(sAllJoints)
    except:
        raise
    finally:
        if sBlendShapes:
            [cmds.setAttr('%s.envelope' % sB, 1) for sB in sBlendShapes]

    cmds.select(sSelBefore)



def proceduralBind_details(iBindLipRows, fBindMultipls):
    _proceduralBind_lipJoints(iBindLipRows, fBindMultipls, sSuffix='LipsDetail', sSkinClusterSuffix='DETAIL')


dButtons = {}
dButtons['bind selected'] = proceduralBind_details


@builderTools.addToBuild(iOrder=95, dButtons=dButtons, bDisableByDefault=True)
def DETAILS_mouth(sAttachMesh=[], iBindLipRows=[3,3], fBindMultipls=[1.0,1.0,1.0]):
    if sAttachMesh:
        sAttachMesh = utils.toList(sAttachMesh)[0]
    else:
        raise Exception('no attachmesh given')
    pMesh = patch.patchFromName(sAttachMesh)
    sBpCurves = ['bpCurve_m_%sLipInner' % sPart for sPart in ['bot', 'top']]
    iiVerts = [topology.getIdsAlongCurve(pMesh, sBpCurves[0])[0],
               topology.getIdsAlongCurve(pMesh, sBpCurves[1])[0]]
    iiVerts[1] = iiVerts[1][1:-1]
    fSliderScale = utils.data.get('mouthSliderScale', sNode=utils.kFaceDataNode) or cmds.getAttr('jnt_m_jawEnd.tx') * 0.2

    sGroup = cmds.createNode('transform', n='grp_details', p='modules')
    ssJoints = [[], []]
    ssRefJoints = [[], []]
    for p,sPart in enumerate(['bot','top']):
        sSides, iInds = utils.convertMiddleSequenceToSides(len(iiVerts[p]))
        for i, iVert in enumerate(iiVerts[p]):
            sJ = 'jnt_%s_%sLipsDetail_%03d' % (sSides[i], sPart, iInds[i])
            if not cmds.objExists(sJ):
                xforms.createJoint(sJ, fSize=fSliderScale*0.1)
            sRefJ = xforms.createJoint('jnt_%s_%sLipsDetail_%03d_ref' % (sSides[i], sPart, iInds[i]), fSize=fSliderScale*0.1)
            utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sRefJ)
            ssJoints[p].append(sJ)
            ssRefJoints[p].append(sRefJ)

            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sJ)
            cmds.connectAttr('%s.rigVis' % utils.getMasterName(), '%s.v' % sRefJ)


    sSkinClusters = [sS for sS in deformers.listAllDeformers(sAttachMesh, sFilterTypes=['skinCluster']) if 'DETAIL' not in sS]
    sLocs = constraints.parallelTransformAsDeformers(sAttachMesh, iiVerts[0]+iiVerts[1], sDeformers=sSkinClusters, sParent=sGroup, fTargetMinimumDistance=0.01)
    ssLocs = [sLocs[0:len(iiVerts[0])], sLocs[len(iiVerts[0]):]]
    sCtrlsGrp = cmds.createNode('grp_detailCtrls', p='ctrls')
    sVisAttr = utils.addOffOnAttr('head_ctrl', 'lipsDetailCtrlsVis', False, sTarget='%s.v' % sCtrlsGrp)
    ccCtrls = [], []
    for p,sPart in enumerate(['bot','top']):

        sSides, iInds = utils.convertMiddleSequenceToSides(len(iiVerts[p]))
        for i, iVert in enumerate(iiVerts[p]):
            cC = ctrls5.create('%sDetail' % sPart, sSide=sSides[i], iIndex=iInds[i], sParent=sCtrlsGrp, sShape='circleZ', iColorIndex=3, fMatchPos=ssLocs[p][i],
                               fSliderScale=fSliderScale, sAttrs=['t','r','s'])
            cmds.connectAttr(sVisAttr, '%s.v' % cC.sPasser)
            aHeadMatrix = utils.getNumpyMatrixFromTransform('jnt_m_headMain')

            iUp = i-1 if sSides[i] == 'r' else i+1
            fSideMultipl = -1.0 if sSides[i] == 'r' else 1.0
            xforms.orientThreePoints(cC.sPasser, aHeadMatrix[0,0:3], ssLocs[p][iUp], fAimVector=[0,fSideMultipl,0], fUpVector=[fSideMultipl,0,0])
            cmds.parent(ssJoints[p][i], cC.sOut)
            cmds.parent(ssRefJoints[p][i], cC.sPasser)
            xforms.resetTransform(ssJoints[p][i])
            xforms.resetTransform(ssRefJoints[p][i])

            # sSlider = cC.appendOffsetGroup('slider')
            # fSideMultipl = -1.0 if sSides[i] == 'r' else 1.0
            # cmds.setAttr('%s.s' % sSlider, fSideMultipl * fSliderScale*0.2, fSliderScale*0.2, fSliderScale*0.2)
            # cmds.setAttr('%s.s' % cC.sOut, fSideMultipl * 1.0/(fSliderScale*0.2), 1/(fSliderScale*0.2), 1/(fSliderScale*0.2))

            xforms.matrixParentConstraint(ssLocs[p][i], cC.sPasser, mo=True)
            ccCtrls[p].append(cC)


    for cC in ccCtrls[0] + ccCtrls[1][::-1]:
        cmds.controller(cC.sCtrl, 'mouth_ctrl' if cmds.objExists('mouth_ctrl') else 'head_ctrl', parent=True)

    # utils.reload2(deformers)
    deformers.connectRefsOnCurrentSkinClusters(ssJoints[0]+ssJoints[1])

    cmds.select(ssJoints[0]+ssJoints[1])




# ***************************
# **** Bend Controls  *******
# ***************************

kBendBpGroupName = '_grp_m_faceBendBps'
kBendBpFileName = 'faceBlueprintsFaceBend.ma'


def placeBendBpCircles():
    xforms.createOrReturnTopGroup(kBendBpGroupName)
    cmds.delete(cmds.parentConstraint('jnt_m_headMain', kBendBpGroupName))
    sCircles = []
    fScale = xforms.distanceBetween('jnt_m_jawEnd', 'jnt_m_headEnd') * 0.5
    for sName, sMatch, fS in [('bp_m_bendBot', 'jnt_m_jawEnd', 0.5),
                              ('bp_m_bendMid', 'bp_l_eye_main', 1.0),
                              ('bp_m_bendTop', 'jnt_m_headEnd', 0.75)]:
        sCircle = cmds.circle(name=sName)[0]
        cmds.parent(sCircle, kBendBpGroupName)
        # cmds.setAttr('%s.rz' % sCircle, 90)
        cmds.rotate(90, 0, 0, '%s.cv[*]' % sCircle)
        cmds.setAttr('%s.s' % sCircle, fScale * fS, fScale * fS, fScale * fS)
        sCircles.append(sCircle)
        cmds.delete(cmds.pointConstraint(sMatch, sCircle))

    cmds.setAttr('%s.ty' % sCircles[1], 0)
    cmds.setAttr('%s.tz' % sCircles[1], 0)

    cmds.select(sCircles)




daBodyWeights2d = {}
daBodyInfluences = {}

def proceduralBind_bendSetup():
    sBodyMeshes = cmds.ls(sl=True)


    for sBody in sBodyMeshes:

        sBendInfluences = ['jnt_m_faceZero', 'jnt_m_faceBendMiddle'] + \
                          cmds.ls('jnt_m_botFaceBend_???', et='joint') + cmds.ls('jnt_m_topFaceBend_???', et='joint')

        sSkinCluster = 'skinCluster__%s__BEND' % sBody
        if not cmds.objExists(sSkinCluster):
            deformers.skinMesh(sBody, sBendInfluences, sName=sSkinCluster, bAlwaysAddDefaultWeights=True, bAlwaysCreateManually=True)
        else:
            deformers.addInfluences(sSkinCluster, sBendInfluences)

    cmds.select(sBodyMeshes)


def bendRomAnim():
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=1, v=1.0)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=10, v=1.25)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=20, v=0.8)
    cmds.setKeyframe('faceSquashStretch_ctrl.sy', t=30, v=1.0)

    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=30, v=0.0)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=40, v=0.25)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=50, v=-0.25)
    cmds.setKeyframe('faceSquashStretchBot_ctrl.ty', t=60, v=0.0)

    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=60, v=0.0)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=70, v=0.25)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=80, v=-0.25)
    cmds.setKeyframe('faceSquashStretchTop_ctrl.ty', t=90, v=0.0)


    cmds.playbackOptions(e=True, minTime=0, maxTime=100)

placeBendBpCircles.dSideButtons = {'?':[['No selection needed. After clicking the button, it should look like '\
                             '\nthe picture below. If it doesn\'t, check the joints "jnt_m_jawEnd", "jnt_m_headMain" and "jnt_m_headEnd"'],
                            'bendCircles.jpg']}


dButtons = OrderedDict()
dButtons['create BPs'] = placeBendBpCircles
dButtons['add influences to selected geos'] = proceduralBind_bendSetup
dButtons['SELECT'] = {'main joint':lambda:cmds.select('jnt_m_faceBendMiddle'),
                      'bottom joints':lambda:cmds.select('jnt_m_botFaceBend_???'),
                      'top joints':lambda:cmds.select('jnt_m_topFaceBend_???')}
dButtons['create rom anim'] = bendRomAnim
dButtons['- Export Bend BPs -'] = lambda: exportBps(kBendBpFileName, kBendBpGroupName)


@builderTools.addToBuild(iOrder=62.5, dButtons=dButtons, bDisableByDefault=True)
def createBendSetup(sParentJoint='jnt_m_headMain', bBotTopChains=True, iBotTopJointCounts=[6, 6], fDefaultPivot=[0,0,0], fPivotDefaultTranslation=[0,0,0]): # bLegacyJointOrientIssue=False
    '''
    This creates the controls "ctrl_m_botFaceSquashStretch", "ctrl_m_midFaceSquashStretch" and "ctrl_m_topFaceSquashStretch"
    '''
    fSliderScale = cmds.getAttr('jnt_m_jawEnd.tx') * 0.5
    fJointRadius = xforms.getAverageJointRadius()
    fCtrlSize = fSliderScale * 4
    sBendGrp = cmds.createNode('transform', name='grp_m_faceBend', p=getFaceGrp())

    xforms.matrixParentConstraint(sParentJoint, sBendGrp, skipScale=[])
    sBps = ['bp_m_bend%s' % sN for sN in ['Bot', 'Mid', 'Top']]
    cCtrls = []

    cMiddleCtrl = ctrls5.create(sName='faceSquashStretch', sSide='m', sParent=_getFaceCtrlGrp(), fRotateShape=(0, 90, 0),
                      sAttrs=['t','r','s'], fSliderScale=fSliderScale,
                      sMatch=sBps[1], sShape='circleY', fSize=fCtrlSize / fSliderScale, bPivot=True)
    cmds.controller(cMiddleCtrl.sCtrl, headCtrl(), parent=True)

    xforms.matrixParentConstraint(sParentJoint, cMiddleCtrl.sPasser, mo=True, skipScale=[])
    # sSliderOffset = cMiddleCtrl.appendOffsetGroup('slider')
    # cmds.setAttr('%s.s' % sSliderOffset, fSliderScale, fSliderScale, fSliderScale)
    # cmds.setAttr('%s.s' % cMiddleCtrl.sOut, 1.0 / fSliderScale, 1.0 / fSliderScale, 1.0 / fSliderScale)

    sMiddleJ = 'jnt_m_faceBendMiddle'
    if not cmds.objExists(sMiddleJ):
        cmds.createNode('joint', n=sMiddleJ)
    cmds.setAttr('%s.radius' % sMiddleJ, fSliderScale * 0.1)
    xforms.parentJointNoTransform(sMiddleJ, cMiddleCtrl.sOut)
    xforms.resetTransform(sMiddleJ, jo=True)# if not bLegacyJointOrientIssue else False)
    sLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sMiddleJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
    sRefMatrix = nodes.createMultMatrixNode([sLocalMatrix, '%s.worldMatrix' % sParentJoint])
    sInvRefMatrix = nodes.createInverseMatrix(sRefMatrix)
    utils.addStringAttr(sMiddleJ, deformers.kPostRefJointAttr, sInvRefMatrix)
    deformers.connectJointReferencesFromAttr(sMiddleJ)
    cmds.setAttr('%s.t' % cMiddleCtrl.sPivot, *fDefaultPivot)
    cmds.connectAttr('master.skeletonVis', '%s.v' % sMiddleJ)

    sSquashStretch = utils.addAttr(cMiddleCtrl.sCtrl, ln='squashStretch', k=True)
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sy' % cMiddleCtrl.sRevR, [0, 1, 10])
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sx' % cMiddleCtrl.sRevR, [10, 1, 0])
    nodes.setDrivenKey(sSquashStretch, [-100,0,100], '%s.sz' % cMiddleCtrl.sRevR, [10, 1, 0])

    if bBotTopChains:
        cC = ctrls5.create(sName='faceSquashStretchBot', sSide='m', sParent=_getFaceCtrlGrp(),
                          sAttrs=['ty', 'r'], fRotateShape=(90, 0, 90), fSliderScale=fSliderScale,
                          sMatch=[sBps[0], sBps[1]], sShape='circleY', fSize=fCtrlSize / fSliderScale)
        cCtrls.append(cC)
        cC = ctrls5.create(sName='faceSquashStretchTop', sSide='m', sParent=_getFaceCtrlGrp(),
                           sAttrs=['ty', 'rx', 'rz'], fRotateShape=(90, 0, 90), fSliderScale=fSliderScale,
                          sMatch=[sBps[2], sBps[1]], sShape='circleY', fSize=fCtrlSize / fSliderScale)
        cCtrls.append(cC)

        for cC in cCtrls:
            xforms.matrixParentConstraint(sMiddleJ, cC.sPasser, mo=True, skipScale=[])
            # sSliderOffset = cC.appendOffsetGroup('slider')
            # cmds.setAttr('%s.s' % sSliderOffset, fSliderScale, fSliderScale, fSliderScale)
            # cmds.setAttr('%s.s' % cC.sOut, 1.0 / fSliderScale, 1.0 / fSliderScale, 1.0 / fSliderScale)
            cmds.controller(cC.sCtrl, cMiddleCtrl.sCtrl, parent=True)

        aPoints = xforms.getPositionArray(sBps)
        sGrp = cmds.createNode('transform', n='grp_m_bendyJointsParent', p=sBendGrp)
        xforms.matrixParentConstraint(sMiddleJ, sGrp)

        aAllCurvePoints = np.array([aPoints[0],
                                    aPoints[0] * 0.33 + aPoints[1] * 0.66,
                                    aPoints[1],
                                    aPoints[1] * 0.66 + aPoints[2] * 0.33,
                                    aPoints[2]], dtype='float64')
        aTopTangent = aAllCurvePoints[3] - aAllCurvePoints[2]
        aBotTangent = aAllCurvePoints[1] - aAllCurvePoints[2]
        fTopTangentLength = np.linalg.norm(aTopTangent)
        fBotTangentLength = np.linalg.norm(aBotTangent)
        aTopTangent /= fTopTangentLength
        aBotTangent /= fBotTangentLength
        aTopSmoothed = (aTopTangent - aBotTangent) * 0.5
        aBotSmoothed = -aTopSmoothed
        aTopSmoothed *= fTopTangentLength
        aBotSmoothed *= fBotTangentLength
        aAllCurvePoints[1] = aAllCurvePoints[2] + aBotSmoothed.reshape(1, 3)
        aAllCurvePoints[3] = aAllCurvePoints[2] + aTopSmoothed.reshape(1, 3)
        cmds.curve(p=aAllCurvePoints)

        aaRanges = [np.arange(2, -1, -1), np.arange(2, 5, 1)]
        ssJoints = [], []
        ssJointParents = [], []

        for p, sPart in enumerate(['bot', 'top']):
            cCtrl = cCtrls[p]
            fPartMultipl = -1 if sPart == 'top' else 1
            sCurve = cmds.curve(n='curve_m_%sFaceBend_Temp' % sPart, p=aAllCurvePoints[aaRanges[p]], d=2)
            fEyeHeightPerc = 0.0
            curves.rebuildWithPercs(sCurve, fPercs=[0,
                                                    fEyeHeightPerc,  # *0.9,
                                                    fEyeHeightPerc + (1.0 - fEyeHeightPerc) * 0.5,
                                                    1.0])

            aPoints = curves.getPointsFromPercs(sCurve, np.linspace(0, 1, iBotTopJointCounts[p]), bReturnNumpy=True)
            sPrev = sGrp
            for j in range(iBotTopJointCounts[p]):
                sJ = 'jnt_m_%sFaceBend_%03d' % (sPart, j)
                sParentG = 'grp_m_%sFaceBendParent_%03d' % (sPart, j)
                cmds.createNode('transform', n=sParentG, p=sPrev)

                if cmds.objExists(sJ):
                    cmds.parent(sJ, sParentG)
                    xforms.resetTransform(sJ, jo=True)
                else:
                    cmds.createNode('joint', n=sJ, p=sParentG)
                cmds.setAttr('%s.segmentScaleCompensate' % sJ, False)
                cmds.setAttr('%s.radius' % sJ, fJointRadius)

                cmds.xform(sParentG, t=aPoints[j], ws=True)
                cmds.delete(cmds.orientConstraint(sParentJoint, sParentG))

                ssJoints[p].append(sJ)
                ssJointParents[p].append(sParentG)
                sPrev = sParentG

                # ref:
                fLocalMatrix = nodes.createMultMatrixNode(['%s.worldMatrix' % sJ, '%s.worldInverseMatrix' % sParentJoint], bJustValues=True)
                sRefMatrix = nodes.createMultMatrixNode([fLocalMatrix, '%s.worldMatrix' % sParentJoint], sName='%s_ref' % sJ)
                sInvRefMatrix = nodes.createInverseMatrix(sRefMatrix, sName='%s_invRef' % sJ)
                utils.addStringAttr(sJ, deformers.kPostRefJointAttr, sInvRefMatrix)

            deformers.connectJointReferencesFromAttr(ssJoints[p])

            # fOutStrength = utils.bSpline3([0,1,1], len(ssJoints[p]))
            aOutStretchStrength = np.power(np.arange(len(ssJoints[p])) / float(len(ssJoints[p])-1), 2)
            aMiddleScaleStrength = 1.0 - np.power(np.arange(len(ssJoints[p])) / float(len(ssJoints[p])-1), 1)
            sAutoSquashWideStrength = utils.addAttr(cCtrl.sCtrl, ln='autoSquashWide', at='double',
                                                    defaultValue=0.5, minValue=0.0, k=True)
            sAutoSquashDepthStrength = utils.addAttr(cCtrl.sCtrl, ln='autoSquashDepth', at='double',
                                                     defaultValue=0.5, minValue=0.0, k=True)
            sAutoSquashWideStrengthNeg = utils.addAttr(cCtrl.sCtrl, ln='autoSquashWideNeg', at='double',
                                                    defaultValue=0.2, minValue=0.0, k=True)
            sAutoSquashDepthStrengthNeg = utils.addAttr(cCtrl.sCtrl, ln='autoSquashDepthNeg', at='double',
                                                     defaultValue=0.2, minValue=0.0, k=True)

            sUpDownByStrengthWide = nodes.createMultiplyNode(sAutoSquashWideStrength, '%s.ty' % cCtrl.sCtrl)
            sUpDownByStrengthDepth = nodes.createMultiplyNode(sAutoSquashDepthStrength, '%s.ty' % cCtrl.sCtrl)
            sUpDownByStrengthWideNeg = nodes.createMultiplyNode(sAutoSquashWideStrengthNeg, '%s.ty' % cCtrl.sCtrl)
            sUpDownByStrengthDepthNeg = nodes.createMultiplyNode(sAutoSquashDepthStrengthNeg, '%s.ty' % cCtrl.sCtrl)
            dScaleAdditionSums = defaultdict(list)
            dTranslationSums = defaultdict(list)

            aRotateStrengthes = np.power(np.arange(len(ssJoints[p])) / float(len(ssJoints[p])-1), 2)
            for j, sJ in enumerate(ssJoints[p]):
                xforms.constraintBlend(ssJointParents[p][j], cMiddleCtrl.sOut, cCtrl.sOut, ssJointParents[p][j], 'orientBlend', bMaintainOffset=True,
                                       func=cmds.orientConstraint, fDefault= utils.projectToRange(aRotateStrengthes[j], 0, 1, 0, 1.0))

                # dScaleAdditionSums['%s.sy' % ssJoints[p][j]].append(nodes.createRangeNode('%s.sz' % cCtrls[2].sCtrl, 0.5, 1.5, -aMiddleScaleStrength[j], aMiddleScaleStrength[j], sName='scaleZ_%03d' % j))
                # dScaleAdditionSums['%s.sz' % ssJoints[p][j]].append(nodes.createRangeNode('%s.sy' % cMiddleCtrl.sCtrl, 0.5, 1.5, -aMiddleScaleStrength[j], aMiddleScaleStrength[j], sName='scaleY_%03d' % j))

                dTranslationSums['%s.tx' % ssJoints[p][j]].append(nodes.setDrivenKey('%s.ty' % cCtrl.sCtrl,
                                                                    [-0.5 * fPartMultipl, 0, 0.5 * fPartMultipl],
                                                                    None,
                                                                    [utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, -fSliderScale * fPartMultipl), 0,
                                                                    utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, fSliderScale * fPartMultipl)]))

                dScaleAdditionSums['%s.sx' % ssJoints[p][j]].append(nodes.setDrivenKey('%s.ty' % cCtrl.sCtrl,
                                                                    [-0.5 * fPartMultipl, 0, 0.5 * fPartMultipl],
                                                                    None,
                                                                    [utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, 1.5), 0,
                                                                    utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, -1.5)]))

                dScaleAdditionSums['%s.sz' % ssJoints[p][j]].append(nodes.createRangeNode(sUpDownByStrengthWide,
                                                                    0, 0.5 * fPartMultipl,
                                                                    0, utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, 1)))
                dScaleAdditionSums['%s.sz' % ssJoints[p][j]].append(nodes.createRangeNode(sUpDownByStrengthWideNeg,
                                                                    0, -0.5 * fPartMultipl,
                                                                    0, utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, -1)))

                dScaleAdditionSums['%s.sz' % ssJoints[p][j]].append(nodes.createRangeNode(sUpDownByStrengthDepth,
                                                                    0, 0.5 * fPartMultipl,
                                                                    0, utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, 1)))
                dScaleAdditionSums['%s.sz' % ssJoints[p][j]].append(nodes.createRangeNode(sUpDownByStrengthDepthNeg,
                                                                    0, -0.5 * fPartMultipl,
                                                                    0, utils.projectToRange(aOutStretchStrength[j], 0, 1, 0, -1)))


            for sAttr, sAdditions in list(dScaleAdditionSums.items()):
                nodes.createAdditionNode([1.0] + sAdditions, sTarget=sAttr)

            for sAttr, sAdditions in list(dTranslationSums.items()):
                nodes.createAdditionNode(sAdditions, sTarget=sAttr)
    
    cmds.setAttr('faceSquashStretchPivot_ctrl.t', *fPivotDefaultTranslation)
    createOrFixFaceZero()
    cmds.setAttr('_grp_m_faceBendBps.v', False)

#grp_l_lipsTop0OutSlidingCopy_000
#
# cmds.setAttr("grp_l_lipsTop0Passer.followCornerPath", 0);
#
#
# cmds.setAttr("grp_l_lipsTop0Passer.followCornerPath", 1);
#
#
# cmds.getAttr('decomposeMatrix_noname90.outputTranslate')



@builderTools.addToBuild(iOrder=131, dButtons={}, bDisableByDefault=True)
def unrealSliderCtrls(sSkipCtrls=[]):
    dExtraCtrlReplacements = utilsUnreal.generateSliderCtrlsCode(sSkipCtrls=sSkipCtrls)
    utils.data.store('dExtraCtrlReplacements', dExtraCtrlReplacements)


@builderTools.addToBuild(iOrder=131.05, dButtons={}, bDisableByDefault=True)
def unrealPostCtrls():
    sUnrealCommands = ['\n\n#Creating Post Ctrls\n']

    # sCtrls = ['eyelidMidBotLFT_ctrl']
    sCtrls = utils.data.get('sAllPostCtrlsForUnreal')
    sCreatedCtrls = []
    for sCtrl in sCtrls:
        cCtrl = ctrls5.ctrlFromName(sCtrl)
        fColor = cmds.getAttr('%s.overrideColorRGB' % cCtrl.sShape)[0]
        fSliderScale = cmds.getAttr('%s.sx' % cCtrl.sSlider)
        sUnrealCommands.append(utilsUnreal.createUnrealCtrl(cCtrl, sShapeName='Box_Solid', fSize=0.018 / fSliderScale, fOverwriteColor=fColor)[1])
        sCreatedCtrls.append(sCtrl)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utils.data.addToList(utilsUnreal.kCreatedUnrealSliderCtrls, sCreatedCtrls)
    utils.data.addToList(utilsUnreal.kCreatedUnrealCtrls, sCreatedCtrls)
    utilsUnreal.dumpUnrealCodeLinesToFile()



@builderTools.addToBuild(iOrder=131.2, dButtons={}, bDisableByDefault=True)
def unrealTransformSliderCtrls(dSimpleConstraints={'jnt_m_headMain':[]}, iMaxFactors=2, bOnlySimple=True):

    sUnrealCommands = ['\n\n#Transform SliderCtrl Passers\n']
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox()")

    sAllSliderCtrls = utils.data.get(utilsUnreal.kCreatedUnrealSliderCtrls)
    sAlreadyConstrained = []
    for sJoint, sCtrls in dSimpleConstraints.items():
        sUnrealCommands.append("ePassers = nodes.createHierarchyTransformArrayNode([%s])" % ', '.join(["%s.ePasser" % sCtrl for sCtrl in sCtrls if cmds.objExists(sCtrl)]))
        sUnrealCommands.append("sForEach = nodes.createForEachExecuteNode(ePassers)")
        sUnrealCommands.append("nodes.createParentConstraintExecuteNode([hierarchy.ConstraintParent(library.getElementKey('%s', 'Bone'))], '%%s.Element' %% sForEach, bMaintainOffset=True)" % sJoint)
        sUnrealCommands.append("controllers.goToParentExecute()")
        sAlreadyConstrained.extend(sCtrls)

    if not bOnlySimple:

        ssJoints = [[] for _ in range(len(sAllSliderCtrls))]
        ffWeights = [[] for _ in range(len(sAllSliderCtrls))]

        # first gather joint attachment infos and create getTransformNodes..
        sCreatedGetTransformNodes = set()
        sCreatedUnrealNodes = utils.data.get('sCreatedUnrealNodes', xDefault=[])

        dFirstValues = {}
        ddProducts = defaultdict(list)

        for c,sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            cCtrl = ctrls5.ctrlFromName(sCtrl)
            sDecomp = cmds.listConnections('%s.t' % cCtrl.sPasser, s=True, d=False)[0]
            sMatrixMult = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]

            if cmds.objectType(sMatrixMult) == 'wtAddMatrix':
                sLoc = cmds.listConnections('%s.matrixIn[1]' % sMatrixMult, s=True, d=False)[0]
                if sLoc.startswith('loc_'):
                    sDecomp = cmds.listConnections('%s.t' % sLoc, s=True, d=False)[0]
                    sBlendEnvelope = cmds.listConnections('%s.inputMatrix' % sDecomp, s=True, d=False)[0]
                    sBlendAllInfluencesNode = cmds.listConnections('%s.wtMatrix[0].matrixIn' % sBlendEnvelope, s=True, d=False)[0]

                    for j in range(10): # per joint
                        sMatrixConns = cmds.listConnections('%s.wtMatrix[%d].matrixIn' % (sBlendAllInfluencesNode, j), s=True, d=False)
                        if j == 0:
                            sFirstMatrixConn = sMatrixConns[0]
                        if not sMatrixConns:
                            break
                        sJoint = cmds.listConnections('%s.matrixIn[2]' % sMatrixConns[0], s=True, d=False)[0]
                        fWeight = cmds.getAttr('%s.wtMatrix[%d].weightIn' % (sBlendAllInfluencesNode, j))
                        ssJoints[c].append(sJoint)
                        ffWeights[c].append(fWeight)
                    bCheckBlendShapes = True
                else:
                    ffWeights[c] = [1.0]
                    ssJoints[c] = [sLoc]
                    bCheckBlendShapes = False
            else:
                ffWeights[c] = [1.0]
                ssJoints[c] = ['jnt_m_headMain']
                bCheckBlendShapes = False

            print ('bCheckBlendShapes: ', bCheckBlendShapes)
            if bCheckBlendShapes:
                sPointToMatrix = cmds.listConnections('%s.matrixIn[0]' % sFirstMatrixConn, s=True, d=False)[0]
                sBlendBlendShape = cmds.listConnections('%s.inputTranslate' % sPointToMatrix, s=True, d=False)[0]

                sAdditionNode = cmds.listConnections('%s.color1' % sBlendBlendShape, s=True, d=False)[0]
                fFirstValue = cmds.getAttr('%s.input3D[0]' % sAdditionNode)[0]
                dFirstValues[sCtrl] = utilsUnreal.flipVectorToUnreal(fFirstValue)

                for b in range(1, 100000, 1):
                    sMults = cmds.listConnections('%s.input3D[%d]' % (sAdditionNode, b), s=True, d=False)
                    if not sMults:
                        break
                    sRangeNode = cmds.listConnections('%s.input2X' % sMults[0], s=True, d=False)[0]
                    if sRangeNode in sCreatedUnrealNodes:
                        fValues = cmds.getAttr('%s.input1' % sMults[0])[0]
                        ddProducts[sCtrl].append(('%s_output' % sRangeNode, utilsUnreal.flipVectorToUnreal(fValues)))


        # create the blendShape nodes
        for c,sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            if sCtrl in ddProducts:
                sProducts = ddProducts[sCtrl]
            else:
                continue
            print ('sCtrl: ', sCtrl)
            print ('ddProducts[sCtrl]: ', ddProducts[sCtrl])
            fFirstValue = dFirstValues[sCtrl]
            sUnrealCommands.append("# blendShape connections")
            sUnrealCommands.append("\ncontrollers.setNewColumn()")
            i = -1
            sProductVars = []
            print ('sProducts: ', sProducts)
            sProducts = sorted(sProducts, key=lambda a:np.linalg.norm(a[1]), reverse=True)

            for sOutput, fValues in sProducts[:min(iMaxFactors, len(sProducts))]:
                i += 1
                if np.linalg.norm(fValues) < 0.001:
                    break
                sProductVars.append('sProduct_%d' % i)
                sUnrealCommands.append("%s = nodes.createBasicCalculateNode([[%0.3f, %0.3f, %0.3f], [%s,%s,%s]], sOperation='Multiply', iPinType=pins.PinType.vector)" %
                                       (sProductVars[-1], fValues[0], fValues[1], fValues[2], sOutput, sOutput, sOutput))

            sUnrealCommands.append("%s_blendShapeSum = nodes.createBasicCalculateNode([[%0.3f, %0.3f, %0.3f]] + [%s], iPinType=pins.PinType.vector, sOperation='Add')" %
                                   (sCtrl, fFirstValue[0], fFirstValue[1], fFirstValue[2], ', '.join(sProductVars)))

        # create the get bone nodes
        sUnrealCommands.append("\n# create get bone nodes")
        sUnrealCommands.append("\ncontrollers.setNewColumn()")
        for c,sCtrl in enumerate(sAllSliderCtrls):
            for sJoint in ssJoints[c]:
                if '%s_initial' % sJoint not in sCreatedGetTransformNodes:
                    sUnrealCommands.append("%s_initial = nodes.getTransformNode(unreal.RigElementKey('%s', 'Bone'), bInitial=True)" % (sJoint, sJoint))
                    sUnrealCommands.append("%s_current = nodes.getTransformNode(hierarchy.Element('%s', 'Bone'))" % (sJoint, sJoint))
                    sCreatedGetTransformNodes.add('%s_initial' % sJoint)

        # now go through and connect the control passers to the previously created getTransformNodes
        sUnrealCommands.append("# connect them all to the bone nodes")
        for c, sCtrl in enumerate(sAllSliderCtrls):
            if sCtrl in sAlreadyConstrained:
                continue
            sUnrealCommands.append("\ncontrollers.setNewColumn()")
            sUnrealCommands.append("%s_initial = nodes.getTransformNode(%s.ePasser, bInitial=True)" % (sCtrl, sCtrl))
            sBlendShapedCtrl = '%s_initial' % sCtrl
            if sCtrl in ddProducts:
                sBlendShapedCtrl = "[%s_blendShapeSum, '%%s.Rotation' %% %s, '%%s.Scale3D' %% %s]"  % (sCtrl, sBlendShapedCtrl, sBlendShapedCtrl)

            for j,sJoint in enumerate(ssJoints[c]):
                sUnrealCommands.append("relativeToJoint = nodes.createMakeRelativeNode(%s, %s_initial)" % (sBlendShapedCtrl, sJoint))
                sUnrealCommands.append("%s_pointMoved = nodes.createMakeAbsoluteNode(relativeToJoint, %s_current)" % (sJoint, sJoint))

            sOutTransform = '%s_pointMoved' % ssJoints[c][0]
            if len(ssJoints[c]) > 1:
                fPrevWeightSum = ffWeights[c][0]
                for jj in range(1, len(ssJoints[c]), 1):
                    fWeight = ffWeights[c][jj] / (ffWeights[c][jj] + fPrevWeightSum)
                    fPrevWeightSum += ffWeights[c][jj]
                    sInterpName = '%s_interp_%d' % (sCtrl, jj)
                    sUnrealCommands.append("%s = nodes.createTransformInterpolateNode(%0.3f, %s, %s_pointMoved)" % (sInterpName, fWeight, sOutTransform, ssJoints[c][jj]))
                    sOutTransform = sInterpName

        sUnrealCommands.append("nodes.createSetTransformExecuteNode(%s.ePasser, %s)" % (sCtrl, sOutTransform))

    sUnrealCommands.append("controllers.closeCommentBox('Transform SliderCtrl Passers')")


    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()


def _replaceTargetsWithOthers(sTargetAttrs, sOtherGrp):
    sTargetShortAttrs = [sAttr.split('.')[-1] for sAttr in sTargetAttrs]

    sFoundTargets = []
    sSearchMeshes = utils.listMeshes(sOtherGrp)
    for sMesh in sSearchMeshes:
        sBlendShapes = deformers.listAllDeformers(sMesh, sFilterTypes=['blendShape'])
        if sBlendShapes:
            sBlendShape = sBlendShapes[0]
            for sTarget in deformers.getBlendShapeTargets(sBlendShape):
                if sTarget in sTargetShortAttrs:
                    sFoundTargets.append('%s.%s' % (sBlendShape, sTarget))

    sTargetAttrs = sorted(sFoundTargets, key=lambda a: a.split('.')[-1].count('_'))
    return sTargetAttrs



# depricated
# @builderTools.addToBuild(iOrder=131.12, dButtons={}, bDisableByDefault=True)
def unrealConnectBlendShapesBackwardsOld(sLookForTargetsUnder=None):
    ''' not fully working. Shuldn't really be used'''

    dDriverReplacements = {'grp_l_eyesLookAtPasser.lookVert':('eyesLookAtLFT_ctrl.translateZ', 2),
                           'grp_r_eyesLookAtPasser.lookVert':('eyesLookAtRGT_ctrl.translateZ', 2),
                           'grp_l_eyesLookAtPasser.lookHoriz':('eyesLookAtLFT_ctrl.translateZ', 2),
                           'grp_r_eyesLookAtPasser.lookHoriz':('eyesLookAtRGT_ctrl.translateZ', 2)}


    sTargetAttrs = utils.data.get(utilsUnreal.kBlendShapeTargetList)


    if sLookForTargetsUnder:
        sTargetAttrs = _replaceTargetsWithOthers(sTargetAttrs, sLookForTargetsUnder)

    sUnrealBackwardsCommands = []
    sUnrealBackwardsCommands.append('\n\n# BlendShape Target Weights (Curve) BACKWARDS Connections\n\n')

    sUnrealBackwardsCommands.append("nodes.newSequencerPlug()")
    sUnrealBackwardsCommands.append("controllers.openCommentBox()")
    sCompletedCurves = set()
    for sAttribute in sTargetAttrs:
        if sAttribute == None:
            continue
        sCurveAttr = sAttribute.split('.')[-1]

        if sCurveAttr in sCompletedCurves:
            continue
        else:
            sCompletedCurves.add(sCurveAttr)

        sConns = cmds.listConnections(sAttribute, s=True, d=False, p=True, skipConversionNodes=True) or []

        if not sConns:
            continue

        sCollectionNode = sConns[0].split('.')[0]
        if cmds.objectType(sCollectionNode) == 'condition':
            sRangeOutputs = eval(cmds.getAttr('%s.sFactors' % sCollectionNode))
        else:
            sRangeOutputs = [sConns[0]]

        sUnrealBackwardsCommands.append('\n\n# BlendShape Weight sAttribute (backwards): %s' % sAttribute)

        xDrivenCtrls = []
        for sRangeOutput in sRangeOutputs:
            sRangeNode, sAttr = sRangeOutput.split('.')
            sDriver = cmds.listConnections('%s.valueX' % sRangeNode, s=True, d=False, p=True, skipConversionNodes=True)[0]
            sDriverNode, sDriverAttr = sDriver.split('.')

            if sDriver in dDriverReplacements:
                xDrivenCtrls.append(dDriverReplacements[sDriver])

            elif sDriverNode.endswith('_ctrl'):
                fValue = getPoseFromRangeNode(sRangeNode)
                if sDriverAttr == 'upCurveBlink':
                    if fValue == 1.0:
                        xDrivenCtrls = []
                        break
                    elif fValue == 0.0:
                        continue
                    else:
                        raise Exception('Not sure what to do when upCurveBlink is %0.3f' % (fValue))
                xDrivenCtrls.append((sDriver, fValue))


        if len(xDrivenCtrls) == 1:
            sUnrealBackwardsCommands.append("%s = nodes.createGetCurveValue('%s')" % (sCurveAttr, sCurveAttr))
            sUnrealBackwardsCommands.append("%s_range = nodes.createRemapNode(%s, 0,1,0,%0.3f)" % (sCurveAttr, sCurveAttr, xDrivenCtrls[0][1]))
            sCtrl, sAttr = xDrivenCtrls[0][0].split('.')
            sUnrealBackwardsCommands.append("nodes.createSetChannelNode(hierarchy.Element('%s', 'Control'), '%s', %s_range)" % (sCtrl, sAttr, sCurveAttr))


    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealBackwardsCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)



def getPoseFromRangeNode(sRangeNode, bJustSign=False):
    sBeforeOverShootAttr = '%s.fBeforeOverShoot' % sRangeNode
    if cmds.objExists(sBeforeOverShootAttr):
        fBeforeOverShoot = eval(cmds.getAttr(sBeforeOverShootAttr))
        fPose = fBeforeOverShoot[1] if fBeforeOverShoot[0] == 0 else fBeforeOverShoot[0]
    else:
        fOldMinX, fOldMinMax = cmds.getAttr('%s.oldMinX' % sRangeNode), cmds.getAttr('%s.oldMaxX' % sRangeNode)
        fPose = fOldMinMax if fOldMinX == 0 else fOldMinX

    if bJustSign:
        return 1 if fPose > 0 else -1
    else:
        return fPose



@builderTools.addToBuild(iOrder=131.15, dButtons={}, bDisableByDefault=True)
def unrealConnectBlendShapes(sLookForTargetsUnder=None):

    dDriverReplacements = {'grp_l_eyesLookAtPasser.lookVert':'sLookVert_l_eye',
                           'grp_r_eyesLookAtPasser.lookVert':'sLookVert_r_eye',
                           'grp_l_eyesLookAtPasser.lookHoriz':'sLookHoriz_l_eye',
                           'grp_r_eyesLookAtPasser.lookHoriz':'sLookHoriz_r_eye'}
    dExtraCtrlReplacements = utils.data.get('dExtraCtrlReplacements', xDefault={})

    dDriverReplacements.update(dExtraCtrlReplacements)

    # for i in range(100):
    #     dDriverReplacements['zipperOut_%03d' % i] = 'sZipperResults[%d]' % i

    bZipper = False

    sCreatedUnrealCtrls = utils.data.get(utilsUnreal.kCreatedUnrealCtrls)
    sTargetAttrs = utils.data.get(utilsUnreal.kBlendShapeTargetList)


    if sLookForTargetsUnder:
        sTargetAttrs = _replaceTargetsWithOthers(sTargetAttrs, sLookForTargetsUnder)


    sUnrealCommands = []
    sUnrealCommands.append('\n\n# BlendShape Target Weights (Curve) Connections\n\n')
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("sLookVert_l_eye = nodes.createGetVariableNode(hierarchy.Variable('lookVert_l_eye'))")
    sUnrealCommands.append("sLookHoriz_l_eye = nodes.createGetVariableNode(hierarchy.Variable('lookHoriz_l_eye'))")
    sUnrealCommands.append("sLookVert_r_eye = nodes.createGetVariableNode(hierarchy.Variable('lookVert_r_eye'))")
    sUnrealCommands.append("sLookHoriz_r_eye = nodes.createGetVariableNode(hierarchy.Variable('lookHoriz_r_eye'))")
    sUnrealCommands.append("controllers.setNewColumn()")
    sUnrealCommands.append("nodes.newSequencerPlug()")
    sUnrealCommands.append("controllers.openCommentBox()")
    sCreatedUnrealNodes = set()
    sCompletedCurves = set()
    for sAttribute in sTargetAttrs:

        print ('%s...' % sAttribute)
        if sAttribute == None:
            continue
        sCurveAttr = sAttribute.split('.')[-1]

        if sCurveAttr in sCompletedCurves:
            continue
        else:
            sCompletedCurves.add(sCurveAttr)

        # sUnrealCommands.append("controllers.setNewColumn()")
        xxDrivers = []

        sConns = cmds.listConnections(sAttribute, s=True, d=False, p=True, skipConversionNodes=True) or []
        sNode = sConns[0].split('.')[0]

        if cmds.objectType(sNode) == 'condition':
            sRangeOutputs = eval(cmds.getAttr('%s.sFactors' % sNode))
        else:
            sRangeOutputs = [sConns[0]]

        bAllRangesAreThere = True
        sUnrealCommands.append('\n\n# BlendShape Weight sAttribute: %s' % sAttribute)
        for sRangeOutput in sRangeOutputs:
            sRangeNode, sAttr = sRangeOutput.split('.')
            if sRangeNode.startswith('zipperOut_'):
                sName, iNumber = utils.getNumberAtEnd(sRangeNode)
                xxDrivers.append(['sZipperResults[%d]' % iNumber, (0,1,0,1)])
                bZipper = True
            else:
                sDriver = cmds.listConnections('%s.valueX' % sRangeNode, s=True, d=False, p=True, skipConversionNodes=True)[0]
                sDriverNode, sDriverAttr = sDriver.split('.')

                # sDriverUnrealCommands = [] # stupid.. we can replace that
                if sDriver in dDriverReplacements:
                    xxDrivers.append([dDriverReplacements[sDriver], nodes.getRangeFromRangeNode(sRangeNode)])
                elif sDriverNode.endswith('_ctrl'):
                    if sDriverNode not in sCreatedUnrealCtrls:
                        continue
                    if sDriverAttr.startswith('translate'):
                        sGetNodeVariableName = '%s_getTranslation' % sDriverNode
                        if sGetNodeVariableName not in sCreatedUnrealNodes:
                            sUnrealCommands.append(
                                "%s = nodes.getTransformNode(%s.eControl, bLocal=True)" % (sGetNodeVariableName, sDriverNode))
                            sCreatedUnrealNodes.add(sGetNodeVariableName)
                        if sDriverAttr == 'translateX':
                            sAxis = 'Translation.X'
                        elif sDriverAttr == 'translateY':
                            sAxis = 'Translation.Z'
                        elif sDriverAttr == 'translateZ':
                            sAxis = 'Translation.Y'
                        else:
                            raise Exception('not sure what attr "%s" is' % sDriverAttr)
                        xxDrivers.append(["'%%s.%s' %% %s" % (sAxis, sGetNodeVariableName), nodes.getRangeFromRangeNode(sRangeNode)]) # ['%s.Translation.Z' % lipsCornerLFT_ctrl_getTranslation

                        # sUnrealDriverOutAttribute = "'%%s.Translation.%s' %% %s_getTranslation" % (sAxis, sDriverNode)
                    elif sDriverAttr.startswith('rotate'):
                        sGetNodeVariableName = '%s_getRotation' % sDriverNode
                        if sGetNodeVariableName not in sCreatedUnrealNodes:
                            sUnrealCommands.append(
                                "%s = nodes.getControlRotator(%s.eControl, bLocal=True)" % (sGetNodeVariableName, sDriverNode))
                            sCreatedUnrealNodes.add(sGetNodeVariableName)
                        if sDriverAttr == 'rotateX':
                            sAxis = 'Roll'
                        elif sDriverAttr == 'rotateY':
                            sAxis = 'Yaw'
                        elif sDriverAttr == 'rotateZ':
                            sAxis = 'Pitch'
                        else:
                            raise Exception('not sure what attr "%s" is' % sDriverAttr)
                        xxDrivers.append(["'%%s.%s' %% %s" % (sAxis, sGetNodeVariableName), nodes.getRangeFromRangeNode(sRangeNode)])

                    else:
                        report.report.addLogText('not sure what type of attribute "%s" is' % sDriverAttr)
                        bAllRangesAreThere = False
                        break

        if bAllRangesAreThere and len(xxDrivers):
            sUnrealCommands.append("controllers.setNewColumn()")
            sDriverStrings = ["[%s, %s]" % (xD[0], str(xD[1])) for xD in xxDrivers]
            sUnrealCommands.append("functions.curveDriver('%s', [%s])" % (sCurveAttr, ', '.join(sDriverStrings)))
    sUnrealCommands.append("controllers.closeCommentBox('BlendShape Connections')")

    if bZipper:
        dZipper = utils.data.get('dZipper')
        sZipperUnrealCommands = ['\n\n#Zipper\n']
        sZipperUnrealCommands.append("sZipperResults = functions.zipper(%d, [lipsCornerLFT_ctrl.eControl, lipsCornerRGT_ctrl.eControl])" % (dZipper['iSampleCount']))
        sUnrealCommands = sZipperUnrealCommands + sUnrealCommands

    report.report.addLogText('\n'.join(sUnrealCommands), bPrint=True)
    utils.data.addToList('sCreatedUnrealNodes', sCreatedUnrealNodes)

    utils.data.addToList(utilsUnreal.kUnrealCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile()
    utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealCommands)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)



@builderTools.addToBuild(iOrder=131.11, dButtons={}, bDisableByDefault=True)
def unrealConnectControlsToAppleCurves(fLookUpDownInOutTranslate=[15,-15,-15,15]):
    sUnrealMocapBackwardsCodeLines = []
    sUnrealMocapBackwardsCodeLines.append('\n\n# BlendShape Target Weights (Curve) Connections (Apple) \n\n')

    fJawOpenRotation = utils.data.get('sBakedBlendShapeJawOpenRotation')
    fJawOpenTranslation = utils.data.get('sBakedBlendShapeJawOpenTranslation')

    dDict = {}
    dDict['blink_l_ctrl.translateZ'] = [(-1,'eyeBlinkLeft'), (0.5,'eyeWideLeft')]
    dDict['blink_r_ctrl.translateZ'] = [(-1,'eyeBlinkRight'), (0.5,'eyeWideRight')]
    dDict['innerEyebrow_l_ctrl.translateZ'] = [(-1,'browDownLeft'), (1,'browInnerUp')]
    dDict['innerEyebrow_r_ctrl.translateZ'] = [(-1,'browDownRight'), (1,'browInnerUp')]
    dDict['outerEyebrow_l_ctrl.translateZ'] = [(1,'browOuterUpLeft')]
    dDict['outerEyebrow_r_ctrl.translateZ'] = [(1,'browOuterUpRight')]
    dDict['cheekRaiser_l_ctrl.translateZ'] = [(1,'cheekSquintLeft')]
    dDict['cheekRaiser_r_ctrl.translateZ'] = [(1,'cheekSquintRight')]
    dDict['puff_l_ctrl.translateZ'] = [(1,'cheekPuff')]
    dDict['puff_r_ctrl.translateZ'] = [(1,'cheekPuff')]
    dDict['jaw_ctrl.rotateY'] = [(-fJawOpenRotation[2], 'jawOpen')]
    dDict['jaw_ctrl.translateY'] = [(-3.0, 'jawLeft')]
    dDict['jaw_ctrl.translateY'] = [(3.0, 'jawRight')]
    dDict['jaw_ctrl.translateX'] = [(3.0, 'jawForward')]
    dDict['mouth_ctrl.translateY'] = [(1.0, 'mouthFunnel')]

    dDict['mouthBot_ctrl.translateY'] = [(-1.0, 'mouthRollLower'), (1.0, 'mouthShrugLower')]
    dDict['mouthTop_ctrl.translateY'] = [(-1.0, 'mouthRollUpper'), (1.0, 'mouthShrugUpper')]

    dDict['lipsBot_l_ctrl.translateZ'] = [(1.0, 'mouthLowerDownLeft')]
    dDict['lipsBot0_r_ctrl.translateZ'] = [(1.0, 'mouthLowerDownRight')]
    dDict['lipsTop_l_ctrl.translateZ'] = [(1.0, 'mouthUpperUpLeft')]
    dDict['lipsTop0_r_ctrl.translateZ'] = [(1.0, 'mouthUpperUpRight')]

    dDict['noseWrinkler_l_ctrl.translateZ'] = [(1.0, 'noseSneerLeft')]
    dDict['noseWrinkler_r_ctrl.translateZ'] = [(1.0, 'noseSneerRight')]
    dDict['lipsCorner_l_ctrl.translateX'] = [(1.0, 'mouthDimpleLeft')]
    dDict['lipsCorner_r_ctrl.translateX'] = [(1.0, 'mouthDimpleRight')]
    dDict['lipsCorner_l_ctrl.translateZ'] = [(1.0, 'mouthSmileLeft'), (-1.0, 'mouthFrownLeft')]
    dDict['lipsCorner_r_ctrl.translateZ'] = [(1.0, 'mouthSmileRight'), (-1.0, 'mouthFrownRight')]
    dDict['lipSretch_l_ctrl.translateZ'] = [(1.0, 'mouthStretchLeft')]
    dDict['lipSretch_r_ctrl.translateZ'] = [(1.0, 'mouthStretchRight')]

    fUp, fDown, fIn, fOut = fLookUpDownInOutTranslate
    dDict['eyesLookAt_l_ctrl.translateZ'] = [(fUp, 'eyeLookUpLeft'), (fDown, 'eyeLookDownLeft')]
    dDict['eyesLookAt_l_ctrl.translateX'] = [(fIn, 'eyeLookInLeft'), (fOut, 'eyeLookOutLeft')]
    dDict['eyesLookAt_r_ctrl.translateZ'] = [(fUp, 'eyeLookUpRight'), (fDown, 'eyeLookDownRight')]
    dDict['eyesLookAt_r_ctrl.translateX'] = [(fIn, 'eyeLookInRight'), (fOut, 'eyeLookOutRight')]


    dDictExisting = {sControlValue:xPoses for sControlValue,xPoses in dDict.items() if cmds.objExists(sControlValue)}
    sUnrealMocapBackwardsCodeLines.append("functions.moveCtrlsByAppleCurves(%s)" % str(dDictExisting))


    utils.data.addToList(utilsUnreal.kUnrealBackwardsCodeLines, sUnrealMocapBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealBackwardsCodeLines)

    utils.data.addToList(utilsUnreal.kUnrealMocapCodeLines, sUnrealMocapBackwardsCodeLines)
    utilsUnreal.dumpUnrealCodeLinesToFile(sKey=utilsUnreal.kUnrealMocapCodeLines)


    # drive apple curves in Maya
    sCurveNames = []
    for _, xPoses in dDictExisting.items():
        sCurveNames.extend([y for x,y in xPoses])
    sTargets = unreal.addEmptyUnrealTargets(sCurveNames)
    print ('sTargets: ', sTargets)
    dTargets = {sTarget.split('.')[-1]:sTarget for sTarget in sTargets}

    sConnected = set()
    for sUnrealCtrlAttr, xPoses in dDictExisting.items():
        if sUnrealCtrlAttr.endswith('Y'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Y', 'Z')
        elif sUnrealCtrlAttr.endswith('Z'):
            sMayaCtrlAttr = utils.replaceStringEnd(sUnrealCtrlAttr, 'Z', 'Y')
        elif sUnrealCtrlAttr.endswith('X'):
            sMayaCtrlAttr = sUnrealCtrlAttr
        else:
            raise Exception('attribute %s not supported' % sUnrealCtrlAttr)
        
        for fPose, sCurve in xPoses:
            if sCurve not in sConnected:
                nodes.createRangeNode(sMayaCtrlAttr, 0, fPose, 0, 1, sTarget=dTargets[sCurve], sName='appleCurve_%s' % sMayaCtrlAttr)
                sConnected.add(sCurve)



def createPostRefAttrFromCurrentWorld(sJoints):
    for sJoint in utils.toList(sJoints):
        utils.addStringAttr(sJoint, deformers.kPostRefJointAttr, str(utils.invertFlatMatrix(cmds.xform(sJoint, q=True, m=True, ws=True))))
