###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import library
import controllers


# eOrigin is not working as expected because the variable is already used as default attributes in functions before it's assigned. Get rid of it?!
eOrigin = None
def setOrigin(eInOrigin):
    global eOrigin
    eOrigin = eInOrigin


class Variable():
    def __init__(self, sName, sType='double', sCppType='', bLocal=False):
        self.sName = sName
        self.sType = sType
        self.sCppType = sCppType
        self.bLocal = bLocal

    def __repr__(self):
        return '<Variable: (%s, %s) >' % (self.sName,self.sType)

    def __str__(self):
        return '<Variable: (%s, %s)>' % (self.sName,self.sType)




def newVariable(sName, sType='double', bArray=False, bLocal=True):
    sCppType = library.dCppTypes.get(sType, '')

    if bLocal:
        FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]

        if sName in FD.dInputs:
            raise Exception('the variable name "%s" already exists in the inputs' % sName)

        sTypePass = f'TArray<{sType}>' if bArray else sType
        FD.vmModel.add_local_variable_from_object_path(sName, sTypePass, sCppType, '', setup_undo_redo=False)
        vVariable = Variable(sName, sTypePass, sCppType, bLocal=bLocal)
    else:
        sTypePass = sCppType if sCppType else sType
        if bArray:
            sTypePass = f'TArray<{sTypePass}>'
        controllers.blueprint.add_member_variable(sName, sTypePass, is_public=False, is_read_only=False, default_value='') # add_member_variable(name, cpp_type, is_public=False, is_read_only=False, default_value='')
        vVariable = Variable(sName, sTypePass, sCppType)

    return vVariable




dControlTypes = {}
dControlTypes['transform'] = unreal.RigControlType.EULER_TRANSFORM
dControlTypes['rotation'] = unreal.RigControlType.ROTATOR
dControlTypes['translation'] = unreal.RigControlType.POSITION
dControlTypes['scale'] = unreal.RigControlType.SCALE

dControlDefaults = {}
dControlDefaults['transform'] = unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000]))
dControlDefaults['rotation'] = unreal.RigHierarchy.make_control_value_from_rotator(unreal.Rotator(pitch=0.000000, roll=-0.000000, yaw=0.000000))
dControlDefaults['translation'] = unreal.RigHierarchy.make_control_value_from_vector(unreal.Vector(0.000000, 0.000000, 0.000000))
dControlDefaults['scale'] = unreal.RigHierarchy.make_control_value_from_vector(unreal.Vector(1.000000, 1.000000, 1.000000))




def createControl(sName, sShape='Default', eParent=eOrigin, ffShapeMatrix=None, fShapeForceRotation=None, sSide='l', bNoSelect=False, bProxy=False,
                  fOverwriteColor=None, fMinTranslation=[None,None,None], fMaxTranslation=[None,None,None], fMinRotation=[None,None,None], fMaxRotation=[None,None,None], bDrawLimits=False, eAddSpaces=[], sControlType='transform',
                  uFilteredChannels=[unreal.RigControlTransformChannel.TRANSLATION_X, unreal.RigControlTransformChannel.TRANSLATION_Y, unreal.RigControlTransformChannel.TRANSLATION_Z], eDrivenControls=[]):
    uCustomization = unreal.RigControlElementCustomization([eSpace for eSpace in eAddSpaces])

    # driven_controls is not working, but let's leave it in there for the case it might magically work in future
    uGlobalCtrlSetting = unreal.RigControlSettings(customization=uCustomization, filtered_channels=uFilteredChannels, driven_controls=eDrivenControls)

    if bNoSelect:
        uGlobalCtrlSetting.animation_type = unreal.RigControlAnimationType.VISUAL_CUE
    elif bProxy:
        uGlobalCtrlSetting.animation_type = unreal.RigControlAnimationType.PROXY_CONTROL
    else:
        uGlobalCtrlSetting.animation_type = unreal.RigControlAnimationType.ANIMATION_CONTROL
    uGlobalCtrlSetting.control_type = dControlTypes[sControlType]
    uGlobalCtrlSetting.display_name = 'None'
    uGlobalCtrlSetting.draw_limits = bDrawLimits
    fColor = library.dColors[sSide] if library.isNone(fOverwriteColor) else fOverwriteColor
    uGlobalCtrlSetting.shape_color = unreal.LinearColor(fColor[0], fColor[1], fColor[2], 1.000000)
    uGlobalCtrlSetting.shape_name = sShape
    uGlobalCtrlSetting.shape_visible = True
    uGlobalCtrlSetting.is_transient_control = False


    fMinRotation = list(fMinRotation)
    fMaxRotation = list(fMaxRotation)
    fMinTranslation = list(fMinTranslation)
    fMaxTranslation = list(fMaxTranslation)

    # if uFilteredChannels:

    bSomeRotationIsThere = False
    for i,uChannel in enumerate([unreal.RigControlTransformChannel.PITCH, unreal.RigControlTransformChannel.YAW, unreal.RigControlTransformChannel.ROLL]):
        if uChannel in uFilteredChannels:
            bSomeRotationIsThere = True
            break

    if not bSomeRotationIsThere:
        for i,uChannel in enumerate([unreal.RigControlTransformChannel.PITCH, unreal.RigControlTransformChannel.YAW, unreal.RigControlTransformChannel.ROLL]):
            fMinRotation[i] = 0.0
            fMaxRotation[i] = 0.0

    # the above should look like this, but rotation locks are too buggy in unreal
    # for i,uChannel in enumerate([unreal.RigControlTransformChannel.PITCH, unreal.RigControlTransformChannel.YAW, unreal.RigControlTransformChannel.ROLL]):
    #     if uChannel not in uFilteredChannels:
    #         fMinRotation[i] = 0.0
    #         fMaxRotation[i] = 0.0

    for i,uChannel in enumerate([unreal.RigControlTransformChannel.TRANSLATION_X, unreal.RigControlTransformChannel.TRANSLATION_Y, unreal.RigControlTransformChannel.TRANSLATION_Z]):
        if uChannel not in uFilteredChannels:
            fMinTranslation[i] = 0.0
            fMaxTranslation[i] = 0.0
    uGlobalCtrlSetting.primary_axis = unreal.RigControlAxis.X


    if sControlType == 'transform':
        uGlobalCtrlSetting.limit_enabled = [unreal.RigControlLimitEnabled(not library.isNone(fMinTranslation[0]), not library.isNone(fMaxTranslation[0])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinTranslation[1]), not library.isNone(fMaxTranslation[1])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinTranslation[2]), not library.isNone(fMaxTranslation[2])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinRotation[0]), not library.isNone(fMaxRotation[0])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinRotation[1]), not library.isNone(fMaxRotation[1])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinRotation[2]), not library.isNone(fMaxRotation[2])),
                                            unreal.RigControlLimitEnabled(False, False),
                                            unreal.RigControlLimitEnabled(False, False),
                                            unreal.RigControlLimitEnabled(False, False)]
        fMinTranslation = [0.0 if library.isNone(fV) else fV for fV in fMinTranslation]
        fMaxTranslation = [0.0 if library.isNone(fV) else fV for fV in fMaxTranslation]
        fMinRotation = [0.0 if library.isNone(fV) else fV for fV in fMinRotation]
        fMaxRotation = [0.0 if library.isNone(fV) else fV for fV in fMaxRotation]
        uGlobalCtrlSetting.minimum_value = unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=fMinTranslation,rotation=fMinRotation,scale=[1.000000,1.000000,1.000000]))
        uGlobalCtrlSetting.maximum_value = unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=fMaxTranslation,rotation=fMaxRotation,scale=[1.000000,1.000000,1.000000]))
    elif sControlType == 'rotation':
        # TODO: Rotation Limits: Unreal seems buggy, avoid it if possible. To verify, create simple controls on the origin and test their limit axis settings in the scene editor
        uGlobalCtrlSetting.limit_enabled = [unreal.RigControlLimitEnabled(not library.isNone(fMinRotation[0]), not library.isNone(fMaxRotation[0])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinRotation[1]), not library.isNone(fMaxRotation[1])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinRotation[2]), not library.isNone(fMaxRotation[2]))]
        fMinRotation = [0.0 if library.isNone(fV) else fV for fV in fMinRotation]
        fMaxRotation = [0.0 if library.isNone(fV) else fV for fV in fMaxRotation]
        uGlobalCtrlSetting.minimum_value = unreal.RigHierarchy.make_control_value_from_rotator(unreal.Rotator(pitch=fMinRotation[0], roll=fMinRotation[1], yaw=fMinRotation[2]))
        uGlobalCtrlSetting.maximum_value = unreal.RigHierarchy.make_control_value_from_rotator(unreal.Rotator(pitch=fMaxRotation[0], roll=fMaxRotation[1], yaw=fMaxRotation[2]))
    elif sControlType == 'translation':
        uGlobalCtrlSetting.limit_enabled = [unreal.RigControlLimitEnabled(not library.isNone(fMinTranslation[0]), not library.isNone(fMaxTranslation[0])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinTranslation[1]), not library.isNone(fMaxTranslation[1])),
                                            unreal.RigControlLimitEnabled(not library.isNone(fMinTranslation[2]), not library.isNone(fMaxTranslation[2]))]
        fMinTranslation = [0.0 if library.isNone(fV) else fV for fV in fMinTranslation]
        fMaxTranslation = [0.0 if library.isNone(fV) else fV for fV in fMaxTranslation]
        uGlobalCtrlSetting.minimum_value = unreal.RigHierarchy.make_control_value_from_vector(unreal.Vector(fMinTranslation[0], fMinTranslation[1], fMinTranslation[2]))
        uGlobalCtrlSetting.maximum_value = unreal.RigHierarchy.make_control_value_from_vector(unreal.Vector(fMaxTranslation[0], fMaxTranslation[1], fMaxTranslation[2]))
    elif sControlType == 'scale':
        pass
        # uGlobalCtrlSetting.limit_enabled = [unreal.RigControlLimitEnabled(False, False), unreal.RigControlLimitEnabled(False, False), unreal.RigControlLimitEnabled(False, False)]
    else:
        raise Exception('unknown control type ("%s")' % sControlType)
    # uMatchKey = eMatch if eMatch else ''

    uKey = controllers.hierarchy_controller.add_control(sName, eParent, uGlobalCtrlSetting, dControlDefaults[sControlType], setup_undo=False)
    controllers.blueprint.hierarchy.set_control_settings(uKey, uGlobalCtrlSetting, setup_undo=False)
    # settings = controllers.blueprint.hierarchy.control_settings(uKey)

    sName = str(uKey).split('"')[1]

    if library.isNone(ffShapeMatrix):
        fShapeTranslation, fShapeRotation, fShapeScale = [0,0,0], [0,0,0], [1,1,1]
    else:
        fShapeTranslation, fShapeRotation, fShapeScale = library.getTrsFromListMatrix(ffShapeMatrix)

    if not library.isNone(fShapeForceRotation):
        fShapeRotation = fShapeForceRotation

    controllers.blueprint.hierarchy.set_control_shape_transform(uKey, unreal.Transform(location=fShapeTranslation,rotation=fShapeRotation,scale=fShapeScale), True, setup_undo=False)
    uControlKey = controllers.blueprint.hierarchy.find_control(uKey)
    uGotSettings = uControlKey.settings

    controllers.hierarchy_controller.set_control_settings(uKey, uGotSettings, setup_undo=False)

    return uKey



def setControlShapeFromMatrix(sCtrl, ffMatrix):
    fTranslation, fShapeRotation, fCtrlScale = library.getTrsFromListMatrix(ffMatrix)
    uCtrlKey = library.getElementKey(sCtrl, 'Control')
    controllers.blueprint.hierarchy.set_control_shape_transform(uCtrlKey, unreal.Transform(location=fTranslation,rotation=fShapeRotation,scale=fCtrlScale), True, setup_undo=False)


def parentElements(hChild, hParent):
    controllers.hierarchy_controller.set_parent(hChild, hParent, True, setup_undo=False)


def createFloatControl(sName, eParent='', fRange=[-100,100], fDefault=0.0, bIsBool=False):
    control_settings_new_control = unreal.RigControlSettings(group_with_parent_control=True)
    control_settings_new_control.animation_type = unreal.RigControlAnimationType.ANIMATION_CHANNEL
    control_settings_new_control.control_type = unreal.RigControlType.BOOL if bIsBool else unreal.RigControlType.FLOAT
    control_settings_new_control.display_name = sName
    control_settings_new_control.draw_limits = True
    control_settings_new_control.shape_color = unreal.LinearColor(1.000000, 0.000000, 0.000000, 1.000000)
    control_settings_new_control.shape_name = 'Default'
    control_settings_new_control.shape_visible = True # False?
    control_settings_new_control.is_transient_control = False
    control_settings_new_control.limit_enabled = [unreal.RigControlLimitEnabled(True, True)]
    control_settings_new_control.minimum_value = unreal.RigHierarchy.make_control_value_from_float(fRange[0])
    control_settings_new_control.primary_axis = unreal.RigControlAxis.X
    control_settings_new_control.maximum_value = unreal.RigHierarchy.make_control_value_from_float(fRange[1])

    uParentKey = eParent if eParent else ''
    uKey = controllers.hierarchy_controller.add_control(sName, uParentKey, control_settings_new_control,
                                                        unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000])),
                                                        setup_undo=False)
    sElementName = str(uKey).split('"')[1]
    controllers.blueprint.hierarchy.set_local_transform(uKey, unreal.Transform(location=[float(fDefault),0.000000,0.000000],rotation=[0.000000,0.000000,-0.000000],scale=[1.000000,1.000000,1.000000]), True, True, setup_undo=False)
    # hierarchy.set_control_settings(unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name='NewControl'), control_settings_new_control)
    return uKey #Element(sElementName, 'Control', uKey, sDisplayName=sName)


def createBoolControl(sName, eParent='', bDefault=False):
    control_settings_new_control = unreal.RigControlSettings(group_with_parent_control=True)
    control_settings_new_control.animation_type = unreal.RigControlAnimationType.ANIMATION_CHANNEL
    control_settings_new_control.control_type = unreal.RigControlType.BOOL
    control_settings_new_control.display_name = sName
    control_settings_new_control.draw_limits = True
    control_settings_new_control.shape_color = unreal.LinearColor(1.000000, 0.000000, 0.000000, 1.000000)
    control_settings_new_control.shape_name = 'Default'
    control_settings_new_control.shape_visible = True # False?
    control_settings_new_control.is_transient_control = False
    control_settings_new_control.limit_enabled = [unreal.RigControlLimitEnabled(True, True)]
    # control_settings_new_control.minimum_value = unreal.RigHierarchy.make_control_value_from_float(fRange[0])
    control_settings_new_control.primary_axis = unreal.RigControlAxis.X
    # control_settings_new_control.maximum_value = unreal.RigHierarchy.make_control_value_from_float(fRange[1])

    uParentKey = eParent if eParent else ''
    uKey = controllers.hierarchy_controller.add_control(sName, uParentKey, control_settings_new_control,
                                                        unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000])),
                                                        setup_undo=False)
    sElementName = str(uKey).split('"')[1]

    controllers.blueprint.hierarchy.set_local_transform(uKey, unreal.Transform(location=[1.0 if bDefault else 0.0,0.000000,0.000000],rotation=[0.000000,0.000000,-0.000000],scale=[1.000000,1.000000,1.000000]), True, True, setup_undo=False)
    return uKey
    # return Element(sElementName, 'Control', uKey, sDisplayName=sName)



def createNull(sName, eMatch='', ffMatrix = library.ffUnityMatrix, fSliderScale=[1,1,1], eParent=eOrigin, bTransformInGlobal=True):

    fTranslation, fRotation, fScale = library.getTrsFromListMatrix(ffMatrix)
    fScale.x *= fSliderScale[0]
    fScale.y *= fSliderScale[1]
    fScale.z *= fSliderScale[2]
    eNewNull = controllers.hierarchy_controller.add_null(sName, eMatch if eMatch else '', unreal.Transform(location=fTranslation, rotation=fRotation, scale=fScale), transform_in_global=bTransformInGlobal, setup_undo=False)
    if eParent:
        controllers.hierarchy_controller.set_parent(eNewNull, eParent, maintain_global_transform=True, setup_undo=False)
    elif eMatch:
        controllers.hierarchy_controller.remove_all_parents(eMatch, maintain_global_transform=True, setup_undo=False)

    return eNewNull




def duplicateElement(eElement, sName=None):
    uKey = controllers.hierarchy_controller.duplicate_elements([eElement], select_new_elements=False, setup_undo=False)[0]
    if sName:
        uKey = controllers.hierarchy_controller.rename_element(uKey, sName, setup_undo=False)
    return uKey






class Ctrl(object):
    def create(self, sName='noname', sSide='m', iIndex=None,
               ffMatrix = library.ffUnityMatrix, fSliderScale=[1,1,1], bExtraSliderScale=False,
               eParent=None, ffShapeMatrix=None, bPasser=True, bProxy=False, bOut=False, sShape='cube',
               sFilteredChannels=[], bIsNoCtrl=False, fOverwriteColor=None, sControlType='transform', sOffsets=[], dOffsetMatrices={}, eDrivenControls=[]):

        self.sName = sName
        self.sSide = sSide
        self.iIndex = iIndex
        sCtrlSplits = [''] * 4
        sCtrlSplits[0] = sName
        if self.iIndex != None:
            sCtrlSplits[1] = '%03d' % self.iIndex
        if self.sSide == 'l':
            sCtrlSplits[2] = '_l'
        elif self.sSide == 'r':
            sCtrlSplits[2] = '_r'
        sCtrlSplits[3] = '__' if bIsNoCtrl else '_ctrl'
        sCtrlName = ''.join(sCtrlSplits)

        if bPasser:
            self.ePasser = createNull('%s_%sPasser' % (sSide, sName), ffMatrix=ffMatrix, eParent=eParent, fSliderScale=[1,1,1] if bExtraSliderScale else fSliderScale)


        uFilteredChannels = [library.dFilteredChannels[sChannel] for sChannel in sFilteredChannels]
        self.eControl = createControl(sCtrlName, sSide=self.sSide, sShape=sShape,
                                      eParent=self.ePasser if bPasser else eParent, ffShapeMatrix=ffShapeMatrix, fOverwriteColor=fOverwriteColor, sControlType=sControlType, uFilteredChannels=uFilteredChannels,
                                      bProxy=bProxy, eDrivenControls=eDrivenControls)

        if not bPasser:
            self.ePasser = self.eControl

        if bOut:
            self.eOut = createNull('%s_%sOut' % (sSide, sName), eParent=self.eControl, eMatch=self.eControl, bTransformInGlobal=False, fSliderScale=[1.0/fSliderScale[0], 1.0/fSliderScale[1], 1.0/fSliderScale[2]])
        else:
            self.eOut = self.eControl


        self.dOffsets = {}
        Ctrl.cAllCreatedCtrls.append(self)
        if bExtraSliderScale and 'slider' not in sOffsets:
            sOffsets.append('slider')
        self.addOffsets(sOffsets, fSliderScaleOnSlider=fSliderScale if bExtraSliderScale else [1,1,1], dOffsetMatrices=dOffsetMatrices)
        return self



    def initFromExisting(self, sCtrlName):

        self.sName = str(sCtrlName)[:-len('_ctrl')]
        if self.sName.endswith('_l'):
            self.sSide = 'l'
            self.sName = library.replaceStringEnd(self.sName, '_l','')
        elif self.sName.endswith('_r'):
            self.sSide = 'r'
            self.sName = library.replaceStringEnd(self.sName, '_r','')
        else:
            self.sSide = 'm'

        self.eControl = library.getElementKey(sCtrlName, 'Control')
        self.eOut = library.getElementKey(sCtrlName, 'Control') # ideally checks if there is an eOut group

        sPasserName = '%s_%sPasser' % (self.sSide, self.sName)
        self.ePasser = library.getElementKey(sPasserName, 'Null')
        return self


    def addOffset(self, sOffsetName):
        eOffset = createNull('grp_%s_%s_%soffset' % (self.sSide, self.sName, sOffsetName), self.eControl, eParent=self.ePasser, bTransformInGlobal=False)
        controllers.hierarchy_controller.set_parent(self.eControl, eOffset, maintain_global_transform=True, setup_undo=False)
        self.dOffsets[sOffsetName] = eOffset
        return eOffset

    def addOffsets(self, sOffsetNames, fSliderScaleOnSlider=[1,1,1], dOffsetMatrices={}):
        eOffsets = []
        eLastParent = self.ePasser
        for sOffsetName in sOffsetNames[::-1]:
            sPrefix = f'grp_{self.sSide}_{self.sName}Offset' # grp_l_lipsCornerOffsetPoses
            if sOffsetName.startswith(sPrefix):
                sOffsetKey = sOffsetName.replace(sPrefix, '').lower()
            else:
                sOffsetKey = sOffsetName
            eOffset = createNull('%s%s' % (sPrefix, sOffsetKey.title()), eMatch=self.eControl, eParent=eLastParent, bTransformInGlobal=False,
                                 fSliderScale=fSliderScaleOnSlider if sOffsetKey=='slider' else [1,1,1], ffMatrix=dOffsetMatrices.get(sOffsetKey, library.ffUnityMatrix))
            controllers.hierarchy_controller.set_parent(self.eControl, eOffset, maintain_global_transform=False, setup_undo=False)
            self.dOffsets[sOffsetKey] = eOffset
            eLastParent = eOffset
            eOffsets.append(eOffset)
        return eOffsets


    def addSpaces(self, eSpaces):
        uControlKey = controllers.blueprint.hierarchy.find_control(self.eControl)
        uCurrentSettings = uControlKey.settings
        uCustomization = unreal.RigControlElementCustomization([eSpace for eSpace in eSpaces])

        uNewSettings = unreal.RigControlSettings(animation_type=uCurrentSettings.animation_type,
                                                 control_type=uCurrentSettings.control_type,
                                                 display_name=uCurrentSettings.display_name,
                                                 draw_limits=uCurrentSettings.draw_limits,
                                                 shape_color=uCurrentSettings.shape_color,
                                                 shape_name=uCurrentSettings.shape_name,
                                                 shape_visible=uCurrentSettings.shape_visible,
                                                 is_transient_control=uCurrentSettings.is_transient_control,
                                                 limit_enabled=uCurrentSettings.limit_enabled,
                                                 primary_axis=uCurrentSettings.primary_axis,
                                                 minimum_value=uCurrentSettings.minimum_value,
                                                 maximum_value=uCurrentSettings.maximum_value,
                                                 customization=uCustomization)

        controllers.hierarchy_controller.set_control_settings(self.eControl, uNewSettings, setup_undo=False)


    cAllCreatedCtrls = []
    @staticmethod
    def resetCounter():
        Ctrl.cAllCreatedCtrls.clear()


    def changeAnimType(self, sType='VISUAL_CUE'):
        uControlKey = controllers.blueprint.hierarchy.find_control(self.eControl)
        uCurrentSettings = uControlKey.settings
        # uCustomization = unreal.RigControlElementCustomization([eSpace for eSpace in eSpaces])

        if sType == 'VISUAL_CUE':
            uType = unreal.RigControlAnimationType.VISUAL_CUE


        uNewSettings = unreal.RigControlSettings(animation_type=unreal.RigControlAnimationType.VISUAL_CUE,
                                                 control_type=uCurrentSettings.control_type,
                                                 display_name=uCurrentSettings.display_name,
                                                 draw_limits=uCurrentSettings.draw_limits,
                                                 shape_color=uCurrentSettings.shape_color,
                                                 shape_name=uCurrentSettings.shape_name,
                                                 shape_visible=uCurrentSettings.shape_visible,
                                                 is_transient_control=uCurrentSettings.is_transient_control,
                                                 limit_enabled=uCurrentSettings.limit_enabled,
                                                 primary_axis=uCurrentSettings.primary_axis,
                                                 minimum_value=uCurrentSettings.minimum_value,
                                                 maximum_value=uCurrentSettings.maximum_value)
                                                 # customization=uCurrentSettings)

        controllers.hierarchy_controller.set_control_settings(self.eControl, uNewSettings, setup_undo=False)


    cAllCreatedCtrls = []
    @staticmethod
    def resetCounter():
        Ctrl.cAllCreatedCtrls.clear()




class SliderCtrl(object):
    def create(self, sName='noname', sSide='m',
               ffMatrix = library.ffUnityMatrix, fSliderScale=[1,1,1], sShape='Default', dSliderData={}, eParent=None, fOverwriteColor=None, sFilteredChannels=[]):

        # {'bAlongX': False, 'fRangeX': [0, 0], 'fRangeY': [-1, 0.5], 'fRangeZ': [0, 0], 'bBorder': True}
        self.sSide = sSide
        self.sName = sName
        sCtrlSplits = [''] * 4
        sCtrlSplits[0] = sName
        if self.sSide == 'l':
            sCtrlSplits[2] = '_l'
        elif self.sSide == 'r':
            sCtrlSplits[2] = '_r'
        sCtrlSplits[3] = '_ctrl'
        sCtrlName = ''.join(sCtrlSplits)
        self.ePasser = createNull('%s_%sPasser' % (sSide, sName), eParent=eParent, ffMatrix=ffMatrix, fSliderScale=fSliderScale)

        fRangeX = dSliderData['fRangeX']
        fRangeY = dSliderData['fRangeY']
        fRangeZ = dSliderData['fRangeZ']

        fShapeForceRotation = None
        fCtrlSize = 0.05
        if 'ARROW' in sShape.upper():
            fShapeForceRotation = [0, 0, 90]
            fCtrlSize *= 2
        uFilteredChannels = [library.dFilteredChannels[sChannel] for sChannel in sFilteredChannels]
        self.eControl = createControl(sCtrlName, sSide=self.sSide, sShape=sShape, eParent=self.ePasser, ffShapeMatrix=library.matrixFromSize(fCtrlSize), fShapeForceRotation=fShapeForceRotation,
                                      fMinTranslation=[fRangeX[0], fRangeY[0], fRangeZ[0]], fMaxTranslation=[fRangeX[1], fRangeY[1], fRangeZ[1]],
                                      bDrawLimits=dSliderData.get('bBorder', False), fOverwriteColor=fOverwriteColor, uFilteredChannels=uFilteredChannels)# sControlType='translation')

        return self



