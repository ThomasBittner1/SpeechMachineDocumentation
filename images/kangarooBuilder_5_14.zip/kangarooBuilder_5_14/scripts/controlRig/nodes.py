###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import pins
import library
import hierarchy
import controllers


fNextColumnGapFactor = 1.0



def createSequencer():
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].sSequencer = createNodeFromPath('/Script/ControlRig.RigUnit_SequenceAggregate', iForceNodePos=[-200,0])
    addToExecute(controllers.functionStacks[controllers.__iCurrentSolver__][-1].sSequencer,  bErrorIfLastExecuteNotExists=False)
    newSequencerPlug(bForce=False)


def getNewNodePos(fNodeSize=[350,200], bExecuteNode=False):
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    if FD.bNextIsNewColumn:
        FD.iCurrentNodePos[0] += FD.fLastNodeSize[0] + FD.fGap * fNextColumnGapFactor
        FD.iCurrentNodePos[1] = FD.iTopNodePos if bExecuteNode else (FD.iTopNodePos + 100)
        FD.bNextIsNewColumn = False
    else:
        FD.iCurrentNodePos[1] += FD.fLastNodeSize[1] + FD.fGap

    FD.iMaximumHeight = max(FD.iMaximumHeight, FD.iCurrentNodePos[1] + fNodeSize[1])

    FD.fLastNodeSize = fNodeSize
    return unreal.Vector2D(FD.iCurrentNodePos[0], FD.iCurrentNodePos[1])


def createConstructionEvent():
    try:
        sNode = createNodeFromPath('/Script/ControlRig.RigUnit_PrepareForExecution')
    except:
        pass
    return sNode


def createBackwardsEvent():
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_InverseExecution')
    return sNode


def createSpawnNullExecuteNode(sName, sTransform=None, eParent=None):
    sSpawnNode = createNodeFromPath('/Script/ControlRig.RigUnit_HierarchyAddNull')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Name' % sSpawnNode, sName, False, setup_undo_redo=False)

    if not library.isNone(eParent):
        pins.connectItem(eParent, '%s.Parent' % sSpawnNode)
    if not library.isNone(sTransform):
        pins.connectToPinTransform(sTransform, '%s.Transform' % sSpawnNode)
    addToExecute(sSpawnNode)

    eNull = library.getElementKey(sName, 'Null')

    return sSpawnNode, eNull


def getNodeNameFromNode(nodeObject):
    return library.getStringInQuota(str(nodeObject))


def createNodeFromPath(sPath, iForceNodePos=None, fNodeSize=[300.0,200.0], bExecuteNode=False):
    if isinstance(iForceNodePos, type(None)):
        uNodePos = getNewNodePos(fNodeSize=fNodeSize, bExecuteNode=bExecuteNode)
    else:
        uNodePos = unreal.Vector2D(iForceNodePos[0], iForceNodePos[1])

    vmUnitNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_unit_node_from_struct_path(sPath, 'Execute', uNodePos, sPath.split('.')[-1], setup_undo_redo=False)
    controllers.recordNodeForCommentBox(vmUnitNode, fNodeSize)
    sName = getNodeNameFromNode(vmUnitNode)
    return sName



def addToExecute(sNode, sFollowingExecutePin='ExecuteContext', bErrorIfLastExecuteNotExists=True):
    sNewExecute = '%s.%s' % (sNode, sFollowingExecutePin)
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    try:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(FD.sLastExecutes[-1], sNewExecute, setup_undo_redo=False)
    except Exception as e:
        if bErrorIfLastExecuteNotExists:
            raise
        else:
            print ('skipping execute')
    FD.sLastExecutes[-1] = sNewExecute


def addToExecuteEmbedded(sNode, sParentExecutePin='Completed', sFollowingExecutePin='ExecuteContext'):
    global sLastExecute
    sNewExecute = '%s.%s' % (sNode, sFollowingExecutePin)
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(FD.sLastExecutes[-1], sNewExecute, setup_undo_redo=False)
    FD.sLastExecutes.append(sNewExecute)
    FD.sLastExecutes[-2] = '%s.%s' % (sNode, sParentExecutePin)







import string
def newSequencerPlug(iPadding=300, bForce=False):
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    if not bForce:
        if FD.uLastSequencerPlug:
            if not FD.uLastSequencerPlug.get_target_links():
                return

    sCurrentSequencer = FD.sSequencer
    if not sCurrentSequencer:
        print ('FD.functionName: ', FD.sFunctionName)
        raise Exception('In current function is no sequencer')

    if FD.iCurrentSequencerPlugCount < 2:
        sPin = '%s.%s' % (sCurrentSequencer, string.ascii_uppercase[FD.iCurrentSequencerPlugCount])
    else:
        sPin = FD.vmModel.add_aggregate_pin(sCurrentSequencer, '', '', setup_undo_redo=False)
    FD.sLastExecutes[-1] = sPin
    FD.uLastSequencerPlug = FD.vmModel.get_graph().find_pin(sPin)
    FD.iTopNodePos = FD.iMaximumHeight + iPadding
    FD.iCurrentNodePos[0] = 0
    FD.iCurrentNodePos[1] = FD.iTopNodePos
    FD.iMaximumHeight = FD.iTopNodePos
    FD.iCurrentSequencerPlugCount += 1
    FD.fLastNodeSize = (0,0)



def createDeltaNode():
    sDeltaNode = createNodeFromPath('/Script/RigVM.RigVMFunction_GetDeltaTime', fNodeSize=[300, 50])
    return '%s.Result' % sDeltaNode


# TODO: This slows down the rig in the Level. Gotta figure out why!
def createSendEventExecuteNode(eItem):
    sSendEventNode = createNodeFromPath('/Script/ControlRig.RigUnit_SendEvent', fNodeSize=[300, 300])
    pins.connectItem(eItem, '%s.Item' % sSendEventNode)
    addToExecute(sSendEventNode)
    return sSendEventNode


def createSplineFromPositionsNode(sPositions, bSpline=False, iSamplesPerSegment=16):
    sSplineNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_ControlRigSplineFromPoints', fNodeSize=[300, 300])
    pins.setVectorArray(sPositions, '%s.Points' % sSplineNode)
    pins.connectToPin1D(iSamplesPerSegment, '%s.SamplesPerSegment' % sSplineNode)
    if bSpline:
        pins.setDefaultValue( 'BSpline', '%s.SplineMode' % sSplineNode)
    return '%s.Spline' % sSplineNode



def createFitChainToSplineCurve(sSpline, eItems, bStretched=True):
    sSplineNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_FitChainToSplineCurveItemArray', fNodeSize=[300, 600])
    pins.setItemArray(eItems, '%s.Items' % sSplineNode)
    pins.connectToPin1D(sSpline, '%s.Spline' % sSplineNode)
    if bStretched:
        pins.setDefaultValue('Stretched', '%s.Alignment' % sSplineNode)
    else:
        pins.setDefaultValue('Front', '%s.Alignment' % sSplineNode)

    addToExecute(sSplineNode)
    return sSplineNode



def createDrawSplineNode(sSpline, fThickness=1.0, fDetail=16, fColor=[1.0, 0.0, 0.0]):
    sDrawNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_DrawControlRigSpline', fNodeSize=[300, 300])
    pins.connectToPin1D(sSpline, '%s.Spline' % sDrawNode)
    pins.connectToPin1D(fThickness, '%s.Thickness' % sDrawNode)
    pins.connectToPinVector(fColor, '%s.Color' % sDrawNode, sAttrs=['R','G','B'])
    pins.connectToPin1D(fDetail, '%s.Detail' % sDrawNode)
    addToExecute(sDrawNode)
    return sDrawNode


# not tested yet
def createItemExistsNode(eItem):
    sExistsNode = createNodeFromPath('/Script/ControlRig.RigUnit_ItemExists', fNodeSize=[300, 300])
    pins.connectItem(eItem, '%s.Item' % sExistsNode)
    return '%s.Exists' % sExistsNode


def createSplineFromTransformsNode(sTransforms):
    sSplineNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_ControlRigSplineFromTransforms', fNodeSize=[300, 300])
    pins.setString('Hermite', '%s.SplineMode' % sSplineNode)
    pins.connectToPin1D(16, '%s.SamplesPerSegment' % sSplineNode)
    pins.connectToPin1D(sTransforms, '%s.Transforms' % sSplineNode)
    return '%s.Spline' % sSplineNode


def createGetPositionOnSpline(sSpline, fU):
    sNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_PositionFromControlRigSpline', fNodeSize=[300, 300])
    pins.connectToPin1D(sSpline, '%s.Spline' % sNode)
    pins.connectToPin1D(fU, '%s.U' % sNode)
    return '%s.Position' % sNode


def createGetTangentOnSpline(sSpline, fU):
    sNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_TangentFromControlRigSpline', fNodeSize=[300, 300])
    pins.connectToPin1D(sSpline, '%s.Spline' % sNode)
    pins.connectToPin1D(fU, '%s.U' % sNode)
    return '%s.Tangent' % sNode


def createGetParamFromPositionOnSpline(sSpline, sPosition):
    sNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_ClosestParameterFromControlRigSpline', fNodeSize=[300, 300])
    pins.connectToPin1D(sSpline, '%s.Spline' % sNode)
    pins.connectToPin1D(sPosition, '%s.Position' % sNode)
    return '%s.U' % sNode


def createGetFloatControlNode(sCtrlName):
    sFloatNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetControlFloat', fNodeSize=[300,100])
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Control' % sFloatNode, sCtrlName, True, setup_undo_redo=False)
    return '%s.FloatValue' % sFloatNode


def createCrossProductNode(xA, xB):
    sCrossNode = createNodeFromPath('/Script/ControlRig.RigUnit_MathVectorCross', fNodeSize=[300,100])
    pins.connectToPinVector(xA, '%s.A' % sCrossNode)
    pins.connectToPinVector(xB, '%s.B' % sCrossNode)
    return '%s.Result' % sCrossNode


def createSetLengthVector(xVector, xLength=1.0):
    sSetLengthNode = createNodeFromPath('/Script/ControlRig.RigUnit_MathVectorSetLength', fNodeSize=[300,100])
    pins.connectToPinVector(xVector, '%s.Value' % sSetLengthNode)
    pins.connectToPin1D(xLength, '%s.Length' % sSetLengthNode)
    return '%s.Result' % sSetLengthNode


def createGetLengthVector(xVector, xLength=1.0):
    sSetLengthNode = createNodeFromPath('/Script/RigVM.RigVMFunction_MathVectorLength', fNodeSize=[300,100])
    pins.connectToPinVector(xVector, '%s.Value' % sSetLengthNode)
    return '%s.Result' % sSetLengthNode


def createGetChannelNodeOLD(eFloatCtrl, eParent):
    sParentName = eParent if isinstance(eParent, str) else eParent.name
    sFloatDisplayName = eFloatCtrl if isinstance(eFloatCtrl, str) else eFloatCtrl.sDisplayName

    sNode = addTemplateNode('GetAnimationChannel::Execute(out Value,in Control,in Channel,in bInitial)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Control' % sNode, sParentName, False, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Channel' % sNode, sFloatDisplayName, False, setup_undo_redo=False)

    return '%s.Value' % sNode


def createGetChannelNodeInFunction(sFloatCtrlName, sParentCtrlName, bBool=False):
    sNode = addTemplateNode('GetAnimationChannel::Execute(out Value,in Control,in Channel,in bInitial)')

    if bBool:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sNode, 'bool', 'None', setup_undo_redo=False)

    pins.connectToPin1D(sParentCtrlName,'%s.Control' % sNode)
    pins.connectToPin1D(sFloatCtrlName, '%s.Channel' % sNode)
    return '%s.Value' % sNode


def createGetChannelNode2(sParentCtrlName, sAttributeName):
    sNode = addTemplateNode('GetAnimationChannel::Execute(out Value,in Control,in Channel,in bInitial)')
    if '.' in sParentCtrlName:
        pins.connectToPin1D(sParentCtrlName, '%s.Control' % sNode)
    else:
        pins.setString(sParentCtrlName, '%s.Control' % sNode)
    if '.' in sAttributeName:
        pins.connectToPin1D(sAttributeName, '%s.Channel' % sNode)
    else:
        pins.setString(sAttributeName, '%s.Channel' % sNode)
    return '%s.Value' % sNode



def createSetChannelNode(sControl, sChannel, xValue, iPinType=pins.PinType.double):
    sNode = addTemplateNode('SetAnimationChannel::Execute(in Value,io ExecuteContext,in Control,in Channel,in bInitial)')

    pins.setString(sControl, '%s.Control' % sNode)
    pins.setString(sChannel, '%s.Channel' % sNode)
    pins.resolveWildCardPin('%s.Value' % sNode, iPinType)
    pins.connectToPin1D(xValue, '%s.Value' % sNode)
    addToExecute(sNode)
    return sNode


def createSpringNode(sTarget):
    sNode = addTemplateNode('SpringInterp::Execute(in Target,in Strength,in CriticalDamping,in Force,in bUseCurrentInput,in Current,in TargetVelocityAmount,in bInitializeFromTarget,out Result,out Velocity)')
    pins.resolveWildCardPin('%s.Target' % sNode, 'FVector')
    pins.connectToPinVector(sTarget, '%s.Target' % sNode)
    return '%s.Result' % sNode



def createVerletNode(sTarget):
    sVerletNode = createNodeFromPath('/Script/RigVM.RigVMFunction_VerletIntegrateVector', fNodeSize=[300, 300])
    pins.connectToPinVector(sTarget, '%s.Target' % sVerletNode)
    return '%s.Position' % sVerletNode



def createDotProductNode(fVectorA, fVectorB):
    sNode = addTemplateNode('Dot,|::Execute(in A,in B,out Result)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'FVector',  '/Script/CoreUObject.Vector',  setup_undo_redo=False)
    pins.connectToPinVector(fVectorA, '%s.A' % sNode)
    pins.connectToPinVector(fVectorB, '%s.B' % sNode)
    return '%s.Result' % sNode




def createInverseNode(xInput):
    sNode = addTemplateNode('Inverse::Execute(in Value,out Result)')
    pins.connectToPin1D(xInput, '%s.Value' % sNode)
    return '%s.Result' % sNode




def getTransformNode(eObject, bLocal=False, bInitial=False):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetTransform', fNodeSize=[300,200])
    pins.connectItem(eObject, '%s.Item' % sNode)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)
    pins.connectToPin1D(bInitial, '%s.bInitial' % sNode)
    return '%s.Transform' % sNode



def getControlVector(sControlName, bLocal=False):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetControlVector', fNodeSize=[300,200])

    pins.connectToPin1D(sControlName, '%s.Control' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_expansion('%s.Control' % sNode, True, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'GlobalSpace', setup_undo_redo=False)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)
    return '%s.Vector' % sNode



def getTransformArrayNode(eElements, bLocal=False, bInitial=False):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetTransformItemArray', fNodeSize=[300,200])

    pins.setItemArray(eElements, '%s.Items' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.bInitial' % sNode, 'true' if bInitial else 'false', False, setup_undo_redo=False)
    return '%s.Transforms' % sNode




def getControlRotator(eControl, bLocal=False):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetControlRotator', fNodeSize=[300,200])

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Control' % sNode, eControl.name, False, setup_undo_redo=False)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)
    return '%s.Rotator' % sNode


def createSetTransformExecuteNode(eObject, sFrom='', bPropagateToChildren=True, bLocal=False, bInitial=False, fWeight=1.0):

    sNode = addTemplateNode('Set Transform::Execute(in Item,in Space,in bInitial,in Value,in Weight,in bPropagateToChildren,io ExecuteContext)')
    pins.connectItem(eObject, '%s.Item' % sNode)

    pins.connectToPin1D(bPropagateToChildren, '%s.bPropagateToChildren' % sNode)
    pins.resolveWildCardPin('%s.Value' % sNode, 'FTransform')
    pins.connectToPinTransform(sFrom, '%s.Value' % sNode)

    pins.setDefaultValue('LocalSpace' if bLocal else 'GlobalSpace', '%s.Space' % sNode)

    if bInitial:
        pins.connectToPin1D(bInitial, '%s.bInitial' % sNode)

    pins.connectToPin1D(fWeight, '%s.Weight' % sNode)
    addToExecute(sNode)

    return sNode


def createSetScaleExecuteNode(eObject, sFrom='', bPropagateToChildren=True, bLocal=True):

    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_SetScale', iForceNodePos=None, fNodeSize=[300.0, 200.0], bExecuteNode=True)
    pins.connectItem(eObject, '%s.Item' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.bPropagateToChildren' % sNode, 'true' if bPropagateToChildren else 'false', False, setup_undo_redo=False)
    if sFrom:
        pins.connectToPinVector(sFrom, '%s.Scale' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)

    addToExecute(sNode)

    return sNode


def createSetTranslationExecuteNode(eObject, sFrom='', bPropagateToChildren=True, bLocal=False, bInitial=False):

    sNode = addTemplateNode('Set Transform::Execute(in Item,in Space,in bInitial,in Value,in Weight,in bPropagateToChildren,io ExecuteContext)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.unresolve_template_nodes(sNode, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sNode, 'FVector', '/Script/CoreUObject.Vector', setup_undo_redo=False)

    pins.connectItem(eObject, '%s.Item' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.bPropagateToChildren' % sNode, 'true' if bPropagateToChildren else 'false', False, setup_undo_redo=False)

    if sFrom:
        pins.connectToPinVector(sFrom, '%s.Value' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)

    if bInitial:
        pins.connectToPin1D(bInitial, '%s.bInitial' % sNode)

    addToExecute(sNode)

    return sNode


def createSetRotationExecuteNode(eObject, sFrom='', bPropagateToChildren=True, bLocal=False):

    sNode = addTemplateNode('Set Transform::Execute(in Item,in Space,in bInitial,in Value,in Weight,in bPropagateToChildren,io ExecuteContext)')

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.unresolve_template_nodes(sNode, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sNode, 'FQuat', '/Script/CoreUObject.Quat')

    pins.connectItem(eObject, '%s.Item' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.bPropagateToChildren' % sNode, 'true' if bPropagateToChildren else 'false', False, setup_undo_redo=False)

    if sFrom:
        pins.connectToPinVector(sFrom, '%s.Value' % sNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)

    addToExecute(sNode)

    return sNode


def createExtremeNode(xFactors, bMinimum=False):
    if bMinimum:
        sNode = addTemplateNode('Minimum::Execute(in A,in B,out Result)')
    else:
        sNode = addTemplateNode('Maximum::Execute(in A,in B,out Result)')

    for i,xF in enumerate(xFactors):
        if i >= 2:
            controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_aggregate_pin(sNode, '', '')
        sLetter = string.ascii_uppercase[i]
        pins.connectToPin1D(xF, '%s.%s' % (sNode, sLetter))

    return '%s.Result' % sNode


def createEvalInterpolatorCurveNode(xValue, iCurveType=None):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_AnimEvalRichCurve', fNodeSize=[500.0,500.0])
    pins.connectToPin1D(xValue, '%s.Value' % sNode)
    if iCurveType == 3: # easeInEaseOut
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Curve' % sNode, '(EditorCurveData=(Keys=((InterpMode=RCIM_Cubic,TangentMode=RCTM_Auto,TangentWeightMode=RCTWM_WeightedNone,Time=0.000000,Value=0.000000,ArriveTangent=0.000000,ArriveTangentWeight=0.000000,LeaveTangent=0.000000,LeaveTangentWeight=0.000000),(InterpMode=RCIM_Cubic,TangentMode=RCTM_Auto,TangentWeightMode=RCTWM_WeightedNone,Time=1.000000,Value=1.000000,ArriveTangent=0.000000,ArriveTangentWeight=0.000000,LeaveTangent=0.000000,LeaveTangentWeight=0.000000)),DefaultValue=340282346638528859811704183484516925440.000000,PreInfinityExtrap=RCCE_Constant,PostInfinityExtrap=RCCE_Constant),ExternalCurve=None)', True, setup_undo_redo=False)
    elif iCurveType == 1: # easeIn
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Curve' % sNode, '(EditorCurveData=(Keys=((InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=0.000000,Value=0.000000,ArriveTangent=-0.000337,ArriveTangentWeight=0.000000,LeaveTangent=-0.000336,LeaveTangentWeight=0.000000),(InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=1.000000,Value=1.000000,ArriveTangent=1.633306,ArriveTangentWeight=0.000000,LeaveTangent=1.633306,LeaveTangentWeight=0.000000)),DefaultValue=340282346638528859811704183484516925440.000000,PreInfinityExtrap=RCCE_Constant,PostInfinityExtrap=RCCE_Constant),ExternalCurve=None)', True, setup_undo_redo=False)
    elif iCurveType == 2: # easeOut
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Curve' % sNode, '(EditorCurveData=(Keys=((InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=0.000000,Value=0.000000,ArriveTangent=1.295691,ArriveTangentWeight=0.000000,LeaveTangent=1.295694,LeaveTangentWeight=0.000000),(InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=1.000000,Value=1.000000,ArriveTangent=0.025041,ArriveTangentWeight=0.000000,LeaveTangent=0.025042,LeaveTangentWeight=0.000000)),DefaultValue=340282346638528859811704183484516925440.000000,PreInfinityExtrap=RCCE_Constant,PostInfinityExtrap=RCCE_Constant),ExternalCurve=None)', True, setup_undo_redo=False)
    return '%s.Result' % sNode



# not tested yet!
def createEvalLinearCurveNode(xValue, fTimes, fValues):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_AnimEvalRichCurve', fNodeSize=[500.0,500.0])
    pins.connectToPin1D(xValue, '%s.Value' % sNode)
    pins.setCurveData('%s.Curve' % sNode, fTimes, fValues)
    return '%s.Result' % sNode


def createRemapNode(xValue, xMin, xMax, xOutMin, xOutMax, bClamp=True, bOutIsVector=False):
    sNode = addTemplateNode('Remap::Execute(in Value,in SourceMinimum,in SourceMaximum,in TargetMinimum,in TargetMaximum,in bClamp,out Result)')

    if bOutIsVector:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sNode, 'FVector', '/Script/CoreUObject.Vector', setup_undo_redo=False)

        pins.connectToPin1D(xValue, '%s.Value.X' % sNode)
        pins.connectToPin1D(xValue, '%s.Value.Y' % sNode)
        pins.connectToPin1D(xValue, '%s.Value.Z' % sNode)

        pins.connectToPin1D(xMin, '%s.SourceMinimum.X' % sNode)
        pins.connectToPin1D(xMin, '%s.SourceMinimum.Y' % sNode)
        pins.connectToPin1D(xMin, '%s.SourceMinimum.Z' % sNode)

        pins.connectToPin1D(xMax, '%s.SourceMaximum.X' % sNode)
        pins.connectToPin1D(xMax, '%s.SourceMaximum.Y' % sNode)
        pins.connectToPin1D(xMax, '%s.SourceMaximum.Z' % sNode)

        pins.connectToPinVector(xOutMin, '%s.TargetMinimum' % sNode)
        pins.connectToPinVector(xOutMax, '%s.TargetMaximum' % sNode)

    else:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sNode, 'double', 'None')

        pins.connectToPin1D(xValue, '%s.Value' % sNode)
        pins.connectToPin1D(xMin, '%s.SourceMinimum' % sNode)
        pins.connectToPin1D(xMax, '%s.SourceMaximum' % sNode)

        pins.connectToPin1D(xOutMin, '%s.TargetMinimum' % sNode)
        pins.connectToPin1D(xOutMax, '%s.TargetMaximum' % sNode)

    pins.connectToPin1D(bClamp, '%s.bClamp' % sNode)
    return '%s.Result' % sNode



def createBranchExecuteNode(xOffOn):

    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_branch_node(getNewNodePos(bExecuteNode=True))
    controllers.recordNodeForCommentBox(node, fEstimatedSize=[300,300])
    sNode = getNodeNameFromNode(node)

    pins.connectToPin1D(xOffOn, '%s.Condition' % sNode)

    sNewExecute = '%s.ExecuteContext' % (sNode)
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    FD.vmModel.add_link(FD.sLastExecutes[-1], sNewExecute, setup_undo_redo=False)
    FD.sLastExecutes[-1] = '%s.Completed' % sNode
    FD.sLastExecutes.append('%s.False' % sNode)
    FD.sLastExecutes.append('%s.True' % sNode)

    return sNode


def createOffsetTransformExecuteNode(eElement, sOffset=None):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_OffsetTransformForItem', bExecuteNode=True)

    if isinstance(eElement, unreal.RigElementKey):
        pins.connectItem(eElement, '%s.Item' % sNode)
    else:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(eElement, '%s.Item' % sNode, setup_undo_redo=False)

    if not library.isNone(sOffset):
        pins.connectToPinTransform(sOffset, '%s.OffsetTransform' % sNode)

    addToExecute(sNode)

    return sNode


def createGetCurveValue(sCurveName):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetCurveValue', fNodeSize=[300, 200])
    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Curve' % sNode, sCurveName, False)
    pins.setString(sCurveName, '%s.Curve' % sNode, bConnectIfPlug=True)
    return '%s.Value' % sNode


def setCurveValueExecuteNode(sCurveName, xValue=None):# , bCurveNameIsPlug=False):
    sSetCurveNode = createNodeFromPath('/Script/ControlRig.RigUnit_SetCurveValue', bExecuteNode=True)
    if '.' in sCurveName:
        pins.connectToPin1D(sCurveName, '%s.Curve' % sSetCurveNode)
    else:
        pins.setString(sCurveName, '%s.Curve' % sSetCurveNode)
        # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Curve' % sSetCurveNode, sCurveName, False)
    pins.connectToPin1D(xValue, '%s.Value' % sSetCurveNode)
    addToExecute(sSetCurveNode)
    return sSetCurveNode


def createForEachExecuteNode(sArray=None, bArrayIsStringList=False):
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_ITERATOR, 'FRigVMUnknownType', '/Script/RigVM.RigVMUnknownType', getNewNodePos(bExecuteNode=True), 'ArrayIterator')
    controllers.recordNodeForCommentBox(node, fEstimatedSize=[200,300])
    sForEachNode = getNodeNameFromNode(node)

    if not library.isNone(sArray):
        if bArrayIsStringList:
            pins.resolveWildCardPin('%s.Array' % sForEachNode, 'TArray<FName>')
            pins.setStringArray(sArray, '%s.Array' % sForEachNode)
        else:
            pins.connectToPin1D(sArray, '%s.Array' % sForEachNode)
    addToExecuteEmbedded(sForEachNode)
    return sForEachNode


def addTemplateNode(sString, fEstimatedNodeSize=[300,200]):
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_template_node(sString, getNewNodePos(fNodeSize=fEstimatedNodeSize), sString.split('::')[0], setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedNodeSize)
    sName = getNodeNameFromNode(node)
    return sName


# currently only handles xItem length to be smaller than 27. Needs to create letters higher than Z
def createBasicCalculateNode(xItems, sOperation='Multiply', iPinType=pins.PinType.double):

    if sOperation not in ['Add', 'Subtract', 'Multiply', 'Divide', 'Power']:
        raise Exception('unknown operation: "%s"' % sOperation)

    fEstimatedHeight = 50 + len(xItems) * 25
    sNode = addTemplateNode('%s::Execute(in A,in B,out Result)' % sOperation, fEstimatedNodeSize=[300,fEstimatedHeight])

    pins.resolveWildCardPin('%s.A' % sNode, iPinType)
    # if iPinType == pins.PinType.integer:
    #     controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'integer', 'None', setup_undo_redo=False)
    # elif iPinType == pins.PinType.double:
    #         controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'double', 'None', setup_undo_redo=False)
    # elif iPinType == pins.PinType.vector:
    #     controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'FVector', '/Script/CoreUObject.Vector', setup_undo_redo=False)

    if len(xItems) > 2:
        for _ in range(len(xItems)-2):
            controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_aggregate_pin(sNode, '', '', setup_undo_redo=False)
            # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_aggregate_pin('Add', 'Z_3')
    for i,xI in enumerate(xItems):
        sLetter = string.ascii_uppercase[i]
        sAttr = '%s.%s' % (sNode, sLetter)
        if iPinType == pins.PinType.vector:
            pins.connectToPinVector(xI, sAttr)
        elif iPinType == pins.PinType.transform:
            pins.connectToPinTransform(xI, sAttr)
        else:
            pins.connectToPin1D(xI, sAttr)

    return '%s.Result' % sNode


def createBasicCalculateNodeOLD(xItems, sOperation='Multiply', iPinType=pins.PinType.double):

    if sOperation not in ['Add', 'Subtract', 'Multiply', 'Divide', 'Power']:
        raise Exception('unknown operation: "%s"' % sOperation)

    xPrevNodeOut = xItems[0]
    for xI in xItems[1:]:
        sNode = addTemplateNode('%s::Execute(in A,in B,out Result)' % sOperation, fEstimatedNodeSize=[300,100])

        if iPinType == pins.PinType.integer:
            controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'integer', 'None', setup_undo_redo=False)
        elif iPinType == pins.PinType.double:
                controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'double', 'None', setup_undo_redo=False)
        elif iPinType == pins.PinType.vector:
            controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sNode, 'FVector', '/Script/CoreUObject.Vector', setup_undo_redo=False)

        if iPinType == pins.PinType.vector:
            pins.connectToPinVector(xPrevNodeOut, '%s.A' % sNode)
            pins.connectToPinVector(xI, '%s.B' % sNode)
        else:
            pins.connectToPin1D(xPrevNodeOut, '%s.A' % sNode)
            pins.connectToPin1D(xI, '%s.B' % sNode)

        xPrevNodeOut = '%s.Result' % sNode

    return xPrevNodeOut

#
# # bQuat not tested yet.
# # TO DO: create data type that can be set to float, int, bool, vector or quat
# def createSelectNode(xItems, xIndex=0, bVector=False, bQuat=False, bFloat=False):
#     if bVector:
#         uSelectNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_select_node('FVector', '/Script/CoreUObject.Vector', getNewNodePos(), 'Select', setup_undo_redo=False)
#     elif bQuat:
#         uSelectNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_select_node('FQuat', '/Script/CoreUObject.Quat', getNewNodePos(), 'Select', setup_undo_redo=False)
#         # 	blueprint.get_controller_by_name('RigVMModel').add_select_node('FQuat', '/Script/CoreUObject.Quat', unreal.Vector2D(-1552.000000, -64.000000), 'Select')
#     else:
#         if isinstance(xItems[0], int) and not bFloat:
#             uSelectNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_select_node('int32', 'None', getNewNodePos(), 'Select', setup_undo_redo=False)
#         else:
#             uSelectNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_select_node('float', 'None', getNewNodePos(), 'Select', setup_undo_redo=False)
#     sSelectNode = getNodeNameFromNode(uSelectNode)
#
#     if len(xItems) > 2:
#         for _ in range(len(xItems)-2):
#             controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.insert_array_pin('%s.Values' % sSelectNode, -1, '', setup_undo_redo=False)
#
#     pins.connectToPin1D(xIndex, '%s.Index' % sSelectNode)
#
#     for i,xI in enumerate(xItems):
#         sAttr = '%s.Values.%d' % (sSelectNode, i)
#         if bVector:
#                 pins.connectToPinVector(xI, sAttr)
#         else:
#             pins.connectToPin1D(xI, sAttr)
#
#     controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_expansion('%s.Values' % sSelectNode, False, setup_undo_redo=False)
#
#     return '%s.Result' % sSelectNode
#

# TODO: rename, remove the 2 in the end
def createSelectNode2(xItems, xIndex=0, iPinType=pins.PinType.double):
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    if iPinType == pins.PinType.vector:
        uSelectNode = FD.vmModel.add_select_node('FVector', '/Script/CoreUObject.Vector', getNewNodePos(), 'Select', setup_undo_redo=False)
        sSelectNode = getNodeNameFromNode(uSelectNode)
    elif iPinType == pins.PinType.integer:
        uSelectNode = FD.vmModel.add_select_node('int32', 'None', getNewNodePos(), 'Select', setup_undo_redo=False)
        sSelectNode = getNodeNameFromNode(uSelectNode)
    elif iPinType == pins.PinType.double:
        uSelectNode = FD.vmModel.add_select_node('float', 'None', getNewNodePos(), 'Select', setup_undo_redo=False)
        sSelectNode = getNodeNameFromNode(uSelectNode)
    elif iPinType == pins.PinType.spline:
        sSelectNode = addTemplateNode('DISPATCH_RigVMDispatch_SelectInt32(in Index,in Values,out Result)')
        pins.resolveWildCardPin('%s.Values' % sSelectNode, 'TArray<FControlRigSpline>')


    if len(xItems) > 2:
        for _ in range(len(xItems)-2):
            controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.insert_array_pin('%s.Values' % sSelectNode, -1, '', setup_undo_redo=False)


    pins.connectToPin1D(xIndex, '%s.Index' % sSelectNode)

    if isinstance(xItems, str):
        pins.connectToPin1D(xItems, '%s.Values' % sSelectNode)
    else:
        for i,xI in enumerate(xItems):
            sAttr = '%s.Values.%d' % (sSelectNode, i)
            if iPinType == pins.PinType.vector:
                    pins.connectToPinVector(xI, sAttr)
            else:
                pins.connectToPin1D(xI, sAttr)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_expansion('%s.Values' % sSelectNode, False, setup_undo_redo=False)

    return '%s.Result' % sSelectNode



def createStringSelectNode(sItems, xIndex):
    uSelectNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_select_node('int32', 'None', getNewNodePos(), 'Select',  setup_undo_redo=False)
    sSelectNode = getNodeNameFromNode(uSelectNode)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Values' % sSelectNode, 'TArray<FName>', 'None')
    pins.connectToPin1D(xIndex, '%s.Index' % sSelectNode)
    pins.setStringArray(sItems, '%s.Values' % sSelectNode)
    return '%s.Result' % sSelectNode



def createIfNode(xCond, xOutputTrue, xOutputFalse, iPinType=pins.PinType.double):
    uIfNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_if_node('FRigVMUnknownType', '/Script/RigVM.RigVMUnknownType', getNewNodePos(), 'If', setup_undo_redo=False)
    controllers.recordNodeForCommentBox(uIfNode)
    sIfNode = getNodeNameFromNode(uIfNode)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(xCond, '%s.Condition' % sIfNode, setup_undo_redo=False)

    pins.resolveWildCardPin('%s.True' % sIfNode, iPinType)
    if iPinType == pins.PinType.vector:
        pins.connectToPinVector(xOutputTrue, '%s.True' % sIfNode)
        pins.connectToPinVector(xOutputFalse, '%s.False' % sIfNode)
    else:
        pins.connectToPin1D(xOutputTrue, '%s.True' % sIfNode)
        pins.connectToPin1D(xOutputFalse, '%s.False' % sIfNode)

    return '%s.Result' % sIfNode


def createConditionNodes(xFirstTerm, sCond, xSecondTerm, xOutputTrue=True, xOutputFalse=False, iTermsPinType=pins.PinType.double, iPinType=pins.PinType.double):

    if sCond == '==':
        sOperatorNode = addTemplateNode('DISPATCH_RigDispatch_CoreEquals(in A,in B,out Result)')
    elif sCond == '!=':
        sOperatorNode = addTemplateNode('DISPATCH_RigDispatch_CoreNotEquals(in A,in B,out Result)')
    elif sCond == '>=':
        sOperatorNode = addTemplateNode('GreaterEqual::Execute(in A,in B,out Result)')
    elif sCond == '>':
        sOperatorNode = addTemplateNode('Greater::Execute(in A,in B,out Result)')
    elif sCond == '<':
        sOperatorNode = addTemplateNode('Less::Execute(in A,in B,out Result)')
    elif sCond == '<=':
        sOperatorNode = addTemplateNode('LessEqual::Execute(in A,in B,out Result)')
    elif sCond == 'stringEqual':
        sOperatorNode = addTemplateNode('DISPATCH_RigDispatch_CoreEquals(in A,in B,out Result)')
    else:
        raise Exception('Don\'t know what operator "%s" is' % sCond)

    if sCond == 'stringEqual':
        pins.resolveWildCardPin('%s.A' % sOperatorNode, 'FName')
        pins.setString(xFirstTerm, '%s.A' % sOperatorNode)
        pins.setString(xSecondTerm, '%s.B' % sOperatorNode)
    else:
        pins.resolveWildCardPin('%s.A' % sOperatorNode, iTermsPinType)
        pins.connectToPin1D(xFirstTerm, '%s.A' % sOperatorNode)
        pins.connectToPin1D(xSecondTerm, '%s.B' % sOperatorNode)

    if xOutputTrue == True and xOutputFalse == False:
        return '%s.Result' % sOperatorNode
    else:
        return createIfNode('%s.Result' % sOperatorNode, xOutputTrue, xOutputFalse, iPinType=iPinType)



def createSetControlVisibility(sControl, xOffOn, bControlIsPin=False):
    sVisNode = createNodeFromPath('/Script/ControlRig.RigUnit_SetControlVisibility', bExecuteNode=True)
    if bControlIsPin:
        pins.connectToPin1D(sControl, '%s.Item.Name' % sVisNode)
    else:
        pins.setString(sControl, '%s.Item.Name' % sVisNode)
    pins.connectToPin1D(xOffOn, '%s.bVisible' % sVisNode)
    addToExecute(sVisNode)
    return sVisNode


def createGetControlVisibility(eCtrl):
    sVisNode = createNodeFromPath('/Script/ControlRig.RigUnit_GetControlVisibility', bExecuteNode=True)
    pins.connectItem(eCtrl, '%s.Item' % sVisNode)
    return '%s.bVisible' % sVisNode


def createBoolAndNode(bA, bB):
    sBoolNode = createNodeFromPath('/Script/RigVM.RigVMFunction_MathBoolAnd', bExecuteNode=True)
    pins.connectToPin1D(bA, '%s.A' % sBoolNode)
    pins.connectToPin1D(bB, '%s.B' % sBoolNode)
    return '%s.Result' % sBoolNode


def createBoolNotNode(bValue):
    sBoolNode = createNodeFromPath('/Script/RigVM.RigVMFunction_MathBoolNot', bExecuteNode=True)
    pins.connectToPin1D(bValue, '%s.Value' % sBoolNode)
    return '%s.Result' % sBoolNode




def createToFloatNode(xFrom):
    sNode = addTemplateNode('Cast::Execute(in Value,out Result)', fEstimatedNodeSize=[80,50])
    pins.connectToPin1D(xFrom, '%s.Value' % sNode)
    return '%s.Result' % sNode


def createGetParentNode(eItem):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_HierarchyGetParent')
    pins.connectItem(eItem, '%s.Child' % sNode)
    return '%s.Parent' % sNode


# not tested:
def createGetChildrensNode(eItem):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_CollectionChildrenArray')
    pins.connectItem(eItem, '%s.Parent' % sNode)
    return '%s.Items' % sNode



def setRotationNode(eObject, sFrom='', bLocal=False):

    sNode = addTemplateNode('Set Transform::Execute(in Item,in Space,in bInitial,in Value,in Weight,in bPropagateToChildren,io ExecuteContext)')
    # sNode = getNodeNameFromNode(node)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Item' % sNode, '(Type=%s,Name="%s")' % (library.dElementTypeStrings[eObject.type], eObject.name), setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_expansion('%s.Item' % sNode, False, setup_undo_redo=False)
    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'GlobalSpace')
    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.bInitial' % sNode, 'False')
    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Weight' % sNode, '1.000000')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.bPropagateToChildren' % sNode, 'True', setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Item.Type' % sNode, library.dElementTypeStrings[eObject.type], True, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Item.Name' % sNode, eObject.name, True, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Space' % sNode, 'LocalSpace' if bLocal else 'GlobalSpace', False, setup_undo_redo=False)

    if sFrom:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(sFrom, '%s.Value' % sNode, setup_undo_redo=False)

    addToExecute(sNode)

    return sNode


def createGetDistanceNode(xA, xB):
    sDistanceNode = createNodeFromPath('/Script/ControlRig.RigUnit_MathVectorDistance')
    pins.connectToPinVector(xA, '%s.A' % sDistanceNode)
    pins.connectToPinVector(xB, '%s.B' % sDistanceNode)
    return '%s.Result' % sDistanceNode


def createNormalizeVectorNode(xVector):
    sNormalizeNode = addTemplateNode('Unit::Execute(in Value,out Result)', fEstimatedNodeSize=[100,200])
    pins.connectToPinVector(xVector, '%s.Value' % sNormalizeNode)
    return '%s.Result' % sNormalizeNode


def createGetAngleNode(xA, xB, bDegrees=False):
    sAngleNode = createNodeFromPath('/Script/ControlRig.RigUnit_MathVectorAngle')
    pins.connectToPinVector(xA, '%s.A' % sAngleNode)
    pins.connectToPinVector(xB, '%s.B' % sAngleNode)

    if not bDegrees:
        return '%s.Result' % sAngleNode
    else:
        # uDegreesNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_template_node('Degrees::Execute(in Value,out Result)', getNewNodePos(), 'Degrees')
        sDegreesNode = addTemplateNode('Degrees::Execute(in Value,out Result)', fEstimatedNodeSize=[100,200])
        pins.connectToPin1D('%s.Result' % sAngleNode, '%s.Value' % sDegreesNode)
        return '%s.Result' % sDegreesNode


def createVectorInterpolateNode(xT, xA, xB):
    sInterpolateNode = addTemplateNode('Interpolate::Execute(in A,in B,in T,out Result)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sInterpolateNode, 'FVector', '/Script/CoreUObject.Vector', setup_undo_redo=False)
    pins.connectToPin1D(xT, '%s.T' % sInterpolateNode)
    pins.connectToPinVector(xA, '%s.A' % sInterpolateNode)
    pins.connectToPinVector(xB, '%s.B' % sInterpolateNode)
    return '%s.Result' % sInterpolateNode


def createFloatInterpolateNode(xT, xA, xB):
    sInterpolateNode = addTemplateNode('Interpolate::Execute(in A,in B,in T,out Result)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sInterpolateNode, 'double', 'None', setup_undo_redo=False)
    pins.connectToPin1D(xT, '%s.T' % sInterpolateNode)
    pins.connectToPin1D(xA, '%s.A' % sInterpolateNode)
    pins.connectToPin1D(xB, '%s.B' % sInterpolateNode)
    return '%s.Result' % sInterpolateNode


def createTransformInterpolateNode(xT, xA, xB):
    sInterpolateNode = addTemplateNode('Interpolate::Execute(in A,in B,in T,out Result)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sInterpolateNode, 'FTransform', '/Script/CoreUObject.Transform', setup_undo_redo=False)
    pins.connectToPin1D(xT, '%s.T' % sInterpolateNode)
    pins.connectToPinTransform(xA, '%s.A' % sInterpolateNode)
    pins.connectToPinTransform(xB, '%s.B' % sInterpolateNode)
    return '%s.Result' % sInterpolateNode


def createRotationInterpolateNode(xT, xA, xB):
    sInterpolateNode = addTemplateNode('Interpolate::Execute(in A,in B,in T,out Result)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.A' % sInterpolateNode, 'FQuat', '/Script/CoreUObject.Quat', setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('Interpolate.T', 'float', 'None', setup_undo_redo=False)
    pins.connectToPin1D(xT, '%s.T' % sInterpolateNode)
    pins.connectToPin1D(xA, '%s.A' % sInterpolateNode)
    pins.connectToPin1D(xB, '%s.B' % sInterpolateNode)
    return '%s.Result' % sInterpolateNode


def createNegateNode(xValue):
    sNegateNode = addTemplateNode('Negate::Execute(in Value,out Result)')
    pins.connectToPin1D(xValue, '%s.Value' % sNegateNode)
    return '%s.Result' % sNegateNode


def createClampNode(xValue, xMin, xMax, bVector=False):
    sClampNode = addTemplateNode('Clamp::Execute(in Value,in Minimum,in Maximum,out Result)')
    if bVector:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sClampNode, 'FVector', '/Script/CoreUObject.Vector', setup_undo_redo=False)
        pins.connectToPinVector(xValue, '%s.Value' % sClampNode)
        pins.connectToPinVector(xMin, '%s.Minimum' % sClampNode)
        pins.connectToPinVector(xMax, '%s.Maximum' % sClampNode)
    else:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Value' % sClampNode, 'double', 'None', setup_undo_redo=False)
        pins.connectToPin1D(xValue, '%s.Value' % sClampNode)
        pins.connectToPin1D(xMin, '%s.Minimum' % sClampNode)
        pins.connectToPin1D(xMax, '%s.Maximum' % sClampNode)
    return '%s.Result' % sClampNode


def createToEulerNode(xRotation, sRotationOrder='XYZ'):
    # iRotationOrder = ['XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'].index(sRotationOrder)
    sEulerNode = createNodeFromPath('/Script/ControlRig.RigUnit_MathQuaternionToEuler')
    pins.connectToPin1D(xRotation, '%s.Value' % sEulerNode)
    pins.setString(sRotationOrder, '%s.RotationOrder' % sEulerNode)
    return '%s.Result' % sEulerNode


def createFromEulerNode(xEuler, sOrder='XYZ'):
    sEulerNode = createNodeFromPath('/Script/ControlRig.RigUnit_MathQuaternionFromEuler')
    pins.connectToPinVector(xEuler, '%s.Euler' % sEulerNode)
    pins.setDefaultValue(sOrder.upper(), '%s.RotationOrder' % sEulerNode)
    return '%s.Result' % sEulerNode



def createDrawLineNode(sA, sB, fColor=[1,0,0], fThickness=1.0, bEnabled=True):
    sNode = createNodeFromPath('/Script/RigVM.RigVMFunction_DebugLineNoSpace')

    pins.connectToPinVector(sA, '%s.A' % sNode)
    pins.connectToPinVector(sB, '%s.B' % sNode)
    pins.connectToPinColor(fColor, '%s.Color' % sNode)
    pins.connectToPin1D(fThickness, '%s.Thickness' % sNode)
    pins.connectToPin1D(bEnabled, '%s.bEnabled' % sNode)
    addToExecute(sNode)
    return sNode



def createDrawTransformNode(sTransform, fColor=[1,0,0], fThickness=1.0, bEnabled=True):
    sNode = createNodeFromPath('/Script/RigVM.RigVMFunction_DebugTransformMutableNoSpace')
    pins.connectToPinTransform(sTransform, '%s.Transform' % sNode)
    # pins.connectToPinVector(fColor, '%s.Color' % sNode)
    pins.connectToPin1D(fThickness, '%s.Thickness' % sNode)
    pins.connectToPin1D(bEnabled, '%s.bEnabled' % sNode)
    addToExecute(sNode)
    return sNode





def createDistributeRotationExecuteNode(sArray, xRotations):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_DistributeRotationForItemArray', bExecuteNode=True)
    # controllers.blueprint.get_controller_by_name('Rigcontrollers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel').set_pin_default_value('DistributeRotationForItemArray_1.Weight', '1.000000')

    pins.connectToPin1D(sArray, '%s.Items' % sNode)

    for _ in range(len(xRotations)):
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.insert_array_pin('%s.Rotations' % sNode, -1, '', setup_undo_redo=False)

    for r,xRot in enumerate(xRotations):
        pins.connectToPin1D(xRot, '%s.Rotations.%d.Rotation' % (sNode, r))

    addToExecute(sNode)

    return sNode



# #TODO: remove and replace with createMathAbs() ???
# def createFloatMakeAbsoluteNode(xValue):
#     sNegative = createBasicCalculateNode([xValue, -1], sOperation='Multiply')
#     return createConditionNodes(xValue, '>', 0.0, xValue, sNegative, iPinType=pins.PinType.double)


def createMathAbs(xValue, iPinType=pins.PinType.double):
    sAbsoluteNode = addTemplateNode('Absolute::Execute(in Value,out Result)')
    pins.resolveWildCardPin('%s.Value' % sAbsoluteNode, iPinType)
    if iPinType == pins.PinType.vector:
        pins.connectToPinVector(xValue, '%s.Value' % sAbsoluteNode)
    else:
        pins.connectToPin1D(xValue, '%s.Value' % sAbsoluteNode)
    return '%s.Result' % sAbsoluteNode


# bQuat not tested yet
def createMakeAbsoluteNode(xLocal, xParent, bQuat=False):
    sAbsoluteNode = addTemplateNode('Make Absolute::Execute(in Local,in Parent,out Global)')
    if bQuat:
        pins.resolveWildCardPin('%s.Local' % sAbsoluteNode, 'FQuat')
        pins.connectToPin1D(xLocal, '%s.Local' % sAbsoluteNode)
        pins.connectToPin1D(xParent, '%s.Parent' % sAbsoluteNode)
    else:
        pins.resolveWildCardPin('%s.Local' % sAbsoluteNode, 'FTransform')
        pins.connectToPinTransform(xLocal, '%s.Local' % sAbsoluteNode)
        pins.connectToPinTransform(xParent, '%s.Parent' % sAbsoluteNode)

    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Local' % sAbsoluteNode, 'FTransform', '/Script/CoreUObject.Transform', setup_undo_redo=False)
    # pins.connectToPinTransform(xLocal, '%s.Local' % sAbsoluteNode)
    # pins.connectToPinTransform(xParent, '%s.Parent' % sAbsoluteNode)
    return '%s.Global' % sAbsoluteNode



def createRotateVectorNode(xVector, xRotation):
    sRotateVectorNode = addTemplateNode('Rotate Vector::Execute(in Transform,in Vector,out Result)', fEstimatedNodeSize=[300,100])
    pins.connectToPin1D(xRotation, '%s.Transform' % sRotateVectorNode)
    pins.connectToPinVector(xVector, '%s.Vector' % sRotateVectorNode)
    return '%s.Result' % sRotateVectorNode


def createMakeRelativeNode(xGlobal, xParent):
    sRelativeNode = addTemplateNode('Make Relative::Execute(in Global,in Parent,out Local)')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin('%s.Global' % sRelativeNode, 'FTransform', '/Script/CoreUObject.Transform', setup_undo_redo=False)
    pins.connectToPinTransform(xGlobal, '%s.Global' % sRelativeNode)
    pins.connectToPinTransform(xParent, '%s.Parent' % sRelativeNode)
    return '%s.Local' % sRelativeNode


def createProjectTransformToNewParent(eChild, eOldParent, eNewParent=None, xChildInitial=True, xOldParentInitial=True, xNewParentInitial=False):
    sProjectNode = createNodeFromPath('/Script/ControlRig.RigUnit_ProjectTransformToNewParent', fNodeSize=[300.0,400.0])
    pins.connectItem(eChild, '%s.Child' % sProjectNode)
    pins.connectItem(eOldParent, '%s.OldParent' % sProjectNode)
    pins.connectItem(eOldParent if library.isNone(eNewParent) else eNewParent, '%s.NewParent' % sProjectNode)

    pins.connectToPin1D(xChildInitial, '%s.bChildInitial' % sProjectNode)
    pins.connectToPin1D(xOldParentInitial, '%s.bOldParentInitial' % sProjectNode)
    pins.connectToPin1D(xNewParentInitial, '%s.bNewParentInitial' % sProjectNode)
    return '%s.Transform' % sProjectNode



# not tested yet!
def createHierarchyTransformArrayNode(eObjects, fEstimatedSize=[500,100]):
    sNode = createNodeFromPath('/Script/ControlRig.RigUnit_ItemArray')
    pins.setItemArray(eObjects, '%s.Items' % sNode)
    return '%s.Items' % sNode


# to do: get the count of the current pins, and then set iIndex accordingly
def appendToHiarchyTransformArray(sArrayNode, eObject, iIndex=0):
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.insert_array_pin(sArrayNode, -1, '', setup_undo_redo=False)
    pins.connectItem(eObject, '%s.%d' % (sArrayNode,iIndex))


def createArrayAtNode(xArray, xIndex, fNodeSize=[300,100]):
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_GET_AT_INDEX, 'FRigVMUnknownType', '/Script/RigVM.RigVMUnknownType',getNewNodePos(fNodeSize=fNodeSize), 'ArrayGetAtIndex', setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedSize=fNodeSize)
    sAtNode = getNodeNameFromNode(node)
    pins.connectToPin1D(xArray, '%s.Array' % sAtNode)
    pins.connectToPin1D(xIndex, '%s.Index' % sAtNode)
    return '%s.Element' % sAtNode



# not tested yet
def createCloneArrayNode(xArray, fNodeSize=[300,100]):
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_CLONE, 'FRigVMUnknownType', '/Script/RigVM.RigVMUnknownType',getNewNodePos(fNodeSize=fNodeSize), setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedSize=fNodeSize)
    sCloneNode = getNodeNameFromNode(node)
    pins.connectToPin1D(xArray, '%s.Array' % sCloneNode)
    return '%s.Clone' % sCloneNode




def createSetAtNode(xArray, xIndex, xElement, fNodeSize=[300,100]):
    #blueprint.get_controller_by_name('New Function').add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_SET_AT_INDEX, 'FRigVMUnknownType', '/Script/RigVM.RigVMUnknownType', unreal.Vector2D(13.864343, -259.875000), 'ArraySetAtIndex_1')
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_SET_AT_INDEX, 'FRigVMUnknownType', '/Script/RigVM.RigVMUnknownType',getNewNodePos(fNodeSize=fNodeSize), setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedSize=fNodeSize)
    sSetAtNode = getNodeNameFromNode(node)
    pins.connectToPin1D(xArray, '%s.Array' % sSetAtNode)
    pins.connectToPin1D(xIndex, '%s.Index' % sSetAtNode)
    pins.connectToPin1D(xElement, '%s.Element' % sSetAtNode)
    addToExecute(sSetAtNode)
    return sSetAtNode


def createArrayAddNode(xArray, xElement, fNodeSize=[300,100]):
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_template_node('DISPATCH_RigVMDispatch_ArrayAdd(io Array,in Element,out Index)', getNewNodePos(fNodeSize=fNodeSize), setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedSize=fNodeSize)
    sSetAtNode = getNodeNameFromNode(node)
    pins.connectToPin1D(xArray, '%s.Array' % sSetAtNode)
    pins.connectToPin1D(xElement, '%s.Element' % sSetAtNode)
    addToExecute(sSetAtNode)
    return sSetAtNode


# not tested yet
def createArrayAppendNode(xArray, xOtherArray, fNodeSize=[300,100]):
    node = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_template_node('DISPATCH_RigVMDispatch_ArrayAppend(io Array,in Other)', getNewNodePos(fNodeSize=fNodeSize), setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedSize=fNodeSize)
    sAppendNode = getNodeNameFromNode(node)
    pins.connectToPin1D(xArray, '%s.Array' % sAppendNode)
    pins.connectToPin1D(xOtherArray, '%s.Other' % sAppendNode)
    addToExecute(sAppendNode)
    return sAppendNode


def createResetArrayNode(xArray, fNodeSize=[300,100]):
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    node = FD.vmModel.add_template_node('DISPATCH_RigVMDispatch_ArrayReset(io Array)', getNewNodePos(fNodeSize=fNodeSize),'DISPATCH_RigVMDispatch_ArrayReset', setup_undo_redo=False)
    controllers.recordNodeForCommentBox(node, fEstimatedSize=fNodeSize)
    sResetNode = getNodeNameFromNode(node)
    pins.connectToPin1D(xArray, '%s.Array' % sResetNode)
    addToExecute(sResetNode)
    return sResetNode



# not used anywhere? remove?
def splineFromPoints(sPoints, sJoints, hTwists):
    sSplineNode = createNodeFromPath('/Script/ControlRigSpline.RigUnit_ControlRigSplineFromPoints', fNodeSize=[300,300])

    sPoints = list(sPoints)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.SplineMode' % sSplineNode, 'Hermite', setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.SamplesPerSegment' % sSplineNode, '16', setup_undo_redo=False)

    eObjects = [library.getElementKey(sJ, 'Bone') for sJ in sJoints]
    sJointArrayNode = createHierarchyTransformArrayNode(eObjects)

    for p,sPoint in enumerate(sPoints):
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.insert_array_pin('%s.Points' % sSplineNode, -1, '', setup_undo_redo=False)
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link('%s.Translation' % sPoint, '%s.Points.%d' % (sSplineNode, p), setup_undo_redo=False)

    sUpVector = createMakeAbsoluteNode([[0,100000,0], None, None], sPoints[0])
    sFitChainOnSpline = createNodeFromPath('/Script/ControlRigSpline.RigUnit_FitChainToSplineCurveItemArray', bExecuteNode=True)
    addToExecute(sFitChainOnSpline)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(sJointArrayNode, '%s.Items' % sFitChainOnSpline, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link('%s.Spline' % sSplineNode, '%s.Spline' % sFitChainOnSpline, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link('%s.Translation' % sUpVector, '%s.PoleVectorPosition' % sFitChainOnSpline, setup_undo_redo=False)
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.SecondaryAxis.Y' % sFitChainOnSpline, str(-1), setup_undo_redo=False)

    sTwist = getTwist(hTwists[1], hTwists[0])
    sTwistDivided = createBasicCalculateNode([sTwist, 1.0 / len(sJoints)], sOperation='Multiply')
    sTwistRotation = createFromEulerNode([sTwistDivided, 0, 0])

    sDistributeRotation = createDistributeRotationExecuteNode(sJointArrayNode, [None, sTwistRotation])
    pins.connectToPin1D(0.5, '%s.Rotations.1.Ratio' % sDistributeRotation)

    return sFitChainOnSpline



def createIkExecuteNode(eBoneA, eBoneB, eEffector, sEffectorIn, fPrimaryAxis=[1,0,0], fSeconaryAxis=[0,1,0], xPole=None, fWeight=1.0):
    sIkNode = createNodeFromPath('/Script/ControlRig.RigUnit_TwoBoneIKSimplePerItem', fNodeSize=[300,700], bExecuteNode=True)

    pins.connectItem(eBoneA, '%s.ItemA' % sIkNode)
    pins.connectItem(eBoneB, '%s.ItemB' % sIkNode)
    pins.connectItem(eEffector, '%s.EffectorItem' % sIkNode)
    pins.connectToPinVector(fPrimaryAxis, '%s.PrimaryAxis' % sIkNode)
    pins.connectToPinVector(fSeconaryAxis, '%s.SecondaryAxis' % sIkNode)
    pins.connectToPinTransform(sEffectorIn, '%s.Effector' % sIkNode)
    pins.connectToPin1D(fWeight, '%s.Weight' % sIkNode)

    if xPole:
        if isinstance(xPole, (unreal.RigElementKey, str)):
            pins.connectItem(xPole, '%s.PoleVectorSpace' % sIkNode)
            pins.connectToPinVector([0,0,0], '%s.PoleVector' % sIkNode)
        else:
            pins.connectToPinVector(xPole, '%s.PoleVector' % sIkNode)
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.PoleVectorKind' % sIkNode, 'Location', True, setup_undo_redo=False)


    addToExecute(sIkNode)
    return sIkNode


# not tested yet
def createIkPositionsNode(xEffector, xRoot, fBoneLengthA, fBoneLengthB, bEnableStretch=True, xPoleVector=None):
    sIkNode = createNodeFromPath('/Script/ControlRig.RigUnit_TwoBoneIKSimpleVectors', fNodeSize=[300,700])
    pins.connectToPinVector(xEffector, '%s.Effector' % sIkNode)
    pins.connectToPinVector(xRoot, '%s.Root' % sIkNode)
    if xPoleVector:
        pins.connectToPinVector(xPoleVector, '%s.PoleVector' % sIkNode)
    pins.connectToPin1D(bEnableStretch, '%s.bEnableStretch' % sIkNode)
    pins.connectToPin1D(fBoneLengthA, '%s.BoneALength' % sIkNode)
    pins.connectToPin1D(fBoneLengthB, '%s.BoneBLength' % sIkNode)
    return sIkNode


def createIkTransformsNode(xRoot, xEffector, fBoneLengthA, fBoneLengthB, bEnableStretch=True, sPoleVector=None, fPrimaryAxis=[1,0,0], fSecondaryAxis=[0,1,0]):
    sIkNode = createNodeFromPath('/Script/ControlRig.RigUnit_TwoBoneIKSimpleTransforms', fNodeSize=[300,700])
    pins.connectToPinTransform(xEffector, '%s.Effector' % sIkNode)
    pins.connectToPinTransform(xRoot, '%s.Root' % sIkNode)
    # pins.connectToPinTransform(xElbow, '%s.Elbow' % sIkNode)
    pins.connectToPin1D(bEnableStretch, '%s.bEnableStretch' % sIkNode)
    pins.connectToPin1D(1.0, '%s.StretchStartRatio' % sIkNode)

    pins.connectToPin1D(fBoneLengthA, '%s.BoneALength' % sIkNode)
    pins.connectToPin1D(fBoneLengthB, '%s.BoneBLength' % sIkNode)
    pins.connectToPinVector(fSecondaryAxis, '%s.SecondaryAxis' % sIkNode)
    pins.connectToPinVector(fPrimaryAxis, '%s.PrimaryAxis' % sIkNode)
    if sPoleVector:
        pins.connectToPinVector(sPoleVector, '%s.PoleVector' % sIkNode)
    return sIkNode



def createAimExecuteNode(eBone, sTarget, fAimVector=[1,0,0], fUpVector=[0,0,1], bUpIsDirection=False, sSecondaryTargetVector=None):
    sAimNode = createNodeFromPath('/Script/ControlRig.RigUnit_AimItem', bExecuteNode=True, fNodeSize=[300.0,600.0])
    pins.connectItem(eBone, '%s.Item' % sAimNode)

    pins.connectToPinVector(fAimVector, '%s.Primary.Axis' % sAimNode)
    pins.connectToPinVector(fUpVector, '%s.Secondary.Axis' % sAimNode)
    pins.connectToPinVector(sTarget, '%s.Primary.Target' % sAimNode)
    pins.connectItem(hierarchy.eOrigin, '%s.Secondary.Space' % sAimNode)

    if bUpIsDirection:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Secondary.Kind' % sAimNode, 'Direction', False, setup_undo_redo=False)

    if sSecondaryTargetVector != None:
        pins.connectToPinVector(sSecondaryTargetVector, '%s.Secondary.Target' % sAimNode)

    addToExecute(sAimNode)
    return sAimNode



def createAimConstraintExecuteNode(eTargets, eBone, fAimVector=[1,0,0], fUpVector=[0,0,1], fWorldUpVector=[0,0,1], bMaintainOffset=False, bUpIsDirection=False, eWorldUpSpace=None):
    '''
    Could be unreal bug, but DIRECTION and eWorldUpSpace and bMaintainOffset has wrong results. Try to avoid these combinations
    '''

    sAimNode = createNodeFromPath('/Script/ControlRig.RigUnit_AimConstraintLocalSpaceOffset', bExecuteNode=True, fNodeSize=[300.0,600.0])
    pins.connectItem(eBone, '%s.Child' % sAimNode)

    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Item.Type' % sAimNode, '(Type=%s)' % eBone.type)
    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Item.Name' % sAimNode, eBone.name, False)

    # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(sTarget, '%s.Primary.Target' % sAimNode)

    pins.connectToPinVector(fAimVector, '%s.AimAxis' % sAimNode)
    pins.connectToPinVector(fUpVector, '%s.UpAxis' % sAimNode)
    pins.connectToPinVector(fWorldUpVector, '%s.WorldUp.Target' % sAimNode)
    pins.connectItem(eTargets[0], '%s.Parents.0.Item' % sAimNode)


    # pins.connectItem(eOrigin, '%s.Secondary.Space' % sAimNode)

    pins.connectToPin1D(bMaintainOffset, '%s.bMaintainOffset' % sAimNode)
    if bUpIsDirection:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.WorldUp.Kind' % sAimNode, 'Direction', False, setup_undo_redo=False)
    else:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.WorldUp.Kind' % sAimNode, 'Location', False, setup_undo_redo=False)
        # controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.WorldUp.Kind' % sAimNode, 'Direction', False)

    if eWorldUpSpace:
        pins.connectItem(eWorldUpSpace, '%s.WorldUp.Space' % sAimNode)

    addToExecute(sAimNode)
    return sAimNode


def createAimNode(xTransform, sTarget, fAimVector=[1,0,0], fUpVector=[0,0,1], fNodeSize=[300.0,600.0], bUpIsDirection=False, fWorldUpVector=[1,0,0], bTargetIsDirection=False, sSecondaryTarget=None):
    '''
    bUpIsDirection not tested yet
    '''
    sAimNode = createNodeFromPath('/Script/ControlRig.RigUnit_AimBoneMath', fNodeSize=fNodeSize)
    pins.connectToPinTransform(xTransform, '%s.InputTransform' % sAimNode)

    pins.connectToPinVector(fAimVector, '%s.Primary.Axis' % sAimNode)
    pins.connectToPinVector(fUpVector, '%s.Secondary.Axis' % sAimNode)
    pins.connectToPinVector(fWorldUpVector, '%s.Secondary.Target' % sAimNode)
    pins.connectToPinVector(sTarget, '%s.Primary.Target' % sAimNode)
    pins.connectItem(hierarchy.eOrigin, '%s.Secondary.Space' % sAimNode)

    if bUpIsDirection:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Secondary.Kind' % sAimNode, 'Direction', False, setup_undo_redo=False)
    if bTargetIsDirection:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Primary.Kind' % sAimNode, 'Direction', False, setup_undo_redo=False)

    return '%s.Result' % sAimNode


def createFromTwoVectorsNode(sA, sB, fNodeSize=[300.0,600.0]):
    sAimNode = createNodeFromPath('/Script/RigVM.RigVMFunction_MathQuaternionFromTwoVectors', fNodeSize=fNodeSize)
    pins.connectToPinVector(sA, '%s.A' % sAimNode)
    pins.connectToPinVector(sB, '%s.B' % sAimNode)
    return '%s.Result' % sAimNode


def createFloatAttrWithGetNode(sAttrName, eParent, fRange=[0,1], fDefault=0.0):
    eFloatCtrl = hierarchy.createFloatControl(sAttrName, eParent=eParent, fRange=fRange, fDefault=fDefault)
    return createGetChannelNode2(eParent.name, eFloatCtrl)


def createOffOnAttrWithGetNode(sAttrName, eParent, bDefault=False):
    eBoolCtrl = hierarchy.createBoolControl(sAttrName, eParent=eParent, bDefault=bDefault)
    return createGetChannelNode2(eParent.name, eBoolCtrl)


def createConstraintParentAppendExecuteNode(xArrayA, xArrayB):
    uNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_APPEND,
                                                                         'FConstraintParent', '/Script/ControlRig.ConstraintParent', getNewNodePos(), 'ArrayAppend', setup_undo_redo=False)
    sAppendNode = getNodeNameFromNode(uNode)
    pins.connectToPinConstraintParentArray(xArrayA, '%s.Array' % sAppendNode)
    pins.connectToPinConstraintParentArray(xArrayB, '%s.Other' % sAppendNode)
    addToExecute(sAppendNode)
    return sAppendNode


def createConstraintParentSetNumExecuteNode(xArray, xNumber):
    uNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_SET_NUM,
                                                                         'FConstraintParent', '/Script/ControlRig.ConstraintParent', getNewNodePos(), 'ArraySetNum', setup_undo_redo=False)
    sSetNumNode = getNodeNameFromNode(uNode)
    pins.connectToPinConstraintParentArray(xArray, '%s.Array' % sSetNumNode)
    pins.connectToPin1D(xNumber, '%s.Num' % sSetNumNode)

    addToExecute(sSetNumNode)
    return sSetNumNode


def createConstraintParentGetNumNode(xArray):
    uNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_GET_NUM,
                                                                         'FConstraintParent', '/Script/ControlRig.ConstraintParent', getNewNodePos(), 'ArrayGetNum', setup_undo_redo=False)
    sGetNumbNode = getNodeNameFromNode(uNode)
    pins.connectToPinConstraintParentArray(xArray, '%s.Array' % sGetNumbNode)

    return '%s.Num' % sGetNumbNode


def createArrayGetCountNode(xArray):
    sGetNumNode = addTemplateNode('DISPATCH_RigVMDispatch_ArrayGetNum(in Array,out Num)')
    pins.connectToPinConstraintParentArray(xArray, '%s.Array' % sGetNumNode)
    return '%s.Num' % sGetNumNode


def createGetMetaData(eItem, sName, sDefault=None, iType=None):
    sMetaDataNode = addTemplateNode('DISPATCH_RigDispatch_GetMetadata(in Item,in Name,in NameSpace,in Default,out Value,out Found)')
    pins.connectItem(eItem, '%s.Item' % sMetaDataNode)
    pins.setString(sName, '%s.Name' % sMetaDataNode, bConnectIfPlug=True)

    if not library.isNone(iType):
        pins.resolveWildCardPin('%s.Default' % sMetaDataNode, iType)
    pins.connectToPin1D(sDefault, '%s.Default' % sMetaDataNode)
    return '%s.Value' % sMetaDataNode



def createSetMetaDataExecuteNode(eItem, sName, sValue=None, iType=pins.PinType.double):
    sMetaDataNode = addTemplateNode('DISPATCH_RigDispatch_SetMetadata(in Item,in Name,in NameSpace,in Value,out Success)')
    pins.connectItem(eItem, '%s.Item' % sMetaDataNode)
    pins.setString(sName, '%s.Name' % sMetaDataNode, bConnectIfPlug=True)
    pins.resolveWildCardPin('%s.Value' % sMetaDataNode, iType)
    pins.connectToPin1D(sValue, '%s.Value' % sMetaDataNode)
    addToExecute(sMetaDataNode)
    return sMetaDataNode


def createHasMetaData(eItem, sName, iType=pins.PinType.double):
    sMetaDataNode = createNodeFromPath('/Script/ControlRig.RigUnit_HasMetadata')
    pins.connectItem(eItem, '%s.Item' % sMetaDataNode)
    pins.setString(sName, '%s.Name' % sMetaDataNode, bConnectIfPlug=True)

    dTypes = {}
    dTypes[pins.PinType.bool] = 'Bool'
    dTypes[pins.PinType.double] = 'Float'
    dTypes[pins.PinType.integer] = 'Int32'
    dTypes[pins.PinType.vector] = 'Vector'
    dTypes[pins.PinType.item] = 'RigElementKey'
    dTypes[pins.PinType.transform] = 'Transform'
    pins.setDefaultValue(dTypes[iType], '%s.Type' % sMetaDataNode)
    return '%s.Found' % sMetaDataNode


def createConstraintParentSetAtExecuteNode(xArray, xIndex, xConstraintParent):
    uNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_array_node_from_object_path(unreal.RigVMOpCode.ARRAY_SET_AT_INDEX,
                                                                         'FConstraintParent', '/Script/ControlRig.ConstraintParent', getNewNodePos(), 'ArraySetAtIndex', setup_undo_redo=False)
    sSetAtNode = getNodeNameFromNode(uNode)
    pins.connectToPinConstraintParentArray(xArray, '%s.Array' % sSetAtNode)
    pins.connectToPin1D(xIndex, '%s.Index' % sSetAtNode)
    pins.connectToPinConstraintParent(xConstraintParent, '%s.Element' % sSetAtNode)

    addToExecute(sSetAtNode)
    return sSetAtNode


def createParentConstraintExecuteNode(xParents, eBone, bMaintainOffset=False, skipTranslate=[], skipRotate=[], skipScale=['x','y','z'], fWeight=1.0):

    sParentConstraintNode = createNodeFromPath('/Script/ControlRig.RigUnit_ParentConstraint', fNodeSize=[300,400], bExecuteNode=True)
    for sAxis in skipTranslate:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Filter.TranslationFilter.b%s' % (sParentConstraintNode, sAxis.upper()), 'false', False, setup_undo_redo=False)
    for sAxis in skipRotate:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Filter.RotationFilter.b%s' % (sParentConstraintNode, sAxis.upper()), 'false', False, setup_undo_redo=False)
    for sAxis in skipScale:
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_pin_default_value('%s.Filter.ScaleFilter.b%s' % (sParentConstraintNode, sAxis.upper()), 'false', False, setup_undo_redo=False)

    pins.connectItem(eBone, '%s.Child' % sParentConstraintNode)

    # xParents is [hierarchy.ConstraintParent('Entry.Control', 1.0)]
    pins.connectToPinConstraintParentArray(xParents, '%s.Parents' % sParentConstraintNode)

    pins.connectToPin1D(bMaintainOffset, '%s.bMaintainOffset' % sParentConstraintNode)
    pins.connectToPin1D(fWeight, '%s.Weight' % sParentConstraintNode)

    addToExecute(sParentConstraintNode)



def createPositionConstraintExecuteNode(xParents, eBone, bMaintainOffset=False, fWeight=1.0):

    sParentConstraintNode = createNodeFromPath('/Script/ControlRig.RigUnit_PositionConstraintLocalSpaceOffset', fNodeSize=[300,400], bExecuteNode=True)
    pins.connectItem(eBone, '%s.Child' % sParentConstraintNode)

    # xParents is [hierarchy.ConstraintParent('Entry.Control', 1.0)]
    pins.connectToPinConstraintParentArray(xParents, '%s.Parents' % sParentConstraintNode)

    pins.connectToPin1D(bMaintainOffset, '%s.bMaintainOffset' % sParentConstraintNode)
    pins.connectToPin1D(fWeight, '%s.Weight' % sParentConstraintNode)

    addToExecute(sParentConstraintNode)



def createOrientConstraintExecuteNode(xParents, eBone, bMaintainOffset=False):
    sParentConstraintNode = createNodeFromPath('/Script/ControlRig.RigUnit_RotationConstraintLocalSpaceOffset', fNodeSize=[300,400], bExecuteNode=True)
    pins.connectItem(eBone, '%s.Child' % sParentConstraintNode)

    # xParents is [hierarchy.ConstraintParent('Entry.Control', 1.0)]
    pins.connectToPinConstraintParentArray(xParents, '%s.Parents' % sParentConstraintNode)

    pins.connectToPin1D(bMaintainOffset, '%s.bMaintainOffset' % sParentConstraintNode)

    addToExecute(sParentConstraintNode)







def createRotationConstraintExecuteNode(hParents, hBone, bMaintainOffset=False):
    sParentConstraintNode = createNodeFromPath('/Script/ControlRig.RigUnit_RotationConstraintLocalSpaceOffset', fNodeSize=[300,400], bExecuteNode=True)
    pins.connectItem(hBone, '%s.Child' % sParentConstraintNode)
    pins.connectToPinConstraintParentArray(hParents, '%s.Parents' % sParentConstraintNode)
    pins.connectToPin1D(bMaintainOffset, '%s.bMaintainOffset' % sParentConstraintNode)
    addToExecute(sParentConstraintNode)
    return sParentConstraintNode





def getTwistNodes(eObject, hParentObject, iForwardAxis=1, iSideAxis=2):
    sObject = getTransformNode(eObject)
    sParent = getTransformNode(hParentObject)

    controllers.setNewColumn()

    sLocal = createMakeRelativeNode(sObject, sParent)
    fForwardVector = [0,0,0]
    fForwardVector[iForwardAxis] = 10
    fSideVector = [0,0,0]
    fSideVector[iSideAxis] = 10
    sForwardAxis = ['X','Y','Z'][iForwardAxis]
    sSideAxis = ['X','Y','Z'][iSideAxis]

    sForward = createMakeAbsoluteNode([fForwardVector,None,None], sLocal)

    controllers.setNewColumn()
    sForwardOrigin = createBasicCalculateNode(['%s.Translation' % sForward, '%s.Translation' % sLocal], sOperation='Subtract', bVector=True)

    sForwardOriginClampped = [0,0,0]
    sForwardOriginClampped[iForwardAxis] = '%s.%s' % (sForwardOrigin, sForwardAxis)
    sForwardOriginClampped[iSideAxis] = '%s.%s' % (sForwardOrigin, sSideAxis)
    sAngle = createGetAngleNode(sForwardOriginClampped, fForwardVector, bDegrees=True)

    sSide = createMakeAbsoluteNode([fSideVector,None,None], sLocal)
    controllers.setNewColumn()
    sSideOrigin = createBasicCalculateNode(['%s.Translation' % sSide, '%s.Translation' % sLocal], sOperation='Subtract', bVector=True)

    sSignedAngle = createConditionNodes('%s.%s' % (sSideOrigin, sForwardAxis), '>', 0, sAngle, createBasicCalculateNode([sAngle, -1], sOperation='Multiply'))
    return sSignedAngle



def startFunction(sFunctionName, xInputs=[], xOutputs=[], bMutable=True, bSequencer=False):
    controllers.functionStacks[controllers.__iCurrentSolver__].append(controllers.functionData(sFunctionName, bMutable=bMutable, bSequencer=bSequencer, iSolver=controllers.__iCurrentSolver__, xInputs=xInputs, xOutputs=xOutputs))

    uFunction = controllers.library_controller.add_function_to_library(sFunctionName, mutable=bMutable, setup_undo_redo=False)
    sFunctionGivenName = getNodeNameFromNode(uFunction)

    uFunctionLibrary = controllers.blueprint.get_controller_by_name(sFunctionGivenName)
    for sName, sType, bArray in xInputs:
        uFunctionLibrary.add_exposed_pin(sName, unreal.RigVMPinDirection.INPUT,  'TArray<%s>' % sType if bArray else sType, library.dCppTypes.get(sType, ''), '', setup_undo_redo=False)
    for sName, sType, bArray in xOutputs:
        uFunctionLibrary.add_exposed_pin(sName, unreal.RigVMPinDirection.OUTPUT, 'TArray<%s>' % sType if bArray else sType, library.dCppTypes.get(sType, ''), '', setup_undo_redo=False)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel = controllers.blueprint.get_controller_by_name(sFunctionGivenName)
    if bMutable:
        if bSequencer:
            createSequencer()

    return sFunctionGivenName



def getFunction(sFunctionName):
    uFunction = controllers.function_library.find_function(sFunctionName)
    return uFunction


def endCurrentFunction(bAddToExecute=True, bReturnInNewSequencerPlug=False):
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    if FD.bMutable:
        if FD.sSequencer and bReturnInNewSequencerPlug:
            newSequencerPlug()
        controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_link(FD.sLastExecutes[-1], 'Return.ExecuteContext', setup_undo_redo=False)

    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.set_node_position_by_name('Return', unreal.Vector2D(FD.iCurrentNodePos[0] + 600, FD.iCurrentNodePos[1]), setup_undo_redo=False)

    sFunctionName = FD.sFunctionName
    del controllers.functionStacks[controllers.__iCurrentSolver__][-1]

    if bAddToExecute:
        return addFunctionNode(sFunctionName)



def addFunctionNode(sName, bFunctionIsMutable=True, fNodeSize=[300.0,200.0]):
    # bFunctionIsMutable = dMutableFunctions[sName]
    uNodePos = getNewNodePos(fNodeSize=fNodeSize, bExecuteNode=bFunctionIsMutable)
    uNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_function_reference_node(controllers.blueprint.get_local_function_library().find_function(sName), uNodePos, sName, setup_undo_redo=False)
    controllers.recordNodeForCommentBox(uNode)
    sFunctionNode = getNodeNameFromNode(uNode)
    if bFunctionIsMutable:
        addToExecute(sFunctionNode)
    return sFunctionNode


def createGetTransformsExecute(eObjects=[], fNodeSize=[600.0,400.0]):
    uGetTransformsNode = controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.add_function_reference_node(controllers.function_blueprint.get_local_function_library().find_function('GetTransforms'),
        getNewNodePos(fNodeSize=fNodeSize, bExecuteNode=True), 'GetTransforms', setup_undo_redo=False)
    controllers.recordNodeForCommentBox(uGetTransformsNode)
    sGetTransformsNode = getNodeNameFromNode(uGetTransformsNode)

    pins.setItemArray(eObjects, '%s.Items' % sGetTransformsNode)
    addToExecute(sGetTransformsNode)
    return sGetTransformsNode


def createGetVariableNode(vVariable, iForceNodePos=None, fNodeSize=[300.0,200.0]):
    if isinstance(iForceNodePos, type(None)):
        uNodePos = getNewNodePos(fNodeSize=[200,50], bExecuteNode=False)
    else:
        uNodePos = unreal.Vector2D(iForceNodePos[0], iForceNodePos[1])
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    if vVariable.bLocal:
        uVariableNode = FD.vmModel.add_variable_node_from_object_path(vVariable.sName, vVariable.sType, vVariable.sCppType, is_getter=True, default_value='', position=uNodePos, setup_undo_redo=False)
    else:
        if vVariable.sCppType:
            uVariableNode = FD.vmModel.add_variable_node_from_object_path(vVariable.sName, vVariable.sType, vVariable.sCppType, is_getter=True, default_value='', position=uNodePos, setup_undo_redo=False)
        else:
            uVariableNode = FD.vmModel.add_variable_node(vVariable.sName, vVariable.sType, None, is_getter=True, default_value='', position=uNodePos, setup_undo_redo=False)
    controllers.recordNodeForCommentBox(uVariableNode, fNodeSize)

    sVariableNode = getNodeNameFromNode(uVariableNode)
    return '%s.Value' % sVariableNode


def createGetEntryVariable(sName, iForceNodePos=None, fNodeSize=[300.0,30.0]):
    if isinstance(iForceNodePos, type(None)):
        uNodePos = getNewNodePos(fNodeSize=fNodeSize, bExecuteNode=False)
    else:
        uNodePos = unreal.Vector2D(iForceNodePos[0], iForceNodePos[1])

    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]

    sType, bArray = FD.dInputs[sName]

    sCppType = library.dCppTypes.get(sType, None)
    sTypePass =  f'TArray<{sType}>' if bArray else sType
    if sCppType:
        uVariableNode = FD.vmModel.add_variable_node_from_object_path(sName, sTypePass, sCppType, is_getter=True, default_value='', position=uNodePos, setup_undo_redo=False)
    else:
        uVariableNode = FD.vmModel.add_variable_node(sName, sTypePass, None, is_getter=True, default_value='', position=uNodePos, setup_undo_redo=False)
    controllers.recordNodeForCommentBox(uVariableNode, fNodeSize)

    sVariableNode = getNodeNameFromNode(uVariableNode)
    return '%s.Value' % sVariableNode



def createSetVariableExecuteNode(vVariable, xValue, iForceNodePos=None, fNodeSize=[300.0,200.0]):
    if isinstance(iForceNodePos, type(None)):
        uNodePos = getNewNodePos(fNodeSize=fNodeSize, bExecuteNode=False)
    else:
        uNodePos = unreal.Vector2D(iForceNodePos[0], iForceNodePos[1])
    FD = controllers.functionStacks[controllers.__iCurrentSolver__][-1]
    if vVariable.bLocal:
        uVariableNode = FD.vmModel.add_variable_node_from_object_path(vVariable.sName, vVariable.sType, vVariable.sCppType, is_getter=False, default_value='', position=uNodePos, setup_undo_redo=False)
    else:
        if vVariable.sCppType:
            uVariableNode = FD.vmModel.add_variable_node_from_object_path(vVariable.sName, vVariable.sType, vVariable.sCppType, is_getter=False, default_value='', position=uNodePos, setup_undo_redo=False)
        else:
            uVariableNode = FD.vmModel.add_variable_node(vVariable.sName, vVariable.sType, None, is_getter=False, default_value='', position=uNodePos, setup_undo_redo=False)
    controllers.recordNodeForCommentBox(uVariableNode, fNodeSize)

    sVariableNode = getNodeNameFromNode(uVariableNode)
    if vVariable.sType == 'FVector':
        pins.connectToPinVector(xValue, '%s.Value' % sVariableNode)
    else:
        pins.connectToPin1D(xValue, '%s.Value' % sVariableNode)
    addToExecute(sVariableNode)#, sFollowingExecutePin='Execute')
    return sVariableNode





def createNameReplaceNode(sString, sOld, sNew):
    sNode = addTemplateNode('Replace::Execute(in Name,in Old,in New,out Result)')
    pins.setString(sString, '%s.Name' % sNode, bConnectIfPlug=True)
    pins.setString(sOld, '%s.Old' % sNode, bConnectIfPlug=True)
    pins.setString(sNew, '%s.New' % sNode, bConnectIfPlug=True)
    return '%s.Result' % sNode


def createNameConcatNode(sA, sB):
    sNode = addTemplateNode('Concat::Execute(in A,in B,out Result)')
    pins.setString(sA, '%s.A' % sNode, bConnectIfPlug=True)
    pins.setString(sB, '%s.B' % sNode, bConnectIfPlug=True)
    return '%s.Result' % sNode


# blueprint.get_controller_by_name('FORWARD').add_template_node('Replace::Execute(in Name,in Old,in New,out Result)', unreal.Vector2D(11600.136233, -591.799912), 'Replace')







