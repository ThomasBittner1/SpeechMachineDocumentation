###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import controllers
import library
import hierarchy

class PinType():
    integer = 0
    double = 1
    vector = 2
    bool = 3
    spline = 4
    item = 5
    transform = 6

dPinTypes = {}
dPinTypes[PinType.bool] = 'bool'
dPinTypes[PinType.double] = 'double'
dPinTypes[PinType.integer] = 'int32'
dPinTypes[PinType.vector] = 'FVector'
dPinTypes[PinType.item] = 'FRigElementKey'
dPinTypes[PinType.transform] = 'FTransform'


def setString(sString, sPin, bConnectIfPlug=True):
    if bConnectIfPlug and '.' in str(sString):
        connectToPin1D(sString, sPin)
    else:
        controllers.latestFD().vmModel.set_pin_default_value(sPin, sString, setup_undo_redo=False)


def getParentPin(sPin):
    return sPin[:sPin.rfind('.')]


def connectToPin1D(xFrom, sToPin):
    if not isinstance(xFrom, type(None)):
        if isinstance(xFrom, str):
            if xFrom.upper() == 'NONE':
                controllers.latestFD().vmModel.set_pin_default_value(sToPin, xFrom, setup_undo_redo=False)
            else:
                controllers.latestFD().vmModel.add_link(xFrom, sToPin, setup_undo_redo=False)
        elif isinstance(xFrom, bool):
            controllers.latestFD().vmModel.set_pin_default_value(sToPin, 'true' if xFrom else 'false', False, setup_undo_redo=False)
        elif isinstance(xFrom, float):
            controllers.latestFD().vmModel.set_pin_default_value(sToPin, '%0.6f' % xFrom, True, setup_undo_redo=False)
        elif isinstance(xFrom, int):
            controllers.latestFD().vmModel.set_pin_default_value(sToPin, '%d' % xFrom, True, setup_undo_redo=False)
        elif not isinstance(xFrom, type(None)):
            raise Exception('not sure what type "%s" is (%s)' % (xFrom, type(xFrom)))

        expandParentPins(xFrom)
        # if isinstance(xFrom, str) and xFrom.count('.') >= 2:
        #     expandPin(getParentPin(xFrom))




def connectToPinVector(xFrom, sVectorPin, sAttrs=['X','Y','Z'], bAutoExpand=True):
    if not isinstance(xFrom, type(None)):
        if isinstance(xFrom, str):
            connectToPin1D(xFrom, sVectorPin)
            expandParentPins(xFrom)
            # if isinstance(xFrom, str) and xFrom.count('.') >= 2:
            #     expandPin(getParentPin(xFrom))
        elif isinstance(xFrom, (list,tuple)):
            for xF, sA in zip(xFrom, sAttrs):
                connectToPin1D(xF, '%s.%s' % (sVectorPin, sA))
            if bAutoExpand:
                expandPin(sVectorPin)
        else:
            controllers.latestFD().vmModel.add_link(xFrom, sVectorPin, setup_undo_redo=False)


def expandPin(sPin, bExpand=True):
    controllers.latestFD().vmModel.set_pin_expansion(sPin, bExpand, setup_undo_redo=False)

def expandParentPins(sPin, bExpand=True):
    if isinstance(sPin, str) and sPin.count('.') >= 2:
        sParentPin = getParentPin(sPin)
        expandPin(sParentPin, bExpand=bExpand)
        if sParentPin.count('.') >= 2:
            sParentPin = getParentPin(sParentPin)
            expandPin(sParentPin, bExpand=bExpand)


def connectToPinColor(xFrom, sColorPin, sAttrs=['R', 'G', 'B', 'A'], bAutoExpand=True):
    if not isinstance(xFrom, type(None)):
        if isinstance(xFrom, str):
            connectToPin1D(xFrom, sColorPin)
        elif isinstance(xFrom, (list,tuple)):
            for xF, sA in zip(xFrom, sAttrs):
                connectToPin1D(xF, '%s.%s' % (sColorPin, sA))
            if bAutoExpand:
                expandPin(sColorPin)
        else:
            controllers.latestFD().vmModel.add_link(xFrom, sColorPin, setup_undo_redo=False)


def setDefaultValue(sValue, sPin):
    controllers.latestFD().vmModel.set_pin_default_value(sPin, sValue, setup_undo_redo=False)


def connectToPinTransform(xFrom, sTransformPin, bAutoExpand=True):
    if xFrom:
        if isinstance(xFrom, (list,tuple)):
            connectToPinVector(xFrom[0], '%s.Translation' % sTransformPin)
            connectToPin1D(xFrom[1], '%s.Rotation' % sTransformPin)
            connectToPinVector(xFrom[2], '%s.Scale3D' % sTransformPin)
            if bAutoExpand:
                expandPin(sTransformPin)
        else:
            controllers.latestFD().vmModel.add_link(xFrom, sTransformPin, setup_undo_redo=False)


def connectItem(xElementOrString, sItemPin):
    if isinstance(xElementOrString, str):
        connectToPin1D(xElementOrString, sItemPin)
    else:
        setString(library.dElementTypeStrings[xElementOrString.type], '%s.Type' % sItemPin)
        if '.' in str(xElementOrString.name):
            connectToPin1D(str(xElementOrString.name), '%s.Name' % sItemPin)
        else:
            setString(xElementOrString.name, '%s.Name' % sItemPin)

        expandPin(sItemPin)


def setValueArray(fValues, sValuePin, bInt=False):
    if isinstance(fValues, str):
        connectToPin1D(fValues, sValuePin)
    else:
        if bInt:
            sValues = '(%s)' % ','.join(['0.0' if isinstance(iV,str) else ('%d'%iV) for iV in fValues])
        else:
            sValues = '(%s)' % ','.join(['0.0' if isinstance(fV,str) else ('%0.10f'%fV) for fV in fValues])
        controllers.latestFD().vmModel.set_pin_default_value(sValuePin, sValues, setup_undo_redo=False) # '(5,4,3,2)'
        for i,fV in enumerate(fValues):
            if isinstance(fV,str):
                connectToPin1D(fV, '%s.%d' % (sValuePin,i))

def setStringArray(sStrings, sPin):
    if isinstance(sStrings, str):
        connectToPin1D(sStrings, sPin)
    else:
        sSetString = '(%s)' % ','.join(['"%s"' % str(fV).replace('.','') for fV in sStrings])
        controllers.latestFD().vmModel.set_pin_default_value(sPin, sSetString, setup_undo_redo=False)
        for i,sStr in enumerate(sStrings):
            if '.' in str(sStr):
                connectToPin1D(sStr, '%s.%d' % (sPin, i))
        expandPin(sPin)

# blueprint.get_controller_by_name('RigVMModel').set_pin_default_value('New Function.Argument', '("one","two","three")')


def setVectorArray(fVectors, sVectorPin):
    if isinstance(fVectors, str):
        connectToPin1D(fVectors, sVectorPin)
    elif isinstance(fVectors, (list,tuple)):
        sVectors = '(%s)' % ','.join([('(X=%0.10f,Y=%0.10f,Z=%0.10f)') % ((0,0,0) if isinstance(fV,str) else (fV[0],fV[1],fV[2])) for fV in fVectors])
        controllers.latestFD().vmModel.set_pin_default_value(sVectorPin, sVectors, setup_undo_redo=False) # '(5,4,3,2)'
        for i,fV in enumerate(fVectors):
            if isinstance(fV,str):
                connectToPinVector(fV, '%s.%d' % (sVectorPin,i))


def setItemArray(eElements, sItemsPin):
    if isinstance(eElements, str):
        connectToPin1D(eElements, sItemsPin)
    else:
        sStrings = []
        for eO in eElements:
            if isinstance(eO, unreal.RigElementKey):
                sStrings.append('(Type=%s,Name="%s")' % (library.dElementTypeStrings[eO.type],
                                                         'None' if '.' in str(eO.name) else eO.name))
            else:
                sStrings.append('(Type="Bone",Name="None")')

        sStrings = '(%s)' % ','.join(sStrings)
        setString(sStrings, sItemsPin)

        for i, eO in enumerate(eElements):
            if isinstance(eO, unreal.RigElementKey):
                if '.' in str(eO.name):
                    connectToPin1D(str(eO.name), '%s.%d.Name' % (sItemsPin, i))
            else:
                connectToPin1D(eO, '%s.%d' % (sItemsPin, i))



def connectToPinConstraintParent(xFrom, sConstraintParentPin): # xFrom: hierarchy.ConstraintParent('Entry.Control', 1.0)
    if isinstance(xFrom, str):
        connectToPin1D(xFrom, sConstraintParentPin)
    if isinstance(xFrom, unreal.RigElementKey):
        connectItem(xFrom, '%s.Item' % sConstraintParentPin)
        connectToPin1D(1.0, '%s.Weight' % sConstraintParentPin)
    elif isinstance(xFrom, tuple):
        if len(xFrom) != 2:
            raise Exception('"%s" needs to be in the form of (Item, Weight)' % xFrom)
        connectItem(xFrom[0], '%s.Item' % sConstraintParentPin)
        connectToPin1D(xFrom[1], '%s.Weight' % sConstraintParentPin)
    else:
        raise Exception('Don\'t know what to do with type "%s" is (%s)' % (type(xFrom), xFrom))


def connectToPinConstraintParentArray(xFromArray, sConstraintParentArrayPin):
    if isinstance(xFromArray, (list,tuple)):
        if len(xFromArray):
            sString = '(%s)' % ','.join(['(Item=(Type=Bone,Name="None"),Weight=0.0)'] * len(xFromArray))
            controllers.latestFD().vmModel.set_pin_default_value(sConstraintParentArrayPin, sString, setup_undo_redo=False)
            for i,xCP in enumerate(xFromArray):
                connectToPinConstraintParent(xCP, '%s.%d' % (sConstraintParentArrayPin, i))
    else: # string
        connectToPin1D(xFromArray, sConstraintParentArrayPin)




#not tested yet:
def setCurveData(sCurveAttr, fTimes, fValues):
    sCurveDataString = '(EditorCurveData=(Keys=(%s)))' % ','.join(['(Time=%0.5f,Value=%0.5f)' % (fT,fV) for fT,fV in zip(fTimes,fValues)])
    controllers.latestFD().vmModel.set_pin_default_value(sCurveAttr, sCurveDataString)



# not fully tested:
def setMatrixToTransformPin(ffMatrix, sPin):
    uMatrix = unreal.Matrix(ffMatrix[0], ffMatrix[1], ffMatrix[2], ffMatrix[3])
    fTranslation = uMatrix.get_origin()
    fRotation = uMatrix.to_quat()
    fScale = uMatrix.get_scale_vector()

    sMatrixString = '(Rotation=(X=%0.7f,Y=%0.7f,Z=%0.7f,W=%0.7f),Translation=(X=%0.7f,Y=%0.7f,Z=%0.7f),Scale3D=(X=%0.7f,Y=%0.7f,Z=%0.7f))' % \
        (fRotation.x, fRotation.y, fRotation.z, fRotation.w, fTranslation.x, fTranslation.y, fTranslation.z, fScale.x, fScale.y, fScale.z)
    print ('sMatrixString: ', sMatrixString)
    controllers.latestFD().vmModel.set_pin_default_value(sPin, sMatrixString, True, setup_undo_redo=False)




def resolveWildCardPin(sPin, sType):
    if isinstance(sType, int):
        sType = dPinTypes[sType]

    sCppType = library.dCppTypes.get(sType, 'None')
    controllers.functionStacks[controllers.__iCurrentSolver__][-1].vmModel.resolve_wild_card_pin(sPin, sType, sCppType, setup_undo_redo=False)
