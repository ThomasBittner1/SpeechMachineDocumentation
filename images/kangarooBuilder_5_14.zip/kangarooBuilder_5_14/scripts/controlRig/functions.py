###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import math
import unreal
import nodes
import library
import hierarchy
import pins
import controllers
from collections import defaultdict

ELEM = library.getElementKey

xBlendInfo = None
def createBlendingSetup(sName, sSide, sFeatures, bDefault=False, eGlobalCtrl=None):
    sBlendName = '%s_%s_%s2%s' % (sSide, sName, sFeatures[0].split('_')[-1], sFeatures[1].split('_')[-1])
    controllers.setNewColumn()

    if eGlobalCtrl == None:
        eParent = ELEM('placement_ctrl','Control')
    else:
        eParent = eGlobalCtrl
    eBlendAttr = hierarchy.createFloatControl(sBlendName, fRange=[0,1], fDefault=bDefault, eParent=eParent, bIsBool=True)

    sSwitchNode = createFeatureSwitchFunction(eBlendAttr, eParent,[], [])
    global xBlendInfo
    xBlendInfo = '%s.ControlsA' % sSwitchNode, '%s.ControlsB' % sSwitchNode
    return ['%s.SwitchFeatureA' % sSwitchNode, '%s.SwitchFeatureB' % sSwitchNode]


def connectControlsToSwitches(ssControls):
    global xBlendInfo
    sFkControlArray, sIkControlArray = xBlendInfo
    pins.setStringArray(ssControls[0], sFkControlArray)
    pins.setStringArray(ssControls[1], sIkControlArray)



# def createVisAttr(sAttrName, eParent, eCtrls, bDefault=False):
#     eBoolCtrl = hierarchy.createBoolControl(sAttrName, eParent=eParent, bDefault=bDefault)
#     createVisAttrFunction(eBoolCtrl, eParent, eCtrls)



def createVisAttrFunction(sAttrName, sParentName, sElementNames, bDefault=False):
    hierarchy.createBoolControl(sAttrName, eParent=ELEM(sParentName, 'Control'), bDefault=bDefault)

    sFunctionName = 'kangaroo_visibilitySwitch'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('AttrName', 'FName', False),
                                                     ('ParentName', 'FName', False),
                                                     ('ElementNames', 'FName', True)])
        sMasterAttr = nodes.createGetChannelNodeInFunction('Entry.AttrName', 'Entry.ParentName')
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.ElementNames')
        # sPrevVis = nodes.createGetControlVisibility('%s.Element' % sForEach)
        # sBoolAnd = nodes.createBoolAndNode(sPrevVis, sMasterAttr)
        controllers.setNewColumn()
        nodes.createSetControlVisibility('%s.Element' % sForEach, sMasterAttr, bControlIsPin=True)
        controllers.goToParentExecute()
        nodes.endCurrentFunction(bAddToExecute=False)
        

    sVisNode = nodes.addFunctionNode(sFunctionName)
    pins.setStringArray(sElementNames, '%s.ElementNames' % sVisNode)
    pins.setString(sAttrName, '%s.AttrName' % sVisNode)
    pins.setString(sParentName, '%s.ParentName' % sVisNode)


def createFeatureSwitchFunction(eBlendAttr, eBlendControl, sControlsA, sControlsB):

    sFunctionName = 'kangaroo_featureSwitch'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('BlendAttrName', 'FName', False),
                                                 ('BlendControlName', 'FName', False),
                                                 ('ControlsA', 'FName', True),
                                                 ('ControlsB', 'FName', True)],
                                            xOutputs=[('SwitchFeatureA', 'bool', False),
                                                      ('SwitchFeatureB', 'bool', False)])

        sFeatureB = nodes.createGetChannelNodeInFunction('Entry.BlendAttrName', 'Entry.BlendControlName', bBool=True)
        sFeatureA = nodes.createBoolNotNode(sFeatureB)
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.ControlsA')
        nodes.createSetControlVisibility('%s.Element' % sForEach, sFeatureA, bControlIsPin=True)
        controllers.goToParentExecute()

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.ControlsB')
        nodes.createSetControlVisibility('%s.Element' % sForEach, sFeatureB, bControlIsPin=True)
        controllers.goToParentExecute()

        # pins.connectToPin1D(sFeatureA, 'Return.FeatureA')
        # pins.connectToPin1D(sFeatureB, 'Return.FeatureB')

        # sMinus = nodes.createBasicCalculateNode([1.0, sBlendAttr], sOperation='Subtract')
        # pins.connectToPin1D(sMinus, 'Return.FeatureValueA')
        # pins.connectToPin1D(sBlendAttr, 'Return.FeatureValueB')
        pins.connectToPin1D(sFeatureA, 'Return.SwitchFeatureA')
        pins.connectToPin1D(sFeatureB, 'Return.SwitchFeatureB')

        nodes.endCurrentFunction(bAddToExecute=False)


    sVisNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(eBlendAttr.name, '%s.BlendAttrName' % sVisNode)
    pins.setString(eBlendControl.name, '%s.BlendControlName' % sVisNode)
    pins.setStringArray(sControlsA, '%s.ControlsA' % sVisNode)
    pins.setStringArray(sControlsB, '%s.ControlsB' % sVisNode)
    return sVisNode



def curveDriver(sCurveName, xxDrivers, fInbetweens=[], sInbetweenCurveNames=[], iCombineMode=0):
    if len(xxDrivers) == 0:
        raise Exception('There is a curveDriver with 0 drivers (%s)' % sCurveName)


    xxDrivers = sorted(xxDrivers, key=lambda x:x[2])
    sFunctionName = 'kangaroo_curveDriver__%s' % '_'.join([xD[2] for xD in xxDrivers])
    if iCombineMode != 0:
        sFunctionName = f"{sFunctionName}_{'min' if iCombineMode==1 else 'mult'}"

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        xExtraInputs = []
        iBrows = -1
        bZipper = False
        for i,xD in enumerate(xxDrivers):
            if xD[2] == 'CTRLTRANSFORM':
                xExtraInputs.extend([('InputCtrl_%d' % i, 'FName', False),
                                     ('AttributeId_%d' % i, 'int32', False),
                                     ('RangeTimes_%d' % i, 'float', True),
                                     ('RangeValues_%d' % i, 'float', True)])
            elif xD[2] == 'CTRLCHANNEL':
                xExtraInputs.extend([('InputCtrl_%d' % i, 'FName', False),
                                     ('Channel_%d' % i, 'FName', False),
                                     ('RangeTimes_%d' % i, 'float', True),
                                     ('RangeValues_%d' % i, 'float', True)])
            elif xD[2] == 'VALUE':
                xExtraInputs.extend([('Value_%d' % i, 'float', False),
                                     ('RangeTimes_%d' % i, 'float', True),
                                     ('RangeValues_%d' % i, 'float', True)])
            elif xD[2] == 'BROWS':
                xExtraInputs.extend([('bIsDown_%d' % i, 'bool', False)])
                iBrows = i
            elif xD[2] == 'ZIPPER':
                bZipper = True

        nodes.startFunction(sFunctionName, xInputs=[('MainCurveName', 'FName', False),
                                                    ('Inbetweens', 'float', True),
                                                    ('InbetweenCurveNames', 'FName', True)] + xExtraInputs)

        sStrengthes = []
        for i, xD in enumerate(xxDrivers):
            xData, _, sType = xD
            if sType in ['BROWS', 'ZIPPER']:
                sStrengthes.append(1.0)
                pass
            else:
                controllers.setNewColumn()
                if sType == 'CTRLTRANSFORM':
                    controllers.openCommentBox('Get Value from Control')
                    sGetTransform = nodes.getTransformNode(ELEM('Entry.InputCtrl_%d' % i, 'Control'), bLocal=True)
                    sEuler = nodes.createToEulerNode('%s.Rotation' % sGetTransform)
                    controllers.setNewColumn()
                    sAnimValue = nodes.createSelectNode2(['%s.Translation.X' % sGetTransform, '%s.Translation.Y' % sGetTransform, '%s.Translation.Z' % sGetTransform,
                                                                '%s.X' % sEuler, '%s.Y' % sEuler, '%s.Z' % sEuler],
                                                               'Entry.AttributeId_%d' % i, iPinType=pins.PinType.double)
                    controllers.closeCommentBox('Get Value from Control')
                elif sType == 'CTRLCHANNEL':
                    sAnimValue = nodes.createGetChannelNode2('Entry.InputCtrl_%d' % i, 'Entry.Channel_%d' % i)
                elif sType == 'VALUE':
                    sAnimValue = 'Entry.Value_%d' % i

                controllers.setNewColumn()
                sStrengthes.append(getRanges(sAnimValue, 'Entry.RangeTimes_%d' % i, 'Entry.RangeValues_%d' % i))

            controllers.setNewColumn()
            controllers.openCommentBox('Combine the Factors')
            xPrev = sStrengthes[0]
            for i in range(1, len(sStrengthes), 1):
                if iCombineMode == 1:
                    xPrev = nodes.createConditionNodes(xPrev, '<', sStrengthes[i], xPrev, sStrengthes[i], iPinType=pins.PinType.double)
                else:
                    xPrev = nodes.createBasicCalculateNode([xPrev, sStrengthes[i]], iPinType=pins.PinType.double)
            controllers.closeCommentBox('Combine the Factors')
            sCurveValue = xPrev


        controllers.setNewColumn()
        if iBrows >= 0:
            sUp = nodes.createGetVariableNode(vBrowVariables[0])
            sDown = nodes.createGetVariableNode(vBrowVariables[1])
            sBrowStrings = nodes.createGetVariableNode(vBrowVariables[2])

            controllers.setNewColumn()
            controllers.openCommentBox('Set Curves for each Brow Value')
            sForEach = nodes.createForEachExecuteNode(sBrowStrings)

            if controllers.BLOCK_FOREACH:
                sUpAt = nodes.createArrayAtNode(sUp, '%s.Index' % sForEach)
                sDownAt = nodes.createArrayAtNode(sDown, '%s.Index' % sForEach)
                sChooseDirection = nodes.createIfNode('Entry.bIsDown_%d' % iBrows, sDownAt, sUpAt)
                sCurveValueBrow = nodes.createBasicCalculateNode([sCurveValue, sChooseDirection])
                sCurveNameBrow = nodes.createNameReplaceNode('Entry.MainCurveName', 'b00', '%s.Element' % sForEach)
                controllers.setNewColumn()


                controllers.openCommentBox('Generate Inbetween CurveNames')
                vInbetweenCurveNames = hierarchy.newVariable('InbetweenCurveNames_temp', 'FName', bArray=True, bLocal=True)
                sInbetweenCurveNamesVar = nodes.createGetVariableNode(vInbetweenCurveNames)
                nodes.createResetArrayNode(sInbetweenCurveNamesVar)
                controllers.setNewColumn()
                sInbetweenForEach = nodes.createForEachExecuteNode('Entry.InbetweenCurveNames')
                if controllers.BLOCK_FOREACH:  # for each inbetween name
                    controllers.setNewColumn()
                    nodes.createArrayAddNode(sInbetweenCurveNamesVar,
                                             nodes.createNameReplaceNode('%s.Element' % sInbetweenForEach, 'b00',
                                                                         '%s.Element' % sForEach))
                    controllers.goToParentExecute()
                controllers.closeCommentBox('Generate Inbetween CurveNames')

                SetCurveWithInbetweens(sCurveNameBrow, sCurveValueBrow, sInbetweenCurveNamesVar, 'Entry.Inbetweens')
                controllers.goToParentExecute()
            controllers.closeCommentBox('Set Curves for each Brow Value')

        elif bZipper:
            sZipperOuts = nodes.createGetVariableNode(vZipperOut)
            sZipperStrings = nodes.createGetVariableNode(vZipperStrings)

            controllers.setNewColumn()
            controllers.openCommentBox('Set Curves for each Zipper Segment')
            sForEach = nodes.createForEachExecuteNode(sZipperStrings)

            if controllers.BLOCK_FOREACH:
                controllers.setNewColumn()
                sZipperOut = nodes.createArrayAtNode(sZipperOuts, '%s.Index' % sForEach)
                sCurveNameZipper = nodes.createNameReplaceNode('Entry.MainCurveName', 'z00', '%s.Element' % sForEach)
                sCurveValueZipper = nodes.createBasicCalculateNode([sCurveValue, sZipperOut])

                controllers.setNewColumn()
                SetCurveWithInbetweens(sCurveNameZipper, sCurveValueZipper, [], [])
                controllers.goToParentExecute()
            controllers.closeCommentBox('Set Curves for each Zipper Segment')

        else:
            SetCurveWithInbetweens('Entry.MainCurveName', sCurveValue, 'Entry.InbetweenCurveNames', 'Entry.Inbetweens')
        nodes.endCurrentFunction(bAddToExecute=False)


    sSetCurveFunctionNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sCurveName, '%s.MainCurveName' % sSetCurveFunctionNode)
    for i,xD in enumerate(xxDrivers):
        xData, ffRange, sType = xD
        if sType == 'BROWS':
            pins.connectToPin1D(True if xD[0] == 'movedDown' else False, '%s.bIsDown_%d' % (sSetCurveFunctionNode, i))
        elif sType == 'ZIPPER':
            pass
        else:
            if sType == 'CTRLTRANSFORM':
                sCtrlName, sAxis = xData.split('.')
                pins.setString(sCtrlName, '%s.InputCtrl_%d' % (sSetCurveFunctionNode, i))
                pins.connectToPin1D(int(sAxis), '%s.AttributeId_%d' % (sSetCurveFunctionNode, i))
            elif sType == 'CTRLCHANNEL':
                sCtrlName, sChannel = xData.split('.')
                pins.setString(sCtrlName, '%s.InputCtrl_%d' % (sSetCurveFunctionNode, i))
                pins.setString(sCtrlName, '%s.Channel_%d' % (sSetCurveFunctionNode, i))
            elif sType == 'VALUE':
                pins.connectToPin1D(xData, '%s.Value_%d' % (sSetCurveFunctionNode, i))
            pins.setValueArray(ffRange[:len(ffRange)//2], '%s.RangeTimes_%d' % (sSetCurveFunctionNode, i))
            pins.setValueArray(ffRange[len(ffRange)//2:], '%s.RangeValues_%d' % (sSetCurveFunctionNode, i))

    pins.setValueArray(fInbetweens, '%s.Inbetweens' % sSetCurveFunctionNode)
    pins.setStringArray(sInbetweenCurveNames, '%s.InbetweenCurveNames' % sSetCurveFunctionNode)



def getRanges(sInput, fTimes, fValues):

    sFunctionName = 'kangaroo_getRanges'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Input', 'float', False),
                                                    ('Times', 'float', True),
                                                    ('Values', 'float', True)],
                                            xOutputs=[('Value', 'float', False)])
        vOut = hierarchy.newVariable('out', 'float', bLocal=True)
        sTime0 = nodes.createArrayAtNode('Entry.Times', 0)
        sValue0 = nodes.createArrayAtNode('Entry.Values', 0)
        sTime1 = nodes.createArrayAtNode('Entry.Times', 1)
        sValue1 = nodes.createArrayAtNode('Entry.Values', 1)
        sRangeNode0 = nodes.createRemapNode('Entry.Input', sTime0, sTime1, sValue0, sValue1)

        sCount = nodes.createArrayGetCountNode('Entry.Times')
        sTwoKeys = nodes.createConditionNodes(sCount, '<=', 2, iTermsPinType=pins.PinType.integer)
        nodes.createBranchExecuteNode(sTwoKeys)
        nodes.createSetVariableExecuteNode(vOut, sRangeNode0)
        controllers.goToParentExecute()
        controllers.setNewColumn()
        sTime2 = nodes.createArrayAtNode('Entry.Times', 2)
        sValue2 = nodes.createArrayAtNode('Entry.Values', 2)
        sRangeNode1 = nodes.createRemapNode('Entry.Input', sTime1, sTime2, sValue1, sValue2)
        nodes.createSetVariableExecuteNode(vOut, nodes.createConditionNodes('Entry.Input', '<', sTime1, sRangeNode0, sRangeNode1, iPinType=pins.PinType.double))
        controllers.goToParentExecute()
        controllers.setNewColumn()
        sOut = nodes.createGetVariableNode(vOut)
        pins.connectToPin1D(sOut, 'Return.Value')
        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)


    sGetRangesFunctionNode = nodes.addFunctionNode(sFunctionName)
    pins.setValueArray(fTimes, '%s.Times' % sGetRangesFunctionNode)
    pins.setValueArray(fValues, '%s.Values' % sGetRangesFunctionNode)
    pins.connectToPin1D(sInput, '%s.Input' % sGetRangesFunctionNode)

    return '%s.Value' % sGetRangesFunctionNode


def SetCurveWithInbetweens(sMainCurveName, sInput, sInbetweenCurveNames=[], fInbetweens=[]):

    sFunctionName = 'kangaroo_setCurveWithInbetweens'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('MainCurveName', 'FName', False),
                                                    ('Input', 'float', False),
                                                    ('Inbetweens', 'float', True),
                                                    ('InbetweenCurveNames', 'FName', True)],
                                            xOutputs=[('Value', 'float', False)])

        sInbetweenCount = nodes.createArrayGetCountNode('Entry.Inbetweens')
        sNoInbetweens = nodes.createConditionNodes(sInbetweenCount, '==', 0, iTermsPinType=pins.PinType.integer)


        nodes.createBranchExecuteNode(sNoInbetweens)
        if controllers.BLOCK_BRANCH_TRUE:
            controllers.openCommentBox('Setting Main Shape (it has no inbetweens)')
            controllers.setNewColumn()
            nodes.setCurveValueExecuteNode('Entry.MainCurveName', 'Entry.Input')
            controllers.goToParentExecute()
        controllers.closeCommentBox('Setting Main Shape (it has no inbetweens)')
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.setNewColumn()
            controllers.openCommentBox('Setting Main Shape (It has Inbetweens!)')
            sLastInbetweenIndex = nodes.createBasicCalculateNode([sInbetweenCount, -1], sOperation='Add', iPinType=pins.PinType.integer)
            sLastInbetween = nodes.createArrayAtNode('Entry.Inbetweens', sLastInbetweenIndex)
            sMappedMainTarget = nodes.createRemapNode('Entry.Input', sLastInbetween, 1.0, 0.0, 1.0)
            nodes.setCurveValueExecuteNode('Entry.MainCurveName', sMappedMainTarget)
            controllers.setNewColumn()
            controllers.goToParentExecute()
            controllers.closeCommentBox('Setting Main Shape (It has Inbetweens!)')

        vStartValue = hierarchy.newVariable('StartValue', bLocal=True)
        nodes.createSetVariableExecuteNode(vStartValue, 0.0)
        controllers.setNewColumn()

        controllers.openCommentBox('Inbetweens')
        sForEach = nodes.createForEachExecuteNode('Entry.Inbetweens')
        if controllers.BLOCK_FOREACH:
            sBeforePeak = nodes.createConditionNodes('Entry.Input', '<=', '%s.Element' % sForEach)
            sInbetweenCurveName = nodes.createArrayAtNode('Entry.InbetweenCurveNames', '%s.Index' % sForEach)
            controllers.setNewColumn()

            nodes.createBranchExecuteNode(sBeforePeak)
            if controllers.BLOCK_BRANCH_TRUE: # before peak
                controllers.openCommentBox('Before Peak')
                controllers.setNewColumn()
                sIsNotFirst = nodes.createConditionNodes('%s.Index' % sForEach, '>', 0, iTermsPinType=pins.PinType.integer)

                nodes.createBranchExecuteNode(sIsNotFirst)
                if controllers.BLOCK_BRANCH_TRUE:
                    sIndexBefore = nodes.createBasicCalculateNode(['%s.Index' % sForEach, -1], sOperation='Add', iPinType=pins.PinType.integer)
                    sStartValue = nodes.createArrayAtNode('Entry.Inbetweens', sIndexBefore)
                    nodes.createSetVariableExecuteNode(vStartValue, sStartValue)
                    controllers.goToParentExecute()
                if controllers.BLOCK_BRANCH_FALSE:
                    controllers.goToParentExecute()

                controllers.setNewColumn()
                sStartValue = nodes.createGetVariableNode(vStartValue)
                sInbetweenMapped = nodes.createRemapNode('Entry.Input', sStartValue, '%s.Element' % sForEach, 0.0, 1.0)
                controllers.setNewColumn()
                nodes.setCurveValueExecuteNode(sInbetweenCurveName, sInbetweenMapped)
                controllers.goToParentExecute()
                controllers.closeCommentBox('Before Peak')

            if controllers.BLOCK_BRANCH_FALSE: # after peak
                controllers.setNewColumn()
                controllers.openCommentBox('After Peak')
                vEndValue = hierarchy.newVariable('EndValue', bLocal=True)

                sLastIndex = nodes.createBasicCalculateNode(['%s.Count' % sForEach, -1], sOperation='Add', iPinType=pins.PinType.integer)
                sIsNotLast = nodes.createConditionNodes('%s.Index' % sForEach, '<', sLastIndex, iTermsPinType=pins.PinType.integer)
                nodes.createBranchExecuteNode(sIsNotLast)
                if controllers.BLOCK_BRANCH_TRUE:
                    sIndexAfter = nodes.createBasicCalculateNode(['%s.Index' % sForEach, +1], sOperation='Add', iPinType=pins.PinType.integer)
                    sEndValue = nodes.createArrayAtNode('Entry.Inbetweens', sIndexAfter)
                    nodes.createSetVariableExecuteNode(vEndValue, sEndValue)
                    controllers.goToParentExecute()
                if controllers.BLOCK_BRANCH_FALSE:
                    nodes.createSetVariableExecuteNode(vEndValue, 1.0)
                    controllers.goToParentExecute()

                sEndValue = nodes.createGetVariableNode(vEndValue)
                sInbetweenMapped = nodes.createRemapNode('Entry.Input', '%s.Element' % sForEach, sEndValue, 1.0, 0.0)
                controllers.setNewColumn()
                nodes.setCurveValueExecuteNode(sInbetweenCurveName, sInbetweenMapped)
                controllers.goToParentExecute()
                controllers.closeCommentBox('After Peak')

            controllers.goToParentExecute()
        controllers.closeCommentBox('Inbetweens')



        nodes.endCurrentFunction(bAddToExecute=False)


    sSetInbetweenCurves = nodes.addFunctionNode(sFunctionName)
    pins.setValueArray(fInbetweens, '%s.Inbetweens' % sSetInbetweenCurves)
    pins.setStringArray(sInbetweenCurveNames, '%s.InbetweenCurveNames' % sSetInbetweenCurves)
    pins.connectToPin1D(sInput, '%s.Input' % sSetInbetweenCurves)
    pins.setString(sMainCurveName, '%s.MainCurveName' % sSetInbetweenCurves, bConnectIfPlug=True)
    return '%s.Value' % sSetInbetweenCurves



def createFkSplineFunction(eRoot, cCtrls, sJoints, sSide, xCtrlWeightings, eEndNull, fUpVector):

    eAttributesControl = cCtrls[-1].eControl
    hierarchy.createFloatControl('Stretched', eParent=eAttributesControl, bIsBool=True, fDefault=False)

    iLength = len(cCtrls)
    sFunctionName = 'kangaroo_fkSpline_%dTransforms' % iLength

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        xProceduralInputs = []
        for i in range(iLength):
            # xProceduralInputs.append(('Control_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Passer_%d' % i, 'FRigElementKey', False))
            if i > 0:
                xProceduralInputs.append(('ATTACHER_fkSpline_%s_t' % library.getLetter(i-1), 'FConstraintParent', True))
                xProceduralInputs.append(('ATTACHER_fkSpline_%s_r' % library.getLetter(i-1), 'FConstraintParent', True))

        nodes.startFunction(sFunctionName, xInputs= [('Root', 'FRigElementKey', False),
                                                      ('Transforms', 'FRigElementKey', True),
                                                      ('Bones', 'FRigElementKey', True),
                                                      ('CtrlWeights', 'float', True),
                                                      ('FirstCtrls', 'int32', True),
                                                      ('SecondCtrls', 'int32', True),
                                                      ('Negative', 'bool', False),
                                                      ('UpVector', 'FVector', False),
                                                      ('AttributesControl', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ] + xProceduralInputs)

        controllers.setNewColumn()

        for i in range(iLength):
            controllers.setNewColumn()
            if i == 0:
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Root', bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Root', bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
            else:
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_fkSpline_%s_t' % library.getLetter(i-1), 'Entry.Passer_%d' % i, bMaintainOffset=True, skipRotate=['x','y','z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_fkSpline_%s_r' % library.getLetter(i-1), 'Entry.Passer_%d' % i, bMaintainOffset=True, skipTranslate=['x','y','z'])

        controllers.openCommentBox('Bones')
        controllers.setNewColumn()
        sEntry_Negative = nodes.createGetEntryVariable('Negative')
        sEntry_FirstCtrls = nodes.createGetEntryVariable('FirstCtrls')
        sEntry_SecondCtrls = nodes.createGetEntryVariable('SecondCtrls')
        sEntry_CtrlWeights = nodes.createGetEntryVariable('CtrlWeights')
        sEntry_UpVector = nodes.createGetEntryVariable('UpVector')
        sEntry_Transforms = nodes.createGetEntryVariable('Transforms')
        sEntry_Bones = nodes.createGetEntryVariable('Bones')
        sEntry_AttributesControl = nodes.createGetEntryVariable('AttributesControl')
        sStretched = nodes.createGetChannelNode2(sEntry_AttributesControl, 'Stretched')
        controllers.setNewColumn()
        spineSplineFunction(sEntry_Transforms, sEntry_Bones, sEntry_Negative, sEntry_FirstCtrls, sEntry_SecondCtrls, sEntry_CtrlWeights, sEntry_UpVector, bStretched=sStretched)
        controllers.closeCommentBox('Bones')

        # spineSplineFunction('Entry.Transforms', 'Entry.Bones', 'Entry.Negative', 'Entry.FirstCtrls', 'Entry.SecondCtrls', 'Entry.CtrlWeights', 'Entry.UpVector')

        nodes.endCurrentFunction(bAddToExecute=False)

    sFkSplineNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eRoot, '%s.Root' % sFkSplineNode)
    pins.setItemArray([cC.eOut for cC in cCtrls] + [eEndNull], '%s.Transforms' % sFkSplineNode)
    pins.setItemArray([ELEM(sJ, 'Bone') for sJ in sJoints], '%s.Bones' % sFkSplineNode)


    for c,cCtrl in enumerate(cCtrls):
        pins.connectItem(cCtrl.ePasser, '%s.Passer_%d' % (sFkSplineNode, c))
        # pins.connectItem(cCtrl.eControl, '%s.Control_%d' % (sFkSplineNode, c))

    pins.setValueArray([xC[0] for xC in xCtrlWeightings], '%s.FirstCtrls' % sFkSplineNode, bInt=True)
    pins.setValueArray([xC[1] for xC in xCtrlWeightings], '%s.SecondCtrls' % sFkSplineNode, bInt=True)
    pins.setValueArray([xC[2] for xC in xCtrlWeightings], '%s.CtrlWeights' % sFkSplineNode)
    pins.connectToPin1D(sSide == 'r', '%s.Negative' % sFkSplineNode)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sFkSplineNode)
    pins.setString(eAttributesControl.name, '%s.AttributesControl' % sFkSplineNode)

    return sFkSplineNode



def createIkSplineFunction(eRoot, cCtrls, eMiddle, fMiddleDistance, sJoints, sSide, xCtrlWeightings, eEndNull, fUpVector):

    eAttributesControl = cCtrls[-1].eControl
    hierarchy.createFloatControl('Stretched', eParent=eAttributesControl, bIsBool=True, fDefault=False)


    if len(cCtrls) == 3:
        cCtrls.append(cCtrls[-1])


    bThreePointChain = library.isNone(xCtrlWeightings)
    iLength = len(cCtrls)
    sFunctionName = 'kangaroo_ikSpline_%dTransforms' % iLength
    if bThreePointChain:
        sFunctionName = '%s_ThreePointChain' % sFunctionName

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xProceduralInputs = []
        for i in range(iLength):
            xProceduralInputs.append(('Passer_%d' % i, 'FRigElementKey', False))
            if i > 0:
                xProceduralInputs.append(('ATTACHER_ikSplineMiddle_%s_t' % library.getLetter(i-1), 'FConstraintParent', True))
                xProceduralInputs.append(('ATTACHER_ikSplineMiddle_%s_r' % library.getLetter(i-1), 'FConstraintParent', True))

        if not bThreePointChain:
            xProceduralInputs.extend([('CtrlWeights', 'float', True),
                                      ('FirstCtrls', 'int32', True),
                                      ('SecondCtrls', 'int32', True)])

        nodes.startFunction(sFunctionName, xInputs= [('Root', 'FRigElementKey', False),
                                                                          ('Top', 'FRigElementKey', False),
                                                                         ('Transforms', 'FRigElementKey', True),
                                                                          ('Bones', 'FRigElementKey', True),
                                                                          ('MiddleLineDefault', 'FRigElementKey', False),
                                                                          ('MiddleDistanceDefault', 'float', False),
                                                                          ('Negative', 'bool', False),
                                                                          ('UpVector', 'FVector', False),
                                                                          ('AttributesControl', 'FName', False),
                                                                         ('ATTACHER_root_t', 'FConstraintParent', True),
                                                                         ('ATTACHER_root_r', 'FConstraintParent', True),
                                                                         ('ATTACHER_top_t', 'FConstraintParent', True),
                                                                         ('ATTACHER_top_r', 'FConstraintParent', True),
                                                                         ] + xProceduralInputs)

        controllers.openCommentBox('Main Attachers')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Root', bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Root', bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_top_t', 'Entry.Passer_%d' % (iLength-1), bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_top_r', 'Entry.Passer_%d' % (iLength-1), bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Main Attachers')


        controllers.openCommentBox('Attachers - Middle Aim Magic')
        controllers.setNewColumn()
        sFirstItem = nodes.createArrayAtNode('Entry.Transforms', 0)
        sFirstTransform = nodes.getTransformNode(sFirstItem)
        sLastItem = nodes.createArrayAtNode('Entry.Transforms', iLength-1)
        sLastTransform = nodes.getTransformNode(sLastItem)
        controllers.setNewColumn()
        sUpVectorTarget = nodes.createMakeAbsoluteNode(['Entry.UpVector', None, [1,1,1]], sFirstTransform)
        sAimResult = nodes.createAimNode(sFirstTransform, '%s.Translation' % sLastTransform, fUpVector=[0,1,0])
        pins.connectToPinVector('%s.Translation' % sUpVectorTarget, '%s.Secondary.Target' % sAimResult.split('.')[0])
        sDistance = nodes.createGetDistanceNode('%s.Translation' % nodes.getTransformNode(sFirstItem), '%s.Translation' % sLastTransform)
        sDistanceFactor = nodes.createBasicCalculateNode([sDistance, 'Entry.MiddleDistanceDefault'], sOperation='Divide')
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode('Entry.MiddleLineDefault', ['%s.Translation' % sAimResult, '%s.Rotation' % sAimResult, [sDistanceFactor, 1, 1]])
        controllers.closeCommentBox('Attachers - Middle Aim Magic')


        controllers.openCommentBox('Attachers - Middle Ctrls')
        controllers.setNewColumn()
        for i in range(iLength-2):
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ikSplineMiddle_%s_t' % library.getLetter(i), 'Entry.Passer_%d' % (i+1), bMaintainOffset=True, skipRotate=['x','y','z'])
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ikSplineMiddle_%s_r' % library.getLetter(i), 'Entry.Passer_%d' % (i+1), bMaintainOffset=True, skipTranslate=['x','y','z'])
        controllers.closeCommentBox('Attachers - Middle Ctrls')

        controllers.setNewColumn()

        controllers.openCommentBox('Bones')
        if bThreePointChain:
            controllers.openCommentBox('Three Bone Chain Constraints')
            controllers.setNewColumn()
            sMiddleItem = nodes.createArrayAtNode('Entry.Transforms', 1)
            sBoneA = nodes.createArrayAtNode('Entry.Bones', 0)
            sBoneB = nodes.createArrayAtNode('Entry.Bones', 1)
            controllers.setNewColumn()
            nodes.createPositionConstraintExecuteNode([(sFirstItem, 1)], sBoneA)
            createKangarooAimConstraintFunction(sBoneA, sMiddleItem, sMiddleItem, fWorldUpVector=[0,1,0])
            nodes.createPositionConstraintExecuteNode([(sMiddleItem, 1)], sBoneB)
            createKangarooAimConstraintFunction(sBoneB, sLastItem, sLastItem, fWorldUpVector=[0,1,0])
            controllers.closeCommentBox('Three Bone Chain Constraints')
        else:
            sEntry_Negative = nodes.createGetEntryVariable('Negative')
            sEntry_FirstCtrls = nodes.createGetEntryVariable('FirstCtrls')
            sEntry_SecondCtrls = nodes.createGetEntryVariable('SecondCtrls')
            sEntry_CtrlWeights= nodes.createGetEntryVariable('CtrlWeights')
            sEntry_UpVector= nodes.createGetEntryVariable('UpVector')
            sEntry_Transforms = nodes.createGetEntryVariable('Transforms')
            sEntry_Bones = nodes.createGetEntryVariable('Bones')
            sEntry_AttributesControl = nodes.createGetEntryVariable('AttributesControl')
            sStretched = nodes.createGetChannelNode2(sEntry_AttributesControl, 'Stretched')
            spineSplineFunction(sEntry_Transforms, sEntry_Bones, sEntry_Negative, sEntry_FirstCtrls, sEntry_SecondCtrls, sEntry_CtrlWeights, sEntry_UpVector, bStretched=sStretched)
        controllers.closeCommentBox('Bones')

        nodes.endCurrentFunction(bAddToExecute=False)

    sIkSplineNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300, 2000])
    pins.connectItem(eRoot, '%s.Root' % sIkSplineNode)
    pins.connectItem(eMiddle, '%s.MiddleLineDefault' % sIkSplineNode)
    pins.connectToPin1D(fMiddleDistance, '%s.MiddleDistanceDefault' % sIkSplineNode)

    eTransforms = [cC.eOut for cC in cCtrls]
    if eEndNull:
        eTransforms.append(eEndNull)
    pins.setItemArray(eTransforms, '%s.Transforms' % sIkSplineNode)
    pins.setItemArray([ELEM(sJ, 'Bone') for sJ in sJoints], '%s.Bones' % sIkSplineNode)


    for c,cCtrl in enumerate(cCtrls):
        pins.connectItem(cCtrl.ePasser, '%s.Passer_%d' % (sIkSplineNode, c))

    if not bThreePointChain:
        pins.setValueArray([xC[0] for xC in xCtrlWeightings], '%s.FirstCtrls' % sIkSplineNode, bInt=True)
        pins.setValueArray([xC[1] for xC in xCtrlWeightings], '%s.SecondCtrls' % sIkSplineNode, bInt=True)
        pins.setValueArray([xC[2] for xC in xCtrlWeightings], '%s.CtrlWeights' % sIkSplineNode)
    pins.connectToPin1D(sSide == 'r', '%s.Negative' % sIkSplineNode)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sIkSplineNode)
    pins.setString(eAttributesControl.name, '%s.AttributesControl' % sIkSplineNode)

    return sIkSplineNode



def createIkSplineFunction_BACKWARDS(eRoot, cCtrls, sCtrlBones, eMiddle, fMiddleDistance, sSide, fUpVector):
    iLength = len(cCtrls)
    if iLength != len(sCtrlBones):
        raise Exception('cCtrls and sCtrlBones needs to have same count')

    sFunctionName = 'kangaroo_ikSpline_%dTransforms' % iLength
    sFunctionName = '%s_BACKWARDS' % sFunctionName
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xProceduralInputs = []
        for i in range(iLength):
            # xProceduralInputs.append(('Control_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Passer_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Control_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Bone_%d' % i, 'FRigElementKey', False))

            if i > 0:
                xProceduralInputs.append(('ATTACHER_ikSplineMiddle_%s_t' % library.getLetter(i - 1), 'FConstraintParent', True))
                xProceduralInputs.append(('ATTACHER_ikSplineMiddle_%s_r' % library.getLetter(i - 1), 'FConstraintParent', True))

        nodes.startFunction(sFunctionName, xInputs=[('Root', 'FRigElementKey', False),
                                                    # ('Top', 'FRigElementKey', False),
                                                    ('MiddleLineDefault', 'FRigElementKey', False),
                                                    ('MiddleDistanceDefault', 'float', False),
                                                    ('Negative', 'bool', False),
                                                    ('UpVector', 'FVector', False),
                                                    ('ATTACHER_root_t', 'FConstraintParent', True),
                                                    ('ATTACHER_root_r', 'FConstraintParent', True),
                                                    ('ATTACHER_top_t', 'FConstraintParent', True),
                                                    ('ATTACHER_top_r', 'FConstraintParent', True),
                                                    ] + xProceduralInputs)

        controllers.openCommentBox('Attachers')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Root', bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Root', bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_top_t', 'Entry.Passer_%d' % (iLength - 1), bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_top_r', 'Entry.Passer_%d' % (iLength - 1), bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers')

        controllers.openCommentBox('First and Last Controls')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([('Entry.Bone_0', 1.0)], 'Entry.Control_0', bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([('Entry.Bone_%d' % (iLength-1), 1.0)], 'Entry.Control_%d' % (iLength-1), bMaintainOffset=True)
        controllers.closeCommentBox('First and Last Controls')

        # middle aim magic
        controllers.openCommentBox('Middle Aim')
        controllers.setNewColumn()
        sFirstTransform = nodes.getTransformNode('Entry.Control_0')
        sLastTransform = nodes.getTransformNode('Entry.Control_%d' % (iLength-1))

        controllers.setNewColumn()
        sUpVectorTarget = nodes.createMakeAbsoluteNode(['Entry.UpVector', None, [1, 1, 1]], sFirstTransform)
        sAimResult = nodes.createAimNode(sFirstTransform, '%s.Translation' % sLastTransform, fUpVector=[0, 1, 0])
        pins.connectToPinVector('%s.Translation' % sUpVectorTarget, '%s.Secondary.Target' % sAimResult.split('.')[0])
        sDistance = nodes.createGetDistanceNode('%s.Translation' % sFirstTransform, '%s.Translation' % sLastTransform)
        sDistanceFactor = nodes.createBasicCalculateNode([sDistance, 'Entry.MiddleDistanceDefault'], sOperation='Divide')
        nodes.createSetTransformExecuteNode('Entry.MiddleLineDefault', ['%s.Translation' % sAimResult, '%s.Rotation' % sAimResult, [sDistanceFactor, 1, 1]])
        controllers.closeCommentBox('Middle Aim')


        controllers.openCommentBox('Constraint to Middle Aim')
        controllers.setNewColumn()
        for i in range(iLength - 2):
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ikSplineMiddle_%s_t' % library.getLetter(i), 'Entry.Passer_%d' % (i + 1), bMaintainOffset=True,skipRotate=['x', 'y', 'z'])
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ikSplineMiddle_%s_r' % library.getLetter(i), 'Entry.Passer_%d' % (i + 1), bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Constraint to Middle Aim')

        controllers.openCommentBox('Constraint all Middle Controls')
        controllers.setNewColumn()
        for i in range(1,iLength-1,1):
            nodes.createParentConstraintExecuteNode([('Entry.Bone_%d' % i, 1.0)], 'Entry.Control_%d' % i, bMaintainOffset=True)
        controllers.closeCommentBox('Constraint all Middle Controls')

        nodes.endCurrentFunction(bAddToExecute=False)

    sIkSplineNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300, 2000])
    pins.connectItem(eRoot, '%s.Root' % sIkSplineNode)
    pins.connectItem(eMiddle, '%s.MiddleLineDefault' % sIkSplineNode)
    pins.connectToPin1D(fMiddleDistance, '%s.MiddleDistanceDefault' % sIkSplineNode)

    for i in range(iLength):
        pins.connectItem(cCtrls[i].eControl, '%s.Control_%d' % (sIkSplineNode,i))
        pins.connectItem(cCtrls[i].ePasser, '%s.Passer_%d' % (sIkSplineNode,i))
        pins.connectItem(ELEM(sCtrlBones[i], 'Bone'), '%s.Bone_%d' % (sIkSplineNode,i))


    pins.connectToPin1D(sSide == 'r', '%s.Negative' % sIkSplineNode)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sIkSplineNode)

    return sIkSplineNode


def spineSplineFunction(sTransformsArray, sBonesArray, bNegative, sFirstCtrls, sSecondCtrls, sCtrlWeights, fUpVector=[0,10,0], bStretched=False):

    sFunctionName = 'kangaroo_spineSpline'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs= [('Transforms', 'FRigElementKey', True),
                                                      ('Bones', 'FRigElementKey', True),
                                                      ('CtrlWeights', 'float', True),
                                                      ('FirstCtrls', 'int32', True),
                                                      ('SecondCtrls', 'int32', True),
                                                      ('bNegative', 'bool', False),
                                                      ('UpVector', 'FVector', False),
                                                      ('bStretched', 'bool', False)
                                                      ], bSequencer=True)

        controllers.openCommentBox('Check If it is the first time')
        sHasMetaData = nodes.createHasMetaData(nodes.createArrayAtNode('Entry.Bones', 0), 'OffsetTransform', iType=pins.PinType.transform)
        sDoesntHaveMetaData = nodes.createBoolNotNode(sHasMetaData)
        nodes.createBranchExecuteNode(sDoesntHaveMetaData)
        controllers.closeCommentBox('Check If it is the first time')

        vCurrentBone = hierarchy.newVariable('CurrentBone', 'FRigElementKey')
        for bInitial in [True, False]:
            controllers.openCommentBox('Create Splines')
            controllers.setNewColumn()

            sCurrentPoints = pointsFromItems('Entry.Transforms', bInitial=bInitial)
            sSpline = nodes.createSplineFromPositionsNode(sCurrentPoints)
            controllers.closeCommentBox('Create Splines')


            controllers.openCommentBox('Put Joints on Splines and store Positions')
            controllers.setNewColumn()
            sEntry_Bones = nodes.createGetEntryVariable('Bones')
            controllers.setNewColumn()
            sEntry_bStretched = nodes.createGetEntryVariable('bStretched')
            controllers.setNewColumn()
            nodes.createBranchExecuteNode(sEntry_bStretched)
            controllers.setNewColumn()
            if controllers.BLOCK_BRANCH_TRUE:
                nodes.createFitChainToSplineCurve(sSpline, sEntry_Bones, bStretched=True)
                controllers.goToParentExecute()
            if controllers.BLOCK_BRANCH_FALSE:
                nodes.createFitChainToSplineCurve(sSpline, sEntry_Bones, bStretched=False)
                controllers.goToParentExecute()
            controllers.setNewColumn()

            controllers.setNewColumn()
            sForEach = nodes.createForEachExecuteNode('Entry.Bones')
            controllers.setNewColumn()
            sSplinedMetaDataKey =  'Splined%s' % ('Initial' if bInitial else '')
            if controllers.BLOCK_FOREACH:
                sPosition = '%s.Translation' % nodes.getTransformNode('%s.Element' % sForEach)
                nodes.createSetMetaDataExecuteNode('%s.Element' % sForEach, sSplinedMetaDataKey, sPosition, iType=pins.PinType.vector)
                controllers.goToParentExecute()
            controllers.closeCommentBox('Put Joints on Splines and store Positions')


            controllers.setNewColumn()
            sForEach = nodes.createForEachExecuteNode('Entry.Bones')
            nodes.createSetVariableExecuteNode(vCurrentBone, '%s.Element' % sForEach)

            controllers.setNewColumn()
            if controllers.BLOCK_FOREACH:
                controllers.openCommentBox('Check if Joint still has a Child')
                controllers.setNewColumn()
                sMinusOne = nodes.createBasicCalculateNode(['%s.Count' % sForEach, 1], sOperation='Subtract', iPinType=pins.PinType.integer)
                sDoJoint = nodes.createConditionNodes('%s.Index' % sForEach, '<', sMinusOne, True, False, iTermsPinType=pins.PinType.integer)
                controllers.closeCommentBox('Check if Joint still has a Child')

                controllers.setNewColumn()
                nodes.createBranchExecuteNode(sDoJoint)
                if controllers.BLOCK_BRANCH_TRUE: # NOT last bone
                    controllers.setNewColumn()
                    controllers.openCommentBox('Get Control Weightings')

                    controllers.setNewColumn()
                    if bInitial:
                        sEntryFirstCtrls = nodes.createGetEntryVariable('FirstCtrls')
                        sStartCtrlIndex = nodes.createArrayAtNode(sEntryFirstCtrls, '%s.Index' % sForEach)
                        sEntry_Transforms = nodes.createGetEntryVariable('Transforms')
                        sStartItem = nodes.createArrayAtNode(sEntry_Transforms, sStartCtrlIndex)
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                        nodes.createSetMetaDataExecuteNode(sCurrentBone, 'StartItem', sStartItem, iType=pins.PinType.item)
                    else:
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                        sStartItem = nodes.createGetMetaData(sCurrentBone, 'StartItem', iType=pins.PinType.item)
                    sStartCtrlTransform = nodes.getTransformNode(sStartItem, bInitial=bInitial)

                    controllers.setNewColumn()
                    if bInitial:
                        sEntrySecondCtrls = nodes.createGetEntryVariable('SecondCtrls')
                        sEndCtrlIndex = nodes.createArrayAtNode(sEntrySecondCtrls, '%s.Index' % sForEach)
                        sEntry_Transforms = nodes.createGetEntryVariable('Transforms')
                        sEndItem = nodes.createArrayAtNode(sEntry_Transforms, sEndCtrlIndex)
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                        nodes.createSetMetaDataExecuteNode(sCurrentBone, 'EndItem', sEndItem, iType=pins.PinType.item)
                    else:
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)

                        sEndItem = nodes.createGetMetaData(sCurrentBone, 'EndItem', iType=pins.PinType.item)
                    sEndCtrlTransform = nodes.getTransformNode(sEndItem, bInitial=bInitial)

                    controllers.setNewColumn()
                    sEntryCtrlWeights = nodes.createGetEntryVariable('CtrlWeights')
                    sBlend = nodes.createArrayAtNode(sEntryCtrlWeights, '%s.Index' % sForEach)

                    controllers.closeCommentBox('Get Control Weightings')

                    controllers.setNewColumn()
                    controllers.openCommentBox('Aim Targets')
                    sNextIndex = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add', iPinType=pins.PinType.integer)
                    sEntry_Bones = nodes.createGetEntryVariable('Bones')
                    sNextBone = nodes.createArrayAtNode(sEntry_Bones, sNextIndex)

                    sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                    sSourcePosition = nodes.createGetMetaData(sCurrentBone, sSplinedMetaDataKey, iType=pins.PinType.vector)
                    sAimPosition = nodes.createGetMetaData(sNextBone, sSplinedMetaDataKey, iType=pins.PinType.vector)
                    controllers.closeCommentBox('Aim Targets')

                    controllers.setNewColumn()
                    controllers.openCommentBox('Aim Secondary Targets')

                    sEntryUpVector = nodes.createGetEntryVariable('UpVector')
                    controllers.setNewColumn()

                    sStartUp = nodes.createRotateVectorNode(sEntryUpVector, '%s.Rotation' % sStartCtrlTransform)
                    sEndUp = nodes.createRotateVectorNode(sEntryUpVector, '%s.Rotation' % sEndCtrlTransform)
                    sInterpUp = nodes.createVectorInterpolateNode(sBlend, sStartUp, sEndUp)
                    controllers.closeCommentBox('Aim Secondary Targets')

                    controllers.setNewColumn()
                    controllers.openCommentBox('Aim Nodes')
                    sEntry_bNegative = nodes.createGetEntryVariable('bNegative')
                    sNegSideMultipl = nodes.createIfNode(sEntry_bNegative, 1.0, -1.0)
                    sAimTransform = nodes.createAimNode([sSourcePosition,None,None], sAimPosition, fWorldUpVector=sInterpUp, fUpVector=[0,sNegSideMultipl,0], bUpIsDirection=True)
                    controllers.closeCommentBox('Aim Nodes')

                    if bInitial:
                        controllers.setNewColumn()
                        controllers.openCommentBox('Calculate Offset')
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                        sInitialTransform = nodes.getTransformNode(sCurrentBone, bInitial=True)
                        controllers.setNewColumn()
                        sOffsetTransform = nodes.createMakeRelativeNode(sInitialTransform, sAimTransform)
                        nodes.createSetMetaDataExecuteNode(sCurrentBone, 'OffsetTransform', sOffsetTransform, iType=pins.PinType.transform)
                        controllers.closeCommentBox('Calculate Offset')
                    else:
                        controllers.setNewColumn()
                        controllers.openCommentBox('Apply')
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                        sOffsetTransform = nodes.createGetMetaData(sCurrentBone, 'OffsetTransform', iType=pins.PinType.transform)
                        sAbsoluteTransform = nodes.createMakeAbsoluteNode(sOffsetTransform, sAimTransform)
                        nodes.createSetTransformExecuteNode(sCurrentBone, sAbsoluteTransform)
                        controllers.closeCommentBox('Apply')
                    controllers.goToParentExecute()


                if controllers.BLOCK_BRANCH_FALSE: #last bone
                    if not bInitial:
                        controllers.openCommentBox('Last Bone')
                        controllers.setNewColumn()
                        sEntry_Transforms = nodes.createGetEntryVariable('Transforms')
                        sLastIndex = nodes.createBasicCalculateNode([nodes.createArrayGetCountNode(sEntry_Transforms), 1], sOperation='Subtract', iPinType=pins.PinType.integer)
                        sLastCtrl = nodes.createArrayAtNode(sEntry_Transforms, sLastIndex)

                        controllers.setNewColumn()
                        sCurrentBone = nodes.createGetVariableNode(vCurrentBone)
                        sBoneTransform = nodes.createProjectTransformToNewParent(sCurrentBone, sLastCtrl)

                        controllers.setNewColumn()
                        sEntry_bStretched = nodes.createGetEntryVariable('bStretched')
                        nodes.createBranchExecuteNode(sEntry_bStretched)
                        controllers.setNewColumn()
                        if controllers.BLOCK_BRANCH_TRUE:
                            sLastCtrlTransform = nodes.getTransformNode(sLastCtrl)
                            nodes.createSetTransformExecuteNode(sCurrentBone, ['%s.Translation' % sLastCtrlTransform, '%s.Rotation' % sBoneTransform, None])
                            controllers.goToParentExecute()
                        if controllers.BLOCK_BRANCH_FALSE:
                            nodes.createSetRotationExecuteNode(sCurrentBone, '%s.Rotation' % sBoneTransform)
                            controllers.goToParentExecute()
                        controllers.closeCommentBox('Last Bone')
                    controllers.goToParentExecute()
                controllers.goToParentExecute()

            controllers.goToParentExecute() # goes back on the Branch Node that switches between intital and current

            nodes.newSequencerPlug()

        nodes.endCurrentFunction(bAddToExecute=False)

    sSpineSpline = nodes.addFunctionNode(sFunctionName)
    pins.connectToPin1D(sTransformsArray, '%s.Transforms' % sSpineSpline)
    pins.connectToPin1D(sBonesArray, '%s.Bones' % sSpineSpline)
    pins.connectToPin1D(sFirstCtrls, '%s.FirstCtrls' % sSpineSpline)
    pins.connectToPin1D(sSecondCtrls, '%s.SecondCtrls' % sSpineSpline)
    pins.connectToPin1D(sCtrlWeights, '%s.CtrlWeights' % sSpineSpline)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sSpineSpline)
    pins.connectToPinVector(bNegative, '%s.bNegative' % sSpineSpline)
    pins.connectToPin1D(bStretched, '%s.bStretched' % sSpineSpline)

    return sSpineSpline



def spineSquashStretch(sJoints, fJointScalePercs):
    sFunctionName = 'kangaroo_squashStretchSpine'
    uFunction = nodes.getFunction(sFunctionName)

    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Bones', 'FName', True),
                                                     ('Percentages', 'float', True)])

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.Bones')
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eBone = ELEM('%s.Element' % sForEach, 'Bone')
            sCountMinusOne = nodes.createBasicCalculateNode(['%s.Count' % sForEach, 1], sOperation='Subtract', iPinType=pins.PinType.integer)
            sDoScaleByDistance = nodes.createConditionNodes('%s.Index' % sForEach, '<', sCountMinusOne, iTermsPinType=pins.PinType.integer)
            controllers.setNewColumn()

            nodes.createBranchExecuteNode(sDoScaleByDistance)
            if controllers.BLOCK_BRANCH_TRUE:
                controllers.openCommentBox('All Bones except Last')
                controllers.setNewColumn()
                sEntry_Bones = nodes.createGetEntryVariable('Bones')
                controllers.setNewColumn()
                sNextBone = nodes.createArrayAtNode(sEntry_Bones, nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add', iPinType=pins.PinType.integer))
                eNextBone = ELEM(sNextBone, 'Bone')
                controllers.setNewColumn()
                sNextCurrent = nodes.getTransformNode(eNextBone, bLocal=True)
                sNextRef = nodes.getTransformNode(eNextBone, bLocal=True, bInitial=True)
                sScaleFactor = nodes.createBasicCalculateNode(['%s.Translation.X' % sNextRef, '%s.Translation.X' % sNextCurrent], sOperation='Divide')
                controllers.setNewColumn()
                sEntry_Percentages = nodes.createGetEntryVariable('Percentages')
                sPerc = nodes.createArrayAtNode(sEntry_Percentages, '%s.Index' % sForEach)

                sInterpScaled = nodes.createFloatInterpolateNode(sPerc, 1, sScaleFactor)
                controllers.setNewColumn()
                nodes.createSetScaleExecuteNode(eBone, [1, sInterpScaled, sInterpScaled], bLocal=False)
                controllers.goToParentExecute()
            controllers.closeCommentBox('All Bones except Last')
            if controllers.BLOCK_BRANCH_FALSE:
                controllers.openCommentBox('Last Bone')
                controllers.setNewColumn()
                nodes.createSetScaleExecuteNode(eBone, [1, 1, 1], bLocal=False)
                controllers.goToParentExecute()
                controllers.closeCommentBox('Last Bone')

            controllers.goToParentExecute()

        nodes.endCurrentFunction(bAddToExecute=False)

    sSquashNode = nodes.addFunctionNode(sFunctionName)
    pins.setStringArray(sJoints, '%s.Bones' % sSquashNode)
    pins.setValueArray(fJointScalePercs, '%s.Percentages' % sSquashNode)



def angleInterpolator(sJoints, ffAngleRanges, iCurveTypes):
    # sAngleNode = angleFromJointsFunction(sJoints)
    # not tested yet after changing definition of angleFromJointsFunction():
    sAngleNode = angleFromJointsFunction(ELEM(sJoints[0], 'Bone'), ELEM(sJoints[1], 'Bone'), ELEM(sJoints[2], 'Bone'))

    sOuts = []
    for xR, iCurveType in zip(ffAngleRanges, iCurveTypes):
        sOuts.append(createEvalInterpolatorCurveNodeFunction(sAngleNode, xR[0], xR[1], iCurveType))

    return sOuts if len(sOuts) > 1 else sOuts[0]


def signedAngleInterpolator(sTwist, sParent, ffAngleRanges, iCurveTypes, iAngleAxis=0, fForwardVector=[0,1,0], fUpVector=[0,0,1]):
    sAngleNode = signedAngleFunction(ELEM(sTwist, 'Bone'), ELEM(sParent, 'Bone'), iAngleAxis=iAngleAxis, fForwardVector=fForwardVector, fUpVector=fUpVector)
    sOuts = []
    for xR, iCurveType in zip(ffAngleRanges, iCurveTypes):
        sOuts.append(createEvalInterpolatorCurveNodeFunction(sAngleNode, xR[0], xR[1], iCurveType))
    return sOuts if len(sOuts) > 1 else sOuts[0]



def createEvalInterpolatorCurveNodeFunction(xValue, xStart, xEnd, iCurveType=None):
    sFunctionName = 'kangaroo_curveInterpolate'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('InputValue', 'float', False),
                                                                         ('Start', 'float', False),
                                                                         ('End', 'float', False),
                                                                        ('CurveType', 'int32', False)],
                                                                xOutputs=[('OutValue', 'float', False)], bMutable=False)
        sRangeNode = nodes.createRemapNode('Entry.InputValue', 'Entry.Start', 'Entry.End', 0, 1)

        sNode1 = nodes.createNodeFromPath('/Script/ControlRig.RigUnit_AnimEvalRichCurve', fNodeSize=[500.0,500.0])
        pins.connectToPin1D(sRangeNode, '%s.Value' % sNode1)
        controllers.latestFD().vmModel.set_pin_default_value('%s.Curve' % sNode1, '(EditorCurveData=(Keys=((InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=0.000000,Value=0.000000,ArriveTangent=-0.000337,ArriveTangentWeight=0.000000,LeaveTangent=-0.000336,LeaveTangentWeight=0.000000),(InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=1.000000,Value=1.000000,ArriveTangent=1.633306,ArriveTangentWeight=0.000000,LeaveTangent=1.633306,LeaveTangentWeight=0.000000)),DefaultValue=340282346638528859811704183484516925440.000000,PreInfinityExtrap=RCCE_Constant,PostInfinityExtrap=RCCE_Constant),ExternalCurve=None)', True)
        sNode2 = nodes.createNodeFromPath('/Script/ControlRig.RigUnit_AnimEvalRichCurve', fNodeSize=[500.0,500.0])
        pins.connectToPin1D(sRangeNode, '%s.Value' % sNode2)
        controllers.latestFD().vmModel.set_pin_default_value('%s.Curve' % sNode2, '(EditorCurveData=(Keys=((InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=0.000000,Value=0.000000,ArriveTangent=1.295691,ArriveTangentWeight=0.000000,LeaveTangent=1.295694,LeaveTangentWeight=0.000000),(InterpMode=RCIM_Cubic,TangentMode=RCTM_User,TangentWeightMode=RCTWM_WeightedNone,Time=1.000000,Value=1.000000,ArriveTangent=0.025041,ArriveTangentWeight=0.000000,LeaveTangent=0.025042,LeaveTangentWeight=0.000000)),DefaultValue=340282346638528859811704183484516925440.000000,PreInfinityExtrap=RCCE_Constant,PostInfinityExtrap=RCCE_Constant),ExternalCurve=None)', True)
        sNode3 = nodes.createNodeFromPath('/Script/ControlRig.RigUnit_AnimEvalRichCurve', fNodeSize=[500.0,500.0])
        pins.connectToPin1D(sRangeNode, '%s.Value' % sNode3)
        controllers.latestFD().vmModel.set_pin_default_value('%s.Curve' % sNode3, '(EditorCurveData=(Keys=((InterpMode=RCIM_Cubic,TangentMode=RCTM_Auto,TangentWeightMode=RCTWM_WeightedNone,Time=0.000000,Value=0.000000,ArriveTangent=0.000000,ArriveTangentWeight=0.000000,LeaveTangent=0.000000,LeaveTangentWeight=0.000000),(InterpMode=RCIM_Cubic,TangentMode=RCTM_Auto,TangentWeightMode=RCTWM_WeightedNone,Time=1.000000,Value=1.000000,ArriveTangent=0.000000,ArriveTangentWeight=0.000000,LeaveTangent=0.000000,LeaveTangentWeight=0.000000)),DefaultValue=340282346638528859811704183484516925440.000000,PreInfinityExtrap=RCCE_Constant,PostInfinityExtrap=RCCE_Constant),ExternalCurve=None)', True)

        sSelectNode = nodes.createSelectNode2([sRangeNode, '%s.Result' % sNode1, '%s.Result' % sNode2, '%s.Result' % sNode3], 'Entry.CurveType', iPinType=pins.PinType.double)
        pins.connectToPin1D(sSelectNode, 'Return.OutValue')

        nodes.endCurrentFunction(bAddToExecute=False)
        

    sEvalFunctionNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)
    pins.connectToPin1D(xValue, '%s.InputValue' % sEvalFunctionNode)
    pins.connectToPin1D(xStart, '%s.Start' % sEvalFunctionNode)
    pins.connectToPin1D(xEnd, '%s.End' % sEvalFunctionNode)
    pins.connectToPin1D(iCurveType, '%s.CurveType' % sEvalFunctionNode)

    return '%s.OutValue' % sEvalFunctionNode




def createEvalConePointFunction(xPointFromJoint, xPosePoint, fStart, fEnd, iCurveType=None): #sConePoint, xP, xR[0], xR[1], iCurveType)
    sFunctionName = 'kangaroo_evalConePoint'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('JointPoint', 'FVector', False),
                                                     ('PosePoint', 'FVector', False),
                                                     ('Start', 'float', False),
                                                     ('End', 'float', False),
                                                    ('CurveType', 'int32', False)],
                                            xOutputs=[('OutValue', 'float', False)], bMutable=False)
        controllers.setNewColumn()
        sAngle = nodes.createGetAngleNode('Entry.JointPoint', 'Entry.PosePoint', bDegrees=True)
        sEvaled = createEvalInterpolatorCurveNodeFunction(sAngle, 'Entry.Start', 'Entry.End', 'Entry.CurveType')
        pins.connectToPin1D(sEvaled, 'Return.OutValue')

        nodes.endCurrentFunction(bAddToExecute=False)
        

    sEvalFunctionNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False, fNodeSize=[300.0,300.0])
    pins.connectToPinVector(xPointFromJoint, '%s.JointPoint' % sEvalFunctionNode)
    pins.connectToPinVector(xPosePoint, '%s.PosePoint' % sEvalFunctionNode)
    pins.connectToPin1D(fStart * 0.5, '%s.Start' % sEvalFunctionNode)
    pins.connectToPin1D(fEnd * 0.5, '%s.End' % sEvalFunctionNode)
    pins.connectToPin1D(iCurveType, '%s.CurveType' % sEvalFunctionNode)

    return '%s.OutValue' % sEvalFunctionNode






def angleFromJointsFunction(eJointA, eJointB, eJointC):

    sFunctionName = 'kangaroo_angleFromJoints'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:


        nodes.startFunction(sFunctionName, xInputs=[('JointA', 'FRigElementKey', False),
                                                     ('JointB', 'FRigElementKey', False),
                                                     ('JointC', 'FRigElementKey', False)],
                                                xOutputs=[('Angle', 'float', False)], bMutable=False)

        

        # nodes.newSequencerPlug()

        sJointPoints = ['%s.Translation' % nodes.getTransformNode(eJ) for eJ in ['Entry.JointA', 'Entry.JointB', 'Entry.JointC']]
        controllers.setNewColumn()
        sJointA = nodes.createBasicCalculateNode([sJointPoints[0], sJointPoints[1]], sOperation='Subtract', iPinType=pins.PinType.vector)
        sJointC = nodes.createBasicCalculateNode([sJointPoints[2], sJointPoints[1]], sOperation='Subtract', iPinType=pins.PinType.vector)
        sAngle = nodes.createGetAngleNode(sJointA, sJointC, bDegrees=True)
        pins.connectToPin1D(sAngle, 'Return.Angle')
        nodes.endCurrentFunction(bAddToExecute=False)

    sAngleNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)

    pins.connectItem(eJointA, '%s.JointA' % sAngleNode)
    pins.connectItem(eJointB, '%s.JointB' % sAngleNode)
    pins.connectItem(eJointC, '%s.JointC' % sAngleNode)
    # pins.connectItem(ELEM(sJoints[0], 'Bone'), '%s.JointA' % sAngleNode)
    # pins.connectItem(ELEM(sJoints[1], 'Bone'), '%s.JointB' % sAngleNode)
    # pins.connectItem(ELEM(sJoints[2], 'Bone'), '%s.JointC' % sAngleNode)

    return '%s.Angle' % sAngleNode


def signedAngleFunction(eTwist, eParent, iAngleAxis=0, fForwardVector=[0,1,0], fUpVector=[0,0,1]):

    sFunctionName = 'kangaroo_signedAngleInterpolator'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Twist', 'FRigElementKey', False),
                                                     ('Parent', 'FRigElementKey', False),
                                                     ('ForwardVector', 'FVector', False),
                                                     ('UpVector', 'FVector', False),
                                                     ('AngleAxis', 'int32', False)],
                                            xOutputs=[('Angle', 'float', False)], bMutable=False)
        controllers.openCommentBox('Get Transforms')
        controllers.setNewColumn()
        sParentTransform = nodes.getTransformNode('Entry.Parent')
        sTwistTransform = nodes.getTransformNode('Entry.Twist')
        sTwistTransformInitial = nodes.getTransformNode('Entry.Twist', bInitial=True)
        sParentTransformInitial = nodes.getTransformNode('Entry.Parent', bInitial=True)
        controllers.setNewColumn()
        sParentLocal = nodes.createMakeRelativeNode(sParentTransformInitial, sTwistTransformInitial)
        sTwistTransform = nodes.createMakeAbsoluteNode(sParentLocal, sTwistTransform)
        controllers.setNewColumn()
        sLocal = nodes.createMakeRelativeNode(sTwistTransform, sParentTransform)
        controllers.closeCommentBox('Get Transforms')

        controllers.setNewColumn()
        sEntry_ForwardVector = nodes.createGetEntryVariable('ForwardVector')
        sForward = nodes.createRotateVectorNode(sEntry_ForwardVector, '%s.Rotation' % sLocal)

        controllers.setNewColumn()
        sEntry_AngleAxis = nodes.createGetEntryVariable('AngleAxis')
        sShrinkSelect = nodes.createSelectNode2([[0,1,1], [1,0,1], [1,1,0]], sEntry_AngleAxis, iPinType=pins.PinType.vector)
        sFrontPoint = nodes.createBasicCalculateNode([sForward, sShrinkSelect], iPinType=pins.PinType.vector)
        sAngle = nodes.createGetAngleNode(sFrontPoint, sEntry_ForwardVector, bDegrees=True)

        controllers.setNewColumn()
        sEntry_UpVector = nodes.createGetEntryVariable('UpVector')
        sDotProduct = nodes.createDotProductNode(sEntry_UpVector, sFrontPoint)
        sSignedAngle = nodes.createConditionNodes(sDotProduct, '>', 0, sAngle, nodes.createBasicCalculateNode([sAngle, -1], sOperation='Multiply'))
        pins.connectToPin1D(sSignedAngle, 'Return.Angle')

        nodes.endCurrentFunction(bAddToExecute=False)


    sTwistNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False, fNodeSize=[300.0, 500.0])
    pins.connectItem(eTwist, '%s.Twist' % sTwistNode)
    pins.connectItem(eParent, '%s.Parent' % sTwistNode)
    pins.connectToPinVector(fForwardVector, '%s.ForwardVector' % sTwistNode)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sTwistNode)
    pins.connectToPin1D(iAngleAxis, '%s.AngleAxis' % sTwistNode)
    return '%s.Angle' % sTwistNode





def uplegUpInterpolator(sInterp, sHip, sKnee, iUnrealAxes, ffLocalPoints, ffValues):
    eHip = ELEM(sHip, 'Bone')
    eKnee = ELEM(sKnee, 'Bone')
    controllers.openCommentBox('Upperleg Up Interpolator - %s' % sInterp)
    # nodes.newSequencerPlug()
    sAxes = ['X','Y','Z']

    sHipTransform = nodes.getTransformNode(eHip)
    sKneeTransform = nodes.getTransformNode(eKnee)
    controllers.setNewColumn()
    sLocalKneePoint = '%s.Translation' % nodes.createMakeRelativeNode(['%s.Translation' % sKneeTransform, None, None], sHipTransform)
    controllers.setNewColumn()

    sUpRange = nodes.createRemapNode('%s.%s' % (sLocalKneePoint, sAxes[iUnrealAxes[0]]), ffLocalPoints[0][0], ffLocalPoints[0][1], ffValues[0][0], ffValues[0][1])
    sNoSideRange = nodes.createRemapNode('%s.%s' % (sLocalKneePoint, sAxes[iUnrealAxes[1]]), ffLocalPoints[1][0], ffLocalPoints[1][1], ffValues[1][0], ffValues[1][1])
    sForwardRange = nodes.createRemapNode('%s.%s' % (sLocalKneePoint, sAxes[iUnrealAxes[2]]), ffLocalPoints[2][0], ffLocalPoints[2][1], ffValues[2][0], ffValues[2][1])
    controllers.setNewColumn()
    sCombined = nodes.createBasicCalculateNode([sUpRange, sNoSideRange, sForwardRange], sOperation='Multiply')

    controllers.closeCommentBox('Upperleg Up Interpolator - %s' % sInterp)

    return sCombined


# uplegUp_l_up = functions.uplegUpInterpolator('uplegUp_l', 'jnt_m_hips', 'jnt_l_leg_lowerTwist_000',
#                                              iUnrealAxes=[1, 0, 2],
#                                              ffLocalPoints=[[40.7249755859375, 6.701560974121094],
#                                                             [18.975906372070312, 34.752254486083984],
#                                                             [0.10445356369018555, 9.20299434661865]],
#                                              ffValues=[[0.0, 1.0], [1.0, 0.0], [0.0, 1.0]])  # (interpolator)


def uplegUpInterpolator(bIsRight=False):
    sFunctionName = 'kangaroo_uplegUpInterpolator'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('bIsRight', 'bool', False)],
                                            xOutputs=[('Result', 'float', False)], bMutable=True)

        sSelectSide = nodes.createIfNode('Entry.bIsRight', 1, 0, iPinType=pins.PinType.integer)

        controllers.setNewColumn()
        sHip = 'jnt_m_hips'
        sUpper = nodes.createStringSelectNode(['jnt_l_leg_upperTwist_000', 'jnt_r_leg_upperTwist_000'], sSelectSide)
        sKnee = nodes.createStringSelectNode(['jnt_l_leg_lowerTwist_000', 'jnt_r_leg_lowerTwist_000'], sSelectSide)
        eHip = ELEM(sHip, 'Bone')
        eKnee = ELEM(sKnee, 'Bone')
        eUpper = ELEM(sUpper, 'Bone')

        controllers.openCommentBox('Get Normalized Knee')
        controllers.setNewColumn()
        sNonMovingUpper = nodes.createProjectTransformToNewParent(eUpper, eHip)
        sKneeTransform = nodes.getTransformNode(eKnee)
        sLocalKnee = nodes.createMakeRelativeNode(['%s.Translation' % sKneeTransform, None, None], sNonMovingUpper)
        controllers.setNewColumn()
        sNegative = nodes.createBasicCalculateNode(['%s.Translation' % sLocalKnee, [-1,-1,-1]], iPinType=pins.PinType.vector)
        sEntry_bIsRight = nodes.createGetEntryVariable('bIsRight')
        sSigned = nodes.createIfNode(sEntry_bIsRight, sNegative, '%s.Translation' % sLocalKnee, iPinType=pins.PinType.vector)
        controllers.setNewColumn()
        sNormalizedKnee = nodes.createNormalizeVectorNode(sSigned)
        controllers.closeCommentBox('Get Normalized Knee')

        controllers.openCommentBox('Remap and Multiply')
        controllers.setNewColumn()
        sUpRange = nodes.createRemapNode('%s.%s' % (sNormalizedKnee, 'X'), 1.0, 0.0, 0.0, 1.0)
        sForwardRange = nodes.createRemapNode('%s.%s' % (sNormalizedKnee, 'Y'), 0.0, math.cos(math.radians(15)), 0, 1)
        sNoSideRange = nodes.createRemapNode('%s.%s' % (sNormalizedKnee, 'Z'), math.sin(math.radians(15)), math.sin(math.radians(45)), 1, 0)
        controllers.setNewColumn()
        sCombined = nodes.createBasicCalculateNode([sUpRange, sNoSideRange, sForwardRange], sOperation='Multiply')
        pins.connectToPin1D(sCombined, 'Return.Result')
        controllers.closeCommentBox('Remap and Multiply')

        nodes.endCurrentFunction(bAddToExecute=False)


    sConeFunctionNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0, 350.0])
    pins.connectToPin1D(bIsRight, '%s.bIsRight' % sConeFunctionNode)

    return '%s.Result' % sConeFunctionNode





def coneInterpolator(sJoint, sParent, bNegative, ffPoints, ffRanges, iCurveTypes, bCreateDebugPoseDots=False):
    sConePoint = coneInterpolatorFunction(sJoint, sParent, bNegative, bCreateDebugPoseDots=bCreateDebugPoseDots)

    sOuts = []
    for xP, xR, iCurveType in zip(ffPoints, ffRanges, iCurveTypes):
        sOuts.append(createEvalConePointFunction(sConePoint, xP, xR[1], xR[0], iCurveType))

    return sOuts if len(sOuts) > 1 else sOuts[0]



def coneInterpolatorFunction(sJoint, sParent, bNegative, bCreateDebugPoseDots=False):
    sFunctionName = 'kangaroo_coneInterpolator'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Joint', 'FRigElementKey', False),
                                                     ('Parent', 'FRigElementKey', False),
                                                     ('bNegative', 'bool', False),
                                                    ('bDebug', 'bool', False)],
                                            xOutputs=[('JointPoint', 'FVector', False)], bMutable=True)

        controllers.setNewColumn()

        sJointReference = nodes.createProjectTransformToNewParent('Entry.Joint', 'Entry.Parent')
        sJointTransform = nodes.getTransformNode('Entry.Joint')
        sJointInReference = nodes.createMakeRelativeNode(sJointTransform, sJointReference)

        controllers.setNewColumn()
        controllers.openCommentBox('Estimated Joint Length')
        # sLocalJointInitial = nodes.getTransformNode('Entry.Joint', bInitial=True, bLocal=True)
        # sJointLength = '%s.Translation.X' % sLocalJointInitial
        # sPositive = nodes.createMathAbs(sJointLength)
        # sNegative = nodes.createNegateNode(sPositive)
        # controllers.setNewColumn()
        sEntry_Negative = nodes.createGetEntryVariable('bNegative')
        sJointLength = nodes.createIfNode(sEntry_Negative, -10.0, 10.0)
        controllers.closeCommentBox('Estimated Joint Length')

        controllers.setNewColumn()
        sJointPoint = '%s.Translation' % nodes.createMakeAbsoluteNode([[sJointLength,0,0],None,None], sJointInReference)

        pins.connectToPinVector(sJointPoint, 'Return.JointPoint')

        controllers.setNewColumn()
        controllers.openCommentBox('Debug Draw')
        sEnabled = nodes.createGetEntryVariable('bDebug')
        nodes.createDrawLineNode('%s.Translation' % sJointInReference, sJointPoint, bEnabled=sEnabled)
        controllers.closeCommentBox('Debug Draw')
        nodes.endCurrentFunction(bAddToExecute=False)


    sConeFunctionNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0, 350.0])
    pins.connectItem(ELEM(sJoint, 'Bone'), '%s.Joint' % sConeFunctionNode)
    pins.connectItem(ELEM(sParent, 'Bone'), '%s.Parent' % sConeFunctionNode)
    pins.connectToPin1D(bNegative, '%s.bNegative' % sConeFunctionNode)
    # pins.connectToPin1D(fJointLength, '%s.JointLength' % sConeFunctionNode)

    return '%s.JointPoint' % sConeFunctionNode


def createMuscleJointFunction(sMuscleJoint, sEndMuscleJoint, sSide, sEndSpace, fSquashPosY, fSquashNegY, fSquashPosZ, fSquashNegZ, fStretch, bAttachEnd, sLimitParent=None, bLimits=[]):
    sFunctionName = 'kangaroo_muscleJoint'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Joint', 'FName', False),
                                                   ('EndJoint', 'FName', False),
                                                   ('SquashPosY', 'float', False),
                                                   ('SquashNegY', 'float', False),
                                                   ('SquashPosZ', 'float', False),
                                                   ('SquashNegZ', 'float', False),
                                                   ('Stretch', 'float', False),
                                                   ('SideMultiply', 'float', False),
                                                   ('EndSpace', 'FName', False),
                                                   ('LimitParent', 'FName', False),
                                                   # ('LocalLimitPoint', 'FVector', False),
                                                   ('MaxX', 'bool', False),
                                                   ('MinX', 'bool', False),
                                                   ('MaxY', 'bool', False),
                                                   ('MinY', 'bool', False),
                                                   ('MaxZ', 'bool', False),
                                                   ('MinZ', 'bool', False),
                                                   ('AttachEnd', 'bool', False)])

        
        controllers.setNewColumn()
        eEntry_Joint = ELEM('Entry.Joint', 'Bone')
        eEntry_EndJoint = ELEM('Entry.EndJoint', 'Bone')
        eEntry_EndSpace = ELEM('Entry.EndSpace', 'Bone')
        sJointTransform = nodes.createProjectTransformToNewParent(eEntry_Joint, nodes.createGetParentNode(eEntry_Joint)) # do we need that?!
        sAimTarget = '%s.Translation' % nodes.createProjectTransformToNewParent(eEntry_EndJoint, eEntry_EndSpace)
        sUp = nodes.createMakeAbsoluteNode([[0,0,10], None, None], sJointTransform)

        controllers.openCommentBox('Get Local Limit Point')
        controllers.setNewColumn()
        eEntry_EndJoint = ELEM(nodes.createGetEntryVariable('EndJoint'), 'Bone')
        sEndJointTransform = nodes.getTransformNode(eEntry_EndJoint, bInitial=True)
        eEntry_LimitSpace = ELEM(nodes.createGetEntryVariable('LimitParent'), 'Bone')
        sLimitSpaceTransform = nodes.getTransformNode(eEntry_LimitSpace, bInitial=True)
        sLocalLimitPoint = '%s.Translation' % nodes.createMakeRelativeNode(sEndJointTransform, sLimitSpaceTransform)
        vLocalLimitPoint = hierarchy.newVariable('LocalLimitPoint', 'FVector')
        nodes.createSetVariableExecuteNode(vLocalLimitPoint, sLocalLimitPoint)
        controllers.closeCommentBox('Get Local Limit Point')

        controllers.openCommentBox('End Limit')
        controllers.setNewColumn()
        sLocalLimitPoint = nodes.createGetVariableNode(vLocalLimitPoint)
        sUpperLimitPoint = nodes.createBasicCalculateNode([sLocalLimitPoint, [1000000, 1000000, 1000000]], sOperation='Add', iPinType=pins.PinType.vector)
        sLowerLimitPoint = nodes.createBasicCalculateNode([sLocalLimitPoint, [-1000000, -1000000, -1000000]], sOperation='Add', iPinType=pins.PinType.vector)
        controllers.setNewColumn()
        fMax = [nodes.createIfNode('Entry.MaxX', '%s.X' % sLocalLimitPoint, '%s.X' % sUpperLimitPoint),
                nodes.createIfNode('Entry.MaxY', '%s.Y' % sLocalLimitPoint, '%s.Y' % sUpperLimitPoint),
                nodes.createIfNode('Entry.MaxZ', '%s.Z' % sLocalLimitPoint, '%s.Z' % sUpperLimitPoint)]
        fMin = [nodes.createIfNode('Entry.MinX', '%s.X' % sLocalLimitPoint, '%s.X' % sLowerLimitPoint),
                nodes.createIfNode('Entry.MinY', '%s.Y' % sLocalLimitPoint, '%s.Y' % sLowerLimitPoint),
                nodes.createIfNode('Entry.MinZ', '%s.Z' % sLocalLimitPoint, '%s.Z' % sLowerLimitPoint)]

        controllers.setNewColumn()
        sEntry_LimitParent = nodes.createGetEntryVariable('LimitParent')
        sLimitSpaceTransform = nodes.getTransformNode(ELEM(sEntry_LimitParent, 'Bone'))
        sLocalInLimitSpace = nodes.createMakeRelativeNode([sAimTarget, None, None], sLimitSpaceTransform)
        sClamped = nodes.createClampNode('%s.Translation' % sLocalInLimitSpace, fMin, fMax, bVector=True)
        sAimTargetLimited = '%s.Translation' % nodes.createMakeAbsoluteNode([sClamped, None, None], sLimitSpaceTransform)
        sAimTarget = nodes.createConditionNodes(sEntry_LimitParent, 'stringEqual', 'None', sAimTarget, sAimTargetLimited, iPinType=pins.PinType.vector)
        controllers.closeCommentBox('End Limit')


        controllers.openCommentBox('Get Initial Length')
        controllers.setNewColumn()
        eEndJoint = ELEM(nodes.createGetEntryVariable('EndJoint'), 'Bone')
        sInitialLength = '%s.Translation.X' % nodes.getTransformNode(eEndJoint, bLocal=True, bInitial=True)
        sInitialLength = nodes.createMathAbs(sInitialLength)
        controllers.closeCommentBox('Get Initial Length')

        controllers.openCommentBox('Aim and Stretch')
        controllers.setNewColumn()
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultiply')
        sAim = nodes.createAimNode(sJointTransform, sAimTarget, fAimVector=[sEntry_SideMultipl, 0,0], fUpVector=[0,0,1])
        pins.connectToPinVector('%s.Translation' % sUp, '%s.Secondary.Target' % sAim.split('.')[0])

        sDistance = nodes.createGetDistanceNode('%s.Translation' % sJointTransform, sAimTarget)
        sScaleLength = nodes.createBasicCalculateNode([sDistance, sInitialLength], sOperation='Divide')
        controllers.closeCommentBox('Aim and Stretch')

        controllers.openCommentBox('Squash')
        controllers.setNewColumn()
        sDefaultSquash = nodes.createBasicCalculateNode([1, sScaleLength], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_SquashPosY = nodes.createGetEntryVariable('SquashPosY')
        sEntry_SquashPosZ = nodes.createGetEntryVariable('SquashPosZ')
        sEntry_SquashNegY = nodes.createGetEntryVariable('SquashNegY')
        sEntry_SquashNegZ = nodes.createGetEntryVariable('SquashNegZ')
        controllers.setNewColumn()
        xScaleConditionedY = nodes.createConditionNodes(sScaleLength, '<', 1, sEntry_SquashPosY, sEntry_SquashNegY)
        xScaleInterpolatedY = nodes.createFloatInterpolateNode(xScaleConditionedY, 1.0, sDefaultSquash)
        xScaleConditionedZ = nodes.createConditionNodes(sScaleLength, '<', 1, sEntry_SquashPosZ, sEntry_SquashNegZ)
        xScaleInterpolatedZ = nodes.createFloatInterpolateNode(xScaleConditionedZ, 1.0, sDefaultSquash)
        controllers.setNewColumn()

        sEntry_Stretch = nodes.createGetEntryVariable('Stretch')
        sStretchLength = nodes.createFloatInterpolateNode(sEntry_Stretch, 1.0, sScaleLength)
        sAddScale = nodes.createMakeAbsoluteNode([None, None, [sStretchLength, xScaleInterpolatedY, xScaleInterpolatedZ]], sAim)
        controllers.closeCommentBox('Squash')
        controllers.setNewColumn()

        controllers.openCommentBox('Set the Bone')
        controllers.setNewColumn()
        eEntry_Joint = ELEM(nodes.createGetEntryVariable('Joint'), 'Bone')
        nodes.createSetTransformExecuteNode(eEntry_Joint, sAddScale)
        controllers.closeCommentBox('Set the Bone')

        controllers.openCommentBox('Attach End')
        controllers.setNewColumn()

        sEntry_AttachEnd = nodes.createGetEntryVariable('AttachEnd')
        nodes.createBranchExecuteNode(sEntry_AttachEnd)
        if controllers.BLOCK_BRANCH_TRUE:
            eEntry_EndJoint = ELEM(nodes.createGetEntryVariable('EndJoint'), 'Bone')
            nodes.createSetTranslationExecuteNode(eEntry_EndJoint, sAimTarget)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.goToParentExecute()

        controllers.closeCommentBox('Attach End')

        nodes.endCurrentFunction(bAddToExecute=False)

    sMuscleNode = nodes.addFunctionNode(sFunctionName)

    pins.setString(sMuscleJoint, '%s.Joint' % sMuscleNode)
    pins.setString(sEndMuscleJoint, '%s.EndJoint' % sMuscleNode)
    pins.setString(sEndSpace, '%s.EndSpace' % sMuscleNode)
    if sLimitParent:
        pins.setString(sLimitParent, '%s.LimitParent' % sMuscleNode)
    # pins.connectToPin1D(fLength, '%s.Length' % sMuscleNode)
    pins.connectToPin1D(-1.0 if sSide == 'r' else 1.0, '%s.SideMultiply' % sMuscleNode)
    # pins.connectToPinVector(fLocalLimitPoint, '%s.LocalLimitPoint' % sMuscleNode)

    pins.connectToPin1D(fSquashPosY, '%s.SquashPosY' % sMuscleNode)
    pins.connectToPin1D(fSquashNegY, '%s.SquashNegY' % sMuscleNode)
    pins.connectToPin1D(fSquashPosZ, '%s.SquashPosZ' % sMuscleNode)
    pins.connectToPin1D(fSquashNegZ, '%s.SquashNegZ' % sMuscleNode)
    pins.connectToPin1D(fStretch, '%s.Stretch' % sMuscleNode)
    pins.connectToPin1D(bAttachEnd, '%s.AttachEnd' % sMuscleNode)

    if bLimits:
        for i,sA in enumerate(['MaxX', 'MinX', 'MaxY', 'MinY', 'MaxZ', 'MinZ']):
            pins.connectToPin1D(bLimits[i], '%s.%s' % (sMuscleNode, sA))





def blendJoints(ssJoints):
    controllers.setNewColumn()

    sFunctionName = 'kangaroo_blendJoints'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('BlendJoints', 'FRigElementKey', True),
                                                    ('FromJoints', 'FRigElementKey', True),
                                                    ('ToJoints', 'FRigElementKey', True),
                                                    ('Weights', 'float', True)])

        sForEach = nodes.createForEachExecuteNode('Entry.BlendJoints')
        sFromItem = nodes.createArrayAtNode('Entry.FromJoints', '%s.Index' % sForEach)
        sToItem = nodes.createArrayAtNode('Entry.ToJoints', '%s.Index' % sForEach)
        controllers.setNewColumn()
        sWeight = nodes.createArrayAtNode('Entry.Weights', '%s.Index' % sForEach)
        sWeightRev = nodes.createBasicCalculateNode([1.0, sWeight], sOperation='Subtract', iPinType=pins.PinType.double)
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(sFromItem, sWeightRev), (sToItem, sWeight)], '%s.Element' % sForEach, bMaintainOffset=True)
        controllers.goToParentExecute()

        nodes.endCurrentFunction(bAddToExecute=False)

    sBlendNode = nodes.addFunctionNode(sFunctionName)
    pins.setItemArray([ELEM(sJoints[0], 'Bone') for sJoints in ssJoints], '%s.BlendJoints' % sBlendNode)
    pins.setItemArray([ELEM(sJoints[1], 'Bone') for sJoints in ssJoints], '%s.FromJoints' % sBlendNode)
    pins.setItemArray([ELEM(sJoints[2], 'Bone') for sJoints in ssJoints], '%s.ToJoints' % sBlendNode)
    pins.setValueArray([sJoints[3] for sJoints in ssJoints], '%s.Weights' % sBlendNode)




def createFkChainCtrlsSetup(sJoints, cCtrls):

    iLength = len(cCtrls)
    sFunctionName = 'kangaroo_fkChain_%dBonesDynamic' % iLength

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xProceduralInputs = []
        for i in range(iLength):
            if i > 0: # if i == 0 it's the ATTACHER_root
                xProceduralInputs.append(('ATTACHER_fk_%02d_t' % i, 'FConstraintParent', True))
                xProceduralInputs.append(('ATTACHER_fk_%02d_r' % i, 'FConstraintParent', True))

        nodes.startFunction(sFunctionName, xInputs= [('Bones', 'FName', True),
                                                     ('Controls', 'FName', True),
                                                     ('Passers', 'FName', True),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                    ] + xProceduralInputs)

        controllers.setNewColumn()

        for i in range(iLength):
            controllers.openCommentBox('Bone %d' % i)

            controllers.setNewColumn()
            ePasser = ELEM(nodes.createArrayAtNode(nodes.createGetEntryVariable('Passers'), i), 'Null')
            if i == 0:
                eAttacherT = nodes.createGetEntryVariable('ATTACHER_root_t')
                eAttacherR = nodes.createGetEntryVariable('ATTACHER_root_r')
            else:
                eAttacherT = nodes.createGetEntryVariable('ATTACHER_fk_%02d_t' % i)
                eAttacherR = nodes.createGetEntryVariable('ATTACHER_fk_%02d_r' % i)
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode(eAttacherT, ePasser, bMaintainOffset=True, skipRotate=['x','y','z'])
            nodes.createParentConstraintExecuteNode(eAttacherR, ePasser, bMaintainOffset=True, skipTranslate=['x','y','z'])

            controllers.setNewColumn()
            eControl = ELEM(nodes.createArrayAtNode(nodes.createGetEntryVariable('Controls'), i), 'Control')
            eBone = ELEM(nodes.createArrayAtNode(nodes.createGetEntryVariable('Bones'), i), 'Bone')

            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode([(eControl, 1.0)], eBone, bMaintainOffset=True)
            controllers.setNewColumn()

            controllers.closeCommentBox('Bone %d' % i)
        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setStringArray([cCtrl.ePasser.name for cCtrl in cCtrls], '%s.Passers' % sFkNode)
    pins.setStringArray([cCtrl.eControl.name for cCtrl in cCtrls], '%s.Controls' % sFkNode)
    pins.setStringArray(sJoints, '%s.Bones' % sFkNode)

    return sFkNode


# this is a verlet node per bone
def createChainSpring_verlets(sJoints, eControl, fDefault=0.0, fSideMultipl=1.0):
    sFunctionName = 'kangaroo_chainSpring'

    hierarchy.createFloatControl('dynamic', eParent=eControl, fRange=[0,1], fDefault=fDefault)

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('Control', 'FName', False),
                                                    ('Bones', 'FName', True),
                                                    ('SideMultipl', 'float', False)])

        controllers.setNewColumn()
        controllers.openCommentBox('Get Dynamics Attribute')
        controllers.setNewColumn()
        sEntry_Controls = nodes.createGetEntryVariable('Controls')
        sDynamic = nodes.createGetChannelNode2(nodes.createArrayAtNode(sEntry_Controls, 0), 'dynamic')
        controllers.setNewColumn()
        vDynamic = hierarchy.newVariable('dynamics')
        nodes.createSetVariableExecuteNode(vDynamic, sDynamic)
        controllers.closeCommentBox('Get Dynamics Attribute')

        controllers.setNewColumn()
        sBones = nodes.createGetEntryVariable('Bones')
        for i in range(len(sJoints)-1):
            controllers.openCommentBox('Dynamics Bone %d' % i)
            controllers.setNewColumn()

            eBone = ELEM(nodes.createArrayAtNode(sBones, i), 'Bone')
            eTargetBone = ELEM(nodes.createArrayAtNode(sBones, i+1), 'Bone')
            controllers.setNewColumn()
            sBonePosition1 = '%s.Translation' % nodes.getTransformNode(eTargetBone)
            sBoneSpring1 = nodes.createVerletNode(sBonePosition1)
            controllers.setNewColumn()
            sDynamics = nodes.createGetVariableNode(vDynamic)
            sBoneSpring1 = nodes.createVectorInterpolateNode(sDynamics, sBonePosition1, sBoneSpring1)
            controllers.setNewColumn()
            sAimNode = nodes.createAimExecuteNode(eBone, sBoneSpring1, bUpIsDirection=True)
            sSideMultipl = nodes.createGetEntryVariable('SideMultipl')
            pins.connectToPinVector([sSideMultipl,0,0], '%s.Primary.Axis' % sAimNode)
            sPoleVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % nodes.getTransformNode(eBone))
            pins.connectToPinVector(sPoleVector, '%s.Secondary.Target' % sAimNode)
        controllers.closeCommentBox('Dynamics Bone %d' % i)
        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(eControl.name, '%s.Control' % sFkNode)
    pins.setStringArray(sJoints, '%s.Bones' % sFkNode)
    pins.connectToPin1D(fSideMultipl, '%s.SideMultipl' % sFkNode)
    return sFkNode



def createChainSpring(sJoints, eControl, fSideMultipl, fDefault, fStiffness, fDamping):

    sFunctionName = 'kangaroo_chainSpring'

    hierarchy.createFloatControl('dynamic', fRange=[0,100], fDefault=fDefault, eParent=eControl)
    hierarchy.createFloatControl('stiffness', fRange=[0,100], fDefault=fStiffness, eParent=eControl)
    hierarchy.createFloatControl('damping', fRange=[0,100], fDefault=fDamping, eParent=eControl)

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('Control', 'FName', False),
                                                    ('Bones', 'FName', True)])

        controllers.setNewColumn()
        sForeach = nodes.createForEachExecuteNode('Entry.Bones')
        if controllers.BLOCK_FOREACH:
            controllers.openCommentBox('Is before Last Bone?')
            sMinusOne = nodes.createBasicCalculateNode(['%s.Count' % sForeach, -1], sOperation='Add', iPinType=pins.PinType.integer)
            sCond = nodes.createConditionNodes('%s.Index' % sForeach, '<', sMinusOne, iTermsPinType=pins.PinType.integer)
            controllers.closeCommentBox('Is before Last Bone?')

            controllers.setNewColumn()
            nodes.createBranchExecuteNode(sCond)
            if controllers.BLOCK_BRANCH_TRUE:
                vBone = hierarchy.newVariable('Bone', 'FName')
                nodes.createSetVariableExecuteNode(vBone, '%s.Element' % sForeach)
                controllers.setNewColumn()

                controllers.openCommentBox('Get Aim')
                controllers.setNewColumn()
                sPlusOne = nodes.createBasicCalculateNode(['%s.Index' % sForeach, 1], sOperation='Add', iPinType=pins.PinType.integer)
                eTargetBone = ELEM(nodes.createArrayAtNode(nodes.createGetEntryVariable('Bones'), sPlusOne), 'Bone')
                controllers.setNewColumn()
                sBonePosition1 = '%s.Translation' % nodes.getTransformNode(eTargetBone)
                vTargetPosition = hierarchy.newVariable('TargetPosition', sType='FVector')
                nodes.createSetVariableExecuteNode(vTargetPosition, sBonePosition1)
                vSideMultipl = hierarchy.newVariable('SideMultipl')
                sBonePositionLocal1 = '%s.Translation' % nodes.getTransformNode(eTargetBone, bLocal=True)
                sSideMultipl = nodes.createConditionNodes('%s.X' % sBonePositionLocal1, '<', 0.0, -1.0, 1.0)
                nodes.createSetVariableExecuteNode(vSideMultipl, sSideMultipl)
                controllers.closeCommentBox('Get Aim')


                controllers.setNewColumn()
                controllers.openCommentBox('Get Old Position')
                eBone = ELEM(nodes.createGetVariableNode(vBone), 'Bone')
                sTargetPosition = nodes.createGetVariableNode(vTargetPosition)
                sOldPosition = nodes.createGetMetaData(eBone, 'Position', sDefault=sTargetPosition, iType=pins.PinType.vector)
                controllers.closeCommentBox('Get Old Position')

                controllers.setNewColumn()
                controllers.openCommentBox('Apply Stiffness to Position Change')
                sEntry_Control = nodes.createGetEntryVariable('Control')
                sStiffness = nodes.createGetChannelNode2(sEntry_Control, 'stiffness')
                sTargetPosition = nodes.createGetVariableNode(vTargetPosition)
                sDiff = nodes.createBasicCalculateNode([sTargetPosition, sOldPosition], sOperation='Subtract', iPinType=pins.PinType.vector)
                sDiffMultiplied = nodes.createBasicCalculateNode([sDiff, [sStiffness, sStiffness, sStiffness]], iPinType=pins.PinType.vector)
                controllers.closeCommentBox('Apply Stiffness to Position Change')
                controllers.setNewColumn()

                controllers.openCommentBox('Get Acceleration')
                eBone = ELEM(nodes.createGetVariableNode(vBone), 'Bone')
                sVel = nodes.createGetMetaData(eBone, 'Velocity', iType=pins.PinType.vector)
                sEntry_Control = nodes.createGetEntryVariable('Control')
                sDamping = nodes.createGetChannelNode2(sEntry_Control, 'damping')
                sVelMultiplied = nodes.createBasicCalculateNode([sVel, [sDamping, sDamping, sDamping]], iPinType=pins.PinType.vector)
                sAcc = nodes.createBasicCalculateNode([sDiffMultiplied, sVelMultiplied], sOperation='Subtract', iPinType=pins.PinType.vector)
                controllers.closeCommentBox('Get Acceleration')

                controllers.openCommentBox('Apply Acceleration to Velocity and update')
                controllers.setNewColumn()
                sDelta = nodes.createDeltaNode()
                sAccByDelta = nodes.createBasicCalculateNode([sAcc, [sDelta, sDelta, sDelta]], iPinType=pins.PinType.vector)
                controllers.setNewColumn()
                sNewVel = nodes.createBasicCalculateNode([sVel, sAccByDelta], sOperation='Add', iPinType=pins.PinType.vector)
                sSpringPosition = nodes.createBasicCalculateNode([sOldPosition, sNewVel], sOperation='Add', iPinType=pins.PinType.vector)
                nodes.createSetMetaDataExecuteNode(eBone, 'Position', sSpringPosition, iType=pins.PinType.vector)
                nodes.createSetMetaDataExecuteNode(eBone, 'Velocity', sNewVel, iType=pins.PinType.vector)
                controllers.closeCommentBox('Apply Acceleration to Velocity and update')


                controllers.openCommentBox('Apply Dynamics Attribute and Aim Bone')
                controllers.setNewColumn()
                sEntry_Control = nodes.createGetEntryVariable('Control')
                sDynamic = nodes.createGetChannelNode2(sEntry_Control, 'dynamic')
                sDynamic = nodes.createBasicCalculateNode([sDynamic, 0.1])
                sTargetPosition = nodes.createGetVariableNode(vTargetPosition)
                sBoneSpring1 = nodes.createVectorInterpolateNode(sDynamic, sTargetPosition, sSpringPosition)


                controllers.setNewColumn()
                eBone = ELEM(nodes.createGetVariableNode(vBone), 'Bone')
                sAimNode = nodes.createAimExecuteNode(eBone, sBoneSpring1, bUpIsDirection=True)
                sSideMultipl = nodes.createGetVariableNode(vSideMultipl)
                pins.connectToPinVector([sSideMultipl,0,0], '%s.Primary.Axis' % sAimNode)

                sPoleVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % nodes.getTransformNode(eBone))
                pins.connectToPinVector(sPoleVector, '%s.Secondary.Target' % sAimNode)
                controllers.closeCommentBox('Apply Dynamics Attribute and Aim Bone')
                controllers.goToParentExecute()
            if controllers.BLOCK_BRANCH_FALSE:
                controllers.goToParentExecute()

            controllers.goToParentExecute()


        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(eControl.name, '%s.Control' % sFkNode, bConnectIfPlug=True)
    pins.setStringArray(sJoints, '%s.Bones' % sFkNode)
    # pins.connectToPin1D(fSideMultipl, '%s.SideMultipl' % sFkNode)

    return sFkNode



def createSpineSimpleCtrlsSetup(xxCtrlBonePairs, eRoot):

    iLength = len(xxCtrlBonePairs)
    sFunctionName = 'kangaroo_spineSimple_%dBones' % iLength

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xProceduralInputs = []
        for i in range(iLength):
            xProceduralInputs.append(('Bone_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Control_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Passer_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('ATTACHER_ctrl_%02d_t' % i, 'FConstraintParent', True))
            xProceduralInputs.append(('ATTACHER_ctrl_%02d_r' % i, 'FConstraintParent', True))

        nodes.startFunction(sFunctionName, xInputs= [('Root', 'FRigElementKey', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ] + xProceduralInputs)
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Root', bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Root', bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])

        for i in range(iLength):
            controllers.openCommentBox('Bone %d' % i)
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ctrl_%02d_t' % i, 'Entry.Passer_%d' % i, bMaintainOffset=True, skipRotate=['x','y','z'])
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ctrl_%02d_r' % i, 'Entry.Passer_%d' % i, bMaintainOffset=True, skipTranslate=['x','y','z'])
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode([('Entry.Control_%d' % i, 1.0)], 'Entry.Bone_%d' % i, bMaintainOffset=True)
            controllers.setNewColumn()

            controllers.closeCommentBox('Bone %d' % i)
        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eRoot, '%s.Root' % sFkNode)
    iCounter = 0
    for cCtrl, sBone in xxCtrlBonePairs:
        pins.connectItem(cCtrl.ePasser, '%s.Passer_%d' % (sFkNode, iCounter))
        pins.connectItem(cCtrl.eControl, '%s.Control_%d' % (sFkNode, iCounter))
        pins.connectItem(ELEM(sBone, 'Bone'), '%s.Bone_%d' % (sFkNode, iCounter))
        iCounter += 1

    return sFkNode



def createSpineSimpleSetupBACKWARDS(eRoot, xxCtrlBonePairs):

    iLength = len(xxCtrlBonePairs)
    sFunctionName = 'kangaroo_spineSimple_%dBone_BACKWARDS' % iLength

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xProceduralInputs = []
        for i in range(iLength):
            xProceduralInputs.append(('Bone_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Control_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Passer_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('ATTACHER_ctrl_%02d_t' % i, 'FConstraintParent', True))
            xProceduralInputs.append(('ATTACHER_ctrl_%02d_r' % i, 'FConstraintParent', True))

        nodes.startFunction(sFunctionName, xInputs= [('Root', 'FRigElementKey', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ] + xProceduralInputs)
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Root', bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Root', bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])

        for i in range(iLength):
            controllers.openCommentBox('Bone %d' % i)
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ctrl_%02d_t' % i, 'Entry.Passer_%d' % i, bMaintainOffset=True, skipRotate=['x','y','z'])
            nodes.createParentConstraintExecuteNode('Entry.ATTACHER_ctrl_%02d_r' % i, 'Entry.Passer_%d' % i, bMaintainOffset=True, skipTranslate=['x','y','z'])
            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode([('Entry.Bone_%d' % i, 1.0)], 'Entry.Control_%d' % i, bMaintainOffset=True)
            controllers.setNewColumn()
            controllers.closeCommentBox('Bone %d' % i)
        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)


    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eRoot, '%s.Root' % sFkNode)
    iCounter = 0
    for cCtrl, sBone in xxCtrlBonePairs:
        pins.connectItem(cCtrl.ePasser, '%s.Passer_%d' % (sFkNode, iCounter))
        pins.connectItem(cCtrl.eControl, '%s.Control_%d' % (sFkNode, iCounter))
        pins.connectItem(ELEM(sBone, 'Bone'), '%s.Bone_%d' % (sFkNode, iCounter))
        iCounter += 1

    return sFkNode



def createHumanArmLegFkSetup(cUpper, cElbow, cWrist, cFingers, sJoints, eAttachRootToClavicle=None, eClavicleDriver=None):

    sFunctionName = 'kangaroo_armFk'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('UpperBone', 'FName', False),
                                                     ('UpperPasser', 'FName', False),
                                                     ('UpperControl', 'FName', False),
                                                     ('ElbowBone', 'FName', False),
                                                     ('ElbowPasser', 'FName', False),
                                                     ('ElbowControl', 'FName', False),
                                                     ('WristBone', 'FName', False),
                                                     ('WristPasser', 'FName', False),
                                                     ('WristControl', 'FName', False),
                                                     ('FingersBone', 'FName', False),
                                                     ('FingersPasser', 'FName', False),
                                                     ('FingersControl', 'FName', False),
                                                     ('AttachToClavicle', 'FName', False),
                                                     ('ClavicleDriver', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noClav_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noClav_r', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_t', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_r', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_t', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_r', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_t', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_r', 'FConstraintParent', True)])

        controllers.setNewColumn()

        controllers.openCommentBox('Attachers')
        eUpperPasser = ELEM('Entry.UpperPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eUpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z']) # is that ok also for Auto Clav?!
        nodes.createParentConstraintExecuteNode([(ELEM('Entry.AttachToClavicle', 'Control'), 1)], eUpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noClav_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers')


        controllers.openCommentBox('Auto Clavicle')
        controllers.setNewColumn()
        sEntry_ATTACHER_root_noClav_t = nodes.createGetEntryVariable('ATTACHER_root_noClav_t')
        sNoClavAttacherCount = nodes.createArrayGetCountNode(sEntry_ATTACHER_root_noClav_t)
        sThereAreNoClavAttachers = nodes.createConditionNodes(sNoClavAttacherCount, '>', 0, True, False, iTermsPinType=pins.PinType.integer)
        controllers.setNewColumn()
        nodes.createBranchExecuteNode(sThereAreNoClavAttachers)
        if controllers.BLOCK_BRANCH_TRUE: # no clavicle attachers
            controllers.setNewColumn()
            eEntry_UpperPasser = ELEM(nodes.createGetEntryVariable('UpperPasser'), 'Null')
            eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
            eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
            controllers.setNewColumn()
            sEntry_ATTACHER_root_noClav_t = nodes.createGetEntryVariable('ATTACHER_root_noClav_t')
            eSpine = '%s.Item' % nodes.createArrayAtNode(sEntry_ATTACHER_root_noClav_t, 0)
            sUpperBySpine = nodes.createProjectTransformToNewParent(eEntry_UpperPasser, eSpine)
            sUpperControlLocal = nodes.getTransformNode(eEntry_UpperControl, bLocal=True)
            controllers.setNewColumn()
            sElbowLocalInitial = nodes.createProjectTransformToNewParent(eEntry_ElbowPasser, eEntry_UpperControl, hierarchy.eOrigin, True, True, True)
            sRotatedElbowLocal = nodes.createMakeAbsoluteNode(sElbowLocalInitial, sUpperControlLocal)
            sFinalAimTarget = nodes.createMakeAbsoluteNode(sRotatedElbowLocal, sUpperBySpine)
            controllers.setNewColumn()
            eEntry_ClavicleDriver = ELEM(nodes.createGetEntryVariable('ClavicleDriver'), 'Null')
            nodes.createSetTransformExecuteNode(eEntry_ClavicleDriver, sFinalAimTarget)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE: # clavicle attachers
            # nothing
            controllers.goToParentExecute()

        controllers.closeCommentBox('Auto Clavicle')


        controllers.openCommentBox('Constraint Bones')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createPositionConstraintExecuteNode([(eEntry_UpperControl, 1)], eEntry_UpperBone)
        createKangarooAimConstraintFunction(eEntry_UpperBone, eEntry_ElbowControl, eEntry_UpperControl, fWorldUpVector=[0,1,0])

        controllers.setNewColumn()
        sEntry_ATTACHER_elbow_t = nodes.createGetEntryVariable('ATTACHER_elbow_t')
        sEntry_ATTACHER_elbow_r = nodes.createGetEntryVariable('ATTACHER_elbow_r')
        eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_elbow_t, eEntry_ElbowPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_elbow_r, eEntry_ElbowPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createPositionConstraintExecuteNode([(eEntry_ElbowControl, 1)], eEntry_ElbowBone)
        createKangarooAimConstraintFunction(eEntry_ElbowBone, eEntry_WristControl,
                                            eEntry_ElbowControl, fWorldUpVector=[0,1,0])
        controllers.setNewColumn()
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        # eWristPasser = ELEM(sEntry_WristPasser, 'Null')
        sEntry_ATTACHER_wrist_t = nodes.createGetEntryVariable('ATTACHER_wrist_t')
        sEntry_ATTACHER_wrist_r = nodes.createGetEntryVariable('ATTACHER_wrist_r')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_t, eEntry_WristPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_r, eEntry_WristPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_WristControl, 1)], eEntry_WristBone, bMaintainOffset=True) #, fWeight='Entry.Weight')
        controllers.closeCommentBox('Constraint Bones')


        controllers.openCommentBox('Fingers Control and Bone')
        controllers.setNewColumn()
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_FingersPasser = ELEM(nodes.createGetEntryVariable('FingersPasser'), 'Null')
        eEntry_FingersControl = ELEM(nodes.createGetEntryVariable('FingersControl'), 'Control')
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_WristControl, 1)], eEntry_FingersPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingersControl, 1)], eEntry_FingersBone, bMaintainOffset=True)
        controllers.closeCommentBox('Fingers Control and Bone')
        controllers.setNewColumn()


        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(cUpper.ePasser.name, '%s.UpperPasser' % sFkNode)
    pins.setString(cUpper.eControl.name, '%s.UpperControl' % sFkNode)
    pins.setString(sJoints[0], '%s.UpperBone' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.eControl.name, '%s.ElbowControl' % sFkNode)
    pins.setString(sJoints[1], '%s.ElbowBone' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.eControl.name, '%s.WristControl' % sFkNode)
    pins.setString(sJoints[2], '%s.WristBone' % sFkNode)

    pins.setString(cFingers.ePasser.name, '%s.FingersPasser' % sFkNode)
    pins.setString(cFingers.eControl.name, '%s.FingersControl' % sFkNode)
    pins.setString(sJoints[3], '%s.FingersBone' % sFkNode)

    if eAttachRootToClavicle:
        pins.setString(eAttachRootToClavicle.name, '%s.AttachToClavicle' % sFkNode)
        pins.setString(eClavicleDriver.name, '%s.ClavicleDriver' % sFkNode)

    return sFkNode



def createHorseArmLegFkSetup(cUpper, cElbow, cWrist, cFingerA, cFingerB, cFingerC, sJoints):

    sFunctionName = 'kangaroo_horseArmLegFk'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('UpperBone', 'FName', False),
                                                     ('UpperPasser', 'FName', False),
                                                     ('UpperControl', 'FName', False),
                                                     ('ElbowBone', 'FName', False),
                                                     ('ElbowPasser', 'FName', False),
                                                     ('ElbowControl', 'FName', False),
                                                     ('WristBone', 'FName', False),
                                                     ('WristPasser', 'FName', False),
                                                     ('WristControl', 'FName', False),
                                                     ('FingerBone', 'FName', False),
                                                     ('FingerAPasser', 'FName', False),
                                                     ('FingerBPasser', 'FName', False),
                                                     ('FingerCPasser', 'FName', False),
                                                     ('FingerAControl', 'FName', False),
                                                     ('FingerBControl', 'FName', False),
                                                     ('FingerCControl', 'FName', False),
                                                     ('FingerABone', 'FName', False),
                                                     ('FingerBBone', 'FName', False),
                                                     ('FingerCBone', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_t', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_r', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_t', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_r', 'FConstraintParent', True)])

        controllers.setNewColumn()

        controllers.openCommentBox('Root Attachers')
        eEntry_UpperPasser = ELEM('Entry.UpperPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eEntry_UpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_UpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noScap_t', eEntry_UpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noScap_r', eEntry_UpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_t', eEntry_UpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_r', eEntry_UpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Root Attachers')

        controllers.openCommentBox('Upper')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createPositionConstraintExecuteNode([(eEntry_UpperControl, 1)], eEntry_UpperBone)
        createKangarooAimConstraintFunction(eEntry_UpperBone, eEntry_ElbowControl, eEntry_UpperControl, fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Upper')


        controllers.openCommentBox('Rotate Elbow')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperControl, 1)], eEntry_ElbowPasser, bMaintainOffset=True)
        controllers.openCommentBox('Rotate Elbow')


        controllers.openCommentBox('Elbow')
        controllers.setNewColumn()
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createPositionConstraintExecuteNode([(eEntry_ElbowControl, 1)], eEntry_ElbowBone)
        createKangarooAimConstraintFunction(eEntry_ElbowBone, eEntry_WristControl, eEntry_ElbowControl, fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Elbow')


        controllers.openCommentBox('Wrist')
        controllers.setNewColumn()
        sEntry_ATTACHER_wrist_t = nodes.createGetEntryVariable('ATTACHER_wrist_t')
        sEntry_ATTACHER_wrist_r = nodes.createGetEntryVariable('ATTACHER_wrist_r')
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_t, eEntry_WristPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_r, eEntry_WristPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_WristControl, 1)], eEntry_WristBone, bMaintainOffset=True)
        controllers.closeCommentBox('Wrist')

        controllers.openCommentBox('Finger FKs')
        controllers.setNewColumn()
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_FingerAPasser = ELEM(nodes.createGetEntryVariable('FingerAPasser'), 'Null')
        eEntry_FingerAControl = ELEM(nodes.createGetEntryVariable('FingerAControl'), 'Control')
        eEntry_FingerABone = ELEM(nodes.createGetEntryVariable('FingerABone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_WristControl, 1)], eEntry_FingerAPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingerAControl, 1)], eEntry_FingerABone, bMaintainOffset=True)
        controllers.setNewColumn()
        eEntry_FingerBPasser = ELEM(nodes.createGetEntryVariable('FingerBPasser'), 'Null')
        eEntry_FingerBControl = ELEM(nodes.createGetEntryVariable('FingerBControl'), 'Control')
        eEntry_FingerBBone = ELEM(nodes.createGetEntryVariable('FingerBBone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_FingerAControl, 1)], eEntry_FingerBPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingerBControl, 1)], eEntry_FingerBBone, bMaintainOffset=True)
        controllers.setNewColumn()
        eEntry_FingerCPasser = ELEM(nodes.createGetEntryVariable('FingerCPasser'), 'Null')
        eEntry_FingerCControl = ELEM(nodes.createGetEntryVariable('FingerCControl'), 'Control')
        eEntry_FingerCBone = ELEM(nodes.createGetEntryVariable('FingerCBone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_FingerBControl, 1)], eEntry_FingerCPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingerCControl, 1)], eEntry_FingerCBone, bMaintainOffset=True)
        controllers.closeCommentBox('Finger FKs')

        controllers.setNewColumn()





        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(cUpper.ePasser.name, '%s.UpperPasser' % sFkNode)
    pins.setString(cUpper.eControl.name, '%s.UpperControl' % sFkNode)
    pins.setString(sJoints[0], '%s.UpperBone' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.eControl.name, '%s.ElbowControl' % sFkNode)
    pins.setString(sJoints[1], '%s.ElbowBone' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.eControl.name, '%s.WristControl' % sFkNode)
    pins.setString(cFingerA.ePasser.name, '%s.FingerAPasser' % sFkNode)
    pins.setString(cFingerB.ePasser.name, '%s.FingerBPasser' % sFkNode)
    pins.setString(cFingerC.ePasser.name, '%s.FingerCPasser' % sFkNode)
    pins.setString(cFingerA.eControl.name, '%s.FingerAControl' % sFkNode)
    pins.setString(cFingerB.eControl.name, '%s.FingerBControl' % sFkNode)
    pins.setString(cFingerC.eControl.name, '%s.FingerCControl' % sFkNode)
    pins.setString(sJoints[2], '%s.WristBone' % sFkNode)
    pins.setString(sJoints[3], '%s.FingerABone' % sFkNode)
    pins.setString(sJoints[4], '%s.FingerBBone' % sFkNode)
    pins.setString(sJoints[5], '%s.FingerCBone' % sFkNode)
    return sFkNode



def createDogArmLegFkSetup(cUpper, cElbow, cWrist, cFinger, cFingerMid, sJoints, eAttachRootToClavicle=None):

    sFunctionName = 'kangaroo_dogArmLegFk'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('UpperBone', 'FName', False),
                                                     ('UpperPasser', 'FName', False),
                                                     ('UpperControl', 'FName', False),
                                                     ('ElbowBone', 'FName', False),
                                                     ('ElbowPasser', 'FName', False),
                                                     ('ElbowControl', 'FName', False),
                                                     ('WristBone', 'FName', False),
                                                     ('WristPasser', 'FName', False),
                                                     ('WristControl', 'FName', False),
                                                     ('FingerBone', 'FName', False),
                                                     ('FingerControl', 'FName', False),
                                                     ('FingerMidBone', 'FName', False),
                                                     ('FingerMidControl', 'FName', False),
                                                     ('FingerPasser', 'FName', False),
                                                     ('FingerMidPasser', 'FName', False),
                                                     ('AttachToClavicle', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                     # ('Weight', 'float', False),
                                                     ('ATTACHER_upper_t', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_r', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_t', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_r', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_t', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_r', 'FConstraintParent', True),
                                                     ('ATTACHER_finger_t', 'FConstraintParent', True),
                                                     ('ATTACHER_finger_r', 'FConstraintParent', True),
                                                     ('ATTACHER_fingerMid_t', 'FConstraintParent', True),
                                                     ('ATTACHER_fingerMid_r', 'FConstraintParent', True)])


        controllers.openCommentBox('Attachers')
        controllers.setNewColumn()
        eUpperPasser = ELEM('Entry.UpperPasser', 'Bone')
        nodes.createParentConstraintExecuteNode([('Entry.AttachToClavicle', 1)], eUpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noScap_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers')

        controllers.openCommentBox('Rotate Elbow')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperControl, 1)], eEntry_ElbowPasser, bMaintainOffset=True)
        controllers.openCommentBox('Rotate Elbow')



        controllers.openCommentBox('Upper')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createPositionConstraintExecuteNode([(eEntry_UpperControl, 1)], eEntry_UpperBone)
        createKangarooAimConstraintFunction(eEntry_UpperBone, eEntry_ElbowControl, eEntry_UpperControl, fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Upper')

        controllers.openCommentBox('Elbow')
        controllers.setNewColumn()
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createPositionConstraintExecuteNode([(eEntry_ElbowControl, 1)], eEntry_ElbowBone)
        createKangarooAimConstraintFunction(eEntry_ElbowBone, eEntry_WristControl, eEntry_ElbowControl, fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Elbow')

        controllers.openCommentBox('Wrist')
        controllers.setNewColumn()
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        sEntry_ATTACHER_wrist_t = nodes.createGetEntryVariable('ATTACHER_wrist_t')
        sEntry_ATTACHER_wrist_r = nodes.createGetEntryVariable('ATTACHER_wrist_r')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_t, eEntry_WristPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_r, eEntry_WristPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_WristControl, 1)], eEntry_WristBone, bMaintainOffset=True)
        controllers.closeCommentBox('Wrist')

        controllers.openCommentBox('Finger')
        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_FingerPasser = ELEM(nodes.createGetEntryVariable('FingerPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_FingerPasser, bMaintainOffset=True)
        controllers.setNewColumn()
        eEntry_FingerControl = ELEM(nodes.createGetEntryVariable('FingerControl'), 'Control')
        eEntry_FingerBone = ELEM(nodes.createGetEntryVariable('FingerBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_FingerControl, 1)], eEntry_FingerBone, bMaintainOffset=True)
        controllers.closeCommentBox('Finger')

        controllers.openCommentBox('FingerMid')
        controllers.setNewColumn()
        eEntry_FingerBone = ELEM(nodes.createGetEntryVariable('FingerBone'), 'Bone')
        eEntry_FingerMidPasser = ELEM(nodes.createGetEntryVariable('FingerMidPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_FingerBone, 1)], eEntry_FingerMidPasser, bMaintainOffset=True)
        controllers.setNewColumn()
        eEntry_FingerMidControl = ELEM(nodes.createGetEntryVariable('FingerMidControl'), 'Control')
        eEntry_FingerMidBone = ELEM(nodes.createGetEntryVariable('FingerMidBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_FingerMidControl, 1)], eEntry_FingerMidBone, bMaintainOffset=True)
        controllers.openCommentBox('FingerMid')

        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(cUpper.ePasser.name, '%s.UpperPasser' % sFkNode)
    pins.setString(cUpper.eControl.name, '%s.UpperControl' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.eControl.name, '%s.ElbowControl' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.eControl.name, '%s.WristControl' % sFkNode)
    pins.setString(cFinger.eControl.name, '%s.FingerControl' % sFkNode)
    pins.setString(cFingerMid.eControl.name, '%s.FingerMidControl' % sFkNode)
    pins.setString(cFinger.ePasser.name, '%s.FingerPasser' % sFkNode)
    pins.setString(cFingerMid.ePasser.name, '%s.FingerMidPasser' % sFkNode)
    pins.setString(sJoints[0], '%s.UpperBone' % sFkNode)
    pins.setString(sJoints[1], '%s.ElbowBone' % sFkNode)
    pins.setString(sJoints[2], '%s.WristBone' % sFkNode)
    pins.setString(sJoints[3], '%s.FingerBone' % sFkNode)
    pins.setString(sJoints[4], '%s.FingerMidBone' % sFkNode)

    if eAttachRootToClavicle:
        pins.setString(eAttachRootToClavicle.name, '%s.AttachToClavicle' % sFkNode)

    return sFkNode


def createDogArmLegFkSetup_BACKWARDS(cUpper, cElbow, cWrist, cFinger, cFingerMid, sJoints, eAttachRootToClavicle=None):

    sFunctionName = 'kangaroo_dogArmLegFk_BACKWARDS'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('UpperBone', 'FName', False),
                                                     ('UpperPasser', 'FName', False),
                                                     ('UpperControl', 'FName', False),
                                                     ('ElbowBone', 'FName', False),
                                                     ('ElbowPasser', 'FName', False),
                                                     ('ElbowControl', 'FName', False),
                                                     ('WristBone', 'FName', False),
                                                     ('WristPasser', 'FName', False),
                                                     ('WristControl', 'FName', False),
                                                     ('FingerBone', 'FName', False),
                                                     ('FingerPasser', 'FName', False),
                                                     ('FingerControl', 'FName', False),
                                                     ('FingerMidBone', 'FName', False),
                                                     ('FingerMidPasser', 'FName', False),
                                                     ('FingerMidControl', 'FName', False),
                                                     ('AttachToClavicle', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                     # ('Weight', 'float', False),
                                                     ('ATTACHER_upper_t', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_r', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_t', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_r', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_t', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_r', 'FConstraintParent', True),
                                                     ('ATTACHER_finger_t', 'FConstraintParent', True),
                                                     ('ATTACHER_finger_r', 'FConstraintParent', True),
                                                     ('ATTACHER_fingerMid_t', 'FConstraintParent', True),
                                                     ('ATTACHER_fingerMid_r', 'FConstraintParent', True)])

        controllers.openCommentBox('Attachers')
        controllers.setNewColumn()
        eEntry_UpperPasser = ELEM(nodes.createGetEntryVariable('UpperPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([('Entry.AttachToClavicle', 1)], eEntry_UpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noScap_r', eEntry_UpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_UpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_r', eEntry_UpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers')



        controllers.openCommentBox('Upper')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_UpperControl, bMaintainOffset=True) # , fWeight='Entry.Weight'
        controllers.closeCommentBox('Upper')

        controllers.openCommentBox('Elbow')
        controllers.setNewColumn()
        sEntry_ATTACHER_elbow_t = nodes.createGetEntryVariable('ATTACHER_elbow_t')
        sEntry_ATTACHER_elbow_r = nodes.createGetEntryVariable('ATTACHER_elbow_r')
        eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_elbow_t, eEntry_ElbowPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_elbow_r, eEntry_ElbowPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_ElbowBone, 1)], eEntry_ElbowControl, bMaintainOffset=True) #, fWeight='Entry.Weight')
        controllers.closeCommentBox('Elbow')

        controllers.openCommentBox('Wrist')
        controllers.setNewColumn()
        sEntry_ATTACHER_wrist_t = nodes.createGetEntryVariable('ATTACHER_wrist_t')
        sEntry_ATTACHER_wrist_r = nodes.createGetEntryVariable('ATTACHER_wrist_r')
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_t, eEntry_WristPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_r, eEntry_WristPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_WristControl, bMaintainOffset=True) #, fWeight='Entry.Weight')
        controllers.closeCommentBox('Wrist')

        controllers.openCommentBox('Finger')
        controllers.setNewColumn()
        eEntry_ATTACHER_finger_t = nodes.createGetEntryVariable('ATTACHER_finger_t')
        eEntry_ATTACHER_finger_r = nodes.createGetEntryVariable('ATTACHER_finger_r')
        eEntry_FingerPasser = ELEM(nodes.createGetEntryVariable('FingerPasser'), 'Null')
        eEntry_FingerBone = ELEM(nodes.createGetEntryVariable('FingerBone'), 'Bone')
        eEntry_FingerControl = ELEM(nodes.createGetEntryVariable('FingerControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(eEntry_ATTACHER_finger_t, eEntry_FingerPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(eEntry_ATTACHER_finger_r, eEntry_FingerPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_FingerBone, 1)], eEntry_FingerControl, bMaintainOffset=True)
        controllers.closeCommentBox('Finger')


        controllers.openCommentBox('FingerMid')
        controllers.setNewColumn()
        sEntry_ATTACHER_fingerMid_t = nodes.createGetEntryVariable('ATTACHER_fingerMid_t')
        sEntry_ATTACHER_fingerMid_r = nodes.createGetEntryVariable('ATTACHER_fingerMid_r')
        eEntry_FingerMidPasser = ELEM(nodes.createGetEntryVariable('FingerMidPasser'), 'Null')
        eEntry_FingerMidBone = ELEM(nodes.createGetEntryVariable('FingerMidBone'), 'Bone')
        eEntry_FingerMidControl = ELEM(nodes.createGetEntryVariable('FingerMidControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_fingerMid_t, eEntry_FingerMidPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_fingerMid_r, eEntry_FingerMidPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_FingerMidBone, 1)], eEntry_FingerMidControl, bMaintainOffset=True) #, fWeight='Entry.Weight')
        controllers.openCommentBox('FingerMid')


        controllers.setNewColumn()


        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(cUpper.ePasser.name, '%s.UpperPasser' % sFkNode)
    pins.setString(cUpper.eControl.name, '%s.UpperControl' % sFkNode)
    pins.setString(sJoints[0], '%s.UpperBone' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.eControl.name, '%s.ElbowControl' % sFkNode)
    pins.setString(sJoints[1], '%s.ElbowBone' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.eControl.name, '%s.WristControl' % sFkNode)
    pins.setString(cFinger.ePasser.name, '%s.FingerPasser' % sFkNode)
    pins.setString(cFinger.eControl.name, '%s.FingerControl' % sFkNode)
    pins.setString(cFingerMid.ePasser.name, '%s.FingerMidPasser' % sFkNode)
    pins.setString(cFingerMid.eControl.name, '%s.FingerMidControl' % sFkNode)
    pins.setString(sJoints[2], '%s.WristBone' % sFkNode)
    pins.setString(sJoints[3], '%s.FingerBone' % sFkNode)
    pins.setString(sJoints[4], '%s.FingerMidBone' % sFkNode)

    if eAttachRootToClavicle:
        pins.setString(eAttachRootToClavicle.name, '%s.AttachToClavicle' % sFkNode)

    return sFkNode


def createHorseArmLegFkSetup_BACKWARDS(cUpper, cElbow, cWrist, cFingerA, cFingerB, cFingerC, sJoints):

    sFunctionName = 'kangaroo_horseArmLegFk_BACKWARDS'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('UpperBone', 'FName', False),
                                                     ('UpperPasser', 'FName', False),
                                                     ('UpperControl', 'FName', False),
                                                     ('ElbowBone', 'FName', False),
                                                     ('ElbowPasser', 'FName', False),
                                                     ('ElbowControl', 'FName', False),
                                                     ('WristBone', 'FName', False),
                                                     ('WristPasser', 'FName', False),
                                                     ('WristControl', 'FName', False),
                                                     ('FingerABone', 'FName', False),
                                                     ('FingerAPasser', 'FName', False),
                                                     ('FingerAControl', 'FName', False),
                                                     ('FingerBBone', 'FName', False),
                                                     ('FingerBPasser', 'FName', False),
                                                     ('FingerBControl', 'FName', False),
                                                     ('FingerCBone', 'FName', False),
                                                     ('FingerCPasser', 'FName', False),
                                                     ('FingerCControl', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_t', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_r', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_t', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_r', 'FConstraintParent', True)])

        controllers.setNewColumn()
        eEntry_UpperPassser = ELEM('Entry.UpperPasser', 'Null')
        controllers.openCommentBox('Root Attachers')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eEntry_UpperPassser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_UpperPassser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noScap_t', eEntry_UpperPassser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noScap_r', eEntry_UpperPassser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_t', eEntry_UpperPassser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_r', eEntry_UpperPassser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Root Attachers')


        controllers.openCommentBox('Upper')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_UpperControl, bMaintainOffset=True)
        controllers.closeCommentBox('Upper')

        controllers.openCommentBox('Rotate Elbow Passer')
        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperControl, 1)], eEntry_ElbowPasser, bMaintainOffset=True)
        controllers.openCommentBox('Rotate Elbow Passer')


        controllers.openCommentBox('Elbow')
        controllers.setNewColumn()
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_ElbowBone, 1)], eEntry_ElbowControl,  bMaintainOffset=True)
        controllers.closeCommentBox('Elbow')

        controllers.openCommentBox('Wrist')
        controllers.setNewColumn()
        eEntry_ATTACHER_wrist_t = nodes.createGetEntryVariable('ATTACHER_wrist_t')
        eEntry_ATTACHER_wrist_r = nodes.createGetEntryVariable('ATTACHER_wrist_r')
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(eEntry_ATTACHER_wrist_t, eEntry_WristPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(eEntry_ATTACHER_wrist_r, eEntry_WristPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_WristControl, bMaintainOffset=True)
        controllers.closeCommentBox('Wrist')

        controllers.openCommentBox('Finger FK A')
        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_FingerABone = ELEM(nodes.createGetEntryVariable('FingerABone'), 'Bone')
        eEntry_FingerAControl = ELEM(nodes.createGetEntryVariable('FingerAControl'), 'Control')
        eEntry_FingerAPasser = ELEM(nodes.createGetEntryVariable('FingerAPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_FingerAPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingerABone, 1)], eEntry_FingerAControl, bMaintainOffset=True)
        controllers.closeCommentBox('Finger FK A')


        controllers.openCommentBox('Finger FK B')
        eEntry_FingerBBone = ELEM(nodes.createGetEntryVariable('FingerBBone'), 'Bone')
        eEntry_FingerBControl = ELEM(nodes.createGetEntryVariable('FingerBControl'), 'Control')
        eEntry_FingerBPasser = ELEM(nodes.createGetEntryVariable('FingerBPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_FingerABone, 1)], eEntry_FingerBPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingerBBone, 1)], eEntry_FingerBControl, bMaintainOffset=True)
        controllers.closeCommentBox('Finger FK B')

        controllers.openCommentBox('Finger FK C')
        eEntry_FingerCBone = ELEM(nodes.createGetEntryVariable('FingerCBone'), 'Bone')
        eEntry_FingerCControl = ELEM(nodes.createGetEntryVariable('FingerCControl'), 'Control')
        eEntry_FingerCPasser = ELEM(nodes.createGetEntryVariable('FingerCPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_FingerBBone, 1)], eEntry_FingerCPasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_FingerCBone, 1)], eEntry_FingerCControl, bMaintainOffset=True)
        controllers.closeCommentBox('Finger FK C')

        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(cUpper.ePasser.name, '%s.UpperPasser' % sFkNode)
    pins.setString(cUpper.eControl.name, '%s.UpperControl' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.eControl.name, '%s.ElbowControl' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.eControl.name, '%s.WristControl' % sFkNode)

    pins.setString(cFingerA.ePasser.name, '%s.FingerAPasser' % sFkNode)
    pins.setString(cFingerA.eControl.name, '%s.FingerAControl' % sFkNode)
    pins.setString(cFingerB.ePasser.name, '%s.FingerBPasser' % sFkNode)
    pins.setString(cFingerB.eControl.name, '%s.FingerBControl' % sFkNode)
    pins.setString(cFingerC.ePasser.name, '%s.FingerCPasser' % sFkNode)
    pins.setString(cFingerC.eControl.name, '%s.FingerCControl' % sFkNode)

    # pins.connectToPin1D(1.0, '%s.Weight' % sFkNode)
    pins.setString(sJoints[0], '%s.UpperBone' % sFkNode)
    pins.setString(sJoints[1], '%s.ElbowBone' % sFkNode)
    pins.setString(sJoints[2], '%s.WristBone' % sFkNode)
    pins.setString(sJoints[3], '%s.FingerABone' % sFkNode)
    pins.setString(sJoints[4], '%s.FingerBBone' % sFkNode)
    pins.setString(sJoints[5], '%s.FingerCBone' % sFkNode)
    return sFkNode


def createHumanArmLegFkSetup_BACKWARDS(cUpper, cElbow, cWrist, cFingers, sJoints, sLastUpperTwist, eAttachRootToClavicle=None):

    sFunctionName = 'kangaroo_armFk_backwards'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('UpperBone', 'FName', False),
                                                     ('UpperBoneLastTwist', 'FName', False),
                                                     ('UpperPasser', 'FName', False),
                                                     ('UpperControl', 'FName', False),
                                                     ('ElbowBone', 'FName', False),
                                                     ('ElbowPasser', 'FName', False),
                                                     ('ElbowControl', 'FName', False),
                                                     ('WristBone', 'FName', False),
                                                     ('WristPasser', 'FName', False),
                                                     ('WristControl', 'FName', False),
                                                     ('FingersBone', 'FName', False),
                                                     ('FingersPasser', 'FName', False),
                                                     ('FingersControl', 'FName', False),
                                                     ('AttachToClavicle', 'FName', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noClav_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_noClav_r', 'FConstraintParent', True),
                                                     # ('Weight', 'float', False),
                                                     ('ATTACHER_upper_t', 'FConstraintParent', True),
                                                     ('ATTACHER_upper_r', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_t', 'FConstraintParent', True),
                                                     ('ATTACHER_elbow_r', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_t', 'FConstraintParent', True),
                                                     ('ATTACHER_wrist_r', 'FConstraintParent', True)])


        controllers.openCommentBox('upper')
        eUpperPasser = ELEM('Entry.UpperPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eUpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z']) # is that ok also for Auto Clav?!
        nodes.createParentConstraintExecuteNode([(ELEM('Entry.AttachToClavicle', 'Control'), 1.0)], eUpperPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_noClav_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_upper_r', eUpperPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])

        controllers.setNewColumn()
        eEntry_UpperControl = ELEM(nodes.createGetEntryVariable('UpperControl'), 'Control')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_UpperBoneLastTwist = ELEM(nodes.createGetEntryVariable('UpperBoneLastTwist'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1.0)], eEntry_UpperControl, skipRotate=['x', 'y', 'z'], bMaintainOffset=True) #, fWeight='Entry.Weight')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBoneLastTwist, 1.0)], eEntry_UpperControl, skipTranslate=['x', 'y', 'z'], bMaintainOffset=True) #, fWeight='Entry.Weight')
        controllers.closeCommentBox('upper')



        controllers.openCommentBox('elbow')
        controllers.setNewColumn()
        sEntry_ATTACHER_elbow_t = nodes.createGetEntryVariable('ATTACHER_elbow_t')
        sEntry_ATTACHER_elbow_r = nodes.createGetEntryVariable('ATTACHER_elbow_r')
        eEntry_ElbowPasser = ELEM(nodes.createGetEntryVariable('ElbowPasser'), 'Null')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_ElbowControl = ELEM(nodes.createGetEntryVariable('ElbowControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_elbow_t, eEntry_ElbowPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_elbow_r, eEntry_ElbowPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_ElbowBone, 1)], eEntry_ElbowControl, bMaintainOffset=True)
        controllers.closeCommentBox('elbow')



        controllers.openCommentBox('wrist')
        controllers.setNewColumn()
        sEntry_ATTACHER_wrist_t = nodes.createGetEntryVariable('ATTACHER_wrist_t')
        sEntry_ATTACHER_wrist_r = nodes.createGetEntryVariable('ATTACHER_wrist_r')
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_t, eEntry_WristPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_wrist_r, eEntry_WristPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_WristControl, bMaintainOffset=True)
        controllers.closeCommentBox('wrist')

        controllers.openCommentBox('Fingers Bone')
        controllers.setNewColumn()
        eEntry_eFingersPasser = ELEM(nodes.createGetEntryVariable('FingersPasser'), 'Null')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_eFingersPasser, bMaintainOffset=True)
        controllers.setNewColumn()
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
        eEntry_FingersControl = ELEM(nodes.createGetEntryVariable('FingersControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_FingersBone, 1)], eEntry_FingersControl, bMaintainOffset=True)
        controllers.closeCommentBox('Fingers Bone')

        controllers.setNewColumn()





        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(cUpper.ePasser.name, '%s.UpperPasser' % sFkNode)
    pins.setString(cUpper.eControl.name, '%s.UpperControl' % sFkNode)
    pins.setString(sJoints[0], '%s.UpperBone' % sFkNode)
    pins.setString(sLastUpperTwist, '%s.UpperBoneLastTwist' % sFkNode)
    pins.setString(cElbow.ePasser.name, '%s.ElbowPasser' % sFkNode)
    pins.setString(cElbow.eControl.name, '%s.ElbowControl' % sFkNode)
    pins.setString(sJoints[1], '%s.ElbowBone' % sFkNode)
    pins.setString(cWrist.ePasser.name, '%s.WristPasser' % sFkNode)
    pins.setString(cWrist.eControl.name, '%s.WristControl' % sFkNode)
    pins.setString(sJoints[2], '%s.WristBone' % sFkNode)
    pins.setString(cFingers.ePasser.name, '%s.FingersPasser' % sFkNode)
    pins.setString(cFingers.eControl.name, '%s.FingersControl' % sFkNode)
    pins.setString(sJoints[3], '%s.FingersBone' % sFkNode)
    if eAttachRootToClavicle:
        pins.setString(eAttachRootToClavicle.name, '%s.AttachToClavicle' % sFkNode)

    return sFkNode



def createFkChainCtrlsSetupBACKWARDS(eRoot, xxCtrlBonePairs, bSpline=False):

    iLength = len(xxCtrlBonePairs)
    sFunctionName = 'kangaroo_fkChain_%dBones%s_BACKWARDS' % (iLength, '_spline' if bSpline else '')

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xProceduralInputs = []
        for i in range(iLength):
            xProceduralInputs.append(('Bone_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Control_%d' % i, 'FRigElementKey', False))
            xProceduralInputs.append(('Passer_%d' % i, 'FRigElementKey', False))
            if i > 0:
                if bSpline:
                    xProceduralInputs.append(('ATTACHER_fkSpline_%s_t' % library.getLetter(i-1), 'FConstraintParent', True))
                    xProceduralInputs.append(('ATTACHER_fkSpline_%s_r' % library.getLetter(i-1), 'FConstraintParent', True))
                else:
                    xProceduralInputs.append(('ATTACHER_fk_%02d_t' % i, 'FConstraintParent', True))
                    xProceduralInputs.append(('ATTACHER_fk_%02d_r' % i, 'FConstraintParent', True))

        nodes.startFunction(sFunctionName, xInputs= [('Root', 'FRigElementKey', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ] + xProceduralInputs)

        controllers.setNewColumn()

        for i in range(iLength):
            controllers.openCommentBox('Bone %d' % i)

            controllers.setNewColumn()
            if i == 0:
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Root', bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Root', bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
            else:
                if bSpline:
                    nodes.createParentConstraintExecuteNode('Entry.ATTACHER_fkSpline_%s_t' % library.getLetter(i-1), 'Entry.Passer_%d' % i, bMaintainOffset=True, skipRotate=['x','y','z'])
                    nodes.createParentConstraintExecuteNode('Entry.ATTACHER_fkSpline_%s_r' % library.getLetter(i-1), 'Entry.Passer_%d' % i, bMaintainOffset=True, skipTranslate=['x','y','z'])
                else:
                    nodes.createParentConstraintExecuteNode('Entry.ATTACHER_fk_%02d_t' % i, 'Entry.Passer_%d' % i, bMaintainOffset=True, skipRotate=['x','y','z'])
                    nodes.createParentConstraintExecuteNode('Entry.ATTACHER_fk_%02d_r' % i, 'Entry.Passer_%d' % i, bMaintainOffset=True, skipTranslate=['x','y','z'])

            controllers.setNewColumn()
            nodes.createParentConstraintExecuteNode([('Entry.Bone_%d' % i, 1)], 'Entry.Control_%d' % i, bMaintainOffset=True)
            controllers.setNewColumn()

            controllers.closeCommentBox('Bone %d' % i)
        controllers.setNewColumn()




        
        nodes.endCurrentFunction(bAddToExecute=False)

    sFkNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eRoot, '%s.Root' % sFkNode)
    iCounter = 0
    for cCtrl, sBone in xxCtrlBonePairs:
        pins.connectItem(cCtrl.ePasser, '%s.Passer_%d' % (sFkNode, iCounter))
        pins.connectItem(cCtrl.eControl, '%s.Control_%d' % (sFkNode, iCounter))
        pins.connectItem(ELEM(sBone, 'Bone'), '%s.Bone_%d' % (sFkNode, iCounter))
        iCounter += 1

    # pins.setItemArray([cC.eControl for cC,_ in xxCtrlBonePairs], '%s.Controls' % sFkNode)
    # pins.setItemArray([cC.ePasser for cC,_ in xxCtrlBonePairs], '%s.Passers' % sFkNode)
    # pins.setItemArray([ELEM(sJ, 'Bone') for _,sJ in xxCtrlBonePairs], '%s.Bones' % sFkNode)

    return sFkNode


def createFkChainCtrlsSetupOld(xxCtrlBonePairs, sComments=None, sSide='l'):


    controllers.setNewColumn()
    eControls = [xPair[0].eOut for xPair in xxCtrlBonePairs]
    eBones = [ELEM(xPair[1], 'Bone') for xPair in xxCtrlBonePairs]

    sBonesArray = nodes.createHierarchyTransformArrayNode(eBones)
    sCtrlsArray = nodes.createHierarchyTransformArrayNode(eControls)

    controllers.setNewColumn()
    sForEachNode = nodes.createForEachExecuteNode(sBonesArray)
    sCtrlElement = nodes.createArrayAtNode(sCtrlsArray, '%s.Index' % sForEachNode)
    # sCtrlGetTransform = nodes.getTransformNode(sCtrlElement)

    sExecuteNodes = []
    controllers.setNewColumn()
    sExecuteNodes.append(nodes.createParentConstraintExecuteNode([sCtrlElement], '%s.Element' % sForEachNode, bMaintainOffset=True))
    # sExecuteNodes.append(nodes.createSetTransformExecuteNode('%s.Element' % sForEachNode, sCtrlGetTransform))

    controllers.goToParentExecute()

    return sExecuteNodes



#
# def limbIkSetupOld(eIk, ePole, eRollAttr, sBones, sSide='l', bIsLeg=False):
#
#     # if sComments:
#     #     controllers.openCommentBox()
#
#     controllers.setNewColumn()
#     eBones = [ELEM(sJ, 'Bone') for sJ in sBones]
#
#     # sParentConstraint = nodes.createParentConstraintExecuteNode([eIk], eBones[2], bMaintainOffset=True)
#     # sGetTipTransforms = nodes.createGetTransformsExecute([eBones[3], eBones[4]])
#
#     sAnkle = nodes.getTransformNode(eBones[2])
#     sFinger = nodes.getTransformNode(eBones[3])
#     sAnkleInitial = nodes.getTransformNode(eBones[2], bInitial=True)
#     sFingerInitial = nodes.getTransformNode(eBones[3], bInitial=True)
#     sEndInitial = nodes.getTransformNode(eBones[4], bInitial=True)
#
#     sCtrl = nodes.getTransformNode(eIk)
#     sCtrlInitial = nodes.getTransformNode(eIk, bInitial=True)
#     controllers.setNewColumn(2)
#     sAnkleLocal = nodes.createMakeRelativeNode(sAnkleInitial, sCtrlInitial)
#     sFingerLocal = nodes.createMakeRelativeNode(sFingerInitial, sCtrlInitial)
#     sAnkleMoved = nodes.createMakeAbsoluteNode(sAnkleLocal, sCtrl)
#     sFingerMoved = nodes.createMakeAbsoluteNode(sFingerLocal, sCtrl)
#     sEndLocal = nodes.createMakeRelativeNode(sEndInitial, sCtrlInitial)
#     sEndMoved = nodes.createMakeAbsoluteNode(sEndLocal, sCtrl)
#
#     controllers.setNewColumn()
#     sSetAnkleTransform = nodes.createSetTransformExecuteNode(eBones[2], sAnkleMoved)
#
#
#     fSideMultipl = -1.0 if sSide == 'r' else 1.0
#
#     sFloatValue = nodes.createGetFloatControlNode(eRollAttr.name)
#     sNegMultipl = nodes.createBasicCalculateNode([sFloatValue, -1], sOperation='Multiply')
#     sRevAnkleEuler = nodes.createFromEulerNode([None, None, sNegMultipl])
#
#     sRotPointTransformInitial = ['%s.Translation' % sFingerInitial, '%s.Rotation' % sAnkleInitial, None]
#     sAnkleOffset = nodes.createMakeRelativeNode(sAnkleInitial, sRotPointTransformInitial)
#     sRotPointTransform = ['%s.Translation' % sFinger, '%s.Rotation' % sAnkle, None]
#     sRotated = nodes.createMakeAbsoluteNode([None, sRevAnkleEuler, None], sRotPointTransform)
#
#     sEffector = nodes.createMakeAbsoluteNode(sAnkleOffset, sRotated)
#
#     sPoleTransform = nodes.getTransformNode(ePole)
#     controllers.setNewColumn()
#     sLegIk = nodes.createIkExecuteNode(eBones[0], eBones[1], eBones[2], sEffector, fPrimaryAxis=[fSideMultipl,0,0], fSeconaryAxis=[0,fSideMultipl,0], sPoleTarget='%s.Translation' % sPoleTransform)
#
#     # controllers.latestFD().vmModel.add_link('%s.Translation' % sPoleTransform, '%s.PoleVector' % sLegIk)
#     # controllers.latestFD().vmModel.set_pin_default_value('%s.PoleVectorKind' % sLegIk, 'Location', True)
#
#     # sFingerAimTarget = nodes.createArrayAtNode('%s.positions' % sGetTipTransforms, 0)
#     # sEndAimTarget = nodes.createArrayAtNode('%s.positions' % sGetTipTransforms, 1)
#     controllers.setNewColumn()
#     sAnkleAim = nodes.createAimExecuteNode(eBones[2], '%s.Translation' % sFingerMoved, fAimVector=[fSideMultipl, 0, 0])
#
#     sAnkleIked = nodes.getTransformNode(eBones[2])
#     sUp = nodes.createMakeAbsoluteNode([[0,1,0], None, None], sAnkleIked)
#     pins.connectToPinVector('%s.Translation' % sUp, '%s.Secondary.Target' % sAnkleAim)
#
#     sFingerIked = nodes.getTransformNode(eBones[3])
#     sUp = nodes.createMakeAbsoluteNode([[0,1,0], None, None], sFingerIked)
#     controllers.setNewColumn()
#     sFingerAim = nodes.createAimExecuteNode(eBones[3], '%s.Translation' % sEndMoved, fAimVector=[fSideMultipl, 0, 0])
#     pins.connectToPinVector('%s.Translation' % sUp, '%s.Secondary.Target' % sFingerAim)
#
#     return [sSetAnkleTransform, sLegIk, sAnkleAim, sFingerAim]
#


def softIk(sCtrlName, sUpperLength, sLowerLength, sUpperBone, sIkEffector):
    sFunctionName = 'kangaroo_softIk'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('CtrlName', 'FName', None),
                                                 # ('AttrName', 'FName', None),
                                                 ('UpperLength', 'float', None),
                                                 ('LowerLength', 'float', None),
                                                 ('UpperBone', 'FRigElementKey', False),
                                                 ('IkEffector', 'FTransform', None)],
                                         xOutputs=[('IkEffectorOut', 'FTransform', False),
                                                   ('ScaleClamped', 'float', False)], bMutable=False)
        

        controllers.setNewColumn()
        
        sTopBoneTransform = nodes.getTransformNode('Entry.UpperBone')
        sDistance = nodes.createGetDistanceNode('%s.Translation' % sTopBoneTransform, 'Entry.IkEffector.Translation')

        sStretchedDistance = nodes.createBasicCalculateNode(['Entry.UpperLength', 'Entry.LowerLength'], sOperation='Add')
        sSoftIkControlValue = nodes.createGetChannelNode2('Entry.CtrlName', 'softIk')
        sStretchAttr = nodes.createGetChannelNode2('Entry.CtrlName', 'stretch')
        sSoftIkValue = nodes.createBasicCalculateNode([sSoftIkControlValue, 0.1], sOperation='Multiply')
        sSoftIkReverse = nodes.createBasicCalculateNode([1.0, sSoftIkValue], sOperation='Subtract')
        sDistanceNormalized = nodes.createBasicCalculateNode([sDistance, sStretchedDistance], sOperation='Divide')

        controllers.setNewColumn()
        sA = nodes.createBasicCalculateNode([sSoftIkReverse, sDistanceNormalized], sOperation='Subtract')
        sB = nodes.createBasicCalculateNode([sA, sSoftIkValue], sOperation='Divide')
        sC = nodes.createBasicCalculateNode([math.e, sB], sOperation='Power')
        sD = nodes.createBasicCalculateNode([1.0, sC], sOperation='Subtract')
        sE = nodes.createBasicCalculateNode([sSoftIkValue, sD], sOperation='Multiply')
        sSoftExpr = nodes.createBasicCalculateNode([sE, sSoftIkReverse], sOperation='Add')

        controllers.setNewColumn()
        sCondDistanceBiggerThanOne = nodes.createConditionNodes(sDistanceNormalized, '>', 1.0, 1.0, sDistanceNormalized, iPinType=pins.PinType.double)
        sCondSoftBiggerThanOne = nodes.createConditionNodes(sSoftIkValue, '>', 0.0, sSoftExpr, sCondDistanceBiggerThanOne, iPinType=pins.PinType.double)
        sSoft = nodes.createConditionNodes(sDistanceNormalized, '>', sSoftIkReverse, sCondSoftBiggerThanOne, sCondDistanceBiggerThanOne, iPinType=pins.PinType.double)
        sSoftRatio = nodes.createBasicCalculateNode([sDistanceNormalized, sSoft], sOperation='Divide')

        controllers.openCommentBox('Stretch')
        controllers.setNewColumn()
        sOneMinusStretch = nodes.createBasicCalculateNode([1.0, sStretchAttr], sOperation='Subtract')
        sDividedBySoftRatio = nodes.createBasicCalculateNode([sOneMinusStretch, sSoftRatio], sOperation='Divide')
        sConstrWeight = nodes.createBasicCalculateNode([sStretchAttr, sDividedBySoftRatio], sOperation='Add')
        # sConstrWeight = nodes.createBasicCalculateNode([1.0, sSoftRatio], sOperation='Divide')
        controllers.closeCommentBox('Stretch')


        controllers.openCommentBox('Scale Limbs')
        # sScaleClamped = nodes.fromEquation('%s * %s + 1.0 - %s' % (sSoftRatio, sStretchAttr, sStretchAttr))
        sSoftRatioByStretch = nodes.createBasicCalculateNode([sSoftRatio, sStretchAttr], sOperation='Multiply')
        sOneAdded = nodes.createBasicCalculateNode([sSoftRatioByStretch, 1.0], sOperation='Add')
        sScaleClamped = nodes.createBasicCalculateNode([sOneAdded, sStretchAttr], sOperation='Subtract')
        pins.connectToPin1D(sScaleClamped, 'Return.ScaleClamped')
        controllers.closeCommentBox('Scale Limbs')

        sInterpolatedEffector = nodes.createVectorInterpolateNode(sConstrWeight, '%s.Translation' % sTopBoneTransform, 'Entry.IkEffector.Translation')
        pins.connectToPinTransform([sInterpolatedEffector, 'Entry.IkEffector.Rotation', [1,1,1]], 'Return.IkEffectorOut')
        
        nodes.endCurrentFunction(bAddToExecute=False)

    sSoftIkNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)
    pins.connectToPin1D(sCtrlName, '%s.CtrlName' % sSoftIkNode)
    # pins.setString('softIk', '%s.AttrName' % sSoftIkNode)
    pins.connectItem(sUpperBone, '%s.UpperBone' % sSoftIkNode)
    pins.connectToPin1D(sUpperLength, '%s.UpperLength' % sSoftIkNode)
    pins.connectToPin1D(sLowerLength, '%s.LowerLength' % sSoftIkNode)
    pins.connectToPinTransform(sIkEffector, '%s.IkEffector' % sSoftIkNode)
    return '%s.IkEffectorOut' % sSoftIkNode


# ('l', scapula_l_ctrl, 'jnt_l_scapulaStart', 'jnt_m_spineSpine_end', eStrPivot_l_scapula, 'l_arm')
def createScapulaFunction(sSide, cCtrl, sJoint, sParentJoint, ePivot, sAutoDriverLimb):

    hierarchy.createFloatControl('autoVert', eParent=cCtrl.eControl, fRange=[0,1], fDefault=0.0)
    hierarchy.createFloatControl('autoHoriz', eParent=cCtrl.eControl, fRange=[0,1], fDefault=0.0)
    hierarchy.createFloatControl('autoRot', eParent=cCtrl.eControl, fRange=[0,1], fDefault=0.0)
    eAutoGrp = cCtrl.addOffset('auto')

    sFunctionName = 'kangaroo_scapula'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Bone', 'FName', False),
                                                 ('ParentBone', 'FName', False),
                                                 ('Control', 'FName', False),
                                                 ('Passer', 'FName', False),
                                                 ('Pivot', 'FName', False),
                                                 ('AutoOffset', 'FName', False),
                                                 ('AnklePasser', 'FName', False),
                                                 ('AnkleControl', 'FName', False),
                                                 ('AnkleBone', 'FName', False),
                                                 ('FootIkControl', 'FName', False),
                                                 ('Negative', 'bool', False),
                                                 ('ATTACHER_root_r', 'FConstraintParent', True),
                                                 ('ATTACHER_root_t', 'FConstraintParent', True)])

        eEntry_Pivot = ELEM('Entry.Pivot', 'Null')
        eEntry_Passer = ELEM('Entry.Passer', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eEntry_Pivot, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_Pivot, bMaintainOffset=True, skipTranslate=['x','y','z'])
        nodes.createParentConstraintExecuteNode([(eEntry_Pivot, 1.0)], eEntry_Passer, bMaintainOffset=True)


        controllers.openCommentBox('Auto HorizVert')
        controllers.setNewColumn()
        eEntry_AnkleBone = ELEM(nodes.createGetEntryVariable('AnkleBone'), 'Bone')
        eEntry_AnklePasser = ELEM(nodes.createGetEntryVariable('AnklePasser'), 'Null')
        controllers.setNewColumn()
        sAnkleBoneInitial = nodes.getTransformNode(eEntry_AnkleBone, bInitial=True)
        sAnklePasserInitial = nodes.getTransformNode(eEntry_AnklePasser, bInitial=True)
        sBoneOffset = nodes.createMakeRelativeNode(sAnkleBoneInitial, sAnklePasserInitial)

        controllers.setNewColumn()
        eEntry_AnklePasser = ELEM(nodes.createGetEntryVariable('AnklePasser'), 'Null')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        controllers.setNewColumn()
        sAnklePasser = nodes.getTransformNode(eEntry_AnklePasser)
        sAnkleControlLocal = nodes.getTransformNode(eEntry_AnkleControl, bLocal=True)
        sAnimatedAnkle = nodes.createMakeAbsoluteNode(sAnkleControlLocal, sAnklePasser)
        sAnimatedAnkleBone = nodes.createMakeAbsoluteNode(sBoneOffset, sAnimatedAnkle)

        controllers.setNewColumn()
        eEntry_Passer = ELEM(nodes.createGetEntryVariable('Passer'), 'Null')
        controllers.setNewColumn()
        sParentPasserInitial = nodes.getTransformNode(eEntry_Passer, bInitial=True)
        sParentPasser = nodes.getTransformNode(eEntry_Passer)
        controllers.setNewColumn()
        sLocalAnkleBoneInitial = nodes.createMakeRelativeNode(sAnkleBoneInitial, sParentPasserInitial)
        sLocalAnkleBone = nodes.createMakeRelativeNode(sAnimatedAnkleBone, sParentPasser)

        controllers.setNewColumn()
        sFootDiff = nodes.createBasicCalculateNode(['%s.Translation' % sLocalAnkleBone, '%s.Translation' % sLocalAnkleBoneInitial], sOperation='Subtract', iPinType=pins.PinType.vector)

        controllers.setNewColumn()
        sEntry_Control = nodes.createGetEntryVariable('Control')
        eEntry_AutoOffset = ELEM(nodes.createGetEntryVariable('AutoOffset'), 'Null')
        controllers.setNewColumn()
        sAutoScapulaVertAttr = nodes.createGetChannelNode2(sEntry_Control, 'autoVert')
        sAutoScapulaHorizAttr = nodes.createGetChannelNode2(sEntry_Control, 'autoHoriz')
        sAutoScapulaDistance = nodes.createBasicCalculateNode([[0, sAutoScapulaHorizAttr, sAutoScapulaVertAttr], sFootDiff], iPinType=pins.PinType.vector)
        nodes.createSetTransformExecuteNode(eEntry_AutoOffset,  [[0,'%s.Y' % sAutoScapulaDistance,'%s.Z' % sAutoScapulaDistance], None, None], bLocal=True)
        controllers.closeCommentBox('Auto HorizVert')

        controllers.openCommentBox('Auto Rot')
        controllers.setNewColumn()
        eEntry_FootIkControl = ELEM(nodes.createGetEntryVariable('FootIkControl'), 'Control')
        eEntry_AutoOffset = ELEM(nodes.createGetEntryVariable('AutoOffset'), 'Null')
        sAutoScapulaRotAttr = nodes.createGetChannelNode2(sEntry_Control, 'autoRot')
        createKangarooAimConstraintFunctionWeighted(eEntry_AutoOffset, eEntry_FootIkControl, eEntry_FootIkControl, fWeight=sAutoScapulaRotAttr, fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Auto Rot')


        controllers.openCommentBox('Constraint Pivot')
        controllers.setNewColumn()
        eEntry_Pivot = ELEM(nodes.createGetEntryVariable('Pivot'), 'Null')
        eEntry_Control = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
        createKangarooAimConstraintFunction(eEntry_Pivot, eEntry_Control, eEntry_Control)
        controllers.closeCommentBox('Constraint Pivot')


        controllers.openCommentBox('Constraint Bone')
        controllers.setNewColumn()
        eEntry_Bone = ELEM(nodes.createGetEntryVariable('Bone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_Pivot, 1.0)], eEntry_Bone, bMaintainOffset=True)
        controllers.closeCommentBox('Constraint Bone')

        nodes.endCurrentFunction(bAddToExecute=False)

        

    sAutoDriverLimbSide, sAutoDriverLimbName = sAutoDriverLimb.split('_')

    sNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300,400])

    pins.setString(sJoint, '%s.Bone' % sNode)
    pins.setString(sParentJoint, '%s.ParentBone' % sNode)

    pins.setString(cCtrl.ePasser.name, '%s.Passer' % sNode)
    pins.setString(cCtrl.eControl.name, '%s.Control' % sNode)
    pins.setString(eAutoGrp.name, '%s.AutoOffset' % sNode)
    pins.setString(ePivot.name, '%s.Pivot' % sNode)

    pins.setString('%sWristRevPasser' % sAutoDriverLimb, '%s.AnklePasser' % sNode)
    pins.setString('%sWristRev_%s_ctrl' % (sAutoDriverLimbName, sAutoDriverLimbSide), '%s.AnkleControl' % sNode)
    pins.setString('jnt_%sWrist' % sAutoDriverLimb, '%s.AnkleBone' % sNode)

    sAutoDriverSide, sAutoDriverName = sAutoDriverLimb.split('_')
    pins.setString('%sIk_%s_ctrl' % (sAutoDriverName, sAutoDriverSide), '%s.FootIkControl' % sNode)

    pins.connectToPin1D(sSide == 'r', '%s.Negative' % sNode)
    return sNode




def createDogArmLegIkSetup(cIk, cPole, cToeEnd, cHeel, cAnkle, cBallRev, eStrToeAimA, eStrToeAimB, cToeFk, sBones, eStrPoleFollow, eStrPoleLine, fUpperLength, fLowerLength, fSoftIkDefault, sLimbName='l_arm', bIsBackLeg=False):

    sSide, sName = sLimbName.split('_')
    hierarchy.createFloatControl('softIk', eParent=cIk.eControl, fRange=[0,1], fDefault=fSoftIkDefault)
    hierarchy.createFloatControl('stretch', eParent=cIk.eControl, fRange=[0,1], fDefault=0.0)
    hierarchy.createFloatControl('ankleAim', eParent=cIk.eControl, fRange=[0,1], fDefault=1.0)
    hierarchy.createFloatControl('UpperScale', eParent=cIk.eControl, fRange=[0.1,3.0], fDefault=1.0)
    hierarchy.createFloatControl('LowerScale', eParent=cIk.eControl, fRange=[0.1,3.0], fDefault=1.0)
    sFunctionName = 'kangaroo_dogArmLegIk'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('IkPasser', 'FName', False),
                                                      ('IkControl', 'FName', False),
                                                      ('AnkleAimOffset', 'FName', False),
                                                      ('AnkleControl', 'FName', False),
                                                      ('ToeFkPasser', 'FName', False),
                                                      ('ToeFkControl', 'FName', False),
                                                      ('PolePasser', 'FName', False),
                                                      ('PoleControl', 'FName', False),
                                                      ('ToeAimA', 'FName', False),
                                                      ('ToeAimB', 'FName', False),
                                                      ('PoleFollow', 'FName', False),
                                                      ('UpperBone', 'FName', False),
                                                      ('ElbowBone', 'FName', False),
                                                      ('WristBone', 'FName', False),
                                                      ('FingersBone', 'FName', False),
                                                      ('FingersMidBone', 'FName', False),
                                                      ('bNegative', 'bool', False),
                                                      ('bBackLeg', 'bool', False),
                                                      ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                      ('ATTACHER_root_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_r', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_t', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_r', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_t', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_r', 'FConstraintParent', True),
                                                      ])

        controllers.openCommentBox('Attachers 1')
        eIkPasser = ELEM('Entry.IkPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_t', eIkPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_r', eIkPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 1')


        controllers.openCommentBox('Get Limb Lengths')
        controllers.setNewColumn()
        vUpperLength = hierarchy.newVariable('UpperLength')
        vLowerLength = hierarchy.newVariable('LowerLength')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        sUpperTx = '%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True)
        controllers.setNewColumn()
        vNegative = hierarchy.newVariable('Negative', 'bool')
        nodes.createSetVariableExecuteNode(vNegative, nodes.createConditionNodes(sUpperTx, '<', 0.0))
        controllers.setNewColumn()
        sUpperLength = nodes.createMathAbs(sUpperTx)

        sUpperAnimScale = nodes.createGetChannelNode2(sEntry_IkControl, 'UpperScale')
        sUpperLengthScaled = nodes.createBasicCalculateNode([sUpperLength, sUpperAnimScale])
        nodes.createSetVariableExecuteNode(vUpperLength, sUpperLengthScaled)
        controllers.setNewColumn()

        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        sLowerLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True, bInitial=True))
        sLowerAnimScale = nodes.createGetChannelNode2(sEntry_IkControl, 'LowerScale')
        sLowerLengthScaled = nodes.createBasicCalculateNode([sLowerLength, sLowerAnimScale])
        nodes.createSetVariableExecuteNode(vLowerLength, sLowerLengthScaled)
        controllers.closeCommentBox('Get Limb Lengths')



        # PoleFollow
        controllers.openCommentBox('Pole Follow')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_PoleFollow = ELEM(nodes.createGetEntryVariable('PoleFollow'), 'Null')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_PoleFollow, skipRotate=['x','y','z'])
        controllers.setNewColumn()
        createKangarooAimConstraintFunction(eEntry_PoleFollow, eEntry_AnkleControl, ELEM(sEntry_IkControl, 'Control'),
                                            fAimVector=[1,0,0], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Pole Follow')

        controllers.openCommentBox('Attachers 2')
        controllers.setNewColumn()
        eEntry_PolePasser = ELEM(nodes.createGetEntryVariable('PolePasser'), 'Null')
        sEntry_ATTACHER_pole_t = nodes.createGetEntryVariable('ATTACHER_pole_t')
        sEntry_ATTACHER_pole_r = nodes.createGetEntryVariable('ATTACHER_pole_r')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_t, eEntry_PolePasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_r, eEntry_PolePasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 2')

        controllers.setNewColumn()
        controllers.openCommentBox('Ankle Aim')
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        eEntry_AnkleAimOffset = ELEM(nodes.createGetEntryVariable('AnkleAimOffset'), 'Null')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        sAnkleAimAttr = nodes.createGetChannelNode2(sEntry_IkControl, 'ankleAim')
        createKangarooAimConstraintFunctionWeighted(eEntry_AnkleAimOffset, eEntry_UpperBone, ELEM(sEntry_IkControl, 'Control'),
                                            fAimVector=[0, 0, 1], fUpVector=[0, 1, 0], fWorldUpVector=[0, 1, 0], fWeight=sAnkleAimAttr)



        controllers.setNewColumn()
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sAnkleInitial = nodes.getTransformNode(eEntry_AnkleControl, bInitial=True)
        sAnkleBoneInitial = nodes.getTransformNode(eEntry_WristBone, bInitial=True)
        sAnkleOffset = nodes.createMakeRelativeNode(sAnkleBoneInitial, sAnkleInitial)
        sAnkleAimed = nodes.getTransformNode(eEntry_AnkleControl)
        controllers.closeCommentBox('Ankle Aim')

        controllers.setNewColumn()
        controllers.openCommentBox('IK')
        sIkEffector = nodes.createMakeAbsoluteNode(sAnkleOffset, sAnkleAimed)
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        sSoftIkEffector = softIk(sEntry_IkControl, sUpperLength, sLowerLength, eEntry_UpperBone, sIkEffector)
        sSoftIkScaleClamped = '%s.ScaleClamped' % sSoftIkEffector.split('.')[0]


        controllers.setNewColumn()
        sEntry_Negative = nodes.createGetEntryVariable('bNegative')
        sEntry_bBackLeg = nodes.createGetEntryVariable('bBackLeg')
        controllers.setNewColumn()
        sSideMultipl = nodes.createIfNode(sEntry_Negative, -1.0, 1.0)
        sSideMultiplNegative = nodes.createIfNode(sEntry_Negative, 1.0, -1.0)
        sSecondaryAxisY = nodes.createIfNode(sEntry_bBackLeg, sSideMultipl, sSideMultiplNegative)

        controllers.setNewColumn()

        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sUpperScaled = nodes.createBasicCalculateNode([sUpperLength, sSoftIkScaleClamped], sOperation='Multiply')
        nodes.createSetTranslationExecuteNode(eEntry_ElbowBone, [sUpperScaled,0,0], bLocal=True)
        sLowerScaled = nodes.createBasicCalculateNode([sLowerLength, sSoftIkScaleClamped], sOperation='Multiply')
        nodes.createSetTranslationExecuteNode(eEntry_WristBone, [sLowerScaled,0,0], bLocal=True)
        controllers.setNewColumn()

        sEntry_PoleControl = nodes.createGetEntryVariable('PoleControl')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        sIk = nodes.createIkTransformsNode(nodes.getTransformNode(eEntry_UpperBone), sSoftIkEffector,
                                           sUpperScaled, sLowerScaled, sPoleVector=nodes.getControlVector(sEntry_PoleControl),
                                           fPrimaryAxis=[sSideMultipl,0,0], fSecondaryAxis=[0,sSecondaryAxisY,0])

        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eEntry_UpperBone, '%s.Root' % sIk)
        nodes.createSetTransformExecuteNode(eEntry_ElbowBone, '%s.Elbow' % sIk)
        nodes.createSetTransformExecuteNode(eEntry_WristBone, '%s.Effector' % sIk)

        controllers.closeCommentBox('IK')
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
        controllers.setNewColumn()
        eEntry_ToeAimA = ELEM(nodes.createGetEntryVariable('ToeAimA'), 'Null')
        createKangarooAimConstraintFunction(eEntry_FingersBone, eEntry_ToeAimA, eEntry_ToeAimA, fAimVector=[1,0,0], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])

        controllers.setNewColumn()
        controllers.openCommentBox('Fk Ctrl')
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')

        eEntry_ToeFkPasser = ELEM(nodes.createGetEntryVariable('ToeFkPasser'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_FingersBone, 1)], eEntry_ToeFkPasser, bMaintainOffset=True)
        eEntry_ToeAimB = ELEM(nodes.createGetEntryVariable('ToeAimB'), 'Null')
        createKangarooAimConstraintFunction(eEntry_ToeFkPasser, eEntry_ToeAimB, eEntry_ToeAimB, fAimVector=[0,0,1], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.setNewColumn()
        eEntry_ToeFkControl = ELEM(nodes.createGetEntryVariable('ToeFkControl'), 'Control')
        eEntry_FingersMidBone = ELEM(nodes.createGetEntryVariable('FingersMidBone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_ToeFkControl, 1)], eEntry_FingersMidBone, bMaintainOffset=True)
        controllers.closeCommentBox('Fk Ctrl')

        controllers.openCommentBox('Pole Line')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_PoleControl = ELEM(nodes.createGetEntryVariable('PoleControl'), 'Control')
        createLineFunction(eEntry_PoleControl, eEntry_ElbowBone)
        controllers.closeCommentBox('Pole Line')
        nodes.endCurrentFunction(bAddToExecute=False)


    sDogArmLegNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sBones[0], '%s.UpperBone' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(sBones[1], '%s.ElbowBone' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(sBones[2], '%s.WristBone' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(sBones[3], '%s.FingersBone' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(sBones[4], '%s.FingersMidBone' % sDogArmLegNode, bConnectIfPlug=True)
    pins.connectToPin1D(sSide == 'r', '%s.bNegative' % sDogArmLegNode)
    pins.connectToPin1D(bIsBackLeg, '%s.bBackLeg' % sDogArmLegNode)
    # pins.connectToPin1D(fUpperLength, '%s.UpperLength' % sDogArmLegNode)
    # pins.connectToPin1D(fLowerLength, '%s.LowerLength' % sDogArmLegNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cPole.ePasser.name, '%s.PolePasser' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cPole.eControl.name, '%s.PoleControl' % sDogArmLegNode, bConnectIfPlug=True)
    # pins.setString(eStrPoleLine.name, '%s.PoleLine' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cAnkle.ePasser.name, '%s.AnkleAimOffset' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cAnkle.eControl.name, '%s.AnkleControl' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(eStrToeAimA.name, '%s.ToeAimA' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(eStrToeAimB.name, '%s.ToeAimB' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cToeFk.ePasser.name, '%s.ToeFkPasser' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(cToeFk.eControl.name, '%s.ToeFkControl' % sDogArmLegNode, bConnectIfPlug=True)
    pins.setString(eStrPoleFollow.name, '%s.PoleFollow' % sDogArmLegNode, bConnectIfPlug=True)
    return sDogArmLegNode


def createDogArmLegIkSetup_BACKWARDS(cIk, cPole, cAnkle, cHeelControl, cFingerRevControl, cFingerMidRev, cToeFk, sBones, eStrPoleFollow):

    sFunctionName = 'kangaroo_dogArmLegIk_BACKWARDS'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('IkPasser', 'FName', False),
                                                      ('IkControl', 'FName', False),
                                                      ('AnkleAimOffset', 'FName', False),
                                                      ('AnkleControl', 'FName', False),
                                                      ('HeelControl', 'FName', False),
                                                      ('FingerRevControl', 'FName', False),
                                                      ('FingerMidControl', 'FName', False),
                                                      ('ToeFkControl', 'FName', False),
                                                      ('PolePasser', 'FName', False),
                                                      ('PoleControl', 'FName', False),
                                                      ('PoleFollow', 'FName', False),
                                                      ('UpperBone', 'FName', False),
                                                      ('ElbowBone', 'FName', False),
                                                      ('WristBone', 'FName', False),
                                                      ('FingersBone', 'FName', False),
                                                      ('FingersMidBone', 'FName', False),
                                                      ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                      ('ATTACHER_root_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_r', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_t', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_r', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_t', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_r', 'FConstraintParent', True),
                                                      ])


        controllers.openCommentBox('Attachers 1')
        eEntry_IkPasser = ELEM('Entry.IkPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_t', eEntry_IkPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_r', eEntry_IkPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 1')

        # TODO: instead of resetting them, can we maintain them same as horse? Might be trickier since it's got that conditional ikControl constraining
        controllers.openCommentBox('Reset Pivot Controls')
        controllers.setNewColumn()
        eEntry_HeelControl = ELEM(nodes.createGetEntryVariable('HeelControl'), 'Control')
        nodes.createSetTransformExecuteNode(eEntry_HeelControl, None, bLocal=True)
        eEntry_FingerRevControl = ELEM(nodes.createGetEntryVariable('FingerRevControl'), 'Control')
        nodes.createSetTransformExecuteNode(eEntry_FingerRevControl, None, bLocal=True)
        controllers.closeCommentBox('Reset Pivot Controls')

        controllers.openCommentBox('Reverse Foot')
        controllers.setNewColumn()
        eEntry_FingersMidBone = ELEM(nodes.createGetEntryVariable('FingersMidBone'), 'Bone')
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
        sFingerMidAngle = getAngleByEulerItems(eEntry_FingersMidBone, eEntry_FingersBone, iAngleAxis=2)
        sIsRotatedUpwards = nodes.createConditionNodes(sFingerMidAngle, '>=', 0.0, True, False)

        nodes.createBranchExecuteNode(sIsRotatedUpwards)
        if controllers.BLOCK_BRANCH_TRUE:
            controllers.setNewColumn()
            eEntry_ToeFkControl = ELEM(nodes.createGetEntryVariable('ToeFkControl'), 'Control')
            eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
            eEntry_FingerMidControl = ELEM(nodes.createGetEntryVariable('FingerMidControl'), 'Control')
            eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eEntry_ToeFkControl, [None, None, None], bLocal=True)
            nodes.createParentConstraintExecuteNode([(eEntry_FingersMidBone, 1)], eEntry_IkControl, bMaintainOffset=True)
            nodes.createRotationConstraintExecuteNode([(eEntry_FingersBone, 1)], eEntry_FingerMidControl, bMaintainOffset=True)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.setNewColumn()
            eEntry_FingerMidControl = ELEM(nodes.createGetEntryVariable('FingerMidControl'), 'Control')
            eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
            eEntry_FingersMidBone = ELEM(nodes.createGetEntryVariable('FingersMidBone'), 'Bone')
            eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
            eEntry_ToeFkControl = ELEM(nodes.createGetEntryVariable('ToeFkControl'), 'Control')
            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eEntry_FingerMidControl, [None, None, None], bLocal=True)
            nodes.createParentConstraintExecuteNode([(eEntry_FingersBone, 1)], eEntry_IkControl, bMaintainOffset=True)
            nodes.createRotationConstraintExecuteNode([(eEntry_FingersMidBone, 1)], eEntry_ToeFkControl, bMaintainOffset=True)
            controllers.setNewColumn()
            controllers.closeCommentBox('Reverse Foot')
            controllers.goToParentExecute()


        controllers.setNewColumn()
        nodes.createSetChannelNode('Entry.IkControl', 'softIk', 0.0)
        controllers.setNewColumn()


        controllers.openCommentBox('Ankle Aim')
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        eEntry_AnkleAimOffset = ELEM(nodes.createGetEntryVariable('AnkleAimOffset'), 'Null')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')

        sAnkleAimAttr = nodes.createGetChannelNode2(sEntry_IkControl, 'ankleAim')
        createKangarooAimConstraintFunctionWeighted(eEntry_AnkleAimOffset, eEntry_UpperBone, ELEM(sEntry_IkControl, 'Control'),
                                            fAimVector=[0, 0, 1], fUpVector=[0, 1, 0], fWorldUpVector=[0, 1, 0], fWeight=sAnkleAimAttr) #, fSourcePosition=)#, eDefaultBone='Entry.IkOut')
        # createKangarooAimConstraintFunction('Entry.AnkleAimOffset', 'Entry.UpperBone', 'Entry.IkOut', fAimVector=[0,1,0], fUpVector=[1,0,0],
        #                                 fWorldUpVector=[0,1,0], fWeight=sAnkleAimAttr)#, eDefaultBone='Entry.IkOut')

        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        nodes.createRotationConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_AnkleControl, bMaintainOffset=True)
        controllers.closeCommentBox('Ankle Aim')


        # PoleFollow
        controllers.openCommentBox('pole follow')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_PoleFollow = ELEM(nodes.createGetEntryVariable('PoleFollow'), 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_PoleFollow, skipRotate=['x','y','z'])
        controllers.setNewColumn()
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        createKangarooAimConstraintFunction(eEntry_PoleFollow, eEntry_AnkleControl, eEntry_IkControl,  fAimVector=[1,0,0], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('pole follow')
        controllers.setNewColumn()


        controllers.openCommentBox('Upper Length') #could this be done as a function?! it's used in horse, dog ik (maybe human) and their backwards functions (4-6 times)
        controllers.setNewColumn()
        vUpperLength = hierarchy.newVariable('UpperLength')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        sUpperLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True))
        sUpperLengthInitial = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True))
        sUpperScale = nodes.createBasicCalculateNode([sUpperLength, sUpperLengthInitial], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        nodes.createSetChannelNode(sEntry_IkControl, 'UpperScale', sUpperScale)
        nodes.createSetVariableExecuteNode(vUpperLength, sUpperLength)
        controllers.closeCommentBox('Upper Length')

        controllers.openCommentBox('Lower Length')
        controllers.setNewColumn()
        vLowerLength = hierarchy.newVariable('LowerLength')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sLowerLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True))
        sLowerLengthInitial = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True, bInitial=True))
        sLowerScale = nodes.createBasicCalculateNode([sLowerLength, sLowerLengthInitial], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        nodes.createSetChannelNode(sEntry_IkControl, 'LowerScale', sLowerScale)
        nodes.createSetVariableExecuteNode(vLowerLength, sLowerLength)
        controllers.setNewColumn()
        controllers.closeCommentBox('Lower Length')

        controllers.openCommentBox('Attachers 2')
        eEntry_ATTACHER_pole_t = nodes.createGetEntryVariable('ATTACHER_pole_t')
        eEntry_ATTACHER_pole_r = nodes.createGetEntryVariable('ATTACHER_pole_r')
        eEntry_PolePasser = ELEM(nodes.createGetEntryVariable('PolePasser'), 'Null')
        nodes.createParentConstraintExecuteNode(eEntry_ATTACHER_pole_t, eEntry_PolePasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(eEntry_ATTACHER_pole_r, eEntry_PolePasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 2')


        controllers.setNewColumn()
        controllers.openCommentBox('Place Pole Ctrl - getting bones')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sUpperTransform = nodes.getTransformNode(eEntry_UpperBone)
        sElbowTransform = nodes.getTransformNode(eEntry_ElbowBone)
        sWristTransform = nodes.getTransformNode(eEntry_WristBone)
        controllers.closeCommentBox('Place Pole Ctrl - getting bones')

        controllers.openCommentBox('calculate NOT stretched')
        controllers.setNewColumn()
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        sLengthSum = nodes.createBasicCalculateNode([sUpperLength, sLowerLength], sOperation='Add')
        sSecondFactor = nodes.createBasicCalculateNode([sUpperLength, sLengthSum], sOperation='Divide')
        sMiddlePoint = nodes.createVectorInterpolateNode(sSecondFactor, '%s.Translation' % sUpperTransform, '%s.Translation' % sWristTransform)
        sAim = nodes.createAimNode([sMiddlePoint, None, None], '%s.Translation' % sElbowTransform)
        sPoleVectorTransform = nodes.createMakeAbsoluteNode([[sLengthSum,0,0], None, None], sAim)
        controllers.closeCommentBox('calculate NOT stretched')

        controllers.openCommentBox('calculate stretched')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sElbowInitial = nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True)
        sPoleVectorTransformStretched = nodes.createMakeAbsoluteNode([['%s.Translation.X' % sElbowInitial, sLengthSum, 0.0], None, None], sUpperTransform)
        controllers.closeCommentBox('calculate stretched')

        controllers.openCommentBox('interpolating poles')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sAngle = angleFromJointsFunction(eEntry_UpperBone, eEntry_ElbowBone, eEntry_WristBone)
        sAngleRemap = nodes.createRemapNode(sAngle, 155, 175, 0, 1)
        sPoleBlend = nodes.createVectorInterpolateNode(sAngleRemap, '%s.Translation' % sPoleVectorTransform, '%s.Translation' % sPoleVectorTransformStretched)
        controllers.setNewColumn()
        eEntry_PoleControl = ELEM(nodes.createGetEntryVariable('PoleControl'), 'Control')
        nodes.createSetTranslationExecuteNode(eEntry_PoleControl, sPoleBlend)
        controllers.closeCommentBox('interpolating poles')

        controllers.setNewColumn()
        # createLineFunction('Entry.Pole', 'Entry.ElbowBone', 'Entry.PoleLine')


        nodes.endCurrentFunction(bAddToExecute=False)


    sDogArmLegNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sBones[0], '%s.UpperBone' % sDogArmLegNode)
    pins.setString(sBones[1], '%s.ElbowBone' % sDogArmLegNode)
    pins.setString(sBones[2], '%s.WristBone' % sDogArmLegNode)
    pins.setString(sBones[3], '%s.FingersBone' % sDogArmLegNode)
    pins.setString(sBones[4], '%s.FingersMidBone' % sDogArmLegNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sDogArmLegNode)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sDogArmLegNode)
    pins.setString(cPole.ePasser.name, '%s.PolePasser' % sDogArmLegNode)
    pins.setString(cPole.eControl.name, '%s.PoleControl' % sDogArmLegNode)
    pins.setString(cFingerRevControl.eControl.name, '%s.FingerRevControl' % sDogArmLegNode)
    pins.setString(cHeelControl.eControl.name, '%s.HeelControl' % sDogArmLegNode)
    pins.setString(cFingerMidRev.eControl.name, '%s.FingerMidControl' % sDogArmLegNode)
    pins.setString(cAnkle.ePasser.name, '%s.AnkleAimOffset' % sDogArmLegNode)
    pins.setString(cAnkle.eControl.name, '%s.AnkleControl' % sDogArmLegNode)
    pins.setString(cToeFk.eControl.name, '%s.ToeFkControl' % sDogArmLegNode)
    pins.setString(eStrPoleFollow.name, '%s.PoleFollow' % sDogArmLegNode)
    return sDogArmLegNode



def createHumanArmLegIkSetup(cIk, cPole, cAnkle, eStrAnkleAim, eStrToeAim, cStrToeFk, sBones, eStrPoleFollow, eStrPoleLine,
                             fUpperLength, fLowerLength, fSoftIkDefault, fIkPrimaryAxis=[1,0,0], fIkSecondaryAxis=[0,1,0], eAttachRootToClavicle=None, eClavicleDriver=None):

    hierarchy.createFloatControl('softIk', eParent=cIk.eControl, fRange=[0,1], fDefault=fSoftIkDefault)
    hierarchy.createFloatControl('stretch', eParent=cIk.eControl, fRange=[0,1], fDefault=0.0)
    hierarchy.createFloatControl('UpperScale', eParent=cIk.eControl, fRange=[0.1,3.0], fDefault=1.0)
    hierarchy.createFloatControl('LowerScale', eParent=cIk.eControl, fRange=[0.1,3.0], fDefault=1.0)

    sFunctionName = 'kangaroo_armLegIk'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('IkPasser', 'FName', False),
                                                      ('IkControl', 'FName', False),
                                                      # ('UpperLength', 'float', False),
                                                      # ('LowerLength', 'float', False),
                                                      ('AnkleControl', 'FName', False),
                                                      ('AnkleAim', 'FName', False),
                                                      ('ToeAim', 'FName', False),
                                                      ('ToeFkControl', 'FName', False),
                                                      ('PolePasser', 'FName', False),
                                                      ('PoleControl', 'FName', False),
                                                      ('PoleFollow', 'FName', False),
                                                      ('UpperBone', 'FName', False),
                                                      ('ElbowBone', 'FName', False),
                                                      ('WristBone', 'FName', False),
                                                      ('FingersBone', 'FName', False),
                                                      ('ClavicleDriver', 'FName', False),
                                                      ('IkPrimaryAxis', 'FVector', False),
                                                      ('IkSecondaryAxis', 'FVector', False),
                                                      ('ATTACHER_root_noClav_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_noClav_r', 'FConstraintParent', True),
                                                      ('ATTACHER_root_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_r', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_t', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_r', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_t', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_r', 'FConstraintParent', True),
                                                      ])

        controllers.openCommentBox('Attachers 1')
        eEntry_IkPasser = ELEM('Entry.IkPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_t', eEntry_IkPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_r', eEntry_IkPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 1')

        # PoleFollow
        controllers.openCommentBox('pole follow for attachers')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_PoleFollow = ELEM(nodes.createGetEntryVariable('PoleFollow'), 'Null')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_PoleFollow, skipRotate=['x','y','z'])
        createKangarooAimConstraintFunction(eEntry_PoleFollow, eEntry_AnkleControl, eEntry_IkControl,  fAimVector=[1,0,0], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('pole follow for attachers')
        controllers.setNewColumn()

        controllers.openCommentBox('Attachers 2')
        controllers.setNewColumn()
        ePolePasser = ELEM(nodes.createGetEntryVariable('PolePasser'), 'Null')
        eEntry_Attacher_pole_t = nodes.createGetEntryVariable('ATTACHER_pole_t')
        eEntry_Attacher_pole_r = nodes.createGetEntryVariable('ATTACHER_pole_r')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(eEntry_Attacher_pole_t, ePolePasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(eEntry_Attacher_pole_r, ePolePasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 2')


        controllers.openCommentBox('Get Limb Lengths')
        controllers.setNewColumn()
        vUpperLength = hierarchy.newVariable('UpperLength')
        vLowerLength = hierarchy.newVariable('LowerLength')
        # vNegative = hierarchy.newVariable('Negative', sType='bool')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        sUpperTx = '%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True)
        controllers.setNewColumn()
        # sNegative = nodes.createConditionNodes(sUpperTx, '<', 0.0, iTermsPinType=pins.PinType.double)
        # nodes.createSetVariableExecuteNode(vNegative, sNegative)
        sUpperLength = nodes.createMathAbs(sUpperTx)

        sUpperAnimScale = nodes.createGetChannelNode2(sEntry_IkControl, 'UpperScale')
        sUpperLengthScaled = nodes.createBasicCalculateNode([sUpperLength, sUpperAnimScale])
        nodes.createSetVariableExecuteNode(vUpperLength, sUpperLengthScaled)
        controllers.setNewColumn()

        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        sLowerLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True, bInitial=True))
        sLowerAnimScale = nodes.createGetChannelNode2(sEntry_IkControl, 'LowerScale')
        sLowerLengthScaled = nodes.createBasicCalculateNode([sLowerLength, sLowerAnimScale])
        nodes.createSetVariableExecuteNode(vLowerLength, sLowerLengthScaled)
        controllers.closeCommentBox('Get Limb Lengths')



        controllers.openCommentBox('Ankle')
        controllers.setNewColumn()
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sAnkleInitial = nodes.getTransformNode(eEntry_AnkleControl, bInitial=True)
        sAnkleBoneInitial = nodes.getTransformNode(eEntry_WristBone, bInitial=True)
        sAnkleOffset = nodes.createMakeRelativeNode(sAnkleBoneInitial, sAnkleInitial)
        sAnkleAimed = nodes.getTransformNode(eEntry_AnkleControl)
        controllers.closeCommentBox('Ankle')


        controllers.setNewColumn()
        controllers.openCommentBox('Soft IK Effector')
        sIkEffector = nodes.createMakeAbsoluteNode(sAnkleOffset, sAnkleAimed)
        sEntry_Ik = nodes.createGetEntryVariable('IkControl')
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        sSoftIkEffector = softIk(sEntry_Ik, sUpperLength, sLowerLength, eEntry_UpperBone, sIkEffector)
        sSoftIkScaleClamped = '%s.ScaleClamped' % sSoftIkEffector.split('.')[0]
        controllers.closeCommentBox('Soft IK Effector')

        controllers.openCommentBox('Set Scale Length')
        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        controllers.setNewColumn()
        sUpperScaled = nodes.createBasicCalculateNode([sUpperLength, sSoftIkScaleClamped], sOperation='Multiply')
        nodes.createSetTranslationExecuteNode(eEntry_ElbowBone, [sUpperScaled,0,0], bLocal=True)
        sLowerScaled = nodes.createBasicCalculateNode([sLowerLength, sSoftIkScaleClamped], sOperation='Multiply')
        nodes.createSetTranslationExecuteNode(eEntry_WristBone, [sLowerScaled,0,0], bLocal=True)
        controllers.closeCommentBox('Set Scale Length')

        controllers.openCommentBox('Auto Clavicle')
        controllers.setNewColumn()
        sEntry_ATTACHER_root_noClav_t = nodes.createGetEntryVariable('ATTACHER_root_noClav_t')
        sNoClavAttacherCount = nodes.createArrayGetCountNode(sEntry_ATTACHER_root_noClav_t)
        sThereAreNoClavAttachers = nodes.createConditionNodes(sNoClavAttacherCount, '>', 0, True, False, iTermsPinType=pins.PinType.integer)
        controllers.setNewColumn()
        nodes.createBranchExecuteNode(sThereAreNoClavAttachers)
        if controllers.BLOCK_BRANCH_TRUE: #no clav attachers
            controllers.setNewColumn()
            eSpine = '%s.Item' % nodes.createArrayAtNode(sEntry_ATTACHER_root_noClav_t, 0)
            eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
            sUpperBySpine = nodes.createProjectTransformToNewParent(eEntry_UpperBone, eSpine, eSpine)
            controllers.setNewColumn()

            sEntry_IkPrimaryAxis = nodes.createGetEntryVariable('IkPrimaryAxis')
            sEntry_IkSecondaryAxis = nodes.createGetEntryVariable('IkSecondaryAxis')
            sEntry_PoleControl = nodes.createGetEntryVariable('PoleControl')
            controllers.setNewColumn()

            sAutoClavIk = nodes.createIkTransformsNode(sUpperBySpine, sSoftIkEffector,
                                                       sUpperScaled, sLowerScaled, sPoleVector=nodes.getControlVector(sEntry_PoleControl),
                                                       fPrimaryAxis=sEntry_IkPrimaryAxis, fSecondaryAxis=sEntry_IkSecondaryAxis)
            controllers.setNewColumn()
            eEntry_ClavicleDriver = ELEM(nodes.createGetEntryVariable('ClavicleDriver'), 'Null')
            nodes.createSetTranslationExecuteNode(eEntry_ClavicleDriver, '%s.Elbow.Translation' % sAutoClavIk)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.goToParentExecute()
        controllers.closeCommentBox('Auto Clavicle')

        controllers.openCommentBox('IK')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sIk = nodes.createIkTransformsNode(nodes.getTransformNode(eEntry_UpperBone), sSoftIkEffector,
                                           sUpperScaled, sLowerScaled, sPoleVector=nodes.getControlVector(sEntry_PoleControl),
                                           fPrimaryAxis=sEntry_IkPrimaryAxis, fSecondaryAxis=sEntry_IkSecondaryAxis)
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eEntry_UpperBone, '%s.Root' % sIk)
        nodes.createSetTransformExecuteNode(eEntry_ElbowBone, '%s.Elbow' % sIk)
        nodes.createSetTransformExecuteNode(eEntry_WristBone, '%s.Effector' % sIk)
        controllers.closeCommentBox('IK')

        controllers.setNewColumn()
        controllers.openCommentBox('Foot Aims')
        eEntry_ToeAim = ELEM(nodes.createGetEntryVariable('ToeAim'), 'Null')
        eEntry_AnkleAim = ELEM(nodes.createGetEntryVariable('AnkleAim'), 'Null')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
        controllers.setNewColumn()
        createKangarooAimConstraintFunction(eEntry_WristBone, eEntry_AnkleAim, eEntry_AnkleAim)
        controllers.setNewColumn()
        createKangarooAimConstraintFunction(eEntry_FingersBone, eEntry_ToeAim, eEntry_ToeAim)
        controllers.closeCommentBox('Foot Aims')

        controllers.openCommentBox('Pole Line')
        controllers.setNewColumn()
        eEntry_PoleControl = ELEM(nodes.createGetEntryVariable('PoleControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        createLineFunction(eEntry_PoleControl, eEntry_ElbowBone)#, '%s.Name' % sEntry_PoleLine)
        controllers.closeCommentBox('Pole Line')

        nodes.endCurrentFunction(bAddToExecute=False)


    sHumanArmLegIkNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sBones[0], '%s.UpperBone' % sHumanArmLegIkNode)
    pins.setString(sBones[1], '%s.ElbowBone' % sHumanArmLegIkNode)
    pins.setString(sBones[2], '%s.WristBone' % sHumanArmLegIkNode)
    pins.setString(sBones[3], '%s.FingersBone' % sHumanArmLegIkNode)
    pins.connectToPinVector(fIkPrimaryAxis, '%s.IkPrimaryAxis' % sHumanArmLegIkNode)
    pins.connectToPinVector(fIkSecondaryAxis, '%s.IkSecondaryAxis' % sHumanArmLegIkNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sHumanArmLegIkNode)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sHumanArmLegIkNode)

    pins.setString(eStrToeAim.name, '%s.ToeAim' % sHumanArmLegIkNode)
    pins.setString(eStrAnkleAim.name, '%s.AnkleAim' % sHumanArmLegIkNode)
    pins.setString(cStrToeFk.eControl.name, '%s.ToeFkControl' % sHumanArmLegIkNode)

    pins.setString(cPole.ePasser.name, '%s.PolePasser' % sHumanArmLegIkNode)
    pins.setString(cPole.eControl.name, '%s.PoleControl' % sHumanArmLegIkNode)
    # pins.setString(eStrPoleLine, '%s.PoleLine' % sHumanArmLegIkNode)
    pins.setString(cAnkle.eControl.name, '%s.AnkleControl' % sHumanArmLegIkNode)
    pins.setString(eStrPoleFollow.name, '%s.PoleFollow' % sHumanArmLegIkNode)
    if eClavicleDriver:
        # pins.setString(eAttachRootToClavicle, '%s.AttachToClavicle' % sHumanArmLegIkNode)
        pins.setString(eClavicleDriver.name, '%s.ClavicleDriver' % sHumanArmLegIkNode)
    return sHumanArmLegIkNode


def createHumanArmLegIkSetup_BACKWARDS(cIk, cPole, cAnkle,  cStrToeFk, cHeel, cToeRev, sBones, eStrPoleFollow, fIkPrimaryAxis=[1,0,0], fIkSecondaryAxis=[0,1,0]):

    sFunctionName = 'kangaroo_armLegIk_BACKWARDS'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs= [('IkPasser', 'FName', False),
                                                      ('IkControl', 'FName', False),
                                                      ('AnkleControl', 'FName', False),
                                                      ('ToeFkControl', 'FName', False),
                                                      ('HeelControl', 'FName', False),
                                                      ('ToeRevControl', 'FName', False),
                                                      ('PolePasser', 'FName', False),
                                                      ('PoleControl', 'FName', False),
                                                      ('PoleFollow', 'FName', False),
                                                      ('UpperBone', 'FName', False),
                                                      ('ElbowBone', 'FName', False),
                                                      ('WristBone', 'FName', False),
                                                      ('FingersBone', 'FName', False),
                                                      ('IkPrimaryAxis', 'FVector', False),
                                                      ('IkSecondaryAxis', 'FVector', False),
                                                      ('ATTACHER_root_noClav_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_noClav_r', 'FConstraintParent', True),
                                                      ('ATTACHER_root_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_r', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_t', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_r', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_t', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_r', 'FConstraintParent', True),
                                                      ])

        controllers.openCommentBox('Attachers 1')
        eEntry_IkPasser = ELEM('Entry.IkPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_t', eEntry_IkPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_r', eEntry_IkPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 1')

        # TODO: instead of resetting them, can we maintain them same as horse? Might be trickier in case we add the conditional ikControl constraining
        controllers.openCommentBox('Reset Pivot Controls')
        controllers.setNewColumn()
        eEntry_HeelControl = ELEM(nodes.createGetEntryVariable('HeelControl'), 'Control')
        nodes.createSetTransformExecuteNode(eEntry_HeelControl, None, bLocal=True)
        eEntry_ToeRevControl = ELEM(nodes.createGetEntryVariable('ToeRevControl'), 'Control')
        nodes.createSetTransformExecuteNode(eEntry_ToeRevControl, None, bLocal=True)
        controllers.closeCommentBox('Reset Pivot Controls')

        controllers.openCommentBox('Ik Control')
        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_FingersBone = ELEM(nodes.createGetEntryVariable('FingersBone'), 'Bone')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_FingersBone, 1)], eEntry_IkControl, bMaintainOffset=True)
        nodes.createOrientConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_AnkleControl, bMaintainOffset=True)
        controllers.closeCommentBox('Ik Control')


        # PoleFollow
        controllers.openCommentBox('pole follow')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_PoleFollow = ELEM(nodes.createGetEntryVariable('PoleFollow'), 'Null')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_PoleFollow, skipRotate=['x','y','z'])
        createKangarooAimConstraintFunction(eEntry_PoleFollow, eEntry_AnkleControl, eEntry_IkControl,  fAimVector=[1,0,0], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('pole follow')
        controllers.setNewColumn()

        controllers.openCommentBox('Attachers 2')
        sEntry_ATTACHER_pole_t = nodes.createGetEntryVariable('ATTACHER_pole_t')
        sEntry_ATTACHER_pole_r = nodes.createGetEntryVariable('ATTACHER_pole_r')
        eEntry_PolePasser = ELEM(nodes.createGetEntryVariable('PolePasser'), 'Null')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_t, eEntry_PolePasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_r, eEntry_PolePasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 2')

        controllers.openCommentBox('Upper Length')
        controllers.setNewColumn()
        vUpperLength = hierarchy.newVariable('UpperLength')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        sUpperLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True))
        sUpperLengthInitial = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True))
        sUpperScale = nodes.createBasicCalculateNode([sUpperLength, sUpperLengthInitial], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        nodes.createSetChannelNode(sEntry_IkControl, 'UpperScale', sUpperScale)
        nodes.createSetVariableExecuteNode(vUpperLength, sUpperLength)
        controllers.closeCommentBox('Upper Length')

        controllers.openCommentBox('Lower Length')
        controllers.setNewColumn()
        vLowerLength = hierarchy.newVariable('LowerLength')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sLowerLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True))
        sLowerLengthInitial = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True, bInitial=True))
        sLowerScale = nodes.createBasicCalculateNode([sLowerLength, sLowerLengthInitial], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        nodes.createSetChannelNode(sEntry_IkControl, 'LowerScale', sLowerScale)
        nodes.createSetVariableExecuteNode(vLowerLength, sLowerLength)
        controllers.setNewColumn()
        controllers.closeCommentBox('Lower Length')


        controllers.setNewColumn()
        controllers.openCommentBox('Place Pole Ctrl - getting bones')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sUpperTransform = nodes.getTransformNode(eEntry_UpperBone)
        sElbowTransform = nodes.getTransformNode(eEntry_ElbowBone)
        sWristTransform = nodes.getTransformNode(eEntry_WristBone)
        controllers.closeCommentBox('Place Pole Ctrl - getting bones')


        controllers.openCommentBox('calculate NOT stretched Pole')
        controllers.setNewColumn()
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        sLengthSum = nodes.createBasicCalculateNode([sUpperLength, sLowerLength], sOperation='Add')
        sSecondFactor = nodes.createBasicCalculateNode([sUpperLength, sLengthSum], sOperation='Divide')
        sMiddlePoint = nodes.createVectorInterpolateNode(sSecondFactor, '%s.Translation' % sUpperTransform, '%s.Translation' % sWristTransform)
        sAim = nodes.createAimNode([sMiddlePoint, None, None], '%s.Translation' % sElbowTransform)
        sPoleVectorTransform = nodes.createMakeAbsoluteNode([[sLengthSum,0,0], None, None], sAim)
        controllers.closeCommentBox('calculate NOT stretched Pole')

        controllers.openCommentBox('calculate stretched Pole')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sElbowInitial = nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True)
        sPoleVectorOffset = nodes.createBasicCalculateNode(['Entry.IkSecondaryAxis', [sLengthSum, sLengthSum, sLengthSum]], iPinType=pins.PinType.vector)
        sPoleVectorTransformStretched = nodes.createMakeAbsoluteNode([['%s.Translation.X' % sElbowInitial, '%s.Y' % sPoleVectorOffset, '%s.Z' % sPoleVectorOffset], None, None], sUpperTransform)
        controllers.closeCommentBox('calculate stretched Pole')

        controllers.openCommentBox('Interpolating Poles')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        sAngle = angleFromJointsFunction(eEntry_UpperBone, eEntry_ElbowBone, eEntry_WristBone)
        sAngleRemap = nodes.createRemapNode(sAngle, 155, 175, 0, 1)
        sPoleBlend = nodes.createVectorInterpolateNode(sAngleRemap, '%s.Translation' % sPoleVectorTransform, '%s.Translation' % sPoleVectorTransformStretched)
        controllers.setNewColumn()
        eEntry_PoleControl = ELEM(nodes.createGetEntryVariable('PoleControl'), 'Control')
        nodes.createSetTranslationExecuteNode(eEntry_PoleControl, sPoleBlend)
        controllers.closeCommentBox('Interpolating Poles')

        nodes.endCurrentFunction(bAddToExecute=False)


    sHumanArmLegNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300.0, 1000.0])
    pins.setString(sBones[0], '%s.UpperBone' % sHumanArmLegNode)
    pins.setString(sBones[1], '%s.ElbowBone' % sHumanArmLegNode)
    pins.setString(sBones[2], '%s.WristBone' % sHumanArmLegNode)
    pins.setString(sBones[3], '%s.FingersBone' % sHumanArmLegNode)
    pins.connectToPinVector(fIkPrimaryAxis, '%s.IkPrimaryAxis' % sHumanArmLegNode)
    pins.connectToPinVector(fIkSecondaryAxis, '%s.IkSecondaryAxis' % sHumanArmLegNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sHumanArmLegNode)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sHumanArmLegNode)
    pins.setString(cHeel.eControl.name, '%s.HeelControl' % sHumanArmLegNode)
    pins.setString(cToeRev.eControl.name, '%s.ToeRevControl' % sHumanArmLegNode)

    pins.setString(cStrToeFk.eControl.name, '%s.ToeFkControl' % sHumanArmLegNode)
    pins.setString(cPole.ePasser.name, '%s.PolePasser' % sHumanArmLegNode)
    pins.setString(cPole.eControl.name, '%s.PoleControl' % sHumanArmLegNode)
    pins.setString(cAnkle.eControl.name, '%s.AnkleControl' % sHumanArmLegNode)
    pins.setString(eStrPoleFollow.name, '%s.PoleFollow' % sHumanArmLegNode)
    return sHumanArmLegNode



def createDogArmLegDetails(sLimbName, cElbowStretch, cWristStretch, sParent, sUpper, sElbow, sWrist, sFingers, sUpperLeaves, sLowerLeaves, fDoubleKneeDefault=0.5, fSideMultipl=1.0):

    hierarchy.createFloatControl('doubleKnee', eParent=cElbowStretch.eControl, fRange=[0,1], fDefault=fDoubleKneeDefault)


    sFunctionName = 'kangaroo_dogArmLegDetails'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('ElbowStretchControl', 'FName', False),
                                                     ('ElbowStretchPasser', 'FName', False),
                                                     ('WristStretchControl', 'FName', False),
                                                     ('WristStretchPasser', 'FName', False),
                                                     ('Parent', 'FName', False),
                                                     ('Upper', 'FName', False),
                                                     ('Elbow', 'FName', False),
                                                     ('Wrist', 'FName', False),
                                                     ('Fingers', 'FName', False),
                                                     ('UpperLeaves', 'FName', True),
                                                     ('LowerLeaves', 'FName', True),
                                                     ('SideMultipl', 'float', False)])
                                                     # ('AimVector', 'FVector', False)])

        eUpper = ELEM('Entry.Upper', 'Bone')
        eElbow = ELEM('Entry.Elbow', 'Bone')
        eWrist = ELEM('Entry.Wrist', 'Bone')
        eElbowStretchPasser = ELEM('Entry.ElbowStretchPasser', 'Null')
        eWristStretchPasser = ELEM('Entry.WristStretchPasser', 'Null')
        nodes.createPositionConstraintExecuteNode([(eElbow, 1)], eElbowStretchPasser)
        nodes.createPositionConstraintExecuteNode([(eWrist, 1)], eWristStretchPasser)
        nodes.createOrientConstraintExecuteNode([(eUpper, 1), (eElbow, 1)], eElbowStretchPasser, bMaintainOffset=True)
        nodes.createOrientConstraintExecuteNode([(eElbow, 1), (eWrist, 1)], eWristStretchPasser, bMaintainOffset=True)


        controllers.openCommentBox('Get Prev Transforms')
        controllers.setNewColumn()
        controllers.setNewColumn()
        eEntry_Upper = ELEM(nodes.createGetEntryVariable('Upper'), 'Bone')
        vUpperBefore = hierarchy.newVariable('UpperBefore', 'FTransform')
        sUpperBefore = nodes.getTransformNode(eEntry_Upper)
        nodes.createSetVariableExecuteNode(vUpperBefore, sUpperBefore)
        controllers.setNewColumn()
        eEntry_Elbow = ELEM(nodes.createGetEntryVariable('Elbow'), 'Bone')
        vElbowBefore = hierarchy.newVariable('ElbowBefore', 'FTransform')
        sElbowBefore = nodes.getTransformNode(eEntry_Elbow)
        nodes.createSetVariableExecuteNode(vElbowBefore, sElbowBefore)
        controllers.setNewColumn()
        eEntry_Wrist = ELEM(nodes.createGetEntryVariable('Wrist'), 'Bone')
        vWristBefore = hierarchy.newVariable('WristBefore', 'FTransform')
        sWristBefore = nodes.getTransformNode(eEntry_Wrist)
        nodes.createSetVariableExecuteNode(vWristBefore, sWristBefore)
        controllers.setNewColumn()
        eEntry_Fingers = ELEM(nodes.createGetEntryVariable('Fingers'), 'Bone')
        vFingersBefore = hierarchy.newVariable('FingersBefore', 'FTransform')
        sFingersBefore = nodes.getTransformNode(eEntry_Fingers)
        nodes.createSetVariableExecuteNode(vFingersBefore, sFingersBefore)
        controllers.closeCommentBox('Get Prev Transforms')

        controllers.openCommentBox('Calculate DoubleKnee Strength')
        controllers.setNewColumn()
        eEntry_Elbow = ELEM(nodes.createGetEntryVariable('Elbow'), 'Bone')
        sElbowLocalInitial = nodes.getTransformNode(eEntry_Elbow, bLocal=True, bInitial=True)
        eEntry_Wrist = ELEM(nodes.createGetEntryVariable('Wrist'), 'Bone')
        sWristLocalInitial = nodes.getTransformNode(eEntry_Wrist, bLocal=True, bInitial=True)
        sArmLength = nodes.createBasicCalculateNode(['%s.Translation.X' % sElbowLocalInitial, '%s.Translation.X' % sWristLocalInitial], sOperation='Add')
        sDoubleKneeStrength = nodes.createBasicCalculateNode([sArmLength, 0.1])
        controllers.closeCommentBox('Calculate DoubleKnee Strength')

        controllers.openCommentBox('DoubleKnee Targets')
        controllers.setNewColumn()
        sEntry_ElbowStretchControl = nodes.createGetEntryVariable('ElbowStretchControl')
        # sEntry_DoubleKneeStrength = nodes.createGetEntryVariable('DoubleKneeStrength')
        controllers.setNewColumn()
        sDoubleKneeAttr = nodes.createGetChannelNode2(sEntry_ElbowStretchControl, 'doubleKnee')
        sDoubleKneeMoveStrength = nodes.createBasicCalculateNode([sDoubleKneeAttr, sDoubleKneeStrength])
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sWristBefore = nodes.createGetVariableNode(vWristBefore)
        sAnglePointA = nodes.createBasicCalculateNode(['%s.Translation' % sUpperBefore, '%s.Translation' % sElbowBefore], sOperation='Subtract', iPinType=pins.PinType.vector)
        sAnglePointB = nodes.createBasicCalculateNode(['%s.Translation' % sWristBefore, '%s.Translation' % sElbowBefore], sOperation='Subtract', iPinType=pins.PinType.vector)
        sRadians = nodes.createGetAngleNode(sAnglePointA, sAnglePointB)
        sDoubleKneeMove = nodes.createRemapNode(sRadians, 0, math.radians(90.0), sDoubleKneeMoveStrength, 0.0)
        controllers.setNewColumn()
        sKneeCtrl = nodes.getTransformNode(ELEM(sEntry_ElbowStretchControl, 'Control'))
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sElbowBefore = nodes.createGetVariableNode(vElbowBefore)
        sBlendRotation = nodes.createRotationInterpolateNode(0.5, '%s.Rotation' % sUpperBefore, '%s.Rotation' % sElbowBefore)
        sTargetParent = ['%s.Translation' % sKneeCtrl, sBlendRotation, None]
        controllers.setNewColumn()
        sTargetA = '%s.Translation' % nodes.createMakeAbsoluteNode([[nodes.createNegateNode(sDoubleKneeMove),0,0],None,None], sTargetParent)
        sTargetB = '%s.Translation' % nodes.createMakeAbsoluteNode([[sDoubleKneeMove,0,0],None,None], sTargetParent)
        controllers.closeCommentBox('DoubleKnee Targets')



        # upper
        controllers.openCommentBox('Constraint Upper Bone')
        controllers.setNewColumn()
        eEntry_Upper = ELEM(nodes.createGetEntryVariable('Upper'), 'Bone')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sUpperPoleVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % sUpperBefore)
        nodes.createAimExecuteNode(eEntry_Upper, sTargetA, fAimVector=[sEntry_SideMultipl,0,0], sSecondaryTargetVector=sUpperPoleVector, bUpIsDirection=True)
        controllers.closeCommentBox('Constraint Upper Bone')

        # elbow
        controllers.openCommentBox('Constraint Elbow Bone')
        controllers.setNewColumn()
        sEntry_WristStretchControl = nodes.createGetEntryVariable('WristStretchControl')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        eEntry_Elbow = ELEM(nodes.createGetEntryVariable('Elbow'), 'Bone')
        controllers.setNewColumn()

        sWristStretchControlPosition = '%s.Translation' % nodes.getTransformNode(ELEM(sEntry_WristStretchControl, 'Control'))
        nodes.createSetTranslationExecuteNode(eEntry_Elbow, sTargetB)
        sElbowBefore = nodes.createGetVariableNode(vElbowBefore)
        sElbowPoleVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % sElbowBefore)
        nodes.createAimExecuteNode(eEntry_Elbow, sWristStretchControlPosition, fAimVector=[sEntry_SideMultipl,0,0], sSecondaryTargetVector=sElbowPoleVector, bUpIsDirection=True)
        controllers.closeCommentBox('Constraint Elbow Bone')

        # wrist
        controllers.openCommentBox('Constraint Wrist Bone')
        controllers.setNewColumn()
        eEntry_Wrist = ELEM(nodes.createGetEntryVariable('Wrist'), 'Bone')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()
        nodes.createSetTranslationExecuteNode(eEntry_Wrist, sWristStretchControlPosition)
        sWristBefore = nodes.createGetVariableNode(vWristBefore)
        sFingersBefore = nodes.createGetVariableNode(vFingersBefore)
        sWristPoleVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % sWristBefore)
        nodes.createAimExecuteNode(eEntry_Wrist, '%s.Translation' % sFingersBefore, fAimVector=[sEntry_SideMultipl,0,0], sSecondaryTargetVector=sWristPoleVector, bUpIsDirection=True)
        controllers.closeCommentBox('Constraint Wrist Bone')

        # fingers
        controllers.openCommentBox('Constraint Fingers Bone')
        controllers.setNewColumn()
        eEntry_Fingers = ELEM(nodes.createGetEntryVariable('Fingers'), 'Bone')
        sFingersBefore = nodes.createGetVariableNode(vFingersBefore)
        nodes.createSetTransformExecuteNode(eEntry_Fingers, sFingersBefore)
        controllers.closeCommentBox('Constraint Fingers Bone')

        controllers.openCommentBox('Twist Joints')
        controllers.setNewColumn()
        sEntry_Upper = nodes.createGetEntryVariable('Upper')
        sEntry_Parent = nodes.createGetEntryVariable('Parent')
        sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        sEntry_UpperLeaves = nodes.createGetEntryVariable('UpperLeaves')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()

        sTwistUpper = twistUpper(sEntry_Upper, sEntry_Parent, sEntry_Elbow, [0,0,0], True, fSideMultipl=sEntry_SideMultipl, sAimTarget=sTargetA, bDebug=False)
        twistLeavesFunction(sEntry_UpperLeaves, '%s.TwistAngle' % sTwistUpper, sEntry_Upper, sEntry_Elbow, sAimTarget=sTargetA)

        controllers.setNewColumn()
        sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        sEntry_Wrist = nodes.createGetEntryVariable('Wrist')
        sEntry_LowerLeaves = nodes.createGetEntryVariable('LowerLeaves')
        controllers.setNewColumn()
        sTwistLower = twistLower(sEntry_Elbow, sEntry_Wrist, False)
        twistLeavesFunction(sEntry_LowerLeaves, '%s.TwistAngle' % sTwistLower, sEntry_Elbow, sEntry_Wrist)
        controllers.closeCommentBox('Twist Joints')

        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sDetailNode = nodes.addFunctionNode(sFunctionName)

    pins.setString(cElbowStretch.eControl.name, '%s.ElbowStretchControl' % sDetailNode, bConnectIfPlug=True)
    pins.setString(cElbowStretch.ePasser.name, '%s.ElbowStretchPasser' % sDetailNode, bConnectIfPlug=True)
    pins.setString(cWristStretch.eControl.name, '%s.WristStretchControl' % sDetailNode, bConnectIfPlug=True)
    pins.setString(cWristStretch.ePasser.name, '%s.WristStretchPasser' % sDetailNode, bConnectIfPlug=True)

    pins.setString(sParent, '%s.Parent' % sDetailNode, bConnectIfPlug=True)
    pins.setString(sUpper, '%s.Upper' % sDetailNode, bConnectIfPlug=True)
    pins.setString(sElbow, '%s.Elbow' % sDetailNode, bConnectIfPlug=True)
    pins.setString(sWrist, '%s.Wrist' % sDetailNode, bConnectIfPlug=True)
    pins.setString(sFingers, '%s.Fingers' % sDetailNode, bConnectIfPlug=True)
    pins.connectToPin1D(fSideMultipl, '%s.SideMultipl' % sDetailNode)
    # pins.connectToPin1D(fDoubleKneeStrength, '%s.DoubleKneeStrength' % sDetailNode)

    pins.setStringArray(sUpperLeaves, '%s.UpperLeaves' % sDetailNode)
    pins.setStringArray(sLowerLeaves, '%s.LowerLeaves' % sDetailNode)


def createHumanArmLegDetails(cElbowStretch, sParent, sUpper, sElbow, sWrist, sFingers, sUpperLeaves, sLowerLeaves, fStraightRotateOffset=None, bPlaneAxisIsZ=True, bLowerUpAxisIsZ=False, fDoubleKneeStrength=5.0, fSideMultipl=1.0, cBendys=[]):

    hierarchy.createFloatControl('doubleKnee', eParent=cElbowStretch.eControl, fRange=[0,1], fDefault=0.5)

    sFunctionName = 'kangaroo_humanArmLegDetails'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('ElbowStretchControl', 'FName', False),
                                                     ('ElbowStretchPasser', 'FName', False),
                                                     ('Parent', 'FName', False),
                                                     ('Upper', 'FName', False),
                                                     ('Elbow', 'FName', False),
                                                     ('Wrist', 'FName', False),
                                                     ('Fingers', 'FName', False),
                                                     ('StraightRotateOffset', 'FVector', False),
                                                     ('UpperLeaves', 'FName', True),
                                                     ('LowerLeaves', 'FName', True),
                                                     ('PlaneAxisIsZ', 'bool', False),
                                                     ('LowerUpAxisIsZ', 'bool', False),
                                                     ('SideMultipl', 'float', False),
                                                    ('UpperBendyPasser', 'FName', False),
                                                    ('UpperBendyControl', 'FName', False),
                                                    ('LowerBendyPasser', 'FName', False),
                                                    ('LowerBendyControl', 'FName', False),
                                                    ])

        controllers.openCommentBox('Constraint ElbowStretchPasser')
        eElbowStretchPasser = ELEM('Entry.ElbowStretchPasser', 'Null')
        # eWrist = ELEM('Entry.Wrist', 'Bone')
        # eFingers = ELEM('Entry.Fingers', 'Bone')
        nodes.createPositionConstraintExecuteNode([(ELEM('Entry.Elbow', 'Bone'), 1)], eElbowStretchPasser)
        nodes.createOrientConstraintExecuteNode([(ELEM('Entry.Upper', 'Bone'), 1), (ELEM('Entry.Elbow', 'Bone'), 1)], eElbowStretchPasser, bMaintainOffset=True)
        controllers.closeCommentBox('Constraint ElbowStretchPasser')


        controllers.openCommentBox('Get Prev Finger&Wrist')
        controllers.setNewColumn()
        # sBeforeTransforms = nodes.createGetTransformsExecute([eUpper, eElbow, eWrist, eFingers])
        # sUpperBefore = nodes.createArrayAtNode('%s.transforms' % sBeforeTransforms, 0)
        # sElbowBefore = nodes.createArrayAtNode('%s.transforms' % sBeforeTransforms, 1)
        # sWristBefore = nodes.createArrayAtNode('%s.transforms' % sBeforeTransforms, 2)
        controllers.setNewColumn()
        eEntry_Upper = ELEM(nodes.createGetEntryVariable('Upper'), 'Bone')
        vUpperBefore = hierarchy.newVariable('UpperBefore', 'FTransform')
        sUpperBefore = nodes.getTransformNode(eEntry_Upper)
        nodes.createSetVariableExecuteNode(vUpperBefore, sUpperBefore)
        controllers.setNewColumn()
        eEntry_Elbow = ELEM(nodes.createGetEntryVariable('Elbow'), 'Bone')
        vElbowBefore = hierarchy.newVariable('ElbowBefore', 'FTransform')
        sElbowBefore = nodes.getTransformNode(eEntry_Elbow)
        nodes.createSetVariableExecuteNode(vElbowBefore, sElbowBefore)
        controllers.setNewColumn()
        eEntry_Wrist = ELEM(nodes.createGetEntryVariable('Wrist'), 'Bone')
        vWristBefore = hierarchy.newVariable('WristBefore', 'FTransform')
        sWristBefore = nodes.getTransformNode(eEntry_Wrist)
        nodes.createSetVariableExecuteNode(vWristBefore, sWristBefore)
        controllers.closeCommentBox('Get Prev Finger&Wrist')


        controllers.openCommentBox('Calculate DoubleKnee Strength')
        controllers.setNewColumn()
        eEntry_Elbow = ELEM(nodes.createGetEntryVariable('Elbow'), 'Bone')
        sElbowLocalInitial = nodes.getTransformNode(eEntry_Elbow, bLocal=True, bInitial=True)
        eEntry_Wrist = ELEM(nodes.createGetEntryVariable('Wrist'), 'Bone')
        sWristLocalInitial = nodes.getTransformNode(eEntry_Wrist, bLocal=True, bInitial=True)
        sArmLength = nodes.createBasicCalculateNode(['%s.Translation.X' % sElbowLocalInitial, '%s.Translation.X' % sWristLocalInitial], sOperation='Add')
        sDoubleKneeStrength = nodes.createBasicCalculateNode([sArmLength, 0.1])
        controllers.closeCommentBox('Calculate DoubleKnee Strength')


        controllers.openCommentBox('DoubleKnee Targets')
        controllers.setNewColumn()
        sEntry_ElbowStretchControl = nodes.createGetEntryVariable('ElbowStretchControl')
        # sEntry_DoubleKneeStrength = nodes.createGetEntryVariable('DoubleKneeStrength')
        controllers.setNewColumn()
        sDoubleKneeAttr = nodes.createGetChannelNode2(sEntry_ElbowStretchControl, 'doubleKnee')
        sDoubleKneeMoveStrength = nodes.createBasicCalculateNode([sDoubleKneeAttr, sDoubleKneeStrength])
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sElbowBefore = nodes.createGetVariableNode(vElbowBefore)
        sWristBefore = nodes.createGetVariableNode(vWristBefore)
        sAnglePointA = nodes.createBasicCalculateNode(['%s.Translation' % sUpperBefore, '%s.Translation' % sElbowBefore], sOperation='Subtract', iPinType=pins.PinType.vector)
        sAnglePointB = nodes.createBasicCalculateNode(['%s.Translation' % sWristBefore, '%s.Translation' % sElbowBefore], sOperation='Subtract', iPinType=pins.PinType.vector)
        sRadians = nodes.createGetAngleNode(sAnglePointA, sAnglePointB)
        sDoubleKneeMove = nodes.createRemapNode(sRadians, 0, math.radians(90.0), sDoubleKneeMoveStrength, 0.0)
        controllers.setNewColumn()
        sKneeCtrl = nodes.getTransformNode(ELEM(sEntry_ElbowStretchControl, 'Control'))
        sBlendRotation = nodes.createRotationInterpolateNode(0.5, '%s.Rotation' % sUpperBefore, '%s.Rotation' % sElbowBefore)
        sTargetParent = ['%s.Translation' % sKneeCtrl, sBlendRotation, None]
        controllers.setNewColumn()
        sTargetA = '%s.Translation' % nodes.createMakeAbsoluteNode([[nodes.createNegateNode(sDoubleKneeMove),0,0],None,None], sTargetParent)
        sTargetB = '%s.Translation' % nodes.createMakeAbsoluteNode([[sDoubleKneeMove,0,0],None,None], sTargetParent)
        controllers.closeCommentBox('DoubleKnee Targets')


        # upper
        controllers.openCommentBox('Constraint Upper Bone')
        controllers.setNewColumn()
        sEntry_Upper = nodes.createGetEntryVariable('Upper')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sUpperPoleVector = nodes.createRotateVectorNode([0,1,0], '%s.Rotation' % sUpperBefore)
        nodes.createAimExecuteNode(ELEM(sEntry_Upper, 'Bone'), sTargetA, fAimVector=[sEntry_SideMultipl,0,0], fUpVector=[0,1,0], sSecondaryTargetVector=sUpperPoleVector, bUpIsDirection=True)
        controllers.closeCommentBox('Constraint Upper Bone')

        # elbow
        controllers.openCommentBox('Constraint Elbow Bone')
        controllers.setNewColumn()
        sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        eElbow = ELEM(sEntry_Elbow, 'Bone')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()
        sElbowBefore = nodes.createGetVariableNode(vElbowBefore)
        nodes.createSetTranslationExecuteNode(eElbow, sTargetB)
        sElbowPoleVector = nodes.createRotateVectorNode([0,1,0], '%s.Rotation' % sElbowBefore)
        sWristBefore = nodes.createGetVariableNode(vWristBefore)
        nodes.createAimExecuteNode(eElbow, '%s.Translation' % sWristBefore, fAimVector=[sEntry_SideMultipl,0,0], fUpVector=[0,1,0], sSecondaryTargetVector=sElbowPoleVector, bUpIsDirection=True)
        controllers.closeCommentBox('Constraint Elbow Bone')

        # wrist
        controllers.openCommentBox('Constraint Wrist Bone')
        controllers.setNewColumn()
        sEntry_Wrist = nodes.createGetEntryVariable('Wrist')
        sWristBefore = nodes.createGetVariableNode(vWristBefore)
        nodes.createSetTransformExecuteNode(ELEM(sEntry_Wrist, 'Bone'), sWristBefore)
        controllers.closeCommentBox('Constraint Wrist Bone')


        controllers.openCommentBox('Twist Joints')
        controllers.setNewColumn()
        sEntry_Upper = nodes.createGetEntryVariable('Upper')
        sEntry_Parent = nodes.createGetEntryVariable('Parent')
        sEntry_UpperLeaves = nodes.createGetEntryVariable('UpperLeaves')
        sEntry_StraightRotateOffset = nodes.createGetEntryVariable('StraightRotateOffset')
        sEntry_PlaneAxisIsZ = nodes.createGetEntryVariable('PlaneAxisIsZ')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()


        sTwistUpper = twistUpper(sEntry_Upper, sEntry_Parent, sEntry_Elbow, sEntry_StraightRotateOffset, sEntry_PlaneAxisIsZ, sEntry_SideMultipl, sAimTarget=sTargetA)#, sAimTarget=sTargetA, cBendy=cBendys[1] if cBendys else None)
        controllers.setNewColumn()
        sEntry_UpperBendyControl = nodes.createGetEntryVariable('UpperBendyControl')
        sEntry_UpperBendyPasser = nodes.createGetEntryVariable('UpperBendyPasser')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()
        twistLeavesBendyFunction(sEntry_UpperLeaves, '%s.TwistAngle' % sTwistUpper, sEntry_Upper, sEntry_Elbow, fSideMultipl=sEntry_SideMultipl, sAimTarget=sTargetA, sBendyPasser=sEntry_UpperBendyPasser, sBendyControl=sEntry_UpperBendyControl)


        controllers.setNewColumn()
        sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        sEntry_Wrist = nodes.createGetEntryVariable('Wrist')
        sEntry_LowerLeaves = nodes.createGetEntryVariable('LowerLeaves')
        sEntry_LowerUpAxisIsZ = nodes.createGetEntryVariable('LowerUpAxisIsZ')
        controllers.setNewColumn()
        sTwistLower = twistLower(sEntry_Elbow, sEntry_Wrist, sEntry_LowerUpAxisIsZ, cBendy=cBendys[0] if cBendys else None)
        controllers.setNewColumn()
        sEntry_LowerBendyControl = nodes.createGetEntryVariable('LowerBendyControl')
        sEntry_LowerBendyPasser = nodes.createGetEntryVariable('LowerBendyPasser')
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        controllers.setNewColumn()
        twistLeavesBendyFunction(sEntry_LowerLeaves, '%s.TwistAngle' % sTwistLower, sEntry_Elbow, sEntry_Wrist, fSideMultipl=sEntry_SideMultipl, sBendyPasser=sEntry_LowerBendyPasser, sBendyControl=sEntry_LowerBendyControl)
        controllers.closeCommentBox('Twist Joints')

        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sDetailNode = nodes.addFunctionNode(sFunctionName)

    pins.setString(cElbowStretch.eControl.name, '%s.ElbowStretchControl' % sDetailNode)
    pins.setString(cElbowStretch.ePasser.name, '%s.ElbowStretchPasser' % sDetailNode)

    pins.setString(sParent, '%s.Parent' % sDetailNode)
    pins.setString(sUpper, '%s.Upper' % sDetailNode)
    pins.setString(sElbow, '%s.Elbow' % sDetailNode)
    pins.setString(sWrist, '%s.Wrist' % sDetailNode)
    pins.setString(sFingers, '%s.Fingers' % sDetailNode)
    pins.connectToPinVector(fStraightRotateOffset, '%s.StraightRotateOffset' % sDetailNode)
    pins.connectToPin1D(bPlaneAxisIsZ, '%s.PlaneAxisIsZ' % sDetailNode)
    pins.connectToPin1D(bLowerUpAxisIsZ, '%s.LowerUpAxisIsZ' % sDetailNode)
    pins.connectToPin1D(fSideMultipl, '%s.SideMultipl' % sDetailNode)
    # pins.connectToPin1D(fDoubleKneeStrength, '%s.DoubleKneeStrength' % sDetailNode)

    pins.setStringArray([sUpper] + sUpperLeaves, '%s.UpperLeaves' % sDetailNode)
    pins.setStringArray([sElbow] + sLowerLeaves, '%s.LowerLeaves' % sDetailNode)

    pins.setString(cBendys[0].ePasser.name, '%s.UpperBendyPasser' % sDetailNode)
    pins.setString(cBendys[0].eControl.name, '%s.UpperBendyControl' % sDetailNode)
    pins.setString(cBendys[1].ePasser.name, '%s.LowerBendyPasser' % sDetailNode)
    pins.setString(cBendys[1].eControl.name, '%s.LowerBendyControl' % sDetailNode)






def createHorseArmLegIkSetup(cIk, cPole, cMidFingerRev, cAnkle, sBones, eStrPoleFollow, sSide='l', cFkCtrls=[], bIsBackLeg=False, fSoftIkDefault=0.5):

    sFunctionName = 'kangaroo_horseArmLegIk'
    hierarchy.createFloatControl('softIk', eParent=cIk.eControl, fRange=[0,1], fDefault=fSoftIkDefault)
    hierarchy.createFloatControl('stretch', eParent=cIk.eControl, fRange=[0,1], fDefault=0.0)
    hierarchy.createFloatControl('ankleAim', eParent=cIk.eControl, fRange=[0,1], fDefault=1.0)
    hierarchy.createFloatControl('UpperScale', eParent=cIk.eControl, fRange=[0.1,3.0], fDefault=1.0)
    hierarchy.createFloatControl('LowerScale', eParent=cIk.eControl, fRange=[0.1,3.0], fDefault=1.0)

    # eAnkleAimOffset = cAnkle.addOffset('ankleAim')

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('IkPasser', 'FName', False),
                                                      ('IkControl', 'FName', False),
                                                      ('AnkleAimOffset', 'FName', False),
                                                      ('AnkleControl', 'FName', False),
                                                      ('MidFingerRevPasser', 'FName', False),
                                                      ('MidFingerRevControl', 'FName', False),
                                                      ('PolePasser', 'FName', False),
                                                      ('PoleControl', 'FName', False),
                                                      ('WristPasser', 'FName', False),
                                                      ('WristControl', 'FName', False),
                                                      ('FingerAPasser', 'FName', False),
                                                      ('FingerAControl', 'FName', False),
                                                      ('FingerBControl', 'FName', False),
                                                      ('FingerCPasser', 'FName', False),
                                                      ('FingerCControl', 'FName', False),
                                                      ('PoleFollow', 'FName', False),
                                                      ('UpperBone', 'FName', False),
                                                      ('ElbowBone', 'FName', False),
                                                      ('WristBone', 'FName', False),
                                                      ('FingerABone', 'FName', False),
                                                      ('FingerBBone', 'FName', False),
                                                      ('FingerCBone', 'FName', False),
                                                      # ('bNegative', 'bool', False),
                                                      ('bBackLeg', 'bool', False),
                                                      ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                      ('ATTACHER_root_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_r', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_t', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_r', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_t', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_r', 'FConstraintParent', True),
                                                      ])
        eEntry_IkPasser = ELEM('Entry.IkPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_t', eEntry_IkPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_r', eEntry_IkPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])


        controllers.openCommentBox('Get Limb Lengths')
        controllers.setNewColumn()
        vUpperLength = hierarchy.newVariable('UpperLength')
        vLowerLength = hierarchy.newVariable('LowerLength')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        sUpperTx = '%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True)
        controllers.setNewColumn()
        vNegative = hierarchy.newVariable('Negative', 'bool')
        nodes.createSetVariableExecuteNode(vNegative, nodes.createConditionNodes(sUpperTx, '<', 0.0))
        controllers.setNewColumn()
        sUpperLength = nodes.createMathAbs(sUpperTx)

        sUpperAnimScale = nodes.createGetChannelNode2(sEntry_IkControl, 'UpperScale')
        sUpperLengthScaled = nodes.createBasicCalculateNode([sUpperLength, sUpperAnimScale])
        nodes.createSetVariableExecuteNode(vUpperLength, sUpperLengthScaled)
        controllers.setNewColumn()

        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        sLowerLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True, bInitial=True))
        sLowerAnimScale = nodes.createGetChannelNode2(sEntry_IkControl, 'LowerScale')
        sLowerLengthScaled = nodes.createBasicCalculateNode([sLowerLength, sLowerAnimScale])
        nodes.createSetVariableExecuteNode(vLowerLength, sLowerLengthScaled)
        controllers.closeCommentBox('Get Limb Lengths')



        # PoleFollow
        controllers.openCommentBox('pole follow')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_PoleFollow = ELEM(nodes.createGetEntryVariable('PoleFollow'), 'Null')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_PoleFollow, skipRotate=['x','y','z'])
        sPoleAimNode = nodes.createAimConstraintExecuteNode([eEntry_AnkleControl], eEntry_PoleFollow, fUpVector=[0,0,1], bUpIsDirection=True)
        controllers.setNewColumn()
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        controllers.setNewColumn()
        pins.connectItem(eEntry_IkControl, '%s.WorldUp.Space' % sPoleAimNode)
        pins.connectToPinVector([1,0,0], '%s.WorldUp.Target' % sPoleAimNode)
        controllers.closeCommentBox('pole follow')


        controllers.setNewColumn()
        sEntry_ATTACHER_pole_t = nodes.createGetEntryVariable('ATTACHER_pole_t')
        sEntry_ATTACHER_pole_r = nodes.createGetEntryVariable('ATTACHER_pole_r')
        eEntry_PolePasser = ELEM(nodes.createGetEntryVariable('PolePasser'), 'Null')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_t, eEntry_PolePasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_r, eEntry_PolePasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])

        controllers.openCommentBox('Ankle Aim and Ik Effector')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        # eEntry_IkControl = ELEM(sEntry_IkControl, 'Control')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')

        sAnkleAimAttr = nodes.createGetChannelNode2(sEntry_IkControl, 'ankleAim')
        controllers.setNewColumn()
        eEntry_AnkleAimOffset = ELEM(nodes.createGetEntryVariable('AnkleAimOffset'), 'Null')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        createKangarooAimConstraintFunctionWeighted(eEntry_AnkleAimOffset, eEntry_UpperBone, eEntry_WristControl,
                                            fAimVector=[0, 0, 1], fUpVector=[0, 1, 0],
                                            fWorldUpVector=[0, 1, 0], fWeight=sAnkleAimAttr)

        controllers.setNewColumn()
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sAnkleInitial = nodes.getTransformNode(eEntry_AnkleControl, bInitial=True)
        sAnkleBoneInitial = nodes.getTransformNode(eEntry_WristBone, bInitial=True)
        sAnkleOffset = nodes.createMakeRelativeNode(sAnkleBoneInitial, sAnkleInitial)

        sAnkleAimed = nodes.getTransformNode(eEntry_AnkleControl)
        sIkEffector = nodes.createMakeAbsoluteNode(sAnkleOffset, sAnkleAimed)
        controllers.closeCommentBox('Ankle Aim and Ik Effector')

        controllers.openCommentBox('Set Bone Lengths')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        # eEntry_IkControl = ELEM(sEntry_IkControl, 'Control')
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        controllers.setNewColumn()
        sSoftIkEffector = softIk(sEntry_IkControl, sUpperLength, sLowerLength, eEntry_UpperBone, sIkEffector)
        sSoftIkScaleClamped = '%s.ScaleClamped' % sSoftIkEffector.split('.')[0]

        sUpperScaled = nodes.createBasicCalculateNode([sUpperLength, sSoftIkScaleClamped], sOperation='Multiply')
        nodes.createSetTranslationExecuteNode(eEntry_ElbowBone, [sUpperScaled,0,0], bLocal=True)
        sLowerScaled = nodes.createBasicCalculateNode([sLowerLength, sSoftIkScaleClamped], sOperation='Multiply')
        nodes.createSetTranslationExecuteNode(eEntry_WristBone, [sLowerScaled,0,0], bLocal=True)
        controllers.setNewColumn()
        controllers.closeCommentBox('Set Bone Lengths')

        controllers.openCommentBox('IK')
        controllers.setNewColumn()
        sNegative = nodes.createGetVariableNode(vNegative)
        sEntry_BackLeg = nodes.createGetEntryVariable('bBackLeg')
        controllers.setNewColumn()
        sSideMultipl = nodes.createIfNode(sNegative, -1.0, 1.0)
        sSideMultiplNegative = nodes.createIfNode(sNegative, 1.0, -1.0)
        sSecondaryAxisY = nodes.createIfNode(sEntry_BackLeg, sSideMultipl, sSideMultiplNegative)
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        sEntry_PoleControl = nodes.createGetEntryVariable('PoleControl')
        sIk = nodes.createIkTransformsNode(nodes.getTransformNode(eEntry_UpperBone), sSoftIkEffector,
                                           sUpperScaled, sLowerScaled, sPoleVector=nodes.getControlVector(sEntry_PoleControl),
                                           fPrimaryAxis=[sSideMultipl,0,0], fSecondaryAxis=[0,sSecondaryAxisY,0])

        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eEntry_UpperBone, '%s.Root' % sIk)
        nodes.createSetTransformExecuteNode(eEntry_ElbowBone, '%s.Elbow' % sIk)
        nodes.createSetTransformExecuteNode(eEntry_WristBone, '%s.Effector' % sIk)
        controllers.closeCommentBox('IK')


        controllers.openCommentBox('Wrist FK Control')
        controllers.setNewColumn()
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sWristPasserTransform = nodes.createProjectTransformToNewParent(eEntry_WristPasser, eEntry_WristBone)

        controllers.setNewColumn()
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_MidFingerRevControl = ELEM(nodes.createGetEntryVariable('MidFingerRevControl'), 'Control')
        eEntry_FingerAPasser = ELEM(nodes.createGetEntryVariable('FingerAPasser'), 'Null')
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eEntry_WristPasser, sWristPasserTransform)
        nodes.createParentConstraintExecuteNode([(eEntry_WristControl, 1)], eEntry_WristBone, bMaintainOffset=True)
        nodes.createRotationConstraintExecuteNode([(eEntry_MidFingerRevControl, 1)], eEntry_FingerAPasser, bMaintainOffset=True)
        controllers.closeCommentBox('Wrist FK Control')

        controllers.openCommentBox('MidFingerRev Control')
        controllers.setNewColumn()
        eEntry_MidFingerRevControl = ELEM(nodes.createGetEntryVariable('MidFingerRevControl'), 'Control')
        eEntry_FingerCPasser = ELEM(nodes.createGetEntryVariable('FingerCPasser'), 'Null')
        controllers.setNewColumn()
        sMidFingerRevLocal = nodes.getTransformNode(eEntry_MidFingerRevControl, bLocal=True)
        sPreTransform = nodes.getTransformNode(eEntry_FingerCPasser, bLocal=True, bInitial=True)
        sInverse = nodes.createInverseNode(sMidFingerRevLocal)
        sAddedInverse = nodes.createMakeAbsoluteNode(sInverse, sPreTransform)
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eEntry_FingerCPasser, sAddedInverse, bLocal=True)
        controllers.closeCommentBox('MidFingerRev Control')

        controllers.openCommentBox('Finger A')
        controllers.setNewColumn()
        eEntry_FingerAControl = ELEM(nodes.createGetEntryVariable('FingerAControl'), 'Control')
        eEntry_FingerABone = ELEM(nodes.createGetEntryVariable('FingerABone'), 'Bone')
        nodes.createRotationConstraintExecuteNode([(eEntry_FingerAControl, 1)], eEntry_FingerABone, bMaintainOffset=True)
        controllers.closeCommentBox('Finger A')

        controllers.openCommentBox('Finger B')
        controllers.setNewColumn()
        eEntry_FingerBControl = ELEM(nodes.createGetEntryVariable('FingerBControl'), 'Control')
        eEntry_FingerBBone = ELEM(nodes.createGetEntryVariable('FingerBBone'), 'Bone')
        nodes.createRotationConstraintExecuteNode([(eEntry_FingerBControl, 1)], eEntry_FingerBBone, bMaintainOffset=True)
        controllers.closeCommentBox('Finger B')

        controllers.openCommentBox('Finger C')
        controllers.setNewColumn()
        eEntry_FingerCControl = ELEM(nodes.createGetEntryVariable('FingerCControl'), 'Control')
        eEntry_FingerCBone = ELEM(nodes.createGetEntryVariable('FingerCBone'), 'Bone')
        nodes.createRotationConstraintExecuteNode([(eEntry_FingerCControl, 1)], eEntry_FingerCBone, bMaintainOffset=True)
        controllers.closeCommentBox('Finger C')

        controllers.openCommentBox('Pole Vector Line')
        controllers.setNewColumn()
        eEntry_PoleControl = ELEM(nodes.createGetEntryVariable('PoleControl'), 'Control')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        createLineFunction(eEntry_PoleControl, eEntry_ElbowBone)
        controllers.closeCommentBox('Pole Vector Line')

        
        nodes.endCurrentFunction(bAddToExecute=False)


    sHorseArmLegNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sBones[0], '%s.UpperBone' % sHorseArmLegNode)
    pins.setString(sBones[1], '%s.ElbowBone' % sHorseArmLegNode)
    pins.setString(sBones[2], '%s.WristBone' % sHorseArmLegNode)
    pins.setString(sBones[3], '%s.FingerABone' % sHorseArmLegNode)
    pins.setString(sBones[4], '%s.FingerBBone' % sHorseArmLegNode)
    pins.setString(sBones[5], '%s.FingerCBone' % sHorseArmLegNode)
    pins.connectToPin1D(bIsBackLeg, '%s.bBackLeg' % sHorseArmLegNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sHorseArmLegNode)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sHorseArmLegNode)
    pins.setString(cPole.ePasser.name, '%s.PolePasser' % sHorseArmLegNode)
    pins.setString(cPole.eControl.name, '%s.PoleControl' % sHorseArmLegNode)
    pins.setString(cMidFingerRev.ePasser.name, '%s.MidFingerRevPasser' % sHorseArmLegNode)
    pins.setString(cMidFingerRev.eControl.name, '%s.MidFingerRevControl' % sHorseArmLegNode)
    pins.setString(cAnkle.ePasser.name, '%s.AnkleAimOffset' % sHorseArmLegNode)
    pins.setString(cAnkle.eControl.name, '%s.AnkleControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[0].ePasser.name, '%s.WristPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[0].eControl.name, '%s.WristControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[1].ePasser.name, '%s.FingerAPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[1].eControl.name, '%s.FingerAControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[2].eControl.name, '%s.FingerBControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[3].ePasser.name, '%s.FingerCPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[3].eControl.name, '%s.FingerCControl' % sHorseArmLegNode)
    pins.setString(eStrPoleFollow.name, '%s.PoleFollow' % sHorseArmLegNode)

    return sHorseArmLegNode




def createHorseArmLegIkSetup_BACKWARDS(cIk, cPole, cAnkle, cHeel, cFingerRev, cMidFingerRev, cFkCtrls, sBones, eStrPoleFollow):

    sFunctionName = 'kangaroo_horseArmLegIk_BACKWARDS'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs= [('IkPasser', 'FName', False),
                                                      ('IkControl', 'FName', False),
                                                      ('AnkleControl', 'FName', False),
                                                      ('AnkleAimOffset', 'FName', False),
                                                      ('MidFingerRevPasser', 'FName', False),
                                                      ('MidFingerRevControl', 'FName', False),
                                                      ('FingerRevControl', 'FName', False),
                                                      ('HeelControl', 'FName', False),
                                                      ('PolePasser', 'FName', False),
                                                      ('PoleControl', 'FName', False),
                                                      ('PoleFollow', 'FName', False),
                                                      ('UpperBone', 'FName', False),
                                                      ('ElbowBone', 'FName', False),
                                                      ('WristBone', 'FName', False),
                                                      ('WristPasser', 'FName', False),
                                                      ('WristControl', 'FName', False),
                                                      ('FingerAPasser', 'FName', False),
                                                      ('FingerBPasser', 'FName', False),
                                                      ('FingerCPasser', 'FName', False),
                                                      ('FingerAControl', 'FName', False),
                                                      ('FingerBControl', 'FName', False),
                                                      ('FingerCControl', 'FName', False),
                                                      ('FingerABone', 'FName', False),
                                                      ('FingerBBone', 'FName', False),
                                                      ('FingerCBone', 'FName', False),
                                                      ('ATTACHER_root_noScap_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_noScap_r', 'FConstraintParent', True),
                                                      ('ATTACHER_root_t', 'FConstraintParent', True),
                                                      ('ATTACHER_root_r', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_t', 'FConstraintParent', True),
                                                      ('ATTACHER_hand_r', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_t', 'FConstraintParent', True),
                                                      ('ATTACHER_pole_r', 'FConstraintParent', True),
                                                      ])

        controllers.openCommentBox('Attachers 1')
        eEntry_IkPasser = ELEM(nodes.createGetEntryVariable('IkPasser'), 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_t', eEntry_IkPasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_hand_r', eEntry_IkPasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 1')


        controllers.openCommentBox('Ik Control')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        eEntry_IkControl = ELEM(sEntry_IkControl, 'Control')
        eEntry_FingerABone = ELEM(nodes.createGetEntryVariable('FingerABone'), 'Bone')
        eEntry_HeelControl = ELEM(nodes.createGetEntryVariable('HeelControl'), 'Control')
        eEntry_FingerRevControl = ELEM(nodes.createGetEntryVariable('FingerRevControl'), 'Control')
        eEntry_FingerMidRevControl = ELEM(nodes.createGetEntryVariable('MidFingerRevControl'), 'Control')
        controllers.setNewColumn()
        sOffsetA = nodes.createProjectTransformToNewParent(eEntry_HeelControl, eEntry_IkControl, hierarchy.eOrigin)
        sOffsetB = nodes.createProjectTransformToNewParent(eEntry_FingerRevControl, eEntry_HeelControl, hierarchy.eOrigin)
        sOffsetC = nodes.createProjectTransformToNewParent(eEntry_FingerMidRevControl, eEntry_FingerRevControl, hierarchy.eOrigin)
        sOffsetD = nodes.createProjectTransformToNewParent(eEntry_FingerABone, eEntry_FingerMidRevControl, hierarchy.eOrigin)
        controllers.setNewColumn()

        sHeelAnim = nodes.getTransformNode(eEntry_HeelControl, bLocal=True)
        sFingerRevAnim = nodes.getTransformNode(eEntry_FingerRevControl, bLocal=True)
        sFingerMidRevAnim = nodes.getTransformNode(eEntry_FingerMidRevControl, bLocal=True)
        sIncrementOffset = nodes.createBasicCalculateNode([sOffsetD, sFingerMidRevAnim, sOffsetC, sFingerRevAnim, sOffsetB, sHeelAnim, sOffsetA], iPinType=pins.PinType.transform)

        sInversedOffset = nodes.createInverseNode(sIncrementOffset)
        controllers.setNewColumn()
        sFingerATransform = nodes.getTransformNode(eEntry_FingerABone)
        sNewOffset = nodes.createMakeAbsoluteNode(sInversedOffset, sFingerATransform)
        nodes.createSetTransformExecuteNode(eEntry_IkControl, sNewOffset)
        controllers.closeCommentBox('Ik Control')


        # PoleFollow
        controllers.openCommentBox('pole follow')
        controllers.setNewColumn()
        eEntry_PoleFollow = ELEM(nodes.createGetEntryVariable('PoleFollow'), 'Null')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_UpperBone, 1)], eEntry_PoleFollow, skipRotate=['x','y','z'])
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        createKangarooAimConstraintFunction(eEntry_PoleFollow, eEntry_AnkleControl, eEntry_IkControl,  fAimVector=[1,0,0], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('pole follow')

        controllers.openCommentBox('Attachers 2')
        controllers.setNewColumn()
        sEntry_ATTACHER_pole_t = nodes.createGetEntryVariable('ATTACHER_pole_t')
        sEntry_ATTACHER_pole_r = nodes.createGetEntryVariable('ATTACHER_pole_r')
        eEntry_PolePasser = ELEM(nodes.createGetEntryVariable('PolePasser'), 'Null')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_t, eEntry_PolePasser, bMaintainOffset=True, skipRotate=['x', 'y', 'z'])
        nodes.createParentConstraintExecuteNode(sEntry_ATTACHER_pole_r, eEntry_PolePasser, bMaintainOffset=True, skipTranslate=['x', 'y', 'z'])
        controllers.closeCommentBox('Attachers 2')

        # controllers.openCommentBox('Reset FingerMid Control')
        # controllers.setNewColumn()
        # eEntry_MidFingerRevControl = ELEM(nodes.createGetEntryVariable('MidFingerRevControl'), 'Control')
        # nodes.createSetRotationExecuteNode(eEntry_MidFingerRevControl, bLocal=True)
        # controllers.closeCommentBox('Reset FingerMid Control')


        controllers.openCommentBox('Upper Length')
        controllers.setNewColumn()
        vUpperLength = hierarchy.newVariable('UpperLength')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        controllers.setNewColumn()
        sUpperLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True))
        sUpperLengthInitial = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True))
        sUpperScale = nodes.createBasicCalculateNode([sUpperLength, sUpperLengthInitial], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        nodes.createSetChannelNode(sEntry_IkControl, 'UpperScale', sUpperScale)
        nodes.createSetVariableExecuteNode(vUpperLength, sUpperLength)
        controllers.closeCommentBox('Upper Length')

        controllers.openCommentBox('Lower Length')
        controllers.setNewColumn()
        vLowerLength = hierarchy.newVariable('LowerLength')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sLowerLength = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True))
        sLowerLengthInitial = nodes.createMathAbs('%s.Translation.X' % nodes.getTransformNode(eEntry_WristBone, bLocal=True, bInitial=True))
        sLowerScale = nodes.createBasicCalculateNode([sLowerLength, sLowerLengthInitial], sOperation='Divide')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        nodes.createSetChannelNode(sEntry_IkControl, 'LowerScale', sLowerScale)
        nodes.createSetVariableExecuteNode(vLowerLength, sLowerLength)
        controllers.setNewColumn()
        controllers.closeCommentBox('Lower Length')


        controllers.openCommentBox('Ankle Aim')
        controllers.setNewColumn()
        eEntry_AnkleAimOffset = ELEM(nodes.createGetEntryVariable('AnkleAimOffset'), 'Null')
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        # eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        controllers.setNewColumn()
        sEntry_IkControl = nodes.createGetEntryVariable('IkControl')
        sAnkleAimAttr = nodes.createGetChannelNode2(sEntry_IkControl, 'ankleAim')
        createKangarooAimConstraintFunctionWeighted(eEntry_AnkleAimOffset, eEntry_UpperBone, eEntry_WristControl, fAimVector=[0, 0, 1], fUpVector=[0, 1, 0], fWorldUpVector=[0, 1, 0], fWeight=sAnkleAimAttr)#, eDefaultBone='Entry.IkOut')

        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_AnkleControl = ELEM(nodes.createGetEntryVariable('AnkleControl'), 'Control')
        nodes.createRotationConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_AnkleControl, bMaintainOffset=True)
        controllers.closeCommentBox('Ankle Aim')


        controllers.openCommentBox('Wrist FK Control')
        controllers.setNewColumn()
        eEntry_WristPasser = ELEM(nodes.createGetEntryVariable('WristPasser'), 'Null')
        eEntry_WristControl = ELEM(nodes.createGetEntryVariable('WristControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        sWristPasserTransform = nodes.createProjectTransformToNewParent(eEntry_WristPasser, eEntry_WristBone)

        nodes.createSetTransformExecuteNode(eEntry_WristPasser, sWristPasserTransform)
        nodes.createSetTransformExecuteNode(eEntry_WristControl, bLocal=True)
        controllers.closeCommentBox('Wrist FK Control')



        controllers.openCommentBox('Place Pole Ctrl - getting bones')

        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')

        controllers.setNewColumn()
        sUpperTransform = nodes.getTransformNode(eEntry_UpperBone)
        sElbowTransform = nodes.getTransformNode(eEntry_ElbowBone)
        sWristTransform = nodes.getTransformNode(eEntry_WristBone)
        controllers.closeCommentBox('Place Pole Ctrl - getting bones')

        controllers.openCommentBox('calculate NOT stretched')
        controllers.setNewColumn()
        sUpperLength = nodes.createGetVariableNode(vUpperLength)
        sLowerLength = nodes.createGetVariableNode(vLowerLength)
        sLengthSum = nodes.createBasicCalculateNode([sUpperLength, sLowerLength], sOperation='Add')
        sSecondFactor = nodes.createBasicCalculateNode([sUpperLength, sLengthSum], sOperation='Divide')
        sMiddlePoint = nodes.createVectorInterpolateNode(sSecondFactor, '%s.Translation' % sUpperTransform, '%s.Translation' % sWristTransform)
        sAim = nodes.createAimNode([sMiddlePoint, None, None], '%s.Translation' % sElbowTransform)
        sPoleVectorTransform = nodes.createMakeAbsoluteNode([[sLengthSum,0,0], None, None], sAim)
        controllers.closeCommentBox('calculate NOT stretched')

        controllers.openCommentBox('calculate stretched')
        controllers.setNewColumn()
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        sElbowInitial = nodes.getTransformNode(eEntry_ElbowBone, bLocal=True, bInitial=True)
        sPoleVectorTransformStretched = nodes.createMakeAbsoluteNode([['%s.Translation.X' % sElbowInitial, sLengthSum, 0.0], None, None], sUpperTransform)
        controllers.closeCommentBox('calculate stretched')

        controllers.openCommentBox('interpolating poles')
        controllers.setNewColumn()
        eEntry_UpperBone = ELEM(nodes.createGetEntryVariable('UpperBone'), 'Bone')
        eEntry_ElbowBone = ELEM(nodes.createGetEntryVariable('ElbowBone'), 'Bone')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        sAngle = angleFromJointsFunction(eEntry_UpperBone, eEntry_ElbowBone, eEntry_WristBone)
        sAngleRemap = nodes.createRemapNode(sAngle, 155, 175, 0, 1)
        sPoleBlend = nodes.createVectorInterpolateNode(sAngleRemap, '%s.Translation' % sPoleVectorTransform, '%s.Translation' % sPoleVectorTransformStretched)
        controllers.setNewColumn()
        eEntry_PoleControl = ELEM(nodes.createGetEntryVariable('PoleControl'), 'Control')
        nodes.createSetTranslationExecuteNode(eEntry_PoleControl, sPoleBlend)
        controllers.closeCommentBox('interpolating poles')

        controllers.openCommentBox('FingerA')
        controllers.setNewColumn()
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        eEntry_FingerABone = ELEM(nodes.createGetEntryVariable('FingerABone'), 'Bone')
        eEntry_FingerAControl = ELEM(nodes.createGetEntryVariable('FingerAControl'), 'Control')
        eEntry_FingerAPasser = ELEM(nodes.createGetEntryVariable('FingerAPasser'), 'Null')
        eEntry_MidFingerRevControl = ELEM(nodes.createGetEntryVariable('MidFingerRevControl'), 'Control')

        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_WristBone, 1)], eEntry_FingerAPasser, skipRotate=['x','y','z'], bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eEntry_MidFingerRevControl, 1)], eEntry_FingerAPasser, skipTranslate=['x','y','z'], bMaintainOffset=True)
        nodes.createRotationConstraintExecuteNode([(eEntry_FingerABone, 1)], eEntry_FingerAControl, bMaintainOffset=True)
        controllers.closeCommentBox('FingerA')

        controllers.setNewColumn()
        controllers.openCommentBox('FingerB')
        eEntry_FingerBBone = ELEM(nodes.createGetEntryVariable('FingerBBone'), 'Bone')
        eEntry_FingerBControl = ELEM(nodes.createGetEntryVariable('FingerBControl'), 'Control')
        eEntry_FingerBPasser = ELEM(nodes.createGetEntryVariable('FingerBPasser'), 'Null')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_FingerABone, 1)], eEntry_FingerBPasser, bMaintainOffset=True)
        nodes.createRotationConstraintExecuteNode([(eEntry_FingerBBone, 1)], eEntry_FingerBControl, bMaintainOffset=True)
        controllers.closeCommentBox('FingerB')

        controllers.setNewColumn()
        controllers.openCommentBox('FingerC')


        controllers.openCommentBox('MidFingerRev Control')
        controllers.setNewColumn()
        eEntry_MidFingerRevControl = ELEM(nodes.createGetEntryVariable('MidFingerRevControl'), 'Control')
        eEntry_FingerCPasser = ELEM(nodes.createGetEntryVariable('FingerCPasser'), 'Null')
        controllers.setNewColumn()
        sBallRevLocal = nodes.getTransformNode(eEntry_MidFingerRevControl, bLocal=True)
        sPreTransform = nodes.getTransformNode(eEntry_FingerCPasser, bLocal=True, bInitial=True)
        sInverse = nodes.createInverseNode(sBallRevLocal)
        sAddedInverse = nodes.createMakeAbsoluteNode(sInverse, sPreTransform)
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eEntry_FingerCPasser, sAddedInverse, bLocal=True)
        controllers.closeCommentBox('MidFingerRev Control')



        eEntry_FingerCBone = ELEM(nodes.createGetEntryVariable('FingerCBone'), 'Bone')
        eEntry_FingerCControl = ELEM(nodes.createGetEntryVariable('FingerCControl'), 'Control')
        eEntry_FingerCPasser = ELEM(nodes.createGetEntryVariable('FingerCPasser'), 'Null')
        controllers.setNewColumn()
        # nodes.createParentConstraintExecuteNode([(eEntry_FingerBBone, 1)], eEntry_FingerCPasser, bMaintainOffset=True)
        nodes.createRotationConstraintExecuteNode([(eEntry_FingerCBone, 1)], eEntry_FingerCControl, bMaintainOffset=True)
        controllers.closeCommentBox('FingerC')

        nodes.endCurrentFunction(bAddToExecute=False)


    sHorseArmLegNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sBones[0], '%s.UpperBone' % sHorseArmLegNode)
    pins.setString(sBones[1], '%s.ElbowBone' % sHorseArmLegNode)
    pins.setString(sBones[2], '%s.WristBone' % sHorseArmLegNode)
    pins.setString(sBones[3], '%s.FingerABone' % sHorseArmLegNode)
    pins.setString(sBones[4], '%s.FingerBBone' % sHorseArmLegNode)
    pins.setString(sBones[5], '%s.FingerCBone' % sHorseArmLegNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sHorseArmLegNode)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sHorseArmLegNode)
    pins.setString(cPole.ePasser.name, '%s.PolePasser' % sHorseArmLegNode)
    pins.setString(cPole.eControl.name, '%s.PoleControl' % sHorseArmLegNode)
    pins.setString(cAnkle.eControl.name, '%s.AnkleControl' % sHorseArmLegNode)
    pins.setString(cHeel.eControl.name, '%s.HeelControl' % sHorseArmLegNode)
    pins.setString(cFingerRev.eControl.name, '%s.FingerRevControl' % sHorseArmLegNode)
    pins.setString(cMidFingerRev.eControl.name, '%s.MidFingerRevControl' % sHorseArmLegNode)
    pins.setString(cMidFingerRev.ePasser.name, '%s.MidFingerRevPasser' % sHorseArmLegNode)
    pins.setString(cAnkle.ePasser.name, '%s.AnkleAimOffset' % sHorseArmLegNode)
    pins.setString(eStrPoleFollow.name, '%s.PoleFollow' % sHorseArmLegNode)
    pins.setString(cFkCtrls[0].ePasser.name, '%s.WristPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[0].eControl.name, '%s.WristControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[1].ePasser.name, '%s.FingerAPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[2].ePasser.name, '%s.FingerBPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[3].ePasser.name, '%s.FingerCPasser' % sHorseArmLegNode)
    pins.setString(cFkCtrls[1].eControl.name, '%s.FingerAControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[2].eControl.name, '%s.FingerBControl' % sHorseArmLegNode)
    pins.setString(cFkCtrls[3].eControl.name, '%s.FingerCControl' % sHorseArmLegNode)
    return sHorseArmLegNode







def twistUpper(sUpper, sParent, sElbow, fStraightRotateOffset=None, bPlaneAxisIsZ=True, fSideMultipl=1.0, sAimTarget=None, bDebug=False):

    # bUseAimTarget = not library.isNone(sAimTarget)
    sFunctionName = 'kangaroo_twistUpper'
    # if bUseAimTarget:
    #     sFunctionName = '%s_aimTarget' % sFunctionName

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, [('Upper', 'FName', False),
                                                   ('Parent', 'FName', False),
                                                   ('Elbow', 'FName', False),
                                                   ('StraightRotateOffset', 'FVector', False),
                                                   ('Leaves', 'FName', True),
                                                   ('PlaneAxisIsZ', 'bool', False),
                                                   ('bDebug', 'bool', False),
                                                   ('SideMultipl', 'float', False),
                                                   ('AimTarget', 'FVector', False),
                                                   ('HasAimTarget', 'bool', False)],
                                        xOutputs=[('TwistAngle', 'float', False)])

        controllers.openCommentBox('Get Bones Before')
        vUpperBefore = hierarchy.newVariable('UpperBefore', 'FTransform')
        nodes.createSetVariableExecuteNode(vUpperBefore, nodes.getTransformNode(ELEM('Entry.Upper', 'Bone')))

        controllers.setNewColumn()
        vElbowBefore = hierarchy.newVariable('ElbowBefore', 'FTransform')
        nodes.createSetVariableExecuteNode(vElbowBefore, nodes.getTransformNode(ELEM('Entry.Elbow', 'Bone')))
        controllers.closeCommentBox('Get Bones Before')

        controllers.openCommentBox('Get Straight Pose')
        controllers.setNewColumn()
        eEntry_Upper = ELEM(nodes.createGetEntryVariable('Upper'), 'Bone')
        sUpperInitial = nodes.getTransformNode(eEntry_Upper, bInitial=True)
        controllers.setNewColumn()
        sEntry_StraightRotateOffset = nodes.createGetEntryVariable('StraightRotateOffset')
        sFromEuler = nodes.createFromEulerNode(sEntry_StraightRotateOffset, sOrder='XYZ')
        sStraightPose = nodes.createMakeAbsoluteNode([None, sFromEuler, None], sUpperInitial)
        vStraightPose = hierarchy.newVariable('StraightPose', 'FTransform')
        nodes.createSetVariableExecuteNode(vStraightPose, sStraightPose)
        controllers.setNewColumn()
        sEntry_Debug = nodes.createGetEntryVariable('bDebug')
        nodes.createDrawTransformNode(sStraightPose, bEnabled=sEntry_Debug)
        controllers.setNewColumn()
        controllers.closeCommentBox('Get Straight Pose')

        controllers.openCommentBox('Calculate ParentWithOffset')
        controllers.setNewColumn()
        sEntry_Parent = nodes.createGetEntryVariable('Parent')
        eParent = ELEM(sEntry_Parent, 'Bone')
        sParentInitial = nodes.getTransformNode(eParent, bInitial=True)
        sParentCurrent = nodes.getTransformNode(eParent)

        controllers.setNewColumn()
        eEntry_Upper = ELEM(nodes.createGetEntryVariable('Upper'), 'Bone')
        sUpperLocalInitial = nodes.getTransformNode(eEntry_Upper, bInitial=True, bLocal=True)
        sParentPlusPosInitial = nodes.createMakeAbsoluteNode(['%s.Translation' % sUpperLocalInitial, None, None], sParentInitial)
        sUpperLocal = nodes.getTransformNode(eEntry_Upper, bLocal=True)
        sParentPlusPos = nodes.createMakeAbsoluteNode(['%s.Translation' % sUpperLocal, None, None], sParentCurrent)

        controllers.setNewColumn()
        sStraightPose = nodes.createGetVariableNode(vStraightPose)
        sRel = nodes.createMakeRelativeNode(sStraightPose, sParentPlusPosInitial)
        sParentWithOffset = nodes.createMakeAbsoluteNode(sRel, sParentPlusPos)
        vParentWithOffset = hierarchy.newVariable('ParentWithOffset', 'FTransform')
        nodes.createSetVariableExecuteNode(vParentWithOffset, sParentWithOffset)
        controllers.closeCommentBox('Calculate ParentWithOffset')


        controllers.openCommentBox('Calculate Normalized Elbow')
        controllers.setNewColumn()
        sElbowBefore = nodes.createGetVariableNode(vElbowBefore)
        sParentWithOffset = nodes.createGetVariableNode(vParentWithOffset)
        sLocalElbow = nodes.createMakeRelativeNode(['%s.Translation' %  sElbowBefore, None, None], sParentWithOffset) #instead of sElbowBefore it was sExtraElbow
        sNormalizedElbow = nodes.createSetLengthVector('%s.Translation' % sLocalElbow)
        controllers.closeCommentBox('Calculate Normalized Elbow')

        controllers.openCommentBox('Calculate Initial Normalized Elbow')
        controllers.setNewColumn()
        sElbowInitial = nodes.getTransformNode(ELEM(nodes.createGetEntryVariable('Elbow'), 'Bone'), bInitial=True)
        sStraightPose = nodes.createGetVariableNode(vStraightPose)
        sLocalElbowInitial = nodes.createMakeRelativeNode(['%s.Translation' %  sElbowInitial, None, None], sStraightPose)
        sNormalizedElbowInitial = nodes.createSetLengthVector('%s.Translation' % sLocalElbowInitial)
        controllers.closeCommentBox('Calculate Initial Normalized Elbow')

        controllers.openCommentBox('Calculate Plane Vector')
        controllers.setNewColumn()
        sEntry_PlaneAxisIsZ = nodes.createGetEntryVariable('PlaneAxisIsZ')
        sUpperUpVector = nodes.createIfNode(sEntry_PlaneAxisIsZ, [0,-1,0],  [0,0,-1], iPinType=pins.PinType.vector)
        vUpperUpVector = hierarchy.newVariable('UpperUpVector', 'FVector')
        nodes.createSetVariableExecuteNode(vUpperUpVector, sUpperUpVector)
        controllers.setNewColumn()
        sPlaneVector = nodes.createCrossProductNode(sNormalizedElbowInitial, sUpperUpVector)
        sPlaneVector = nodes.createBasicCalculateNode([sPlaneVector, [-1,-1,-1]], iPinType=pins.PinType.vector)
        controllers.closeCommentBox('Calculate Plane Vector')


        controllers.openCommentBox('Calculate Pole')
        controllers.setNewColumn()
        sEntry_PlaneAxisIsZ = nodes.createGetEntryVariable('PlaneAxisIsZ')
        controllers.setNewColumn()
        sAxisChoose = nodes.createIfNode(sEntry_PlaneAxisIsZ, '%s.Z' % sNormalizedElbow, '%s.Y' % sNormalizedElbow)
        sChosenAxisAbs = nodes.createMathAbs(sAxisChoose)

        controllers.setNewColumn()
        sUpperUpVector = nodes.createGetVariableNode(vUpperUpVector)
        sPolePos = nodes.createRemapNode(sChosenAxisAbs, 0, 1,
                                         nodes.createCrossProductNode(sNormalizedElbow, sPlaneVector),
                                         sUpperUpVector, bOutIsVector=True)
        controllers.setNewColumn()
        sPolePosLonger = nodes.createBasicCalculateNode([sPolePos, [20,20,20]], iPinType=pins.PinType.vector)
        sParentWithOffset = nodes.createGetVariableNode(vParentWithOffset)
        sPolePosAbs = nodes.createMakeAbsoluteNode([sPolePosLonger, None, None], sParentWithOffset)
        controllers.setNewColumn()
        sEntry_Debug = nodes.createGetEntryVariable('bDebug')
        nodes.createDrawLineNode('%s.Translation' % sParentWithOffset, '%s.Translation' % sPolePosAbs, fThickness=0.5, fColor=[1.0,1.0,1.0], bEnabled=sEntry_Debug)
        controllers.closeCommentBox('Calculate Pole')

        controllers.openCommentBox('Target and Aim')
        controllers.setNewColumn()
        sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
        sUpperUpVector = nodes.createGetVariableNode(vUpperUpVector)
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sEntry_AimTarget = nodes.createGetEntryVariable('AimTarget')
        sAim = nodes.createAimNode(sUpperBefore, sEntry_AimTarget, fAimVector=[sEntry_SideMultipl,0,0], fUpVector=sUpperUpVector)
        controllers.setNewColumn()
        sEntry_Upper = nodes.createGetEntryVariable('Upper')
        nodes.createSetTransformExecuteNode(ELEM(sEntry_Upper, 'Bone'), sAim)
        controllers.closeCommentBox('Target and Aim')

        controllers.setNewColumn()
        controllers.openCommentBox('Set Elbow to Previous')
        sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        sElbowBefore = nodes.createGetVariableNode(vElbowBefore)
        nodes.createSetTransformExecuteNode(ELEM(sEntry_Elbow, 'Bone'), sElbowBefore)
        controllers.closeCommentBox('Set Elbow to Previous')

        pins.connectItem(hierarchy.eOrigin, '%s.Secondary.Space' % sAim.split('.')[0])
        pins.connectToPinVector('%s.Translation' % sPolePosAbs, '%s.Secondary.Target' % sAim.split('.')[0])

        controllers.openCommentBox('Calculate Twist')
        controllers.setNewColumn()
        sUpperBefore = nodes.createGetVariableNode(vUpperBefore)
        sChanges = nodes.createMakeRelativeNode(sUpperBefore, sAim)
        sEuler = nodes.createToEulerNode('%s.Rotation' % sChanges)
        pins.connectToPin1D('%s.X' % sEuler, 'Return.TwistAngle')
        controllers.closeCommentBox('Calculate Twist')

        # controllers.openCommentBox('Leaves')
        # controllers.setNewColumn()
        # sEntry_Leaves = nodes.createGetEntryVariable('Leaves')
        # sEntry_Upper = nodes.createGetEntryVariable('Upper')
        # sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        # if bUseAimTarget:
        # sEntry_HasAimTarget = nodes.createGetEntryVariable('HasAimTarget')
        # sEntry_AimTarget = nodes.createGetEntryVariable('AimTarget')
        # twistLeavesFunction(sEntry_Leaves, '%s.X' % sEuler, sEntry_Upper, sEntry_Elbow, sAimTarget=sEntry_AimTarget, sBendyPasser='Entry.BendyPasser', sBendyControl='Entry.BendyPasser')
        # else:
        #     twistLeavesFunction(sEntry_Leaves, '%s.X' % sEuler, sEntry_Upper, sEntry_Elbow, bHasAimTarget=False, cBendys=cBendys)
        # controllers.closeCommentBox('Leaves')

        nodes.endCurrentFunction(bAddToExecute=False)

    sTwistNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[200,600])

    pins.setString(sUpper, '%s.Upper' % sTwistNode)
    pins.setString(sParent, '%s.Parent' % sTwistNode)
    pins.setString(sElbow, '%s.Elbow' % sTwistNode)
    pins.connectToPinVector(fStraightRotateOffset, '%s.StraightRotateOffset' % sTwistNode)
    pins.connectToPin1D(bPlaneAxisIsZ, '%s.PlaneAxisIsZ' % sTwistNode)
    pins.connectToPin1D(bDebug, '%s.bDebug' % sTwistNode)
    if library.isNone(sAimTarget):
        pins.connectToPin1D(False, '%s.HasAimTarget' % sTwistNode)
    else:
        pins.connectToPin1D(True, '%s.HasAimTarget' % sTwistNode)
        pins.connectToPinVector(sAimTarget, '%s.AimTarget' % sTwistNode)
    pins.connectToPin1D(fSideMultipl, '%s.SideMultipl' % sTwistNode)

    # pins.setStringArray(sLeaves, '%s.Leaves' % sTwistNode)

    return sTwistNode


def twistLeavesBendyFunction(sLeaves, sTwistAngle, sParent, sChild, fSideMultipl, sAimTarget=None, sBendyPasser=None, sBendyControl=None, bDebug=False):
    sFunctionName = 'kangaroo_twistLeavesBendy'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, [('TwistAngle', 'float', None),
                                                   ('Parent', 'FName', False),
                                                   ('Child', 'FName', False),
                                                   ('Leaves', 'FName', 3),
                                                   ('Control', 'FName', False),
                                                   ('Passer', 'FName', False),
                                                   ('HasAimTarget', 'bool', False),
                                                   ('AimTarget', 'FVector', False),
                                                   ('SideMultipl', 'float', False),
                                                   ('bDebug', 'bool', False),
                                            ])
        eEntry_Parent = ELEM('Entry.Parent', 'Bone')
        eEntry_Passer = ELEM('Entry.Passer', 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_Parent, 1)], eEntry_Passer, bMaintainOffset=True)


        controllers.openCommentBox('Get Scale')
        controllers.setNewColumn()
        sParentTransform = nodes.getTransformNode(ELEM('Entry.Parent', 'Bone'))

        vChildAimLocal = hierarchy.newVariable('ChildAimLocal', 'FVector', bLocal=True)
        vEndPoint = hierarchy.newVariable('EndPoint', 'FVector', bLocal=True)
        nodes.createBranchExecuteNode('Entry.HasAimTarget')
        eEntry_Child = ELEM(nodes.createGetEntryVariable('Child'), 'Bone')
        vScaleFactor = hierarchy.newVariable('ScaleFactor', 'float', bLocal=True)
        if controllers.BLOCK_BRANCH_TRUE:
            controllers.setNewColumn()
            sEntry_AimTarget = nodes.createGetEntryVariable('AimTarget')
            nodes.createSetVariableExecuteNode(vEndPoint, sEntry_AimTarget)
            sChildAimLocal = nodes.createMakeRelativeNode([sEntry_AimTarget,None,None], sParentTransform)
            sChildInitial = nodes.getTransformNode(eEntry_Child, bInitial=True, bLocal=True)
            sScaleFactor = nodes.createBasicCalculateNode(['%s.Translation.X' % sChildAimLocal, '%s.Translation.X' % sChildInitial], sOperation='Divide')
            controllers.setNewColumn()
            nodes.createSetVariableExecuteNode(vScaleFactor, sScaleFactor)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.setNewColumn()
            eEntry_Child = ELEM(nodes.createGetEntryVariable('Child'), 'Bone')
            sChildAim = nodes.getTransformNode(eEntry_Child)
            nodes.createSetVariableExecuteNode(vEndPoint, '%s.Translation' % sChildAim)
            sChildAimLocal = nodes.getTransformNode(eEntry_Child, bLocal=True)
            nodes.createSetVariableExecuteNode(vChildAimLocal, '%s.Translation' % sChildAimLocal)
            sChildInitial = nodes.getTransformNode(eEntry_Child, bInitial=True, bLocal=True)
            sScaleFactor = nodes.createBasicCalculateNode(['%s.Translation.X' % sChildAimLocal, '%s.Translation.X' % sChildInitial], sOperation='Divide')
            controllers.setNewColumn()
            nodes.createSetVariableExecuteNode(vScaleFactor, sScaleFactor)
            controllers.goToParentExecute()
        controllers.setNewColumn()
        controllers.closeCommentBox('Get Scale')


        controllers.openCommentBox('Calculate Params')
        controllers.setNewColumn()
        sEntry_Leaves = nodes.createGetEntryVariable('Leaves')
        eFirstLeave = ELEM(nodes.createArrayAtNode(sEntry_Leaves, 0), 'Bone')
        sAlreadyThere = nodes.createHasMetaData(eFirstLeave, 'Param', pins.PinType.double)
        nodes.createBranchExecuteNode(sAlreadyThere)
        if controllers.BLOCK_BRANCH_TRUE:
            # nothing
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.setNewColumn()
            eEntry_Parent = ELEM(nodes.createGetEntryVariable('Parent'), 'Bone')
            eEntry_Child = ELEM(nodes.createGetEntryVariable('Child'), 'Bone')
            controllers.setNewColumn()
            sParentInitial = nodes.getTransformNode(eEntry_Parent, bInitial=True)
            sChildInitial = nodes.getTransformNode(eEntry_Child, bInitial=True)
            controllers.setNewColumn()
            sPoints = ['%s.Translation' % sParentInitial,
                       nodes.createVectorInterpolateNode(0.4, '%s.Translation' % sParentInitial, '%s.Translation' % sChildInitial),
                       nodes.createVectorInterpolateNode(0.6, '%s.Translation' % sParentInitial, '%s.Translation' % sChildInitial),
                       '%s.Translation' % sChildInitial]

            controllers.setNewColumn()
            eControl = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
            sControlTransformInitial = nodes.getTransformNode(eControl, bInitial=True)
            controllers.setNewColumn()
            # vPointOffset1 = hierarchy.newVariable('PointOffset1', 'FVector', bLocal=False)
            nodes.createSetMetaDataExecuteNode(eControl, 'PointOffset1', '%s.Translation' % nodes.createMakeRelativeNode([sPoints[1], None, None], sControlTransformInitial), iType=pins.PinType.vector)
            controllers.setNewColumn()
            # vPointOffset2 = hierarchy.newVariable('PointOffset2', 'FVector', bLocal=False)
            nodes.createSetMetaDataExecuteNode(eControl, 'PointOffset2', '%s.Translation' % nodes.createMakeRelativeNode([sPoints[2], None, None], sControlTransformInitial), iType=pins.PinType.vector)
            # nodes.createSetVariableExecuteNode(vPointOffset2, '%s.Translation' % nodes.createMakeRelativeNode([sPoints[2], None, None], sControlTransformInitial))
            controllers.setNewColumn()

            controllers.setNewColumn()
            sSplineInitial = nodes.createSplineFromPositionsNode(sPoints)
            controllers.setNewColumn()
            sEntry_Leaves = nodes.createGetEntryVariable('Leaves')
            sForEach = nodes.createForEachExecuteNode(sEntry_Leaves)
            if controllers.BLOCK_FOREACH:
                eTwistBone = ELEM('%s.Element' % sForEach, 'Bone')
                sTwistTransformInitial = nodes.getTransformNode(eTwistBone, bInitial=True)
                sParam = nodes.createGetParamFromPositionOnSpline(sSplineInitial, '%s.Translation' % sTwistTransformInitial)
                nodes.createSetMetaDataExecuteNode(eTwistBone, 'Param', sParam, iType=pins.PinType.double)
                controllers.goToParentExecute()
            controllers.goToParentExecute()
        controllers.closeCommentBox('Calculate Params')

        controllers.openCommentBox('Debug - Draw Initial Spline')
        controllers.setNewColumn()
        sEntry_bDebug = nodes.createGetEntryVariable('bDebug')
        nodes.createBranchExecuteNode(sEntry_bDebug)
        if controllers.BLOCK_BRANCH_TRUE:
            nodes.createDrawSplineNode(sSplineInitial, fColor=[0,1,1])
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.goToParentExecute()
        controllers.closeCommentBox('Debug - Draw Initial Spline')



        controllers.openCommentBox('Create and Deform Spline')
        controllers.setNewColumn()
        sStartPoint = '%s.Translation' % nodes.getTransformNode(eEntry_Parent)
        controllers.setNewColumn()
        sEndPoint = nodes.createGetVariableNode(vEndPoint)
        sPoints = [sStartPoint,
                   None,
                   None,
                   sEndPoint]

        eControl = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
        sControlTransform = nodes.getTransformNode(eControl)
        controllers.setNewColumn()
        sPoints[1] = '%s.Translation' % nodes.createMakeAbsoluteNode([nodes.createGetMetaData(eControl, 'PointOffset1', iType=pins.PinType.vector), None, None], sControlTransform)
        sPoints[2] = '%s.Translation' % nodes.createMakeAbsoluteNode([nodes.createGetMetaData(eControl, 'PointOffset2', iType=pins.PinType.vector), None, None], sControlTransform)
        controllers.setNewColumn()
        sSpline = nodes.createSplineFromPositionsNode(sPoints)
        controllers.closeCommentBox('Create and Deform Spline')


        controllers.openCommentBox('Debug - Draw Spline')
        controllers.setNewColumn()
        sEntry_bDebug = nodes.createGetEntryVariable('bDebug')
        nodes.createBranchExecuteNode(sEntry_bDebug)
        if controllers.BLOCK_BRANCH_TRUE:
            nodes.createDrawSplineNode(sSpline)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.goToParentExecute()
        controllers.closeCommentBox('Debug - Draw Spline')

        controllers.openCommentBox('Get Parent Rotation Before')
        controllers.setNewColumn()
        vRotationBefore = hierarchy.newVariable('Rotation Before', 'FQuat')
        eParent = ELEM(nodes.createGetEntryVariable('Parent'), 'Bone')
        sParentTransform = nodes.getTransformNode(eParent)
        nodes.createSetVariableExecuteNode(vRotationBefore, '%s.Rotation' % sParentTransform)
        controllers.closeCommentBox('Get Parent Rotation Before')

        controllers.openCommentBox('Put Joints to Spline and Twist')
        controllers.setNewColumn()
        sEntry_Leaves = nodes.createGetEntryVariable('Leaves')
        sForEach = nodes.createForEachExecuteNode(sEntry_Leaves)
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eLeave = ELEM('%s.Element' % sForEach, 'Bone')
            sIndexPlusOne = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add', iPinType=pins.PinType.integer)
            sIndexFloat = nodes.createToFloatNode(sIndexPlusOne)
            sDivided = nodes.createBasicCalculateNode([1.0, nodes.createToFloatNode('%s.Count' % sForEach)], sOperation='Divide')
            sRatio = nodes.createBasicCalculateNode(['Entry.TwistAngle', sIndexFloat, sDivided], sOperation='Multiply')
            sFromEuler = nodes.createFromEulerNode([sRatio, 0, 0])

            controllers.setNewColumn()
            sParam = nodes.createGetMetaData(eLeave, 'Param', iType=pins.PinType.double)
            controllers.setNewColumn()
            sPositionOnSpline = nodes.createGetPositionOnSpline(sSpline, sParam)
            sTangentOnSpline = nodes.createGetTangentOnSpline(sSpline, sParam)
            sParentRotation = nodes.createGetVariableNode(vRotationBefore)
            sUpVector = nodes.createMakeAbsoluteNode(sFromEuler, sParentRotation, bQuat=True)
            sUpVector = nodes.createRotateVectorNode([0,0,1], sUpVector)
            controllers.setNewColumn()
            sEntry_SideMultipl = nodes.createGetEntryVariable('SideMultipl')
            sAimTransform = nodes.createAimNode([sPositionOnSpline, None, None], sTangentOnSpline, fAimVector=[sEntry_SideMultipl,0,0], fWorldUpVector=sUpVector, bUpIsDirection=True, bTargetIsDirection=True)
            controllers.setNewColumn()
            bPropagate = nodes.createConditionNodes('%s.Index' % sForEach, '>', 0, iTermsPinType=pins.PinType.integer)
            nodes.createSetTransformExecuteNode(eLeave, sAimTransform, bPropagateToChildren=bPropagate)

            controllers.setNewColumn()
            controllers.goToParentExecute()
        controllers.closeCommentBox('Put Joints to Spline and Twist')

        nodes.endCurrentFunction(bAddToExecute=False)

    sLeavesNode = nodes.addFunctionNode(sFunctionName)
    pins.connectToPin1D(sTwistAngle, '%s.TwistAngle' % sLeavesNode)
    if library.isNone(sAimTarget):
        pins.connectToPin1D(False, '%s.HasAimTarget' % sLeavesNode)
    else:
        pins.connectToPin1D(True, '%s.HasAimTarget' % sLeavesNode)
        pins.connectToPin1D(sAimTarget, '%s.AimTarget' % sLeavesNode)
    pins.setString(sChild, '%s.Child' % sLeavesNode)
    pins.setString(sParent, '%s.Parent' % sLeavesNode)
    pins.setString(sBendyPasser, '%s.Passer' % sLeavesNode)
    pins.setString(sBendyControl, '%s.Control' % sLeavesNode)
    pins.connectToPin1D(bDebug, '%s.bDebug' % sLeavesNode)
    pins.connectToPin1D(fSideMultipl, '%s.SideMultipl' % sLeavesNode)

    if isinstance(sLeaves, str):
        pins.connectToPin1D(sLeaves, '%s.Leaves' % sLeavesNode)
    else:
        raise Exception('array connection not working yet. needs to get copied from the twistUpper() function')
    return sLeavesNode


def twistLeavesFunction(sLeaves, sTwistAngle, sParent, sChild, sAimTarget=None):
    # bDoBendy = not library.isNone(sAimTarget)
    sFunctionName = 'kangaroo_twistLeaves'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, [('TwistAngle', 'float', None),
                                                   ('Parent', 'FName', False),
                                                   ('Child', 'FName', False),
                                                   ('Leaves', 'FName', 3),
                                                   ('Control', 'FName', False),
                                                   ('Passer', 'FName', False),
                                                   ('HasAimTarget', 'bool', False),
                                                   ('AimTarget', 'FVector', False)])


        controllers.openCommentBox('Get Scale')
        controllers.setNewColumn()
        sParentTransform = nodes.getTransformNode(ELEM('Entry.Parent', 'Bone'))

        vChildAimLocal = hierarchy.newVariable('ChildAimLocal', 'FVector', bLocal=True)
        nodes.createBranchExecuteNode('Entry.HasAimTarget')
        eEntry_Child = ELEM(nodes.createGetEntryVariable('Child'), 'Bone')
        vScaleFactor = hierarchy.newVariable('ScaleFactor', 'float', bLocal=True)
        if controllers.BLOCK_BRANCH_TRUE:
            controllers.setNewColumn()
            sChildAimLocal = nodes.createMakeRelativeNode(['Entry.AimTarget',None,None], sParentTransform)
            sChildInitial = nodes.getTransformNode(eEntry_Child, bInitial=True, bLocal=True)
            sScaleFactor = nodes.createBasicCalculateNode(['%s.Translation.X' % sChildAimLocal, '%s.Translation.X' % sChildInitial], sOperation='Divide')
            controllers.setNewColumn()
            nodes.createSetVariableExecuteNode(vScaleFactor, sScaleFactor)
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            controllers.setNewColumn()
            sChildAimLocal = nodes.getTransformNode(ELEM('Entry.Child', 'Bone'), bLocal=True)
            nodes.createSetVariableExecuteNode(vChildAimLocal, '%s.Translation' % sChildAimLocal)
            sChildInitial = nodes.getTransformNode(eEntry_Child, bInitial=True, bLocal=True)
            sScaleFactor = nodes.createBasicCalculateNode(['%s.Translation.X' % sChildAimLocal, '%s.Translation.X' % sChildInitial], sOperation='Divide')
            controllers.setNewColumn()
            nodes.createSetVariableExecuteNode(vScaleFactor, sScaleFactor)
            controllers.goToParentExecute()

        controllers.setNewColumn()
        controllers.closeCommentBox('Get Scale')


        # controllers.setNewColumn()
        # eEntry_Parent = ELEM(nodes.createGetEntryVariable('Parent'), 'Bone')
        # eEntry_Child = ELEM(nodes.createGetEntryVariable('Child'), 'Bone')
        # controllers.setNewColumn()
        # sParentTransform = nodes.getTransformNode(eEntry_Parent)
        # sChildTransform = nodes.getTransformNode(eEntry_Child)
        # sParentPosition = nodes.createVectorInterpolateNode(0.5, '%s.Translation' % sParentTransform, '%s.Translation' % sChildTransform)
        # controllers.setNewColumn()
        # eEntry_Passer = ELEM(nodes.createGetEntryVariable('Passer'), 'Null')
        # nodes.createSetTransformExecuteNode(eEntry_Passer, [sParentPosition, '%s.Rotation' % sParentTransform, None])

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.Leaves')
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eLeave = ELEM('%s.Element' % sForEach, 'Bone')
            sIndexPlusOne = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add', iPinType=pins.PinType.integer)
            sIndexFloat = nodes.createToFloatNode(sIndexPlusOne)
            sDivided = nodes.createBasicCalculateNode([1.0, nodes.createToFloatNode('%s.Count' % sForEach)], sOperation='Divide')
            sRatio = nodes.createBasicCalculateNode(['Entry.TwistAngle', sIndexFloat, sDivided], sOperation='Multiply')
            sFromEuler = nodes.createFromEulerNode([sRatio, 0, 0])

            controllers.setNewColumn()
            sDefaultLeaveX = '%s.Translation.X' % nodes.getTransformNode(eLeave, bInitial=True, bLocal=True)
            sScaleFactor = nodes.createGetVariableNode(vScaleFactor)
            sLeaveTranslateX = nodes.createBasicCalculateNode([sDefaultLeaveX, sScaleFactor])

            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eLeave, [[sLeaveTranslateX,0,0], sFromEuler, None], bLocal=True)

            controllers.setNewColumn()
            controllers.goToParentExecute()

        nodes.endCurrentFunction(bAddToExecute=False)

    sLeavesNode = nodes.addFunctionNode(sFunctionName)
    pins.connectToPin1D(sTwistAngle, '%s.TwistAngle' % sLeavesNode)
    if library.isNone(sAimTarget):
        pins.connectToPin1D(False, '%s.HasAimTarget' % sLeavesNode)
    else:
        pins.connectToPin1D(True, '%s.HasAimTarget' % sLeavesNode)
        pins.connectToPin1D(sAimTarget, '%s.AimTarget' % sLeavesNode)
    pins.setString(sChild, '%s.Child' % sLeavesNode)
    pins.setString(sParent, '%s.Parent' % sLeavesNode)

    if isinstance(sLeaves, str):
        pins.connectToPin1D(sLeaves, '%s.Leaves' % sLeavesNode)
    else:
        raise Exception('array connection not working yet. needs to get copied from the twistUpper() function')
    return sLeavesNode





def blendAttributesElements(eAttrParent, sAttrNames=['space_local', 'space_head'], xWeights=[1.0, 0.0]):
    for o in range(0, len(sAttrNames), 1):
        hierarchy.createFloatControl(sAttrNames[o], eParent=eAttrParent, fRange= [1,1] if o == 0 else [0,1], fDefault=xWeights[o] if not library.isNone(xWeights) else 0.0)


def blendAttributesFunction(eAttrParent, sAttrNames=['space_local', 'space_head'], xWeights=[1.0, 0.0]):
    sFunctionName = 'kangaroo_blendAttributes_%dInputs' % len(sAttrNames)
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName,
                             xInputs=[('CtrlName', 'FName', False)] +
                                    [('Attr_%d' % o, 'FName', None) for o in range(1,len(sAttrNames),1)],
                            xOutputs=[('OutAttr_%d' % o, 'float', False) for o in range(0,len(sAttrNames),1)],
                            bMutable=False)
        
        # blueprint.get_controller_by_name('kangaroo_blendAttributes_2').add_link('Entry.Attr_1', 'GetAnimationChannel.Channel')
        # blueprint.get_controller_by_name('kangaroo_blendAttributes_2').add_link('Entry.CtrlName', 'GetAnimationChannel.Control')
        sUserAttrs = [1]
        for o in range(1,len(sAttrNames),1):
            sUserAttrs.append(nodes.createGetChannelNode2('Entry.CtrlName', 'Entry.Attr_%d' % o))
        # sOutAttrs = []
        for p, sAttr in enumerate(sUserAttrs):
            if p < len(sUserAttrs) - 1:
                sMinus = sUserAttrs[p+1:]
                sMinusCalculated = sMinus[0] if len(sMinus) == 1 else nodes.createBasicCalculateNode(sMinus, sOperation='Add')
                sDifference = nodes.createBasicCalculateNode([sUserAttrs[p], sMinusCalculated], sOperation='Subtract')
                pins.connectToPin1D(nodes.createClampNode(sDifference, 0, 1), 'Return.OutAttr_%d' % p)

            else:
                # sOutAttrs.append(sUserAttrs[p])
                pins.connectToPin1D(sUserAttrs[p], 'Return.OutAttr_%d' % p)

        nodes.endCurrentFunction(bAddToExecute=False) # this is where it happens

    sBlendNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)

    pins.setString(eAttrParent.name, '%s.CtrlName' % sBlendNode)
    for o in range(0, len(sAttrNames), 1):
        # eFloatCtrl = hierarchy.createFloatControl(sAttrNames[o], eParent=eAttrParent, fRange= [1,1] if o == 0 else [0,1], fDefault=xWeights[o] if not library.isNone(xWeights) else 0.0)
        if o > 0:
            pins.setString(sAttrNames[o], '%s.Attr_%d' % (sBlendNode, o))


    return sBlendNode


# def createBlendAttributes(eAttrParent, sAttrNames=['space_local', 'space_head'], xWeights=[1.0, 0.0]):
#
#     sUserAttrs = [1]
#     for o in range(1,len(sAttrNames),1): # TODO: use the createFloatAttrWithGetNode() function instead
#         eFloatCtrl = hierarchy.createFloatControl(sAttrNames[o], eParent=eAttrParent, fRange=[0, 1], fDefault=xWeights[o] if not library.isNone(xWeights) else 0.0)
#         sUserAttrs.append(createGetChannelNode(eFloatCtrl, eAttrParent))
#     sOutAttrs = []
#     for p, sAttr in enumerate(sUserAttrs):
#         if p < len(sUserAttrs) - 1:
#             sMinus = sUserAttrs[p+1:]
#             sMinusCalculated = sMinus[0] if len(sMinus) == 1 else createBasicCalculateNode(sMinus, sOperation='Add')
#             sDifference = createBasicCalculateNode([sUserAttrs[p], sMinusCalculated], sOperation='Subtract')
#             sOutAttrs.append(createClampNode(sDifference, 0, 1))
#         else:
#             sOutAttrs.append(sUserAttrs[p])
#
#     return sOutAttrs


# def twistLeaves(sLeaves, sTwistRotation):
#     hLeaves = [ELEM(sJ, 'Bone') for sJ in sLeaves]
#     controllers.setNewColumn()
#
#     sLeavesNode = nodes.createHierarchyTransformArrayNode(hLeaves)
#     controllers.setNewColumn()
#     sForEach = nodes.createForEachExecuteNode(sLeavesNode)
#
#     sIndexPlusOne = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add')
#     sIndexFloat = nodes.createToFloatNode(sIndexPlusOne)
#     sRatio = nodes.createBasicCalculateNode([sTwistRotation, sIndexFloat, 1.0/(3-1)], sOperation='Multiply')
#
#     sFromEuler = nodes.createFromEulerNode([sRatio, 0,0])
#     controllers.setNewColumn()
#     sOffsetLeave = nodes.createOffsetTransformExecuteNode('%s.Element' % sForEach)
#
#     controllers.latestFD().vmModel.add_link(sFromEuler, '%s.OffsetTransform.Rotation' % sOffsetLeave, setup_undo_redo=False)
#
#     controllers.setNewColumn()
#     controllers.goToParentExecute()



def twistLower(sElbow, sWrist, bUpAxisIsZ=True, cBendy=None):

    sFunctionName = 'kangaroo_twistLower'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Elbow', 'FName', False),
                                                    ('Wrist', 'FName', False),
                                                    # ('Leaves', 'FName', True),
                                                    ('UpAxisIsZ', 'bool', False)],
                                        xOutputs=[('TwistAngle', 'float', False)], bMutable=False)

        controllers.setNewColumn()
        controllers.openCommentBox('Calculate Angle')
        sUpVector = nodes.createIfNode('Entry.UpAxisIsZ', [0,0,1], [0,1,0], iPinType=pins.PinType.vector)
        sForwardVector = nodes.createIfNode('Entry.UpAxisIsZ', [0,1,0], [0,0,1], iPinType=pins.PinType.vector)
        sAngle = signedAngleFunction(ELEM('Entry.Wrist', 'Bone'), ELEM('Entry.Elbow', 'Bone'), iAngleAxis=0, fForwardVector=sForwardVector, fUpVector=sUpVector)
        pins.connectToPin1D(sAngle, 'Return.TwistAngle')
        controllers.closeCommentBox('Calculate Angle')

        # controllers.openCommentBox('Leaves')
        # controllers.setNewColumn()
        # sEntry_Wrist = nodes.createGetEntryVariable('Wrist')
        # sWristTransform = nodes.getTransformNode(ELEM(sEntry_Wrist, 'Bone'))
        # controllers.setNewColumn()
        # sEntry_Leaves = nodes.createGetEntryVariable('Leaves')
        # sEntry_Elbow = nodes.createGetEntryVariable('Elbow')
        # sEntry_Wrist = nodes.createGetEntryVariable('Wrist')
        # controllers.setNewColumn()
        # twistLeavesFunction(sEntry_Leaves, sAngle, sEntry_Elbow, sEntry_Wrist, '%s.Translation' % sWristTransform)
        # controllers.openCommentBox('Leaves')
        nodes.endCurrentFunction(bAddToExecute=False)


    sTwistNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)
    pins.setString(sWrist, '%s.Wrist' % sTwistNode)
    pins.setString(sElbow, '%s.Elbow' % sTwistNode)
    # pins.setStringArray(sLeaves, '%s.Leaves' % sTwistNode)
    pins.connectToPin1D(bUpAxisIsZ, '%s.UpAxisIsZ' % sTwistNode)
    return sTwistNode

def getAngleByEulerItems(eBone, eParent, iAngleAxis=0):

    sAxis = ['X','Y','Z'][iAngleAxis]

    sFunctionName = 'kangaroo_signedAngleByEulerItems_%s' % sAxis
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Bone', 'FRigElementKey', False),
                                                                         ('Parent', 'FRigElementKey', False)],
                                                                xOutputs=[('Angle', 'float', False)],
                                                                bMutable=False)

        # current
        controllers.openCommentBox('current')
        controllers.setNewColumn()
        sBone = nodes.getTransformNode('Entry.Bone')
        sParent = nodes.getTransformNode('Entry.Parent')

        controllers.setNewColumn()
        sRelative = nodes.createMakeRelativeNode(sBone, sParent)
        sEuler = nodes.createToEulerNode('%s.Rotation' % sRelative)
        controllers.closeCommentBox('current')

        # initial
        controllers.openCommentBox('initial')
        controllers.setNewColumn()
        sBone = nodes.getTransformNode('Entry.Bone', bInitial=True)
        sParent = nodes.getTransformNode('Entry.Parent', bInitial=True)

        controllers.setNewColumn()
        sRelativeInitial = nodes.createMakeRelativeNode(sBone, sParent)
        sEulerInitial = nodes.createToEulerNode('%s.Rotation' % sRelativeInitial)
        controllers.closeCommentBox('initial')

        sSubtracted = nodes.createBasicCalculateNode(['%s.%s' % (sEuler,sAxis), '%s.%s.' % (sEulerInitial,sAxis)], 'Subtract')

        pins.connectToPin1D(sSubtracted, 'Return.Angle')

        nodes.endCurrentFunction(bAddToExecute=False)

        

    sAngleNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)
    pins.connectItem(eBone, '%s.Bone' % sAngleNode)
    pins.connectItem(eParent, '%s.Parent' % sAngleNode)
    return '%s.Angle' % sAngleNode






def lidSetup(fffLowerTrs, fffUpperTrs, sSide, sLookVertVarName, sLookHorizVarName):

    fffValues = [fffLowerTrs, fffUpperTrs]

    sBlinkTransform = nodes.getTransformNode(ELEM('blink_%s_ctrl' % sSide, 'Control'), bLocal=True)
    sExtraTransforms = [nodes.getTransformNode(ELEM('lidBot_%s_ctrl' % sSide, 'Control'), bLocal=True),
                        nodes.getTransformNode(ELEM('lidTop_%s_ctrl' % sSide, 'Control'), bLocal=True)]

    controllers.setNewColumn()


    sEyeOpen = nodes.createRemapNode('%s.Translation.Z' % sBlinkTransform, 0, -1, 1, 0)
    sLookVert = nodes.createGetVariableNode(hierarchy.Variable(sLookVertVarName))
    sSwitchedLookY = nodes.createBasicCalculateNode([sLookVert, 0.5, sEyeOpen], sOperation='Multiply')

    # sEyeOpen = nodes.createRangeNode('%s.ty' % cBlink.sCtrl, 0, -1, 1, 0)
    # sSwitchedLookY = nodes.createMultiplyArrayNode([sLookVert, 0.5, sEyeOpen])


    for p,sPart in enumerate(['bot', 'top']):
        controllers.setNewColumn()
        sFunctionOutputs = []
        for a, sA in enumerate(['t', 'r', 's']):
            controllers.setNewColumn()

            if sA == 's':
                fffValues[p][a] = [(fV[0]-1.0, fV[1]-1.0, fV[2]-1.0) for fV in fffValues[p][a]]

            sFunctionName = 'kangaroo_lidPose'
            uFunction = nodes.getFunction(sFunctionName)
            if not uFunction:
                sFunctionGivenName = nodes.startFunction(sFunctionName, bMutable=False, xInputs=[
                    ('BlinkWideControlValue', 'float', False),
                    ('ExtraControlValue', 'float', False),
                    ('SwitchedLookY', 'float', False),
                    ('PoseValueBlink', 'FVector', False),
                    ('PoseValueWide', 'FVector', False),
                    ('PoseValueUp', 'FVector', False),
                    ('PoseValueDown', 'FVector', False),
                    ('ScaleAddition', 'FVector', False),

                ],
                 xOutputs=[
                    ('Sum', 'FVector', False)])

                

                sBlink = nodes.createRemapNode('Entry.BlinkWideControlValue', 0, -1, [0,0,0], 'Entry.PoseValueBlink', bOutIsVector=True)  # fffValues[p][a][0]
                sWide = nodes.createRemapNode('Entry.BlinkWideControlValue', 0, 0.5, [0,0,0], 'Entry.PoseValueWide', bOutIsVector=True)  # fffValues[p][a][1]
                sDown = nodes.createRemapNode('Entry.ExtraControlValue', 0, -1, [0,0,0], 'Entry.PoseValueUp', bOutIsVector=True)  # fffValues[p][a][2] # '%s.Translation.Z' % sExtraTransforms[p]
                sUp = nodes.createRemapNode('Entry.ExtraControlValue', 0, 1, [0,0,0], 'Entry.PoseValueDown', bOutIsVector=True)  # fffValues[p][a][3] # '%s.Translation.Z' % sExtraTransforms[p]

                sLookDown = nodes.createRemapNode('Entry.SwitchedLookY', 0, -0.707, [0,0,0], 'Entry.PoseValueUp', bOutIsVector=True) # fffValues[p][a][2] # sSwitchedLookY
                sLookUp = nodes.createRemapNode('Entry.SwitchedLookY', 0, 0.707, [0,0,0], 'Entry.PoseValueDown', bOutIsVector=True) # fffValues[p][a][3] # sSwitchedLookY

                controllers.setNewColumn()
                sSum = nodes.createBasicCalculateNode([sBlink, sWide, sDown, sUp, sLookDown, sLookUp, 'Entry.ScaleAddition'],
                                                      iPinType=pins.PinType.vector, sOperation='Add')
                pins.connectToPinVector(sSum, 'Return.Sum')
                nodes.endCurrentFunction(bAddToExecute=False)

            sPoseFunctionNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False)
            pins.connectToPin1D('%s.Translation.Z' % sBlinkTransform, '%s.BlinkWideControlValue' % sPoseFunctionNode)
            pins.connectToPin1D('%s.Translation.Z' % sExtraTransforms[p], '%s.ExtraControlValue' % sPoseFunctionNode)
            pins.connectToPin1D(sSwitchedLookY, '%s.SwitchedLookY' % sPoseFunctionNode)
            for fVector, sPin in zip(fffValues[p][a], ['PoseValueBlink', 'PoseValueWide', 'PoseValueUp', 'PoseValueDown']):
                pins.connectToPinVector(fVector, '%s.%s' % (sPoseFunctionNode,sPin))
            if a == 2:
                pins.connectToPinVector([1,1,1], '%s.ScaleAddition' % sPoseFunctionNode)
            sFunctionOutputs.append('%s.Sum' % sPoseFunctionNode)

        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(ELEM('jnt_%s_eyeBlink%s' % (sSide, library.getFirstLetterUpperCase(sPart)), 'Bone'),
                                            [sFunctionOutputs[0], nodes.createFromEulerNode(sFunctionOutputs[1]), sFunctionOutputs[2]], bLocal=True)




# depricated!! do not use
def lidSetupApple(fffLowerTrs, fffUpperTrs, sSide):

    controllers.openCommentBox('%s Lid Setup' % library.dSidesFull[sSide])
    fffValues = [fffLowerTrs, fffUpperTrs]
    nodes.newSequencerPlug()

    controllers.setNewColumn()

    for p,sPart in enumerate(['bot', 'top']):
        controllers.setNewColumn()
        sSums = []
        for a, sA in enumerate(['t', 'r', 's']):
            if a == 2:
                break
            controllers.setNewColumn()

            fDefault = [1, 1, 1] if sA == 's' else [0, 0, 0]
            sBlink = nodes.createRemapNode(nodes.createGetCurveValue('eyeBlinkLeft'), 0, 1, fDefault, fffValues[p][a][0], bOutIsVector=True) if any(fffValues[p][a][0]) else None
            sWide = nodes.createRemapNode(nodes.createGetCurveValue('eyeWideLeft'), 0, 1, fDefault, fffValues[p][a][1], bOutIsVector=True) if any(fffValues[p][a][1]) else None
            sDown = nodes.createRemapNode(nodes.createGetCurveValue('eyeLookDownLeft'), 0, 1, fDefault, fffValues[p][a][2], bOutIsVector=True) if any(fffValues[p][a][2]) else None
            sUp = nodes.createRemapNode(nodes.createGetCurveValue('eyeLookUpLeft'), 0, 1, fDefault, fffValues[p][a][3], bOutIsVector=True) if any(fffValues[p][a][3]) else None


            controllers.setNewColumn()
            sFactors = [sF for sF in [sBlink, sWide, sDown, sUp] if sF != None]
            sSums.append(nodes.createBasicCalculateNode(sFactors, bVector=True, sOperation='Add'))


        controllers.setNewColumn()
        sRotation = nodes.createFromEulerNode(sSums[1])
        nodes.createSetTransformExecuteNode(ELEM('jnt_%s_eyeBlink%s' % (sSide, library.getFirstLetterUpperCase(sPart)), 'Bone'),
                                            [sSums[0], sRotation, [1,1,1]], bLocal=True)

    controllers.closeCommentBox('%s Lid Setup' % library.dSidesFull[sSide])



def createBeltRigFunction(sSide, cCtrls, sJoints, eCtrlParent, xCtrlWeightings=None):
    iCtrlCount = len(cCtrls)
    bSoft = not library.isNone(xCtrlWeightings)
    sFunctionName = 'kangaroo_belt_%dControls_%s_%s' % (iCtrlCount, 'middle' if sSide == 'm' else 'side', 'soft' if bSoft else 'full')
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xExtraInputs = []
        if sSide == 'm':
            # index generation for middle belts copied from belt_v12
            iMiddles = [iCtrlCount // 2 + 1, 1]  # [5, 1]
            iLefts = list(range(iCtrlCount // 2 + 2, iCtrlCount, 1)) + [0]  # [6, 7, 0]
            iRights = list(range(iCtrlCount // 2, 1, -1))  # [4, 3, 2]
            iAllInds = [None] * iCtrlCount
            sAllSides = [None] * iCtrlCount
            for _sSide, iInds in [('m', iMiddles), ('l', iLefts), ('r', iRights)]:
                for i, iInd in enumerate(iInds):
                    sAllSides[iInd] = _sSide
                    iAllInds[iInd] = i
            for i in range(iCtrlCount):
                xExtraInputs.append(('ATTACHER_%s_%d_t' % (sAllSides[i], iAllInds[i]), 'FConstraintParent', True))
                xExtraInputs.append(('ATTACHER_%s_%d_r' % (sAllSides[i], iAllInds[i]), 'FConstraintParent', True))
        else:
            for i in range(iCtrlCount):
                xExtraInputs.append(('ATTACHER_m_%d_t' % i, 'FConstraintParent', True))
                xExtraInputs.append(('ATTACHER_m_%d_r' % i, 'FConstraintParent', True))
        if bSoft:
            xExtraInputs.append(('FirstControls', 'FRigElementKey', True))
            xExtraInputs.append(('SecondControls', 'FRigElementKey', True))
            xExtraInputs.append(('ControlWeights', 'float', True))
        else:
            xExtraInputs.append(('Controls', 'FRigElementKey', True))


        nodes.startFunction(sFunctionName, xInputs=[('Passers', 'FRigElementKey', True),
                                                                         ('Bones', 'FRigElementKey', True),
                                                                         ('CtrlParent', 'FRigElementKey', False),
                                                                         ('ATTACHER_root_t', 'FConstraintParent', True),
                                                                         ('ATTACHER_root_r', 'FConstraintParent', True),
                                                                         ] + xExtraInputs)
        

        controllers.setNewColumn()

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.CtrlParent', bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.CtrlParent', bMaintainOffset=True, skipTranslate=['x','y','z'])
        for i in range(iCtrlCount):
            if sSide == 'm':
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_%s_%d_r' % (sAllSides[i], iAllInds[i]), nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipRotate=['x','y','z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_%s_%d_t' % (sAllSides[i], iAllInds[i]), nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipTranslate=['x','y','z'])
            else:
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_m_%d_r' % i, nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipRotate=['x','y','z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_m_%d_t' % i, nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipTranslate=['x','y','z'])

        sForEach = nodes.createForEachExecuteNode('Entry.Bones')

        if bSoft:
            eFirstControl = nodes.createArrayAtNode('Entry.FirstControls', '%s.Index' % sForEach)
            eSecondControl = nodes.createArrayAtNode('Entry.SecondControls', '%s.Index' % sForEach)
            sCtrlWeight = nodes.createArrayAtNode('Entry.ControlWeights', '%s.Index' % sForEach)
            sRevCtrlWeight = nodes.createBasicCalculateNode([1.0, sCtrlWeight], sOperation='Subtract')
            nodes.createParentConstraintExecuteNode([(eFirstControl, sRevCtrlWeight),
                                                     (eSecondControl, sCtrlWeight)],
                                                    '%s.Element' % sForEach, bMaintainOffset=True)
        else:
            eControl = nodes.createArrayAtNode('Entry.Controls', '%s.Index' % sForEach)
            nodes.createParentConstraintExecuteNode([(eControl, 1)], '%s.Element' % sForEach, bMaintainOffset=True)

        controllers.goToParentExecute()
        nodes.endCurrentFunction(bAddToExecute=False)

    sBeltNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eCtrlParent, '%s.CtrlParent' % sBeltNode)
    pins.setItemArray([cC.ePasser for cC in cCtrls], '%s.Passers' % sBeltNode)
    pins.setItemArray([ELEM(sJ, 'Bone') for sJ in sJoints], '%s.Bones' % sBeltNode)
    if bSoft:
        pins.setItemArray([cCtrls[xC[0]].eControl for xC in xCtrlWeightings], '%s.FirstControls' % sBeltNode)
        pins.setItemArray([cCtrls[xC[1]].eControl for xC in xCtrlWeightings], '%s.SecondControls' % sBeltNode)
        pins.setValueArray([xC[2] for xC in xCtrlWeightings], '%s.ControlWeights' % sBeltNode)
    else:
        pins.setItemArray([cC.eControl for cC in cCtrls], '%s.Controls' % sBeltNode)

    return sBeltNode


def createBeltRigFunction_BACKWARDS(sSide, cCtrls, sJoints, eCtrlParent):
    iCtrlCount = len(cCtrls)
    bSoft = False
    sFunctionName = 'kangaroo_belt_%dControls_%s_%s_BACKWARDS' % (iCtrlCount, 'middle' if sSide == 'm' else 'side', 'soft' if bSoft else 'full')
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        xExtraInputs = []
        if sSide == 'm':
            # index generation for middle belts copied from belt_v12
            iMiddles = [iCtrlCount // 2 + 1, 1]  # [5, 1]
            iLefts = list(range(iCtrlCount // 2 + 2, iCtrlCount, 1)) + [0]  # [6, 7, 0]
            iRights = list(range(iCtrlCount // 2, 1, -1))  # [4, 3, 2]
            iAllInds = [None] * iCtrlCount
            sAllSides = [None] * iCtrlCount
            for _sSide, iInds in [('m', iMiddles), ('l', iLefts), ('r', iRights)]:
                for i, iInd in enumerate(iInds):
                    sAllSides[iInd] = _sSide
                    iAllInds[iInd] = i
            for i in range(iCtrlCount):
                xExtraInputs.append(('ATTACHER_%s_%d_t' % (sAllSides[i], iAllInds[i]), 'FConstraintParent', True))
                xExtraInputs.append(('ATTACHER_%s_%d_r' % (sAllSides[i], iAllInds[i]), 'FConstraintParent', True))
        else:
            for i in range(iCtrlCount):
                xExtraInputs.append(('ATTACHER_m_%d_t' % i, 'FConstraintParent', True))
                xExtraInputs.append(('ATTACHER_m_%d_r' % i, 'FConstraintParent', True))
        xExtraInputs.append(('Controls', 'FRigElementKey', True))


        nodes.startFunction(sFunctionName, xInputs=[('Passers', 'FRigElementKey', True),
                                                     ('Bones', 'FRigElementKey', True),
                                                     ('CtrlParent', 'FRigElementKey', False),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ] + xExtraInputs)


        controllers.setNewColumn()

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.CtrlParent', bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.CtrlParent', bMaintainOffset=True, skipTranslate=['x','y','z'])
        for i in range(iCtrlCount):
            if sSide == 'm':
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_%s_%d_r' % (sAllSides[i], iAllInds[i]), nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipRotate=['x','y','z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_%s_%d_t' % (sAllSides[i], iAllInds[i]), nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipTranslate=['x','y','z'])
            else:
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_m_%d_r' % i, nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipRotate=['x','y','z'])
                nodes.createParentConstraintExecuteNode('Entry.ATTACHER_m_%d_t' % i, nodes.createArrayAtNode('Entry.Passers', i), bMaintainOffset=True, skipTranslate=['x','y','z'])

        sForEach = nodes.createForEachExecuteNode('Entry.Bones')

        eControl = nodes.createArrayAtNode('Entry.Controls', '%s.Index' % sForEach)
        nodes.createParentConstraintExecuteNode([('%s.Element' % sForEach, 1)], eControl, bMaintainOffset=True)

        controllers.goToParentExecute()
        nodes.endCurrentFunction(bAddToExecute=False)

    sBeltNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eCtrlParent, '%s.CtrlParent' % sBeltNode)
    pins.setItemArray([cC.ePasser for cC in cCtrls], '%s.Passers' % sBeltNode)
    pins.setItemArray([ELEM(sJ, 'Bone') for sJ in sJoints], '%s.Bones' % sBeltNode)
    pins.setItemArray([cC.eControl for cC in cCtrls], '%s.Controls' % sBeltNode)

    return sBeltNode



def createClavicleFunction(cCtrl, cIk, sJoint, eAutoDriver=None):
    sFunctionName = 'kangaroo_clavicle'
    if eAutoDriver:
        hierarchy.createFloatControl('Auto', eParent=cCtrl.eControl, fRange=[0,1], fDefault=0.0)

    eAutoOffset = cCtrl.addOffset('auto')

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Bone', 'FName', False),
                                                     ('Control', 'FName', False),
                                                     ('Passer', 'FName', False),
                                                     ('AutoOffset', 'FName', False),
                                                     ('IkControl', 'FName', False),
                                                     ('IkPasser', 'FName', False),
                                                     ('AutoDriver', 'FName', False),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_main_r', 'FConstraintParent', True),
                                                     ('ATTACHER_main_t', 'FConstraintParent', True)])


        controllers.openCommentBox('Attachers')
        eEntry_Passer = ELEM('Entry.Passer', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eEntry_Passer, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_Passer, bMaintainOffset=True, skipTranslate=['x','y','z'])

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_t', eEntry_Passer, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_r', eEntry_Passer, bMaintainOffset=True, skipTranslate=['x','y','z'])
        controllers.closeCommentBox('Attachers')

        controllers.openCommentBox('Auto')
        controllers.setNewColumn()
        sEntry_Control = nodes.createGetEntryVariable('Control')
        sAutoAttr = nodes.createGetChannelNode2(sEntry_Control, 'Auto')
        controllers.setNewColumn()
        eEntry_AutoOffset = ELEM(nodes.createGetEntryVariable('AutoOffset'), 'Null')
        eEntry_AutoDriver = ELEM(nodes.createGetEntryVariable('AutoDriver'), 'Null')
        eEntry_Passer = ELEM(nodes.createGetEntryVariable('Passer'), 'Null')
        createKangarooAimConstraintFunctionWeighted(eEntry_AutoOffset, eEntry_AutoDriver, eEntry_Passer, fWeight=sAutoAttr, fAimVector=[0,0,1], fUpVector=[0,1,0], fWorldUpVector=[0,1,0])
        controllers.closeCommentBox('Auto')

        controllers.openCommentBox('Constraint Bone')
        controllers.setNewColumn()
        eEntry_Control = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
        eEntry_IkControl = ELEM(nodes.createGetEntryVariable('IkControl'), 'Control')
        eEntry_Bone = ELEM(nodes.createGetEntryVariable('Bone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_Control, 1.0)], eEntry_Bone, bMaintainOffset=True, skipRotate=['x','y','z'])
        createKangarooAimConstraintFunction(eEntry_Bone, eEntry_IkControl, eEntry_Control)

        controllers.closeCommentBox('Constraint Bone')

        nodes.endCurrentFunction(bAddToExecute=False)



    sClavicleNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300,400])
    if sJoint:
        pins.setString(sJoint, '%s.Bone' % sClavicleNode)
    pins.setString(cCtrl.ePasser.name, '%s.Passer' % sClavicleNode)
    pins.setString(cCtrl.eControl.name, '%s.Control' % sClavicleNode)
    pins.setString(cIk.ePasser.name, '%s.IkPasser' % sClavicleNode)
    pins.setString(cIk.eControl.name, '%s.IkControl' % sClavicleNode)
    if eAutoDriver:
        pins.setString(eAutoDriver.name, '%s.AutoDriver' % sClavicleNode)
        pins.setString(eAutoOffset.name, '%s.AutoOffset' % sClavicleNode)
    return sClavicleNode




def createSingleBoneFunction(cCtrl, sJoint, sChildMaintainBone=None):
    sFunctionName = 'kangaroo_singleCtrl'
    if sChildMaintainBone:
        sFunctionName = '%s_maintainChild' % sFunctionName
        xExtraInputs = [('ChildMaintain', 'FName', False)]
    else:
        xExtraInputs = []
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Bone', 'FName', False),
                                                     ('Control', 'FName', False),
                                                     ('Passer', 'FName', False),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_main_r', 'FConstraintParent', True),
                                                     ('ATTACHER_main_t', 'FConstraintParent', True)] + xExtraInputs)


        if sChildMaintainBone:
            controllers.openCommentBox('Get Bone to Maintain')
            vChildBefore = hierarchy.newVariable('ChildBefore', 'FTransform', bLocal=True)
            eEntry_ChildMaintain = ELEM(nodes.createGetEntryVariable('ChildMaintain'), 'Bone')
            sChildTransform = nodes.getTransformNode(eEntry_ChildMaintain)
            nodes.createSetVariableExecuteNode(vChildBefore, sChildTransform)
            # sGetChild = nodes.createGetTransformsExecute([eEntry_ChildMaintain])
            # sChildTransform = nodes.createArrayAtNode('%s.transforms' % sGetChild, 0)
            controllers.setNewColumn()
            controllers.closeCommentBox('Get Bone to Maintain')

        controllers.openCommentBox('Attachers')
        controllers.setNewColumn()
        ePasser = ELEM(nodes.createGetEntryVariable('Passer'), 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', ePasser, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', ePasser, bMaintainOffset=True, skipTranslate=['x','y','z'])

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_t', ePasser, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_r', ePasser, bMaintainOffset=True, skipTranslate=['x','y','z'])
        controllers.closeCommentBox('Attachers')

        controllers.openCommentBox('Constraint Bone')
        controllers.setNewColumn()
        eEntry_Bone = ELEM(nodes.createGetEntryVariable('Bone'), 'Bone')
        eEntry_Control = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_Control, 1.0)], eEntry_Bone, bMaintainOffset=True)
        controllers.closeCommentBox('Constraint Bone')

        if sChildMaintainBone:
            controllers.setNewColumn()
            controllers.openCommentBox('Fix Child Bone to Maintain')
            eEntry_ChildMaintain = ELEM(nodes.createGetEntryVariable('ChildMaintain'), 'Bone')
            sChildTransform = nodes.createGetVariableNode(vChildBefore)
            nodes.createSetTransformExecuteNode(eEntry_ChildMaintain, sChildTransform)
            controllers.closeCommentBox('Fix Child Bone to Maintain')

        nodes.endCurrentFunction(bAddToExecute=False)



    sSingleBoneNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300,400])
    if sJoint:
        print ('sJoint: ', sJoint)
        pins.setString(sJoint, '%s.Bone' % sSingleBoneNode)
    pins.setString(cCtrl.ePasser.name, '%s.Passer' % sSingleBoneNode)
    pins.setString(cCtrl.eControl.name, '%s.Control' % sSingleBoneNode)
    if sChildMaintainBone:
        pins.setString(sChildMaintainBone, '%s.ChildMaintain' % sSingleBoneNode)


    return sSingleBoneNode


def createSingleBoneFunction_BACKWARDS(cCtrl, sJoint):
    sFunctionName = 'kangaroo_singleCtrl_BACKWARDS'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[ ('Bone', 'FName', False),
                                                     ('Control', 'FName', False),
                                                     ('Passer', 'FName', False),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_main_r', 'FConstraintParent', True),
                                                     ('ATTACHER_main_t', 'FConstraintParent', True)])

        controllers.openCommentBox('Attachers')
        eEntry_Passer = ELEM('Entry.Passer', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eEntry_Passer, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_Passer, bMaintainOffset=True, skipTranslate=['x','y','z'])

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_t', eEntry_Passer, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_r', eEntry_Passer, bMaintainOffset=True, skipTranslate=['x','y','z'])
        controllers.closeCommentBox('Attachers')

        controllers.openCommentBox('Constraint Control')
        controllers.setNewColumn()
        eEntry_Control = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
        eEntry_Bone = ELEM(nodes.createGetEntryVariable('Bone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_Bone, 1.0)], eEntry_Control, bMaintainOffset=True)
        controllers.closeCommentBox('Constraint Control')
        nodes.endCurrentFunction(bAddToExecute=False)


    sSingleBoneNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300,400])
    pins.setString(sJoint, '%s.Bone' % sSingleBoneNode)
    pins.setString(cCtrl.ePasser.name, '%s.Passer' % sSingleBoneNode)
    pins.setString(cCtrl.eControl.name, '%s.Control' % sSingleBoneNode)


    return sSingleBoneNode


def createEyeFunction(cTransformCtrl, cCtrl, sTransformJoint, sJoint):
    sFunctionName = 'kangaroo_eyeCtrl'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('TransformBone', 'FName', False),
                                                 ('Bone', 'FName', False),
                                                 ('TransformControl', 'FName', False),
                                                 ('TransformPasser', 'FName', False),
                                                 ('Control', 'FName', False),
                                                 ('Passer', 'FName', False),
                                                 ('ATTACHER_root_r', 'FConstraintParent', True),
                                                 ('ATTACHER_root_t', 'FConstraintParent', True),
                                                 ('ATTACHER_main_r', 'FConstraintParent', True),
                                                 ('ATTACHER_main_t', 'FConstraintParent', True)])

        eEntry_TransformPasser = ELEM('Entry.TransformPasser', 'Null')
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', eEntry_TransformPasser, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', eEntry_TransformPasser, bMaintainOffset=True, skipTranslate=['x','y','z'])

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_t', eEntry_TransformPasser, bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_r', eEntry_TransformPasser, bMaintainOffset=True, skipTranslate=['x','y','z'])

        controllers.setNewColumn()
        eEntry_TransformControl = ELEM(nodes.createGetEntryVariable('TransformControl'), 'Control')
        eEntry_TransformBone = ELEM(nodes.createGetEntryVariable('TransformBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_TransformControl, 1)], eEntry_TransformBone, bMaintainOffset=True)
        controllers.setNewColumn()
        eEntry_Control = ELEM(nodes.createGetEntryVariable('Control'), 'Control')
        eEntry_Bone = ELEM(nodes.createGetEntryVariable('Bone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_Control, 1)], eEntry_Bone, bMaintainOffset=True)

        nodes.endCurrentFunction(bAddToExecute=False)

    sSingleBoneNode = nodes.addFunctionNode(sFunctionName)
    pins.setString(sTransformJoint, '%s.TransformBone' % sSingleBoneNode)
    pins.setString(sJoint, '%s.Bone' % sSingleBoneNode)
    pins.setString(cCtrl.ePasser.name, '%s.Passer' % sSingleBoneNode)
    pins.setString(cCtrl.eControl.name, '%s.Control' % sSingleBoneNode)
    pins.setString(cTransformCtrl.ePasser.name, '%s.TransformPasser' % sSingleBoneNode)
    pins.setString(cTransformCtrl.eControl.name, '%s.TransformControl' % sSingleBoneNode)
    return sSingleBoneNode


def createEyeAimFunction(sCtrl, sEyeJoint, sEyeJointEnd, sRoot, fLidFollowDefault):

    sFunctionName = 'kangaroo_eyeAim'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('AimControl', 'FName', False),
                                                     ('EyeMain', 'FName', False),
                                                     ('EyeEnd', 'FName', False),
                                                     ('Root', 'FName', False),
                                                     ('LidFollowDefault', 'float', False)
                                                     ],
                                            xOutputs=[('LookHoriz', 'float', False),
                                                      ('LookVert', 'float', False)])

        controllers.openCommentBox('Get Initial and SideMultipl')
        vEndPointDefault = hierarchy.newVariable('EndPointDefault', sType='FVector')
        vSideMultipl = hierarchy.newVariable('SideMultipl')
        eEntry_EyeEnd = ELEM('Entry.EyeEnd', 'Bone')
        sEyeEndInitial = nodes.getTransformNode(eEntry_EyeEnd, bInitial=True, bLocal=True)
        nodes.createSetVariableExecuteNode(vEndPointDefault, '%s.Translation' % sEyeEndInitial)
        controllers.setNewColumn()
        sSideMultipl = nodes.createConditionNodes('%s.Translation.X' % sEyeEndInitial, '<', 0, -1.0, 1.0)
        nodes.createSetVariableExecuteNode(vSideMultipl, sSideMultipl)
        controllers.closeCommentBox('Get Initial and SideMultipl')

        controllers.openCommentBox('Aim')
        controllers.setNewColumn()
        eEntry_AimControl = ELEM('Entry.AimControl', 'Control')
        sEyeAimTransform = nodes.getTransformNode(eEntry_AimControl)
        controllers.setNewColumn()
        eEntry_EyeMain = ELEM(nodes.createGetEntryVariable('EyeMain'), 'Bone')
        sSideMultipl = nodes.createGetVariableNode(vSideMultipl)
        nodes.createAimExecuteNode(eEntry_EyeMain, '%s.Translation' % sEyeAimTransform, fAimVector=[sSideMultipl, 0, 0], fUpVector=[0, sSideMultipl, 0])
        controllers.closeCommentBox('Aim')

        controllers.openCommentBox('Line')
        controllers.setNewColumn()
        eEntry_AimControl = ELEM(nodes.createGetEntryVariable('AimControl'), 'Control')
        eEntry_EyeMain = ELEM(nodes.createGetEntryVariable('EyeMain'), 'Bone')
        createLineFunction(eEntry_AimControl, eEntry_EyeMain)
        controllers.closeCommentBox('Line')

        controllers.openCommentBox('Calculate Look Direction For Return')
        controllers.setNewColumn()
        eEntry_EyeEnd = ELEM(nodes.createGetEntryVariable('EyeEnd'), 'Bone')
        eEntry_Root = ELEM(nodes.createGetEntryVariable('Root'), 'Bone')
        controllers.setNewColumn()
        sEndTransform = nodes.getTransformNode(eEntry_EyeEnd)
        sRootTransform = nodes.getTransformNode(eEntry_Root)
        controllers.setNewColumn()
        sRel = nodes.createMakeRelativeNode(['%s.Translation' % sEndTransform, None, None], sRootTransform)
        sEndPointDefault = nodes.createGetVariableNode(vEndPointDefault)
        sResetLook = nodes.createBasicCalculateNode(['%s.Translation' % sRel, sEndPointDefault], sOperation='Subtract', iPinType=pins.PinType.vector)
        # sResetLook = nodes.createBasicCalculateNode([['%s.Translation.Y' % sRel, '%s.Translation.Z' % sRel, 0], 'Entry.EndPointDefault'], sOperation='Subtract', iPinType=pins.PinType.vector)

        controllers.setNewColumn()
        sSideMultipl = nodes.createGetVariableNode(vSideMultipl)
        sResetLook = nodes.createBasicCalculateNode([sResetLook, [sSideMultipl, sSideMultipl, sSideMultipl]], iPinType=pins.PinType.vector)

        controllers.setNewColumn()
        sEntry_LidFollowDefault = nodes.createGetEntryVariable('LidFollowDefault')
        sAdjustedLook = nodes.createBasicCalculateNode([sResetLook, [sEntry_LidFollowDefault, sEntry_LidFollowDefault, sEntry_LidFollowDefault]], sOperation='Multiply', iPinType=pins.PinType.vector)

        sNegativeVert = nodes.createBasicCalculateNode(['%s.Y' % sAdjustedLook, -1.0])
        pins.connectToPin1D(sNegativeVert, 'Return.LookVert')
        pins.connectToPin1D('%s.Z' % sAdjustedLook, 'Return.LookHoriz')
        controllers.closeCommentBox('Calculate Look Direction For Return')

        nodes.endCurrentFunction(bAddToExecute=False)

    sAimFunctionNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[200,600])
    pins.setString(sCtrl.eControl.name, '%s.AimControl' % sAimFunctionNode)
    pins.setString(sEyeJoint, '%s.EyeMain' % sAimFunctionNode)
    pins.setString(sEyeJointEnd, '%s.EyeEnd' % sAimFunctionNode)
    pins.setString(sRoot, '%s.Root' % sAimFunctionNode)
    pins.connectToPin1D(fLidFollowDefault, '%s.LidFollowDefault' % sAimFunctionNode)

    return sAimFunctionNode


def createLineFunction(eFrom, eTo):

    sFunctionName = 'kangaroo_line'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('From', 'FRigElementKey', False),
                                                     ('To', 'FRigElementKey', False)])

        controllers.openCommentBox('Calculate Thickness')
        sFromInitial = nodes.getTransformNode('Entry.From', bInitial=True)
        sToInitial = nodes.getTransformNode('Entry.To', bInitial=True)
        controllers.setNewColumn()
        sDistance = nodes.createGetDistanceNode('%s.Translation' % sFromInitial, '%s.Translation' % sToInitial)
        sThickness = nodes.createBasicCalculateNode([sDistance, 0.01])
        controllers.closeCommentBox('Calculate Thickness')

        controllers.setNewColumn()
        sFrom = nodes.getTransformNode('Entry.From')
        sTo = nodes.getTransformNode('Entry.To')
        

        nodes.createDrawLineNode('%s.Translation' % sFrom, '%s.Translation' % sTo, fThickness=sThickness, fColor=[1,1,1])
        nodes.endCurrentFunction(bAddToExecute=False)
        

    sLineNode = nodes.addFunctionNode(sFunctionName)
    pins.connectItem(eFrom, '%s.From' % sLineNode)
    pins.connectItem(eTo, '%s.To' % sLineNode)

    return sLineNode




def createSingleCtrlFunction(cCtrl):#, sJoint):
    sFunctionName = 'kangaroo_singleBone'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[#('Bone', 'FRigElementKey', False),
                                                     # ('Control', 'FRigElementKey', False),
                                                     ('Passer', 'FRigElementKey', False),
                                                     ('ATTACHER_root_r', 'FConstraintParent', True),
                                                     ('ATTACHER_root_t', 'FConstraintParent', True),
                                                     ('ATTACHER_main_r', 'FConstraintParent', True),
                                                     ('ATTACHER_main_t', 'FConstraintParent', True)])

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_t', 'Entry.Passer', bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_root_r', 'Entry.Passer', bMaintainOffset=True, skipTranslate=['x','y','z'])

        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_t', 'Entry.Passer', bMaintainOffset=True, skipRotate=['x','y','z'])
        nodes.createParentConstraintExecuteNode('Entry.ATTACHER_main_r', 'Entry.Passer', bMaintainOffset=True, skipTranslate=['x','y','z'])

        controllers.setNewColumn()
        # nodes.createParentConstraintExecuteNode([hierarchy.ConstraintParent('Entry.Control', 1.0)], 'Entry.Bone', bMaintainOffset=True)

        nodes.endCurrentFunction(bAddToExecute=False)

        

    sSingleCtrlNode = nodes.addFunctionNode(sFunctionName)
    # pins.connectItem(ELEM(sJoint, 'Bone'), '%s.Bone' % sSingleCtrlNode)
    pins.connectItem(cCtrl.ePasser, '%s.Passer' % sSingleCtrlNode)
    # pins.connectItem(cCtrl.eControl, '%s.Control' % sSingleCtrlNode)

    return sSingleCtrlNode


vZipperOut = None
vZipperStrings = None
def createZipperVariables(iSampleCount, eControlParents):
    global vZipperOut
    global vZipperStrings
    sFunctionName = 'kangaroo_zipper'
    uFunction = nodes.getFunction(sFunctionName)
    hierarchy.createFloatControl('zipper', eParent=eControlParents[0], fRange=[0, 1])
    hierarchy.createFloatControl('zipper', eParent=eControlParents[1], fRange=[0,1])
    hierarchy.createFloatControl('zipperFade', eParent=eControlParents[0], fRange=[0, 1], fDefault=0.4)
    hierarchy.createFloatControl('zipperFade', eParent=eControlParents[1], fRange=[0, 1], fDefault=0.4)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[])
        controllers.setNewColumn()
        sZipperLeft = nodes.createGetChannelNode2(str(eControlParents[0].name), 'zipper')
        sZipperFadeLeftLength = nodes.createGetChannelNode2(str(eControlParents[0].name), 'zipperFade')
        sZipperRight = nodes.createGetChannelNode2(str(eControlParents[1].name), 'zipper')
        sZipperFadeRightLength = nodes.createGetChannelNode2(str(eControlParents[1].name), 'zipperFade')

        controllers.setNewColumn()
        sZipperLeftByFade = nodes.createBasicCalculateNode([sZipperLeft, nodes.createBasicCalculateNode([1.0, sZipperFadeLeftLength], sOperation='Add')], sOperation='Multiply')
        sZipperRightByFade = nodes.createBasicCalculateNode([sZipperRight, nodes.createBasicCalculateNode([1.0, sZipperFadeRightLength], sOperation='Add')], sOperation='Multiply')

        fLeftPercs = library.bSpline4([0,0,1,1], fValues=[(float(fV) / (iSampleCount-1)) for fV in range(iSampleCount)])
        # fRightPercs = [1.0-fV for fV in fLeftPercs]

        controllers.openCommentBox('Create Variables')
        controllers.setNewColumn()
        vZipperOut = hierarchy.newVariable('zipperOut', 'double', True, False)
        nodes.createResetArrayNode(nodes.createGetVariableNode(vZipperOut))

        controllers.setNewColumn()
        vZipperStrings = hierarchy.newVariable('zipperStrings', 'FName', True, False)
        sSetVar = nodes.createSetVariableExecuteNode(vZipperStrings, None)
        pins.setStringArray(['z%02d' % i for i in range(iSampleCount)], '%s.Value' % sSetVar)
        controllers.closeCommentBox('Create Variables')

        controllers.setNewColumn()
        sForeach = nodes.createForEachExecuteNode(None)
        pins.resolveWildCardPin('%s.Array' % sForeach, 'TArray<double>')
        pins.setValueArray(fLeftPercs, '%s.Array' % sForeach)
        if controllers.BLOCK_FOREACH:

            controllers.openCommentBox('Left')
            controllers.setNewColumn()
            sEndLeft = nodes.createBasicCalculateNode(['%s.Element' % sForeach, sZipperFadeLeftLength], sOperation='Add')
            sRangeLeft = nodes.createRemapNode(sZipperLeftByFade, '%s.Element' % sForeach, sEndLeft, 0.0, 1.0)
            sFlattenedLeft = nodes.createEvalInterpolatorCurveNode(sRangeLeft)
            controllers.closeCommentBox('Left')

            controllers.openCommentBox('Right')
            controllers.setNewColumn()
            sRightPerc = nodes.createBasicCalculateNode([1.0, '%s.Element' % sForeach], sOperation='Subtract')
            sEndRight = nodes.createBasicCalculateNode([sRightPerc, sZipperFadeRightLength], sOperation='Add')
            sRangeRight = nodes.createRemapNode(sZipperRightByFade, sRightPerc, sEndRight, 0.0, 1.0)
            sFlattenedRight = nodes.createEvalInterpolatorCurveNode(sRangeRight)
            controllers.closeCommentBox('Right')

            controllers.openCommentBox('Combine and Store to Variable')
            controllers.setNewColumn()
            sLeftRightSeals = nodes.createBasicCalculateNode([sFlattenedLeft, sFlattenedRight], sOperation='Add')
            sOut = nodes.createClampNode(sLeftRightSeals, 0, 1)
            controllers.setNewColumn()
            sVarNode = nodes.createGetVariableNode(vZipperOut)
            nodes.createArrayAddNode(sVarNode, sOut)
            controllers.closeCommentBox('Combine and Store to Variable')
            controllers.goToParentExecute()

        nodes.endCurrentFunction(bAddToExecute=False)

    sZipperNode = nodes.addFunctionNode(sFunctionName)

    return sZipperNode


def shirtHipSetup(sSide, cCtrls, fDefaultMayaAimValues, fMayaMoveFrontals, fMayaForwardTranslation, fMayaOppositeRotation, sUplegUpInterpolatorOutputs):
    fSideMultipl = -1.0 if sSide == 'r' else 1.0
    s = ['l','r'].index(sSide)

    eHip = ELEM('pelvis', 'Bone')
    eUpper = ELEM('thigh_%s' % sSide, 'Bone')
    eKnee = ELEM('calf_%s' % sSide, 'Bone')

    nodes.newSequencerPlug()

    sHipTransform = nodes.getTransformNode(eHip)
    sHipTransformInitial = nodes.getTransformNode(eHip, bInitial=True)
    sKneeTransform = nodes.getTransformNode(eKnee)


    sUpperTransform = nodes.getTransformNode(eUpper)
    sUpperTransformInitial = nodes.getTransformNode(eUpper, bInitial=True)

    controllers.setNewColumn()
    sLocalAim = '%s.Translation' % nodes.createMakeRelativeNode(sKneeTransform, sHipTransform)
    sUpperLocalInitial = nodes.createMakeRelativeNode(sUpperTransformInitial, sHipTransformInitial)
    sHipInUpper = nodes.createMakeAbsoluteNode(sUpperLocalInitial, sUpperTransform)


    for d, sDir in enumerate(['forward', 'backwards']):
        eJoint = ELEM('jnt_%s_leg_upperTwist_000_%s' % (sSide, sDir), 'Bone')
        controllers.setNewColumn()

        nodes.createParentConstraintExecuteNode([eHip], cCtrls[d].ePasser, bMaintainOffset=True)

        sClampOut = nodes.createClampNode(sLocalAim, [-100000, -100000, -10000], [10000, 10000, 10000], bVector=True)
        sClampNode = sClampOut.split('.')[0]

        if d == 0:
            pins.connectToPin1D(fDefaultMayaAimValues[2], '%s.Minimum.Y' % sClampNode)
        else:
            pins.connectToPin1D(fDefaultMayaAimValues[2], '%s.Maximum.Y' % sClampNode)

        sMovedUpVector = nodes.createRemapNode('%s.Y' % sLocalAim, fDefaultMayaAimValues[2], fMayaMoveFrontals[d], 0, 1)
        sUpBlend = nodes.createTransformInterpolateNode(sMovedUpVector, [None, '%s.Rotation' % sUpperTransform, None], [None, '%s.Rotation' % sHipInUpper, None])
        sUpDirection = '%s.Translation' % nodes.createMakeAbsoluteNode([[0,0,10], None, None], sUpBlend)
        # nodes.createRangeNode('%s.tz' % sAim, fDefaultAim[2], fMovedFrontal, fDefaultAim[1], 0, sTarget='%s.maxG' % sClamp)
        sMovedFrontal = '%s.Y' % sLocalAim

        # nodes.createRangeNode('%s.tz' % sAim, fDefaultAimLocalTarget[2], fMovedFrontal, fDefaultAimLocalTarget[1], 0, sTarget='%s.maxG' % sClamp)
        sUpDownClampRange = nodes.createRemapNode('%s.Y' % sLocalAim, fDefaultMayaAimValues[2], fMayaMoveFrontals[d], fDefaultMayaAimValues[1], 100)
        pins.connectToPin1D(sUpDownClampRange, '%s.Maximum.X' % sClampNode)

        controllers.setNewColumn()
        sPasserTransform = nodes.getTransformNode(cCtrls[d].ePasser)
        sWorldAim = '%s.Translation' % nodes.createMakeAbsoluteNode([sClampOut, None, None], sHipTransform)

        controllers.setNewColumn()
        sAimNodeOutput = nodes.createAimNode(sPasserTransform, sWorldAim, fAimVector = [fSideMultipl,0,0], fUpVector=[0,-1,0])
        sAimNode = sAimNodeOutput.split('.')[0]
        controllers.latestFD().vmModel.set_pin_default_value('%s.Secondary.Kind' % sAimNode, 'Direction', False)
        pins.connectToPin1D(sUpDirection, '%s.Secondary.Target' % sAimNode)

        if d == 0:
            sTranslateBlend = nodes.createVectorInterpolateNode(sUplegUpInterpolatorOutputs[s], [0,0,0], [fMayaForwardTranslation[0], fMayaForwardTranslation[2], fMayaForwardTranslation[1]])
            sOppositeT = nodes.createBasicCalculateNode([sUplegUpInterpolatorOutputs[1-s], sUplegUpInterpolatorOutputs[s]], sOperation='Subtract')
            sEulerBlend = nodes.createRemapNode(sOppositeT, 0, 1, [0,0,0], [-fMayaOppositeRotation[0], -fMayaOppositeRotation[2], -fMayaOppositeRotation[1]], bOutIsVector=True)
            sRotateBlend = nodes.createFromEulerNode(sEulerBlend)
            sFinalTransform = nodes.createMakeAbsoluteNode([sTranslateBlend, sRotateBlend, None], sAimNodeOutput)
        else:
            sFinalTransform = sAimNodeOutput

        nodes.createSetTransformExecuteNode(cCtrls[d].ePasser, sFinalTransform)
        nodes.createParentConstraintExecuteNode([cCtrls[d].eControl], eJoint, bMaintainOffset=True)

        # sMinimum = nodes.createExtremeNode(sUplegUpInterpolatorOutputs, bMinimum=True)
        # nodes.setCurveValueExecuteNode('shirtUpperLegForwardBoth_INV', sMinimum)


def createDogToeFunction(sWristJoint, sFingerJoint, sFingerMidJoint, cMetaIk, cFkCtrls, cProxy, sJoints, fIkStretch,
                         dFingerPosesDrivers={}, sPosePassersRotation=[], xPasserPosesRotation=[], sPosePassersTranslation=[], xPasserPosesTranslation=[]):
    sFunctionName = 'kangaroo_dogToe'
    uFunction = nodes.getFunction(sFunctionName)
    iPosePasserRangeRotation = range(len(xPasserPosesRotation))
    iPosePasserRangeTranslation = range(len(xPasserPosesTranslation))
    if not uFunction:

        xPasserPosesInputs = [('PosePasserRotation_%d' % i, 'FName', False) for i in iPosePasserRangeRotation] + \
                                [('PasserPosesDriversRotation_%d' % i, 'float', True) for i in iPosePasserRangeRotation] + \
                                [('PasserPosesVectorsRotation_%d' % i, 'FVector', True) for i in iPosePasserRangeRotation] + \
                                [('PosePasserTranslation_%d' % i, 'FName', False) for i in iPosePasserRangeTranslation] + \
                                [('PasserPosesDriversTranslation_%d' % i, 'float', True) for i in iPosePasserRangeTranslation] + \
                                [('PasserPosesVectorsTranslation_%d' % i, 'FVector', True) for i in iPosePasserRangeTranslation]


        nodes.startFunction(sFunctionName, xInputs=[('WristBone', 'FName', False),
                                                     ('LegFingerBone', 'FName', False),
                                                     ('LegFingerMidBone', 'FName', False),
                                                     ('ProxyControl', 'FName', False),
                                                     ('MetaIkPasser', 'FName', False),
                                                     ('MetaIkControl', 'FName', False),
                                                     ('MetaBone', 'FName', False),
                                                     ('BaseBone', 'FName', False),
                                                     ('MidBone', 'FName', False),
                                                     ('TipBone', 'FName', False),
                                                     ('BasePasser', 'FName', False),
                                                     ('BaseControl', 'FName', False),
                                                     ('MidPasser', 'FName', False),
                                                     ('MidControl', 'FName', False),
                                                     ('TipPasser', 'FName', False),
                                                     ('TipControl', 'FName', False),
                                                     ('IkStretch', 'float', False),
                                                    ] + xPasserPosesInputs,
                                            xOutputs=[('OutValue', 'float', False)])


        controllers.openCommentBox('Get Bone Lengths')
        vMetaDefaultLength = hierarchy.newVariable('MetaDefaultLength')
        vBaseDefaultLength = hierarchy.newVariable('BaseDefaultLength')
        vElbowDefaultLength = hierarchy.newVariable('ElbowDefaultLength')
        sInitialLocals = []
        for vVar, sEntry in [(vMetaDefaultLength, 'BaseBone'), (vBaseDefaultLength, 'MidBone'), (vElbowDefaultLength, 'TipBone')]:
            controllers.setNewColumn()
            eEntry_Bone = ELEM(nodes.createGetEntryVariable(sEntry), 'Bone')
            sInitialLocal = nodes.getTransformNode(eEntry_Bone, bLocal=True, bInitial=True)
            sLength = nodes.createMathAbs('%s.Translation.X' % sInitialLocal)
            nodes.createSetVariableExecuteNode(vVar, sLength)
            sInitialLocals.append(sInitialLocal)
        controllers.setNewColumn()
        controllers.closeCommentBox('Get Bone Lengths')

        controllers.openCommentBox('Get SideMultipl')
        vSideMultipl = hierarchy.newVariable('SideMultipl')
        sSideMultipl = nodes.createConditionNodes('%s.Translation.X' % sInitialLocals[-1], '<', 0.0, -1.0, 1.0)
        nodes.createSetVariableExecuteNode(vSideMultipl, sSideMultipl)
        controllers.closeCommentBox('Get SideMultipl')

        controllers.openCommentBox('Get PoleMultipl')
        vPoleMultipl = hierarchy.newVariable('PoleMultipl')
        eEntry_MidBone = ELEM(nodes.createGetEntryVariable('MidBone'), 'Bone')
        sMidBoneInitial = nodes.getTransformNode(eEntry_MidBone, bInitial=True, bLocal=True)
        sEuler = nodes.createToEulerNode('%s.Rotation' % sMidBoneInitial)
        sPoleMultipl = nodes.createConditionNodes('%s.Z' % sEuler, '<', 0.0, .0, -1.0)
        nodes.createSetVariableExecuteNode(vPoleMultipl, sPoleMultipl)
        controllers.closeCommentBox('Get PoleMultipl')


        controllers.openCommentBox('Get Default Ik Distance')
        controllers.setNewColumn()
        eEntry_BaseBone = ELEM(nodes.createGetEntryVariable('BaseBone'), 'Bone')
        eEntry_TipBone = ELEM(nodes.createGetEntryVariable('TipBone'), 'Bone')
        sBaseBoneInitial = nodes.getTransformNode(eEntry_BaseBone, bInitial=True)
        sTipBoneInitial = nodes.getTransformNode(eEntry_TipBone, bInitial=True)
        controllers.setNewColumn()
        sDistance = nodes.createGetDistanceNode('%s.Translation' % sBaseBoneInitial, '%s.Translation' % sTipBoneInitial)
        vDefaultIkDistance = hierarchy.newVariable('DefaultIkDistance')
        nodes.createSetVariableExecuteNode(vDefaultIkDistance, sDistance)
        controllers.closeCommentBox('Get Default Ik Distance')


        controllers.openCommentBox('Reset Passers')
        controllers.setNewColumn()
        for i in iPosePasserRangeRotation:
            ePasser = ELEM('Entry.PosePasserRotation_%d' % i, 'Null')
            sInitialRotation = '%s.Rotation' % nodes.getTransformNode(ePasser, bInitial=True, bLocal=True)
            nodes.createSetRotationExecuteNode(ePasser, sInitialRotation, bLocal=True)
        controllers.setNewColumn()
        if len(iPosePasserRangeTranslation):
            for i in iPosePasserRangeTranslation:
                ePasser = ELEM('Entry.PosePasserTranslation_%d' % i, 'Null')
                sInitialTranslation = '%s.Translation' % nodes.getTransformNode(ePasser, bInitial=True, bLocal=True)
                nodes.createSetTranslationExecuteNode(ePasser, sInitialTranslation, bLocal=True)
        controllers.closeCommentBox('Reset Passers')


        controllers.openCommentBox('Proxy Control')
        controllers.setNewColumn()
        eEntry_ProxyControl = ELEM(nodes.createGetEntryVariable('ProxyControl'), 'Control')
        sProxyControlAnim = nodes.getTransformNode(eEntry_ProxyControl, bLocal=True)
        vProxyControlAnim = hierarchy.newVariable('ProxyControlAnim', 'FQuat')
        nodes.createSetVariableExecuteNode(vProxyControlAnim, '%s.Rotation' % sProxyControlAnim)

        controllers.setNewColumn()
        # sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sEntry_BaseControl = nodes.createGetEntryVariable('BaseControl')
        sEntry_MidControl = nodes.createGetEntryVariable('MidControl')
        sEntry_TipControl = nodes.createGetEntryVariable('TipControl')
        sForeach = nodes.createForEachExecuteNode([sEntry_BaseControl, sEntry_MidControl, sEntry_TipControl], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            sProxyControlAnim = nodes.createGetVariableNode(vProxyControlAnim)
            eControl = ELEM('%s.Element' % sForeach, 'Control')
            nodes.createOffsetTransformExecuteNode(eControl, [None, sProxyControlAnim, None])
            # nodes.createSendEventExecuteNode(eControl)
            controllers.goToParentExecute()
        controllers.setNewColumn()
        eEntry_ProxyControl = ELEM(nodes.createGetEntryVariable('ProxyControl'), 'Control')
        nodes.createSetRotationExecuteNode(eEntry_ProxyControl, bLocal=True)
        controllers.closeCommentBox('Proxy Control')



        controllers.setNewColumn()
        # sEntry_MetaBone = nodes.createGetEntryVariable('MetaBone')
        sEntry_LegFingerBone = nodes.createGetEntryVariable('LegFingerBone')
        sEntry_MetaIkPasser = nodes.createGetEntryVariable('MetaIkPasser')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(ELEM(sEntry_LegFingerBone, 'Bone'), 1)], ELEM(sEntry_MetaIkPasser, 'Null'), bMaintainOffset=True)

        controllers.openCommentBox('Create Effector and Pole for IK')
        controllers.setNewColumn()
        sEntry_BaseBone = nodes.createGetEntryVariable('BaseBone')
        sEntry_MetaIkOut = nodes.createGetEntryVariable('MetaIkControl')
        sEntry_TipBone = nodes.createGetEntryVariable('TipBone')
        sEntry_LegFingerMidBone = nodes.createGetEntryVariable('LegFingerMidBone')
        sPoleMultiply = nodes.createGetVariableNode(vPoleMultipl)
        sSideMultipl = nodes.createGetVariableNode(vSideMultipl)
        controllers.setNewColumn()
        sRootTransform = nodes.createProjectTransformToNewParent(ELEM(sEntry_BaseBone, 'Bone'), ELEM(sEntry_MetaIkOut, 'Control'), ELEM(sEntry_MetaIkOut, 'Control'), True, True, False)
        sEffectorTransform = nodes.createProjectTransformToNewParent(ELEM(sEntry_TipBone, 'Bone'), ELEM(sEntry_LegFingerMidBone, 'Bone'), ELEM(sEntry_LegFingerMidBone, 'Bone'), True, True, False)
        sPoleY = nodes.createBasicCalculateNode([sPoleMultiply, 100])
        sPole = nodes.createMakeAbsoluteNode([[0,nodes.createBasicCalculateNode([sPoleY, sSideMultipl]),0],None,None], sEffectorTransform )
        controllers.closeCommentBox('Create Effector and Pole for IK')

        # stretch
        controllers.openCommentBox('ik stretch')
        controllers.setNewColumn()
        sDefaultIkDistance = nodes.createGetVariableNode(vDefaultIkDistance)
        sEntry_IkStretch = nodes.createGetEntryVariable('IkStretch')
        controllers.setNewColumn()
        sDistance = nodes.createGetDistanceNode('%s.Translation' % sRootTransform, '%s.Translation' % sEffectorTransform)
        sDistanceFactor = nodes.createBasicCalculateNode([sDistance, sDefaultIkDistance], sOperation='Divide')
        sDistanceFactorBlended = nodes.createFloatInterpolateNode(sEntry_IkStretch, 1, sDistanceFactor)
        controllers.setNewColumn()
        sBaseDefaultLength = nodes.createGetVariableNode(vBaseDefaultLength)
        sElbowDefaultLength = nodes.createGetVariableNode(vElbowDefaultLength)
        controllers.setNewColumn()
        sBaseLength = nodes.createBasicCalculateNode([sDistanceFactorBlended, sBaseDefaultLength])
        sElbowLength = nodes.createBasicCalculateNode([sDistanceFactorBlended, sElbowDefaultLength])
        controllers.closeCommentBox('ik stretch')

        controllers.openCommentBox('IK')
        controllers.setNewColumn()
        sSideMultipl = nodes.createGetVariableNode(vSideMultipl)
        sPoleMultipl = nodes.createGetVariableNode(vPoleMultipl)
        sIk = nodes.createIkTransformsNode(sRootTransform, sEffectorTransform,
                                           sBaseLength, sElbowLength, sPoleVector='%s.Translation' % sPole,
                                           fPrimaryAxis=[sSideMultipl,0,0], fSecondaryAxis=[0,nodes.createBasicCalculateNode([sPoleMultipl, sSideMultipl]),0])
        controllers.closeCommentBox('IK')


        # manipulate ctrls
        controllers.openCommentBox('Get FingerMid Angle')
        controllers.setNewColumn()
        eEntry_LegFingerMidBone = ELEM(nodes.createGetEntryVariable('LegFingerMidBone'), 'Bone')
        eEntry_LegFingerBone = ELEM(nodes.createGetEntryVariable('LegFingerBone'), 'Bone')
        controllers.setNewColumn()
        sAngle = getAngleByEulerItems(eEntry_LegFingerMidBone, eEntry_LegFingerBone, 2)
        sIkCond = nodes.createConditionNodes(sAngle, '>', 0, True, False)
        sIkMultipl = nodes.createIfNode(sIkCond, 1.0, 0.0)
        sAngleFkClamp = nodes.createClampNode(sAngle, -1000, 0)
        sFkBase = nodes.createBasicCalculateNode([sAngleFkClamp, 0.2])
        sFkMid = nodes.createBasicCalculateNode([sAngleFkClamp, 0.4])
        sFkTip = nodes.createBasicCalculateNode([sAngleFkClamp, 0.6])
        controllers.closeCommentBox('Get FingerMid Angle')


        # controllers.openCommentBox('manipulate all the ctrls') #base
        controllers.openCommentBox('manipulate base ctrl') #base
        controllers.setNewColumn()
        eEntry_BasePasser = ELEM(nodes.createGetEntryVariable('BasePasser'), 'Null')
        eEntry_BaseBone = ELEM(nodes.createGetEntryVariable('BaseBone'), 'Bone')
        controllers.setNewColumn()
        sBaseWorld = createProjectInitialToTransformFunction(eEntry_BasePasser, eEntry_BaseBone, '%s.Root' % sIk)
        sBaseParent = nodes.getTransformNode(nodes.createGetParentNode(eEntry_BasePasser))
        sBaseLocal = nodes.createMakeRelativeNode(sBaseWorld, sBaseParent)
        sBaseBlended = nodes.createTransformInterpolateNode(sIkMultipl, [None,nodes.createFromEulerNode([sFkBase,0,0]),None], sBaseLocal)
        nodes.createSetTransformExecuteNode(eEntry_BasePasser, sBaseBlended, bLocal=True)
        controllers.closeCommentBox('manipulate base ctrl')

        controllers.openCommentBox('manipulate mid ctrl') #mid
        controllers.setNewColumn()
        eEntry_BasePasser = ELEM(nodes.createGetEntryVariable('BasePasser'), 'Null')
        eEntry_BaseCtrlOut = ELEM(nodes.createGetEntryVariable('BaseControl'), 'Control')
        eEntry_BaseBone = ELEM(nodes.createGetEntryVariable('BaseBone'), 'Bone')
        eEntry_MidPasser = ELEM(nodes.createGetEntryVariable('MidPasser'), 'Null')
        controllers.setNewColumn()
        sParentTransform = createProjectInitialToTransformFunction(eEntry_BaseCtrlOut, eEntry_BaseBone, '%s.Root' % sIk)
        sChainInParent = nodes.createMakeRelativeNode('%s.Elbow' % sIk, sParentTransform)
        sChainJoint = nodes.createMakeAbsoluteNode(sChainInParent, nodes.getTransformNode(eEntry_BaseCtrlOut))
        sMidWorld = createProjectInitialToTransformFunction(eEntry_BasePasser, eEntry_BaseBone, sChainJoint)
        controllers.setNewColumn()
        sMidParent = nodes.getTransformNode(nodes.createGetParentNode(eEntry_MidPasser))
        sMidLocal = nodes.createMakeRelativeNode(sMidWorld, sMidParent)
        sMidBlended = nodes.createTransformInterpolateNode(sIkMultipl, [None,nodes.createFromEulerNode([sFkMid,0,0]),None], sMidLocal)
        nodes.createSetTransformExecuteNode(eEntry_MidPasser, sMidBlended, bLocal=True)
        controllers.closeCommentBox('manipulate mid ctrl')

        controllers.openCommentBox('manipulate tip ctrl') #tip
        controllers.setNewColumn()
        eEntry_MidCtrlOut = ELEM(nodes.createGetEntryVariable('MidControl'), 'Control')
        eEntry_MidBone = ELEM(nodes.createGetEntryVariable('MidBone'), 'Bone')
        eEntry_MidPasser = ELEM(nodes.createGetEntryVariable('MidPasser'), 'Null')
        sEntry_TipPasser = ELEM(nodes.createGetEntryVariable('TipPasser'), 'Null')
        controllers.setNewColumn()
        sParentTransform = createProjectInitialToTransformFunction(eEntry_MidCtrlOut, eEntry_MidBone, '%s.Elbow' % sIk)
        sChainInParent = nodes.createMakeRelativeNode('%s.Effector' % sIk, sParentTransform)
        sChainJoint = nodes.createMakeAbsoluteNode(sChainInParent, nodes.getTransformNode(eEntry_MidCtrlOut))
        sTipWorld = createProjectInitialToTransformFunction(eEntry_MidPasser, eEntry_MidBone, sChainJoint)
        controllers.setNewColumn()
        sTipParent = nodes.getTransformNode(nodes.createGetParentNode(sEntry_TipPasser))
        sTipLocal = nodes.createMakeRelativeNode(sTipWorld, sTipParent)
        sTipBlended = nodes.createTransformInterpolateNode(sIkMultipl, [None,nodes.createFromEulerNode([sFkTip,0,0]),None], sTipLocal)

        nodes.createSetTransformExecuteNode(sEntry_TipPasser, sTipBlended, bLocal=True)
        controllers.closeCommentBox('manipulate tip ctrl')


        controllers.openCommentBox('Passer Poses Rotations')
        for i in iPosePasserRangeRotation:
            controllers.setNewColumn()
            sEntry_PosePasserRotation = nodes.createGetEntryVariable('PosePasserRotation_%d' % i)
            sEntry_PasserPosesDriversRotation = nodes.createGetEntryVariable('PasserPosesDriversRotation_%d' % i)
            sEntry_PasserPosesVectorsRotation = nodes.createGetEntryVariable('PasserPosesVectorsRotation_%d' % i)
            ePasser = ELEM(sEntry_PosePasserRotation, 'Null')
            sForEach = nodes.createForEachExecuteNode(sEntry_PasserPosesDriversRotation)
            if controllers.BLOCK_FOREACH:
                sVector = nodes.createArrayAtNode(sEntry_PasserPosesVectorsRotation, '%s.Index' % sForEach)
                sMultipl = nodes.createBasicCalculateNode([sVector, ['%s.Element' % sForEach, '%s.Element' % sForEach, '%s.Element' % sForEach]], iPinType=pins.PinType.vector)
                sQuat = nodes.createFromEulerNode(sMultipl)
                controllers.setNewColumn()
                nodes.createOffsetTransformExecuteNode(ePasser, [None, sQuat, None])
                controllers.goToParentExecute()

        controllers.closeCommentBox('Passer Poses Rotations')

        if len(iPosePasserRangeTranslation):
            controllers.openCommentBox('Passer Poses Translations')
            for i in iPosePasserRangeTranslation:
                controllers.setNewColumn()
                sEntry_PosePasserTranslation = nodes.createGetEntryVariable('PosePasserTranslation_%d' % i)
                sEntry_PasserPosesDriversTranslation = nodes.createGetEntryVariable('PasserPosesDriversTranslation_%d' % i)
                sEntry_PasserPosesVectorsTranslation = nodes.createGetEntryVariable('PasserPosesVectorsTranslation_%d' % i)

                ePasser = ELEM(sEntry_PosePasserTranslation, 'Null')
                sForEach = nodes.createForEachExecuteNode(sEntry_PasserPosesDriversTranslation)
                if controllers.BLOCK_FOREACH:
                    sVector = nodes.createArrayAtNode(sEntry_PasserPosesVectorsTranslation, '%s.Index' % sForEach)
                    sMultipl = nodes.createBasicCalculateNode([sVector, ['%s.Element' % sForEach, '%s.Element' % sForEach, '%s.Element' % sForEach]], iPinType=pins.PinType.vector)
                    controllers.setNewColumn()
                    nodes.createOffsetTransformExecuteNode(ePasser, [sMultipl, None, None])
                    controllers.goToParentExecute()
            controllers.closeCommentBox('Passer Poses Translations')


        # scale of meta joint
        controllers.openCommentBox('Meta Bone Scale')
        controllers.setNewColumn()
        eEntry_MetaBone = ELEM(nodes.createGetEntryVariable('MetaBone'), 'Bone')
        eEntry_MetaIkControl = ELEM(nodes.createGetEntryVariable('MetaIkControl'), 'Control')
        eEntry_WristBone = ELEM(nodes.createGetEntryVariable('WristBone'), 'Bone')
        controllers.setNewColumn()
        createKangarooAimConstraintFunction(eEntry_MetaBone, eEntry_MetaIkControl, eEntry_WristBone, fWorldUpVector=[0,1,0])
        MetaControlTransform = nodes.getTransformNode(eEntry_MetaIkControl)
        eEntry_MetaBone = ELEM(nodes.createGetEntryVariable('MetaBone'), 'Bone')
        sMetaStart = nodes.getTransformNode(eEntry_MetaBone)
        fDistance = nodes.createGetDistanceNode('%s.Translation' % sMetaStart, '%s.Translation' % MetaControlTransform)
        controllers.setNewColumn()
        sMetaDefaultLength = nodes.createGetVariableNode(vMetaDefaultLength)
        fScaleX = nodes.createBasicCalculateNode([fDistance, sMetaDefaultLength], sOperation='Divide')
        eEntry_MetaBone = ELEM(nodes.createGetEntryVariable('MetaBone'), 'Bone')
        nodes.createSetScaleExecuteNode(eEntry_MetaBone, [fScaleX, 1, 1], bPropagateToChildren=False)
        controllers.closeCommentBox('Meta Bone Scale')

        # transform all fk joints
        controllers.openCommentBox('Setting Joints')
        controllers.setNewColumn()
        eEntry_BaseCtrlOut = ELEM(nodes.createGetEntryVariable('BaseControl'), 'Control')
        eEntry_BaseBone = ELEM(nodes.createGetEntryVariable('BaseBone'), 'Bone')
        eEntry_MidControl = ELEM(nodes.createGetEntryVariable('MidControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_BaseCtrlOut, 1)], eEntry_BaseBone, bMaintainOffset=True)
        createKangarooAimConstraintFunction(eEntry_BaseBone, eEntry_MidControl, eEntry_BaseCtrlOut, fWorldUpVector=[0,1,0])
        controllers.setNewColumn()
        eEntry_MidBone = ELEM(nodes.createGetEntryVariable('MidBone'), 'Bone')
        eEntry_TipBone = ELEM(nodes.createGetEntryVariable('TipBone'), 'Bone')
        eEntry_TipCtrlOut = ELEM(nodes.createGetEntryVariable('TipControl'), 'Control')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_MidControl, 1)], eEntry_MidBone, bMaintainOffset=True)
        createKangarooAimConstraintFunction(eEntry_MidBone, eEntry_TipCtrlOut, eEntry_MidControl, fWorldUpVector=[0,1,0])
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_TipCtrlOut, 1)], eEntry_TipBone, bMaintainOffset=True)
        controllers.closeCommentBox('Setting Joints')

        nodes.endCurrentFunction(bAddToExecute=False)

    sToeNode = nodes.addFunctionNode(sFunctionName)

    pins.setString(sFingerJoint, '%s.LegFingerBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(sFingerMidJoint, '%s.LegFingerMidBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(sWristJoint, '%s.WristBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(sJoints[0], '%s.MetaBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(sJoints[1], '%s.BaseBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(sJoints[2], '%s.MidBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(sJoints[3], '%s.TipBone' % sToeNode, bConnectIfPlug=True)
    pins.setString(cMetaIk.ePasser.name, '%s.MetaIkPasser' % sToeNode, bConnectIfPlug=True)
    pins.setString(cMetaIk.eControl.name, '%s.MetaIkControl' % sToeNode, bConnectIfPlug=True)
    pins.setString(cProxy.eControl.name, '%s.ProxyControl' % sToeNode, bConnectIfPlug=True)

    pins.setString(cFkCtrls[0].dOffsets['ik'].name, '%s.BasePasser' % sToeNode, bConnectIfPlug=True)
    pins.setString(cFkCtrls[0].eControl.name, '%s.BaseControl' % sToeNode, bConnectIfPlug=True)
    pins.setString(cFkCtrls[1].dOffsets['ik'].name, '%s.MidPasser' % sToeNode, bConnectIfPlug=True)
    pins.setString(cFkCtrls[1].eControl.name, '%s.MidControl' % sToeNode, bConnectIfPlug=True)
    pins.setString(cFkCtrls[2].dOffsets['ik'].name, '%s.TipPasser' % sToeNode, bConnectIfPlug=True)
    pins.setString(cFkCtrls[2].eControl.name, '%s.TipControl' % sToeNode, bConnectIfPlug=True)
    pins.connectToPin1D(fIkStretch, '%s.IkStretch' %sToeNode)

    for i,sPasserRotation in enumerate(sPosePassersRotation):
        if not library.isNone(sPasserRotation):
            pins.setString(sPasserRotation, '%s.PosePasserRotation_%d' % (sToeNode,i))
            pins.setValueArray([dFingerPosesDrivers[xP[0]] for xP in xPasserPosesRotation[i]], '%s.PasserPosesDriversRotation_%d' % (sToeNode,i))
            pins.setVectorArray([xP[1] for xP in xPasserPosesRotation[i]], '%s.PasserPosesVectorsRotation_%d' % (sToeNode,i))
    for i,sPasserTranslation in enumerate(sPosePassersTranslation):
        if not library.isNone(sPasserTranslation):
            pins.setString(sPasserTranslation, '%s.PosePasserTranslation_%d' % (sToeNode,i))
            pins.setValueArray([dFingerPosesDrivers[xP[0]] for xP in xPasserPosesTranslation[i]], '%s.PasserPosesDriversTranslation_%d' % (sToeNode,i))
            pins.setVectorArray([xP[1] for xP in xPasserPosesTranslation[i]], '%s.PasserPosesVectorsTranslation_%d' % (sToeNode,i))


    return sToeNode


def createFingerFunction(sFingerJoint, cMetaIk, cFkCtrls, cProxy, sJoints, fMetaDefaultLength, dFingerPosesDrivers={}, sPosePassersRotation=[], xPasserPosesRotation=[], sPosePassersTranslation=[], xPasserPosesTranslation=[]):
    sFunctionName = 'kangaroo_finger'
    uFunction = nodes.getFunction(sFunctionName)
    iPosePasserRangeRotation = range(len(xPasserPosesRotation))
    iPosePasserRangeTranslation = range(len(xPasserPosesTranslation))
    if not uFunction:
        xPasserPosesInputs = [('PosePasserRotation_%d' % i, 'FName', False) for i in iPosePasserRangeRotation] + \
                                [('PasserPosesDriversRotation_%d' % i, 'float', True) for i in iPosePasserRangeRotation] + \
                                [('PasserPosesVectorsRotation_%d' % i, 'FVector', True) for i in iPosePasserRangeRotation] + \
                                [('PosePasserTranslation_%d' % i, 'FName', False) for i in iPosePasserRangeTranslation] + \
                                [('PasserPosesDriversTranslation_%d' % i, 'float', True) for i in iPosePasserRangeTranslation] + \
                                [('PasserPosesVectorsTranslation_%d' % i, 'FVector', True) for i in iPosePasserRangeTranslation]

        nodes.startFunction(sFunctionName, xInputs=[('LegFingerBone', 'FName', False),
                                                     ('MetaIkPasser', 'FName', False),
                                                     ('MetaIkControl', 'FName', False),
                                                     ('MetaBone', 'FName', False),
                                                     ('FkAimBones', 'FName', True),
                                                     ('FkControls', 'FName', True),
                                                     ('ProxyControl', 'FName', False),
                                                     ('LastBone', 'FName', False),
                                                     ] + xPasserPosesInputs)

        controllers.openCommentBox('Reset Passers')
        controllers.setNewColumn()
        for i in iPosePasserRangeRotation:
            ePasser = ELEM('Entry.PosePasserRotation_%d' % i, 'Null')
            sInitialRotation = '%s.Rotation' % nodes.getTransformNode(ePasser, bInitial=True, bLocal=True)
            nodes.createSetRotationExecuteNode(ePasser, sInitialRotation, bLocal=True)
        controllers.setNewColumn()
        if len(iPosePasserRangeTranslation):
            for i in iPosePasserRangeTranslation:
                ePasser = ELEM('Entry.PosePasserTranslation_%d' % i, 'Null')
                sInitialTranslation = '%s.Translation' % nodes.getTransformNode(ePasser, bInitial=True, bLocal=True)
                nodes.createSetTranslationExecuteNode(ePasser, sInitialTranslation, bLocal=True)
        controllers.closeCommentBox('Reset Passers')

        controllers.openCommentBox('Proxy Control')
        controllers.setNewColumn()
        eEntry_ProxyControl = ELEM(nodes.createGetEntryVariable('ProxyControl'), 'Control')
        sProxyControlAnim = nodes.getTransformNode(eEntry_ProxyControl, bLocal=True)
        vProxyControlAnim = hierarchy.newVariable('ProxyControlAnim', 'FQuat')
        nodes.createSetVariableExecuteNode(vProxyControlAnim, '%s.Rotation' % sProxyControlAnim)

        controllers.setNewColumn()
        sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sForeach = nodes.createForEachExecuteNode(sEntry_FkControls)
        if controllers.BLOCK_FOREACH:
            sProxyControlAnim = nodes.createGetVariableNode(vProxyControlAnim)
            eControl = ELEM('%s.Element' % sForeach, 'Control')
            nodes.createOffsetTransformExecuteNode(eControl, [None, sProxyControlAnim, None])
            # nodes.createSendEventExecuteNode(eControl)
            controllers.goToParentExecute()
        controllers.setNewColumn()
        eEntry_ProxyControl = ELEM(nodes.createGetEntryVariable('ProxyControl'), 'Control')
        nodes.createSetRotationExecuteNode(eEntry_ProxyControl, bLocal=True)
        controllers.closeCommentBox('Proxy Control')



        controllers.setNewColumn()
        controllers.openCommentBox('Meta Control')
        eEntry_MetaIkPasser = ELEM(nodes.createGetEntryVariable('MetaIkPasser'), 'Null')
        eEntry_LegFingerBone = ELEM(nodes.createGetEntryVariable('LegFingerBone'), 'Bone')
        controllers.setNewColumn()
        # sMetaStart = nodes.getTransformNode(sEntry_MetaBone)
        nodes.createParentConstraintExecuteNode([(eEntry_LegFingerBone, 1)], eEntry_MetaIkPasser, bMaintainOffset=True)
        controllers.closeCommentBox('Meta Control')

        controllers.openCommentBox('Passer Poses Rotations')
        for i in iPosePasserRangeRotation:
            controllers.setNewColumn()
            sEntry_PosePasserRotation = nodes.createGetEntryVariable('PosePasserRotation_%d' % i)
            sEntry_PasserPosesDriversRotation = nodes.createGetEntryVariable('PasserPosesDriversRotation_%d' % i)
            sEntry_PasserPosesVectorsRotation = nodes.createGetEntryVariable('PasserPosesVectorsRotation_%d' % i)
            controllers.setNewColumn()
            ePasser = ELEM(sEntry_PosePasserRotation, 'Null')
            sForEach = nodes.createForEachExecuteNode(sEntry_PasserPosesDriversRotation)
            sVector = nodes.createArrayAtNode(sEntry_PasserPosesVectorsRotation, '%s.Index' % sForEach)
            sMultipl = nodes.createBasicCalculateNode([sVector, ['%s.Element' % sForEach, '%s.Element' % sForEach, '%s.Element' % sForEach]], iPinType=pins.PinType.vector)
            sQuat = nodes.createFromEulerNode(sMultipl)
            controllers.setNewColumn()
            nodes.createOffsetTransformExecuteNode(ePasser, [None, sQuat, None])
            controllers.goToParentExecute()

        controllers.closeCommentBox('Passer Poses Rotations')

        if len(iPosePasserRangeTranslation):
            controllers.openCommentBox('Passer Poses Translations')
            for i in iPosePasserRangeTranslation:
                controllers.setNewColumn()
                sEntry_PosePasserTranslation = nodes.createGetEntryVariable('PosePasserTranslation_%d' % i)
                sEntry_PasserPosesDriversTranslation = nodes.createGetEntryVariable('PasserPosesDriversTranslation_%d' % i)
                sEntry_PasserPosesVectorsTranslation = nodes.createGetEntryVariable('PasserPosesVectorsTranslation_%d' % i)
                controllers.setNewColumn()
                ePasser = ELEM(sEntry_PosePasserTranslation, 'Null')
                sForEach = nodes.createForEachExecuteNode(sEntry_PasserPosesDriversTranslation)
                if controllers.BLOCK_FOREACH:
                    sVector = nodes.createArrayAtNode(sEntry_PasserPosesVectorsTranslation, '%s.Index' % sForEach)
                    sMultipl = nodes.createBasicCalculateNode([sVector, ['%s.Element' % sForEach, '%s.Element' % sForEach, '%s.Element' % sForEach]], iPinType=pins.PinType.vector)
                    controllers.setNewColumn()
                    nodes.createOffsetTransformExecuteNode(ePasser, [sMultipl, None, None])
                    controllers.goToParentExecute()

            controllers.closeCommentBox('Passer Poses Translations')


        controllers.openCommentBox('Meta Bone Length')
        controllers.setNewColumn()
        sEntry_FkAimBones = nodes.createGetEntryVariable('FkAimBones')
        eFirstAimBone = ELEM(nodes.createArrayAtNode(sEntry_FkAimBones, 0), 'Bone')
        sFirstAimBoneInitialTransform = nodes.getTransformNode(eFirstAimBone, bInitial=True, bLocal=True)
        controllers.setNewColumn()
        sMetaBoneDefaultLength = nodes.createMathAbs('%s.Translation.X' % sFirstAimBoneInitialTransform)
        vMetaBoneDefaultLength = hierarchy.newVariable('MetaBoneDefaultLength')
        nodes.createSetVariableExecuteNode(vMetaBoneDefaultLength, sMetaBoneDefaultLength)
        controllers.closeCommentBox('Meta Bone Length')

        controllers.openCommentBox('Meta Bone')
        controllers.setNewColumn()
        eEntry_MetaBone = ELEM(nodes.createGetEntryVariable('MetaBone'), 'Bone')
        eEntry_MetaIkControl = ELEM(nodes.createGetEntryVariable('MetaIkControl'), 'Control')
        sMetaStart = nodes.getTransformNode(eEntry_MetaBone)
        createKangarooAimConstraintFunction(eEntry_MetaBone, eEntry_MetaIkControl, eEntry_MetaIkControl, fWorldUpVector=[0,1,0])

        controllers.setNewColumn()
        sMetaControlTransform = nodes.getTransformNode(eEntry_MetaIkControl)
        fDistance = nodes.createGetDistanceNode('%s.Translation' % sMetaStart, '%s.Translation' % sMetaControlTransform)
        sMetaDefaultLength = nodes.createGetVariableNode(vMetaBoneDefaultLength)
        fScaleX = nodes.createBasicCalculateNode([fDistance, sMetaDefaultLength], sOperation='Divide')
        nodes.createSetScaleExecuteNode(eEntry_MetaBone, [fScaleX, 1, 1], bPropagateToChildren=False)
        controllers.closeCommentBox('Meta Bone')

        controllers.openCommentBox('FK Bones')
        controllers.setNewColumn()
        sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sForEach = nodes.createForEachExecuteNode(sEntry_FkControls)
        if controllers.BLOCK_FOREACH:
            sNextIndex = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add', iPinType=pins.PinType.integer)
            sThereIsTarget = nodes.createConditionNodes(sNextIndex, '<', '%s.Count' % sForEach, iTermsPinType=pins.PinType.integer)
            controllers.setNewColumn()
            nodes.createBranchExecuteNode(sThereIsTarget)
            if controllers.BLOCK_BRANCH_TRUE:
                sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
                eCurrentBaseTarget = ELEM('%s.Element' % sForEach,'Control')
                eCurrentAimTarget = ELEM(nodes.createArrayAtNode(sEntry_FkControls, sNextIndex), 'Control')
                controllers.setNewColumn()

                sEntry_FkAimBones = nodes.createGetEntryVariable('FkAimBones')
                eBone = ELEM(nodes.createArrayAtNode(sEntry_FkAimBones, '%s.Index' % sForEach), 'Bone')
                nodes.createParentConstraintExecuteNode([(eCurrentBaseTarget, 1)], eBone, bMaintainOffset=True)
                createKangarooAimConstraintFunction(eBone, eCurrentAimTarget, eCurrentBaseTarget, fWorldUpVector=[0, 1, 0])
                controllers.goToParentExecute()
            if controllers.BLOCK_BRANCH_FALSE:
                #nothing
                controllers.goToParentExecute()
            controllers.setNewColumn()
            controllers.goToParentExecute()

        controllers.setNewColumn()
        controllers.closeCommentBox('FK Bones')

        controllers.openCommentBox('Last Bone')
        sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sCount = nodes.createArrayGetCountNode(sEntry_FkControls)
        sLastIndex = nodes.createBasicCalculateNode([sCount, -1], sOperation='Add', iPinType=pins.PinType.integer)
        eEntry_LastControl = ELEM(nodes.createArrayAtNode(sEntry_FkControls, sLastIndex), 'Control')
        eEntry_LastBone = ELEM(nodes.createGetEntryVariable('LastBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_LastControl, 1)], eEntry_LastBone, bMaintainOffset=True)
        controllers.closeCommentBox('Last Bone')

        nodes.endCurrentFunction(bAddToExecute=False)

    sFingerNode = nodes.addFunctionNode(sFunctionName)


    sAimBones = sJoints[1:-1]
    pins.setString(sFingerJoint, '%s.LegFingerBone' % sFingerNode)
    pins.setString(sJoints[0], '%s.MetaBone' % sFingerNode)
    pins.setString(cMetaIk.ePasser.name, '%s.MetaIkPasser' % sFingerNode)
    pins.setString(cMetaIk.eControl.name, '%s.MetaIkControl' % sFingerNode)
    pins.setString(cProxy.eControl.name, '%s.ProxyControl' % sFingerNode)

    pins.setStringArray([cC.eControl.name for cC in cFkCtrls], '%s.FkControls' % sFingerNode)
    pins.setStringArray(sAimBones, '%s.FkAimBones' % sFingerNode)
    pins.setString(sJoints[-1], '%s.LastBone' % sFingerNode)
    for i,sPasserRotation in enumerate(sPosePassersRotation):
        if not library.isNone(sPasserRotation):
            pins.setString(sPasserRotation, '%s.PosePasserRotation_%d' % (sFingerNode,i))
            pins.setValueArray([dFingerPosesDrivers[xP[0]] for xP in xPasserPosesRotation[i]], '%s.PasserPosesDriversRotation_%d' % (sFingerNode,i))
            pins.setVectorArray([xP[1] for xP in xPasserPosesRotation[i]], '%s.PasserPosesVectorsRotation_%d' % (sFingerNode,i))
    for i,sPasserTranslation in enumerate(sPosePassersTranslation):
        if not library.isNone(sPasserTranslation):
            pins.setString(sPasserTranslation, '%s.PosePasserTranslation_%d' % (sFingerNode,i))
            pins.setValueArray([dFingerPosesDrivers[xP[0]] for xP in xPasserPosesTranslation[i]], '%s.PasserPosesDriversTranslation_%d' % (sFingerNode,i))
            pins.setVectorArray([xP[1] for xP in xPasserPosesTranslation[i]], '%s.PasserPosesVectorsTranslation_%d' % (sFingerNode,i))

    return sFingerNode



def createFingerFunction_BACKWARDS(sFingerJoint, cMetaIk, cFkCtrls, sJoints):
    sFunctionName = 'kangaroo_finger_BACKWARDS'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('LegFingerBone', 'FName', False),
                                                 ('MetaIkPasser', 'FName', False),
                                                 ('MetaIk', 'FName', False),
                                                 ('MetaBone', 'FName', False),
                                                 ('BaseBone', 'FName', False),
                                                 ('Bones', 'FName', True),
                                                 ('Controls', 'FName', True)])

        eEntry_LegFingerBone = ELEM('Entry.LegFingerBone', 'Bone')
        eEntry_MetaIkPasser = ELEM('Entry.MetaIkPasser', 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_LegFingerBone, 1)], eEntry_MetaIkPasser, bMaintainOffset=True)

        controllers.setNewColumn()
        eEntry_BaseBone = ELEM(nodes.createGetEntryVariable('BaseBone'), 'Bone')
        eEntry_MetaBone = ELEM(nodes.createGetEntryVariable('MetaBone'), 'Bone')
        eEntry_MetaIk = ELEM(nodes.createGetEntryVariable('MetaIk'), 'Control')
        nodes.createPositionConstraintExecuteNode([(eEntry_BaseBone, 1)], eEntry_MetaIk)
        nodes.createOrientConstraintExecuteNode([(eEntry_MetaBone, 1)], eEntry_MetaIk, bMaintainOffset=True)

        controllers.setNewColumn()
        sEntry_Bones = nodes.createGetEntryVariable('Bones')
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode(sEntry_Bones)
        if controllers.BLOCK_FOREACH:
            eBone = ELEM('%s.Element' % sForEach, 'Bone')
            controllers.setNewColumn()
            sEntry_Controls = nodes.createGetEntryVariable('Controls')
            eCurrentControl = ELEM(nodes.createArrayAtNode(sEntry_Controls, '%s.Index' % sForEach), 'Control')
            nodes.createParentConstraintExecuteNode([(eBone, 1)], eCurrentControl, bMaintainOffset=True)
            controllers.goToParentExecute()
        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sFingerNode = nodes.addFunctionNode(sFunctionName)


    # eBones = [ELEM(sJ, 'Bone') for sJ in sJoints[1:]]
    # eControls = [cC.eOut for cC in cFkCtrls]
    # if len(eBones) != len(eControls):
    #     raise Exception('wrong lengths: eControls: %d, eControls: %d, eAimTargets: %d' % (eBones, eControls))

    pins.setString(sFingerJoint, '%s.LegFingerBone' % sFingerNode)
    pins.setString(sJoints[0], '%s.MetaBone' % sFingerNode)
    pins.setString(sJoints[1], '%s.BaseBone' % sFingerNode)

    pins.setString(cMetaIk.ePasser.name, '%s.MetaIkPasser' % sFingerNode)
    pins.setString(cMetaIk.eControl.name, '%s.MetaIk' % sFingerNode)

    pins.setStringArray([cC.eControl.name for cC in cFkCtrls], '%s.Controls' % sFingerNode)
    pins.setStringArray(sJoints[1:], '%s.Bones' % sFingerNode)

    return sFingerNode


def createFingerFunctionThumb(sArmAttachJoint, cFkCtrls, cProxy, sJoints, dFingerPosesDrivers={}, sPosePassersRotation=[], xPasserPosesRotation=[], sPosePassersTranslation=[], xPasserPosesTranslation=[]):
    sFunctionName = 'kangaroo_finger_thumb'
    uFunction = nodes.getFunction(sFunctionName)
    iPosePasserRangeRotation = range(len(xPasserPosesRotation))
    iPosePasserRangeTranslation = range(len(xPasserPosesTranslation))
    if not uFunction:

        xPasserPosesInputs = [('PosePasserRotation_%d' % i, 'FName', False) for i in iPosePasserRangeRotation] + \
                                [('PasserPosesDriversRotation_%d' % i, 'float', True) for i in iPosePasserRangeRotation] + \
                                [('PasserPosesVectorsRotation_%d' % i, 'FVector', True) for i in iPosePasserRangeRotation] + \
                                [('PosePasserTranslation_%d' % i, 'FName', False) for i in iPosePasserRangeTranslation] + \
                                [('PasserPosesDriversTranslation_%d' % i, 'float', True) for i in iPosePasserRangeTranslation] + \
                                [('PasserPosesVectorsTranslation_%d' % i, 'FVector', True) for i in iPosePasserRangeTranslation]
        nodes.startFunction(sFunctionName, xInputs=[('ArmAttachBone', 'FName', False),
                                                     ('ProxyControl', 'FName', False),
                                                     ('FirstPasser', 'FName', False),
                                                     ('FkAimBones', 'FName', True),
                                                     ('FkControls', 'FName', True),
                                                     # ('FkAimTargets', 'FName', True),
                                                     # ('LastControl', 'FName', False),
                                                     ('LastBone', 'FName', False),
                                                     ] + xPasserPosesInputs)

        controllers.openCommentBox('Reset Passers')
        controllers.setNewColumn()
        for i in iPosePasserRangeRotation:
            ePasser = ELEM('Entry.PosePasserRotation_%d' % i, 'Null')
            sInitialRotation = '%s.Rotation' % nodes.getTransformNode(ePasser, bInitial=True, bLocal=True)
            nodes.createSetRotationExecuteNode(ePasser, sInitialRotation, bLocal=True)
        controllers.setNewColumn()
        if len(iPosePasserRangeTranslation):
            for i in iPosePasserRangeTranslation:
                ePasser = ELEM('Entry.PosePasserTranslation_%d' % i, 'Null')
                sInitialTranslation = '%s.Translation' % nodes.getTransformNode(ePasser, bInitial=True, bLocal=True)
                nodes.createSetTranslationExecuteNode(ePasser, sInitialTranslation, bLocal=True)
        controllers.closeCommentBox('Reset Passers')


        controllers.setNewColumn()
        eFirstPasser = ELEM(nodes.createGetEntryVariable('FirstPasser'), 'Null')
        eEntry_ArmAttachBone = ELEM(nodes.createGetEntryVariable('ArmAttachBone'), 'Bone')
        nodes.createParentConstraintExecuteNode([(eEntry_ArmAttachBone, 1)], eFirstPasser, bMaintainOffset=True)

        controllers.openCommentBox('Proxy Control')
        controllers.setNewColumn()
        eEntry_ProxyControl = ELEM(nodes.createGetEntryVariable('ProxyControl'), 'Control')
        sProxyControlAnim = nodes.getTransformNode(eEntry_ProxyControl, bLocal=True)
        vProxyControlAnim = hierarchy.newVariable('ProxyControlAnim', 'FQuat')
        nodes.createSetVariableExecuteNode(vProxyControlAnim, '%s.Rotation' % sProxyControlAnim)

        controllers.setNewColumn()
        sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sForeach = nodes.createForEachExecuteNode(sEntry_FkControls)
        if controllers.BLOCK_FOREACH:
            sProxyControlAnim = nodes.createGetVariableNode(vProxyControlAnim)
            eControl = ELEM('%s.Element' % sForeach, 'Control')
            nodes.createOffsetTransformExecuteNode(eControl, [None, sProxyControlAnim, None])
            # nodes.createSendEventExecuteNode(eControl)
            controllers.goToParentExecute()
        controllers.setNewColumn()
        eEntry_ProxyControl = ELEM(nodes.createGetEntryVariable('ProxyControl'), 'Control')
        nodes.createSetRotationExecuteNode(eEntry_ProxyControl, bLocal=True)
        controllers.closeCommentBox('Proxy Control')



        controllers.openCommentBox('Passer Poses Rotations')
        for i in iPosePasserRangeRotation:
            controllers.setNewColumn()
            ePasser = ELEM('Entry.PosePasserRotation_%d' % i, 'Null')
            sForEach = nodes.createForEachExecuteNode('Entry.PasserPosesDriversRotation_%d' % i)
            sVector = nodes.createArrayAtNode('Entry.PasserPosesVectorsRotation_%d' % i, '%s.Index' % sForEach)
            sMultipl = nodes.createBasicCalculateNode([sVector, ['%s.Element' % sForEach, '%s.Element' % sForEach, '%s.Element' % sForEach]], iPinType=pins.PinType.vector)
            sQuat = nodes.createFromEulerNode(sMultipl)
            controllers.setNewColumn()
            nodes.createOffsetTransformExecuteNode(ePasser, [None, sQuat, None])
            controllers.goToParentExecute()

        controllers.closeCommentBox('Passer Poses Rotations')

        if len(iPosePasserRangeTranslation):
            controllers.openCommentBox('Passer Poses Translations')
            for i in iPosePasserRangeTranslation:
                controllers.setNewColumn()
                ePasser = ELEM('Entry.PosePasserTranslation_%d' % i, 'Null')
                sForEach = nodes.createForEachExecuteNode('Entry.PasserPosesDriversTranslation_%d' % i)
                sVector = nodes.createArrayAtNode('Entry.PasserPosesVectorsTranslation_%d' % i, '%s.Index' % sForEach)
                sMultipl = nodes.createBasicCalculateNode([sVector, ['%s.Element' % sForEach, '%s.Element' % sForEach, '%s.Element' % sForEach]], iPinType=pins.PinType.vector)
                controllers.setNewColumn()
                nodes.createOffsetTransformExecuteNode(ePasser, [sMultipl, None, None])
                controllers.goToParentExecute()

            controllers.closeCommentBox('Passer Poses Translations')


        controllers.openCommentBox('FK Bones')
        controllers.setNewColumn()
        sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sForEach = nodes.createForEachExecuteNode(sEntry_FkControls)
        if controllers.BLOCK_FOREACH:
            sNextIndex = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 1], sOperation='Add', iPinType=pins.PinType.integer)
            sThereIsTarget = nodes.createConditionNodes(sNextIndex, '<', '%s.Count' % sForEach, iTermsPinType=pins.PinType.integer)
            controllers.setNewColumn()
            nodes.createBranchExecuteNode(sThereIsTarget)
            if controllers.BLOCK_BRANCH_TRUE:
                sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
                eCurrentBaseTarget = ELEM('%s.Element' % sForEach,'Control')
                eCurrentAimTarget = ELEM(nodes.createArrayAtNode(sEntry_FkControls, sNextIndex), 'Control')
                controllers.setNewColumn()

                sEntry_FkAimBones = nodes.createGetEntryVariable('FkAimBones')
                eBone = ELEM(nodes.createArrayAtNode(sEntry_FkAimBones, '%s.Index' % sForEach), 'Bone')
                nodes.createParentConstraintExecuteNode([(eCurrentBaseTarget, 1)], eBone, bMaintainOffset=True)
                createKangarooAimConstraintFunction(eBone, eCurrentAimTarget, eCurrentBaseTarget, fWorldUpVector=[0, 1, 0])
                controllers.goToParentExecute()
            if controllers.BLOCK_BRANCH_FALSE:
                #nothing
                controllers.goToParentExecute()
            controllers.setNewColumn()
            controllers.goToParentExecute()

        controllers.setNewColumn()
        controllers.closeCommentBox('FK Bones')

        controllers.openCommentBox('Last Bone')
        sEntry_FkControls = nodes.createGetEntryVariable('FkControls')
        sCount = nodes.createArrayGetCountNode(sEntry_FkControls)
        sLastIndex = nodes.createBasicCalculateNode([sCount, -1], sOperation='Add', iPinType=pins.PinType.integer)
        eEntry_LastControl = ELEM(nodes.createArrayAtNode(sEntry_FkControls, sLastIndex), 'Control')
        eEntry_LastBone = ELEM(nodes.createGetEntryVariable('LastBone'), 'Bone')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eEntry_LastControl, 1)], eEntry_LastBone, bMaintainOffset=True)
        controllers.closeCommentBox('Last Bone')

        nodes.endCurrentFunction(bAddToExecute=False)

    sFingerNode = nodes.addFunctionNode(sFunctionName)


    pins.setString(sArmAttachJoint, '%s.ArmAttachBone' % sFingerNode)
    pins.setStringArray( [cC.eControl.name for cC in cFkCtrls], '%s.FkControls' % sFingerNode)
    pins.setStringArray(sJoints[:-1], '%s.FkAimBones' % sFingerNode)
    pins.setString(cProxy.eControl.name, '%s.ProxyControl' % sFingerNode)
    pins.setString(cFkCtrls[0].ePasser.name, '%s.FirstPasser' % sFingerNode)
    # pins.setString(cFkCtrls[-1].eControl.name, '%s.LastControl' % sFingerNode)
    pins.setString(sJoints[-1], '%s.LastBone' % sFingerNode)
    for i,sPasserRotation in enumerate(sPosePassersRotation):
        if not library.isNone(sPasserRotation):
            pins.setString(sPasserRotation, '%s.PosePasserRotation_%d' % (sFingerNode,i))
            pins.setValueArray([dFingerPosesDrivers[xP[0]] for xP in xPasserPosesRotation[i]], '%s.PasserPosesDriversRotation_%d' % (sFingerNode,i))
            pins.setVectorArray([xP[1] for xP in xPasserPosesRotation[i]], '%s.PasserPosesVectorsRotation_%d' % (sFingerNode,i))
    for i,sPasserTranslation in enumerate(sPosePassersTranslation):
        if not library.isNone(sPasserTranslation):
            pins.setString(sPasserTranslation, '%s.PosePasserTranslation_%d' % (sFingerNode,i))
            pins.setValueArray([dFingerPosesDrivers[xP[0]] for xP in xPasserPosesTranslation[i]], '%s.PasserPosesDriversTranslation_%d' % (sFingerNode,i))
            pins.setVectorArray([xP[1] for xP in xPasserPosesTranslation[i]], '%s.PasserPosesVectorsTranslation_%d' % (sFingerNode,i))

    return sFingerNode



def createFingerFunctionThumb_BACKWARDS(sArmAttachJoint, cFkCtrls, sJoints):
    sFunctionName = 'kangaroo_finger_thumb_BACKWARDS'
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('ArmAttachBone', 'FName', False),
                                                     ('FirstPasser', 'FName', False),
                                                     ('Controls', 'FName', True),
                                                     ('Bones', 'FName', True)])

        eEntry_ArmAttachBone = ELEM('Entry.ArmAttachBone', 'Bone')
        eEntry_FirstPasser = ELEM('Entry.FirstPasser', 'Null')
        nodes.createParentConstraintExecuteNode([(eEntry_ArmAttachBone, 1)], eEntry_FirstPasser, bMaintainOffset=True)

        controllers.setNewColumn()
        sEntry_Bones = nodes.createGetEntryVariable('Bones')
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode(sEntry_Bones)
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eBone = ELEM('%s.Element' % sForEach, 'Bone')
            sEntry_Controls = nodes.createGetEntryVariable('Controls')
            eCurrentControl = ELEM(nodes.createArrayAtNode(sEntry_Controls, '%s.Index' % sForEach), 'Control')
            nodes.createParentConstraintExecuteNode([(eBone, 1)], eCurrentControl, bMaintainOffset=True)
            controllers.goToParentExecute()
        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)

    sFingerNode = nodes.addFunctionNode(sFunctionName)


    if len(cFkCtrls) != len(sJoints):
        raise Exception('wrong lengths: eAimBones: %d, eBaseTargets: %d' % (len(cFkCtrls), len(sJoints)))

    pins.setString(sArmAttachJoint, '%s.ArmAttachBone' % sFingerNode)
    pins.setString(cFkCtrls[0].ePasser.name, '%s.FirstPasser' % sFingerNode)
    pins.setStringArray([cC.eControl.name for cC in cFkCtrls], '%s.Controls' % sFingerNode)
    pins.setStringArray(sJoints, '%s.Bones' % sFingerNode)
    return sFingerNode




# functions.moveCtrlsByAppleCurves({'blinkLFT_ctrl.translateZ': [(-1, 'eyeBlinkLeft'), (0.5, 'eyeWideLeft')], 'blinkRGT_ctrl.translateZ': [(-1, 'eyeBlinkRight'), (0.5, 'eyeWideRight')], 'innerEyebrowLFT_ctrl.translateZ': [(-1, 'browDownLeft'), (1, 'browInnerUp')], 'innerEyebrowRGT_ctrl.translateZ': [(-1, 'browDownRight'), (1, 'browInnerUp')], 'outerEyebrowLFT_ctrl.translateZ': [(1, 'browOuterUpLeft')], 'outerEyebrowRGT_ctrl.translateZ': [(1, 'browOuterUpRight')], 'cheekRaiserLFT_ctrl.translateZ': [(1, 'cheekSquintLeft')], 'cheekRaiserRGT_ctrl.translateZ': [(1, 'cheekSquintRight')], 'puffLFT_ctrl.translateZ': [(1, 'cheekPuff')], 'puffRGT_ctrl.translateZ': [(1, 'cheekPuff')], 'jaw_ctrl.rotateZ': [(0.0, 'jawOpen')], 'jaw_ctrl.translateY': [(3.0, 'jawRight')], 'jaw_ctrl.translateX': [(3.0, 'jawForward')], 'mouth_ctrl.translateY': [(1.0, 'mouthFunnel')], 'mouthBot_ctrl.translateY': [(-1.0, 'mouthRollLower'), (1.0, 'mouthShrugLower')], 'mouthTop_ctrl.translateY': [(-1.0, 'mouthRollUpper'), (1.0, 'mouthShrugUpper')], 'lipsBot0LFT_ctrl.translateZ': [(1.0, 'mouthLowerDownLeft')], 'lipsBot0RGT_ctrl.translateZ': [(1.0, 'mouthLowerDownRight')], 'lipsTop0LFT_ctrl.translateZ': [(1.0, 'mouthUpperUpLeft')], 'lipsTop0RGT_ctrl.translateZ': [(1.0, 'mouthUpperUpRight')], 'noseWrinklerLFT_ctrl.translateZ': [(1.0, 'noseSneerLeft')], 'noseWrinklerRGT_ctrl.translateZ': [(1.0, 'noseSneerRight')], 'lipsCornerLFT_ctrl.translateX': [(1.0, 'mouthDimpleLeft')], 'lipsCornerRGT_ctrl.translateX': [(1.0, 'mouthDimpleRight')], 'lipsCornerLFT_ctrl.translateZ': [(1.0, 'mouthSmileLeft'), (-1.0, 'mouthFrownLeft')], 'lipsCornerRGT_ctrl.translateZ': [(1.0, 'mouthSmileRight'), (-1.0, 'mouthFrownRight')], 'eyesLookAtLFT_ctrl.translateZ': [(15, 'eyeLookUpLeft'), (-15, 'eyeLookDownLeft')], 'eyesLookAtLFT_ctrl.translateX': [(-15, 'eyeLookInLeft'), (15, 'eyeLookOutLeft')], 'eyesLookAtRGT_ctrl.translateZ': [(15, 'eyeLookUpRight'), (-15, 'eyeLookDownRight')], 'eyesLookAtRGT_ctrl.translateX': [(-15, 'eyeLookInRight'), (15, 'eyeLookOutRight')]})
def moveCtrlsByAppleCurves(dDict):
    '''
    dDict['blinkLFT_ctrl.translateZ'] = [(-1,'eyeBlinkLeft'), (1,'eyeWideLeft')]
    dDict['blinkRGT_ctrl.translateZ'] = [(-1,'eyeBlinkRight'), (1,'eyeWideRight')]
    dDict['innerEyebrowLFT_ctrl.translateZ'] = [(-1,'browDownLeft'), (1,'browInnerUp')]
    dDict['innerEyebrowRGT_ctrl.translateZ'] = [(-1,'browDownRight'), (1,'browInnerUp')]
    dDict['outerEyebrowLFT_ctrl.translateZ'] = [(1,'browOuterUpLeft')]
    dDict['outerEyebrowRGT_ctrl.translateZ'] = [(1,'browOuterUpRight')]
    dDict['cheekRaiserRGT_ctrl.translateZ'] = [(1,'cheekSquintRight')]
    dDict['cheekRaiserLFT_ctrl.translateZ'] = [(1,'cheekSquintLeft')]
    dDict['puffLFT_ctrl.translateZ'] = [(1,'cheekPuff')]
    dDict['puffRGT_ctrl.translateZ'] = [(1,'cheekPuff')]
    dDict['jaw_ctrl.rotateZ'] = [(fJawOpenRotation[0], 'jawOpen')]
    dDict['lipsCornerLFT_ctrl.translateX'] = [(1.0, 'mouthDimpleLeft')]
    dDict['lipsCornerLFT_ctrl.translateZ'] = [(1.0, 'mouthSmileLeft')]
    dDict['jaw_ctrl.rotateZ']: [(0.0, 'jawOpen')]
    '''

    nodes.newSequencerPlug()
    controllers.openCommentBox('Move Controls by Apple Curves')
    sCtrlAttrs = list(dDict.keys())
    dCtrls = defaultdict(list)
    for sCtrlAttr in sCtrlAttrs:
        sCtrl, sAttr = sCtrlAttr.split('.')
        dCtrls[sCtrl].append(sAttr)

    sSortedCtrls = sorted(list(dCtrls.keys()))
    for sCtrl in sSortedCtrls:
        sAttrs = dCtrls[sCtrl]
        sSums = []
        for sAttr in sAttrs:
            xPoses = dDict['%s.%s' % (sCtrl,sAttr)]

            sOutputs = []
            for fCtrlValue, sAppleCurve in xPoses:
                sOutputs.append(nodes.createRemapNode(nodes.createGetCurveValue(sAppleCurve), 0, 1, 0, fCtrlValue))

            controllers.setNewColumn()
            if len(sOutputs) == 1:
                sSums.append(sOutputs[0])
            else:
                sSums.append(nodes.createBasicCalculateNode(sOutputs, sOperation='Add'))


        xTransform = [[0,0,0], None, [1,1,1]]
        controllers.setNewColumn()

        for sSum, sAttr in zip(sSums, sAttrs):
            if sAttr.startswith('translate'):
                iAxis = ['translateX', 'translateY', 'translateZ'].index(sAttr)
                xTransform[0][iAxis] = sSum
            elif sAttr.startswith('rotate'):
                iAxis = ['rotateX', 'rotateY', 'rotateZ'].index(sAttr)
                fEuler = [0,0,0]
                fEuler[iAxis] = sSum
                xTransform[1] = nodes.createFromEulerNode(fEuler)

        nodes.createSetTransformExecuteNode(ELEM(sCtrl, 'Control'), xTransform, bLocal=True)

    controllers.closeCommentBox('Move Controls by Apple Curves')




def createKangarooAimConstraintFunction(eBone, eTarget, eWorldUpSpace, fAimVector=[1,0,0], fUpVector=[0,0,1], fWorldUpVector=[0,0,1]):#, fWeight=1.0):
    sFunctionName = 'kangaroo_aimConstraint'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('TargetAim', 'FRigElementKey', False),
                                                     ('Bone', 'FRigElementKey', False),
                                                     ('TargetUp', 'FRigElementKey', False),
                                                     # ('Weight', 'float', False),
                                                     ('AimVector', 'FVector', False),
                                                     ('UpVector', 'FVector', False),
                                                     ('WorldUpVector', 'FVector', False)] )
        sBoneInitial = nodes.getTransformNode('Entry.Bone', bInitial=True)
        sBone = nodes.getTransformNode('Entry.Bone')
        sTargetAimInitial = nodes.getTransformNode('Entry.TargetAim', bInitial=True)
        sTargetAim = nodes.getTransformNode('Entry.TargetAim')
        sTargetUpInitial = nodes.getTransformNode('Entry.TargetUp', bInitial=True)
        sTargetUp = nodes.getTransformNode('Entry.TargetUp')

        sSourcePosition = '%s.Translation' % sBone
        controllers.setNewColumn()
        sUpVectorTranslationInitial = '%s.Translation' % nodes.createMakeAbsoluteNode(['Entry.WorldUpVector', None, None], ['%s.Translation' % sBoneInitial, '%s.Rotation' % sTargetUpInitial,None])
        sUpVectorTranslation = '%s.Translation' % nodes.createMakeAbsoluteNode(['Entry.WorldUpVector', None, None], [sSourcePosition, '%s.Rotation' % sTargetUp,None])

        sAimMathInitial = nodes.createAimNode(['%s.Translation' % sBoneInitial, None, None],
                                              '%s.Translation' % sTargetAimInitial, fAimVector='Entry.AimVector', fUpVector='Entry.UpVector',
                                              bUpIsDirection=False, fWorldUpVector=sUpVectorTranslationInitial, fNodeSize=[300.0,600.0])

        sAimMath = nodes.createAimNode([sSourcePosition, None, None],
                                            '%s.Translation' % sTargetAim, fAimVector='Entry.AimVector', fUpVector='Entry.UpVector', # '%s.Rotation' % sBoneFromParent
                                            bUpIsDirection=False, fWorldUpVector=sUpVectorTranslation, fNodeSize=[300.0,600.0])
        controllers.setNewColumn()
        sOffset = nodes.createMakeRelativeNode(sBoneInitial, sAimMathInitial)
        sWorldAimed = nodes.createMakeAbsoluteNode(sOffset, sAimMath)

        controllers.setNewColumn()

        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode('Entry.Bone', ['%s.Translation' % sBone,  '%s.Rotation' % sWorldAimed, '%s.Scale3D' % sBone])#, fWeight='Entry.Weight')
        
        nodes.endCurrentFunction(bAddToExecute=False)


    sAimNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300.0,400.0])
    pins.connectItem(eBone, '%s.Bone' % sAimNode)
    pins.connectItem(eTarget, '%s.TargetAim' % sAimNode)
    pins.connectItem(eWorldUpSpace, '%s.TargetUp' % sAimNode)
    pins.connectToPinVector(fAimVector, '%s.AimVector' % sAimNode)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sAimNode)
    pins.connectToPinVector(fWorldUpVector, '%s.WorldUpVector' % sAimNode)


    # pins.connectToPin1D(fWeight, '%s.Weight' % sAimNode)
    return sAimNode



def createKangarooAimConstraintFunctionWeighted(eBone, eTarget, eWorldUpSpace, fAimVector=[1,0,0], fUpVector=[0,0,1], fWorldUpVector=[0,0,1], fWeight=1.0, fSourcePosition=None):
    bSourcePosition = not library.isNone(fSourcePosition)
    sFunctionName = 'kangaroo_aimConstraintWeighted'
    if bSourcePosition:
        sFunctionName = '%s_sourcePosition' % sFunctionName

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        xExtraInputs = [('SourcePosition', 'FVector', False)] if not library.isNone(fSourcePosition) else []
        nodes.startFunction(sFunctionName, xInputs=[('TargetAim', 'FRigElementKey', False),
                                                                         ('Bone', 'FRigElementKey', False),
                                                                         ('TargetUp', 'FRigElementKey', False),
                                                                         ('Weight', 'float', False),
                                                                         ('AimVector', 'FVector', False),
                                                                         ('UpVector', 'FVector', False),
                                                                         ('WorldUpVector', 'FVector', False)] + xExtraInputs)
        sBoneInitial = nodes.getTransformNode('Entry.Bone', bInitial=True)
        sBone = nodes.getTransformNode('Entry.Bone')
        sTargetAimInitial = nodes.getTransformNode('Entry.TargetAim', bInitial=True)
        sTargetAim = nodes.getTransformNode('Entry.TargetAim')
        sTargetUpInitial = nodes.getTransformNode('Entry.TargetUp', bInitial=True)
        sTargetUp = nodes.getTransformNode('Entry.TargetUp')

        sSourcePosition = 'Entry.SourcePosition' if bSourcePosition else '%s.Translation' % sBone
        controllers.setNewColumn()
        sUpVectorTranslationInitial = '%s.Translation' % nodes.createMakeAbsoluteNode(['Entry.WorldUpVector', None, None], ['%s.Translation' % sBoneInitial, '%s.Rotation' % sTargetUpInitial,None])
        sUpVectorTranslation = '%s.Translation' % nodes.createMakeAbsoluteNode(['Entry.WorldUpVector', None, None], [sSourcePosition, '%s.Rotation' % sTargetUp,None])

        sAimMathInitial = nodes.createAimNode(['%s.Translation' % sBoneInitial, None, None],
                                              '%s.Translation' % sTargetAimInitial, fAimVector='Entry.AimVector', fUpVector='Entry.UpVector',
                                              bUpIsDirection=False, fWorldUpVector=sUpVectorTranslationInitial, fNodeSize=[300.0,600.0])

        eParent = nodes.createGetParentNode('Entry.Bone')
        sBoneLocalInitial = nodes.getTransformNode('Entry.Bone', bLocal=True, bInitial=True)

        sBoneFromParent = nodes.createMakeAbsoluteNode(sBoneLocalInitial, nodes.getTransformNode(eParent))

        sAimMath = nodes.createAimNode([sSourcePosition, None, None],
                                            '%s.Translation' % sTargetAim, fAimVector='Entry.AimVector', fUpVector='Entry.UpVector', # '%s.Rotation' % sBoneFromParent
                                            bUpIsDirection=False, fWorldUpVector=sUpVectorTranslation, fNodeSize=[300.0,600.0])
        controllers.setNewColumn()
        sOffset = nodes.createMakeRelativeNode(sBoneInitial, sAimMathInitial)
        sWorldAimed = nodes.createMakeAbsoluteNode(sOffset, sAimMath)

        controllers.setNewColumn()
        sInterpolatedRotation = nodes.createRotationInterpolateNode('Entry.Weight', '%s.Rotation' % sBoneFromParent, '%s.Rotation' % sWorldAimed)

        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode('Entry.Bone', ['%s.Translation' % sBone, sInterpolatedRotation, '%s.Scale3D' % sBone]) #, fWeight='Entry.Weight')

        nodes.endCurrentFunction(bAddToExecute=False)


    sAimNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300.0,400.0])
    pins.connectItem(eBone, '%s.Bone' % sAimNode)
    pins.connectItem(eTarget, '%s.TargetAim' % sAimNode)
    pins.connectItem(eWorldUpSpace, '%s.TargetUp' % sAimNode)
    pins.connectToPinVector(fAimVector, '%s.AimVector' % sAimNode)
    pins.connectToPinVector(fUpVector, '%s.UpVector' % sAimNode)
    pins.connectToPinVector(fWorldUpVector, '%s.WorldUpVector' % sAimNode)

    if bSourcePosition:
        pins.connectToPinVector(fSourcePosition, '%s.SourcePosition' % sAimNode)

    pins.connectToPin1D(fWeight, '%s.Weight' % sAimNode)
    return sAimNode



def createProjectInitialToTransformFunction(eBone, eParent, sTransform):
    sFunctionName = 'kangaroo_projectInitialToTransformNode'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Bone', 'FRigElementKey', False),
                                                                         ('Parent', 'FRigElementKey', False),
                                                                         ('Transform', 'FTransform', False)],
                                                                 xOutputs=[('OutTransform', 'FTransform', False)], bMutable=False)

        sBoneInitial = nodes.getTransformNode('Entry.Bone', bInitial=True)
        sParentInitial = nodes.getTransformNode('Entry.Parent', bInitial=True)
        sRelative = nodes.createMakeRelativeNode(sBoneInitial, sParentInitial)
        sAbsolute = nodes.createMakeAbsoluteNode(sRelative, 'Entry.Transform')
        pins.connectToPin1D(sAbsolute, 'Return.OutTransform')

        
        nodes.endCurrentFunction(bAddToExecute=False)


    sProjectNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False, fNodeSize=[300.0,400.0])
    pins.connectItem(eBone, '%s.Bone' % sProjectNode)
    pins.connectItem(eParent, '%s.Parent' % sProjectNode)
    pins.connectToPinTransform(sTransform, '%s.Transform' % sProjectNode)
    return '%s.OutTransform' % sProjectNode


def mapFloatControl(sParent, sAttr, fPose):
    sFunctionName = 'kangaroo_mapPoseControl'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Parent', 'FName', False),
                                                    ('Attr', 'FName', False),
                                                    ('Max', 'float', False)],
                                                xOutputs=[('Strength', 'float', False)], bMutable=False)
        sGetChannel = nodes.createGetChannelNode2('Entry.Parent', 'Entry.Attr')
        sMap = nodes.createRemapNode(sGetChannel, 0, 'Entry.Max', 0, 1)
        pins.connectToPin1D(sMap, 'Return.Strength')
        nodes.endCurrentFunction(bAddToExecute=False)

    sMapFloatNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=False, fNodeSize=[300.0, 400.0])
    pins.setString(sParent, '%s.Parent' % sMapFloatNode)
    pins.setString(sAttr, '%s.Attr' % sMapFloatNode)
    pins.connectToPin1D(fPose, '%s.Max' % sMapFloatNode)
    return '%s.Strength' % sMapFloatNode



def createOneFingerControlPosesFunctions(sPasserAttr, sStengthes, ffVectors):

    if len(sStengthes) != len(ffVectors):
        raise Exception('sStrengthes and ffVectors need to be the same length!')

    sPasser, sA = sPasserAttr.split('.')
    sFunctionName = 'kangaroo_oneFingerPose_%s' % sA

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[('Passer', 'FRigElementKey', False),
                                                    ('Strengthes', 'float', True),
                                                    ('Vectors', 'FVector', True)])
        controllers.setNewColumn()
        # if sA == 't':
        #     sInitial = nodes.getTransformNode('Entry.Passer', bLocal=True, bInitial=True)
        #     nodes.createSetTranslationExecuteNode('Entry.Passer', '%s.Translation' % sInitial, bLocal=True)
        # elif sA == 'r':
        #     sInitial = nodes.getTransformNode('Entry.Passer', bLocal=True, bInitial=True)
        #     nodes.createSetRotationExecuteNode('Entry.Passer', '%s.Rotation' % sInitial, bLocal=True)
        # else:
        #     raise Exception('not sure what to do with attribute %s in %s' % (sA, sPasser))

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.Vectors')
        sStrength = nodes.createArrayAtNode('Entry.Strengthes', '%s.Index' % sForEach)
        sMultipl = nodes.createBasicCalculateNode(['%s.Element' % sForEach, [sStrength,sStrength,sStrength]], sOperation='Multiply', iPinType=pins.PinType.vector)

        if sA == 't':
            nodes.createOffsetTransformExecuteNode('Entry.Passer', [sMultipl,None,None])
        elif sA == 'r':
            nodes.createOffsetTransformExecuteNode('Entry.Passer', [None, nodes.createFromEulerNode(sMultipl), None])
        controllers.goToParentExecute()
        nodes.endCurrentFunction(bAddToExecute=False)


    sPoseNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setValueArray(sStengthes, '%s.Strengthes' % sPoseNode)
    pins.setVectorArray(ffVectors, '%s.Vectors' % sPoseNode)
    controllers.setNewColumn()
    pins.connectItem(ELEM(sPasser, 'Null'), '%s.Passer' % sPoseNode)
    return sPoseNode




'''
functions.fingerPoses({'indexBase_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [102.07447, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.90678, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', 10.0, [95.58889, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [0.0, 0.0, 20.35545]), ('armGlobal_l_ctrl.spread', -5.0, [0.0, 0.0, -12.54535])], 'indexBase_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [-0.0, -0.0, 0.0])], 'indexMid_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [87.85868, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.02856, 0.0, 0.0])], 'indexMid_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [-0.0, -0.0, -0.0])], 'indexTip_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [106.48885, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-5.76683, 0.0, 0.0])], 'indexTip_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, 0.0, -0.0])], 'middleBase_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [102.07447, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.90678, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', 10.0, [95.58889, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [0.0, 0.0, 4.79593])], 'middleMid_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [87.85868, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.02856, 0.0, 0.0])], 'middleMid_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, 0.0, 0.0])], 'middleTip_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [106.48885, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-5.76683, 0.0, 0.0])], 'middleTip_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, -0.0, 0.0])], 'pinkyBase_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [102.07447, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.90678, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', 10.0, [95.58889, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [0.0, 0.0, -15.9196]), ('armGlobal_l_ctrl.spread', -5.0, [0.0, 0.0, 14.12797])], 'pinkyBase_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [-0.0, 0.0, 0.0])], 'pinkyMid_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [87.85868, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.02856, 0.0, 0.0])], 'pinkyMid_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, 0.0, 0.0])], 'pinkyTip_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [106.48885, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-5.76683, 0.0, 0.0])], 'pinkyTip_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, 0.0, 0.0])], 'ringBase_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [102.07447, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.90678, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', 10.0, [95.58889, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [0.0, 0.0, -2.27314]), ('armGlobal_l_ctrl.spread', -5.0, [0.0, 0.0, 10.07275])], 'ringMid_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [87.85868, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-13.02856, 0.0, 0.0])], 'ringMid_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, 0.0, 0.0])], 'ringTip_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [106.48885, 0.0, 0.0]), ('armGlobal_l_ctrl.curl', -5.0, [-5.76683, 0.0, 0.0])], 'ringTip_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [0.0, 0.0, 0.0])], 'thumbBase_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [39.52225, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [-15.749, 0.0, 0.0])], 'thumbBase_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [-0.0, 0.0, 0.0])], 'thumbMeta_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [-0.0, -0.0, 0.0])], 'thumbMid_r_ctrl.r': [('armGlobal_l_ctrl.curl', 10.0, [37.5165, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [-12.18428, 0.0, 0.0])], 'thumbMid_r_ctrl.t': [('armGlobal_l_ctrl.curl', 10.0, [-0.0, 0.0, 0.0])], 'indexBaseIk_r_ctrl.t': [('armGlobal_l_ctrl.curl', -5.0, [0.0, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', 10.0, [0.0, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [0.0, 0.0, 0.0])], 'ringBaseIk_r_ctrl.t': [('armGlobal_l_ctrl.curl', -5.0, [-0.0, 0.0, 0.0]), ('armGlobal_l_ctrl.baseCurl', 10.0, [-0.0, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', 10.0, [-0.0, 0.0, 0.0])], 'thumbMeta_r_ctrl.r': [('armGlobal_l_ctrl.spread', 10.0, [-15.6896, 0.0, 0.0]), ('armGlobal_l_ctrl.spread', -5.0, [16.57119, 1.59861, -5.35596])]})
'''
def fingerPoses(dProducts):

    sFunctionName = 'kangaroo_fingerPoses'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:

        nodes.startFunction(sFunctionName, xInputs=[])
        controllers.setNewColumn()
        dRanges = {}
        for sControlAttr, xDatas in dProducts.items():
            for sAttr, fPose, fVector in xDatas:
                sKey = '%s_%0.3f' % (sAttr, fPose)
                if sKey not in dRanges:
                    sCtrl,sA = sAttr.split('.')
                    dRanges[sKey] = mapFloatControl(sCtrl, sA, fPose)

        for sControlAttr, xDatas in dProducts.items():
            sStrengthes = []
            ffVectors = []
            for sAttr, fPose, fVector in xDatas:
                sKey = '%s_%0.3f' % (sAttr, fPose)
                sStrengthes.append(dRanges[sKey])
                ffVectors.append(fVector)
            controllers.setNewColumn()
            createOneFingerControlPosesFunctions(sControlAttr, sStrengthes, ffVectors)

        nodes.endCurrentFunction(bAddToExecute=False)


    sFingerPosesNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    return '%s.OutTransform' % sFingerPosesNode


def pointsFromItems(eItems, bInitial=False, bLocal=False):
    sFunctionName = 'kangaroo_pointsFromItems_%s' % ('local' if bLocal else 'global')

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Items', 'FRigElementKey', True),
                                                    ('bInitial', 'bool', False)],
                                                    # ('bLocal', 'bool', False)],
                                            xOutputs=[('Points', 'FVector', True)])

        controllers.setNewColumn()
        vPoints = hierarchy.newVariable('OutPoints', 'FVector', True, bLocal=True)
        sPointsVariableNode = nodes.createGetVariableNode(vPoints)
        nodes.createResetArrayNode(sPointsVariableNode)

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.Items')
        controllers.setNewColumn()
        sTransform = nodes.getTransformNode('%s.Element' % sForEach, bInitial='Entry.bInitial', bLocal=bLocal)
        nodes.createArrayAddNode(sPointsVariableNode, '%s.Translation' % sTransform)
        controllers.goToParentExecute()

        controllers.setNewColumn()
        pins.connectToPinVector(sPointsVariableNode, 'Return.Points')
        nodes.endCurrentFunction(bAddToExecute=False)


    sPointsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setItemArray(eItems, '%s.Items' % sPointsNode)
    pins.connectToPin1D(bInitial, '%s.bInitial' % sPointsNode)
    # pins.connectToPin1D(bLocal, '%s.bLocal' % sPointsNode)
    return '%s.Points' % sPointsNode


def makePointsAbsolute(sPoints, eItem):
    sFunctionName = 'kangaroo_makePointsAbsolute'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Points', 'FVector', True),
                                                    ('Item', 'FRigElementKey', False)],
                                            xOutputs=[('OutPoints', 'FVector', True)])

        controllers.setNewColumn()
        vOutPoints = hierarchy.newVariable('OutPoints', 'FVector', True, bLocal=True)
        sGetPointsVariableNode = nodes.createGetVariableNode(vOutPoints)
        nodes.createResetArrayNode(sGetPointsVariableNode)

        controllers.setNewColumn()
        sTransform = nodes.getTransformNode('Entry.Item')
        sForEach = nodes.createForEachExecuteNode('Entry.Points')
        controllers.setNewColumn()
        sAbsolutePoint = '%s.Translation' % nodes.createMakeAbsoluteNode(['%s.Element' % sForEach,None,None], sTransform)
        nodes.createArrayAddNode(sGetPointsVariableNode, sAbsolutePoint)
        controllers.goToParentExecute()

        controllers.setNewColumn()
        sGetPointsVariableNode = nodes.createGetVariableNode(vOutPoints)
        pins.connectToPinVector(sGetPointsVariableNode, 'Return.OutPoints')
        nodes.endCurrentFunction(bAddToExecute=False)


    sPointsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setVectorArray(sPoints, '%s.Points' % sPointsNode)
    pins.connectItem(eItem, '%s.Item' % sPointsNode)
    return '%s.OutPoints' % sPointsNode


def movePointsByItem(sPoints, eItem):
    sFunctionName = 'kangaroo_movePointsByItem'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Points', 'FVector', True),
                                                    ('Item', 'FRigElementKey', False)],
                                            xOutputs=[('OutPoints', 'FVector', True)])

        controllers.setNewColumn()
        vOutPoints = hierarchy.newVariable('OutPoints', 'FVector', True, bLocal=True)
        sGetPointsVariableNode = nodes.createGetVariableNode(vOutPoints)
        nodes.createResetArrayNode(sGetPointsVariableNode)

        controllers.setNewColumn()
        sTransform = nodes.getTransformNode('Entry.Item')
        sTransformInitial = nodes.getTransformNode('Entry.Item', bInitial=True)
        sForEach = nodes.createForEachExecuteNode('Entry.Points')
        controllers.setNewColumn()
        sRelativePoint = nodes.createMakeRelativeNode(['%s.Element' % sForEach,None,None], sTransformInitial)
        sAbsolutePoint = '%s.Translation' % nodes.createMakeAbsoluteNode(sRelativePoint, sTransform)
        nodes.createArrayAddNode(sGetPointsVariableNode, sAbsolutePoint)
        controllers.goToParentExecute()

        controllers.setNewColumn()
        sGetPointsVariableNode = nodes.createGetVariableNode(vOutPoints)
        pins.connectToPinVector(sGetPointsVariableNode, 'Return.OutPoints')
        nodes.endCurrentFunction(bAddToExecute=False)


    sPointsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setVectorArray(sPoints, '%s.Points' % sPointsNode)
    pins.connectItem(eItem, '%s.Item' % sPointsNode)
    return '%s.OutPoints' % sPointsNode


def makePointsRelative(sPoints, eItem):
    sFunctionName = 'kangaroo_makePointsRelative'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Points', 'FVector', True),
                                                    ('Item', 'FRigElementKey', False)],
                                            xOutputs=[('OutPoints', 'FVector', True)])

        controllers.setNewColumn()
        vOutPoints = hierarchy.newVariable('OutPoints', 'FVector', True, bLocal=True)
        sGetPointsVariableNode = nodes.createGetVariableNode(vOutPoints)
        nodes.createResetArrayNode(sGetPointsVariableNode)

        controllers.setNewColumn()
        sTransform = nodes.getTransformNode('Entry.Item')
        sForEach = nodes.createForEachExecuteNode('Entry.Points')
        controllers.setNewColumn()
        sAbsolutePoint = '%s.Translation' % nodes.createMakeRelativeNode(['%s.Element' % sForEach,None,None], sTransform)
        nodes.createArrayAddNode(sGetPointsVariableNode, sAbsolutePoint)
        controllers.goToParentExecute()

        controllers.setNewColumn()
        sGetPointsVariableNode = nodes.createGetVariableNode(vOutPoints)
        pins.connectToPinVector(sGetPointsVariableNode, 'Return.OutPoints')
        nodes.endCurrentFunction(bAddToExecute=False)


    sPointsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setVectorArray(sPoints, '%s.Points' % sPointsNode)
    pins.connectItem(eItem, '%s.Item' % sPointsNode)
    return '%s.OutPoints' % sPointsNode



def lips(cCorners, ccLips, cCornerTangents, dJawAttaches, dFollowCornerZs, dFollowCornerPathIns, dFollowCornerPathOuts, dAimToNeighbors, dPercParamsStaticCurve, dDistancesToCorner, cBotTops, sMouthPivot,
         fVerticalTranslates, fHorizontalTranslates, fVerticalRotate, fHorizontalRotate, ffTwoStaticSlideCurvePoints, ffTwoStaticSlideCurvePointsUp, ffTwoCornerSlideCurves, flipCornerSlideParamsLeft, flipCornerSlideParamsRight):
    sFunctionName = 'kangaroo_Lips'
    eHeadBone = ELEM('jnt_m_headMain', 'Bone')
    eJawBone = ELEM('jnt_m_JawMain', 'Bone')
    eMouthPivot = ELEM('loc_m_mouthPivot', 'Null')
    eFrontPivotJaw = ELEM('jnt_m_mouthPivotFrontJaw', 'Bone')
    eFrontPivotHead = ELEM('jnt_m_mouthPivotFrontHead', 'Bone')

    for cC in ccLips[0] + ccLips[1]:
        # eSlider = cC.dOffsets['slider']
        cC.eJustAnim = hierarchy.createNull('grp_%s_%sJustAnim' % (cC.sSide, cC.sName), eParent=cC.ePasser, eMatch=cC.ePasser, bTransformInGlobal=False)
        cC.eInf = hierarchy.duplicateElement(cC.eOut, '%sInf' % cC.eOut.name)

    for c,cC in enumerate(cCorners):
        eSlider = cC.dOffsets['slider']
        cC.eJustAnims = []
        cC.eParentIs = []
        cC.eInfs = []
        cC.eOrig = hierarchy.createNull('grp_%s_%sOrig' % (cC.sSide, cC.sName), eParent=eSlider, eMatch=eSlider, bTransformInGlobal=False)
        cC.eTangentParent = hierarchy.duplicateElement(cC.eOut, sName='%sTangentParent' % cC.eOut.name)
        for p,sPart in enumerate(['bot','top']):
            cC.eJustAnims.append(hierarchy.createNull('grp_%s_%s%sJustAnim' % (cC.sSide, cC.sName, sPart.title()), eParent=eSlider, eMatch=eSlider, bTransformInGlobal=False))
            cC.eParentIs.append(hierarchy.createNull('parent_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, sPart.title()), eParent=cC.eOrig, eMatch=cCornerTangents[c + p*2].eControl, bTransformInGlobal=False))
            cC.eInfs.append(hierarchy.createNull('inf_%s_%sMouthInfluence%s' % (cC.sSide, cC.sName, sPart.title()), eParent=cC.eParentIs[-1], eMatch=cC.eParentIs[-1], bTransformInGlobal=False))
        controllers.hierarchy_controller.set_parent(cCornerTangents[c*1 + 0].ePasser, cC.eTangentParent, maintain_global_transform=True, setup_undo=False)
        controllers.hierarchy_controller.set_parent(cCornerTangents[c*1 + 2].ePasser, cC.eTangentParent, maintain_global_transform=True, setup_undo=False)


    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('CornerControls', 'FName', True),
                                                    ('TopLipControls', 'FName', True),
                                                    ('VerticalTranslates', 'FVector', False),
                                                    ('VerticalRotate', 'float', False),
                                                    ('HorizontalTranslates', 'FVector', False),
                                                    ('HorizontalRotate', 'float', False),
                                                    ], bSequencer=True)
        controllers.openCommentBox('Mouth Pivot')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eHeadBone, 1.0)], eMouthPivot, bMaintainOffset=True)
        sMouthAnim = '%s.Translation' % nodes.getTransformNode(ELEM('mouth_ctrl', 'Control'), bLocal=True)
        sMouthAbs = nodes.createMathAbs(sMouthAnim, iPinType=pins.PinType.vector)
        controllers.setNewColumn()
        sHorizResult = nodes.createBasicCalculateNode(['Entry.HorizontalTranslates', ['%s.X' % sMouthAbs, '%s.X' % sMouthAnim, '%s.X' % sMouthAbs]], iPinType=pins.PinType.vector)
        sVertResult = nodes.createBasicCalculateNode(['Entry.VerticalTranslates', ['%s.Z' % sMouthAnim, '%s.Z' % sMouthAbs, '%s.Z' % sMouthAbs]], iPinType=pins.PinType.vector)
        sResultSum = nodes.createBasicCalculateNode([sHorizResult, sVertResult], sOperation='Add', iPinType=pins.PinType.vector)
        sHorizRotateResult = nodes.createBasicCalculateNode(['Entry.HorizontalRotate', '%s.X' % sMouthAnim])
        sVertRotateResult = nodes.createBasicCalculateNode(['Entry.VerticalRotate', '%s.Z' % sMouthAnim])
        sEuler = nodes.createFromEulerNode([sHorizRotateResult, sVertRotateResult, 0])
        controllers.setNewColumn()
        nodes.createOffsetTransformExecuteNode(eMouthPivot, [sResultSum, sEuler, None])
        # pivot front head

        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eMouthPivot, 1.0)], eFrontPivotHead, bMaintainOffset=True)
        # pivot front jaw
        controllers.setNewColumn()
        sHeadByMouthPivot = nodes.createProjectTransformToNewParent(eHeadBone, eMouthPivot)
        sLocalJaw = nodes.getTransformNode(eJawBone, bLocal=True)
        sJawByPivot = nodes.createMakeAbsoluteNode(sLocalJaw, sHeadByMouthPivot)
        sFrontPivotOffsetToJaw = nodes.createMakeRelativeNode(nodes.getTransformNode(eFrontPivotJaw, bInitial=True), nodes.getTransformNode(eJawBone, bInitial=True))
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eFrontPivotJaw, nodes.createMakeAbsoluteNode(sFrontPivotOffsetToJaw, sJawByPivot))
        controllers.closeCommentBox('Mouth Pivot')


        controllers.setNewColumn()
        controllers.openCommentBox('Constrain Box Passers')
        nodes.createParentConstraintExecuteNode([(eFrontPivotJaw, 1.0)], cBotTops[0].ePasser, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eFrontPivotHead, 1.0)], cBotTops[1].ePasser, bMaintainOffset=True)
        controllers.closeCommentBox('Constrain Box Passers')

        controllers.setNewColumn()

        # Attach Lip Ctrl Passers
        eeJawSpaces = [(eFrontPivotJaw, eFrontPivotHead), (cBotTops[0].eControl, eFrontPivotHead), (eFrontPivotJaw, cBotTops[1].eControl)]
        sInfo = ['Corners', 'Bottom Lips', 'Top Lips']
        for cc,cCtrls in enumerate([cCorners, ccLips[0], ccLips[1]]):
            controllers.setNewColumn()
            controllers.openCommentBox('Attach Passers of %s' % sInfo[cc])
            for cC in cCtrls:
                hierarchy.createFloatControl('jawAttach', eParent=cC.eControl, fRange=[0, 1], fDefault=dJawAttaches[str(cC.eControl.name)])

            controllers.setNewColumn()
            sFirst = nodes.getTransformNode(eeJawSpaces[cc][0])
            sFirstInitial = nodes.getTransformNode(eeJawSpaces[cc][0], bInitial=True)
            sSecondOffsetted = nodes.createProjectTransformToNewParent(eeJawSpaces[cc][0], eeJawSpaces[cc][1])
            controllers.setNewColumn()

            sForEach = nodes.createForEachExecuteNode([str(cC.ePasser.name) for cC in cCtrls], bArrayIsStringList=True)
            # pins.resolveWildCardPin('%s.Array' % sForEach, 'TArray<FName>')
            # pins.setStringArray([str(cC.ePasser.name) for cC in cCtrls], '%s.Array' % sForEach)
            if controllers.BLOCK_FOREACH:
                ePasser = ELEM('%s.Element' % sForEach, 'Null')
                controllers.setNewColumn()
                sControl = nodes.createStringSelectNode([str(cC.eControl.name) for cC in cCtrls], '%s.Index' % sForEach)
                sJawAttach = nodes.createGetChannelNode2(sControl, 'jawAttach')
                controllers.setNewColumn()
                sInterpolated = nodes.createTransformInterpolateNode(sJawAttach, sSecondOffsetted, sFirst)
                controllers.setNewColumn()
                sPasserInitial = nodes.getTransformNode(ePasser, bInitial=True)
                sTransformOffset = nodes.createMakeRelativeNode(sPasserInitial, sFirstInitial)
                controllers.setNewColumn()
                sTransform = nodes.createMakeAbsoluteNode(sTransformOffset, sInterpolated)
                nodes.createSetTransformExecuteNode(ePasser, sTransform)
                controllers.goToParentExecute()

            controllers.closeCommentBox('Attach Passers of %s' % sInfo[cc])
        controllers.setNewColumn()



        controllers.openCommentBox('Just Anims Lip Ctrls')
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode([str(cC.eJustAnim.name) for cC in ccLips[0]+ccLips[1]], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eJustAnim = ELEM('%s.Element' % sForEach, 'Null')
            eControl = ELEM(nodes.createStringSelectNode([str(cC.eControl.name) for cC in ccLips[0]+ccLips[1]], '%s.Index' % sForEach), 'Control')
            ePoseParent = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['twist'].name) for cC in ccLips[0]+ccLips[1]], '%s.Index' % sForEach), 'Null')
            controllers.setNewColumn()
            sAnimPose = nodes.createProjectTransformToNewParent(eControl, ePoseParent, hierarchy.eOrigin, False, False, True)
            sOffset = nodes.createProjectTransformToNewParent(nodes.createGetParentNode(eJustAnim), eFrontPivotHead, None, True, True, False)
            controllers.setNewColumn()
            sGlobalAnimPose = nodes.createMakeAbsoluteNode(sAnimPose, sOffset)
            nodes.createSetTranslationExecuteNode(eJustAnim, '%s.Translation' % sGlobalAnimPose)
            controllers.goToParentExecute()
        controllers.closeCommentBox('Just Anims Lip Ctrls')

        controllers.setNewColumn()
        for p,sPart in enumerate(['bot','top']):
            controllers.setNewColumn()
            controllers.openCommentBox('Just Anims Corner Ctrls %s' % sPart.title())
            sForEach = nodes.createForEachExecuteNode([str(cC.eJustAnims[p].name) for cC in cCorners], bArrayIsStringList=True)
            if controllers.BLOCK_FOREACH:
                controllers.setNewColumn()
                eControl = ELEM(nodes.createStringSelectNode([str(cC.eControl.name) for cC in cCorners], '%s.Index' % sForEach), 'Control')
                eSlider = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['slider'].name) for cC in cCorners], '%s.Index' % sForEach), 'Null')
                eBoxControl = ELEM(cBotTops[p].eControl.name, 'Control')

                controllers.setNewColumn()
                sWorldCornerFromBox = nodes.createProjectTransformToNewParent(eControl, eBoxControl)
                sTranslationPlusPoses = '%s.Translation' % nodes.createProjectTransformToNewParent(eControl, eSlider, hierarchy.eOrigin, False, False)
                sTranslateXZ = ['%s.X' % sTranslationPlusPoses, 0.0, '%s.Z' % sTranslationPlusPoses]

                controllers.setNewColumn()
                sSlider = nodes.getTransformNode(eSlider)
                sCornerFromBoxInCornerSpace = '%s.Translation' % nodes.createMakeRelativeNode(sWorldCornerFromBox, sSlider)
                # sOffset = nodes.getTransformNode(eSlider, bLocal=True, bInitial=True)
                sOffset = nodes.createProjectTransformToNewParent(eSlider, eFrontPivotHead, hierarchy.eOrigin, True, True)
                # fOffset = nodes.createMultMatrixNode([sSliderJumped, '%s.worldInverseMatrix' % sMouthPivotFront], bJustValues=True)

                controllers.setNewColumn()
                sMaxZ = nodes.createConditionNodes('%s.Z' % sTranslationPlusPoses, '<' if p==0 else '>', 0, '%s.Z' % sTranslationPlusPoses, 0, iPinType=pins.PinType.double)
                if p == 0:
                    sClampedZ = nodes.createClampNode('%s.Z' % sCornerFromBoxInCornerSpace, sMaxZ, 0)
                else:
                    sClampedZ = nodes.createClampNode('%s.Z' % sCornerFromBoxInCornerSpace, 0, sMaxZ)
                sClamped = ['%s.X' % sCornerFromBoxInCornerSpace, '%s.Y' % sCornerFromBoxInCornerSpace, sClampedZ]
                sDiff = nodes.createBasicCalculateNode([sTranslateXZ, sClamped], sOperation='Subtract', iPinType=pins.PinType.vector)
                controllers.setNewColumn()
                sJustAnimMarix = nodes.createMakeAbsoluteNode([sDiff, None, None], sOffset)
                sMovedByFrontPivot = nodes.createMakeAbsoluteNode(sJustAnimMarix, nodes.getTransformNode(eFrontPivotHead))
                controllers.setNewColumn()
                nodes.createSetTransformExecuteNode(ELEM('%s.Element' % sForEach, 'Null'), sMovedByFrontPivot)
                controllers.goToParentExecute()
            controllers.closeCommentBox('Just Anims Corner Ctrls %s' % sPart.title())


        # MOVE BY CORNERS
        nodes.newSequencerPlug()
        controllers.setNewColumn()

        cSlideCtrls = [cC for cC in ccLips[0] if cC.sSide != 'm'] + [cC for cC in ccLips[1] if cC.sSide != 'm']
        eCornerJustAnims = []
        cCornerPerSlideCtrl = []
        iSides = []
        for cC in cSlideCtrls:
            iBotTop = 1 if 'TOP' in str(cC.eControl.name).upper() else 0
            iSide = ['l','r'].index(cC.sSide)
            eCornerJustAnims.append(cCorners[iSide].eJustAnims[iBotTop])
            cCornerPerSlideCtrl.append(cCorners[iSide])
            iSides.append(iSide)

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode([str(cC.eControl.name) for cC in cSlideCtrls], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            sSideIndex = nodes.createSelectNode2(iSides, '%s.Index' % sForEach, iPinType=pins.PinType.integer)
            controllers.openCommentBox('Move Y')
            controllers.setNewColumn()
            eJustAnim = ELEM(nodes.createStringSelectNode([str(eJustAnim.name) for eJustAnim in eCornerJustAnims], '%s.Index' % sForEach), 'Null')
            sParentMatrix = nodes.createProjectTransformToNewParent(eJustAnim, eFrontPivotHead)
            controllers.setNewColumn()
            sLocalMovingMatrix = nodes.createMakeRelativeNode(nodes.getTransformNode(eJustAnim), sParentMatrix)
            sCornerJustAnimTranslation = '%s.Translation' % sLocalMovingMatrix
            ePasser = ELEM(nodes.createStringSelectNode([str(cC.ePasser.name) for cC in cSlideCtrls], '%s.Index' % sForEach), 'Null')

            controllers.setNewColumn()
            sScaleFactorForUpDown = nodes.createBasicCalculateNode([1.0, '%s.Scale3D.X' % nodes.getTransformNode(ePasser)], sOperation='Divide')
            sUpDown = nodes.createBasicCalculateNode(['%s.Z' % sCornerJustAnimTranslation, sScaleFactorForUpDown])
            sFollowZ = nodes.createStringSelectNode([dFollowCornerZs[str(cC.eControl.name)] for cC in cSlideCtrls], '%s.Index' % sForEach)
            controllers.setNewColumn()
            eMove = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['movetocorner'].name) for cC in cSlideCtrls], '%s.Index' % sForEach), 'Null')
            sTz = nodes.createBasicCalculateNode([sFollowZ, sUpDown])
            controllers.setNewColumn()
            nodes.createSetTranslationExecuteNode(eMove, [0,0,sTz], bLocal=True)
            controllers.closeCommentBox('Move Y')

            controllers.openCommentBox('Move by Path - get speed')
            controllers.setNewColumn()
            controllers.setNewColumn()
            eCornerPasser = ELEM(nodes.createStringSelectNode([str(cC.ePasser.name) for cC in cCorners], sSideIndex), 'Null')
            controllers.setNewColumn()
            sScaleFactorForPath = nodes.createBasicCalculateNode(['%s.Scale3D.X' % nodes.getTransformNode(eCornerPasser), '%s.Scale3D.X' % nodes.getTransformNode(ePasser)], sOperation='Divide')
            controllers.setNewColumn()
            sCornerJustAnimBackForward = nodes.createBasicCalculateNode(['%s.X' % sCornerJustAnimTranslation, sScaleFactorForPath])

            controllers.setNewColumn()
            sFollowPathOut = nodes.createStringSelectNode([dFollowCornerPathOuts[str(cC.eControl.name)] for cC in cSlideCtrls], '%s.Index' % sForEach)
            sFollowPathIn = nodes.createStringSelectNode([dFollowCornerPathIns[str(cC.eControl.name)] for cC in cSlideCtrls], '%s.Index' % sForEach)
            sFollowPath = nodes.createConditionNodes(sCornerJustAnimBackForward, '>', 0.0, sFollowPathOut, sFollowPathIn, iPinType=pins.PinType.double)

            sDistancesToCorner = nodes.createStringSelectNode([dDistancesToCorner[str(cC.eControl.name)] for cC in cSlideCtrls], '%s.Index' % sForEach)

            controllers.setNewColumn()
            sDistanceToCornerBySpeed = nodes.createBasicCalculateNode([sDistancesToCorner, sFollowPath], sOperation='Divide')
            controllers.closeCommentBox('Move by Path - get speed')


            controllers.setNewColumn()
            controllers.openCommentBox('Move by Path - Static Splines')
            controllers.setNewColumn()
            sStaticCurvesInitial = []
            sStaticCurvesMoved = []
            sStaticUpCurvesInitial = []
            sStaticUpCurvesMoved = []
            for s, sSide in enumerate(['l', 'r']):
                controllers.setNewColumn()
                _pointsInitial = ffTwoStaticSlideCurvePoints[s]
                _sPointsMoved = movePointsByItem(_pointsInitial, eFrontPivotHead)
                sStaticCurvesInitial.append(nodes.createSplineFromPositionsNode(_pointsInitial, bSpline=True, iSamplesPerSegment=128))
                sStaticCurvesMoved.append(nodes.createSplineFromPositionsNode(_sPointsMoved, bSpline=True, iSamplesPerSegment=128))

                _pointsInitial = ffTwoStaticSlideCurvePointsUp[s]
                _sPointsMoved = movePointsByItem(_pointsInitial, eFrontPivotHead)
                sStaticUpCurvesInitial.append(nodes.createSplineFromPositionsNode(_pointsInitial, bSpline=True, iSamplesPerSegment=128))
                sStaticUpCurvesMoved.append(nodes.createSplineFromPositionsNode(_sPointsMoved, bSpline=True, iSamplesPerSegment=128))

            controllers.setNewColumn()
            sCurveMoved = nodes.createSelectNode2(sStaticCurvesMoved, sSideIndex, iPinType=pins.PinType.spline)
            sCurveInitial = nodes.createSelectNode2(sStaticCurvesInitial, sSideIndex, iPinType=pins.PinType.spline)
            sUpCurveMoved = nodes.createSelectNode2(sStaticUpCurvesMoved, sSideIndex, iPinType=pins.PinType.spline)
            sUpCurveInitial = nodes.createSelectNode2(sStaticUpCurvesInitial, sSideIndex, iPinType=pins.PinType.spline)

            # if False:
            #     nodes.createDrawSplineNode(sCurveInitial, fThickness=0.4, fColor=[1,0,0])
            #     nodes.createDrawSplineNode(sCurveMoved, fThickness=0.2, fColor=[0,0,1])
            controllers.setNewColumn()
            controllers.closeCommentBox('Move by Path - Static Splines')


            controllers.openCommentBox('Move by Path - Calculate Param')
            controllers.setNewColumn()
            sParamInitial = nodes.createStringSelectNode([dPercParamsStaticCurve[str(cC.eControl.name)] for cC in cSlideCtrls], '%s.Index' % sForEach)
            controllers.setNewColumn()

            sPositive = nodes.createRemapNode(sCornerJustAnimBackForward, 0, sDistanceToCornerBySpeed, sParamInitial, 0.0)
            sNegative = nodes.createRemapNode(sCornerJustAnimBackForward, 0, nodes.createNegateNode(sDistanceToCornerBySpeed), sParamInitial, 1.0)
            sParam = nodes.createConditionNodes(sCornerJustAnimBackForward, '>', 0, sPositive, sNegative, iPinType=pins.PinType.double)

            controllers.setNewColumn()
            sPos = nodes.createGetPositionOnSpline(sCurveMoved, sParam)
            sTangent = nodes.createGetTangentOnSpline(sCurveMoved, sParam)
            sUpPos = nodes.createGetPositionOnSpline(sUpCurveMoved, sParam)

            controllers.setNewColumn()
            sPosInitial = nodes.createGetPositionOnSpline(sCurveInitial, sParamInitial)
            sTangentInitial = nodes.createGetTangentOnSpline(sCurveInitial, sParamInitial)
            sUpPosInitial = nodes.createGetPositionOnSpline(sUpCurveInitial, sParamInitial)
            controllers.closeCommentBox('Move by Path - Calculate Param')

            controllers.setNewColumn()
            controllers.openCommentBox('Move by Path - Aim Constraints')
            sAimConstraint = nodes.createAimNode([sPos, None, None], sTangent, bUpIsDirection=False, bTargetIsDirection=True)
            pins.connectToPinVector(sUpPos, '%s.Secondary.Target' % sAimConstraint.split('.')[0])
            sAimConstraintInitial = nodes.createAimNode([sPosInitial, None, None], sTangentInitial, bUpIsDirection=False, bTargetIsDirection=True)
            pins.connectToPinVector(sUpPosInitial, '%s.Secondary.Target' % sAimConstraintInitial.split('.')[0])
            controllers.closeCommentBox('Move by Path - Aim Constraints')

            # end tangent
            controllers.openCommentBox('Move by Path - End Tangent')
            controllers.setNewColumn()
            sEndTangent = nodes.createGetTangentOnSpline(sCurveMoved, 0.0)
            controllers.setNewColumn()
            sEndTangent = nodes.createNormalizeVectorNode(sEndTangent)
            sEndTangent = nodes.createBasicCalculateNode([sEndTangent, [100, 100, 100]], iPinType=pins.PinType.vector)
            controllers.setNewColumn()
            sEndTangentExtra = nodes.createRemapNode(sCornerJustAnimBackForward, sDistanceToCornerBySpeed, 100, [0, 0, 0],
                                                     nodes.createBasicCalculateNode([sEndTangent, [sFollowPath, sFollowPath, sFollowPath]], iPinType=pins.PinType.vector),
                                                     bOutIsVector=True)
            controllers.setNewColumn()
            sAimConstraintWithAddedTangent = [nodes.createBasicCalculateNode([sPos, sEndTangentExtra], sOperation='Add', iPinType=pins.PinType.vector),
                                          '%s.Rotation' % sAimConstraint, '%s.Scale3D' % sAimConstraint]
            controllers.closeCommentBox('Move by Path - End Tangent')


            controllers.setNewColumn()
            controllers.openCommentBox('Move by Path - Set Offset Group')
            ePivot = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['pivot'].name) for cC in cSlideCtrls], '%s.Index' % sForEach), 'Null')
            sSliderMoved = nodes.createProjectTransformToNewParent(ePivot, eFrontPivotHead)
            sPutToZero = nodes.createMakeRelativeNode(sAimConstraintWithAddedTangent, sSliderMoved)

            eOffsetGrp = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['movetocornerpath'].name) for cC in cSlideCtrls], '%s.Index' % sForEach), 'Null')
            controllers.setNewColumn()
            sOffset = nodes.createMakeRelativeNode(nodes.getTransformNode(eOffsetGrp, bInitial=True), sAimConstraintInitial)
            sFinalTransform = nodes.createMakeAbsoluteNode(sOffset, sPutToZero)
            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eOffsetGrp, sFinalTransform, bLocal=True)
            controllers.closeCommentBox('Move by Path - Set Offset Group')
            controllers.setNewColumn()
            controllers.goToParentExecute()


        nodes.newSequencerPlug()
        controllers.openCommentBox('Corner Slides')
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode([str(cC.eControl.name) for cC in cCorners], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eCorner = ELEM('%s.Element' % sForEach, 'Control')
            ePoses = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['poses'].name) for cC in cCorners], '%s.Index' % sForEach), 'Null')
            sCtrlTransform = nodes.getTransformNode(eCorner, bLocal=True)
            sCtrlTransformNoY = [['%s.Translation.X' % sCtrlTransform, 0.0, '%s.Translation.Z' % sCtrlTransform], '%s.Rotation' % sCtrlTransform, '%s.Scale3D' % sCtrlTransform]
            sPoseTransform = nodes.getTransformNode(ePoses, bLocal=True)
            sCornerAnim = nodes.createMakeAbsoluteNode(sCtrlTransformNoY, sPoseTransform)

            controllers.setNewColumn()
            sSlideCurvesInitial = []
            sSlideCurvesMoved = []
            for s, sSide in enumerate(['l', 'r']):
                controllers.setNewColumn()
                _pointsInitial = ffTwoCornerSlideCurves[s]
                _sPointsMoved = movePointsByItem(_pointsInitial, eFrontPivotHead)
                sSlideCurvesInitial.append(nodes.createSplineFromPositionsNode(_pointsInitial, bSpline=True, iSamplesPerSegment=64))
                sSlideCurvesMoved.append(nodes.createSplineFromPositionsNode(_sPointsMoved, bSpline=True, iSamplesPerSegment=64))

            controllers.setNewColumn()
            sCurveMoved = nodes.createSelectNode2(sSlideCurvesMoved, '%s.Index' % sForEach, iPinType=pins.PinType.spline)
            sCurveInitial = nodes.createSelectNode2(sSlideCurvesInitial, '%s.Index' % sForEach, iPinType=pins.PinType.spline)

            controllers.setNewColumn()
            sOut = nodes.createRemapNode('%s.Translation.X' % sCornerAnim, 0.0, 3.0, flipCornerSlideParamsLeft[0], flipCornerSlideParamsLeft[1], bClamp=False)
            sIn = nodes.createRemapNode('%s.Translation.X' % sCornerAnim, 0.0, -1.0, flipCornerSlideParamsLeft[0], flipCornerSlideParamsLeft[2], bClamp=False)
            sInOrOut = nodes.createConditionNodes('%s.Translation.X' % sCornerAnim, '>', 0.0, sOut, sIn, iPinType=pins.PinType.double)

            controllers.setNewColumn()
            sPointOnCurve = nodes.createGetPositionOnSpline(sCurveMoved, sInOrOut)
            sTangentOnCurve = nodes.createGetTangentOnSpline(sCurveMoved, sInOrOut)
            sPointOnCurveInitial = nodes.createGetPositionOnSpline(sCurveInitial, flipCornerSlideParamsLeft[0])
            sTangentOnCurveInitial = nodes.createGetTangentOnSpline(sCurveInitial, flipCornerSlideParamsLeft[0])

            controllers.setNewColumn()
            sWorldUpVector = nodes.createRotateVectorNode([0.0, 0.0, 1.0], '%s.Rotation' % nodes.getTransformNode(eCorner))
            sWorldUpVectorInitial = nodes.createRotateVectorNode([0.0, 0.0, 1.0], '%s.Rotation' % nodes.getTransformNode(eCorner, bInitial=True))
            controllers.setNewColumn()
            sAimTransform = nodes.createAimNode([sPointOnCurve, None, None], sTangentOnCurve, bUpIsDirection=False, bTargetIsDirection=True)
            pins.connectToPinVector(sWorldUpVector, '%s.Secondary.Target' % sAimTransform.split('.')[0])
            controllers.setNewColumn()
            sAimTransformInitial = nodes.createAimNode([sPointOnCurveInitial, None, None], sTangentOnCurveInitial, bUpIsDirection=False, bTargetIsDirection=True)
            pins.connectToPinVector(sWorldUpVectorInitial, '%s.Secondary.Target' % sAimTransformInitial.split('.')[0])

            eOrig = ELEM(nodes.createStringSelectNode([str(cC.eOrig.name) for cC in cCorners], '%s.Index' % sForEach), 'Null')
            eFirstOffset = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['slider'].name) for cC in cCorners], '%s.Index' % sForEach), 'Null')

            controllers.setNewColumn()
            sUpDownRotated = nodes.createRotateVectorNode([0.0, 0.0, '%s.Translation.Z' % sCornerAnim], '%s.Rotation' % sCtrlTransform)
            sAimTransformPlusUpDown = [nodes.createBasicCalculateNode(['%s.Translation' % sAimTransform, sUpDownRotated], sOperation='Add', iPinType=pins.PinType.vector),
                                       '%s.Rotation' % sAimTransform,
                                       '%s.Scale3D' % sAimTransform]
            controllers.setNewColumn()
            sWorldCtrlWithoutJaw = nodes.createProjectTransformToNewParent(eFirstOffset, eFrontPivotHead)
            sOffset = nodes.createMakeRelativeNode(nodes.getTransformNode(eOrig, bInitial=True), sAimTransformInitial)
            sRotationPlusY = [[0.0, '%s.Translation.Y' % sCtrlTransform, 0.0], '%s.Rotation' % sCtrlTransform, None]
            sAimTransformWithOffset = nodes.createMakeAbsoluteNode(sOffset, sAimTransformPlusUpDown)
            controllers.setNewColumn()
            sWorld = nodes.createMakeAbsoluteNode(sRotationPlusY, sAimTransformWithOffset)
            sLocal = nodes.createMakeRelativeNode(sWorld, sWorldCtrlWithoutJaw)
            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eOrig, sLocal, bLocal=True)

            #
            controllers.goToParentExecute()
        controllers.closeCommentBox('Corner Slides')


        nodes.newSequencerPlug()
        controllers.openCommentBox('Corner Influences (Aim)')
        sForEach = nodes.createForEachExecuteNode([str(cTangent.ePasser.name) for cTangent in cCornerTangents], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eAimTarget = ELEM(nodes.createStringSelectNode([str(cC.eControl.name) for cC in [ccLips[0][0], ccLips[0][-1], ccLips[1][0], ccLips[1][-1]]], '%s.Index' % sForEach), 'Control')
            eParentI = ELEM(nodes.createStringSelectNode([str(eParentI.name) for eParentI in [cCorners[0].eParentIs[0], cCorners[1].eParentIs[0], cCorners[0].eParentIs[1], cCorners[1].eParentIs[1]]], '%s.Index' % sForEach), 'Null')
            # eCorner = ELEM(nodes.createStringSelectNode([str(cC.eControl.name) for cC in [cCorners[0], cCorners[1], cCorners[0], cCorners[1]]], '%s.Index' % sForEach), 'Control')
            # eCornerParent = nodes.createGetParentNode(eCorner)
            eCornerOrig = ELEM(nodes.createStringSelectNode([str(cC.eOrig.name) for cC in [cCorners[0], cCorners[1], cCorners[0], cCorners[1]]], '%s.Index' % sForEach), 'Null')
            eCornerSlider = ELEM(nodes.createStringSelectNode([str(cC.dOffsets['slider'].name) for cC in [cCorners[0], cCorners[1], cCorners[0], cCorners[1]]], '%s.Index' % sForEach), 'Null')

            controllers.setNewColumn()
            sNoRotCtrlLocalTransform = nodes.createMakeAbsoluteNode(['%s.Translation' % nodes.getTransformNode(eCornerOrig, bLocal=True), None, None], nodes.getTransformNode(eCornerSlider))
            sAimTargetLocalInNoRotate = nodes.createMakeRelativeNode(nodes.getTransformNode(eAimTarget), sNoRotCtrlLocalTransform)
            controllers.setNewColumn()
            sAimTransform = nodes.createAimNode([[0,0,0], None, None], '%s.Translation' % sAimTargetLocalInNoRotate)
            pins.connectToPinVector([0,1,0], '%s.Secondary.Target' % sAimTransform.split('.')[0])
            controllers.setNewColumn()
            nodes.createSetTranslationExecuteNode(eParentI, '%s.Translation' % sAimTransform, bLocal=True)
            nodes.createSetRotationExecuteNode(eParentI, '%s.Rotation' % sAimTransform, bLocal=True)

            controllers.setNewColumn()
            sAimedTransform = nodes.getTransformNode(eParentI, bLocal=True)
            eTangentPasser = ELEM('%s.Element' % sForEach, 'Null')
            nodes.createSetTranslationExecuteNode(eTangentPasser, '%s.Translation' % sAimedTransform, bLocal=True)
            nodes.createSetRotationExecuteNode(eTangentPasser, '%s.Rotation' % sAimedTransform, bLocal=True)

            eTangentCtrl = ELEM(nodes.createStringSelectNode([str(cTangent.eControl.name) for cTangent in cCornerTangents], '%s.Index' % sForEach), 'Control')
            eTangentSlider = ELEM(nodes.createStringSelectNode([str(cTangent.dOffsets['slider'].name) for cTangent in cCornerTangents], '%s.Index' % sForEach), 'Null')
            sTangentAnimMatrix = nodes.createProjectTransformToNewParent(eTangentCtrl, eTangentSlider, hierarchy.eOrigin, False, False, True)
            eInf = ELEM(nodes.createStringSelectNode([str(eInf.name) for eInf in [cCorners[0].eInfs[0], cCorners[1].eInfs[0], cCorners[0].eInfs[1], cCorners[1].eInfs[1]]], '%s.Index' % sForEach), 'Null')
            nodes.createSetTransformExecuteNode(eInf, sTangentAnimMatrix, bLocal=True)

            controllers.goToParentExecute()
        controllers.closeCommentBox('Corner Influences (Aim)')

        controllers.openCommentBox('Lips Influences (Aim)')
        nodes.newSequencerPlug()
        cLips = []
        eAimTargetsA = []
        eAimTargetsB = []
        for p,sPart in enumerate(['bot','top']):
            cLips.extend(ccLips[p])
            eAimTargetsA.append(cCorners[0].eJustAnims[p])
            eAimTargetsA.extend(cC.eJustAnim for cC in ccLips[p][:-1])
            eAimTargetsB.extend(cC.eJustAnim for cC in ccLips[p][1:])
            eAimTargetsB.append(cCorners[1].eJustAnims[p])

        sForEach = nodes.createForEachExecuteNode([str(cC.eJustAnim.name) for cC in cLips], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            eJustAnim = ELEM('%s.Element' % sForEach, 'Null')
            controllers.setNewColumn()
            eAimTargetA = ELEM(nodes.createStringSelectNode([str(eTarget.name) for eTarget in eAimTargetsA], '%s.Index' % sForEach), 'Null')
            eAimTargetB = ELEM(nodes.createStringSelectNode([str(eTarget.name) for eTarget in eAimTargetsB], '%s.Index' % sForEach), 'Null')
            eInf = ELEM(nodes.createStringSelectNode([str(cC.eInf.name) for cC in cLips], '%s.Index' % sForEach), 'Null')
            controllers.setNewColumn()
            sJustAnim = nodes.getTransformNode(eJustAnim)
            sJustAnimInitial = nodes.getTransformNode(eJustAnim, bInitial=True)

            controllers.setNewColumn()
            sAimTargetA = nodes.createMakeRelativeNode(nodes.getTransformNode(eAimTargetA), sJustAnim)
            sAimTargetB = nodes.createMakeRelativeNode(nodes.getTransformNode(eAimTargetB), sJustAnim)
            sAimTarget = nodes.createBasicCalculateNode(['%s.Translation' % sAimTargetA, '%s.Translation' % sAimTargetB], sOperation='Subtract', iPinType=pins.PinType.vector)
            controllers.setNewColumn()
            sAimTargetInitialA = nodes.createMakeRelativeNode(nodes.getTransformNode(eAimTargetA, bInitial=True), sJustAnimInitial)
            sAimTargetInitialB = nodes.createMakeRelativeNode(nodes.getTransformNode(eAimTargetB, bInitial=True), sJustAnimInitial)
            sAimTargetInitial = nodes.createBasicCalculateNode(['%s.Translation' % sAimTargetInitialA, '%s.Translation' % sAimTargetInitialB], sOperation='Subtract', iPinType=pins.PinType.vector)


            controllers.setNewColumn()
            sAimTransform = nodes.createAimNode([[0.0, 0.0, 0.0], None, None], sAimTarget, bUpIsDirection=True, bTargetIsDirection=True)
            pins.connectToPinVector([0,0,1], '%s.Secondary.Target' % sAimTransform.split('.')[0])
            sAimTransformInitial = nodes.createAimNode([[0.0, 0.0, 0.0], None, None], sAimTargetInitial, bUpIsDirection=True, bTargetIsDirection=True)
            pins.connectToPinVector([0,0,1], '%s.Secondary.Target' % sAimTransformInitial.split('.')[0])

            controllers.setNewColumn()
            sOffset = nodes.createMakeRelativeNode(None, sAimTransformInitial)
            sOfsetted = nodes.createMakeAbsoluteNode(sOffset, sAimTransform)

            controllers.setNewColumn()
            sAimToNeighborsStrength = nodes.createStringSelectNode([dAimToNeighbors[str(cC.eControl.name)] for cC in cLips], '%s.Index' % sForEach)
            controllers.setNewColumn()
            sRotateInterpolate = nodes.createRotationInterpolateNode(sAimToNeighborsStrength, None, '%s.Rotation' % sOfsetted)
            controllers.setNewColumn()
            nodes.createSetRotationExecuteNode(eInf, sRotateInterpolate, bLocal=True)
            controllers.goToParentExecute()
        controllers.closeCommentBox('Lips Influences (Aim)')

        nodes.newSequencerPlug()
        nodes.endCurrentFunction(bAddToExecute=False)


    sLipsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.connectToPinVector(fVerticalTranslates, '%s.VerticalTranslates' % sLipsNode)
    pins.connectToPin1D(fVerticalRotate, '%s.VerticalRotate' % sLipsNode)
    pins.connectToPinVector(fHorizontalTranslates, '%s.HorizontalTranslates' % sLipsNode)
    pins.connectToPin1D(fHorizontalRotate, '%s.HorizontalRotate' % sLipsNode)
    # pins.connectItem(eItem, '%s.Item' % sLipsNode)


    # eBotInfluences = [cCornerTangents[0].eOut] + [cC.eInf for cC in ccLips[0]] + [cCornerTangents[1].eOut]
    # eTopInfluences = [cCornerTangents[2].eOut] + [cC.eInf for cC in ccLips[1]] + [cCornerTangents[3].eOut]
    eBotInfluences = [cCorners[0].eInfs[0]] + [cC.eInf for cC in ccLips[0]] + [cCorners[1].eInfs[0]]
    eTopInfluences = [cCorners[0].eInfs[1]] + [cC.eInf for cC in ccLips[1]] + [cCorners[1].eInfs[1]]

    return sLipsNode, eBotInfluences, eTopInfluences



def lipsSplines(cCorners, ccLips, ffBotCurvePoints, ffTopCurvePoints, dJawAttaches, fLipsEndFollowMouthT, fLipsEndFollowMouthR,
                sLipsSmallJointsBot, sLipsSmallJointsTop, sLipsBigJointsBot, sLipsBigJointsTop,
                eBotInfluences, eTopInfluences,
                iBotInfluencesA, ffBotInfluenceWeightsA, iBotInfluencesB, ffBotInfluenceWeightsB, iBotInfluencesC, ffBotInfluenceWeightsC,
                iTopInfluencesA, ffTopInfluenceWeightsA, iTopInfluencesB, ffTopInfluenceWeightsB, iTopInfluencesC, ffTopInfluenceWeightsC,
                fLipsParamsBot, fLipsParamsTop, xMouthCtrlWeightingsBot, xMouthCtrlWeightingsTop):

    eHead = ELEM('jnt_m_headMain', 'Bone')
    eFrontPivotHead = ELEM('jnt_m_mouthPivotFrontHead', 'Bone')
    eFrontPivotJaw = ELEM('jnt_m_mouthPivotFrontJaw', 'Bone')

    sFunctionName = 'kangaroo_lipsSplines'
    ccRows = [[cCorners[0]] + ccLips[0] + [cCorners[1]],
              [cCorners[0]] + ccLips[1] + [cCorners[1]]]
    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('BotCurvePoints', 'FVector', True),
                                                    ('TopCurvePoints', 'FVector', True),
                                                    ('BotCurvePointsBeforePivot', 'FVector', True),
                                                    ('TopCurvePointsBeforePivot', 'FVector', True),
                                                    ('BotParams', 'float', True),
                                                    ('TopParams', 'float', True),
                                                    ('Controls', 'FName', True),
                                                    ],
                                            xOutputs=[('OutPoints', 'FVector', True)])
        controllers.setNewColumn()
        sSplineBotInitial = nodes.createSplineFromPositionsNode('Entry.BotCurvePoints', bSpline=True, iSamplesPerSegment=128)
        sSplineTopInitial = nodes.createSplineFromPositionsNode('Entry.TopCurvePoints', bSpline=True, iSamplesPerSegment=128)
        controllers.setNewColumn()

        sBotPointsDeformed = skinClusterPoints('Entry.BotCurvePoints', eBotInfluences, iBotInfluencesA, ffBotInfluenceWeightsA, iBotInfluencesB, ffBotInfluenceWeightsB, iBotInfluencesC, ffBotInfluenceWeightsC)
        sTopPointsDeformed = skinClusterPoints('Entry.TopCurvePoints', eTopInfluences, iTopInfluencesA, ffTopInfluenceWeightsA, iTopInfluencesB, ffTopInfluenceWeightsB, iTopInfluencesC, ffTopInfluenceWeightsC)

        controllers.setNewColumn()
        sSplineBot = nodes.createSplineFromPositionsNode(sBotPointsDeformed, bSpline=True, iSamplesPerSegment=128)
        sSplineTop = nodes.createSplineFromPositionsNode(sTopPointsDeformed, bSpline=True, iSamplesPerSegment=128)

        controllers.setNewColumn()
        lipsSplinesOnePart('Entry.BotCurvePoints', sLipsSmallJointsBot, sLipsBigJointsBot, 'Entry.BotParams', sSplineBot, sSplineBotInitial,
                           [str(cC.eControl.name) for cC in ccRows[0]], xMouthCtrlWeightingsBot, [dJawAttaches[str(cC.eControl.name)] for cC in ccRows[0]], bLipsEndJoints=True)
        controllers.setNewColumn()
        lipsSplinesOnePart('Entry.TopCurvePoints', sLipsSmallJointsTop, sLipsBigJointsTop, 'Entry.TopParams', sSplineTop, sSplineTopInitial,
                           [str(cC.eControl.name) for cC in ccRows[1]], xMouthCtrlWeightingsTop, [dJawAttaches[str(cC.eControl.name)] for cC in ccRows[1]], bLipsEndJoints=False)


        controllers.openCommentBox('Lips End Joints')
        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode(['jnt_l_lipsEnd', 'jnt_r_lipsEnd'], bArrayIsStringList=True)
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            eLipsEnd = ELEM('%s.Element' % sForEach, 'Bone')
            sParam = nodes.createSelectNode2([0.0, 1.0], '%s.Index' % sForEach)
            sPosition = nodes.createGetPositionOnSpline(sSplineBot, sParam)
            sPositionInitial = nodes.createGetPositionOnSpline(sSplineBotInitial, sParam)
            sTangent = nodes.createGetPositionOnSpline(sSplineBot, sParam)
            sTangentInitial = nodes.createGetPositionOnSpline(sSplineBotInitial, sParam)
            controllers.setNewColumn()
            sAimTransform = nodes.createAimNode([sPosition, None, None], sTangent, bTargetIsDirection=True, bUpIsDirection=True)
            sFrontPivotHeadTransform = nodes.getTransformNode(eFrontPivotHead)
            sUpVector = nodes.createRotateVectorNode([0,1,0], sFrontPivotHeadTransform)
            pins.connectItem(sUpVector, '%s.Secondary.Target' % sAimTransform.split('.')[0])
            controllers.setNewColumn()

            sAimTransformInitial = nodes.createAimNode([sPositionInitial, None, None], sTangentInitial, bTargetIsDirection=True, bUpIsDirection=True)
            sFrontPivotHeadTransformInitial = nodes.getTransformNode(eFrontPivotHead, bInitial=True)
            sUpVectorInitial = nodes.createRotateVectorNode([0,1,0], sFrontPivotHeadTransformInitial)
            pins.connectItem(sUpVectorInitial, '%s.Secondary.Target' % sAimTransformInitial.split('.')[0])

            controllers.setNewColumn()
            sStaticMouthPivotFront = nodes.createProjectTransformToNewParent(eFrontPivotHead, eHead)
            sAimTransformLocal = nodes.createMakeRelativeNode(sAimTransform, sFrontPivotHeadTransform)
            sLipsEndNoMouth = nodes.createMakeAbsoluteNode(sAimTransformLocal, sStaticMouthPivotFront)

            controllers.setNewColumn()
            sTranslationBlended = nodes.createVectorInterpolateNode(fLipsEndFollowMouthT, '%s.Translation' % sLipsEndNoMouth, '%s.Translation' % sAimTransform)
            sRotationBlended = nodes.createRotationInterpolateNode(fLipsEndFollowMouthR, '%s.Rotation' % sLipsEndNoMouth, '%s.Rotation' % sAimTransform)
            controllers.setNewColumn()
            sBoneInitial = nodes.getTransformNode(eLipsEnd, bInitial=True)
            sOffset = nodes.createMakeRelativeNode(sBoneInitial, sAimTransformInitial)
            sFinalLipsEnd = nodes.createMakeAbsoluteNode(sOffset, [sTranslationBlended, sRotationBlended, '%s.Scale3D' % sAimTransform])
            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eLipsEnd, sFinalLipsEnd)

            controllers.goToParentExecute()


        controllers.closeCommentBox('Lips End Joints')




        # sForEach = nodes.createForEachExecuteNode(['jnt_l_lipsEnd', 'jnt_r_lipsEnd'], bArrayIsStringList=True)
        # if controllers.BLOCK_FOREACH:
        #     eEndBone = ELEM('%s.Element' % sForEach, 'Bone')
        #
        #
        #     controllers.goToParentExecute()

        nodes.endCurrentFunction(bAddToExecute=False)


    sPointsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setVectorArray(ffBotCurvePoints, '%s.BotCurvePoints' % sPointsNode)
    pins.setVectorArray(ffTopCurvePoints, '%s.TopCurvePoints' % sPointsNode)
    # pins.setVectorArray(ffBotCurvePointsBeforePivot, '%s.BotCurvePointsBeforePivot' % sPointsNode)
    # pins.setVectorArray(ffTopCurvePointsBeforePivot, '%s.TopCurvePointsBeforePivot' % sPointsNode)
    # pins.setStringArray(sLipsSmallJointsBot, '%s.BotSmallJoints' % sPointsNode)
    # pins.setStringArray(sLipsSmallJointsTop, '%s.TopSmallJoints' % sPointsNode)
    pins.setValueArray(fLipsParamsBot, '%s.BotParams' % sPointsNode)
    pins.setValueArray(fLipsParamsTop, '%s.TopParams' % sPointsNode)
    return '%s.OutPoints' % sPointsNode



def lipsSplinesOnePart(ffCurvePoints, sSmallJoints, sBigJoints, fLipsParams, sSpline, sSplineInitial, sControls, xMouthCtrlWeightings, fJawAttaches, bLipsEndJoints):
    sFunctionName = 'kangaroo_lipsSplinesOnePart'
    eHead = ELEM('jnt_m_headMain', 'Bone')
    eFrontPivotHead = ELEM('jnt_m_mouthPivotFrontHead', 'Bone')
    eFrontPivotJaw = ELEM('jnt_m_mouthPivotFrontJaw', 'Bone')

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('CurvePoints', 'FVector', True),
                                                    ('SmallJoints', 'FName', True),
                                                    ('BigJoints', 'FName', True),
                                                    ('Params', 'float', True),
                                                    ('Spline', 'FControlRigSpline', False),
                                                    ('SplineInitial', 'FControlRigSpline', False),
                                                    ('Controls', 'FName', True),
                                                    ('CtrlWeightingsIndex0', 'int32', True),
                                                    ('CtrlWeightingsIndex1', 'int32', True),
                                                    ('CtrlWeightingsWeight', 'float', True),
                                                    ('JawAttaches', 'float', True),
                                                    ('bLipsEndJoints', 'bool', True),
                                                    ],
                                            xOutputs=[('OutPoints', 'FVector', True)])
        controllers.setNewColumn()


        controllers.setNewColumn()
        nodes.createDrawSplineNode('Entry.SplineInitial', fThickness=0.025, fDetail=128, fColor=[0,1,0])
        nodes.createDrawSplineNode('Entry.Spline', fThickness=0.025, fDetail=128, fColor=[1,0,0])

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.Params')
        if controllers.BLOCK_FOREACH:
            controllers.setNewColumn()
            controllers.openCommentBox('Point on Curve')
            sParam =  '%s.Element' % sForEach
            eSmallBone = ELEM(nodes.createArrayAtNode('Entry.SmallJoints', '%s.Index' % sForEach), 'Bone')
            sBoneInitial = nodes.getTransformNode(eSmallBone, bInitial=True)

            controllers.setNewColumn()
            sPointOnCurve = nodes.createGetPositionOnSpline('Entry.Spline', sParam)
            sPointOnCurveInitial = nodes.createGetPositionOnSpline('Entry.SplineInitial', sParam)
            controllers.closeCommentBox('Point on Curve')

            # sOffset = nodes.createBasicCalculateNode(['%s.Translation' % sBoneInitial, sPointOnCurveInitial], sOperation='Subtract', iPinType=pins.PinType.vector)
            # sAbsolute = nodes.createBasicCalculateNode([sOffset, sPointOnCurve], sOperation='Add', iPinType=pins.PinType.vector)
            # nodes.createSetTranslationExecuteNode(eSmallBone, sAbsolute)

            controllers.openCommentBox('Twist')
            controllers.setNewColumn()
            sControlIndex0 = nodes.createArrayAtNode('Entry.CtrlWeightingsIndex0', '%s.Index' % sForEach)
            sControlIndex1 = nodes.createArrayAtNode('Entry.CtrlWeightingsIndex1', '%s.Index' % sForEach)
            controllers.setNewColumn()
            sControl0 = ELEM(nodes.createArrayAtNode('Entry.Controls', sControlIndex0), 'Control')
            sControl1 = ELEM(nodes.createArrayAtNode('Entry.Controls', sControlIndex1), 'Control')
            controllers.setNewColumn()

            sTransform0 = nodes.getTransformNode(sControl0)
            sTransform1 = nodes.getTransformNode(sControl1)
            sTransformInitial0 = nodes.getTransformNode(sControl0, bInitial=True)
            sTransformInitial1 = nodes.getTransformNode(sControl1, bInitial=True)

            controllers.setNewColumn()
            sUpRotated0 = '%s.Translation' % nodes.createMakeAbsoluteNode([[0,1,0], None, None], [None, '%s.Rotation' % sTransform0, '%s.Scale3D' % sTransform0])
            sUpRotated1 = '%s.Translation' %  nodes.createMakeAbsoluteNode([[0,1,0], None, None], [None, '%s.Rotation' % sTransform1, '%s.Scale3D' % sTransform1])
            sUpRotatedInitial0 = '%s.Translation' % nodes.createMakeAbsoluteNode([[0,1,0], None, None], [None, '%s.Rotation' % sTransformInitial0, '%s.Scale3D' % sTransformInitial0])
            sUpRotatedInitial1 = '%s.Translation' % nodes.createMakeAbsoluteNode([[0,1,0], None, None], [None, '%s.Rotation' % sTransformInitial1, '%s.Scale3D' % sTransformInitial1])
            controllers.setNewColumn()
            sWeight = nodes.createArrayAtNode('Entry.CtrlWeightingsWeight', '%s.Index' % sForEach)
            sUpRotated = nodes.createVectorInterpolateNode(sWeight, sUpRotated0, sUpRotated1)
            sUpRotatedInitial = nodes.createVectorInterpolateNode(sWeight, sUpRotatedInitial0, sUpRotatedInitial1)


            controllers.setNewColumn()
            sTangent = nodes.createGetTangentOnSpline('Entry.Spline', sParam)
            sTangentInitial = nodes.createGetTangentOnSpline('Entry.SplineInitial', sParam)
            controllers.setNewColumn()
            sAimNode = nodes.createAimNode([sPointOnCurve, None, None], sUpRotated, bTargetIsDirection=True, bUpIsDirection=True)
            pins.connectToPinVector(sTangent, '%s.Secondary.Target' % sAimNode.split('.')[0])
            sAimNodeInitial = nodes.createAimNode([sPointOnCurveInitial, None, None], sUpRotatedInitial, bTargetIsDirection=True, bUpIsDirection=True)
            pins.connectToPinVector(sTangentInitial, '%s.Secondary.Target' % sAimNodeInitial.split('.')[0])

            controllers.setNewColumn()
            controllers.closeCommentBox('Twist')

            controllers.openCommentBox('Setting Small Joint')

            controllers.setNewColumn()
            sOffset = nodes.createMakeRelativeNode(sBoneInitial, sAimNodeInitial)
            sFinalBoneTransform = nodes.createMakeAbsoluteNode(sOffset, sAimNode)

            nodes.createSetTransformExecuteNode(eSmallBone, sFinalBoneTransform)
            controllers.closeCommentBox('Setting Small Joint')



            controllers.openCommentBox('Big Joints')
            controllers.setNewColumn()
            sJawAttach0 = nodes.createSelectNode2('Entry.JawAttaches', sControlIndex0)
            sJawAttach1 = nodes.createSelectNode2('Entry.JawAttaches', sControlIndex1)
            controllers.setNewColumn()
            sJawAttach = nodes.createFloatInterpolateNode(sWeight, sJawAttach0, sJawAttach1)
            eBigBone = ELEM(nodes.createArrayAtNode('Entry.BigJoints', '%s.Index' % sForEach), 'Bone')
            # sBigBoneTransform = nodes.getTransformNode(eBigBone)

            controllers.setNewColumn()
            sHeadProjected = nodes.createProjectTransformToNewParent(eBigBone, eFrontPivotHead)
            sJawProjected = nodes.createProjectTransformToNewParent(eBigBone, eFrontPivotJaw)
            sJawInterpolated = nodes.createRotationInterpolateNode(sJawAttach, '%s.Rotation' % sHeadProjected, '%s.Rotation' % sJawProjected)

            controllers.setNewColumn()
            sBigBoneTransformInitial = nodes.getTransformNode(eBigBone, bInitial=True)
            sOffset = nodes.createMakeRelativeNode(sBigBoneTransformInitial, sAimNodeInitial)
            sAimedBigBoneTransform = nodes.createMakeAbsoluteNode(sOffset, sAimNode)
            controllers.setNewColumn()
            nodes.createSetTransformExecuteNode(eBigBone, ['%s.Translation' % sAimedBigBoneTransform, sJawInterpolated, '%s.Scale3D' % sAimedBigBoneTransform])
            controllers.closeCommentBox('Big Joints')
            controllers.goToParentExecute()

        controllers.setNewColumn()

        nodes.endCurrentFunction(bAddToExecute=False)


    sPointsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setVectorArray(ffCurvePoints, '%s.CurvePoints' % sPointsNode)
    pins.setStringArray(sSmallJoints, '%s.SmallJoints' % sPointsNode)
    pins.setStringArray(sBigJoints, '%s.BigJoints' % sPointsNode)
    pins.setValueArray(fLipsParams, '%s.Params' % sPointsNode)
    pins.setValueArray(fJawAttaches, '%s.JawAttaches' % sPointsNode)
    pins.connectToPin1D(sSpline, '%s.Spline' % sPointsNode)
    pins.connectToPin1D(sSplineInitial, '%s.SplineInitial' % sPointsNode)
    pins.setStringArray(sControls, '%s.Controls' % sPointsNode)
    pins.setValueArray([xC[0] for xC in xMouthCtrlWeightings], '%s.CtrlWeightingsIndex0' % sPointsNode, bInt=True)
    pins.setValueArray([xC[1] for xC in xMouthCtrlWeightings], '%s.CtrlWeightingsIndex1' % sPointsNode, bInt=True)
    pins.setValueArray([xC[2] for xC in xMouthCtrlWeightings], '%s.CtrlWeightingsWeight' % sPointsNode)
    pins.connectToPin1D(bLipsEndJoints, '%s.bLipsEndJoints' % sPointsNode)
    return '%s.OutPoints' % sPointsNode



def skinClusterPoints(ffPoints, eInfluences, iInfluences0, fInfluenceWeights0, iInfluences1, fInfluenceWeights1, iInfluences2, fInfluenceWeights2):
    sFunctionName = 'kangaroo_skinClusterPoints'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Points', 'FVector', True),
                                                    ('Influences', 'FRigElementKey', True),
                                                    ('Influences0', 'int32', True),
                                                    ('Influences1', 'int32', True),
                                                    ('Influences2', 'int32', True),
                                                    ('InfluencesWeights0', 'float', True),
                                                    ('InfluencesWeights1', 'float', True),
                                                    ('InfluencesWeights2', 'float', True)],
                                            xOutputs=[('OutPoints', 'FVector', True)])


        vPointsSkinned = hierarchy.newVariable('PointsSkinned', 'FVector', bArray=True, bLocal=True)
        sPointsSkinnedVar = nodes.createGetVariableNode(vPointsSkinned)
        nodes.createResetArrayNode(sPointsSkinnedVar)

        controllers.setNewColumn()
        sForEach = nodes.createForEachExecuteNode('Entry.Points')
        if controllers.BLOCK_FOREACH:  # each point
            controllers.setNewColumn()
            sMultipliedPoints = []
            for i in range(3):
                controllers.openCommentBox('Influence %d' % i)
                controllers.setNewColumn()
                sInfluenceIndexI = nodes.createArrayAtNode('Entry.Influences%d' % i, '%s.Index' % sForEach)
                sInfluenceI = nodes.createArrayAtNode('Entry.Influences', sInfluenceIndexI)
                controllers.setNewColumn()
                sTransformInitialI = nodes.getTransformNode(sInfluenceI, bInitial=True)
                sTransformI = nodes.getTransformNode(sInfluenceI)
                sRelativeI = nodes.createMakeRelativeNode(['%s.Element' % sForEach, None, None], sTransformInitialI)
                sAbsoluteI = '%s.Translation' % nodes.createMakeAbsoluteNode(sRelativeI, sTransformI)
                controllers.setNewColumn()

                controllers.setNewColumn()
                sWeightI = nodes.createArrayAtNode('Entry.InfluencesWeights%d' % i, '%s.Index' % sForEach)
                sMultiplied = nodes.createBasicCalculateNode([sAbsoluteI, [sWeightI, sWeightI, sWeightI]], iPinType=pins.PinType.vector)
                sMultipliedPoints.append(sMultiplied)
                controllers.closeCommentBox('Influence %d' % i)

            controllers.setNewColumn()
            sSum = nodes.createBasicCalculateNode(sMultipliedPoints, sOperation='Add', iPinType=pins.PinType.vector)
            sPointsSkinnedVar = nodes.createGetVariableNode(vPointsSkinned)
            nodes.createArrayAddNode(sPointsSkinnedVar, sSum)
            pins.connectToPin1D(sPointsSkinnedVar, 'Return.OutPoints')
            controllers.goToParentExecute()


        nodes.endCurrentFunction(bAddToExecute=False)



def tweakerControls(sCtrls, sCurveNamePrefixes):
    sFunctionName = 'kangaroo_tweakerCtrls'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Controls', 'FName', True),
                                                    ('CurveNamePrefixes', 'FName', True)])
        sForeach = nodes.createForEachExecuteNode('Entry.Controls')
        if controllers.BLOCK_FOREACH:
            eControl = ELEM('%s.Element' % sForeach, 'Control')
            sTransform = nodes.getTransformNode(eControl, bLocal=True)

            sCurveNamePrefix = nodes.createArrayAtNode('Entry.CurveNamePrefixes', '%s.Index' % sForeach)

            for sMorphTargetAxis, sCtrlAxis in zip(['X','Y','Z'], ['X','Z','Y']):
                controllers.setNewColumn()
                sCurveName = nodes.createNameConcatNode(sCurveNamePrefix, sMorphTargetAxis)
                nodes.setCurveValueExecuteNode(sCurveName, '%s.Translation.%s' % (sTransform,sCtrlAxis))

            controllers.goToParentExecute()

        nodes.endCurrentFunction(bAddToExecute=False)

    sTweakerNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setStringArray(sCtrls, '%s.Controls' % sTweakerNode)
    pins.setStringArray(sCurveNamePrefixes, '%s.CurveNamePrefixes' % sTweakerNode)
    return sTweakerNode



def parallelAttach(eItem, xBlendShapePairs, xConstraintParents):
    sFunctionName = 'kangaroo_parallelAttach'

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('Item', 'FName', False),
                                                    ('ConstraintParents', 'FConstraintParent', True),
                                                    ('MorphTargetCurves', 'FName', True),
                                                    ('MorphTargetDeltas', 'FVector', True)],
                                            xOutputs=[])

        controllers.openCommentBox('Get Start Position')
        eEntry_Item = ELEM('Entry.Item', 'Null')
        sHasMetaData = nodes.createHasMetaData(eEntry_Item, 'InitialPosition', iType=pins.PinType.vector)
        controllers.setNewColumn()
        nodes.createBranchExecuteNode(sHasMetaData)
        if controllers.BLOCK_BRANCH_TRUE:
            controllers.goToParentExecute()
        if controllers.BLOCK_BRANCH_FALSE:
            sTransformInitial = nodes.getTransformNode(eEntry_Item, bInitial=True)
            nodes.createSetMetaDataExecuteNode(eEntry_Item, 'InitialPosition', '%s.Translation' % sTransformInitial, iType=pins.PinType.vector)
            controllers.goToParentExecute()
        controllers.setNewColumn()
        vPosition = hierarchy.newVariable('position', 'FVector', False, True)
        sInitialPosition = nodes.createGetMetaData(eEntry_Item, 'InitialPosition', iType=pins.PinType.vector)
        nodes.createSetVariableExecuteNode(vPosition, sInitialPosition)
        controllers.closeCommentBox('Get Start Position')


        controllers.openCommentBox('MorphTarget connections')
        controllers.setNewColumn()
        sForeach = nodes.createForEachExecuteNode('Entry.MorphTargetCurves')
        if controllers.BLOCK_FOREACH: # for each morph target
            controllers.setNewColumn()
            sCurveValue = nodes.createGetCurveValue('%s.Element' % sForeach)
            controllers.setNewColumn()
            sEntry_MorphTargetDeltas = nodes.createGetEntryVariable('MorphTargetDeltas')
            sDelta = nodes.createArrayAtNode(sEntry_MorphTargetDeltas, '%s.Index' % sForeach)
            sMultipl = nodes.createBasicCalculateNode([sDelta, [sCurveValue, sCurveValue, sCurveValue]], iPinType=pins.PinType.vector)
            controllers.setNewColumn()
            sGetPosition = nodes.createGetVariableNode(vPosition)
            sNewPosition = nodes.createBasicCalculateNode([sGetPosition, sMultipl], sOperation='Add', iPinType=pins.PinType.vector)
            nodes.createSetVariableExecuteNode(vPosition, sNewPosition)
            controllers.goToParentExecute()

        controllers.setNewColumn()
        sPosition = nodes.createGetVariableNode(vPosition)
        controllers.setNewColumn()
        nodes.createSetTranslationExecuteNode(eEntry_Item, sPosition, bInitial=True)
        controllers.closeCommentBox('MorphTarget connections')

        controllers.openCommentBox('SkinCluster')
        controllers.setNewColumn()
        eEntry_Item = ELEM(nodes.createGetEntryVariable('Item'), 'Null')
        sEntry_ConstraintParents = nodes.createGetEntryVariable('ConstraintParents')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode(sEntry_ConstraintParents, eEntry_Item, bMaintainOffset=True)
        controllers.closeCommentBox('SkinCluster')

        nodes.endCurrentFunction(bAddToExecute=False)


    sAttachNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[300.0,400.0])
    pins.setString(str(eItem.name), '%s.Item' % sAttachNode)
    pins.connectToPinConstraintParentArray([(ELEM(sJ, 'Bone'), fV) for sJ,fV in xConstraintParents], '%s.ConstraintParents' % sAttachNode)
    pins.setStringArray([xP[0] for xP in xBlendShapePairs], '%s.MorphTargetCurves' % sAttachNode)
    pins.setVectorArray([xP[1] for xP in xBlendShapePairs], '%s.MorphTargetDeltas' % sAttachNode)
    return sAttachNode



def lidSplines(cMainCtrl, cBotCtrls, cTopCtrls, cCornerCtrls, cTangentInCtrls, cTangentOutCtrls, ffBotMaxPoints, ffTopMaxPoints, ffBotPoints, ffTopPoints, sBotBones, sTopBones,
               xCtrlWeightsBot, xCtrlWeightsTop, cBlink, fDefaultBlinkLine, fBlinkOverShoot, sTransformBone, fLivePole):
    sFunctionName = 'kangaroo_splineLids'
    hierarchy.createFloatControl('BlinkLine', eParent=cBlink.eControl, fRange=[0, 1], fDefault=fDefaultBlinkLine)
    uFunction = nodes.getFunction(sFunctionName)

    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('MainControl', 'FName', False),
                                                    ('MainPasser', 'FName', False),
                                                    ('BotControlPasserA', 'FName', False),
                                                    ('BotControlPasserB', 'FName', False),
                                                    ('BotControlPasserC', 'FName', False),
                                                    ('TopControlPasserA', 'FName', False),
                                                    ('TopControlPasserB', 'FName', False),
                                                    ('TopControlPasserC', 'FName', False),
                                                    ('TransformBone', 'FName', False),
                                                    ('Bones', 'FName', True),
                                                    ('BotMaxPoints', 'FVector', True),
                                                    ('TopMaxPoints', 'FVector', True),
                                                    ('BotPoints', 'FVector', True),
                                                    ('TopPoints', 'FVector', True),
                                                    ('BotBones', 'FName', True),
                                                    ('TopBones', 'FName', True),
                                                    ('CtrlWeightsCtrlsBot', 'FName', True),
                                                    ('CtrlWeightsValuesBot', 'float', True),
                                                    ('CtrlWeightsCtrlsTop', 'FName', True),
                                                    ('CtrlWeightsValuesTop', 'float', True),
                                                    ('LivePole', 'float', False),
                                                    ('BlinkOverShoot', 'float', False),
                                                    ('BlinkControl', 'FName', False),
                                                    ],
                                            xOutputs=[('BlendCurveBot', 'float', False),
                                                      ('BlendCurveTop', 'float', False)],
                                                    bMutable=True, bSequencer=True)

        sTransformBoneTransform = nodes.getTransformNode(ELEM('Entry.TransformBone', 'Bone'))

        controllers.openCommentBox('Get Blink Values')
        controllers.setNewColumn()
        sBlinkLine = nodes.createGetChannelNode2('Entry.BlinkControl', 'BlinkLine')
        sBlinkValue = '%s.Translation.Z' % nodes.getTransformNode(ELEM('Entry.BlinkControl', 'Control'), bLocal=True)
        sNegativeBlink = nodes.createBasicCalculateNode([sBlinkValue, -1])
        controllers.setNewColumn()

        sBlendCurves = []
        sBlendCurves.append(nodes.createBasicCalculateNode([sNegativeBlink, sBlinkLine, 'Entry.BlinkOverShoot']))
        controllers.setNewColumn()
        sRevBlinkLine = nodes.createBasicCalculateNode([1.0, sBlinkLine], sOperation='Subtract')
        controllers.setNewColumn()
        sBlendCurves.append(nodes.createBasicCalculateNode([sNegativeBlink, sRevBlinkLine, 'Entry.BlinkOverShoot']))
        controllers.closeCommentBox('Get Blink Values')

        ssAttachPassers = [['Entry.BotControlPasserA', 'Entry.BotControlPasserB', 'Entry.BotControlPasserC'], ['Entry.TopControlPasserA', 'Entry.TopControlPasserB', 'Entry.TopControlPasserC']]
        sParts = ['top', 'bot']
        sBlendCurves[0], sBlendCurves[1] = sBlendCurves[1], sBlendCurves[0]
        ssAttachPassers[0], ssAttachPassers[1] = ssAttachPassers[1], ssAttachPassers[0]

        vvWorldPoints = [hierarchy.newVariable('TopPointsVar', 'FVector', True, bLocal=True),
                         hierarchy.newVariable('BotPointsVar', 'FVector', True, bLocal=True)]
        for p,sPart in enumerate(sParts):
            nodes.newSequencerPlug()
            sOtherPart = sParts[1-p]

            controllers.setNewColumn()
            controllers.openCommentBox('%s Reset Variables' % sPart.title())
            vMaxPoints = hierarchy.newVariable('%sMaxPointsVar' % sPart, 'FVector', True, bLocal=True)
            vInitialPointsOnSpline = hierarchy.newVariable('%sInitialPointsOnSpline' % sPart, 'FVector', True, bLocal=True)
            nodes.createResetArrayNode(nodes.createGetVariableNode(vMaxPoints))
            nodes.createResetArrayNode(nodes.createGetVariableNode(vvWorldPoints[p]))
            nodes.createResetArrayNode(nodes.createGetVariableNode(vInitialPointsOnSpline))
            controllers.closeCommentBox('%s Reset Variables' % sPart.title())

            pins.connectToPin1D(sBlendCurves[p], 'return.BlendCurve%s' % sPart.title())
            controllers.openCommentBox('%s Max Points Blend for Blink' % sPart.title())
            controllers.setNewColumn()

            controllers.setNewColumn()
            sForEach = nodes.createForEachExecuteNode('Entry.%sMaxPoints' % sPart.title())
            if controllers.BLOCK_FOREACH: # for each max point
                controllers.setNewColumn()
                sOtherPoint = nodes.createArrayAtNode('Entry.%sMaxPoints' % sOtherPart.title(), '%s.Index' % sForEach)
                sInterp = nodes.createVectorInterpolateNode(sBlendCurves[p], '%s.Element' % sForEach, sOtherPoint)
                sGetMaxPointsVar = nodes.createGetVariableNode(vMaxPoints)
                nodes.createArrayAddNode(sGetMaxPointsVar, sInterp)
                controllers.goToParentExecute()
            controllers.closeCommentBox('%s Max Points Blend for Blink' % sPart.title())


            # Project to Points and Push Out
            controllers.setNewColumn()
            controllers.openCommentBox('%s Project to Points and Push Out' % sPart.title())
            sMaxPoints = nodes.createGetVariableNode(vMaxPoints)
            sSplineInitial = nodes.createSplineFromPositionsNode('Entry.%sMaxPoints' % sPart.title(), bSpline=True)
            sSpline = nodes.createSplineFromPositionsNode(sMaxPoints, bSpline=True)
            controllers.setNewColumn()
            sForEach = nodes.createForEachExecuteNode('Entry.%sPoints' % sPart.title())
            if controllers.BLOCK_FOREACH: # for each point
                controllers.setNewColumn()
                sInitialU = nodes.createGetParamFromPositionOnSpline(sSplineInitial, '%s.Element' % sForEach)
                sInitialLength = nodes.createGetLengthVector('%s.Element' % sForEach)
                controllers.setNewColumn()
                sProjectedPoint = nodes.createGetPositionOnSpline(sSpline, sInitialU)
                sSpheredLocal = nodes.createSetLengthVector(sProjectedPoint, sInitialLength)
                sWorldPoints = nodes.createGetVariableNode(vvWorldPoints[p])
                nodes.createArrayAddNode(sWorldPoints, '%s.Translation' % nodes.createMakeAbsoluteNode([sSpheredLocal,None,None], sTransformBoneTransform))

                controllers.setNewColumn()
                sProjectedPointInitial = nodes.createGetPositionOnSpline(sSplineInitial, sInitialU)
                sSpheredLocalInitial = nodes.createSetLengthVector(sProjectedPointInitial, sInitialLength)
                sInitialPointsOnSplineVar = nodes.createGetVariableNode(vInitialPointsOnSpline)
                nodes.createArrayAddNode(sInitialPointsOnSplineVar, sSpheredLocalInitial)
                controllers.setNewColumn()
                controllers.goToParentExecute()
            controllers.closeCommentBox('%s Project to Points and Push Out' % sPart.title())

            # drawing splines
            controllers.openCommentBox('Creating Splines')
            controllers.setNewColumn()
            sWorldPoints = nodes.createGetVariableNode(vvWorldPoints[p])
            sSpline = nodes.createSplineFromPositionsNode(sWorldPoints, bSpline=True)
            sWorldPointsInitial = makePointsAbsolute('Entry.%sPoints' % sPart.title(), ELEM('Entry.TransformBone', 'Bone'))
            sSplineInitial = nodes.createSplineFromPositionsNode(sWorldPointsInitial, bSpline=True)

            if False:
                nodes.createDrawSplineNode(sSpline, fThickness=0.2)
                nodes.createDrawSplineNode(sSplineInitial, fThickness=0.4, fColor=[0,0,1])
            controllers.closeCommentBox('Creating Splines')


            # controls follow
            controllers.openCommentBox('Placing Ctrls on Spline')
            controllers.setNewColumn()
            sForEach = nodes.createForEachExecuteNode(None)
            if controllers.BLOCK_FOREACH: # for each control passer
                controllers.setNewColumn()
                pins.resolveWildCardPin('%s.Array' % sForEach, 'TArray<FName>')
                pins.setStringArray(ssAttachPassers[p], '%s.Array' % sForEach)

                ePasserItem = ELEM('%s.Element' % sForEach, 'Null')
                sPasserInitial = nodes.getTransformNode(ePasserItem, bInitial=True)
                controllers.setNewColumn()
                sCenterPosition = '%s.Translation' % nodes.getTransformNode(ELEM('Entry.TransformBone', 'Bone'))
                sInitialU = nodes.createGetParamFromPositionOnSpline(sSplineInitial, '%s.Translation' % sPasserInitial)
                sPointOnSpline = nodes.createGetPositionOnSpline(sSpline, sInitialU)
                sTangentOnSpline = nodes.createGetTangentOnSpline(sSpline, sInitialU)
                controllers.setNewColumn()
                sAimTransform = nodes.createAimNode([sPointOnSpline,None,None], sCenterPosition, [0,-1,0], [1,0,0], bUpIsDirection=True)
                pins.connectToPinVector(sTangentOnSpline, '%s.Secondary.Target' % sAimTransform.split('.')[0])
                controllers.setNewColumn()
                nodes.createSetTranslationExecuteNode(ePasserItem, '%s.Translation' % sAimTransform)
                nodes.createSetRotationExecuteNode(ePasserItem, '%s.Rotation' % sAimTransform)
                controllers.goToParentExecute()
            controllers.closeCommentBox('Placing Ctrls on Spline')



            # Bones Position and Aim
            controllers.openCommentBox('%s Bones position and aim' % sPart.title())
            controllers.setNewColumn()
            sWorldPoints = nodes.createGetVariableNode(vvWorldPoints[p])
            sPoints = makePointsRelative(sWorldPoints, ELEM('Entry.TransformBone', 'Bone'))
            sForEach = nodes.createForEachExecuteNode('Entry.%sBones' % sPart.title())
            if controllers.BLOCK_FOREACH: # for each bone
                controllers.setNewColumn()
                controllers.openCommentBox('First get UpVector')
                if sPart == 'bot': # since the upvector of the first item needs to be the first bone of the TOP spline, we'll have to create this Branch setup with local variables
                    vUpVector = hierarchy.newVariable('UpVector', 'FVector', bArray=False, bLocal=True)
                    vUpVectorInitial = hierarchy.newVariable('UpVectorInitial', 'FVector', bArray=False, bLocal=True)
                    sIsFirst = nodes.createConditionNodes('%s.Index' % sForEach, '==', 0, iTermsPinType=pins.PinType.integer)
                    nodes.createBranchExecuteNode(sIsFirst)
                    if controllers.BLOCK_BRANCH_TRUE: # first bone, take the first point of top
                        controllers.setNewColumn()
                        sTopWorldPoints = nodes.createGetVariableNode(vvWorldPoints[0])
                        sTopWorldPoint = nodes.createArrayAtNode(sTopWorldPoints, 0)
                        sWorldPointTransform = nodes.createMakeRelativeNode([sTopWorldPoint,None,None], sTransformBoneTransform)
                        nodes.createSetVariableExecuteNode(vUpVector, '%s.Translation' % sWorldPointTransform)
                        nodes.createSetVariableExecuteNode(vUpVectorInitial, nodes.createArrayAtNode('Entry.TopPoints', 0))
                        controllers.goToParentExecute()
                    if controllers.BLOCK_BRANCH_FALSE: # bones after first
                        controllers.setNewColumn()
                        sSecondaryTargetIndex = nodes.createBasicCalculateNode(['%s.Index' % sForEach, -1], sOperation='Add', iPinType=pins.PinType.integer)
                        nodes.createSetVariableExecuteNode(vUpVector, nodes.createArrayAtNode(sPoints, sSecondaryTargetIndex))
                        nodes.createSetVariableExecuteNode(vUpVectorInitial, nodes.createArrayAtNode('Entry.BotPoints', sSecondaryTargetIndex))
                        controllers.goToParentExecute()
                    sSecondaryTarget = nodes.createGetVariableNode(vUpVector)
                    sSecondaryTargetInitial = nodes.createGetVariableNode(vUpVectorInitial)
                else: # top is much easier
                    controllers.setNewColumn()
                    sIndexMinusOne = nodes.createBasicCalculateNode(['%s.Index' % sForEach, -1], sOperation='Add', iPinType=pins.PinType.integer)
                    sSecondaryTargetIndex = nodes.createConditionNodes('%s.Index' % sForEach, '==', 0, 1, sIndexMinusOne, iTermsPinType=pins.PinType.integer, iPinType=pins.PinType.integer)
                    controllers.setNewColumn()
                    sSecondaryTarget = nodes.createArrayAtNode(sPoints, sSecondaryTargetIndex)
                    sSecondaryTargetInitial = nodes.createArrayAtNode('Entry.TopPoints', sSecondaryTargetIndex)
                controllers.closeCommentBox('First get UpVector')

                controllers.setNewColumn()
                sSecondaryTargetDirectionCurrent = nodes.createBasicCalculateNode([sSecondaryTarget, nodes.createArrayAtNode(sPoints, '%s.Index' % sForEach)], iPinType=pins.PinType.vector, sOperation='Subtract')
                sSecondaryTargetDirectionInitial = nodes.createBasicCalculateNode([sSecondaryTargetInitial, nodes.createArrayAtNode('Entry.%sPoints' % sPart.title(), '%s.Index' % sForEach)], iPinType=pins.PinType.vector, sOperation='Subtract')
                sSecondaryTargetDirection = nodes.createVectorInterpolateNode('Entry.LivePole', sSecondaryTargetDirectionInitial, sSecondaryTargetDirectionCurrent)
                controllers.setNewColumn()
                sAimTransform = nodes.createAimNode([nodes.createArrayAtNode(sPoints, '%s.Index' % sForEach), None, None], [0,0,0], fAimVector=[0,0,-1], fUpVector=[1,0,0], bUpIsDirection=True)
                pins.connectToPinVector(sSecondaryTargetDirection, '%s.Secondary.Target' % sAimTransform.split('.')[0])
                controllers.setNewColumn()
                nodes.createSetTransformExecuteNode(ELEM('%s.Element' % sForEach, 'Bone'), sAimTransform, bLocal=True)
                controllers.goToParentExecute()
            controllers.closeCommentBox('%s Bones position and aim' % sPart.title())

            controllers.openCommentBox('%s Bones Ctrls Move' % sPart.title())
            controllers.setNewColumn()
            sForEach = nodes.createForEachExecuteNode('Entry.%sBones' % sPart.title())
            if controllers.BLOCK_FOREACH: # for each bone
                eBone = ELEM('%s.Element' % sForEach, 'Bone')
                sIndex0 = nodes.createBasicCalculateNode(['%s.Index' % sForEach, 2], iPinType=pins.PinType.integer)
                sIndex1 = nodes.createBasicCalculateNode([sIndex0, 1], sOperation='Add', iPinType=pins.PinType.integer)
                sBoneTransform = nodes.getTransformNode(eBone)
                controllers.setNewColumn()
                sCtrl0 = ELEM(nodes.createArrayAtNode('Entry.CtrlWeightsCtrls%s' % sPart.title(), sIndex0), 'Control')
                sCtrlTransform0 = nodes.getTransformNode(sCtrl0)
                sPasser0 = nodes.createGetParentNode(sCtrl0)
                sPasserTransform0 = nodes.getTransformNode(sPasser0)
                sRelative0 = nodes.createMakeRelativeNode(sBoneTransform, sPasserTransform0)
                sAbsolute0 = nodes.createMakeAbsoluteNode(sRelative0, sCtrlTransform0)
                controllers.setNewColumn()

                controllers.setNewColumn()
                sCtrl1 = ELEM(nodes.createArrayAtNode('Entry.CtrlWeightsCtrls%s' % sPart.title(), sIndex1), 'Control')
                sCtrlTransform1 = nodes.getTransformNode(sCtrl1)
                sPasser1 = nodes.createGetParentNode(sCtrl1)
                sPasserTransform1 = nodes.getTransformNode(sPasser1)
                sRelative1 = nodes.createMakeRelativeNode(sBoneTransform, sPasserTransform1)
                sAbsolute1 = nodes.createMakeAbsoluteNode(sRelative1, sCtrlTransform1)

                controllers.setNewColumn()
                sWeight1 = nodes.createArrayAtNode('Entry.CtrlWeightsValues%s' % sPart.title(), sIndex1)
                sInterp = nodes.createVectorInterpolateNode(sWeight1, '%s.Translation' % sAbsolute0, '%s.Translation' % sAbsolute1)

                controllers.setNewColumn()
                sInterpRelative = nodes.createMakeRelativeNode([sInterp,None,None], sTransformBoneTransform)
                sCurrentLength = nodes.createGetLengthVector('%s.Translation' % sInterpRelative)
                controllers.setNewColumn()
                sBoneTransformInitialLocal = nodes.getTransformNode(eBone, bInitial=True, bLocal=True)
                sDefaultLength = nodes.createGetLengthVector('%s.Translation' % sBoneTransformInitialLocal)
                sClampedLength = nodes.createConditionNodes(sCurrentLength, '<', sDefaultLength, sDefaultLength, sCurrentLength, iPinType=pins.PinType.double)
                sSpheredInterp = nodes.createSetLengthVector('%s.Translation' % sInterpRelative, sClampedLength)
                controllers.setNewColumn()
                sBoneTransformLocal = nodes.getTransformNode(eBone, bLocal=True)
                sWorldInterp = nodes.createMakeAbsoluteNode([sSpheredInterp, '%s.Rotation' % sBoneTransformLocal, None], sTransformBoneTransform)
                controllers.setNewColumn()
                nodes.createSetTransformExecuteNode(eBone, sWorldInterp)
                controllers.goToParentExecute()
            controllers.closeCommentBox('%s Bones Ctrls Move' % sPart.title())

            controllers.openCommentBox('%s Add Bones Offsets' % sPart.title())
            sForEach = nodes.createForEachExecuteNode('Entry.%sBones' % sPart.title())
            controllers.setNewColumn()
            if controllers.BLOCK_FOREACH: # for each bone
                eBone = ELEM('%s.Element' % sForEach, 'Bone')
                controllers.setNewColumn()
                sBoneLocalInitial = nodes.getTransformNode(eBone, bLocal=True, bInitial=True)
                sInitialPointsOnSplineVar = nodes.createGetVariableNode(vInitialPointsOnSpline)
                sInitialPointOnSpline = nodes.createArrayAtNode(sInitialPointsOnSplineVar, '%s.Index' % sForEach)
                controllers.setNewColumn()
                sDelta = nodes.createBasicCalculateNode(['%s.Translation' % sBoneLocalInitial, sInitialPointOnSpline], sOperation='Subtract', iPinType=pins.PinType.vector)
                sBoneLocal = nodes.getTransformNode(eBone, bLocal=True)
                sFinal = nodes.createBasicCalculateNode([sDelta, '%s.Translation' % sBoneLocal], sOperation='Add', iPinType=pins.PinType.vector)
                controllers.setNewColumn()
                nodes.createSetTranslationExecuteNode(eBone, sFinal, bLocal=True)
                controllers.goToParentExecute()

            controllers.closeCommentBox('%s Add Bones Offsets' % sPart.title())
        nodes.newSequencerPlug()
        nodes.endCurrentFunction(bAddToExecute=False)


    sSplineLidsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[600.0, 400.0])
    pins.setString(cBlink.eControl.name, '%s.BlinkControl' % sSplineLidsNode)
    pins.setString(sTransformBone, '%s.TransformBone' % sSplineLidsNode)
    pins.setStringArray(sBotBones, '%s.BotBones' % sSplineLidsNode)
    pins.setStringArray(sTopBones, '%s.TopBones' % sSplineLidsNode)
    pins.setVectorArray(ffBotMaxPoints, '%s.BotMaxPoints' % sSplineLidsNode)
    pins.setVectorArray(ffTopMaxPoints, '%s.TopMaxPoints' % sSplineLidsNode)
    pins.setVectorArray(ffBotPoints, '%s.BotPoints' % sSplineLidsNode)
    pins.setVectorArray(ffTopPoints, '%s.TopPoints' % sSplineLidsNode)
    pins.connectToPin1D(fLivePole, '%s.LivePole' % sSplineLidsNode)
    pins.connectToPin1D(fBlinkOverShoot, '%s.BlinkOverShoot' % sSplineLidsNode)
    for c,cCtrl in enumerate(cBotCtrls):
        pins.setString(cCtrl.ePasser.name, '%s.BotControlPasser%s' % (sSplineLidsNode, library.getLetter(c)))
    for c,cCtrl in enumerate(cTopCtrls):
        pins.setString(cCtrl.ePasser.name, '%s.TopControlPasser%s' % (sSplineLidsNode, library.getLetter(c)))
    pins.setStringArray(library.flattenedList([xx[0] for xx in xCtrlWeightsBot]), '%s.CtrlWeightsCtrlsBot' % sSplineLidsNode)
    pins.setValueArray(library.flattenedList([xx[1] for xx in xCtrlWeightsBot]), '%s.CtrlWeightsValuesBot' % sSplineLidsNode)
    pins.setStringArray(library.flattenedList([xx[0] for xx in xCtrlWeightsTop]), '%s.CtrlWeightsCtrlsTop' % sSplineLidsNode)
    pins.setValueArray(library.flattenedList([xx[1] for xx in xCtrlWeightsTop]), '%s.CtrlWeightsValuesTop' % sSplineLidsNode)
    return sSplineLidsNode




'''
functions.splineBrows([([2.72, 9.2, 166.08], [('browTangentAOut_l_ctrl', 1.0)]), ([4.38, 8.83, 167.02], [('browTangentAOut_l_ctrl', 0.7407407407407407), ('browTangentBIn_l_ctrl', 0.25925925925925924)]), ([6.11, 8.14, 167.54], [('browTangentBIn_l_ctrl', 0.7407407407407407), ('browTangentAOut_l_ctrl', 0.2592592592592593)]), ([7.8, 7.17, 167.68], [('browTangentBOut_l_ctrl', 1.0)]), ([9.27, 5.92, 167.49], [('browTangentBOut_l_ctrl', 0.7407407407407407), ('browTangentCIn_l_ctrl', 0.25925925925925924)]), ([10.33, 4.38, 166.97], [('browTangentCIn_l_ctrl', 0.7407407407407407), ('browTangentBOut_l_ctrl', 0.2592592592592593)]), ([10.98, 2.83, 165.98], [('browTangentCIn_l_ctrl', 1.0)])])
'''

def browSplines(cMainCtrl, cCtrls, cTangentCtrls, fPoints, sSplineInfluences, iSplineInfluencesA, iSplineInfluencesB, fSplineInfluenceWeightsA, sJoints=[], sSide='l', fJointWeights0=[], fJointWeights1=[],
                dPreSiblingValues={}, dPreSiblingDriverValues={}, dPostSiblingValuesAllDirections={}, dPostSiblingDriverValuesAllDirections={}, dTangentPreSiblingValuesAllDirections={}, dTangentPreSiblingDriverValuesAllDirections={},
                sParentBone='jnt_m_headMain', fVerticalDefaults=[], fVerticalDowns=[], fVerticalUps=[]):
    sFunctionName = 'kangaroo_splineBrows'

    uFunction = nodes.getFunction(sFunctionName)

    xPrePoseInputs = []
    dPrePoseOffsets = {}
    for iCtrlIndex in dPreSiblingDriverValues.keys():
        dPrePoseOffsets[iCtrlIndex] = cCtrls[iCtrlIndex].addOffset('prePose')
        xPrePoseInputs.append(('PrePoseOffset%d' % iCtrlIndex, 'FName', False))


    # dPostSiblingValuesAllDirections={'up': {'0.RotateX': 24.616191081251735, '1.RotateX': 24.616191081251735, '2.RotateX': 24.616191081251735}}, dPostSiblingDriverValuesAllDirections
    dTangentPreOffsets = {}
    for sDirection, dTangentPreSiblings in dTangentPreSiblingValuesAllDirections.items():
        for sUnrealAttr,fValue in dTangentPreSiblings.items():
            sTangentCtrlIndex, sAttr = sUnrealAttr.split('.')
            iTangentCtrlIndex = int(sTangentCtrlIndex)
            if iTangentCtrlIndex not in dTangentPreOffsets:
                dTangentPreOffsets[iTangentCtrlIndex] = cTangentCtrls[iTangentCtrlIndex].addOffset('prePose')
                xPrePoseInputs.append(('TangentPrePoseOffset%d' % iTangentCtrlIndex, 'FName', False))

    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[('ParentBone', 'FName', False),
                                                    ('MainControl', 'FName', False),
                                                    ('MainPasser', 'FName', False),
                                                    ('Control0', 'FName', False),
                                                    ('Control1', 'FName', False),
                                                    ('Control2', 'FName', False),
                                                    ('SplinePoints', 'FVector', True),
                                                    ('SplineInfluences', 'FName', True),
                                                    ('SplineInfluences0', 'int32', True),
                                                    ('SplineInfluences1', 'int32', True),
                                                    ('SplineInfluenceWeights0', 'float', True),
                                                    ('ControlOut0', 'FName', False),
                                                    ('ControlOut1', 'FName', False),
                                                    ('ControlOut2', 'FName', False),
                                                    ('ControlPasser0', 'FName', False),
                                                    ('ControlPasser1', 'FName', False),
                                                    ('ControlPasser2', 'FName', False),
                                                    ('TangentPasser0', 'FName', False),
                                                    ('TangentPasser1_A', 'FName', False),
                                                    ('TangentPasser1_B', 'FName', False),
                                                    ('TangentPasser2', 'FName', False),
                                                    ('BoneNames', 'FName', True),
                                                    ('BoneWeights0', 'float', True),
                                                    ('BoneWeights1', 'float', True),
                                                    ('bNegative', 'bool', False),
                                                    ('VerticalDefaults', 'float', True),
                                                    ('VerticalDowns', 'float', True),
                                                    ('VerticalUps', 'float', True)] + xPrePoseInputs,
                                        xOutputs=[('ControlTotalTranslate0', 'FVector', False),
                                                  ('VerticalUpsOut', 'float', True),
                                                  ('VerticalDownsOut', 'float', True)],
                                                bMutable=True)

        eParentBone = ELEM('Entry.ParentBone', 'Bone')
        eMainControl = ELEM('Entry.MainControl', 'Control')
        eMainPasser = ELEM('Entry.MainPasser', 'Null')
        eControl0 = ELEM('Entry.Control0', 'Control')
        eControl1 = ELEM('Entry.Control1', 'Control')
        eControl2 = ELEM('Entry.Control2', 'Control')
        eControlPasser0 = ELEM('Entry.ControlPasser0', 'Null')
        eControlPasser1 = ELEM('Entry.ControlPasser1', 'Null')
        eControlPasser2 = ELEM('Entry.ControlPasser2', 'Null')
        eControlOut0 = ELEM('Entry.ControlOut0', 'Null')
        eControlOut1 = ELEM('Entry.ControlOut1', 'Null')
        eControlOut2 = ELEM('Entry.ControlOut2', 'Null')


        controllers.openCommentBox('Controls')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eParentBone, 1.0)], eMainPasser, bMaintainOffset=True)
        controllers.setNewColumn()
        sCtrlPasserTransform0 = nodes.createProjectTransformToNewParent(eControlPasser0, eMainControl)
        sCtrlPasserTransform1 = nodes.createProjectTransformToNewParent(eControlPasser1, eMainControl)
        sCtrlPasserTransform2 = nodes.createProjectTransformToNewParent(eControlPasser2, eMainControl)
        controllers.setNewColumn()
        nodes.createSetTransformExecuteNode(eControlPasser0, sCtrlPasserTransform0)
        nodes.createSetTransformExecuteNode(eControlPasser1, sCtrlPasserTransform1)
        nodes.createSetTransformExecuteNode(eControlPasser2, sCtrlPasserTransform2)
        controllers.closeCommentBox('Controls')

        # Pre Siblings
        #
        sLocalControl0 = nodes.getTransformNode(eControl0, bLocal=True)
        sLocalControl1 = nodes.getTransformNode(eControl1, bLocal=True)
        sLocalControl2 = nodes.getTransformNode(eControl2, bLocal=True)
        controllers.setNewColumn()
        controllers.openCommentBox('Pre Siblings')
        sDriver = '%s.Translation.Z' % nodes.getTransformNode(eMainControl, bLocal=True)
        dPoseTransforms = {}
        for iCtrlIndex, fDriverValue in dPreSiblingDriverValues.items():
            controllers.setNewColumn()
            xTransform = [[0,0,0], None, [1,1,1]]
            for sUnrealAttr, fValue in dPreSiblingValues.items():
                if sUnrealAttr.startswith('%d.' % iCtrlIndex):
                    iTranslateAttr = ['TranslateX', 'TranslateY', 'TranslateZ'].index(sUnrealAttr.split('.')[1])
                    sRemap = nodes.createRemapNode(sDriver, 0, fDriverValue, 0, fValue)
                    xTransform[0][iTranslateAttr] = sRemap
            dPoseTransforms[iCtrlIndex] = xTransform
            ePrePoseOffset = ELEM('Entry.PrePoseOffset%d' % iCtrlIndex, 'Null')
            controllers.setNewColumn()
            print ('xTransform: ', xTransform)
            nodes.createSetTransformExecuteNode(ePrePoseOffset, xTransform, bLocal=True)
        controllers.closeCommentBox('Pre Siblings')


        controllers.setNewColumn()
        controllers.openCommentBox('Total Translations for Drivers')
        sTotalTranslations = []
        for iCtrlIndex in [0,1,2]:
            controllers.setNewColumn()
            sLocalControlFactors = []
            sLocalControlFactors.append('%s.Translation' % [sLocalControl0, sLocalControl1, sLocalControl2][iCtrlIndex])
            if iCtrlIndex in dPoseTransforms:
                sPosed = dPoseTransforms[iCtrlIndex][0]
                if sPosed[0] or sPosed[1] or sPosed[2]:
                    sLocalControlFactors.append(sPosed)

            # the following 2 nodes could be optimized, to not create if they have been created already
            sCtrlPasserTransformByParentBone = nodes.createProjectTransformToNewParent([eControlPasser0, eControlPasser1, eControlPasser2][iCtrlIndex], eParentBone)
            sPasserMovedByMain = nodes.createMakeRelativeNode([sCtrlPasserTransform0, sCtrlPasserTransform1, sCtrlPasserTransform2][iCtrlIndex], sCtrlPasserTransformByParentBone)
            sLocalControlFactors.append('%s.Translation' % sPasserMovedByMain)
            sTotalTranslations.append(nodes.createBasicCalculateNodeAutoAddPins(sLocalControlFactors, sOperation='Add', iPinType=pins.PinType.vector))
            if iCtrlIndex == 0:
                pins.connectToPinVector(sTotalTranslations[0], 'Return.ControlTotalTranslate0')
        controllers.closeCommentBox('Total Translations for Drivers')


        # Post Siblings
        #
        controllers.setNewColumn()
        controllers.openCommentBox('Post Siblings')
        dDriverAttributes = {}
        dDriverA = {'up': 'Z', 'down': 'Z', 'in': 'X'}

        dTransforms = {}
        for sDirection, dPostSiblingValues in dPostSiblingValuesAllDirections.items():
            for sUnrealAttr, fValue in dPostSiblingValues.items():
                controllers.setNewColumn()
                sCtrlIndex, sUnrealA = sUnrealAttr.split('.')
                iCtrlIndex = int(sCtrlIndex)
                xTransform = dTransforms.get(iCtrlIndex, [[0,0,0], [0,0,0], None])
                iAxis = ['X','Y','Z'].index(sUnrealA[-1])
                if sUnrealA.startswith('Rotate'):
                    xTransform[1][iAxis] = nodes.createRemapNode('%s.%s' % (sTotalTranslations[iCtrlIndex], dDriverA[sDirection]), 0, dPostSiblingDriverValuesAllDirections[sDirection][iCtrlIndex], 0, fValue, bClamp=True)
                dTransforms[iCtrlIndex] = xTransform

        for iCtrlIndex in sorted(dTransforms.keys()):
            controllers.setNewColumn()
            xTransform = dTransforms[iCtrlIndex]
            # xTransform[1] = nodes.createFromEulerNode(xTransform[1])
            nodes.createSetTranslationExecuteNode([eControlOut0, eControlOut1, eControlOut2][iCtrlIndex], dTransforms[iCtrlIndex][0], bLocal=True)
            nodes.createSetRotationExecuteNode([eControlOut0, eControlOut1, eControlOut2][iCtrlIndex], nodes.createFromEulerNode(xTransform[1]), bLocal=True)
        controllers.closeCommentBox('Post Siblings')


        # Tangent Pre Siblings
        #
        controllers.setNewColumn()
        controllers.openCommentBox('Tangent Pre Siblings')
        dEulers = {}
        dCtrlIndices = {0:0, 1:1, 2:1, 3:2}
        for sDirection, dTangentPreSiblingValues in dTangentPreSiblingValuesAllDirections.items():
            for sUnrealAttr, fValue in dTangentPreSiblingValues.items():
                controllers.setNewColumn()
                sCtrlIndex, sUnrealA = sUnrealAttr.split('.')
                iTangentCtrlIndex = int(sCtrlIndex)
                ffEuler = dEulers.get(iTangentCtrlIndex, [[], [], []])
                iAxis = ['X','Y','Z'].index(sUnrealA[-1])
                if sUnrealA.startswith('Rotate'):
                    ffEuler[iAxis].append(nodes.createRemapNode('%s.%s' % (sTotalTranslations[dCtrlIndices[iTangentCtrlIndex]], dDriverA[sDirection]), 0,
                                                                 dTangentPreSiblingDriverValuesAllDirections[sDirection][iTangentCtrlIndex],
                                                                 0, fValue, bClamp=True))
                dEulers[iTangentCtrlIndex] = ffEuler

        for iTangentCtrlIndex in sorted(dEulers.keys()):
            controllers.setNewColumn()
            ffEuler = dEulers[iTangentCtrlIndex]
            fEuler = [0,0,0]
            for i in range(3):
                if len(ffEuler[i]) == 1:
                    fEuler[i] = ffEuler[i]
                elif len(ffEuler[i]) > 1:
                    fEuler[i] = nodes.createBasicCalculateNode(ffEuler[i], sOperation='Add')
            sQuat = nodes.createFromEulerNode(fEuler)
            nodes.createSetRotationExecuteNode(ELEM('Entry.TangentPrePoseOffset%d' % iTangentCtrlIndex, 'Null'), sQuat, bLocal=True)

        controllers.closeCommentBox('Tangent Pre Siblings')



        controllers.setNewColumn()
        controllers.openCommentBox('Get Control Transforms')
        sControlTransform0 = nodes.getTransformNode(eControl0)
        sControlTransform1 = nodes.getTransformNode(eControl1)
        sControlTransform2 = nodes.getTransformNode(eControl2)
        sControlOutTransform0 = nodes.getTransformNode(eControlOut0)
        sControlOutTransform1 = nodes.getTransformNode(eControlOut1)
        sControlOutTransform2 = nodes.getTransformNode(eControlOut2)
        controllers.closeCommentBox('Get Control Transforms')

        sForward = nodes.createIfNode('Entry.bNegative', -1.0, 1.0, iPinType=pins.PinType.double)
        sBackwards = nodes.createIfNode('Entry.bNegative', 1.0, -1.0, iPinType=pins.PinType.double)
        controllers.setNewColumn()
        controllers.openCommentBox('Tangents 0')
        sCtrlWithoutRotation0 = ['%s.Translation' % sControlTransform0, '%s.Rotation' % sCtrlPasserTransform0, '%s.Scale3D' % sCtrlPasserTransform0]
        sLocalTarget = nodes.createMakeRelativeNode(sControlTransform1, sCtrlWithoutRotation0)
        sWorldTarget = nodes.createMakeAbsoluteNode(sLocalTarget, sControlOutTransform0)
        sUpVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % sControlOutTransform0)
        nodes.createAimExecuteNode(ELEM('Entry.TangentPasser0', 'Null'), '%s.Translation' % sWorldTarget,
                                   fAimVector=[1,0,0], sSecondaryTargetVector=sUpVector, bUpIsDirection=True)
        controllers.closeCommentBox('Tangents 0')

        controllers.setNewColumn()
        controllers.openCommentBox('Tangents 1')
        sCtrlWithoutRotation1 = ['%s.Translation' % sControlTransform1, '%s.Rotation' % sCtrlPasserTransform1, '%s.Scale3D' % sCtrlPasserTransform1]
        sLocalTarget_A = nodes.createMakeRelativeNode(sControlTransform0, sCtrlWithoutRotation1)
        sLocalTarget_B = nodes.createMakeRelativeNode(sControlTransform2, sCtrlWithoutRotation1)
        sLocalTarget = nodes.createBasicCalculateNode(['%s.Translation' % sLocalTarget_A, '%s.Translation' % sLocalTarget_B], sOperation='Subtract', iPinType=pins.PinType.vector)
        sLocalTarget = nodes.createBasicCalculateNode([sLocalTarget, [0.5, 0.5, 0.5]], iPinType=pins.PinType.vector)
        sWorldTarget = nodes.createMakeAbsoluteNode([sLocalTarget,None,None], sControlOutTransform1)
        sUpVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % sControlOutTransform1)
        nodes.createAimExecuteNode(ELEM('Entry.TangentPasser1_A', 'Null'), '%s.Translation' % sWorldTarget, fAimVector=[-1,0,0], fUpVector=[0,0,1], sSecondaryTargetVector=sUpVector, bUpIsDirection=True)
        nodes.createAimExecuteNode(ELEM('Entry.TangentPasser1_B', 'Null'), '%s.Translation' % sWorldTarget, fAimVector=[-1,0,0], fUpVector=[0,0,1], sSecondaryTargetVector=sUpVector, bUpIsDirection=True)
        controllers.closeCommentBox('Tangents 1')

        controllers.setNewColumn()
        controllers.openCommentBox('Tangents 2')
        sCtrlWithoutRotation2 = ['%s.Translation' % sControlTransform2, '%s.Rotation' % sCtrlPasserTransform2, '%s.Scale3D' % sCtrlPasserTransform2]
        sLocalTarget = nodes.createMakeRelativeNode(sControlTransform1, sCtrlWithoutRotation2)
        sWorldTarget = nodes.createMakeAbsoluteNode(sLocalTarget, sControlOutTransform2)
        sUpVector = nodes.createRotateVectorNode([0,0,1], '%s.Rotation' % sControlOutTransform2)
        nodes.createAimExecuteNode(ELEM('Entry.TangentPasser2', 'Null'), '%s.Translation' % sWorldTarget,
                                   fAimVector=[-1,0,0], fUpVector=[0,0,1], sSecondaryTargetVector=sUpVector, bUpIsDirection=True)
        controllers.closeCommentBox('Tangents 2')

        controllers.setNewColumn()
        sCurvePoints = []

        # controllers.openCommentBox('Get Influences')
        # ssTransforms = []
        # for i in range(len(sAllInfluences)):
        #     sTransformInitial = nodes.getTransformNode(ELEM('Entry.Influence_%s' % library.getLetter(i), 'Control'), bInitial=True)
        #     sTransform = nodes.getTransformNode(ELEM('Entry.Influence_%s' % library.getLetter(i), 'Control'))
        #     ssTransforms.append([sTransformInitial, sTransform])
        # controllers.closeCommentBox('Get Influences')
        #
        # controllers.setNewColumn()
        # controllers.openCommentBox('Transform Curve Points')
        #
        #
        # for i,xP in enumerate(xPoints):
        #     xInfs = xP[1]
        #     sPointsPerPoint = []
        #     for ii, xI in enumerate(xInfs):
        #         controllers.setNewColumn()
        #         sTransformInitial, sTransform = ssTransforms[xIndices[i][ii]]
        #         sPointRelative = nodes.createMakeRelativeNode(['Entry.Point%d' % i, None, None], sTransformInitial)
        #         sPointAbsolute = nodes.createMakeAbsoluteNode(sPointRelative, sTransform)
        #         sPointsPerPoint.append(sPointAbsolute)
        #
        #     if len(sPointsPerPoint) == 1:
        #         sCurvePoints.append('%s.Translation' % sPointsPerPoint[0])
        #     else:
        #         sCurvePoints.append(nodes.createVectorInterpolateNode(xInfs[0][1], '%s.Translation' % sPointsPerPoint[1], '%s.Translation' % sPointsPerPoint[0]))


        controllers.openCommentBox('Transform Curve Points')
        vSplinePointsSkinned = hierarchy.newVariable('SplinePointsDeformed7', 'FVector', bArray=True, bLocal=True)
        nodes.createResetArrayNode(nodes.createGetVariableNode(vSplinePointsSkinned))
        controllers.setNewColumn()
        sForeachPoint = nodes.createForEachExecuteNode('Entry.SplinePoints')
        if controllers.BLOCK_FOREACH: # each point
            controllers.setNewColumn()
            sInfluenceIndex0 = nodes.createArrayAtNode('Entry.SplineInfluences0', '%s.Index' % sForeachPoint)
            sInfluence0 = nodes.createArrayAtNode('Entry.SplineInfluences', sInfluenceIndex0)
            controllers.setNewColumn()
            sTransformInitial0 = nodes.getTransformNode(ELEM(sInfluence0, 'Control'), bInitial=True)
            sTransform0 = nodes.getTransformNode(ELEM(sInfluence0, 'Control'))
            sRelative0 = nodes.createMakeRelativeNode(['%s.Element' % sForeachPoint,None,None], sTransformInitial0)
            sAbsolute0 = nodes.createMakeAbsoluteNode(sRelative0, sTransform0)
            controllers.setNewColumn()
            sInfluenceIndex1 = nodes.createArrayAtNode('Entry.SplineInfluences1', '%s.Index' % sForeachPoint)
            sInfluence1 = nodes.createArrayAtNode('Entry.SplineInfluences', sInfluenceIndex1)
            controllers.setNewColumn()
            sTransformInitial1 = nodes.getTransformNode(ELEM(sInfluence1, 'Control'), bInitial=True)
            sTransform1 = nodes.getTransformNode(ELEM(sInfluence1, 'Control'))
            sRelative1 = nodes.createMakeRelativeNode(['%s.Element' % sForeachPoint,None,None], sTransformInitial1)
            sAbsolute1 = nodes.createMakeAbsoluteNode(sRelative1, sTransform1)
            controllers.setNewColumn()
            sWeight0 = nodes.createArrayAtNode('Entry.SplineInfluenceWeights0', '%s.Index' % sForeachPoint)
            sBlended = nodes.createVectorInterpolateNode(sWeight0, '%s.Translation' % sAbsolute1, '%s.Translation' % sAbsolute0)
            sCurvePointsVar = nodes.createGetVariableNode(vSplinePointsSkinned)
            nodes.createArrayAddNode(sCurvePointsVar, sBlended)
            controllers.goToParentExecute()

        controllers.closeCommentBox('Transform Curve Points')


        controllers.setNewColumn()
        sCurvePointsVar = nodes.createGetVariableNode(vSplinePointsSkinned)
        sSplineInitial = nodes.createSplineFromPositionsNode('Entry.SplinePoints', bSpline=True)
        sSpline = nodes.createSplineFromPositionsNode(sCurvePointsVar, bSpline=True)
        controllers.setNewColumn()
        # nodes.createDrawSplineNode(sSplineInitial, 0.25, fColor=[0,0,1])
        # nodes.createDrawSplineNode(sSpline, 0.1, fColor=[1,0,0])


        controllers.setNewColumn()
        controllers.openCommentBox('Joints')
        sForEach = nodes.createForEachExecuteNode('Entry.BoneNames')
        controllers.setNewColumn()
        sBoneTransformInitial = nodes.getTransformNode(ELEM('%s.Element' % sForEach, 'Bone'), bInitial=True)
        sBoneTransform = nodes.getTransformNode(ELEM('%s.Element' % sForEach, 'Bone'))
        controllers.setNewColumn()
        sInitialU = nodes.createGetParamFromPositionOnSpline(sSplineInitial, '%s.Translation' % sBoneTransformInitial)
        sPointOnSpline = nodes.createGetPositionOnSpline(sSpline, sInitialU)
        controllers.setNewColumn()
        eElement = ELEM('%s.Element' % sForEach, 'Bone')
        nodes.createSetTransformExecuteNode(eElement, [sPointOnSpline, '%s.Rotation' % sBoneTransform, '%s.Scale3D' % sBoneTransform])
        controllers.setNewColumn()
        sWeight0 = nodes.createArrayAtNode('Entry.BoneWeights0', '%s.Index' % sForEach)
        sWeight1 = nodes.createArrayAtNode('Entry.BoneWeights1', '%s.Index' % sForEach)
        sWeight2 = nodes.createBasicCalculateNode([1.0, sWeight0, sWeight1], sOperation='Subtract')
        controllers.setNewColumn()
        nodes.createRotationConstraintExecuteNode([(eControlOut0, sWeight0), (eControlOut1, sWeight1), (eControlOut2, sWeight2)],
                                                  eElement, bMaintainOffset=True)

        controllers.closeCommentBox('Joints')
        controllers.goToParentExecute()


        controllers.openCommentBox('MorphTarget Drivers')
        controllers.setNewColumn()
        sPasserTransform = nodes.getTransformNode(eMainPasser)

        controllers.setNewColumn()
        vUpTempVar = hierarchy.newVariable(f'outUps', 'double', True, True)
        vDownTempVar = hierarchy.newVariable(f'outDowns', 'double', True, True)
        nodes.createResetArrayNode(nodes.createGetVariableNode(vUpTempVar))
        nodes.createResetArrayNode(nodes.createGetVariableNode(vDownTempVar))
        vTempVars = [vUpTempVar, vDownTempVar]

        controllers.setNewColumn()
        sForEachBone = nodes.createForEachExecuteNode('Entry.BoneNames')
        if controllers.BLOCK_FOREACH:
            eBone = ELEM('%s.Element' % sForEachBone, 'Bone')
            sBoneTransform = nodes.getTransformNode(eBone)
            controllers.setNewColumn()
            sRelative = nodes.createMakeRelativeNode(sBoneTransform, sPasserTransform)
            controllers.setNewColumn()

            sCurrentDefault = nodes.createArrayAtNode('Entry.VerticalDefaults', '%s.Index' % sForEachBone)
            for d,sDir in enumerate(['Up', 'Down']):
                controllers.setNewColumn()
                sCurrentDir = nodes.createArrayAtNode(f'Entry.Vertical{sDir}s', '%s.Index' % sForEachBone)
                controllers.setNewColumn()
                sMapped = nodes.createRemapNode('%s.Translation.Z' % sRelative, sCurrentDefault, sCurrentDir, 0.0, 1.0)
                sTempVarNode = nodes.createGetVariableNode(vTempVars[d])
                nodes.createArrayAddNode(sTempVarNode, sMapped)

            controllers.goToParentExecute()
            controllers.setNewColumn()

            pins.connectToPin1D(nodes.createGetVariableNode(vUpTempVar), 'Return.VerticalUpsOut' )
            pins.connectToPin1D(nodes.createGetVariableNode(vDownTempVar), 'Return.VerticalDownsOut' )
        controllers.closeCommentBox('MorphTarget Drivers')




        nodes.endCurrentFunction(bAddToExecute=False)

    controllers.setNewColumn()
    sSplineBrowsNode = nodes.addFunctionNode(sFunctionName, bFunctionIsMutable=True, fNodeSize=[600.0, 400.0])
    pins.setString(cMainCtrl.eControl.name, '%s.MainControl' % sSplineBrowsNode)
    pins.setString(cMainCtrl.ePasser.name, '%s.MainPasser' % sSplineBrowsNode)
    pins.setString(cTangentCtrls[0].ePasser.name, '%s.TangentPasser0' % sSplineBrowsNode)
    pins.setString(cTangentCtrls[1].ePasser.name, '%s.TangentPasser1_A' % sSplineBrowsNode)
    pins.setString(cTangentCtrls[2].ePasser.name, '%s.TangentPasser1_B' % sSplineBrowsNode)
    pins.setString(cTangentCtrls[3].ePasser.name, '%s.TangentPasser2' % sSplineBrowsNode)
    pins.setString(cCtrls[0].eControl.name, '%s.Control0' % sSplineBrowsNode)
    pins.setString(cCtrls[1].eControl.name, '%s.Control1' % sSplineBrowsNode)
    pins.setString(cCtrls[2].eControl.name, '%s.Control2' % sSplineBrowsNode)
    pins.setString(cCtrls[0].ePasser.name, '%s.ControlPasser0' % sSplineBrowsNode)
    pins.setString(cCtrls[1].ePasser.name, '%s.ControlPasser1' % sSplineBrowsNode)
    pins.setString(cCtrls[2].ePasser.name, '%s.ControlPasser2' % sSplineBrowsNode)
    pins.setString(cCtrls[0].eOut.name, '%s.ControlOut0' % sSplineBrowsNode)
    pins.setString(cCtrls[1].eOut.name, '%s.ControlOut1' % sSplineBrowsNode)
    pins.setString(cCtrls[2].eOut.name, '%s.ControlOut2' % sSplineBrowsNode)
    pins.setString(sParentBone, '%s.ParentBone' % sSplineBrowsNode)
    pins.connectToPin1D(True if sSide=='r' else False, '%s.bNegative' % sSplineBrowsNode)
    pins.setVectorArray(fPoints, '%s.SplinePoints' % sSplineBrowsNode)
    pins.setStringArray(sSplineInfluences, '%s.SplineInfluences' % sSplineBrowsNode)
    pins.setValueArray(iSplineInfluencesA, '%s.SplineInfluences0' % sSplineBrowsNode, bInt=True)
    pins.setValueArray(iSplineInfluencesB, '%s.SplineInfluences1' % sSplineBrowsNode, bInt=True)
    pins.setValueArray(fSplineInfluenceWeightsA, '%s.SplineInfluenceWeights0' % sSplineBrowsNode)
    pins.setStringArray(sJoints, '%s.BoneNames' % sSplineBrowsNode)
    pins.setValueArray(fJointWeights0, '%s.BoneWeights0' % sSplineBrowsNode)
    pins.setValueArray(fJointWeights1, '%s.BoneWeights1' % sSplineBrowsNode)

    for iCtrlIndex in dPreSiblingDriverValues.keys():
        pins.setString(dPrePoseOffsets[iCtrlIndex].name, '%s.PrePoseOffset%d' % (sSplineBrowsNode, iCtrlIndex))

    for iTangentCtrlIndex, eOffset in dTangentPreOffsets.items():
        pins.setString(eOffset.name, '%s.TangentPrePoseOffset%d' % (sSplineBrowsNode, iTangentCtrlIndex))

    pins.setValueArray(fVerticalDefaults, '%s.VerticalDefaults' % sSplineBrowsNode)
    pins.setValueArray(fVerticalDowns, '%s.VerticalDowns' % sSplineBrowsNode)
    pins.setValueArray(fVerticalUps, '%s.VerticalUps' % sSplineBrowsNode)

    return sSplineBrowsNode



def browsMiddle(cMiddle, sBone, sBoneDefault, sBrowsNodeLeft, sBrowsNodeRight, cBrowsControlLeft, cBrowsControlRight, fFollow=1.0, fAutoPush=1.0, fAutoScale=1.0, sParentBone='jnt_m_headMain', fVerticalDefault=0, fVerticalUp=0, fVerticalDown=0):
    sFunctionName = 'kangaroo_browsMiddle'
    eMoveWithSides, ePush = cMiddle.addOffsets(['push', 'movewithsides'])

    hierarchy.createFloatControl('Follow', eParent=cMiddle.eControl, fRange=[0, 1.0], fDefault=fFollow)
    hierarchy.createFloatControl('AutoPush', eParent=cMiddle.eControl, fRange=[0, 3.0], fDefault=fAutoPush)
    hierarchy.createFloatControl('AutoScale', eParent=cMiddle.eControl, fRange=[0, 3.0], fDefault=fAutoScale)

    uFunction = nodes.getFunction(sFunctionName)
    if not uFunction:
        nodes.startFunction(sFunctionName, xInputs=[
                                                       ('ControlPasser', 'FName', False),
                                                       ('ControlMoveWithSides', 'FName', False),
                                                       ('Push', 'FName', False),
                                                       ('Control', 'FName', False),
                                                       ('SideTotalTranslateLeft', 'FVector', False),
                                                       ('SidesTotalTranslateRight', 'FVector', False),
                                                       ('BrowsControlLeft', 'FName', False),
                                                       ('BrowsControlRight', 'FName', False),
                                                       ('Bone', 'FName', False),
                                                       ('BoneDefault', 'FName', False),
                                                       ('ParentBone', 'FName', False),
                                                       ('VerticalDefault', 'float', False),
                                                       ('VerticalDown', 'float', False),
                                                       ('VerticalUp', 'float', False)],
                                            xOutputs=[('VerticalUpOut', 'float', False),
                                                      ('VerticalDownOut', 'float', False)])

        eMoveWithSidesInside = ELEM('Entry.ControlMoveWithSides', 'Null')
        ePushInside = ELEM('Entry.Push', 'Null')
        eControl = ELEM('Entry.Control', 'Control')
        ePasser = ELEM('Entry.ControlPasser', 'Null')
        nodes.createParentConstraintExecuteNode([(ELEM('Entry.ParentBone', 'Bone'), 1.0)], ePasser, bMaintainOffset=True)

        controllers.openCommentBox('Move with Sides')
        controllers.setNewColumn()
        sSidesTotalTranslateRight = [nodes.createBasicCalculateNode(['Entry.SidesTotalTranslateRight.X', -1.0]), 'Entry.SidesTotalTranslateRight.Y', 'Entry.SidesTotalTranslateRight.Z']
        sTotalTranslateSum = nodes.createBasicCalculateNode(['Entry.SideTotalTranslateLeft', sSidesTotalTranslateRight], sOperation='Add', iPinType=pins.PinType.vector)
        sMoveWithSides = nodes.createBasicCalculateNode([sTotalTranslateSum, [0.5,0.5,0.5]], sOperation='Multiply', iPinType=pins.PinType.vector)
        controllers.setNewColumn()
        sFollowAttr = nodes.createGetChannelNode2('Entry.Control', 'Follow')
        sFollow = nodes.createVectorInterpolateNode(sFollowAttr, [0,0,0], sMoveWithSides)
        controllers.closeCommentBox('Move with Sides')

        controllers.openCommentBox('Push & Scale')
        controllers.setNewColumn()
        sLeftTransform = nodes.getTransformNode(ELEM('Entry.BrowsControlLeft', 'Control'))
        sRightTransform = nodes.getTransformNode(ELEM('Entry.BrowsControlRight', 'Control'))
        sLeftTransformInitial = nodes.getTransformNode(ELEM('Entry.BrowsControlLeft', 'Control'), bInitial=True)
        sRightTransformInitial = nodes.getTransformNode(ELEM('Entry.BrowsControlRight', 'Control'), bInitial=True)
        controllers.setNewColumn()
        sDistance = nodes.createGetDistanceNode('%s.Translation' % sLeftTransform, '%s.Translation' % sRightTransform)
        sDistanceInitial = nodes.createGetDistanceNode('%s.Translation' % sLeftTransformInitial, '%s.Translation' % sRightTransformInitial)
        sFactor = nodes.createBasicCalculateNode([sDistance, sDistanceInitial], sOperation='Divide')
        controllers.setNewColumn()
        sPushAttr = nodes.createGetChannelNode2('Entry.Control', 'AutoPush')
        sScaleAttr = nodes.createGetChannelNode2('Entry.Control', 'AutoScale')
        controllers.setNewColumn()
        sPushTranslate = nodes.createRemapNode(sFactor, 1.0, 0.1, 0.0, sPushAttr)
        sPushScale = nodes.createRemapNode(sFactor, 1.0, 0.1, 1.0, sScaleAttr)
        controllers.setNewColumn()
        nodes.createSetTranslationExecuteNode(eMoveWithSidesInside, sFollow, bLocal=True)
        nodes.createSetTransformExecuteNode(ePushInside, [[0,sPushTranslate,0], None, [sPushScale, 1.0, 1.0]], bLocal=True)
        controllers.closeCommentBox('Push & Scale')

        # nodes.createSetTranslationExecuteNode(eMoveWithSidesInside, sFollow, bLocal=True)

        eDefaultBone = ELEM('Entry.BoneDefault','Bone')
        controllers.openCommentBox('Constraint Bones')
        controllers.setNewColumn()
        nodes.createParentConstraintExecuteNode([(eControl, 1.0)], ELEM('Entry.Bone','Bone'), bMaintainOffset=True, skipScale=[])
        nodes.createParentConstraintExecuteNode([(eMoveWithSidesInside, 1.0)], eDefaultBone, bMaintainOffset=True)
        nodes.createParentConstraintExecuteNode([(eControl, 1.0)], eDefaultBone, bMaintainOffset=True, skipTranslate=['x','y','z'], skipRotate=['x','y','z'], skipScale=[])
        controllers.closeCommentBox('Constraint Bones')


        controllers.openCommentBox('MorphTarget Driver')
        controllers.setNewColumn()
        sBoneTransform = nodes.getTransformNode(eDefaultBone)
        controllers.setNewColumn()
        sPasserTransform = nodes.getTransformNode(ePasser)
        sRelative = nodes.createMakeRelativeNode(sBoneTransform, sPasserTransform)
        controllers.setNewColumn()
        controllers.setNewColumn()
        sMapUp = nodes.createRemapNode('%s.Translation.Z' % sRelative, 'Entry.VerticalDefault', 'Entry.VerticalUp', 0.0, 1.0)
        sMapDown = nodes.createRemapNode('%s.Translation.Z' % sRelative, 'Entry.VerticalDefault', 'Entry.VerticalDown', 0.0, 1.0)
        pins.connectToPin1D(sMapUp, 'Return.VerticalUpOut')
        pins.connectToPin1D(sMapDown, 'Return.VerticalDownOut')

        nodes.endCurrentFunction(bAddToExecute=False)

    sBrowsMiddleNode = nodes.addFunctionNode(sFunctionName, fNodeSize=[300.0, 400.0])
    pins.setString(cBrowsControlLeft.eControl.name, '%s.BrowsControlLeft' % sBrowsMiddleNode)
    pins.setString(cBrowsControlRight.eControl.name, '%s.BrowsControlRight' % sBrowsMiddleNode)
    pins.setString(cMiddle.ePasser.name, '%s.ControlPasser' % sBrowsMiddleNode)
    pins.setString(cMiddle.eControl.name, '%s.Control' % sBrowsMiddleNode)
    pins.setString(eMoveWithSides.name, '%s.ControlMoveWithSides' % sBrowsMiddleNode)
    pins.setString(ePush.name, '%s.Push' % sBrowsMiddleNode)
    pins.setString(sBone, '%s.Bone' % sBrowsMiddleNode)
    pins.setString(sBoneDefault, '%s.BoneDefault' % sBrowsMiddleNode)
    pins.setString(sParentBone, '%s.ParentBone' % sBrowsMiddleNode)
    pins.connectToPinVector('%s.ControlTotalTranslate0' % sBrowsNodeLeft, '%s.SideTotalTranslateLeft' % sBrowsMiddleNode)
    pins.connectToPinVector('%s.ControlTotalTranslate0' % sBrowsNodeRight, '%s.SidesTotalTranslateRight' % sBrowsMiddleNode)
    pins.connectToPin1D(fVerticalDefault, '%s.VerticalDefault' % sBrowsMiddleNode)
    pins.connectToPin1D(fVerticalDown, '%s.VerticalDown' % sBrowsMiddleNode)
    pins.connectToPin1D(fVerticalUp, '%s.VerticalUp' % sBrowsMiddleNode)
    return sBrowsMiddleNode



vBrowVariables = []
def browsToVariables(sLeftBrow, sRightBrow, sMiddleBrow, iCount):
    global vBrowVariables
    # vReturn = []
    for sDir in ['Up', 'Down']:
        vVar = hierarchy.newVariable(f'brow{sDir}s', 'double', bArray=True)
        sGetVar = nodes.createGetVariableNode(vVar)
        controllers.setNewColumn()
        nodes.createResetArrayNode(sGetVar)
        nodes.createArrayAppendNode(sGetVar, f'%s.Vertical{sDir}sOut' % sLeftBrow)
        nodes.createArrayAppendNode(sGetVar, f'%s.Vertical{sDir}sOut' % sRightBrow)
        nodes.createArrayAddNode(sGetVar, f'%s.Vertical{sDir}Out' % sMiddleBrow)
        vBrowVariables.append(vVar)


    vStrings = hierarchy.newVariable('browStrings', 'FName', bArray=True)
    sSetVar = nodes.createSetVariableExecuteNode(vStrings, None)
    pins.setStringArray(['b%02d' % i for i in range(iCount)], '%s.Value' % sSetVar)
    vBrowVariables.append(vStrings)
    controllers.setNewColumn()


