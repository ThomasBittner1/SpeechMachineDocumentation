###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import os
import sys

sys.path.append(os.path.dirname(__file__))
sys.path.append(CONTROLRIGFOLDER) #r'C:\toolsRoot\kangaroo\main\scripts\controlRig')

import pins
import nodes
import functions
import hierarchy
import library
import importlib
import controllers
import time
import traceback
import unrealUI
from collections import OrderedDict, defaultdict

ELEM = library.getElementKey



for mod in [pins, nodes, functions, hierarchy, library, controllers, unrealUI]:
    importlib.reload(mod)



openBlueprints = unreal.ControlRigBlueprint.get_currently_open_rig_blueprints()
if len(openBlueprints) > 1:
    raise Exception('there are more than one blueprints open')
blueprint = openBlueprints[0]
controllers.updateAsset(blueprint)

blueprint.set_auto_vm_recompile(False)


# # why does this not work? https://docs.unrealengine.com/5.0/en-US/PythonAPI/class/ControlRigBlueprint.html?highlight=controlrigblueprint#unreal.ControlRigBlueprint
# displaySettings = blueprint.rig_graph_display_settings()
# print('current limit: ', displaySettings.node_run_limit)



eOrigin = hierarchy.createNull('origin')
hierarchy.setOrigin(eOrigin)
# nodes.updateTopGroups(eOrigin)

print ('finished updating top groups')




