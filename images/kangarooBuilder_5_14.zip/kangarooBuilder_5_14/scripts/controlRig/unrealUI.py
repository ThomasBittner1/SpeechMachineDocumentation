###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import sys
import os
import subprocess
import time
from functools import partial  # if you want to include args with UI method calls
try:
    from PySide6 import QtGui, QtWidgets, QtCore
except:
    from PySide2 import QtGui, QtWidgets, QtCore

'''
started with template from:
https://dev.epicgames.com/community/learning/tutorials/mJaO/unreal-engine-unreal-pyqt-sample-ui-template

'''

# qProgress = None

qWindow = None

class UnrealUITemplate(QtWidgets.QWidget):
    """
    Create a default tool window.
    """
    # store ref to window to prevent garbage collection
    # window = None

    def __init__(self, parent=None, runCallback=None, iProgressCount=10):
        """
        Import UI and connect components
        """
        super(UnrealUITemplate, self).__init__(parent) #, QtCore.Qt.WindowStaysOnTopHint)
        # load the created UI widget
        self.widget = QtWidgets.QWidget()
        # attach the widget to the instance of this class (aka self)
        self.widget.setParent(self)
        self.qLayout = QtWidgets.QVBoxLayout()
        self.widget.setLayout(self.qLayout)
        self.qLabel = QtWidgets.QLabel('Kangaroo Unreal Control Rig Build')
        self.qLayout.addWidget(self.qLabel)

        self.qBrowser = QtWidgets.QTextBrowser()
        self.qLayout.addWidget(self.qBrowser)


        self.qBrowser.setOpenLinks(False)
        self.qBrowser.setReadOnly(True)
        self.qBrowser.anchorClicked.connect(self.handle_links)
        # self.addLogText('test: "test/python.py" hmmm')
        self.qBrowser.append('....')



        self.qProgress = QtWidgets.QProgressBar()
        self.qProgress.setRange(0, iProgressCount)
        self.qProgress.setValue(0)
        self.qLayout.addWidget(self.qProgress)
        self.resize(1500, 300)

        QtCore.QTimer.singleShot(10, runCallback)
        self.fTimeSinceLastLog = None

    def addToEnd(self, sText):
        qTextCursor = self.qBrowser.textCursor()
        qTextCursor.movePosition(QtGui.QTextCursor.End)
        qTextCursor.insertText(sText)


    def addLogText(self, sText, bQuotationsToLink=True, bPrint=False, bLogTimeWhenDone=True):
        if bPrint:
            print('addLogText: ', sText)

        if self.fTimeSinceLastLog != None:
            self.addToEnd('  (%0.3f seconds)' % (time.time()-self.fTimeSinceLastLog))

        sLines = sText.split('\n')
        sCommaLine = ', line'

        if bQuotationsToLink:
            for l,sLine in enumerate(sLines):
                iFirstQuotation = sLine.find('"', 0)
                if iFirstQuotation != -1:
                    iSecondQuotation = sLine.find('"', iFirstQuotation+1)
                    if iSecondQuotation != -1:
                        sFilePath = sLine[iFirstQuotation+1:iSecondQuotation]
                        if '/' in sFilePath or '\\' in sFilePath:
                            sLink = sFilePath
                            iCommaLine = sLine.find(sCommaLine, iSecondQuotation)

                            if iCommaLine != -1:
                                iNumberStart = iCommaLine + len(sCommaLine)
                                iNumberEnd = sLine.find(',', iNumberStart)
                                if iNumberEnd == -1:
                                    iNumberEnd = len(sLine)
                                sNumber = sLine[iNumberStart:iNumberEnd].strip()
                                sLink = '%s@%s' % (sLink, sNumber)

                            sLines[l] = '%s<a href="%s"> "%s" </a>%s' % (sLine[:iFirstQuotation], sLink.replace('\\','/'), sFilePath, sLine[iSecondQuotation+1:])

        for sLine in sLines:
            self.qBrowser.append(sLine)

        self.fTimeSinceLastLog = time.time() if bLogTimeWhenDone else None



    def handle_links(self, qLink):
        sLink = qLink.toString()
        print('sLink: ', sLink)
        sLinkSplits = sLink.split('@')
        if '.py' in sLink:
            openPycharm(sLinkSplits[0], iLine=None if len(sLinkSplits) < 2 else int(sLinkSplits[1]))
        else:
            openExplorer(os.path.dirname(sLink))


    def resizeEvent(self, event):
        """
        Called on automatically generated resize event
        """
        self.widget.resize(self.width(), self.height())

    def closewindow(self):
        """
        Close the window.
        """
        self.destroy()


def openWindow(runCallback, iProgressCount=10):
    """
    Create tool window.
    """
    if QtWidgets.QApplication.instance():
        # Id any current instances of tool and destroy
        for win in (QtWidgets.QApplication.allWindows()):
            if 'kangarooBuild' in win.objectName():
                win.destroy()
    else:
        QtWidgets.QApplication(sys.argv)

    # load UI into QApp instance
    global qWindow
    qWindow = UnrealUITemplate(runCallback=runCallback, iProgressCount=iProgressCount)
    qWindow.show()
    qWindow.setObjectName('kangarooBuild')  # update this with something unique to your tool
    qWindow.setWindowTitle('Kangaroo Build')
    unreal.parent_external_window_to_slate(qWindow.winId())


# openWindow()

def incrementProgress():
    global qWindow
    qWindow.qProgress.setValue(qWindow.qProgress.value() + 1)


def logMessage(sError, bLogTimeWhenDone=True):
    global qWindow
    qWindow.addLogText(sError, bLogTimeWhenDone=bLogTimeWhenDone)



def openPycharm(sFilePath, iLine):
    sPycharm = r'C:\Program Files\JetBrains\PyCharm Community Edition 2023.3.2\bin\pycharm64.exe'
    if iLine == None:
        sPassArguments = [sPycharm, sFilePath]
    else:
        sPassArguments = [sPycharm, '--line', '%03d' % (iLine), sFilePath]

    subprocess.Popen(sPassArguments, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)



def openExplorer(sLocation):
    print('open explorer: %s' % sLocation)

    if '.' in sLocation:
        sLocation = os.path.dirname(sLocation)

    for i in range(10):
        if not os.path.exists(sLocation):
            sLocation = os.path.join(sLocation, os.pardir)

    sLocation = os.path.abspath(sLocation)

    subprocess.call(['explorer', sLocation])
