###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import library

blueprint = None
vmModels = []
library_controller = None
hierarchy_controller = None
function_blueprint = None
function_library = None



BLOCK_BRANCH_TRUE = True
BLOCK_BRANCH_FALSE = True
BLOCK_FOREACH = True

def updateAsset(inBlueprint):
    global blueprint
    global vmModel
    global library_controller
    global hierarchy_controller
    global function_blueprint
    global function_library
    blueprint = inBlueprint
    vmModels.append(blueprint.get_controller_by_name('RigVMModel'))

    function_library = blueprint.get_local_function_library()
    library_controller = blueprint.get_controller(function_library)
    hierarchy_controller = blueprint.hierarchy.get_controller()
    function_blueprint = unreal.load_object(name='/ControlRig/StandardFunctionLibrary/StandardFunctionLibrary.StandardFunctionLibrary', outer=None)

    global functionStacks
    functionStacks = [[functionData(None, iSolver=0, sExecuteStart='RigUnit_BeginExecution.ExecuteContext')],
                      [functionData(None, iSolver=1, sExecuteStart='RigUnit_InverseExecution.ExecuteContext')]]


__iCurrentSolver__ = 0



fTopNodeDefaults = [0,-3000, 0]
fCommentsBoxBorderSize = 50
class functionData():
    def __init__(self, sFunctionName, bMutable=True, bSequencer=False, iSolver=0, sExecuteStart='Entry.ExecuteContext', xInputs=[], xOutputs=[]):
        self.sFunctionName = sFunctionName
        self.sSequencer = True if bSequencer else None
        self.uLastSequencerPlug = None
        self.iCurrentSequencerPlugCount = 0
        self.iCurrentNodePos = [0, fTopNodeDefaults[iSolver]]
        self.iTopNodePos = fTopNodeDefaults[iSolver]
        self.iMaximumHeight = 0
        self.fLastNodeSize = (0, 0)
        self.fGap = 100
        self.bNextIsNewColumn = True
        self.bMutable = bMutable
        self.dCommentBoxesNodePoints = {}
        self.vmModel = blueprint.get_controller_by_name('RigVMModel')

        self.dInputs = {xI[0]:(xI[1], xI[2]) for xI in xInputs}
        self.dOutputs = {xI[0]:(xI[1], xI[2]) for xI in xOutputs}

        if bMutable:
            self.sLastExecutes = [sExecuteStart]


    def openCommentBox(self, sComment):
        self.dCommentBoxesNodePoints[sComment] = []


    def closeCommentBox(self, sComment, fColor=[0.25, 0.25, 0.25]):

        if sComment not in self.dCommentBoxesNodePoints:
            raise Exception('Invalid comment, possible comments in this function are "%s"' % ', '.join(list(self.dCommentBoxesNodePoints.keys())))

        ffNodesPoints = self.dCommentBoxesNodePoints[sComment]
        if len(ffNodesPoints):
            fAllX = [fPos[0] for fPos in ffNodesPoints]
            fAllY = [fPos[1] for fPos in ffNodesPoints]

            fSmallestX = min(fAllX)
            fSmallestY = min(fAllY)

            fSizeX = max(fAllX) - fSmallestX
            fSizeY = max(fAllY) - fSmallestY

            self.vmModel.add_comment_node(sComment,
                                     unreal.Vector2D(fSmallestX - fCommentsBoxBorderSize, fSmallestY - fCommentsBoxBorderSize),
                                     unreal.Vector2D(fSizeX + fCommentsBoxBorderSize*2, fSizeY + fCommentsBoxBorderSize*2),
                                     unreal.LinearColor(fColor[0], fColor[1], fColor[2], 0.2), 'EdGraphNode_Comment', setup_undo_redo=False)

        del self.dCommentBoxesNodePoints[sComment]


    def recordNodeForCommentsBox(self, vmNode, fEstimatedSize=[200,200]):
        uPos = vmNode.get_position()
        for sComment in list(self.dCommentBoxesNodePoints.keys()):
            self.dCommentBoxesNodePoints[sComment].append([uPos.x, uPos.y])
            self.dCommentBoxesNodePoints[sComment].append([uPos.x + fEstimatedSize[0], uPos.y + fEstimatedSize[1]])


functionStacks = None

def openCommentBox(sComment):
    functionStacks[__iCurrentSolver__][-1].openCommentBox(sComment)

def closeCommentBox(sComment):
    functionStacks[__iCurrentSolver__][-1].closeCommentBox(sComment)

def recordNodeForCommentBox(vmNode, fEstimatedSize=[200,200]):
    functionStacks[__iCurrentSolver__][-1].recordNodeForCommentsBox(vmNode, fEstimatedSize)



def setNewColumn(fInNextColumnGapFactor=1.0):
    FD = functionStacks[__iCurrentSolver__][-1]
    FD.bNextIsNewColumn = True
    FD.fNextColumnGapFactor = fInNextColumnGapFactor


def latestFD():
    return functionStacks[__iCurrentSolver__][-1]



def goToParentExecute():
    FD = functionStacks[__iCurrentSolver__][-1]
    del FD.sLastExecutes[-1]
