###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import unreal
import math
import string
from collections import OrderedDict

blueprint = None
vmModel = None
def updateAsset(sAsset):
    global blueprint
    global vmModel
    blueprint = unreal.load_object(name=sAsset, outer=None)
    vmModel = blueprint.get_controller_by_name('RigVMModel')



dElementTypes = {}
dElementTypes['Control'] = unreal.RigElementType.CONTROL
dElementTypes['Bone'] = unreal.RigElementType.BONE
dElementTypes['Null'] = unreal.RigElementType.NULL

dElementTypeStrings = {}
dElementTypeStrings[unreal.RigElementType.CONTROL] = 'Control'
dElementTypeStrings[unreal.RigElementType.BONE] = 'Bone'
dElementTypeStrings[unreal.RigElementType.NULL] = 'Null'

dFilteredChannels = OrderedDict()
dFilteredChannels['TRANSLATION_X'] = unreal.RigControlTransformChannel.TRANSLATION_X
dFilteredChannels['TRANSLATION_Y'] = unreal.RigControlTransformChannel.TRANSLATION_Y
dFilteredChannels['TRANSLATION_Z'] = unreal.RigControlTransformChannel.TRANSLATION_Z
dFilteredChannels['PITCH'] = unreal.RigControlTransformChannel.PITCH
dFilteredChannels['ROLL'] = unreal.RigControlTransformChannel.ROLL
dFilteredChannels['YAW'] = unreal.RigControlTransformChannel.YAW
dFilteredChannels['SCALE_X'] = unreal.RigControlTransformChannel.SCALE_X
dFilteredChannels['SCALE_Y'] = unreal.RigControlTransformChannel.SCALE_Z
dFilteredChannels['SCALE_Z'] = unreal.RigControlTransformChannel.SCALE_Y

dColors = {}
dColors['m'] = [1,1,0]
dColors['l'] = [0,0,1]
dColors['r'] = [1,0,0]

def convertTranslation(fTranslation):
    return [fTranslation[0], fTranslation[2], fTranslation[1]]

sSides = ['l','r']
dSides3 = {'l':'LFT', 'r':'RGT'}
dSidesFull = {'l':'Left', 'r':'Right'}

dOperators = {}
dOperators['>'] = 'Greater'
dOperators['>='] = 'GreaterEqual'
dOperators['<'] = 'Less'
dOperators['<='] = 'LessEqual'
dOperators['=='] = 'Equal'



dCppTypes = {}
dCppTypes['FVector'] =  '/Script/CoreUObject.Vector'
dCppTypes['FRigElementKey'] = '/Script/ControlRig.RigElementKey'
dCppTypes['FConstraintParent'] =  '/Script/ControlRig.ConstraintParent'
dCppTypes['FTransform'] =  '/Script/CoreUObject.Transform'
dCppTypes['FControlRigSpline'] =  '/Script/ControlRigSpline.ControlRigSpline'
dCppTypes['FQuat'] =  '/Script/CoreUObject.Quat'





def getElementKey(sName, sType):
    return unreal.RigElementKey(type=dElementTypes[sType], name=sName)

ffUnityMatrix = [[1,0,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1]]


def getTrsFromListMatrix(ffMatrix):
    uMatrix = unreal.Matrix(ffMatrix[0], ffMatrix[1], ffMatrix[2], ffMatrix[3])
    fTranslation = uMatrix.get_origin()
    fRotation = uMatrix.get_rotator()
    fScale = uMatrix.get_scale_vector()
    return fTranslation, fRotation, fScale


def getStringInQuota(sMainString):
    sSplits = sMainString.split('\'')
    sName = sSplits[1].split('.')[-1]
    return sName


def getFirstLetterUpperCase(sText):
    if not sText:
        return ''
    elif len(sText) == 1:
        return sText.upper()
    else:
        return '%s%s' % (sText[0].upper(), sText[1:])


def getLetter(iIndex, bLower=False):
    sLetter = string.ascii_lowercase[iIndex]
    if bLower:
        return sLetter
    else:
        return sLetter.upper()


def flattenedList(ssList):
    def _flattenREC(xObj, xResultList):
        if isinstance(xObj, (list,tuple)):
            for sO in xObj:
                _flattenREC(sO, xResultList)
        else:
            xResultList.append(xObj)
    sReturnList = []
    _flattenREC(ssList, sReturnList)
    return sReturnList



def isNone(xVariable):
    return isinstance(xVariable, type(None))


def matrixFromSize(fSize=1.0):
    return [[fSize, 0, 0, 0], [0, fSize, 0, 0], [0, 0, fSize, 0], [0, 0, 0, 1]]



def bSpline4(fFourValues, fValues):
    fOutValues = []
    for a in fValues:
        fResult =   fFourValues[0] * pow(1-a, 3) + \
                    fFourValues[1] * 3 * a * pow(1-a,2) + \
                    fFourValues[2] * 3 * pow(a,2) * (1-a) + \
                    fFourValues[3] * pow(a, 3)
        fOutValues.append(fResult)
    return fOutValues


def calculateCrossProduct(a, b):
    result = [a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0]]
    return result


def secondsNice(fSeconds):
    iMinutes = math.floor(fSeconds / 60.0)
    sTime = ''
    if iMinutes == 1:
        fSeconds = fSeconds % 60.0
        sTime = '1 minute and '
    elif iMinutes > 1:
        fSeconds = fSeconds % 60.0
        sTime = '%d minutes and ' % iMinutes

    sTime += '%d seconds' % round(fSeconds)
    return sTime




def replaceStringStart(sText, sSearch, sReplace):
    if sText.startswith(sSearch):
        return '%s%s' % (sReplace, sText[len(sSearch):])
    else:
        return sText

def replaceStringEnd(sText, sSearch, sReplace):
    if sText.endswith(sSearch):
        return '%s%s' % (sText[:-len(sSearch)], sReplace)
    else:
        return sText

