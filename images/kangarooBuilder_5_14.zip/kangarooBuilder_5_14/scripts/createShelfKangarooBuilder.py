###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from maya import cmds
import os
import sys


kPythonVersion = int(sys.version[0])




def absIconPath(sFileName):
    sFile = __file__
    return os.path.join(os.path.dirname(sFile), 'icons', sFileName)



def createShelf():
    print('create shelf inside createShelf.py...')
    sLayoutName = 'KangarooBuilder'
    if cmds.shelfLayout(sLayoutName, ex=True):
        if cmds.shelfLayout(sLayoutName, q=True, ca=True):
            for child in cmds.shelfLayout(sLayoutName, q=True, ca=True):
                cmds.deleteUI(child)
    else:
        cmds.shelfLayout(sLayoutName, p="ShelfLayout")


    sUiButton = cmds.shelfButton(olb=[0,0,0,0], olc=[0,0,0], ann='toggle UI', p=sLayoutName, c=sToggleUI, i=absIconPath('shelf_UI.jpg'), noDefaultPopup=True)
    sUiMenu = cmds.popupMenu(parent=sUiButton, button=3)
    cmds.menuItem(label="open with reload", sourceType="python", parent=sUiMenu, command=sShowUiScriptReload)

    sReopenButton = cmds.shelfButton(iol='reOp', ann='reopen current scene', p=sLayoutName, c=sReopenCurrentScene, i='pythonFamily.png', noDefaultPopup=True)
    sReopenMenu = cmds.popupMenu(parent=sReopenButton, button=3)
    cmds.menuItem(label="Copy Path to Clipboard", sourceType="python", parent=sReopenMenu, command='import kangarooTools.utilFunctions as utils; utils.copyFilePathToClipboard()')


    cmds.shelfButton(iol='mirror', olb=[0,0,0,0], olc=[0,0,0], ann='mirror', p=sLayoutName, c=sMirrorJoints, i=absIconPath('shelf_joint.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='orient', olb=[0,0,0,0], olc=[0,0,0], ann='orient joints', p=sLayoutName, c=sReorientJoints, i=absIconPath('shelf_joint.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='orientH', olb=[0,0,0,0], olc=[0,0,0], ann='orient joint hierarchy', p=sLayoutName, c=sReorientJointHierarchies, i=absIconPath('shelf_joint.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='skin', ann='create skinCluster', p=sLayoutName, c=sCreateSkinCluster, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='cls', ann='create cluster', p=sLayoutName, c=sCreateCluster, i='pythonFamily.png', noDefaultPopup=True)

    cmds.shelfButton(iol='', ann='create debug cubes', p=sLayoutName, c=sDebugCubes, i=absIconPath('shelf_cube.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='', ann='create and connect Locator to node', p=sLayoutName, c=nodeLocator, i=absIconPath('shelf_locator.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='+C+', ann='bigger ctrls', p=sLayoutName, c="import kangarooTabTools.geometry as geometry; geometry.scaleSelectedCurves(1.1)", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='-C-', ann='smaller ctrls', p=sLayoutName, c="import kangarooTabTools.geometry as geometry; geometry.scaleSelectedCurves(0.9)", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='selCVs', ann='select all cvs', p=sLayoutName, c=sSelectAllCvs, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='+P+', ann='bigger planes', p=sLayoutName, c="import kangarooTabTools.geometry as geometry; geometry.scaleSelectedPlanes(1.1)", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='-P-', ann='smaller planes', p=sLayoutName, c="import kangarooTabTools.geometry as geometry; geometry.scaleSelectedPlanes(0.9)", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='+allJ+', ann='scale all joint radius', p=sLayoutName, c='import kangarooTools.xforms as xforms; xforms.scaleAllJointRadius(1.1)', i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='-allJ-', ann='scale all joint radius', p=sLayoutName, c='import kangarooTools.xforms as xforms; xforms.scaleAllJointRadius(0.9)', i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='+selT+', ann='scale all joint radius', p=sLayoutName, c='import kangarooTools.xforms as xforms; xforms.scaleSelectedTranslations(1.1)', i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='+selS+', ann='scale all joint radius', p=sLayoutName, c='import kangarooTools.xforms as xforms; xforms.scaleSelectedScales(1.1)', i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='', ann='cmds.ToggleLocalRotationAxes()', p=sLayoutName, c='cmds.ToggleLocalRotationAxes()', i=absIconPath('shelf_rotVis.jpg'), noDefaultPopup=True)

    cmds.shelfButton(iol='copy', olb=[0,0,0,0], olc=[0,0,0], ann='copy selection', p=sLayoutName, c=sCopySel, i=absIconPath('shelf_SEL.jpg'), noDefaultPopup=True)
    sUiButton = cmds.shelfButton(iol='paste', olb=[0,0,0,0], olc=[0,0,0], ann='paste selection', p=sLayoutName, c=sPasteSel % 'pasteSel', i=absIconPath('shelf_SEL.jpg'), noDefaultPopup=True)
    pasteSelMenu = cmds.popupMenu(parent=sUiButton, button=3)
    for sName, sFunc in [('add', 'pasteSelAdd'), ('add first', 'pasteSelAddFirst'), ('deselect', 'pasteSelDeselect')]:
        cmds.menuItem(label=sName, sourceType="python", parent=pasteSelMenu, command=sPasteSel % sFunc)
    cmds.shelfButton(iol='print', olb=[0,0,0,0], olc=[0,0,0], ann='print the selection nicely and copies it to clipboard', p=sLayoutName, c="import kangarooTools.utilFunctions as utils; utils.printSelectedList(True)", i=absIconPath('shelf_SEL.jpg'), noDefaultPopup=True)
    sMirrorSelectionButton = cmds.shelfButton(iol='Mirror', olb=[0,0,0,0], olc=[0,0,0], ann='Mirrors Selection', p=sLayoutName, c="import kangarooTools.utilFunctions as utils; utils.selectMirrors()", i=absIconPath('shelf_SEL.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='Siblings', olb=[0,0,0,0], olc=[0,0,0], ann='Selects Sibling Joints', p=sLayoutName, c=sSelectSpline, i=absIconPath('shelf_SEL.jpg'), noDefaultPopup=True)
    sDefPoseMenu = cmds.popupMenu(parent=sMirrorSelectionButton, button=3)
    cmds.menuItem(label="Add Select", sourceType="python", parent=sDefPoseMenu, command="import kangarooTools.utilFunctions as utils; utils.selectMirrors(bAdd=True)")



    cmds.shelfButton(iol='bakeBS', ann='bake blendshapes', p=sLayoutName, c="import kangarooTools.deformers as deformers; deformers.bakeBlendShapesSelection()", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='o skin', olb=[0,0,0,0], olc=[0,0,0], ann='deletes all skinClusters except selected', p=sLayoutName, c='import kangarooTools.deformers as deformers; deformers.deleteOtherSkinClusters()', i=absIconPath('shelf_delete.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='unknown', olb=[0,0,0,0], olc=[0,0,0], ann='delete all unknown nodes', p=sLayoutName, c=sDeleteUnknownNodes, i=absIconPath('shelf_delete.jpg'), noDefaultPopup=True)
    cmds.shelfButton(iol='cutTop', ann='retopologize head', p=sLayoutName, c=sReTopologizeHead, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='pickUI', ann='show rig anim tool', p=sLayoutName, c=sShowRigAnimTool, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='shapeE', ann='show shape tool', p=sLayoutName, c=sShowRigShapeTool, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='skinE', ann='create skinCluster', p=sLayoutName, c=sSkinWeightsEditor, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='aMP4', ann='Playblast to Mp4', p=sLayoutName, c=sPlayblastScript,
                     menuItem=[('no sound', sPlayblastScriptNoAudio), ('just sound', sPlayblastScriptJustAudio)], menuItemPython=[0,1], i='pythonFamily.png', noDefaultPopup=True)
    sDefPoseButton = cmds.shelfButton(iol='', ann='Go to Default Pose', p=sLayoutName, c="import kangarooAnimation.KangarooMatchTools as KangarooMatchTools; KangarooMatchTools.goToDefaultPoseSelected(bSkipFk2IkAttrs=True)", i=absIconPath('shelf_default.jpg'), noDefaultPopup=True)
    sDefPoseMenu = cmds.popupMenu(parent=sDefPoseButton, button=3)
    cmds.menuItem(label="Including Switch Attributes", sourceType="python", parent=sDefPoseMenu, command="import kangarooAnimation.KangarooMatchTools as KangarooMatchTools; KangarooMatchTools.goToDefaultPoseSelected(bSkipFk2IkAttrs=False)")
    cmds.menuItem(label="Delete Animation", sourceType="python", parent=sDefPoseMenu, command="import kangarooAnimation.KangarooMatchTools as KangarooMatchTools; KangarooMatchTools.goToDefaultPoseSelected(bDeleteAnim=True)")
    cmds.menuItem(label="Delete Animation Keep Pose", sourceType="python", parent=sDefPoseMenu, command="import kangarooAnimation.KangarooMatchTools as KangarooMatchTools; KangarooMatchTools.goToDefaultPoseSelected(bDeleteAnim=True, bKeepPoseOnDeleteAnim=True)")

    
    cmds.shelfButton(iol='resRefB', ann='Reset Bind Pose', p=sLayoutName, c="import kangarooTools.deformers as deformers; deformers.resetJointReferences(cmds.ls(et='joint'))", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='iOBJ', ann='import objs from folder', p=sLayoutName, c="import kangarooTabTools.export as export; export.importObjsUI()", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='speech', ann='Speech-Machine UI', p=sLayoutName, c=sSpeechMachineReload, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='faceSkn', ann='Painting tools for Face', p=sLayoutName, c=sPaintFaceTool, i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='Parallel', ann='Toggle Parallel', p=sLayoutName, c="import kangarooTools.utilFunctions as utils; utils.toggleEval()", i='pythonFamily.png', noDefaultPopup=True)
    sUndoButton = cmds.shelfButton(iol='flushU', ann='Flush Undo', p=sLayoutName, c="import kangarooTools.utilFunctions as utils; utils.flushUndo()", i='pythonFamily.png', noDefaultPopup=True)
    sUndoMenu = cmds.popupMenu(parent=sUndoButton, button=3)
    cmds.menuItem(label="endless undos", sourceType="python", parent=sUndoMenu,  command='import kangarooTools.utilFunctions as utils; utils.undoUntilBreak()')
    cmds.shelfButton(iol='prSetAttr', ann='Print SetAttr Commands', p=sLayoutName, c="import kangarooTools.utilFunctions as utils; utils.clipBoardSetAttrCommands()", i='pythonFamily.png', noDefaultPopup=True)
    cmds.shelfButton(iol='selPssr', ann='Select Passers', p=sLayoutName, c="import kangarooTabTools.ctrls8 as ctrls8; ctrls8.selectPassers()", i='pythonFamily.png', noDefaultPopup=True)



sReopenCurrentScene = 'sFilePath = cmds.file(q=True, l=True)[0]; cmds.file(sFilePath, o=True, f=True)'
sToggleUI = "import kangarooTools.UI2 as UI; UI.toggleCollapsed()" if kPythonVersion == 2 else "import kangarooTools.UI3 as UI; UI.toggleCollapsed()"
sMirrorJoints = "import kangarooTools.xforms as xforms; xforms.mirrorJointsSelection();"
sReorientJoints = "import kangarooTools.xforms as xforms; xforms.reorientJoints(cmds.ls(sl=True, et='joint'));"
sReorientJointHierarchies = "import kangarooTools.xforms as xforms; xforms.reorientJoints(cmds.ls(sl=True, dag=True, et='joint'));"
sDebugCubes = "import kangarooTools.xforms as xforms; xforms.createDebugCubesSelection();"
sCopySel = "import kangarooTools.copyPasteSel as copyPasteSel; copyPasteSel.copySel()"
sPasteSel = "import kangarooTools.copyPasteSel as copyPasteSel; copyPasteSel.%s()"
nodeLocator = "import kangarooTools.nodes as nodes; sSel=cmds.ls(sl=True); nodes.createMatrixDebugLocator(sSel)"
sShowRigAnimTool = "import kangarooAnimation.KangarooAnimTool as KangarooAnimTool; KangarooAnimTool.showUI(False)"
sShowRigShapeTool = "import kangarooShapeEditor.kangarooShapeEditorUI as kangarooShapeEditorUI; kangarooShapeEditorUI.showUI()"
sSelectAllCvs = "import kangarooTools.curves; kangarooTools.curves.selectAllCvsSelected(bIncludeSurfaces=True)"
sCreateCluster = "import kangarooTools.deformers as deformers; deformers.clusterSel()"
sReTopologizeHead = "import kangarooTabTools.geometry as geometry; geometry.cutResetTopologySelectedFaces()"
sPlayblastScript = "import kangarooTabTools.export as export; export.playblastMov(sFile=None, bOpenWhenDone=True)"
# sPlayblastScriptUncompressed = "import kangarooTabTools.export as export; export.playblastMov(sFile=None, bOpenWhenDone=True, bUncompressed=True)"
sPlayblastScriptJustAudio = "import kangarooTabTools.export as export; export.playblastMov(sFile=None, bOpenWhenDone=True, bJustAudio=True)"
sPlayblastScriptNoAudio = "import kangarooTabTools.export as export; export.playblastMov(sFile=None, bOpenWhenDone=True, bNoAudio=True)"
sDeleteUnknownNodes = "sNodes = cmds.ls(et='unknown')+cmds.ls(et='unknownDag'); cmds.lockNode(sNodes, lock=False); cmds.delete(sNodes)"
sSkinWeightsEditor = "import kangarooTools.skinWeightsEditor as skinWeightsEditor; skinWeightsEditor.showUI()"
sSelectSpline = '''
import kangarooTools.utilFunctions as utils
utils.selectSelectionSiblingNodes()
'''

sCreateSkinCluster = '''
import kangarooTools.deformers as deformers
import kangarooTools.utilFunctions as utils
utils.reload2(deformers)
deformers.skinSel()
'''

sShowUiScriptReload = '''
import maya.cmds as cmds
if cmds.confirmDialog(message='Reloading everything can get messy. Are you sure you want this?', button=['yes','no']) == 'yes':
    import kangarooTools.assets as assets
    import kangarooTools.report as report
    import kangarooTools.utilFunctions as utils
    import kangarooTools.utilsQt as utilsQt
    import kangarooTools.settings as settings
    
    utils.reload2(utilsQt) # not working
    
    utils.reload2(report)
    utils.reload2(settings)

    if assets.assetManager:
        assets.assetManager.closeEvent()
    utils.reload2(assets)

    import kangarooTools.utilFunctions as utils
    utils.reload2(utils)
    
    import kangarooTools.uiSettings as uiSettings
    utils.reload2(uiSettings)
    
    import kangarooTools.puppetDataUtils as puppetDataUtils
    utils.reload2(puppetDataUtils)
    
    import kangarooTools.puppetAttrItems as puppetAttrItems
    utils.reload2(puppetAttrItems)
    
    import kangarooTools.controls as controls
    utils.reload2(controls)
    
    import kangarooTools.controlsPuppet as controlsPuppet
    utils.reload2(controlsPuppet)
    
    import kangarooTools.UI%d as UI;
    utils.reload2(UI)
    UI.toggleCollapsed()

''' % (2 if kPythonVersion == 2 else 3)


sSpeechMachineReload = \
'''
import kangarooTools.utilFunctions as utils

import speechMachine.speechMachine as speechMachine; 
utils.reload2(speechMachine)

import speechMachine.speechMachineUI as speechMachineUI; 
utils.reload2(speechMachineUI)
speechMachineUI.showUI()

'''


sPaintFaceTool = \
'''
import kangarooTools.faceSkinUI as faceSkinUI 
import importlib
importlib.reload(faceSkinUI)
faceSkinUI.openMouthPaintUI()
'''