###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import copy
from dataclasses import dataclass, field

from kangarooBatchTools.batchArgSync import arguments
from kangarooBatchTools.utilities import dict_filter

from PySide2 import QtCore


class Signals(QtCore.QObject):
    merge_module_into_slave = QtCore.Signal(str, str, int, int)
    export_puppet_data = QtCore.Signal(str, int)


@dataclass
class AppData:
    signals = Signals()

    master_asset: str
    assets_path: str
    assets_in_project: list[str]
    keys_to_ignore: list[str] = field(default_factory=list)

    master_module_names: list[str] = field(default_factory=list)
    modules_to_compare: list[str] = field(default_factory=list)
    master_data: dict = field(default_factory=dict)
    slave_assets: list[str] = field(default_factory=list)
    slave_data: list[dict] = field(default_factory=list)

    slave_data_to_compare: list[dict] = field(default_factory=list)
    master_data_to_compare: dict = field(default_factory=dict)
    slave_filter_list: list[dict] = field(default_factory=list)
    global_filter: dict = field(default_factory=dict)
    merged_data_to_compare: dict = field(default_factory=list)

    merged_merge_data: dict = field(default_factory=dict)
    slave_merge_filter: list = field(default_factory=list)
    slave_merged_data: list = field(default_factory=list)
    slave_merged_files: list = field(default_factory=list)

    def get_all_active_assets(self) -> list[str]:
        """
        Returns the master asset plus the slave assets
        Returns:

        """
        return [self.master_asset] + self.slave_assets

    def calculate_master_data(self):
        """
        Loads the master data from file
        Returns:

        """
        self.master_data = arguments.load_build_data_from_file(self.assets_path, self.master_asset)

    def get_possible_slave_assets(self) -> list[str]:
        return [a for a in self.assets_in_project if a != self.master_asset]

    def get_modul_names(self):
        return self.master_data[arguments.FUNCTIONS_KEY].keys()

    def get_data_to_compare(self, data: dict) -> dict:
        return {k: v for k, v in data.items() if k in self.modules_to_compare}

    def get_all_compare_data(self):
        return [self.master_data_to_compare] + self.slave_data_to_compare

    def get_global_filter(self):
        """
        Returns the global filter, every asset gets compared to
        Returns:

        """
        ret = dict_filter.get_merged_data_from_list(self.slave_filter_list, True)

        for key in self.keys_to_ignore:
            ret = dict_filter.remove_key_from_dict(ret, key)
        return ret

    def get_slave_filter_list(self):
        """
        Returns a list with a filter for every slave asset
        Returns:

        """
        data = [dict_filter.get_equal_dict(self.master_data_to_compare, d) for d in self.slave_data_to_compare]
        data = [dict_filter.get_compressed_delta_dict(d) for d in data]
        return data

    def get_file_names_from_file_data(self, data: list) -> list[str]:
        """

        Args:
            data:

        Returns:

        """
        return [d[0].split("_v")[0] for d in data]

    def calculate_slave_merge_filter_list(self):
        """
        Returns the merged merge data and split by asset
        Returns:

        """
        ret = list()
        for asset_index, asset_name in enumerate(self.slave_assets):
            merge_filter = dict_filter.split_merged_module_data(self.merged_merge_data, asset_index)
            merge_filter = dict_filter.remove_with_value_from_dict(merge_filter, False)
            merge_filter = dict_filter.remove_empty_from_dict(merge_filter)
            ret.append(merge_filter)

        self.slave_merge_filter = ret

    def calculate_compare_data(self):
        self.slave_data = [arguments.load_build_data_from_file(self.assets_path, a) for a in self.slave_assets]
        self.slave_data_to_compare = [self.get_data_to_compare(d[arguments.FUNCTIONS_KEY]) for d in self.slave_data]
        self.master_data_to_compare = self.get_data_to_compare(self.master_data[arguments.FUNCTIONS_KEY])
        self.slave_filter_list = self.get_slave_filter_list()
        self.global_filter = self.get_global_filter()
        self.merged_data_to_compare = dict_filter.merge_module_data(self.global_filter, self.get_all_compare_data())

    def merge_master_into_slaves(self):
        self.slave_merged_data = []
        self.slave_merged_files = []

        master_func_data = self.master_data[arguments.FUNCTIONS_KEY]
        master_file_data = self.master_data[arguments.FILES_KEY]

        filtered_master_files = [(n, d) for n, d in master_file_data if not n.startswith(self.master_asset)]
        master_file_names = self.get_file_names_from_file_data(filtered_master_files)

        for s_asset, s_data, s_filter in zip(
                self.slave_assets,
                self.slave_data,
                self.slave_merge_filter
        ):

            slave_func_data = s_data[arguments.FUNCTIONS_KEY]
            merged_data = dict_filter.merge_master_into_slave(s_filter, master_func_data, slave_func_data)
            self.slave_merged_data.append(merged_data)
            self.signals.merge_module_into_slave.emit(s_asset, "Arguments", 0, 0)

            slave_file_data = s_data[arguments.FILES_KEY]
            slave_file_names = self.get_file_names_from_file_data(slave_file_data)

            merged_files = []
            for i, name in enumerate(slave_file_names):
                if name in master_file_names:
                    continue

                merged_files.append(s_data[arguments.FILES_KEY][i])

            merged_files.extend(filtered_master_files)
            self.slave_merged_files.append(merged_files)
            self.signals.merge_module_into_slave.emit(s_asset, "Files", 0, 0)

    def export_slave_data(self):
        """
        Saves the merged slave data to file
        Returns:

        """

        for asset_index, (name, og_data, merged_files, merged_data, sl_filter) in enumerate(
                zip(
                    self.slave_assets,
                    self.slave_data,
                    self.slave_merged_files,
                    self.slave_merged_data,
                    self.slave_merge_filter
                )):
            if not sl_filter:
                continue

            export_data = copy.deepcopy(og_data)
            export_data[arguments.FILES_KEY] = merged_files
            export_data[arguments.FUNCTIONS_KEY] = merged_data
            arguments.export_data(self.assets_path, name, export_data)

            self.signals.export_puppet_data.emit(name, asset_index)

    def get_slaves_without_changes(self) -> list[str]:
        return [name for name, _filter in zip(self.slave_assets, self.slave_merge_filter) if not _filter]
