###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import json

from kangarooBatchTools.utilities.kangaroo_wrappers import assets

import os

BUILD_FILE_NAME = "build.bld"
FILES_KEY = "__FILES__"
FUNCTIONS_KEY = "__FUNCTIONDATAS__"
SELECTION_TEMPLATE = "dSelectionTemplates"
FUNCTION_COUNTS = "dFuncCounts"


def get_build_file_path(asset_folder: str, asset_name: str):
    asset_path = assets.get_asset_version_path(asset_folder, asset_name, -1)
    return os.path.join(asset_path, BUILD_FILE_NAME)


def load_build_data_from_file(asset_folder: str, asset_name: str) -> dict:
    build_file_path = get_build_file_path(asset_folder, asset_name)

    with open(build_file_path, "r") as fp:
        data = json.load(fp)

    return prep_data_after_import(data)


def flatten_data(data: dict) -> dict:
    return {k: d[0] for k, d in data.items()}


def unflatten_data(data: dict) -> dict:
    return {k: [d] for k, d in data.items()}


def prep_data_after_import(data: dict) -> dict:
    data[FUNCTIONS_KEY] = flatten_data(data[FUNCTIONS_KEY])
    return data


def prep_data_for_export(data) -> dict:
    data[FUNCTIONS_KEY] = unflatten_data(data[FUNCTIONS_KEY])
    return data


def export_data(asset_folder: str, asset_name: str, data: dict):
    build_file_path = get_build_file_path(asset_folder, asset_name)

    with open(build_file_path, "w") as fp:
        json.dump(prep_data_for_export(data), fp)
