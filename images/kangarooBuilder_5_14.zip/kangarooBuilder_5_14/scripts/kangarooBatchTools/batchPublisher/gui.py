###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import time

from PySide2 import QtCore
from PySide2.QtWidgets import *
import os

from kangarooBatchTools.utilities.kangaroo_wrappers import assets
from kangarooBatchTools.utilities.widgets import output_dialog
from kangarooBatchTools.utilities.widgets import item_selector
from kangarooBatchTools.utilities.widgets import preset_selector
from kangarooBatchTools.utilities.widgets import line

from kangarooBatchTools.utilities.widgets import maya_dialog
from kangarooBatchTools.batchPublisher import core

# TODO: the project and preset path need to be set. we store it on m:projects...mtp/.../rig/_presets/tools/TOOL_NAME
TOOL_NAME = "Batch Publisher"
# PROJECT_PATH = os.path.normpath(r"U:\projects\hs3\work\source\assets\rig\thomas.bittner\__HS3__")
# PRESET_PATH = os.path.join(PROJECT_PATH, "_presets", "tools", TOOL_NAME)


def show(sProjectPath):
    global my_window

    try:
        my_window.close()  # Close existing window if open
        my_window.deleteLater()
    except:
        pass

    app_data = core.App()
    app_data.assets_in_project = assets.get_assets_in_project(sProjectPath)

    my_window = CheckBoxDialog(app_data)
    my_window.show()


class CheckBoxDialog(QDialog):

    def __init__(self, app_data: core.App, parent=maya_dialog.get_maya_main_window()):
        super().__init__(parent)

        self.app_data = app_data
        self.settings = QtCore.QSettings("Rigging", TOOL_NAME)

        # Widgets
        # self.preset_selector = preset_selector.PresetFileSelector()
        # self.preset_selector.set_folder_path(PRESET_PATH)

        self.asset_selector = item_selector.ItemSelector()
        self.asset_selector.set_items(self.app_data.assets_in_project, False)

        self.message_dialog = output_dialog.MessageDialog(self, "Publish Log")

        self.comment_field = QTextBrowser(self)
        self.comment_field.setReadOnly(False)
        self.comment_field.setPlaceholderText("Comment")

        # self.force_arx_publish = QCheckBox(self)
        # self.force_arx_publish.setText("Force Arx Publish")
        # self.force_arx_publish.setChecked(True)

        self.publish_button = QPushButton("Publish")

        # Layout
        self.setWindowTitle(TOOL_NAME)
        self.resize(300, 800)

        data_widget = QWidget()
        data_widget.setLayout(QVBoxLayout())
        data_widget.layout().setContentsMargins(0, 0, 0, 0)
        data_widget.layout().addWidget(self.comment_field)
        # data_widget.layout().addWidget(self.force_arx_publish)

        selection_splitter = QSplitter(QtCore.Qt.Vertical)
        selection_splitter.setLayout(QVBoxLayout())
        selection_splitter.layout().addWidget(self.asset_selector)
        selection_splitter.layout().addWidget(data_widget)
        selection_splitter.setSizes([700, 100])
        # selection_splitter.layout().setContentsMargins(0,0,0,0)

        main_layout = QVBoxLayout(self)
        # main_layout.addWidget(self.preset_selector)
        main_layout.addWidget(line.HLine())
        main_layout.addWidget(selection_splitter)
        main_layout.addWidget(self.publish_button)

        self.load_settings()

        # signals
        self.publish_button.clicked.connect(self.publish)
        self.app_data.signals.publish_success.connect(self.asset_succeeded)
        self.app_data.signals.publish_fail.connect(self.asset_failed)
        # self.preset_selector.load_button.clicked.connect(self.load_preset)
        # self.preset_selector.add_button.clicked.connect(self.export_preset)

    def publish(self):
        asset_list = self.asset_selector.get_checked()
        comment = self.comment_field.toPlainText()
        force_publish = False # self.force_arx_publish.isChecked()

        self.message_dialog.show()
        self.message_dialog.reset()

        start_time = time.time()
        self.message_dialog.add_message("Start")

        self.app_data.run(
            asset_list=asset_list,
            comment=comment,
            force_publish=force_publish
        )

        self.message_dialog.add_message("\nSuccessful Assets")
        self.message_dialog.add_message("\n".join([f"- {asset}" for asset in self.app_data.successful_assets]))

        self.message_dialog.add_message("\nFailed Assets")
        self.message_dialog.add_message("\n".join([f"- {asset}" for asset in self.app_data.failed_assets]))

        self.message_dialog.add_message("\nFinish")
        self.message_dialog.add_message(f"- {(time.time() - start_time):.4f}s")

    def asset_succeeded(self, asset_name):
        self.message_dialog.add_message(f"- {asset_name} published")

    def asset_failed(self, asset_name):
        self.message_dialog.add_message(f"- {asset_name} failed")

    def load_settings(self):
        self.deserialize({k: self.settings.value(k) for k in self.settings.allKeys()})

    def save_settings(self):
        for k, v in self.serialize().items():
            self.settings.setValue(k, v)

    def load_preset(self):
        self.deserialize(self.preset_selector.get_data())

    def export_preset(self):
        self.preset_selector.export_data(self.serialize())

    def serialize(self) -> dict:
        """
        converts the storable data into a dict
        Returns:

        """
        return {
            "assets": self.asset_selector.get_checked(),
        }

    def deserialize(self, data):
        """
        Populates the ui from a dict
        Args:
            data:

        Returns:

        """
        self.asset_selector.set_checked_items(data.get("assets", self.asset_selector.get_checked()))

    def closeEvent(self, event):
        self.save_settings()
        event.accept()
