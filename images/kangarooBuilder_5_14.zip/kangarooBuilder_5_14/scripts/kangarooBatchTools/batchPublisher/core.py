###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from PySide2 import QtCore

from kangarooTools import UI3
from kangarooTools import assets as kg_assets
from kangarooTools import utilFunctions

import maya.cmds as cmds

class Signals(QtCore.QObject):
    publish_success = QtCore.Signal(str)
    publish_fail = QtCore.Signal(str)


class App:
    def __init__(self):
        self.signals = Signals()
        self.assets_in_project = []
        self.successful_assets = []
        self.failed_assets = []

    def run(self, asset_list: list[str], comment: str, force_publish: bool):
        """
        Starts the publish process
        Args:
            asset_list:
            comment:
            force_publish:

        Returns:

        """
        self.successful_assets.clear()
        self.failed_assets.clear()

        for asset in asset_list:
            try:
                set_asset_in_ui(asset)

                # if force_publish:
                #     resetFunctionArg("arxPublish", "bDoArxPublish")

                build_asset()
                data = get_publish_info_for_asset(comment)
                get_asset_manager()._publishAsset(data)

                self.successful_assets.append(asset)
                self.signals.publish_success.emit(asset)

            except RuntimeError:
                self.failed_assets.append(asset)
                self.signals.publish_fail.emit(asset)
                continue
            finally:
                continue

        self.failed_assets = [a for a in asset_list if a not in self.successful_assets]


def get_asset_manager() -> kg_assets.AssetManager:
    return UI3.mainWin.assetManager


def build_asset():
    """
    Traverses through the ui till it finds the button
    Returns:

    """
    tab = UI3.mainWin.findChildren(UI3.QtWidgets.QTabWidget)[0]
    builder_tab = tab.widget(0)
    splitter = builder_tab.layout().itemAt(1).widget()
    builder_widget = splitter.widget(0).layout().itemAt(1).widget()
    run_all_button = builder_widget.layout().itemAt(1).itemAt(0).itemAt(0).widget()
    run_all_button.run()


def set_asset_in_ui(asset_name: str):
    """
    Sets the asset in the ui
    Args:
        asset_name:

    Returns:

    """
    get_asset_manager().fillProjects(sSwitchProjectTo=get_asset_manager().getCurrentProject(),
                                     sSwitchAssetTo=asset_name)


def get_publish_info_for_asset(comment: str):
    data = utilFunctions.data.get(
        'ddMasters',
        xDefault={'master': {'sFilename': 'RIG_%s_[v].ma' % get_asset_manager().getCurrentAsset()}},
        sNode=utilFunctions.kExportNode
    )

    for sMaster, dMasterData in data.items():
        dMasterData['sComments'] = comment

    return data


def getFunctionArg(sFunction, sArg, iFunctionIndex=0, xDefault=None):
    build_file = kg_assets.getCurrentBuildFile()
    dBuildContent = utilFunctions.getJsonContent(build_file)
    dAllFunctionDatas = dBuildContent.get('__FUNCTIONDATAS__', {})

    dFunctionDatas = dAllFunctionDatas.get(sFunction, [{}])
    dFunctionData = dFunctionDatas[iFunctionIndex]
    dFileArgs = dFunctionData.get('dFileArgs', {})

    return dFileArgs.get(sArg, xDefault)


def setFunctionArg(sFunction, sArg, xData, iFunctionIndex=0):
    build_file = kg_assets.getCurrentBuildFile()
    dBuildContent = utilFunctions.getJsonContent(build_file)
    dAllFunctionDatas = dBuildContent.get('__FUNCTIONDATAS__', {})

    dFunctionDatas = dAllFunctionDatas.get(sFunction, [{}])
    dFunctionData = dFunctionDatas[iFunctionIndex]
    dFileArgs = dFunctionData.get('dFileArgs', {})
    dFileArgs[sArg] = xData

    dFunctionDatas[iFunctionIndex] = dFunctionData
    dAllFunctionDatas[sFunction] = dFunctionDatas
    dBuildContent['__FUNCTIONDATAS__'] = dAllFunctionDatas
    utilFunctions.setJsonContent(build_file, dBuildContent)


def resetFunctionArg(sFunction, sArg, iFunctionIndex=0):
    build_file = kg_assets.getCurrentBuildFile()
    dBuildContent = utilFunctions.getJsonContent(build_file)
    dAllFunctionDatas = dBuildContent.get('__FUNCTIONDATAS__', {})

    dFunctionDatas = dAllFunctionDatas.get(sFunction, [{}])
    dFunctionData = dFunctionDatas[iFunctionIndex]
    dFileArgs = dFunctionData.get('dFileArgs', {})

    if sArg in dFileArgs:
        del dFileArgs[sArg]

    dFunctionDatas[iFunctionIndex] = dFunctionData
    dAllFunctionDatas[sFunction] = dFunctionDatas
    dBuildContent['__FUNCTIONDATAS__'] = dAllFunctionDatas
    utilFunctions.setJsonContent(build_file, dBuildContent)
