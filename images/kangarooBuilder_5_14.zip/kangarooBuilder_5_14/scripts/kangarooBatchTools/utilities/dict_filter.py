###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from copy import deepcopy


def get_equal_dict(a: dict, b: dict) -> dict:
    """
    compares dictionaries and returns a dict with the equal status of the values
    takes nested dictionaries into account
    Args:
        a:
        b:

    Returns:

    """
    equal_dict = dict()
    for k, v in a.items():
        if isinstance(v, dict):
            equal_dict[k] = get_equal_dict(v, b.get(k, {}))
            continue

        equal_dict[k] = v == b.get(k)
    return equal_dict


def get_filtered_data(data: dict, filter_data: dict):
    """
    returns a filtered dictionary that only contains entries are also in the filter
    Args:
        data:
        filter_data:

    Returns:

    """
    filtered_dict = dict()
    for k, valid_data in filter_data.items():
        if isinstance(valid_data, dict):
            filtered_dict[k] = get_filtered_data(data[k], valid_data)
            continue

        if valid_data:
            filtered_dict[k] = data[k]

    return filtered_dict


def invert_bool_dict(data: dict):
    """
    Inverts the values of a bool dictionary
    Args:
        data:

    Returns:

    """
    ret_dict = dict()
    for k, v in data.items():
        if isinstance(v, dict):
            ret_dict[k] = invert_bool_dict(v)
            continue
        ret_dict[k] = not v
    return ret_dict


def remove_with_value_from_dict(data: dict, valid_value: bool):
    """
    remove all entries that dont match the valid value
    Args:
        data:
        valid_value:

    Returns:

    """
    ret_dict = dict()
    for k, v in data.items():
        if isinstance(v, dict):
            ret_dict[k] = remove_with_value_from_dict(v, valid_value)
            continue

        if v == valid_value:
            continue

        ret_dict[k] = v

    return ret_dict


def remove_empty_from_dict(data: dict):
    """
    remove all empty iterables from the data set
    Args:
        data:

    Returns:

    """
    ret_dict = dict()
    for k, v in data.items():

        if isinstance(v, dict):
            d = remove_empty_from_dict(v)

            if len(d) == 0:
                continue

            ret_dict[k] = d
            continue

        ret_dict[k] = v
    return ret_dict


def merge_filter_dict(a: dict, b: dict, overwrite_value: bool) -> dict:
    """
    merges two dictionaries. if both have values, the one with the overwrite value get sed
    Args:
        a:
        b:
        overwrite_value:

    Returns:

    """
    ret_dict = dict()

    keys = set(a.keys())
    keys.update(set(b.keys()))

    for k in keys:
        av = a.get(k)
        bv = b.get(k)

        if av is None:
            ret_dict[k] = bv
            continue

        if bv is None:
            ret_dict[k] = av
            continue

        if isinstance(av, dict):
            ret_dict[k] = merge_filter_dict(av, bv, overwrite_value)
            continue

        if bv is overwrite_value:
            ret_dict[k] = bv
            continue

        ret_dict[k] = av

    return ret_dict


def get_compressed_delta_dict(data) -> dict:
    """
    returns a dict only with the keys containing change
    Args:
        data: 

    Returns:

    """
    data = remove_with_value_from_dict(data, True)
    data = remove_empty_from_dict(data)
    data = invert_bool_dict(data)
    return data


def remove_key_from_dict(data: dict, key: str) -> dict:
    """
    removes a key from a dictionary
    Args:
        data:
        key:

    Returns:

    """

    ret_dict = deepcopy(data)

    if key in ret_dict:
        del ret_dict[key]

    for k, v in ret_dict.items():
        if isinstance(v, dict):
            ret_dict[k] = remove_key_from_dict(v, key)

    return ret_dict


def merge_module_data(global_filter: dict, asset_data_list: list[dict]) -> dict:
    """
    combines multiple data sets into one merged one.
    each value entry turns into a list with the merged entries
    Args:
        global_filter:
        asset_data_list:

    Returns:

    """
    ret = dict()

    for k, v in global_filter.items():
        if isinstance(v, dict):
            k_asset_data = [ad.get(k, {}) for ad in asset_data_list]
            ret[k] = merge_module_data(v, k_asset_data)
            continue

        ret[k] = [ad.get(k) for ad in asset_data_list]
    return ret


def split_merged_module_data(data: dict | list, index: int):
    """
    Splits a nested dictionary of lists into separate dictionaries based on index.
    Args:
        index:
        data:

    Returns:

    """

    if isinstance(data, list):
        return deepcopy(data[index])

    ret = dict()
    for k, v in data.items():
        ret[k] = split_merged_module_data(v, index)

    return ret


def merge_master_into_slave(merge_filter: dict, master_data, slave_data) -> dict:
    """
    merges the master data into the slave data
    Args:
        merge_filter:
        master_data:
        slave_data:

    Returns:

    """
    ret = deepcopy(slave_data)

    for k, v in merge_filter.items():
        if isinstance(v, dict):
            ret[k] = merge_master_into_slave(v, master_data.get(k, {}), slave_data.get(k, {}))
            continue

        if not v:
            continue

        ret[k] = master_data[k]

    return ret


def get_merged_data_from_list(data: list[dict], override_value: bool):
    """
    merges multiple filter lists into one
    if two values collide, the override value defines witch one will be used
    Args:
        data:
        override_value:

    Returns:

    """
    ret = data[0]
    for slave_data in data[1:]:
        ret = merge_filter_dict(ret, slave_data, override_value)
    return ret
