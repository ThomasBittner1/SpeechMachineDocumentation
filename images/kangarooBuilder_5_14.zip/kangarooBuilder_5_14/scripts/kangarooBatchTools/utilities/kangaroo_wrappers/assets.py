###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os
from kangarooTools import puppetDataUtils


def _contains_subfolder(path, sub_folder):
    if not os.path.isdir(path):
        return False

    return sub_folder in os.listdir(path)


def get_assets_in_project(asset_folder: str) -> list[str]:
    """
    returns a list of all assets in the project
    Returns:

    """
    folders = [(os.path.join(asset_folder, d), d) for d in os.listdir(asset_folder)]
    return [d for path, d in folders if _contains_subfolder(path, "_build")]


def get_asset_version_path(assets_folder: str, asset_name: str, version: int) -> str:
    """
    returns the path to a version folder of an asset
    Args:
        assets_folder:
        version:
        asset_name:

    Returns:

    """
    build_folder = os.path.join(assets_folder, asset_name, '_build')
    versions = [(os.path.join(build_folder, v), v) for v in os.listdir(build_folder)]
    versions = [(path, name) for path, name in versions if not name.startswith('_') and _contains_subfolder(path, "build.bld")]
    ids = [int(name[1:]) for _, name in versions]
    versions = [v for _, v in sorted(zip(ids, versions))]
    return versions[version][0]


def get_puppet_data_for_asset(asset_folder: str, asset_name: str, version: int) -> list:
    """
    loads the data from a puppet file for a versioned asset
    Args:
        asset_folder:
        asset_name:
        version:

    Returns:

    """
    version_folder = get_asset_version_path(asset_folder, asset_name, version)
    puppet_file = os.path.join(version_folder, "puppet.rig")
    return puppetDataUtils.getDictListFromFile(puppet_file)


def save_puppet_data_to_file(asset_folder: str, asset_name: str, version: int, data: dict):
    """
    stores the data to an asset puppet file
    Args:
        asset_folder:
        asset_name:
        version:
        data:

    Returns:

    """
    version_folder = get_asset_version_path(asset_folder, asset_name, version)
    puppet_file = os.path.join(version_folder, "puppet.rig")
    puppetDataUtils.fileDump(puppet_file, data)


def get_puppet_module_names(data: list) -> list[str]:
    ret_list = list()
    for module in data:
        args = module.get("dArgsFILE", {})
        name: str = args.get('sName', 'noName')
        side: str = args.get('sSide', 'noSide')
        ret_list.append("_".join([name, side]))

    return ret_list
