###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from PySide2 import QtWidgets, QtCore


class ScaleSlider(QtWidgets.QWidget):
    def __init__(self, minimum: float, maximum: float):
        super().__init__()

        self.minimum = minimum
        self.maximum = maximum

        self.slider = QtWidgets.QSlider()
        self.slider.setOrientation(QtCore.Qt.Horizontal)
        self.slider.setRange(0.0, 200.0)
        self.slider.setValue(100.0)

        self.label = QtWidgets.QLabel()
        self.update_label()

        self.setLayout(QtWidgets.QHBoxLayout())
        self.layout().addWidget(self.slider)
        self.layout().addWidget(self.label)
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.slider.valueChanged.connect(self.update_label)

    def get_scale(self):
        value = self.slider.value() / 100.0

        if value < 1:
            return (1 - value) * self.minimum + value

        return 1. + pow((value - 1.), 2) * (self.maximum - 1.)

    def update_label(self):
        self.label.setText(f"{self.get_scale():.2f}")
