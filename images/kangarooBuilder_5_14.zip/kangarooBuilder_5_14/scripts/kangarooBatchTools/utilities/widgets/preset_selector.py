###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import json

from PySide2.QtWidgets import *
from kangarooBatchTools.utilities.widgets import filtered_combo_box

import os


class PresetFileSelector(QWidget):

    def __init__(self):
        super().__init__()

        self._folder_path = ""

        self.preset_combo = filtered_combo_box.FilteredComboBox()
        self.load_button = QPushButton("Load")
        self.load_button.setMaximumWidth(40)

        self.add_button = QPushButton("New")
        self.add_button.setMaximumWidth(40)

        self.setLayout(QHBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().addWidget(self.preset_combo)
        self.layout().addWidget(self.load_button)
        self.layout().addWidget(self.add_button)

    def set_folder_path(self, path: str):
        self._folder_path = path
        self.reload()

    def reload(self):
        if not os.path.exists(self._folder_path):
            return

        current = self.preset_combo.currentText()
        self.preset_combo.set_items([f.split(".")[0] for f in os.listdir(self._folder_path)])
        self.preset_combo.setCurrentText(current)

    def get_current_file_path(self) -> str:
        return os.path.join(self._folder_path, self.preset_combo.currentText() + ".json")

    def get_data(self) -> dict:
        with open(self.get_current_file_path(), "r") as f:
            data = json.load(f)

        return data

    def export_data(self, data):

        if os.path.exists(self.get_current_file_path()):
            if not self.can_overwrite():
                return

        if not os.path.exists(self._folder_path):
            os.makedirs(self._folder_path)

        with open(self.get_current_file_path(), "w") as f:
            json.dump(data, f, indent=4)

        self.reload()

    def can_overwrite(self) -> bool:
        dialog = QMessageBox()
        dialog.setWindowTitle("Preset already exists")
        dialog.setText("Do you want to overwrite it?")
        dialog.setStandardButtons(QMessageBox.Yes | QMessageBox.Cancel)
        result = dialog.exec_()

        return result == QMessageBox.Yes
