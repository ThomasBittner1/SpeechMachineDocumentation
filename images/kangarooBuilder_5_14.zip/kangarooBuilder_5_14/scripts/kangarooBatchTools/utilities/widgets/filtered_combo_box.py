###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from PySide2.QtWidgets import *
from PySide2 import QtCore


class FilteredComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setEditable(True)  # Make the combo box editable

        # Set up completer
        self.completer = QCompleter([], self)
        self.completer.setCompletionMode(QCompleter.PopupCompletion)
        self.completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.setCompleter(self.completer)

        # Filter items when text changes
        self.lineEdit().textChanged.connect(self.update_filter)

    def set_items(self, items: list[str]):
        self.clear()
        self.addItems(items)
        self.completer.setModel(QtCore.QStringListModel(items))

    def update_filter(self, text):
        filtered_items = [self.itemText(i) for i in range(self.count()) if text.lower() in self.itemText(i).lower()]
        self.completer.setModel(QtCore.QStringListModel(filtered_items))
