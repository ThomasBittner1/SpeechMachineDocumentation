###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from PySide2.QtWidgets import *


class ItemSelector(QWidget):
    def __init__(self):
        super().__init__()

        self.setLayout(QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)

        self.filter = QLineEdit()
        self.filter.setPlaceholderText("Filter...")
        self.layout().addWidget(self.filter)
        self.filter.textEdited.connect(self.filter_items)

        # Scroll area
        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.layout().addWidget(self.scroll_area)

        # Scroll area content
        self.scroll_widget = QWidget()
        self.scroll_layout = QVBoxLayout()
        self.scroll_widget.setLayout(self.scroll_layout)
        self.scroll_area.setWidget(self.scroll_widget)

        # setup buttons
        self.toggle_button = QPushButton("Toggle")
        self.clear_button = QPushButton("Clear")
        self.all_button = QPushButton("All")

        self.button_widget = QWidget()
        self.button_widget.setLayout(QHBoxLayout())
        self.button_widget.layout().addWidget(self.toggle_button)
        self.button_widget.layout().addWidget(self.all_button)
        self.button_widget.layout().addWidget(self.clear_button)
        self.button_widget.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().addWidget(self.button_widget)

        self.clear_button.clicked.connect(self.clear_selection)
        self.all_button.clicked.connect(self.select_all)
        self.toggle_button.clicked.connect(self.toggle_selection)

    def set_filter_enabled(self, enabled: bool):
        self.filter.setHidden(not enabled)
        self.filter_items()

    def set_items(self, assets: list[str], default_value: bool):
        """
        fill the scroll box with the assets
        Args:
            default_value:
            assets:

        Returns:

        """
        checked_dict = {cb.text(): cb.isChecked() for cb in self.get_check_boxes()}

        self.clear_layout()

        for asset_name in assets:
            check_box = QCheckBox(asset_name)
            check_box.setChecked(checked_dict.get(asset_name, default_value))
            self.scroll_layout.addWidget(check_box)

        spacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.scroll_layout.addSpacerItem(spacer)

    def clear_layout(self):
        """
        Empties the scroll layout
        Returns:

        """
        while self.scroll_layout.count():
            item = self.scroll_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def toggle_selection(self):
        """
        Toggles all check boxes
        Returns:

        """
        for cb in self.get_check_boxes():
            cb.setChecked(not cb.isChecked())

    def clear_selection(self):
        """
        Deselects all checkboxes
        Returns:

        """
        for cb in self.get_check_boxes():
            cb.setChecked(False)

    def select_all(self):
        """
        Selects all checkboxes
        Returns:

        """
        for cb in self.get_check_boxes():
            cb.setChecked(True)

    def get_checked(self) -> list[str]:
        """
        returns a list with all checked elements
        Returns:

        """
        return [cb.text() for cb in self.get_check_boxes() if cb.isChecked()]

    def get_check_boxes(self) -> list[QCheckBox]:
        """
        returns a list of all current checkboxes
        Returns:

        """
        ret = list()
        for i in range(self.scroll_layout.count()):
            item = self.scroll_layout.itemAt(i).widget()

            if isinstance(item, QCheckBox):
                ret.append(item)

        return ret

    def filter_items(self):
        """
        filters the checkboxes
        if the filter is deactivated everything is active
        Returns:

        """
        text = self.filter.text().lower()
        global_enabled = text == "" or self.filter.isHidden()

        for cb in self.get_check_boxes():
            enabled = text in cb.text().lower() or global_enabled
            cb.setHidden(not enabled)

    def set_checked_items(self, items: list[str]):
        """
        set a list off items to checked, and un check the others
        Args:
            items:

        Returns:

        """

        for cb in self.get_check_boxes():
            cb.setChecked(cb.text() in items)
