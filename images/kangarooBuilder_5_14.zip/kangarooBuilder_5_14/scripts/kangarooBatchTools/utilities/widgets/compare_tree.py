###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from collections.abc import Callable

from PySide2 import QtWidgets, QtCore, QtGui
from PySide2.QtWidgets import QTreeWidget
from PySide2.QtWidgets import QTreeWidgetItem


DISABLED_TXT = QtGui.QColor(130, 130, 130)

EVEN_BG = QtGui.QColor(255, 255, 255, 2)
OD_BG = QtGui.QColor(255, 255, 255, 0)

UNCHECKED_BG = QtGui.QColor(255, 0, 0, 30)
UNCHECKED_TXT = QtGui.QColor(255, 180, 180, 255)
CHECKED_BG = QtGui.QColor(0, 255, 255, 30)
CHECKED_TXT = QtGui.QColor(180, 255, 255, 255)


def get_background_color_static_item(i) -> QtGui.QColor:
    return OD_BG if i % 2 else EVEN_BG


class DictItem(QTreeWidgetItem):

    def update(self):
        for i in range(2, self.columnCount()):
            self.setBackgroundColor(i, get_background_color_static_item(i))


class DataItem(QTreeWidgetItem):

    def __init__(self, values, parent: QTreeWidgetItem):
        super().__init__()
        self.values = values
        parent.addChild(self)

        self.match_list = self.get_match_list()
        self.set_init_text()
        self.set_init_checked()
        self.update()
        self.setExpanded(True)

    def get_match_list(self) -> list[bool]:
        """
        returns a list for all elements if they match
        Returns:

        """
        return [self.values[1] == v for v in self.values]

    def set_init_text(self):
        """
        Fills the item with the data values
        Returns:

        """
        for i, v in enumerate(self.values):
            self.setText(i, str(v))

    def set_init_checked(self):
        """
        Sets the initial checked values
        Returns:

        """
        for i, match in enumerate(self.match_list):
            if i < 2:
                continue

            if match:
                continue
            self.setCheckState(i, QtCore.Qt.Checked)

    def is_checked(self, i) -> bool:
        """
        Helper function the get the match value for a row
        Args:
            i:

        Returns:

        """
        return self.checkState(i) == QtCore.Qt.Checked

    def update(self):
        """
        Updates the colors of the item dependent on the stored data
        Returns:

        """
        for i in range(2, self.columnCount()):
            if self.match_list[i]:
                self.setBackgroundColor(i, get_background_color_static_item(i))
                self.setTextColor(i, DISABLED_TXT)
                continue

            self.setBackgroundColor(i, CHECKED_BG if self.is_checked(i) else UNCHECKED_BG)
            self.setTextColor(i, CHECKED_TXT if self.is_checked(i) else UNCHECKED_TXT)


class ContextMenu(QtWidgets.QMenu):
    def __init__(self, parent):
        super().__init__(parent)

        self.expand_all: QtWidgets.QAction = QtWidgets.QAction("Expand All")
        self.collapse_all: QtWidgets.QAction = QtWidgets.QAction("Collapse All")
        self.lock_selected: QtWidgets.QAction = QtWidgets.QAction("Check Selected")
        self.unlock_selected: QtWidgets.QAction = QtWidgets.QAction("Uncheck Selected")
        self.select_row: QtWidgets.QAction = QtWidgets.QAction("Select Row")
        self.select_column: QtWidgets.QAction = QtWidgets.QAction("Select Column")
        self.select_children: QtWidgets.QAction = QtWidgets.QAction("Select Children")

        self.addAction(self.expand_all)
        self.addAction(self.collapse_all)
        self.addSeparator()

        select_menu = self.addMenu("Select")
        select_menu.addAction(self.select_children)
        select_menu.addAction(self.select_row)
        select_menu.addAction(self.select_column)

        self.addAction(self.lock_selected)
        self.addAction(self.unlock_selected)


class CompareTree(QTreeWidget):
    def __init__(self, row_headers: dict, col_headers: list[str], data: dict):
        super().__init__()

        self.row_headers = row_headers
        self.col_headers = col_headers
        self.data = data

        self.setHeaderLabels(self.col_headers)
        self.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectItems)
        self.header().setSectionsMovable(False)

        self.menu = ContextMenu(self)

        # Enable custom right-click menu
        self.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)

        self.menu.lock_selected.triggered.connect(lambda _: self.set_selection_locked(True))
        self.menu.unlock_selected.triggered.connect(lambda _: self.set_selection_locked(False))
        self.menu.expand_all.triggered.connect(lambda _: self.set_expand_all(True))
        self.menu.collapse_all.triggered.connect(lambda _: self.set_expand_all(False))
        self.menu.select_row.triggered.connect(lambda _: self.set_rows_selected(self.selectedItems()))
        self.menu.select_column.triggered.connect(self.set_columns_selected)
        self.menu.select_children.triggered.connect(lambda _: self.set_children_selected(self.currentItem()))

        self.itemChanged.connect(self.item_changes)

    def get_selected_items_and_columns(self) -> list[tuple[DataItem, list[int]]]:
        """
        returns a list with the items and their selected columns
        Returns:

        """
        item_list = list()

        for item in self.selectedItems():
            column_list = []
            for col in range(self.columnCount()):
                index = self.indexFromItem(item, col)  # Get model index
                if self.selectionModel().isSelected(index):
                    column_list.append(col)
            item_list.append((item, column_list))
        return item_list

    def set_rows_selected(self, items: list[DataItem]):

        for item in items:
            if isinstance(item, DictItem):
                continue

            for column, matches in enumerate(item.get_match_list()):
                if column < 2:
                    continue

                if matches:
                    continue

                index = self.indexFromItem(item, column)
                self.selectionModel().select(index, QtCore.QItemSelectionModel.Select)

    def set_children_selected(self, item):

        if not item:
            return

        if not isinstance(item, DictItem):
            return

        data_items = get_nested_children(item, is_data_item)
        self.set_rows_selected(data_items)

    def set_columns_selected(self):
        current_items = self.get_selected_items_and_columns()
        all_data_items = self.get_all_data_items()

        selected_columns = set()

        for item, columns in current_items:
            selected_columns.update(columns)

        for item in all_data_items:

            for column in selected_columns:
                if column < 2:
                    continue

                if item.get_match_list()[column]:
                    continue

                index = self.indexFromItem(item, column)
                self.selectionModel().select(index, QtCore.QItemSelectionModel.Select)

    def show_context_menu(self, position):
        """
        Show right-click menu at the cursor position.
        Args:
            position:

        Returns:

        """
        selected_items = set(self.selectedItems() + [self.itemAt(position)]) - {None}
        self.menu.lock_selected.setEnabled(len(selected_items) > 0)
        self.menu.unlock_selected.setEnabled(len(selected_items) > 0)
        self.menu.exec_(self.viewport().mapToGlobal(position))

    def fill_tree(self):
        """
        Fills the tree with the data
        Returns:

        """
        self.blockSignals(True)
        self.clear()

        try:

            self.setColumnCount(len(self.col_headers))
            self.setHeaderLabels(self.col_headers)

            print ('self.data: ',self.data)

            for i, (module_name, asset_data) in enumerate(zip(
                    self.row_headers,
                    self.data
            )):

                module_item = DictItem()
                self.addTopLevelItem(module_item)

                self.fill_item(module_item, asset_data)
                print ('asset_data: ', asset_data)
                print ('module_item.childCount(): ', module_item.childCount())
                module_item.setHidden(module_item.childCount() == 0)
                module_item.setExpanded(False)
                module_item.setText(0, module_name)
                module_item.update()

        except RuntimeError as e:
            print(e)

        finally:
            self.blockSignals(False)

    def fill_item(self, item, data):
        """
        Populates the item, if the item has a child item,
         it  steps in and fills it recursive
        Args:
            item:
            data:

        Returns:

        """
        for k, v in data.items():

            if isinstance(v, dict):
                new_item = DictItem()
                item.addChild(new_item)
                new_item.setExpanded(True)
                new_item.setText(0, k)
                new_item.update()
                self.fill_item(new_item, v)
                continue

            new_item = DataItem([k] + v, parent=item)

    def set_selection_locked(self, value: bool):
        for item, columns in self.get_selected_items_and_columns():
            if not isinstance(item, DataItem):
                continue

            columns = [i for i in columns if not item.match_list[i]]
            columns = [i for i in columns if i > 1]

            for col in columns:
                item.setCheckState(col, QtCore.Qt.Checked if value else QtCore.Qt.Unchecked)

    def item_changes(self, item: DataItem, column):
        item.update()

    def set_expand_all(self, value: bool):
        for i in range(self.topLevelItemCount()):
            item: DataItem = self.topLevelItem(i)
            item.setExpanded(value)

    def get_merge_data(self) -> list:
        ret_list = list()
        for i in range(self.topLevelItemCount()):
            item = self.topLevelItem(i)
            ret_list.append(self._get_item_merge_data(item))

        return ret_list

    def _get_item_merge_data(self, item: QtWidgets.QTreeWidgetItem) -> dict | list:

        if isinstance(item, DataItem):
            different = [not item.match_list[i] for i in range(2, item.columnCount())]
            checked = [item.is_checked(i) for i in range(2, item.columnCount())]
            return [v and c for v, c in zip(different, checked)]

        data = dict()
        for i in range(item.childCount()):
            child = item.child(i)
            data[child.text(0)] = self._get_item_merge_data(child)

        return data

    def get_all_data_items(self) -> list[DataItem]:
        """
        get all data items in the tree
        Returns:

        """
        ret = list()

        for i in range(self.topLevelItemCount()):
            item = self.topLevelItem(i)
            data_items = get_nested_children(item, is_data_item)
            ret.extend(data_items)

        return ret


def get_nested_children(parent, filter_func: Callable[[QTreeWidgetItem], bool]) -> list:
    """
    walks through all nested children and returns those
    that match the filter function
    Args:
        parent:
        filter_func:

    Returns:

    """
    ret = list()

    for i in range(parent.childCount()):
        child = parent.child(i)

        if filter_func(child):
            ret.append(child)

        ret.extend(get_nested_children(child, filter_func))

    return ret


def is_data_item(item: QTreeWidgetItem) -> bool:
    return isinstance(item, DataItem)
