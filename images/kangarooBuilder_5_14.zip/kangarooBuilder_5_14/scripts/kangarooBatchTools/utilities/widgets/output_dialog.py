###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from PySide2 import QtWidgets
from PySide2.QtWidgets import QApplication


class MessageDialog(QtWidgets.QDialog):

    def __init__(self, parent, title: str):
        super().__init__(parent)

        self.message_box = QtWidgets.QPlainTextEdit()
        self.message_box.setReadOnly(True)

        self.setWindowTitle(title)
        self.setLayout(QtWidgets.QVBoxLayout())
        self.layout().addWidget(self.message_box)

    def add_message(self, text: str):
        current_text = self.message_box.toPlainText()
        current_text = f"{current_text}{text}\n"
        self.message_box.setPlainText(current_text)
        self.message_box.verticalScrollBar().setValue(self.message_box.verticalScrollBar().maximum())
        QApplication.processEvents()

    def reset(self):
        self.message_box.clear()
