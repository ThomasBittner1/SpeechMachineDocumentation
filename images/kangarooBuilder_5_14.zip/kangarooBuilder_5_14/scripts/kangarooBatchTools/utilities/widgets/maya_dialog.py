###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



from shiboken2 import wrapInstance
import maya.OpenMayaUI as omui
from PySide2.QtWidgets import QDialog, QMainWindow
from maya import cmds


def get_maya_main_window():
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QMainWindow)


class MayaDialog(QDialog):
    my_window: QDialog = None

    def __init__(self):
        super().__init__(get_maya_main_window())

    @classmethod
    def run(cls) -> "MayaDialog":
        return cls._run()

    @classmethod
    def _run(cls, *args, **kwargs) -> "MayaDialog":
        global my_window

        try:
            my_window.close()  # Close existing window if open
            my_window.deleteLater()
        except RuntimeError:
            pass

        my_window = cls(*args, **kwargs)
        my_window.show()

        return my_window
