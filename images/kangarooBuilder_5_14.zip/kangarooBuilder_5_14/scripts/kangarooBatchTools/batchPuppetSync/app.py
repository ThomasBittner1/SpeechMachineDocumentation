###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import copy
from PySide2 import QtCore

from kangarooBatchTools.utilities.kangaroo_wrappers import assets as kg_asset_utils
from kangarooBatchTools.batchPuppetSync import puppet
from kangarooBatchTools.utilities import dict_filter


class Signals(QtCore.QObject):
    merge_module_into_slave = QtCore.Signal(str, str, int, int)
    export_puppet_data = QtCore.Signal(str, int)
    skipped_export_puppet_data = QtCore.Signal(str, int)


class AppData:
    def __init__(self):

        self.signals = Signals()

        self.keys_to_ignore = []
        self.assets_in_project = list()
        self.assets_path = ""
        self.master_asset = None
        self.master_data = None
        self.master_module_names = None

        self.slave_assets = []
        self.modules_to_compare = []
        self.merged_merge_data = []

        self.filtered_master_data = []
        self.slave_data_list = []
        self.slave_module_filtered_list = []
        self.slave_filter_list = []
        self.global_filter = []
        self.asset_data = []
        self.merged_asset_data = []
        self.slave_merge_filter = []
        self.slave_merged_data = []
        self.slaves_with_change = []

    def calculate_master_data(self):
        """
        fills the master data based on the master name
        Returns:

        """
        self.master_data = kg_asset_utils.get_puppet_data_for_asset(self.assets_path, self.master_asset, -1)
        self.master_module_names = kg_asset_utils.get_puppet_module_names(self.master_data)

    def get_modules_to_remove(self) -> list:
        """
        returns a list of modules that need to be removed from the master data
        Returns:

        """
        return [m for m in self.master_module_names if m not in self.modules_to_compare]

    def get_all_assets(self) -> list[str]:
        """
        gets a list of all assets that are being dealt with, starting with the master
        Returns:

        """
        return [self.master_asset] + self.slave_assets

    def get_possible_slave_assets(self) -> list[str]:
        """
        get all assets from the project, minus the master asset
        Returns:

        """
        return [a for a in self.assets_in_project if a != self.master_asset]

    def get_slave_data_list(self):
        """
        returns a puppet data list from all slave assets
        Returns:

        """
        return [
            kg_asset_utils.get_puppet_data_for_asset(self.assets_path, asset_name, -1)
            for asset_name in self.slave_assets
        ]

    def get_module_filtered_slave_data_list(self):
        """
        returns a list of all slave assets, matching the comparison module list
        missing modules are empty dicts
        Returns:

        """
        return [
            puppet.get_module_filtered_data(self.modules_to_compare, d)
            for d in self.slave_data_list
        ]

    def get_module_filtered_master_data(self) -> list:
        """
        returns the master data with only the modules to be compared to
        Returns:

        """
        master_data = self.master_data
        for m in self.get_modules_to_remove():
            master_data = puppet.remove_module_from_puppet_data(master_data, m)

        return master_data

    def get_slave_filter_list(self) -> list:
        """
        returns a filter for each slave asset
        Returns:

        """
        return [
            puppet.get_asset_filter_data(self.filtered_master_data, d)
            for d in self.slave_module_filtered_list
        ]

    def get_merged_asset_data(self) -> list:
        """
        merges the data from all assets into one data set. with a list for each attribute
        Returns:

        """
        data = list()
        for i, _ in enumerate(self.modules_to_compare):
            data.append(dict_filter.merge_module_data(self.global_filter[i], [ad[i] for ad in self.asset_data]))
        return data

    def get_global_filter(self) -> list:
        """
        returns the global filter.
        attributes to ignore are removed from the dict
        Returns:

        """
        ret = puppet.get_global_filter(self.slave_filter_list)

        for module_index, module in enumerate(ret):
            for key in self.keys_to_ignore:
                module = dict_filter.remove_key_from_dict(module, key)
            ret[module_index] = module
        return ret

    def calculate_slave_merge_filter_list(self):
        """
        Returns the merged merge data and split by asset
        Returns:

        """
        ret = list()
        for asset_index, asset_name in enumerate(self.slave_assets):
            asset_modules_filter = []

            has_change = False

            for module_index, module_name in enumerate(self.modules_to_compare):
                merge_filter = dict_filter.split_merged_module_data(self.merged_merge_data[module_index], asset_index)
                merge_filter = dict_filter.remove_with_value_from_dict(merge_filter, False)
                merge_filter = dict_filter.remove_empty_from_dict(merge_filter)
                asset_modules_filter.append(merge_filter)
                has_change = has_change or len(merge_filter) > 0
            ret.append(asset_modules_filter)

            if has_change:
                self.slaves_with_change.append(asset_index)
        self.slave_merge_filter = ret

    def calculate_slave_merged_data_list(self):
        """

        Returns:

        """
        ret = list()
        for asset_index, asset_name in enumerate(self.slave_assets):

            if asset_index not in self.slaves_with_change:
                ret.append(self.slave_data_list[asset_index])
                continue

            slave_merged_data = self.get_slave_merged_data(asset_index, asset_name, self.slave_data_list[asset_index])
            ret.append(slave_merged_data)
        self.slave_merged_data = ret

    def get_slave_merged_data(self, asset_index, asset_name, slave_data):
        """

        Args:
            slave_data:
            asset_index:
            asset_name:

        Returns:

        """

        slave_module_names = kg_asset_utils.get_puppet_module_names(slave_data)
        slave_merged_data = copy.deepcopy(slave_data)
        new_modules = list()

        for master_module_index, module_name in enumerate(self.modules_to_compare):

            master_module = self.filtered_master_data[master_module_index]
            merge_filter = self.slave_merge_filter[asset_index][master_module_index]

            if not merge_filter:
                continue

            # if the module doesn't exist create it and add it in the new module list
            if module_name not in slave_module_names:
                merged_module_data = dict_filter.merge_master_into_slave(merge_filter, master_module, {})
                new_modules.append(merged_module_data)

            # if it does exist, replace it
            else:
                slave_module_index = slave_module_names.index(module_name)
                slave_module = slave_data[slave_module_index]
                merged_module_data = dict_filter.merge_master_into_slave(merge_filter, master_module, slave_module)
                slave_merged_data[slave_module_index] = merged_module_data

            self.signals.merge_module_into_slave.emit(asset_name, module_name, asset_index, master_module_index)

        slave_merged_data.extend(new_modules)
        return slave_merged_data

    def calculate(self):
        """
        calculates the data for the app
        Returns:

        """
        self.filtered_master_data = self.get_module_filtered_master_data()
        self.slave_data_list = self.get_slave_data_list()
        self.slave_module_filtered_list = self.get_module_filtered_slave_data_list()
        self.slave_filter_list = self.get_slave_filter_list()
        self.global_filter = self.get_global_filter()
        self.asset_data = [self.filtered_master_data] + self.slave_module_filtered_list
        self.merged_asset_data = self.get_merged_asset_data()

    def reset_calculation(self):
        """
        Resets the calculated data
        Returns:

        """
        self.filtered_master_data = []
        self.slave_data_list = []
        self.slave_module_filtered_list = []
        self.slave_filter_list = []
        self.global_filter = []
        self.asset_data = []
        self.merged_asset_data = []

    def export_slave_data(self):
        for asset_index in self.slaves_with_change:
            asset_name = self.slave_assets[asset_index]
            kg_asset_utils.save_puppet_data_to_file(self.assets_path, asset_name, -1, self.slave_merged_data[asset_index])
            self.signals.export_puppet_data.emit(asset_name, asset_index)

    def get_slaves_without_change(self) -> list[str]:
        """
        Returns a list with all asset names that have no changes
        Returns:

        """
        return [name for i, name in enumerate(self.slave_assets) if i not in self.slaves_with_change]

    def serialize(self) -> dict:
        return {
            "master_asset": self.master_asset,
            "master_modules": self.modules_to_compare,
            "slave_assets": self.slave_assets,
        }

    def deserialize(self, data: dict):
        self.master_asset = data.get("master_asset", self.master_asset)
        self.modules_to_compare = data.get("master_modules", self.modules_to_compare)
        self.slave_assets = data.get("slave_assets", self.slave_assets)
