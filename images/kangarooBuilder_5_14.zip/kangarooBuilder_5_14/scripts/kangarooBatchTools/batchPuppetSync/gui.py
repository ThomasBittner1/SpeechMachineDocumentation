###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import os

from PySide2 import QtWidgets, QtCore
from shiboken2 import wrapInstance
import maya.OpenMayaUI as omui

import time

from kangarooBatchTools.utilities.widgets import item_selector
from kangarooBatchTools.utilities.widgets import filtered_combo_box
from kangarooBatchTools.utilities.widgets import line
from kangarooBatchTools.utilities.widgets import output_dialog
from kangarooBatchTools.utilities.widgets import compare_tree
from kangarooBatchTools.utilities.widgets import preset_selector
from kangarooBatchTools.utilities.widgets import maya_dialog
from kangarooBatchTools.utilities.kangaroo_wrappers import assets as kg_asset_utils
from kangarooBatchTools.batchPuppetSync import app

# import importlib
# importlib.reload(kg_asset_utils)
# importlib.reload(compare_tree)
# importlib.reload(app)


# TODO: the project and preset path need to be set. we store it on m:projects...mtp/.../rig/_presets/tools/TOOL_NAME
TOOL_NAME = "Puppet Synchronizer"
# PROJECT_PATH = os.path.normpath(r"U:\projects\hs3\work\source\assets\rig\thomas.bittner\__HS3__")
# PRESET_PATH = os.path.join(PROJECT_PATH, "_presets", "tools", TOOL_NAME)


def show(sProjectPath, sAsset):
    global my_window

    try:
        my_window.close()  # Close existing window if open
        my_window.deleteLater()
    except:
        pass

    # TODO: PROJECT path and default asset need to be set.
    app_data = app.AppData()
    app_data.assets_in_project = kg_asset_utils.get_assets_in_project(sProjectPath)
    app_data.master_asset = sAsset
    app_data.keys_to_ignore = ["bExpandedFILE"]
    app_data.assets_path = sProjectPath
    app_data.calculate_master_data()

    my_window = MyMayaUI(app_data)
    my_window.show()


class MyMayaUI(QtWidgets.QDialog):

    def __init__(self, app_data: app.AppData, parent=maya_dialog.get_maya_main_window()):
        super(MyMayaUI, self).__init__(parent)

        self.app_data = app_data
        self.settings = QtCore.QSettings("Rigging", TOOL_NAME)

        self.asset_selector = item_selector.ItemSelector()
        self.module_selector = item_selector.ItemSelector()

        # self.preset_selector = preset_selector.PresetFileSelector()
        # self.preset_selector.set_folder_path(PRESET_PATH)

        self.tree = compare_tree.CompareTree({}, ["Attributes"], {})

        self.master_edit = filtered_combo_box.FilteredComboBox()
        self.master_edit.set_items(self.app_data.assets_in_project)
        self.master_edit.setCurrentText(self.app_data.master_asset)

        self.compare_button = QtWidgets.QPushButton("Compare")
        self.merge_button = QtWidgets.QPushButton("Merge")

        self.message_dialog = output_dialog.MessageDialog(self, "Merge Log")

        self.setWindowTitle(TOOL_NAME)
        self.setWindowFlags(QtCore.Qt.Window)
        self.setMinimumSize(900, 600)
        self.layout = QtWidgets.QHBoxLayout(self)

        # selection part
        master_asset_widget = QtWidgets.QWidget()
        master_asset_widget.setLayout(QtWidgets.QVBoxLayout())
        master_asset_widget.layout().setContentsMargins(0, 0, 0, 0)
        master_asset_widget.layout().addWidget(self.master_edit)
        master_asset_widget.layout().addWidget(self.module_selector)

        selection_splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        selection_splitter.setLayout(QtWidgets.QVBoxLayout())
        selection_splitter.layout().addWidget(master_asset_widget)
        selection_splitter.layout().addWidget(self.asset_selector)

        main_button_widget = QtWidgets.QWidget()
        main_button_widget.setLayout(QtWidgets.QHBoxLayout())
        main_button_widget.layout().addWidget(self.compare_button)
        main_button_widget.layout().addWidget(self.merge_button)
        main_button_widget.layout().setContentsMargins(0, 0, 0, 0)

        side_bar_widget = QtWidgets.QWidget()
        side_bar_widget.setLayout(QtWidgets.QVBoxLayout())
        # side_bar_widget.layout().addWidget(self.preset_selector)
        side_bar_widget.layout().addWidget(line.HLine())
        side_bar_widget.layout().addWidget(selection_splitter)
        side_bar_widget.layout().addWidget(line.HLine())
        side_bar_widget.layout().addWidget(main_button_widget)

        main_splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        main_splitter.addWidget(side_bar_widget)
        main_splitter.addWidget(self.tree)

        self.layout.addWidget(main_splitter)

        self.load_settings()

        self.master_edit.currentTextChanged.connect(self.on_master_changed)
        self.compare_button.clicked.connect(self.compare)
        self.merge_button.clicked.connect(self.merge)

        # self.preset_selector.add_button.clicked.connect(self.export_preset)
        # self.preset_selector.load_button.clicked.connect(self.load_preset)

        self.app_data.signals.merge_module_into_slave.connect(self.add_merge_module_into_slave_message)
        self.app_data.signals.export_puppet_data.connect(self.add_exported_slave_message)

    def on_master_changed(self):
        """
        Update the ui once the master changed
        Returns:

        """
        new_master = self.master_edit.currentText()
        if new_master not in self.app_data.assets_in_project:
            return

        self.app_data.master_asset = new_master
        self.app_data.calculate_master_data()
        self.app_data.reset_calculation()

        self.asset_selector.set_items(self.app_data.get_possible_slave_assets(), True)
        self.module_selector.set_items(self.app_data.master_module_names, True)
        self.merge_button.setEnabled(False)

    def compare(self):
        """
        Fill the tree with the compared data
        Returns:

        """

        self.app_data.calculate_master_data()

        self.app_data.slave_assets = self.asset_selector.get_checked()
        self.app_data.modules_to_compare = self.module_selector.get_checked()
        self.app_data.calculate()

        self.tree.col_headers = ["Attributes"] + self.app_data.get_all_assets()
        self.tree.row_headers = self.app_data.modules_to_compare
        self.tree.data = self.app_data.merged_asset_data
        self.tree.fill_tree()
        self.merge_button.setEnabled(True)

    def merge(self):
        self.message_dialog.reset()
        self.message_dialog.show()

        start_time = time.time()

        self.message_dialog.add_message("Start Merge Process")
        self.app_data.merged_merge_data = self.tree.get_merge_data()
        self.message_dialog.add_message("")

        self.message_dialog.add_message("Start Merge Mapping Process")
        self.app_data.calculate_slave_merge_filter_list()
        self.message_dialog.add_message("")

        self.message_dialog.add_message("Start Asset Merge Process")
        self.app_data.calculate_slave_merged_data_list()
        self.message_dialog.add_message("")

        self.message_dialog.add_message("Start Export Process")
        self.app_data.export_slave_data()
        self.message_dialog.add_message("")

        self.message_dialog.add_message("Skipped Assets without Changes")
        self.message_dialog.add_message("\n".join(self.app_data.get_slaves_without_change()))
        self.message_dialog.add_message("")

        self.message_dialog.add_message("Merge Complete")
        self.message_dialog.add_message(f"- {(time.time() - start_time):.4f}s")
        self.message_dialog.add_message("")

    def add_merge_module_into_slave_message(self, asset_name, module_name):
        message = f"- merged {asset_name} - {module_name}"
        self.message_dialog.add_message(message)

    def add_exported_slave_message(self, asset_name):
        message = f"- exported {asset_name} "
        self.message_dialog.add_message(message)

    def load_settings(self):
        self.deserialize({k: self.settings.value(k) for k in self.settings.allKeys()})

    def save_settings(self):
        for k, v in self.serialize().items():
            self.settings.setValue(k, v)

    def load_preset(self):
        self.deserialize(self.preset_selector.get_data())

    def export_preset(self):
        self.preset_selector.export_data(self.serialize())

    def serialize(self) -> dict:
        """
        converts the storable data into a dict
        Returns:

        """
        return {
            "master_asset": self.master_edit.currentText(),
            "slave_assets": self.asset_selector.get_checked(),
            "master_modules": self.module_selector.get_checked()
        }

    def deserialize(self, data):
        """
        Populates the ui from a dict
        Args:
            data:

        Returns:

        """
        self.master_edit.setCurrentText(data.get("master_asset", self.master_edit.currentText()))
        self.on_master_changed()

        self.module_selector.set_checked_items(data.get("master_modules", self.module_selector.get_checked()))
        self.asset_selector.set_checked_items(data.get("slave_assets", self.asset_selector.get_checked()))

    def closeEvent(self, event):
        self.save_settings()
        event.accept()
