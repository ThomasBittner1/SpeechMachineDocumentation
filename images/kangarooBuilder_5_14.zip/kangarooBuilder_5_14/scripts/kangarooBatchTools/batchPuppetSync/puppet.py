###############################################################################################
#
# Kangaroo Builder has been created by Thomas Bittner from 2019 to 2025, the full rights to 
# this tool belong to Thomas Bittner.
#
# For everyone else it is forbidden to extract and/or redistribute any of the code, unless 
# granted by Thomas Bittner. 
#
# The standard free trial license grants everyone to use this tool as long as you don't generate
# money or any other type of income with it.
# If Kangaroo Builder is used for paid projects, a paid license must be obtained.  
# 
# Furthermore, the author does not take responsibility/liability for any damage resulting 
# from the kangaroo builder.
# 
###############################################################################################



import copy

from kangarooBatchTools.utilities.kangaroo_wrappers import assets
from kangarooBatchTools.utilities import dict_filter


def remove_module_from_puppet_data(data: list[dict], module: str):
    """
    removes a module name from the puppet list
    Args:
        data:
        module:

    Returns:

    """
    ret_data = copy.deepcopy(data)
    module_names = assets.get_puppet_module_names(data)
    index = module_names.index(module)
    del ret_data[index]
    return ret_data


def get_puppet_identical_data(master_data: list, slave_data: list) -> list[dict]:
    """
    returns an identical dictionary with the compare result.
    Contains true if the entries match, False if they are missing or different
    Args:
        master_data:
        slave_data:

    Returns:

    """

    return [dict_filter.get_equal_dict(a_mod, b_mod) for a_mod, b_mod in zip(master_data, slave_data)]


def get_asset_filter_data(master_data, slave_data) -> list:
    filter_data = get_puppet_identical_data(master_data, slave_data)

    for i, data in enumerate(filter_data):
        filter_data[i] = dict_filter.get_compressed_delta_dict(data)

    return filter_data


def get_global_filter(slave_filter_list: list) -> list:
    """
    compares multiple datasets and returns the global filter, that's a sum of all filter data
    and the individual filter sets plus the missing modules
    Args:
        slave_filter_list:

    Returns:

    """

    global_filter = slave_filter_list[0]
    for slave_filter in slave_filter_list[1:]:
        for i, (global_data, slave_data) in enumerate(zip(global_filter, slave_filter)):
            global_filter[i] = dict_filter.merge_filter_dict(global_data, slave_data, True)

    return global_filter


def get_module_filtered_data(module_names, data: list):
    """
    Returns the data, matching the input module names.
    if the module does not exist, we get an empty dictionary
    Args:
        module_names:
        data:

    Returns:

    """
    mapping = {k: v for k, v in zip(assets.get_puppet_module_names(data), data)}
    return [mapping.get(k, {}) for k in module_names]
